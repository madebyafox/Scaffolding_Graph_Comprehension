var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["06042969070b5e18852b814333b599a0897a183d"] = {
  "startTime": "2018-06-04T20:25:28.869099Z",
  "websitePageUrl": "/16",
  "visitTime": 150401,
  "engagementTime": 124990,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "f12307c63c79fcb2f698796191e5781a",
    "created": "2018-06-04T20:25:28.869099+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=TTCWS",
      "CONDITION=211"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "9f37ce493a25c36e31677d927dced574",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/f12307c63c79fcb2f698796191e5781a/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 2200,
      "e": 2200,
      "ty": 2,
      "x": 1137,
      "y": 781
    },
    {
      "t": 2251,
      "e": 2251,
      "ty": 41,
      "x": 23607,
      "y": 45623,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 2301,
      "e": 2301,
      "ty": 2,
      "x": 1121,
      "y": 775
    },
    {
      "t": 2401,
      "e": 2401,
      "ty": 2,
      "x": 1118,
      "y": 774
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 23396,
      "y": 45552,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 2601,
      "e": 2601,
      "ty": 2,
      "x": 1106,
      "y": 768
    },
    {
      "t": 2702,
      "e": 2702,
      "ty": 2,
      "x": 721,
      "y": 652
    },
    {
      "t": 2735,
      "e": 2735,
      "ty": 6,
      "x": 498,
      "y": 599,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2750,
      "e": 2750,
      "ty": 41,
      "x": 35511,
      "y": 44713,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2801,
      "e": 2801,
      "ty": 2,
      "x": 303,
      "y": 559
    },
    {
      "t": 2901,
      "e": 2901,
      "ty": 2,
      "x": 300,
      "y": 559
    },
    {
      "t": 3002,
      "e": 3002,
      "ty": 41,
      "x": 22808,
      "y": 29341,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8601,
      "e": 8002,
      "ty": 2,
      "x": 284,
      "y": 547
    },
    {
      "t": 8701,
      "e": 8102,
      "ty": 2,
      "x": 270,
      "y": 538
    },
    {
      "t": 8752,
      "e": 8153,
      "ty": 41,
      "x": 19436,
      "y": 12351,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9001,
      "e": 8402,
      "ty": 2,
      "x": 259,
      "y": 544
    },
    {
      "t": 9001,
      "e": 8402,
      "ty": 41,
      "x": 18199,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9101,
      "e": 8502,
      "ty": 2,
      "x": 252,
      "y": 548
    },
    {
      "t": 9252,
      "e": 8653,
      "ty": 41,
      "x": 17413,
      "y": 20441,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9497,
      "e": 8898,
      "ty": 3,
      "x": 252,
      "y": 548,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9499,
      "e": 8900,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9664,
      "e": 9065,
      "ty": 4,
      "x": 17413,
      "y": 20441,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9664,
      "e": 9065,
      "ty": 5,
      "x": 252,
      "y": 548,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10001,
      "e": 9402,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 12053,
      "e": 11454,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12552,
      "e": 11953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12585,
      "e": 11986,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12618,
      "e": 12019,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12650,
      "e": 12051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12683,
      "e": 12084,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12716,
      "e": 12117,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12750,
      "e": 12151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12783,
      "e": 12184,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12816,
      "e": 12217,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12849,
      "e": 12250,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12882,
      "e": 12283,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12915,
      "e": 12316,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12948,
      "e": 12349,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12981,
      "e": 12382,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 13014,
      "e": 12415,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 13047,
      "e": 12448,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 13080,
      "e": 12481,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 13113,
      "e": 12514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 13124,
      "e": 12525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 13564,
      "e": 12965,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 13924,
      "e": 13325,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13925,
      "e": 13326,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13987,
      "e": 13388,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 14043,
      "e": 13444,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 14228,
      "e": 13629,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 14229,
      "e": 13630,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14308,
      "e": 13709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Tr"
    },
    {
      "t": 14492,
      "e": 13893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 14493,
      "e": 13894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14571,
      "e": 13972,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Tra"
    },
    {
      "t": 14772,
      "e": 14173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 14772,
      "e": 14173,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14867,
      "e": 14268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trac"
    },
    {
      "t": 14995,
      "e": 14396,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14996,
      "e": 14397,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15092,
      "e": 14493,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 15148,
      "e": 14549,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15149,
      "e": 14550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15251,
      "e": 14652,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15284,
      "e": 14685,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 15284,
      "e": 14685,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15388,
      "e": 14789,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 15436,
      "e": 14837,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 15437,
      "e": 14838,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15531,
      "e": 14932,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 15531,
      "e": 14932,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 15532,
      "e": 14933,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15603,
      "e": 15004,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 15676,
      "e": 15077,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15676,
      "e": 15077,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15763,
      "e": 15164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15948,
      "e": 15349,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 15949,
      "e": 15350,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16051,
      "e": 15452,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 16164,
      "e": 15565,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 16165,
      "e": 15566,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16292,
      "e": 15693,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 16372,
      "e": 15773,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 16372,
      "e": 15773,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16484,
      "e": 15885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 16900,
      "e": 16301,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 16900,
      "e": 16301,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16955,
      "e": 16356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 17172,
      "e": 16573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 17173,
      "e": 16574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17292,
      "e": 16693,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 17484,
      "e": 16885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 17485,
      "e": 16886,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17604,
      "e": 17005,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagon"
    },
    {
      "t": 17604,
      "e": 17005,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 18108,
      "e": 17509,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18109,
      "e": 17510,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18235,
      "e": 17636,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 18724,
      "e": 18125,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 18725,
      "e": 18126,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18811,
      "e": 18212,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 20001,
      "e": 19402,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 22660,
      "e": 22061,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22661,
      "e": 22062,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22780,
      "e": 22181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22940,
      "e": 22341,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 22940,
      "e": 22341,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23059,
      "e": 22460,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 23180,
      "e": 22581,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 23181,
      "e": 22582,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23292,
      "e": 22693,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 23396,
      "e": 22797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 23397,
      "e": 22798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23516,
      "e": 22917,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 23604,
      "e": 23005,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23605,
      "e": 23006,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23692,
      "e": 23093,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 23803,
      "e": 23204,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line"
    },
    {
      "t": 23812,
      "e": 23213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23812,
      "e": 23213,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23916,
      "e": 23317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25212,
      "e": 24613,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25213,
      "e": 24614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25308,
      "e": 24709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 25412,
      "e": 24813,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 25412,
      "e": 24813,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25532,
      "e": 24933,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 25548,
      "e": 24949,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25549,
      "e": 24950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25667,
      "e": 25068,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 25716,
      "e": 25117,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25716,
      "e": 25117,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25820,
      "e": 25221,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27084,
      "e": 26485,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 27086,
      "e": 26487,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27196,
      "e": 26597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 27316,
      "e": 26717,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27317,
      "e": 26718,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27403,
      "e": 26804,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 27475,
      "e": 26876,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 27475,
      "e": 26876,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27596,
      "e": 26997,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 27612,
      "e": 27013,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 27613,
      "e": 27014,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27699,
      "e": 27100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 27802,
      "e": 27203,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the star"
    },
    {
      "t": 27811,
      "e": 27212,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27811,
      "e": 27212,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27899,
      "e": 27300,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 28002,
      "e": 27403,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the start"
    },
    {
      "t": 28019,
      "e": 27420,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 28020,
      "e": 27421,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28091,
      "e": 27492,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 28164,
      "e": 27565,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28164,
      "e": 27565,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28260,
      "e": 27661,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28396,
      "e": 27797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 28396,
      "e": 27797,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28507,
      "e": 27908,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 28611,
      "e": 28012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28612,
      "e": 28013,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28699,
      "e": 28100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 28772,
      "e": 28173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28772,
      "e": 28173,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28876,
      "e": 28277,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29060,
      "e": 28461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 29061,
      "e": 28462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29179,
      "e": 28580,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 29908,
      "e": 29309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 29909,
      "e": 29310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30000,
      "e": 29401,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30011,
      "e": 29412,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 30109,
      "e": 29510,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30109,
      "e": 29510,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30187,
      "e": 29588,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30332,
      "e": 29733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 30332,
      "e": 29733,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30435,
      "e": 29836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 30579,
      "e": 29980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 30579,
      "e": 29980,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30675,
      "e": 30076,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 30788,
      "e": 30189,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30788,
      "e": 30189,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30884,
      "e": 30285,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30892,
      "e": 30293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 30893,
      "e": 30294,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30987,
      "e": 30388,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 31068,
      "e": 30469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 31068,
      "e": 30469,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31156,
      "e": 30557,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 31300,
      "e": 30701,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 31301,
      "e": 30702,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31388,
      "e": 30789,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 31412,
      "e": 30813,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31413,
      "e": 30814,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31491,
      "e": 30892,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31602,
      "e": 31003,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the starts at 12 pm and "
    },
    {
      "t": 31692,
      "e": 31093,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 31693,
      "e": 31094,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31787,
      "e": 31188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 31899,
      "e": 31300,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31900,
      "e": 31301,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32003,
      "e": 31404,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the starts at 12 pm and mo"
    },
    {
      "t": 32036,
      "e": 31437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 32084,
      "e": 31485,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 32084,
      "e": 31485,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32202,
      "e": 31603,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the starts at 12 pm and mov"
    },
    {
      "t": 32211,
      "e": 31612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 32364,
      "e": 31765,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 32365,
      "e": 31766,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32460,
      "e": 31861,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 32604,
      "e": 32005,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 32605,
      "e": 32006,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32708,
      "e": 32109,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 36564,
      "e": 35965,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37063,
      "e": 36464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37095,
      "e": 36496,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37129,
      "e": 36530,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37161,
      "e": 36562,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37194,
      "e": 36595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37228,
      "e": 36629,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37252,
      "e": 36653,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the starts at 12 pm an"
    },
    {
      "t": 37403,
      "e": 36804,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the starts at 12 pm an"
    },
    {
      "t": 38276,
      "e": 37677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 38277,
      "e": 37678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38380,
      "e": 37781,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 38443,
      "e": 37844,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38445,
      "e": 37846,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38555,
      "e": 37956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38788,
      "e": 38189,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 38789,
      "e": 38190,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38852,
      "e": 38253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 38979,
      "e": 38380,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 38980,
      "e": 38381,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39108,
      "e": 38509,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 39444,
      "e": 38845,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 39445,
      "e": 38846,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39580,
      "e": 38981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 39708,
      "e": 39109,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 39709,
      "e": 39110,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39819,
      "e": 39220,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 39940,
      "e": 39341,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 39941,
      "e": 39342,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40001,
      "e": 39402,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40019,
      "e": 39420,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 40187,
      "e": 39588,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40187,
      "e": 39588,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40316,
      "e": 39717,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41132,
      "e": 40533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41133,
      "e": 40534,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41235,
      "e": 40636,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 41300,
      "e": 40701,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 41300,
      "e": 40701,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41387,
      "e": 40788,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 41540,
      "e": 40941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41540,
      "e": 40941,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41619,
      "e": 41020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41643,
      "e": 41044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41643,
      "e": 41044,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41747,
      "e": 41148,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 41771,
      "e": 41172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 41773,
      "e": 41174,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41891,
      "e": 41292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 41891,
      "e": 41292,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 41891,
      "e": 41292,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41988,
      "e": 41389,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 42060,
      "e": 41461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42060,
      "e": 41461,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42147,
      "e": 41548,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 42870,
      "e": 42271,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 42871,
      "e": 42272,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42979,
      "e": 42380,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 43028,
      "e": 42429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 43028,
      "e": 42429,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43148,
      "e": 42549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 43205,
      "e": 42606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 43205,
      "e": 42606,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43291,
      "e": 42692,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 43307,
      "e": 42708,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 43307,
      "e": 42708,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43436,
      "e": 42837,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 43460,
      "e": 42861,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 43461,
      "e": 42862,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43555,
      "e": 42956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 44540,
      "e": 43941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 44541,
      "e": 43942,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44603,
      "e": 44004,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 45036,
      "e": 44437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 45195,
      "e": 44596,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the starts at 12 pm and moves to the right"
    },
    {
      "t": 45739,
      "e": 45140,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46240,
      "e": 45641,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46272,
      "e": 45673,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46305,
      "e": 45706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46338,
      "e": 45739,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46371,
      "e": 45772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46403,
      "e": 45804,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46437,
      "e": 45838,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46470,
      "e": 45871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46503,
      "e": 45904,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46536,
      "e": 45937,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46569,
      "e": 45970,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46595,
      "e": 45996,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the starts at 12 pm and moves "
    },
    {
      "t": 47467,
      "e": 46868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 47602,
      "e": 47003,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the starts at 12 pm and moves"
    },
    {
      "t": 47968,
      "e": 47369,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48000,
      "e": 47401,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48033,
      "e": 47434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48066,
      "e": 47467,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48098,
      "e": 47499,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48131,
      "e": 47532,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48155,
      "e": 47556,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the starts at 12 pm and"
    },
    {
      "t": 48696,
      "e": 48097,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48696,
      "e": 48097,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48792,
      "e": 48193,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49192,
      "e": 48593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 49193,
      "e": 48594,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49287,
      "e": 48688,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 49351,
      "e": 48752,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 49352,
      "e": 48753,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49415,
      "e": 48816,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 49800,
      "e": 49201,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49912,
      "e": 49313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the starts at 12 pm and g"
    },
    {
      "t": 49996,
      "e": 49397,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50024,
      "e": 49425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50111,
      "e": 49512,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the starts at 12 pm and "
    },
    {
      "t": 50288,
      "e": 49689,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 50289,
      "e": 49690,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50368,
      "e": 49769,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 50496,
      "e": 49897,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 50496,
      "e": 49897,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50592,
      "e": 49993,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 50664,
      "e": 50065,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 50664,
      "e": 50065,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50760,
      "e": 50161,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 50808,
      "e": 50209,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 50808,
      "e": 50209,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50903,
      "e": 50304,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 50903,
      "e": 50304,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50911,
      "e": 50312,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||le"
    },
    {
      "t": 50984,
      "e": 50385,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51104,
      "e": 50505,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 51105,
      "e": 50506,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51176,
      "e": 50577,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 51183,
      "e": 50584,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51183,
      "e": 50584,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51256,
      "e": 50657,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 51384,
      "e": 50785,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 51385,
      "e": 50786,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51487,
      "e": 50888,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 51592,
      "e": 50993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 51592,
      "e": 50993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51680,
      "e": 51081,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 51800,
      "e": 51201,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51801,
      "e": 51202,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51903,
      "e": 51304,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 51904,
      "e": 51305,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51912,
      "e": 51313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 51975,
      "e": 51376,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52007,
      "e": 51408,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 52007,
      "e": 51408,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52063,
      "e": 51464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 52064,
      "e": 51465,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52096,
      "e": 51497,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 52167,
      "e": 51568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52191,
      "e": 51592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52192,
      "e": 51593,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52272,
      "e": 51673,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 52304,
      "e": 51705,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 52305,
      "e": 51706,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52383,
      "e": 51784,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 52439,
      "e": 51840,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 52440,
      "e": 51841,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52560,
      "e": 51961,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 52592,
      "e": 51993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 52593,
      "e": 51994,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52687,
      "e": 52088,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 52696,
      "e": 52097,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 52696,
      "e": 52097,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52784,
      "e": 52185,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 52824,
      "e": 52225,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 52824,
      "e": 52225,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52911,
      "e": 52312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52912,
      "e": 52313,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52919,
      "e": 52320,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 52991,
      "e": 52392,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53104,
      "e": 52505,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 53105,
      "e": 52506,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53183,
      "e": 52584,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 53311,
      "e": 52712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 53311,
      "e": 52712,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53375,
      "e": 52776,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 53632,
      "e": 53033,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 53712,
      "e": 53113,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the starts at 12 pm and scales up the right o"
    },
    {
      "t": 53776,
      "e": 53177,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 53777,
      "e": 53178,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53863,
      "e": 53264,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 53880,
      "e": 53281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53880,
      "e": 53281,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53984,
      "e": 53385,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53992,
      "e": 53393,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 53992,
      "e": 53393,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54071,
      "e": 53472,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 54095,
      "e": 53496,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 54097,
      "e": 53498,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54192,
      "e": 53593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 54193,
      "e": 53594,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54200,
      "e": 53601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 54263,
      "e": 53664,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54319,
      "e": 53720,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54320,
      "e": 53721,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54424,
      "e": 53825,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 54440,
      "e": 53841,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 54440,
      "e": 53841,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54504,
      "e": 53905,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 54640,
      "e": 54041,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 54641,
      "e": 54042,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54719,
      "e": 54120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 54831,
      "e": 54232,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 54832,
      "e": 54233,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54944,
      "e": 54345,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 54976,
      "e": 54377,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 54976,
      "e": 54377,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55055,
      "e": 54456,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 55160,
      "e": 54561,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 55160,
      "e": 54561,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55240,
      "e": 54641,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 55248,
      "e": 54649,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 55249,
      "e": 54650,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55327,
      "e": 54728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 55464,
      "e": 54865,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 55465,
      "e": 54866,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55559,
      "e": 54960,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 55688,
      "e": 55089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55689,
      "e": 55090,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55767,
      "e": 55168,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55871,
      "e": 55272,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 56136,
      "e": 55537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 56136,
      "e": 55537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56224,
      "e": 55625,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||W"
    },
    {
      "t": 56234,
      "e": 55627,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56351,
      "e": 55744,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 56351,
      "e": 55744,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56424,
      "e": 55817,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 56424,
      "e": 55817,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56455,
      "e": 55848,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 56528,
      "e": 55921,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56656,
      "e": 56049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 56657,
      "e": 56050,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56751,
      "e": 56144,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 56928,
      "e": 56321,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 56929,
      "e": 56322,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56999,
      "e": 56392,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 57168,
      "e": 56561,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 57168,
      "e": 56561,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57215,
      "e": 56608,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 57464,
      "e": 56857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 57464,
      "e": 56857,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57567,
      "e": 56960,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 57568,
      "e": 56961,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57623,
      "e": 57016,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 57696,
      "e": 57089,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57720,
      "e": 57113,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57721,
      "e": 57114,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57816,
      "e": 57209,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57952,
      "e": 57345,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 57953,
      "e": 57346,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58065,
      "e": 57458,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 58400,
      "e": 57793,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 58401,
      "e": 57794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58479,
      "e": 57872,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 58600,
      "e": 57993,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the starts at 12 pm and scales up the right of the screen. Whatever po"
    },
    {
      "t": 58600,
      "e": 57993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 58601,
      "e": 57994,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58671,
      "e": 58064,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 58784,
      "e": 58177,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 58784,
      "e": 58177,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58872,
      "e": 58265,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 58872,
      "e": 58265,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58895,
      "e": 58288,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nt"
    },
    {
      "t": 58951,
      "e": 58344,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 59064,
      "e": 58457,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 59065,
      "e": 58458,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59151,
      "e": 58544,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 59208,
      "e": 58601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59208,
      "e": 58601,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59312,
      "e": 58705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 60049,
      "e": 59442,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 60049,
      "e": 59442,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60127,
      "e": 59520,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 60247,
      "e": 59640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 60248,
      "e": 59641,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60345,
      "e": 59738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 60402,
      "e": 59795,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 60403,
      "e": 59796,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60487,
      "e": 59880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 60584,
      "e": 59977,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 60584,
      "e": 59977,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60688,
      "e": 60081,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 60840,
      "e": 60233,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60840,
      "e": 60233,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60879,
      "e": 60272,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 60999,
      "e": 60392,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the starts at 12 pm and scales up the right of the screen. Whatever points fall "
    },
    {
      "t": 61472,
      "e": 60865,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 61473,
      "e": 60866,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61551,
      "e": 60944,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 61688,
      "e": 61081,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 61689,
      "e": 61082,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61783,
      "e": 61176,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 62295,
      "e": 61688,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 62368,
      "e": 61761,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the starts at 12 pm and scales up the right of the screen. Whatever points fall p"
    },
    {
      "t": 62488,
      "e": 61881,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 62567,
      "e": 61960,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the starts at 12 pm and scales up the right of the screen. Whatever points fall "
    },
    {
      "t": 63008,
      "e": 62401,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 63009,
      "e": 62402,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63120,
      "e": 62513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 63224,
      "e": 62617,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 63225,
      "e": 62618,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63312,
      "e": 62618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 63424,
      "e": 62730,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 63424,
      "e": 62730,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63495,
      "e": 62801,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 63536,
      "e": 62842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 63536,
      "e": 62842,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63615,
      "e": 62921,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 63656,
      "e": 62962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 63656,
      "e": 62962,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63751,
      "e": 63057,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 63751,
      "e": 63057,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63768,
      "e": 63074,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 63831,
      "e": 63137,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 63889,
      "e": 63195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 63889,
      "e": 63195,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63999,
      "e": 63305,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the starts at 12 pm and scales up the right of the screen. Whatever points fall on the "
    },
    {
      "t": 64000,
      "e": 63306,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 64424,
      "e": 63730,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 64527,
      "e": 63833,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the starts at 12 pm and scales up the right of the screen. Whatever points fall on the"
    },
    {
      "t": 64615,
      "e": 63921,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 64712,
      "e": 64018,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the starts at 12 pm and scales up the right of the screen. Whatever points fall on th"
    },
    {
      "t": 65000,
      "e": 64306,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 65001,
      "e": 64307,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65135,
      "e": 64441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 65408,
      "e": 64714,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 65409,
      "e": 64715,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65495,
      "e": 64801,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 65528,
      "e": 64834,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 65528,
      "e": 64834,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65632,
      "e": 64938,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 65768,
      "e": 65074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 65768,
      "e": 65074,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65855,
      "e": 65161,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 65967,
      "e": 65273,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 65969,
      "e": 65275,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66039,
      "e": 65345,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 66112,
      "e": 65418,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 66112,
      "e": 65418,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66215,
      "e": 65521,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 66215,
      "e": 65521,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66223,
      "e": 65529,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ne"
    },
    {
      "t": 66311,
      "e": 65617,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66359,
      "e": 65665,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 66359,
      "e": 65665,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66463,
      "e": 65769,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 66471,
      "e": 65777,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 66473,
      "e": 65779,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66575,
      "e": 65881,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 66665,
      "e": 65971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 66665,
      "e": 65971,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66776,
      "e": 66082,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 66776,
      "e": 66082,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66791,
      "e": 66097,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 66879,
      "e": 66185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 66879,
      "e": 66185,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66911,
      "e": 66217,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 66983,
      "e": 66289,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 67024,
      "e": 66330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 67024,
      "e": 66330,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67096,
      "e": 66402,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 67097,
      "e": 66403,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67135,
      "e": 66441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 67223,
      "e": 66529,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 67224,
      "e": 66530,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 67224,
      "e": 66530,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67352,
      "e": 66658,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 67360,
      "e": 66666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67360,
      "e": 66666,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67471,
      "e": 66777,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 67697,
      "e": 67003,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 67698,
      "e": 67004,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67791,
      "e": 67097,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 68032,
      "e": 67338,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 68033,
      "e": 67339,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68167,
      "e": 67473,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 68240,
      "e": 67546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 68240,
      "e": 67546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68392,
      "e": 67698,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 68393,
      "e": 67699,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68400,
      "e": 67706,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||is"
    },
    {
      "t": 68504,
      "e": 67810,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 68624,
      "e": 67930,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 68625,
      "e": 67931,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68695,
      "e": 68001,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 68799,
      "e": 68001,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the starts at 12 pm and scales up the right of the screen. Whatever points fall on that line are the shist"
    },
    {
      "t": 68815,
      "e": 68017,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 68815,
      "e": 68017,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68904,
      "e": 68106,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 68935,
      "e": 68137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 68935,
      "e": 68137,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69039,
      "e": 68241,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 69063,
      "e": 68265,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 69064,
      "e": 68266,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69160,
      "e": 68362,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 69184,
      "e": 68386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 69184,
      "e": 68386,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69311,
      "e": 68513,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 69311,
      "e": 68513,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69319,
      "e": 68521,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 69399,
      "e": 68601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 69495,
      "e": 68697,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 69496,
      "e": 68698,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69591,
      "e": 68793,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 69631,
      "e": 68833,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69631,
      "e": 68833,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69727,
      "e": 68929,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 69759,
      "e": 68961,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 69760,
      "e": 68962,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69888,
      "e": 69090,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 69968,
      "e": 69170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 69969,
      "e": 69171,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70063,
      "e": 69265,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 70159,
      "e": 69361,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 70160,
      "e": 69362,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70280,
      "e": 69482,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 70281,
      "e": 69483,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70287,
      "e": 69489,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 70384,
      "e": 69586,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 70515,
      "e": 69717,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 70515,
      "e": 69717,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70607,
      "e": 69809,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 70655,
      "e": 69857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 70655,
      "e": 69857,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70768,
      "e": 69970,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 70776,
      "e": 69978,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 70777,
      "e": 69979,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70864,
      "e": 70066,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 70968,
      "e": 70170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 70969,
      "e": 70171,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71063,
      "e": 70265,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 71135,
      "e": 70337,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 71136,
      "e": 70338,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71247,
      "e": 70449,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 71407,
      "e": 70609,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 71480,
      "e": 70682,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 71776,
      "e": 70978,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 71863,
      "e": 71065,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the starts at 12 pm and scales up the right of the screen. Whatever points fall on that line are the shists that start at"
    },
    {
      "t": 72223,
      "e": 71425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 72224,
      "e": 71426,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72383,
      "e": 71585,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 72392,
      "e": 71594,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 72392,
      "e": 71594,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72552,
      "e": 71754,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 72600,
      "e": 71802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 72601,
      "e": 71803,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72663,
      "e": 71865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 72799,
      "e": 72001,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the starts at 12 pm and scales up the right of the screen. Whatever points fall on that line are the shists that start at 12"
    },
    {
      "t": 72920,
      "e": 72122,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 72920,
      "e": 72122,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73032,
      "e": 72234,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 73128,
      "e": 72330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 73128,
      "e": 72330,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73207,
      "e": 72409,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 73352,
      "e": 72554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "191"
    },
    {
      "t": 73353,
      "e": 72555,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73472,
      "e": 72674,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||/"
    },
    {
      "t": 74696,
      "e": 73898,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 74783,
      "e": 73898,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the starts at 12 pm and scales up the right of the screen. Whatever points fall on that line are the shists that start at 12pm"
    },
    {
      "t": 74951,
      "e": 74066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 74951,
      "e": 74066,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75031,
      "e": 74146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 75740,
      "e": 74855,
      "ty": 7,
      "x": 0,
      "y": 575,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75747,
      "e": 74862,
      "ty": 41,
      "x": 0,
      "y": 31853,
      "ta": "html"
    },
    {
      "t": 75797,
      "e": 74912,
      "ty": 2,
      "x": 0,
      "y": 605
    },
    {
      "t": 75897,
      "e": 75012,
      "ty": 2,
      "x": 0,
      "y": 622
    },
    {
      "t": 75992,
      "e": 75107,
      "ty": 6,
      "x": 380,
      "y": 674,
      "ta": "#strategyButton"
    },
    {
      "t": 75996,
      "e": 75111,
      "ty": 2,
      "x": 380,
      "y": 674
    },
    {
      "t": 75998,
      "e": 75113,
      "ty": 41,
      "x": 22612,
      "y": 37134,
      "ta": "#strategyButton"
    },
    {
      "t": 76008,
      "e": 75123,
      "ty": 7,
      "x": 522,
      "y": 642,
      "ta": "#strategyButton"
    },
    {
      "t": 76024,
      "e": 75139,
      "ty": 6,
      "x": 643,
      "y": 596,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76041,
      "e": 75156,
      "ty": 7,
      "x": 706,
      "y": 571,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76096,
      "e": 75211,
      "ty": 2,
      "x": 719,
      "y": 564
    },
    {
      "t": 76158,
      "e": 75273,
      "ty": 6,
      "x": 659,
      "y": 546,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76197,
      "e": 75312,
      "ty": 2,
      "x": 542,
      "y": 546
    },
    {
      "t": 76248,
      "e": 75363,
      "ty": 41,
      "x": 44278,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76297,
      "e": 75412,
      "ty": 2,
      "x": 491,
      "y": 544
    },
    {
      "t": 76397,
      "e": 75512,
      "ty": 2,
      "x": 493,
      "y": 550
    },
    {
      "t": 76497,
      "e": 75612,
      "ty": 2,
      "x": 494,
      "y": 551
    },
    {
      "t": 76498,
      "e": 75613,
      "ty": 41,
      "x": 44616,
      "y": 22868,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76556,
      "e": 75671,
      "ty": 3,
      "x": 494,
      "y": 551,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76700,
      "e": 75815,
      "ty": 4,
      "x": 44616,
      "y": 22868,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76701,
      "e": 75816,
      "ty": 5,
      "x": 494,
      "y": 551,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77304,
      "e": 76419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 77415,
      "e": 76530,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the starts at 12 pm and scales up the right of the screen. Whatever points fall on that line are the shits that start at 12pm."
    },
    {
      "t": 77647,
      "e": 76762,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 77648,
      "e": 76763,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77719,
      "e": 76834,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the starts at 12 pm and scales up the right of the screen. Whatever points fall on that line are the shifts that start at 12pm."
    },
    {
      "t": 78493,
      "e": 77608,
      "ty": 7,
      "x": 472,
      "y": 623,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78497,
      "e": 77612,
      "ty": 2,
      "x": 472,
      "y": 623
    },
    {
      "t": 78498,
      "e": 77613,
      "ty": 41,
      "x": 42143,
      "y": 34069,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 78525,
      "e": 77640,
      "ty": 6,
      "x": 451,
      "y": 657,
      "ta": "#strategyButton"
    },
    {
      "t": 78597,
      "e": 77712,
      "ty": 2,
      "x": 446,
      "y": 664
    },
    {
      "t": 78748,
      "e": 77863,
      "ty": 41,
      "x": 44457,
      "y": 35206,
      "ta": "#strategyButton"
    },
    {
      "t": 78797,
      "e": 77912,
      "ty": 2,
      "x": 415,
      "y": 673
    },
    {
      "t": 78932,
      "e": 78047,
      "ty": 7,
      "x": 440,
      "y": 650,
      "ta": "#strategyButton"
    },
    {
      "t": 78959,
      "e": 78074,
      "ty": 6,
      "x": 533,
      "y": 568,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78977,
      "e": 78092,
      "ty": 7,
      "x": 598,
      "y": 518,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78997,
      "e": 78112,
      "ty": 2,
      "x": 657,
      "y": 475
    },
    {
      "t": 78997,
      "e": 78112,
      "ty": 41,
      "x": 62939,
      "y": 25870,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 79098,
      "e": 78213,
      "ty": 2,
      "x": 714,
      "y": 442
    },
    {
      "t": 79197,
      "e": 78312,
      "ty": 2,
      "x": 723,
      "y": 468
    },
    {
      "t": 79248,
      "e": 78363,
      "ty": 41,
      "x": 1257,
      "y": 25915,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 79298,
      "e": 78413,
      "ty": 2,
      "x": 689,
      "y": 515
    },
    {
      "t": 79377,
      "e": 78492,
      "ty": 6,
      "x": 668,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79397,
      "e": 78512,
      "ty": 2,
      "x": 666,
      "y": 523
    },
    {
      "t": 79497,
      "e": 78612,
      "ty": 2,
      "x": 666,
      "y": 530
    },
    {
      "t": 79497,
      "e": 78612,
      "ty": 41,
      "x": 63950,
      "y": 5878,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79597,
      "e": 78712,
      "ty": 2,
      "x": 667,
      "y": 539
    },
    {
      "t": 79697,
      "e": 78812,
      "ty": 2,
      "x": 667,
      "y": 544
    },
    {
      "t": 79747,
      "e": 78862,
      "ty": 41,
      "x": 64063,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79897,
      "e": 79012,
      "ty": 2,
      "x": 668,
      "y": 547
    },
    {
      "t": 79997,
      "e": 79112,
      "ty": 2,
      "x": 669,
      "y": 567
    },
    {
      "t": 79997,
      "e": 79112,
      "ty": 41,
      "x": 64287,
      "y": 35814,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79998,
      "e": 79113,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80097,
      "e": 79212,
      "ty": 2,
      "x": 669,
      "y": 570
    },
    {
      "t": 80197,
      "e": 79312,
      "ty": 2,
      "x": 653,
      "y": 562
    },
    {
      "t": 80248,
      "e": 79363,
      "ty": 41,
      "x": 62489,
      "y": 31768,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80298,
      "e": 79413,
      "ty": 2,
      "x": 645,
      "y": 562
    },
    {
      "t": 80397,
      "e": 79512,
      "ty": 2,
      "x": 547,
      "y": 564
    },
    {
      "t": 80498,
      "e": 79613,
      "ty": 2,
      "x": 539,
      "y": 560
    },
    {
      "t": 80498,
      "e": 79613,
      "ty": 41,
      "x": 49674,
      "y": 30150,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80598,
      "e": 79713,
      "ty": 2,
      "x": 545,
      "y": 554
    },
    {
      "t": 80697,
      "e": 79812,
      "ty": 2,
      "x": 558,
      "y": 557
    },
    {
      "t": 80748,
      "e": 79863,
      "ty": 41,
      "x": 51810,
      "y": 30150,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80798,
      "e": 79913,
      "ty": 2,
      "x": 556,
      "y": 561
    },
    {
      "t": 80898,
      "e": 80013,
      "ty": 2,
      "x": 537,
      "y": 560
    },
    {
      "t": 80997,
      "e": 80112,
      "ty": 2,
      "x": 516,
      "y": 557
    },
    {
      "t": 80997,
      "e": 80112,
      "ty": 41,
      "x": 47089,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81097,
      "e": 80212,
      "ty": 2,
      "x": 497,
      "y": 553
    },
    {
      "t": 81197,
      "e": 80312,
      "ty": 2,
      "x": 452,
      "y": 553
    },
    {
      "t": 81248,
      "e": 80363,
      "ty": 41,
      "x": 37084,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81297,
      "e": 80412,
      "ty": 2,
      "x": 414,
      "y": 553
    },
    {
      "t": 81398,
      "e": 80513,
      "ty": 2,
      "x": 391,
      "y": 555
    },
    {
      "t": 81497,
      "e": 80612,
      "ty": 2,
      "x": 374,
      "y": 553
    },
    {
      "t": 81497,
      "e": 80612,
      "ty": 41,
      "x": 31127,
      "y": 24487,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81597,
      "e": 80712,
      "ty": 2,
      "x": 353,
      "y": 550
    },
    {
      "t": 81698,
      "e": 80813,
      "ty": 2,
      "x": 315,
      "y": 550
    },
    {
      "t": 81747,
      "e": 80862,
      "ty": 41,
      "x": 21459,
      "y": 22059,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81797,
      "e": 80912,
      "ty": 2,
      "x": 272,
      "y": 547
    },
    {
      "t": 81897,
      "e": 81012,
      "ty": 2,
      "x": 248,
      "y": 545
    },
    {
      "t": 81997,
      "e": 81112,
      "ty": 2,
      "x": 249,
      "y": 545
    },
    {
      "t": 81997,
      "e": 81112,
      "ty": 41,
      "x": 17075,
      "y": 18014,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82097,
      "e": 81212,
      "ty": 2,
      "x": 281,
      "y": 552
    },
    {
      "t": 82197,
      "e": 81312,
      "ty": 2,
      "x": 298,
      "y": 554
    },
    {
      "t": 82248,
      "e": 81363,
      "ty": 41,
      "x": 22921,
      "y": 25296,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82297,
      "e": 81412,
      "ty": 2,
      "x": 304,
      "y": 554
    },
    {
      "t": 82398,
      "e": 81513,
      "ty": 2,
      "x": 326,
      "y": 553
    },
    {
      "t": 82498,
      "e": 81613,
      "ty": 2,
      "x": 363,
      "y": 546
    },
    {
      "t": 82498,
      "e": 81613,
      "ty": 41,
      "x": 29890,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82597,
      "e": 81712,
      "ty": 2,
      "x": 391,
      "y": 543
    },
    {
      "t": 82697,
      "e": 81812,
      "ty": 2,
      "x": 411,
      "y": 543
    },
    {
      "t": 82748,
      "e": 81863,
      "ty": 41,
      "x": 37646,
      "y": 13969,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82797,
      "e": 81912,
      "ty": 2,
      "x": 449,
      "y": 537
    },
    {
      "t": 82897,
      "e": 82012,
      "ty": 2,
      "x": 451,
      "y": 537
    },
    {
      "t": 82997,
      "e": 82112,
      "ty": 2,
      "x": 462,
      "y": 537
    },
    {
      "t": 82998,
      "e": 82113,
      "ty": 41,
      "x": 41019,
      "y": 11541,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83098,
      "e": 82213,
      "ty": 2,
      "x": 473,
      "y": 543
    },
    {
      "t": 83198,
      "e": 82313,
      "ty": 2,
      "x": 523,
      "y": 547
    },
    {
      "t": 83248,
      "e": 82363,
      "ty": 41,
      "x": 50911,
      "y": 19632,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83298,
      "e": 82413,
      "ty": 2,
      "x": 591,
      "y": 549
    },
    {
      "t": 83396,
      "e": 82511,
      "ty": 2,
      "x": 641,
      "y": 555
    },
    {
      "t": 83497,
      "e": 82612,
      "ty": 2,
      "x": 674,
      "y": 558
    },
    {
      "t": 83498,
      "e": 82613,
      "ty": 41,
      "x": 64850,
      "y": 28532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83598,
      "e": 82713,
      "ty": 2,
      "x": 678,
      "y": 558
    },
    {
      "t": 83697,
      "e": 82812,
      "ty": 2,
      "x": 680,
      "y": 557
    },
    {
      "t": 83748,
      "e": 82863,
      "ty": 41,
      "x": 65524,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83798,
      "e": 82913,
      "ty": 2,
      "x": 627,
      "y": 556
    },
    {
      "t": 83897,
      "e": 83012,
      "ty": 2,
      "x": 509,
      "y": 551
    },
    {
      "t": 83998,
      "e": 83113,
      "ty": 2,
      "x": 471,
      "y": 551
    },
    {
      "t": 83998,
      "e": 83113,
      "ty": 41,
      "x": 42030,
      "y": 22868,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84097,
      "e": 83212,
      "ty": 2,
      "x": 390,
      "y": 551
    },
    {
      "t": 84198,
      "e": 83313,
      "ty": 2,
      "x": 372,
      "y": 550
    },
    {
      "t": 84248,
      "e": 83363,
      "ty": 41,
      "x": 27305,
      "y": 21250,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84298,
      "e": 83413,
      "ty": 2,
      "x": 314,
      "y": 544
    },
    {
      "t": 84398,
      "e": 83513,
      "ty": 2,
      "x": 286,
      "y": 537
    },
    {
      "t": 84497,
      "e": 83612,
      "ty": 2,
      "x": 274,
      "y": 533
    },
    {
      "t": 84497,
      "e": 83612,
      "ty": 41,
      "x": 19886,
      "y": 8305,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84698,
      "e": 83813,
      "ty": 2,
      "x": 279,
      "y": 536
    },
    {
      "t": 84749,
      "e": 83864,
      "ty": 41,
      "x": 25731,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84797,
      "e": 83912,
      "ty": 2,
      "x": 373,
      "y": 536
    },
    {
      "t": 84898,
      "e": 84013,
      "ty": 2,
      "x": 409,
      "y": 536
    },
    {
      "t": 84997,
      "e": 84112,
      "ty": 2,
      "x": 417,
      "y": 535
    },
    {
      "t": 84997,
      "e": 84112,
      "ty": 41,
      "x": 35960,
      "y": 9923,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85097,
      "e": 84212,
      "ty": 2,
      "x": 452,
      "y": 534
    },
    {
      "t": 85197,
      "e": 84312,
      "ty": 2,
      "x": 490,
      "y": 530
    },
    {
      "t": 85247,
      "e": 84362,
      "ty": 41,
      "x": 44278,
      "y": 5878,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85297,
      "e": 84412,
      "ty": 2,
      "x": 491,
      "y": 530
    },
    {
      "t": 85498,
      "e": 84613,
      "ty": 2,
      "x": 515,
      "y": 529
    },
    {
      "t": 85499,
      "e": 84614,
      "ty": 41,
      "x": 46976,
      "y": 5069,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85598,
      "e": 84713,
      "ty": 2,
      "x": 597,
      "y": 527
    },
    {
      "t": 85697,
      "e": 84812,
      "ty": 2,
      "x": 599,
      "y": 527
    },
    {
      "t": 85748,
      "e": 84863,
      "ty": 41,
      "x": 56981,
      "y": 1833,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85798,
      "e": 84913,
      "ty": 2,
      "x": 620,
      "y": 523
    },
    {
      "t": 85897,
      "e": 85012,
      "ty": 2,
      "x": 631,
      "y": 523
    },
    {
      "t": 85997,
      "e": 85112,
      "ty": 2,
      "x": 658,
      "y": 523
    },
    {
      "t": 85998,
      "e": 85113,
      "ty": 41,
      "x": 63051,
      "y": 214,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86098,
      "e": 85213,
      "ty": 2,
      "x": 648,
      "y": 535
    },
    {
      "t": 86198,
      "e": 85313,
      "ty": 2,
      "x": 571,
      "y": 562
    },
    {
      "t": 86248,
      "e": 85363,
      "ty": 41,
      "x": 49112,
      "y": 46332,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86297,
      "e": 85412,
      "ty": 2,
      "x": 515,
      "y": 595
    },
    {
      "t": 86316,
      "e": 85431,
      "ty": 7,
      "x": 498,
      "y": 616,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86398,
      "e": 85513,
      "ty": 2,
      "x": 487,
      "y": 631
    },
    {
      "t": 86483,
      "e": 85598,
      "ty": 6,
      "x": 450,
      "y": 655,
      "ta": "#strategyButton"
    },
    {
      "t": 86498,
      "e": 85613,
      "ty": 2,
      "x": 450,
      "y": 655
    },
    {
      "t": 86498,
      "e": 85613,
      "ty": 41,
      "x": 60841,
      "y": 511,
      "ta": "#strategyButton"
    },
    {
      "t": 86597,
      "e": 85712,
      "ty": 2,
      "x": 442,
      "y": 660
    },
    {
      "t": 86697,
      "e": 85812,
      "ty": 2,
      "x": 435,
      "y": 665
    },
    {
      "t": 86748,
      "e": 85863,
      "ty": 41,
      "x": 52649,
      "y": 19786,
      "ta": "#strategyButton"
    },
    {
      "t": 86763,
      "e": 85878,
      "ty": 3,
      "x": 435,
      "y": 665,
      "ta": "#strategyButton"
    },
    {
      "t": 86764,
      "e": 85879,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trace the diagonal line the starts at 12 pm and scales up the right of the screen. Whatever points fall on that line are the shifts that start at 12pm."
    },
    {
      "t": 86764,
      "e": 85879,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86764,
      "e": 85879,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 86893,
      "e": 86008,
      "ty": 4,
      "x": 52649,
      "y": 19786,
      "ta": "#strategyButton"
    },
    {
      "t": 86908,
      "e": 86023,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 86909,
      "e": 86024,
      "ty": 5,
      "x": 435,
      "y": 665,
      "ta": "#strategyButton"
    },
    {
      "t": 86915,
      "e": 86030,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 86998,
      "e": 86113,
      "ty": 2,
      "x": 466,
      "y": 654
    },
    {
      "t": 86998,
      "e": 86113,
      "ty": 41,
      "x": 15772,
      "y": 35786,
      "ta": "html > body"
    },
    {
      "t": 87097,
      "e": 86212,
      "ty": 2,
      "x": 1088,
      "y": 467
    },
    {
      "t": 87197,
      "e": 86312,
      "ty": 2,
      "x": 1410,
      "y": 311
    },
    {
      "t": 87248,
      "e": 86363,
      "ty": 41,
      "x": 49142,
      "y": 16065,
      "ta": "html > body"
    },
    {
      "t": 87298,
      "e": 86413,
      "ty": 2,
      "x": 1439,
      "y": 297
    },
    {
      "t": 87498,
      "e": 86613,
      "ty": 41,
      "x": 49280,
      "y": 16009,
      "ta": "html > body"
    },
    {
      "t": 87916,
      "e": 87031,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 88698,
      "e": 87813,
      "ty": 2,
      "x": 1249,
      "y": 396
    },
    {
      "t": 88748,
      "e": 87863,
      "ty": 41,
      "x": 39982,
      "y": 23876,
      "ta": "html > body"
    },
    {
      "t": 88798,
      "e": 87913,
      "ty": 2,
      "x": 1122,
      "y": 472
    },
    {
      "t": 88898,
      "e": 88013,
      "ty": 2,
      "x": 1053,
      "y": 526
    },
    {
      "t": 88985,
      "e": 88100,
      "ty": 6,
      "x": 1024,
      "y": 557,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 88997,
      "e": 88112,
      "ty": 2,
      "x": 1024,
      "y": 557
    },
    {
      "t": 88998,
      "e": 88113,
      "ty": 41,
      "x": 46718,
      "y": 9362,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 89097,
      "e": 88212,
      "ty": 2,
      "x": 1004,
      "y": 572
    },
    {
      "t": 89188,
      "e": 88303,
      "ty": 3,
      "x": 1004,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 89190,
      "e": 88305,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 89248,
      "e": 88363,
      "ty": 41,
      "x": 42392,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 89283,
      "e": 88398,
      "ty": 4,
      "x": 42392,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 89283,
      "e": 88398,
      "ty": 5,
      "x": 1004,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 89997,
      "e": 89112,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90512,
      "e": 89627,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 90512,
      "e": 89627,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 90623,
      "e": 89738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 90647,
      "e": 89762,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 90647,
      "e": 89762,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 90735,
      "e": 89850,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 91120,
      "e": 90235,
      "ty": 7,
      "x": 842,
      "y": 551,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 91197,
      "e": 90312,
      "ty": 2,
      "x": 188,
      "y": 322
    },
    {
      "t": 91247,
      "e": 90362,
      "ty": 41,
      "x": 5406,
      "y": 19444,
      "ta": "html > body"
    },
    {
      "t": 91297,
      "e": 90412,
      "ty": 2,
      "x": 169,
      "y": 379
    },
    {
      "t": 91396,
      "e": 90511,
      "ty": 2,
      "x": 401,
      "y": 485
    },
    {
      "t": 91497,
      "e": 90612,
      "ty": 2,
      "x": 930,
      "y": 553
    },
    {
      "t": 91497,
      "e": 90612,
      "ty": 41,
      "x": 26387,
      "y": 44394,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 91573,
      "e": 90688,
      "ty": 6,
      "x": 930,
      "y": 555,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 91597,
      "e": 90712,
      "ty": 2,
      "x": 930,
      "y": 558
    },
    {
      "t": 91636,
      "e": 90751,
      "ty": 7,
      "x": 908,
      "y": 582,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 91697,
      "e": 90812,
      "ty": 2,
      "x": 866,
      "y": 628
    },
    {
      "t": 91704,
      "e": 90819,
      "ty": 6,
      "x": 855,
      "y": 651,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91747,
      "e": 90862,
      "ty": 41,
      "x": 8435,
      "y": 59293,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91788,
      "e": 90903,
      "ty": 7,
      "x": 845,
      "y": 668,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91796,
      "e": 90911,
      "ty": 2,
      "x": 845,
      "y": 668
    },
    {
      "t": 91897,
      "e": 91012,
      "ty": 2,
      "x": 839,
      "y": 672
    },
    {
      "t": 91932,
      "e": 91047,
      "ty": 3,
      "x": 839,
      "y": 672,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 91932,
      "e": 91047,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 91932,
      "e": 91047,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 91997,
      "e": 91112,
      "ty": 41,
      "x": 6704,
      "y": 62716,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 92083,
      "e": 91198,
      "ty": 4,
      "x": 6704,
      "y": 62716,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 92084,
      "e": 91199,
      "ty": 5,
      "x": 839,
      "y": 672,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 92197,
      "e": 91312,
      "ty": 2,
      "x": 835,
      "y": 669
    },
    {
      "t": 92221,
      "e": 91336,
      "ty": 6,
      "x": 829,
      "y": 662,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92247,
      "e": 91362,
      "ty": 41,
      "x": 3676,
      "y": 24965,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92296,
      "e": 91411,
      "ty": 2,
      "x": 824,
      "y": 654
    },
    {
      "t": 92340,
      "e": 91455,
      "ty": 3,
      "x": 824,
      "y": 654,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92340,
      "e": 91455,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92443,
      "e": 91558,
      "ty": 4,
      "x": 3460,
      "y": 21845,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92444,
      "e": 91559,
      "ty": 5,
      "x": 824,
      "y": 654,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92498,
      "e": 91613,
      "ty": 41,
      "x": 3460,
      "y": 21845,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 93032,
      "e": 92147,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 93240,
      "e": 92355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 93240,
      "e": 92355,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 93279,
      "e": 92394,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 93343,
      "e": 92458,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 93464,
      "e": 92579,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 93465,
      "e": 92580,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 93543,
      "e": 92658,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un"
    },
    {
      "t": 93631,
      "e": 92746,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 93631,
      "e": 92746,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 93752,
      "e": 92867,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 93912,
      "e": 93027,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 93912,
      "e": 93027,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94006,
      "e": 93121,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 94056,
      "e": 93171,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 94056,
      "e": 93171,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94143,
      "e": 93258,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 94232,
      "e": 93347,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 94232,
      "e": 93347,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94311,
      "e": 93426,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 94351,
      "e": 93466,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 94351,
      "e": 93466,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94439,
      "e": 93554,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 94512,
      "e": 93627,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 94607,
      "e": 93722,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 94609,
      "e": 93724,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94671,
      "e": 93786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 94679,
      "e": 93794,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 94743,
      "e": 93858,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 94748,
      "e": 93863,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94863,
      "e": 93978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 94935,
      "e": 94050,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 94936,
      "e": 94051,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95064,
      "e": 94179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 95071,
      "e": 94186,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 95072,
      "e": 94187,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95198,
      "e": 94313,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United Stat"
    },
    {
      "t": 95199,
      "e": 94314,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 95215,
      "e": 94330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 95215,
      "e": 94330,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95336,
      "e": 94451,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 95480,
      "e": 94595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 95480,
      "e": 94595,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95560,
      "e": 94675,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 95696,
      "e": 94811,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 95697,
      "e": 94812,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95783,
      "e": 94898,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 95911,
      "e": 95026,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "80"
    },
    {
      "t": 95913,
      "e": 95028,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 96015,
      "e": 95130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||p"
    },
    {
      "t": 96096,
      "e": 95211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "70"
    },
    {
      "t": 96096,
      "e": 95211,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 96168,
      "e": 95283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||f"
    },
    {
      "t": 96207,
      "e": 95322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 96207,
      "e": 95322,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 96303,
      "e": 95418,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 96511,
      "e": 95626,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 96575,
      "e": 95690,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States pf"
    },
    {
      "t": 96663,
      "e": 95778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 96736,
      "e": 95851,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States p"
    },
    {
      "t": 96832,
      "e": 95947,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 96912,
      "e": 96027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States "
    },
    {
      "t": 97320,
      "e": 96435,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "79"
    },
    {
      "t": 97321,
      "e": 96436,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 97406,
      "e": 96521,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||o"
    },
    {
      "t": 97535,
      "e": 96650,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "70"
    },
    {
      "t": 97536,
      "e": 96651,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 97608,
      "e": 96723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||f"
    },
    {
      "t": 97624,
      "e": 96739,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 97625,
      "e": 96740,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 97735,
      "e": 96850,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 97792,
      "e": 96907,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 97903,
      "e": 97018,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 97905,
      "e": 97020,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 97943,
      "e": 97058,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||A"
    },
    {
      "t": 97983,
      "e": 97098,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 98023,
      "e": 97138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "77"
    },
    {
      "t": 98024,
      "e": 97139,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 98103,
      "e": 97218,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 98103,
      "e": 97218,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 98127,
      "e": 97242,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||me"
    },
    {
      "t": 98247,
      "e": 97362,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "82"
    },
    {
      "t": 98248,
      "e": 97363,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 98256,
      "e": 97364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||r"
    },
    {
      "t": 98327,
      "e": 97435,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 98359,
      "e": 97467,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 98359,
      "e": 97467,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 98463,
      "e": 97571,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||i"
    },
    {
      "t": 98504,
      "e": 97612,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 98505,
      "e": 97613,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 98591,
      "e": 97699,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||c"
    },
    {
      "t": 98664,
      "e": 97772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 98665,
      "e": 97773,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 98736,
      "e": 97844,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 100077,
      "e": 99185,
      "ty": 7,
      "x": 824,
      "y": 670,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 100097,
      "e": 99205,
      "ty": 2,
      "x": 827,
      "y": 687
    },
    {
      "t": 100197,
      "e": 99305,
      "ty": 2,
      "x": 841,
      "y": 708
    },
    {
      "t": 100247,
      "e": 99355,
      "ty": 41,
      "x": 31166,
      "y": 39664,
      "ta": "html > body"
    },
    {
      "t": 100297,
      "e": 99405,
      "ty": 2,
      "x": 1002,
      "y": 719
    },
    {
      "t": 100397,
      "e": 99505,
      "ty": 2,
      "x": 1004,
      "y": 717
    },
    {
      "t": 100494,
      "e": 99602,
      "ty": 6,
      "x": 1002,
      "y": 708,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 100497,
      "e": 99605,
      "ty": 2,
      "x": 1002,
      "y": 708
    },
    {
      "t": 100497,
      "e": 99605,
      "ty": 41,
      "x": 54671,
      "y": 63549,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 100597,
      "e": 99705,
      "ty": 2,
      "x": 1002,
      "y": 700
    },
    {
      "t": 100637,
      "e": 99745,
      "ty": 3,
      "x": 1002,
      "y": 700,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 100637,
      "e": 99745,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States of America"
    },
    {
      "t": 100638,
      "e": 99746,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 100638,
      "e": 99746,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 100747,
      "e": 99855,
      "ty": 41,
      "x": 54671,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 100771,
      "e": 99879,
      "ty": 4,
      "x": 54671,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 100772,
      "e": 99880,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 100772,
      "e": 99880,
      "ty": 5,
      "x": 1002,
      "y": 700,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 100773,
      "e": 99881,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 101197,
      "e": 100305,
      "ty": 2,
      "x": 964,
      "y": 754
    },
    {
      "t": 101248,
      "e": 100356,
      "ty": 41,
      "x": 32027,
      "y": 44096,
      "ta": "html > body"
    },
    {
      "t": 101297,
      "e": 100405,
      "ty": 2,
      "x": 884,
      "y": 885
    },
    {
      "t": 101398,
      "e": 100506,
      "ty": 2,
      "x": 132,
      "y": 1199
    },
    {
      "t": 101497,
      "e": 100605,
      "ty": 2,
      "x": 0,
      "y": 1199
    },
    {
      "t": 101789,
      "e": 100897,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 101998,
      "e": 101106,
      "ty": 2,
      "x": 0,
      "y": 1152
    },
    {
      "t": 101998,
      "e": 101106,
      "ty": 41,
      "x": 0,
      "y": 63817,
      "ta": "html"
    },
    {
      "t": 102097,
      "e": 101205,
      "ty": 2,
      "x": 71,
      "y": 993
    },
    {
      "t": 102198,
      "e": 101306,
      "ty": 2,
      "x": 738,
      "y": 408
    },
    {
      "t": 102247,
      "e": 101355,
      "ty": 41,
      "x": 59231,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-0 > p"
    },
    {
      "t": 102298,
      "e": 101406,
      "ty": 2,
      "x": 1132,
      "y": 154
    },
    {
      "t": 102397,
      "e": 101505,
      "ty": 2,
      "x": 1134,
      "y": 150
    },
    {
      "t": 102497,
      "e": 101605,
      "ty": 2,
      "x": 1052,
      "y": 168
    },
    {
      "t": 102497,
      "e": 101605,
      "ty": 41,
      "x": 54721,
      "y": 523,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 102598,
      "e": 101706,
      "ty": 2,
      "x": 984,
      "y": 193
    },
    {
      "t": 102697,
      "e": 101805,
      "ty": 2,
      "x": 961,
      "y": 207
    },
    {
      "t": 102747,
      "e": 101855,
      "ty": 41,
      "x": 29328,
      "y": 14517,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 102797,
      "e": 101905,
      "ty": 2,
      "x": 935,
      "y": 219
    },
    {
      "t": 102897,
      "e": 102005,
      "ty": 2,
      "x": 911,
      "y": 226
    },
    {
      "t": 102997,
      "e": 102105,
      "ty": 2,
      "x": 862,
      "y": 228
    },
    {
      "t": 102997,
      "e": 102105,
      "ty": 41,
      "x": 9630,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 103098,
      "e": 102206,
      "ty": 2,
      "x": 854,
      "y": 228
    },
    {
      "t": 103197,
      "e": 102305,
      "ty": 2,
      "x": 853,
      "y": 228
    },
    {
      "t": 103247,
      "e": 102355,
      "ty": 41,
      "x": 24220,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 103297,
      "e": 102405,
      "ty": 2,
      "x": 850,
      "y": 233
    },
    {
      "t": 103379,
      "e": 102487,
      "ty": 6,
      "x": 834,
      "y": 267,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 103397,
      "e": 102505,
      "ty": 7,
      "x": 831,
      "y": 274,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 103398,
      "e": 102506,
      "ty": 2,
      "x": 831,
      "y": 274
    },
    {
      "t": 103430,
      "e": 102538,
      "ty": 6,
      "x": 829,
      "y": 289,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 103480,
      "e": 102588,
      "ty": 7,
      "x": 825,
      "y": 299,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 103497,
      "e": 102605,
      "ty": 2,
      "x": 824,
      "y": 303
    },
    {
      "t": 103498,
      "e": 102606,
      "ty": 41,
      "x": 807,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 103598,
      "e": 102706,
      "ty": 2,
      "x": 823,
      "y": 318
    },
    {
      "t": 103698,
      "e": 102806,
      "ty": 2,
      "x": 823,
      "y": 324
    },
    {
      "t": 103748,
      "e": 102856,
      "ty": 41,
      "x": 1798,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 103798,
      "e": 102857,
      "ty": 2,
      "x": 829,
      "y": 333
    },
    {
      "t": 103860,
      "e": 102919,
      "ty": 3,
      "x": 829,
      "y": 333,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 103955,
      "e": 103014,
      "ty": 4,
      "x": 1798,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 103955,
      "e": 103014,
      "ty": 5,
      "x": 829,
      "y": 333,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 104098,
      "e": 103157,
      "ty": 2,
      "x": 831,
      "y": 331
    },
    {
      "t": 104181,
      "e": 103240,
      "ty": 6,
      "x": 833,
      "y": 328,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 104198,
      "e": 103257,
      "ty": 2,
      "x": 833,
      "y": 327
    },
    {
      "t": 104236,
      "e": 103295,
      "ty": 3,
      "x": 833,
      "y": 326,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 104237,
      "e": 103296,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 104247,
      "e": 103306,
      "ty": 41,
      "x": 33161,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 104297,
      "e": 103356,
      "ty": 2,
      "x": 833,
      "y": 326
    },
    {
      "t": 104331,
      "e": 103390,
      "ty": 4,
      "x": 33161,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 104331,
      "e": 103390,
      "ty": 5,
      "x": 833,
      "y": 326,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 104331,
      "e": 103390,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf",
      "v": "Other"
    },
    {
      "t": 104497,
      "e": 103556,
      "ty": 2,
      "x": 833,
      "y": 325
    },
    {
      "t": 104498,
      "e": 103557,
      "ty": 41,
      "x": 33161,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 104598,
      "e": 103657,
      "ty": 7,
      "x": 843,
      "y": 321,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 104598,
      "e": 103657,
      "ty": 2,
      "x": 843,
      "y": 321
    },
    {
      "t": 104698,
      "e": 103757,
      "ty": 2,
      "x": 1005,
      "y": 334
    },
    {
      "t": 104748,
      "e": 103807,
      "ty": 41,
      "x": 54959,
      "y": 13973,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 104798,
      "e": 103857,
      "ty": 2,
      "x": 1055,
      "y": 350
    },
    {
      "t": 104897,
      "e": 103956,
      "ty": 2,
      "x": 1046,
      "y": 386
    },
    {
      "t": 104998,
      "e": 104057,
      "ty": 2,
      "x": 990,
      "y": 402
    },
    {
      "t": 104998,
      "e": 104057,
      "ty": 41,
      "x": 40007,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 105098,
      "e": 104157,
      "ty": 2,
      "x": 948,
      "y": 392
    },
    {
      "t": 105197,
      "e": 104256,
      "ty": 2,
      "x": 927,
      "y": 381
    },
    {
      "t": 105248,
      "e": 104307,
      "ty": 41,
      "x": 22445,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 105298,
      "e": 104357,
      "ty": 2,
      "x": 902,
      "y": 376
    },
    {
      "t": 105398,
      "e": 104457,
      "ty": 2,
      "x": 848,
      "y": 382
    },
    {
      "t": 105498,
      "e": 104557,
      "ty": 2,
      "x": 834,
      "y": 386
    },
    {
      "t": 105498,
      "e": 104557,
      "ty": 41,
      "x": 2985,
      "y": 8394,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 105598,
      "e": 104657,
      "ty": 2,
      "x": 833,
      "y": 387
    },
    {
      "t": 105683,
      "e": 104742,
      "ty": 6,
      "x": 833,
      "y": 410,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 105698,
      "e": 104757,
      "ty": 2,
      "x": 833,
      "y": 410
    },
    {
      "t": 105748,
      "e": 104807,
      "ty": 41,
      "x": 33161,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 105749,
      "e": 104808,
      "ty": 7,
      "x": 834,
      "y": 425,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 105798,
      "e": 104857,
      "ty": 2,
      "x": 834,
      "y": 435
    },
    {
      "t": 105798,
      "e": 104857,
      "ty": 6,
      "x": 834,
      "y": 439,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 105898,
      "e": 104957,
      "ty": 2,
      "x": 835,
      "y": 446
    },
    {
      "t": 105915,
      "e": 104974,
      "ty": 7,
      "x": 836,
      "y": 449,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 105997,
      "e": 105056,
      "ty": 2,
      "x": 838,
      "y": 462
    },
    {
      "t": 105997,
      "e": 105056,
      "ty": 41,
      "x": 17523,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 105999,
      "e": 105058,
      "ty": 6,
      "x": 838,
      "y": 464,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 106098,
      "e": 105157,
      "ty": 2,
      "x": 838,
      "y": 469
    },
    {
      "t": 106198,
      "e": 105257,
      "ty": 2,
      "x": 836,
      "y": 469
    },
    {
      "t": 106216,
      "e": 105275,
      "ty": 7,
      "x": 834,
      "y": 461,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 106247,
      "e": 105306,
      "ty": 41,
      "x": 2510,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 106249,
      "e": 105308,
      "ty": 6,
      "x": 831,
      "y": 447,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 106298,
      "e": 105357,
      "ty": 2,
      "x": 830,
      "y": 438
    },
    {
      "t": 106299,
      "e": 105358,
      "ty": 7,
      "x": 829,
      "y": 434,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 106397,
      "e": 105456,
      "ty": 2,
      "x": 828,
      "y": 423
    },
    {
      "t": 106429,
      "e": 105488,
      "ty": 6,
      "x": 828,
      "y": 420,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 106498,
      "e": 105557,
      "ty": 2,
      "x": 828,
      "y": 415
    },
    {
      "t": 106498,
      "e": 105557,
      "ty": 41,
      "x": 7955,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 106598,
      "e": 105657,
      "ty": 2,
      "x": 832,
      "y": 409
    },
    {
      "t": 106668,
      "e": 105727,
      "ty": 7,
      "x": 842,
      "y": 410,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 106698,
      "e": 105757,
      "ty": 2,
      "x": 843,
      "y": 411
    },
    {
      "t": 106749,
      "e": 105758,
      "ty": 41,
      "x": 26429,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 106797,
      "e": 105806,
      "ty": 2,
      "x": 844,
      "y": 412
    },
    {
      "t": 106898,
      "e": 105907,
      "ty": 2,
      "x": 845,
      "y": 412
    },
    {
      "t": 106998,
      "e": 106007,
      "ty": 41,
      "x": 27600,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 107180,
      "e": 106189,
      "ty": 6,
      "x": 839,
      "y": 411,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 107198,
      "e": 106207,
      "ty": 2,
      "x": 838,
      "y": 410
    },
    {
      "t": 107248,
      "e": 106257,
      "ty": 41,
      "x": 58367,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 107300,
      "e": 106309,
      "ty": 3,
      "x": 838,
      "y": 410,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 107301,
      "e": 106310,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 107301,
      "e": 106310,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 107428,
      "e": 106437,
      "ty": 4,
      "x": 58367,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 107428,
      "e": 106437,
      "ty": 5,
      "x": 838,
      "y": 410,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 107429,
      "e": 106438,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 107497,
      "e": 106506,
      "ty": 2,
      "x": 837,
      "y": 412
    },
    {
      "t": 107497,
      "e": 106506,
      "ty": 41,
      "x": 53325,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 107500,
      "e": 106509,
      "ty": 7,
      "x": 836,
      "y": 437,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 107500,
      "e": 106509,
      "ty": 6,
      "x": 836,
      "y": 437,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 107516,
      "e": 106525,
      "ty": 7,
      "x": 831,
      "y": 467,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 107516,
      "e": 106525,
      "ty": 6,
      "x": 831,
      "y": 467,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 107532,
      "e": 106541,
      "ty": 7,
      "x": 828,
      "y": 487,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 107550,
      "e": 106559,
      "ty": 6,
      "x": 828,
      "y": 501,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 107566,
      "e": 106575,
      "ty": 7,
      "x": 828,
      "y": 510,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 107598,
      "e": 106607,
      "ty": 2,
      "x": 828,
      "y": 518
    },
    {
      "t": 107616,
      "e": 106625,
      "ty": 6,
      "x": 827,
      "y": 551,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 107633,
      "e": 106642,
      "ty": 7,
      "x": 827,
      "y": 564,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 107666,
      "e": 106675,
      "ty": 6,
      "x": 827,
      "y": 578,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 107683,
      "e": 106692,
      "ty": 7,
      "x": 827,
      "y": 591,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 107697,
      "e": 106706,
      "ty": 2,
      "x": 827,
      "y": 591
    },
    {
      "t": 107747,
      "e": 106756,
      "ty": 41,
      "x": 1323,
      "y": 9362,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 107798,
      "e": 106807,
      "ty": 2,
      "x": 832,
      "y": 637
    },
    {
      "t": 107897,
      "e": 106906,
      "ty": 2,
      "x": 848,
      "y": 666
    },
    {
      "t": 107998,
      "e": 107007,
      "ty": 2,
      "x": 855,
      "y": 678
    },
    {
      "t": 107998,
      "e": 107007,
      "ty": 41,
      "x": 9015,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 108098,
      "e": 107107,
      "ty": 2,
      "x": 864,
      "y": 681
    },
    {
      "t": 108198,
      "e": 107207,
      "ty": 2,
      "x": 908,
      "y": 691
    },
    {
      "t": 108248,
      "e": 107257,
      "ty": 41,
      "x": 29123,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 108298,
      "e": 107307,
      "ty": 2,
      "x": 957,
      "y": 697
    },
    {
      "t": 108398,
      "e": 107407,
      "ty": 2,
      "x": 984,
      "y": 695
    },
    {
      "t": 108498,
      "e": 107507,
      "ty": 2,
      "x": 962,
      "y": 695
    },
    {
      "t": 108498,
      "e": 107507,
      "ty": 41,
      "x": 35423,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 108598,
      "e": 107607,
      "ty": 2,
      "x": 943,
      "y": 691
    },
    {
      "t": 108696,
      "e": 107705,
      "ty": 2,
      "x": 908,
      "y": 677
    },
    {
      "t": 108746,
      "e": 107755,
      "ty": 41,
      "x": 20292,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 108795,
      "e": 107804,
      "ty": 2,
      "x": 895,
      "y": 673
    },
    {
      "t": 108895,
      "e": 107904,
      "ty": 2,
      "x": 865,
      "y": 673
    },
    {
      "t": 108949,
      "e": 107958,
      "ty": 6,
      "x": 838,
      "y": 673,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 108995,
      "e": 108004,
      "ty": 2,
      "x": 838,
      "y": 673
    },
    {
      "t": 108996,
      "e": 108005,
      "ty": 41,
      "x": 58367,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 109195,
      "e": 108204,
      "ty": 2,
      "x": 837,
      "y": 680
    },
    {
      "t": 109199,
      "e": 108208,
      "ty": 7,
      "x": 836,
      "y": 687,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 109245,
      "e": 108254,
      "ty": 41,
      "x": 3673,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 109249,
      "e": 108254,
      "ty": 6,
      "x": 836,
      "y": 697,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 109296,
      "e": 108301,
      "ty": 2,
      "x": 836,
      "y": 699
    },
    {
      "t": 109396,
      "e": 108401,
      "ty": 2,
      "x": 835,
      "y": 705
    },
    {
      "t": 109495,
      "e": 108500,
      "ty": 2,
      "x": 835,
      "y": 707
    },
    {
      "t": 109496,
      "e": 108501,
      "ty": 41,
      "x": 43243,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 109596,
      "e": 108601,
      "ty": 2,
      "x": 836,
      "y": 707
    },
    {
      "t": 109696,
      "e": 108701,
      "ty": 2,
      "x": 836,
      "y": 703
    },
    {
      "t": 109746,
      "e": 108751,
      "ty": 41,
      "x": 48284,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 109796,
      "e": 108801,
      "ty": 2,
      "x": 836,
      "y": 698
    },
    {
      "t": 109895,
      "e": 108900,
      "ty": 2,
      "x": 836,
      "y": 697
    },
    {
      "t": 109897,
      "e": 108902,
      "ty": 3,
      "x": 836,
      "y": 697,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 109897,
      "e": 108902,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 109898,
      "e": 108903,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 109996,
      "e": 109001,
      "ty": 41,
      "x": 48284,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 110001,
      "e": 109006,
      "ty": 4,
      "x": 48284,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 110001,
      "e": 109006,
      "ty": 5,
      "x": 836,
      "y": 697,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 110002,
      "e": 109007,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 110195,
      "e": 109200,
      "ty": 2,
      "x": 834,
      "y": 704
    },
    {
      "t": 110245,
      "e": 109250,
      "ty": 41,
      "x": 38202,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 110351,
      "e": 109356,
      "ty": 7,
      "x": 832,
      "y": 713,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 110366,
      "e": 109371,
      "ty": 6,
      "x": 829,
      "y": 725,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 110383,
      "e": 109388,
      "ty": 7,
      "x": 828,
      "y": 737,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 110395,
      "e": 109400,
      "ty": 2,
      "x": 828,
      "y": 737
    },
    {
      "t": 110400,
      "e": 109405,
      "ty": 6,
      "x": 827,
      "y": 753,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 110416,
      "e": 109421,
      "ty": 7,
      "x": 828,
      "y": 782,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 110416,
      "e": 109421,
      "ty": 6,
      "x": 828,
      "y": 782,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 110433,
      "e": 109438,
      "ty": 7,
      "x": 828,
      "y": 798,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 110450,
      "e": 109455,
      "ty": 6,
      "x": 829,
      "y": 809,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 110483,
      "e": 109488,
      "ty": 7,
      "x": 831,
      "y": 821,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 110495,
      "e": 109500,
      "ty": 2,
      "x": 831,
      "y": 821
    },
    {
      "t": 110495,
      "e": 109500,
      "ty": 41,
      "x": 5653,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 110534,
      "e": 109539,
      "ty": 6,
      "x": 831,
      "y": 841,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 110567,
      "e": 109572,
      "ty": 7,
      "x": 829,
      "y": 852,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 110595,
      "e": 109600,
      "ty": 2,
      "x": 825,
      "y": 862
    },
    {
      "t": 110695,
      "e": 109700,
      "ty": 2,
      "x": 820,
      "y": 883
    },
    {
      "t": 110745,
      "e": 109750,
      "ty": 41,
      "x": 27963,
      "y": 48749,
      "ta": "html > body"
    },
    {
      "t": 110795,
      "e": 109800,
      "ty": 2,
      "x": 821,
      "y": 890
    },
    {
      "t": 110896,
      "e": 109901,
      "ty": 2,
      "x": 821,
      "y": 920
    },
    {
      "t": 110901,
      "e": 109906,
      "ty": 6,
      "x": 826,
      "y": 939,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 110918,
      "e": 109923,
      "ty": 7,
      "x": 827,
      "y": 952,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 110935,
      "e": 109924,
      "ty": 6,
      "x": 830,
      "y": 960,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 110996,
      "e": 109985,
      "ty": 2,
      "x": 831,
      "y": 963
    },
    {
      "t": 110996,
      "e": 109985,
      "ty": 41,
      "x": 23079,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111095,
      "e": 110084,
      "ty": 2,
      "x": 832,
      "y": 964
    },
    {
      "t": 111194,
      "e": 110183,
      "ty": 2,
      "x": 832,
      "y": 962
    },
    {
      "t": 111218,
      "e": 110207,
      "ty": 7,
      "x": 834,
      "y": 955,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111245,
      "e": 110234,
      "ty": 41,
      "x": 3697,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 111294,
      "e": 110283,
      "ty": 2,
      "x": 839,
      "y": 943
    },
    {
      "t": 111394,
      "e": 110383,
      "ty": 2,
      "x": 855,
      "y": 901
    },
    {
      "t": 111495,
      "e": 110484,
      "ty": 2,
      "x": 856,
      "y": 901
    },
    {
      "t": 111495,
      "e": 110484,
      "ty": 41,
      "x": 8206,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 111594,
      "e": 110583,
      "ty": 2,
      "x": 842,
      "y": 927
    },
    {
      "t": 111694,
      "e": 110683,
      "ty": 2,
      "x": 837,
      "y": 948
    },
    {
      "t": 111744,
      "e": 110733,
      "ty": 41,
      "x": 12601,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 111754,
      "e": 110743,
      "ty": 6,
      "x": 837,
      "y": 956,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111795,
      "e": 110784,
      "ty": 2,
      "x": 837,
      "y": 958
    },
    {
      "t": 111894,
      "e": 110883,
      "ty": 2,
      "x": 837,
      "y": 963
    },
    {
      "t": 111970,
      "e": 110959,
      "ty": 3,
      "x": 837,
      "y": 963,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111971,
      "e": 110960,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 111972,
      "e": 110961,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111994,
      "e": 110983,
      "ty": 41,
      "x": 53325,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 112073,
      "e": 111062,
      "ty": 4,
      "x": 48284,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 112073,
      "e": 111062,
      "ty": 5,
      "x": 836,
      "y": 964,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 112073,
      "e": 111062,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 112094,
      "e": 111083,
      "ty": 2,
      "x": 836,
      "y": 964
    },
    {
      "t": 112194,
      "e": 111183,
      "ty": 2,
      "x": 834,
      "y": 966
    },
    {
      "t": 112219,
      "e": 111208,
      "ty": 7,
      "x": 839,
      "y": 972,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 112245,
      "e": 111234,
      "ty": 41,
      "x": 5595,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 112295,
      "e": 111284,
      "ty": 2,
      "x": 875,
      "y": 997
    },
    {
      "t": 112395,
      "e": 111384,
      "ty": 2,
      "x": 882,
      "y": 1004
    },
    {
      "t": 112441,
      "e": 111430,
      "ty": 6,
      "x": 882,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 112495,
      "e": 111484,
      "ty": 2,
      "x": 883,
      "y": 1008
    },
    {
      "t": 112495,
      "e": 111484,
      "ty": 41,
      "x": 27613,
      "y": 5957,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 112595,
      "e": 111584,
      "ty": 2,
      "x": 883,
      "y": 1011
    },
    {
      "t": 112694,
      "e": 111683,
      "ty": 2,
      "x": 881,
      "y": 1017
    },
    {
      "t": 112745,
      "e": 111734,
      "ty": 41,
      "x": 26582,
      "y": 23830,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 112795,
      "e": 111784,
      "ty": 2,
      "x": 880,
      "y": 1018
    },
    {
      "t": 112826,
      "e": 111815,
      "ty": 3,
      "x": 880,
      "y": 1018,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 112827,
      "e": 111816,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 112828,
      "e": 111817,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 112921,
      "e": 111910,
      "ty": 4,
      "x": 26067,
      "y": 25816,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 112921,
      "e": 111910,
      "ty": 5,
      "x": 880,
      "y": 1018,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 112923,
      "e": 111912,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 112924,
      "e": 111913,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 112925,
      "e": 111914,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 112994,
      "e": 111983,
      "ty": 2,
      "x": 879,
      "y": 1008
    },
    {
      "t": 112994,
      "e": 111983,
      "ty": 41,
      "x": 29995,
      "y": 55397,
      "ta": "html > body"
    },
    {
      "t": 113094,
      "e": 112083,
      "ty": 2,
      "x": 1305,
      "y": 636
    },
    {
      "t": 113194,
      "e": 112183,
      "ty": 2,
      "x": 1919,
      "y": 0
    },
    {
      "t": 114260,
      "e": 113249,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 114895,
      "e": 113884,
      "ty": 2,
      "x": 1866,
      "y": 14
    },
    {
      "t": 114995,
      "e": 113984,
      "ty": 2,
      "x": 1155,
      "y": 202
    },
    {
      "t": 114996,
      "e": 113985,
      "ty": 41,
      "x": 42385,
      "y": 5242,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 115095,
      "e": 114084,
      "ty": 2,
      "x": 874,
      "y": 271
    },
    {
      "t": 115195,
      "e": 114184,
      "ty": 2,
      "x": 863,
      "y": 271
    },
    {
      "t": 115245,
      "e": 114234,
      "ty": 41,
      "x": 24969,
      "y": 10228,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 115295,
      "e": 114284,
      "ty": 2,
      "x": 636,
      "y": 298
    },
    {
      "t": 115394,
      "e": 114383,
      "ty": 2,
      "x": 372,
      "y": 307
    },
    {
      "t": 115495,
      "e": 114484,
      "ty": 2,
      "x": 318,
      "y": 317
    },
    {
      "t": 115495,
      "e": 114484,
      "ty": 41,
      "x": 1207,
      "y": 13205,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 115695,
      "e": 114684,
      "ty": 2,
      "x": 327,
      "y": 317
    },
    {
      "t": 115745,
      "e": 114734,
      "ty": 41,
      "x": 3864,
      "y": 13205,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 115795,
      "e": 114784,
      "ty": 2,
      "x": 431,
      "y": 324
    },
    {
      "t": 115895,
      "e": 114884,
      "ty": 2,
      "x": 482,
      "y": 332
    },
    {
      "t": 115995,
      "e": 114984,
      "ty": 2,
      "x": 489,
      "y": 332
    },
    {
      "t": 115996,
      "e": 114985,
      "ty": 41,
      "x": 9620,
      "y": 14244,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 116095,
      "e": 115084,
      "ty": 2,
      "x": 590,
      "y": 342
    },
    {
      "t": 116195,
      "e": 115184,
      "ty": 2,
      "x": 944,
      "y": 352
    },
    {
      "t": 116245,
      "e": 115234,
      "ty": 41,
      "x": 45681,
      "y": 40995,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 116294,
      "e": 115283,
      "ty": 2,
      "x": 1588,
      "y": 347
    },
    {
      "t": 116395,
      "e": 115384,
      "ty": 2,
      "x": 1919,
      "y": 291
    },
    {
      "t": 116495,
      "e": 115484,
      "ty": 2,
      "x": 1919,
      "y": 281
    },
    {
      "t": 119995,
      "e": 118984,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 145895,
      "e": 120484,
      "ty": 2,
      "x": 1919,
      "y": 357
    },
    {
      "t": 145995,
      "e": 120584,
      "ty": 2,
      "x": 1919,
      "y": 788
    },
    {
      "t": 146095,
      "e": 120684,
      "ty": 2,
      "x": 1918,
      "y": 821
    },
    {
      "t": 146195,
      "e": 120784,
      "ty": 2,
      "x": 1906,
      "y": 853
    },
    {
      "t": 146245,
      "e": 120834,
      "ty": 41,
      "x": 63606,
      "y": 47032,
      "ta": "> div.masterdiv"
    },
    {
      "t": 146296,
      "e": 120885,
      "ty": 2,
      "x": 1753,
      "y": 855
    },
    {
      "t": 146395,
      "e": 120984,
      "ty": 2,
      "x": 1528,
      "y": 784
    },
    {
      "t": 146496,
      "e": 121085,
      "ty": 2,
      "x": 1241,
      "y": 957
    },
    {
      "t": 146496,
      "e": 121085,
      "ty": 41,
      "x": 46616,
      "y": 57523,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 146596,
      "e": 121185,
      "ty": 2,
      "x": 1085,
      "y": 1118
    },
    {
      "t": 146696,
      "e": 121285,
      "ty": 2,
      "x": 1048,
      "y": 1126
    },
    {
      "t": 146746,
      "e": 121335,
      "ty": 41,
      "x": 35574,
      "y": 61601,
      "ta": "> div.masterdiv"
    },
    {
      "t": 146795,
      "e": 121384,
      "ty": 2,
      "x": 1013,
      "y": 1108
    },
    {
      "t": 146895,
      "e": 121484,
      "ty": 2,
      "x": 1011,
      "y": 1107
    },
    {
      "t": 146986,
      "e": 121575,
      "ty": 6,
      "x": 1008,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 146995,
      "e": 121584,
      "ty": 2,
      "x": 1008,
      "y": 1106
    },
    {
      "t": 146996,
      "e": 121585,
      "ty": 41,
      "x": 53793,
      "y": 64209,
      "ta": "#start"
    },
    {
      "t": 147095,
      "e": 121684,
      "ty": 2,
      "x": 999,
      "y": 1096
    },
    {
      "t": 147195,
      "e": 121784,
      "ty": 2,
      "x": 997,
      "y": 1087
    },
    {
      "t": 147243,
      "e": 121832,
      "ty": 3,
      "x": 997,
      "y": 1087,
      "ta": "#start"
    },
    {
      "t": 147244,
      "e": 121833,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 147245,
      "e": 121834,
      "ty": 41,
      "x": 47785,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 147409,
      "e": 121998,
      "ty": 4,
      "x": 47785,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 147411,
      "e": 122000,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 147412,
      "e": 122001,
      "ty": 5,
      "x": 997,
      "y": 1087,
      "ta": "#start"
    },
    {
      "t": 147413,
      "e": 122002,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 147695,
      "e": 122284,
      "ty": 2,
      "x": 1214,
      "y": 1015
    },
    {
      "t": 147746,
      "e": 122335,
      "ty": 41,
      "x": 48385,
      "y": 51574,
      "ta": "html > body"
    },
    {
      "t": 147795,
      "e": 122384,
      "ty": 2,
      "x": 1699,
      "y": 781
    },
    {
      "t": 147896,
      "e": 122485,
      "ty": 2,
      "x": 1919,
      "y": 609
    },
    {
      "t": 148460,
      "e": 123049,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 150401,
      "e": 124990,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 59793, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 59799, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"TTCWS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 15803, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 76936, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"TTCWS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 12920, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"ZULU\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"211\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 90864, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"TTCWS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 16059, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 108016, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"TTCWS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 8680, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 117700, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"TTCWS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 31128, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 150191, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"TTCWS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1886,y:929,t:1528143465208};\\\", \\\"{x:1663,y:990,t:1528143465223};\\\", \\\"{x:1315,y:1058,t:1528143465247};\\\", \\\"{x:1130,y:1083,t:1528143465263};\\\", \\\"{x:1001,y:1093,t:1528143465280};\\\", \\\"{x:912,y:1105,t:1528143465297};\\\", \\\"{x:864,y:1112,t:1528143465313};\\\", \\\"{x:849,y:1114,t:1528143465330};\\\", \\\"{x:847,y:1115,t:1528143465347};\\\", \\\"{x:849,y:1106,t:1528143465373};\\\", \\\"{x:855,y:1095,t:1528143465381};\\\", \\\"{x:860,y:1083,t:1528143465397};\\\", \\\"{x:874,y:1047,t:1528143465413};\\\", \\\"{x:901,y:960,t:1528143465430};\\\", \\\"{x:918,y:881,t:1528143465448};\\\", \\\"{x:942,y:800,t:1528143465463};\\\", \\\"{x:964,y:725,t:1528143465481};\\\", \\\"{x:981,y:638,t:1528143465498};\\\", \\\"{x:988,y:556,t:1528143465514};\\\", \\\"{x:990,y:501,t:1528143465531};\\\", \\\"{x:963,y:464,t:1528143465547};\\\", \\\"{x:896,y:434,t:1528143465565};\\\", \\\"{x:778,y:386,t:1528143465580};\\\", \\\"{x:616,y:323,t:1528143465598};\\\", \\\"{x:330,y:228,t:1528143465614};\\\", \\\"{x:151,y:178,t:1528143465631};\\\", \\\"{x:9,y:150,t:1528143465648};\\\", \\\"{x:0,y:148,t:1528143465665};\\\", \\\"{x:0,y:159,t:1528143465681};\\\", \\\"{x:0,y:170,t:1528143465697};\\\", \\\"{x:0,y:174,t:1528143465715};\\\", \\\"{x:0,y:180,t:1528143465731};\\\", \\\"{x:0,y:190,t:1528143465747};\\\", \\\"{x:0,y:210,t:1528143465764};\\\", \\\"{x:3,y:230,t:1528143465780};\\\", \\\"{x:8,y:245,t:1528143465798};\\\", \\\"{x:14,y:253,t:1528143465814};\\\", \\\"{x:18,y:257,t:1528143465830};\\\", \\\"{x:25,y:263,t:1528143465847};\\\", \\\"{x:41,y:275,t:1528143465864};\\\", \\\"{x:78,y:301,t:1528143465880};\\\", \\\"{x:131,y:337,t:1528143465897};\\\", \\\"{x:190,y:380,t:1528143465914};\\\", \\\"{x:259,y:425,t:1528143465931};\\\", \\\"{x:324,y:473,t:1528143465948};\\\", \\\"{x:375,y:510,t:1528143465966};\\\", \\\"{x:423,y:545,t:1528143465982};\\\", \\\"{x:446,y:564,t:1528143465996};\\\", \\\"{x:457,y:579,t:1528143466014};\\\", \\\"{x:457,y:586,t:1528143466032};\\\", \\\"{x:456,y:591,t:1528143466048};\\\", \\\"{x:455,y:591,t:1528143466064};\\\", \\\"{x:454,y:592,t:1528143466081};\\\", \\\"{x:453,y:593,t:1528143466098};\\\", \\\"{x:451,y:593,t:1528143466114};\\\", \\\"{x:450,y:593,t:1528143466131};\\\", \\\"{x:448,y:593,t:1528143466148};\\\", \\\"{x:447,y:593,t:1528143466164};\\\", \\\"{x:444,y:593,t:1528143466181};\\\", \\\"{x:436,y:593,t:1528143466197};\\\", \\\"{x:429,y:590,t:1528143466214};\\\", \\\"{x:414,y:583,t:1528143466231};\\\", \\\"{x:387,y:571,t:1528143466250};\\\", \\\"{x:353,y:559,t:1528143466265};\\\", \\\"{x:342,y:558,t:1528143466282};\\\", \\\"{x:345,y:560,t:1528143466407};\\\", \\\"{x:346,y:562,t:1528143466423};\\\", \\\"{x:346,y:563,t:1528143466431};\\\", \\\"{x:347,y:564,t:1528143466449};\\\", \\\"{x:348,y:565,t:1528143466465};\\\", \\\"{x:350,y:565,t:1528143466526};\\\", \\\"{x:351,y:565,t:1528143466542};\\\", \\\"{x:353,y:565,t:1528143466558};\\\", \\\"{x:354,y:565,t:1528143466582};\\\", \\\"{x:355,y:565,t:1528143466622};\\\", \\\"{x:356,y:565,t:1528143466638};\\\", \\\"{x:357,y:565,t:1528143466654};\\\", \\\"{x:359,y:565,t:1528143466670};\\\", \\\"{x:361,y:565,t:1528143466681};\\\", \\\"{x:363,y:565,t:1528143466698};\\\", \\\"{x:365,y:564,t:1528143466791};\\\", \\\"{x:366,y:564,t:1528143466839};\\\", \\\"{x:367,y:564,t:1528143466966};\\\", \\\"{x:370,y:563,t:1528143466982};\\\", \\\"{x:373,y:562,t:1528143466998};\\\", \\\"{x:374,y:561,t:1528143467016};\\\", \\\"{x:375,y:561,t:1528143467033};\\\", \\\"{x:377,y:561,t:1528143467049};\\\", \\\"{x:378,y:560,t:1528143467065};\\\", \\\"{x:379,y:560,t:1528143467082};\\\", \\\"{x:380,y:562,t:1528143467454};\\\", \\\"{x:384,y:571,t:1528143467465};\\\", \\\"{x:395,y:588,t:1528143467483};\\\", \\\"{x:417,y:609,t:1528143467499};\\\", \\\"{x:449,y:634,t:1528143467516};\\\", \\\"{x:483,y:656,t:1528143467533};\\\", \\\"{x:515,y:676,t:1528143467550};\\\", \\\"{x:530,y:686,t:1528143467565};\\\", \\\"{x:537,y:689,t:1528143467582};\\\", \\\"{x:538,y:690,t:1528143467599};\\\", \\\"{x:538,y:691,t:1528143467616};\\\", \\\"{x:539,y:691,t:1528143467632};\\\", \\\"{x:539,y:692,t:1528143467711};\\\", \\\"{x:538,y:693,t:1528143467718};\\\", \\\"{x:537,y:693,t:1528143467732};\\\", \\\"{x:535,y:693,t:1528143467750};\\\", \\\"{x:533,y:693,t:1528143467765};\\\", \\\"{x:533,y:694,t:1528143467783};\\\", \\\"{x:528,y:696,t:1528143467799};\\\", \\\"{x:524,y:699,t:1528143467817};\\\", \\\"{x:522,y:702,t:1528143467834};\\\", \\\"{x:520,y:704,t:1528143467849};\\\", \\\"{x:516,y:709,t:1528143467866};\\\", \\\"{x:515,y:711,t:1528143467881};\\\", \\\"{x:513,y:713,t:1528143467898};\\\", \\\"{x:515,y:713,t:1528143468429};\\\", \\\"{x:521,y:713,t:1528143468438};\\\", \\\"{x:528,y:713,t:1528143468450};\\\", \\\"{x:539,y:713,t:1528143468466};\\\", \\\"{x:551,y:714,t:1528143468483};\\\", \\\"{x:572,y:718,t:1528143468500};\\\", \\\"{x:600,y:724,t:1528143468516};\\\", \\\"{x:649,y:731,t:1528143468534};\\\", \\\"{x:694,y:737,t:1528143468549};\\\", \\\"{x:736,y:744,t:1528143468566};\\\", \\\"{x:768,y:750,t:1528143468583};\\\", \\\"{x:804,y:758,t:1528143468600};\\\", \\\"{x:834,y:764,t:1528143468616};\\\", \\\"{x:856,y:767,t:1528143468633};\\\", \\\"{x:876,y:769,t:1528143468651};\\\", \\\"{x:889,y:773,t:1528143468666};\\\", \\\"{x:895,y:773,t:1528143468683};\\\", \\\"{x:896,y:773,t:1528143468700};\\\", \\\"{x:896,y:774,t:1528143468815};\\\" ] }, { \\\"rt\\\": 17491, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 168933, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"TTCWS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -12 PM-12 PM-K -K -K -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:902,y:773,t:1528143475983};\\\", \\\"{x:1061,y:716,t:1528143475998};\\\", \\\"{x:1179,y:680,t:1528143476005};\\\", \\\"{x:1422,y:616,t:1528143476022};\\\", \\\"{x:1629,y:582,t:1528143476039};\\\", \\\"{x:1793,y:530,t:1528143476056};\\\", \\\"{x:1919,y:472,t:1528143476073};\\\", \\\"{x:1919,y:427,t:1528143476089};\\\", \\\"{x:1919,y:397,t:1528143476105};\\\", \\\"{x:1919,y:379,t:1528143476122};\\\", \\\"{x:1919,y:367,t:1528143476140};\\\", \\\"{x:1919,y:347,t:1528143476156};\\\", \\\"{x:1919,y:329,t:1528143476172};\\\", \\\"{x:1919,y:304,t:1528143476190};\\\", \\\"{x:1919,y:290,t:1528143476205};\\\", \\\"{x:1919,y:284,t:1528143476222};\\\", \\\"{x:1919,y:279,t:1528143476239};\\\", \\\"{x:1911,y:277,t:1528143476255};\\\", \\\"{x:1896,y:269,t:1528143476273};\\\", \\\"{x:1876,y:264,t:1528143476289};\\\", \\\"{x:1845,y:264,t:1528143476307};\\\", \\\"{x:1771,y:267,t:1528143476323};\\\", \\\"{x:1671,y:282,t:1528143476340};\\\", \\\"{x:1550,y:295,t:1528143476357};\\\", \\\"{x:1471,y:298,t:1528143476373};\\\", \\\"{x:1448,y:303,t:1528143476390};\\\", \\\"{x:1447,y:304,t:1528143476470};\\\", \\\"{x:1447,y:308,t:1528143476478};\\\", \\\"{x:1447,y:315,t:1528143476490};\\\", \\\"{x:1447,y:334,t:1528143476506};\\\", \\\"{x:1447,y:357,t:1528143476523};\\\", \\\"{x:1450,y:378,t:1528143476540};\\\", \\\"{x:1457,y:389,t:1528143476557};\\\", \\\"{x:1461,y:395,t:1528143476573};\\\", \\\"{x:1464,y:395,t:1528143476590};\\\", \\\"{x:1466,y:395,t:1528143476607};\\\", \\\"{x:1469,y:395,t:1528143476624};\\\", \\\"{x:1473,y:395,t:1528143476640};\\\", \\\"{x:1478,y:395,t:1528143476657};\\\", \\\"{x:1484,y:395,t:1528143476673};\\\", \\\"{x:1494,y:394,t:1528143476690};\\\", \\\"{x:1503,y:392,t:1528143476707};\\\", \\\"{x:1513,y:391,t:1528143476724};\\\", \\\"{x:1524,y:389,t:1528143476740};\\\", \\\"{x:1531,y:389,t:1528143476757};\\\", \\\"{x:1546,y:389,t:1528143476774};\\\", \\\"{x:1566,y:389,t:1528143476790};\\\", \\\"{x:1585,y:394,t:1528143476807};\\\", \\\"{x:1599,y:399,t:1528143476824};\\\", \\\"{x:1609,y:403,t:1528143476840};\\\", \\\"{x:1611,y:405,t:1528143476857};\\\", \\\"{x:1611,y:406,t:1528143476874};\\\", \\\"{x:1611,y:407,t:1528143476902};\\\", \\\"{x:1611,y:408,t:1528143476911};\\\", \\\"{x:1611,y:410,t:1528143476924};\\\", \\\"{x:1610,y:413,t:1528143476941};\\\", \\\"{x:1610,y:416,t:1528143476957};\\\", \\\"{x:1610,y:418,t:1528143476974};\\\", \\\"{x:1609,y:420,t:1528143476991};\\\", \\\"{x:1608,y:423,t:1528143477008};\\\", \\\"{x:1607,y:424,t:1528143477024};\\\", \\\"{x:1607,y:426,t:1528143477040};\\\", \\\"{x:1607,y:427,t:1528143477062};\\\", \\\"{x:1607,y:428,t:1528143477094};\\\", \\\"{x:1607,y:429,t:1528143477108};\\\", \\\"{x:1607,y:430,t:1528143477199};\\\", \\\"{x:1607,y:432,t:1528143477238};\\\", \\\"{x:1607,y:433,t:1528143477255};\\\", \\\"{x:1607,y:436,t:1528143477262};\\\", \\\"{x:1606,y:438,t:1528143477274};\\\", \\\"{x:1603,y:442,t:1528143477291};\\\", \\\"{x:1597,y:450,t:1528143477307};\\\", \\\"{x:1591,y:458,t:1528143477324};\\\", \\\"{x:1585,y:464,t:1528143477341};\\\", \\\"{x:1580,y:470,t:1528143477357};\\\", \\\"{x:1571,y:480,t:1528143477374};\\\", \\\"{x:1562,y:490,t:1528143477391};\\\", \\\"{x:1549,y:504,t:1528143477407};\\\", \\\"{x:1540,y:517,t:1528143477424};\\\", \\\"{x:1533,y:538,t:1528143477441};\\\", \\\"{x:1527,y:559,t:1528143477458};\\\", \\\"{x:1521,y:576,t:1528143477474};\\\", \\\"{x:1513,y:600,t:1528143477491};\\\", \\\"{x:1506,y:616,t:1528143477508};\\\", \\\"{x:1495,y:633,t:1528143477524};\\\", \\\"{x:1489,y:646,t:1528143477541};\\\", \\\"{x:1475,y:670,t:1528143477559};\\\", \\\"{x:1469,y:684,t:1528143477575};\\\", \\\"{x:1462,y:698,t:1528143477591};\\\", \\\"{x:1455,y:714,t:1528143477608};\\\", \\\"{x:1449,y:727,t:1528143477624};\\\", \\\"{x:1442,y:740,t:1528143477641};\\\", \\\"{x:1437,y:746,t:1528143477658};\\\", \\\"{x:1433,y:755,t:1528143477675};\\\", \\\"{x:1427,y:766,t:1528143477691};\\\", \\\"{x:1420,y:778,t:1528143477708};\\\", \\\"{x:1414,y:788,t:1528143477725};\\\", \\\"{x:1410,y:796,t:1528143477741};\\\", \\\"{x:1404,y:806,t:1528143477758};\\\", \\\"{x:1399,y:816,t:1528143477774};\\\", \\\"{x:1393,y:827,t:1528143477792};\\\", \\\"{x:1388,y:836,t:1528143477808};\\\", \\\"{x:1384,y:845,t:1528143477825};\\\", \\\"{x:1382,y:851,t:1528143477841};\\\", \\\"{x:1379,y:858,t:1528143477859};\\\", \\\"{x:1375,y:867,t:1528143477874};\\\", \\\"{x:1370,y:879,t:1528143477891};\\\", \\\"{x:1365,y:892,t:1528143477908};\\\", \\\"{x:1360,y:903,t:1528143477925};\\\", \\\"{x:1357,y:911,t:1528143477941};\\\", \\\"{x:1354,y:923,t:1528143477958};\\\", \\\"{x:1351,y:932,t:1528143477975};\\\", \\\"{x:1348,y:941,t:1528143477991};\\\", \\\"{x:1346,y:949,t:1528143478009};\\\", \\\"{x:1344,y:956,t:1528143478025};\\\", \\\"{x:1342,y:962,t:1528143478042};\\\", \\\"{x:1342,y:966,t:1528143478058};\\\", \\\"{x:1341,y:969,t:1528143478075};\\\", \\\"{x:1340,y:973,t:1528143478091};\\\", \\\"{x:1339,y:975,t:1528143478109};\\\", \\\"{x:1339,y:976,t:1528143478125};\\\", \\\"{x:1338,y:979,t:1528143478141};\\\", \\\"{x:1337,y:985,t:1528143478158};\\\", \\\"{x:1335,y:989,t:1528143478174};\\\", \\\"{x:1335,y:990,t:1528143478190};\\\", \\\"{x:1335,y:989,t:1528143480102};\\\", \\\"{x:1337,y:988,t:1528143480110};\\\", \\\"{x:1339,y:986,t:1528143480126};\\\", \\\"{x:1341,y:986,t:1528143480144};\\\", \\\"{x:1341,y:985,t:1528143480831};\\\", \\\"{x:1344,y:980,t:1528143480844};\\\", \\\"{x:1351,y:967,t:1528143480862};\\\", \\\"{x:1355,y:960,t:1528143480877};\\\", \\\"{x:1357,y:955,t:1528143480894};\\\", \\\"{x:1361,y:946,t:1528143480910};\\\", \\\"{x:1364,y:939,t:1528143480927};\\\", \\\"{x:1367,y:932,t:1528143480944};\\\", \\\"{x:1368,y:930,t:1528143480961};\\\", \\\"{x:1370,y:926,t:1528143480977};\\\", \\\"{x:1371,y:924,t:1528143480994};\\\", \\\"{x:1374,y:921,t:1528143481010};\\\", \\\"{x:1374,y:920,t:1528143481027};\\\", \\\"{x:1375,y:917,t:1528143481044};\\\", \\\"{x:1377,y:913,t:1528143481060};\\\", \\\"{x:1378,y:911,t:1528143481078};\\\", \\\"{x:1382,y:905,t:1528143481095};\\\", \\\"{x:1382,y:902,t:1528143481110};\\\", \\\"{x:1385,y:898,t:1528143481127};\\\", \\\"{x:1385,y:897,t:1528143481166};\\\", \\\"{x:1386,y:895,t:1528143481182};\\\", \\\"{x:1388,y:892,t:1528143481215};\\\", \\\"{x:1389,y:890,t:1528143481228};\\\", \\\"{x:1390,y:889,t:1528143481244};\\\", \\\"{x:1391,y:887,t:1528143481261};\\\", \\\"{x:1392,y:885,t:1528143481277};\\\", \\\"{x:1395,y:881,t:1528143481295};\\\", \\\"{x:1397,y:878,t:1528143481311};\\\", \\\"{x:1400,y:874,t:1528143481328};\\\", \\\"{x:1403,y:870,t:1528143481345};\\\", \\\"{x:1408,y:863,t:1528143481360};\\\", \\\"{x:1411,y:859,t:1528143481377};\\\", \\\"{x:1418,y:852,t:1528143481394};\\\", \\\"{x:1427,y:841,t:1528143481410};\\\", \\\"{x:1433,y:834,t:1528143481428};\\\", \\\"{x:1439,y:827,t:1528143481444};\\\", \\\"{x:1446,y:819,t:1528143481461};\\\", \\\"{x:1452,y:811,t:1528143481477};\\\", \\\"{x:1459,y:799,t:1528143481494};\\\", \\\"{x:1466,y:792,t:1528143481512};\\\", \\\"{x:1469,y:786,t:1528143481527};\\\", \\\"{x:1471,y:783,t:1528143481545};\\\", \\\"{x:1474,y:779,t:1528143481562};\\\", \\\"{x:1475,y:778,t:1528143481577};\\\", \\\"{x:1476,y:775,t:1528143481594};\\\", \\\"{x:1477,y:774,t:1528143481611};\\\", \\\"{x:1477,y:771,t:1528143481627};\\\", \\\"{x:1481,y:764,t:1528143481645};\\\", \\\"{x:1482,y:755,t:1528143481661};\\\", \\\"{x:1483,y:745,t:1528143481677};\\\", \\\"{x:1485,y:730,t:1528143481694};\\\", \\\"{x:1486,y:723,t:1528143481711};\\\", \\\"{x:1487,y:717,t:1528143481727};\\\", \\\"{x:1489,y:710,t:1528143481745};\\\", \\\"{x:1489,y:697,t:1528143481762};\\\", \\\"{x:1491,y:687,t:1528143481778};\\\", \\\"{x:1493,y:676,t:1528143481794};\\\", \\\"{x:1494,y:670,t:1528143481812};\\\", \\\"{x:1496,y:663,t:1528143481827};\\\", \\\"{x:1498,y:659,t:1528143481844};\\\", \\\"{x:1499,y:655,t:1528143481862};\\\", \\\"{x:1501,y:651,t:1528143481878};\\\", \\\"{x:1504,y:645,t:1528143481894};\\\", \\\"{x:1507,y:643,t:1528143481911};\\\", \\\"{x:1510,y:640,t:1528143481927};\\\", \\\"{x:1512,y:635,t:1528143481947};\\\", \\\"{x:1514,y:633,t:1528143481960};\\\", \\\"{x:1516,y:631,t:1528143481978};\\\", \\\"{x:1517,y:631,t:1528143481994};\\\", \\\"{x:1517,y:629,t:1528143482010};\\\", \\\"{x:1519,y:627,t:1528143482027};\\\", \\\"{x:1521,y:625,t:1528143482044};\\\", \\\"{x:1523,y:623,t:1528143482060};\\\", \\\"{x:1523,y:621,t:1528143482078};\\\", \\\"{x:1522,y:621,t:1528143482374};\\\", \\\"{x:1522,y:622,t:1528143482398};\\\", \\\"{x:1521,y:622,t:1528143482412};\\\", \\\"{x:1520,y:623,t:1528143482429};\\\", \\\"{x:1519,y:625,t:1528143482503};\\\", \\\"{x:1518,y:626,t:1528143482512};\\\", \\\"{x:1517,y:628,t:1528143482545};\\\", \\\"{x:1516,y:628,t:1528143482561};\\\", \\\"{x:1515,y:630,t:1528143482578};\\\", \\\"{x:1513,y:631,t:1528143482595};\\\", \\\"{x:1511,y:634,t:1528143482610};\\\", \\\"{x:1509,y:636,t:1528143482628};\\\", \\\"{x:1508,y:637,t:1528143482645};\\\", \\\"{x:1507,y:638,t:1528143482661};\\\", \\\"{x:1506,y:638,t:1528143482678};\\\", \\\"{x:1507,y:638,t:1528143483086};\\\", \\\"{x:1508,y:638,t:1528143483095};\\\", \\\"{x:1510,y:638,t:1528143483113};\\\", \\\"{x:1511,y:638,t:1528143483142};\\\", \\\"{x:1514,y:635,t:1528143483166};\\\", \\\"{x:1507,y:635,t:1528143484727};\\\", \\\"{x:1496,y:635,t:1528143484734};\\\", \\\"{x:1483,y:635,t:1528143484747};\\\", \\\"{x:1453,y:635,t:1528143484763};\\\", \\\"{x:1403,y:635,t:1528143484781};\\\", \\\"{x:1317,y:635,t:1528143484796};\\\", \\\"{x:1213,y:625,t:1528143484815};\\\", \\\"{x:1019,y:606,t:1528143484830};\\\", \\\"{x:876,y:600,t:1528143484850};\\\", \\\"{x:740,y:591,t:1528143484863};\\\", \\\"{x:630,y:581,t:1528143484880};\\\", \\\"{x:569,y:575,t:1528143484896};\\\", \\\"{x:539,y:573,t:1528143484913};\\\", \\\"{x:519,y:572,t:1528143484929};\\\", \\\"{x:513,y:572,t:1528143484946};\\\", \\\"{x:513,y:573,t:1528143485021};\\\", \\\"{x:513,y:574,t:1528143485029};\\\", \\\"{x:512,y:577,t:1528143485047};\\\", \\\"{x:510,y:581,t:1528143485063};\\\", \\\"{x:510,y:585,t:1528143485081};\\\", \\\"{x:507,y:588,t:1528143485097};\\\", \\\"{x:505,y:592,t:1528143485112};\\\", \\\"{x:497,y:597,t:1528143485131};\\\", \\\"{x:477,y:606,t:1528143485146};\\\", \\\"{x:456,y:610,t:1528143485163};\\\", \\\"{x:438,y:612,t:1528143485180};\\\", \\\"{x:410,y:614,t:1528143485197};\\\", \\\"{x:398,y:614,t:1528143485213};\\\", \\\"{x:384,y:613,t:1528143485230};\\\", \\\"{x:367,y:611,t:1528143485247};\\\", \\\"{x:355,y:610,t:1528143485263};\\\", \\\"{x:350,y:607,t:1528143485280};\\\", \\\"{x:349,y:607,t:1528143485297};\\\", \\\"{x:349,y:605,t:1528143485333};\\\", \\\"{x:349,y:604,t:1528143485349};\\\", \\\"{x:350,y:604,t:1528143485526};\\\", \\\"{x:354,y:604,t:1528143485534};\\\", \\\"{x:358,y:604,t:1528143485547};\\\", \\\"{x:362,y:604,t:1528143485564};\\\", \\\"{x:365,y:604,t:1528143485580};\\\", \\\"{x:366,y:604,t:1528143485597};\\\", \\\"{x:367,y:604,t:1528143485702};\\\", \\\"{x:369,y:603,t:1528143485718};\\\", \\\"{x:370,y:603,t:1528143485730};\\\", \\\"{x:371,y:603,t:1528143485747};\\\", \\\"{x:372,y:603,t:1528143485764};\\\", \\\"{x:374,y:602,t:1528143485783};\\\", \\\"{x:375,y:602,t:1528143485813};\\\", \\\"{x:376,y:601,t:1528143485829};\\\", \\\"{x:377,y:601,t:1528143485853};\\\", \\\"{x:378,y:601,t:1528143485902};\\\", \\\"{x:379,y:601,t:1528143485957};\\\", \\\"{x:380,y:601,t:1528143485965};\\\", \\\"{x:381,y:601,t:1528143486485};\\\", \\\"{x:384,y:605,t:1528143486498};\\\", \\\"{x:396,y:620,t:1528143486516};\\\", \\\"{x:415,y:639,t:1528143486531};\\\", \\\"{x:449,y:661,t:1528143486548};\\\", \\\"{x:489,y:688,t:1528143486565};\\\", \\\"{x:504,y:700,t:1528143486581};\\\", \\\"{x:512,y:707,t:1528143486599};\\\", \\\"{x:516,y:710,t:1528143486615};\\\", \\\"{x:517,y:711,t:1528143486631};\\\", \\\"{x:518,y:711,t:1528143487302};\\\", \\\"{x:526,y:711,t:1528143487315};\\\", \\\"{x:572,y:717,t:1528143487332};\\\", \\\"{x:658,y:728,t:1528143487349};\\\", \\\"{x:756,y:742,t:1528143487365};\\\", \\\"{x:902,y:765,t:1528143487382};\\\", \\\"{x:997,y:781,t:1528143487398};\\\", \\\"{x:1092,y:796,t:1528143487415};\\\", \\\"{x:1167,y:807,t:1528143487432};\\\", \\\"{x:1234,y:818,t:1528143487449};\\\", \\\"{x:1274,y:825,t:1528143487466};\\\", \\\"{x:1292,y:825,t:1528143487483};\\\", \\\"{x:1300,y:825,t:1528143487499};\\\", \\\"{x:1302,y:825,t:1528143487515};\\\", \\\"{x:1303,y:825,t:1528143487532};\\\" ] }, { \\\"rt\\\": 18972, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 189123, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"TTCWS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -11 AM-11 AM-F -F -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1302,y:825,t:1528143497215};\\\", \\\"{x:1298,y:827,t:1528143497223};\\\", \\\"{x:1283,y:834,t:1528143497245};\\\", \\\"{x:1270,y:839,t:1528143497256};\\\", \\\"{x:1251,y:849,t:1528143497273};\\\", \\\"{x:1236,y:855,t:1528143497290};\\\", \\\"{x:1235,y:857,t:1528143497481};\\\", \\\"{x:1235,y:861,t:1528143497494};\\\", \\\"{x:1243,y:872,t:1528143497509};\\\", \\\"{x:1253,y:887,t:1528143497526};\\\", \\\"{x:1257,y:897,t:1528143497544};\\\", \\\"{x:1261,y:903,t:1528143497560};\\\", \\\"{x:1261,y:906,t:1528143497577};\\\", \\\"{x:1262,y:910,t:1528143497593};\\\", \\\"{x:1262,y:912,t:1528143497610};\\\", \\\"{x:1262,y:913,t:1528143497633};\\\", \\\"{x:1262,y:915,t:1528143497645};\\\", \\\"{x:1262,y:917,t:1528143497660};\\\", \\\"{x:1264,y:920,t:1528143497676};\\\", \\\"{x:1265,y:925,t:1528143497693};\\\", \\\"{x:1266,y:928,t:1528143497711};\\\", \\\"{x:1268,y:932,t:1528143497727};\\\", \\\"{x:1269,y:936,t:1528143497743};\\\", \\\"{x:1271,y:941,t:1528143497760};\\\", \\\"{x:1274,y:948,t:1528143497777};\\\", \\\"{x:1280,y:959,t:1528143497795};\\\", \\\"{x:1282,y:961,t:1528143497810};\\\", \\\"{x:1284,y:965,t:1528143497827};\\\", \\\"{x:1285,y:967,t:1528143497844};\\\", \\\"{x:1285,y:970,t:1528143497860};\\\", \\\"{x:1286,y:971,t:1528143497876};\\\", \\\"{x:1286,y:972,t:1528143497897};\\\", \\\"{x:1286,y:974,t:1528143497913};\\\", \\\"{x:1287,y:974,t:1528143497929};\\\", \\\"{x:1286,y:975,t:1528143498161};\\\", \\\"{x:1285,y:978,t:1528143498176};\\\", \\\"{x:1285,y:980,t:1528143498193};\\\", \\\"{x:1285,y:981,t:1528143498233};\\\", \\\"{x:1285,y:983,t:1528143498265};\\\", \\\"{x:1285,y:982,t:1528143498521};\\\", \\\"{x:1285,y:980,t:1528143498529};\\\", \\\"{x:1285,y:978,t:1528143498544};\\\", \\\"{x:1285,y:975,t:1528143498561};\\\", \\\"{x:1285,y:971,t:1528143498577};\\\", \\\"{x:1285,y:970,t:1528143498625};\\\", \\\"{x:1285,y:969,t:1528143499049};\\\", \\\"{x:1285,y:968,t:1528143499062};\\\", \\\"{x:1284,y:968,t:1528143499089};\\\", \\\"{x:1282,y:968,t:1528143499113};\\\", \\\"{x:1281,y:968,t:1528143500001};\\\", \\\"{x:1279,y:968,t:1528143500017};\\\", \\\"{x:1278,y:969,t:1528143500029};\\\", \\\"{x:1276,y:970,t:1528143500081};\\\", \\\"{x:1277,y:969,t:1528143500608};\\\", \\\"{x:1279,y:968,t:1528143500616};\\\", \\\"{x:1281,y:966,t:1528143500628};\\\", \\\"{x:1284,y:964,t:1528143500645};\\\", \\\"{x:1285,y:963,t:1528143500662};\\\", \\\"{x:1288,y:961,t:1528143500678};\\\", \\\"{x:1289,y:960,t:1528143500694};\\\", \\\"{x:1291,y:956,t:1528143500712};\\\", \\\"{x:1293,y:954,t:1528143500728};\\\", \\\"{x:1295,y:950,t:1528143500745};\\\", \\\"{x:1296,y:950,t:1528143500762};\\\", \\\"{x:1297,y:949,t:1528143500778};\\\", \\\"{x:1298,y:948,t:1528143500809};\\\", \\\"{x:1298,y:947,t:1528143500825};\\\", \\\"{x:1299,y:946,t:1528143500841};\\\", \\\"{x:1300,y:944,t:1528143500857};\\\", \\\"{x:1301,y:943,t:1528143500873};\\\", \\\"{x:1302,y:942,t:1528143500881};\\\", \\\"{x:1302,y:941,t:1528143500895};\\\", \\\"{x:1303,y:938,t:1528143500913};\\\", \\\"{x:1305,y:934,t:1528143500929};\\\", \\\"{x:1306,y:930,t:1528143500946};\\\", \\\"{x:1309,y:926,t:1528143500963};\\\", \\\"{x:1309,y:923,t:1528143500979};\\\", \\\"{x:1313,y:915,t:1528143500995};\\\", \\\"{x:1314,y:910,t:1528143501013};\\\", \\\"{x:1319,y:899,t:1528143501030};\\\", \\\"{x:1322,y:893,t:1528143501045};\\\", \\\"{x:1326,y:882,t:1528143501062};\\\", \\\"{x:1332,y:862,t:1528143501079};\\\", \\\"{x:1336,y:849,t:1528143501095};\\\", \\\"{x:1337,y:842,t:1528143501112};\\\", \\\"{x:1342,y:830,t:1528143501129};\\\", \\\"{x:1345,y:824,t:1528143501145};\\\", \\\"{x:1347,y:819,t:1528143501163};\\\", \\\"{x:1349,y:814,t:1528143501180};\\\", \\\"{x:1352,y:808,t:1528143501196};\\\", \\\"{x:1357,y:800,t:1528143501212};\\\", \\\"{x:1362,y:791,t:1528143501230};\\\", \\\"{x:1367,y:783,t:1528143501247};\\\", \\\"{x:1370,y:776,t:1528143501263};\\\", \\\"{x:1375,y:769,t:1528143501279};\\\", \\\"{x:1379,y:764,t:1528143501296};\\\", \\\"{x:1380,y:763,t:1528143501312};\\\", \\\"{x:1380,y:762,t:1528143501329};\\\", \\\"{x:1383,y:759,t:1528143501369};\\\", \\\"{x:1384,y:758,t:1528143501379};\\\", \\\"{x:1384,y:757,t:1528143501398};\\\", \\\"{x:1385,y:755,t:1528143501413};\\\", \\\"{x:1386,y:755,t:1528143501714};\\\", \\\"{x:1386,y:758,t:1528143501730};\\\", \\\"{x:1384,y:760,t:1528143501747};\\\", \\\"{x:1384,y:762,t:1528143501762};\\\", \\\"{x:1383,y:762,t:1528143501779};\\\", \\\"{x:1383,y:763,t:1528143501796};\\\", \\\"{x:1382,y:763,t:1528143501825};\\\", \\\"{x:1382,y:764,t:1528143501849};\\\", \\\"{x:1381,y:765,t:1528143501873};\\\", \\\"{x:1380,y:766,t:1528143502762};\\\", \\\"{x:1378,y:768,t:1528143502777};\\\", \\\"{x:1377,y:769,t:1528143502786};\\\", \\\"{x:1376,y:771,t:1528143502802};\\\", \\\"{x:1376,y:772,t:1528143502825};\\\", \\\"{x:1376,y:771,t:1528143503193};\\\", \\\"{x:1376,y:770,t:1528143503402};\\\", \\\"{x:1377,y:768,t:1528143503415};\\\", \\\"{x:1377,y:767,t:1528143503434};\\\", \\\"{x:1378,y:766,t:1528143503448};\\\", \\\"{x:1379,y:764,t:1528143503464};\\\", \\\"{x:1380,y:763,t:1528143503480};\\\", \\\"{x:1380,y:765,t:1528143503921};\\\", \\\"{x:1380,y:766,t:1528143503931};\\\", \\\"{x:1380,y:767,t:1528143503953};\\\", \\\"{x:1379,y:768,t:1528143503977};\\\", \\\"{x:1377,y:770,t:1528143504227};\\\", \\\"{x:1370,y:774,t:1528143504233};\\\", \\\"{x:1365,y:777,t:1528143504247};\\\", \\\"{x:1342,y:788,t:1528143504264};\\\", \\\"{x:1322,y:790,t:1528143504281};\\\", \\\"{x:1283,y:791,t:1528143504298};\\\", \\\"{x:1212,y:787,t:1528143504314};\\\", \\\"{x:1138,y:769,t:1528143504331};\\\", \\\"{x:1063,y:747,t:1528143504348};\\\", \\\"{x:978,y:716,t:1528143504364};\\\", \\\"{x:914,y:686,t:1528143504381};\\\", \\\"{x:850,y:658,t:1528143504399};\\\", \\\"{x:802,y:632,t:1528143504414};\\\", \\\"{x:770,y:612,t:1528143504432};\\\", \\\"{x:741,y:599,t:1528143504448};\\\", \\\"{x:731,y:595,t:1528143504464};\\\", \\\"{x:719,y:592,t:1528143504483};\\\", \\\"{x:711,y:591,t:1528143504499};\\\", \\\"{x:697,y:590,t:1528143504516};\\\", \\\"{x:678,y:587,t:1528143504533};\\\", \\\"{x:662,y:587,t:1528143504549};\\\", \\\"{x:652,y:587,t:1528143504566};\\\", \\\"{x:640,y:587,t:1528143504583};\\\", \\\"{x:628,y:587,t:1528143504599};\\\", \\\"{x:618,y:587,t:1528143504616};\\\", \\\"{x:614,y:587,t:1528143504632};\\\", \\\"{x:608,y:588,t:1528143504649};\\\", \\\"{x:596,y:590,t:1528143504667};\\\", \\\"{x:582,y:591,t:1528143504683};\\\", \\\"{x:567,y:591,t:1528143504699};\\\", \\\"{x:554,y:591,t:1528143504716};\\\", \\\"{x:536,y:589,t:1528143504732};\\\", \\\"{x:517,y:586,t:1528143504750};\\\", \\\"{x:497,y:584,t:1528143504767};\\\", \\\"{x:479,y:579,t:1528143504784};\\\", \\\"{x:466,y:575,t:1528143504799};\\\", \\\"{x:456,y:573,t:1528143504817};\\\", \\\"{x:452,y:573,t:1528143504833};\\\", \\\"{x:446,y:573,t:1528143504849};\\\", \\\"{x:441,y:572,t:1528143504866};\\\", \\\"{x:436,y:571,t:1528143504883};\\\", \\\"{x:434,y:571,t:1528143504899};\\\", \\\"{x:433,y:570,t:1528143504937};\\\", \\\"{x:432,y:570,t:1528143504953};\\\", \\\"{x:431,y:570,t:1528143504966};\\\", \\\"{x:425,y:569,t:1528143504984};\\\", \\\"{x:420,y:567,t:1528143504999};\\\", \\\"{x:413,y:566,t:1528143505018};\\\", \\\"{x:410,y:565,t:1528143505032};\\\", \\\"{x:405,y:564,t:1528143505049};\\\", \\\"{x:398,y:563,t:1528143505066};\\\", \\\"{x:387,y:562,t:1528143505083};\\\", \\\"{x:376,y:559,t:1528143505099};\\\", \\\"{x:370,y:558,t:1528143505116};\\\", \\\"{x:368,y:557,t:1528143505133};\\\", \\\"{x:369,y:557,t:1528143505529};\\\", \\\"{x:371,y:557,t:1528143505537};\\\", \\\"{x:376,y:558,t:1528143505551};\\\", \\\"{x:382,y:558,t:1528143505566};\\\", \\\"{x:385,y:559,t:1528143505583};\\\", \\\"{x:388,y:560,t:1528143505600};\\\", \\\"{x:390,y:560,t:1528143505665};\\\", \\\"{x:392,y:560,t:1528143505680};\\\", \\\"{x:393,y:560,t:1528143506169};\\\", \\\"{x:393,y:565,t:1528143506184};\\\", \\\"{x:393,y:569,t:1528143506201};\\\", \\\"{x:396,y:577,t:1528143506218};\\\", \\\"{x:399,y:583,t:1528143506235};\\\", \\\"{x:402,y:589,t:1528143506251};\\\", \\\"{x:412,y:601,t:1528143506267};\\\", \\\"{x:426,y:617,t:1528143506285};\\\", \\\"{x:440,y:634,t:1528143506302};\\\", \\\"{x:454,y:654,t:1528143506318};\\\", \\\"{x:467,y:673,t:1528143506335};\\\", \\\"{x:476,y:684,t:1528143506350};\\\", \\\"{x:481,y:690,t:1528143506367};\\\", \\\"{x:482,y:691,t:1528143506384};\\\", \\\"{x:482,y:692,t:1528143506425};\\\", \\\"{x:482,y:693,t:1528143506434};\\\", \\\"{x:483,y:696,t:1528143506450};\\\", \\\"{x:484,y:698,t:1528143506467};\\\", \\\"{x:485,y:699,t:1528143506484};\\\", \\\"{x:485,y:701,t:1528143506503};\\\", \\\"{x:488,y:709,t:1528143506517};\\\", \\\"{x:489,y:718,t:1528143506535};\\\", \\\"{x:494,y:726,t:1528143506551};\\\", \\\"{x:497,y:729,t:1528143506567};\\\", \\\"{x:497,y:730,t:1528143506584};\\\", \\\"{x:497,y:731,t:1528143506616};\\\", \\\"{x:497,y:733,t:1528143506624};\\\", \\\"{x:497,y:736,t:1528143506635};\\\", \\\"{x:497,y:737,t:1528143506651};\\\", \\\"{x:497,y:738,t:1528143506668};\\\", \\\"{x:498,y:737,t:1528143506913};\\\", \\\"{x:498,y:735,t:1528143506930};\\\", \\\"{x:499,y:732,t:1528143506937};\\\", \\\"{x:500,y:729,t:1528143506951};\\\", \\\"{x:504,y:717,t:1528143506968};\\\", \\\"{x:504,y:715,t:1528143506984};\\\", \\\"{x:505,y:714,t:1528143507352};\\\", \\\"{x:512,y:710,t:1528143507368};\\\", \\\"{x:516,y:708,t:1528143507385};\\\", \\\"{x:519,y:707,t:1528143507401};\\\", \\\"{x:529,y:707,t:1528143507418};\\\", \\\"{x:560,y:707,t:1528143507435};\\\", \\\"{x:618,y:722,t:1528143507451};\\\", \\\"{x:701,y:743,t:1528143507469};\\\", \\\"{x:791,y:760,t:1528143507485};\\\", \\\"{x:890,y:781,t:1528143507501};\\\", \\\"{x:970,y:802,t:1528143507518};\\\", \\\"{x:1024,y:815,t:1528143507535};\\\", \\\"{x:1050,y:817,t:1528143507551};\\\", \\\"{x:1073,y:818,t:1528143507569};\\\", \\\"{x:1076,y:818,t:1528143507584};\\\", \\\"{x:1078,y:818,t:1528143507602};\\\", \\\"{x:1080,y:818,t:1528143507619};\\\", \\\"{x:1084,y:816,t:1528143507636};\\\", \\\"{x:1085,y:816,t:1528143507652};\\\", \\\"{x:1088,y:815,t:1528143507669};\\\", \\\"{x:1089,y:814,t:1528143507704};\\\" ] }, { \\\"rt\\\": 10808, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 201163, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"TTCWS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-04 PM-H -04 PM-H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1091,y:820,t:1528143510545};\\\", \\\"{x:1092,y:839,t:1528143510564};\\\", \\\"{x:1094,y:849,t:1528143510570};\\\", \\\"{x:1107,y:869,t:1528143510588};\\\", \\\"{x:1120,y:890,t:1528143510603};\\\", \\\"{x:1131,y:903,t:1528143510620};\\\", \\\"{x:1141,y:917,t:1528143510637};\\\", \\\"{x:1153,y:931,t:1528143510654};\\\", \\\"{x:1166,y:943,t:1528143510670};\\\", \\\"{x:1181,y:955,t:1528143510687};\\\", \\\"{x:1210,y:975,t:1528143510704};\\\", \\\"{x:1229,y:988,t:1528143510721};\\\", \\\"{x:1251,y:999,t:1528143510738};\\\", \\\"{x:1271,y:1009,t:1528143510755};\\\", \\\"{x:1289,y:1018,t:1528143510770};\\\", \\\"{x:1311,y:1031,t:1528143510788};\\\", \\\"{x:1335,y:1041,t:1528143510804};\\\", \\\"{x:1355,y:1048,t:1528143510821};\\\", \\\"{x:1380,y:1053,t:1528143510837};\\\", \\\"{x:1409,y:1059,t:1528143510855};\\\", \\\"{x:1440,y:1064,t:1528143510871};\\\", \\\"{x:1472,y:1065,t:1528143510888};\\\", \\\"{x:1513,y:1065,t:1528143510905};\\\", \\\"{x:1529,y:1065,t:1528143510921};\\\", \\\"{x:1538,y:1064,t:1528143510937};\\\", \\\"{x:1542,y:1061,t:1528143510954};\\\", \\\"{x:1543,y:1060,t:1528143510971};\\\", \\\"{x:1543,y:1058,t:1528143510987};\\\", \\\"{x:1546,y:1051,t:1528143511005};\\\", \\\"{x:1547,y:1046,t:1528143511021};\\\", \\\"{x:1550,y:1039,t:1528143511038};\\\", \\\"{x:1551,y:1033,t:1528143511054};\\\", \\\"{x:1551,y:1026,t:1528143511072};\\\", \\\"{x:1553,y:1021,t:1528143511088};\\\", \\\"{x:1554,y:1018,t:1528143511105};\\\", \\\"{x:1554,y:1015,t:1528143511121};\\\", \\\"{x:1557,y:1010,t:1528143511138};\\\", \\\"{x:1564,y:1004,t:1528143511155};\\\", \\\"{x:1572,y:997,t:1528143511172};\\\", \\\"{x:1578,y:993,t:1528143511188};\\\", \\\"{x:1581,y:992,t:1528143511205};\\\", \\\"{x:1585,y:990,t:1528143511222};\\\", \\\"{x:1587,y:989,t:1528143511238};\\\", \\\"{x:1592,y:987,t:1528143511255};\\\", \\\"{x:1593,y:986,t:1528143511272};\\\", \\\"{x:1594,y:986,t:1528143511288};\\\", \\\"{x:1598,y:985,t:1528143511305};\\\", \\\"{x:1603,y:981,t:1528143511322};\\\", \\\"{x:1605,y:981,t:1528143511338};\\\", \\\"{x:1606,y:980,t:1528143511355};\\\", \\\"{x:1607,y:980,t:1528143511377};\\\", \\\"{x:1608,y:979,t:1528143511388};\\\", \\\"{x:1609,y:978,t:1528143511405};\\\", \\\"{x:1612,y:976,t:1528143511422};\\\", \\\"{x:1615,y:975,t:1528143511438};\\\", \\\"{x:1618,y:973,t:1528143511455};\\\", \\\"{x:1619,y:973,t:1528143511472};\\\", \\\"{x:1620,y:971,t:1528143511529};\\\", \\\"{x:1621,y:971,t:1528143511577};\\\", \\\"{x:1620,y:971,t:1528143511737};\\\", \\\"{x:1619,y:971,t:1528143511745};\\\", \\\"{x:1618,y:971,t:1528143511777};\\\", \\\"{x:1616,y:971,t:1528143511969};\\\", \\\"{x:1614,y:969,t:1528143511977};\\\", \\\"{x:1609,y:965,t:1528143511989};\\\", \\\"{x:1598,y:952,t:1528143512005};\\\", \\\"{x:1584,y:940,t:1528143512023};\\\", \\\"{x:1574,y:931,t:1528143512039};\\\", \\\"{x:1568,y:926,t:1528143512056};\\\", \\\"{x:1563,y:922,t:1528143512072};\\\", \\\"{x:1557,y:912,t:1528143512090};\\\", \\\"{x:1550,y:901,t:1528143512105};\\\", \\\"{x:1543,y:886,t:1528143512122};\\\", \\\"{x:1531,y:867,t:1528143512139};\\\", \\\"{x:1521,y:847,t:1528143512157};\\\", \\\"{x:1515,y:841,t:1528143512172};\\\", \\\"{x:1507,y:831,t:1528143512189};\\\", \\\"{x:1502,y:826,t:1528143512207};\\\", \\\"{x:1500,y:819,t:1528143512222};\\\", \\\"{x:1493,y:809,t:1528143512240};\\\", \\\"{x:1489,y:796,t:1528143512256};\\\", \\\"{x:1483,y:783,t:1528143512272};\\\", \\\"{x:1476,y:764,t:1528143512288};\\\", \\\"{x:1471,y:753,t:1528143512306};\\\", \\\"{x:1467,y:745,t:1528143512321};\\\", \\\"{x:1464,y:737,t:1528143512338};\\\", \\\"{x:1462,y:733,t:1528143512355};\\\", \\\"{x:1459,y:725,t:1528143512372};\\\", \\\"{x:1455,y:717,t:1528143512388};\\\", \\\"{x:1453,y:706,t:1528143512406};\\\", \\\"{x:1448,y:687,t:1528143512422};\\\", \\\"{x:1443,y:671,t:1528143512439};\\\", \\\"{x:1437,y:654,t:1528143512455};\\\", \\\"{x:1432,y:642,t:1528143512472};\\\", \\\"{x:1422,y:625,t:1528143512488};\\\", \\\"{x:1418,y:617,t:1528143512506};\\\", \\\"{x:1414,y:612,t:1528143512522};\\\", \\\"{x:1413,y:609,t:1528143512539};\\\", \\\"{x:1410,y:604,t:1528143512556};\\\", \\\"{x:1407,y:599,t:1528143512572};\\\", \\\"{x:1406,y:597,t:1528143512589};\\\", \\\"{x:1406,y:595,t:1528143512605};\\\", \\\"{x:1406,y:593,t:1528143512729};\\\", \\\"{x:1406,y:592,t:1528143512745};\\\", \\\"{x:1406,y:589,t:1528143512761};\\\", \\\"{x:1407,y:587,t:1528143512777};\\\", \\\"{x:1407,y:586,t:1528143512789};\\\", \\\"{x:1407,y:583,t:1528143512806};\\\", \\\"{x:1409,y:578,t:1528143512823};\\\", \\\"{x:1410,y:574,t:1528143512840};\\\", \\\"{x:1412,y:572,t:1528143512856};\\\", \\\"{x:1412,y:571,t:1528143512873};\\\", \\\"{x:1412,y:569,t:1528143512889};\\\", \\\"{x:1412,y:568,t:1528143512908};\\\", \\\"{x:1414,y:567,t:1528143512923};\\\", \\\"{x:1414,y:566,t:1528143512976};\\\", \\\"{x:1415,y:565,t:1528143513105};\\\", \\\"{x:1417,y:565,t:1528143514081};\\\", \\\"{x:1417,y:572,t:1528143514091};\\\", \\\"{x:1424,y:591,t:1528143514107};\\\", \\\"{x:1440,y:620,t:1528143514124};\\\", \\\"{x:1460,y:650,t:1528143514140};\\\", \\\"{x:1476,y:682,t:1528143514157};\\\", \\\"{x:1500,y:720,t:1528143514175};\\\", \\\"{x:1521,y:756,t:1528143514191};\\\", \\\"{x:1544,y:799,t:1528143514207};\\\", \\\"{x:1568,y:830,t:1528143514225};\\\", \\\"{x:1590,y:871,t:1528143514241};\\\", \\\"{x:1615,y:905,t:1528143514257};\\\", \\\"{x:1630,y:922,t:1528143514274};\\\", \\\"{x:1637,y:938,t:1528143514290};\\\", \\\"{x:1641,y:951,t:1528143514308};\\\", \\\"{x:1642,y:959,t:1528143514324};\\\", \\\"{x:1643,y:963,t:1528143514341};\\\", \\\"{x:1643,y:969,t:1528143514357};\\\", \\\"{x:1643,y:972,t:1528143514374};\\\", \\\"{x:1643,y:974,t:1528143514390};\\\", \\\"{x:1643,y:979,t:1528143514407};\\\", \\\"{x:1643,y:982,t:1528143514424};\\\", \\\"{x:1642,y:986,t:1528143514441};\\\", \\\"{x:1641,y:987,t:1528143514457};\\\", \\\"{x:1640,y:986,t:1528143514586};\\\", \\\"{x:1636,y:982,t:1528143514594};\\\", \\\"{x:1635,y:978,t:1528143514607};\\\", \\\"{x:1628,y:970,t:1528143514624};\\\", \\\"{x:1623,y:964,t:1528143514641};\\\", \\\"{x:1623,y:962,t:1528143514657};\\\", \\\"{x:1622,y:960,t:1528143514674};\\\", \\\"{x:1620,y:957,t:1528143514890};\\\", \\\"{x:1616,y:950,t:1528143514897};\\\", \\\"{x:1610,y:941,t:1528143514907};\\\", \\\"{x:1602,y:925,t:1528143514925};\\\", \\\"{x:1583,y:900,t:1528143514941};\\\", \\\"{x:1569,y:880,t:1528143514958};\\\", \\\"{x:1558,y:866,t:1528143514974};\\\", \\\"{x:1549,y:854,t:1528143514991};\\\", \\\"{x:1538,y:840,t:1528143515008};\\\", \\\"{x:1531,y:827,t:1528143515024};\\\", \\\"{x:1518,y:804,t:1528143515042};\\\", \\\"{x:1510,y:791,t:1528143515058};\\\", \\\"{x:1500,y:776,t:1528143515074};\\\", \\\"{x:1491,y:763,t:1528143515092};\\\", \\\"{x:1486,y:755,t:1528143515109};\\\", \\\"{x:1483,y:744,t:1528143515124};\\\", \\\"{x:1477,y:730,t:1528143515141};\\\", \\\"{x:1471,y:714,t:1528143515159};\\\", \\\"{x:1463,y:698,t:1528143515175};\\\", \\\"{x:1460,y:689,t:1528143515191};\\\", \\\"{x:1455,y:680,t:1528143515208};\\\", \\\"{x:1452,y:674,t:1528143515225};\\\", \\\"{x:1450,y:668,t:1528143515242};\\\", \\\"{x:1448,y:665,t:1528143515258};\\\", \\\"{x:1448,y:662,t:1528143515274};\\\", \\\"{x:1447,y:658,t:1528143515291};\\\", \\\"{x:1443,y:652,t:1528143515308};\\\", \\\"{x:1442,y:644,t:1528143515324};\\\", \\\"{x:1440,y:638,t:1528143515342};\\\", \\\"{x:1436,y:628,t:1528143515358};\\\", \\\"{x:1434,y:619,t:1528143515376};\\\", \\\"{x:1432,y:613,t:1528143515391};\\\", \\\"{x:1430,y:606,t:1528143515408};\\\", \\\"{x:1426,y:598,t:1528143515425};\\\", \\\"{x:1426,y:594,t:1528143515442};\\\", \\\"{x:1423,y:588,t:1528143515458};\\\", \\\"{x:1422,y:585,t:1528143515474};\\\", \\\"{x:1422,y:582,t:1528143515492};\\\", \\\"{x:1420,y:579,t:1528143515508};\\\", \\\"{x:1420,y:577,t:1528143515525};\\\", \\\"{x:1419,y:576,t:1528143515541};\\\", \\\"{x:1419,y:574,t:1528143515562};\\\", \\\"{x:1419,y:573,t:1528143515586};\\\", \\\"{x:1418,y:571,t:1528143515784};\\\", \\\"{x:1418,y:570,t:1528143515800};\\\", \\\"{x:1417,y:569,t:1528143515817};\\\", \\\"{x:1417,y:568,t:1528143515824};\\\", \\\"{x:1417,y:566,t:1528143515864};\\\", \\\"{x:1416,y:564,t:1528143515896};\\\", \\\"{x:1415,y:563,t:1528143515936};\\\", \\\"{x:1414,y:563,t:1528143516017};\\\", \\\"{x:1413,y:562,t:1528143516041};\\\", \\\"{x:1412,y:560,t:1528143516073};\\\", \\\"{x:1411,y:559,t:1528143516097};\\\", \\\"{x:1410,y:559,t:1528143516113};\\\", \\\"{x:1410,y:558,t:1528143516163};\\\", \\\"{x:1409,y:558,t:1528143516754};\\\", \\\"{x:1406,y:559,t:1528143516762};\\\", \\\"{x:1406,y:560,t:1528143516775};\\\", \\\"{x:1404,y:562,t:1528143516793};\\\", \\\"{x:1398,y:565,t:1528143516809};\\\", \\\"{x:1383,y:566,t:1528143516826};\\\", \\\"{x:1352,y:566,t:1528143516842};\\\", \\\"{x:1291,y:566,t:1528143516859};\\\", \\\"{x:1202,y:566,t:1528143516875};\\\", \\\"{x:1111,y:566,t:1528143516892};\\\", \\\"{x:1028,y:558,t:1528143516909};\\\", \\\"{x:967,y:551,t:1528143516925};\\\", \\\"{x:935,y:551,t:1528143516943};\\\", \\\"{x:915,y:551,t:1528143516958};\\\", \\\"{x:903,y:551,t:1528143516976};\\\", \\\"{x:889,y:555,t:1528143516993};\\\", \\\"{x:882,y:557,t:1528143517010};\\\", \\\"{x:877,y:559,t:1528143517025};\\\", \\\"{x:867,y:564,t:1528143517043};\\\", \\\"{x:847,y:572,t:1528143517059};\\\", \\\"{x:823,y:579,t:1528143517076};\\\", \\\"{x:802,y:585,t:1528143517093};\\\", \\\"{x:784,y:588,t:1528143517110};\\\", \\\"{x:769,y:590,t:1528143517126};\\\", \\\"{x:751,y:595,t:1528143517143};\\\", \\\"{x:726,y:602,t:1528143517160};\\\", \\\"{x:697,y:607,t:1528143517177};\\\", \\\"{x:660,y:614,t:1528143517193};\\\", \\\"{x:638,y:614,t:1528143517209};\\\", \\\"{x:622,y:614,t:1528143517226};\\\", \\\"{x:609,y:614,t:1528143517243};\\\", \\\"{x:601,y:614,t:1528143517260};\\\", \\\"{x:596,y:614,t:1528143517277};\\\", \\\"{x:595,y:614,t:1528143517293};\\\", \\\"{x:595,y:613,t:1528143517393};\\\", \\\"{x:607,y:606,t:1528143517410};\\\", \\\"{x:616,y:602,t:1528143517426};\\\", \\\"{x:621,y:600,t:1528143517443};\\\", \\\"{x:625,y:598,t:1528143517458};\\\", \\\"{x:626,y:598,t:1528143517488};\\\", \\\"{x:627,y:598,t:1528143517496};\\\", \\\"{x:628,y:597,t:1528143517509};\\\", \\\"{x:632,y:594,t:1528143517526};\\\", \\\"{x:635,y:592,t:1528143517543};\\\", \\\"{x:637,y:589,t:1528143517559};\\\", \\\"{x:638,y:588,t:1528143517576};\\\", \\\"{x:639,y:587,t:1528143517594};\\\", \\\"{x:639,y:586,t:1528143517609};\\\", \\\"{x:639,y:585,t:1528143517627};\\\", \\\"{x:632,y:581,t:1528143517643};\\\", \\\"{x:626,y:579,t:1528143517659};\\\", \\\"{x:618,y:574,t:1528143517677};\\\", \\\"{x:615,y:571,t:1528143517693};\\\", \\\"{x:611,y:569,t:1528143517710};\\\", \\\"{x:610,y:568,t:1528143517727};\\\", \\\"{x:609,y:567,t:1528143517743};\\\", \\\"{x:609,y:566,t:1528143517760};\\\", \\\"{x:608,y:565,t:1528143517776};\\\", \\\"{x:607,y:564,t:1528143517794};\\\", \\\"{x:607,y:562,t:1528143517810};\\\", \\\"{x:607,y:560,t:1528143517827};\\\", \\\"{x:607,y:559,t:1528143517844};\\\", \\\"{x:601,y:561,t:1528143518257};\\\", \\\"{x:595,y:567,t:1528143518264};\\\", \\\"{x:592,y:572,t:1528143518277};\\\", \\\"{x:581,y:586,t:1528143518294};\\\", \\\"{x:574,y:593,t:1528143518311};\\\", \\\"{x:567,y:601,t:1528143518327};\\\", \\\"{x:562,y:606,t:1528143518344};\\\", \\\"{x:555,y:612,t:1528143518360};\\\", \\\"{x:551,y:619,t:1528143518377};\\\", \\\"{x:547,y:624,t:1528143518395};\\\", \\\"{x:542,y:633,t:1528143518411};\\\", \\\"{x:538,y:640,t:1528143518427};\\\", \\\"{x:536,y:645,t:1528143518444};\\\", \\\"{x:532,y:653,t:1528143518461};\\\", \\\"{x:529,y:662,t:1528143518478};\\\", \\\"{x:528,y:668,t:1528143518494};\\\", \\\"{x:526,y:673,t:1528143518510};\\\", \\\"{x:524,y:678,t:1528143518528};\\\", \\\"{x:523,y:684,t:1528143518544};\\\", \\\"{x:522,y:690,t:1528143518561};\\\", \\\"{x:522,y:694,t:1528143518578};\\\", \\\"{x:520,y:696,t:1528143518593};\\\", \\\"{x:520,y:700,t:1528143518611};\\\", \\\"{x:519,y:702,t:1528143518629};\\\", \\\"{x:519,y:705,t:1528143518644};\\\", \\\"{x:519,y:709,t:1528143518661};\\\", \\\"{x:517,y:715,t:1528143518678};\\\", \\\"{x:516,y:718,t:1528143518694};\\\", \\\"{x:516,y:722,t:1528143518711};\\\", \\\"{x:516,y:723,t:1528143518728};\\\", \\\"{x:516,y:725,t:1528143518744};\\\", \\\"{x:517,y:726,t:1528143519352};\\\", \\\"{x:526,y:725,t:1528143519360};\\\", \\\"{x:547,y:722,t:1528143519378};\\\", \\\"{x:568,y:719,t:1528143519395};\\\", \\\"{x:587,y:717,t:1528143519411};\\\", \\\"{x:608,y:714,t:1528143519428};\\\", \\\"{x:628,y:714,t:1528143519445};\\\", \\\"{x:649,y:714,t:1528143519462};\\\", \\\"{x:665,y:714,t:1528143519478};\\\", \\\"{x:679,y:714,t:1528143519495};\\\", \\\"{x:687,y:714,t:1528143519512};\\\", \\\"{x:693,y:714,t:1528143519528};\\\", \\\"{x:698,y:714,t:1528143519544};\\\", \\\"{x:699,y:714,t:1528143519562};\\\", \\\"{x:703,y:714,t:1528143519578};\\\", \\\"{x:711,y:715,t:1528143519595};\\\", \\\"{x:720,y:716,t:1528143519612};\\\", \\\"{x:731,y:718,t:1528143519627};\\\", \\\"{x:743,y:719,t:1528143519644};\\\", \\\"{x:760,y:723,t:1528143519662};\\\", \\\"{x:775,y:724,t:1528143519677};\\\", \\\"{x:789,y:726,t:1528143519695};\\\", \\\"{x:802,y:729,t:1528143519712};\\\", \\\"{x:812,y:730,t:1528143519728};\\\", \\\"{x:820,y:730,t:1528143519745};\\\", \\\"{x:822,y:730,t:1528143519762};\\\", \\\"{x:823,y:730,t:1528143519784};\\\", \\\"{x:823,y:731,t:1528143519795};\\\" ] }, { \\\"rt\\\": 32763, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 235142, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"TTCWS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -08 AM-I -U -03 PM-I -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:823,y:734,t:1528143524313};\\\", \\\"{x:825,y:752,t:1528143524332};\\\", \\\"{x:830,y:773,t:1528143524348};\\\", \\\"{x:835,y:790,t:1528143524365};\\\", \\\"{x:842,y:806,t:1528143524382};\\\", \\\"{x:848,y:821,t:1528143524398};\\\", \\\"{x:855,y:835,t:1528143524415};\\\", \\\"{x:870,y:862,t:1528143524431};\\\", \\\"{x:879,y:880,t:1528143524448};\\\", \\\"{x:892,y:902,t:1528143524465};\\\", \\\"{x:911,y:927,t:1528143524482};\\\", \\\"{x:927,y:952,t:1528143524498};\\\", \\\"{x:944,y:974,t:1528143524515};\\\", \\\"{x:964,y:1001,t:1528143524532};\\\", \\\"{x:986,y:1023,t:1528143524548};\\\", \\\"{x:1017,y:1052,t:1528143524565};\\\", \\\"{x:1045,y:1075,t:1528143524582};\\\", \\\"{x:1067,y:1093,t:1528143524599};\\\", \\\"{x:1097,y:1114,t:1528143524616};\\\", \\\"{x:1154,y:1156,t:1528143524632};\\\", \\\"{x:1202,y:1190,t:1528143524648};\\\", \\\"{x:1240,y:1199,t:1528143524665};\\\", \\\"{x:1275,y:1199,t:1528143524682};\\\", \\\"{x:1307,y:1199,t:1528143524700};\\\", \\\"{x:1337,y:1199,t:1528143524716};\\\", \\\"{x:1368,y:1199,t:1528143524733};\\\", \\\"{x:1397,y:1199,t:1528143524750};\\\", \\\"{x:1420,y:1199,t:1528143524766};\\\", \\\"{x:1440,y:1199,t:1528143524784};\\\", \\\"{x:1449,y:1199,t:1528143524799};\\\", \\\"{x:1454,y:1199,t:1528143524816};\\\", \\\"{x:1457,y:1198,t:1528143524832};\\\", \\\"{x:1466,y:1188,t:1528143524849};\\\", \\\"{x:1472,y:1178,t:1528143524867};\\\", \\\"{x:1477,y:1162,t:1528143524883};\\\", \\\"{x:1482,y:1146,t:1528143524899};\\\", \\\"{x:1483,y:1132,t:1528143524916};\\\", \\\"{x:1486,y:1119,t:1528143524932};\\\", \\\"{x:1486,y:1105,t:1528143524949};\\\", \\\"{x:1488,y:1085,t:1528143524967};\\\", \\\"{x:1493,y:1058,t:1528143524983};\\\", \\\"{x:1497,y:1032,t:1528143525000};\\\", \\\"{x:1501,y:994,t:1528143525016};\\\", \\\"{x:1503,y:979,t:1528143525032};\\\", \\\"{x:1504,y:966,t:1528143525049};\\\", \\\"{x:1505,y:955,t:1528143525066};\\\", \\\"{x:1505,y:947,t:1528143525084};\\\", \\\"{x:1505,y:946,t:1528143525099};\\\", \\\"{x:1505,y:948,t:1528143525241};\\\", \\\"{x:1508,y:951,t:1528143525250};\\\", \\\"{x:1509,y:956,t:1528143525266};\\\", \\\"{x:1510,y:958,t:1528143525284};\\\", \\\"{x:1511,y:959,t:1528143525299};\\\", \\\"{x:1511,y:961,t:1528143525316};\\\", \\\"{x:1512,y:963,t:1528143525334};\\\", \\\"{x:1512,y:965,t:1528143525350};\\\", \\\"{x:1513,y:968,t:1528143525367};\\\", \\\"{x:1513,y:971,t:1528143525384};\\\", \\\"{x:1513,y:974,t:1528143525400};\\\", \\\"{x:1514,y:976,t:1528143525417};\\\", \\\"{x:1514,y:978,t:1528143525433};\\\", \\\"{x:1514,y:981,t:1528143525450};\\\", \\\"{x:1514,y:984,t:1528143525466};\\\", \\\"{x:1514,y:988,t:1528143525483};\\\", \\\"{x:1513,y:992,t:1528143525501};\\\", \\\"{x:1511,y:997,t:1528143525516};\\\", \\\"{x:1510,y:999,t:1528143525534};\\\", \\\"{x:1506,y:1002,t:1528143525550};\\\", \\\"{x:1502,y:1004,t:1528143525567};\\\", \\\"{x:1496,y:1005,t:1528143525583};\\\", \\\"{x:1482,y:1005,t:1528143525601};\\\", \\\"{x:1472,y:1005,t:1528143525617};\\\", \\\"{x:1460,y:1005,t:1528143525634};\\\", \\\"{x:1445,y:1005,t:1528143525650};\\\", \\\"{x:1428,y:1004,t:1528143525667};\\\", \\\"{x:1405,y:1001,t:1528143525683};\\\", \\\"{x:1383,y:1001,t:1528143525701};\\\", \\\"{x:1357,y:998,t:1528143525717};\\\", \\\"{x:1333,y:996,t:1528143525734};\\\", \\\"{x:1317,y:996,t:1528143525751};\\\", \\\"{x:1298,y:996,t:1528143525767};\\\", \\\"{x:1280,y:996,t:1528143525784};\\\", \\\"{x:1261,y:996,t:1528143525801};\\\", \\\"{x:1245,y:996,t:1528143525817};\\\", \\\"{x:1230,y:996,t:1528143525834};\\\", \\\"{x:1214,y:996,t:1528143525851};\\\", \\\"{x:1200,y:996,t:1528143525867};\\\", \\\"{x:1185,y:996,t:1528143525883};\\\", \\\"{x:1171,y:996,t:1528143525901};\\\", \\\"{x:1159,y:996,t:1528143525917};\\\", \\\"{x:1149,y:996,t:1528143525934};\\\", \\\"{x:1139,y:998,t:1528143525951};\\\", \\\"{x:1126,y:1002,t:1528143525968};\\\", \\\"{x:1114,y:1005,t:1528143525983};\\\", \\\"{x:1097,y:1014,t:1528143526001};\\\", \\\"{x:1085,y:1020,t:1528143526017};\\\", \\\"{x:1073,y:1029,t:1528143526034};\\\", \\\"{x:1059,y:1038,t:1528143526051};\\\", \\\"{x:1049,y:1045,t:1528143526068};\\\", \\\"{x:1043,y:1050,t:1528143526083};\\\", \\\"{x:1041,y:1052,t:1528143526100};\\\", \\\"{x:1041,y:1050,t:1528143526217};\\\", \\\"{x:1062,y:996,t:1528143526233};\\\", \\\"{x:1107,y:886,t:1528143526251};\\\", \\\"{x:1145,y:766,t:1528143526267};\\\", \\\"{x:1179,y:671,t:1528143526283};\\\", \\\"{x:1200,y:619,t:1528143526300};\\\", \\\"{x:1222,y:564,t:1528143526318};\\\", \\\"{x:1241,y:500,t:1528143526335};\\\", \\\"{x:1265,y:425,t:1528143526351};\\\", \\\"{x:1286,y:355,t:1528143526367};\\\", \\\"{x:1308,y:312,t:1528143526384};\\\", \\\"{x:1314,y:302,t:1528143526400};\\\", \\\"{x:1317,y:296,t:1528143526418};\\\", \\\"{x:1318,y:292,t:1528143526434};\\\", \\\"{x:1319,y:291,t:1528143526451};\\\", \\\"{x:1319,y:292,t:1528143526513};\\\", \\\"{x:1319,y:302,t:1528143526521};\\\", \\\"{x:1318,y:316,t:1528143526535};\\\", \\\"{x:1312,y:342,t:1528143526551};\\\", \\\"{x:1307,y:364,t:1528143526568};\\\", \\\"{x:1305,y:386,t:1528143526585};\\\", \\\"{x:1305,y:405,t:1528143526601};\\\", \\\"{x:1305,y:427,t:1528143526618};\\\", \\\"{x:1304,y:448,t:1528143526635};\\\", \\\"{x:1304,y:464,t:1528143526651};\\\", \\\"{x:1304,y:475,t:1528143526668};\\\", \\\"{x:1304,y:481,t:1528143526685};\\\", \\\"{x:1307,y:489,t:1528143526701};\\\", \\\"{x:1307,y:490,t:1528143526754};\\\", \\\"{x:1307,y:491,t:1528143526778};\\\", \\\"{x:1308,y:491,t:1528143527193};\\\", \\\"{x:1309,y:491,t:1528143527209};\\\", \\\"{x:1310,y:491,t:1528143527218};\\\", \\\"{x:1311,y:491,t:1528143527241};\\\", \\\"{x:1312,y:491,t:1528143527273};\\\", \\\"{x:1313,y:491,t:1528143527292};\\\", \\\"{x:1314,y:492,t:1528143527360};\\\", \\\"{x:1315,y:492,t:1528143527400};\\\", \\\"{x:1315,y:493,t:1528143527416};\\\", \\\"{x:1315,y:494,t:1528143527432};\\\", \\\"{x:1315,y:495,t:1528143527440};\\\", \\\"{x:1315,y:496,t:1528143527451};\\\", \\\"{x:1315,y:497,t:1528143527468};\\\", \\\"{x:1316,y:499,t:1528143527488};\\\", \\\"{x:1316,y:500,t:1528143528257};\\\", \\\"{x:1315,y:502,t:1528143528289};\\\", \\\"{x:1309,y:509,t:1528143528304};\\\", \\\"{x:1300,y:520,t:1528143528319};\\\", \\\"{x:1292,y:530,t:1528143528336};\\\", \\\"{x:1277,y:550,t:1528143528353};\\\", \\\"{x:1267,y:566,t:1528143528369};\\\", \\\"{x:1256,y:588,t:1528143528386};\\\", \\\"{x:1244,y:615,t:1528143528403};\\\", \\\"{x:1226,y:656,t:1528143528419};\\\", \\\"{x:1214,y:685,t:1528143528436};\\\", \\\"{x:1200,y:720,t:1528143528453};\\\", \\\"{x:1190,y:752,t:1528143528469};\\\", \\\"{x:1179,y:781,t:1528143528486};\\\", \\\"{x:1169,y:802,t:1528143528503};\\\", \\\"{x:1160,y:826,t:1528143528520};\\\", \\\"{x:1150,y:849,t:1528143528536};\\\", \\\"{x:1134,y:878,t:1528143528553};\\\", \\\"{x:1129,y:891,t:1528143528569};\\\", \\\"{x:1124,y:900,t:1528143528586};\\\", \\\"{x:1116,y:911,t:1528143528603};\\\", \\\"{x:1110,y:922,t:1528143528620};\\\", \\\"{x:1105,y:929,t:1528143528636};\\\", \\\"{x:1102,y:933,t:1528143528653};\\\", \\\"{x:1101,y:935,t:1528143528670};\\\", \\\"{x:1099,y:938,t:1528143528686};\\\", \\\"{x:1097,y:941,t:1528143528702};\\\", \\\"{x:1094,y:945,t:1528143528720};\\\", \\\"{x:1091,y:949,t:1528143528736};\\\", \\\"{x:1087,y:954,t:1528143528753};\\\", \\\"{x:1086,y:957,t:1528143528769};\\\", \\\"{x:1083,y:959,t:1528143528786};\\\", \\\"{x:1081,y:961,t:1528143528803};\\\", \\\"{x:1078,y:965,t:1528143528821};\\\", \\\"{x:1077,y:967,t:1528143528836};\\\", \\\"{x:1076,y:969,t:1528143528854};\\\", \\\"{x:1076,y:970,t:1528143528870};\\\", \\\"{x:1076,y:971,t:1528143528886};\\\", \\\"{x:1076,y:972,t:1528143528903};\\\", \\\"{x:1078,y:967,t:1528143529186};\\\", \\\"{x:1079,y:963,t:1528143529203};\\\", \\\"{x:1081,y:960,t:1528143529220};\\\", \\\"{x:1083,y:958,t:1528143529237};\\\", \\\"{x:1085,y:954,t:1528143529252};\\\", \\\"{x:1086,y:952,t:1528143529273};\\\", \\\"{x:1087,y:950,t:1528143529304};\\\", \\\"{x:1088,y:949,t:1528143529320};\\\", \\\"{x:1088,y:948,t:1528143529336};\\\", \\\"{x:1091,y:944,t:1528143529353};\\\", \\\"{x:1092,y:943,t:1528143529369};\\\", \\\"{x:1095,y:940,t:1528143529386};\\\", \\\"{x:1098,y:936,t:1528143529403};\\\", \\\"{x:1102,y:932,t:1528143529420};\\\", \\\"{x:1110,y:925,t:1528143529436};\\\", \\\"{x:1118,y:917,t:1528143529454};\\\", \\\"{x:1125,y:909,t:1528143529469};\\\", \\\"{x:1131,y:900,t:1528143529486};\\\", \\\"{x:1141,y:887,t:1528143529504};\\\", \\\"{x:1148,y:877,t:1528143529519};\\\", \\\"{x:1165,y:854,t:1528143529537};\\\", \\\"{x:1180,y:834,t:1528143529553};\\\", \\\"{x:1196,y:811,t:1528143529570};\\\", \\\"{x:1206,y:788,t:1528143529586};\\\", \\\"{x:1219,y:760,t:1528143529604};\\\", \\\"{x:1230,y:734,t:1528143529620};\\\", \\\"{x:1245,y:706,t:1528143529637};\\\", \\\"{x:1275,y:655,t:1528143529654};\\\", \\\"{x:1303,y:603,t:1528143529670};\\\", \\\"{x:1332,y:564,t:1528143529687};\\\", \\\"{x:1347,y:537,t:1528143529704};\\\", \\\"{x:1353,y:520,t:1528143529720};\\\", \\\"{x:1355,y:507,t:1528143529738};\\\", \\\"{x:1356,y:504,t:1528143529754};\\\", \\\"{x:1356,y:501,t:1528143529770};\\\", \\\"{x:1356,y:498,t:1528143529787};\\\", \\\"{x:1356,y:495,t:1528143529804};\\\", \\\"{x:1356,y:494,t:1528143529821};\\\", \\\"{x:1356,y:492,t:1528143529837};\\\", \\\"{x:1356,y:491,t:1528143529854};\\\", \\\"{x:1356,y:489,t:1528143529871};\\\", \\\"{x:1355,y:487,t:1528143529887};\\\", \\\"{x:1353,y:487,t:1528143529905};\\\", \\\"{x:1348,y:485,t:1528143529920};\\\", \\\"{x:1342,y:485,t:1528143529937};\\\", \\\"{x:1336,y:485,t:1528143529954};\\\", \\\"{x:1329,y:485,t:1528143529971};\\\", \\\"{x:1322,y:485,t:1528143529987};\\\", \\\"{x:1319,y:485,t:1528143530004};\\\", \\\"{x:1318,y:485,t:1528143530020};\\\", \\\"{x:1317,y:485,t:1528143530041};\\\", \\\"{x:1316,y:485,t:1528143530273};\\\", \\\"{x:1315,y:485,t:1528143530288};\\\", \\\"{x:1315,y:487,t:1528143530304};\\\", \\\"{x:1315,y:489,t:1528143530320};\\\", \\\"{x:1315,y:492,t:1528143530338};\\\", \\\"{x:1315,y:495,t:1528143530353};\\\", \\\"{x:1315,y:498,t:1528143530370};\\\", \\\"{x:1316,y:503,t:1528143530388};\\\", \\\"{x:1316,y:505,t:1528143530403};\\\", \\\"{x:1316,y:507,t:1528143530420};\\\", \\\"{x:1316,y:508,t:1528143530437};\\\", \\\"{x:1316,y:510,t:1528143530453};\\\", \\\"{x:1317,y:515,t:1528143530470};\\\", \\\"{x:1318,y:518,t:1528143530488};\\\", \\\"{x:1319,y:523,t:1528143530503};\\\", \\\"{x:1323,y:538,t:1528143530520};\\\", \\\"{x:1326,y:547,t:1528143530538};\\\", \\\"{x:1328,y:553,t:1528143530553};\\\", \\\"{x:1329,y:557,t:1528143530571};\\\", \\\"{x:1330,y:561,t:1528143530588};\\\", \\\"{x:1330,y:563,t:1528143530604};\\\", \\\"{x:1331,y:564,t:1528143530621};\\\", \\\"{x:1332,y:567,t:1528143530638};\\\", \\\"{x:1333,y:570,t:1528143530654};\\\", \\\"{x:1334,y:573,t:1528143530671};\\\", \\\"{x:1335,y:576,t:1528143530688};\\\", \\\"{x:1336,y:579,t:1528143530705};\\\", \\\"{x:1337,y:581,t:1528143530721};\\\", \\\"{x:1338,y:582,t:1528143530738};\\\", \\\"{x:1339,y:586,t:1528143530754};\\\", \\\"{x:1342,y:590,t:1528143530771};\\\", \\\"{x:1342,y:593,t:1528143530788};\\\", \\\"{x:1344,y:596,t:1528143530805};\\\", \\\"{x:1345,y:598,t:1528143530821};\\\", \\\"{x:1345,y:599,t:1528143530837};\\\", \\\"{x:1347,y:603,t:1528143530855};\\\", \\\"{x:1348,y:606,t:1528143530871};\\\", \\\"{x:1350,y:609,t:1528143530888};\\\", \\\"{x:1354,y:616,t:1528143530905};\\\", \\\"{x:1357,y:621,t:1528143530921};\\\", \\\"{x:1359,y:623,t:1528143530938};\\\", \\\"{x:1360,y:624,t:1528143530955};\\\", \\\"{x:1361,y:625,t:1528143530970};\\\", \\\"{x:1361,y:626,t:1528143530988};\\\", \\\"{x:1361,y:627,t:1528143531009};\\\", \\\"{x:1362,y:628,t:1528143531021};\\\", \\\"{x:1362,y:630,t:1528143531038};\\\", \\\"{x:1364,y:632,t:1528143531055};\\\", \\\"{x:1365,y:634,t:1528143531070};\\\", \\\"{x:1367,y:637,t:1528143531088};\\\", \\\"{x:1369,y:639,t:1528143531105};\\\", \\\"{x:1369,y:641,t:1528143531121};\\\", \\\"{x:1371,y:644,t:1528143531138};\\\", \\\"{x:1374,y:649,t:1528143531155};\\\", \\\"{x:1377,y:655,t:1528143531172};\\\", \\\"{x:1379,y:663,t:1528143531188};\\\", \\\"{x:1382,y:669,t:1528143531205};\\\", \\\"{x:1388,y:679,t:1528143531221};\\\", \\\"{x:1395,y:690,t:1528143531238};\\\", \\\"{x:1397,y:698,t:1528143531255};\\\", \\\"{x:1401,y:705,t:1528143531272};\\\", \\\"{x:1404,y:709,t:1528143531288};\\\", \\\"{x:1406,y:716,t:1528143531305};\\\", \\\"{x:1409,y:722,t:1528143531321};\\\", \\\"{x:1414,y:730,t:1528143531338};\\\", \\\"{x:1421,y:742,t:1528143531355};\\\", \\\"{x:1425,y:749,t:1528143531372};\\\", \\\"{x:1431,y:757,t:1528143531388};\\\", \\\"{x:1434,y:762,t:1528143531405};\\\", \\\"{x:1435,y:765,t:1528143531422};\\\", \\\"{x:1436,y:767,t:1528143531438};\\\", \\\"{x:1438,y:770,t:1528143531455};\\\", \\\"{x:1439,y:773,t:1528143531472};\\\", \\\"{x:1442,y:777,t:1528143531489};\\\", \\\"{x:1448,y:785,t:1528143531505};\\\", \\\"{x:1455,y:793,t:1528143531522};\\\", \\\"{x:1461,y:802,t:1528143531539};\\\", \\\"{x:1464,y:806,t:1528143531555};\\\", \\\"{x:1469,y:816,t:1528143531572};\\\", \\\"{x:1478,y:826,t:1528143531588};\\\", \\\"{x:1486,y:837,t:1528143531606};\\\", \\\"{x:1494,y:845,t:1528143531623};\\\", \\\"{x:1500,y:851,t:1528143531638};\\\", \\\"{x:1504,y:856,t:1528143531655};\\\", \\\"{x:1506,y:858,t:1528143531673};\\\", \\\"{x:1508,y:861,t:1528143531689};\\\", \\\"{x:1508,y:862,t:1528143531705};\\\", \\\"{x:1508,y:864,t:1528143531722};\\\", \\\"{x:1509,y:864,t:1528143531753};\\\", \\\"{x:1509,y:865,t:1528143531769};\\\", \\\"{x:1510,y:867,t:1528143531777};\\\", \\\"{x:1511,y:870,t:1528143531793};\\\", \\\"{x:1512,y:872,t:1528143531805};\\\", \\\"{x:1513,y:875,t:1528143531822};\\\", \\\"{x:1514,y:883,t:1528143531839};\\\", \\\"{x:1516,y:887,t:1528143531855};\\\", \\\"{x:1517,y:891,t:1528143531872};\\\", \\\"{x:1519,y:895,t:1528143531889};\\\", \\\"{x:1519,y:897,t:1528143531905};\\\", \\\"{x:1521,y:902,t:1528143531922};\\\", \\\"{x:1523,y:910,t:1528143531939};\\\", \\\"{x:1526,y:917,t:1528143531955};\\\", \\\"{x:1533,y:927,t:1528143531972};\\\", \\\"{x:1541,y:938,t:1528143531989};\\\", \\\"{x:1546,y:944,t:1528143532005};\\\", \\\"{x:1548,y:946,t:1528143532022};\\\", \\\"{x:1550,y:948,t:1528143532039};\\\", \\\"{x:1550,y:949,t:1528143532056};\\\", \\\"{x:1551,y:950,t:1528143532072};\\\", \\\"{x:1556,y:957,t:1528143532089};\\\", \\\"{x:1561,y:961,t:1528143532106};\\\", \\\"{x:1563,y:962,t:1528143532122};\\\", \\\"{x:1565,y:964,t:1528143532140};\\\", \\\"{x:1566,y:964,t:1528143532306};\\\", \\\"{x:1566,y:966,t:1528143532322};\\\", \\\"{x:1565,y:969,t:1528143532339};\\\", \\\"{x:1563,y:970,t:1528143532356};\\\", \\\"{x:1563,y:972,t:1528143532372};\\\", \\\"{x:1561,y:973,t:1528143532389};\\\", \\\"{x:1561,y:974,t:1528143532417};\\\", \\\"{x:1560,y:975,t:1528143532457};\\\", \\\"{x:1559,y:976,t:1528143532489};\\\", \\\"{x:1558,y:977,t:1528143532506};\\\", \\\"{x:1557,y:977,t:1528143534417};\\\", \\\"{x:1554,y:973,t:1528143534425};\\\", \\\"{x:1550,y:964,t:1528143534441};\\\", \\\"{x:1548,y:960,t:1528143534458};\\\", \\\"{x:1548,y:956,t:1528143534474};\\\", \\\"{x:1546,y:955,t:1528143534490};\\\", \\\"{x:1546,y:953,t:1528143534576};\\\", \\\"{x:1545,y:952,t:1528143534600};\\\", \\\"{x:1544,y:950,t:1528143534608};\\\", \\\"{x:1544,y:949,t:1528143534624};\\\", \\\"{x:1541,y:944,t:1528143534640};\\\", \\\"{x:1537,y:938,t:1528143534657};\\\", \\\"{x:1534,y:933,t:1528143534673};\\\", \\\"{x:1530,y:928,t:1528143534691};\\\", \\\"{x:1527,y:922,t:1528143534707};\\\", \\\"{x:1522,y:917,t:1528143534724};\\\", \\\"{x:1518,y:908,t:1528143534741};\\\", \\\"{x:1514,y:902,t:1528143534757};\\\", \\\"{x:1508,y:892,t:1528143534774};\\\", \\\"{x:1503,y:883,t:1528143534791};\\\", \\\"{x:1497,y:873,t:1528143534808};\\\", \\\"{x:1487,y:856,t:1528143534825};\\\", \\\"{x:1478,y:844,t:1528143534840};\\\", \\\"{x:1472,y:835,t:1528143534858};\\\", \\\"{x:1468,y:829,t:1528143534874};\\\", \\\"{x:1465,y:824,t:1528143534891};\\\", \\\"{x:1460,y:814,t:1528143534908};\\\", \\\"{x:1456,y:804,t:1528143534924};\\\", \\\"{x:1450,y:785,t:1528143534941};\\\", \\\"{x:1440,y:765,t:1528143534958};\\\", \\\"{x:1433,y:749,t:1528143534974};\\\", \\\"{x:1422,y:732,t:1528143534991};\\\", \\\"{x:1414,y:716,t:1528143535008};\\\", \\\"{x:1406,y:696,t:1528143535024};\\\", \\\"{x:1387,y:650,t:1528143535041};\\\", \\\"{x:1373,y:617,t:1528143535058};\\\", \\\"{x:1354,y:590,t:1528143535074};\\\", \\\"{x:1345,y:575,t:1528143535091};\\\", \\\"{x:1338,y:564,t:1528143535109};\\\", \\\"{x:1333,y:552,t:1528143535124};\\\", \\\"{x:1330,y:544,t:1528143535141};\\\", \\\"{x:1325,y:537,t:1528143535158};\\\", \\\"{x:1323,y:532,t:1528143535175};\\\", \\\"{x:1322,y:530,t:1528143535192};\\\", \\\"{x:1321,y:529,t:1528143535225};\\\", \\\"{x:1321,y:528,t:1528143535241};\\\", \\\"{x:1320,y:524,t:1528143535259};\\\", \\\"{x:1318,y:519,t:1528143535276};\\\", \\\"{x:1316,y:514,t:1528143535290};\\\", \\\"{x:1315,y:512,t:1528143535308};\\\", \\\"{x:1314,y:509,t:1528143535325};\\\", \\\"{x:1314,y:507,t:1528143535340};\\\", \\\"{x:1312,y:505,t:1528143535358};\\\", \\\"{x:1311,y:502,t:1528143535374};\\\", \\\"{x:1310,y:497,t:1528143535390};\\\", \\\"{x:1308,y:495,t:1528143535408};\\\", \\\"{x:1307,y:493,t:1528143535425};\\\", \\\"{x:1304,y:493,t:1528143535753};\\\", \\\"{x:1304,y:498,t:1528143535760};\\\", \\\"{x:1300,y:505,t:1528143535775};\\\", \\\"{x:1300,y:513,t:1528143535792};\\\", \\\"{x:1299,y:518,t:1528143535808};\\\", \\\"{x:1299,y:525,t:1528143535825};\\\", \\\"{x:1299,y:529,t:1528143535842};\\\", \\\"{x:1299,y:536,t:1528143535858};\\\", \\\"{x:1299,y:543,t:1528143535875};\\\", \\\"{x:1299,y:551,t:1528143535892};\\\", \\\"{x:1299,y:558,t:1528143535908};\\\", \\\"{x:1299,y:566,t:1528143535925};\\\", \\\"{x:1299,y:570,t:1528143535942};\\\", \\\"{x:1299,y:576,t:1528143535958};\\\", \\\"{x:1299,y:581,t:1528143535975};\\\", \\\"{x:1299,y:587,t:1528143535992};\\\", \\\"{x:1299,y:594,t:1528143536009};\\\", \\\"{x:1299,y:596,t:1528143536025};\\\", \\\"{x:1299,y:599,t:1528143536043};\\\", \\\"{x:1299,y:600,t:1528143536065};\\\", \\\"{x:1300,y:601,t:1528143536075};\\\", \\\"{x:1300,y:602,t:1528143536092};\\\", \\\"{x:1300,y:604,t:1528143536110};\\\", \\\"{x:1300,y:609,t:1528143536125};\\\", \\\"{x:1303,y:614,t:1528143536142};\\\", \\\"{x:1303,y:619,t:1528143536159};\\\", \\\"{x:1305,y:624,t:1528143536175};\\\", \\\"{x:1307,y:628,t:1528143536193};\\\", \\\"{x:1307,y:639,t:1528143536209};\\\", \\\"{x:1308,y:646,t:1528143536225};\\\", \\\"{x:1311,y:652,t:1528143536242};\\\", \\\"{x:1311,y:654,t:1528143536259};\\\", \\\"{x:1311,y:655,t:1528143536305};\\\", \\\"{x:1312,y:656,t:1528143536313};\\\", \\\"{x:1312,y:657,t:1528143536325};\\\", \\\"{x:1313,y:661,t:1528143536342};\\\", \\\"{x:1313,y:664,t:1528143536360};\\\", \\\"{x:1314,y:670,t:1528143536375};\\\", \\\"{x:1314,y:673,t:1528143536393};\\\", \\\"{x:1315,y:676,t:1528143536409};\\\", \\\"{x:1315,y:678,t:1528143536425};\\\", \\\"{x:1315,y:680,t:1528143536443};\\\", \\\"{x:1315,y:685,t:1528143536459};\\\", \\\"{x:1316,y:688,t:1528143536475};\\\", \\\"{x:1316,y:693,t:1528143536493};\\\", \\\"{x:1318,y:697,t:1528143536509};\\\", \\\"{x:1319,y:702,t:1528143536527};\\\", \\\"{x:1320,y:708,t:1528143536542};\\\", \\\"{x:1322,y:713,t:1528143536560};\\\", \\\"{x:1322,y:719,t:1528143536577};\\\", \\\"{x:1323,y:723,t:1528143536592};\\\", \\\"{x:1324,y:730,t:1528143536609};\\\", \\\"{x:1324,y:732,t:1528143536627};\\\", \\\"{x:1324,y:735,t:1528143536643};\\\", \\\"{x:1324,y:738,t:1528143536660};\\\", \\\"{x:1324,y:741,t:1528143536677};\\\", \\\"{x:1324,y:744,t:1528143536693};\\\", \\\"{x:1324,y:747,t:1528143536710};\\\", \\\"{x:1324,y:751,t:1528143536727};\\\", \\\"{x:1323,y:754,t:1528143536742};\\\", \\\"{x:1323,y:756,t:1528143536759};\\\", \\\"{x:1322,y:759,t:1528143536777};\\\", \\\"{x:1322,y:761,t:1528143536793};\\\", \\\"{x:1320,y:763,t:1528143536810};\\\", \\\"{x:1319,y:768,t:1528143536827};\\\", \\\"{x:1319,y:771,t:1528143536842};\\\", \\\"{x:1319,y:774,t:1528143536859};\\\", \\\"{x:1318,y:775,t:1528143536876};\\\", \\\"{x:1317,y:777,t:1528143536892};\\\", \\\"{x:1317,y:779,t:1528143536909};\\\", \\\"{x:1316,y:781,t:1528143536927};\\\", \\\"{x:1316,y:787,t:1528143536943};\\\", \\\"{x:1316,y:792,t:1528143536959};\\\", \\\"{x:1316,y:795,t:1528143536976};\\\", \\\"{x:1316,y:798,t:1528143536993};\\\", \\\"{x:1316,y:799,t:1528143537009};\\\", \\\"{x:1316,y:800,t:1528143537027};\\\", \\\"{x:1316,y:801,t:1528143537073};\\\", \\\"{x:1316,y:802,t:1528143537081};\\\", \\\"{x:1316,y:803,t:1528143537093};\\\", \\\"{x:1315,y:804,t:1528143537109};\\\", \\\"{x:1315,y:805,t:1528143537126};\\\", \\\"{x:1315,y:806,t:1528143537144};\\\", \\\"{x:1315,y:808,t:1528143537160};\\\", \\\"{x:1313,y:811,t:1528143537177};\\\", \\\"{x:1313,y:812,t:1528143537193};\\\", \\\"{x:1313,y:815,t:1528143537210};\\\", \\\"{x:1313,y:816,t:1528143537233};\\\", \\\"{x:1313,y:817,t:1528143537243};\\\", \\\"{x:1313,y:819,t:1528143537259};\\\", \\\"{x:1312,y:822,t:1528143537277};\\\", \\\"{x:1311,y:826,t:1528143537293};\\\", \\\"{x:1311,y:829,t:1528143537310};\\\", \\\"{x:1310,y:831,t:1528143537326};\\\", \\\"{x:1310,y:832,t:1528143537343};\\\", \\\"{x:1310,y:834,t:1528143537361};\\\", \\\"{x:1309,y:834,t:1528143537376};\\\", \\\"{x:1309,y:835,t:1528143537393};\\\", \\\"{x:1309,y:837,t:1528143537410};\\\", \\\"{x:1309,y:840,t:1528143537426};\\\", \\\"{x:1309,y:843,t:1528143537444};\\\", \\\"{x:1309,y:845,t:1528143537460};\\\", \\\"{x:1308,y:845,t:1528143537476};\\\", \\\"{x:1308,y:847,t:1528143537493};\\\", \\\"{x:1308,y:848,t:1528143537513};\\\", \\\"{x:1308,y:850,t:1528143537529};\\\", \\\"{x:1307,y:851,t:1528143537544};\\\", \\\"{x:1307,y:852,t:1528143537561};\\\", \\\"{x:1307,y:854,t:1528143537576};\\\", \\\"{x:1306,y:856,t:1528143537593};\\\", \\\"{x:1306,y:857,t:1528143537617};\\\", \\\"{x:1306,y:858,t:1528143537633};\\\", \\\"{x:1306,y:859,t:1528143537649};\\\", \\\"{x:1306,y:861,t:1528143537665};\\\", \\\"{x:1306,y:863,t:1528143537681};\\\", \\\"{x:1306,y:864,t:1528143537705};\\\", \\\"{x:1306,y:865,t:1528143537713};\\\", \\\"{x:1306,y:866,t:1528143537729};\\\", \\\"{x:1306,y:867,t:1528143537762};\\\", \\\"{x:1306,y:870,t:1528143537777};\\\", \\\"{x:1306,y:874,t:1528143537793};\\\", \\\"{x:1306,y:877,t:1528143537810};\\\", \\\"{x:1306,y:880,t:1528143537827};\\\", \\\"{x:1306,y:886,t:1528143537844};\\\", \\\"{x:1305,y:890,t:1528143537860};\\\", \\\"{x:1305,y:892,t:1528143537877};\\\", \\\"{x:1305,y:893,t:1528143537894};\\\", \\\"{x:1303,y:896,t:1528143537911};\\\", \\\"{x:1303,y:898,t:1528143537928};\\\", \\\"{x:1302,y:900,t:1528143537944};\\\", \\\"{x:1301,y:902,t:1528143537960};\\\", \\\"{x:1300,y:907,t:1528143537977};\\\", \\\"{x:1299,y:912,t:1528143537994};\\\", \\\"{x:1298,y:918,t:1528143538010};\\\", \\\"{x:1297,y:923,t:1528143538028};\\\", \\\"{x:1297,y:926,t:1528143538044};\\\", \\\"{x:1297,y:929,t:1528143538061};\\\", \\\"{x:1297,y:933,t:1528143538078};\\\", \\\"{x:1297,y:936,t:1528143538094};\\\", \\\"{x:1299,y:939,t:1528143538110};\\\", \\\"{x:1299,y:941,t:1528143538128};\\\", \\\"{x:1302,y:945,t:1528143538143};\\\", \\\"{x:1304,y:948,t:1528143538160};\\\", \\\"{x:1306,y:951,t:1528143538177};\\\", \\\"{x:1307,y:952,t:1528143538217};\\\", \\\"{x:1307,y:953,t:1528143538228};\\\", \\\"{x:1309,y:955,t:1528143538244};\\\", \\\"{x:1311,y:956,t:1528143538261};\\\", \\\"{x:1312,y:958,t:1528143538279};\\\", \\\"{x:1314,y:960,t:1528143538386};\\\", \\\"{x:1314,y:961,t:1528143538395};\\\", \\\"{x:1316,y:962,t:1528143538410};\\\", \\\"{x:1316,y:963,t:1528143538427};\\\", \\\"{x:1317,y:963,t:1528143538445};\\\", \\\"{x:1319,y:967,t:1528143538461};\\\", \\\"{x:1319,y:969,t:1528143538489};\\\", \\\"{x:1320,y:970,t:1528143538497};\\\", \\\"{x:1319,y:971,t:1528143539025};\\\", \\\"{x:1317,y:971,t:1528143539041};\\\", \\\"{x:1316,y:971,t:1528143539056};\\\", \\\"{x:1314,y:971,t:1528143539097};\\\", \\\"{x:1314,y:970,t:1528143539297};\\\", \\\"{x:1314,y:969,t:1528143539313};\\\", \\\"{x:1315,y:969,t:1528143539329};\\\", \\\"{x:1315,y:968,t:1528143541698};\\\", \\\"{x:1314,y:967,t:1528143541714};\\\", \\\"{x:1312,y:966,t:1528143541745};\\\", \\\"{x:1313,y:966,t:1528143542130};\\\", \\\"{x:1316,y:966,t:1528143542146};\\\", \\\"{x:1320,y:966,t:1528143542164};\\\", \\\"{x:1327,y:966,t:1528143542181};\\\", \\\"{x:1328,y:967,t:1528143542197};\\\", \\\"{x:1329,y:967,t:1528143542214};\\\", \\\"{x:1328,y:967,t:1528143542305};\\\", \\\"{x:1327,y:967,t:1528143542354};\\\", \\\"{x:1325,y:967,t:1528143542377};\\\", \\\"{x:1324,y:967,t:1528143542393};\\\", \\\"{x:1322,y:967,t:1528143542425};\\\", \\\"{x:1321,y:967,t:1528143542433};\\\", \\\"{x:1320,y:967,t:1528143542448};\\\", \\\"{x:1318,y:967,t:1528143542463};\\\", \\\"{x:1318,y:966,t:1528143542842};\\\", \\\"{x:1318,y:965,t:1528143542873};\\\", \\\"{x:1318,y:964,t:1528143542897};\\\", \\\"{x:1318,y:962,t:1528143542929};\\\", \\\"{x:1318,y:961,t:1528143542961};\\\", \\\"{x:1319,y:960,t:1528143542969};\\\", \\\"{x:1319,y:959,t:1528143542985};\\\", \\\"{x:1319,y:958,t:1528143543017};\\\", \\\"{x:1319,y:957,t:1528143543031};\\\", \\\"{x:1319,y:956,t:1528143543047};\\\", \\\"{x:1319,y:955,t:1528143543082};\\\", \\\"{x:1319,y:954,t:1528143543098};\\\", \\\"{x:1319,y:953,t:1528143543121};\\\", \\\"{x:1319,y:952,t:1528143543137};\\\", \\\"{x:1319,y:951,t:1528143543148};\\\", \\\"{x:1319,y:950,t:1528143543165};\\\", \\\"{x:1319,y:948,t:1528143543181};\\\", \\\"{x:1319,y:947,t:1528143543198};\\\", \\\"{x:1319,y:946,t:1528143543214};\\\", \\\"{x:1319,y:945,t:1528143543232};\\\", \\\"{x:1319,y:944,t:1528143543248};\\\", \\\"{x:1319,y:943,t:1528143543273};\\\", \\\"{x:1319,y:941,t:1528143543297};\\\", \\\"{x:1319,y:940,t:1528143543315};\\\", \\\"{x:1319,y:938,t:1528143543331};\\\", \\\"{x:1319,y:937,t:1528143543347};\\\", \\\"{x:1319,y:936,t:1528143543377};\\\", \\\"{x:1319,y:935,t:1528143543417};\\\", \\\"{x:1319,y:934,t:1528143543441};\\\", \\\"{x:1319,y:933,t:1528143543449};\\\", \\\"{x:1319,y:932,t:1528143543465};\\\", \\\"{x:1319,y:930,t:1528143543482};\\\", \\\"{x:1319,y:929,t:1528143543498};\\\", \\\"{x:1319,y:928,t:1528143543515};\\\", \\\"{x:1319,y:926,t:1528143543531};\\\", \\\"{x:1319,y:925,t:1528143543548};\\\", \\\"{x:1318,y:923,t:1528143543565};\\\", \\\"{x:1318,y:922,t:1528143543581};\\\", \\\"{x:1318,y:921,t:1528143543598};\\\", \\\"{x:1318,y:919,t:1528143543615};\\\", \\\"{x:1318,y:918,t:1528143543632};\\\", \\\"{x:1318,y:916,t:1528143543648};\\\", \\\"{x:1317,y:914,t:1528143543665};\\\", \\\"{x:1316,y:912,t:1528143543682};\\\", \\\"{x:1316,y:911,t:1528143543698};\\\", \\\"{x:1316,y:909,t:1528143543715};\\\", \\\"{x:1316,y:907,t:1528143543732};\\\", \\\"{x:1315,y:903,t:1528143543749};\\\", \\\"{x:1315,y:901,t:1528143543765};\\\", \\\"{x:1315,y:900,t:1528143543782};\\\", \\\"{x:1315,y:897,t:1528143543799};\\\", \\\"{x:1314,y:895,t:1528143543815};\\\", \\\"{x:1314,y:893,t:1528143543832};\\\", \\\"{x:1313,y:890,t:1528143543849};\\\", \\\"{x:1313,y:884,t:1528143543865};\\\", \\\"{x:1312,y:881,t:1528143543882};\\\", \\\"{x:1312,y:876,t:1528143543898};\\\", \\\"{x:1312,y:872,t:1528143543915};\\\", \\\"{x:1312,y:866,t:1528143543932};\\\", \\\"{x:1312,y:861,t:1528143543948};\\\", \\\"{x:1311,y:855,t:1528143543965};\\\", \\\"{x:1311,y:849,t:1528143543982};\\\", \\\"{x:1311,y:845,t:1528143543999};\\\", \\\"{x:1309,y:839,t:1528143544014};\\\", \\\"{x:1309,y:835,t:1528143544032};\\\", \\\"{x:1308,y:828,t:1528143544049};\\\", \\\"{x:1307,y:821,t:1528143544065};\\\", \\\"{x:1306,y:815,t:1528143544082};\\\", \\\"{x:1305,y:811,t:1528143544098};\\\", \\\"{x:1305,y:806,t:1528143544116};\\\", \\\"{x:1304,y:802,t:1528143544132};\\\", \\\"{x:1304,y:798,t:1528143544149};\\\", \\\"{x:1304,y:794,t:1528143544166};\\\", \\\"{x:1304,y:789,t:1528143544182};\\\", \\\"{x:1304,y:783,t:1528143544199};\\\", \\\"{x:1304,y:778,t:1528143544216};\\\", \\\"{x:1304,y:775,t:1528143544231};\\\", \\\"{x:1304,y:771,t:1528143544249};\\\", \\\"{x:1304,y:768,t:1528143544265};\\\", \\\"{x:1304,y:765,t:1528143544282};\\\", \\\"{x:1304,y:762,t:1528143544299};\\\", \\\"{x:1303,y:759,t:1528143544316};\\\", \\\"{x:1303,y:755,t:1528143544332};\\\", \\\"{x:1303,y:753,t:1528143544349};\\\", \\\"{x:1303,y:749,t:1528143544366};\\\", \\\"{x:1303,y:745,t:1528143544382};\\\", \\\"{x:1303,y:739,t:1528143544399};\\\", \\\"{x:1303,y:733,t:1528143544415};\\\", \\\"{x:1303,y:729,t:1528143544432};\\\", \\\"{x:1303,y:723,t:1528143544449};\\\", \\\"{x:1303,y:722,t:1528143544465};\\\", \\\"{x:1303,y:718,t:1528143544482};\\\", \\\"{x:1303,y:716,t:1528143544499};\\\", \\\"{x:1303,y:714,t:1528143544516};\\\", \\\"{x:1303,y:711,t:1528143544533};\\\", \\\"{x:1303,y:708,t:1528143544549};\\\", \\\"{x:1303,y:703,t:1528143544566};\\\", \\\"{x:1303,y:699,t:1528143544583};\\\", \\\"{x:1303,y:695,t:1528143544598};\\\", \\\"{x:1303,y:692,t:1528143544616};\\\", \\\"{x:1304,y:687,t:1528143544633};\\\", \\\"{x:1305,y:685,t:1528143544649};\\\", \\\"{x:1305,y:682,t:1528143544666};\\\", \\\"{x:1307,y:680,t:1528143544683};\\\", \\\"{x:1307,y:677,t:1528143544699};\\\", \\\"{x:1308,y:673,t:1528143544716};\\\", \\\"{x:1309,y:670,t:1528143544732};\\\", \\\"{x:1310,y:668,t:1528143544748};\\\", \\\"{x:1311,y:664,t:1528143544766};\\\", \\\"{x:1312,y:663,t:1528143544783};\\\", \\\"{x:1313,y:659,t:1528143544799};\\\", \\\"{x:1314,y:657,t:1528143544816};\\\", \\\"{x:1314,y:656,t:1528143544833};\\\", \\\"{x:1315,y:654,t:1528143544849};\\\", \\\"{x:1315,y:653,t:1528143544866};\\\", \\\"{x:1315,y:651,t:1528143544882};\\\", \\\"{x:1317,y:649,t:1528143544899};\\\", \\\"{x:1317,y:647,t:1528143544916};\\\", \\\"{x:1317,y:644,t:1528143544933};\\\", \\\"{x:1319,y:641,t:1528143544950};\\\", \\\"{x:1320,y:639,t:1528143544965};\\\", \\\"{x:1321,y:635,t:1528143544982};\\\", \\\"{x:1321,y:634,t:1528143544999};\\\", \\\"{x:1321,y:633,t:1528143545113};\\\", \\\"{x:1321,y:632,t:1528143545145};\\\", \\\"{x:1321,y:631,t:1528143545153};\\\", \\\"{x:1319,y:630,t:1528143545177};\\\", \\\"{x:1318,y:630,t:1528143545209};\\\", \\\"{x:1317,y:630,t:1528143545241};\\\", \\\"{x:1315,y:630,t:1528143545265};\\\", \\\"{x:1311,y:630,t:1528143545282};\\\", \\\"{x:1297,y:630,t:1528143545301};\\\", \\\"{x:1278,y:629,t:1528143545316};\\\", \\\"{x:1248,y:629,t:1528143545333};\\\", \\\"{x:1206,y:629,t:1528143545350};\\\", \\\"{x:1145,y:633,t:1528143545366};\\\", \\\"{x:1097,y:642,t:1528143545383};\\\", \\\"{x:1051,y:653,t:1528143545400};\\\", \\\"{x:1004,y:668,t:1528143545417};\\\", \\\"{x:982,y:674,t:1528143545432};\\\", \\\"{x:969,y:676,t:1528143545450};\\\", \\\"{x:957,y:678,t:1528143545466};\\\", \\\"{x:942,y:678,t:1528143545483};\\\", \\\"{x:921,y:678,t:1528143545499};\\\", \\\"{x:893,y:677,t:1528143545516};\\\", \\\"{x:863,y:670,t:1528143545533};\\\", \\\"{x:829,y:659,t:1528143545550};\\\", \\\"{x:783,y:644,t:1528143545566};\\\", \\\"{x:741,y:631,t:1528143545583};\\\", \\\"{x:700,y:623,t:1528143545602};\\\", \\\"{x:643,y:615,t:1528143545618};\\\", \\\"{x:588,y:607,t:1528143545650};\\\", \\\"{x:581,y:607,t:1528143545666};\\\", \\\"{x:581,y:606,t:1528143545744};\\\", \\\"{x:588,y:603,t:1528143545752};\\\", \\\"{x:601,y:598,t:1528143545766};\\\", \\\"{x:632,y:594,t:1528143545783};\\\", \\\"{x:690,y:594,t:1528143545800};\\\", \\\"{x:732,y:594,t:1528143545816};\\\", \\\"{x:768,y:594,t:1528143545833};\\\", \\\"{x:786,y:594,t:1528143545849};\\\", \\\"{x:792,y:594,t:1528143545866};\\\", \\\"{x:795,y:593,t:1528143545883};\\\", \\\"{x:797,y:592,t:1528143545899};\\\", \\\"{x:805,y:589,t:1528143545916};\\\", \\\"{x:815,y:586,t:1528143545934};\\\", \\\"{x:822,y:585,t:1528143545949};\\\", \\\"{x:826,y:581,t:1528143545966};\\\", \\\"{x:827,y:581,t:1528143545984};\\\", \\\"{x:827,y:580,t:1528143546000};\\\", \\\"{x:829,y:579,t:1528143546017};\\\", \\\"{x:833,y:572,t:1528143546033};\\\", \\\"{x:839,y:560,t:1528143546051};\\\", \\\"{x:845,y:549,t:1528143546068};\\\", \\\"{x:849,y:541,t:1528143546083};\\\", \\\"{x:850,y:536,t:1528143546100};\\\", \\\"{x:851,y:532,t:1528143546116};\\\", \\\"{x:852,y:529,t:1528143546134};\\\", \\\"{x:853,y:529,t:1528143546150};\\\", \\\"{x:853,y:528,t:1528143546184};\\\", \\\"{x:852,y:527,t:1528143546200};\\\", \\\"{x:851,y:527,t:1528143546305};\\\", \\\"{x:849,y:527,t:1528143546318};\\\", \\\"{x:845,y:527,t:1528143546334};\\\", \\\"{x:840,y:530,t:1528143546351};\\\", \\\"{x:839,y:530,t:1528143546367};\\\", \\\"{x:837,y:531,t:1528143546384};\\\", \\\"{x:835,y:531,t:1528143546441};\\\", \\\"{x:833,y:533,t:1528143546457};\\\", \\\"{x:833,y:534,t:1528143546467};\\\", \\\"{x:832,y:534,t:1528143546484};\\\", \\\"{x:831,y:534,t:1528143546728};\\\", \\\"{x:823,y:538,t:1528143546737};\\\", \\\"{x:811,y:546,t:1528143546750};\\\", \\\"{x:789,y:567,t:1528143546768};\\\", \\\"{x:748,y:602,t:1528143546784};\\\", \\\"{x:713,y:631,t:1528143546800};\\\", \\\"{x:682,y:661,t:1528143546818};\\\", \\\"{x:648,y:694,t:1528143546835};\\\", \\\"{x:626,y:717,t:1528143546851};\\\", \\\"{x:619,y:724,t:1528143546867};\\\", \\\"{x:610,y:731,t:1528143546884};\\\", \\\"{x:602,y:737,t:1528143546900};\\\", \\\"{x:595,y:742,t:1528143546917};\\\", \\\"{x:588,y:747,t:1528143546934};\\\", \\\"{x:584,y:749,t:1528143546950};\\\", \\\"{x:583,y:750,t:1528143546968};\\\", \\\"{x:581,y:751,t:1528143546984};\\\", \\\"{x:580,y:751,t:1528143547001};\\\", \\\"{x:577,y:753,t:1528143547017};\\\", \\\"{x:576,y:751,t:1528143547081};\\\", \\\"{x:574,y:748,t:1528143547089};\\\", \\\"{x:572,y:747,t:1528143547101};\\\", \\\"{x:570,y:744,t:1528143547117};\\\", \\\"{x:565,y:742,t:1528143547135};\\\", \\\"{x:562,y:740,t:1528143547153};\\\", \\\"{x:554,y:737,t:1528143547167};\\\", \\\"{x:536,y:732,t:1528143547184};\\\", \\\"{x:527,y:730,t:1528143547201};\\\", \\\"{x:523,y:729,t:1528143547217};\\\", \\\"{x:520,y:729,t:1528143547234};\\\", \\\"{x:520,y:727,t:1528143553473};\\\", \\\"{x:552,y:727,t:1528143553490};\\\", \\\"{x:609,y:739,t:1528143553507};\\\", \\\"{x:667,y:754,t:1528143553522};\\\", \\\"{x:735,y:765,t:1528143553539};\\\", \\\"{x:812,y:774,t:1528143553556};\\\", \\\"{x:892,y:781,t:1528143553572};\\\", \\\"{x:968,y:784,t:1528143553589};\\\", \\\"{x:1029,y:784,t:1528143553605};\\\", \\\"{x:1076,y:784,t:1528143553622};\\\", \\\"{x:1121,y:780,t:1528143553640};\\\", \\\"{x:1161,y:774,t:1528143553656};\\\", \\\"{x:1181,y:770,t:1528143553673};\\\", \\\"{x:1186,y:768,t:1528143553690};\\\", \\\"{x:1188,y:768,t:1528143553745};\\\" ] }, { \\\"rt\\\": 42400, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 278763, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"TTCWS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-09 AM-10 AM-09 AM-08 AM-08 AM-09 AM-09 AM-10 AM-10 AM-11 AM-11 AM-08 AM-08 AM-09 AM-09 AM-09 AM-0-08 AM-09 AM-09 AM-10 AM-10 AM-11 AM-12 PM-12 PM-01 PM-01 PM-02 PM-I -B -M -01 PM-12 PM-10 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1182,y:773,t:1528143557924};\\\", \\\"{x:1174,y:784,t:1528143557932};\\\", \\\"{x:1166,y:796,t:1528143557946};\\\", \\\"{x:1149,y:826,t:1528143557962};\\\", \\\"{x:1144,y:835,t:1528143557979};\\\", \\\"{x:1142,y:838,t:1528143557996};\\\", \\\"{x:1142,y:839,t:1528143558013};\\\", \\\"{x:1142,y:840,t:1528143558030};\\\", \\\"{x:1142,y:842,t:1528143558045};\\\", \\\"{x:1140,y:844,t:1528143558063};\\\", \\\"{x:1138,y:848,t:1528143558080};\\\", \\\"{x:1137,y:853,t:1528143558096};\\\", \\\"{x:1135,y:857,t:1528143558113};\\\", \\\"{x:1133,y:862,t:1528143558130};\\\", \\\"{x:1133,y:864,t:1528143558146};\\\", \\\"{x:1131,y:869,t:1528143558163};\\\", \\\"{x:1130,y:875,t:1528143558180};\\\", \\\"{x:1128,y:880,t:1528143558197};\\\", \\\"{x:1128,y:888,t:1528143558213};\\\", \\\"{x:1128,y:896,t:1528143558229};\\\", \\\"{x:1128,y:903,t:1528143558246};\\\", \\\"{x:1128,y:913,t:1528143558263};\\\", \\\"{x:1129,y:922,t:1528143558280};\\\", \\\"{x:1132,y:931,t:1528143558296};\\\", \\\"{x:1137,y:939,t:1528143558312};\\\", \\\"{x:1142,y:946,t:1528143558330};\\\", \\\"{x:1148,y:956,t:1528143558346};\\\", \\\"{x:1152,y:962,t:1528143558363};\\\", \\\"{x:1157,y:969,t:1528143558380};\\\", \\\"{x:1160,y:972,t:1528143558397};\\\", \\\"{x:1163,y:975,t:1528143558413};\\\", \\\"{x:1166,y:977,t:1528143558430};\\\", \\\"{x:1170,y:979,t:1528143558448};\\\", \\\"{x:1177,y:982,t:1528143558463};\\\", \\\"{x:1181,y:984,t:1528143558480};\\\", \\\"{x:1185,y:984,t:1528143558497};\\\", \\\"{x:1185,y:985,t:1528143558515};\\\", \\\"{x:1187,y:985,t:1528143558643};\\\", \\\"{x:1189,y:983,t:1528143558651};\\\", \\\"{x:1190,y:978,t:1528143558663};\\\", \\\"{x:1193,y:974,t:1528143558680};\\\", \\\"{x:1194,y:973,t:1528143558696};\\\", \\\"{x:1195,y:970,t:1528143558713};\\\", \\\"{x:1196,y:969,t:1528143558729};\\\", \\\"{x:1196,y:968,t:1528143558747};\\\", \\\"{x:1195,y:967,t:1528143559092};\\\", \\\"{x:1188,y:967,t:1528143559100};\\\", \\\"{x:1184,y:968,t:1528143559114};\\\", \\\"{x:1173,y:969,t:1528143559131};\\\", \\\"{x:1162,y:972,t:1528143559148};\\\", \\\"{x:1150,y:973,t:1528143559163};\\\", \\\"{x:1144,y:974,t:1528143559180};\\\", \\\"{x:1142,y:975,t:1528143559197};\\\", \\\"{x:1140,y:975,t:1528143559214};\\\", \\\"{x:1138,y:975,t:1528143559231};\\\", \\\"{x:1132,y:976,t:1528143559247};\\\", \\\"{x:1124,y:977,t:1528143559265};\\\", \\\"{x:1115,y:977,t:1528143559281};\\\", \\\"{x:1111,y:977,t:1528143559297};\\\", \\\"{x:1109,y:977,t:1528143559314};\\\", \\\"{x:1107,y:980,t:1528143560996};\\\", \\\"{x:1104,y:985,t:1528143561004};\\\", \\\"{x:1102,y:989,t:1528143561015};\\\", \\\"{x:1099,y:995,t:1528143561032};\\\", \\\"{x:1096,y:1000,t:1528143561049};\\\", \\\"{x:1094,y:1001,t:1528143561065};\\\", \\\"{x:1093,y:1001,t:1528143561082};\\\", \\\"{x:1092,y:1002,t:1528143561100};\\\", \\\"{x:1091,y:1003,t:1528143561116};\\\", \\\"{x:1089,y:1003,t:1528143561132};\\\", \\\"{x:1086,y:1003,t:1528143561149};\\\", \\\"{x:1083,y:1002,t:1528143561166};\\\", \\\"{x:1081,y:1002,t:1528143561183};\\\", \\\"{x:1078,y:999,t:1528143561199};\\\", \\\"{x:1075,y:996,t:1528143561216};\\\", \\\"{x:1072,y:991,t:1528143561232};\\\", \\\"{x:1071,y:990,t:1528143561249};\\\", \\\"{x:1068,y:985,t:1528143561266};\\\", \\\"{x:1068,y:984,t:1528143561282};\\\", \\\"{x:1068,y:983,t:1528143561299};\\\", \\\"{x:1068,y:982,t:1528143561364};\\\", \\\"{x:1068,y:980,t:1528143561371};\\\", \\\"{x:1068,y:979,t:1528143561382};\\\", \\\"{x:1068,y:978,t:1528143561399};\\\", \\\"{x:1068,y:977,t:1528143561416};\\\", \\\"{x:1068,y:976,t:1528143561432};\\\", \\\"{x:1068,y:974,t:1528143561450};\\\", \\\"{x:1069,y:972,t:1528143561466};\\\", \\\"{x:1070,y:970,t:1528143561482};\\\", \\\"{x:1071,y:969,t:1528143561499};\\\", \\\"{x:1072,y:968,t:1528143561981};\\\", \\\"{x:1075,y:971,t:1528143561988};\\\", \\\"{x:1077,y:975,t:1528143561999};\\\", \\\"{x:1085,y:983,t:1528143562016};\\\", \\\"{x:1093,y:993,t:1528143562034};\\\", \\\"{x:1104,y:1001,t:1528143562050};\\\", \\\"{x:1111,y:1006,t:1528143562067};\\\", \\\"{x:1118,y:1009,t:1528143562083};\\\", \\\"{x:1122,y:1011,t:1528143562099};\\\", \\\"{x:1124,y:1011,t:1528143562116};\\\", \\\"{x:1128,y:1011,t:1528143562133};\\\", \\\"{x:1135,y:1011,t:1528143562149};\\\", \\\"{x:1142,y:1011,t:1528143562167};\\\", \\\"{x:1148,y:1010,t:1528143562183};\\\", \\\"{x:1153,y:1008,t:1528143562200};\\\", \\\"{x:1156,y:1006,t:1528143562217};\\\", \\\"{x:1159,y:1004,t:1528143562233};\\\", \\\"{x:1162,y:1002,t:1528143562249};\\\", \\\"{x:1165,y:999,t:1528143562266};\\\", \\\"{x:1167,y:994,t:1528143562283};\\\", \\\"{x:1167,y:991,t:1528143562300};\\\", \\\"{x:1167,y:990,t:1528143562316};\\\", \\\"{x:1167,y:988,t:1528143562334};\\\", \\\"{x:1167,y:987,t:1528143562351};\\\", \\\"{x:1167,y:984,t:1528143562366};\\\", \\\"{x:1167,y:982,t:1528143562383};\\\", \\\"{x:1166,y:981,t:1528143562401};\\\", \\\"{x:1165,y:981,t:1528143562417};\\\", \\\"{x:1165,y:980,t:1528143562433};\\\", \\\"{x:1164,y:977,t:1528143562450};\\\", \\\"{x:1162,y:975,t:1528143562466};\\\", \\\"{x:1159,y:972,t:1528143562483};\\\", \\\"{x:1158,y:971,t:1528143562500};\\\", \\\"{x:1158,y:970,t:1528143562517};\\\", \\\"{x:1156,y:969,t:1528143562533};\\\", \\\"{x:1156,y:968,t:1528143562643};\\\", \\\"{x:1156,y:967,t:1528143562659};\\\", \\\"{x:1155,y:967,t:1528143562675};\\\", \\\"{x:1155,y:965,t:1528143563348};\\\", \\\"{x:1155,y:962,t:1528143563355};\\\", \\\"{x:1155,y:960,t:1528143563368};\\\", \\\"{x:1155,y:957,t:1528143563385};\\\", \\\"{x:1155,y:953,t:1528143563400};\\\", \\\"{x:1155,y:952,t:1528143563417};\\\", \\\"{x:1155,y:951,t:1528143563580};\\\", \\\"{x:1153,y:951,t:1528143563611};\\\", \\\"{x:1153,y:952,t:1528143563636};\\\", \\\"{x:1151,y:952,t:1528143563660};\\\", \\\"{x:1150,y:954,t:1528143563698};\\\", \\\"{x:1150,y:955,t:1528143563707};\\\", \\\"{x:1150,y:956,t:1528143563717};\\\", \\\"{x:1150,y:957,t:1528143563733};\\\", \\\"{x:1150,y:960,t:1528143563751};\\\", \\\"{x:1150,y:962,t:1528143563767};\\\", \\\"{x:1150,y:964,t:1528143563784};\\\", \\\"{x:1150,y:968,t:1528143563801};\\\", \\\"{x:1150,y:971,t:1528143563817};\\\", \\\"{x:1150,y:975,t:1528143563834};\\\", \\\"{x:1151,y:979,t:1528143563850};\\\", \\\"{x:1152,y:981,t:1528143563867};\\\", \\\"{x:1153,y:984,t:1528143563884};\\\", \\\"{x:1155,y:986,t:1528143563902};\\\", \\\"{x:1155,y:988,t:1528143563917};\\\", \\\"{x:1156,y:991,t:1528143563934};\\\", \\\"{x:1158,y:992,t:1528143563952};\\\", \\\"{x:1158,y:994,t:1528143563967};\\\", \\\"{x:1160,y:996,t:1528143563984};\\\", \\\"{x:1161,y:997,t:1528143564001};\\\", \\\"{x:1164,y:999,t:1528143564017};\\\", \\\"{x:1170,y:1002,t:1528143564034};\\\", \\\"{x:1186,y:1011,t:1528143564051};\\\", \\\"{x:1202,y:1016,t:1528143564067};\\\", \\\"{x:1216,y:1019,t:1528143564084};\\\", \\\"{x:1227,y:1022,t:1528143564101};\\\", \\\"{x:1231,y:1023,t:1528143564118};\\\", \\\"{x:1234,y:1023,t:1528143564135};\\\", \\\"{x:1236,y:1023,t:1528143564151};\\\", \\\"{x:1237,y:1023,t:1528143564168};\\\", \\\"{x:1238,y:1022,t:1528143564185};\\\", \\\"{x:1241,y:1020,t:1528143564202};\\\", \\\"{x:1243,y:1015,t:1528143564219};\\\", \\\"{x:1244,y:1013,t:1528143564235};\\\", \\\"{x:1244,y:1008,t:1528143564252};\\\", \\\"{x:1244,y:1003,t:1528143564268};\\\", \\\"{x:1242,y:999,t:1528143564283};\\\", \\\"{x:1240,y:997,t:1528143564301};\\\", \\\"{x:1239,y:993,t:1528143564318};\\\", \\\"{x:1236,y:989,t:1528143564334};\\\", \\\"{x:1235,y:986,t:1528143564351};\\\", \\\"{x:1234,y:983,t:1528143564368};\\\", \\\"{x:1232,y:980,t:1528143564384};\\\", \\\"{x:1232,y:979,t:1528143564400};\\\", \\\"{x:1231,y:977,t:1528143564418};\\\", \\\"{x:1230,y:977,t:1528143564434};\\\", \\\"{x:1229,y:975,t:1528143564451};\\\", \\\"{x:1228,y:974,t:1528143564699};\\\", \\\"{x:1227,y:974,t:1528143564707};\\\", \\\"{x:1225,y:974,t:1528143564718};\\\", \\\"{x:1219,y:974,t:1528143564735};\\\", \\\"{x:1211,y:974,t:1528143564752};\\\", \\\"{x:1201,y:977,t:1528143564769};\\\", \\\"{x:1193,y:978,t:1528143564786};\\\", \\\"{x:1192,y:978,t:1528143564802};\\\", \\\"{x:1191,y:978,t:1528143564818};\\\", \\\"{x:1192,y:980,t:1528143564835};\\\", \\\"{x:1198,y:982,t:1528143564852};\\\", \\\"{x:1207,y:986,t:1528143564869};\\\", \\\"{x:1217,y:987,t:1528143564885};\\\", \\\"{x:1231,y:989,t:1528143564902};\\\", \\\"{x:1240,y:991,t:1528143564918};\\\", \\\"{x:1244,y:992,t:1528143564935};\\\", \\\"{x:1246,y:992,t:1528143564952};\\\", \\\"{x:1250,y:992,t:1528143565116};\\\", \\\"{x:1256,y:991,t:1528143565123};\\\", \\\"{x:1259,y:989,t:1528143565136};\\\", \\\"{x:1271,y:984,t:1528143565152};\\\", \\\"{x:1279,y:980,t:1528143565169};\\\", \\\"{x:1287,y:978,t:1528143565185};\\\", \\\"{x:1288,y:977,t:1528143565412};\\\", \\\"{x:1288,y:976,t:1528143565427};\\\", \\\"{x:1287,y:976,t:1528143565436};\\\", \\\"{x:1286,y:975,t:1528143565452};\\\", \\\"{x:1286,y:974,t:1528143565499};\\\", \\\"{x:1286,y:972,t:1528143565515};\\\", \\\"{x:1286,y:969,t:1528143565523};\\\", \\\"{x:1286,y:966,t:1528143565536};\\\", \\\"{x:1286,y:964,t:1528143565553};\\\", \\\"{x:1286,y:963,t:1528143565570};\\\", \\\"{x:1286,y:962,t:1528143565596};\\\", \\\"{x:1286,y:961,t:1528143565620};\\\", \\\"{x:1285,y:960,t:1528143565700};\\\", \\\"{x:1284,y:960,t:1528143565796};\\\", \\\"{x:1282,y:960,t:1528143565803};\\\", \\\"{x:1281,y:960,t:1528143565819};\\\", \\\"{x:1279,y:960,t:1528143565836};\\\", \\\"{x:1278,y:960,t:1528143566140};\\\", \\\"{x:1277,y:960,t:1528143566155};\\\", \\\"{x:1276,y:960,t:1528143566169};\\\", \\\"{x:1275,y:961,t:1528143566187};\\\", \\\"{x:1274,y:961,t:1528143566203};\\\", \\\"{x:1273,y:962,t:1528143567596};\\\", \\\"{x:1272,y:965,t:1528143567804};\\\", \\\"{x:1269,y:973,t:1528143567821};\\\", \\\"{x:1265,y:980,t:1528143567838};\\\", \\\"{x:1259,y:983,t:1528143567855};\\\", \\\"{x:1254,y:984,t:1528143567871};\\\", \\\"{x:1241,y:986,t:1528143567888};\\\", \\\"{x:1223,y:989,t:1528143567905};\\\", \\\"{x:1204,y:993,t:1528143567920};\\\", \\\"{x:1186,y:997,t:1528143567937};\\\", \\\"{x:1172,y:999,t:1528143567955};\\\", \\\"{x:1154,y:1001,t:1528143567971};\\\", \\\"{x:1134,y:1001,t:1528143567987};\\\", \\\"{x:1127,y:1001,t:1528143568005};\\\", \\\"{x:1120,y:999,t:1528143568020};\\\", \\\"{x:1113,y:999,t:1528143568038};\\\", \\\"{x:1108,y:997,t:1528143568055};\\\", \\\"{x:1107,y:996,t:1528143568071};\\\", \\\"{x:1106,y:996,t:1528143568087};\\\", \\\"{x:1106,y:993,t:1528143568105};\\\", \\\"{x:1106,y:992,t:1528143568122};\\\", \\\"{x:1106,y:990,t:1528143568138};\\\", \\\"{x:1106,y:989,t:1528143568155};\\\", \\\"{x:1106,y:987,t:1528143568171};\\\", \\\"{x:1106,y:986,t:1528143568187};\\\", \\\"{x:1106,y:983,t:1528143568205};\\\", \\\"{x:1106,y:981,t:1528143568222};\\\", \\\"{x:1105,y:978,t:1528143568237};\\\", \\\"{x:1101,y:975,t:1528143568256};\\\", \\\"{x:1099,y:975,t:1528143568272};\\\", \\\"{x:1095,y:973,t:1528143568288};\\\", \\\"{x:1092,y:971,t:1528143568305};\\\", \\\"{x:1087,y:970,t:1528143568321};\\\", \\\"{x:1083,y:968,t:1528143568338};\\\", \\\"{x:1081,y:967,t:1528143568355};\\\", \\\"{x:1080,y:966,t:1528143568372};\\\", \\\"{x:1079,y:966,t:1528143568412};\\\", \\\"{x:1078,y:966,t:1528143568563};\\\", \\\"{x:1078,y:968,t:1528143568571};\\\", \\\"{x:1078,y:973,t:1528143568589};\\\", \\\"{x:1080,y:977,t:1528143568605};\\\", \\\"{x:1083,y:982,t:1528143568622};\\\", \\\"{x:1087,y:983,t:1528143568639};\\\", \\\"{x:1093,y:985,t:1528143568655};\\\", \\\"{x:1101,y:987,t:1528143568672};\\\", \\\"{x:1109,y:988,t:1528143568689};\\\", \\\"{x:1115,y:988,t:1528143568705};\\\", \\\"{x:1121,y:988,t:1528143568722};\\\", \\\"{x:1125,y:988,t:1528143568739};\\\", \\\"{x:1127,y:985,t:1528143568755};\\\", \\\"{x:1128,y:981,t:1528143568772};\\\", \\\"{x:1128,y:978,t:1528143568789};\\\", \\\"{x:1128,y:975,t:1528143568805};\\\", \\\"{x:1128,y:972,t:1528143568821};\\\", \\\"{x:1128,y:968,t:1528143568839};\\\", \\\"{x:1128,y:965,t:1528143568854};\\\", \\\"{x:1127,y:962,t:1528143568871};\\\", \\\"{x:1125,y:959,t:1528143568888};\\\", \\\"{x:1125,y:958,t:1528143568905};\\\", \\\"{x:1125,y:957,t:1528143568922};\\\", \\\"{x:1124,y:956,t:1528143568964};\\\", \\\"{x:1123,y:956,t:1528143568996};\\\", \\\"{x:1121,y:956,t:1528143569006};\\\", \\\"{x:1118,y:956,t:1528143569022};\\\", \\\"{x:1117,y:957,t:1528143569039};\\\", \\\"{x:1117,y:959,t:1528143569124};\\\", \\\"{x:1117,y:962,t:1528143569139};\\\", \\\"{x:1117,y:968,t:1528143569155};\\\", \\\"{x:1118,y:975,t:1528143569172};\\\", \\\"{x:1124,y:981,t:1528143569189};\\\", \\\"{x:1130,y:986,t:1528143569206};\\\", \\\"{x:1136,y:990,t:1528143569221};\\\", \\\"{x:1139,y:991,t:1528143569239};\\\", \\\"{x:1143,y:994,t:1528143569256};\\\", \\\"{x:1147,y:994,t:1528143569272};\\\", \\\"{x:1150,y:994,t:1528143569289};\\\", \\\"{x:1154,y:994,t:1528143569305};\\\", \\\"{x:1157,y:994,t:1528143569321};\\\", \\\"{x:1162,y:994,t:1528143569339};\\\", \\\"{x:1166,y:991,t:1528143569356};\\\", \\\"{x:1168,y:989,t:1528143569372};\\\", \\\"{x:1169,y:985,t:1528143569388};\\\", \\\"{x:1169,y:982,t:1528143569406};\\\", \\\"{x:1169,y:980,t:1528143569422};\\\", \\\"{x:1168,y:975,t:1528143569439};\\\", \\\"{x:1167,y:974,t:1528143569457};\\\", \\\"{x:1166,y:973,t:1528143569473};\\\", \\\"{x:1164,y:970,t:1528143569489};\\\", \\\"{x:1163,y:969,t:1528143569507};\\\", \\\"{x:1162,y:968,t:1528143569523};\\\", \\\"{x:1161,y:966,t:1528143569539};\\\", \\\"{x:1159,y:966,t:1528143569556};\\\", \\\"{x:1158,y:965,t:1528143569652};\\\", \\\"{x:1156,y:965,t:1528143570051};\\\", \\\"{x:1153,y:965,t:1528143570060};\\\", \\\"{x:1153,y:968,t:1528143570073};\\\", \\\"{x:1149,y:974,t:1528143570090};\\\", \\\"{x:1145,y:981,t:1528143570106};\\\", \\\"{x:1143,y:986,t:1528143570123};\\\", \\\"{x:1138,y:996,t:1528143570140};\\\", \\\"{x:1137,y:997,t:1528143570156};\\\", \\\"{x:1135,y:1000,t:1528143570173};\\\", \\\"{x:1135,y:1001,t:1528143570190};\\\", \\\"{x:1133,y:1002,t:1528143570206};\\\", \\\"{x:1131,y:1002,t:1528143570223};\\\", \\\"{x:1130,y:1003,t:1528143570240};\\\", \\\"{x:1129,y:1003,t:1528143570256};\\\", \\\"{x:1126,y:1003,t:1528143570273};\\\", \\\"{x:1122,y:1003,t:1528143570289};\\\", \\\"{x:1114,y:1003,t:1528143570306};\\\", \\\"{x:1102,y:1003,t:1528143570323};\\\", \\\"{x:1081,y:1000,t:1528143570340};\\\", \\\"{x:1070,y:998,t:1528143570357};\\\", \\\"{x:1062,y:997,t:1528143570372};\\\", \\\"{x:1059,y:996,t:1528143570390};\\\", \\\"{x:1058,y:996,t:1528143570407};\\\", \\\"{x:1056,y:996,t:1528143570468};\\\", \\\"{x:1055,y:994,t:1528143570475};\\\", \\\"{x:1054,y:993,t:1528143570490};\\\", \\\"{x:1053,y:987,t:1528143570507};\\\", \\\"{x:1053,y:981,t:1528143570523};\\\", \\\"{x:1053,y:974,t:1528143570540};\\\", \\\"{x:1053,y:973,t:1528143570556};\\\", \\\"{x:1054,y:970,t:1528143570573};\\\", \\\"{x:1054,y:969,t:1528143570590};\\\", \\\"{x:1056,y:968,t:1528143570607};\\\", \\\"{x:1059,y:964,t:1528143570622};\\\", \\\"{x:1061,y:963,t:1528143570639};\\\", \\\"{x:1064,y:961,t:1528143570658};\\\", \\\"{x:1066,y:960,t:1528143570673};\\\", \\\"{x:1067,y:960,t:1528143570732};\\\", \\\"{x:1068,y:960,t:1528143570820};\\\", \\\"{x:1069,y:960,t:1528143570828};\\\", \\\"{x:1070,y:960,t:1528143570839};\\\", \\\"{x:1072,y:962,t:1528143570858};\\\", \\\"{x:1072,y:963,t:1528143570874};\\\", \\\"{x:1072,y:964,t:1528143570891};\\\", \\\"{x:1072,y:965,t:1528143570907};\\\", \\\"{x:1073,y:965,t:1528143571011};\\\", \\\"{x:1075,y:965,t:1528143571024};\\\", \\\"{x:1077,y:964,t:1528143571040};\\\", \\\"{x:1078,y:963,t:1528143571058};\\\", \\\"{x:1080,y:962,t:1528143571074};\\\", \\\"{x:1081,y:961,t:1528143571091};\\\", \\\"{x:1081,y:963,t:1528143571317};\\\", \\\"{x:1081,y:964,t:1528143571324};\\\", \\\"{x:1081,y:968,t:1528143571342};\\\", \\\"{x:1081,y:972,t:1528143571357};\\\", \\\"{x:1082,y:976,t:1528143571374};\\\", \\\"{x:1085,y:981,t:1528143571390};\\\", \\\"{x:1086,y:985,t:1528143571407};\\\", \\\"{x:1088,y:987,t:1528143571424};\\\", \\\"{x:1088,y:988,t:1528143571441};\\\", \\\"{x:1090,y:991,t:1528143571457};\\\", \\\"{x:1092,y:993,t:1528143571474};\\\", \\\"{x:1094,y:994,t:1528143571491};\\\", \\\"{x:1101,y:998,t:1528143571507};\\\", \\\"{x:1108,y:1000,t:1528143571524};\\\", \\\"{x:1113,y:1001,t:1528143571541};\\\", \\\"{x:1118,y:1002,t:1528143571557};\\\", \\\"{x:1119,y:1003,t:1528143571574};\\\", \\\"{x:1121,y:1003,t:1528143571596};\\\", \\\"{x:1122,y:1003,t:1528143571607};\\\", \\\"{x:1126,y:1001,t:1528143571624};\\\", \\\"{x:1128,y:999,t:1528143571641};\\\", \\\"{x:1132,y:998,t:1528143571658};\\\", \\\"{x:1133,y:997,t:1528143571674};\\\", \\\"{x:1134,y:996,t:1528143571691};\\\", \\\"{x:1136,y:994,t:1528143571707};\\\", \\\"{x:1140,y:990,t:1528143571724};\\\", \\\"{x:1143,y:989,t:1528143571740};\\\", \\\"{x:1146,y:987,t:1528143571758};\\\", \\\"{x:1147,y:986,t:1528143571774};\\\", \\\"{x:1148,y:985,t:1528143571791};\\\", \\\"{x:1149,y:985,t:1528143571808};\\\", \\\"{x:1149,y:984,t:1528143571824};\\\", \\\"{x:1150,y:983,t:1528143571841};\\\", \\\"{x:1151,y:981,t:1528143571858};\\\", \\\"{x:1151,y:979,t:1528143571874};\\\", \\\"{x:1153,y:977,t:1528143571891};\\\", \\\"{x:1153,y:976,t:1528143571907};\\\", \\\"{x:1154,y:976,t:1528143571924};\\\", \\\"{x:1154,y:974,t:1528143571941};\\\", \\\"{x:1154,y:973,t:1528143571978};\\\", \\\"{x:1154,y:971,t:1528143572010};\\\", \\\"{x:1154,y:970,t:1528143572188};\\\", \\\"{x:1154,y:968,t:1528143572252};\\\", \\\"{x:1154,y:967,t:1528143572259};\\\", \\\"{x:1153,y:966,t:1528143572274};\\\", \\\"{x:1153,y:965,t:1528143572291};\\\", \\\"{x:1152,y:964,t:1528143572314};\\\", \\\"{x:1152,y:963,t:1528143572371};\\\", \\\"{x:1152,y:964,t:1528143572660};\\\", \\\"{x:1152,y:967,t:1528143572675};\\\", \\\"{x:1152,y:976,t:1528143572692};\\\", \\\"{x:1155,y:985,t:1528143572709};\\\", \\\"{x:1158,y:988,t:1528143572725};\\\", \\\"{x:1161,y:993,t:1528143572742};\\\", \\\"{x:1162,y:994,t:1528143572758};\\\", \\\"{x:1165,y:997,t:1528143572775};\\\", \\\"{x:1169,y:1001,t:1528143572792};\\\", \\\"{x:1172,y:1004,t:1528143572808};\\\", \\\"{x:1178,y:1008,t:1528143572825};\\\", \\\"{x:1185,y:1011,t:1528143572842};\\\", \\\"{x:1192,y:1014,t:1528143572858};\\\", \\\"{x:1197,y:1017,t:1528143572875};\\\", \\\"{x:1200,y:1018,t:1528143572892};\\\", \\\"{x:1203,y:1018,t:1528143572907};\\\", \\\"{x:1205,y:1018,t:1528143572924};\\\", \\\"{x:1207,y:1018,t:1528143572941};\\\", \\\"{x:1212,y:1017,t:1528143572958};\\\", \\\"{x:1215,y:1014,t:1528143572974};\\\", \\\"{x:1217,y:1012,t:1528143572991};\\\", \\\"{x:1221,y:1007,t:1528143573009};\\\", \\\"{x:1222,y:1005,t:1528143573024};\\\", \\\"{x:1225,y:1001,t:1528143573041};\\\", \\\"{x:1225,y:999,t:1528143573058};\\\", \\\"{x:1226,y:994,t:1528143573075};\\\", \\\"{x:1226,y:993,t:1528143573091};\\\", \\\"{x:1228,y:990,t:1528143573108};\\\", \\\"{x:1228,y:988,t:1528143573124};\\\", \\\"{x:1228,y:987,t:1528143573142};\\\", \\\"{x:1228,y:985,t:1528143573159};\\\", \\\"{x:1228,y:984,t:1528143573180};\\\", \\\"{x:1228,y:982,t:1528143573220};\\\", \\\"{x:1228,y:981,t:1528143573235};\\\", \\\"{x:1228,y:979,t:1528143573243};\\\", \\\"{x:1225,y:976,t:1528143573259};\\\", \\\"{x:1222,y:973,t:1528143573275};\\\", \\\"{x:1219,y:971,t:1528143573291};\\\", \\\"{x:1217,y:970,t:1528143573308};\\\", \\\"{x:1216,y:969,t:1528143573325};\\\", \\\"{x:1216,y:968,t:1528143573364};\\\", \\\"{x:1216,y:967,t:1528143573375};\\\", \\\"{x:1216,y:965,t:1528143573411};\\\", \\\"{x:1216,y:964,t:1528143573436};\\\", \\\"{x:1215,y:964,t:1528143573916};\\\", \\\"{x:1215,y:965,t:1528143573926};\\\", \\\"{x:1215,y:968,t:1528143573942};\\\", \\\"{x:1214,y:971,t:1528143573959};\\\", \\\"{x:1214,y:973,t:1528143573975};\\\", \\\"{x:1214,y:974,t:1528143573992};\\\", \\\"{x:1214,y:975,t:1528143574008};\\\", \\\"{x:1214,y:977,t:1528143574026};\\\", \\\"{x:1214,y:978,t:1528143574043};\\\", \\\"{x:1214,y:982,t:1528143574059};\\\", \\\"{x:1214,y:983,t:1528143574075};\\\", \\\"{x:1214,y:985,t:1528143574093};\\\", \\\"{x:1214,y:987,t:1528143574109};\\\", \\\"{x:1214,y:989,t:1528143574126};\\\", \\\"{x:1216,y:993,t:1528143574143};\\\", \\\"{x:1222,y:999,t:1528143574159};\\\", \\\"{x:1230,y:1006,t:1528143574176};\\\", \\\"{x:1241,y:1012,t:1528143574193};\\\", \\\"{x:1252,y:1017,t:1528143574209};\\\", \\\"{x:1261,y:1020,t:1528143574225};\\\", \\\"{x:1263,y:1020,t:1528143574243};\\\", \\\"{x:1264,y:1020,t:1528143574267};\\\", \\\"{x:1266,y:1020,t:1528143574282};\\\", \\\"{x:1268,y:1020,t:1528143574292};\\\", \\\"{x:1272,y:1016,t:1528143574309};\\\", \\\"{x:1276,y:1011,t:1528143574326};\\\", \\\"{x:1278,y:1009,t:1528143574342};\\\", \\\"{x:1279,y:1005,t:1528143574360};\\\", \\\"{x:1279,y:1002,t:1528143574375};\\\", \\\"{x:1279,y:999,t:1528143574392};\\\", \\\"{x:1279,y:996,t:1528143574409};\\\", \\\"{x:1279,y:993,t:1528143574426};\\\", \\\"{x:1279,y:992,t:1528143574442};\\\", \\\"{x:1280,y:989,t:1528143574460};\\\", \\\"{x:1280,y:987,t:1528143574475};\\\", \\\"{x:1280,y:986,t:1528143574493};\\\", \\\"{x:1280,y:984,t:1528143574509};\\\", \\\"{x:1280,y:983,t:1528143574530};\\\", \\\"{x:1280,y:982,t:1528143574543};\\\", \\\"{x:1280,y:981,t:1528143574559};\\\", \\\"{x:1280,y:979,t:1528143574576};\\\", \\\"{x:1280,y:978,t:1528143574592};\\\", \\\"{x:1280,y:977,t:1528143574644};\\\", \\\"{x:1280,y:975,t:1528143574667};\\\", \\\"{x:1280,y:974,t:1528143574684};\\\", \\\"{x:1280,y:972,t:1528143574732};\\\", \\\"{x:1280,y:971,t:1528143574780};\\\", \\\"{x:1280,y:969,t:1528143574828};\\\", \\\"{x:1280,y:973,t:1528143575371};\\\", \\\"{x:1280,y:977,t:1528143575378};\\\", \\\"{x:1280,y:981,t:1528143575394};\\\", \\\"{x:1280,y:989,t:1528143575409};\\\", \\\"{x:1280,y:996,t:1528143575426};\\\", \\\"{x:1281,y:1000,t:1528143575443};\\\", \\\"{x:1282,y:1002,t:1528143575459};\\\", \\\"{x:1283,y:1003,t:1528143575476};\\\", \\\"{x:1283,y:1004,t:1528143575498};\\\", \\\"{x:1284,y:1004,t:1528143575514};\\\", \\\"{x:1285,y:1006,t:1528143575527};\\\", \\\"{x:1286,y:1007,t:1528143575543};\\\", \\\"{x:1288,y:1010,t:1528143575560};\\\", \\\"{x:1289,y:1011,t:1528143575577};\\\", \\\"{x:1289,y:1012,t:1528143575594};\\\", \\\"{x:1290,y:1013,t:1528143575610};\\\", \\\"{x:1291,y:1014,t:1528143575636};\\\", \\\"{x:1292,y:1014,t:1528143575651};\\\", \\\"{x:1293,y:1015,t:1528143575661};\\\", \\\"{x:1294,y:1016,t:1528143575677};\\\", \\\"{x:1297,y:1017,t:1528143575694};\\\", \\\"{x:1301,y:1019,t:1528143575711};\\\", \\\"{x:1310,y:1022,t:1528143575727};\\\", \\\"{x:1311,y:1023,t:1528143575744};\\\", \\\"{x:1314,y:1023,t:1528143575761};\\\", \\\"{x:1315,y:1023,t:1528143575787};\\\", \\\"{x:1316,y:1023,t:1528143575795};\\\", \\\"{x:1320,y:1023,t:1528143575810};\\\", \\\"{x:1321,y:1023,t:1528143575827};\\\", \\\"{x:1323,y:1022,t:1528143575843};\\\", \\\"{x:1325,y:1020,t:1528143575861};\\\", \\\"{x:1326,y:1020,t:1528143575876};\\\", \\\"{x:1327,y:1019,t:1528143575893};\\\", \\\"{x:1331,y:1018,t:1528143575910};\\\", \\\"{x:1333,y:1016,t:1528143575926};\\\", \\\"{x:1334,y:1016,t:1528143575943};\\\", \\\"{x:1337,y:1015,t:1528143575960};\\\", \\\"{x:1338,y:1014,t:1528143575977};\\\", \\\"{x:1341,y:1013,t:1528143575993};\\\", \\\"{x:1345,y:1012,t:1528143576010};\\\", \\\"{x:1350,y:1008,t:1528143576027};\\\", \\\"{x:1352,y:1005,t:1528143576044};\\\", \\\"{x:1356,y:1003,t:1528143576060};\\\", \\\"{x:1358,y:1001,t:1528143576076};\\\", \\\"{x:1359,y:999,t:1528143576094};\\\", \\\"{x:1362,y:996,t:1528143576111};\\\", \\\"{x:1362,y:995,t:1528143576140};\\\", \\\"{x:1362,y:994,t:1528143576147};\\\", \\\"{x:1362,y:993,t:1528143576163};\\\", \\\"{x:1362,y:992,t:1528143576180};\\\", \\\"{x:1362,y:991,t:1528143576194};\\\", \\\"{x:1363,y:987,t:1528143576212};\\\", \\\"{x:1363,y:985,t:1528143576228};\\\", \\\"{x:1363,y:983,t:1528143576244};\\\", \\\"{x:1363,y:982,t:1528143576261};\\\", \\\"{x:1363,y:981,t:1528143576278};\\\", \\\"{x:1363,y:980,t:1528143576294};\\\", \\\"{x:1363,y:979,t:1528143576311};\\\", \\\"{x:1363,y:977,t:1528143576328};\\\", \\\"{x:1362,y:976,t:1528143576344};\\\", \\\"{x:1361,y:974,t:1528143576361};\\\", \\\"{x:1361,y:973,t:1528143576378};\\\", \\\"{x:1361,y:971,t:1528143576394};\\\", \\\"{x:1359,y:969,t:1528143576412};\\\", \\\"{x:1358,y:967,t:1528143576428};\\\", \\\"{x:1357,y:967,t:1528143576444};\\\", \\\"{x:1357,y:966,t:1528143576483};\\\", \\\"{x:1356,y:965,t:1528143576494};\\\", \\\"{x:1354,y:964,t:1528143576511};\\\", \\\"{x:1353,y:964,t:1528143576572};\\\", \\\"{x:1352,y:963,t:1528143576820};\\\", \\\"{x:1352,y:962,t:1528143576852};\\\", \\\"{x:1352,y:961,t:1528143576899};\\\", \\\"{x:1351,y:961,t:1528143577036};\\\", \\\"{x:1350,y:961,t:1528143577051};\\\", \\\"{x:1348,y:961,t:1528143577062};\\\", \\\"{x:1348,y:962,t:1528143577078};\\\", \\\"{x:1347,y:966,t:1528143577095};\\\", \\\"{x:1347,y:967,t:1528143577112};\\\", \\\"{x:1347,y:968,t:1528143577128};\\\", \\\"{x:1347,y:970,t:1528143577145};\\\", \\\"{x:1347,y:971,t:1528143577162};\\\", \\\"{x:1347,y:974,t:1528143577178};\\\", \\\"{x:1347,y:980,t:1528143577195};\\\", \\\"{x:1349,y:983,t:1528143577212};\\\", \\\"{x:1351,y:986,t:1528143577229};\\\", \\\"{x:1354,y:988,t:1528143577245};\\\", \\\"{x:1357,y:990,t:1528143577263};\\\", \\\"{x:1359,y:991,t:1528143577278};\\\", \\\"{x:1362,y:992,t:1528143577295};\\\", \\\"{x:1363,y:992,t:1528143577312};\\\", \\\"{x:1369,y:995,t:1528143577328};\\\", \\\"{x:1373,y:995,t:1528143577345};\\\", \\\"{x:1376,y:995,t:1528143577362};\\\", \\\"{x:1377,y:995,t:1528143577378};\\\", \\\"{x:1379,y:995,t:1528143577396};\\\", \\\"{x:1380,y:995,t:1528143577412};\\\", \\\"{x:1383,y:995,t:1528143577429};\\\", \\\"{x:1384,y:995,t:1528143577445};\\\", \\\"{x:1386,y:995,t:1528143577462};\\\", \\\"{x:1388,y:995,t:1528143577479};\\\", \\\"{x:1390,y:995,t:1528143577495};\\\", \\\"{x:1392,y:995,t:1528143577516};\\\", \\\"{x:1393,y:995,t:1528143577539};\\\", \\\"{x:1396,y:994,t:1528143577548};\\\", \\\"{x:1397,y:994,t:1528143577562};\\\", \\\"{x:1400,y:992,t:1528143577579};\\\", \\\"{x:1402,y:991,t:1528143577596};\\\", \\\"{x:1403,y:991,t:1528143577619};\\\", \\\"{x:1405,y:990,t:1528143577644};\\\", \\\"{x:1406,y:990,t:1528143577652};\\\", \\\"{x:1406,y:989,t:1528143577662};\\\", \\\"{x:1409,y:988,t:1528143577679};\\\", \\\"{x:1413,y:986,t:1528143577696};\\\", \\\"{x:1415,y:985,t:1528143577712};\\\", \\\"{x:1417,y:985,t:1528143577729};\\\", \\\"{x:1418,y:984,t:1528143577745};\\\", \\\"{x:1419,y:984,t:1528143577771};\\\", \\\"{x:1419,y:983,t:1528143577804};\\\", \\\"{x:1419,y:982,t:1528143577819};\\\", \\\"{x:1419,y:980,t:1528143577835};\\\", \\\"{x:1419,y:979,t:1528143577867};\\\", \\\"{x:1419,y:977,t:1528143577907};\\\", \\\"{x:1419,y:976,t:1528143577923};\\\", \\\"{x:1419,y:975,t:1528143577964};\\\", \\\"{x:1419,y:974,t:1528143577996};\\\", \\\"{x:1418,y:973,t:1528143578019};\\\", \\\"{x:1418,y:972,t:1528143578030};\\\", \\\"{x:1418,y:970,t:1528143578046};\\\", \\\"{x:1418,y:969,t:1528143578067};\\\", \\\"{x:1417,y:969,t:1528143578079};\\\", \\\"{x:1416,y:967,t:1528143578096};\\\", \\\"{x:1416,y:966,t:1528143578112};\\\", \\\"{x:1416,y:964,t:1528143578129};\\\", \\\"{x:1416,y:963,t:1528143578146};\\\", \\\"{x:1415,y:961,t:1528143578162};\\\", \\\"{x:1414,y:960,t:1528143578179};\\\", \\\"{x:1413,y:961,t:1528143578460};\\\", \\\"{x:1412,y:963,t:1528143578468};\\\", \\\"{x:1412,y:965,t:1528143578480};\\\", \\\"{x:1412,y:968,t:1528143578496};\\\", \\\"{x:1412,y:972,t:1528143578514};\\\", \\\"{x:1412,y:975,t:1528143578529};\\\", \\\"{x:1412,y:978,t:1528143578546};\\\", \\\"{x:1412,y:979,t:1528143578563};\\\", \\\"{x:1412,y:981,t:1528143578580};\\\", \\\"{x:1412,y:983,t:1528143578596};\\\", \\\"{x:1412,y:985,t:1528143578613};\\\", \\\"{x:1413,y:988,t:1528143578630};\\\", \\\"{x:1415,y:992,t:1528143578646};\\\", \\\"{x:1418,y:995,t:1528143578663};\\\", \\\"{x:1420,y:997,t:1528143578679};\\\", \\\"{x:1422,y:998,t:1528143578696};\\\", \\\"{x:1422,y:999,t:1528143578713};\\\", \\\"{x:1423,y:999,t:1528143578729};\\\", \\\"{x:1424,y:999,t:1528143578756};\\\", \\\"{x:1425,y:1000,t:1528143578764};\\\", \\\"{x:1429,y:1001,t:1528143578780};\\\", \\\"{x:1432,y:1002,t:1528143578796};\\\", \\\"{x:1435,y:1003,t:1528143578813};\\\", \\\"{x:1438,y:1004,t:1528143578830};\\\", \\\"{x:1441,y:1004,t:1528143578846};\\\", \\\"{x:1443,y:1004,t:1528143578863};\\\", \\\"{x:1444,y:1004,t:1528143578883};\\\", \\\"{x:1445,y:1004,t:1528143578896};\\\", \\\"{x:1446,y:1004,t:1528143578914};\\\", \\\"{x:1447,y:1004,t:1528143578931};\\\", \\\"{x:1448,y:1004,t:1528143578946};\\\", \\\"{x:1449,y:1004,t:1528143578963};\\\", \\\"{x:1450,y:1004,t:1528143578980};\\\", \\\"{x:1452,y:1004,t:1528143578996};\\\", \\\"{x:1454,y:1004,t:1528143579013};\\\", \\\"{x:1458,y:1004,t:1528143579031};\\\", \\\"{x:1461,y:1004,t:1528143579046};\\\", \\\"{x:1463,y:1004,t:1528143579063};\\\", \\\"{x:1465,y:1003,t:1528143579080};\\\", \\\"{x:1467,y:1003,t:1528143579097};\\\", \\\"{x:1468,y:1002,t:1528143579113};\\\", \\\"{x:1469,y:1001,t:1528143579130};\\\", \\\"{x:1472,y:1000,t:1528143579146};\\\", \\\"{x:1474,y:998,t:1528143579163};\\\", \\\"{x:1475,y:997,t:1528143579180};\\\", \\\"{x:1477,y:996,t:1528143579196};\\\", \\\"{x:1478,y:994,t:1528143579213};\\\", \\\"{x:1480,y:993,t:1528143579230};\\\", \\\"{x:1480,y:992,t:1528143579247};\\\", \\\"{x:1480,y:991,t:1528143579268};\\\", \\\"{x:1482,y:990,t:1528143579280};\\\", \\\"{x:1482,y:989,t:1528143579297};\\\", \\\"{x:1482,y:988,t:1528143579315};\\\", \\\"{x:1482,y:987,t:1528143579330};\\\", \\\"{x:1482,y:985,t:1528143579348};\\\", \\\"{x:1484,y:981,t:1528143579363};\\\", \\\"{x:1484,y:980,t:1528143579380};\\\", \\\"{x:1485,y:978,t:1528143579397};\\\", \\\"{x:1485,y:976,t:1528143579413};\\\", \\\"{x:1485,y:975,t:1528143579431};\\\", \\\"{x:1485,y:973,t:1528143579447};\\\", \\\"{x:1485,y:972,t:1528143579463};\\\", \\\"{x:1485,y:969,t:1528143579480};\\\", \\\"{x:1485,y:967,t:1528143579498};\\\", \\\"{x:1485,y:966,t:1528143579513};\\\", \\\"{x:1485,y:964,t:1528143579548};\\\", \\\"{x:1484,y:964,t:1528143580316};\\\", \\\"{x:1483,y:964,t:1528143580332};\\\", \\\"{x:1481,y:963,t:1528143580756};\\\", \\\"{x:1473,y:953,t:1528143580765};\\\", \\\"{x:1459,y:936,t:1528143580781};\\\", \\\"{x:1445,y:922,t:1528143580798};\\\", \\\"{x:1430,y:905,t:1528143580815};\\\", \\\"{x:1414,y:886,t:1528143580832};\\\", \\\"{x:1399,y:871,t:1528143580848};\\\", \\\"{x:1379,y:849,t:1528143580865};\\\", \\\"{x:1362,y:826,t:1528143580881};\\\", \\\"{x:1348,y:806,t:1528143580898};\\\", \\\"{x:1336,y:788,t:1528143580915};\\\", \\\"{x:1325,y:766,t:1528143580931};\\\", \\\"{x:1318,y:750,t:1528143580948};\\\", \\\"{x:1314,y:736,t:1528143580965};\\\", \\\"{x:1305,y:707,t:1528143580982};\\\", \\\"{x:1297,y:682,t:1528143580998};\\\", \\\"{x:1290,y:659,t:1528143581016};\\\", \\\"{x:1283,y:634,t:1528143581031};\\\", \\\"{x:1278,y:616,t:1528143581049};\\\", \\\"{x:1276,y:612,t:1528143581066};\\\", \\\"{x:1276,y:609,t:1528143581081};\\\", \\\"{x:1274,y:606,t:1528143581098};\\\", \\\"{x:1274,y:603,t:1528143581116};\\\", \\\"{x:1273,y:599,t:1528143581131};\\\", \\\"{x:1273,y:594,t:1528143581148};\\\", \\\"{x:1273,y:590,t:1528143581165};\\\", \\\"{x:1273,y:587,t:1528143581181};\\\", \\\"{x:1273,y:581,t:1528143581198};\\\", \\\"{x:1273,y:570,t:1528143581215};\\\", \\\"{x:1273,y:553,t:1528143581232};\\\", \\\"{x:1273,y:536,t:1528143581249};\\\", \\\"{x:1273,y:528,t:1528143581265};\\\", \\\"{x:1274,y:522,t:1528143581282};\\\", \\\"{x:1274,y:521,t:1528143581299};\\\", \\\"{x:1273,y:524,t:1528143581396};\\\", \\\"{x:1268,y:532,t:1528143581403};\\\", \\\"{x:1264,y:539,t:1528143581416};\\\", \\\"{x:1253,y:558,t:1528143581432};\\\", \\\"{x:1242,y:577,t:1528143581449};\\\", \\\"{x:1237,y:590,t:1528143581466};\\\", \\\"{x:1233,y:601,t:1528143581483};\\\", \\\"{x:1229,y:609,t:1528143581499};\\\", \\\"{x:1221,y:623,t:1528143581515};\\\", \\\"{x:1211,y:637,t:1528143581532};\\\", \\\"{x:1202,y:652,t:1528143581548};\\\", \\\"{x:1195,y:664,t:1528143581565};\\\", \\\"{x:1191,y:672,t:1528143581582};\\\", \\\"{x:1187,y:680,t:1528143581598};\\\", \\\"{x:1180,y:692,t:1528143581615};\\\", \\\"{x:1171,y:706,t:1528143581631};\\\", \\\"{x:1160,y:719,t:1528143581648};\\\", \\\"{x:1150,y:739,t:1528143581665};\\\", \\\"{x:1141,y:759,t:1528143581682};\\\", \\\"{x:1132,y:778,t:1528143581698};\\\", \\\"{x:1127,y:793,t:1528143581714};\\\", \\\"{x:1123,y:801,t:1528143581731};\\\", \\\"{x:1121,y:809,t:1528143581748};\\\", \\\"{x:1119,y:816,t:1528143581765};\\\", \\\"{x:1115,y:827,t:1528143581782};\\\", \\\"{x:1114,y:837,t:1528143581798};\\\", \\\"{x:1112,y:848,t:1528143581815};\\\", \\\"{x:1110,y:857,t:1528143581832};\\\", \\\"{x:1109,y:869,t:1528143581848};\\\", \\\"{x:1107,y:884,t:1528143581865};\\\", \\\"{x:1104,y:901,t:1528143581882};\\\", \\\"{x:1102,y:913,t:1528143581899};\\\", \\\"{x:1102,y:914,t:1528143581915};\\\", \\\"{x:1102,y:915,t:1528143581970};\\\", \\\"{x:1102,y:916,t:1528143581981};\\\", \\\"{x:1102,y:925,t:1528143581999};\\\", \\\"{x:1100,y:929,t:1528143582015};\\\", \\\"{x:1100,y:932,t:1528143582032};\\\", \\\"{x:1100,y:933,t:1528143582049};\\\", \\\"{x:1100,y:936,t:1528143582065};\\\", \\\"{x:1100,y:939,t:1528143582082};\\\", \\\"{x:1099,y:948,t:1528143582099};\\\", \\\"{x:1099,y:956,t:1528143582115};\\\", \\\"{x:1099,y:960,t:1528143582132};\\\", \\\"{x:1099,y:963,t:1528143582149};\\\", \\\"{x:1099,y:964,t:1528143582165};\\\", \\\"{x:1099,y:966,t:1528143582183};\\\", \\\"{x:1099,y:962,t:1528143582284};\\\", \\\"{x:1106,y:937,t:1528143582300};\\\", \\\"{x:1114,y:921,t:1528143582316};\\\", \\\"{x:1121,y:910,t:1528143582333};\\\", \\\"{x:1126,y:901,t:1528143582349};\\\", \\\"{x:1132,y:889,t:1528143582366};\\\", \\\"{x:1142,y:870,t:1528143582383};\\\", \\\"{x:1153,y:846,t:1528143582399};\\\", \\\"{x:1160,y:830,t:1528143582416};\\\", \\\"{x:1166,y:817,t:1528143582432};\\\", \\\"{x:1171,y:806,t:1528143582449};\\\", \\\"{x:1175,y:796,t:1528143582466};\\\", \\\"{x:1179,y:783,t:1528143582482};\\\", \\\"{x:1185,y:761,t:1528143582501};\\\", \\\"{x:1190,y:747,t:1528143582517};\\\", \\\"{x:1193,y:739,t:1528143582532};\\\", \\\"{x:1195,y:735,t:1528143582549};\\\", \\\"{x:1197,y:727,t:1528143582566};\\\", \\\"{x:1198,y:717,t:1528143582582};\\\", \\\"{x:1202,y:707,t:1528143582599};\\\", \\\"{x:1205,y:694,t:1528143582616};\\\", \\\"{x:1209,y:682,t:1528143582632};\\\", \\\"{x:1213,y:673,t:1528143582650};\\\", \\\"{x:1220,y:662,t:1528143582666};\\\", \\\"{x:1227,y:651,t:1528143582683};\\\", \\\"{x:1239,y:632,t:1528143582700};\\\", \\\"{x:1249,y:619,t:1528143582717};\\\", \\\"{x:1259,y:608,t:1528143582733};\\\", \\\"{x:1266,y:602,t:1528143582750};\\\", \\\"{x:1270,y:598,t:1528143582767};\\\", \\\"{x:1272,y:597,t:1528143582784};\\\", \\\"{x:1275,y:594,t:1528143582800};\\\", \\\"{x:1279,y:591,t:1528143582816};\\\", \\\"{x:1281,y:590,t:1528143582833};\\\", \\\"{x:1286,y:586,t:1528143582849};\\\", \\\"{x:1294,y:581,t:1528143582867};\\\", \\\"{x:1302,y:574,t:1528143582883};\\\", \\\"{x:1304,y:572,t:1528143582899};\\\", \\\"{x:1304,y:575,t:1528143583132};\\\", \\\"{x:1307,y:581,t:1528143583139};\\\", \\\"{x:1308,y:587,t:1528143583149};\\\", \\\"{x:1312,y:598,t:1528143583166};\\\", \\\"{x:1315,y:609,t:1528143583184};\\\", \\\"{x:1319,y:618,t:1528143583201};\\\", \\\"{x:1324,y:630,t:1528143583217};\\\", \\\"{x:1327,y:645,t:1528143583234};\\\", \\\"{x:1329,y:667,t:1528143583251};\\\", \\\"{x:1333,y:691,t:1528143583267};\\\", \\\"{x:1344,y:728,t:1528143583284};\\\", \\\"{x:1349,y:750,t:1528143583299};\\\", \\\"{x:1357,y:770,t:1528143583318};\\\", \\\"{x:1362,y:791,t:1528143583333};\\\", \\\"{x:1367,y:810,t:1528143583351};\\\", \\\"{x:1371,y:833,t:1528143583366};\\\", \\\"{x:1376,y:859,t:1528143583384};\\\", \\\"{x:1379,y:882,t:1528143583401};\\\", \\\"{x:1385,y:902,t:1528143583417};\\\", \\\"{x:1392,y:917,t:1528143583433};\\\", \\\"{x:1396,y:927,t:1528143583450};\\\", \\\"{x:1400,y:939,t:1528143583467};\\\", \\\"{x:1403,y:950,t:1528143583483};\\\", \\\"{x:1404,y:956,t:1528143583500};\\\", \\\"{x:1406,y:960,t:1528143583517};\\\", \\\"{x:1406,y:963,t:1528143583534};\\\", \\\"{x:1408,y:966,t:1528143583551};\\\", \\\"{x:1409,y:971,t:1528143583567};\\\", \\\"{x:1412,y:975,t:1528143583583};\\\", \\\"{x:1412,y:977,t:1528143583600};\\\", \\\"{x:1413,y:979,t:1528143583618};\\\", \\\"{x:1413,y:977,t:1528143583875};\\\", \\\"{x:1413,y:971,t:1528143583883};\\\", \\\"{x:1413,y:966,t:1528143583900};\\\", \\\"{x:1411,y:965,t:1528143584196};\\\", \\\"{x:1408,y:962,t:1528143584203};\\\", \\\"{x:1406,y:962,t:1528143584217};\\\", \\\"{x:1403,y:961,t:1528143584234};\\\", \\\"{x:1402,y:961,t:1528143584356};\\\", \\\"{x:1400,y:961,t:1528143584380};\\\", \\\"{x:1399,y:961,t:1528143584387};\\\", \\\"{x:1396,y:961,t:1528143584401};\\\", \\\"{x:1393,y:961,t:1528143584416};\\\", \\\"{x:1385,y:964,t:1528143584434};\\\", \\\"{x:1377,y:967,t:1528143584450};\\\", \\\"{x:1363,y:970,t:1528143584467};\\\", \\\"{x:1354,y:973,t:1528143584484};\\\", \\\"{x:1340,y:978,t:1528143584501};\\\", \\\"{x:1326,y:983,t:1528143584517};\\\", \\\"{x:1311,y:989,t:1528143584534};\\\", \\\"{x:1302,y:991,t:1528143584551};\\\", \\\"{x:1293,y:993,t:1528143584567};\\\", \\\"{x:1288,y:996,t:1528143584584};\\\", \\\"{x:1281,y:997,t:1528143584600};\\\", \\\"{x:1274,y:1000,t:1528143584617};\\\", \\\"{x:1260,y:1004,t:1528143584634};\\\", \\\"{x:1236,y:1009,t:1528143584651};\\\", \\\"{x:1221,y:1010,t:1528143584667};\\\", \\\"{x:1210,y:1010,t:1528143584685};\\\", \\\"{x:1204,y:1010,t:1528143584701};\\\", \\\"{x:1203,y:1010,t:1528143584718};\\\", \\\"{x:1202,y:1010,t:1528143584868};\\\", \\\"{x:1202,y:1002,t:1528143584885};\\\", \\\"{x:1208,y:992,t:1528143584901};\\\", \\\"{x:1210,y:986,t:1528143584917};\\\", \\\"{x:1213,y:983,t:1528143584935};\\\", \\\"{x:1213,y:982,t:1528143584952};\\\", \\\"{x:1214,y:980,t:1528143584980};\\\", \\\"{x:1214,y:978,t:1528143584987};\\\", \\\"{x:1214,y:977,t:1528143585001};\\\", \\\"{x:1218,y:972,t:1528143585019};\\\", \\\"{x:1227,y:962,t:1528143585035};\\\", \\\"{x:1241,y:947,t:1528143585052};\\\", \\\"{x:1258,y:928,t:1528143585067};\\\", \\\"{x:1279,y:902,t:1528143585085};\\\", \\\"{x:1309,y:853,t:1528143585102};\\\", \\\"{x:1332,y:814,t:1528143585119};\\\", \\\"{x:1352,y:775,t:1528143585134};\\\", \\\"{x:1367,y:737,t:1528143585151};\\\", \\\"{x:1381,y:701,t:1528143585169};\\\", \\\"{x:1399,y:655,t:1528143585185};\\\", \\\"{x:1425,y:606,t:1528143585202};\\\", \\\"{x:1439,y:587,t:1528143585218};\\\", \\\"{x:1445,y:575,t:1528143585235};\\\", \\\"{x:1449,y:566,t:1528143585251};\\\", \\\"{x:1449,y:565,t:1528143585267};\\\", \\\"{x:1449,y:564,t:1528143585284};\\\", \\\"{x:1449,y:565,t:1528143585379};\\\", \\\"{x:1446,y:567,t:1528143585386};\\\", \\\"{x:1444,y:569,t:1528143585401};\\\", \\\"{x:1433,y:575,t:1528143585418};\\\", \\\"{x:1426,y:581,t:1528143585435};\\\", \\\"{x:1425,y:583,t:1528143585451};\\\", \\\"{x:1424,y:583,t:1528143585499};\\\", \\\"{x:1423,y:583,t:1528143585596};\\\", \\\"{x:1423,y:582,t:1528143585604};\\\", \\\"{x:1423,y:581,t:1528143585619};\\\", \\\"{x:1421,y:576,t:1528143585636};\\\", \\\"{x:1421,y:574,t:1528143585652};\\\", \\\"{x:1421,y:572,t:1528143585669};\\\", \\\"{x:1421,y:571,t:1528143585686};\\\", \\\"{x:1421,y:569,t:1528143585716};\\\", \\\"{x:1421,y:568,t:1528143585763};\\\", \\\"{x:1421,y:569,t:1528143585931};\\\", \\\"{x:1421,y:577,t:1528143585940};\\\", \\\"{x:1421,y:584,t:1528143585953};\\\", \\\"{x:1421,y:607,t:1528143585968};\\\", \\\"{x:1426,y:630,t:1528143585985};\\\", \\\"{x:1432,y:649,t:1528143586003};\\\", \\\"{x:1437,y:664,t:1528143586019};\\\", \\\"{x:1447,y:690,t:1528143586035};\\\", \\\"{x:1451,y:707,t:1528143586052};\\\", \\\"{x:1455,y:721,t:1528143586068};\\\", \\\"{x:1461,y:734,t:1528143586086};\\\", \\\"{x:1466,y:748,t:1528143586103};\\\", \\\"{x:1471,y:759,t:1528143586119};\\\", \\\"{x:1477,y:767,t:1528143586136};\\\", \\\"{x:1480,y:772,t:1528143586152};\\\", \\\"{x:1484,y:780,t:1528143586168};\\\", \\\"{x:1486,y:784,t:1528143586186};\\\", \\\"{x:1490,y:792,t:1528143586203};\\\", \\\"{x:1494,y:798,t:1528143586218};\\\", \\\"{x:1498,y:805,t:1528143586235};\\\", \\\"{x:1502,y:810,t:1528143586253};\\\", \\\"{x:1506,y:817,t:1528143586268};\\\", \\\"{x:1511,y:825,t:1528143586285};\\\", \\\"{x:1517,y:834,t:1528143586302};\\\", \\\"{x:1524,y:841,t:1528143586319};\\\", \\\"{x:1531,y:850,t:1528143586335};\\\", \\\"{x:1537,y:856,t:1528143586352};\\\", \\\"{x:1542,y:862,t:1528143586370};\\\", \\\"{x:1546,y:867,t:1528143586386};\\\", \\\"{x:1551,y:873,t:1528143586403};\\\", \\\"{x:1563,y:887,t:1528143586419};\\\", \\\"{x:1569,y:895,t:1528143586436};\\\", \\\"{x:1573,y:901,t:1528143586452};\\\", \\\"{x:1579,y:907,t:1528143586469};\\\", \\\"{x:1584,y:913,t:1528143586485};\\\", \\\"{x:1588,y:916,t:1528143586502};\\\", \\\"{x:1592,y:919,t:1528143586520};\\\", \\\"{x:1594,y:922,t:1528143586536};\\\", \\\"{x:1597,y:925,t:1528143586553};\\\", \\\"{x:1600,y:929,t:1528143586570};\\\", \\\"{x:1601,y:931,t:1528143586585};\\\", \\\"{x:1602,y:932,t:1528143586603};\\\", \\\"{x:1603,y:933,t:1528143586619};\\\", \\\"{x:1606,y:936,t:1528143586635};\\\", \\\"{x:1607,y:939,t:1528143586653};\\\", \\\"{x:1611,y:944,t:1528143586671};\\\", \\\"{x:1612,y:947,t:1528143586685};\\\", \\\"{x:1614,y:948,t:1528143586702};\\\", \\\"{x:1615,y:950,t:1528143586720};\\\", \\\"{x:1617,y:952,t:1528143586735};\\\", \\\"{x:1618,y:953,t:1528143586753};\\\", \\\"{x:1619,y:955,t:1528143586769};\\\", \\\"{x:1621,y:957,t:1528143586786};\\\", \\\"{x:1622,y:958,t:1528143586803};\\\", \\\"{x:1622,y:959,t:1528143586819};\\\", \\\"{x:1619,y:950,t:1528143588676};\\\", \\\"{x:1604,y:934,t:1528143588688};\\\", \\\"{x:1556,y:886,t:1528143588705};\\\", \\\"{x:1472,y:822,t:1528143588720};\\\", \\\"{x:1377,y:754,t:1528143588738};\\\", \\\"{x:1220,y:660,t:1528143588755};\\\", \\\"{x:1160,y:628,t:1528143588771};\\\", \\\"{x:1002,y:543,t:1528143588787};\\\", \\\"{x:921,y:502,t:1528143588806};\\\", \\\"{x:841,y:466,t:1528143588821};\\\", \\\"{x:764,y:434,t:1528143588837};\\\", \\\"{x:679,y:399,t:1528143588855};\\\", \\\"{x:598,y:373,t:1528143588871};\\\", \\\"{x:533,y:359,t:1528143588888};\\\", \\\"{x:478,y:355,t:1528143588905};\\\", \\\"{x:435,y:363,t:1528143588921};\\\", \\\"{x:417,y:372,t:1528143588938};\\\", \\\"{x:411,y:377,t:1528143588955};\\\", \\\"{x:411,y:380,t:1528143588971};\\\", \\\"{x:410,y:387,t:1528143588988};\\\", \\\"{x:409,y:402,t:1528143589005};\\\", \\\"{x:407,y:414,t:1528143589021};\\\", \\\"{x:405,y:427,t:1528143589038};\\\", \\\"{x:405,y:435,t:1528143589056};\\\", \\\"{x:405,y:444,t:1528143589071};\\\", \\\"{x:405,y:449,t:1528143589088};\\\", \\\"{x:405,y:455,t:1528143589106};\\\", \\\"{x:407,y:464,t:1528143589122};\\\", \\\"{x:408,y:473,t:1528143589139};\\\", \\\"{x:412,y:489,t:1528143589157};\\\", \\\"{x:413,y:501,t:1528143589171};\\\", \\\"{x:416,y:512,t:1528143589188};\\\", \\\"{x:417,y:520,t:1528143589205};\\\", \\\"{x:420,y:529,t:1528143589222};\\\", \\\"{x:421,y:535,t:1528143589238};\\\", \\\"{x:424,y:544,t:1528143589256};\\\", \\\"{x:425,y:548,t:1528143589272};\\\", \\\"{x:428,y:552,t:1528143589288};\\\", \\\"{x:429,y:556,t:1528143589305};\\\", \\\"{x:430,y:557,t:1528143589322};\\\", \\\"{x:431,y:561,t:1528143589338};\\\", \\\"{x:433,y:563,t:1528143589355};\\\", \\\"{x:433,y:564,t:1528143589371};\\\", \\\"{x:433,y:566,t:1528143590923};\\\", \\\"{x:433,y:568,t:1528143590930};\\\", \\\"{x:431,y:570,t:1528143590940};\\\", \\\"{x:430,y:572,t:1528143590958};\\\", \\\"{x:436,y:571,t:1528143591075};\\\", \\\"{x:445,y:564,t:1528143591090};\\\", \\\"{x:485,y:539,t:1528143591110};\\\", \\\"{x:500,y:534,t:1528143591124};\\\", \\\"{x:504,y:533,t:1528143591140};\\\", \\\"{x:505,y:534,t:1528143591211};\\\", \\\"{x:504,y:543,t:1528143591223};\\\", \\\"{x:490,y:558,t:1528143591241};\\\", \\\"{x:473,y:569,t:1528143591257};\\\", \\\"{x:460,y:574,t:1528143591273};\\\", \\\"{x:450,y:577,t:1528143591290};\\\", \\\"{x:431,y:577,t:1528143591306};\\\", \\\"{x:422,y:578,t:1528143591324};\\\", \\\"{x:417,y:578,t:1528143591341};\\\", \\\"{x:413,y:578,t:1528143591357};\\\", \\\"{x:411,y:578,t:1528143591373};\\\", \\\"{x:406,y:579,t:1528143591391};\\\", \\\"{x:402,y:579,t:1528143591406};\\\", \\\"{x:392,y:579,t:1528143591423};\\\", \\\"{x:379,y:579,t:1528143591441};\\\", \\\"{x:363,y:579,t:1528143591458};\\\", \\\"{x:348,y:579,t:1528143591473};\\\", \\\"{x:340,y:578,t:1528143591490};\\\", \\\"{x:330,y:576,t:1528143591507};\\\", \\\"{x:324,y:575,t:1528143591524};\\\", \\\"{x:321,y:574,t:1528143591541};\\\", \\\"{x:316,y:572,t:1528143591557};\\\", \\\"{x:314,y:571,t:1528143591573};\\\", \\\"{x:313,y:571,t:1528143591603};\\\", \\\"{x:313,y:569,t:1528143591627};\\\", \\\"{x:316,y:565,t:1528143591640};\\\", \\\"{x:327,y:558,t:1528143591659};\\\", \\\"{x:342,y:549,t:1528143591674};\\\", \\\"{x:371,y:538,t:1528143591690};\\\", \\\"{x:395,y:533,t:1528143591707};\\\", \\\"{x:426,y:530,t:1528143591724};\\\", \\\"{x:452,y:527,t:1528143591740};\\\", \\\"{x:479,y:527,t:1528143591757};\\\", \\\"{x:502,y:527,t:1528143591774};\\\", \\\"{x:528,y:527,t:1528143591790};\\\", \\\"{x:551,y:527,t:1528143591807};\\\", \\\"{x:569,y:527,t:1528143591823};\\\", \\\"{x:586,y:527,t:1528143591840};\\\", \\\"{x:593,y:527,t:1528143591857};\\\", \\\"{x:594,y:527,t:1528143591873};\\\", \\\"{x:595,y:527,t:1528143591956};\\\", \\\"{x:596,y:526,t:1528143591971};\\\", \\\"{x:596,y:525,t:1528143591979};\\\", \\\"{x:596,y:524,t:1528143591992};\\\", \\\"{x:596,y:522,t:1528143592035};\\\", \\\"{x:596,y:521,t:1528143592083};\\\", \\\"{x:595,y:520,t:1528143592091};\\\", \\\"{x:595,y:517,t:1528143592107};\\\", \\\"{x:595,y:515,t:1528143592124};\\\", \\\"{x:595,y:510,t:1528143592140};\\\", \\\"{x:595,y:508,t:1528143592157};\\\", \\\"{x:595,y:507,t:1528143592175};\\\", \\\"{x:595,y:506,t:1528143592191};\\\", \\\"{x:596,y:504,t:1528143592207};\\\", \\\"{x:597,y:503,t:1528143592227};\\\", \\\"{x:598,y:502,t:1528143592251};\\\", \\\"{x:599,y:502,t:1528143592587};\\\", \\\"{x:609,y:503,t:1528143592596};\\\", \\\"{x:624,y:505,t:1528143592609};\\\", \\\"{x:655,y:509,t:1528143592624};\\\", \\\"{x:700,y:516,t:1528143592641};\\\", \\\"{x:756,y:524,t:1528143592657};\\\", \\\"{x:810,y:543,t:1528143592675};\\\", \\\"{x:818,y:544,t:1528143592691};\\\", \\\"{x:819,y:544,t:1528143592708};\\\", \\\"{x:812,y:544,t:1528143593211};\\\", \\\"{x:804,y:541,t:1528143593226};\\\", \\\"{x:764,y:534,t:1528143593243};\\\", \\\"{x:741,y:529,t:1528143593259};\\\", \\\"{x:721,y:527,t:1528143593277};\\\", \\\"{x:710,y:524,t:1528143593294};\\\", \\\"{x:702,y:523,t:1528143593308};\\\", \\\"{x:693,y:522,t:1528143593325};\\\", \\\"{x:685,y:522,t:1528143593342};\\\", \\\"{x:675,y:522,t:1528143593359};\\\", \\\"{x:667,y:522,t:1528143593375};\\\", \\\"{x:660,y:522,t:1528143593392};\\\", \\\"{x:653,y:522,t:1528143593408};\\\", \\\"{x:647,y:520,t:1528143593426};\\\", \\\"{x:634,y:518,t:1528143593442};\\\", \\\"{x:625,y:514,t:1528143593459};\\\", \\\"{x:617,y:512,t:1528143593476};\\\", \\\"{x:611,y:510,t:1528143593492};\\\", \\\"{x:604,y:507,t:1528143593508};\\\", \\\"{x:593,y:502,t:1528143593526};\\\", \\\"{x:590,y:500,t:1528143593542};\\\", \\\"{x:589,y:500,t:1528143593563};\\\", \\\"{x:588,y:500,t:1528143593595};\\\", \\\"{x:588,y:499,t:1528143593608};\\\", \\\"{x:588,y:498,t:1528143593626};\\\", \\\"{x:588,y:496,t:1528143593643};\\\", \\\"{x:589,y:494,t:1528143593659};\\\", \\\"{x:590,y:494,t:1528143593676};\\\", \\\"{x:591,y:494,t:1528143593693};\\\", \\\"{x:592,y:494,t:1528143593739};\\\", \\\"{x:593,y:494,t:1528143593747};\\\", \\\"{x:595,y:494,t:1528143593763};\\\", \\\"{x:598,y:494,t:1528143593777};\\\", \\\"{x:601,y:494,t:1528143593794};\\\", \\\"{x:604,y:494,t:1528143593810};\\\", \\\"{x:605,y:494,t:1528143593907};\\\", \\\"{x:607,y:494,t:1528143593971};\\\", \\\"{x:608,y:494,t:1528143594011};\\\", \\\"{x:609,y:494,t:1528143594026};\\\", \\\"{x:613,y:498,t:1528143594043};\\\", \\\"{x:617,y:502,t:1528143594060};\\\", \\\"{x:620,y:507,t:1528143594075};\\\", \\\"{x:621,y:507,t:1528143594093};\\\", \\\"{x:622,y:508,t:1528143594125};\\\", \\\"{x:622,y:508,t:1528143594249};\\\", \\\"{x:631,y:510,t:1528143594259};\\\", \\\"{x:652,y:515,t:1528143594276};\\\", \\\"{x:689,y:522,t:1528143594293};\\\", \\\"{x:740,y:530,t:1528143594309};\\\", \\\"{x:772,y:536,t:1528143594326};\\\", \\\"{x:790,y:538,t:1528143594342};\\\", \\\"{x:795,y:538,t:1528143594360};\\\", \\\"{x:796,y:538,t:1528143594376};\\\", \\\"{x:797,y:538,t:1528143594523};\\\", \\\"{x:798,y:538,t:1528143594595};\\\", \\\"{x:800,y:538,t:1528143594610};\\\", \\\"{x:805,y:538,t:1528143594627};\\\", \\\"{x:811,y:537,t:1528143594643};\\\", \\\"{x:812,y:537,t:1528143594659};\\\", \\\"{x:813,y:537,t:1528143594900};\\\", \\\"{x:814,y:537,t:1528143594931};\\\", \\\"{x:816,y:537,t:1528143594947};\\\", \\\"{x:819,y:537,t:1528143594963};\\\", \\\"{x:823,y:537,t:1528143594976};\\\", \\\"{x:830,y:537,t:1528143594995};\\\", \\\"{x:834,y:537,t:1528143595010};\\\", \\\"{x:835,y:537,t:1528143595027};\\\", \\\"{x:836,y:538,t:1528143595363};\\\", \\\"{x:832,y:542,t:1528143595376};\\\", \\\"{x:807,y:554,t:1528143595394};\\\", \\\"{x:775,y:576,t:1528143595412};\\\", \\\"{x:738,y:602,t:1528143595427};\\\", \\\"{x:687,y:640,t:1528143595444};\\\", \\\"{x:645,y:669,t:1528143595460};\\\", \\\"{x:605,y:698,t:1528143595476};\\\", \\\"{x:574,y:725,t:1528143595493};\\\", \\\"{x:558,y:740,t:1528143595511};\\\", \\\"{x:546,y:754,t:1528143595528};\\\", \\\"{x:538,y:764,t:1528143595544};\\\", \\\"{x:533,y:772,t:1528143595561};\\\", \\\"{x:533,y:775,t:1528143595577};\\\", \\\"{x:532,y:776,t:1528143595595};\\\", \\\"{x:531,y:776,t:1528143595675};\\\", \\\"{x:531,y:772,t:1528143595683};\\\", \\\"{x:530,y:766,t:1528143595694};\\\", \\\"{x:530,y:761,t:1528143595710};\\\", \\\"{x:530,y:756,t:1528143595727};\\\", \\\"{x:530,y:751,t:1528143595745};\\\", \\\"{x:530,y:744,t:1528143595761};\\\", \\\"{x:530,y:737,t:1528143595777};\\\", \\\"{x:532,y:732,t:1528143595794};\\\", \\\"{x:534,y:724,t:1528143595811};\\\", \\\"{x:535,y:723,t:1528143595835};\\\", \\\"{x:536,y:725,t:1528143596116};\\\", \\\"{x:536,y:728,t:1528143596131};\\\", \\\"{x:536,y:731,t:1528143596145};\\\", \\\"{x:536,y:734,t:1528143596162};\\\", \\\"{x:536,y:736,t:1528143596178};\\\", \\\"{x:539,y:736,t:1528143596947};\\\", \\\"{x:549,y:736,t:1528143596961};\\\", \\\"{x:574,y:732,t:1528143596978};\\\", \\\"{x:627,y:731,t:1528143596995};\\\", \\\"{x:672,y:731,t:1528143597011};\\\", \\\"{x:719,y:731,t:1528143597027};\\\", \\\"{x:761,y:731,t:1528143597044};\\\", \\\"{x:787,y:731,t:1528143597061};\\\", \\\"{x:803,y:731,t:1528143597077};\\\", \\\"{x:819,y:731,t:1528143597094};\\\", \\\"{x:828,y:731,t:1528143597112};\\\", \\\"{x:832,y:731,t:1528143597128};\\\", \\\"{x:833,y:731,t:1528143597144};\\\" ] }, { \\\"rt\\\": 69059, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 349085, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"TTCWS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-J -J -J -X -M -J -09 AM-09 AM-J -A -A -M -M -12 PM-12 PM-M -M -M -01 PM-M -M -M -12 PM-12 PM-12 PM-02 PM-01 PM-02 PM-02 PM-03 PM-03 PM-04 PM-04 PM-05 PM-05 PM-06 PM-06 PM-05 PM-04 PM-03 PM-02 PM-X -X -O -X -01 PM-01 PM-01 PM-02 PM-02 PM-03 PM-04 PM-05 PM-05 PM-06 PM-O -D -01 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:834,y:730,t:1528143599692};\\\", \\\"{x:843,y:639,t:1528143603924};\\\", \\\"{x:853,y:371,t:1528143603935};\\\", \\\"{x:849,y:0,t:1528143603951};\\\", \\\"{x:802,y:0,t:1528143603968};\\\", \\\"{x:706,y:0,t:1528143603984};\\\", \\\"{x:600,y:0,t:1528143604000};\\\", \\\"{x:517,y:0,t:1528143604017};\\\", \\\"{x:476,y:0,t:1528143604034};\\\", \\\"{x:434,y:0,t:1528143604050};\\\", \\\"{x:395,y:0,t:1528143604067};\\\", \\\"{x:400,y:0,t:1528143604085};\\\", \\\"{x:413,y:0,t:1528143604101};\\\", \\\"{x:415,y:0,t:1528143604117};\\\", \\\"{x:433,y:0,t:1528143604135};\\\", \\\"{x:506,y:0,t:1528143604152};\\\", \\\"{x:597,y:0,t:1528143604168};\\\", \\\"{x:706,y:0,t:1528143604184};\\\", \\\"{x:811,y:0,t:1528143604201};\\\", \\\"{x:920,y:0,t:1528143604217};\\\", \\\"{x:1015,y:0,t:1528143604234};\\\", \\\"{x:1140,y:0,t:1528143604251};\\\", \\\"{x:1221,y:0,t:1528143604267};\\\", \\\"{x:1292,y:0,t:1528143604285};\\\", \\\"{x:1334,y:0,t:1528143604301};\\\", \\\"{x:1337,y:0,t:1528143604317};\\\", \\\"{x:1335,y:0,t:1528143604339};\\\", \\\"{x:1334,y:0,t:1528143604351};\\\", \\\"{x:1331,y:0,t:1528143604367};\\\", \\\"{x:1327,y:0,t:1528143604384};\\\", \\\"{x:1324,y:0,t:1528143604419};\\\", \\\"{x:1323,y:3,t:1528143604434};\\\", \\\"{x:1324,y:30,t:1528143604451};\\\", \\\"{x:1329,y:49,t:1528143604467};\\\", \\\"{x:1349,y:138,t:1528143604484};\\\", \\\"{x:1393,y:344,t:1528143604501};\\\", \\\"{x:1432,y:628,t:1528143604518};\\\", \\\"{x:1491,y:955,t:1528143604535};\\\", \\\"{x:1557,y:1199,t:1528143604551};\\\", \\\"{x:1644,y:1199,t:1528143604568};\\\", \\\"{x:1736,y:1199,t:1528143604584};\\\", \\\"{x:1841,y:1199,t:1528143604601};\\\", \\\"{x:1919,y:1199,t:1528143604618};\\\", \\\"{x:1918,y:1199,t:1528143604707};\\\", \\\"{x:1915,y:1199,t:1528143604723};\\\", \\\"{x:1913,y:1199,t:1528143604734};\\\", \\\"{x:1907,y:1199,t:1528143604751};\\\", \\\"{x:1901,y:1195,t:1528143604769};\\\", \\\"{x:1890,y:1188,t:1528143604785};\\\", \\\"{x:1871,y:1178,t:1528143604801};\\\", \\\"{x:1849,y:1168,t:1528143604818};\\\", \\\"{x:1831,y:1161,t:1528143604835};\\\", \\\"{x:1819,y:1147,t:1528143604851};\\\", \\\"{x:1815,y:1141,t:1528143604868};\\\", \\\"{x:1811,y:1135,t:1528143604885};\\\", \\\"{x:1807,y:1132,t:1528143604901};\\\", \\\"{x:1798,y:1128,t:1528143604918};\\\", \\\"{x:1780,y:1122,t:1528143604936};\\\", \\\"{x:1747,y:1115,t:1528143604951};\\\", \\\"{x:1680,y:1107,t:1528143604968};\\\", \\\"{x:1605,y:1094,t:1528143604985};\\\", \\\"{x:1544,y:1079,t:1528143605001};\\\", \\\"{x:1485,y:1059,t:1528143605019};\\\", \\\"{x:1375,y:1024,t:1528143605036};\\\", \\\"{x:1286,y:995,t:1528143605051};\\\", \\\"{x:1213,y:969,t:1528143605069};\\\", \\\"{x:1158,y:956,t:1528143605086};\\\", \\\"{x:1137,y:952,t:1528143605102};\\\", \\\"{x:1123,y:950,t:1528143605118};\\\", \\\"{x:1118,y:949,t:1528143605136};\\\", \\\"{x:1115,y:949,t:1528143605152};\\\", \\\"{x:1115,y:948,t:1528143605204};\\\", \\\"{x:1115,y:947,t:1528143605219};\\\", \\\"{x:1114,y:937,t:1528143605236};\\\", \\\"{x:1112,y:921,t:1528143605251};\\\", \\\"{x:1112,y:906,t:1528143605269};\\\", \\\"{x:1112,y:894,t:1528143605285};\\\", \\\"{x:1118,y:883,t:1528143605304};\\\", \\\"{x:1126,y:874,t:1528143605318};\\\", \\\"{x:1140,y:861,t:1528143605335};\\\", \\\"{x:1155,y:852,t:1528143605352};\\\", \\\"{x:1166,y:847,t:1528143605368};\\\", \\\"{x:1169,y:846,t:1528143605386};\\\", \\\"{x:1175,y:846,t:1528143605403};\\\", \\\"{x:1177,y:850,t:1528143605418};\\\", \\\"{x:1184,y:861,t:1528143605435};\\\", \\\"{x:1186,y:861,t:1528143605452};\\\", \\\"{x:1186,y:862,t:1528143605491};\\\", \\\"{x:1187,y:863,t:1528143605524};\\\", \\\"{x:1187,y:864,t:1528143605536};\\\", \\\"{x:1189,y:864,t:1528143605724};\\\", \\\"{x:1190,y:863,t:1528143605740};\\\", \\\"{x:1190,y:862,t:1528143605752};\\\", \\\"{x:1190,y:859,t:1528143605770};\\\", \\\"{x:1190,y:857,t:1528143605785};\\\", \\\"{x:1192,y:853,t:1528143605803};\\\", \\\"{x:1194,y:850,t:1528143605819};\\\", \\\"{x:1195,y:847,t:1528143605835};\\\", \\\"{x:1196,y:847,t:1528143605853};\\\", \\\"{x:1196,y:846,t:1528143605899};\\\", \\\"{x:1196,y:845,t:1528143605907};\\\", \\\"{x:1196,y:844,t:1528143605923};\\\", \\\"{x:1196,y:843,t:1528143605956};\\\", \\\"{x:1197,y:842,t:1528143605972};\\\", \\\"{x:1198,y:841,t:1528143606003};\\\", \\\"{x:1199,y:839,t:1528143606019};\\\", \\\"{x:1199,y:838,t:1528143606036};\\\", \\\"{x:1200,y:837,t:1528143606053};\\\", \\\"{x:1201,y:834,t:1528143606069};\\\", \\\"{x:1202,y:833,t:1528143606091};\\\", \\\"{x:1202,y:832,t:1528143606331};\\\", \\\"{x:1203,y:831,t:1528143606339};\\\", \\\"{x:1204,y:830,t:1528143606353};\\\", \\\"{x:1206,y:829,t:1528143606370};\\\", \\\"{x:1208,y:827,t:1528143606387};\\\", \\\"{x:1209,y:827,t:1528143606406};\\\", \\\"{x:1210,y:826,t:1528143606419};\\\", \\\"{x:1211,y:825,t:1528143606482};\\\", \\\"{x:1211,y:824,t:1528143606692};\\\", \\\"{x:1209,y:824,t:1528143606708};\\\", \\\"{x:1208,y:824,t:1528143606724};\\\", \\\"{x:1208,y:825,t:1528143606747};\\\", \\\"{x:1207,y:825,t:1528143606771};\\\", \\\"{x:1210,y:825,t:1528143607012};\\\", \\\"{x:1215,y:825,t:1528143607021};\\\", \\\"{x:1233,y:825,t:1528143607038};\\\", \\\"{x:1253,y:825,t:1528143607053};\\\", \\\"{x:1278,y:825,t:1528143607071};\\\", \\\"{x:1305,y:825,t:1528143607087};\\\", \\\"{x:1333,y:825,t:1528143607104};\\\", \\\"{x:1358,y:825,t:1528143607120};\\\", \\\"{x:1377,y:825,t:1528143607136};\\\", \\\"{x:1389,y:825,t:1528143607153};\\\", \\\"{x:1392,y:825,t:1528143607171};\\\", \\\"{x:1394,y:825,t:1528143607187};\\\", \\\"{x:1396,y:824,t:1528143607244};\\\", \\\"{x:1398,y:823,t:1528143607254};\\\", \\\"{x:1402,y:821,t:1528143607271};\\\", \\\"{x:1408,y:820,t:1528143607287};\\\", \\\"{x:1412,y:818,t:1528143607305};\\\", \\\"{x:1414,y:817,t:1528143607321};\\\", \\\"{x:1415,y:817,t:1528143607339};\\\", \\\"{x:1417,y:817,t:1528143607364};\\\", \\\"{x:1419,y:817,t:1528143607371};\\\", \\\"{x:1420,y:817,t:1528143607387};\\\", \\\"{x:1427,y:817,t:1528143607404};\\\", \\\"{x:1433,y:817,t:1528143607421};\\\", \\\"{x:1439,y:817,t:1528143607438};\\\", \\\"{x:1452,y:817,t:1528143607454};\\\", \\\"{x:1467,y:820,t:1528143607470};\\\", \\\"{x:1482,y:821,t:1528143607488};\\\", \\\"{x:1495,y:824,t:1528143607505};\\\", \\\"{x:1505,y:825,t:1528143607521};\\\", \\\"{x:1510,y:825,t:1528143607538};\\\", \\\"{x:1511,y:825,t:1528143607554};\\\", \\\"{x:1512,y:826,t:1528143607651};\\\", \\\"{x:1512,y:827,t:1528143607675};\\\", \\\"{x:1512,y:828,t:1528143607687};\\\", \\\"{x:1511,y:828,t:1528143607704};\\\", \\\"{x:1510,y:829,t:1528143607721};\\\", \\\"{x:1509,y:829,t:1528143607738};\\\", \\\"{x:1508,y:830,t:1528143607754};\\\", \\\"{x:1508,y:831,t:1528143607770};\\\", \\\"{x:1506,y:831,t:1528143607787};\\\", \\\"{x:1505,y:831,t:1528143607844};\\\", \\\"{x:1503,y:833,t:1528143607955};\\\", \\\"{x:1502,y:833,t:1528143607994};\\\", \\\"{x:1501,y:833,t:1528143608027};\\\", \\\"{x:1500,y:833,t:1528143608037};\\\", \\\"{x:1499,y:833,t:1528143608075};\\\", \\\"{x:1500,y:833,t:1528143608348};\\\", \\\"{x:1503,y:835,t:1528143608355};\\\", \\\"{x:1515,y:838,t:1528143608372};\\\", \\\"{x:1531,y:844,t:1528143608387};\\\", \\\"{x:1548,y:848,t:1528143608405};\\\", \\\"{x:1562,y:852,t:1528143608422};\\\", \\\"{x:1574,y:855,t:1528143608438};\\\", \\\"{x:1589,y:859,t:1528143608454};\\\", \\\"{x:1611,y:863,t:1528143608472};\\\", \\\"{x:1633,y:865,t:1528143608487};\\\", \\\"{x:1661,y:869,t:1528143608504};\\\", \\\"{x:1688,y:872,t:1528143608522};\\\", \\\"{x:1709,y:875,t:1528143608537};\\\", \\\"{x:1726,y:877,t:1528143608554};\\\", \\\"{x:1738,y:880,t:1528143608571};\\\", \\\"{x:1740,y:880,t:1528143608588};\\\", \\\"{x:1742,y:880,t:1528143608605};\\\", \\\"{x:1743,y:881,t:1528143608803};\\\", \\\"{x:1743,y:882,t:1528143608844};\\\", \\\"{x:1743,y:883,t:1528143609092};\\\", \\\"{x:1740,y:885,t:1528143612884};\\\", \\\"{x:1735,y:886,t:1528143612891};\\\", \\\"{x:1731,y:888,t:1528143612908};\\\", \\\"{x:1728,y:888,t:1528143612925};\\\", \\\"{x:1724,y:888,t:1528143612942};\\\", \\\"{x:1720,y:888,t:1528143612958};\\\", \\\"{x:1718,y:888,t:1528143612975};\\\", \\\"{x:1715,y:888,t:1528143612992};\\\", \\\"{x:1710,y:888,t:1528143613008};\\\", \\\"{x:1702,y:888,t:1528143613025};\\\", \\\"{x:1692,y:888,t:1528143613042};\\\", \\\"{x:1680,y:888,t:1528143613058};\\\", \\\"{x:1667,y:888,t:1528143613075};\\\", \\\"{x:1637,y:886,t:1528143613092};\\\", \\\"{x:1619,y:885,t:1528143613108};\\\", \\\"{x:1602,y:882,t:1528143613125};\\\", \\\"{x:1590,y:881,t:1528143613142};\\\", \\\"{x:1580,y:881,t:1528143613158};\\\", \\\"{x:1572,y:881,t:1528143613175};\\\", \\\"{x:1565,y:881,t:1528143613192};\\\", \\\"{x:1560,y:882,t:1528143613209};\\\", \\\"{x:1551,y:885,t:1528143613225};\\\", \\\"{x:1542,y:886,t:1528143613242};\\\", \\\"{x:1530,y:890,t:1528143613260};\\\", \\\"{x:1525,y:890,t:1528143613275};\\\", \\\"{x:1519,y:891,t:1528143613292};\\\", \\\"{x:1512,y:892,t:1528143613309};\\\", \\\"{x:1507,y:893,t:1528143613326};\\\", \\\"{x:1500,y:894,t:1528143613342};\\\", \\\"{x:1494,y:894,t:1528143613359};\\\", \\\"{x:1488,y:894,t:1528143613375};\\\", \\\"{x:1479,y:894,t:1528143613392};\\\", \\\"{x:1472,y:894,t:1528143613409};\\\", \\\"{x:1464,y:894,t:1528143613425};\\\", \\\"{x:1454,y:894,t:1528143613442};\\\", \\\"{x:1436,y:894,t:1528143613460};\\\", \\\"{x:1425,y:894,t:1528143613475};\\\", \\\"{x:1412,y:894,t:1528143613492};\\\", \\\"{x:1403,y:894,t:1528143613509};\\\", \\\"{x:1394,y:894,t:1528143613525};\\\", \\\"{x:1383,y:894,t:1528143613543};\\\", \\\"{x:1372,y:892,t:1528143613560};\\\", \\\"{x:1360,y:891,t:1528143613575};\\\", \\\"{x:1350,y:889,t:1528143613592};\\\", \\\"{x:1337,y:888,t:1528143613608};\\\", \\\"{x:1323,y:885,t:1528143613625};\\\", \\\"{x:1308,y:884,t:1528143613642};\\\", \\\"{x:1284,y:877,t:1528143613659};\\\", \\\"{x:1268,y:873,t:1528143613676};\\\", \\\"{x:1252,y:865,t:1528143613692};\\\", \\\"{x:1239,y:860,t:1528143613709};\\\", \\\"{x:1227,y:855,t:1528143613726};\\\", \\\"{x:1217,y:851,t:1528143613743};\\\", \\\"{x:1210,y:846,t:1528143613759};\\\", \\\"{x:1208,y:844,t:1528143613776};\\\", \\\"{x:1208,y:843,t:1528143613792};\\\", \\\"{x:1207,y:842,t:1528143613809};\\\", \\\"{x:1207,y:840,t:1528143613826};\\\", \\\"{x:1207,y:839,t:1528143613842};\\\", \\\"{x:1207,y:837,t:1528143613859};\\\", \\\"{x:1207,y:836,t:1528143613876};\\\", \\\"{x:1207,y:835,t:1528143613892};\\\", \\\"{x:1207,y:834,t:1528143613924};\\\", \\\"{x:1207,y:833,t:1528143613939};\\\", \\\"{x:1208,y:832,t:1528143613988};\\\", \\\"{x:1209,y:832,t:1528143613995};\\\", \\\"{x:1209,y:831,t:1528143614009};\\\", \\\"{x:1210,y:831,t:1528143614027};\\\", \\\"{x:1211,y:830,t:1528143614060};\\\", \\\"{x:1212,y:828,t:1528143614107};\\\", \\\"{x:1213,y:828,t:1528143614132};\\\", \\\"{x:1213,y:829,t:1528143616796};\\\", \\\"{x:1204,y:835,t:1528143616813};\\\", \\\"{x:1198,y:847,t:1528143616829};\\\", \\\"{x:1192,y:866,t:1528143616845};\\\", \\\"{x:1184,y:882,t:1528143616861};\\\", \\\"{x:1178,y:897,t:1528143616878};\\\", \\\"{x:1175,y:912,t:1528143616895};\\\", \\\"{x:1173,y:930,t:1528143616911};\\\", \\\"{x:1173,y:949,t:1528143616928};\\\", \\\"{x:1173,y:967,t:1528143616945};\\\", \\\"{x:1173,y:985,t:1528143616961};\\\", \\\"{x:1172,y:997,t:1528143616978};\\\", \\\"{x:1170,y:1015,t:1528143616995};\\\", \\\"{x:1168,y:1022,t:1528143617011};\\\", \\\"{x:1167,y:1027,t:1528143617028};\\\", \\\"{x:1166,y:1027,t:1528143617076};\\\", \\\"{x:1165,y:1027,t:1528143617092};\\\", \\\"{x:1164,y:1027,t:1528143617099};\\\", \\\"{x:1162,y:1027,t:1528143617111};\\\", \\\"{x:1161,y:1026,t:1528143617128};\\\", \\\"{x:1160,y:1021,t:1528143617144};\\\", \\\"{x:1156,y:1011,t:1528143617160};\\\", \\\"{x:1152,y:1000,t:1528143617177};\\\", \\\"{x:1147,y:988,t:1528143617194};\\\", \\\"{x:1142,y:981,t:1528143617212};\\\", \\\"{x:1139,y:974,t:1528143617227};\\\", \\\"{x:1136,y:967,t:1528143617245};\\\", \\\"{x:1136,y:965,t:1528143617262};\\\", \\\"{x:1136,y:964,t:1528143617278};\\\", \\\"{x:1135,y:962,t:1528143617295};\\\", \\\"{x:1136,y:961,t:1528143617783};\\\", \\\"{x:1139,y:955,t:1528143619982};\\\", \\\"{x:1146,y:946,t:1528143620000};\\\", \\\"{x:1153,y:935,t:1528143620017};\\\", \\\"{x:1161,y:922,t:1528143620033};\\\", \\\"{x:1169,y:912,t:1528143620050};\\\", \\\"{x:1178,y:903,t:1528143620068};\\\", \\\"{x:1184,y:898,t:1528143620084};\\\", \\\"{x:1191,y:891,t:1528143620100};\\\", \\\"{x:1197,y:884,t:1528143620118};\\\", \\\"{x:1203,y:878,t:1528143620134};\\\", \\\"{x:1208,y:871,t:1528143620150};\\\", \\\"{x:1210,y:868,t:1528143620167};\\\", \\\"{x:1212,y:863,t:1528143620183};\\\", \\\"{x:1212,y:860,t:1528143620200};\\\", \\\"{x:1213,y:857,t:1528143620217};\\\", \\\"{x:1213,y:855,t:1528143620234};\\\", \\\"{x:1214,y:851,t:1528143620251};\\\", \\\"{x:1215,y:847,t:1528143620268};\\\", \\\"{x:1216,y:844,t:1528143620283};\\\", \\\"{x:1217,y:842,t:1528143620301};\\\", \\\"{x:1217,y:840,t:1528143620317};\\\", \\\"{x:1217,y:839,t:1528143620518};\\\", \\\"{x:1216,y:839,t:1528143620534};\\\", \\\"{x:1212,y:840,t:1528143620550};\\\", \\\"{x:1203,y:845,t:1528143620566};\\\", \\\"{x:1190,y:859,t:1528143620584};\\\", \\\"{x:1176,y:876,t:1528143620600};\\\", \\\"{x:1163,y:896,t:1528143620617};\\\", \\\"{x:1153,y:912,t:1528143620634};\\\", \\\"{x:1146,y:928,t:1528143620649};\\\", \\\"{x:1143,y:938,t:1528143620666};\\\", \\\"{x:1140,y:945,t:1528143620683};\\\", \\\"{x:1140,y:949,t:1528143620700};\\\", \\\"{x:1140,y:951,t:1528143620716};\\\", \\\"{x:1140,y:956,t:1528143620734};\\\", \\\"{x:1140,y:959,t:1528143620751};\\\", \\\"{x:1140,y:961,t:1528143620766};\\\", \\\"{x:1140,y:963,t:1528143620783};\\\", \\\"{x:1140,y:964,t:1528143620801};\\\", \\\"{x:1140,y:965,t:1528143620983};\\\", \\\"{x:1142,y:966,t:1528143621014};\\\", \\\"{x:1143,y:966,t:1528143621031};\\\", \\\"{x:1146,y:968,t:1528143621046};\\\", \\\"{x:1146,y:969,t:1528143621055};\\\", \\\"{x:1148,y:970,t:1528143621068};\\\", \\\"{x:1149,y:970,t:1528143621084};\\\", \\\"{x:1150,y:971,t:1528143621102};\\\", \\\"{x:1151,y:971,t:1528143621135};\\\", \\\"{x:1152,y:971,t:1528143621151};\\\", \\\"{x:1153,y:971,t:1528143621167};\\\", \\\"{x:1155,y:972,t:1528143621184};\\\", \\\"{x:1157,y:972,t:1528143621201};\\\", \\\"{x:1158,y:972,t:1528143621218};\\\", \\\"{x:1160,y:972,t:1528143621234};\\\", \\\"{x:1161,y:972,t:1528143621252};\\\", \\\"{x:1162,y:972,t:1528143621268};\\\", \\\"{x:1163,y:971,t:1528143621284};\\\", \\\"{x:1163,y:969,t:1528143621302};\\\", \\\"{x:1163,y:967,t:1528143621318};\\\", \\\"{x:1163,y:965,t:1528143621333};\\\", \\\"{x:1163,y:964,t:1528143621351};\\\", \\\"{x:1163,y:962,t:1528143621368};\\\", \\\"{x:1163,y:961,t:1528143621406};\\\", \\\"{x:1161,y:960,t:1528143621430};\\\", \\\"{x:1161,y:959,t:1528143621438};\\\", \\\"{x:1160,y:959,t:1528143621450};\\\", \\\"{x:1159,y:959,t:1528143621468};\\\", \\\"{x:1158,y:958,t:1528143621484};\\\", \\\"{x:1156,y:956,t:1528143621501};\\\", \\\"{x:1156,y:955,t:1528143621518};\\\", \\\"{x:1156,y:954,t:1528143621534};\\\", \\\"{x:1156,y:953,t:1528143621551};\\\", \\\"{x:1155,y:953,t:1528143621638};\\\", \\\"{x:1154,y:952,t:1528143621758};\\\", \\\"{x:1155,y:950,t:1528143621782};\\\", \\\"{x:1156,y:948,t:1528143621790};\\\", \\\"{x:1157,y:945,t:1528143621802};\\\", \\\"{x:1157,y:942,t:1528143621819};\\\", \\\"{x:1159,y:938,t:1528143621835};\\\", \\\"{x:1160,y:934,t:1528143621851};\\\", \\\"{x:1161,y:929,t:1528143621869};\\\", \\\"{x:1161,y:927,t:1528143621885};\\\", \\\"{x:1163,y:923,t:1528143621902};\\\", \\\"{x:1163,y:920,t:1528143621919};\\\", \\\"{x:1164,y:918,t:1528143621936};\\\", \\\"{x:1164,y:917,t:1528143621952};\\\", \\\"{x:1164,y:914,t:1528143621968};\\\", \\\"{x:1164,y:913,t:1528143621986};\\\", \\\"{x:1164,y:911,t:1528143622001};\\\", \\\"{x:1164,y:909,t:1528143622018};\\\", \\\"{x:1164,y:905,t:1528143622036};\\\", \\\"{x:1164,y:901,t:1528143622051};\\\", \\\"{x:1165,y:899,t:1528143622068};\\\", \\\"{x:1165,y:898,t:1528143622086};\\\", \\\"{x:1165,y:894,t:1528143622102};\\\", \\\"{x:1166,y:893,t:1528143622119};\\\", \\\"{x:1166,y:892,t:1528143622135};\\\", \\\"{x:1166,y:890,t:1528143622152};\\\", \\\"{x:1166,y:888,t:1528143622168};\\\", \\\"{x:1166,y:885,t:1528143622186};\\\", \\\"{x:1167,y:883,t:1528143622202};\\\", \\\"{x:1167,y:881,t:1528143622219};\\\", \\\"{x:1168,y:879,t:1528143622236};\\\", \\\"{x:1168,y:878,t:1528143622270};\\\", \\\"{x:1169,y:877,t:1528143622286};\\\", \\\"{x:1170,y:876,t:1528143622326};\\\", \\\"{x:1170,y:875,t:1528143622366};\\\", \\\"{x:1170,y:874,t:1528143622423};\\\", \\\"{x:1171,y:873,t:1528143622436};\\\", \\\"{x:1172,y:872,t:1528143622454};\\\", \\\"{x:1173,y:872,t:1528143622551};\\\", \\\"{x:1173,y:871,t:1528143622557};\\\", \\\"{x:1174,y:871,t:1528143622605};\\\", \\\"{x:1174,y:870,t:1528143622630};\\\", \\\"{x:1175,y:870,t:1528143622670};\\\", \\\"{x:1176,y:869,t:1528143622751};\\\", \\\"{x:1176,y:868,t:1528143622870};\\\", \\\"{x:1177,y:868,t:1528143623175};\\\", \\\"{x:1178,y:868,t:1528143623190};\\\", \\\"{x:1179,y:868,t:1528143623255};\\\", \\\"{x:1179,y:866,t:1528143623294};\\\", \\\"{x:1180,y:866,t:1528143623310};\\\", \\\"{x:1181,y:865,t:1528143623334};\\\", \\\"{x:1182,y:864,t:1528143623479};\\\", \\\"{x:1182,y:863,t:1528143623486};\\\", \\\"{x:1185,y:861,t:1528143623503};\\\", \\\"{x:1186,y:860,t:1528143623519};\\\", \\\"{x:1189,y:853,t:1528143623537};\\\", \\\"{x:1194,y:846,t:1528143623554};\\\", \\\"{x:1202,y:835,t:1528143623570};\\\", \\\"{x:1213,y:822,t:1528143623586};\\\", \\\"{x:1229,y:804,t:1528143623604};\\\", \\\"{x:1275,y:744,t:1528143623619};\\\", \\\"{x:1308,y:696,t:1528143623637};\\\", \\\"{x:1318,y:676,t:1528143623653};\\\", \\\"{x:1325,y:660,t:1528143623670};\\\", \\\"{x:1332,y:640,t:1528143623686};\\\", \\\"{x:1334,y:631,t:1528143623704};\\\", \\\"{x:1335,y:627,t:1528143623720};\\\", \\\"{x:1335,y:626,t:1528143623736};\\\", \\\"{x:1338,y:618,t:1528143623951};\\\", \\\"{x:1340,y:614,t:1528143623958};\\\", \\\"{x:1342,y:609,t:1528143623970};\\\", \\\"{x:1351,y:597,t:1528143623987};\\\", \\\"{x:1367,y:581,t:1528143624003};\\\", \\\"{x:1375,y:554,t:1528143624020};\\\", \\\"{x:1378,y:535,t:1528143624037};\\\", \\\"{x:1380,y:514,t:1528143624054};\\\", \\\"{x:1383,y:494,t:1528143624070};\\\", \\\"{x:1391,y:470,t:1528143624087};\\\", \\\"{x:1397,y:454,t:1528143624104};\\\", \\\"{x:1402,y:443,t:1528143624121};\\\", \\\"{x:1404,y:437,t:1528143624137};\\\", \\\"{x:1407,y:423,t:1528143624153};\\\", \\\"{x:1408,y:413,t:1528143624170};\\\", \\\"{x:1409,y:410,t:1528143624187};\\\", \\\"{x:1409,y:409,t:1528143624203};\\\", \\\"{x:1409,y:408,t:1528143624223};\\\", \\\"{x:1410,y:408,t:1528143624366};\\\", \\\"{x:1410,y:409,t:1528143624375};\\\", \\\"{x:1410,y:410,t:1528143624387};\\\", \\\"{x:1411,y:414,t:1528143624404};\\\", \\\"{x:1412,y:416,t:1528143624421};\\\", \\\"{x:1413,y:418,t:1528143624437};\\\", \\\"{x:1413,y:419,t:1528143624453};\\\", \\\"{x:1414,y:420,t:1528143624470};\\\", \\\"{x:1415,y:422,t:1528143624487};\\\", \\\"{x:1415,y:423,t:1528143624790};\\\", \\\"{x:1415,y:425,t:1528143624805};\\\", \\\"{x:1415,y:428,t:1528143624820};\\\", \\\"{x:1414,y:432,t:1528143624837};\\\", \\\"{x:1413,y:436,t:1528143624855};\\\", \\\"{x:1413,y:437,t:1528143624870};\\\", \\\"{x:1413,y:439,t:1528143624888};\\\", \\\"{x:1412,y:439,t:1528143624905};\\\", \\\"{x:1412,y:442,t:1528143624920};\\\", \\\"{x:1411,y:445,t:1528143624938};\\\", \\\"{x:1409,y:449,t:1528143624954};\\\", \\\"{x:1407,y:460,t:1528143624971};\\\", \\\"{x:1406,y:470,t:1528143624988};\\\", \\\"{x:1404,y:485,t:1528143625004};\\\", \\\"{x:1402,y:498,t:1528143625021};\\\", \\\"{x:1401,y:513,t:1528143625038};\\\", \\\"{x:1395,y:534,t:1528143625054};\\\", \\\"{x:1392,y:550,t:1528143625070};\\\", \\\"{x:1390,y:560,t:1528143625088};\\\", \\\"{x:1388,y:578,t:1528143625105};\\\", \\\"{x:1386,y:596,t:1528143625121};\\\", \\\"{x:1383,y:618,t:1528143625138};\\\", \\\"{x:1381,y:640,t:1528143625154};\\\", \\\"{x:1380,y:661,t:1528143625171};\\\", \\\"{x:1380,y:681,t:1528143625188};\\\", \\\"{x:1377,y:699,t:1528143625205};\\\", \\\"{x:1373,y:716,t:1528143625221};\\\", \\\"{x:1373,y:727,t:1528143625238};\\\", \\\"{x:1370,y:737,t:1528143625254};\\\", \\\"{x:1370,y:740,t:1528143625272};\\\", \\\"{x:1370,y:745,t:1528143625288};\\\", \\\"{x:1370,y:747,t:1528143625304};\\\", \\\"{x:1369,y:752,t:1528143625322};\\\", \\\"{x:1368,y:755,t:1528143625337};\\\", \\\"{x:1366,y:761,t:1528143625354};\\\", \\\"{x:1366,y:767,t:1528143625372};\\\", \\\"{x:1365,y:777,t:1528143625388};\\\", \\\"{x:1364,y:787,t:1528143625404};\\\", \\\"{x:1361,y:798,t:1528143625421};\\\", \\\"{x:1360,y:814,t:1528143625437};\\\", \\\"{x:1356,y:839,t:1528143625454};\\\", \\\"{x:1355,y:854,t:1528143625471};\\\", \\\"{x:1354,y:864,t:1528143625488};\\\", \\\"{x:1352,y:874,t:1528143625505};\\\", \\\"{x:1350,y:887,t:1528143625522};\\\", \\\"{x:1349,y:897,t:1528143625538};\\\", \\\"{x:1347,y:902,t:1528143625555};\\\", \\\"{x:1346,y:906,t:1528143625572};\\\", \\\"{x:1346,y:909,t:1528143625588};\\\", \\\"{x:1346,y:912,t:1528143625605};\\\", \\\"{x:1346,y:914,t:1528143625630};\\\", \\\"{x:1346,y:915,t:1528143625663};\\\", \\\"{x:1346,y:917,t:1528143625686};\\\", \\\"{x:1346,y:918,t:1528143625743};\\\", \\\"{x:1347,y:917,t:1528143625799};\\\", \\\"{x:1348,y:913,t:1528143625806};\\\", \\\"{x:1350,y:911,t:1528143625822};\\\", \\\"{x:1354,y:907,t:1528143625838};\\\", \\\"{x:1356,y:905,t:1528143625854};\\\", \\\"{x:1357,y:903,t:1528143625878};\\\", \\\"{x:1358,y:903,t:1528143625894};\\\", \\\"{x:1359,y:902,t:1528143625934};\\\", \\\"{x:1360,y:901,t:1528143625943};\\\", \\\"{x:1362,y:900,t:1528143625954};\\\", \\\"{x:1367,y:898,t:1528143625971};\\\", \\\"{x:1371,y:895,t:1528143625989};\\\", \\\"{x:1374,y:893,t:1528143626005};\\\", \\\"{x:1375,y:892,t:1528143626022};\\\", \\\"{x:1379,y:891,t:1528143626039};\\\", \\\"{x:1380,y:891,t:1528143626055};\\\", \\\"{x:1382,y:889,t:1528143626071};\\\", \\\"{x:1381,y:889,t:1528143626551};\\\", \\\"{x:1380,y:891,t:1528143627151};\\\", \\\"{x:1380,y:893,t:1528143627159};\\\", \\\"{x:1380,y:894,t:1528143627190};\\\", \\\"{x:1380,y:895,t:1528143627205};\\\", \\\"{x:1379,y:897,t:1528143627223};\\\", \\\"{x:1379,y:898,t:1528143627319};\\\", \\\"{x:1378,y:898,t:1528143628214};\\\", \\\"{x:1376,y:902,t:1528143628225};\\\", \\\"{x:1369,y:912,t:1528143628239};\\\", \\\"{x:1365,y:920,t:1528143628257};\\\", \\\"{x:1359,y:933,t:1528143628273};\\\", \\\"{x:1350,y:953,t:1528143628289};\\\", \\\"{x:1342,y:975,t:1528143628307};\\\", \\\"{x:1333,y:996,t:1528143628324};\\\", \\\"{x:1325,y:1014,t:1528143628340};\\\", \\\"{x:1320,y:1025,t:1528143628357};\\\", \\\"{x:1315,y:1038,t:1528143628373};\\\", \\\"{x:1310,y:1060,t:1528143628390};\\\", \\\"{x:1309,y:1070,t:1528143628407};\\\", \\\"{x:1308,y:1072,t:1528143628423};\\\", \\\"{x:1308,y:1065,t:1528143628470};\\\", \\\"{x:1308,y:1055,t:1528143628478};\\\", \\\"{x:1308,y:1048,t:1528143628491};\\\", \\\"{x:1309,y:1038,t:1528143628507};\\\", \\\"{x:1313,y:1026,t:1528143628523};\\\", \\\"{x:1317,y:1016,t:1528143628541};\\\", \\\"{x:1321,y:1004,t:1528143628557};\\\", \\\"{x:1324,y:990,t:1528143628574};\\\", \\\"{x:1328,y:972,t:1528143628591};\\\", \\\"{x:1331,y:965,t:1528143628607};\\\", \\\"{x:1332,y:958,t:1528143628623};\\\", \\\"{x:1338,y:949,t:1528143628641};\\\", \\\"{x:1342,y:940,t:1528143628657};\\\", \\\"{x:1346,y:934,t:1528143628674};\\\", \\\"{x:1351,y:925,t:1528143628691};\\\", \\\"{x:1359,y:915,t:1528143628707};\\\", \\\"{x:1368,y:905,t:1528143628724};\\\", \\\"{x:1374,y:899,t:1528143628741};\\\", \\\"{x:1375,y:897,t:1528143628757};\\\", \\\"{x:1376,y:897,t:1528143628774};\\\", \\\"{x:1376,y:896,t:1528143628790};\\\", \\\"{x:1377,y:896,t:1528143628822};\\\", \\\"{x:1379,y:896,t:1528143629015};\\\", \\\"{x:1382,y:900,t:1528143629023};\\\", \\\"{x:1386,y:914,t:1528143629042};\\\", \\\"{x:1392,y:925,t:1528143629058};\\\", \\\"{x:1401,y:940,t:1528143629074};\\\", \\\"{x:1413,y:952,t:1528143629091};\\\", \\\"{x:1427,y:963,t:1528143629108};\\\", \\\"{x:1438,y:971,t:1528143629124};\\\", \\\"{x:1447,y:977,t:1528143629141};\\\", \\\"{x:1452,y:980,t:1528143629158};\\\", \\\"{x:1455,y:981,t:1528143629174};\\\", \\\"{x:1455,y:982,t:1528143629191};\\\", \\\"{x:1456,y:982,t:1528143629208};\\\", \\\"{x:1455,y:978,t:1528143629478};\\\", \\\"{x:1450,y:968,t:1528143629491};\\\", \\\"{x:1442,y:957,t:1528143629508};\\\", \\\"{x:1433,y:947,t:1528143629525};\\\", \\\"{x:1424,y:938,t:1528143629541};\\\", \\\"{x:1415,y:932,t:1528143629558};\\\", \\\"{x:1414,y:931,t:1528143629574};\\\", \\\"{x:1413,y:930,t:1528143629590};\\\", \\\"{x:1412,y:929,t:1528143629608};\\\", \\\"{x:1411,y:929,t:1528143629702};\\\", \\\"{x:1410,y:929,t:1528143629710};\\\", \\\"{x:1409,y:928,t:1528143629725};\\\", \\\"{x:1406,y:926,t:1528143629741};\\\", \\\"{x:1404,y:925,t:1528143629757};\\\", \\\"{x:1400,y:922,t:1528143629774};\\\", \\\"{x:1396,y:920,t:1528143629791};\\\", \\\"{x:1390,y:916,t:1528143629807};\\\", \\\"{x:1388,y:915,t:1528143629824};\\\", \\\"{x:1384,y:912,t:1528143629841};\\\", \\\"{x:1383,y:910,t:1528143629857};\\\", \\\"{x:1382,y:909,t:1528143629878};\\\", \\\"{x:1382,y:907,t:1528143629917};\\\", \\\"{x:1382,y:906,t:1528143629933};\\\", \\\"{x:1382,y:904,t:1528143629950};\\\", \\\"{x:1382,y:902,t:1528143629958};\\\", \\\"{x:1382,y:900,t:1528143629974};\\\", \\\"{x:1381,y:897,t:1528143629991};\\\", \\\"{x:1381,y:896,t:1528143630008};\\\", \\\"{x:1381,y:895,t:1528143630025};\\\", \\\"{x:1381,y:894,t:1528143630042};\\\", \\\"{x:1381,y:893,t:1528143630058};\\\", \\\"{x:1380,y:892,t:1528143630790};\\\", \\\"{x:1379,y:893,t:1528143630839};\\\", \\\"{x:1378,y:894,t:1528143630887};\\\", \\\"{x:1380,y:891,t:1528143631759};\\\", \\\"{x:1385,y:882,t:1528143631776};\\\", \\\"{x:1391,y:874,t:1528143631793};\\\", \\\"{x:1395,y:866,t:1528143631810};\\\", \\\"{x:1404,y:855,t:1528143631825};\\\", \\\"{x:1415,y:840,t:1528143631843};\\\", \\\"{x:1429,y:818,t:1528143631860};\\\", \\\"{x:1452,y:770,t:1528143631876};\\\", \\\"{x:1494,y:678,t:1528143631893};\\\", \\\"{x:1542,y:594,t:1528143631910};\\\", \\\"{x:1570,y:552,t:1528143631927};\\\", \\\"{x:1594,y:518,t:1528143631944};\\\", \\\"{x:1617,y:484,t:1528143631960};\\\", \\\"{x:1629,y:467,t:1528143631976};\\\", \\\"{x:1636,y:457,t:1528143631993};\\\", \\\"{x:1637,y:453,t:1528143632010};\\\", \\\"{x:1637,y:452,t:1528143632046};\\\", \\\"{x:1637,y:451,t:1528143632060};\\\", \\\"{x:1638,y:450,t:1528143632077};\\\", \\\"{x:1636,y:453,t:1528143632159};\\\", \\\"{x:1635,y:456,t:1528143632166};\\\", \\\"{x:1632,y:461,t:1528143632177};\\\", \\\"{x:1629,y:469,t:1528143632193};\\\", \\\"{x:1622,y:478,t:1528143632210};\\\", \\\"{x:1616,y:486,t:1528143632227};\\\", \\\"{x:1612,y:490,t:1528143632243};\\\", \\\"{x:1612,y:491,t:1528143632260};\\\", \\\"{x:1611,y:491,t:1528143632358};\\\", \\\"{x:1609,y:492,t:1528143632365};\\\", \\\"{x:1606,y:494,t:1528143632376};\\\", \\\"{x:1600,y:496,t:1528143632393};\\\", \\\"{x:1595,y:498,t:1528143632409};\\\", \\\"{x:1586,y:503,t:1528143632426};\\\", \\\"{x:1575,y:507,t:1528143632443};\\\", \\\"{x:1567,y:511,t:1528143632459};\\\", \\\"{x:1560,y:514,t:1528143632476};\\\", \\\"{x:1547,y:527,t:1528143632493};\\\", \\\"{x:1531,y:546,t:1528143632509};\\\", \\\"{x:1509,y:585,t:1528143632526};\\\", \\\"{x:1483,y:651,t:1528143632544};\\\", \\\"{x:1455,y:743,t:1528143632559};\\\", \\\"{x:1442,y:843,t:1528143632577};\\\", \\\"{x:1440,y:913,t:1528143632593};\\\", \\\"{x:1440,y:943,t:1528143632610};\\\", \\\"{x:1438,y:963,t:1528143632626};\\\", \\\"{x:1434,y:985,t:1528143632644};\\\", \\\"{x:1432,y:1000,t:1528143632659};\\\", \\\"{x:1431,y:1010,t:1528143632676};\\\", \\\"{x:1430,y:1012,t:1528143632693};\\\", \\\"{x:1430,y:1013,t:1528143632710};\\\", \\\"{x:1430,y:1015,t:1528143632726};\\\", \\\"{x:1427,y:1018,t:1528143632744};\\\", \\\"{x:1423,y:1021,t:1528143632760};\\\", \\\"{x:1420,y:1021,t:1528143632777};\\\", \\\"{x:1418,y:1021,t:1528143632794};\\\", \\\"{x:1417,y:1021,t:1528143632810};\\\", \\\"{x:1416,y:1020,t:1528143632846};\\\", \\\"{x:1414,y:1015,t:1528143632860};\\\", \\\"{x:1409,y:999,t:1528143632876};\\\", \\\"{x:1401,y:974,t:1528143632894};\\\", \\\"{x:1395,y:959,t:1528143632910};\\\", \\\"{x:1391,y:952,t:1528143632927};\\\", \\\"{x:1390,y:950,t:1528143632944};\\\", \\\"{x:1390,y:949,t:1528143632961};\\\", \\\"{x:1389,y:947,t:1528143632977};\\\", \\\"{x:1388,y:946,t:1528143632994};\\\", \\\"{x:1388,y:944,t:1528143633011};\\\", \\\"{x:1387,y:943,t:1528143633027};\\\", \\\"{x:1387,y:940,t:1528143633044};\\\", \\\"{x:1385,y:939,t:1528143633061};\\\", \\\"{x:1385,y:938,t:1528143633077};\\\", \\\"{x:1385,y:937,t:1528143633094};\\\", \\\"{x:1384,y:936,t:1528143633183};\\\", \\\"{x:1384,y:934,t:1528143633302};\\\", \\\"{x:1383,y:932,t:1528143633311};\\\", \\\"{x:1380,y:926,t:1528143633328};\\\", \\\"{x:1378,y:921,t:1528143633344};\\\", \\\"{x:1377,y:920,t:1528143633361};\\\", \\\"{x:1377,y:919,t:1528143633390};\\\", \\\"{x:1377,y:917,t:1528143633414};\\\", \\\"{x:1377,y:915,t:1528143633428};\\\", \\\"{x:1377,y:912,t:1528143633444};\\\", \\\"{x:1377,y:911,t:1528143633460};\\\", \\\"{x:1377,y:909,t:1528143633478};\\\", \\\"{x:1377,y:908,t:1528143633494};\\\", \\\"{x:1377,y:904,t:1528143633511};\\\", \\\"{x:1377,y:899,t:1528143633528};\\\", \\\"{x:1377,y:897,t:1528143633544};\\\", \\\"{x:1377,y:895,t:1528143633561};\\\", \\\"{x:1377,y:894,t:1528143633577};\\\", \\\"{x:1377,y:893,t:1528143633598};\\\", \\\"{x:1377,y:892,t:1528143633614};\\\", \\\"{x:1377,y:891,t:1528143633672};\\\", \\\"{x:1377,y:892,t:1528143633959};\\\", \\\"{x:1377,y:893,t:1528143633978};\\\", \\\"{x:1377,y:895,t:1528143633994};\\\", \\\"{x:1377,y:897,t:1528143634010};\\\", \\\"{x:1375,y:899,t:1528143634029};\\\", \\\"{x:1375,y:900,t:1528143634045};\\\", \\\"{x:1375,y:901,t:1528143634062};\\\", \\\"{x:1375,y:903,t:1528143634078};\\\", \\\"{x:1375,y:905,t:1528143634094};\\\", \\\"{x:1375,y:908,t:1528143634112};\\\", \\\"{x:1375,y:913,t:1528143634128};\\\", \\\"{x:1375,y:922,t:1528143634145};\\\", \\\"{x:1376,y:928,t:1528143634161};\\\", \\\"{x:1376,y:939,t:1528143634177};\\\", \\\"{x:1376,y:945,t:1528143634194};\\\", \\\"{x:1376,y:950,t:1528143634211};\\\", \\\"{x:1376,y:953,t:1528143634227};\\\", \\\"{x:1375,y:958,t:1528143634244};\\\", \\\"{x:1373,y:966,t:1528143634261};\\\", \\\"{x:1371,y:970,t:1528143634277};\\\", \\\"{x:1369,y:974,t:1528143634295};\\\", \\\"{x:1367,y:977,t:1528143634311};\\\", \\\"{x:1366,y:980,t:1528143634328};\\\", \\\"{x:1363,y:982,t:1528143634345};\\\", \\\"{x:1363,y:984,t:1528143634362};\\\", \\\"{x:1362,y:984,t:1528143634398};\\\", \\\"{x:1362,y:985,t:1528143634495};\\\", \\\"{x:1360,y:985,t:1528143634511};\\\", \\\"{x:1358,y:985,t:1528143634528};\\\", \\\"{x:1357,y:985,t:1528143634591};\\\", \\\"{x:1355,y:985,t:1528143634606};\\\", \\\"{x:1354,y:984,t:1528143634614};\\\", \\\"{x:1353,y:983,t:1528143634629};\\\", \\\"{x:1352,y:980,t:1528143634645};\\\", \\\"{x:1350,y:977,t:1528143634662};\\\", \\\"{x:1348,y:976,t:1528143634678};\\\", \\\"{x:1346,y:974,t:1528143634695};\\\", \\\"{x:1344,y:972,t:1528143634712};\\\", \\\"{x:1343,y:970,t:1528143634728};\\\", \\\"{x:1342,y:968,t:1528143634746};\\\", \\\"{x:1341,y:967,t:1528143634774};\\\", \\\"{x:1343,y:968,t:1528143634822};\\\", \\\"{x:1346,y:971,t:1528143634830};\\\", \\\"{x:1353,y:974,t:1528143634845};\\\", \\\"{x:1377,y:982,t:1528143634863};\\\", \\\"{x:1398,y:985,t:1528143634878};\\\", \\\"{x:1419,y:989,t:1528143634895};\\\", \\\"{x:1437,y:990,t:1528143634912};\\\", \\\"{x:1451,y:990,t:1528143634929};\\\", \\\"{x:1458,y:990,t:1528143634945};\\\", \\\"{x:1462,y:988,t:1528143634962};\\\", \\\"{x:1462,y:986,t:1528143634979};\\\", \\\"{x:1462,y:982,t:1528143634996};\\\", \\\"{x:1462,y:979,t:1528143635012};\\\", \\\"{x:1461,y:974,t:1528143635029};\\\", \\\"{x:1455,y:965,t:1528143635046};\\\", \\\"{x:1448,y:960,t:1528143635062};\\\", \\\"{x:1439,y:955,t:1528143635079};\\\", \\\"{x:1431,y:953,t:1528143635096};\\\", \\\"{x:1425,y:952,t:1528143635112};\\\", \\\"{x:1419,y:952,t:1528143635129};\\\", \\\"{x:1417,y:952,t:1528143635146};\\\", \\\"{x:1416,y:952,t:1528143635162};\\\", \\\"{x:1415,y:953,t:1528143635279};\\\", \\\"{x:1415,y:955,t:1528143635296};\\\", \\\"{x:1415,y:956,t:1528143635312};\\\", \\\"{x:1415,y:958,t:1528143635329};\\\", \\\"{x:1415,y:959,t:1528143635407};\\\", \\\"{x:1415,y:961,t:1528143635414};\\\", \\\"{x:1415,y:962,t:1528143635429};\\\", \\\"{x:1415,y:970,t:1528143635446};\\\", \\\"{x:1416,y:975,t:1528143635463};\\\", \\\"{x:1417,y:977,t:1528143635479};\\\", \\\"{x:1418,y:980,t:1528143635496};\\\", \\\"{x:1419,y:980,t:1528143635512};\\\", \\\"{x:1421,y:982,t:1528143635529};\\\", \\\"{x:1426,y:984,t:1528143635547};\\\", \\\"{x:1430,y:985,t:1528143635564};\\\", \\\"{x:1434,y:987,t:1528143635579};\\\", \\\"{x:1440,y:988,t:1528143635596};\\\", \\\"{x:1446,y:988,t:1528143635613};\\\", \\\"{x:1453,y:988,t:1528143635629};\\\", \\\"{x:1459,y:989,t:1528143635646};\\\", \\\"{x:1461,y:989,t:1528143635663};\\\", \\\"{x:1462,y:989,t:1528143635702};\\\", \\\"{x:1463,y:989,t:1528143635713};\\\", \\\"{x:1463,y:985,t:1528143635729};\\\", \\\"{x:1465,y:981,t:1528143635746};\\\", \\\"{x:1466,y:978,t:1528143635763};\\\", \\\"{x:1466,y:975,t:1528143635779};\\\", \\\"{x:1466,y:972,t:1528143635795};\\\", \\\"{x:1466,y:970,t:1528143635813};\\\", \\\"{x:1466,y:968,t:1528143635829};\\\", \\\"{x:1466,y:966,t:1528143635845};\\\", \\\"{x:1466,y:965,t:1528143635862};\\\", \\\"{x:1466,y:963,t:1528143635879};\\\", \\\"{x:1466,y:962,t:1528143635895};\\\", \\\"{x:1468,y:961,t:1528143635912};\\\", \\\"{x:1468,y:960,t:1528143635929};\\\", \\\"{x:1469,y:959,t:1528143635946};\\\", \\\"{x:1471,y:958,t:1528143635962};\\\", \\\"{x:1472,y:958,t:1528143636167};\\\", \\\"{x:1474,y:960,t:1528143636180};\\\", \\\"{x:1477,y:967,t:1528143636196};\\\", \\\"{x:1480,y:969,t:1528143636213};\\\", \\\"{x:1481,y:972,t:1528143636230};\\\", \\\"{x:1482,y:973,t:1528143636246};\\\", \\\"{x:1483,y:973,t:1528143636278};\\\", \\\"{x:1483,y:974,t:1528143636302};\\\", \\\"{x:1485,y:975,t:1528143636313};\\\", \\\"{x:1486,y:977,t:1528143636330};\\\", \\\"{x:1488,y:978,t:1528143636347};\\\", \\\"{x:1489,y:980,t:1528143636363};\\\", \\\"{x:1491,y:981,t:1528143636380};\\\", \\\"{x:1497,y:984,t:1528143636397};\\\", \\\"{x:1501,y:986,t:1528143636414};\\\", \\\"{x:1507,y:989,t:1528143636430};\\\", \\\"{x:1512,y:990,t:1528143636447};\\\", \\\"{x:1515,y:990,t:1528143636463};\\\", \\\"{x:1519,y:990,t:1528143636480};\\\", \\\"{x:1522,y:990,t:1528143636497};\\\", \\\"{x:1525,y:990,t:1528143636513};\\\", \\\"{x:1528,y:990,t:1528143636530};\\\", \\\"{x:1529,y:991,t:1528143636547};\\\", \\\"{x:1530,y:991,t:1528143636563};\\\", \\\"{x:1531,y:991,t:1528143636582};\\\", \\\"{x:1532,y:991,t:1528143636598};\\\", \\\"{x:1534,y:991,t:1528143636613};\\\", \\\"{x:1541,y:991,t:1528143636630};\\\", \\\"{x:1546,y:990,t:1528143636647};\\\", \\\"{x:1553,y:988,t:1528143636663};\\\", \\\"{x:1559,y:986,t:1528143636680};\\\", \\\"{x:1561,y:986,t:1528143636697};\\\", \\\"{x:1563,y:984,t:1528143636714};\\\", \\\"{x:1563,y:983,t:1528143636731};\\\", \\\"{x:1564,y:982,t:1528143636747};\\\", \\\"{x:1564,y:981,t:1528143636764};\\\", \\\"{x:1564,y:979,t:1528143636780};\\\", \\\"{x:1565,y:978,t:1528143636797};\\\", \\\"{x:1566,y:976,t:1528143636814};\\\", \\\"{x:1566,y:974,t:1528143636830};\\\", \\\"{x:1566,y:973,t:1528143636847};\\\", \\\"{x:1566,y:972,t:1528143636864};\\\", \\\"{x:1566,y:971,t:1528143636886};\\\", \\\"{x:1566,y:970,t:1528143636902};\\\", \\\"{x:1566,y:969,t:1528143636934};\\\", \\\"{x:1566,y:968,t:1528143636950};\\\", \\\"{x:1566,y:967,t:1528143636966};\\\", \\\"{x:1565,y:966,t:1528143637094};\\\", \\\"{x:1564,y:966,t:1528143637142};\\\", \\\"{x:1564,y:967,t:1528143637150};\\\", \\\"{x:1564,y:969,t:1528143637164};\\\", \\\"{x:1564,y:971,t:1528143637180};\\\", \\\"{x:1564,y:973,t:1528143637198};\\\", \\\"{x:1564,y:976,t:1528143637214};\\\", \\\"{x:1564,y:977,t:1528143637246};\\\", \\\"{x:1564,y:979,t:1528143637264};\\\", \\\"{x:1564,y:980,t:1528143637281};\\\", \\\"{x:1564,y:982,t:1528143637297};\\\", \\\"{x:1564,y:984,t:1528143637318};\\\", \\\"{x:1564,y:985,t:1528143637351};\\\", \\\"{x:1566,y:986,t:1528143637382};\\\", \\\"{x:1568,y:988,t:1528143637398};\\\", \\\"{x:1570,y:989,t:1528143637413};\\\", \\\"{x:1571,y:989,t:1528143637438};\\\", \\\"{x:1574,y:989,t:1528143637502};\\\", \\\"{x:1577,y:989,t:1528143637514};\\\", \\\"{x:1581,y:989,t:1528143637532};\\\", \\\"{x:1585,y:989,t:1528143637547};\\\", \\\"{x:1588,y:989,t:1528143637564};\\\", \\\"{x:1596,y:990,t:1528143637581};\\\", \\\"{x:1604,y:990,t:1528143637597};\\\", \\\"{x:1613,y:990,t:1528143637614};\\\", \\\"{x:1616,y:990,t:1528143637631};\\\", \\\"{x:1620,y:990,t:1528143637648};\\\", \\\"{x:1624,y:989,t:1528143637664};\\\", \\\"{x:1625,y:989,t:1528143637681};\\\", \\\"{x:1625,y:988,t:1528143637698};\\\", \\\"{x:1626,y:987,t:1528143637714};\\\", \\\"{x:1628,y:984,t:1528143637731};\\\", \\\"{x:1629,y:981,t:1528143637748};\\\", \\\"{x:1630,y:975,t:1528143637764};\\\", \\\"{x:1630,y:971,t:1528143637781};\\\", \\\"{x:1630,y:967,t:1528143637799};\\\", \\\"{x:1630,y:966,t:1528143637814};\\\", \\\"{x:1630,y:964,t:1528143637832};\\\", \\\"{x:1630,y:963,t:1528143637848};\\\", \\\"{x:1630,y:961,t:1528143637865};\\\", \\\"{x:1629,y:960,t:1528143637997};\\\", \\\"{x:1629,y:961,t:1528143638045};\\\", \\\"{x:1629,y:963,t:1528143638053};\\\", \\\"{x:1629,y:967,t:1528143638063};\\\", \\\"{x:1629,y:971,t:1528143638081};\\\", \\\"{x:1629,y:974,t:1528143638097};\\\", \\\"{x:1629,y:976,t:1528143638114};\\\", \\\"{x:1629,y:978,t:1528143638130};\\\", \\\"{x:1629,y:979,t:1528143638148};\\\", \\\"{x:1629,y:980,t:1528143638165};\\\", \\\"{x:1629,y:981,t:1528143638181};\\\", \\\"{x:1631,y:983,t:1528143638198};\\\", \\\"{x:1633,y:985,t:1528143638214};\\\", \\\"{x:1634,y:986,t:1528143638231};\\\", \\\"{x:1636,y:988,t:1528143638248};\\\", \\\"{x:1637,y:988,t:1528143638278};\\\", \\\"{x:1638,y:988,t:1528143638286};\\\", \\\"{x:1639,y:988,t:1528143638303};\\\", \\\"{x:1640,y:988,t:1528143638315};\\\", \\\"{x:1643,y:989,t:1528143638331};\\\", \\\"{x:1647,y:989,t:1528143638348};\\\", \\\"{x:1652,y:991,t:1528143638365};\\\", \\\"{x:1658,y:991,t:1528143638381};\\\", \\\"{x:1662,y:991,t:1528143638398};\\\", \\\"{x:1664,y:991,t:1528143638415};\\\", \\\"{x:1665,y:991,t:1528143638431};\\\", \\\"{x:1667,y:990,t:1528143638454};\\\", \\\"{x:1667,y:989,t:1528143638465};\\\", \\\"{x:1671,y:987,t:1528143638482};\\\", \\\"{x:1675,y:983,t:1528143638499};\\\", \\\"{x:1677,y:980,t:1528143638515};\\\", \\\"{x:1679,y:977,t:1528143638531};\\\", \\\"{x:1681,y:973,t:1528143638548};\\\", \\\"{x:1682,y:970,t:1528143638565};\\\", \\\"{x:1682,y:964,t:1528143638582};\\\", \\\"{x:1684,y:962,t:1528143638598};\\\", \\\"{x:1685,y:960,t:1528143638615};\\\", \\\"{x:1685,y:958,t:1528143638631};\\\", \\\"{x:1685,y:956,t:1528143638647};\\\", \\\"{x:1685,y:955,t:1528143638664};\\\", \\\"{x:1685,y:956,t:1528143638798};\\\", \\\"{x:1685,y:957,t:1528143638816};\\\", \\\"{x:1685,y:960,t:1528143638832};\\\", \\\"{x:1685,y:963,t:1528143638848};\\\", \\\"{x:1685,y:964,t:1528143638865};\\\", \\\"{x:1688,y:970,t:1528143638883};\\\", \\\"{x:1690,y:974,t:1528143638898};\\\", \\\"{x:1693,y:979,t:1528143638915};\\\", \\\"{x:1694,y:980,t:1528143638931};\\\", \\\"{x:1695,y:980,t:1528143638948};\\\", \\\"{x:1696,y:981,t:1528143638965};\\\", \\\"{x:1697,y:982,t:1528143639023};\\\", \\\"{x:1698,y:982,t:1528143639062};\\\", \\\"{x:1698,y:983,t:1528143639077};\\\", \\\"{x:1699,y:983,t:1528143639102};\\\", \\\"{x:1700,y:983,t:1528143639115};\\\", \\\"{x:1702,y:985,t:1528143639132};\\\", \\\"{x:1705,y:986,t:1528143639149};\\\", \\\"{x:1708,y:988,t:1528143639165};\\\", \\\"{x:1709,y:988,t:1528143639181};\\\", \\\"{x:1711,y:989,t:1528143639198};\\\", \\\"{x:1712,y:989,t:1528143639215};\\\", \\\"{x:1714,y:990,t:1528143639232};\\\", \\\"{x:1716,y:991,t:1528143639248};\\\", \\\"{x:1718,y:992,t:1528143639265};\\\", \\\"{x:1720,y:992,t:1528143639281};\\\", \\\"{x:1721,y:992,t:1528143639299};\\\", \\\"{x:1722,y:992,t:1528143639315};\\\", \\\"{x:1723,y:992,t:1528143639332};\\\", \\\"{x:1725,y:992,t:1528143639350};\\\", \\\"{x:1726,y:992,t:1528143639366};\\\", \\\"{x:1727,y:992,t:1528143639415};\\\", \\\"{x:1728,y:992,t:1528143639439};\\\", \\\"{x:1729,y:992,t:1528143639449};\\\", \\\"{x:1733,y:992,t:1528143639466};\\\", \\\"{x:1736,y:992,t:1528143639482};\\\", \\\"{x:1741,y:992,t:1528143639499};\\\", \\\"{x:1745,y:991,t:1528143639516};\\\", \\\"{x:1749,y:991,t:1528143639532};\\\", \\\"{x:1751,y:991,t:1528143639549};\\\", \\\"{x:1751,y:990,t:1528143639654};\\\", \\\"{x:1752,y:990,t:1528143639678};\\\", \\\"{x:1752,y:989,t:1528143639694};\\\", \\\"{x:1753,y:988,t:1528143639735};\\\", \\\"{x:1753,y:987,t:1528143639758};\\\", \\\"{x:1754,y:987,t:1528143639766};\\\", \\\"{x:1755,y:986,t:1528143639782};\\\", \\\"{x:1755,y:985,t:1528143639799};\\\", \\\"{x:1755,y:983,t:1528143639822};\\\", \\\"{x:1755,y:981,t:1528143639846};\\\", \\\"{x:1755,y:980,t:1528143639862};\\\", \\\"{x:1756,y:979,t:1528143639878};\\\", \\\"{x:1756,y:978,t:1528143639902};\\\", \\\"{x:1756,y:977,t:1528143639916};\\\", \\\"{x:1756,y:975,t:1528143639933};\\\", \\\"{x:1756,y:974,t:1528143639948};\\\", \\\"{x:1756,y:972,t:1528143639965};\\\", \\\"{x:1756,y:969,t:1528143639982};\\\", \\\"{x:1756,y:968,t:1528143640005};\\\", \\\"{x:1756,y:967,t:1528143640016};\\\", \\\"{x:1756,y:966,t:1528143640070};\\\", \\\"{x:1752,y:966,t:1528143641190};\\\", \\\"{x:1746,y:967,t:1528143641201};\\\", \\\"{x:1729,y:972,t:1528143641217};\\\", \\\"{x:1712,y:975,t:1528143641235};\\\", \\\"{x:1689,y:979,t:1528143641250};\\\", \\\"{x:1664,y:980,t:1528143641267};\\\", \\\"{x:1646,y:980,t:1528143641285};\\\", \\\"{x:1627,y:980,t:1528143641300};\\\", \\\"{x:1604,y:980,t:1528143641317};\\\", \\\"{x:1570,y:980,t:1528143641335};\\\", \\\"{x:1550,y:980,t:1528143641350};\\\", \\\"{x:1529,y:981,t:1528143641367};\\\", \\\"{x:1510,y:981,t:1528143641384};\\\", \\\"{x:1492,y:981,t:1528143641400};\\\", \\\"{x:1477,y:981,t:1528143641417};\\\", \\\"{x:1467,y:979,t:1528143641434};\\\", \\\"{x:1458,y:977,t:1528143641450};\\\", \\\"{x:1448,y:973,t:1528143641467};\\\", \\\"{x:1445,y:972,t:1528143641485};\\\", \\\"{x:1444,y:972,t:1528143641500};\\\", \\\"{x:1443,y:971,t:1528143641518};\\\", \\\"{x:1441,y:969,t:1528143641534};\\\", \\\"{x:1440,y:967,t:1528143641551};\\\", \\\"{x:1439,y:963,t:1528143641567};\\\", \\\"{x:1437,y:954,t:1528143641584};\\\", \\\"{x:1434,y:939,t:1528143641600};\\\", \\\"{x:1429,y:922,t:1528143641618};\\\", \\\"{x:1426,y:916,t:1528143641635};\\\", \\\"{x:1424,y:914,t:1528143641651};\\\", \\\"{x:1424,y:913,t:1528143641667};\\\", \\\"{x:1422,y:912,t:1528143641684};\\\", \\\"{x:1421,y:911,t:1528143641701};\\\", \\\"{x:1419,y:911,t:1528143641718};\\\", \\\"{x:1417,y:911,t:1528143641735};\\\", \\\"{x:1414,y:911,t:1528143641751};\\\", \\\"{x:1412,y:911,t:1528143641768};\\\", \\\"{x:1408,y:911,t:1528143641784};\\\", \\\"{x:1399,y:913,t:1528143641801};\\\", \\\"{x:1392,y:915,t:1528143641818};\\\", \\\"{x:1385,y:917,t:1528143641834};\\\", \\\"{x:1384,y:917,t:1528143641852};\\\", \\\"{x:1385,y:917,t:1528143641974};\\\", \\\"{x:1387,y:917,t:1528143641985};\\\", \\\"{x:1390,y:915,t:1528143642002};\\\", \\\"{x:1394,y:910,t:1528143642017};\\\", \\\"{x:1403,y:901,t:1528143642035};\\\", \\\"{x:1417,y:890,t:1528143642052};\\\", \\\"{x:1432,y:882,t:1528143642067};\\\", \\\"{x:1440,y:878,t:1528143642084};\\\", \\\"{x:1441,y:878,t:1528143642102};\\\", \\\"{x:1444,y:875,t:1528143642582};\\\", \\\"{x:1448,y:867,t:1528143642589};\\\", \\\"{x:1453,y:859,t:1528143642601};\\\", \\\"{x:1458,y:847,t:1528143642618};\\\", \\\"{x:1463,y:840,t:1528143642634};\\\", \\\"{x:1468,y:831,t:1528143642650};\\\", \\\"{x:1471,y:828,t:1528143642667};\\\", \\\"{x:1472,y:827,t:1528143642685};\\\", \\\"{x:1474,y:827,t:1528143642781};\\\", \\\"{x:1476,y:827,t:1528143642790};\\\", \\\"{x:1479,y:829,t:1528143642800};\\\", \\\"{x:1483,y:832,t:1528143642818};\\\", \\\"{x:1484,y:833,t:1528143642835};\\\", \\\"{x:1484,y:834,t:1528143642862};\\\", \\\"{x:1485,y:834,t:1528143643647};\\\", \\\"{x:1486,y:834,t:1528143643663};\\\", \\\"{x:1486,y:833,t:1528143643678};\\\", \\\"{x:1486,y:832,t:1528143643686};\\\", \\\"{x:1486,y:831,t:1528143643702};\\\", \\\"{x:1486,y:828,t:1528143643719};\\\", \\\"{x:1486,y:826,t:1528143643736};\\\", \\\"{x:1487,y:824,t:1528143643752};\\\", \\\"{x:1487,y:822,t:1528143643769};\\\", \\\"{x:1488,y:819,t:1528143643785};\\\", \\\"{x:1490,y:816,t:1528143643802};\\\", \\\"{x:1491,y:814,t:1528143643819};\\\", \\\"{x:1495,y:809,t:1528143643835};\\\", \\\"{x:1497,y:805,t:1528143643852};\\\", \\\"{x:1497,y:804,t:1528143643870};\\\", \\\"{x:1498,y:802,t:1528143643886};\\\", \\\"{x:1498,y:801,t:1528143643926};\\\", \\\"{x:1498,y:800,t:1528143643942};\\\", \\\"{x:1498,y:799,t:1528143643952};\\\", \\\"{x:1500,y:798,t:1528143643970};\\\", \\\"{x:1500,y:796,t:1528143643987};\\\", \\\"{x:1501,y:793,t:1528143644003};\\\", \\\"{x:1503,y:788,t:1528143644020};\\\", \\\"{x:1507,y:782,t:1528143644036};\\\", \\\"{x:1510,y:777,t:1528143644052};\\\", \\\"{x:1513,y:772,t:1528143644070};\\\", \\\"{x:1513,y:771,t:1528143644126};\\\", \\\"{x:1513,y:770,t:1528143644142};\\\", \\\"{x:1515,y:769,t:1528143644152};\\\", \\\"{x:1515,y:768,t:1528143644471};\\\", \\\"{x:1515,y:767,t:1528143644503};\\\", \\\"{x:1515,y:766,t:1528143644519};\\\", \\\"{x:1514,y:765,t:1528143644558};\\\", \\\"{x:1514,y:764,t:1528143644975};\\\", \\\"{x:1514,y:763,t:1528143644990};\\\", \\\"{x:1514,y:762,t:1528143645038};\\\", \\\"{x:1515,y:761,t:1528143645062};\\\", \\\"{x:1515,y:762,t:1528143645439};\\\", \\\"{x:1515,y:764,t:1528143645453};\\\", \\\"{x:1514,y:766,t:1528143645470};\\\", \\\"{x:1513,y:770,t:1528143645488};\\\", \\\"{x:1512,y:772,t:1528143645503};\\\", \\\"{x:1512,y:773,t:1528143645521};\\\", \\\"{x:1511,y:776,t:1528143645538};\\\", \\\"{x:1510,y:779,t:1528143645554};\\\", \\\"{x:1508,y:784,t:1528143645571};\\\", \\\"{x:1505,y:790,t:1528143645587};\\\", \\\"{x:1503,y:794,t:1528143645603};\\\", \\\"{x:1502,y:796,t:1528143645620};\\\", \\\"{x:1500,y:800,t:1528143645638};\\\", \\\"{x:1500,y:802,t:1528143645654};\\\", \\\"{x:1500,y:804,t:1528143645670};\\\", \\\"{x:1500,y:805,t:1528143645687};\\\", \\\"{x:1499,y:807,t:1528143645704};\\\", \\\"{x:1498,y:809,t:1528143645721};\\\", \\\"{x:1497,y:811,t:1528143645738};\\\", \\\"{x:1496,y:813,t:1528143645755};\\\", \\\"{x:1494,y:816,t:1528143645771};\\\", \\\"{x:1494,y:818,t:1528143645788};\\\", \\\"{x:1493,y:820,t:1528143645805};\\\", \\\"{x:1492,y:821,t:1528143645821};\\\", \\\"{x:1492,y:823,t:1528143645837};\\\", \\\"{x:1490,y:826,t:1528143645855};\\\", \\\"{x:1488,y:829,t:1528143645870};\\\", \\\"{x:1487,y:831,t:1528143645888};\\\", \\\"{x:1486,y:832,t:1528143645905};\\\", \\\"{x:1484,y:836,t:1528143646359};\\\", \\\"{x:1482,y:839,t:1528143646372};\\\", \\\"{x:1480,y:842,t:1528143646387};\\\", \\\"{x:1477,y:846,t:1528143646404};\\\", \\\"{x:1472,y:852,t:1528143646421};\\\", \\\"{x:1470,y:853,t:1528143646437};\\\", \\\"{x:1468,y:856,t:1528143646455};\\\", \\\"{x:1465,y:859,t:1528143646472};\\\", \\\"{x:1461,y:865,t:1528143646487};\\\", \\\"{x:1456,y:872,t:1528143646505};\\\", \\\"{x:1453,y:877,t:1528143646521};\\\", \\\"{x:1452,y:878,t:1528143646550};\\\", \\\"{x:1452,y:879,t:1528143646558};\\\", \\\"{x:1452,y:880,t:1528143646571};\\\", \\\"{x:1450,y:882,t:1528143646588};\\\", \\\"{x:1449,y:884,t:1528143646604};\\\", \\\"{x:1445,y:891,t:1528143646622};\\\", \\\"{x:1443,y:895,t:1528143646638};\\\", \\\"{x:1442,y:898,t:1528143646655};\\\", \\\"{x:1441,y:902,t:1528143646672};\\\", \\\"{x:1438,y:908,t:1528143646689};\\\", \\\"{x:1435,y:918,t:1528143646704};\\\", \\\"{x:1429,y:928,t:1528143646722};\\\", \\\"{x:1426,y:933,t:1528143646739};\\\", \\\"{x:1424,y:936,t:1528143646755};\\\", \\\"{x:1422,y:940,t:1528143646772};\\\", \\\"{x:1422,y:942,t:1528143646789};\\\", \\\"{x:1421,y:943,t:1528143646804};\\\", \\\"{x:1419,y:948,t:1528143646822};\\\", \\\"{x:1417,y:952,t:1528143646838};\\\", \\\"{x:1414,y:957,t:1528143646855};\\\", \\\"{x:1413,y:961,t:1528143646872};\\\", \\\"{x:1411,y:963,t:1528143646889};\\\", \\\"{x:1411,y:964,t:1528143646904};\\\", \\\"{x:1411,y:965,t:1528143646922};\\\", \\\"{x:1411,y:966,t:1528143646939};\\\", \\\"{x:1411,y:968,t:1528143646955};\\\", \\\"{x:1411,y:970,t:1528143646972};\\\", \\\"{x:1411,y:971,t:1528143646989};\\\", \\\"{x:1411,y:972,t:1528143647006};\\\", \\\"{x:1411,y:974,t:1528143647022};\\\", \\\"{x:1411,y:976,t:1528143647039};\\\", \\\"{x:1411,y:978,t:1528143647055};\\\", \\\"{x:1411,y:977,t:1528143647270};\\\", \\\"{x:1411,y:974,t:1528143647289};\\\", \\\"{x:1411,y:973,t:1528143647306};\\\", \\\"{x:1411,y:971,t:1528143647322};\\\", \\\"{x:1411,y:967,t:1528143647551};\\\", \\\"{x:1413,y:959,t:1528143647558};\\\", \\\"{x:1417,y:949,t:1528143647572};\\\", \\\"{x:1422,y:932,t:1528143647588};\\\", \\\"{x:1428,y:908,t:1528143647606};\\\", \\\"{x:1433,y:893,t:1528143647622};\\\", \\\"{x:1437,y:882,t:1528143647639};\\\", \\\"{x:1440,y:867,t:1528143647656};\\\", \\\"{x:1445,y:849,t:1528143647673};\\\", \\\"{x:1452,y:826,t:1528143647689};\\\", \\\"{x:1456,y:813,t:1528143647705};\\\", \\\"{x:1458,y:804,t:1528143647723};\\\", \\\"{x:1462,y:799,t:1528143647739};\\\", \\\"{x:1463,y:795,t:1528143647755};\\\", \\\"{x:1465,y:791,t:1528143647772};\\\", \\\"{x:1467,y:788,t:1528143647789};\\\", \\\"{x:1471,y:782,t:1528143647806};\\\", \\\"{x:1475,y:774,t:1528143647822};\\\", \\\"{x:1478,y:771,t:1528143647839};\\\", \\\"{x:1479,y:770,t:1528143647856};\\\", \\\"{x:1480,y:769,t:1528143647873};\\\", \\\"{x:1481,y:769,t:1528143647973};\\\", \\\"{x:1482,y:769,t:1528143647989};\\\", \\\"{x:1487,y:769,t:1528143648005};\\\", \\\"{x:1491,y:769,t:1528143648022};\\\", \\\"{x:1492,y:769,t:1528143648039};\\\", \\\"{x:1494,y:769,t:1528143648069};\\\", \\\"{x:1495,y:769,t:1528143648110};\\\", \\\"{x:1497,y:769,t:1528143648134};\\\", \\\"{x:1498,y:769,t:1528143648141};\\\", \\\"{x:1499,y:769,t:1528143648156};\\\", \\\"{x:1501,y:767,t:1528143648173};\\\", \\\"{x:1502,y:766,t:1528143648190};\\\", \\\"{x:1502,y:769,t:1528143648487};\\\", \\\"{x:1502,y:773,t:1528143648494};\\\", \\\"{x:1502,y:779,t:1528143648507};\\\", \\\"{x:1500,y:785,t:1528143648523};\\\", \\\"{x:1499,y:792,t:1528143648540};\\\", \\\"{x:1496,y:801,t:1528143648557};\\\", \\\"{x:1495,y:808,t:1528143648573};\\\", \\\"{x:1492,y:816,t:1528143648590};\\\", \\\"{x:1492,y:820,t:1528143648606};\\\", \\\"{x:1491,y:824,t:1528143648623};\\\", \\\"{x:1491,y:827,t:1528143648640};\\\", \\\"{x:1491,y:831,t:1528143648657};\\\", \\\"{x:1491,y:834,t:1528143648673};\\\", \\\"{x:1491,y:837,t:1528143648690};\\\", \\\"{x:1491,y:840,t:1528143648707};\\\", \\\"{x:1490,y:841,t:1528143649118};\\\", \\\"{x:1488,y:844,t:1528143649951};\\\", \\\"{x:1488,y:847,t:1528143649958};\\\", \\\"{x:1486,y:853,t:1528143649974};\\\", \\\"{x:1484,y:860,t:1528143649990};\\\", \\\"{x:1481,y:869,t:1528143650008};\\\", \\\"{x:1478,y:879,t:1528143650023};\\\", \\\"{x:1474,y:887,t:1528143650041};\\\", \\\"{x:1470,y:894,t:1528143650058};\\\", \\\"{x:1466,y:900,t:1528143650074};\\\", \\\"{x:1462,y:908,t:1528143650091};\\\", \\\"{x:1457,y:915,t:1528143650108};\\\", \\\"{x:1453,y:922,t:1528143650125};\\\", \\\"{x:1450,y:927,t:1528143650141};\\\", \\\"{x:1443,y:935,t:1528143650158};\\\", \\\"{x:1440,y:941,t:1528143650174};\\\", \\\"{x:1436,y:946,t:1528143650191};\\\", \\\"{x:1435,y:948,t:1528143650207};\\\", \\\"{x:1435,y:950,t:1528143650224};\\\", \\\"{x:1435,y:951,t:1528143650241};\\\", \\\"{x:1434,y:953,t:1528143650258};\\\", \\\"{x:1433,y:953,t:1528143650274};\\\", \\\"{x:1433,y:955,t:1528143650291};\\\", \\\"{x:1432,y:959,t:1528143650307};\\\", \\\"{x:1431,y:960,t:1528143650325};\\\", \\\"{x:1431,y:961,t:1528143650366};\\\", \\\"{x:1431,y:962,t:1528143650382};\\\", \\\"{x:1431,y:964,t:1528143650391};\\\", \\\"{x:1431,y:968,t:1528143650408};\\\", \\\"{x:1431,y:970,t:1528143650426};\\\", \\\"{x:1431,y:971,t:1528143650454};\\\", \\\"{x:1430,y:971,t:1528143650558};\\\", \\\"{x:1428,y:971,t:1528143650574};\\\", \\\"{x:1425,y:971,t:1528143650591};\\\", \\\"{x:1421,y:971,t:1528143650607};\\\", \\\"{x:1412,y:971,t:1528143650624};\\\", \\\"{x:1404,y:971,t:1528143650641};\\\", \\\"{x:1400,y:971,t:1528143650657};\\\", \\\"{x:1395,y:971,t:1528143650675};\\\", \\\"{x:1393,y:971,t:1528143650691};\\\", \\\"{x:1395,y:971,t:1528143651102};\\\", \\\"{x:1396,y:971,t:1528143651110};\\\", \\\"{x:1397,y:972,t:1528143651124};\\\", \\\"{x:1403,y:974,t:1528143651141};\\\", \\\"{x:1412,y:977,t:1528143651158};\\\", \\\"{x:1423,y:982,t:1528143651174};\\\", \\\"{x:1433,y:984,t:1528143651191};\\\", \\\"{x:1441,y:987,t:1528143651209};\\\", \\\"{x:1450,y:990,t:1528143651224};\\\", \\\"{x:1454,y:991,t:1528143651241};\\\", \\\"{x:1457,y:991,t:1528143651258};\\\", \\\"{x:1459,y:991,t:1528143651275};\\\", \\\"{x:1460,y:991,t:1528143651291};\\\", \\\"{x:1462,y:991,t:1528143651308};\\\", \\\"{x:1463,y:991,t:1528143651326};\\\", \\\"{x:1465,y:991,t:1528143651350};\\\", \\\"{x:1466,y:991,t:1528143651358};\\\", \\\"{x:1468,y:991,t:1528143651375};\\\", \\\"{x:1470,y:991,t:1528143651391};\\\", \\\"{x:1472,y:989,t:1528143651409};\\\", \\\"{x:1472,y:987,t:1528143651424};\\\", \\\"{x:1474,y:983,t:1528143651442};\\\", \\\"{x:1477,y:979,t:1528143651458};\\\", \\\"{x:1478,y:975,t:1528143651475};\\\", \\\"{x:1480,y:973,t:1528143651492};\\\", \\\"{x:1480,y:969,t:1528143651509};\\\", \\\"{x:1480,y:963,t:1528143651526};\\\", \\\"{x:1480,y:962,t:1528143651542};\\\", \\\"{x:1480,y:961,t:1528143651559};\\\", \\\"{x:1481,y:961,t:1528143651839};\\\", \\\"{x:1482,y:963,t:1528143651854};\\\", \\\"{x:1483,y:965,t:1528143651862};\\\", \\\"{x:1484,y:966,t:1528143651876};\\\", \\\"{x:1484,y:967,t:1528143651893};\\\", \\\"{x:1485,y:969,t:1528143651909};\\\", \\\"{x:1486,y:970,t:1528143651926};\\\", \\\"{x:1486,y:971,t:1528143651942};\\\", \\\"{x:1487,y:972,t:1528143651959};\\\", \\\"{x:1487,y:974,t:1528143651975};\\\", \\\"{x:1490,y:976,t:1528143651993};\\\", \\\"{x:1492,y:979,t:1528143652009};\\\", \\\"{x:1494,y:979,t:1528143652025};\\\", \\\"{x:1497,y:980,t:1528143652043};\\\", \\\"{x:1500,y:981,t:1528143652058};\\\", \\\"{x:1504,y:983,t:1528143652077};\\\", \\\"{x:1513,y:986,t:1528143652093};\\\", \\\"{x:1522,y:988,t:1528143652109};\\\", \\\"{x:1533,y:990,t:1528143652126};\\\", \\\"{x:1537,y:990,t:1528143652142};\\\", \\\"{x:1541,y:991,t:1528143652159};\\\", \\\"{x:1542,y:991,t:1528143652182};\\\", \\\"{x:1544,y:991,t:1528143652231};\\\", \\\"{x:1546,y:990,t:1528143652246};\\\", \\\"{x:1548,y:990,t:1528143652262};\\\", \\\"{x:1550,y:990,t:1528143652276};\\\", \\\"{x:1551,y:989,t:1528143652293};\\\", \\\"{x:1552,y:988,t:1528143652309};\\\", \\\"{x:1553,y:985,t:1528143652326};\\\", \\\"{x:1554,y:984,t:1528143652343};\\\", \\\"{x:1554,y:982,t:1528143652360};\\\", \\\"{x:1554,y:981,t:1528143652376};\\\", \\\"{x:1554,y:979,t:1528143652393};\\\", \\\"{x:1554,y:977,t:1528143652409};\\\", \\\"{x:1554,y:976,t:1528143652426};\\\", \\\"{x:1554,y:975,t:1528143652454};\\\", \\\"{x:1553,y:974,t:1528143652462};\\\", \\\"{x:1553,y:973,t:1528143652475};\\\", \\\"{x:1551,y:972,t:1528143652492};\\\", \\\"{x:1551,y:971,t:1528143652510};\\\", \\\"{x:1550,y:971,t:1528143652701};\\\", \\\"{x:1550,y:972,t:1528143652846};\\\", \\\"{x:1550,y:973,t:1528143652860};\\\", \\\"{x:1553,y:982,t:1528143652877};\\\", \\\"{x:1556,y:988,t:1528143652894};\\\", \\\"{x:1560,y:992,t:1528143652910};\\\", \\\"{x:1561,y:993,t:1528143652926};\\\", \\\"{x:1564,y:994,t:1528143652943};\\\", \\\"{x:1570,y:995,t:1528143652960};\\\", \\\"{x:1578,y:996,t:1528143652977};\\\", \\\"{x:1586,y:997,t:1528143652992};\\\", \\\"{x:1591,y:998,t:1528143653010};\\\", \\\"{x:1594,y:998,t:1528143653027};\\\", \\\"{x:1596,y:998,t:1528143653102};\\\", \\\"{x:1598,y:998,t:1528143653110};\\\", \\\"{x:1602,y:998,t:1528143653127};\\\", \\\"{x:1604,y:998,t:1528143653143};\\\", \\\"{x:1606,y:998,t:1528143653160};\\\", \\\"{x:1607,y:996,t:1528143653190};\\\", \\\"{x:1608,y:995,t:1528143653198};\\\", \\\"{x:1609,y:994,t:1528143653210};\\\", \\\"{x:1609,y:989,t:1528143653227};\\\", \\\"{x:1612,y:986,t:1528143653244};\\\", \\\"{x:1613,y:985,t:1528143653260};\\\", \\\"{x:1615,y:983,t:1528143653277};\\\", \\\"{x:1616,y:981,t:1528143653294};\\\", \\\"{x:1616,y:979,t:1528143653310};\\\", \\\"{x:1616,y:978,t:1528143653327};\\\", \\\"{x:1616,y:977,t:1528143653344};\\\", \\\"{x:1616,y:976,t:1528143653360};\\\", \\\"{x:1616,y:975,t:1528143653398};\\\", \\\"{x:1616,y:974,t:1528143653414};\\\", \\\"{x:1616,y:973,t:1528143653430};\\\", \\\"{x:1615,y:972,t:1528143653444};\\\", \\\"{x:1615,y:971,t:1528143653470};\\\", \\\"{x:1615,y:970,t:1528143653502};\\\", \\\"{x:1614,y:970,t:1528143653558};\\\", \\\"{x:1614,y:971,t:1528143654006};\\\", \\\"{x:1615,y:974,t:1528143654014};\\\", \\\"{x:1615,y:975,t:1528143654027};\\\", \\\"{x:1616,y:978,t:1528143654044};\\\", \\\"{x:1617,y:979,t:1528143654061};\\\", \\\"{x:1617,y:980,t:1528143654077};\\\", \\\"{x:1617,y:981,t:1528143654094};\\\", \\\"{x:1618,y:982,t:1528143654110};\\\", \\\"{x:1618,y:983,t:1528143654149};\\\", \\\"{x:1619,y:984,t:1528143654160};\\\", \\\"{x:1620,y:985,t:1528143654178};\\\", \\\"{x:1620,y:987,t:1528143654194};\\\", \\\"{x:1622,y:988,t:1528143654211};\\\", \\\"{x:1623,y:989,t:1528143654227};\\\", \\\"{x:1625,y:989,t:1528143654243};\\\", \\\"{x:1626,y:991,t:1528143654261};\\\", \\\"{x:1631,y:992,t:1528143654277};\\\", \\\"{x:1632,y:992,t:1528143654302};\\\", \\\"{x:1633,y:994,t:1528143654311};\\\", \\\"{x:1634,y:994,t:1528143654430};\\\", \\\"{x:1635,y:994,t:1528143654444};\\\", \\\"{x:1637,y:994,t:1528143654461};\\\", \\\"{x:1640,y:994,t:1528143654478};\\\", \\\"{x:1641,y:994,t:1528143654502};\\\", \\\"{x:1642,y:993,t:1528143654518};\\\", \\\"{x:1644,y:993,t:1528143654528};\\\", \\\"{x:1648,y:993,t:1528143654545};\\\", \\\"{x:1652,y:992,t:1528143654561};\\\", \\\"{x:1656,y:990,t:1528143654577};\\\", \\\"{x:1659,y:990,t:1528143654595};\\\", \\\"{x:1661,y:988,t:1528143654610};\\\", \\\"{x:1662,y:987,t:1528143654627};\\\", \\\"{x:1663,y:986,t:1528143654645};\\\", \\\"{x:1664,y:986,t:1528143654678};\\\", \\\"{x:1665,y:985,t:1528143654694};\\\", \\\"{x:1665,y:983,t:1528143654718};\\\", \\\"{x:1665,y:982,t:1528143654734};\\\", \\\"{x:1666,y:982,t:1528143654745};\\\", \\\"{x:1667,y:979,t:1528143654760};\\\", \\\"{x:1667,y:978,t:1528143654778};\\\", \\\"{x:1667,y:975,t:1528143654795};\\\", \\\"{x:1668,y:972,t:1528143654811};\\\", \\\"{x:1668,y:967,t:1528143654829};\\\", \\\"{x:1669,y:963,t:1528143654845};\\\", \\\"{x:1670,y:956,t:1528143654862};\\\", \\\"{x:1670,y:951,t:1528143654878};\\\", \\\"{x:1670,y:950,t:1528143654895};\\\", \\\"{x:1670,y:949,t:1528143654918};\\\", \\\"{x:1671,y:948,t:1528143655143};\\\", \\\"{x:1672,y:949,t:1528143655150};\\\", \\\"{x:1673,y:950,t:1528143655162};\\\", \\\"{x:1674,y:953,t:1528143655178};\\\", \\\"{x:1676,y:955,t:1528143655194};\\\", \\\"{x:1676,y:956,t:1528143655212};\\\", \\\"{x:1678,y:958,t:1528143655229};\\\", \\\"{x:1678,y:960,t:1528143655246};\\\", \\\"{x:1679,y:961,t:1528143655262};\\\", \\\"{x:1681,y:963,t:1528143655278};\\\", \\\"{x:1681,y:965,t:1528143655295};\\\", \\\"{x:1682,y:965,t:1528143655312};\\\", \\\"{x:1683,y:966,t:1528143655328};\\\", \\\"{x:1683,y:967,t:1528143655345};\\\", \\\"{x:1684,y:968,t:1528143655362};\\\", \\\"{x:1685,y:969,t:1528143655382};\\\", \\\"{x:1686,y:969,t:1528143655395};\\\", \\\"{x:1688,y:972,t:1528143655412};\\\", \\\"{x:1688,y:973,t:1528143655428};\\\", \\\"{x:1689,y:973,t:1528143655445};\\\", \\\"{x:1689,y:974,t:1528143655462};\\\", \\\"{x:1690,y:974,t:1528143655478};\\\", \\\"{x:1691,y:975,t:1528143655495};\\\", \\\"{x:1695,y:977,t:1528143655512};\\\", \\\"{x:1696,y:978,t:1528143655529};\\\", \\\"{x:1698,y:979,t:1528143655545};\\\", \\\"{x:1699,y:980,t:1528143655574};\\\", \\\"{x:1701,y:981,t:1528143655615};\\\", \\\"{x:1703,y:982,t:1528143655628};\\\", \\\"{x:1705,y:983,t:1528143655644};\\\", \\\"{x:1707,y:984,t:1528143655661};\\\", \\\"{x:1708,y:985,t:1528143655679};\\\", \\\"{x:1710,y:985,t:1528143655694};\\\", \\\"{x:1712,y:986,t:1528143655711};\\\", \\\"{x:1714,y:987,t:1528143655728};\\\", \\\"{x:1715,y:987,t:1528143655749};\\\", \\\"{x:1716,y:988,t:1528143655761};\\\", \\\"{x:1718,y:988,t:1528143655778};\\\", \\\"{x:1719,y:989,t:1528143655795};\\\", \\\"{x:1720,y:989,t:1528143655812};\\\", \\\"{x:1721,y:989,t:1528143655830};\\\", \\\"{x:1722,y:989,t:1528143655854};\\\", \\\"{x:1723,y:989,t:1528143655878};\\\", \\\"{x:1724,y:989,t:1528143655918};\\\", \\\"{x:1725,y:990,t:1528143655934};\\\", \\\"{x:1726,y:990,t:1528143655966};\\\", \\\"{x:1727,y:991,t:1528143656006};\\\", \\\"{x:1728,y:991,t:1528143656022};\\\", \\\"{x:1729,y:991,t:1528143656029};\\\", \\\"{x:1732,y:991,t:1528143656046};\\\", \\\"{x:1734,y:991,t:1528143656062};\\\", \\\"{x:1735,y:991,t:1528143656079};\\\", \\\"{x:1736,y:991,t:1528143656096};\\\", \\\"{x:1737,y:991,t:1528143656112};\\\", \\\"{x:1738,y:991,t:1528143656129};\\\", \\\"{x:1739,y:991,t:1528143656147};\\\", \\\"{x:1739,y:990,t:1528143656162};\\\", \\\"{x:1740,y:990,t:1528143656179};\\\", \\\"{x:1741,y:988,t:1528143656196};\\\", \\\"{x:1742,y:985,t:1528143656212};\\\", \\\"{x:1742,y:982,t:1528143656229};\\\", \\\"{x:1744,y:978,t:1528143656245};\\\", \\\"{x:1745,y:976,t:1528143656270};\\\", \\\"{x:1745,y:975,t:1528143656279};\\\", \\\"{x:1745,y:974,t:1528143656296};\\\", \\\"{x:1745,y:973,t:1528143656318};\\\", \\\"{x:1745,y:972,t:1528143656333};\\\", \\\"{x:1746,y:971,t:1528143656390};\\\", \\\"{x:1746,y:970,t:1528143656446};\\\", \\\"{x:1746,y:969,t:1528143656463};\\\", \\\"{x:1746,y:968,t:1528143656479};\\\", \\\"{x:1746,y:966,t:1528143656496};\\\", \\\"{x:1746,y:963,t:1528143656514};\\\", \\\"{x:1746,y:962,t:1528143656530};\\\", \\\"{x:1746,y:959,t:1528143656546};\\\", \\\"{x:1746,y:957,t:1528143656563};\\\", \\\"{x:1746,y:956,t:1528143656579};\\\", \\\"{x:1746,y:955,t:1528143656596};\\\", \\\"{x:1746,y:954,t:1528143656613};\\\", \\\"{x:1746,y:955,t:1528143656918};\\\", \\\"{x:1746,y:956,t:1528143656931};\\\", \\\"{x:1746,y:958,t:1528143656946};\\\", \\\"{x:1744,y:960,t:1528143656963};\\\", \\\"{x:1741,y:961,t:1528143656981};\\\", \\\"{x:1734,y:963,t:1528143656996};\\\", \\\"{x:1728,y:963,t:1528143657013};\\\", \\\"{x:1704,y:963,t:1528143657029};\\\", \\\"{x:1680,y:957,t:1528143657046};\\\", \\\"{x:1659,y:952,t:1528143657063};\\\", \\\"{x:1642,y:948,t:1528143657080};\\\", \\\"{x:1632,y:945,t:1528143657097};\\\", \\\"{x:1622,y:939,t:1528143657113};\\\", \\\"{x:1610,y:927,t:1528143657131};\\\", \\\"{x:1601,y:912,t:1528143657146};\\\", \\\"{x:1587,y:893,t:1528143657163};\\\", \\\"{x:1573,y:871,t:1528143657181};\\\", \\\"{x:1560,y:847,t:1528143657197};\\\", \\\"{x:1551,y:832,t:1528143657213};\\\", \\\"{x:1543,y:818,t:1528143657230};\\\", \\\"{x:1542,y:817,t:1528143657246};\\\", \\\"{x:1542,y:814,t:1528143657263};\\\", \\\"{x:1542,y:811,t:1528143657280};\\\", \\\"{x:1541,y:806,t:1528143657298};\\\", \\\"{x:1539,y:803,t:1528143657313};\\\", \\\"{x:1539,y:801,t:1528143657330};\\\", \\\"{x:1539,y:800,t:1528143657382};\\\", \\\"{x:1538,y:798,t:1528143657398};\\\", \\\"{x:1538,y:796,t:1528143657413};\\\", \\\"{x:1535,y:785,t:1528143657430};\\\", \\\"{x:1529,y:771,t:1528143657447};\\\", \\\"{x:1524,y:757,t:1528143657463};\\\", \\\"{x:1523,y:750,t:1528143657480};\\\", \\\"{x:1523,y:749,t:1528143657497};\\\", \\\"{x:1523,y:747,t:1528143657513};\\\", \\\"{x:1522,y:747,t:1528143657599};\\\", \\\"{x:1521,y:747,t:1528143657614};\\\", \\\"{x:1514,y:765,t:1528143657631};\\\", \\\"{x:1510,y:776,t:1528143657648};\\\", \\\"{x:1507,y:784,t:1528143657663};\\\", \\\"{x:1503,y:792,t:1528143657680};\\\", \\\"{x:1501,y:797,t:1528143657697};\\\", \\\"{x:1499,y:803,t:1528143657714};\\\", \\\"{x:1498,y:806,t:1528143657730};\\\", \\\"{x:1497,y:808,t:1528143657747};\\\", \\\"{x:1497,y:810,t:1528143657765};\\\", \\\"{x:1497,y:812,t:1528143657780};\\\", \\\"{x:1495,y:818,t:1528143657797};\\\", \\\"{x:1488,y:833,t:1528143657814};\\\", \\\"{x:1485,y:841,t:1528143657830};\\\", \\\"{x:1484,y:845,t:1528143657847};\\\", \\\"{x:1483,y:847,t:1528143657870};\\\", \\\"{x:1483,y:848,t:1528143657886};\\\", \\\"{x:1481,y:850,t:1528143657897};\\\", \\\"{x:1481,y:852,t:1528143657914};\\\", \\\"{x:1479,y:855,t:1528143657929};\\\", \\\"{x:1478,y:857,t:1528143657947};\\\", \\\"{x:1478,y:858,t:1528143657963};\\\", \\\"{x:1477,y:859,t:1528143657979};\\\", \\\"{x:1477,y:858,t:1528143658854};\\\", \\\"{x:1482,y:848,t:1528143658865};\\\", \\\"{x:1504,y:826,t:1528143658881};\\\", \\\"{x:1515,y:819,t:1528143658898};\\\", \\\"{x:1520,y:815,t:1528143658914};\\\", \\\"{x:1525,y:810,t:1528143658932};\\\", \\\"{x:1530,y:805,t:1528143658949};\\\", \\\"{x:1534,y:801,t:1528143658964};\\\", \\\"{x:1539,y:795,t:1528143658981};\\\", \\\"{x:1545,y:788,t:1528143658998};\\\", \\\"{x:1549,y:783,t:1528143659016};\\\", \\\"{x:1554,y:778,t:1528143659030};\\\", \\\"{x:1556,y:775,t:1528143659047};\\\", \\\"{x:1560,y:770,t:1528143659064};\\\", \\\"{x:1562,y:767,t:1528143659080};\\\", \\\"{x:1564,y:763,t:1528143659097};\\\", \\\"{x:1568,y:759,t:1528143659115};\\\", \\\"{x:1571,y:756,t:1528143659131};\\\", \\\"{x:1576,y:751,t:1528143659147};\\\", \\\"{x:1580,y:747,t:1528143659165};\\\", \\\"{x:1585,y:743,t:1528143659180};\\\", \\\"{x:1589,y:740,t:1528143659197};\\\", \\\"{x:1595,y:737,t:1528143659215};\\\", \\\"{x:1599,y:736,t:1528143659230};\\\", \\\"{x:1605,y:736,t:1528143659248};\\\", \\\"{x:1618,y:737,t:1528143659264};\\\", \\\"{x:1636,y:746,t:1528143659281};\\\", \\\"{x:1655,y:757,t:1528143659298};\\\", \\\"{x:1671,y:770,t:1528143659315};\\\", \\\"{x:1691,y:784,t:1528143659331};\\\", \\\"{x:1709,y:796,t:1528143659348};\\\", \\\"{x:1729,y:810,t:1528143659364};\\\", \\\"{x:1745,y:821,t:1528143659381};\\\", \\\"{x:1754,y:827,t:1528143659398};\\\", \\\"{x:1756,y:828,t:1528143659415};\\\", \\\"{x:1757,y:830,t:1528143659431};\\\", \\\"{x:1757,y:831,t:1528143659534};\\\", \\\"{x:1757,y:832,t:1528143659548};\\\", \\\"{x:1754,y:834,t:1528143659565};\\\", \\\"{x:1749,y:836,t:1528143659582};\\\", \\\"{x:1746,y:837,t:1528143659599};\\\", \\\"{x:1741,y:840,t:1528143659615};\\\", \\\"{x:1740,y:840,t:1528143659633};\\\", \\\"{x:1738,y:841,t:1528143659648};\\\", \\\"{x:1736,y:841,t:1528143659666};\\\", \\\"{x:1735,y:841,t:1528143659685};\\\", \\\"{x:1734,y:841,t:1528143659698};\\\", \\\"{x:1733,y:842,t:1528143659715};\\\", \\\"{x:1731,y:844,t:1528143659732};\\\", \\\"{x:1729,y:844,t:1528143659748};\\\", \\\"{x:1727,y:845,t:1528143659766};\\\", \\\"{x:1726,y:846,t:1528143659782};\\\", \\\"{x:1724,y:846,t:1528143660254};\\\", \\\"{x:1723,y:846,t:1528143660265};\\\", \\\"{x:1720,y:846,t:1528143660282};\\\", \\\"{x:1718,y:846,t:1528143660299};\\\", \\\"{x:1716,y:847,t:1528143660315};\\\", \\\"{x:1715,y:847,t:1528143660333};\\\", \\\"{x:1714,y:847,t:1528143660350};\\\", \\\"{x:1713,y:848,t:1528143660366};\\\", \\\"{x:1712,y:848,t:1528143660382};\\\", \\\"{x:1710,y:849,t:1528143660400};\\\", \\\"{x:1709,y:849,t:1528143660417};\\\", \\\"{x:1708,y:849,t:1528143660446};\\\", \\\"{x:1707,y:850,t:1528143660470};\\\", \\\"{x:1705,y:850,t:1528143660494};\\\", \\\"{x:1705,y:851,t:1528143660526};\\\", \\\"{x:1704,y:851,t:1528143660718};\\\", \\\"{x:1700,y:849,t:1528143660732};\\\", \\\"{x:1698,y:848,t:1528143660750};\\\", \\\"{x:1694,y:845,t:1528143660765};\\\", \\\"{x:1692,y:843,t:1528143660784};\\\", \\\"{x:1687,y:842,t:1528143660800};\\\", \\\"{x:1677,y:839,t:1528143660817};\\\", \\\"{x:1662,y:836,t:1528143660832};\\\", \\\"{x:1648,y:834,t:1528143660849};\\\", \\\"{x:1636,y:834,t:1528143660866};\\\", \\\"{x:1621,y:834,t:1528143660883};\\\", \\\"{x:1605,y:834,t:1528143660900};\\\", \\\"{x:1590,y:836,t:1528143660916};\\\", \\\"{x:1581,y:840,t:1528143660934};\\\", \\\"{x:1573,y:842,t:1528143660949};\\\", \\\"{x:1559,y:843,t:1528143660965};\\\", \\\"{x:1551,y:843,t:1528143660983};\\\", \\\"{x:1549,y:843,t:1528143660999};\\\", \\\"{x:1548,y:843,t:1528143661016};\\\", \\\"{x:1546,y:843,t:1528143661046};\\\", \\\"{x:1544,y:842,t:1528143661054};\\\", \\\"{x:1542,y:839,t:1528143661066};\\\", \\\"{x:1537,y:833,t:1528143661083};\\\", \\\"{x:1532,y:828,t:1528143661099};\\\", \\\"{x:1526,y:825,t:1528143661116};\\\", \\\"{x:1522,y:824,t:1528143661133};\\\", \\\"{x:1519,y:824,t:1528143661149};\\\", \\\"{x:1509,y:824,t:1528143661166};\\\", \\\"{x:1500,y:827,t:1528143661184};\\\", \\\"{x:1493,y:830,t:1528143661200};\\\", \\\"{x:1491,y:832,t:1528143661217};\\\", \\\"{x:1490,y:832,t:1528143661233};\\\", \\\"{x:1490,y:833,t:1528143661249};\\\", \\\"{x:1489,y:835,t:1528143661267};\\\", \\\"{x:1488,y:837,t:1528143661283};\\\", \\\"{x:1486,y:838,t:1528143661300};\\\", \\\"{x:1483,y:841,t:1528143661316};\\\", \\\"{x:1480,y:844,t:1528143661333};\\\", \\\"{x:1478,y:845,t:1528143661350};\\\", \\\"{x:1477,y:845,t:1528143661366};\\\", \\\"{x:1477,y:846,t:1528143661422};\\\", \\\"{x:1477,y:847,t:1528143661434};\\\", \\\"{x:1471,y:851,t:1528143661451};\\\", \\\"{x:1467,y:853,t:1528143661467};\\\", \\\"{x:1462,y:858,t:1528143661483};\\\", \\\"{x:1458,y:863,t:1528143661501};\\\", \\\"{x:1452,y:870,t:1528143661517};\\\", \\\"{x:1444,y:882,t:1528143661533};\\\", \\\"{x:1430,y:904,t:1528143661550};\\\", \\\"{x:1419,y:919,t:1528143661567};\\\", \\\"{x:1414,y:925,t:1528143661583};\\\", \\\"{x:1406,y:934,t:1528143661601};\\\", \\\"{x:1404,y:941,t:1528143661616};\\\", \\\"{x:1402,y:945,t:1528143661634};\\\", \\\"{x:1401,y:947,t:1528143661650};\\\", \\\"{x:1401,y:948,t:1528143661678};\\\", \\\"{x:1400,y:949,t:1528143661694};\\\", \\\"{x:1398,y:953,t:1528143661710};\\\", \\\"{x:1398,y:954,t:1528143661718};\\\", \\\"{x:1398,y:955,t:1528143661732};\\\", \\\"{x:1397,y:960,t:1528143661750};\\\", \\\"{x:1397,y:965,t:1528143661766};\\\", \\\"{x:1395,y:969,t:1528143661782};\\\", \\\"{x:1395,y:970,t:1528143661800};\\\", \\\"{x:1395,y:972,t:1528143661817};\\\", \\\"{x:1394,y:975,t:1528143661833};\\\", \\\"{x:1394,y:977,t:1528143661850};\\\", \\\"{x:1394,y:979,t:1528143661867};\\\", \\\"{x:1394,y:980,t:1528143661883};\\\", \\\"{x:1394,y:981,t:1528143661900};\\\", \\\"{x:1394,y:982,t:1528143661917};\\\", \\\"{x:1393,y:983,t:1528143661933};\\\", \\\"{x:1393,y:985,t:1528143661950};\\\", \\\"{x:1391,y:988,t:1528143661968};\\\", \\\"{x:1390,y:993,t:1528143661984};\\\", \\\"{x:1386,y:999,t:1528143662000};\\\", \\\"{x:1384,y:1005,t:1528143662018};\\\", \\\"{x:1382,y:1007,t:1528143662033};\\\", \\\"{x:1379,y:1010,t:1528143662050};\\\", \\\"{x:1375,y:1013,t:1528143662068};\\\", \\\"{x:1366,y:1021,t:1528143662083};\\\", \\\"{x:1357,y:1029,t:1528143662100};\\\", \\\"{x:1347,y:1035,t:1528143662117};\\\", \\\"{x:1336,y:1039,t:1528143662133};\\\", \\\"{x:1329,y:1040,t:1528143662150};\\\", \\\"{x:1322,y:1040,t:1528143662167};\\\", \\\"{x:1316,y:1040,t:1528143662183};\\\", \\\"{x:1307,y:1037,t:1528143662200};\\\", \\\"{x:1290,y:1033,t:1528143662217};\\\", \\\"{x:1263,y:1023,t:1528143662234};\\\", \\\"{x:1236,y:1014,t:1528143662250};\\\", \\\"{x:1205,y:1005,t:1528143662267};\\\", \\\"{x:1164,y:989,t:1528143662283};\\\", \\\"{x:1118,y:972,t:1528143662299};\\\", \\\"{x:1072,y:955,t:1528143662317};\\\", \\\"{x:1009,y:927,t:1528143662334};\\\", \\\"{x:976,y:906,t:1528143662350};\\\", \\\"{x:950,y:889,t:1528143662367};\\\", \\\"{x:934,y:877,t:1528143662384};\\\", \\\"{x:920,y:866,t:1528143662400};\\\", \\\"{x:905,y:861,t:1528143662417};\\\", \\\"{x:894,y:857,t:1528143662434};\\\", \\\"{x:889,y:856,t:1528143662450};\\\", \\\"{x:887,y:855,t:1528143662467};\\\", \\\"{x:886,y:854,t:1528143662486};\\\", \\\"{x:885,y:853,t:1528143662518};\\\", \\\"{x:882,y:847,t:1528143662534};\\\", \\\"{x:879,y:840,t:1528143662551};\\\", \\\"{x:877,y:834,t:1528143662567};\\\", \\\"{x:876,y:830,t:1528143662584};\\\", \\\"{x:876,y:829,t:1528143662838};\\\", \\\"{x:871,y:797,t:1528143662851};\\\", \\\"{x:808,y:688,t:1528143662867};\\\", \\\"{x:750,y:597,t:1528143662884};\\\", \\\"{x:701,y:527,t:1528143662903};\\\", \\\"{x:620,y:439,t:1528143662917};\\\", \\\"{x:561,y:396,t:1528143662934};\\\", \\\"{x:524,y:378,t:1528143662951};\\\", \\\"{x:510,y:374,t:1528143662969};\\\", \\\"{x:507,y:374,t:1528143662985};\\\", \\\"{x:504,y:374,t:1528143663002};\\\", \\\"{x:502,y:374,t:1528143663019};\\\", \\\"{x:493,y:381,t:1528143663035};\\\", \\\"{x:487,y:397,t:1528143663052};\\\", \\\"{x:484,y:414,t:1528143663068};\\\", \\\"{x:484,y:431,t:1528143663085};\\\", \\\"{x:486,y:446,t:1528143663102};\\\", \\\"{x:490,y:461,t:1528143663118};\\\", \\\"{x:492,y:472,t:1528143663136};\\\", \\\"{x:494,y:480,t:1528143663152};\\\", \\\"{x:494,y:495,t:1528143663170};\\\", \\\"{x:497,y:517,t:1528143663185};\\\", \\\"{x:512,y:536,t:1528143663203};\\\", \\\"{x:540,y:546,t:1528143663218};\\\", \\\"{x:578,y:552,t:1528143663236};\\\", \\\"{x:657,y:557,t:1528143663253};\\\", \\\"{x:809,y:571,t:1528143663270};\\\", \\\"{x:865,y:571,t:1528143663285};\\\", \\\"{x:892,y:571,t:1528143663302};\\\", \\\"{x:899,y:570,t:1528143663319};\\\", \\\"{x:900,y:570,t:1528143663336};\\\", \\\"{x:900,y:568,t:1528143663398};\\\", \\\"{x:900,y:567,t:1528143663406};\\\", \\\"{x:900,y:564,t:1528143663420};\\\", \\\"{x:900,y:563,t:1528143663436};\\\", \\\"{x:898,y:561,t:1528143663454};\\\", \\\"{x:883,y:557,t:1528143663470};\\\", \\\"{x:865,y:556,t:1528143663486};\\\", \\\"{x:853,y:556,t:1528143663503};\\\", \\\"{x:847,y:556,t:1528143663519};\\\", \\\"{x:843,y:557,t:1528143663535};\\\", \\\"{x:841,y:558,t:1528143663553};\\\", \\\"{x:839,y:560,t:1528143663613};\\\", \\\"{x:837,y:562,t:1528143663621};\\\", \\\"{x:837,y:564,t:1528143663636};\\\", \\\"{x:836,y:570,t:1528143663653};\\\", \\\"{x:836,y:572,t:1528143663669};\\\", \\\"{x:836,y:575,t:1528143663686};\\\", \\\"{x:836,y:578,t:1528143663703};\\\", \\\"{x:836,y:579,t:1528143663725};\\\", \\\"{x:837,y:580,t:1528143664141};\\\", \\\"{x:837,y:583,t:1528143664153};\\\", \\\"{x:835,y:585,t:1528143664169};\\\", \\\"{x:833,y:587,t:1528143664185};\\\", \\\"{x:832,y:589,t:1528143664203};\\\", \\\"{x:830,y:590,t:1528143664220};\\\", \\\"{x:827,y:592,t:1528143664235};\\\", \\\"{x:824,y:594,t:1528143664253};\\\", \\\"{x:822,y:596,t:1528143664269};\\\", \\\"{x:819,y:598,t:1528143664285};\\\", \\\"{x:815,y:600,t:1528143664303};\\\", \\\"{x:812,y:602,t:1528143664321};\\\", \\\"{x:805,y:606,t:1528143664336};\\\", \\\"{x:800,y:607,t:1528143664353};\\\", \\\"{x:790,y:610,t:1528143664370};\\\", \\\"{x:777,y:612,t:1528143664386};\\\", \\\"{x:767,y:614,t:1528143664403};\\\", \\\"{x:760,y:615,t:1528143664420};\\\", \\\"{x:740,y:616,t:1528143664438};\\\", \\\"{x:732,y:616,t:1528143664453};\\\", \\\"{x:701,y:616,t:1528143664472};\\\", \\\"{x:675,y:614,t:1528143664487};\\\", \\\"{x:651,y:608,t:1528143664503};\\\", \\\"{x:621,y:601,t:1528143664520};\\\", \\\"{x:587,y:590,t:1528143664538};\\\", \\\"{x:549,y:580,t:1528143664553};\\\", \\\"{x:525,y:575,t:1528143664570};\\\", \\\"{x:504,y:570,t:1528143664587};\\\", \\\"{x:492,y:565,t:1528143664605};\\\", \\\"{x:489,y:564,t:1528143664620};\\\", \\\"{x:488,y:562,t:1528143664638};\\\", \\\"{x:488,y:559,t:1528143664653};\\\", \\\"{x:491,y:555,t:1528143664670};\\\", \\\"{x:501,y:550,t:1528143664687};\\\", \\\"{x:507,y:548,t:1528143664703};\\\", \\\"{x:510,y:547,t:1528143664720};\\\", \\\"{x:513,y:547,t:1528143664737};\\\", \\\"{x:518,y:547,t:1528143664753};\\\", \\\"{x:526,y:548,t:1528143664770};\\\", \\\"{x:531,y:549,t:1528143664787};\\\", \\\"{x:534,y:550,t:1528143664803};\\\", \\\"{x:541,y:552,t:1528143664820};\\\", \\\"{x:555,y:556,t:1528143664838};\\\", \\\"{x:569,y:561,t:1528143664853};\\\", \\\"{x:575,y:562,t:1528143664870};\\\", \\\"{x:578,y:564,t:1528143664888};\\\", \\\"{x:580,y:565,t:1528143664904};\\\", \\\"{x:585,y:568,t:1528143664920};\\\", \\\"{x:590,y:571,t:1528143664937};\\\", \\\"{x:592,y:572,t:1528143664954};\\\", \\\"{x:593,y:572,t:1528143664969};\\\", \\\"{x:594,y:573,t:1528143664987};\\\", \\\"{x:595,y:573,t:1528143665004};\\\", \\\"{x:596,y:573,t:1528143665020};\\\", \\\"{x:596,y:574,t:1528143665271};\\\", \\\"{x:596,y:575,t:1528143665293};\\\", \\\"{x:595,y:576,t:1528143665303};\\\", \\\"{x:594,y:576,t:1528143665341};\\\", \\\"{x:594,y:576,t:1528143665398};\\\", \\\"{x:593,y:576,t:1528143665437};\\\", \\\"{x:589,y:580,t:1528143665454};\\\", \\\"{x:582,y:588,t:1528143665471};\\\", \\\"{x:577,y:600,t:1528143665488};\\\", \\\"{x:569,y:610,t:1528143665505};\\\", \\\"{x:564,y:619,t:1528143665520};\\\", \\\"{x:561,y:631,t:1528143665536};\\\", \\\"{x:560,y:639,t:1528143665554};\\\", \\\"{x:558,y:648,t:1528143665571};\\\", \\\"{x:556,y:655,t:1528143665587};\\\", \\\"{x:555,y:665,t:1528143665604};\\\", \\\"{x:554,y:674,t:1528143665622};\\\", \\\"{x:552,y:678,t:1528143665638};\\\", \\\"{x:552,y:681,t:1528143665654};\\\", \\\"{x:553,y:679,t:1528143665694};\\\", \\\"{x:556,y:673,t:1528143665704};\\\", \\\"{x:563,y:660,t:1528143665721};\\\", \\\"{x:571,y:648,t:1528143665739};\\\", \\\"{x:580,y:636,t:1528143665754};\\\", \\\"{x:588,y:625,t:1528143665773};\\\", \\\"{x:594,y:615,t:1528143665788};\\\", \\\"{x:599,y:606,t:1528143665804};\\\", \\\"{x:599,y:604,t:1528143665821};\\\", \\\"{x:599,y:603,t:1528143665838};\\\", \\\"{x:599,y:602,t:1528143665861};\\\", \\\"{x:599,y:601,t:1528143665870};\\\", \\\"{x:599,y:600,t:1528143665888};\\\", \\\"{x:599,y:599,t:1528143665904};\\\", \\\"{x:599,y:598,t:1528143665921};\\\", \\\"{x:599,y:597,t:1528143665938};\\\", \\\"{x:599,y:596,t:1528143665957};\\\", \\\"{x:599,y:594,t:1528143665971};\\\", \\\"{x:602,y:591,t:1528143665989};\\\", \\\"{x:604,y:588,t:1528143666004};\\\", \\\"{x:605,y:584,t:1528143666021};\\\", \\\"{x:608,y:581,t:1528143666038};\\\", \\\"{x:609,y:579,t:1528143666054};\\\", \\\"{x:609,y:578,t:1528143666072};\\\", \\\"{x:610,y:578,t:1528143666110};\\\", \\\"{x:609,y:581,t:1528143666397};\\\", \\\"{x:606,y:587,t:1528143666405};\\\", \\\"{x:596,y:609,t:1528143666422};\\\", \\\"{x:588,y:630,t:1528143666438};\\\", \\\"{x:581,y:642,t:1528143666455};\\\", \\\"{x:576,y:655,t:1528143666471};\\\", \\\"{x:573,y:664,t:1528143666488};\\\", \\\"{x:569,y:676,t:1528143666505};\\\", \\\"{x:568,y:680,t:1528143666521};\\\", \\\"{x:566,y:684,t:1528143666538};\\\", \\\"{x:565,y:689,t:1528143666555};\\\", \\\"{x:562,y:694,t:1528143666572};\\\", \\\"{x:560,y:701,t:1528143666588};\\\", \\\"{x:559,y:704,t:1528143666605};\\\", \\\"{x:558,y:706,t:1528143666662};\\\", \\\"{x:555,y:708,t:1528143666672};\\\", \\\"{x:553,y:713,t:1528143666688};\\\", \\\"{x:552,y:714,t:1528143666705};\\\", \\\"{x:551,y:716,t:1528143666749};\\\", \\\"{x:550,y:716,t:1528143666765};\\\", \\\"{x:550,y:717,t:1528143666773};\\\", \\\"{x:549,y:719,t:1528143666788};\\\", \\\"{x:548,y:719,t:1528143666805};\\\", \\\"{x:547,y:721,t:1528143666823};\\\", \\\"{x:545,y:723,t:1528143666838};\\\", \\\"{x:544,y:724,t:1528143666855};\\\", \\\"{x:543,y:726,t:1528143666872};\\\", \\\"{x:542,y:727,t:1528143666888};\\\", \\\"{x:541,y:729,t:1528143666905};\\\", \\\"{x:538,y:732,t:1528143666922};\\\", \\\"{x:537,y:733,t:1528143666941};\\\", \\\"{x:534,y:733,t:1528143666981};\\\", \\\"{x:532,y:733,t:1528143666997};\\\", \\\"{x:531,y:734,t:1528143667118};\\\", \\\"{x:531,y:734,t:1528143667179};\\\", \\\"{x:531,y:732,t:1528143667205};\\\", \\\"{x:533,y:731,t:1528143667245};\\\", \\\"{x:535,y:731,t:1528143667325};\\\", \\\"{x:536,y:731,t:1528143667389};\\\", \\\"{x:540,y:728,t:1528143667405};\\\", \\\"{x:548,y:724,t:1528143667422};\\\", \\\"{x:562,y:718,t:1528143667440};\\\", \\\"{x:581,y:708,t:1528143667456};\\\", \\\"{x:613,y:696,t:1528143667472};\\\", \\\"{x:649,y:687,t:1528143667489};\\\", \\\"{x:683,y:677,t:1528143667506};\\\", \\\"{x:716,y:669,t:1528143667522};\\\", \\\"{x:755,y:660,t:1528143667539};\\\", \\\"{x:808,y:644,t:1528143667556};\\\", \\\"{x:885,y:625,t:1528143667572};\\\", \\\"{x:969,y:609,t:1528143667589};\\\", \\\"{x:1011,y:604,t:1528143667606};\\\", \\\"{x:1043,y:599,t:1528143667622};\\\", \\\"{x:1070,y:594,t:1528143667639};\\\", \\\"{x:1092,y:592,t:1528143667656};\\\", \\\"{x:1119,y:592,t:1528143667672};\\\", \\\"{x:1136,y:592,t:1528143667689};\\\", \\\"{x:1141,y:592,t:1528143667706};\\\", \\\"{x:1142,y:592,t:1528143667726};\\\" ] }, { \\\"rt\\\": 126633, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 477258, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"TTCWS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -J -J -11 AM-X -03 PM-B -F -E -I -F -I -I -I -I -J -11 AM-M -M -M -M -01 PM-E -E -I -I -K -A -A -A -K -K -K -A -A -A -09 AM-09 AM-J -09 AM-B -F -10 AM-10 AM-G -F -G -10 AM-11 AM-11 AM-12 PM-12 PM-01 PM-01 PM-02 PM-02 PM-03 PM-7-A -K -K -K -A -A -O -G -G -J -09 AM-05 PM-F -F -F -C -04 PM-04 PM-04 PM-04 PM-C -C -C -C -C -N -11 AM-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1136,y:592,t:1528143669831};\\\", \\\"{x:1120,y:601,t:1528143669842};\\\", \\\"{x:1068,y:622,t:1528143669857};\\\", \\\"{x:1027,y:640,t:1528143669875};\\\", \\\"{x:1003,y:648,t:1528143669891};\\\", \\\"{x:982,y:653,t:1528143669908};\\\", \\\"{x:957,y:662,t:1528143669925};\\\", \\\"{x:930,y:669,t:1528143669941};\\\", \\\"{x:926,y:670,t:1528143669957};\\\", \\\"{x:944,y:665,t:1528143679146};\\\", \\\"{x:1032,y:645,t:1528143679153};\\\", \\\"{x:1119,y:634,t:1528143679168};\\\", \\\"{x:1333,y:632,t:1528143679185};\\\", \\\"{x:1384,y:634,t:1528143679202};\\\", \\\"{x:1413,y:634,t:1528143679219};\\\", \\\"{x:1435,y:634,t:1528143679236};\\\", \\\"{x:1452,y:634,t:1528143679252};\\\", \\\"{x:1461,y:635,t:1528143679268};\\\", \\\"{x:1465,y:638,t:1528143679285};\\\", \\\"{x:1467,y:641,t:1528143679302};\\\", \\\"{x:1467,y:654,t:1528143679318};\\\", \\\"{x:1469,y:666,t:1528143679335};\\\", \\\"{x:1474,y:685,t:1528143679353};\\\", \\\"{x:1477,y:703,t:1528143679369};\\\", \\\"{x:1472,y:714,t:1528143679385};\\\", \\\"{x:1464,y:723,t:1528143679403};\\\", \\\"{x:1454,y:731,t:1528143679420};\\\", \\\"{x:1443,y:738,t:1528143679436};\\\", \\\"{x:1436,y:742,t:1528143679452};\\\", \\\"{x:1430,y:746,t:1528143679469};\\\", \\\"{x:1428,y:749,t:1528143679485};\\\", \\\"{x:1427,y:750,t:1528143679502};\\\", \\\"{x:1426,y:751,t:1528143679521};\\\", \\\"{x:1424,y:751,t:1528143679553};\\\", \\\"{x:1415,y:751,t:1528143679569};\\\", \\\"{x:1398,y:750,t:1528143679585};\\\", \\\"{x:1376,y:748,t:1528143679603};\\\", \\\"{x:1354,y:748,t:1528143679619};\\\", \\\"{x:1337,y:748,t:1528143679635};\\\", \\\"{x:1330,y:748,t:1528143679652};\\\", \\\"{x:1329,y:748,t:1528143679669};\\\", \\\"{x:1331,y:748,t:1528143679809};\\\", \\\"{x:1337,y:748,t:1528143679819};\\\", \\\"{x:1344,y:748,t:1528143679837};\\\", \\\"{x:1347,y:747,t:1528143679852};\\\", \\\"{x:1351,y:747,t:1528143679870};\\\", \\\"{x:1354,y:747,t:1528143679887};\\\", \\\"{x:1359,y:748,t:1528143679903};\\\", \\\"{x:1360,y:748,t:1528143679920};\\\", \\\"{x:1362,y:750,t:1528143679937};\\\", \\\"{x:1364,y:750,t:1528143679977};\\\", \\\"{x:1364,y:751,t:1528143680025};\\\", \\\"{x:1364,y:753,t:1528143680036};\\\", \\\"{x:1363,y:755,t:1528143680053};\\\", \\\"{x:1359,y:758,t:1528143680069};\\\", \\\"{x:1356,y:761,t:1528143680086};\\\", \\\"{x:1351,y:764,t:1528143680105};\\\", \\\"{x:1347,y:766,t:1528143680119};\\\", \\\"{x:1338,y:768,t:1528143680136};\\\", \\\"{x:1335,y:768,t:1528143680152};\\\", \\\"{x:1322,y:769,t:1528143680169};\\\", \\\"{x:1313,y:772,t:1528143680186};\\\", \\\"{x:1300,y:774,t:1528143680201};\\\", \\\"{x:1285,y:774,t:1528143680219};\\\", \\\"{x:1273,y:774,t:1528143680236};\\\", \\\"{x:1260,y:774,t:1528143680252};\\\", \\\"{x:1253,y:774,t:1528143680269};\\\", \\\"{x:1249,y:775,t:1528143680286};\\\", \\\"{x:1247,y:776,t:1528143680303};\\\", \\\"{x:1247,y:777,t:1528143680319};\\\", \\\"{x:1244,y:779,t:1528143680336};\\\", \\\"{x:1240,y:783,t:1528143680352};\\\", \\\"{x:1237,y:785,t:1528143680369};\\\", \\\"{x:1234,y:789,t:1528143680386};\\\", \\\"{x:1229,y:797,t:1528143680403};\\\", \\\"{x:1222,y:805,t:1528143680419};\\\", \\\"{x:1218,y:810,t:1528143680436};\\\", \\\"{x:1214,y:813,t:1528143680454};\\\", \\\"{x:1210,y:817,t:1528143680469};\\\", \\\"{x:1206,y:820,t:1528143680487};\\\", \\\"{x:1204,y:823,t:1528143680503};\\\", \\\"{x:1202,y:827,t:1528143680519};\\\", \\\"{x:1201,y:828,t:1528143680536};\\\", \\\"{x:1201,y:829,t:1528143680561};\\\", \\\"{x:1200,y:831,t:1528143680577};\\\", \\\"{x:1199,y:832,t:1528143680592};\\\", \\\"{x:1200,y:832,t:1528143680834};\\\", \\\"{x:1201,y:832,t:1528143680840};\\\", \\\"{x:1202,y:832,t:1528143680857};\\\", \\\"{x:1203,y:832,t:1528143680897};\\\", \\\"{x:1204,y:832,t:1528143680921};\\\", \\\"{x:1204,y:831,t:1528143680937};\\\", \\\"{x:1205,y:831,t:1528143680977};\\\", \\\"{x:1206,y:831,t:1528143680992};\\\", \\\"{x:1207,y:831,t:1528143681004};\\\", \\\"{x:1208,y:831,t:1528143681033};\\\", \\\"{x:1209,y:831,t:1528143681042};\\\", \\\"{x:1210,y:831,t:1528143681053};\\\", \\\"{x:1211,y:831,t:1528143681072};\\\", \\\"{x:1212,y:831,t:1528143681097};\\\", \\\"{x:1213,y:831,t:1528143681105};\\\", \\\"{x:1213,y:833,t:1528143683041};\\\", \\\"{x:1214,y:833,t:1528143683649};\\\", \\\"{x:1214,y:832,t:1528143683713};\\\", \\\"{x:1217,y:840,t:1528143684042};\\\", \\\"{x:1218,y:848,t:1528143684055};\\\", \\\"{x:1228,y:869,t:1528143684073};\\\", \\\"{x:1239,y:884,t:1528143684088};\\\", \\\"{x:1257,y:900,t:1528143684106};\\\", \\\"{x:1271,y:912,t:1528143684122};\\\", \\\"{x:1278,y:918,t:1528143684139};\\\", \\\"{x:1284,y:923,t:1528143684156};\\\", \\\"{x:1289,y:928,t:1528143684172};\\\", \\\"{x:1294,y:932,t:1528143684189};\\\", \\\"{x:1296,y:935,t:1528143684206};\\\", \\\"{x:1298,y:940,t:1528143684222};\\\", \\\"{x:1300,y:943,t:1528143684239};\\\", \\\"{x:1301,y:945,t:1528143684256};\\\", \\\"{x:1302,y:945,t:1528143684273};\\\", \\\"{x:1302,y:946,t:1528143684385};\\\", \\\"{x:1302,y:948,t:1528143684392};\\\", \\\"{x:1302,y:949,t:1528143684417};\\\", \\\"{x:1302,y:950,t:1528143684433};\\\", \\\"{x:1302,y:952,t:1528143684440};\\\", \\\"{x:1302,y:953,t:1528143684465};\\\", \\\"{x:1302,y:955,t:1528143684472};\\\", \\\"{x:1301,y:958,t:1528143684490};\\\", \\\"{x:1300,y:959,t:1528143684507};\\\", \\\"{x:1300,y:960,t:1528143684523};\\\", \\\"{x:1299,y:961,t:1528143684539};\\\", \\\"{x:1299,y:962,t:1528143684555};\\\", \\\"{x:1299,y:964,t:1528143684572};\\\", \\\"{x:1298,y:965,t:1528143684589};\\\", \\\"{x:1297,y:967,t:1528143684605};\\\", \\\"{x:1296,y:969,t:1528143684622};\\\", \\\"{x:1295,y:970,t:1528143684648};\\\", \\\"{x:1295,y:972,t:1528143684672};\\\", \\\"{x:1294,y:972,t:1528143684840};\\\", \\\"{x:1294,y:971,t:1528143685897};\\\", \\\"{x:1295,y:971,t:1528143685908};\\\", \\\"{x:1300,y:969,t:1528143685924};\\\", \\\"{x:1303,y:967,t:1528143685941};\\\", \\\"{x:1309,y:965,t:1528143685957};\\\", \\\"{x:1313,y:963,t:1528143685974};\\\", \\\"{x:1315,y:962,t:1528143685991};\\\", \\\"{x:1316,y:962,t:1528143686008};\\\", \\\"{x:1317,y:962,t:1528143686025};\\\", \\\"{x:1319,y:961,t:1528143686040};\\\", \\\"{x:1322,y:959,t:1528143686058};\\\", \\\"{x:1327,y:957,t:1528143686074};\\\", \\\"{x:1332,y:955,t:1528143686091};\\\", \\\"{x:1334,y:955,t:1528143686121};\\\", \\\"{x:1335,y:955,t:1528143686136};\\\", \\\"{x:1336,y:955,t:1528143686145};\\\", \\\"{x:1338,y:955,t:1528143686158};\\\", \\\"{x:1343,y:953,t:1528143686174};\\\", \\\"{x:1350,y:952,t:1528143686191};\\\", \\\"{x:1358,y:951,t:1528143686207};\\\", \\\"{x:1368,y:951,t:1528143686225};\\\", \\\"{x:1375,y:950,t:1528143686240};\\\", \\\"{x:1379,y:949,t:1528143686258};\\\", \\\"{x:1382,y:949,t:1528143686275};\\\", \\\"{x:1385,y:949,t:1528143686291};\\\", \\\"{x:1388,y:948,t:1528143686308};\\\", \\\"{x:1390,y:948,t:1528143686325};\\\", \\\"{x:1395,y:947,t:1528143686340};\\\", \\\"{x:1400,y:945,t:1528143686357};\\\", \\\"{x:1409,y:945,t:1528143686374};\\\", \\\"{x:1423,y:944,t:1528143686391};\\\", \\\"{x:1435,y:943,t:1528143686408};\\\", \\\"{x:1453,y:943,t:1528143686425};\\\", \\\"{x:1463,y:943,t:1528143686441};\\\", \\\"{x:1470,y:943,t:1528143686457};\\\", \\\"{x:1474,y:943,t:1528143686474};\\\", \\\"{x:1477,y:943,t:1528143686491};\\\", \\\"{x:1478,y:943,t:1528143686508};\\\", \\\"{x:1478,y:942,t:1528143686525};\\\", \\\"{x:1479,y:941,t:1528143686542};\\\", \\\"{x:1480,y:941,t:1528143686801};\\\", \\\"{x:1481,y:937,t:1528143686809};\\\", \\\"{x:1482,y:908,t:1528143686825};\\\", \\\"{x:1482,y:888,t:1528143686841};\\\", \\\"{x:1482,y:877,t:1528143686857};\\\", \\\"{x:1482,y:865,t:1528143686874};\\\", \\\"{x:1482,y:859,t:1528143686891};\\\", \\\"{x:1480,y:854,t:1528143686908};\\\", \\\"{x:1480,y:853,t:1528143686924};\\\", \\\"{x:1480,y:852,t:1528143687016};\\\", \\\"{x:1480,y:849,t:1528143687146};\\\", \\\"{x:1480,y:848,t:1528143687159};\\\", \\\"{x:1480,y:846,t:1528143687175};\\\", \\\"{x:1480,y:845,t:1528143687193};\\\", \\\"{x:1480,y:844,t:1528143687241};\\\", \\\"{x:1480,y:843,t:1528143687369};\\\", \\\"{x:1481,y:839,t:1528143687376};\\\", \\\"{x:1482,y:836,t:1528143687392};\\\", \\\"{x:1485,y:827,t:1528143687409};\\\", \\\"{x:1487,y:822,t:1528143687425};\\\", \\\"{x:1488,y:820,t:1528143687442};\\\", \\\"{x:1488,y:819,t:1528143687458};\\\", \\\"{x:1489,y:818,t:1528143687561};\\\", \\\"{x:1489,y:819,t:1528143687584};\\\", \\\"{x:1491,y:828,t:1528143687593};\\\", \\\"{x:1498,y:847,t:1528143687608};\\\", \\\"{x:1507,y:869,t:1528143687624};\\\", \\\"{x:1514,y:885,t:1528143687641};\\\", \\\"{x:1524,y:901,t:1528143687658};\\\", \\\"{x:1532,y:912,t:1528143687675};\\\", \\\"{x:1538,y:922,t:1528143687691};\\\", \\\"{x:1542,y:926,t:1528143687708};\\\", \\\"{x:1544,y:931,t:1528143687725};\\\", \\\"{x:1550,y:940,t:1528143687741};\\\", \\\"{x:1559,y:954,t:1528143687758};\\\", \\\"{x:1567,y:964,t:1528143687775};\\\", \\\"{x:1572,y:971,t:1528143687792};\\\", \\\"{x:1573,y:973,t:1528143687808};\\\", \\\"{x:1574,y:974,t:1528143687825};\\\", \\\"{x:1575,y:975,t:1528143687842};\\\", \\\"{x:1575,y:977,t:1528143687858};\\\", \\\"{x:1576,y:977,t:1528143687929};\\\", \\\"{x:1571,y:977,t:1528143688985};\\\", \\\"{x:1562,y:971,t:1528143688993};\\\", \\\"{x:1542,y:957,t:1528143689011};\\\", \\\"{x:1521,y:947,t:1528143689027};\\\", \\\"{x:1501,y:939,t:1528143689043};\\\", \\\"{x:1483,y:932,t:1528143689060};\\\", \\\"{x:1469,y:925,t:1528143689077};\\\", \\\"{x:1456,y:921,t:1528143689093};\\\", \\\"{x:1445,y:918,t:1528143689110};\\\", \\\"{x:1439,y:916,t:1528143689127};\\\", \\\"{x:1433,y:914,t:1528143689142};\\\", \\\"{x:1431,y:914,t:1528143689159};\\\", \\\"{x:1429,y:913,t:1528143689177};\\\", \\\"{x:1428,y:913,t:1528143689200};\\\", \\\"{x:1427,y:912,t:1528143689265};\\\", \\\"{x:1425,y:912,t:1528143689277};\\\", \\\"{x:1421,y:911,t:1528143689294};\\\", \\\"{x:1415,y:909,t:1528143689310};\\\", \\\"{x:1411,y:906,t:1528143689326};\\\", \\\"{x:1403,y:901,t:1528143689344};\\\", \\\"{x:1393,y:892,t:1528143689360};\\\", \\\"{x:1377,y:869,t:1528143689377};\\\", \\\"{x:1368,y:847,t:1528143689396};\\\", \\\"{x:1359,y:814,t:1528143689410};\\\", \\\"{x:1347,y:773,t:1528143689427};\\\", \\\"{x:1338,y:740,t:1528143689444};\\\", \\\"{x:1335,y:724,t:1528143689460};\\\", \\\"{x:1335,y:717,t:1528143689477};\\\", \\\"{x:1334,y:713,t:1528143689494};\\\", \\\"{x:1334,y:711,t:1528143689509};\\\", \\\"{x:1333,y:710,t:1528143689526};\\\", \\\"{x:1332,y:710,t:1528143689641};\\\", \\\"{x:1331,y:710,t:1528143689649};\\\", \\\"{x:1328,y:712,t:1528143689660};\\\", \\\"{x:1323,y:715,t:1528143689677};\\\", \\\"{x:1320,y:719,t:1528143689693};\\\", \\\"{x:1320,y:722,t:1528143689711};\\\", \\\"{x:1320,y:728,t:1528143689726};\\\", \\\"{x:1320,y:731,t:1528143689744};\\\", \\\"{x:1320,y:733,t:1528143689760};\\\", \\\"{x:1320,y:734,t:1528143689777};\\\", \\\"{x:1320,y:736,t:1528143689795};\\\", \\\"{x:1320,y:738,t:1528143689811};\\\", \\\"{x:1324,y:743,t:1528143689827};\\\", \\\"{x:1327,y:747,t:1528143689844};\\\", \\\"{x:1329,y:750,t:1528143689861};\\\", \\\"{x:1330,y:750,t:1528143689876};\\\", \\\"{x:1330,y:751,t:1528143689894};\\\", \\\"{x:1331,y:752,t:1528143689911};\\\", \\\"{x:1332,y:753,t:1528143689926};\\\", \\\"{x:1332,y:754,t:1528143689945};\\\", \\\"{x:1333,y:754,t:1528143689961};\\\", \\\"{x:1334,y:755,t:1528143689976};\\\", \\\"{x:1335,y:756,t:1528143689995};\\\", \\\"{x:1336,y:757,t:1528143690025};\\\", \\\"{x:1337,y:757,t:1528143690049};\\\", \\\"{x:1338,y:757,t:1528143690065};\\\", \\\"{x:1339,y:757,t:1528143690077};\\\", \\\"{x:1340,y:757,t:1528143690094};\\\", \\\"{x:1341,y:757,t:1528143690110};\\\", \\\"{x:1343,y:755,t:1528143690128};\\\", \\\"{x:1344,y:755,t:1528143690153};\\\", \\\"{x:1345,y:755,t:1528143690320};\\\", \\\"{x:1345,y:753,t:1528143690513};\\\", \\\"{x:1345,y:752,t:1528143690527};\\\", \\\"{x:1345,y:743,t:1528143690545};\\\", \\\"{x:1345,y:739,t:1528143690561};\\\", \\\"{x:1345,y:729,t:1528143690578};\\\", \\\"{x:1345,y:719,t:1528143690595};\\\", \\\"{x:1345,y:708,t:1528143690611};\\\", \\\"{x:1345,y:693,t:1528143690629};\\\", \\\"{x:1342,y:675,t:1528143690646};\\\", \\\"{x:1338,y:651,t:1528143690661};\\\", \\\"{x:1335,y:629,t:1528143690677};\\\", \\\"{x:1333,y:611,t:1528143690694};\\\", \\\"{x:1328,y:594,t:1528143690711};\\\", \\\"{x:1323,y:583,t:1528143690728};\\\", \\\"{x:1319,y:578,t:1528143690745};\\\", \\\"{x:1319,y:577,t:1528143690761};\\\", \\\"{x:1318,y:577,t:1528143690792};\\\", \\\"{x:1317,y:576,t:1528143690801};\\\", \\\"{x:1316,y:576,t:1528143690816};\\\", \\\"{x:1314,y:576,t:1528143690827};\\\", \\\"{x:1310,y:576,t:1528143690845};\\\", \\\"{x:1307,y:576,t:1528143690861};\\\", \\\"{x:1304,y:576,t:1528143690877};\\\", \\\"{x:1303,y:576,t:1528143690961};\\\", \\\"{x:1299,y:573,t:1528143690978};\\\", \\\"{x:1298,y:571,t:1528143690995};\\\", \\\"{x:1297,y:569,t:1528143691012};\\\", \\\"{x:1296,y:569,t:1528143691028};\\\", \\\"{x:1296,y:568,t:1528143691049};\\\", \\\"{x:1294,y:568,t:1528143691257};\\\", \\\"{x:1293,y:567,t:1528143691346};\\\", \\\"{x:1292,y:566,t:1528143691361};\\\", \\\"{x:1290,y:563,t:1528143691378};\\\", \\\"{x:1288,y:560,t:1528143691395};\\\", \\\"{x:1287,y:558,t:1528143691412};\\\", \\\"{x:1286,y:558,t:1528143691428};\\\", \\\"{x:1286,y:557,t:1528143691445};\\\", \\\"{x:1285,y:556,t:1528143691617};\\\", \\\"{x:1284,y:556,t:1528143691656};\\\", \\\"{x:1283,y:558,t:1528143694210};\\\", \\\"{x:1284,y:565,t:1528143694231};\\\", \\\"{x:1287,y:570,t:1528143694248};\\\", \\\"{x:1289,y:573,t:1528143694265};\\\", \\\"{x:1291,y:577,t:1528143694280};\\\", \\\"{x:1291,y:578,t:1528143694328};\\\", \\\"{x:1292,y:578,t:1528143694344};\\\", \\\"{x:1292,y:580,t:1528143694352};\\\", \\\"{x:1293,y:582,t:1528143694364};\\\", \\\"{x:1297,y:588,t:1528143694381};\\\", \\\"{x:1299,y:593,t:1528143694397};\\\", \\\"{x:1302,y:599,t:1528143694414};\\\", \\\"{x:1303,y:601,t:1528143694431};\\\", \\\"{x:1304,y:602,t:1528143694447};\\\", \\\"{x:1304,y:606,t:1528143695289};\\\", \\\"{x:1304,y:616,t:1528143695298};\\\", \\\"{x:1304,y:628,t:1528143695315};\\\", \\\"{x:1304,y:639,t:1528143695331};\\\", \\\"{x:1304,y:652,t:1528143695348};\\\", \\\"{x:1304,y:660,t:1528143695365};\\\", \\\"{x:1304,y:669,t:1528143695382};\\\", \\\"{x:1304,y:674,t:1528143695398};\\\", \\\"{x:1304,y:680,t:1528143695414};\\\", \\\"{x:1306,y:689,t:1528143695431};\\\", \\\"{x:1306,y:694,t:1528143695448};\\\", \\\"{x:1307,y:698,t:1528143695465};\\\", \\\"{x:1307,y:701,t:1528143695481};\\\", \\\"{x:1307,y:702,t:1528143695497};\\\", \\\"{x:1307,y:703,t:1528143695560};\\\", \\\"{x:1307,y:705,t:1528143695576};\\\", \\\"{x:1307,y:707,t:1528143695584};\\\", \\\"{x:1307,y:710,t:1528143695597};\\\", \\\"{x:1305,y:717,t:1528143695614};\\\", \\\"{x:1301,y:726,t:1528143695632};\\\", \\\"{x:1295,y:740,t:1528143695647};\\\", \\\"{x:1282,y:770,t:1528143695665};\\\", \\\"{x:1277,y:789,t:1528143695682};\\\", \\\"{x:1272,y:801,t:1528143695698};\\\", \\\"{x:1268,y:808,t:1528143695714};\\\", \\\"{x:1265,y:812,t:1528143695732};\\\", \\\"{x:1265,y:813,t:1528143695748};\\\", \\\"{x:1264,y:814,t:1528143695765};\\\", \\\"{x:1263,y:816,t:1528143695782};\\\", \\\"{x:1262,y:816,t:1528143695799};\\\", \\\"{x:1262,y:817,t:1528143695814};\\\", \\\"{x:1260,y:818,t:1528143695831};\\\", \\\"{x:1259,y:818,t:1528143695904};\\\", \\\"{x:1258,y:815,t:1528143695915};\\\", \\\"{x:1253,y:804,t:1528143695932};\\\", \\\"{x:1250,y:793,t:1528143695948};\\\", \\\"{x:1249,y:791,t:1528143695964};\\\", \\\"{x:1248,y:791,t:1528143695982};\\\", \\\"{x:1248,y:790,t:1528143696049};\\\", \\\"{x:1246,y:789,t:1528143696065};\\\", \\\"{x:1244,y:788,t:1528143696082};\\\", \\\"{x:1240,y:787,t:1528143696099};\\\", \\\"{x:1236,y:785,t:1528143696115};\\\", \\\"{x:1231,y:785,t:1528143696132};\\\", \\\"{x:1226,y:785,t:1528143696149};\\\", \\\"{x:1223,y:784,t:1528143696165};\\\", \\\"{x:1221,y:784,t:1528143696182};\\\", \\\"{x:1220,y:783,t:1528143696199};\\\", \\\"{x:1218,y:782,t:1528143696215};\\\", \\\"{x:1215,y:781,t:1528143696232};\\\", \\\"{x:1211,y:778,t:1528143696249};\\\", \\\"{x:1209,y:778,t:1528143696266};\\\", \\\"{x:1208,y:777,t:1528143696282};\\\", \\\"{x:1205,y:777,t:1528143696299};\\\", \\\"{x:1199,y:774,t:1528143696316};\\\", \\\"{x:1194,y:773,t:1528143696332};\\\", \\\"{x:1190,y:771,t:1528143696349};\\\", \\\"{x:1188,y:771,t:1528143696366};\\\", \\\"{x:1185,y:771,t:1528143696382};\\\", \\\"{x:1183,y:771,t:1528143696400};\\\", \\\"{x:1181,y:771,t:1528143696416};\\\", \\\"{x:1178,y:771,t:1528143696432};\\\", \\\"{x:1177,y:771,t:1528143696449};\\\", \\\"{x:1176,y:771,t:1528143696537};\\\", \\\"{x:1175,y:771,t:1528143696550};\\\", \\\"{x:1174,y:771,t:1528143696569};\\\", \\\"{x:1173,y:771,t:1528143696601};\\\", \\\"{x:1172,y:771,t:1528143696761};\\\", \\\"{x:1172,y:770,t:1528143696769};\\\", \\\"{x:1171,y:767,t:1528143696783};\\\", \\\"{x:1171,y:761,t:1528143696799};\\\", \\\"{x:1171,y:759,t:1528143696816};\\\", \\\"{x:1175,y:755,t:1528143696832};\\\", \\\"{x:1181,y:753,t:1528143697057};\\\", \\\"{x:1191,y:751,t:1528143697066};\\\", \\\"{x:1229,y:751,t:1528143697083};\\\", \\\"{x:1271,y:751,t:1528143697099};\\\", \\\"{x:1301,y:751,t:1528143697117};\\\", \\\"{x:1327,y:751,t:1528143697133};\\\", \\\"{x:1353,y:751,t:1528143697149};\\\", \\\"{x:1375,y:750,t:1528143697166};\\\", \\\"{x:1385,y:747,t:1528143697183};\\\", \\\"{x:1390,y:746,t:1528143697200};\\\", \\\"{x:1390,y:745,t:1528143697217};\\\", \\\"{x:1391,y:744,t:1528143697233};\\\", \\\"{x:1391,y:742,t:1528143697250};\\\", \\\"{x:1391,y:739,t:1528143697266};\\\", \\\"{x:1391,y:736,t:1528143697283};\\\", \\\"{x:1389,y:732,t:1528143697300};\\\", \\\"{x:1384,y:729,t:1528143697316};\\\", \\\"{x:1379,y:727,t:1528143697333};\\\", \\\"{x:1377,y:726,t:1528143697350};\\\", \\\"{x:1376,y:725,t:1528143697465};\\\", \\\"{x:1375,y:723,t:1528143697505};\\\", \\\"{x:1374,y:722,t:1528143697529};\\\", \\\"{x:1374,y:721,t:1528143697545};\\\", \\\"{x:1373,y:721,t:1528143697552};\\\", \\\"{x:1372,y:720,t:1528143697567};\\\", \\\"{x:1370,y:718,t:1528143697583};\\\", \\\"{x:1368,y:717,t:1528143697600};\\\", \\\"{x:1367,y:715,t:1528143697616};\\\", \\\"{x:1366,y:715,t:1528143697633};\\\", \\\"{x:1365,y:715,t:1528143697650};\\\", \\\"{x:1364,y:714,t:1528143697777};\\\", \\\"{x:1362,y:714,t:1528143697793};\\\", \\\"{x:1358,y:712,t:1528143697800};\\\", \\\"{x:1348,y:709,t:1528143697817};\\\", \\\"{x:1333,y:705,t:1528143697833};\\\", \\\"{x:1321,y:704,t:1528143697850};\\\", \\\"{x:1306,y:704,t:1528143697867};\\\", \\\"{x:1285,y:704,t:1528143697883};\\\", \\\"{x:1262,y:704,t:1528143697900};\\\", \\\"{x:1235,y:704,t:1528143697917};\\\", \\\"{x:1213,y:710,t:1528143697934};\\\", \\\"{x:1195,y:715,t:1528143697950};\\\", \\\"{x:1184,y:720,t:1528143697967};\\\", \\\"{x:1177,y:723,t:1528143697983};\\\", \\\"{x:1170,y:727,t:1528143698000};\\\", \\\"{x:1169,y:729,t:1528143698017};\\\", \\\"{x:1168,y:729,t:1528143698034};\\\", \\\"{x:1167,y:730,t:1528143698057};\\\", \\\"{x:1167,y:731,t:1528143698067};\\\", \\\"{x:1166,y:732,t:1528143698089};\\\", \\\"{x:1165,y:734,t:1528143698100};\\\", \\\"{x:1163,y:738,t:1528143698117};\\\", \\\"{x:1162,y:742,t:1528143698134};\\\", \\\"{x:1161,y:745,t:1528143698150};\\\", \\\"{x:1161,y:747,t:1528143698169};\\\", \\\"{x:1161,y:749,t:1528143698184};\\\", \\\"{x:1161,y:753,t:1528143698201};\\\", \\\"{x:1161,y:755,t:1528143698216};\\\", \\\"{x:1161,y:756,t:1528143698233};\\\", \\\"{x:1161,y:757,t:1528143698250};\\\", \\\"{x:1162,y:759,t:1528143698266};\\\", \\\"{x:1164,y:760,t:1528143698283};\\\", \\\"{x:1167,y:763,t:1528143698299};\\\", \\\"{x:1168,y:763,t:1528143698316};\\\", \\\"{x:1169,y:763,t:1528143698335};\\\", \\\"{x:1170,y:763,t:1528143698352};\\\", \\\"{x:1171,y:763,t:1528143698367};\\\", \\\"{x:1173,y:762,t:1528143698383};\\\", \\\"{x:1174,y:762,t:1528143698400};\\\", \\\"{x:1176,y:761,t:1528143698417};\\\", \\\"{x:1178,y:760,t:1528143698434};\\\", \\\"{x:1179,y:759,t:1528143698450};\\\", \\\"{x:1180,y:759,t:1528143698568};\\\", \\\"{x:1181,y:759,t:1528143699897};\\\", \\\"{x:1184,y:759,t:1528143699904};\\\", \\\"{x:1192,y:759,t:1528143699919};\\\", \\\"{x:1224,y:768,t:1528143699935};\\\", \\\"{x:1285,y:783,t:1528143699953};\\\", \\\"{x:1354,y:793,t:1528143699968};\\\", \\\"{x:1482,y:804,t:1528143699985};\\\", \\\"{x:1537,y:810,t:1528143700002};\\\", \\\"{x:1561,y:810,t:1528143700019};\\\", \\\"{x:1565,y:810,t:1528143700035};\\\", \\\"{x:1563,y:807,t:1528143700089};\\\", \\\"{x:1554,y:802,t:1528143700102};\\\", \\\"{x:1542,y:796,t:1528143700118};\\\", \\\"{x:1525,y:789,t:1528143700135};\\\", \\\"{x:1498,y:780,t:1528143700153};\\\", \\\"{x:1484,y:775,t:1528143700169};\\\", \\\"{x:1471,y:773,t:1528143700186};\\\", \\\"{x:1464,y:770,t:1528143700202};\\\", \\\"{x:1456,y:767,t:1528143700218};\\\", \\\"{x:1453,y:765,t:1528143700236};\\\", \\\"{x:1449,y:762,t:1528143700252};\\\", \\\"{x:1444,y:760,t:1528143700269};\\\", \\\"{x:1433,y:752,t:1528143700286};\\\", \\\"{x:1421,y:746,t:1528143700303};\\\", \\\"{x:1416,y:743,t:1528143700319};\\\", \\\"{x:1416,y:742,t:1528143700336};\\\", \\\"{x:1415,y:741,t:1528143700353};\\\", \\\"{x:1414,y:740,t:1528143700369};\\\", \\\"{x:1413,y:739,t:1528143700385};\\\", \\\"{x:1412,y:736,t:1528143700402};\\\", \\\"{x:1406,y:730,t:1528143700419};\\\", \\\"{x:1403,y:728,t:1528143700436};\\\", \\\"{x:1400,y:725,t:1528143700453};\\\", \\\"{x:1398,y:724,t:1528143700469};\\\", \\\"{x:1396,y:723,t:1528143700486};\\\", \\\"{x:1395,y:723,t:1528143700503};\\\", \\\"{x:1391,y:722,t:1528143700520};\\\", \\\"{x:1385,y:720,t:1528143700535};\\\", \\\"{x:1377,y:717,t:1528143700553};\\\", \\\"{x:1372,y:716,t:1528143700568};\\\", \\\"{x:1370,y:714,t:1528143700585};\\\", \\\"{x:1368,y:714,t:1528143700608};\\\", \\\"{x:1367,y:714,t:1528143700673};\\\", \\\"{x:1366,y:714,t:1528143700817};\\\", \\\"{x:1365,y:714,t:1528143700833};\\\", \\\"{x:1364,y:714,t:1528143701025};\\\", \\\"{x:1363,y:712,t:1528143701041};\\\", \\\"{x:1361,y:709,t:1528143701057};\\\", \\\"{x:1359,y:706,t:1528143701069};\\\", \\\"{x:1359,y:705,t:1528143701086};\\\", \\\"{x:1357,y:703,t:1528143701102};\\\", \\\"{x:1356,y:702,t:1528143701119};\\\", \\\"{x:1355,y:701,t:1528143701377};\\\", \\\"{x:1354,y:701,t:1528143701417};\\\", \\\"{x:1353,y:701,t:1528143701473};\\\", \\\"{x:1352,y:701,t:1528143701489};\\\", \\\"{x:1351,y:701,t:1528143701504};\\\", \\\"{x:1350,y:701,t:1528143701520};\\\", \\\"{x:1347,y:701,t:1528143701536};\\\", \\\"{x:1346,y:701,t:1528143701553};\\\", \\\"{x:1346,y:702,t:1528143705313};\\\", \\\"{x:1346,y:703,t:1528143705324};\\\", \\\"{x:1347,y:704,t:1528143705340};\\\", \\\"{x:1348,y:704,t:1528143705361};\\\", \\\"{x:1349,y:705,t:1528143705377};\\\", \\\"{x:1350,y:706,t:1528143705389};\\\", \\\"{x:1351,y:707,t:1528143705407};\\\", \\\"{x:1351,y:708,t:1528143705422};\\\", \\\"{x:1351,y:709,t:1528143705449};\\\", \\\"{x:1352,y:710,t:1528143705457};\\\", \\\"{x:1356,y:713,t:1528143705473};\\\", \\\"{x:1362,y:720,t:1528143705490};\\\", \\\"{x:1365,y:727,t:1528143705506};\\\", \\\"{x:1366,y:734,t:1528143705523};\\\", \\\"{x:1367,y:739,t:1528143705540};\\\", \\\"{x:1371,y:749,t:1528143705557};\\\", \\\"{x:1374,y:759,t:1528143705573};\\\", \\\"{x:1375,y:766,t:1528143705589};\\\", \\\"{x:1376,y:771,t:1528143705606};\\\", \\\"{x:1379,y:778,t:1528143705623};\\\", \\\"{x:1383,y:794,t:1528143705640};\\\", \\\"{x:1389,y:815,t:1528143705657};\\\", \\\"{x:1390,y:821,t:1528143705673};\\\", \\\"{x:1391,y:826,t:1528143705690};\\\", \\\"{x:1392,y:832,t:1528143705707};\\\", \\\"{x:1395,y:845,t:1528143705723};\\\", \\\"{x:1400,y:858,t:1528143705739};\\\", \\\"{x:1406,y:870,t:1528143705757};\\\", \\\"{x:1408,y:872,t:1528143705774};\\\", \\\"{x:1408,y:873,t:1528143705790};\\\", \\\"{x:1408,y:874,t:1528143705817};\\\", \\\"{x:1409,y:876,t:1528143705824};\\\", \\\"{x:1411,y:878,t:1528143705840};\\\", \\\"{x:1413,y:884,t:1528143705857};\\\", \\\"{x:1414,y:886,t:1528143705873};\\\", \\\"{x:1415,y:890,t:1528143705890};\\\", \\\"{x:1419,y:895,t:1528143705906};\\\", \\\"{x:1422,y:899,t:1528143705924};\\\", \\\"{x:1424,y:901,t:1528143705939};\\\", \\\"{x:1427,y:905,t:1528143705957};\\\", \\\"{x:1434,y:916,t:1528143705974};\\\", \\\"{x:1441,y:927,t:1528143705989};\\\", \\\"{x:1449,y:938,t:1528143706007};\\\", \\\"{x:1455,y:944,t:1528143706024};\\\", \\\"{x:1457,y:947,t:1528143706040};\\\", \\\"{x:1458,y:948,t:1528143706072};\\\", \\\"{x:1459,y:948,t:1528143706091};\\\", \\\"{x:1463,y:951,t:1528143706106};\\\", \\\"{x:1467,y:957,t:1528143706124};\\\", \\\"{x:1469,y:961,t:1528143706140};\\\", \\\"{x:1471,y:964,t:1528143706157};\\\", \\\"{x:1471,y:966,t:1528143706174};\\\", \\\"{x:1470,y:966,t:1528143707032};\\\", \\\"{x:1469,y:966,t:1528143707040};\\\", \\\"{x:1455,y:953,t:1528143707057};\\\", \\\"{x:1435,y:920,t:1528143707074};\\\", \\\"{x:1413,y:886,t:1528143707090};\\\", \\\"{x:1392,y:858,t:1528143707107};\\\", \\\"{x:1377,y:840,t:1528143707124};\\\", \\\"{x:1361,y:827,t:1528143707140};\\\", \\\"{x:1343,y:816,t:1528143707157};\\\", \\\"{x:1329,y:812,t:1528143707175};\\\", \\\"{x:1312,y:809,t:1528143707190};\\\", \\\"{x:1298,y:809,t:1528143707207};\\\", \\\"{x:1278,y:813,t:1528143707223};\\\", \\\"{x:1261,y:818,t:1528143707240};\\\", \\\"{x:1242,y:823,t:1528143707257};\\\", \\\"{x:1222,y:829,t:1528143707274};\\\", \\\"{x:1201,y:830,t:1528143707291};\\\", \\\"{x:1186,y:831,t:1528143707308};\\\", \\\"{x:1171,y:831,t:1528143707325};\\\", \\\"{x:1156,y:831,t:1528143707341};\\\", \\\"{x:1141,y:831,t:1528143707357};\\\", \\\"{x:1129,y:834,t:1528143707375};\\\", \\\"{x:1117,y:838,t:1528143707390};\\\", \\\"{x:1110,y:840,t:1528143707408};\\\", \\\"{x:1102,y:845,t:1528143707424};\\\", \\\"{x:1097,y:848,t:1528143707441};\\\", \\\"{x:1091,y:856,t:1528143707458};\\\", \\\"{x:1086,y:866,t:1528143707475};\\\", \\\"{x:1079,y:880,t:1528143707491};\\\", \\\"{x:1073,y:893,t:1528143707507};\\\", \\\"{x:1067,y:908,t:1528143707524};\\\", \\\"{x:1059,y:925,t:1528143707542};\\\", \\\"{x:1055,y:939,t:1528143707557};\\\", \\\"{x:1053,y:951,t:1528143707575};\\\", \\\"{x:1051,y:956,t:1528143707591};\\\", \\\"{x:1050,y:959,t:1528143707608};\\\", \\\"{x:1050,y:960,t:1528143707624};\\\", \\\"{x:1050,y:961,t:1528143707641};\\\", \\\"{x:1050,y:963,t:1528143707658};\\\", \\\"{x:1050,y:965,t:1528143707681};\\\", \\\"{x:1050,y:966,t:1528143707705};\\\", \\\"{x:1049,y:967,t:1528143707761};\\\", \\\"{x:1051,y:967,t:1528143707849};\\\", \\\"{x:1054,y:963,t:1528143707858};\\\", \\\"{x:1062,y:950,t:1528143707874};\\\", \\\"{x:1072,y:939,t:1528143707891};\\\", \\\"{x:1078,y:931,t:1528143707907};\\\", \\\"{x:1086,y:920,t:1528143707924};\\\", \\\"{x:1093,y:910,t:1528143707941};\\\", \\\"{x:1099,y:899,t:1528143707958};\\\", \\\"{x:1105,y:889,t:1528143707974};\\\", \\\"{x:1111,y:877,t:1528143707991};\\\", \\\"{x:1123,y:853,t:1528143708008};\\\", \\\"{x:1131,y:837,t:1528143708024};\\\", \\\"{x:1140,y:822,t:1528143708041};\\\", \\\"{x:1145,y:808,t:1528143708058};\\\", \\\"{x:1149,y:803,t:1528143708074};\\\", \\\"{x:1153,y:795,t:1528143708091};\\\", \\\"{x:1157,y:789,t:1528143708109};\\\", \\\"{x:1161,y:780,t:1528143708124};\\\", \\\"{x:1164,y:775,t:1528143708141};\\\", \\\"{x:1165,y:771,t:1528143708159};\\\", \\\"{x:1166,y:769,t:1528143708174};\\\", \\\"{x:1166,y:768,t:1528143708216};\\\", \\\"{x:1166,y:767,t:1528143708225};\\\", \\\"{x:1167,y:764,t:1528143708242};\\\", \\\"{x:1168,y:763,t:1528143708258};\\\", \\\"{x:1168,y:761,t:1528143708275};\\\", \\\"{x:1168,y:760,t:1528143708291};\\\", \\\"{x:1168,y:756,t:1528143708308};\\\", \\\"{x:1171,y:749,t:1528143708325};\\\", \\\"{x:1172,y:746,t:1528143708341};\\\", \\\"{x:1173,y:744,t:1528143708358};\\\", \\\"{x:1173,y:745,t:1528143708657};\\\", \\\"{x:1173,y:748,t:1528143708664};\\\", \\\"{x:1173,y:749,t:1528143708675};\\\", \\\"{x:1173,y:752,t:1528143708691};\\\", \\\"{x:1173,y:754,t:1528143708712};\\\", \\\"{x:1173,y:755,t:1528143710313};\\\", \\\"{x:1173,y:757,t:1528143710327};\\\", \\\"{x:1173,y:758,t:1528143710344};\\\", \\\"{x:1173,y:760,t:1528143710360};\\\", \\\"{x:1175,y:762,t:1528143710376};\\\", \\\"{x:1175,y:763,t:1528143710396};\\\", \\\"{x:1175,y:764,t:1528143710409};\\\", \\\"{x:1176,y:766,t:1528143710426};\\\", \\\"{x:1177,y:767,t:1528143710443};\\\", \\\"{x:1178,y:768,t:1528143710459};\\\", \\\"{x:1178,y:769,t:1528143710476};\\\", \\\"{x:1179,y:770,t:1528143710494};\\\", \\\"{x:1179,y:771,t:1528143710544};\\\", \\\"{x:1179,y:772,t:1528143710689};\\\", \\\"{x:1180,y:773,t:1528143710977};\\\", \\\"{x:1180,y:771,t:1528143711289};\\\", \\\"{x:1180,y:769,t:1528143711297};\\\", \\\"{x:1180,y:767,t:1528143711311};\\\", \\\"{x:1180,y:766,t:1528143711328};\\\", \\\"{x:1179,y:763,t:1528143711343};\\\", \\\"{x:1176,y:759,t:1528143711361};\\\", \\\"{x:1174,y:758,t:1528143711378};\\\", \\\"{x:1174,y:759,t:1528143711945};\\\", \\\"{x:1175,y:763,t:1528143711962};\\\", \\\"{x:1176,y:766,t:1528143711978};\\\", \\\"{x:1177,y:767,t:1528143711996};\\\", \\\"{x:1178,y:768,t:1528143712012};\\\", \\\"{x:1179,y:769,t:1528143712041};\\\", \\\"{x:1180,y:770,t:1528143712049};\\\", \\\"{x:1180,y:771,t:1528143712062};\\\", \\\"{x:1181,y:771,t:1528143712078};\\\", \\\"{x:1181,y:772,t:1528143712097};\\\", \\\"{x:1182,y:773,t:1528143712112};\\\", \\\"{x:1183,y:774,t:1528143712128};\\\", \\\"{x:1184,y:775,t:1528143712144};\\\", \\\"{x:1184,y:776,t:1528143712162};\\\", \\\"{x:1186,y:777,t:1528143712178};\\\", \\\"{x:1186,y:778,t:1528143712200};\\\", \\\"{x:1187,y:779,t:1528143712232};\\\", \\\"{x:1188,y:780,t:1528143712248};\\\", \\\"{x:1189,y:781,t:1528143712262};\\\", \\\"{x:1190,y:782,t:1528143712278};\\\", \\\"{x:1190,y:783,t:1528143712295};\\\", \\\"{x:1191,y:784,t:1528143712312};\\\", \\\"{x:1193,y:785,t:1528143712329};\\\", \\\"{x:1193,y:787,t:1528143712345};\\\", \\\"{x:1194,y:788,t:1528143712362};\\\", \\\"{x:1195,y:790,t:1528143712379};\\\", \\\"{x:1196,y:791,t:1528143712395};\\\", \\\"{x:1197,y:792,t:1528143712412};\\\", \\\"{x:1197,y:793,t:1528143712429};\\\", \\\"{x:1198,y:794,t:1528143712445};\\\", \\\"{x:1200,y:796,t:1528143712462};\\\", \\\"{x:1201,y:797,t:1528143712479};\\\", \\\"{x:1202,y:799,t:1528143712495};\\\", \\\"{x:1203,y:800,t:1528143712512};\\\", \\\"{x:1205,y:804,t:1528143712529};\\\", \\\"{x:1206,y:805,t:1528143712545};\\\", \\\"{x:1209,y:809,t:1528143712561};\\\", \\\"{x:1212,y:813,t:1528143712578};\\\", \\\"{x:1213,y:817,t:1528143712594};\\\", \\\"{x:1216,y:821,t:1528143712611};\\\", \\\"{x:1217,y:823,t:1528143712628};\\\", \\\"{x:1220,y:826,t:1528143712644};\\\", \\\"{x:1223,y:831,t:1528143712661};\\\", \\\"{x:1225,y:834,t:1528143712678};\\\", \\\"{x:1227,y:838,t:1528143712695};\\\", \\\"{x:1228,y:840,t:1528143712711};\\\", \\\"{x:1234,y:848,t:1528143712728};\\\", \\\"{x:1238,y:854,t:1528143712745};\\\", \\\"{x:1240,y:859,t:1528143712762};\\\", \\\"{x:1244,y:863,t:1528143712779};\\\", \\\"{x:1247,y:866,t:1528143712796};\\\", \\\"{x:1249,y:869,t:1528143712811};\\\", \\\"{x:1251,y:872,t:1528143712829};\\\", \\\"{x:1254,y:875,t:1528143712845};\\\", \\\"{x:1256,y:878,t:1528143712862};\\\", \\\"{x:1259,y:881,t:1528143712878};\\\", \\\"{x:1260,y:883,t:1528143712896};\\\", \\\"{x:1261,y:884,t:1528143712912};\\\", \\\"{x:1264,y:889,t:1528143712928};\\\", \\\"{x:1265,y:893,t:1528143712946};\\\", \\\"{x:1269,y:898,t:1528143712962};\\\", \\\"{x:1271,y:902,t:1528143712978};\\\", \\\"{x:1273,y:905,t:1528143712996};\\\", \\\"{x:1276,y:910,t:1528143713012};\\\", \\\"{x:1278,y:914,t:1528143713028};\\\", \\\"{x:1280,y:918,t:1528143713046};\\\", \\\"{x:1284,y:924,t:1528143713062};\\\", \\\"{x:1286,y:929,t:1528143713078};\\\", \\\"{x:1287,y:934,t:1528143713096};\\\", \\\"{x:1290,y:937,t:1528143713112};\\\", \\\"{x:1292,y:944,t:1528143713128};\\\", \\\"{x:1295,y:949,t:1528143713146};\\\", \\\"{x:1297,y:954,t:1528143713162};\\\", \\\"{x:1299,y:957,t:1528143713179};\\\", \\\"{x:1300,y:961,t:1528143713196};\\\", \\\"{x:1302,y:963,t:1528143713212};\\\", \\\"{x:1302,y:966,t:1528143713229};\\\", \\\"{x:1303,y:967,t:1528143713248};\\\", \\\"{x:1303,y:968,t:1528143713264};\\\", \\\"{x:1303,y:969,t:1528143713279};\\\", \\\"{x:1304,y:970,t:1528143713296};\\\", \\\"{x:1301,y:969,t:1528143713929};\\\", \\\"{x:1291,y:956,t:1528143713946};\\\", \\\"{x:1283,y:945,t:1528143713963};\\\", \\\"{x:1275,y:933,t:1528143713980};\\\", \\\"{x:1271,y:928,t:1528143713996};\\\", \\\"{x:1266,y:920,t:1528143714013};\\\", \\\"{x:1261,y:911,t:1528143714030};\\\", \\\"{x:1257,y:904,t:1528143714046};\\\", \\\"{x:1254,y:898,t:1528143714063};\\\", \\\"{x:1251,y:890,t:1528143714080};\\\", \\\"{x:1244,y:875,t:1528143714097};\\\", \\\"{x:1240,y:867,t:1528143714113};\\\", \\\"{x:1239,y:863,t:1528143714130};\\\", \\\"{x:1239,y:862,t:1528143714147};\\\", \\\"{x:1238,y:860,t:1528143714163};\\\", \\\"{x:1237,y:859,t:1528143714180};\\\", \\\"{x:1237,y:857,t:1528143714196};\\\", \\\"{x:1237,y:856,t:1528143714213};\\\", \\\"{x:1236,y:854,t:1528143714230};\\\", \\\"{x:1236,y:852,t:1528143714247};\\\", \\\"{x:1235,y:850,t:1528143714263};\\\", \\\"{x:1232,y:846,t:1528143714280};\\\", \\\"{x:1231,y:841,t:1528143714297};\\\", \\\"{x:1229,y:837,t:1528143714313};\\\", \\\"{x:1226,y:831,t:1528143714330};\\\", \\\"{x:1223,y:824,t:1528143714347};\\\", \\\"{x:1221,y:819,t:1528143714363};\\\", \\\"{x:1217,y:813,t:1528143714380};\\\", \\\"{x:1216,y:810,t:1528143714397};\\\", \\\"{x:1215,y:807,t:1528143714413};\\\", \\\"{x:1213,y:803,t:1528143714430};\\\", \\\"{x:1212,y:801,t:1528143714447};\\\", \\\"{x:1211,y:797,t:1528143714463};\\\", \\\"{x:1210,y:797,t:1528143714480};\\\", \\\"{x:1209,y:796,t:1528143714497};\\\", \\\"{x:1209,y:795,t:1528143714514};\\\", \\\"{x:1208,y:794,t:1528143714530};\\\", \\\"{x:1207,y:793,t:1528143714552};\\\", \\\"{x:1206,y:793,t:1528143714576};\\\", \\\"{x:1206,y:792,t:1528143714585};\\\", \\\"{x:1204,y:790,t:1528143714601};\\\", \\\"{x:1203,y:788,t:1528143714617};\\\", \\\"{x:1203,y:787,t:1528143714632};\\\", \\\"{x:1202,y:786,t:1528143714647};\\\", \\\"{x:1201,y:784,t:1528143714665};\\\", \\\"{x:1200,y:784,t:1528143714679};\\\", \\\"{x:1199,y:781,t:1528143714696};\\\", \\\"{x:1197,y:778,t:1528143714714};\\\", \\\"{x:1196,y:776,t:1528143714729};\\\", \\\"{x:1195,y:774,t:1528143714747};\\\", \\\"{x:1200,y:780,t:1528143714865};\\\", \\\"{x:1204,y:789,t:1528143714880};\\\", \\\"{x:1223,y:818,t:1528143714897};\\\", \\\"{x:1241,y:841,t:1528143714914};\\\", \\\"{x:1262,y:860,t:1528143714930};\\\", \\\"{x:1283,y:877,t:1528143714946};\\\", \\\"{x:1301,y:888,t:1528143714964};\\\", \\\"{x:1321,y:894,t:1528143714981};\\\", \\\"{x:1330,y:895,t:1528143714997};\\\", \\\"{x:1334,y:895,t:1528143715014};\\\", \\\"{x:1336,y:896,t:1528143715031};\\\", \\\"{x:1338,y:894,t:1528143715130};\\\", \\\"{x:1338,y:893,t:1528143715136};\\\", \\\"{x:1338,y:892,t:1528143715147};\\\", \\\"{x:1339,y:891,t:1528143715164};\\\", \\\"{x:1340,y:890,t:1528143715193};\\\", \\\"{x:1341,y:890,t:1528143715224};\\\", \\\"{x:1342,y:888,t:1528143715232};\\\", \\\"{x:1344,y:888,t:1528143715247};\\\", \\\"{x:1349,y:888,t:1528143715264};\\\", \\\"{x:1367,y:891,t:1528143715281};\\\", \\\"{x:1378,y:895,t:1528143715297};\\\", \\\"{x:1385,y:898,t:1528143715314};\\\", \\\"{x:1388,y:899,t:1528143715332};\\\", \\\"{x:1389,y:899,t:1528143715347};\\\", \\\"{x:1390,y:899,t:1528143715364};\\\", \\\"{x:1392,y:900,t:1528143715381};\\\", \\\"{x:1393,y:900,t:1528143715433};\\\", \\\"{x:1393,y:898,t:1528143715497};\\\", \\\"{x:1390,y:894,t:1528143715514};\\\", \\\"{x:1388,y:892,t:1528143715531};\\\", \\\"{x:1385,y:890,t:1528143715548};\\\", \\\"{x:1384,y:890,t:1528143715564};\\\", \\\"{x:1382,y:890,t:1528143715617};\\\", \\\"{x:1382,y:889,t:1528143715631};\\\", \\\"{x:1380,y:888,t:1528143715648};\\\", \\\"{x:1378,y:887,t:1528143715665};\\\", \\\"{x:1375,y:886,t:1528143715682};\\\", \\\"{x:1374,y:886,t:1528143715698};\\\", \\\"{x:1373,y:886,t:1528143715714};\\\", \\\"{x:1374,y:886,t:1528143716015};\\\", \\\"{x:1376,y:886,t:1528143716031};\\\", \\\"{x:1379,y:889,t:1528143716048};\\\", \\\"{x:1381,y:895,t:1528143716064};\\\", \\\"{x:1383,y:899,t:1528143716080};\\\", \\\"{x:1384,y:902,t:1528143716098};\\\", \\\"{x:1385,y:905,t:1528143716115};\\\", \\\"{x:1386,y:907,t:1528143716130};\\\", \\\"{x:1387,y:908,t:1528143716152};\\\", \\\"{x:1387,y:909,t:1528143716165};\\\", \\\"{x:1387,y:910,t:1528143716181};\\\", \\\"{x:1387,y:912,t:1528143716198};\\\", \\\"{x:1388,y:913,t:1528143716215};\\\", \\\"{x:1390,y:917,t:1528143716231};\\\", \\\"{x:1391,y:920,t:1528143716248};\\\", \\\"{x:1392,y:923,t:1528143716265};\\\", \\\"{x:1394,y:928,t:1528143716281};\\\", \\\"{x:1395,y:931,t:1528143716298};\\\", \\\"{x:1399,y:939,t:1528143716315};\\\", \\\"{x:1401,y:945,t:1528143716332};\\\", \\\"{x:1406,y:954,t:1528143716348};\\\", \\\"{x:1411,y:965,t:1528143716365};\\\", \\\"{x:1418,y:977,t:1528143716382};\\\", \\\"{x:1424,y:990,t:1528143716398};\\\", \\\"{x:1429,y:1000,t:1528143716415};\\\", \\\"{x:1436,y:1013,t:1528143716432};\\\", \\\"{x:1438,y:1015,t:1528143716448};\\\", \\\"{x:1439,y:1016,t:1528143716465};\\\", \\\"{x:1439,y:1006,t:1528143716553};\\\", \\\"{x:1439,y:987,t:1528143716565};\\\", \\\"{x:1439,y:942,t:1528143716582};\\\", \\\"{x:1430,y:883,t:1528143716599};\\\", \\\"{x:1407,y:815,t:1528143716615};\\\", \\\"{x:1385,y:758,t:1528143716633};\\\", \\\"{x:1373,y:721,t:1528143716648};\\\", \\\"{x:1359,y:670,t:1528143716665};\\\", \\\"{x:1347,y:646,t:1528143716682};\\\", \\\"{x:1337,y:628,t:1528143716698};\\\", \\\"{x:1330,y:615,t:1528143716715};\\\", \\\"{x:1326,y:610,t:1528143716732};\\\", \\\"{x:1324,y:609,t:1528143716749};\\\", \\\"{x:1324,y:606,t:1528143716921};\\\", \\\"{x:1324,y:603,t:1528143716932};\\\", \\\"{x:1324,y:598,t:1528143716949};\\\", \\\"{x:1324,y:594,t:1528143716965};\\\", \\\"{x:1324,y:593,t:1528143716982};\\\", \\\"{x:1323,y:592,t:1528143716999};\\\", \\\"{x:1322,y:590,t:1528143717015};\\\", \\\"{x:1320,y:588,t:1528143717033};\\\", \\\"{x:1319,y:588,t:1528143717049};\\\", \\\"{x:1318,y:588,t:1528143717089};\\\", \\\"{x:1317,y:587,t:1528143717145};\\\", \\\"{x:1317,y:586,t:1528143717152};\\\", \\\"{x:1317,y:584,t:1528143717166};\\\", \\\"{x:1315,y:581,t:1528143717182};\\\", \\\"{x:1313,y:578,t:1528143717199};\\\", \\\"{x:1309,y:573,t:1528143717216};\\\", \\\"{x:1303,y:568,t:1528143717232};\\\", \\\"{x:1292,y:562,t:1528143717249};\\\", \\\"{x:1286,y:558,t:1528143717266};\\\", \\\"{x:1281,y:556,t:1528143717282};\\\", \\\"{x:1281,y:558,t:1528143717392};\\\", \\\"{x:1281,y:567,t:1528143717416};\\\", \\\"{x:1281,y:575,t:1528143717433};\\\", \\\"{x:1281,y:581,t:1528143717449};\\\", \\\"{x:1281,y:586,t:1528143717465};\\\", \\\"{x:1282,y:592,t:1528143717482};\\\", \\\"{x:1284,y:596,t:1528143717499};\\\", \\\"{x:1285,y:601,t:1528143717516};\\\", \\\"{x:1285,y:603,t:1528143717532};\\\", \\\"{x:1286,y:606,t:1528143717549};\\\", \\\"{x:1288,y:609,t:1528143717566};\\\", \\\"{x:1288,y:611,t:1528143717582};\\\", \\\"{x:1290,y:615,t:1528143717599};\\\", \\\"{x:1294,y:624,t:1528143717616};\\\", \\\"{x:1299,y:633,t:1528143717632};\\\", \\\"{x:1303,y:642,t:1528143717648};\\\", \\\"{x:1308,y:653,t:1528143717665};\\\", \\\"{x:1313,y:666,t:1528143717683};\\\", \\\"{x:1320,y:679,t:1528143717699};\\\", \\\"{x:1329,y:697,t:1528143717716};\\\", \\\"{x:1340,y:716,t:1528143717733};\\\", \\\"{x:1351,y:734,t:1528143717749};\\\", \\\"{x:1361,y:752,t:1528143717766};\\\", \\\"{x:1370,y:764,t:1528143717783};\\\", \\\"{x:1381,y:776,t:1528143717799};\\\", \\\"{x:1394,y:791,t:1528143717816};\\\", \\\"{x:1398,y:798,t:1528143717833};\\\", \\\"{x:1403,y:804,t:1528143717849};\\\", \\\"{x:1408,y:810,t:1528143717866};\\\", \\\"{x:1413,y:817,t:1528143717884};\\\", \\\"{x:1418,y:825,t:1528143717899};\\\", \\\"{x:1429,y:839,t:1528143717916};\\\", \\\"{x:1441,y:857,t:1528143717933};\\\", \\\"{x:1446,y:865,t:1528143717949};\\\", \\\"{x:1449,y:869,t:1528143717966};\\\", \\\"{x:1453,y:873,t:1528143717983};\\\", \\\"{x:1454,y:877,t:1528143717999};\\\", \\\"{x:1456,y:880,t:1528143718016};\\\", \\\"{x:1458,y:884,t:1528143718033};\\\", \\\"{x:1459,y:885,t:1528143718049};\\\", \\\"{x:1460,y:890,t:1528143718066};\\\", \\\"{x:1465,y:898,t:1528143718083};\\\", \\\"{x:1468,y:907,t:1528143718100};\\\", \\\"{x:1474,y:916,t:1528143718116};\\\", \\\"{x:1478,y:924,t:1528143718133};\\\", \\\"{x:1483,y:932,t:1528143718150};\\\", \\\"{x:1486,y:938,t:1528143718166};\\\", \\\"{x:1488,y:940,t:1528143718183};\\\", \\\"{x:1490,y:943,t:1528143718199};\\\", \\\"{x:1490,y:946,t:1528143718231};\\\", \\\"{x:1490,y:947,t:1528143718288};\\\", \\\"{x:1492,y:948,t:1528143718299};\\\", \\\"{x:1492,y:949,t:1528143718315};\\\", \\\"{x:1492,y:950,t:1528143718333};\\\", \\\"{x:1492,y:953,t:1528143718349};\\\", \\\"{x:1493,y:954,t:1528143718365};\\\", \\\"{x:1494,y:956,t:1528143718382};\\\", \\\"{x:1494,y:958,t:1528143718400};\\\", \\\"{x:1495,y:959,t:1528143718416};\\\", \\\"{x:1495,y:961,t:1528143718448};\\\", \\\"{x:1496,y:963,t:1528143718505};\\\", \\\"{x:1495,y:962,t:1528143721529};\\\", \\\"{x:1494,y:958,t:1528143721536};\\\", \\\"{x:1491,y:955,t:1528143721552};\\\", \\\"{x:1488,y:952,t:1528143721568};\\\", \\\"{x:1487,y:950,t:1528143721585};\\\", \\\"{x:1485,y:949,t:1528143721603};\\\", \\\"{x:1484,y:948,t:1528143721619};\\\", \\\"{x:1482,y:947,t:1528143722593};\\\", \\\"{x:1480,y:947,t:1528143722603};\\\", \\\"{x:1470,y:939,t:1528143722620};\\\", \\\"{x:1455,y:927,t:1528143722636};\\\", \\\"{x:1436,y:913,t:1528143722653};\\\", \\\"{x:1414,y:898,t:1528143722670};\\\", \\\"{x:1390,y:880,t:1528143722685};\\\", \\\"{x:1367,y:864,t:1528143722702};\\\", \\\"{x:1336,y:842,t:1528143722720};\\\", \\\"{x:1318,y:828,t:1528143722735};\\\", \\\"{x:1300,y:818,t:1528143722752};\\\", \\\"{x:1279,y:803,t:1528143722770};\\\", \\\"{x:1263,y:791,t:1528143722786};\\\", \\\"{x:1250,y:782,t:1528143722803};\\\", \\\"{x:1238,y:774,t:1528143722820};\\\", \\\"{x:1227,y:768,t:1528143722836};\\\", \\\"{x:1219,y:764,t:1528143722853};\\\", \\\"{x:1210,y:759,t:1528143722870};\\\", \\\"{x:1201,y:755,t:1528143722886};\\\", \\\"{x:1196,y:755,t:1528143722903};\\\", \\\"{x:1191,y:755,t:1528143722920};\\\", \\\"{x:1184,y:756,t:1528143722936};\\\", \\\"{x:1178,y:758,t:1528143722953};\\\", \\\"{x:1168,y:762,t:1528143722971};\\\", \\\"{x:1164,y:764,t:1528143722988};\\\", \\\"{x:1161,y:766,t:1528143723003};\\\", \\\"{x:1160,y:766,t:1528143723020};\\\", \\\"{x:1158,y:767,t:1528143723037};\\\", \\\"{x:1159,y:767,t:1528143723505};\\\", \\\"{x:1163,y:764,t:1528143723520};\\\", \\\"{x:1165,y:764,t:1528143723537};\\\", \\\"{x:1166,y:763,t:1528143723555};\\\", \\\"{x:1168,y:762,t:1528143723570};\\\", \\\"{x:1169,y:762,t:1528143723587};\\\", \\\"{x:1171,y:761,t:1528143723801};\\\", \\\"{x:1172,y:761,t:1528143723816};\\\", \\\"{x:1174,y:761,t:1528143723824};\\\", \\\"{x:1175,y:760,t:1528143723838};\\\", \\\"{x:1177,y:760,t:1528143723855};\\\", \\\"{x:1178,y:760,t:1528143723872};\\\", \\\"{x:1180,y:760,t:1528143723887};\\\", \\\"{x:1181,y:760,t:1528143723904};\\\", \\\"{x:1183,y:760,t:1528143723937};\\\", \\\"{x:1184,y:760,t:1528143723993};\\\", \\\"{x:1187,y:758,t:1528143728578};\\\", \\\"{x:1203,y:736,t:1528143728591};\\\", \\\"{x:1265,y:678,t:1528143728608};\\\", \\\"{x:1371,y:570,t:1528143728624};\\\", \\\"{x:1422,y:509,t:1528143728641};\\\", \\\"{x:1478,y:448,t:1528143728657};\\\", \\\"{x:1517,y:412,t:1528143728675};\\\", \\\"{x:1552,y:355,t:1528143728691};\\\", \\\"{x:1575,y:302,t:1528143728708};\\\", \\\"{x:1590,y:259,t:1528143728724};\\\", \\\"{x:1595,y:241,t:1528143728742};\\\", \\\"{x:1597,y:230,t:1528143728758};\\\", \\\"{x:1597,y:224,t:1528143728775};\\\", \\\"{x:1597,y:222,t:1528143728791};\\\", \\\"{x:1597,y:221,t:1528143728808};\\\", \\\"{x:1596,y:220,t:1528143728832};\\\", \\\"{x:1592,y:220,t:1528143728841};\\\", \\\"{x:1578,y:222,t:1528143728859};\\\", \\\"{x:1558,y:232,t:1528143728875};\\\", \\\"{x:1542,y:242,t:1528143728892};\\\", \\\"{x:1528,y:255,t:1528143728909};\\\", \\\"{x:1518,y:266,t:1528143728925};\\\", \\\"{x:1506,y:280,t:1528143728941};\\\", \\\"{x:1499,y:290,t:1528143728959};\\\", \\\"{x:1495,y:295,t:1528143728974};\\\", \\\"{x:1492,y:298,t:1528143728992};\\\", \\\"{x:1492,y:297,t:1528143729248};\\\", \\\"{x:1492,y:294,t:1528143729258};\\\", \\\"{x:1492,y:292,t:1528143729276};\\\", \\\"{x:1492,y:289,t:1528143729292};\\\", \\\"{x:1492,y:287,t:1528143729309};\\\", \\\"{x:1491,y:287,t:1528143729648};\\\", \\\"{x:1490,y:287,t:1528143729664};\\\", \\\"{x:1489,y:287,t:1528143729676};\\\", \\\"{x:1488,y:287,t:1528143729693};\\\", \\\"{x:1487,y:289,t:1528143729709};\\\", \\\"{x:1486,y:289,t:1528143729737};\\\", \\\"{x:1486,y:290,t:1528143730361};\\\", \\\"{x:1486,y:291,t:1528143730375};\\\", \\\"{x:1485,y:294,t:1528143730393};\\\", \\\"{x:1484,y:296,t:1528143730409};\\\", \\\"{x:1484,y:297,t:1528143730426};\\\", \\\"{x:1483,y:299,t:1528143730443};\\\", \\\"{x:1482,y:301,t:1528143730460};\\\", \\\"{x:1481,y:302,t:1528143730475};\\\", \\\"{x:1480,y:304,t:1528143730493};\\\", \\\"{x:1480,y:305,t:1528143730510};\\\", \\\"{x:1479,y:306,t:1528143730527};\\\", \\\"{x:1479,y:307,t:1528143730576};\\\", \\\"{x:1478,y:308,t:1528143730593};\\\", \\\"{x:1477,y:309,t:1528143730610};\\\", \\\"{x:1474,y:313,t:1528143730626};\\\", \\\"{x:1469,y:321,t:1528143730643};\\\", \\\"{x:1462,y:331,t:1528143730660};\\\", \\\"{x:1453,y:343,t:1528143730676};\\\", \\\"{x:1447,y:356,t:1528143730694};\\\", \\\"{x:1441,y:364,t:1528143730710};\\\", \\\"{x:1439,y:370,t:1528143730727};\\\", \\\"{x:1436,y:377,t:1528143730743};\\\", \\\"{x:1434,y:381,t:1528143730760};\\\", \\\"{x:1430,y:387,t:1528143730776};\\\", \\\"{x:1429,y:390,t:1528143730793};\\\", \\\"{x:1427,y:394,t:1528143730810};\\\", \\\"{x:1427,y:399,t:1528143730827};\\\", \\\"{x:1425,y:404,t:1528143730843};\\\", \\\"{x:1424,y:407,t:1528143730860};\\\", \\\"{x:1424,y:408,t:1528143730877};\\\", \\\"{x:1424,y:409,t:1528143730893};\\\", \\\"{x:1424,y:410,t:1528143730910};\\\", \\\"{x:1424,y:412,t:1528143730929};\\\", \\\"{x:1423,y:414,t:1528143730943};\\\", \\\"{x:1422,y:416,t:1528143730960};\\\", \\\"{x:1420,y:421,t:1528143730976};\\\", \\\"{x:1420,y:425,t:1528143730995};\\\", \\\"{x:1418,y:429,t:1528143731011};\\\", \\\"{x:1418,y:430,t:1528143731026};\\\", \\\"{x:1417,y:431,t:1528143731044};\\\", \\\"{x:1417,y:432,t:1528143731073};\\\", \\\"{x:1417,y:433,t:1528143731088};\\\", \\\"{x:1417,y:434,t:1528143731096};\\\", \\\"{x:1417,y:435,t:1528143731112};\\\", \\\"{x:1417,y:437,t:1528143731129};\\\", \\\"{x:1416,y:437,t:1528143731144};\\\", \\\"{x:1414,y:437,t:1528143731496};\\\", \\\"{x:1413,y:436,t:1528143731545};\\\", \\\"{x:1413,y:435,t:1528143732178};\\\", \\\"{x:1412,y:433,t:1528143732211};\\\", \\\"{x:1411,y:432,t:1528143732228};\\\", \\\"{x:1411,y:431,t:1528143732249};\\\", \\\"{x:1411,y:430,t:1528143732729};\\\", \\\"{x:1411,y:427,t:1528143733449};\\\", \\\"{x:1415,y:416,t:1528143733462};\\\", \\\"{x:1434,y:392,t:1528143733480};\\\", \\\"{x:1444,y:378,t:1528143733495};\\\", \\\"{x:1453,y:367,t:1528143733512};\\\", \\\"{x:1461,y:358,t:1528143733529};\\\", \\\"{x:1462,y:357,t:1528143733545};\\\", \\\"{x:1462,y:356,t:1528143733562};\\\", \\\"{x:1463,y:355,t:1528143733601};\\\", \\\"{x:1463,y:354,t:1528143733616};\\\", \\\"{x:1464,y:353,t:1528143733629};\\\", \\\"{x:1464,y:350,t:1528143733646};\\\", \\\"{x:1466,y:345,t:1528143733662};\\\", \\\"{x:1467,y:343,t:1528143733679};\\\", \\\"{x:1467,y:340,t:1528143733696};\\\", \\\"{x:1468,y:338,t:1528143733712};\\\", \\\"{x:1468,y:334,t:1528143733729};\\\", \\\"{x:1468,y:333,t:1528143733746};\\\", \\\"{x:1470,y:328,t:1528143733762};\\\", \\\"{x:1471,y:322,t:1528143733779};\\\", \\\"{x:1474,y:314,t:1528143733796};\\\", \\\"{x:1475,y:310,t:1528143733812};\\\", \\\"{x:1476,y:306,t:1528143733829};\\\", \\\"{x:1476,y:305,t:1528143733847};\\\", \\\"{x:1477,y:304,t:1528143733862};\\\", \\\"{x:1478,y:303,t:1528143733881};\\\", \\\"{x:1478,y:302,t:1528143733896};\\\", \\\"{x:1479,y:302,t:1528143733920};\\\", \\\"{x:1479,y:301,t:1528143734058};\\\", \\\"{x:1479,y:298,t:1528143734201};\\\", \\\"{x:1481,y:296,t:1528143734217};\\\", \\\"{x:1481,y:295,t:1528143734229};\\\", \\\"{x:1481,y:293,t:1528143734246};\\\", \\\"{x:1481,y:292,t:1528143734263};\\\", \\\"{x:1482,y:291,t:1528143734280};\\\", \\\"{x:1482,y:290,t:1528143734295};\\\", \\\"{x:1480,y:293,t:1528143734625};\\\", \\\"{x:1474,y:308,t:1528143734647};\\\", \\\"{x:1465,y:326,t:1528143734663};\\\", \\\"{x:1455,y:349,t:1528143734680};\\\", \\\"{x:1443,y:376,t:1528143734696};\\\", \\\"{x:1431,y:408,t:1528143734713};\\\", \\\"{x:1426,y:420,t:1528143734730};\\\", \\\"{x:1424,y:425,t:1528143734746};\\\", \\\"{x:1421,y:432,t:1528143734763};\\\", \\\"{x:1421,y:434,t:1528143734780};\\\", \\\"{x:1420,y:436,t:1528143734796};\\\", \\\"{x:1420,y:437,t:1528143734813};\\\", \\\"{x:1418,y:437,t:1528143735057};\\\", \\\"{x:1418,y:436,t:1528143735065};\\\", \\\"{x:1417,y:434,t:1528143735080};\\\", \\\"{x:1414,y:430,t:1528143735096};\\\", \\\"{x:1413,y:426,t:1528143735113};\\\", \\\"{x:1411,y:424,t:1528143735131};\\\", \\\"{x:1410,y:423,t:1528143735147};\\\", \\\"{x:1410,y:424,t:1528143735457};\\\", \\\"{x:1410,y:425,t:1528143735465};\\\", \\\"{x:1410,y:427,t:1528143735481};\\\", \\\"{x:1410,y:428,t:1528143735497};\\\", \\\"{x:1410,y:429,t:1528143735514};\\\", \\\"{x:1410,y:430,t:1528143735530};\\\", \\\"{x:1410,y:431,t:1528143735547};\\\", \\\"{x:1410,y:432,t:1528143735563};\\\", \\\"{x:1410,y:433,t:1528143735584};\\\", \\\"{x:1410,y:434,t:1528143735597};\\\", \\\"{x:1410,y:435,t:1528143735613};\\\", \\\"{x:1410,y:436,t:1528143735629};\\\", \\\"{x:1409,y:438,t:1528143735646};\\\", \\\"{x:1409,y:439,t:1528143735663};\\\", \\\"{x:1408,y:440,t:1528143735679};\\\", \\\"{x:1408,y:441,t:1528143735696};\\\", \\\"{x:1407,y:443,t:1528143735713};\\\", \\\"{x:1405,y:446,t:1528143735729};\\\", \\\"{x:1404,y:451,t:1528143735747};\\\", \\\"{x:1401,y:454,t:1528143735764};\\\", \\\"{x:1400,y:457,t:1528143735780};\\\", \\\"{x:1397,y:461,t:1528143735797};\\\", \\\"{x:1397,y:462,t:1528143735814};\\\", \\\"{x:1396,y:465,t:1528143735829};\\\", \\\"{x:1394,y:468,t:1528143735846};\\\", \\\"{x:1392,y:472,t:1528143735864};\\\", \\\"{x:1391,y:474,t:1528143735880};\\\", \\\"{x:1390,y:476,t:1528143735897};\\\", \\\"{x:1390,y:480,t:1528143735913};\\\", \\\"{x:1387,y:484,t:1528143735931};\\\", \\\"{x:1385,y:489,t:1528143735947};\\\", \\\"{x:1384,y:491,t:1528143735964};\\\", \\\"{x:1383,y:494,t:1528143735981};\\\", \\\"{x:1379,y:498,t:1528143735997};\\\", \\\"{x:1378,y:501,t:1528143736014};\\\", \\\"{x:1375,y:507,t:1528143736031};\\\", \\\"{x:1372,y:512,t:1528143736046};\\\", \\\"{x:1368,y:517,t:1528143736064};\\\", \\\"{x:1367,y:520,t:1528143736080};\\\", \\\"{x:1363,y:524,t:1528143736097};\\\", \\\"{x:1359,y:531,t:1528143736114};\\\", \\\"{x:1356,y:536,t:1528143736131};\\\", \\\"{x:1355,y:537,t:1528143736147};\\\", \\\"{x:1353,y:539,t:1528143736164};\\\", \\\"{x:1351,y:542,t:1528143736181};\\\", \\\"{x:1349,y:544,t:1528143736197};\\\", \\\"{x:1348,y:546,t:1528143736214};\\\", \\\"{x:1345,y:550,t:1528143736231};\\\", \\\"{x:1341,y:556,t:1528143736247};\\\", \\\"{x:1338,y:559,t:1528143736265};\\\", \\\"{x:1336,y:564,t:1528143736280};\\\", \\\"{x:1334,y:566,t:1528143736298};\\\", \\\"{x:1332,y:568,t:1528143736314};\\\", \\\"{x:1332,y:569,t:1528143736331};\\\", \\\"{x:1330,y:571,t:1528143736504};\\\", \\\"{x:1328,y:572,t:1528143736514};\\\", \\\"{x:1326,y:574,t:1528143736531};\\\", \\\"{x:1323,y:578,t:1528143736548};\\\", \\\"{x:1320,y:583,t:1528143736564};\\\", \\\"{x:1317,y:586,t:1528143736581};\\\", \\\"{x:1314,y:587,t:1528143736598};\\\", \\\"{x:1312,y:589,t:1528143736614};\\\", \\\"{x:1311,y:589,t:1528143736631};\\\", \\\"{x:1310,y:591,t:1528143736649};\\\", \\\"{x:1304,y:597,t:1528143736665};\\\", \\\"{x:1300,y:611,t:1528143736681};\\\", \\\"{x:1290,y:642,t:1528143736698};\\\", \\\"{x:1273,y:701,t:1528143736714};\\\", \\\"{x:1256,y:762,t:1528143736731};\\\", \\\"{x:1235,y:826,t:1528143736748};\\\", \\\"{x:1216,y:878,t:1528143736765};\\\", \\\"{x:1198,y:913,t:1528143736781};\\\", \\\"{x:1181,y:939,t:1528143736798};\\\", \\\"{x:1167,y:960,t:1528143736815};\\\", \\\"{x:1157,y:975,t:1528143736831};\\\", \\\"{x:1149,y:993,t:1528143736848};\\\", \\\"{x:1146,y:999,t:1528143736864};\\\", \\\"{x:1144,y:1001,t:1528143736881};\\\", \\\"{x:1142,y:1001,t:1528143736898};\\\", \\\"{x:1141,y:1001,t:1528143736937};\\\", \\\"{x:1140,y:1001,t:1528143736953};\\\", \\\"{x:1139,y:1000,t:1528143736977};\\\", \\\"{x:1139,y:997,t:1528143736985};\\\", \\\"{x:1139,y:992,t:1528143736999};\\\", \\\"{x:1140,y:979,t:1528143737016};\\\", \\\"{x:1143,y:968,t:1528143737032};\\\", \\\"{x:1149,y:952,t:1528143737048};\\\", \\\"{x:1152,y:946,t:1528143737064};\\\", \\\"{x:1154,y:938,t:1528143737081};\\\", \\\"{x:1158,y:926,t:1528143737098};\\\", \\\"{x:1160,y:919,t:1528143737115};\\\", \\\"{x:1163,y:912,t:1528143737131};\\\", \\\"{x:1165,y:908,t:1528143737148};\\\", \\\"{x:1166,y:905,t:1528143737165};\\\", \\\"{x:1167,y:901,t:1528143737181};\\\", \\\"{x:1170,y:894,t:1528143737198};\\\", \\\"{x:1171,y:888,t:1528143737215};\\\", \\\"{x:1175,y:879,t:1528143737232};\\\", \\\"{x:1179,y:874,t:1528143737248};\\\", \\\"{x:1182,y:870,t:1528143737264};\\\", \\\"{x:1183,y:867,t:1528143737282};\\\", \\\"{x:1184,y:865,t:1528143737298};\\\", \\\"{x:1184,y:864,t:1528143737315};\\\", \\\"{x:1185,y:864,t:1528143737332};\\\", \\\"{x:1185,y:863,t:1528143737348};\\\", \\\"{x:1186,y:861,t:1528143737365};\\\", \\\"{x:1188,y:859,t:1528143737382};\\\", \\\"{x:1189,y:858,t:1528143737400};\\\", \\\"{x:1189,y:857,t:1528143737415};\\\", \\\"{x:1192,y:855,t:1528143737432};\\\", \\\"{x:1195,y:851,t:1528143737448};\\\", \\\"{x:1198,y:848,t:1528143737465};\\\", \\\"{x:1198,y:847,t:1528143737482};\\\", \\\"{x:1199,y:844,t:1528143737498};\\\", \\\"{x:1202,y:840,t:1528143737515};\\\", \\\"{x:1203,y:837,t:1528143737532};\\\", \\\"{x:1203,y:835,t:1528143737549};\\\", \\\"{x:1205,y:833,t:1528143737565};\\\", \\\"{x:1205,y:832,t:1528143737627};\\\", \\\"{x:1206,y:831,t:1528143737643};\\\", \\\"{x:1207,y:830,t:1528143737651};\\\", \\\"{x:1208,y:829,t:1528143737668};\\\", \\\"{x:1209,y:828,t:1528143737700};\\\", \\\"{x:1207,y:828,t:1528143737837};\\\", \\\"{x:1200,y:832,t:1528143737851};\\\", \\\"{x:1196,y:839,t:1528143737868};\\\", \\\"{x:1192,y:844,t:1528143737885};\\\", \\\"{x:1190,y:848,t:1528143737902};\\\", \\\"{x:1187,y:852,t:1528143737918};\\\", \\\"{x:1184,y:858,t:1528143737935};\\\", \\\"{x:1183,y:866,t:1528143737952};\\\", \\\"{x:1180,y:875,t:1528143737968};\\\", \\\"{x:1178,y:884,t:1528143737985};\\\", \\\"{x:1177,y:894,t:1528143738002};\\\", \\\"{x:1174,y:903,t:1528143738018};\\\", \\\"{x:1173,y:921,t:1528143738035};\\\", \\\"{x:1170,y:937,t:1528143738051};\\\", \\\"{x:1168,y:949,t:1528143738068};\\\", \\\"{x:1167,y:961,t:1528143738085};\\\", \\\"{x:1165,y:967,t:1528143738102};\\\", \\\"{x:1164,y:969,t:1528143738119};\\\", \\\"{x:1164,y:970,t:1528143738135};\\\", \\\"{x:1164,y:971,t:1528143738152};\\\", \\\"{x:1164,y:959,t:1528143738235};\\\", \\\"{x:1164,y:898,t:1528143738252};\\\", \\\"{x:1169,y:853,t:1528143738268};\\\", \\\"{x:1173,y:822,t:1528143738284};\\\", \\\"{x:1174,y:802,t:1528143738301};\\\", \\\"{x:1174,y:795,t:1528143738319};\\\", \\\"{x:1175,y:791,t:1528143738335};\\\", \\\"{x:1175,y:790,t:1528143738351};\\\", \\\"{x:1175,y:787,t:1528143738369};\\\", \\\"{x:1175,y:783,t:1528143738384};\\\", \\\"{x:1177,y:780,t:1528143738402};\\\", \\\"{x:1177,y:776,t:1528143738419};\\\", \\\"{x:1177,y:774,t:1528143738435};\\\", \\\"{x:1178,y:773,t:1528143738508};\\\", \\\"{x:1172,y:775,t:1528143738539};\\\", \\\"{x:1166,y:782,t:1528143738552};\\\", \\\"{x:1151,y:803,t:1528143738569};\\\", \\\"{x:1139,y:825,t:1528143738585};\\\", \\\"{x:1126,y:847,t:1528143738602};\\\", \\\"{x:1115,y:869,t:1528143738619};\\\", \\\"{x:1110,y:882,t:1528143738635};\\\", \\\"{x:1106,y:894,t:1528143738652};\\\", \\\"{x:1104,y:903,t:1528143738669};\\\", \\\"{x:1103,y:905,t:1528143738686};\\\", \\\"{x:1103,y:906,t:1528143738755};\\\", \\\"{x:1104,y:906,t:1528143738771};\\\", \\\"{x:1109,y:906,t:1528143738786};\\\", \\\"{x:1123,y:901,t:1528143738802};\\\", \\\"{x:1150,y:886,t:1528143738819};\\\", \\\"{x:1172,y:877,t:1528143738835};\\\", \\\"{x:1189,y:869,t:1528143738852};\\\", \\\"{x:1203,y:863,t:1528143738869};\\\", \\\"{x:1215,y:855,t:1528143738886};\\\", \\\"{x:1231,y:845,t:1528143738902};\\\", \\\"{x:1247,y:834,t:1528143738919};\\\", \\\"{x:1256,y:828,t:1528143738936};\\\", \\\"{x:1264,y:819,t:1528143738953};\\\", \\\"{x:1277,y:810,t:1528143738969};\\\", \\\"{x:1284,y:802,t:1528143738987};\\\", \\\"{x:1290,y:798,t:1528143739003};\\\", \\\"{x:1293,y:795,t:1528143739020};\\\", \\\"{x:1296,y:793,t:1528143739036};\\\", \\\"{x:1302,y:789,t:1528143739053};\\\", \\\"{x:1312,y:783,t:1528143739069};\\\", \\\"{x:1326,y:770,t:1528143739087};\\\", \\\"{x:1337,y:758,t:1528143739103};\\\", \\\"{x:1341,y:752,t:1528143739119};\\\", \\\"{x:1344,y:749,t:1528143739136};\\\", \\\"{x:1344,y:746,t:1528143739153};\\\", \\\"{x:1346,y:742,t:1528143739170};\\\", \\\"{x:1347,y:738,t:1528143739186};\\\", \\\"{x:1349,y:734,t:1528143739204};\\\", \\\"{x:1349,y:732,t:1528143739219};\\\", \\\"{x:1349,y:729,t:1528143739236};\\\", \\\"{x:1349,y:725,t:1528143739253};\\\", \\\"{x:1349,y:721,t:1528143739269};\\\", \\\"{x:1349,y:715,t:1528143739287};\\\", \\\"{x:1349,y:710,t:1528143739304};\\\", \\\"{x:1349,y:706,t:1528143739319};\\\", \\\"{x:1349,y:704,t:1528143739336};\\\", \\\"{x:1349,y:703,t:1528143739363};\\\", \\\"{x:1349,y:701,t:1528143739371};\\\", \\\"{x:1348,y:698,t:1528143739403};\\\", \\\"{x:1348,y:696,t:1528143739428};\\\", \\\"{x:1348,y:695,t:1528143739443};\\\", \\\"{x:1347,y:694,t:1528143739635};\\\", \\\"{x:1342,y:696,t:1528143739653};\\\", \\\"{x:1337,y:700,t:1528143739671};\\\", \\\"{x:1331,y:708,t:1528143739686};\\\", \\\"{x:1327,y:715,t:1528143739703};\\\", \\\"{x:1322,y:724,t:1528143739720};\\\", \\\"{x:1318,y:731,t:1528143739737};\\\", \\\"{x:1314,y:738,t:1528143739753};\\\", \\\"{x:1312,y:746,t:1528143739771};\\\", \\\"{x:1307,y:755,t:1528143739786};\\\", \\\"{x:1299,y:772,t:1528143739803};\\\", \\\"{x:1295,y:781,t:1528143739819};\\\", \\\"{x:1294,y:790,t:1528143739837};\\\", \\\"{x:1291,y:798,t:1528143739853};\\\", \\\"{x:1289,y:804,t:1528143739870};\\\", \\\"{x:1289,y:813,t:1528143739887};\\\", \\\"{x:1286,y:818,t:1528143739904};\\\", \\\"{x:1285,y:826,t:1528143739921};\\\", \\\"{x:1282,y:835,t:1528143739937};\\\", \\\"{x:1280,y:844,t:1528143739953};\\\", \\\"{x:1276,y:852,t:1528143739970};\\\", \\\"{x:1274,y:861,t:1528143739988};\\\", \\\"{x:1273,y:864,t:1528143740004};\\\", \\\"{x:1273,y:867,t:1528143740019};\\\", \\\"{x:1273,y:869,t:1528143740036};\\\", \\\"{x:1273,y:873,t:1528143740052};\\\", \\\"{x:1272,y:878,t:1528143740070};\\\", \\\"{x:1270,y:883,t:1528143740087};\\\", \\\"{x:1270,y:888,t:1528143740103};\\\", \\\"{x:1270,y:894,t:1528143740119};\\\", \\\"{x:1269,y:897,t:1528143740136};\\\", \\\"{x:1268,y:902,t:1528143740153};\\\", \\\"{x:1268,y:909,t:1528143740170};\\\", \\\"{x:1267,y:915,t:1528143740186};\\\", \\\"{x:1266,y:917,t:1528143740202};\\\", \\\"{x:1266,y:920,t:1528143740220};\\\", \\\"{x:1265,y:921,t:1528143740237};\\\", \\\"{x:1265,y:925,t:1528143740253};\\\", \\\"{x:1263,y:929,t:1528143740270};\\\", \\\"{x:1261,y:934,t:1528143740287};\\\", \\\"{x:1261,y:937,t:1528143740303};\\\", \\\"{x:1259,y:939,t:1528143740320};\\\", \\\"{x:1259,y:942,t:1528143740337};\\\", \\\"{x:1257,y:945,t:1528143740354};\\\", \\\"{x:1256,y:947,t:1528143740370};\\\", \\\"{x:1255,y:951,t:1528143740388};\\\", \\\"{x:1252,y:956,t:1528143740403};\\\", \\\"{x:1248,y:961,t:1528143740420};\\\", \\\"{x:1245,y:966,t:1528143740437};\\\", \\\"{x:1243,y:969,t:1528143740454};\\\", \\\"{x:1240,y:972,t:1528143740470};\\\", \\\"{x:1238,y:974,t:1528143740487};\\\", \\\"{x:1235,y:977,t:1528143740504};\\\", \\\"{x:1233,y:979,t:1528143740520};\\\", \\\"{x:1232,y:981,t:1528143740537};\\\", \\\"{x:1229,y:985,t:1528143740555};\\\", \\\"{x:1227,y:987,t:1528143740570};\\\", \\\"{x:1225,y:988,t:1528143740588};\\\", \\\"{x:1224,y:989,t:1528143740604};\\\", \\\"{x:1223,y:990,t:1528143740620};\\\", \\\"{x:1221,y:990,t:1528143740915};\\\", \\\"{x:1220,y:990,t:1528143740956};\\\", \\\"{x:1220,y:989,t:1528143740978};\\\", \\\"{x:1220,y:988,t:1528143740986};\\\", \\\"{x:1219,y:985,t:1528143741003};\\\", \\\"{x:1218,y:984,t:1528143741020};\\\", \\\"{x:1218,y:981,t:1528143741036};\\\", \\\"{x:1217,y:978,t:1528143741053};\\\", \\\"{x:1217,y:977,t:1528143741070};\\\", \\\"{x:1216,y:975,t:1528143741087};\\\", \\\"{x:1215,y:973,t:1528143741104};\\\", \\\"{x:1215,y:972,t:1528143741121};\\\", \\\"{x:1214,y:970,t:1528143741137};\\\", \\\"{x:1214,y:969,t:1528143741154};\\\", \\\"{x:1214,y:968,t:1528143741171};\\\", \\\"{x:1214,y:967,t:1528143741187};\\\", \\\"{x:1214,y:966,t:1528143741204};\\\", \\\"{x:1214,y:965,t:1528143741276};\\\", \\\"{x:1214,y:964,t:1528143741291};\\\", \\\"{x:1214,y:963,t:1528143741307};\\\", \\\"{x:1213,y:963,t:1528143741323};\\\", \\\"{x:1213,y:962,t:1528143741380};\\\", \\\"{x:1213,y:961,t:1528143741404};\\\", \\\"{x:1213,y:960,t:1528143741427};\\\", \\\"{x:1212,y:958,t:1528143741444};\\\", \\\"{x:1212,y:957,t:1528143741476};\\\", \\\"{x:1212,y:956,t:1528143741499};\\\", \\\"{x:1211,y:955,t:1528143741507};\\\", \\\"{x:1211,y:953,t:1528143741523};\\\", \\\"{x:1211,y:952,t:1528143741547};\\\", \\\"{x:1211,y:951,t:1528143741556};\\\", \\\"{x:1210,y:950,t:1528143741571};\\\", \\\"{x:1209,y:947,t:1528143741588};\\\", \\\"{x:1209,y:945,t:1528143741619};\\\", \\\"{x:1209,y:943,t:1528143741635};\\\", \\\"{x:1209,y:942,t:1528143741643};\\\", \\\"{x:1208,y:941,t:1528143741654};\\\", \\\"{x:1208,y:940,t:1528143741671};\\\", \\\"{x:1208,y:939,t:1528143741691};\\\", \\\"{x:1208,y:938,t:1528143741715};\\\", \\\"{x:1208,y:937,t:1528143741811};\\\", \\\"{x:1208,y:936,t:1528143741821};\\\", \\\"{x:1207,y:935,t:1528143741838};\\\", \\\"{x:1207,y:934,t:1528143741900};\\\", \\\"{x:1207,y:933,t:1528143741915};\\\", \\\"{x:1207,y:932,t:1528143741932};\\\", \\\"{x:1207,y:931,t:1528143741963};\\\", \\\"{x:1207,y:930,t:1528143742012};\\\", \\\"{x:1207,y:929,t:1528143742021};\\\", \\\"{x:1207,y:925,t:1528143742038};\\\", \\\"{x:1210,y:915,t:1528143742055};\\\", \\\"{x:1216,y:898,t:1528143742071};\\\", \\\"{x:1227,y:871,t:1528143742088};\\\", \\\"{x:1251,y:826,t:1528143742105};\\\", \\\"{x:1289,y:745,t:1528143742122};\\\", \\\"{x:1324,y:682,t:1528143742138};\\\", \\\"{x:1351,y:640,t:1528143742155};\\\", \\\"{x:1359,y:626,t:1528143742172};\\\", \\\"{x:1367,y:612,t:1528143742189};\\\", \\\"{x:1371,y:603,t:1528143742204};\\\", \\\"{x:1375,y:596,t:1528143742222};\\\", \\\"{x:1379,y:592,t:1528143742237};\\\", \\\"{x:1382,y:586,t:1528143742254};\\\", \\\"{x:1387,y:579,t:1528143742272};\\\", \\\"{x:1394,y:568,t:1528143742288};\\\", \\\"{x:1397,y:563,t:1528143742305};\\\", \\\"{x:1400,y:560,t:1528143742322};\\\", \\\"{x:1400,y:559,t:1528143742338};\\\", \\\"{x:1400,y:558,t:1528143742354};\\\", \\\"{x:1401,y:557,t:1528143742372};\\\", \\\"{x:1404,y:555,t:1528143742388};\\\", \\\"{x:1410,y:552,t:1528143742405};\\\", \\\"{x:1412,y:551,t:1528143742422};\\\", \\\"{x:1413,y:551,t:1528143742443};\\\", \\\"{x:1413,y:550,t:1528143742455};\\\", \\\"{x:1414,y:550,t:1528143742516};\\\", \\\"{x:1412,y:552,t:1528143742651};\\\", \\\"{x:1411,y:554,t:1528143742659};\\\", \\\"{x:1410,y:556,t:1528143742672};\\\", \\\"{x:1408,y:560,t:1528143742690};\\\", \\\"{x:1407,y:562,t:1528143742705};\\\", \\\"{x:1406,y:564,t:1528143742723};\\\", \\\"{x:1406,y:565,t:1528143742740};\\\", \\\"{x:1405,y:566,t:1528143742780};\\\", \\\"{x:1405,y:567,t:1528143742972};\\\", \\\"{x:1406,y:567,t:1528143742996};\\\", \\\"{x:1407,y:568,t:1528143743035};\\\", \\\"{x:1408,y:569,t:1528143743403};\\\", \\\"{x:1408,y:572,t:1528143743411};\\\", \\\"{x:1408,y:574,t:1528143743423};\\\", \\\"{x:1406,y:580,t:1528143743439};\\\", \\\"{x:1403,y:585,t:1528143743457};\\\", \\\"{x:1400,y:589,t:1528143743474};\\\", \\\"{x:1398,y:592,t:1528143743489};\\\", \\\"{x:1398,y:595,t:1528143743507};\\\", \\\"{x:1395,y:601,t:1528143743523};\\\", \\\"{x:1393,y:606,t:1528143743539};\\\", \\\"{x:1392,y:611,t:1528143743557};\\\", \\\"{x:1390,y:616,t:1528143743573};\\\", \\\"{x:1388,y:623,t:1528143743589};\\\", \\\"{x:1385,y:628,t:1528143743606};\\\", \\\"{x:1382,y:633,t:1528143743623};\\\", \\\"{x:1382,y:635,t:1528143743639};\\\", \\\"{x:1379,y:638,t:1528143743657};\\\", \\\"{x:1378,y:642,t:1528143743674};\\\", \\\"{x:1376,y:645,t:1528143743689};\\\", \\\"{x:1374,y:649,t:1528143743707};\\\", \\\"{x:1371,y:653,t:1528143743724};\\\", \\\"{x:1370,y:655,t:1528143743739};\\\", \\\"{x:1369,y:658,t:1528143743756};\\\", \\\"{x:1367,y:660,t:1528143743773};\\\", \\\"{x:1366,y:663,t:1528143743789};\\\", \\\"{x:1365,y:665,t:1528143743806};\\\", \\\"{x:1365,y:667,t:1528143743823};\\\", \\\"{x:1364,y:669,t:1528143743839};\\\", \\\"{x:1363,y:670,t:1528143743857};\\\", \\\"{x:1362,y:672,t:1528143743873};\\\", \\\"{x:1361,y:676,t:1528143743891};\\\", \\\"{x:1359,y:679,t:1528143743906};\\\", \\\"{x:1357,y:682,t:1528143743924};\\\", \\\"{x:1355,y:685,t:1528143743939};\\\", \\\"{x:1355,y:688,t:1528143743956};\\\", \\\"{x:1352,y:692,t:1528143743973};\\\", \\\"{x:1350,y:697,t:1528143743991};\\\", \\\"{x:1347,y:704,t:1528143744007};\\\", \\\"{x:1344,y:708,t:1528143744024};\\\", \\\"{x:1344,y:710,t:1528143744041};\\\", \\\"{x:1342,y:712,t:1528143744057};\\\", \\\"{x:1341,y:714,t:1528143744073};\\\", \\\"{x:1340,y:715,t:1528143744090};\\\", \\\"{x:1340,y:719,t:1528143744106};\\\", \\\"{x:1338,y:722,t:1528143744124};\\\", \\\"{x:1337,y:723,t:1528143744156};\\\", \\\"{x:1337,y:725,t:1528143744187};\\\", \\\"{x:1336,y:726,t:1528143744203};\\\", \\\"{x:1336,y:727,t:1528143744211};\\\", \\\"{x:1336,y:728,t:1528143744223};\\\", \\\"{x:1334,y:729,t:1528143744240};\\\", \\\"{x:1334,y:731,t:1528143744256};\\\", \\\"{x:1333,y:731,t:1528143744273};\\\", \\\"{x:1333,y:733,t:1528143744290};\\\", \\\"{x:1331,y:735,t:1528143744306};\\\", \\\"{x:1331,y:736,t:1528143744323};\\\", \\\"{x:1330,y:737,t:1528143744341};\\\", \\\"{x:1330,y:740,t:1528143744358};\\\", \\\"{x:1328,y:743,t:1528143744374};\\\", \\\"{x:1328,y:745,t:1528143744390};\\\", \\\"{x:1326,y:747,t:1528143744407};\\\", \\\"{x:1326,y:750,t:1528143744424};\\\", \\\"{x:1325,y:751,t:1528143744441};\\\", \\\"{x:1324,y:753,t:1528143744457};\\\", \\\"{x:1324,y:754,t:1528143744473};\\\", \\\"{x:1323,y:755,t:1528143744490};\\\", \\\"{x:1323,y:756,t:1528143744507};\\\", \\\"{x:1323,y:757,t:1528143744523};\\\", \\\"{x:1322,y:758,t:1528143744547};\\\", \\\"{x:1321,y:758,t:1528143744571};\\\", \\\"{x:1321,y:759,t:1528143744588};\\\", \\\"{x:1321,y:760,t:1528143744604};\\\", \\\"{x:1321,y:761,t:1528143744644};\\\", \\\"{x:1320,y:762,t:1528143744692};\\\", \\\"{x:1320,y:763,t:1528143745004};\\\", \\\"{x:1319,y:764,t:1528143745012};\\\", \\\"{x:1318,y:764,t:1528143745027};\\\", \\\"{x:1318,y:765,t:1528143745043};\\\", \\\"{x:1318,y:766,t:1528143745100};\\\", \\\"{x:1318,y:767,t:1528143745164};\\\", \\\"{x:1317,y:769,t:1528143745174};\\\", \\\"{x:1317,y:770,t:1528143745203};\\\", \\\"{x:1316,y:770,t:1528143745211};\\\", \\\"{x:1316,y:771,t:1528143745224};\\\", \\\"{x:1315,y:772,t:1528143745242};\\\", \\\"{x:1314,y:774,t:1528143745257};\\\", \\\"{x:1313,y:776,t:1528143745274};\\\", \\\"{x:1312,y:778,t:1528143745291};\\\", \\\"{x:1311,y:781,t:1528143745307};\\\", \\\"{x:1309,y:783,t:1528143745324};\\\", \\\"{x:1309,y:785,t:1528143745341};\\\", \\\"{x:1307,y:788,t:1528143745357};\\\", \\\"{x:1306,y:791,t:1528143745374};\\\", \\\"{x:1305,y:793,t:1528143745392};\\\", \\\"{x:1304,y:795,t:1528143745407};\\\", \\\"{x:1304,y:796,t:1528143745425};\\\", \\\"{x:1302,y:799,t:1528143745441};\\\", \\\"{x:1300,y:803,t:1528143745458};\\\", \\\"{x:1298,y:805,t:1528143745475};\\\", \\\"{x:1296,y:809,t:1528143745492};\\\", \\\"{x:1294,y:812,t:1528143745507};\\\", \\\"{x:1294,y:814,t:1528143745525};\\\", \\\"{x:1292,y:817,t:1528143745541};\\\", \\\"{x:1291,y:819,t:1528143745558};\\\", \\\"{x:1290,y:819,t:1528143745575};\\\", \\\"{x:1290,y:820,t:1528143745592};\\\", \\\"{x:1289,y:820,t:1528143745607};\\\", \\\"{x:1289,y:821,t:1528143745624};\\\", \\\"{x:1288,y:822,t:1528143745643};\\\", \\\"{x:1288,y:823,t:1528143745659};\\\", \\\"{x:1288,y:824,t:1528143745684};\\\", \\\"{x:1286,y:826,t:1528143745699};\\\", \\\"{x:1286,y:827,t:1528143745732};\\\", \\\"{x:1286,y:823,t:1528143745860};\\\", \\\"{x:1286,y:812,t:1528143745875};\\\", \\\"{x:1289,y:778,t:1528143745891};\\\", \\\"{x:1297,y:757,t:1528143745909};\\\", \\\"{x:1306,y:727,t:1528143745924};\\\", \\\"{x:1318,y:687,t:1528143745942};\\\", \\\"{x:1331,y:652,t:1528143745958};\\\", \\\"{x:1340,y:632,t:1528143745974};\\\", \\\"{x:1344,y:623,t:1528143745991};\\\", \\\"{x:1348,y:616,t:1528143746008};\\\", \\\"{x:1350,y:610,t:1528143746025};\\\", \\\"{x:1351,y:605,t:1528143746041};\\\", \\\"{x:1353,y:601,t:1528143746058};\\\", \\\"{x:1356,y:597,t:1528143746074};\\\", \\\"{x:1365,y:590,t:1528143746091};\\\", \\\"{x:1369,y:587,t:1528143746108};\\\", \\\"{x:1371,y:585,t:1528143746125};\\\", \\\"{x:1375,y:583,t:1528143746141};\\\", \\\"{x:1377,y:582,t:1528143746159};\\\", \\\"{x:1382,y:580,t:1528143746176};\\\", \\\"{x:1386,y:578,t:1528143746192};\\\", \\\"{x:1388,y:577,t:1528143746209};\\\", \\\"{x:1395,y:576,t:1528143746226};\\\", \\\"{x:1401,y:574,t:1528143746241};\\\", \\\"{x:1403,y:573,t:1528143746259};\\\", \\\"{x:1405,y:572,t:1528143746420};\\\", \\\"{x:1407,y:568,t:1528143746427};\\\", \\\"{x:1409,y:566,t:1528143746441};\\\", \\\"{x:1413,y:564,t:1528143746459};\\\", \\\"{x:1414,y:563,t:1528143746476};\\\", \\\"{x:1414,y:562,t:1528143746604};\\\", \\\"{x:1411,y:568,t:1528143746692};\\\", \\\"{x:1407,y:585,t:1528143746708};\\\", \\\"{x:1403,y:601,t:1528143746726};\\\", \\\"{x:1394,y:621,t:1528143746743};\\\", \\\"{x:1384,y:644,t:1528143746759};\\\", \\\"{x:1372,y:670,t:1528143746775};\\\", \\\"{x:1364,y:698,t:1528143746792};\\\", \\\"{x:1349,y:726,t:1528143746809};\\\", \\\"{x:1341,y:745,t:1528143746826};\\\", \\\"{x:1335,y:761,t:1528143746843};\\\", \\\"{x:1325,y:777,t:1528143746859};\\\", \\\"{x:1310,y:802,t:1528143746875};\\\", \\\"{x:1303,y:819,t:1528143746892};\\\", \\\"{x:1297,y:835,t:1528143746909};\\\", \\\"{x:1291,y:844,t:1528143746925};\\\", \\\"{x:1289,y:846,t:1528143746943};\\\", \\\"{x:1287,y:852,t:1528143746959};\\\", \\\"{x:1285,y:857,t:1528143746975};\\\", \\\"{x:1284,y:860,t:1528143746992};\\\", \\\"{x:1283,y:861,t:1528143747010};\\\", \\\"{x:1282,y:863,t:1528143747025};\\\", \\\"{x:1281,y:864,t:1528143747043};\\\", \\\"{x:1278,y:875,t:1528143747060};\\\", \\\"{x:1275,y:882,t:1528143747075};\\\", \\\"{x:1274,y:885,t:1528143747093};\\\", \\\"{x:1273,y:887,t:1528143747115};\\\", \\\"{x:1272,y:889,t:1528143747126};\\\", \\\"{x:1270,y:893,t:1528143747143};\\\", \\\"{x:1269,y:899,t:1528143747159};\\\", \\\"{x:1266,y:903,t:1528143747176};\\\", \\\"{x:1266,y:907,t:1528143747192};\\\", \\\"{x:1263,y:910,t:1528143747209};\\\", \\\"{x:1259,y:915,t:1528143747225};\\\", \\\"{x:1256,y:919,t:1528143747243};\\\", \\\"{x:1250,y:925,t:1528143747259};\\\", \\\"{x:1247,y:930,t:1528143747275};\\\", \\\"{x:1242,y:938,t:1528143747292};\\\", \\\"{x:1232,y:952,t:1528143747309};\\\", \\\"{x:1227,y:961,t:1528143747325};\\\", \\\"{x:1223,y:966,t:1528143747342};\\\", \\\"{x:1221,y:968,t:1528143747359};\\\", \\\"{x:1219,y:969,t:1528143747375};\\\", \\\"{x:1219,y:970,t:1528143747392};\\\", \\\"{x:1218,y:971,t:1528143747532};\\\", \\\"{x:1218,y:972,t:1528143747547};\\\", \\\"{x:1218,y:974,t:1528143747559};\\\", \\\"{x:1221,y:976,t:1528143747576};\\\", \\\"{x:1226,y:978,t:1528143747592};\\\", \\\"{x:1233,y:981,t:1528143747609};\\\", \\\"{x:1242,y:982,t:1528143747627};\\\", \\\"{x:1249,y:982,t:1528143747642};\\\", \\\"{x:1261,y:982,t:1528143747660};\\\", \\\"{x:1268,y:979,t:1528143747676};\\\", \\\"{x:1274,y:975,t:1528143747693};\\\", \\\"{x:1278,y:970,t:1528143747709};\\\", \\\"{x:1284,y:965,t:1528143747727};\\\", \\\"{x:1289,y:959,t:1528143747743};\\\", \\\"{x:1291,y:957,t:1528143747759};\\\", \\\"{x:1292,y:955,t:1528143747776};\\\", \\\"{x:1292,y:954,t:1528143747793};\\\", \\\"{x:1292,y:951,t:1528143747810};\\\", \\\"{x:1292,y:949,t:1528143747827};\\\", \\\"{x:1292,y:947,t:1528143747843};\\\", \\\"{x:1292,y:946,t:1528143747860};\\\", \\\"{x:1291,y:944,t:1528143747891};\\\", \\\"{x:1290,y:944,t:1528143747940};\\\", \\\"{x:1290,y:945,t:1528143747963};\\\", \\\"{x:1288,y:947,t:1528143747977};\\\", \\\"{x:1288,y:950,t:1528143747994};\\\", \\\"{x:1288,y:951,t:1528143748010};\\\", \\\"{x:1287,y:952,t:1528143748027};\\\", \\\"{x:1287,y:953,t:1528143748052};\\\", \\\"{x:1287,y:954,t:1528143748076};\\\", \\\"{x:1285,y:957,t:1528143748094};\\\", \\\"{x:1285,y:963,t:1528143748110};\\\", \\\"{x:1283,y:969,t:1528143748127};\\\", \\\"{x:1281,y:973,t:1528143748143};\\\", \\\"{x:1281,y:975,t:1528143748160};\\\", \\\"{x:1281,y:976,t:1528143748177};\\\", \\\"{x:1281,y:979,t:1528143748193};\\\", \\\"{x:1281,y:982,t:1528143748210};\\\", \\\"{x:1280,y:985,t:1528143748227};\\\", \\\"{x:1279,y:989,t:1528143748244};\\\", \\\"{x:1279,y:990,t:1528143748259};\\\", \\\"{x:1279,y:992,t:1528143748277};\\\", \\\"{x:1281,y:994,t:1528143748294};\\\", \\\"{x:1284,y:995,t:1528143748310};\\\", \\\"{x:1288,y:996,t:1528143748326};\\\", \\\"{x:1294,y:996,t:1528143748343};\\\", \\\"{x:1299,y:996,t:1528143748360};\\\", \\\"{x:1303,y:996,t:1528143748376};\\\", \\\"{x:1311,y:996,t:1528143748393};\\\", \\\"{x:1317,y:996,t:1528143748410};\\\", \\\"{x:1323,y:995,t:1528143748426};\\\", \\\"{x:1332,y:990,t:1528143748443};\\\", \\\"{x:1336,y:986,t:1528143748460};\\\", \\\"{x:1339,y:982,t:1528143748476};\\\", \\\"{x:1341,y:978,t:1528143748493};\\\", \\\"{x:1346,y:974,t:1528143748510};\\\", \\\"{x:1348,y:972,t:1528143748526};\\\", \\\"{x:1350,y:969,t:1528143748543};\\\", \\\"{x:1351,y:968,t:1528143748560};\\\", \\\"{x:1351,y:967,t:1528143748576};\\\", \\\"{x:1351,y:966,t:1528143748595};\\\", \\\"{x:1351,y:965,t:1528143748610};\\\", \\\"{x:1351,y:964,t:1528143748652};\\\", \\\"{x:1352,y:964,t:1528143748844};\\\", \\\"{x:1353,y:967,t:1528143748861};\\\", \\\"{x:1355,y:970,t:1528143748878};\\\", \\\"{x:1356,y:974,t:1528143748894};\\\", \\\"{x:1358,y:977,t:1528143748910};\\\", \\\"{x:1360,y:979,t:1528143748928};\\\", \\\"{x:1362,y:981,t:1528143748943};\\\", \\\"{x:1363,y:981,t:1528143748960};\\\", \\\"{x:1365,y:983,t:1528143748977};\\\", \\\"{x:1367,y:984,t:1528143748994};\\\", \\\"{x:1369,y:984,t:1528143749011};\\\", \\\"{x:1377,y:990,t:1528143749028};\\\", \\\"{x:1380,y:992,t:1528143749043};\\\", \\\"{x:1384,y:994,t:1528143749060};\\\", \\\"{x:1386,y:994,t:1528143749077};\\\", \\\"{x:1388,y:995,t:1528143749093};\\\", \\\"{x:1391,y:995,t:1528143749111};\\\", \\\"{x:1394,y:995,t:1528143749128};\\\", \\\"{x:1395,y:995,t:1528143749144};\\\", \\\"{x:1397,y:995,t:1528143749161};\\\", \\\"{x:1400,y:995,t:1528143749177};\\\", \\\"{x:1403,y:993,t:1528143749193};\\\", \\\"{x:1405,y:993,t:1528143749211};\\\", \\\"{x:1416,y:986,t:1528143749227};\\\", \\\"{x:1419,y:983,t:1528143749245};\\\", \\\"{x:1422,y:978,t:1528143749261};\\\", \\\"{x:1423,y:975,t:1528143749278};\\\", \\\"{x:1425,y:971,t:1528143749295};\\\", \\\"{x:1426,y:964,t:1528143749311};\\\", \\\"{x:1427,y:958,t:1528143749328};\\\", \\\"{x:1428,y:952,t:1528143749345};\\\", \\\"{x:1429,y:948,t:1528143749361};\\\", \\\"{x:1429,y:946,t:1528143749377};\\\", \\\"{x:1429,y:945,t:1528143749395};\\\", \\\"{x:1429,y:944,t:1528143749492};\\\", \\\"{x:1428,y:944,t:1528143749499};\\\", \\\"{x:1427,y:944,t:1528143749511};\\\", \\\"{x:1426,y:946,t:1528143749528};\\\", \\\"{x:1426,y:948,t:1528143749545};\\\", \\\"{x:1425,y:951,t:1528143749561};\\\", \\\"{x:1424,y:953,t:1528143749578};\\\", \\\"{x:1424,y:955,t:1528143749595};\\\", \\\"{x:1424,y:958,t:1528143749611};\\\", \\\"{x:1424,y:963,t:1528143749628};\\\", \\\"{x:1424,y:965,t:1528143749645};\\\", \\\"{x:1424,y:967,t:1528143749662};\\\", \\\"{x:1424,y:972,t:1528143749677};\\\", \\\"{x:1424,y:978,t:1528143749694};\\\", \\\"{x:1424,y:984,t:1528143749711};\\\", \\\"{x:1427,y:987,t:1528143749728};\\\", \\\"{x:1430,y:991,t:1528143749745};\\\", \\\"{x:1431,y:993,t:1528143749762};\\\", \\\"{x:1433,y:994,t:1528143749777};\\\", \\\"{x:1435,y:995,t:1528143749794};\\\", \\\"{x:1436,y:996,t:1528143749811};\\\", \\\"{x:1437,y:998,t:1528143749827};\\\", \\\"{x:1438,y:998,t:1528143749844};\\\", \\\"{x:1439,y:998,t:1528143749861};\\\", \\\"{x:1441,y:998,t:1528143749878};\\\", \\\"{x:1442,y:998,t:1528143749895};\\\", \\\"{x:1444,y:998,t:1528143749911};\\\", \\\"{x:1447,y:998,t:1528143749928};\\\", \\\"{x:1448,y:998,t:1528143749945};\\\", \\\"{x:1451,y:998,t:1528143749962};\\\", \\\"{x:1453,y:997,t:1528143749977};\\\", \\\"{x:1455,y:995,t:1528143749995};\\\", \\\"{x:1462,y:989,t:1528143750011};\\\", \\\"{x:1465,y:987,t:1528143750028};\\\", \\\"{x:1469,y:984,t:1528143750045};\\\", \\\"{x:1472,y:982,t:1528143750062};\\\", \\\"{x:1474,y:979,t:1528143750078};\\\", \\\"{x:1475,y:977,t:1528143750095};\\\", \\\"{x:1476,y:976,t:1528143750111};\\\", \\\"{x:1477,y:975,t:1528143750129};\\\", \\\"{x:1477,y:973,t:1528143750147};\\\", \\\"{x:1479,y:972,t:1528143750161};\\\", \\\"{x:1479,y:971,t:1528143750179};\\\", \\\"{x:1479,y:970,t:1528143750195};\\\", \\\"{x:1480,y:969,t:1528143750212};\\\", \\\"{x:1480,y:968,t:1528143750236};\\\", \\\"{x:1482,y:966,t:1528143750251};\\\", \\\"{x:1483,y:967,t:1528143751500};\\\", \\\"{x:1483,y:970,t:1528143751513};\\\", \\\"{x:1484,y:973,t:1528143751530};\\\", \\\"{x:1484,y:974,t:1528143751546};\\\", \\\"{x:1485,y:976,t:1528143751562};\\\", \\\"{x:1487,y:980,t:1528143751579};\\\", \\\"{x:1488,y:983,t:1528143751596};\\\", \\\"{x:1489,y:984,t:1528143751613};\\\", \\\"{x:1490,y:986,t:1528143751630};\\\", \\\"{x:1491,y:987,t:1528143751646};\\\", \\\"{x:1491,y:988,t:1528143751663};\\\", \\\"{x:1493,y:991,t:1528143751680};\\\", \\\"{x:1493,y:993,t:1528143751696};\\\", \\\"{x:1496,y:996,t:1528143751713};\\\", \\\"{x:1497,y:997,t:1528143751729};\\\", \\\"{x:1498,y:997,t:1528143751747};\\\", \\\"{x:1499,y:998,t:1528143751763};\\\", \\\"{x:1500,y:1000,t:1528143751779};\\\", \\\"{x:1502,y:1000,t:1528143751795};\\\", \\\"{x:1504,y:1001,t:1528143751843};\\\", \\\"{x:1504,y:1002,t:1528143751859};\\\", \\\"{x:1505,y:1002,t:1528143751875};\\\", \\\"{x:1506,y:1003,t:1528143751891};\\\", \\\"{x:1507,y:1003,t:1528143751923};\\\", \\\"{x:1508,y:1004,t:1528143751972};\\\", \\\"{x:1509,y:1004,t:1528143751995};\\\", \\\"{x:1510,y:1005,t:1528143752003};\\\", \\\"{x:1511,y:1005,t:1528143752059};\\\", \\\"{x:1512,y:1005,t:1528143752084};\\\", \\\"{x:1513,y:1005,t:1528143752124};\\\", \\\"{x:1514,y:1006,t:1528143752132};\\\", \\\"{x:1515,y:1006,t:1528143752156};\\\", \\\"{x:1515,y:1007,t:1528143752164};\\\", \\\"{x:1516,y:1007,t:1528143752324};\\\", \\\"{x:1517,y:1007,t:1528143752820};\\\", \\\"{x:1518,y:1007,t:1528143752836};\\\", \\\"{x:1519,y:1007,t:1528143752964};\\\", \\\"{x:1520,y:1007,t:1528143753003};\\\", \\\"{x:1521,y:1007,t:1528143753115};\\\", \\\"{x:1523,y:1007,t:1528143753131};\\\", \\\"{x:1524,y:1007,t:1528143753147};\\\", \\\"{x:1526,y:1007,t:1528143753163};\\\", \\\"{x:1527,y:1007,t:1528143753181};\\\", \\\"{x:1527,y:1006,t:1528143753198};\\\", \\\"{x:1528,y:1005,t:1528143753220};\\\", \\\"{x:1529,y:1004,t:1528143753235};\\\", \\\"{x:1530,y:1004,t:1528143753247};\\\", \\\"{x:1531,y:1003,t:1528143753264};\\\", \\\"{x:1532,y:1002,t:1528143753281};\\\", \\\"{x:1534,y:1001,t:1528143753298};\\\", \\\"{x:1536,y:999,t:1528143753314};\\\", \\\"{x:1537,y:999,t:1528143753331};\\\", \\\"{x:1537,y:998,t:1528143753348};\\\", \\\"{x:1539,y:996,t:1528143753363};\\\", \\\"{x:1540,y:995,t:1528143753380};\\\", \\\"{x:1540,y:994,t:1528143753399};\\\", \\\"{x:1541,y:993,t:1528143753413};\\\", \\\"{x:1542,y:991,t:1528143753430};\\\", \\\"{x:1543,y:990,t:1528143753447};\\\", \\\"{x:1544,y:989,t:1528143753463};\\\", \\\"{x:1545,y:988,t:1528143753480};\\\", \\\"{x:1546,y:986,t:1528143753497};\\\", \\\"{x:1547,y:983,t:1528143753515};\\\", \\\"{x:1548,y:982,t:1528143753531};\\\", \\\"{x:1549,y:980,t:1528143753547};\\\", \\\"{x:1549,y:979,t:1528143753563};\\\", \\\"{x:1550,y:977,t:1528143753581};\\\", \\\"{x:1551,y:975,t:1528143753598};\\\", \\\"{x:1552,y:974,t:1528143753619};\\\", \\\"{x:1552,y:973,t:1528143753635};\\\", \\\"{x:1552,y:972,t:1528143753648};\\\", \\\"{x:1553,y:970,t:1528143754659};\\\", \\\"{x:1553,y:968,t:1528143754724};\\\", \\\"{x:1555,y:966,t:1528143754731};\\\", \\\"{x:1555,y:965,t:1528143754748};\\\", \\\"{x:1555,y:963,t:1528143754766};\\\", \\\"{x:1556,y:962,t:1528143754782};\\\", \\\"{x:1556,y:961,t:1528143754799};\\\", \\\"{x:1556,y:960,t:1528143754815};\\\", \\\"{x:1556,y:958,t:1528143754832};\\\", \\\"{x:1556,y:957,t:1528143754916};\\\", \\\"{x:1558,y:955,t:1528143754932};\\\", \\\"{x:1558,y:954,t:1528143754948};\\\", \\\"{x:1558,y:952,t:1528143754965};\\\", \\\"{x:1558,y:951,t:1528143754995};\\\", \\\"{x:1559,y:950,t:1528143755026};\\\", \\\"{x:1559,y:948,t:1528143755042};\\\", \\\"{x:1558,y:945,t:1528143755059};\\\", \\\"{x:1551,y:941,t:1528143755067};\\\", \\\"{x:1546,y:939,t:1528143755082};\\\", \\\"{x:1508,y:923,t:1528143755098};\\\", \\\"{x:1461,y:901,t:1528143755115};\\\", \\\"{x:1373,y:865,t:1528143755132};\\\", \\\"{x:1257,y:815,t:1528143755149};\\\", \\\"{x:1153,y:776,t:1528143755166};\\\", \\\"{x:1071,y:756,t:1528143755181};\\\", \\\"{x:1012,y:737,t:1528143755198};\\\", \\\"{x:953,y:720,t:1528143755216};\\\", \\\"{x:898,y:706,t:1528143755232};\\\", \\\"{x:863,y:695,t:1528143755249};\\\", \\\"{x:842,y:686,t:1528143755266};\\\", \\\"{x:824,y:677,t:1528143755281};\\\", \\\"{x:792,y:660,t:1528143755299};\\\", \\\"{x:744,y:636,t:1528143755315};\\\", \\\"{x:687,y:612,t:1528143755333};\\\", \\\"{x:643,y:596,t:1528143755349};\\\", \\\"{x:618,y:588,t:1528143755366};\\\", \\\"{x:597,y:587,t:1528143755379};\\\", \\\"{x:574,y:587,t:1528143755397};\\\", \\\"{x:548,y:587,t:1528143755417};\\\", \\\"{x:513,y:584,t:1528143755434};\\\", \\\"{x:488,y:584,t:1528143755451};\\\", \\\"{x:465,y:583,t:1528143755467};\\\", \\\"{x:447,y:583,t:1528143755483};\\\", \\\"{x:427,y:583,t:1528143755500};\\\", \\\"{x:410,y:583,t:1528143755517};\\\", \\\"{x:399,y:583,t:1528143755533};\\\", \\\"{x:389,y:582,t:1528143755551};\\\", \\\"{x:380,y:579,t:1528143755568};\\\", \\\"{x:368,y:575,t:1528143755585};\\\", \\\"{x:360,y:574,t:1528143755601};\\\", \\\"{x:354,y:574,t:1528143755617};\\\", \\\"{x:349,y:574,t:1528143755634};\\\", \\\"{x:343,y:574,t:1528143755650};\\\", \\\"{x:332,y:574,t:1528143755668};\\\", \\\"{x:319,y:574,t:1528143755685};\\\", \\\"{x:306,y:574,t:1528143755702};\\\", \\\"{x:297,y:575,t:1528143755717};\\\", \\\"{x:291,y:577,t:1528143755735};\\\", \\\"{x:288,y:580,t:1528143755752};\\\", \\\"{x:287,y:581,t:1528143755767};\\\", \\\"{x:284,y:585,t:1528143755784};\\\", \\\"{x:284,y:588,t:1528143755802};\\\", \\\"{x:284,y:591,t:1528143755817};\\\", \\\"{x:297,y:600,t:1528143755835};\\\", \\\"{x:310,y:605,t:1528143755851};\\\", \\\"{x:324,y:613,t:1528143755867};\\\", \\\"{x:338,y:618,t:1528143755885};\\\", \\\"{x:345,y:620,t:1528143755902};\\\", \\\"{x:351,y:624,t:1528143755918};\\\", \\\"{x:361,y:627,t:1528143755935};\\\", \\\"{x:371,y:629,t:1528143755951};\\\", \\\"{x:383,y:629,t:1528143755967};\\\", \\\"{x:396,y:629,t:1528143755984};\\\", \\\"{x:404,y:629,t:1528143756001};\\\", \\\"{x:414,y:629,t:1528143756017};\\\", \\\"{x:444,y:634,t:1528143756037};\\\", \\\"{x:463,y:637,t:1528143756051};\\\", \\\"{x:482,y:642,t:1528143756068};\\\", \\\"{x:502,y:644,t:1528143756085};\\\", \\\"{x:521,y:648,t:1528143756101};\\\", \\\"{x:538,y:649,t:1528143756117};\\\", \\\"{x:559,y:649,t:1528143756134};\\\", \\\"{x:585,y:650,t:1528143756151};\\\", \\\"{x:608,y:650,t:1528143756167};\\\", \\\"{x:632,y:650,t:1528143756184};\\\", \\\"{x:651,y:649,t:1528143756201};\\\", \\\"{x:661,y:647,t:1528143756218};\\\", \\\"{x:672,y:643,t:1528143756234};\\\", \\\"{x:681,y:642,t:1528143756250};\\\", \\\"{x:690,y:640,t:1528143756267};\\\", \\\"{x:696,y:637,t:1528143756284};\\\", \\\"{x:701,y:634,t:1528143756302};\\\", \\\"{x:712,y:626,t:1528143756319};\\\", \\\"{x:727,y:617,t:1528143756334};\\\", \\\"{x:740,y:608,t:1528143756351};\\\", \\\"{x:756,y:604,t:1528143756368};\\\", \\\"{x:776,y:599,t:1528143756385};\\\", \\\"{x:790,y:594,t:1528143756401};\\\", \\\"{x:800,y:590,t:1528143756418};\\\", \\\"{x:804,y:590,t:1528143756435};\\\", \\\"{x:806,y:590,t:1528143756451};\\\", \\\"{x:808,y:589,t:1528143756468};\\\", \\\"{x:811,y:588,t:1528143756484};\\\", \\\"{x:814,y:587,t:1528143756501};\\\", \\\"{x:820,y:583,t:1528143756518};\\\", \\\"{x:827,y:578,t:1528143756534};\\\", \\\"{x:835,y:572,t:1528143756551};\\\", \\\"{x:841,y:567,t:1528143756569};\\\", \\\"{x:847,y:562,t:1528143756586};\\\", \\\"{x:851,y:558,t:1528143756602};\\\", \\\"{x:852,y:554,t:1528143756619};\\\", \\\"{x:853,y:553,t:1528143756634};\\\", \\\"{x:855,y:551,t:1528143756651};\\\", \\\"{x:856,y:550,t:1528143756669};\\\", \\\"{x:858,y:547,t:1528143756685};\\\", \\\"{x:859,y:547,t:1528143756701};\\\", \\\"{x:859,y:546,t:1528143756719};\\\", \\\"{x:859,y:545,t:1528143756747};\\\", \\\"{x:859,y:544,t:1528143756762};\\\", \\\"{x:858,y:543,t:1528143756771};\\\", \\\"{x:857,y:543,t:1528143756785};\\\", \\\"{x:855,y:542,t:1528143756801};\\\", \\\"{x:851,y:540,t:1528143756819};\\\", \\\"{x:849,y:540,t:1528143756835};\\\", \\\"{x:847,y:538,t:1528143756852};\\\", \\\"{x:846,y:538,t:1528143756869};\\\", \\\"{x:845,y:538,t:1528143756886};\\\", \\\"{x:844,y:538,t:1528143757308};\\\", \\\"{x:843,y:538,t:1528143757323};\\\", \\\"{x:844,y:538,t:1528143757610};\\\", \\\"{x:848,y:538,t:1528143757618};\\\", \\\"{x:859,y:542,t:1528143757635};\\\", \\\"{x:868,y:543,t:1528143757652};\\\", \\\"{x:881,y:543,t:1528143757670};\\\", \\\"{x:905,y:543,t:1528143757685};\\\", \\\"{x:937,y:539,t:1528143757703};\\\", \\\"{x:996,y:517,t:1528143757720};\\\", \\\"{x:1060,y:490,t:1528143757735};\\\", \\\"{x:1142,y:454,t:1528143757753};\\\", \\\"{x:1222,y:419,t:1528143757770};\\\", \\\"{x:1270,y:396,t:1528143757785};\\\", \\\"{x:1319,y:373,t:1528143757802};\\\", \\\"{x:1339,y:364,t:1528143757819};\\\", \\\"{x:1352,y:357,t:1528143757836};\\\", \\\"{x:1353,y:356,t:1528143757852};\\\", \\\"{x:1354,y:356,t:1528143757870};\\\", \\\"{x:1356,y:355,t:1528143757886};\\\", \\\"{x:1358,y:361,t:1528143757995};\\\", \\\"{x:1361,y:374,t:1528143758003};\\\", \\\"{x:1371,y:405,t:1528143758019};\\\", \\\"{x:1389,y:439,t:1528143758036};\\\", \\\"{x:1404,y:465,t:1528143758053};\\\", \\\"{x:1414,y:476,t:1528143758070};\\\", \\\"{x:1417,y:476,t:1528143758086};\\\", \\\"{x:1418,y:473,t:1528143758148};\\\", \\\"{x:1419,y:465,t:1528143758155};\\\", \\\"{x:1420,y:460,t:1528143758170};\\\", \\\"{x:1426,y:453,t:1528143758186};\\\", \\\"{x:1435,y:445,t:1528143758204};\\\", \\\"{x:1437,y:443,t:1528143758220};\\\", \\\"{x:1437,y:442,t:1528143758363};\\\", \\\"{x:1436,y:441,t:1528143758419};\\\", \\\"{x:1433,y:440,t:1528143758436};\\\", \\\"{x:1428,y:438,t:1528143758452};\\\", \\\"{x:1421,y:435,t:1528143758470};\\\", \\\"{x:1417,y:433,t:1528143758487};\\\", \\\"{x:1417,y:432,t:1528143758723};\\\", \\\"{x:1416,y:430,t:1528143759714};\\\", \\\"{x:1420,y:410,t:1528143759723};\\\", \\\"{x:1429,y:389,t:1528143759736};\\\", \\\"{x:1442,y:359,t:1528143759753};\\\", \\\"{x:1463,y:326,t:1528143759771};\\\", \\\"{x:1474,y:304,t:1528143759787};\\\", \\\"{x:1479,y:297,t:1528143759804};\\\", \\\"{x:1480,y:294,t:1528143759821};\\\", \\\"{x:1481,y:293,t:1528143759836};\\\", \\\"{x:1481,y:292,t:1528143759859};\\\", \\\"{x:1481,y:291,t:1528143759876};\\\", \\\"{x:1481,y:290,t:1528143759891};\\\", \\\"{x:1482,y:288,t:1528143759904};\\\", \\\"{x:1483,y:286,t:1528143759921};\\\", \\\"{x:1481,y:287,t:1528143760124};\\\", \\\"{x:1481,y:288,t:1528143760137};\\\", \\\"{x:1477,y:300,t:1528143760155};\\\", \\\"{x:1470,y:320,t:1528143760171};\\\", \\\"{x:1462,y:334,t:1528143760187};\\\", \\\"{x:1457,y:346,t:1528143760204};\\\", \\\"{x:1451,y:359,t:1528143760221};\\\", \\\"{x:1446,y:373,t:1528143760238};\\\", \\\"{x:1444,y:381,t:1528143760254};\\\", \\\"{x:1441,y:392,t:1528143760271};\\\", \\\"{x:1436,y:407,t:1528143760288};\\\", \\\"{x:1432,y:419,t:1528143760304};\\\", \\\"{x:1431,y:430,t:1528143760321};\\\", \\\"{x:1426,y:444,t:1528143760339};\\\", \\\"{x:1420,y:465,t:1528143760355};\\\", \\\"{x:1407,y:497,t:1528143760371};\\\", \\\"{x:1397,y:520,t:1528143760387};\\\", \\\"{x:1386,y:545,t:1528143760405};\\\", \\\"{x:1374,y:570,t:1528143760421};\\\", \\\"{x:1365,y:590,t:1528143760438};\\\", \\\"{x:1358,y:606,t:1528143760454};\\\", \\\"{x:1354,y:615,t:1528143760472};\\\", \\\"{x:1351,y:621,t:1528143760488};\\\", \\\"{x:1346,y:628,t:1528143760504};\\\", \\\"{x:1339,y:635,t:1528143760521};\\\", \\\"{x:1336,y:643,t:1528143760539};\\\", \\\"{x:1331,y:651,t:1528143760555};\\\", \\\"{x:1326,y:662,t:1528143760571};\\\", \\\"{x:1323,y:670,t:1528143760588};\\\", \\\"{x:1319,y:678,t:1528143760604};\\\", \\\"{x:1313,y:690,t:1528143760621};\\\", \\\"{x:1306,y:702,t:1528143760638};\\\", \\\"{x:1304,y:708,t:1528143760654};\\\", \\\"{x:1300,y:716,t:1528143760671};\\\", \\\"{x:1295,y:728,t:1528143760688};\\\", \\\"{x:1291,y:741,t:1528143760704};\\\", \\\"{x:1287,y:753,t:1528143760722};\\\", \\\"{x:1283,y:768,t:1528143760739};\\\", \\\"{x:1278,y:779,t:1528143760754};\\\", \\\"{x:1274,y:787,t:1528143760771};\\\", \\\"{x:1272,y:791,t:1528143760788};\\\", \\\"{x:1271,y:793,t:1528143760805};\\\", \\\"{x:1271,y:791,t:1528143760891};\\\", \\\"{x:1271,y:776,t:1528143760905};\\\", \\\"{x:1274,y:733,t:1528143760922};\\\", \\\"{x:1289,y:678,t:1528143760939};\\\", \\\"{x:1315,y:584,t:1528143760956};\\\", \\\"{x:1331,y:530,t:1528143760971};\\\", \\\"{x:1337,y:501,t:1528143760988};\\\", \\\"{x:1340,y:467,t:1528143761006};\\\", \\\"{x:1344,y:445,t:1528143761021};\\\", \\\"{x:1345,y:441,t:1528143761038};\\\", \\\"{x:1345,y:440,t:1528143761055};\\\", \\\"{x:1345,y:439,t:1528143761071};\\\", \\\"{x:1346,y:438,t:1528143761089};\\\", \\\"{x:1347,y:438,t:1528143761180};\\\", \\\"{x:1351,y:438,t:1528143761188};\\\", \\\"{x:1355,y:439,t:1528143761205};\\\", \\\"{x:1358,y:440,t:1528143761221};\\\", \\\"{x:1361,y:443,t:1528143761238};\\\", \\\"{x:1364,y:443,t:1528143761255};\\\", \\\"{x:1368,y:445,t:1528143761271};\\\", \\\"{x:1369,y:446,t:1528143761288};\\\", \\\"{x:1372,y:445,t:1528143761347};\\\", \\\"{x:1373,y:442,t:1528143761355};\\\", \\\"{x:1377,y:437,t:1528143761371};\\\", \\\"{x:1380,y:433,t:1528143761389};\\\", \\\"{x:1381,y:432,t:1528143761406};\\\", \\\"{x:1382,y:431,t:1528143761421};\\\", \\\"{x:1384,y:430,t:1528143761439};\\\", \\\"{x:1390,y:427,t:1528143761456};\\\", \\\"{x:1399,y:426,t:1528143761472};\\\", \\\"{x:1411,y:422,t:1528143761488};\\\", \\\"{x:1418,y:422,t:1528143761506};\\\", \\\"{x:1424,y:421,t:1528143761523};\\\", \\\"{x:1425,y:420,t:1528143761538};\\\", \\\"{x:1426,y:420,t:1528143761652};\\\", \\\"{x:1426,y:423,t:1528143761828};\\\", \\\"{x:1424,y:423,t:1528143761839};\\\", \\\"{x:1422,y:423,t:1528143761855};\\\", \\\"{x:1420,y:425,t:1528143761873};\\\", \\\"{x:1419,y:426,t:1528143762156};\\\", \\\"{x:1418,y:426,t:1528143762172};\\\", \\\"{x:1416,y:428,t:1528143762188};\\\", \\\"{x:1415,y:428,t:1528143762205};\\\", \\\"{x:1415,y:429,t:1528143762222};\\\", \\\"{x:1414,y:429,t:1528143762243};\\\", \\\"{x:1413,y:430,t:1528143762259};\\\", \\\"{x:1413,y:432,t:1528143763052};\\\", \\\"{x:1413,y:435,t:1528143763059};\\\", \\\"{x:1414,y:438,t:1528143763074};\\\", \\\"{x:1418,y:448,t:1528143763089};\\\", \\\"{x:1421,y:452,t:1528143763107};\\\", \\\"{x:1425,y:457,t:1528143763123};\\\", \\\"{x:1427,y:460,t:1528143763139};\\\", \\\"{x:1429,y:462,t:1528143763155};\\\", \\\"{x:1430,y:464,t:1528143763172};\\\", \\\"{x:1433,y:469,t:1528143763189};\\\", \\\"{x:1436,y:475,t:1528143763206};\\\", \\\"{x:1440,y:482,t:1528143763222};\\\", \\\"{x:1443,y:487,t:1528143763239};\\\", \\\"{x:1447,y:491,t:1528143763256};\\\", \\\"{x:1449,y:494,t:1528143763272};\\\", \\\"{x:1453,y:499,t:1528143763290};\\\", \\\"{x:1457,y:505,t:1528143763306};\\\", \\\"{x:1461,y:511,t:1528143763322};\\\", \\\"{x:1466,y:522,t:1528143763339};\\\", \\\"{x:1474,y:533,t:1528143763357};\\\", \\\"{x:1478,y:541,t:1528143763372};\\\", \\\"{x:1481,y:546,t:1528143763390};\\\", \\\"{x:1483,y:549,t:1528143763406};\\\", \\\"{x:1486,y:554,t:1528143763423};\\\", \\\"{x:1489,y:559,t:1528143763440};\\\", \\\"{x:1495,y:568,t:1528143763456};\\\", \\\"{x:1498,y:573,t:1528143763474};\\\", \\\"{x:1503,y:584,t:1528143763497};\\\", \\\"{x:1505,y:589,t:1528143763506};\\\", \\\"{x:1510,y:598,t:1528143763522};\\\", \\\"{x:1513,y:602,t:1528143763539};\\\", \\\"{x:1516,y:608,t:1528143763556};\\\", \\\"{x:1519,y:613,t:1528143763573};\\\", \\\"{x:1523,y:623,t:1528143763589};\\\", \\\"{x:1529,y:635,t:1528143763606};\\\", \\\"{x:1535,y:649,t:1528143763623};\\\", \\\"{x:1542,y:663,t:1528143763639};\\\", \\\"{x:1547,y:678,t:1528143763656};\\\", \\\"{x:1552,y:692,t:1528143763673};\\\", \\\"{x:1556,y:706,t:1528143763689};\\\", \\\"{x:1563,y:727,t:1528143763706};\\\", \\\"{x:1577,y:762,t:1528143763723};\\\", \\\"{x:1587,y:786,t:1528143763739};\\\", \\\"{x:1596,y:806,t:1528143763756};\\\", \\\"{x:1606,y:826,t:1528143763773};\\\", \\\"{x:1610,y:842,t:1528143763789};\\\", \\\"{x:1615,y:854,t:1528143763806};\\\", \\\"{x:1622,y:871,t:1528143763823};\\\", \\\"{x:1629,y:890,t:1528143763839};\\\", \\\"{x:1634,y:903,t:1528143763856};\\\", \\\"{x:1639,y:921,t:1528143763873};\\\", \\\"{x:1642,y:933,t:1528143763889};\\\", \\\"{x:1645,y:943,t:1528143763907};\\\", \\\"{x:1649,y:954,t:1528143763923};\\\", \\\"{x:1651,y:965,t:1528143763939};\\\", \\\"{x:1656,y:976,t:1528143763956};\\\", \\\"{x:1657,y:982,t:1528143763973};\\\", \\\"{x:1657,y:986,t:1528143763989};\\\", \\\"{x:1657,y:987,t:1528143764006};\\\", \\\"{x:1655,y:987,t:1528143764196};\\\", \\\"{x:1652,y:987,t:1528143764207};\\\", \\\"{x:1649,y:986,t:1528143764223};\\\", \\\"{x:1647,y:985,t:1528143764240};\\\", \\\"{x:1643,y:984,t:1528143764256};\\\", \\\"{x:1642,y:983,t:1528143764363};\\\", \\\"{x:1641,y:982,t:1528143764373};\\\", \\\"{x:1641,y:981,t:1528143764428};\\\", \\\"{x:1641,y:980,t:1528143764441};\\\", \\\"{x:1641,y:979,t:1528143764457};\\\", \\\"{x:1640,y:978,t:1528143764483};\\\", \\\"{x:1639,y:977,t:1528143764571};\\\", \\\"{x:1639,y:976,t:1528143764579};\\\", \\\"{x:1638,y:974,t:1528143764590};\\\", \\\"{x:1636,y:968,t:1528143764606};\\\", \\\"{x:1633,y:962,t:1528143764624};\\\", \\\"{x:1630,y:955,t:1528143764641};\\\", \\\"{x:1626,y:948,t:1528143764656};\\\", \\\"{x:1622,y:937,t:1528143764673};\\\", \\\"{x:1610,y:918,t:1528143764690};\\\", \\\"{x:1590,y:889,t:1528143764707};\\\", \\\"{x:1558,y:839,t:1528143764724};\\\", \\\"{x:1551,y:827,t:1528143764740};\\\", \\\"{x:1546,y:813,t:1528143764756};\\\", \\\"{x:1538,y:799,t:1528143764774};\\\", \\\"{x:1530,y:780,t:1528143764791};\\\", \\\"{x:1517,y:755,t:1528143764807};\\\", \\\"{x:1491,y:717,t:1528143764823};\\\", \\\"{x:1469,y:690,t:1528143764841};\\\", \\\"{x:1456,y:669,t:1528143764857};\\\", \\\"{x:1448,y:658,t:1528143764873};\\\", \\\"{x:1442,y:651,t:1528143764890};\\\", \\\"{x:1430,y:636,t:1528143764907};\\\", \\\"{x:1424,y:625,t:1528143764923};\\\", \\\"{x:1418,y:614,t:1528143764940};\\\", \\\"{x:1415,y:604,t:1528143764957};\\\", \\\"{x:1415,y:595,t:1528143764972};\\\", \\\"{x:1415,y:587,t:1528143764990};\\\", \\\"{x:1415,y:576,t:1528143765007};\\\", \\\"{x:1415,y:563,t:1528143765023};\\\", \\\"{x:1415,y:546,t:1528143765040};\\\", \\\"{x:1415,y:524,t:1528143765057};\\\", \\\"{x:1415,y:497,t:1528143765073};\\\", \\\"{x:1414,y:466,t:1528143765090};\\\", \\\"{x:1403,y:422,t:1528143765107};\\\", \\\"{x:1393,y:403,t:1528143765123};\\\", \\\"{x:1388,y:395,t:1528143765140};\\\", \\\"{x:1388,y:393,t:1528143765157};\\\", \\\"{x:1388,y:392,t:1528143765173};\\\", \\\"{x:1389,y:392,t:1528143765268};\\\", \\\"{x:1389,y:394,t:1528143765275};\\\", \\\"{x:1389,y:398,t:1528143765290};\\\", \\\"{x:1390,y:408,t:1528143765308};\\\", \\\"{x:1390,y:416,t:1528143765323};\\\", \\\"{x:1390,y:422,t:1528143765341};\\\", \\\"{x:1392,y:432,t:1528143765358};\\\", \\\"{x:1392,y:440,t:1528143765374};\\\", \\\"{x:1392,y:448,t:1528143765390};\\\", \\\"{x:1391,y:457,t:1528143765408};\\\", \\\"{x:1385,y:469,t:1528143765423};\\\", \\\"{x:1381,y:476,t:1528143765441};\\\", \\\"{x:1377,y:484,t:1528143765458};\\\", \\\"{x:1373,y:492,t:1528143765475};\\\", \\\"{x:1368,y:504,t:1528143765491};\\\", \\\"{x:1358,y:525,t:1528143765507};\\\", \\\"{x:1352,y:543,t:1528143765524};\\\", \\\"{x:1346,y:563,t:1528143765540};\\\", \\\"{x:1336,y:584,t:1528143765558};\\\", \\\"{x:1327,y:603,t:1528143765574};\\\", \\\"{x:1318,y:620,t:1528143765590};\\\", \\\"{x:1308,y:642,t:1528143765608};\\\", \\\"{x:1300,y:667,t:1528143765625};\\\", \\\"{x:1290,y:688,t:1528143765640};\\\", \\\"{x:1279,y:707,t:1528143765657};\\\", \\\"{x:1269,y:723,t:1528143765674};\\\", \\\"{x:1263,y:739,t:1528143765691};\\\", \\\"{x:1243,y:776,t:1528143765707};\\\", \\\"{x:1213,y:828,t:1528143765724};\\\", \\\"{x:1202,y:849,t:1528143765742};\\\", \\\"{x:1192,y:863,t:1528143765757};\\\", \\\"{x:1187,y:872,t:1528143765775};\\\", \\\"{x:1182,y:883,t:1528143765791};\\\", \\\"{x:1178,y:891,t:1528143765807};\\\", \\\"{x:1177,y:897,t:1528143765824};\\\", \\\"{x:1174,y:903,t:1528143765840};\\\", \\\"{x:1173,y:908,t:1528143765857};\\\", \\\"{x:1173,y:912,t:1528143765874};\\\", \\\"{x:1170,y:917,t:1528143765890};\\\", \\\"{x:1170,y:926,t:1528143765907};\\\", \\\"{x:1168,y:936,t:1528143765924};\\\", \\\"{x:1166,y:945,t:1528143765940};\\\", \\\"{x:1163,y:953,t:1528143765957};\\\", \\\"{x:1160,y:962,t:1528143765974};\\\", \\\"{x:1154,y:973,t:1528143765990};\\\", \\\"{x:1151,y:980,t:1528143766007};\\\", \\\"{x:1149,y:984,t:1528143766024};\\\", \\\"{x:1147,y:988,t:1528143766041};\\\", \\\"{x:1146,y:991,t:1528143766057};\\\", \\\"{x:1144,y:996,t:1528143766074};\\\", \\\"{x:1143,y:1000,t:1528143766090};\\\", \\\"{x:1143,y:1001,t:1528143766468};\\\", \\\"{x:1146,y:1001,t:1528143766483};\\\", \\\"{x:1148,y:1001,t:1528143766492};\\\", \\\"{x:1153,y:1001,t:1528143766507};\\\", \\\"{x:1159,y:999,t:1528143766524};\\\", \\\"{x:1166,y:998,t:1528143766542};\\\", \\\"{x:1174,y:998,t:1528143766557};\\\", \\\"{x:1178,y:997,t:1528143766574};\\\", \\\"{x:1185,y:997,t:1528143766592};\\\", \\\"{x:1194,y:997,t:1528143766607};\\\", \\\"{x:1206,y:997,t:1528143766625};\\\", \\\"{x:1225,y:997,t:1528143766642};\\\", \\\"{x:1243,y:997,t:1528143766657};\\\", \\\"{x:1258,y:997,t:1528143766675};\\\", \\\"{x:1283,y:997,t:1528143766691};\\\", \\\"{x:1303,y:997,t:1528143766707};\\\", \\\"{x:1320,y:997,t:1528143766724};\\\", \\\"{x:1342,y:997,t:1528143766741};\\\", \\\"{x:1362,y:997,t:1528143766758};\\\", \\\"{x:1380,y:997,t:1528143766774};\\\", \\\"{x:1401,y:993,t:1528143766792};\\\", \\\"{x:1421,y:991,t:1528143766808};\\\", \\\"{x:1445,y:989,t:1528143766823};\\\", \\\"{x:1466,y:989,t:1528143766841};\\\", \\\"{x:1493,y:989,t:1528143766858};\\\", \\\"{x:1518,y:989,t:1528143766874};\\\", \\\"{x:1542,y:989,t:1528143766891};\\\", \\\"{x:1562,y:989,t:1528143766908};\\\", \\\"{x:1585,y:989,t:1528143766924};\\\", \\\"{x:1608,y:989,t:1528143766940};\\\", \\\"{x:1625,y:989,t:1528143766958};\\\", \\\"{x:1641,y:988,t:1528143766974};\\\", \\\"{x:1653,y:988,t:1528143766991};\\\", \\\"{x:1659,y:986,t:1528143767008};\\\", \\\"{x:1665,y:986,t:1528143767024};\\\", \\\"{x:1671,y:986,t:1528143767041};\\\", \\\"{x:1674,y:986,t:1528143767058};\\\", \\\"{x:1680,y:986,t:1528143767074};\\\", \\\"{x:1684,y:984,t:1528143767091};\\\", \\\"{x:1685,y:984,t:1528143767109};\\\", \\\"{x:1686,y:984,t:1528143767124};\\\", \\\"{x:1687,y:983,t:1528143767141};\\\", \\\"{x:1688,y:983,t:1528143767158};\\\", \\\"{x:1689,y:983,t:1528143767203};\\\", \\\"{x:1691,y:983,t:1528143767234};\\\", \\\"{x:1691,y:982,t:1528143767242};\\\", \\\"{x:1692,y:981,t:1528143767267};\\\", \\\"{x:1692,y:980,t:1528143767323};\\\", \\\"{x:1692,y:979,t:1528143767331};\\\", \\\"{x:1692,y:978,t:1528143767341};\\\", \\\"{x:1691,y:978,t:1528143767603};\\\", \\\"{x:1690,y:978,t:1528143767612};\\\", \\\"{x:1689,y:979,t:1528143767627};\\\", \\\"{x:1689,y:982,t:1528143767641};\\\", \\\"{x:1687,y:989,t:1528143767659};\\\", \\\"{x:1683,y:1001,t:1528143767675};\\\", \\\"{x:1680,y:1009,t:1528143767692};\\\", \\\"{x:1679,y:1018,t:1528143767709};\\\", \\\"{x:1678,y:1026,t:1528143767725};\\\", \\\"{x:1678,y:1029,t:1528143767742};\\\", \\\"{x:1678,y:1030,t:1528143767759};\\\", \\\"{x:1677,y:1030,t:1528143767852};\\\", \\\"{x:1676,y:1030,t:1528143767859};\\\", \\\"{x:1675,y:1030,t:1528143767876};\\\", \\\"{x:1673,y:1027,t:1528143778699};\\\", \\\"{x:1673,y:861,t:1528143778715};\\\", \\\"{x:1642,y:446,t:1528143778731};\\\", \\\"{x:1489,y:0,t:1528143778748};\\\", \\\"{x:1299,y:0,t:1528143778765};\\\", \\\"{x:1105,y:0,t:1528143778781};\\\", \\\"{x:918,y:0,t:1528143778799};\\\", \\\"{x:748,y:0,t:1528143778815};\\\", \\\"{x:629,y:0,t:1528143778831};\\\", \\\"{x:565,y:0,t:1528143778848};\\\", \\\"{x:557,y:0,t:1528143778864};\\\", \\\"{x:631,y:0,t:1528143778880};\\\", \\\"{x:762,y:0,t:1528143778897};\\\", \\\"{x:1004,y:0,t:1528143778914};\\\", \\\"{x:1183,y:0,t:1528143778931};\\\", \\\"{x:1370,y:0,t:1528143778947};\\\", \\\"{x:1519,y:0,t:1528143778964};\\\", \\\"{x:1628,y:0,t:1528143778981};\\\", \\\"{x:1694,y:0,t:1528143778997};\\\", \\\"{x:1717,y:0,t:1528143779014};\\\", \\\"{x:1720,y:0,t:1528143779030};\\\", \\\"{x:1719,y:5,t:1528143779066};\\\", \\\"{x:1709,y:28,t:1528143779081};\\\", \\\"{x:1669,y:145,t:1528143779098};\\\", \\\"{x:1617,y:421,t:1528143779115};\\\", \\\"{x:1594,y:644,t:1528143779131};\\\", \\\"{x:1589,y:882,t:1528143779148};\\\", \\\"{x:1598,y:1117,t:1528143779165};\\\", \\\"{x:1600,y:1199,t:1528143779183};\\\", \\\"{x:1601,y:1199,t:1528143779197};\\\", \\\"{x:1579,y:1199,t:1528143779220};\\\", \\\"{x:1560,y:1199,t:1528143779236};\\\", \\\"{x:1550,y:1199,t:1528143779253};\\\", \\\"{x:1545,y:1199,t:1528143779271};\\\", \\\"{x:1544,y:1199,t:1528143779287};\\\", \\\"{x:1540,y:1198,t:1528143779303};\\\", \\\"{x:1526,y:1185,t:1528143779320};\\\", \\\"{x:1481,y:1124,t:1528143779337};\\\", \\\"{x:1410,y:1003,t:1528143779354};\\\", \\\"{x:1290,y:753,t:1528143779370};\\\", \\\"{x:1235,y:610,t:1528143779387};\\\", \\\"{x:1205,y:492,t:1528143779404};\\\", \\\"{x:1180,y:401,t:1528143779420};\\\", \\\"{x:1174,y:373,t:1528143779437};\\\", \\\"{x:1174,y:372,t:1528143779454};\\\", \\\"{x:1174,y:371,t:1528143779483};\\\", \\\"{x:1175,y:371,t:1528143779499};\\\", \\\"{x:1176,y:371,t:1528143779506};\\\", \\\"{x:1178,y:371,t:1528143779538};\\\", \\\"{x:1182,y:375,t:1528143779554};\\\", \\\"{x:1216,y:421,t:1528143779571};\\\", \\\"{x:1247,y:478,t:1528143779587};\\\", \\\"{x:1271,y:526,t:1528143779603};\\\", \\\"{x:1297,y:570,t:1528143779621};\\\", \\\"{x:1327,y:612,t:1528143779637};\\\", \\\"{x:1354,y:645,t:1528143779654};\\\", \\\"{x:1375,y:669,t:1528143779671};\\\", \\\"{x:1386,y:684,t:1528143779689};\\\", \\\"{x:1389,y:688,t:1528143779704};\\\", \\\"{x:1389,y:682,t:1528143779788};\\\", \\\"{x:1386,y:663,t:1528143779804};\\\", \\\"{x:1386,y:653,t:1528143779821};\\\", \\\"{x:1386,y:652,t:1528143779838};\\\", \\\"{x:1384,y:650,t:1528143779900};\\\", \\\"{x:1383,y:650,t:1528143779907};\\\", \\\"{x:1380,y:650,t:1528143779931};\\\", \\\"{x:1376,y:653,t:1528143779939};\\\", \\\"{x:1373,y:658,t:1528143779954};\\\", \\\"{x:1364,y:668,t:1528143779971};\\\", \\\"{x:1360,y:671,t:1528143779988};\\\", \\\"{x:1356,y:674,t:1528143780005};\\\", \\\"{x:1354,y:678,t:1528143780021};\\\", \\\"{x:1351,y:681,t:1528143780038};\\\", \\\"{x:1349,y:684,t:1528143780055};\\\", \\\"{x:1347,y:687,t:1528143780071};\\\", \\\"{x:1346,y:691,t:1528143780088};\\\", \\\"{x:1345,y:694,t:1528143780106};\\\", \\\"{x:1344,y:698,t:1528143780121};\\\", \\\"{x:1343,y:704,t:1528143780139};\\\", \\\"{x:1340,y:709,t:1528143780155};\\\", \\\"{x:1339,y:711,t:1528143780171};\\\", \\\"{x:1339,y:712,t:1528143780203};\\\", \\\"{x:1338,y:713,t:1528143780228};\\\", \\\"{x:1338,y:712,t:1528143780491};\\\", \\\"{x:1341,y:708,t:1528143780505};\\\", \\\"{x:1347,y:703,t:1528143780522};\\\", \\\"{x:1350,y:698,t:1528143780538};\\\", \\\"{x:1354,y:692,t:1528143780556};\\\", \\\"{x:1356,y:690,t:1528143780572};\\\", \\\"{x:1357,y:689,t:1528143780588};\\\", \\\"{x:1358,y:689,t:1528143780605};\\\", \\\"{x:1358,y:688,t:1528143780635};\\\", \\\"{x:1359,y:687,t:1528143780643};\\\", \\\"{x:1360,y:685,t:1528143780655};\\\", \\\"{x:1363,y:680,t:1528143780672};\\\", \\\"{x:1367,y:676,t:1528143780688};\\\", \\\"{x:1372,y:671,t:1528143780705};\\\", \\\"{x:1380,y:659,t:1528143780723};\\\", \\\"{x:1389,y:646,t:1528143780738};\\\", \\\"{x:1404,y:621,t:1528143780756};\\\", \\\"{x:1411,y:603,t:1528143780772};\\\", \\\"{x:1420,y:586,t:1528143780789};\\\", \\\"{x:1426,y:577,t:1528143780805};\\\", \\\"{x:1427,y:574,t:1528143780822};\\\", \\\"{x:1428,y:573,t:1528143780838};\\\", \\\"{x:1426,y:573,t:1528143781042};\\\", \\\"{x:1425,y:572,t:1528143781055};\\\", \\\"{x:1424,y:571,t:1528143781071};\\\", \\\"{x:1422,y:568,t:1528143781088};\\\", \\\"{x:1421,y:568,t:1528143781104};\\\", \\\"{x:1421,y:567,t:1528143781139};\\\", \\\"{x:1422,y:567,t:1528143781235};\\\", \\\"{x:1423,y:567,t:1528143781243};\\\", \\\"{x:1423,y:568,t:1528143781255};\\\", \\\"{x:1425,y:570,t:1528143781273};\\\", \\\"{x:1425,y:573,t:1528143781289};\\\", \\\"{x:1429,y:581,t:1528143781305};\\\", \\\"{x:1434,y:593,t:1528143781323};\\\", \\\"{x:1441,y:610,t:1528143781339};\\\", \\\"{x:1449,y:623,t:1528143781356};\\\", \\\"{x:1457,y:638,t:1528143781373};\\\", \\\"{x:1467,y:654,t:1528143781390};\\\", \\\"{x:1473,y:665,t:1528143781407};\\\", \\\"{x:1482,y:680,t:1528143781423};\\\", \\\"{x:1489,y:694,t:1528143781439};\\\", \\\"{x:1499,y:710,t:1528143781456};\\\", \\\"{x:1508,y:726,t:1528143781472};\\\", \\\"{x:1520,y:746,t:1528143781489};\\\", \\\"{x:1530,y:762,t:1528143781507};\\\", \\\"{x:1541,y:779,t:1528143781523};\\\", \\\"{x:1553,y:801,t:1528143781539};\\\", \\\"{x:1561,y:815,t:1528143781557};\\\", \\\"{x:1566,y:825,t:1528143781572};\\\", \\\"{x:1569,y:834,t:1528143781589};\\\", \\\"{x:1574,y:845,t:1528143781607};\\\", \\\"{x:1581,y:861,t:1528143781623};\\\", \\\"{x:1586,y:877,t:1528143781640};\\\", \\\"{x:1593,y:894,t:1528143781657};\\\", \\\"{x:1598,y:915,t:1528143781672};\\\", \\\"{x:1604,y:935,t:1528143781690};\\\", \\\"{x:1609,y:948,t:1528143781707};\\\", \\\"{x:1615,y:964,t:1528143781722};\\\", \\\"{x:1623,y:984,t:1528143781739};\\\", \\\"{x:1625,y:993,t:1528143781757};\\\", \\\"{x:1629,y:1003,t:1528143781773};\\\", \\\"{x:1630,y:1008,t:1528143781789};\\\", \\\"{x:1630,y:1010,t:1528143781806};\\\", \\\"{x:1630,y:1011,t:1528143781822};\\\", \\\"{x:1630,y:1012,t:1528143781839};\\\", \\\"{x:1630,y:1009,t:1528143782044};\\\", \\\"{x:1630,y:1002,t:1528143782056};\\\", \\\"{x:1626,y:989,t:1528143782073};\\\", \\\"{x:1624,y:980,t:1528143782090};\\\", \\\"{x:1619,y:969,t:1528143782106};\\\", \\\"{x:1613,y:954,t:1528143782124};\\\", \\\"{x:1607,y:943,t:1528143782139};\\\", \\\"{x:1603,y:935,t:1528143782156};\\\", \\\"{x:1599,y:929,t:1528143782173};\\\", \\\"{x:1595,y:921,t:1528143782189};\\\", \\\"{x:1589,y:913,t:1528143782207};\\\", \\\"{x:1583,y:899,t:1528143782224};\\\", \\\"{x:1576,y:889,t:1528143782240};\\\", \\\"{x:1569,y:878,t:1528143782256};\\\", \\\"{x:1559,y:864,t:1528143782274};\\\", \\\"{x:1553,y:854,t:1528143782290};\\\", \\\"{x:1543,y:842,t:1528143782307};\\\", \\\"{x:1534,y:824,t:1528143782323};\\\", \\\"{x:1532,y:814,t:1528143782341};\\\", \\\"{x:1529,y:804,t:1528143782356};\\\", \\\"{x:1525,y:795,t:1528143782374};\\\", \\\"{x:1523,y:791,t:1528143782390};\\\", \\\"{x:1521,y:786,t:1528143782406};\\\", \\\"{x:1521,y:784,t:1528143782424};\\\", \\\"{x:1521,y:779,t:1528143782441};\\\", \\\"{x:1521,y:773,t:1528143782456};\\\", \\\"{x:1521,y:768,t:1528143782474};\\\", \\\"{x:1521,y:763,t:1528143782491};\\\", \\\"{x:1521,y:761,t:1528143782507};\\\", \\\"{x:1520,y:761,t:1528143782523};\\\", \\\"{x:1521,y:761,t:1528143782675};\\\", \\\"{x:1523,y:761,t:1528143782691};\\\", \\\"{x:1526,y:769,t:1528143782707};\\\", \\\"{x:1532,y:783,t:1528143782723};\\\", \\\"{x:1534,y:789,t:1528143782740};\\\", \\\"{x:1536,y:798,t:1528143782757};\\\", \\\"{x:1540,y:811,t:1528143782773};\\\", \\\"{x:1544,y:820,t:1528143782790};\\\", \\\"{x:1546,y:830,t:1528143782808};\\\", \\\"{x:1551,y:845,t:1528143782824};\\\", \\\"{x:1555,y:859,t:1528143782840};\\\", \\\"{x:1559,y:872,t:1528143782857};\\\", \\\"{x:1564,y:887,t:1528143782874};\\\", \\\"{x:1570,y:899,t:1528143782890};\\\", \\\"{x:1579,y:921,t:1528143782907};\\\", \\\"{x:1585,y:933,t:1528143782923};\\\", \\\"{x:1586,y:939,t:1528143782940};\\\", \\\"{x:1590,y:946,t:1528143782958};\\\", \\\"{x:1593,y:953,t:1528143782973};\\\", \\\"{x:1595,y:957,t:1528143782990};\\\", \\\"{x:1597,y:962,t:1528143783007};\\\", \\\"{x:1599,y:966,t:1528143783023};\\\", \\\"{x:1601,y:970,t:1528143783041};\\\", \\\"{x:1602,y:972,t:1528143783057};\\\", \\\"{x:1604,y:974,t:1528143783073};\\\", \\\"{x:1606,y:977,t:1528143783090};\\\", \\\"{x:1614,y:985,t:1528143783108};\\\", \\\"{x:1615,y:986,t:1528143783123};\\\", \\\"{x:1616,y:986,t:1528143783251};\\\", \\\"{x:1616,y:983,t:1528143783259};\\\", \\\"{x:1616,y:980,t:1528143783274};\\\", \\\"{x:1617,y:977,t:1528143783290};\\\", \\\"{x:1617,y:970,t:1528143783307};\\\", \\\"{x:1617,y:969,t:1528143783324};\\\", \\\"{x:1617,y:967,t:1528143783341};\\\", \\\"{x:1616,y:962,t:1528143784411};\\\", \\\"{x:1613,y:953,t:1528143784425};\\\", \\\"{x:1603,y:935,t:1528143784442};\\\", \\\"{x:1591,y:911,t:1528143784458};\\\", \\\"{x:1554,y:856,t:1528143784475};\\\", \\\"{x:1525,y:818,t:1528143784491};\\\", \\\"{x:1505,y:792,t:1528143784508};\\\", \\\"{x:1485,y:764,t:1528143784526};\\\", \\\"{x:1469,y:736,t:1528143784541};\\\", \\\"{x:1457,y:717,t:1528143784558};\\\", \\\"{x:1451,y:701,t:1528143784575};\\\", \\\"{x:1445,y:688,t:1528143784592};\\\", \\\"{x:1439,y:676,t:1528143784608};\\\", \\\"{x:1433,y:664,t:1528143784625};\\\", \\\"{x:1431,y:658,t:1528143784641};\\\", \\\"{x:1429,y:654,t:1528143784658};\\\", \\\"{x:1428,y:649,t:1528143784675};\\\", \\\"{x:1428,y:648,t:1528143784692};\\\", \\\"{x:1428,y:647,t:1528143784715};\\\", \\\"{x:1428,y:646,t:1528143784731};\\\", \\\"{x:1428,y:644,t:1528143784747};\\\", \\\"{x:1428,y:642,t:1528143784763};\\\", \\\"{x:1428,y:641,t:1528143784775};\\\", \\\"{x:1428,y:635,t:1528143784791};\\\", \\\"{x:1428,y:631,t:1528143784808};\\\", \\\"{x:1427,y:626,t:1528143784826};\\\", \\\"{x:1427,y:623,t:1528143784841};\\\", \\\"{x:1427,y:619,t:1528143784859};\\\", \\\"{x:1427,y:613,t:1528143784875};\\\", \\\"{x:1427,y:609,t:1528143784891};\\\", \\\"{x:1427,y:608,t:1528143784909};\\\", \\\"{x:1427,y:606,t:1528143784926};\\\", \\\"{x:1428,y:606,t:1528143784948};\\\", \\\"{x:1432,y:607,t:1528143784963};\\\", \\\"{x:1434,y:608,t:1528143784976};\\\", \\\"{x:1437,y:609,t:1528143784992};\\\", \\\"{x:1444,y:617,t:1528143785008};\\\", \\\"{x:1448,y:631,t:1528143785026};\\\", \\\"{x:1453,y:647,t:1528143785043};\\\", \\\"{x:1459,y:665,t:1528143785059};\\\", \\\"{x:1470,y:703,t:1528143785075};\\\", \\\"{x:1481,y:732,t:1528143785093};\\\", \\\"{x:1487,y:756,t:1528143785108};\\\", \\\"{x:1496,y:776,t:1528143785125};\\\", \\\"{x:1501,y:786,t:1528143785143};\\\", \\\"{x:1503,y:791,t:1528143785159};\\\", \\\"{x:1503,y:793,t:1528143785175};\\\", \\\"{x:1506,y:798,t:1528143785193};\\\", \\\"{x:1510,y:807,t:1528143785208};\\\", \\\"{x:1515,y:822,t:1528143785225};\\\", \\\"{x:1519,y:829,t:1528143785241};\\\", \\\"{x:1519,y:832,t:1528143785258};\\\", \\\"{x:1521,y:837,t:1528143785275};\\\", \\\"{x:1525,y:843,t:1528143785291};\\\", \\\"{x:1529,y:850,t:1528143785308};\\\", \\\"{x:1534,y:858,t:1528143785325};\\\", \\\"{x:1540,y:865,t:1528143785342};\\\", \\\"{x:1546,y:872,t:1528143785358};\\\", \\\"{x:1552,y:881,t:1528143785375};\\\", \\\"{x:1556,y:885,t:1528143785392};\\\", \\\"{x:1562,y:892,t:1528143785408};\\\", \\\"{x:1568,y:899,t:1528143785425};\\\", \\\"{x:1577,y:908,t:1528143785442};\\\", \\\"{x:1588,y:918,t:1528143785458};\\\", \\\"{x:1593,y:922,t:1528143785476};\\\", \\\"{x:1596,y:925,t:1528143785492};\\\", \\\"{x:1598,y:927,t:1528143785510};\\\", \\\"{x:1601,y:929,t:1528143785525};\\\", \\\"{x:1606,y:934,t:1528143785542};\\\", \\\"{x:1615,y:943,t:1528143785559};\\\", \\\"{x:1625,y:953,t:1528143785575};\\\", \\\"{x:1638,y:962,t:1528143785592};\\\", \\\"{x:1648,y:969,t:1528143785609};\\\", \\\"{x:1654,y:973,t:1528143785625};\\\", \\\"{x:1658,y:976,t:1528143785642};\\\", \\\"{x:1659,y:976,t:1528143785883};\\\", \\\"{x:1659,y:975,t:1528143786028};\\\", \\\"{x:1659,y:973,t:1528143786043};\\\", \\\"{x:1656,y:966,t:1528143786059};\\\", \\\"{x:1653,y:960,t:1528143786076};\\\", \\\"{x:1648,y:952,t:1528143786092};\\\", \\\"{x:1644,y:945,t:1528143786110};\\\", \\\"{x:1640,y:937,t:1528143786126};\\\", \\\"{x:1636,y:932,t:1528143786142};\\\", \\\"{x:1631,y:922,t:1528143786159};\\\", \\\"{x:1626,y:910,t:1528143786176};\\\", \\\"{x:1619,y:897,t:1528143786192};\\\", \\\"{x:1611,y:881,t:1528143786209};\\\", \\\"{x:1605,y:863,t:1528143786226};\\\", \\\"{x:1593,y:842,t:1528143786243};\\\", \\\"{x:1588,y:833,t:1528143786259};\\\", \\\"{x:1582,y:822,t:1528143786277};\\\", \\\"{x:1575,y:809,t:1528143786293};\\\", \\\"{x:1569,y:795,t:1528143786310};\\\", \\\"{x:1562,y:781,t:1528143786327};\\\", \\\"{x:1551,y:766,t:1528143786343};\\\", \\\"{x:1540,y:752,t:1528143786359};\\\", \\\"{x:1531,y:738,t:1528143786377};\\\", \\\"{x:1526,y:731,t:1528143786394};\\\", \\\"{x:1523,y:726,t:1528143786410};\\\", \\\"{x:1522,y:723,t:1528143786426};\\\", \\\"{x:1519,y:718,t:1528143786443};\\\", \\\"{x:1518,y:714,t:1528143786460};\\\", \\\"{x:1515,y:707,t:1528143786477};\\\", \\\"{x:1511,y:701,t:1528143786494};\\\", \\\"{x:1506,y:691,t:1528143786510};\\\", \\\"{x:1500,y:679,t:1528143786527};\\\", \\\"{x:1494,y:672,t:1528143786544};\\\", \\\"{x:1488,y:663,t:1528143786560};\\\", \\\"{x:1481,y:656,t:1528143786576};\\\", \\\"{x:1474,y:647,t:1528143786593};\\\", \\\"{x:1465,y:640,t:1528143786609};\\\", \\\"{x:1453,y:631,t:1528143786627};\\\", \\\"{x:1448,y:627,t:1528143786643};\\\", \\\"{x:1446,y:626,t:1528143786660};\\\", \\\"{x:1445,y:625,t:1528143786677};\\\", \\\"{x:1443,y:623,t:1528143786694};\\\", \\\"{x:1444,y:623,t:1528143786907};\\\", \\\"{x:1444,y:624,t:1528143786923};\\\", \\\"{x:1444,y:627,t:1528143786932};\\\", \\\"{x:1444,y:629,t:1528143786943};\\\", \\\"{x:1445,y:631,t:1528143786960};\\\", \\\"{x:1445,y:632,t:1528143787219};\\\", \\\"{x:1445,y:633,t:1528143787235};\\\", \\\"{x:1445,y:635,t:1528143787243};\\\", \\\"{x:1445,y:641,t:1528143787261};\\\", \\\"{x:1447,y:646,t:1528143787277};\\\", \\\"{x:1448,y:651,t:1528143787294};\\\", \\\"{x:1449,y:656,t:1528143787311};\\\", \\\"{x:1451,y:661,t:1528143787327};\\\", \\\"{x:1453,y:664,t:1528143787344};\\\", \\\"{x:1458,y:669,t:1528143787361};\\\", \\\"{x:1463,y:674,t:1528143787377};\\\", \\\"{x:1473,y:682,t:1528143787394};\\\", \\\"{x:1482,y:689,t:1528143787411};\\\", \\\"{x:1495,y:701,t:1528143787427};\\\", \\\"{x:1509,y:714,t:1528143787444};\\\", \\\"{x:1521,y:728,t:1528143787461};\\\", \\\"{x:1533,y:746,t:1528143787478};\\\", \\\"{x:1545,y:762,t:1528143787493};\\\", \\\"{x:1555,y:778,t:1528143787511};\\\", \\\"{x:1564,y:791,t:1528143787527};\\\", \\\"{x:1573,y:803,t:1528143787544};\\\", \\\"{x:1582,y:819,t:1528143787561};\\\", \\\"{x:1591,y:834,t:1528143787577};\\\", \\\"{x:1602,y:852,t:1528143787593};\\\", \\\"{x:1610,y:864,t:1528143787611};\\\", \\\"{x:1619,y:884,t:1528143787627};\\\", \\\"{x:1623,y:894,t:1528143787644};\\\", \\\"{x:1628,y:903,t:1528143787661};\\\", \\\"{x:1633,y:912,t:1528143787678};\\\", \\\"{x:1637,y:920,t:1528143787695};\\\", \\\"{x:1643,y:927,t:1528143787711};\\\", \\\"{x:1647,y:933,t:1528143787727};\\\", \\\"{x:1653,y:941,t:1528143787745};\\\", \\\"{x:1657,y:948,t:1528143787760};\\\", \\\"{x:1661,y:955,t:1528143787778};\\\", \\\"{x:1664,y:960,t:1528143787794};\\\", \\\"{x:1666,y:962,t:1528143787810};\\\", \\\"{x:1667,y:962,t:1528143787866};\\\", \\\"{x:1668,y:962,t:1528143787877};\\\", \\\"{x:1679,y:960,t:1528143787894};\\\", \\\"{x:1696,y:956,t:1528143787910};\\\", \\\"{x:1714,y:955,t:1528143787927};\\\", \\\"{x:1730,y:953,t:1528143787944};\\\", \\\"{x:1743,y:951,t:1528143787960};\\\", \\\"{x:1757,y:948,t:1528143787977};\\\", \\\"{x:1772,y:945,t:1528143787994};\\\", \\\"{x:1791,y:938,t:1528143788011};\\\", \\\"{x:1801,y:933,t:1528143788027};\\\", \\\"{x:1807,y:931,t:1528143788044};\\\", \\\"{x:1807,y:930,t:1528143788066};\\\", \\\"{x:1807,y:929,t:1528143788091};\\\", \\\"{x:1807,y:926,t:1528143788099};\\\", \\\"{x:1807,y:925,t:1528143788111};\\\", \\\"{x:1807,y:922,t:1528143788127};\\\", \\\"{x:1807,y:921,t:1528143788163};\\\", \\\"{x:1806,y:920,t:1528143788177};\\\", \\\"{x:1801,y:918,t:1528143788195};\\\", \\\"{x:1796,y:917,t:1528143788210};\\\", \\\"{x:1792,y:914,t:1528143788227};\\\", \\\"{x:1787,y:913,t:1528143788243};\\\", \\\"{x:1781,y:910,t:1528143788261};\\\", \\\"{x:1772,y:909,t:1528143788277};\\\", \\\"{x:1763,y:906,t:1528143788294};\\\", \\\"{x:1750,y:903,t:1528143788311};\\\", \\\"{x:1740,y:902,t:1528143788327};\\\", \\\"{x:1734,y:900,t:1528143788343};\\\", \\\"{x:1726,y:898,t:1528143788361};\\\", \\\"{x:1718,y:895,t:1528143788377};\\\", \\\"{x:1710,y:889,t:1528143788394};\\\", \\\"{x:1704,y:885,t:1528143788411};\\\", \\\"{x:1703,y:884,t:1528143788427};\\\", \\\"{x:1700,y:881,t:1528143788444};\\\", \\\"{x:1698,y:877,t:1528143788461};\\\", \\\"{x:1693,y:869,t:1528143788477};\\\", \\\"{x:1690,y:860,t:1528143788495};\\\", \\\"{x:1685,y:850,t:1528143788511};\\\", \\\"{x:1683,y:847,t:1528143788527};\\\", \\\"{x:1680,y:843,t:1528143788544};\\\", \\\"{x:1678,y:841,t:1528143788561};\\\", \\\"{x:1678,y:840,t:1528143788578};\\\", \\\"{x:1677,y:840,t:1528143788683};\\\", \\\"{x:1677,y:832,t:1528143789276};\\\", \\\"{x:1670,y:791,t:1528143789297};\\\", \\\"{x:1657,y:746,t:1528143789312};\\\", \\\"{x:1643,y:678,t:1528143789329};\\\", \\\"{x:1628,y:597,t:1528143789346};\\\", \\\"{x:1607,y:461,t:1528143789362};\\\", \\\"{x:1588,y:281,t:1528143789378};\\\", \\\"{x:1588,y:246,t:1528143789396};\\\", \\\"{x:1588,y:228,t:1528143789412};\\\", \\\"{x:1588,y:211,t:1528143789429};\\\", \\\"{x:1588,y:197,t:1528143789446};\\\", \\\"{x:1588,y:192,t:1528143789462};\\\", \\\"{x:1588,y:189,t:1528143789479};\\\", \\\"{x:1588,y:198,t:1528143789555};\\\", \\\"{x:1582,y:213,t:1528143789562};\\\", \\\"{x:1562,y:257,t:1528143789580};\\\", \\\"{x:1535,y:303,t:1528143789595};\\\", \\\"{x:1518,y:340,t:1528143789613};\\\", \\\"{x:1498,y:387,t:1528143789629};\\\", \\\"{x:1469,y:448,t:1528143789646};\\\", \\\"{x:1431,y:516,t:1528143789663};\\\", \\\"{x:1405,y:571,t:1528143789679};\\\", \\\"{x:1389,y:622,t:1528143789696};\\\", \\\"{x:1373,y:678,t:1528143789712};\\\", \\\"{x:1357,y:734,t:1528143789729};\\\", \\\"{x:1345,y:773,t:1528143789746};\\\", \\\"{x:1325,y:828,t:1528143789763};\\\", \\\"{x:1311,y:859,t:1528143789779};\\\", \\\"{x:1303,y:879,t:1528143789795};\\\", \\\"{x:1299,y:896,t:1528143789813};\\\", \\\"{x:1294,y:909,t:1528143789830};\\\", \\\"{x:1293,y:919,t:1528143789846};\\\", \\\"{x:1291,y:928,t:1528143789863};\\\", \\\"{x:1290,y:938,t:1528143789879};\\\", \\\"{x:1289,y:946,t:1528143789896};\\\", \\\"{x:1288,y:952,t:1528143789913};\\\", \\\"{x:1287,y:957,t:1528143789930};\\\", \\\"{x:1286,y:960,t:1528143789946};\\\", \\\"{x:1286,y:961,t:1528143789962};\\\", \\\"{x:1286,y:960,t:1528143790139};\\\", \\\"{x:1286,y:952,t:1528143790148};\\\", \\\"{x:1297,y:933,t:1528143790163};\\\", \\\"{x:1309,y:912,t:1528143790180};\\\", \\\"{x:1323,y:888,t:1528143790197};\\\", \\\"{x:1338,y:868,t:1528143790212};\\\", \\\"{x:1348,y:857,t:1528143790229};\\\", \\\"{x:1359,y:850,t:1528143790246};\\\", \\\"{x:1370,y:844,t:1528143790262};\\\", \\\"{x:1375,y:841,t:1528143790279};\\\", \\\"{x:1377,y:839,t:1528143790296};\\\", \\\"{x:1378,y:838,t:1528143790312};\\\", \\\"{x:1380,y:836,t:1528143790329};\\\", \\\"{x:1381,y:834,t:1528143790346};\\\", \\\"{x:1381,y:833,t:1528143790362};\\\", \\\"{x:1382,y:832,t:1528143790379};\\\", \\\"{x:1382,y:831,t:1528143790531};\\\", \\\"{x:1373,y:833,t:1528143790547};\\\", \\\"{x:1361,y:839,t:1528143790563};\\\", \\\"{x:1349,y:845,t:1528143790580};\\\", \\\"{x:1335,y:852,t:1528143790598};\\\", \\\"{x:1322,y:859,t:1528143790613};\\\", \\\"{x:1310,y:863,t:1528143790630};\\\", \\\"{x:1305,y:865,t:1528143790646};\\\", \\\"{x:1301,y:868,t:1528143790663};\\\", \\\"{x:1297,y:870,t:1528143790680};\\\", \\\"{x:1294,y:873,t:1528143790697};\\\", \\\"{x:1293,y:874,t:1528143790713};\\\", \\\"{x:1291,y:877,t:1528143790730};\\\", \\\"{x:1290,y:880,t:1528143790746};\\\", \\\"{x:1289,y:883,t:1528143790763};\\\", \\\"{x:1287,y:885,t:1528143790779};\\\", \\\"{x:1286,y:890,t:1528143790798};\\\", \\\"{x:1285,y:894,t:1528143790814};\\\", \\\"{x:1284,y:898,t:1528143790830};\\\", \\\"{x:1283,y:902,t:1528143790847};\\\", \\\"{x:1282,y:906,t:1528143790864};\\\", \\\"{x:1282,y:910,t:1528143790880};\\\", \\\"{x:1280,y:915,t:1528143790897};\\\", \\\"{x:1280,y:918,t:1528143790914};\\\", \\\"{x:1280,y:921,t:1528143790930};\\\", \\\"{x:1279,y:926,t:1528143790947};\\\", \\\"{x:1279,y:927,t:1528143790963};\\\", \\\"{x:1279,y:930,t:1528143790980};\\\", \\\"{x:1278,y:932,t:1528143790998};\\\", \\\"{x:1278,y:933,t:1528143791014};\\\", \\\"{x:1278,y:935,t:1528143791030};\\\", \\\"{x:1277,y:937,t:1528143791046};\\\", \\\"{x:1277,y:939,t:1528143791064};\\\", \\\"{x:1277,y:942,t:1528143791080};\\\", \\\"{x:1276,y:942,t:1528143791096};\\\", \\\"{x:1276,y:943,t:1528143791114};\\\", \\\"{x:1276,y:944,t:1528143791130};\\\", \\\"{x:1276,y:945,t:1528143791147};\\\", \\\"{x:1276,y:946,t:1528143791508};\\\", \\\"{x:1276,y:948,t:1528143791523};\\\", \\\"{x:1276,y:949,t:1528143791539};\\\", \\\"{x:1276,y:951,t:1528143791555};\\\", \\\"{x:1276,y:952,t:1528143791564};\\\", \\\"{x:1275,y:954,t:1528143791581};\\\", \\\"{x:1275,y:957,t:1528143791598};\\\", \\\"{x:1274,y:959,t:1528143791614};\\\", \\\"{x:1274,y:961,t:1528143791631};\\\", \\\"{x:1273,y:962,t:1528143791648};\\\", \\\"{x:1273,y:964,t:1528143791664};\\\", \\\"{x:1273,y:966,t:1528143791683};\\\", \\\"{x:1272,y:967,t:1528143791699};\\\", \\\"{x:1271,y:968,t:1528143791715};\\\", \\\"{x:1270,y:969,t:1528143791748};\\\", \\\"{x:1268,y:969,t:1528143791956};\\\", \\\"{x:1267,y:969,t:1528143791995};\\\", \\\"{x:1266,y:967,t:1528143792011};\\\", \\\"{x:1266,y:958,t:1528143792019};\\\", \\\"{x:1269,y:940,t:1528143792031};\\\", \\\"{x:1276,y:900,t:1528143792048};\\\", \\\"{x:1281,y:869,t:1528143792065};\\\", \\\"{x:1293,y:843,t:1528143792081};\\\", \\\"{x:1302,y:821,t:1528143792098};\\\", \\\"{x:1314,y:802,t:1528143792115};\\\", \\\"{x:1320,y:794,t:1528143792131};\\\", \\\"{x:1322,y:791,t:1528143792148};\\\", \\\"{x:1323,y:791,t:1528143792165};\\\", \\\"{x:1323,y:789,t:1528143792387};\\\", \\\"{x:1325,y:786,t:1528143792398};\\\", \\\"{x:1331,y:780,t:1528143792414};\\\", \\\"{x:1334,y:779,t:1528143792431};\\\", \\\"{x:1336,y:776,t:1528143792448};\\\", \\\"{x:1338,y:776,t:1528143792465};\\\", \\\"{x:1339,y:776,t:1528143792481};\\\", \\\"{x:1340,y:776,t:1528143792498};\\\", \\\"{x:1341,y:774,t:1528143792739};\\\", \\\"{x:1341,y:773,t:1528143792747};\\\", \\\"{x:1341,y:768,t:1528143792764};\\\", \\\"{x:1342,y:765,t:1528143792782};\\\", \\\"{x:1343,y:762,t:1528143792799};\\\", \\\"{x:1341,y:763,t:1528143792956};\\\", \\\"{x:1337,y:767,t:1528143792965};\\\", \\\"{x:1333,y:774,t:1528143792982};\\\", \\\"{x:1327,y:783,t:1528143792998};\\\", \\\"{x:1319,y:799,t:1528143793015};\\\", \\\"{x:1311,y:814,t:1528143793032};\\\", \\\"{x:1299,y:832,t:1528143793049};\\\", \\\"{x:1286,y:851,t:1528143793065};\\\", \\\"{x:1274,y:863,t:1528143793082};\\\", \\\"{x:1265,y:877,t:1528143793099};\\\", \\\"{x:1258,y:885,t:1528143793115};\\\", \\\"{x:1255,y:888,t:1528143793131};\\\", \\\"{x:1252,y:894,t:1528143793149};\\\", \\\"{x:1249,y:901,t:1528143793165};\\\", \\\"{x:1247,y:904,t:1528143793182};\\\", \\\"{x:1244,y:909,t:1528143793199};\\\", \\\"{x:1243,y:912,t:1528143793214};\\\", \\\"{x:1241,y:915,t:1528143793231};\\\", \\\"{x:1239,y:924,t:1528143793248};\\\", \\\"{x:1235,y:936,t:1528143793264};\\\", \\\"{x:1235,y:942,t:1528143793281};\\\", \\\"{x:1232,y:954,t:1528143793298};\\\", \\\"{x:1231,y:957,t:1528143793314};\\\", \\\"{x:1231,y:959,t:1528143793331};\\\", \\\"{x:1231,y:960,t:1528143793349};\\\", \\\"{x:1231,y:962,t:1528143793364};\\\", \\\"{x:1231,y:963,t:1528143793381};\\\", \\\"{x:1231,y:964,t:1528143793399};\\\", \\\"{x:1231,y:965,t:1528143793419};\\\", \\\"{x:1231,y:966,t:1528143793523};\\\", \\\"{x:1233,y:965,t:1528143793532};\\\", \\\"{x:1236,y:963,t:1528143793550};\\\", \\\"{x:1242,y:961,t:1528143793566};\\\", \\\"{x:1243,y:959,t:1528143793582};\\\", \\\"{x:1244,y:959,t:1528143793598};\\\", \\\"{x:1245,y:958,t:1528143793616};\\\", \\\"{x:1246,y:958,t:1528143793635};\\\", \\\"{x:1247,y:958,t:1528143793963};\\\", \\\"{x:1249,y:958,t:1528143794003};\\\", \\\"{x:1250,y:958,t:1528143794411};\\\", \\\"{x:1251,y:957,t:1528143794491};\\\", \\\"{x:1248,y:952,t:1528143794499};\\\", \\\"{x:1225,y:932,t:1528143794516};\\\", \\\"{x:1181,y:895,t:1528143794533};\\\", \\\"{x:1108,y:843,t:1528143794550};\\\", \\\"{x:1012,y:781,t:1528143794566};\\\", \\\"{x:897,y:713,t:1528143794583};\\\", \\\"{x:791,y:657,t:1528143794600};\\\", \\\"{x:692,y:617,t:1528143794617};\\\", \\\"{x:617,y:585,t:1528143794633};\\\", \\\"{x:558,y:566,t:1528143794650};\\\", \\\"{x:523,y:554,t:1528143794666};\\\", \\\"{x:510,y:553,t:1528143794682};\\\", \\\"{x:509,y:553,t:1528143794706};\\\", \\\"{x:509,y:554,t:1528143794722};\\\", \\\"{x:508,y:555,t:1528143794733};\\\", \\\"{x:508,y:562,t:1528143794750};\\\", \\\"{x:508,y:576,t:1528143794767};\\\", \\\"{x:508,y:591,t:1528143794783};\\\", \\\"{x:508,y:612,t:1528143794800};\\\", \\\"{x:508,y:632,t:1528143794817};\\\", \\\"{x:508,y:653,t:1528143794833};\\\", \\\"{x:513,y:676,t:1528143794849};\\\", \\\"{x:523,y:702,t:1528143794866};\\\", \\\"{x:529,y:712,t:1528143794884};\\\", \\\"{x:538,y:721,t:1528143794901};\\\", \\\"{x:539,y:723,t:1528143794916};\\\", \\\"{x:540,y:723,t:1528143794954};\\\", \\\"{x:541,y:723,t:1528143795059};\\\", \\\"{x:542,y:723,t:1528143795315};\\\", \\\"{x:542,y:721,t:1528143795322};\\\", \\\"{x:539,y:720,t:1528143795352};\\\", \\\"{x:538,y:720,t:1528143795378};\\\", \\\"{x:537,y:719,t:1528143795394};\\\", \\\"{x:535,y:719,t:1528143795458};\\\", \\\"{x:535,y:718,t:1528143795466};\\\", \\\"{x:534,y:717,t:1528143795483};\\\", \\\"{x:534,y:709,t:1528143795500};\\\", \\\"{x:538,y:696,t:1528143795516};\\\", \\\"{x:547,y:676,t:1528143795533};\\\", \\\"{x:562,y:651,t:1528143795551};\\\", \\\"{x:592,y:609,t:1528143795566};\\\", \\\"{x:630,y:553,t:1528143795583};\\\", \\\"{x:676,y:488,t:1528143795600};\\\", \\\"{x:734,y:405,t:1528143795616};\\\", \\\"{x:788,y:329,t:1528143795633};\\\", \\\"{x:853,y:247,t:1528143795651};\\\", \\\"{x:878,y:224,t:1528143795667};\\\", \\\"{x:896,y:212,t:1528143795684};\\\", \\\"{x:904,y:207,t:1528143795700};\\\", \\\"{x:906,y:206,t:1528143795718};\\\", \\\"{x:907,y:206,t:1528143795747};\\\" ] }, { \\\"rt\\\": 47144, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 525976, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"TTCWS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -08 AM-09 AM-08 AM-11 AM-11 AM-B -B -B -11 AM-E -F -F -B -E -J -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:909,y:210,t:1528143806055};\\\", \\\"{x:918,y:265,t:1528143806062};\\\", \\\"{x:966,y:449,t:1528143806078};\\\", \\\"{x:1039,y:633,t:1528143806096};\\\", \\\"{x:1148,y:804,t:1528143806111};\\\", \\\"{x:1250,y:941,t:1528143806129};\\\", \\\"{x:1340,y:1043,t:1528143806145};\\\", \\\"{x:1403,y:1119,t:1528143806162};\\\", \\\"{x:1444,y:1164,t:1528143806179};\\\", \\\"{x:1470,y:1189,t:1528143806195};\\\", \\\"{x:1487,y:1199,t:1528143806211};\\\", \\\"{x:1496,y:1199,t:1528143806229};\\\", \\\"{x:1498,y:1199,t:1528143806247};\\\", \\\"{x:1498,y:1196,t:1528143806318};\\\", \\\"{x:1498,y:1184,t:1528143806329};\\\", \\\"{x:1494,y:1155,t:1528143806346};\\\", \\\"{x:1494,y:1099,t:1528143806363};\\\", \\\"{x:1494,y:1013,t:1528143806379};\\\", \\\"{x:1502,y:911,t:1528143806396};\\\", \\\"{x:1512,y:834,t:1528143806412};\\\", \\\"{x:1530,y:732,t:1528143806459};\\\", \\\"{x:1533,y:721,t:1528143806462};\\\", \\\"{x:1542,y:698,t:1528143806479};\\\", \\\"{x:1548,y:680,t:1528143806496};\\\", \\\"{x:1552,y:658,t:1528143806511};\\\", \\\"{x:1552,y:641,t:1528143806529};\\\", \\\"{x:1552,y:625,t:1528143806546};\\\", \\\"{x:1546,y:610,t:1528143806562};\\\", \\\"{x:1543,y:606,t:1528143806579};\\\", \\\"{x:1542,y:606,t:1528143806596};\\\", \\\"{x:1538,y:604,t:1528143806612};\\\", \\\"{x:1527,y:604,t:1528143806629};\\\", \\\"{x:1516,y:609,t:1528143806645};\\\", \\\"{x:1514,y:621,t:1528143806662};\\\", \\\"{x:1512,y:643,t:1528143806680};\\\", \\\"{x:1512,y:686,t:1528143806697};\\\", \\\"{x:1512,y:739,t:1528143806712};\\\", \\\"{x:1512,y:773,t:1528143806729};\\\", \\\"{x:1512,y:798,t:1528143806747};\\\", \\\"{x:1514,y:818,t:1528143806763};\\\", \\\"{x:1520,y:838,t:1528143806779};\\\", \\\"{x:1528,y:853,t:1528143806796};\\\", \\\"{x:1538,y:867,t:1528143806814};\\\", \\\"{x:1542,y:871,t:1528143806830};\\\", \\\"{x:1546,y:874,t:1528143806846};\\\", \\\"{x:1548,y:876,t:1528143806863};\\\", \\\"{x:1549,y:876,t:1528143806880};\\\", \\\"{x:1550,y:876,t:1528143806950};\\\", \\\"{x:1550,y:875,t:1528143806963};\\\", \\\"{x:1551,y:862,t:1528143806980};\\\", \\\"{x:1551,y:842,t:1528143806997};\\\", \\\"{x:1538,y:819,t:1528143807014};\\\", \\\"{x:1530,y:809,t:1528143807030};\\\", \\\"{x:1526,y:805,t:1528143807047};\\\", \\\"{x:1521,y:802,t:1528143807064};\\\", \\\"{x:1520,y:802,t:1528143807079};\\\", \\\"{x:1518,y:801,t:1528143807135};\\\", \\\"{x:1517,y:801,t:1528143807147};\\\", \\\"{x:1514,y:799,t:1528143807164};\\\", \\\"{x:1510,y:797,t:1528143807180};\\\", \\\"{x:1502,y:794,t:1528143807197};\\\", \\\"{x:1488,y:788,t:1528143807214};\\\", \\\"{x:1474,y:785,t:1528143807230};\\\", \\\"{x:1458,y:783,t:1528143807246};\\\", \\\"{x:1443,y:781,t:1528143807264};\\\", \\\"{x:1425,y:781,t:1528143807281};\\\", \\\"{x:1403,y:781,t:1528143807297};\\\", \\\"{x:1382,y:781,t:1528143807313};\\\", \\\"{x:1363,y:781,t:1528143807331};\\\", \\\"{x:1345,y:782,t:1528143807347};\\\", \\\"{x:1328,y:785,t:1528143807364};\\\", \\\"{x:1314,y:786,t:1528143807380};\\\", \\\"{x:1300,y:787,t:1528143807396};\\\", \\\"{x:1288,y:791,t:1528143807413};\\\", \\\"{x:1285,y:791,t:1528143807430};\\\", \\\"{x:1283,y:792,t:1528143807447};\\\", \\\"{x:1280,y:794,t:1528143807463};\\\", \\\"{x:1276,y:797,t:1528143807481};\\\", \\\"{x:1273,y:799,t:1528143807497};\\\", \\\"{x:1269,y:800,t:1528143807514};\\\", \\\"{x:1269,y:801,t:1528143807531};\\\", \\\"{x:1268,y:801,t:1528143807550};\\\", \\\"{x:1266,y:802,t:1528143807574};\\\", \\\"{x:1265,y:802,t:1528143807590};\\\", \\\"{x:1264,y:803,t:1528143807598};\\\", \\\"{x:1262,y:804,t:1528143807614};\\\", \\\"{x:1260,y:806,t:1528143807631};\\\", \\\"{x:1257,y:808,t:1528143807646};\\\", \\\"{x:1256,y:810,t:1528143807663};\\\", \\\"{x:1255,y:812,t:1528143807681};\\\", \\\"{x:1254,y:815,t:1528143807698};\\\", \\\"{x:1253,y:819,t:1528143807714};\\\", \\\"{x:1252,y:825,t:1528143807730};\\\", \\\"{x:1251,y:830,t:1528143807748};\\\", \\\"{x:1251,y:838,t:1528143807764};\\\", \\\"{x:1251,y:841,t:1528143807780};\\\", \\\"{x:1249,y:846,t:1528143807798};\\\", \\\"{x:1249,y:848,t:1528143807814};\\\", \\\"{x:1248,y:849,t:1528143807846};\\\", \\\"{x:1247,y:851,t:1528143807854};\\\", \\\"{x:1245,y:852,t:1528143807864};\\\", \\\"{x:1242,y:852,t:1528143807881};\\\", \\\"{x:1241,y:853,t:1528143807897};\\\", \\\"{x:1239,y:853,t:1528143807914};\\\", \\\"{x:1237,y:853,t:1528143808006};\\\", \\\"{x:1236,y:852,t:1528143808014};\\\", \\\"{x:1234,y:850,t:1528143808031};\\\", \\\"{x:1232,y:849,t:1528143808048};\\\", \\\"{x:1231,y:848,t:1528143808064};\\\", \\\"{x:1230,y:848,t:1528143808080};\\\", \\\"{x:1229,y:847,t:1528143808102};\\\", \\\"{x:1228,y:846,t:1528143808206};\\\", \\\"{x:1226,y:845,t:1528143808222};\\\", \\\"{x:1224,y:844,t:1528143808278};\\\", \\\"{x:1223,y:843,t:1528143808294};\\\", \\\"{x:1223,y:842,t:1528143808302};\\\", \\\"{x:1222,y:839,t:1528143808315};\\\", \\\"{x:1221,y:837,t:1528143808331};\\\", \\\"{x:1220,y:836,t:1528143808348};\\\", \\\"{x:1219,y:835,t:1528143808365};\\\", \\\"{x:1218,y:834,t:1528143808383};\\\", \\\"{x:1216,y:833,t:1528143808478};\\\", \\\"{x:1215,y:832,t:1528143808502};\\\", \\\"{x:1213,y:833,t:1528143808662};\\\", \\\"{x:1210,y:836,t:1528143808671};\\\", \\\"{x:1207,y:842,t:1528143808682};\\\", \\\"{x:1198,y:852,t:1528143808697};\\\", \\\"{x:1194,y:857,t:1528143808714};\\\", \\\"{x:1191,y:861,t:1528143808731};\\\", \\\"{x:1190,y:861,t:1528143808748};\\\", \\\"{x:1189,y:862,t:1528143808764};\\\", \\\"{x:1189,y:863,t:1528143808782};\\\", \\\"{x:1187,y:864,t:1528143808806};\\\", \\\"{x:1187,y:865,t:1528143808814};\\\", \\\"{x:1187,y:868,t:1528143808832};\\\", \\\"{x:1187,y:870,t:1528143808848};\\\", \\\"{x:1186,y:871,t:1528143808865};\\\", \\\"{x:1186,y:872,t:1528143808886};\\\", \\\"{x:1185,y:874,t:1528143808897};\\\", \\\"{x:1185,y:876,t:1528143808914};\\\", \\\"{x:1183,y:879,t:1528143808932};\\\", \\\"{x:1182,y:881,t:1528143808947};\\\", \\\"{x:1180,y:883,t:1528143808964};\\\", \\\"{x:1179,y:885,t:1528143808982};\\\", \\\"{x:1178,y:887,t:1528143809030};\\\", \\\"{x:1177,y:888,t:1528143809038};\\\", \\\"{x:1176,y:889,t:1528143809049};\\\", \\\"{x:1175,y:889,t:1528143809064};\\\", \\\"{x:1173,y:890,t:1528143809082};\\\", \\\"{x:1172,y:891,t:1528143809099};\\\", \\\"{x:1171,y:892,t:1528143809115};\\\", \\\"{x:1167,y:893,t:1528143809131};\\\", \\\"{x:1163,y:896,t:1528143809149};\\\", \\\"{x:1159,y:898,t:1528143809165};\\\", \\\"{x:1152,y:899,t:1528143809182};\\\", \\\"{x:1145,y:900,t:1528143809198};\\\", \\\"{x:1138,y:900,t:1528143809215};\\\", \\\"{x:1132,y:900,t:1528143809231};\\\", \\\"{x:1125,y:900,t:1528143809249};\\\", \\\"{x:1118,y:900,t:1528143809265};\\\", \\\"{x:1106,y:900,t:1528143809281};\\\", \\\"{x:1101,y:900,t:1528143809299};\\\", \\\"{x:1099,y:901,t:1528143809471};\\\", \\\"{x:1097,y:905,t:1528143809481};\\\", \\\"{x:1091,y:914,t:1528143809499};\\\", \\\"{x:1088,y:918,t:1528143809516};\\\", \\\"{x:1087,y:920,t:1528143809532};\\\", \\\"{x:1085,y:924,t:1528143809549};\\\", \\\"{x:1085,y:925,t:1528143809583};\\\", \\\"{x:1084,y:926,t:1528143809598};\\\", \\\"{x:1084,y:927,t:1528143809622};\\\", \\\"{x:1084,y:929,t:1528143809632};\\\", \\\"{x:1084,y:930,t:1528143809654};\\\", \\\"{x:1083,y:931,t:1528143809666};\\\", \\\"{x:1083,y:932,t:1528143809686};\\\", \\\"{x:1083,y:933,t:1528143809702};\\\", \\\"{x:1083,y:934,t:1528143809715};\\\", \\\"{x:1081,y:938,t:1528143809732};\\\", \\\"{x:1081,y:941,t:1528143809749};\\\", \\\"{x:1081,y:943,t:1528143809766};\\\", \\\"{x:1081,y:944,t:1528143809782};\\\", \\\"{x:1080,y:945,t:1528143809814};\\\", \\\"{x:1080,y:946,t:1528143809830};\\\", \\\"{x:1080,y:948,t:1528143809845};\\\", \\\"{x:1080,y:949,t:1528143809862};\\\", \\\"{x:1079,y:950,t:1528143810095};\\\", \\\"{x:1078,y:950,t:1528143810278};\\\", \\\"{x:1077,y:950,t:1528143810391};\\\", \\\"{x:1077,y:949,t:1528143810400};\\\", \\\"{x:1076,y:949,t:1528143810535};\\\", \\\"{x:1075,y:949,t:1528143810790};\\\", \\\"{x:1075,y:952,t:1528143810806};\\\", \\\"{x:1075,y:954,t:1528143810816};\\\", \\\"{x:1074,y:956,t:1528143810833};\\\", \\\"{x:1074,y:958,t:1528143810850};\\\", \\\"{x:1074,y:959,t:1528143810867};\\\", \\\"{x:1073,y:960,t:1528143811062};\\\", \\\"{x:1071,y:960,t:1528143811077};\\\", \\\"{x:1069,y:959,t:1528143811102};\\\", \\\"{x:1068,y:959,t:1528143811117};\\\", \\\"{x:1066,y:958,t:1528143811133};\\\", \\\"{x:1065,y:958,t:1528143811150};\\\", \\\"{x:1067,y:958,t:1528143811519};\\\", \\\"{x:1068,y:959,t:1528143811534};\\\", \\\"{x:1069,y:959,t:1528143811558};\\\", \\\"{x:1071,y:959,t:1528143811574};\\\", \\\"{x:1071,y:960,t:1528143811606};\\\", \\\"{x:1073,y:960,t:1528143811630};\\\", \\\"{x:1073,y:961,t:1528143811646};\\\", \\\"{x:1073,y:962,t:1528143811654};\\\", \\\"{x:1074,y:962,t:1528143811667};\\\", \\\"{x:1075,y:963,t:1528143811684};\\\", \\\"{x:1077,y:965,t:1528143811701};\\\", \\\"{x:1081,y:969,t:1528143811717};\\\", \\\"{x:1084,y:972,t:1528143811735};\\\", \\\"{x:1085,y:973,t:1528143811758};\\\", \\\"{x:1088,y:972,t:1528143811974};\\\", \\\"{x:1089,y:972,t:1528143811983};\\\", \\\"{x:1096,y:971,t:1528143812001};\\\", \\\"{x:1101,y:971,t:1528143812017};\\\", \\\"{x:1106,y:971,t:1528143812035};\\\", \\\"{x:1109,y:971,t:1528143812051};\\\", \\\"{x:1112,y:971,t:1528143812067};\\\", \\\"{x:1114,y:971,t:1528143812084};\\\", \\\"{x:1117,y:971,t:1528143812101};\\\", \\\"{x:1118,y:971,t:1528143812118};\\\", \\\"{x:1119,y:971,t:1528143812133};\\\", \\\"{x:1120,y:971,t:1528143812151};\\\", \\\"{x:1121,y:971,t:1528143812168};\\\", \\\"{x:1123,y:971,t:1528143812184};\\\", \\\"{x:1123,y:972,t:1528143812201};\\\", \\\"{x:1124,y:972,t:1528143812255};\\\", \\\"{x:1126,y:972,t:1528143812294};\\\", \\\"{x:1127,y:972,t:1528143812310};\\\", \\\"{x:1128,y:972,t:1528143812318};\\\", \\\"{x:1129,y:972,t:1528143812342};\\\", \\\"{x:1131,y:971,t:1528143812351};\\\", \\\"{x:1132,y:971,t:1528143812368};\\\", \\\"{x:1133,y:971,t:1528143812384};\\\", \\\"{x:1135,y:971,t:1528143812400};\\\", \\\"{x:1139,y:972,t:1528143812418};\\\", \\\"{x:1140,y:972,t:1528143812434};\\\", \\\"{x:1141,y:973,t:1528143812450};\\\", \\\"{x:1142,y:973,t:1528143812468};\\\", \\\"{x:1140,y:973,t:1528143812726};\\\", \\\"{x:1139,y:973,t:1528143812742};\\\", \\\"{x:1138,y:972,t:1528143812791};\\\", \\\"{x:1136,y:971,t:1528143812814};\\\", \\\"{x:1133,y:970,t:1528143812830};\\\", \\\"{x:1132,y:969,t:1528143812838};\\\", \\\"{x:1131,y:968,t:1528143812851};\\\", \\\"{x:1127,y:967,t:1528143812868};\\\", \\\"{x:1124,y:967,t:1528143812884};\\\", \\\"{x:1119,y:967,t:1528143812901};\\\", \\\"{x:1113,y:967,t:1528143812918};\\\", \\\"{x:1110,y:967,t:1528143812935};\\\", \\\"{x:1109,y:967,t:1528143812951};\\\", \\\"{x:1108,y:967,t:1528143813006};\\\", \\\"{x:1106,y:967,t:1528143813022};\\\", \\\"{x:1104,y:965,t:1528143813038};\\\", \\\"{x:1103,y:965,t:1528143813054};\\\", \\\"{x:1102,y:965,t:1528143813102};\\\", \\\"{x:1101,y:965,t:1528143813118};\\\", \\\"{x:1100,y:965,t:1528143813135};\\\", \\\"{x:1099,y:965,t:1528143813158};\\\", \\\"{x:1099,y:964,t:1528143813168};\\\", \\\"{x:1097,y:964,t:1528143813190};\\\", \\\"{x:1096,y:964,t:1528143813214};\\\", \\\"{x:1096,y:963,t:1528143813230};\\\", \\\"{x:1095,y:962,t:1528143813262};\\\", \\\"{x:1094,y:962,t:1528143813270};\\\", \\\"{x:1092,y:961,t:1528143813286};\\\", \\\"{x:1090,y:961,t:1528143813302};\\\", \\\"{x:1089,y:960,t:1528143813318};\\\", \\\"{x:1088,y:959,t:1528143813335};\\\", \\\"{x:1087,y:959,t:1528143813352};\\\", \\\"{x:1086,y:959,t:1528143813367};\\\", \\\"{x:1086,y:960,t:1528143813598};\\\", \\\"{x:1089,y:962,t:1528143813606};\\\", \\\"{x:1091,y:963,t:1528143813619};\\\", \\\"{x:1095,y:964,t:1528143813634};\\\", \\\"{x:1099,y:966,t:1528143813652};\\\", \\\"{x:1100,y:966,t:1528143813669};\\\", \\\"{x:1102,y:967,t:1528143813685};\\\", \\\"{x:1104,y:967,t:1528143813750};\\\", \\\"{x:1105,y:967,t:1528143813758};\\\", \\\"{x:1106,y:967,t:1528143813769};\\\", \\\"{x:1109,y:967,t:1528143813785};\\\", \\\"{x:1111,y:967,t:1528143813802};\\\", \\\"{x:1113,y:969,t:1528143813819};\\\", \\\"{x:1115,y:970,t:1528143813835};\\\", \\\"{x:1117,y:970,t:1528143813852};\\\", \\\"{x:1120,y:971,t:1528143813869};\\\", \\\"{x:1123,y:973,t:1528143813885};\\\", \\\"{x:1125,y:974,t:1528143813902};\\\", \\\"{x:1124,y:974,t:1528143814399};\\\", \\\"{x:1121,y:974,t:1528143814406};\\\", \\\"{x:1119,y:976,t:1528143814419};\\\", \\\"{x:1116,y:977,t:1528143814435};\\\", \\\"{x:1114,y:977,t:1528143814453};\\\", \\\"{x:1113,y:977,t:1528143814469};\\\", \\\"{x:1112,y:977,t:1528143814494};\\\", \\\"{x:1111,y:977,t:1528143814526};\\\", \\\"{x:1110,y:977,t:1528143814536};\\\", \\\"{x:1107,y:977,t:1528143814552};\\\", \\\"{x:1104,y:977,t:1528143814569};\\\", \\\"{x:1100,y:976,t:1528143814586};\\\", \\\"{x:1094,y:976,t:1528143814603};\\\", \\\"{x:1093,y:976,t:1528143814619};\\\", \\\"{x:1091,y:976,t:1528143814645};\\\", \\\"{x:1090,y:976,t:1528143814702};\\\", \\\"{x:1092,y:976,t:1528143815710};\\\", \\\"{x:1097,y:976,t:1528143815719};\\\", \\\"{x:1106,y:976,t:1528143815737};\\\", \\\"{x:1112,y:976,t:1528143815754};\\\", \\\"{x:1115,y:976,t:1528143815770};\\\", \\\"{x:1115,y:975,t:1528143815787};\\\", \\\"{x:1117,y:974,t:1528143815814};\\\", \\\"{x:1117,y:973,t:1528143815845};\\\", \\\"{x:1117,y:971,t:1528143815965};\\\", \\\"{x:1115,y:970,t:1528143815973};\\\", \\\"{x:1113,y:969,t:1528143815986};\\\", \\\"{x:1109,y:967,t:1528143816003};\\\", \\\"{x:1107,y:966,t:1528143816019};\\\", \\\"{x:1105,y:965,t:1528143816037};\\\", \\\"{x:1103,y:964,t:1528143816054};\\\", \\\"{x:1103,y:963,t:1528143816069};\\\", \\\"{x:1103,y:961,t:1528143816279};\\\", \\\"{x:1103,y:958,t:1528143816287};\\\", \\\"{x:1102,y:955,t:1528143816304};\\\", \\\"{x:1102,y:953,t:1528143816321};\\\", \\\"{x:1102,y:952,t:1528143816350};\\\", \\\"{x:1100,y:952,t:1528143818230};\\\", \\\"{x:1098,y:952,t:1528143818239};\\\", \\\"{x:1096,y:953,t:1528143818256};\\\", \\\"{x:1093,y:954,t:1528143818272};\\\", \\\"{x:1092,y:954,t:1528143818318};\\\", \\\"{x:1091,y:954,t:1528143818358};\\\", \\\"{x:1090,y:955,t:1528143818374};\\\", \\\"{x:1088,y:956,t:1528143818390};\\\", \\\"{x:1087,y:957,t:1528143818406};\\\", \\\"{x:1086,y:958,t:1528143818422};\\\", \\\"{x:1085,y:959,t:1528143818439};\\\", \\\"{x:1085,y:960,t:1528143818462};\\\", \\\"{x:1085,y:961,t:1528143818477};\\\", \\\"{x:1084,y:962,t:1528143818489};\\\", \\\"{x:1084,y:964,t:1528143818507};\\\", \\\"{x:1084,y:965,t:1528143818526};\\\", \\\"{x:1084,y:963,t:1528143818623};\\\", \\\"{x:1086,y:958,t:1528143818639};\\\", \\\"{x:1095,y:946,t:1528143818656};\\\", \\\"{x:1099,y:938,t:1528143818672};\\\", \\\"{x:1104,y:931,t:1528143818689};\\\", \\\"{x:1105,y:925,t:1528143818706};\\\", \\\"{x:1109,y:913,t:1528143818722};\\\", \\\"{x:1113,y:900,t:1528143818739};\\\", \\\"{x:1116,y:886,t:1528143818756};\\\", \\\"{x:1120,y:872,t:1528143818772};\\\", \\\"{x:1125,y:861,t:1528143818790};\\\", \\\"{x:1128,y:852,t:1528143818806};\\\", \\\"{x:1129,y:849,t:1528143818823};\\\", \\\"{x:1131,y:842,t:1528143818839};\\\", \\\"{x:1132,y:838,t:1528143818856};\\\", \\\"{x:1135,y:830,t:1528143818873};\\\", \\\"{x:1137,y:823,t:1528143818890};\\\", \\\"{x:1141,y:815,t:1528143818906};\\\", \\\"{x:1141,y:810,t:1528143818923};\\\", \\\"{x:1141,y:809,t:1528143818942};\\\", \\\"{x:1142,y:808,t:1528143818974};\\\", \\\"{x:1143,y:806,t:1528143818998};\\\", \\\"{x:1144,y:805,t:1528143819005};\\\", \\\"{x:1144,y:803,t:1528143819023};\\\", \\\"{x:1146,y:800,t:1528143819039};\\\", \\\"{x:1147,y:795,t:1528143819057};\\\", \\\"{x:1152,y:783,t:1528143819074};\\\", \\\"{x:1156,y:777,t:1528143819089};\\\", \\\"{x:1157,y:774,t:1528143819106};\\\", \\\"{x:1159,y:772,t:1528143819123};\\\", \\\"{x:1159,y:771,t:1528143819139};\\\", \\\"{x:1159,y:774,t:1528143819423};\\\", \\\"{x:1160,y:788,t:1528143819441};\\\", \\\"{x:1161,y:799,t:1528143819456};\\\", \\\"{x:1163,y:803,t:1528143819473};\\\", \\\"{x:1163,y:805,t:1528143819490};\\\", \\\"{x:1163,y:806,t:1528143819510};\\\", \\\"{x:1163,y:807,t:1528143819523};\\\", \\\"{x:1164,y:810,t:1528143819540};\\\", \\\"{x:1165,y:815,t:1528143819556};\\\", \\\"{x:1165,y:817,t:1528143819573};\\\", \\\"{x:1166,y:822,t:1528143819589};\\\", \\\"{x:1166,y:823,t:1528143819613};\\\", \\\"{x:1166,y:824,t:1528143819629};\\\", \\\"{x:1166,y:825,t:1528143819645};\\\", \\\"{x:1167,y:825,t:1528143819661};\\\", \\\"{x:1167,y:826,t:1528143819672};\\\", \\\"{x:1167,y:827,t:1528143819689};\\\", \\\"{x:1167,y:829,t:1528143819707};\\\", \\\"{x:1167,y:830,t:1528143819723};\\\", \\\"{x:1167,y:832,t:1528143819740};\\\", \\\"{x:1167,y:838,t:1528143819756};\\\", \\\"{x:1167,y:839,t:1528143819773};\\\", \\\"{x:1167,y:841,t:1528143819789};\\\", \\\"{x:1166,y:841,t:1528143820886};\\\", \\\"{x:1166,y:845,t:1528143820894};\\\", \\\"{x:1166,y:850,t:1528143820907};\\\", \\\"{x:1166,y:864,t:1528143820924};\\\", \\\"{x:1169,y:876,t:1528143820941};\\\", \\\"{x:1172,y:888,t:1528143820957};\\\", \\\"{x:1181,y:904,t:1528143820973};\\\", \\\"{x:1189,y:914,t:1528143820990};\\\", \\\"{x:1202,y:928,t:1528143821007};\\\", \\\"{x:1212,y:940,t:1528143821024};\\\", \\\"{x:1221,y:951,t:1528143821041};\\\", \\\"{x:1229,y:959,t:1528143821058};\\\", \\\"{x:1236,y:966,t:1528143821073};\\\", \\\"{x:1240,y:970,t:1528143821091};\\\", \\\"{x:1246,y:974,t:1528143821108};\\\", \\\"{x:1253,y:977,t:1528143821124};\\\", \\\"{x:1262,y:981,t:1528143821141};\\\", \\\"{x:1278,y:987,t:1528143821158};\\\", \\\"{x:1286,y:988,t:1528143821174};\\\", \\\"{x:1293,y:988,t:1528143821191};\\\", \\\"{x:1296,y:988,t:1528143821208};\\\", \\\"{x:1297,y:988,t:1528143821230};\\\", \\\"{x:1298,y:988,t:1528143821270};\\\", \\\"{x:1298,y:987,t:1528143821286};\\\", \\\"{x:1298,y:986,t:1528143821294};\\\", \\\"{x:1298,y:984,t:1528143821309};\\\", \\\"{x:1297,y:979,t:1528143821324};\\\", \\\"{x:1294,y:971,t:1528143821341};\\\", \\\"{x:1287,y:964,t:1528143821358};\\\", \\\"{x:1283,y:960,t:1528143821374};\\\", \\\"{x:1281,y:958,t:1528143821392};\\\", \\\"{x:1279,y:956,t:1528143821408};\\\", \\\"{x:1278,y:955,t:1528143821424};\\\", \\\"{x:1277,y:955,t:1528143822102};\\\", \\\"{x:1277,y:956,t:1528143822110};\\\", \\\"{x:1276,y:958,t:1528143822126};\\\", \\\"{x:1275,y:961,t:1528143822142};\\\", \\\"{x:1274,y:962,t:1528143822158};\\\", \\\"{x:1273,y:963,t:1528143822175};\\\", \\\"{x:1273,y:965,t:1528143822192};\\\", \\\"{x:1273,y:966,t:1528143822209};\\\", \\\"{x:1273,y:965,t:1528143822678};\\\", \\\"{x:1273,y:961,t:1528143822692};\\\", \\\"{x:1274,y:954,t:1528143822709};\\\", \\\"{x:1276,y:940,t:1528143822726};\\\", \\\"{x:1285,y:911,t:1528143822742};\\\", \\\"{x:1290,y:889,t:1528143822759};\\\", \\\"{x:1300,y:864,t:1528143822776};\\\", \\\"{x:1312,y:838,t:1528143822791};\\\", \\\"{x:1322,y:812,t:1528143822809};\\\", \\\"{x:1334,y:785,t:1528143822826};\\\", \\\"{x:1339,y:768,t:1528143822842};\\\", \\\"{x:1343,y:758,t:1528143822859};\\\", \\\"{x:1344,y:754,t:1528143822876};\\\", \\\"{x:1344,y:752,t:1528143822891};\\\", \\\"{x:1346,y:750,t:1528143822909};\\\", \\\"{x:1349,y:745,t:1528143822925};\\\", \\\"{x:1352,y:738,t:1528143822942};\\\", \\\"{x:1355,y:731,t:1528143822959};\\\", \\\"{x:1358,y:726,t:1528143822976};\\\", \\\"{x:1358,y:725,t:1528143822992};\\\", \\\"{x:1354,y:727,t:1528143823079};\\\", \\\"{x:1353,y:732,t:1528143823092};\\\", \\\"{x:1345,y:746,t:1528143823110};\\\", \\\"{x:1344,y:750,t:1528143823126};\\\", \\\"{x:1340,y:756,t:1528143823143};\\\", \\\"{x:1340,y:761,t:1528143823160};\\\", \\\"{x:1340,y:764,t:1528143823177};\\\", \\\"{x:1339,y:764,t:1528143823192};\\\", \\\"{x:1339,y:766,t:1528143823209};\\\", \\\"{x:1339,y:767,t:1528143823226};\\\", \\\"{x:1338,y:769,t:1528143823246};\\\", \\\"{x:1338,y:771,t:1528143823262};\\\", \\\"{x:1338,y:772,t:1528143823277};\\\", \\\"{x:1337,y:775,t:1528143823294};\\\", \\\"{x:1337,y:776,t:1528143823310};\\\", \\\"{x:1337,y:777,t:1528143823327};\\\", \\\"{x:1337,y:778,t:1528143823343};\\\", \\\"{x:1337,y:779,t:1528143823399};\\\", \\\"{x:1339,y:779,t:1528143823494};\\\", \\\"{x:1342,y:775,t:1528143823509};\\\", \\\"{x:1344,y:771,t:1528143823526};\\\", \\\"{x:1345,y:767,t:1528143823544};\\\", \\\"{x:1345,y:766,t:1528143823560};\\\", \\\"{x:1346,y:763,t:1528143823576};\\\", \\\"{x:1347,y:763,t:1528143823606};\\\", \\\"{x:1345,y:763,t:1528143823702};\\\", \\\"{x:1343,y:764,t:1528143823709};\\\", \\\"{x:1335,y:773,t:1528143823728};\\\", \\\"{x:1330,y:781,t:1528143823743};\\\", \\\"{x:1324,y:788,t:1528143823762};\\\", \\\"{x:1316,y:797,t:1528143823776};\\\", \\\"{x:1307,y:807,t:1528143823794};\\\", \\\"{x:1301,y:815,t:1528143823810};\\\", \\\"{x:1297,y:823,t:1528143823827};\\\", \\\"{x:1292,y:832,t:1528143823843};\\\", \\\"{x:1287,y:842,t:1528143823860};\\\", \\\"{x:1284,y:851,t:1528143823877};\\\", \\\"{x:1279,y:863,t:1528143823894};\\\", \\\"{x:1277,y:870,t:1528143823910};\\\", \\\"{x:1274,y:878,t:1528143823927};\\\", \\\"{x:1272,y:884,t:1528143823944};\\\", \\\"{x:1270,y:888,t:1528143823962};\\\", \\\"{x:1270,y:890,t:1528143823977};\\\", \\\"{x:1267,y:894,t:1528143823994};\\\", \\\"{x:1267,y:898,t:1528143824011};\\\", \\\"{x:1266,y:901,t:1528143824026};\\\", \\\"{x:1265,y:905,t:1528143824044};\\\", \\\"{x:1265,y:909,t:1528143824060};\\\", \\\"{x:1264,y:913,t:1528143824076};\\\", \\\"{x:1263,y:917,t:1528143824093};\\\", \\\"{x:1262,y:929,t:1528143824110};\\\", \\\"{x:1261,y:934,t:1528143824126};\\\", \\\"{x:1260,y:938,t:1528143824143};\\\", \\\"{x:1259,y:941,t:1528143824161};\\\", \\\"{x:1258,y:945,t:1528143824178};\\\", \\\"{x:1256,y:949,t:1528143824193};\\\", \\\"{x:1255,y:955,t:1528143824211};\\\", \\\"{x:1255,y:957,t:1528143824228};\\\", \\\"{x:1253,y:959,t:1528143824243};\\\", \\\"{x:1252,y:962,t:1528143824261};\\\", \\\"{x:1251,y:963,t:1528143824278};\\\", \\\"{x:1250,y:965,t:1528143824294};\\\", \\\"{x:1250,y:966,t:1528143824310};\\\", \\\"{x:1249,y:968,t:1528143824328};\\\", \\\"{x:1248,y:969,t:1528143824344};\\\", \\\"{x:1248,y:970,t:1528143824361};\\\", \\\"{x:1247,y:971,t:1528143824382};\\\", \\\"{x:1246,y:972,t:1528143824406};\\\", \\\"{x:1246,y:973,t:1528143824414};\\\", \\\"{x:1245,y:974,t:1528143824429};\\\", \\\"{x:1245,y:975,t:1528143824443};\\\", \\\"{x:1244,y:976,t:1528143824460};\\\", \\\"{x:1243,y:977,t:1528143824478};\\\", \\\"{x:1243,y:978,t:1528143824510};\\\", \\\"{x:1242,y:978,t:1528143824527};\\\", \\\"{x:1242,y:979,t:1528143824550};\\\", \\\"{x:1241,y:980,t:1528143824646};\\\", \\\"{x:1240,y:980,t:1528143824694};\\\", \\\"{x:1238,y:980,t:1528143824718};\\\", \\\"{x:1237,y:979,t:1528143824733};\\\", \\\"{x:1237,y:977,t:1528143824750};\\\", \\\"{x:1237,y:975,t:1528143824762};\\\", \\\"{x:1237,y:973,t:1528143824778};\\\", \\\"{x:1237,y:968,t:1528143824794};\\\", \\\"{x:1237,y:966,t:1528143824810};\\\", \\\"{x:1237,y:964,t:1528143824828};\\\", \\\"{x:1237,y:963,t:1528143824844};\\\", \\\"{x:1239,y:961,t:1528143824861};\\\", \\\"{x:1241,y:959,t:1528143824878};\\\", \\\"{x:1245,y:957,t:1528143824894};\\\", \\\"{x:1248,y:957,t:1528143824911};\\\", \\\"{x:1254,y:955,t:1528143824928};\\\", \\\"{x:1256,y:954,t:1528143824945};\\\", \\\"{x:1257,y:954,t:1528143825134};\\\", \\\"{x:1258,y:954,t:1528143825145};\\\", \\\"{x:1259,y:954,t:1528143825161};\\\", \\\"{x:1261,y:954,t:1528143825302};\\\", \\\"{x:1262,y:954,t:1528143825312};\\\", \\\"{x:1264,y:955,t:1528143825328};\\\", \\\"{x:1265,y:956,t:1528143826583};\\\", \\\"{x:1265,y:958,t:1528143826596};\\\", \\\"{x:1265,y:964,t:1528143826612};\\\", \\\"{x:1265,y:967,t:1528143826629};\\\", \\\"{x:1265,y:970,t:1528143826646};\\\", \\\"{x:1265,y:971,t:1528143826662};\\\", \\\"{x:1265,y:972,t:1528143826726};\\\", \\\"{x:1263,y:970,t:1528143826798};\\\", \\\"{x:1262,y:965,t:1528143826813};\\\", \\\"{x:1256,y:945,t:1528143826830};\\\", \\\"{x:1250,y:932,t:1528143826846};\\\", \\\"{x:1239,y:912,t:1528143826862};\\\", \\\"{x:1228,y:890,t:1528143826879};\\\", \\\"{x:1212,y:865,t:1528143826895};\\\", \\\"{x:1198,y:848,t:1528143826912};\\\", \\\"{x:1188,y:836,t:1528143826929};\\\", \\\"{x:1179,y:829,t:1528143826945};\\\", \\\"{x:1170,y:821,t:1528143826962};\\\", \\\"{x:1165,y:817,t:1528143826978};\\\", \\\"{x:1163,y:815,t:1528143826995};\\\", \\\"{x:1162,y:814,t:1528143827012};\\\", \\\"{x:1161,y:814,t:1528143827029};\\\", \\\"{x:1161,y:813,t:1528143827044};\\\", \\\"{x:1161,y:812,t:1528143827069};\\\", \\\"{x:1159,y:811,t:1528143827079};\\\", \\\"{x:1159,y:808,t:1528143827095};\\\", \\\"{x:1159,y:805,t:1528143827112};\\\", \\\"{x:1160,y:799,t:1528143827129};\\\", \\\"{x:1164,y:793,t:1528143827145};\\\", \\\"{x:1169,y:784,t:1528143827162};\\\", \\\"{x:1172,y:777,t:1528143827179};\\\", \\\"{x:1173,y:771,t:1528143827196};\\\", \\\"{x:1173,y:767,t:1528143827212};\\\", \\\"{x:1174,y:767,t:1528143827229};\\\", \\\"{x:1174,y:766,t:1528143827245};\\\", \\\"{x:1173,y:763,t:1528143827374};\\\", \\\"{x:1168,y:761,t:1528143827382};\\\", \\\"{x:1160,y:757,t:1528143827396};\\\", \\\"{x:1139,y:748,t:1528143827413};\\\", \\\"{x:1086,y:732,t:1528143827430};\\\", \\\"{x:1014,y:716,t:1528143827446};\\\", \\\"{x:938,y:699,t:1528143827462};\\\", \\\"{x:879,y:691,t:1528143827479};\\\", \\\"{x:841,y:683,t:1528143827497};\\\", \\\"{x:804,y:671,t:1528143827513};\\\", \\\"{x:772,y:662,t:1528143827529};\\\", \\\"{x:746,y:651,t:1528143827547};\\\", \\\"{x:723,y:641,t:1528143827563};\\\", \\\"{x:704,y:633,t:1528143827580};\\\", \\\"{x:688,y:625,t:1528143827598};\\\", \\\"{x:670,y:616,t:1528143827612};\\\", \\\"{x:643,y:603,t:1528143827629};\\\", \\\"{x:623,y:592,t:1528143827647};\\\", \\\"{x:601,y:579,t:1528143827663};\\\", \\\"{x:581,y:568,t:1528143827680};\\\", \\\"{x:563,y:560,t:1528143827696};\\\", \\\"{x:544,y:551,t:1528143827713};\\\", \\\"{x:529,y:549,t:1528143827730};\\\", \\\"{x:517,y:546,t:1528143827746};\\\", \\\"{x:504,y:545,t:1528143827763};\\\", \\\"{x:495,y:545,t:1528143827781};\\\", \\\"{x:486,y:545,t:1528143827796};\\\", \\\"{x:477,y:545,t:1528143827813};\\\", \\\"{x:466,y:545,t:1528143827830};\\\", \\\"{x:449,y:545,t:1528143827846};\\\", \\\"{x:428,y:542,t:1528143827863};\\\", \\\"{x:403,y:535,t:1528143827880};\\\", \\\"{x:375,y:527,t:1528143827898};\\\", \\\"{x:331,y:511,t:1528143827913};\\\", \\\"{x:284,y:497,t:1528143827930};\\\", \\\"{x:239,y:486,t:1528143827947};\\\", \\\"{x:212,y:481,t:1528143827963};\\\", \\\"{x:200,y:480,t:1528143827979};\\\", \\\"{x:193,y:478,t:1528143827996};\\\", \\\"{x:185,y:474,t:1528143828013};\\\", \\\"{x:180,y:471,t:1528143828030};\\\", \\\"{x:178,y:471,t:1528143828046};\\\", \\\"{x:177,y:470,t:1528143828063};\\\", \\\"{x:175,y:470,t:1528143828101};\\\", \\\"{x:173,y:470,t:1528143828114};\\\", \\\"{x:170,y:472,t:1528143828130};\\\", \\\"{x:166,y:473,t:1528143828146};\\\", \\\"{x:166,y:475,t:1528143828163};\\\", \\\"{x:164,y:477,t:1528143828179};\\\", \\\"{x:163,y:479,t:1528143828197};\\\", \\\"{x:163,y:480,t:1528143828213};\\\", \\\"{x:163,y:484,t:1528143828230};\\\", \\\"{x:163,y:488,t:1528143828247};\\\", \\\"{x:163,y:492,t:1528143828262};\\\", \\\"{x:163,y:495,t:1528143828280};\\\", \\\"{x:164,y:497,t:1528143828297};\\\", \\\"{x:166,y:500,t:1528143828314};\\\", \\\"{x:167,y:502,t:1528143828330};\\\", \\\"{x:168,y:503,t:1528143828347};\\\", \\\"{x:170,y:506,t:1528143828364};\\\", \\\"{x:170,y:507,t:1528143828379};\\\", \\\"{x:172,y:509,t:1528143828397};\\\", \\\"{x:173,y:509,t:1528143828414};\\\", \\\"{x:173,y:508,t:1528143828718};\\\", \\\"{x:173,y:507,t:1528143828731};\\\", \\\"{x:173,y:506,t:1528143828748};\\\", \\\"{x:173,y:504,t:1528143828765};\\\", \\\"{x:173,y:503,t:1528143829165};\\\", \\\"{x:174,y:503,t:1528143829181};\\\", \\\"{x:176,y:503,t:1528143829197};\\\", \\\"{x:178,y:503,t:1528143829214};\\\", \\\"{x:182,y:503,t:1528143829231};\\\", \\\"{x:188,y:505,t:1528143829249};\\\", \\\"{x:200,y:509,t:1528143829264};\\\", \\\"{x:214,y:512,t:1528143829281};\\\", \\\"{x:231,y:515,t:1528143829298};\\\", \\\"{x:252,y:518,t:1528143829315};\\\", \\\"{x:271,y:519,t:1528143829331};\\\", \\\"{x:292,y:523,t:1528143829348};\\\", \\\"{x:318,y:524,t:1528143829364};\\\", \\\"{x:377,y:525,t:1528143829382};\\\", \\\"{x:437,y:530,t:1528143829398};\\\", \\\"{x:515,y:541,t:1528143829415};\\\", \\\"{x:611,y:561,t:1528143829432};\\\", \\\"{x:738,y:597,t:1528143829448};\\\", \\\"{x:868,y:635,t:1528143829464};\\\", \\\"{x:1014,y:677,t:1528143829481};\\\", \\\"{x:1161,y:716,t:1528143829498};\\\", \\\"{x:1283,y:752,t:1528143829514};\\\", \\\"{x:1395,y:779,t:1528143829531};\\\", \\\"{x:1474,y:795,t:1528143829548};\\\", \\\"{x:1519,y:801,t:1528143829564};\\\", \\\"{x:1548,y:802,t:1528143829582};\\\", \\\"{x:1556,y:802,t:1528143829598};\\\", \\\"{x:1559,y:802,t:1528143829614};\\\", \\\"{x:1560,y:802,t:1528143829632};\\\", \\\"{x:1560,y:796,t:1528143829649};\\\", \\\"{x:1560,y:781,t:1528143829665};\\\", \\\"{x:1557,y:759,t:1528143829681};\\\", \\\"{x:1539,y:723,t:1528143829698};\\\", \\\"{x:1514,y:682,t:1528143829715};\\\", \\\"{x:1478,y:647,t:1528143829732};\\\", \\\"{x:1432,y:614,t:1528143829749};\\\", \\\"{x:1404,y:601,t:1528143829765};\\\", \\\"{x:1397,y:600,t:1528143829782};\\\", \\\"{x:1391,y:600,t:1528143829799};\\\", \\\"{x:1387,y:600,t:1528143829816};\\\", \\\"{x:1382,y:602,t:1528143829831};\\\", \\\"{x:1380,y:602,t:1528143829849};\\\", \\\"{x:1379,y:603,t:1528143829866};\\\", \\\"{x:1379,y:604,t:1528143829886};\\\", \\\"{x:1379,y:605,t:1528143829990};\\\", \\\"{x:1377,y:605,t:1528143829999};\\\", \\\"{x:1370,y:603,t:1528143830016};\\\", \\\"{x:1357,y:598,t:1528143830033};\\\", \\\"{x:1344,y:593,t:1528143830049};\\\", \\\"{x:1317,y:585,t:1528143830066};\\\", \\\"{x:1290,y:579,t:1528143830082};\\\", \\\"{x:1269,y:574,t:1528143830099};\\\", \\\"{x:1260,y:572,t:1528143830116};\\\", \\\"{x:1256,y:571,t:1528143830132};\\\", \\\"{x:1253,y:570,t:1528143830149};\\\", \\\"{x:1254,y:570,t:1528143830230};\\\", \\\"{x:1256,y:569,t:1528143830238};\\\", \\\"{x:1257,y:568,t:1528143830248};\\\", \\\"{x:1258,y:566,t:1528143830266};\\\", \\\"{x:1259,y:564,t:1528143830283};\\\", \\\"{x:1260,y:563,t:1528143830299};\\\", \\\"{x:1261,y:561,t:1528143830316};\\\", \\\"{x:1264,y:558,t:1528143830333};\\\", \\\"{x:1266,y:557,t:1528143830349};\\\", \\\"{x:1268,y:557,t:1528143830430};\\\", \\\"{x:1269,y:557,t:1528143830438};\\\", \\\"{x:1270,y:557,t:1528143830449};\\\", \\\"{x:1272,y:557,t:1528143830654};\\\", \\\"{x:1273,y:558,t:1528143830670};\\\", \\\"{x:1273,y:559,t:1528143830683};\\\", \\\"{x:1274,y:561,t:1528143830700};\\\", \\\"{x:1275,y:562,t:1528143830716};\\\", \\\"{x:1276,y:564,t:1528143830733};\\\", \\\"{x:1276,y:567,t:1528143830751};\\\", \\\"{x:1278,y:570,t:1528143830766};\\\", \\\"{x:1278,y:572,t:1528143830783};\\\", \\\"{x:1280,y:574,t:1528143830800};\\\", \\\"{x:1281,y:576,t:1528143830816};\\\", \\\"{x:1282,y:577,t:1528143830833};\\\", \\\"{x:1282,y:579,t:1528143830850};\\\", \\\"{x:1283,y:581,t:1528143830865};\\\", \\\"{x:1284,y:583,t:1528143830882};\\\", \\\"{x:1284,y:584,t:1528143830899};\\\", \\\"{x:1285,y:586,t:1528143830915};\\\", \\\"{x:1285,y:587,t:1528143830932};\\\", \\\"{x:1286,y:588,t:1528143830949};\\\", \\\"{x:1287,y:591,t:1528143830965};\\\", \\\"{x:1289,y:594,t:1528143830982};\\\", \\\"{x:1290,y:598,t:1528143830999};\\\", \\\"{x:1292,y:601,t:1528143831016};\\\", \\\"{x:1293,y:605,t:1528143831032};\\\", \\\"{x:1296,y:610,t:1528143831050};\\\", \\\"{x:1297,y:613,t:1528143831066};\\\", \\\"{x:1300,y:618,t:1528143831082};\\\", \\\"{x:1304,y:624,t:1528143831099};\\\", \\\"{x:1306,y:628,t:1528143831117};\\\", \\\"{x:1309,y:633,t:1528143831132};\\\", \\\"{x:1313,y:640,t:1528143831149};\\\", \\\"{x:1316,y:643,t:1528143831167};\\\", \\\"{x:1317,y:647,t:1528143831183};\\\", \\\"{x:1320,y:650,t:1528143831199};\\\", \\\"{x:1322,y:653,t:1528143831217};\\\", \\\"{x:1325,y:658,t:1528143831233};\\\", \\\"{x:1327,y:662,t:1528143831250};\\\", \\\"{x:1331,y:667,t:1528143831267};\\\", \\\"{x:1335,y:673,t:1528143831283};\\\", \\\"{x:1338,y:677,t:1528143831300};\\\", \\\"{x:1340,y:680,t:1528143831317};\\\", \\\"{x:1343,y:685,t:1528143831333};\\\", \\\"{x:1347,y:690,t:1528143831349};\\\", \\\"{x:1351,y:696,t:1528143831366};\\\", \\\"{x:1354,y:699,t:1528143831383};\\\", \\\"{x:1357,y:704,t:1528143831399};\\\", \\\"{x:1362,y:710,t:1528143831416};\\\", \\\"{x:1364,y:713,t:1528143831433};\\\", \\\"{x:1365,y:716,t:1528143831449};\\\", \\\"{x:1368,y:720,t:1528143831466};\\\", \\\"{x:1371,y:726,t:1528143831483};\\\", \\\"{x:1373,y:731,t:1528143831499};\\\", \\\"{x:1376,y:738,t:1528143831516};\\\", \\\"{x:1387,y:750,t:1528143831533};\\\", \\\"{x:1391,y:757,t:1528143831550};\\\", \\\"{x:1393,y:761,t:1528143831567};\\\", \\\"{x:1394,y:762,t:1528143831583};\\\", \\\"{x:1397,y:766,t:1528143831599};\\\", \\\"{x:1398,y:768,t:1528143831616};\\\", \\\"{x:1399,y:770,t:1528143831634};\\\", \\\"{x:1401,y:773,t:1528143831650};\\\", \\\"{x:1402,y:775,t:1528143831666};\\\", \\\"{x:1405,y:779,t:1528143831684};\\\", \\\"{x:1406,y:782,t:1528143831700};\\\", \\\"{x:1408,y:785,t:1528143831716};\\\", \\\"{x:1410,y:791,t:1528143831733};\\\", \\\"{x:1413,y:796,t:1528143831750};\\\", \\\"{x:1416,y:799,t:1528143831767};\\\", \\\"{x:1417,y:804,t:1528143831783};\\\", \\\"{x:1419,y:806,t:1528143831800};\\\", \\\"{x:1420,y:809,t:1528143831817};\\\", \\\"{x:1422,y:812,t:1528143831833};\\\", \\\"{x:1424,y:816,t:1528143831850};\\\", \\\"{x:1426,y:820,t:1528143831866};\\\", \\\"{x:1428,y:823,t:1528143831884};\\\", \\\"{x:1431,y:829,t:1528143831901};\\\", \\\"{x:1434,y:834,t:1528143831917};\\\", \\\"{x:1435,y:836,t:1528143831934};\\\", \\\"{x:1437,y:838,t:1528143831950};\\\", \\\"{x:1437,y:840,t:1528143831967};\\\", \\\"{x:1437,y:842,t:1528143831984};\\\", \\\"{x:1438,y:844,t:1528143832000};\\\", \\\"{x:1439,y:845,t:1528143832017};\\\", \\\"{x:1440,y:848,t:1528143832034};\\\", \\\"{x:1441,y:848,t:1528143832050};\\\", \\\"{x:1441,y:850,t:1528143832067};\\\", \\\"{x:1441,y:851,t:1528143832084};\\\", \\\"{x:1444,y:855,t:1528143832101};\\\", \\\"{x:1445,y:859,t:1528143832117};\\\", \\\"{x:1449,y:870,t:1528143832133};\\\", \\\"{x:1453,y:876,t:1528143832151};\\\", \\\"{x:1454,y:882,t:1528143832167};\\\", \\\"{x:1459,y:892,t:1528143832184};\\\", \\\"{x:1461,y:896,t:1528143832201};\\\", \\\"{x:1463,y:901,t:1528143832217};\\\", \\\"{x:1466,y:907,t:1528143832234};\\\", \\\"{x:1469,y:912,t:1528143832251};\\\", \\\"{x:1470,y:915,t:1528143832268};\\\", \\\"{x:1472,y:919,t:1528143832283};\\\", \\\"{x:1473,y:922,t:1528143832301};\\\", \\\"{x:1474,y:928,t:1528143832317};\\\", \\\"{x:1474,y:929,t:1528143832334};\\\", \\\"{x:1474,y:924,t:1528143832414};\\\", \\\"{x:1474,y:909,t:1528143832422};\\\", \\\"{x:1470,y:895,t:1528143832434};\\\", \\\"{x:1456,y:863,t:1528143832450};\\\", \\\"{x:1450,y:848,t:1528143832468};\\\", \\\"{x:1447,y:841,t:1528143832484};\\\", \\\"{x:1444,y:835,t:1528143832501};\\\", \\\"{x:1439,y:826,t:1528143832518};\\\", \\\"{x:1438,y:826,t:1528143832534};\\\", \\\"{x:1438,y:824,t:1528143832551};\\\", \\\"{x:1438,y:823,t:1528143832568};\\\", \\\"{x:1436,y:819,t:1528143832584};\\\", \\\"{x:1434,y:815,t:1528143832601};\\\", \\\"{x:1432,y:812,t:1528143832618};\\\", \\\"{x:1429,y:809,t:1528143832634};\\\", \\\"{x:1426,y:808,t:1528143832651};\\\", \\\"{x:1422,y:805,t:1528143832668};\\\", \\\"{x:1415,y:802,t:1528143832684};\\\", \\\"{x:1408,y:797,t:1528143832701};\\\", \\\"{x:1392,y:790,t:1528143832718};\\\", \\\"{x:1384,y:787,t:1528143832734};\\\", \\\"{x:1375,y:783,t:1528143832751};\\\", \\\"{x:1368,y:781,t:1528143832767};\\\", \\\"{x:1367,y:780,t:1528143832784};\\\", \\\"{x:1367,y:779,t:1528143832814};\\\", \\\"{x:1366,y:779,t:1528143832822};\\\", \\\"{x:1365,y:779,t:1528143832838};\\\", \\\"{x:1365,y:778,t:1528143832854};\\\", \\\"{x:1364,y:777,t:1528143832868};\\\", \\\"{x:1364,y:776,t:1528143832902};\\\", \\\"{x:1362,y:775,t:1528143832917};\\\", \\\"{x:1361,y:773,t:1528143832935};\\\", \\\"{x:1359,y:770,t:1528143832951};\\\", \\\"{x:1358,y:769,t:1528143832968};\\\", \\\"{x:1355,y:768,t:1528143832985};\\\", \\\"{x:1353,y:767,t:1528143833001};\\\", \\\"{x:1351,y:765,t:1528143833018};\\\", \\\"{x:1351,y:764,t:1528143833050};\\\", \\\"{x:1350,y:763,t:1528143833068};\\\", \\\"{x:1350,y:764,t:1528143833254};\\\", \\\"{x:1350,y:767,t:1528143833268};\\\", \\\"{x:1350,y:770,t:1528143833286};\\\", \\\"{x:1354,y:778,t:1528143833302};\\\", \\\"{x:1356,y:784,t:1528143833318};\\\", \\\"{x:1357,y:786,t:1528143833335};\\\", \\\"{x:1359,y:790,t:1528143833352};\\\", \\\"{x:1360,y:792,t:1528143833368};\\\", \\\"{x:1361,y:793,t:1528143833385};\\\", \\\"{x:1362,y:795,t:1528143833402};\\\", \\\"{x:1364,y:797,t:1528143833418};\\\", \\\"{x:1367,y:800,t:1528143833434};\\\", \\\"{x:1369,y:802,t:1528143833452};\\\", \\\"{x:1370,y:803,t:1528143833467};\\\", \\\"{x:1371,y:804,t:1528143833484};\\\", \\\"{x:1372,y:805,t:1528143833509};\\\", \\\"{x:1374,y:807,t:1528143833518};\\\", \\\"{x:1376,y:809,t:1528143833534};\\\", \\\"{x:1378,y:813,t:1528143833552};\\\", \\\"{x:1381,y:817,t:1528143833567};\\\", \\\"{x:1385,y:823,t:1528143833585};\\\", \\\"{x:1389,y:829,t:1528143833602};\\\", \\\"{x:1398,y:838,t:1528143833619};\\\", \\\"{x:1404,y:846,t:1528143833635};\\\", \\\"{x:1412,y:856,t:1528143833652};\\\", \\\"{x:1420,y:864,t:1528143833667};\\\", \\\"{x:1429,y:874,t:1528143833684};\\\", \\\"{x:1440,y:885,t:1528143833702};\\\", \\\"{x:1447,y:893,t:1528143833719};\\\", \\\"{x:1452,y:901,t:1528143833735};\\\", \\\"{x:1458,y:911,t:1528143833752};\\\", \\\"{x:1467,y:920,t:1528143833768};\\\", \\\"{x:1472,y:926,t:1528143833785};\\\", \\\"{x:1478,y:934,t:1528143833801};\\\", \\\"{x:1484,y:941,t:1528143833819};\\\", \\\"{x:1487,y:944,t:1528143833835};\\\", \\\"{x:1490,y:946,t:1528143833852};\\\", \\\"{x:1492,y:947,t:1528143833869};\\\", \\\"{x:1492,y:948,t:1528143833918};\\\", \\\"{x:1493,y:948,t:1528143833950};\\\", \\\"{x:1494,y:950,t:1528143833974};\\\", \\\"{x:1495,y:950,t:1528143833984};\\\", \\\"{x:1495,y:951,t:1528143834013};\\\", \\\"{x:1496,y:951,t:1528143834094};\\\", \\\"{x:1497,y:951,t:1528143834125};\\\", \\\"{x:1498,y:951,t:1528143834150};\\\", \\\"{x:1499,y:951,t:1528143834157};\\\", \\\"{x:1500,y:949,t:1528143834173};\\\", \\\"{x:1499,y:944,t:1528143834186};\\\", \\\"{x:1494,y:935,t:1528143834202};\\\", \\\"{x:1490,y:929,t:1528143834219};\\\", \\\"{x:1486,y:923,t:1528143834236};\\\", \\\"{x:1474,y:904,t:1528143834252};\\\", \\\"{x:1458,y:883,t:1528143834269};\\\", \\\"{x:1439,y:857,t:1528143834286};\\\", \\\"{x:1428,y:844,t:1528143834302};\\\", \\\"{x:1412,y:830,t:1528143834319};\\\", \\\"{x:1398,y:816,t:1528143834336};\\\", \\\"{x:1384,y:803,t:1528143834352};\\\", \\\"{x:1376,y:797,t:1528143834368};\\\", \\\"{x:1372,y:794,t:1528143834385};\\\", \\\"{x:1368,y:791,t:1528143834401};\\\", \\\"{x:1365,y:788,t:1528143834418};\\\", \\\"{x:1361,y:785,t:1528143834435};\\\", \\\"{x:1359,y:784,t:1528143834452};\\\", \\\"{x:1358,y:783,t:1528143834501};\\\", \\\"{x:1358,y:786,t:1528143834678};\\\", \\\"{x:1358,y:789,t:1528143834686};\\\", \\\"{x:1359,y:795,t:1528143834703};\\\", \\\"{x:1361,y:801,t:1528143834719};\\\", \\\"{x:1363,y:807,t:1528143834736};\\\", \\\"{x:1364,y:811,t:1528143834753};\\\", \\\"{x:1365,y:815,t:1528143834769};\\\", \\\"{x:1367,y:822,t:1528143834786};\\\", \\\"{x:1369,y:827,t:1528143834803};\\\", \\\"{x:1371,y:833,t:1528143834819};\\\", \\\"{x:1373,y:838,t:1528143834836};\\\", \\\"{x:1376,y:844,t:1528143834853};\\\", \\\"{x:1379,y:852,t:1528143834870};\\\", \\\"{x:1385,y:867,t:1528143834886};\\\", \\\"{x:1392,y:878,t:1528143834903};\\\", \\\"{x:1396,y:884,t:1528143834919};\\\", \\\"{x:1400,y:888,t:1528143834936};\\\", \\\"{x:1402,y:893,t:1528143834953};\\\", \\\"{x:1403,y:897,t:1528143834970};\\\", \\\"{x:1405,y:901,t:1528143834986};\\\", \\\"{x:1408,y:906,t:1528143835003};\\\", \\\"{x:1410,y:911,t:1528143835020};\\\", \\\"{x:1412,y:917,t:1528143835036};\\\", \\\"{x:1416,y:927,t:1528143835053};\\\", \\\"{x:1423,y:935,t:1528143835070};\\\", \\\"{x:1425,y:939,t:1528143835086};\\\", \\\"{x:1429,y:943,t:1528143835103};\\\", \\\"{x:1431,y:948,t:1528143835120};\\\", \\\"{x:1435,y:952,t:1528143835136};\\\", \\\"{x:1435,y:955,t:1528143835153};\\\", \\\"{x:1437,y:957,t:1528143835170};\\\", \\\"{x:1440,y:964,t:1528143835187};\\\", \\\"{x:1444,y:971,t:1528143835204};\\\", \\\"{x:1446,y:974,t:1528143835220};\\\", \\\"{x:1447,y:976,t:1528143835236};\\\", \\\"{x:1448,y:976,t:1528143835382};\\\", \\\"{x:1448,y:974,t:1528143835390};\\\", \\\"{x:1448,y:970,t:1528143835403};\\\", \\\"{x:1448,y:967,t:1528143835420};\\\", \\\"{x:1448,y:965,t:1528143835437};\\\", \\\"{x:1448,y:963,t:1528143835453};\\\", \\\"{x:1446,y:959,t:1528143835470};\\\", \\\"{x:1446,y:957,t:1528143835487};\\\", \\\"{x:1445,y:956,t:1528143835503};\\\", \\\"{x:1443,y:953,t:1528143835520};\\\", \\\"{x:1442,y:952,t:1528143835537};\\\", \\\"{x:1441,y:951,t:1528143835566};\\\", \\\"{x:1439,y:950,t:1528143835686};\\\", \\\"{x:1439,y:948,t:1528143835703};\\\", \\\"{x:1437,y:945,t:1528143835720};\\\", \\\"{x:1434,y:938,t:1528143835737};\\\", \\\"{x:1427,y:929,t:1528143835753};\\\", \\\"{x:1414,y:908,t:1528143835770};\\\", \\\"{x:1390,y:867,t:1528143835787};\\\", \\\"{x:1347,y:806,t:1528143835803};\\\", \\\"{x:1292,y:737,t:1528143835820};\\\", \\\"{x:1233,y:680,t:1528143835837};\\\", \\\"{x:1142,y:613,t:1528143835854};\\\", \\\"{x:1080,y:577,t:1528143835869};\\\", \\\"{x:1025,y:547,t:1528143835887};\\\", \\\"{x:977,y:519,t:1528143835904};\\\", \\\"{x:937,y:500,t:1528143835921};\\\", \\\"{x:916,y:491,t:1528143835936};\\\", \\\"{x:907,y:490,t:1528143835954};\\\", \\\"{x:902,y:489,t:1528143835969};\\\", \\\"{x:901,y:488,t:1528143835986};\\\", \\\"{x:899,y:488,t:1528143836004};\\\", \\\"{x:896,y:488,t:1528143836019};\\\", \\\"{x:892,y:488,t:1528143836037};\\\", \\\"{x:883,y:488,t:1528143836053};\\\", \\\"{x:878,y:488,t:1528143836069};\\\", \\\"{x:870,y:490,t:1528143836087};\\\", \\\"{x:861,y:492,t:1528143836104};\\\", \\\"{x:856,y:492,t:1528143836121};\\\", \\\"{x:852,y:492,t:1528143836136};\\\", \\\"{x:851,y:492,t:1528143836153};\\\", \\\"{x:850,y:493,t:1528143836170};\\\", \\\"{x:850,y:494,t:1528143836186};\\\", \\\"{x:851,y:500,t:1528143836203};\\\", \\\"{x:867,y:507,t:1528143836221};\\\", \\\"{x:887,y:516,t:1528143836238};\\\", \\\"{x:922,y:524,t:1528143836253};\\\", \\\"{x:951,y:528,t:1528143836271};\\\", \\\"{x:981,y:530,t:1528143836286};\\\", \\\"{x:1020,y:530,t:1528143836304};\\\", \\\"{x:1062,y:530,t:1528143836321};\\\", \\\"{x:1109,y:526,t:1528143836337};\\\", \\\"{x:1160,y:519,t:1528143836353};\\\", \\\"{x:1201,y:509,t:1528143836371};\\\", \\\"{x:1231,y:496,t:1528143836386};\\\", \\\"{x:1245,y:487,t:1528143836403};\\\", \\\"{x:1251,y:481,t:1528143836421};\\\", \\\"{x:1253,y:479,t:1528143836437};\\\", \\\"{x:1253,y:495,t:1528143836526};\\\", \\\"{x:1258,y:527,t:1528143836537};\\\", \\\"{x:1270,y:600,t:1528143836554};\\\", \\\"{x:1288,y:669,t:1528143836571};\\\", \\\"{x:1304,y:717,t:1528143836588};\\\", \\\"{x:1317,y:753,t:1528143836604};\\\", \\\"{x:1328,y:774,t:1528143836621};\\\", \\\"{x:1337,y:784,t:1528143836637};\\\", \\\"{x:1337,y:778,t:1528143836765};\\\", \\\"{x:1336,y:765,t:1528143836773};\\\", \\\"{x:1329,y:745,t:1528143836787};\\\", \\\"{x:1312,y:692,t:1528143836803};\\\", \\\"{x:1283,y:630,t:1528143836820};\\\", \\\"{x:1258,y:587,t:1528143836837};\\\", \\\"{x:1253,y:581,t:1528143836854};\\\", \\\"{x:1250,y:576,t:1528143836871};\\\", \\\"{x:1248,y:572,t:1528143836887};\\\", \\\"{x:1242,y:565,t:1528143836904};\\\", \\\"{x:1236,y:555,t:1528143836921};\\\", \\\"{x:1233,y:551,t:1528143836938};\\\", \\\"{x:1232,y:550,t:1528143836958};\\\", \\\"{x:1236,y:553,t:1528143837014};\\\", \\\"{x:1242,y:555,t:1528143837021};\\\", \\\"{x:1258,y:563,t:1528143837038};\\\", \\\"{x:1266,y:565,t:1528143837056};\\\", \\\"{x:1267,y:566,t:1528143837071};\\\", \\\"{x:1266,y:566,t:1528143837158};\\\", \\\"{x:1262,y:564,t:1528143837171};\\\", \\\"{x:1260,y:563,t:1528143837188};\\\", \\\"{x:1258,y:562,t:1528143837204};\\\", \\\"{x:1257,y:562,t:1528143837221};\\\", \\\"{x:1257,y:561,t:1528143837317};\\\", \\\"{x:1257,y:560,t:1528143837333};\\\", \\\"{x:1260,y:560,t:1528143837349};\\\", \\\"{x:1263,y:560,t:1528143837358};\\\", \\\"{x:1265,y:561,t:1528143837372};\\\", \\\"{x:1271,y:564,t:1528143837388};\\\", \\\"{x:1275,y:565,t:1528143837405};\\\", \\\"{x:1279,y:567,t:1528143837422};\\\", \\\"{x:1279,y:568,t:1528143837437};\\\", \\\"{x:1279,y:575,t:1528143837639};\\\", \\\"{x:1271,y:608,t:1528143837655};\\\", \\\"{x:1254,y:666,t:1528143837672};\\\", \\\"{x:1237,y:728,t:1528143837688};\\\", \\\"{x:1227,y:787,t:1528143837705};\\\", \\\"{x:1213,y:837,t:1528143837722};\\\", \\\"{x:1203,y:875,t:1528143837738};\\\", \\\"{x:1184,y:908,t:1528143837756};\\\", \\\"{x:1172,y:923,t:1528143837772};\\\", \\\"{x:1169,y:928,t:1528143837788};\\\", \\\"{x:1169,y:929,t:1528143837805};\\\", \\\"{x:1169,y:923,t:1528143837886};\\\", \\\"{x:1169,y:911,t:1528143837894};\\\", \\\"{x:1169,y:900,t:1528143837905};\\\", \\\"{x:1164,y:878,t:1528143837922};\\\", \\\"{x:1161,y:856,t:1528143837939};\\\", \\\"{x:1160,y:839,t:1528143837955};\\\", \\\"{x:1159,y:820,t:1528143837972};\\\", \\\"{x:1158,y:802,t:1528143837989};\\\", \\\"{x:1155,y:778,t:1528143838005};\\\", \\\"{x:1153,y:769,t:1528143838021};\\\", \\\"{x:1153,y:766,t:1528143838039};\\\", \\\"{x:1152,y:765,t:1528143838055};\\\", \\\"{x:1153,y:765,t:1528143838294};\\\", \\\"{x:1154,y:765,t:1528143838309};\\\", \\\"{x:1155,y:765,t:1528143838322};\\\", \\\"{x:1157,y:765,t:1528143838339};\\\", \\\"{x:1158,y:767,t:1528143838356};\\\", \\\"{x:1159,y:768,t:1528143838406};\\\", \\\"{x:1160,y:768,t:1528143838550};\\\", \\\"{x:1161,y:768,t:1528143838558};\\\", \\\"{x:1161,y:769,t:1528143838573};\\\", \\\"{x:1164,y:770,t:1528143838589};\\\", \\\"{x:1169,y:773,t:1528143838606};\\\", \\\"{x:1171,y:773,t:1528143838623};\\\", \\\"{x:1172,y:773,t:1528143838638};\\\", \\\"{x:1175,y:775,t:1528143838656};\\\", \\\"{x:1176,y:775,t:1528143838677};\\\", \\\"{x:1177,y:775,t:1528143839477};\\\", \\\"{x:1178,y:776,t:1528143839489};\\\", \\\"{x:1185,y:779,t:1528143839507};\\\", \\\"{x:1189,y:781,t:1528143839522};\\\", \\\"{x:1193,y:783,t:1528143839540};\\\", \\\"{x:1195,y:784,t:1528143839556};\\\", \\\"{x:1196,y:784,t:1528143839572};\\\", \\\"{x:1197,y:784,t:1528143839590};\\\", \\\"{x:1200,y:786,t:1528143839606};\\\", \\\"{x:1202,y:787,t:1528143839629};\\\", \\\"{x:1203,y:787,t:1528143839653};\\\", \\\"{x:1204,y:787,t:1528143839661};\\\", \\\"{x:1205,y:788,t:1528143839677};\\\", \\\"{x:1206,y:788,t:1528143839701};\\\", \\\"{x:1206,y:789,t:1528143839734};\\\", \\\"{x:1207,y:790,t:1528143839741};\\\", \\\"{x:1209,y:794,t:1528143839757};\\\", \\\"{x:1214,y:808,t:1528143839774};\\\", \\\"{x:1216,y:820,t:1528143839790};\\\", \\\"{x:1220,y:830,t:1528143839808};\\\", \\\"{x:1222,y:839,t:1528143839825};\\\", \\\"{x:1224,y:844,t:1528143839840};\\\", \\\"{x:1224,y:847,t:1528143839857};\\\", \\\"{x:1224,y:850,t:1528143839874};\\\", \\\"{x:1225,y:851,t:1528143839890};\\\", \\\"{x:1225,y:852,t:1528143839907};\\\", \\\"{x:1225,y:853,t:1528143839950};\\\", \\\"{x:1225,y:850,t:1528143839999};\\\", \\\"{x:1225,y:846,t:1528143840007};\\\", \\\"{x:1225,y:839,t:1528143840024};\\\", \\\"{x:1225,y:838,t:1528143840040};\\\", \\\"{x:1225,y:837,t:1528143840057};\\\", \\\"{x:1224,y:836,t:1528143840075};\\\", \\\"{x:1224,y:835,t:1528143840090};\\\", \\\"{x:1223,y:834,t:1528143840286};\\\", \\\"{x:1223,y:835,t:1528143840383};\\\", \\\"{x:1225,y:836,t:1528143840392};\\\", \\\"{x:1231,y:836,t:1528143840407};\\\", \\\"{x:1240,y:829,t:1528143840424};\\\", \\\"{x:1255,y:814,t:1528143840441};\\\", \\\"{x:1269,y:797,t:1528143840457};\\\", \\\"{x:1284,y:785,t:1528143840474};\\\", \\\"{x:1294,y:779,t:1528143840492};\\\", \\\"{x:1300,y:776,t:1528143840507};\\\", \\\"{x:1303,y:775,t:1528143840524};\\\", \\\"{x:1303,y:773,t:1528143840541};\\\", \\\"{x:1304,y:771,t:1528143840558};\\\", \\\"{x:1306,y:767,t:1528143840574};\\\", \\\"{x:1306,y:763,t:1528143840592};\\\", \\\"{x:1306,y:759,t:1528143840609};\\\", \\\"{x:1307,y:754,t:1528143840624};\\\", \\\"{x:1307,y:746,t:1528143840642};\\\", \\\"{x:1307,y:735,t:1528143840658};\\\", \\\"{x:1307,y:726,t:1528143840675};\\\", \\\"{x:1307,y:723,t:1528143840691};\\\", \\\"{x:1307,y:722,t:1528143840709};\\\", \\\"{x:1307,y:721,t:1528143840775};\\\", \\\"{x:1309,y:718,t:1528143840791};\\\", \\\"{x:1311,y:715,t:1528143840808};\\\", \\\"{x:1315,y:712,t:1528143840824};\\\", \\\"{x:1320,y:709,t:1528143840842};\\\", \\\"{x:1323,y:706,t:1528143840858};\\\", \\\"{x:1324,y:706,t:1528143840874};\\\", \\\"{x:1326,y:705,t:1528143840892};\\\", \\\"{x:1327,y:704,t:1528143840908};\\\", \\\"{x:1327,y:710,t:1528143840982};\\\", \\\"{x:1322,y:722,t:1528143840991};\\\", \\\"{x:1309,y:748,t:1528143841009};\\\", \\\"{x:1290,y:780,t:1528143841025};\\\", \\\"{x:1271,y:809,t:1528143841041};\\\", \\\"{x:1255,y:830,t:1528143841058};\\\", \\\"{x:1239,y:850,t:1528143841075};\\\", \\\"{x:1228,y:867,t:1528143841091};\\\", \\\"{x:1223,y:884,t:1528143841108};\\\", \\\"{x:1220,y:897,t:1528143841126};\\\", \\\"{x:1219,y:908,t:1528143841141};\\\", \\\"{x:1218,y:924,t:1528143841158};\\\", \\\"{x:1218,y:931,t:1528143841175};\\\", \\\"{x:1218,y:938,t:1528143841191};\\\", \\\"{x:1218,y:943,t:1528143841208};\\\", \\\"{x:1218,y:946,t:1528143841225};\\\", \\\"{x:1218,y:951,t:1528143841242};\\\", \\\"{x:1219,y:958,t:1528143841259};\\\", \\\"{x:1219,y:961,t:1528143841275};\\\", \\\"{x:1220,y:965,t:1528143841291};\\\", \\\"{x:1220,y:968,t:1528143841308};\\\", \\\"{x:1222,y:962,t:1528143841543};\\\", \\\"{x:1232,y:928,t:1528143841559};\\\", \\\"{x:1252,y:881,t:1528143841576};\\\", \\\"{x:1279,y:837,t:1528143841592};\\\", \\\"{x:1300,y:813,t:1528143841608};\\\", \\\"{x:1317,y:795,t:1528143841625};\\\", \\\"{x:1334,y:776,t:1528143841642};\\\", \\\"{x:1343,y:762,t:1528143841658};\\\", \\\"{x:1347,y:754,t:1528143841676};\\\", \\\"{x:1348,y:750,t:1528143841692};\\\", \\\"{x:1348,y:749,t:1528143841709};\\\", \\\"{x:1349,y:748,t:1528143841790};\\\", \\\"{x:1349,y:749,t:1528143841870};\\\", \\\"{x:1346,y:753,t:1528143841878};\\\", \\\"{x:1344,y:758,t:1528143841893};\\\", \\\"{x:1330,y:782,t:1528143841910};\\\", \\\"{x:1319,y:798,t:1528143841925};\\\", \\\"{x:1314,y:805,t:1528143841942};\\\", \\\"{x:1313,y:807,t:1528143841959};\\\", \\\"{x:1312,y:808,t:1528143841998};\\\", \\\"{x:1311,y:808,t:1528143842010};\\\", \\\"{x:1308,y:811,t:1528143842026};\\\", \\\"{x:1307,y:813,t:1528143842042};\\\", \\\"{x:1305,y:815,t:1528143842059};\\\", \\\"{x:1302,y:819,t:1528143842076};\\\", \\\"{x:1297,y:824,t:1528143842093};\\\", \\\"{x:1287,y:835,t:1528143842110};\\\", \\\"{x:1278,y:845,t:1528143842125};\\\", \\\"{x:1274,y:850,t:1528143842142};\\\", \\\"{x:1269,y:857,t:1528143842159};\\\", \\\"{x:1265,y:863,t:1528143842175};\\\", \\\"{x:1261,y:868,t:1528143842192};\\\", \\\"{x:1260,y:870,t:1528143842209};\\\", \\\"{x:1258,y:876,t:1528143842227};\\\", \\\"{x:1257,y:879,t:1528143842242};\\\", \\\"{x:1256,y:885,t:1528143842260};\\\", \\\"{x:1253,y:892,t:1528143842276};\\\", \\\"{x:1250,y:899,t:1528143842293};\\\", \\\"{x:1247,y:910,t:1528143842310};\\\", \\\"{x:1244,y:918,t:1528143842326};\\\", \\\"{x:1243,y:923,t:1528143842343};\\\", \\\"{x:1240,y:931,t:1528143842360};\\\", \\\"{x:1239,y:935,t:1528143842377};\\\", \\\"{x:1236,y:940,t:1528143842392};\\\", \\\"{x:1236,y:942,t:1528143842410};\\\", \\\"{x:1235,y:943,t:1528143842427};\\\", \\\"{x:1234,y:943,t:1528143842550};\\\", \\\"{x:1231,y:940,t:1528143842560};\\\", \\\"{x:1221,y:914,t:1528143842576};\\\", \\\"{x:1210,y:889,t:1528143842592};\\\", \\\"{x:1204,y:874,t:1528143842610};\\\", \\\"{x:1201,y:872,t:1528143842627};\\\", \\\"{x:1201,y:871,t:1528143842654};\\\", \\\"{x:1201,y:870,t:1528143842742};\\\", \\\"{x:1201,y:869,t:1528143842759};\\\", \\\"{x:1199,y:865,t:1528143842776};\\\", \\\"{x:1196,y:862,t:1528143842793};\\\", \\\"{x:1192,y:856,t:1528143842810};\\\", \\\"{x:1183,y:846,t:1528143842827};\\\", \\\"{x:1171,y:829,t:1528143842843};\\\", \\\"{x:1141,y:802,t:1528143842861};\\\", \\\"{x:1095,y:768,t:1528143842876};\\\", \\\"{x:1010,y:716,t:1528143842893};\\\", \\\"{x:952,y:692,t:1528143842910};\\\", \\\"{x:897,y:676,t:1528143842926};\\\", \\\"{x:846,y:660,t:1528143842943};\\\", \\\"{x:790,y:643,t:1528143842960};\\\", \\\"{x:736,y:625,t:1528143842978};\\\", \\\"{x:673,y:597,t:1528143842993};\\\", \\\"{x:607,y:568,t:1528143843009};\\\", \\\"{x:528,y:526,t:1528143843026};\\\", \\\"{x:455,y:491,t:1528143843043};\\\", \\\"{x:396,y:470,t:1528143843059};\\\", \\\"{x:354,y:465,t:1528143843076};\\\", \\\"{x:334,y:465,t:1528143843093};\\\", \\\"{x:330,y:465,t:1528143843109};\\\", \\\"{x:330,y:476,t:1528143843126};\\\", \\\"{x:332,y:495,t:1528143843143};\\\", \\\"{x:347,y:530,t:1528143843161};\\\", \\\"{x:371,y:578,t:1528143843177};\\\", \\\"{x:399,y:630,t:1528143843194};\\\", \\\"{x:435,y:685,t:1528143843209};\\\", \\\"{x:472,y:733,t:1528143843227};\\\", \\\"{x:511,y:768,t:1528143843243};\\\", \\\"{x:536,y:781,t:1528143843259};\\\", \\\"{x:557,y:789,t:1528143843276};\\\", \\\"{x:587,y:794,t:1528143843293};\\\", \\\"{x:600,y:796,t:1528143843309};\\\", \\\"{x:608,y:799,t:1528143843325};\\\", \\\"{x:609,y:799,t:1528143843342};\\\", \\\"{x:610,y:799,t:1528143843373};\\\", \\\"{x:610,y:795,t:1528143843389};\\\", \\\"{x:608,y:786,t:1528143843397};\\\", \\\"{x:605,y:779,t:1528143843409};\\\", \\\"{x:590,y:751,t:1528143843426};\\\", \\\"{x:573,y:727,t:1528143843442};\\\", \\\"{x:564,y:718,t:1528143843459};\\\", \\\"{x:560,y:715,t:1528143843475};\\\", \\\"{x:550,y:712,t:1528143843492};\\\", \\\"{x:543,y:711,t:1528143843509};\\\", \\\"{x:541,y:710,t:1528143843526};\\\", \\\"{x:540,y:710,t:1528143843629};\\\", \\\"{x:539,y:710,t:1528143843643};\\\", \\\"{x:536,y:713,t:1528143843659};\\\", \\\"{x:533,y:722,t:1528143843676};\\\", \\\"{x:531,y:727,t:1528143843692};\\\", \\\"{x:531,y:728,t:1528143843709};\\\", \\\"{x:531,y:729,t:1528143843733};\\\", \\\"{x:531,y:730,t:1528143843742};\\\", \\\"{x:533,y:730,t:1528143844237};\\\", \\\"{x:538,y:732,t:1528143844245};\\\", \\\"{x:543,y:734,t:1528143844260};\\\", \\\"{x:557,y:741,t:1528143844277};\\\", \\\"{x:566,y:744,t:1528143844293};\\\", \\\"{x:581,y:746,t:1528143844309};\\\", \\\"{x:607,y:745,t:1528143844327};\\\", \\\"{x:643,y:733,t:1528143844343};\\\", \\\"{x:683,y:719,t:1528143844360};\\\", \\\"{x:729,y:695,t:1528143844377};\\\", \\\"{x:783,y:667,t:1528143844393};\\\", \\\"{x:824,y:639,t:1528143844410};\\\", \\\"{x:877,y:607,t:1528143844427};\\\", \\\"{x:929,y:585,t:1528143844444};\\\", \\\"{x:974,y:564,t:1528143844460};\\\", \\\"{x:1031,y:520,t:1528143844477};\\\", \\\"{x:1054,y:497,t:1528143844493};\\\", \\\"{x:1067,y:484,t:1528143844510};\\\", \\\"{x:1071,y:478,t:1528143844527};\\\", \\\"{x:1073,y:475,t:1528143844544};\\\" ] }, { \\\"rt\\\": 9253, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 536501, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"TTCWS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1073,y:479,t:1528143846735};\\\", \\\"{x:1076,y:498,t:1528143846746};\\\", \\\"{x:1090,y:561,t:1528143846767};\\\", \\\"{x:1093,y:577,t:1528143846779};\\\", \\\"{x:1094,y:608,t:1528143846795};\\\", \\\"{x:1094,y:632,t:1528143846812};\\\", \\\"{x:1099,y:667,t:1528143846828};\\\", \\\"{x:1102,y:690,t:1528143846845};\\\", \\\"{x:1111,y:716,t:1528143846862};\\\", \\\"{x:1118,y:736,t:1528143846879};\\\", \\\"{x:1124,y:756,t:1528143846895};\\\", \\\"{x:1132,y:770,t:1528143846912};\\\", \\\"{x:1138,y:786,t:1528143846929};\\\", \\\"{x:1149,y:801,t:1528143846945};\\\", \\\"{x:1162,y:813,t:1528143846962};\\\", \\\"{x:1174,y:820,t:1528143846979};\\\", \\\"{x:1186,y:825,t:1528143846995};\\\", \\\"{x:1198,y:830,t:1528143847012};\\\", \\\"{x:1220,y:835,t:1528143847029};\\\", \\\"{x:1238,y:836,t:1528143847046};\\\", \\\"{x:1252,y:836,t:1528143847062};\\\", \\\"{x:1264,y:836,t:1528143847079};\\\", \\\"{x:1276,y:827,t:1528143847096};\\\", \\\"{x:1281,y:814,t:1528143847112};\\\", \\\"{x:1282,y:794,t:1528143847129};\\\", \\\"{x:1283,y:770,t:1528143847146};\\\", \\\"{x:1281,y:745,t:1528143847162};\\\", \\\"{x:1275,y:726,t:1528143847179};\\\", \\\"{x:1272,y:711,t:1528143847197};\\\", \\\"{x:1268,y:696,t:1528143847213};\\\", \\\"{x:1260,y:679,t:1528143847230};\\\", \\\"{x:1255,y:670,t:1528143847247};\\\", \\\"{x:1254,y:667,t:1528143847262};\\\", \\\"{x:1255,y:666,t:1528143847374};\\\", \\\"{x:1261,y:666,t:1528143847382};\\\", \\\"{x:1270,y:668,t:1528143847397};\\\", \\\"{x:1299,y:678,t:1528143847413};\\\", \\\"{x:1321,y:684,t:1528143847430};\\\", \\\"{x:1349,y:692,t:1528143847449};\\\", \\\"{x:1376,y:699,t:1528143847463};\\\", \\\"{x:1393,y:703,t:1528143847479};\\\", \\\"{x:1399,y:703,t:1528143847496};\\\", \\\"{x:1395,y:703,t:1528143847670};\\\", \\\"{x:1387,y:703,t:1528143847680};\\\", \\\"{x:1364,y:703,t:1528143847696};\\\", \\\"{x:1345,y:703,t:1528143847714};\\\", \\\"{x:1333,y:703,t:1528143847730};\\\", \\\"{x:1328,y:702,t:1528143847747};\\\", \\\"{x:1325,y:701,t:1528143847763};\\\", \\\"{x:1326,y:701,t:1528143847894};\\\", \\\"{x:1330,y:702,t:1528143847902};\\\", \\\"{x:1333,y:707,t:1528143847913};\\\", \\\"{x:1339,y:714,t:1528143847931};\\\", \\\"{x:1343,y:719,t:1528143847947};\\\", \\\"{x:1349,y:725,t:1528143847963};\\\", \\\"{x:1353,y:731,t:1528143847981};\\\", \\\"{x:1354,y:733,t:1528143847997};\\\", \\\"{x:1356,y:736,t:1528143848014};\\\", \\\"{x:1357,y:739,t:1528143848030};\\\", \\\"{x:1358,y:742,t:1528143848047};\\\", \\\"{x:1361,y:750,t:1528143848064};\\\", \\\"{x:1364,y:755,t:1528143848081};\\\", \\\"{x:1367,y:761,t:1528143848097};\\\", \\\"{x:1367,y:767,t:1528143848114};\\\", \\\"{x:1369,y:771,t:1528143848130};\\\", \\\"{x:1372,y:779,t:1528143848147};\\\", \\\"{x:1373,y:788,t:1528143848164};\\\", \\\"{x:1375,y:791,t:1528143848181};\\\", \\\"{x:1375,y:794,t:1528143848197};\\\", \\\"{x:1377,y:797,t:1528143848214};\\\", \\\"{x:1378,y:799,t:1528143848231};\\\", \\\"{x:1379,y:801,t:1528143848247};\\\", \\\"{x:1382,y:807,t:1528143848264};\\\", \\\"{x:1386,y:813,t:1528143848281};\\\", \\\"{x:1388,y:817,t:1528143848297};\\\", \\\"{x:1392,y:823,t:1528143848314};\\\", \\\"{x:1397,y:830,t:1528143848331};\\\", \\\"{x:1404,y:838,t:1528143848347};\\\", \\\"{x:1408,y:848,t:1528143848364};\\\", \\\"{x:1418,y:859,t:1528143848381};\\\", \\\"{x:1430,y:874,t:1528143848397};\\\", \\\"{x:1435,y:879,t:1528143848414};\\\", \\\"{x:1438,y:882,t:1528143848430};\\\", \\\"{x:1440,y:887,t:1528143848447};\\\", \\\"{x:1441,y:890,t:1528143848464};\\\", \\\"{x:1446,y:897,t:1528143848481};\\\", \\\"{x:1447,y:901,t:1528143848498};\\\", \\\"{x:1448,y:904,t:1528143848513};\\\", \\\"{x:1450,y:907,t:1528143848531};\\\", \\\"{x:1451,y:909,t:1528143848548};\\\", \\\"{x:1451,y:911,t:1528143848564};\\\", \\\"{x:1452,y:915,t:1528143848580};\\\", \\\"{x:1456,y:922,t:1528143848598};\\\", \\\"{x:1458,y:927,t:1528143848615};\\\", \\\"{x:1460,y:932,t:1528143848631};\\\", \\\"{x:1462,y:936,t:1528143848647};\\\", \\\"{x:1463,y:940,t:1528143848664};\\\", \\\"{x:1464,y:943,t:1528143848681};\\\", \\\"{x:1466,y:945,t:1528143848698};\\\", \\\"{x:1467,y:948,t:1528143848715};\\\", \\\"{x:1467,y:949,t:1528143848731};\\\", \\\"{x:1467,y:950,t:1528143848750};\\\", \\\"{x:1468,y:951,t:1528143848765};\\\", \\\"{x:1470,y:953,t:1528143848781};\\\", \\\"{x:1470,y:954,t:1528143848806};\\\", \\\"{x:1471,y:955,t:1528143848862};\\\", \\\"{x:1475,y:959,t:1528143848870};\\\", \\\"{x:1481,y:965,t:1528143848881};\\\", \\\"{x:1495,y:976,t:1528143848898};\\\", \\\"{x:1500,y:981,t:1528143848915};\\\", \\\"{x:1501,y:982,t:1528143848931};\\\", \\\"{x:1499,y:982,t:1528143849142};\\\", \\\"{x:1495,y:982,t:1528143849150};\\\", \\\"{x:1487,y:978,t:1528143849165};\\\", \\\"{x:1477,y:976,t:1528143849182};\\\", \\\"{x:1474,y:975,t:1528143849198};\\\", \\\"{x:1473,y:974,t:1528143849214};\\\", \\\"{x:1471,y:974,t:1528143849310};\\\", \\\"{x:1471,y:973,t:1528143849510};\\\", \\\"{x:1471,y:972,t:1528143849534};\\\", \\\"{x:1472,y:971,t:1528143849558};\\\", \\\"{x:1473,y:970,t:1528143849670};\\\", \\\"{x:1474,y:969,t:1528143849685};\\\", \\\"{x:1475,y:968,t:1528143849699};\\\", \\\"{x:1477,y:966,t:1528143849716};\\\", \\\"{x:1477,y:965,t:1528143849732};\\\", \\\"{x:1478,y:964,t:1528143849749};\\\", \\\"{x:1478,y:962,t:1528143850343};\\\", \\\"{x:1476,y:953,t:1528143850350};\\\", \\\"{x:1460,y:932,t:1528143850366};\\\", \\\"{x:1412,y:888,t:1528143850381};\\\", \\\"{x:1319,y:809,t:1528143850398};\\\", \\\"{x:1171,y:695,t:1528143850415};\\\", \\\"{x:968,y:584,t:1528143850432};\\\", \\\"{x:735,y:496,t:1528143850450};\\\", \\\"{x:516,y:447,t:1528143850466};\\\", \\\"{x:341,y:423,t:1528143850481};\\\", \\\"{x:204,y:410,t:1528143850498};\\\", \\\"{x:136,y:407,t:1528143850515};\\\", \\\"{x:114,y:405,t:1528143850532};\\\", \\\"{x:110,y:404,t:1528143850548};\\\", \\\"{x:113,y:406,t:1528143850661};\\\", \\\"{x:119,y:413,t:1528143850670};\\\", \\\"{x:128,y:427,t:1528143850682};\\\", \\\"{x:156,y:464,t:1528143850699};\\\", \\\"{x:181,y:500,t:1528143850716};\\\", \\\"{x:196,y:521,t:1528143850732};\\\", \\\"{x:213,y:539,t:1528143850748};\\\", \\\"{x:234,y:565,t:1528143850765};\\\", \\\"{x:256,y:581,t:1528143850782};\\\", \\\"{x:264,y:586,t:1528143850798};\\\", \\\"{x:268,y:588,t:1528143850815};\\\", \\\"{x:269,y:588,t:1528143850832};\\\", \\\"{x:273,y:588,t:1528143850849};\\\", \\\"{x:274,y:588,t:1528143850865};\\\", \\\"{x:279,y:588,t:1528143850882};\\\", \\\"{x:284,y:588,t:1528143850898};\\\", \\\"{x:291,y:588,t:1528143850915};\\\", \\\"{x:299,y:586,t:1528143850932};\\\", \\\"{x:308,y:581,t:1528143850948};\\\", \\\"{x:327,y:575,t:1528143850965};\\\", \\\"{x:339,y:573,t:1528143850982};\\\", \\\"{x:353,y:573,t:1528143850998};\\\", \\\"{x:368,y:573,t:1528143851015};\\\", \\\"{x:385,y:573,t:1528143851032};\\\", \\\"{x:405,y:573,t:1528143851048};\\\", \\\"{x:422,y:573,t:1528143851066};\\\", \\\"{x:439,y:572,t:1528143851082};\\\", \\\"{x:453,y:572,t:1528143851100};\\\", \\\"{x:468,y:572,t:1528143851116};\\\", \\\"{x:486,y:572,t:1528143851132};\\\", \\\"{x:503,y:570,t:1528143851150};\\\", \\\"{x:512,y:567,t:1528143851166};\\\", \\\"{x:519,y:562,t:1528143851183};\\\", \\\"{x:528,y:558,t:1528143851199};\\\", \\\"{x:535,y:552,t:1528143851216};\\\", \\\"{x:541,y:550,t:1528143851232};\\\", \\\"{x:544,y:549,t:1528143851249};\\\", \\\"{x:546,y:549,t:1528143851318};\\\", \\\"{x:548,y:549,t:1528143851333};\\\", \\\"{x:556,y:540,t:1528143851349};\\\", \\\"{x:560,y:536,t:1528143851365};\\\", \\\"{x:562,y:533,t:1528143851383};\\\", \\\"{x:565,y:530,t:1528143851399};\\\", \\\"{x:568,y:526,t:1528143851416};\\\", \\\"{x:571,y:523,t:1528143851434};\\\", \\\"{x:576,y:521,t:1528143851450};\\\", \\\"{x:584,y:517,t:1528143851468};\\\", \\\"{x:594,y:511,t:1528143851484};\\\", \\\"{x:602,y:504,t:1528143851499};\\\", \\\"{x:607,y:502,t:1528143851516};\\\", \\\"{x:608,y:502,t:1528143851532};\\\", \\\"{x:609,y:502,t:1528143851557};\\\", \\\"{x:610,y:502,t:1528143851629};\\\", \\\"{x:614,y:502,t:1528143852157};\\\", \\\"{x:623,y:514,t:1528143852166};\\\", \\\"{x:655,y:552,t:1528143852184};\\\", \\\"{x:709,y:604,t:1528143852201};\\\", \\\"{x:777,y:657,t:1528143852217};\\\", \\\"{x:878,y:712,t:1528143852233};\\\", \\\"{x:999,y:767,t:1528143852251};\\\", \\\"{x:1114,y:809,t:1528143852267};\\\", \\\"{x:1229,y:851,t:1528143852284};\\\", \\\"{x:1314,y:888,t:1528143852300};\\\", \\\"{x:1374,y:919,t:1528143852317};\\\", \\\"{x:1385,y:926,t:1528143852334};\\\", \\\"{x:1386,y:928,t:1528143852351};\\\", \\\"{x:1387,y:928,t:1528143852662};\\\", \\\"{x:1390,y:928,t:1528143852670};\\\", \\\"{x:1400,y:928,t:1528143852685};\\\", \\\"{x:1411,y:928,t:1528143852703};\\\", \\\"{x:1429,y:930,t:1528143852719};\\\", \\\"{x:1448,y:932,t:1528143852736};\\\", \\\"{x:1469,y:935,t:1528143852753};\\\", \\\"{x:1485,y:936,t:1528143852770};\\\", \\\"{x:1493,y:938,t:1528143852786};\\\", \\\"{x:1494,y:938,t:1528143852803};\\\", \\\"{x:1495,y:938,t:1528143852820};\\\", \\\"{x:1496,y:939,t:1528143853406};\\\", \\\"{x:1494,y:946,t:1528143853422};\\\", \\\"{x:1492,y:949,t:1528143853439};\\\", \\\"{x:1488,y:954,t:1528143853456};\\\", \\\"{x:1485,y:956,t:1528143853472};\\\", \\\"{x:1482,y:959,t:1528143853490};\\\", \\\"{x:1481,y:959,t:1528143853506};\\\", \\\"{x:1480,y:959,t:1528143853598};\\\", \\\"{x:1479,y:959,t:1528143853605};\\\", \\\"{x:1474,y:959,t:1528143853624};\\\", \\\"{x:1453,y:959,t:1528143853640};\\\", \\\"{x:1394,y:937,t:1528143853657};\\\", \\\"{x:1267,y:879,t:1528143853673};\\\", \\\"{x:1106,y:805,t:1528143853689};\\\", \\\"{x:932,y:755,t:1528143853706};\\\", \\\"{x:755,y:723,t:1528143853723};\\\", \\\"{x:602,y:714,t:1528143853739};\\\", \\\"{x:510,y:714,t:1528143853756};\\\", \\\"{x:459,y:714,t:1528143853773};\\\", \\\"{x:451,y:714,t:1528143853789};\\\", \\\"{x:452,y:715,t:1528143854038};\\\", \\\"{x:454,y:716,t:1528143854046};\\\", \\\"{x:458,y:717,t:1528143854058};\\\", \\\"{x:460,y:718,t:1528143854075};\\\", \\\"{x:463,y:719,t:1528143854091};\\\", \\\"{x:466,y:721,t:1528143854108};\\\", \\\"{x:468,y:721,t:1528143854124};\\\", \\\"{x:469,y:722,t:1528143854141};\\\", \\\"{x:470,y:722,t:1528143854173};\\\", \\\"{x:471,y:722,t:1528143854182};\\\", \\\"{x:476,y:725,t:1528143854198};\\\", \\\"{x:479,y:726,t:1528143854215};\\\", \\\"{x:484,y:728,t:1528143854232};\\\", \\\"{x:487,y:729,t:1528143854248};\\\", \\\"{x:489,y:730,t:1528143854265};\\\", \\\"{x:490,y:730,t:1528143854283};\\\", \\\"{x:497,y:734,t:1528143854298};\\\", \\\"{x:508,y:738,t:1528143854315};\\\", \\\"{x:511,y:739,t:1528143854326};\\\", \\\"{x:513,y:740,t:1528143854349};\\\", \\\"{x:513,y:740,t:1528143854593};\\\" ] }, { \\\"rt\\\": 14383, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 552107, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"TTCWS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-M -L -11 AM-12 PM-M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:748,t:1528143860513};\\\", \\\"{x:576,y:818,t:1528143860528};\\\", \\\"{x:667,y:898,t:1528143860543};\\\", \\\"{x:765,y:967,t:1528143860560};\\\", \\\"{x:857,y:1015,t:1528143860576};\\\", \\\"{x:958,y:1053,t:1528143860593};\\\", \\\"{x:1058,y:1081,t:1528143860610};\\\", \\\"{x:1139,y:1096,t:1528143860626};\\\", \\\"{x:1196,y:1107,t:1528143860642};\\\", \\\"{x:1224,y:1107,t:1528143860659};\\\", \\\"{x:1230,y:1107,t:1528143860677};\\\", \\\"{x:1231,y:1106,t:1528143860693};\\\", \\\"{x:1231,y:1102,t:1528143860747};\\\", \\\"{x:1231,y:1096,t:1528143860760};\\\", \\\"{x:1229,y:1086,t:1528143860777};\\\", \\\"{x:1225,y:1073,t:1528143860793};\\\", \\\"{x:1223,y:1063,t:1528143860809};\\\", \\\"{x:1223,y:1058,t:1528143860827};\\\", \\\"{x:1223,y:1055,t:1528143860843};\\\", \\\"{x:1227,y:1048,t:1528143860860};\\\", \\\"{x:1236,y:1037,t:1528143860876};\\\", \\\"{x:1244,y:1027,t:1528143860893};\\\", \\\"{x:1251,y:1018,t:1528143860909};\\\", \\\"{x:1260,y:1012,t:1528143860927};\\\", \\\"{x:1271,y:1004,t:1528143860943};\\\", \\\"{x:1286,y:997,t:1528143860960};\\\", \\\"{x:1294,y:992,t:1528143860977};\\\", \\\"{x:1301,y:988,t:1528143860993};\\\", \\\"{x:1306,y:984,t:1528143861010};\\\", \\\"{x:1311,y:981,t:1528143861027};\\\", \\\"{x:1318,y:977,t:1528143861044};\\\", \\\"{x:1328,y:972,t:1528143861061};\\\", \\\"{x:1340,y:969,t:1528143861077};\\\", \\\"{x:1350,y:963,t:1528143861095};\\\", \\\"{x:1352,y:962,t:1528143861111};\\\", \\\"{x:1352,y:961,t:1528143861425};\\\", \\\"{x:1349,y:961,t:1528143861440};\\\", \\\"{x:1348,y:961,t:1528143861449};\\\", \\\"{x:1345,y:961,t:1528143861460};\\\", \\\"{x:1338,y:963,t:1528143861478};\\\", \\\"{x:1336,y:963,t:1528143861494};\\\", \\\"{x:1333,y:963,t:1528143861511};\\\", \\\"{x:1333,y:964,t:1528143861527};\\\", \\\"{x:1332,y:964,t:1528143862177};\\\", \\\"{x:1332,y:963,t:1528143862201};\\\", \\\"{x:1334,y:961,t:1528143862212};\\\", \\\"{x:1337,y:957,t:1528143862229};\\\", \\\"{x:1339,y:955,t:1528143862244};\\\", \\\"{x:1340,y:954,t:1528143862313};\\\", \\\"{x:1338,y:957,t:1528143862561};\\\", \\\"{x:1335,y:961,t:1528143862579};\\\", \\\"{x:1331,y:965,t:1528143862596};\\\", \\\"{x:1328,y:968,t:1528143862611};\\\", \\\"{x:1326,y:970,t:1528143862628};\\\", \\\"{x:1326,y:965,t:1528143863241};\\\", \\\"{x:1327,y:962,t:1528143863249};\\\", \\\"{x:1329,y:958,t:1528143863262};\\\", \\\"{x:1331,y:954,t:1528143863279};\\\", \\\"{x:1333,y:950,t:1528143863295};\\\", \\\"{x:1335,y:944,t:1528143863312};\\\", \\\"{x:1336,y:939,t:1528143863329};\\\", \\\"{x:1338,y:932,t:1528143863346};\\\", \\\"{x:1339,y:929,t:1528143863362};\\\", \\\"{x:1340,y:927,t:1528143863379};\\\", \\\"{x:1340,y:924,t:1528143863395};\\\", \\\"{x:1341,y:922,t:1528143863417};\\\", \\\"{x:1342,y:922,t:1528143863429};\\\", \\\"{x:1342,y:921,t:1528143863445};\\\", \\\"{x:1342,y:920,t:1528143863463};\\\", \\\"{x:1343,y:919,t:1528143863480};\\\", \\\"{x:1343,y:917,t:1528143863496};\\\", \\\"{x:1345,y:915,t:1528143863513};\\\", \\\"{x:1348,y:913,t:1528143863529};\\\", \\\"{x:1350,y:913,t:1528143863546};\\\", \\\"{x:1354,y:910,t:1528143863563};\\\", \\\"{x:1363,y:905,t:1528143863580};\\\", \\\"{x:1373,y:900,t:1528143863596};\\\", \\\"{x:1382,y:897,t:1528143863615};\\\", \\\"{x:1388,y:896,t:1528143863629};\\\", \\\"{x:1390,y:895,t:1528143863645};\\\", \\\"{x:1391,y:895,t:1528143863881};\\\", \\\"{x:1392,y:883,t:1528143863896};\\\", \\\"{x:1393,y:817,t:1528143863913};\\\", \\\"{x:1396,y:768,t:1528143863930};\\\", \\\"{x:1408,y:711,t:1528143863946};\\\", \\\"{x:1421,y:671,t:1528143863962};\\\", \\\"{x:1434,y:629,t:1528143863980};\\\", \\\"{x:1444,y:597,t:1528143863996};\\\", \\\"{x:1454,y:573,t:1528143864013};\\\", \\\"{x:1464,y:543,t:1528143864029};\\\", \\\"{x:1471,y:518,t:1528143864047};\\\", \\\"{x:1476,y:501,t:1528143864063};\\\", \\\"{x:1481,y:489,t:1528143864080};\\\", \\\"{x:1484,y:481,t:1528143864097};\\\", \\\"{x:1485,y:478,t:1528143864112};\\\", \\\"{x:1488,y:475,t:1528143864129};\\\", \\\"{x:1490,y:472,t:1528143864147};\\\", \\\"{x:1492,y:470,t:1528143864163};\\\", \\\"{x:1493,y:469,t:1528143864180};\\\", \\\"{x:1495,y:468,t:1528143864197};\\\", \\\"{x:1496,y:468,t:1528143864217};\\\", \\\"{x:1497,y:468,t:1528143864230};\\\", \\\"{x:1500,y:468,t:1528143864247};\\\", \\\"{x:1507,y:468,t:1528143864263};\\\", \\\"{x:1518,y:470,t:1528143864280};\\\", \\\"{x:1542,y:476,t:1528143864297};\\\", \\\"{x:1555,y:480,t:1528143864313};\\\", \\\"{x:1562,y:484,t:1528143864329};\\\", \\\"{x:1564,y:484,t:1528143864347};\\\", \\\"{x:1566,y:484,t:1528143864362};\\\", \\\"{x:1568,y:485,t:1528143864379};\\\", \\\"{x:1569,y:485,t:1528143864396};\\\", \\\"{x:1571,y:485,t:1528143864414};\\\", \\\"{x:1575,y:485,t:1528143864429};\\\", \\\"{x:1576,y:485,t:1528143864446};\\\", \\\"{x:1580,y:487,t:1528143864463};\\\", \\\"{x:1581,y:487,t:1528143864513};\\\", \\\"{x:1583,y:487,t:1528143864530};\\\", \\\"{x:1590,y:491,t:1528143864547};\\\", \\\"{x:1597,y:493,t:1528143864563};\\\", \\\"{x:1601,y:496,t:1528143864580};\\\", \\\"{x:1603,y:497,t:1528143864597};\\\", \\\"{x:1603,y:498,t:1528143864929};\\\", \\\"{x:1603,y:499,t:1528143864947};\\\", \\\"{x:1603,y:500,t:1528143864963};\\\", \\\"{x:1602,y:502,t:1528143864980};\\\", \\\"{x:1602,y:503,t:1528143864996};\\\", \\\"{x:1599,y:509,t:1528143865013};\\\", \\\"{x:1594,y:522,t:1528143865030};\\\", \\\"{x:1580,y:542,t:1528143865047};\\\", \\\"{x:1562,y:574,t:1528143865064};\\\", \\\"{x:1514,y:639,t:1528143865081};\\\", \\\"{x:1477,y:690,t:1528143865097};\\\", \\\"{x:1434,y:749,t:1528143865114};\\\", \\\"{x:1394,y:803,t:1528143865130};\\\", \\\"{x:1358,y:849,t:1528143865147};\\\", \\\"{x:1327,y:889,t:1528143865164};\\\", \\\"{x:1300,y:922,t:1528143865180};\\\", \\\"{x:1279,y:951,t:1528143865197};\\\", \\\"{x:1265,y:970,t:1528143865214};\\\", \\\"{x:1258,y:983,t:1528143865231};\\\", \\\"{x:1252,y:993,t:1528143865247};\\\", \\\"{x:1248,y:1002,t:1528143865263};\\\", \\\"{x:1245,y:1012,t:1528143865281};\\\", \\\"{x:1244,y:1015,t:1528143865297};\\\", \\\"{x:1244,y:1017,t:1528143865314};\\\", \\\"{x:1243,y:1018,t:1528143865330};\\\", \\\"{x:1243,y:1019,t:1528143865347};\\\", \\\"{x:1243,y:1022,t:1528143865363};\\\", \\\"{x:1243,y:1025,t:1528143865381};\\\", \\\"{x:1243,y:1027,t:1528143865397};\\\", \\\"{x:1243,y:1025,t:1528143865481};\\\", \\\"{x:1243,y:999,t:1528143865497};\\\", \\\"{x:1241,y:980,t:1528143865513};\\\", \\\"{x:1240,y:976,t:1528143865530};\\\", \\\"{x:1240,y:981,t:1528143865680};\\\", \\\"{x:1248,y:993,t:1528143865697};\\\", \\\"{x:1259,y:1002,t:1528143865713};\\\", \\\"{x:1274,y:1007,t:1528143865730};\\\", \\\"{x:1293,y:1011,t:1528143865747};\\\", \\\"{x:1315,y:1011,t:1528143865763};\\\", \\\"{x:1335,y:1007,t:1528143865780};\\\", \\\"{x:1348,y:995,t:1528143865797};\\\", \\\"{x:1356,y:989,t:1528143865813};\\\", \\\"{x:1362,y:982,t:1528143865830};\\\", \\\"{x:1366,y:977,t:1528143865847};\\\", \\\"{x:1366,y:975,t:1528143865864};\\\", \\\"{x:1367,y:972,t:1528143865880};\\\", \\\"{x:1368,y:970,t:1528143865898};\\\", \\\"{x:1368,y:969,t:1528143865914};\\\", \\\"{x:1368,y:968,t:1528143865931};\\\", \\\"{x:1368,y:967,t:1528143865948};\\\", \\\"{x:1368,y:966,t:1528143865965};\\\", \\\"{x:1368,y:965,t:1528143866073};\\\", \\\"{x:1367,y:965,t:1528143866112};\\\", \\\"{x:1366,y:965,t:1528143866120};\\\", \\\"{x:1364,y:965,t:1528143866131};\\\", \\\"{x:1362,y:966,t:1528143866147};\\\", \\\"{x:1360,y:966,t:1528143866164};\\\", \\\"{x:1359,y:967,t:1528143866181};\\\", \\\"{x:1358,y:967,t:1528143866198};\\\", \\\"{x:1358,y:963,t:1528143866313};\\\", \\\"{x:1358,y:949,t:1528143866331};\\\", \\\"{x:1363,y:935,t:1528143866347};\\\", \\\"{x:1367,y:926,t:1528143866365};\\\", \\\"{x:1370,y:917,t:1528143866382};\\\", \\\"{x:1372,y:913,t:1528143866397};\\\", \\\"{x:1374,y:910,t:1528143866415};\\\", \\\"{x:1374,y:909,t:1528143866431};\\\", \\\"{x:1375,y:909,t:1528143866457};\\\", \\\"{x:1375,y:907,t:1528143866465};\\\", \\\"{x:1378,y:902,t:1528143866481};\\\", \\\"{x:1381,y:899,t:1528143866498};\\\", \\\"{x:1383,y:896,t:1528143866514};\\\", \\\"{x:1385,y:893,t:1528143866532};\\\", \\\"{x:1388,y:889,t:1528143866549};\\\", \\\"{x:1393,y:884,t:1528143866564};\\\", \\\"{x:1396,y:880,t:1528143866582};\\\", \\\"{x:1398,y:877,t:1528143866598};\\\", \\\"{x:1401,y:873,t:1528143866615};\\\", \\\"{x:1404,y:870,t:1528143866632};\\\", \\\"{x:1406,y:868,t:1528143866648};\\\", \\\"{x:1408,y:864,t:1528143866665};\\\", \\\"{x:1409,y:863,t:1528143866729};\\\", \\\"{x:1409,y:862,t:1528143866769};\\\", \\\"{x:1411,y:858,t:1528143866782};\\\", \\\"{x:1416,y:845,t:1528143866797};\\\", \\\"{x:1424,y:822,t:1528143866815};\\\", \\\"{x:1443,y:773,t:1528143866832};\\\", \\\"{x:1477,y:648,t:1528143866850};\\\", \\\"{x:1501,y:573,t:1528143866864};\\\", \\\"{x:1521,y:518,t:1528143866882};\\\", \\\"{x:1542,y:480,t:1528143866897};\\\", \\\"{x:1559,y:453,t:1528143866915};\\\", \\\"{x:1572,y:437,t:1528143866932};\\\", \\\"{x:1580,y:427,t:1528143866949};\\\", \\\"{x:1582,y:423,t:1528143866965};\\\", \\\"{x:1583,y:421,t:1528143866982};\\\", \\\"{x:1584,y:419,t:1528143866999};\\\", \\\"{x:1584,y:418,t:1528143867015};\\\", \\\"{x:1584,y:422,t:1528143867145};\\\", \\\"{x:1584,y:427,t:1528143867153};\\\", \\\"{x:1584,y:432,t:1528143867164};\\\", \\\"{x:1584,y:438,t:1528143867181};\\\", \\\"{x:1584,y:439,t:1528143867199};\\\", \\\"{x:1585,y:441,t:1528143867214};\\\", \\\"{x:1585,y:442,t:1528143867232};\\\", \\\"{x:1586,y:452,t:1528143867249};\\\", \\\"{x:1587,y:460,t:1528143867265};\\\", \\\"{x:1587,y:473,t:1528143867281};\\\", \\\"{x:1587,y:488,t:1528143867299};\\\", \\\"{x:1587,y:503,t:1528143867316};\\\", \\\"{x:1587,y:514,t:1528143867331};\\\", \\\"{x:1587,y:520,t:1528143867349};\\\", \\\"{x:1587,y:519,t:1528143867617};\\\", \\\"{x:1587,y:516,t:1528143867631};\\\", \\\"{x:1587,y:515,t:1528143867648};\\\", \\\"{x:1587,y:514,t:1528143867665};\\\", \\\"{x:1586,y:512,t:1528143867682};\\\", \\\"{x:1585,y:512,t:1528143867699};\\\", \\\"{x:1583,y:511,t:1528143867715};\\\", \\\"{x:1571,y:511,t:1528143867731};\\\", \\\"{x:1536,y:511,t:1528143867749};\\\", \\\"{x:1422,y:511,t:1528143867766};\\\", \\\"{x:1240,y:533,t:1528143867783};\\\", \\\"{x:992,y:568,t:1528143867798};\\\", \\\"{x:705,y:612,t:1528143867817};\\\", \\\"{x:317,y:698,t:1528143867832};\\\", \\\"{x:125,y:746,t:1528143867848};\\\", \\\"{x:12,y:775,t:1528143867865};\\\", \\\"{x:0,y:780,t:1528143867882};\\\", \\\"{x:0,y:781,t:1528143867899};\\\", \\\"{x:0,y:780,t:1528143867928};\\\", \\\"{x:2,y:774,t:1528143867968};\\\", \\\"{x:15,y:754,t:1528143867982};\\\", \\\"{x:64,y:672,t:1528143868000};\\\", \\\"{x:94,y:644,t:1528143868017};\\\", \\\"{x:115,y:631,t:1528143868033};\\\", \\\"{x:139,y:621,t:1528143868049};\\\", \\\"{x:163,y:614,t:1528143868066};\\\", \\\"{x:184,y:608,t:1528143868084};\\\", \\\"{x:213,y:603,t:1528143868100};\\\", \\\"{x:260,y:596,t:1528143868117};\\\", \\\"{x:311,y:588,t:1528143868134};\\\", \\\"{x:345,y:584,t:1528143868149};\\\", \\\"{x:365,y:583,t:1528143868166};\\\", \\\"{x:382,y:583,t:1528143868183};\\\", \\\"{x:392,y:583,t:1528143868199};\\\", \\\"{x:392,y:582,t:1528143868217};\\\", \\\"{x:396,y:579,t:1528143868233};\\\", \\\"{x:401,y:572,t:1528143868249};\\\", \\\"{x:406,y:563,t:1528143868267};\\\", \\\"{x:411,y:554,t:1528143868284};\\\", \\\"{x:413,y:546,t:1528143868299};\\\", \\\"{x:414,y:544,t:1528143868316};\\\", \\\"{x:414,y:543,t:1528143868333};\\\", \\\"{x:414,y:542,t:1528143868349};\\\", \\\"{x:413,y:541,t:1528143868465};\\\", \\\"{x:412,y:541,t:1528143868473};\\\", \\\"{x:410,y:540,t:1528143868484};\\\", \\\"{x:404,y:538,t:1528143868500};\\\", \\\"{x:397,y:536,t:1528143868516};\\\", \\\"{x:393,y:534,t:1528143868534};\\\", \\\"{x:392,y:533,t:1528143868550};\\\", \\\"{x:391,y:533,t:1528143868968};\\\", \\\"{x:389,y:538,t:1528143868983};\\\", \\\"{x:385,y:563,t:1528143869000};\\\", \\\"{x:382,y:581,t:1528143869017};\\\", \\\"{x:378,y:595,t:1528143869033};\\\", \\\"{x:377,y:603,t:1528143869051};\\\", \\\"{x:377,y:604,t:1528143869068};\\\", \\\"{x:377,y:605,t:1528143869144};\\\", \\\"{x:377,y:607,t:1528143869160};\\\", \\\"{x:377,y:608,t:1528143869168};\\\", \\\"{x:377,y:610,t:1528143869184};\\\", \\\"{x:377,y:614,t:1528143869201};\\\", \\\"{x:377,y:615,t:1528143869241};\\\", \\\"{x:377,y:618,t:1528143869527};\\\", \\\"{x:382,y:629,t:1528143869536};\\\", \\\"{x:390,y:640,t:1528143869551};\\\", \\\"{x:405,y:662,t:1528143869567};\\\", \\\"{x:423,y:686,t:1528143869584};\\\", \\\"{x:427,y:693,t:1528143869600};\\\", \\\"{x:430,y:696,t:1528143869617};\\\", \\\"{x:430,y:698,t:1528143869634};\\\", \\\"{x:432,y:700,t:1528143869652};\\\", \\\"{x:433,y:701,t:1528143869777};\\\", \\\"{x:437,y:703,t:1528143869784};\\\", \\\"{x:452,y:713,t:1528143869801};\\\", \\\"{x:467,y:722,t:1528143869820};\\\", \\\"{x:479,y:728,t:1528143869834};\\\", \\\"{x:485,y:728,t:1528143869851};\\\", \\\"{x:487,y:728,t:1528143869867};\\\", \\\"{x:488,y:728,t:1528143869884};\\\", \\\"{x:489,y:728,t:1528143870121};\\\", \\\"{x:489,y:728,t:1528143870199};\\\", \\\"{x:490,y:719,t:1528143870352};\\\", \\\"{x:501,y:681,t:1528143870368};\\\", \\\"{x:509,y:652,t:1528143870384};\\\", \\\"{x:518,y:630,t:1528143870401};\\\", \\\"{x:526,y:612,t:1528143870418};\\\", \\\"{x:533,y:591,t:1528143870434};\\\", \\\"{x:542,y:564,t:1528143870451};\\\", \\\"{x:547,y:535,t:1528143870468};\\\", \\\"{x:551,y:506,t:1528143870484};\\\", \\\"{x:551,y:482,t:1528143870501};\\\", \\\"{x:551,y:472,t:1528143870518};\\\", \\\"{x:551,y:466,t:1528143870534};\\\", \\\"{x:551,y:462,t:1528143870551};\\\", \\\"{x:551,y:461,t:1528143870568};\\\", \\\"{x:551,y:460,t:1528143871008};\\\", \\\"{x:550,y:460,t:1528143871018};\\\", \\\"{x:548,y:460,t:1528143871035};\\\", \\\"{x:546,y:460,t:1528143871256};\\\" ] }, { \\\"rt\\\": 10223, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 563547, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"TTCWS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-M -G -F -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:543,y:460,t:1528143872289};\\\", \\\"{x:541,y:464,t:1528143872303};\\\", \\\"{x:535,y:480,t:1528143872320};\\\", \\\"{x:524,y:521,t:1528143872336};\\\", \\\"{x:519,y:564,t:1528143872354};\\\", \\\"{x:516,y:618,t:1528143872370};\\\", \\\"{x:516,y:660,t:1528143872386};\\\", \\\"{x:519,y:702,t:1528143872403};\\\", \\\"{x:525,y:752,t:1528143872420};\\\", \\\"{x:534,y:806,t:1528143872436};\\\", \\\"{x:541,y:843,t:1528143872453};\\\", \\\"{x:554,y:885,t:1528143872469};\\\", \\\"{x:568,y:920,t:1528143872486};\\\", \\\"{x:580,y:946,t:1528143872503};\\\", \\\"{x:593,y:973,t:1528143872519};\\\", \\\"{x:597,y:980,t:1528143872536};\\\", \\\"{x:600,y:983,t:1528143872553};\\\", \\\"{x:601,y:984,t:1528143872570};\\\", \\\"{x:601,y:985,t:1528143872616};\\\", \\\"{x:602,y:986,t:1528143872624};\\\", \\\"{x:603,y:986,t:1528143872637};\\\", \\\"{x:612,y:990,t:1528143872653};\\\", \\\"{x:629,y:1000,t:1528143872670};\\\", \\\"{x:660,y:1015,t:1528143872687};\\\", \\\"{x:721,y:1043,t:1528143872704};\\\", \\\"{x:860,y:1101,t:1528143872720};\\\", \\\"{x:960,y:1131,t:1528143872738};\\\", \\\"{x:1047,y:1148,t:1528143872754};\\\", \\\"{x:1122,y:1159,t:1528143872770};\\\", \\\"{x:1172,y:1159,t:1528143872788};\\\", \\\"{x:1207,y:1159,t:1528143872805};\\\", \\\"{x:1229,y:1160,t:1528143872821};\\\", \\\"{x:1234,y:1160,t:1528143872837};\\\", \\\"{x:1236,y:1160,t:1528143872855};\\\", \\\"{x:1236,y:1159,t:1528143872921};\\\", \\\"{x:1236,y:1155,t:1528143872938};\\\", \\\"{x:1235,y:1153,t:1528143872954};\\\", \\\"{x:1235,y:1152,t:1528143872972};\\\", \\\"{x:1235,y:1151,t:1528143873057};\\\", \\\"{x:1233,y:1149,t:1528143873072};\\\", \\\"{x:1231,y:1143,t:1528143873088};\\\", \\\"{x:1228,y:1133,t:1528143873105};\\\", \\\"{x:1227,y:1130,t:1528143873122};\\\", \\\"{x:1224,y:1126,t:1528143873138};\\\", \\\"{x:1224,y:1121,t:1528143873155};\\\", \\\"{x:1224,y:1120,t:1528143873172};\\\", \\\"{x:1223,y:1116,t:1528143873189};\\\", \\\"{x:1223,y:1112,t:1528143873206};\\\", \\\"{x:1220,y:1105,t:1528143873222};\\\", \\\"{x:1220,y:1102,t:1528143873239};\\\", \\\"{x:1219,y:1096,t:1528143873256};\\\", \\\"{x:1219,y:1094,t:1528143873272};\\\", \\\"{x:1219,y:1089,t:1528143873288};\\\", \\\"{x:1219,y:1088,t:1528143873306};\\\", \\\"{x:1219,y:1087,t:1528143873323};\\\", \\\"{x:1219,y:1086,t:1528143873368};\\\", \\\"{x:1219,y:1083,t:1528143873384};\\\", \\\"{x:1220,y:1082,t:1528143873393};\\\", \\\"{x:1220,y:1080,t:1528143873406};\\\", \\\"{x:1220,y:1079,t:1528143873423};\\\", \\\"{x:1223,y:1074,t:1528143873440};\\\", \\\"{x:1230,y:1064,t:1528143873456};\\\", \\\"{x:1241,y:1048,t:1528143873473};\\\", \\\"{x:1253,y:1030,t:1528143873489};\\\", \\\"{x:1267,y:1010,t:1528143873506};\\\", \\\"{x:1279,y:993,t:1528143873523};\\\", \\\"{x:1290,y:977,t:1528143873540};\\\", \\\"{x:1304,y:958,t:1528143873557};\\\", \\\"{x:1319,y:942,t:1528143873572};\\\", \\\"{x:1334,y:929,t:1528143873589};\\\", \\\"{x:1352,y:917,t:1528143873607};\\\", \\\"{x:1368,y:906,t:1528143873623};\\\", \\\"{x:1383,y:898,t:1528143873640};\\\", \\\"{x:1417,y:879,t:1528143873656};\\\", \\\"{x:1454,y:861,t:1528143873673};\\\", \\\"{x:1489,y:842,t:1528143873690};\\\", \\\"{x:1531,y:814,t:1528143873706};\\\", \\\"{x:1565,y:790,t:1528143873724};\\\", \\\"{x:1604,y:762,t:1528143873740};\\\", \\\"{x:1636,y:739,t:1528143873756};\\\", \\\"{x:1669,y:715,t:1528143873774};\\\", \\\"{x:1687,y:702,t:1528143873791};\\\", \\\"{x:1690,y:700,t:1528143873807};\\\", \\\"{x:1691,y:700,t:1528143873906};\\\", \\\"{x:1694,y:700,t:1528143873913};\\\", \\\"{x:1694,y:702,t:1528143873924};\\\", \\\"{x:1700,y:718,t:1528143873941};\\\", \\\"{x:1700,y:730,t:1528143873958};\\\", \\\"{x:1700,y:747,t:1528143873974};\\\", \\\"{x:1700,y:762,t:1528143873991};\\\", \\\"{x:1700,y:773,t:1528143874008};\\\", \\\"{x:1695,y:784,t:1528143874025};\\\", \\\"{x:1687,y:794,t:1528143874041};\\\", \\\"{x:1674,y:804,t:1528143874058};\\\", \\\"{x:1650,y:812,t:1528143874075};\\\", \\\"{x:1611,y:812,t:1528143874091};\\\", \\\"{x:1558,y:812,t:1528143874107};\\\", \\\"{x:1502,y:812,t:1528143874124};\\\", \\\"{x:1460,y:812,t:1528143874142};\\\", \\\"{x:1441,y:812,t:1528143874158};\\\", \\\"{x:1435,y:812,t:1528143874175};\\\", \\\"{x:1434,y:812,t:1528143874265};\\\", \\\"{x:1432,y:812,t:1528143874275};\\\", \\\"{x:1424,y:812,t:1528143874292};\\\", \\\"{x:1416,y:811,t:1528143874309};\\\", \\\"{x:1408,y:809,t:1528143874325};\\\", \\\"{x:1399,y:806,t:1528143874342};\\\", \\\"{x:1393,y:806,t:1528143874359};\\\", \\\"{x:1386,y:803,t:1528143874376};\\\", \\\"{x:1377,y:798,t:1528143874392};\\\", \\\"{x:1352,y:784,t:1528143874408};\\\", \\\"{x:1334,y:770,t:1528143874426};\\\", \\\"{x:1315,y:760,t:1528143874442};\\\", \\\"{x:1305,y:756,t:1528143874459};\\\", \\\"{x:1304,y:755,t:1528143874601};\\\", \\\"{x:1304,y:753,t:1528143874649};\\\", \\\"{x:1306,y:748,t:1528143874660};\\\", \\\"{x:1317,y:734,t:1528143874676};\\\", \\\"{x:1321,y:728,t:1528143874693};\\\", \\\"{x:1324,y:725,t:1528143874710};\\\", \\\"{x:1327,y:722,t:1528143874726};\\\", \\\"{x:1328,y:721,t:1528143874743};\\\", \\\"{x:1329,y:720,t:1528143874760};\\\", \\\"{x:1331,y:720,t:1528143874824};\\\", \\\"{x:1333,y:720,t:1528143874833};\\\", \\\"{x:1335,y:720,t:1528143874843};\\\", \\\"{x:1344,y:716,t:1528143874860};\\\", \\\"{x:1351,y:713,t:1528143874877};\\\", \\\"{x:1354,y:710,t:1528143874894};\\\", \\\"{x:1360,y:707,t:1528143874910};\\\", \\\"{x:1363,y:706,t:1528143874927};\\\", \\\"{x:1365,y:705,t:1528143874944};\\\", \\\"{x:1366,y:704,t:1528143874960};\\\", \\\"{x:1367,y:703,t:1528143875313};\\\", \\\"{x:1367,y:701,t:1528143875328};\\\", \\\"{x:1365,y:699,t:1528143875344};\\\", \\\"{x:1364,y:697,t:1528143875363};\\\", \\\"{x:1363,y:696,t:1528143875378};\\\", \\\"{x:1362,y:695,t:1528143875395};\\\", \\\"{x:1362,y:694,t:1528143875560};\\\", \\\"{x:1359,y:692,t:1528143875568};\\\", \\\"{x:1358,y:691,t:1528143875579};\\\", \\\"{x:1355,y:690,t:1528143875596};\\\", \\\"{x:1354,y:690,t:1528143875611};\\\", \\\"{x:1352,y:689,t:1528143875632};\\\", \\\"{x:1352,y:687,t:1528143876009};\\\", \\\"{x:1352,y:685,t:1528143876017};\\\", \\\"{x:1352,y:684,t:1528143876029};\\\", \\\"{x:1353,y:680,t:1528143876046};\\\", \\\"{x:1354,y:677,t:1528143876062};\\\", \\\"{x:1357,y:673,t:1528143876079};\\\", \\\"{x:1357,y:670,t:1528143876096};\\\", \\\"{x:1358,y:668,t:1528143876113};\\\", \\\"{x:1361,y:663,t:1528143876130};\\\", \\\"{x:1364,y:658,t:1528143876146};\\\", \\\"{x:1369,y:650,t:1528143876163};\\\", \\\"{x:1372,y:645,t:1528143876179};\\\", \\\"{x:1378,y:635,t:1528143876196};\\\", \\\"{x:1382,y:626,t:1528143876214};\\\", \\\"{x:1385,y:623,t:1528143876231};\\\", \\\"{x:1391,y:615,t:1528143876247};\\\", \\\"{x:1398,y:606,t:1528143876264};\\\", \\\"{x:1411,y:591,t:1528143876280};\\\", \\\"{x:1419,y:583,t:1528143876297};\\\", \\\"{x:1425,y:575,t:1528143876314};\\\", \\\"{x:1427,y:573,t:1528143876331};\\\", \\\"{x:1428,y:573,t:1528143876348};\\\", \\\"{x:1428,y:572,t:1528143876376};\\\", \\\"{x:1428,y:571,t:1528143876385};\\\", \\\"{x:1429,y:570,t:1528143876401};\\\", \\\"{x:1430,y:569,t:1528143876425};\\\", \\\"{x:1430,y:567,t:1528143876705};\\\", \\\"{x:1429,y:567,t:1528143876720};\\\", \\\"{x:1428,y:567,t:1528143876732};\\\", \\\"{x:1427,y:567,t:1528143876752};\\\", \\\"{x:1426,y:567,t:1528143876765};\\\", \\\"{x:1425,y:566,t:1528143876782};\\\", \\\"{x:1424,y:565,t:1528143876809};\\\", \\\"{x:1423,y:565,t:1528143876865};\\\", \\\"{x:1423,y:564,t:1528143876882};\\\", \\\"{x:1422,y:563,t:1528143876899};\\\", \\\"{x:1421,y:563,t:1528143876953};\\\", \\\"{x:1420,y:562,t:1528143876985};\\\", \\\"{x:1418,y:562,t:1528143877169};\\\", \\\"{x:1417,y:565,t:1528143877183};\\\", \\\"{x:1410,y:574,t:1528143877201};\\\", \\\"{x:1405,y:582,t:1528143877216};\\\", \\\"{x:1399,y:591,t:1528143877234};\\\", \\\"{x:1390,y:599,t:1528143877250};\\\", \\\"{x:1381,y:610,t:1528143877267};\\\", \\\"{x:1375,y:619,t:1528143877283};\\\", \\\"{x:1370,y:626,t:1528143877300};\\\", \\\"{x:1361,y:637,t:1528143877317};\\\", \\\"{x:1358,y:645,t:1528143877334};\\\", \\\"{x:1353,y:652,t:1528143877350};\\\", \\\"{x:1349,y:659,t:1528143877367};\\\", \\\"{x:1346,y:663,t:1528143877384};\\\", \\\"{x:1345,y:665,t:1528143877401};\\\", \\\"{x:1344,y:668,t:1528143877417};\\\", \\\"{x:1343,y:671,t:1528143877434};\\\", \\\"{x:1341,y:676,t:1528143877451};\\\", \\\"{x:1340,y:679,t:1528143877467};\\\", \\\"{x:1338,y:683,t:1528143877484};\\\", \\\"{x:1337,y:687,t:1528143877501};\\\", \\\"{x:1337,y:692,t:1528143877517};\\\", \\\"{x:1335,y:698,t:1528143877534};\\\", \\\"{x:1335,y:704,t:1528143877551};\\\", \\\"{x:1335,y:708,t:1528143877568};\\\", \\\"{x:1335,y:709,t:1528143877585};\\\", \\\"{x:1335,y:710,t:1528143877616};\\\", \\\"{x:1335,y:708,t:1528143877929};\\\", \\\"{x:1335,y:705,t:1528143877937};\\\", \\\"{x:1337,y:700,t:1528143877952};\\\", \\\"{x:1341,y:695,t:1528143877968};\\\", \\\"{x:1345,y:687,t:1528143877985};\\\", \\\"{x:1349,y:681,t:1528143878002};\\\", \\\"{x:1351,y:678,t:1528143878019};\\\", \\\"{x:1351,y:677,t:1528143878037};\\\", \\\"{x:1351,y:675,t:1528143878052};\\\", \\\"{x:1352,y:669,t:1528143878069};\\\", \\\"{x:1353,y:665,t:1528143878086};\\\", \\\"{x:1355,y:658,t:1528143878102};\\\", \\\"{x:1356,y:653,t:1528143878119};\\\", \\\"{x:1359,y:644,t:1528143878137};\\\", \\\"{x:1360,y:641,t:1528143878153};\\\", \\\"{x:1361,y:635,t:1528143878169};\\\", \\\"{x:1363,y:629,t:1528143878186};\\\", \\\"{x:1365,y:622,t:1528143878204};\\\", \\\"{x:1366,y:616,t:1528143878219};\\\", \\\"{x:1368,y:611,t:1528143878236};\\\", \\\"{x:1369,y:608,t:1528143878254};\\\", \\\"{x:1369,y:607,t:1528143878269};\\\", \\\"{x:1371,y:604,t:1528143878286};\\\", \\\"{x:1371,y:600,t:1528143878303};\\\", \\\"{x:1374,y:596,t:1528143878321};\\\", \\\"{x:1374,y:593,t:1528143878336};\\\", \\\"{x:1375,y:591,t:1528143878353};\\\", \\\"{x:1376,y:590,t:1528143878370};\\\", \\\"{x:1378,y:587,t:1528143878386};\\\", \\\"{x:1381,y:582,t:1528143878403};\\\", \\\"{x:1382,y:580,t:1528143878420};\\\", \\\"{x:1383,y:579,t:1528143878437};\\\", \\\"{x:1385,y:576,t:1528143878454};\\\", \\\"{x:1386,y:574,t:1528143878470};\\\", \\\"{x:1387,y:572,t:1528143878487};\\\", \\\"{x:1390,y:570,t:1528143878503};\\\", \\\"{x:1394,y:565,t:1528143878520};\\\", \\\"{x:1398,y:562,t:1528143878537};\\\", \\\"{x:1404,y:559,t:1528143878554};\\\", \\\"{x:1406,y:557,t:1528143878570};\\\", \\\"{x:1411,y:555,t:1528143878588};\\\", \\\"{x:1415,y:554,t:1528143878604};\\\", \\\"{x:1417,y:553,t:1528143878620};\\\", \\\"{x:1420,y:552,t:1528143878637};\\\", \\\"{x:1421,y:552,t:1528143878657};\\\", \\\"{x:1423,y:552,t:1528143878673};\\\", \\\"{x:1424,y:552,t:1528143878687};\\\", \\\"{x:1429,y:552,t:1528143878705};\\\", \\\"{x:1431,y:552,t:1528143878721};\\\", \\\"{x:1433,y:552,t:1528143878738};\\\", \\\"{x:1433,y:551,t:1528143878769};\\\", \\\"{x:1424,y:555,t:1528143879104};\\\", \\\"{x:1398,y:570,t:1528143879122};\\\", \\\"{x:1349,y:597,t:1528143879138};\\\", \\\"{x:1266,y:638,t:1528143879154};\\\", \\\"{x:1161,y:679,t:1528143879171};\\\", \\\"{x:1036,y:721,t:1528143879189};\\\", \\\"{x:906,y:755,t:1528143879205};\\\", \\\"{x:767,y:781,t:1528143879221};\\\", \\\"{x:655,y:805,t:1528143879239};\\\", \\\"{x:555,y:821,t:1528143879255};\\\", \\\"{x:433,y:840,t:1528143879273};\\\", \\\"{x:376,y:845,t:1528143879289};\\\", \\\"{x:323,y:845,t:1528143879306};\\\", \\\"{x:294,y:845,t:1528143879322};\\\", \\\"{x:281,y:841,t:1528143879339};\\\", \\\"{x:274,y:837,t:1528143879356};\\\", \\\"{x:269,y:829,t:1528143879373};\\\", \\\"{x:262,y:800,t:1528143879389};\\\", \\\"{x:254,y:763,t:1528143879406};\\\", \\\"{x:254,y:718,t:1528143879424};\\\", \\\"{x:254,y:659,t:1528143879441};\\\", \\\"{x:273,y:603,t:1528143879456};\\\", \\\"{x:286,y:582,t:1528143879485};\\\", \\\"{x:291,y:576,t:1528143879502};\\\", \\\"{x:293,y:576,t:1528143879518};\\\", \\\"{x:296,y:575,t:1528143879535};\\\", \\\"{x:311,y:572,t:1528143879551};\\\", \\\"{x:325,y:570,t:1528143879568};\\\", \\\"{x:345,y:569,t:1528143879584};\\\", \\\"{x:368,y:569,t:1528143879602};\\\", \\\"{x:396,y:569,t:1528143879619};\\\", \\\"{x:416,y:571,t:1528143879634};\\\", \\\"{x:438,y:577,t:1528143879659};\\\", \\\"{x:453,y:581,t:1528143879676};\\\", \\\"{x:459,y:582,t:1528143879692};\\\", \\\"{x:460,y:582,t:1528143879708};\\\", \\\"{x:455,y:582,t:1528143879793};\\\", \\\"{x:442,y:582,t:1528143879809};\\\", \\\"{x:429,y:582,t:1528143879826};\\\", \\\"{x:405,y:582,t:1528143879844};\\\", \\\"{x:372,y:582,t:1528143879859};\\\", \\\"{x:330,y:582,t:1528143879876};\\\", \\\"{x:303,y:582,t:1528143879892};\\\", \\\"{x:288,y:582,t:1528143879909};\\\", \\\"{x:283,y:582,t:1528143879925};\\\", \\\"{x:281,y:582,t:1528143879943};\\\", \\\"{x:279,y:582,t:1528143879958};\\\", \\\"{x:255,y:580,t:1528143880013};\\\", \\\"{x:246,y:580,t:1528143880025};\\\", \\\"{x:243,y:580,t:1528143880042};\\\", \\\"{x:242,y:580,t:1528143880058};\\\", \\\"{x:240,y:580,t:1528143880075};\\\", \\\"{x:238,y:580,t:1528143880093};\\\", \\\"{x:237,y:580,t:1528143880108};\\\", \\\"{x:236,y:580,t:1528143880152};\\\", \\\"{x:237,y:582,t:1528143880160};\\\", \\\"{x:246,y:589,t:1528143880176};\\\", \\\"{x:255,y:594,t:1528143880193};\\\", \\\"{x:263,y:595,t:1528143880209};\\\", \\\"{x:274,y:595,t:1528143880225};\\\", \\\"{x:301,y:595,t:1528143880243};\\\", \\\"{x:352,y:595,t:1528143880258};\\\", \\\"{x:441,y:595,t:1528143880275};\\\", \\\"{x:557,y:595,t:1528143880293};\\\", \\\"{x:646,y:595,t:1528143880309};\\\", \\\"{x:718,y:595,t:1528143880326};\\\", \\\"{x:763,y:595,t:1528143880343};\\\", \\\"{x:798,y:594,t:1528143880359};\\\", \\\"{x:831,y:587,t:1528143880377};\\\", \\\"{x:842,y:585,t:1528143880392};\\\", \\\"{x:849,y:584,t:1528143880409};\\\", \\\"{x:854,y:584,t:1528143880427};\\\", \\\"{x:856,y:582,t:1528143880442};\\\", \\\"{x:857,y:582,t:1528143880463};\\\", \\\"{x:857,y:581,t:1528143880477};\\\", \\\"{x:858,y:580,t:1528143880493};\\\", \\\"{x:859,y:577,t:1528143880510};\\\", \\\"{x:860,y:573,t:1528143880526};\\\", \\\"{x:861,y:570,t:1528143880542};\\\", \\\"{x:861,y:567,t:1528143880560};\\\", \\\"{x:861,y:565,t:1528143880576};\\\", \\\"{x:861,y:564,t:1528143880593};\\\", \\\"{x:858,y:560,t:1528143880611};\\\", \\\"{x:850,y:554,t:1528143880655};\\\", \\\"{x:849,y:553,t:1528143880660};\\\", \\\"{x:848,y:551,t:1528143880676};\\\", \\\"{x:846,y:550,t:1528143880693};\\\", \\\"{x:844,y:548,t:1528143880709};\\\", \\\"{x:841,y:546,t:1528143880727};\\\", \\\"{x:840,y:546,t:1528143880742};\\\", \\\"{x:837,y:548,t:1528143881007};\\\", \\\"{x:825,y:557,t:1528143881016};\\\", \\\"{x:806,y:569,t:1528143881027};\\\", \\\"{x:754,y:601,t:1528143881045};\\\", \\\"{x:691,y:637,t:1528143881060};\\\", \\\"{x:635,y:662,t:1528143881077};\\\", \\\"{x:600,y:677,t:1528143881093};\\\", \\\"{x:568,y:689,t:1528143881110};\\\", \\\"{x:552,y:694,t:1528143881127};\\\", \\\"{x:540,y:700,t:1528143881143};\\\", \\\"{x:538,y:701,t:1528143881160};\\\", \\\"{x:537,y:702,t:1528143881184};\\\", \\\"{x:536,y:702,t:1528143881194};\\\", \\\"{x:535,y:704,t:1528143881211};\\\", \\\"{x:535,y:707,t:1528143881227};\\\", \\\"{x:532,y:714,t:1528143881244};\\\", \\\"{x:528,y:722,t:1528143881261};\\\", \\\"{x:527,y:727,t:1528143881277};\\\", \\\"{x:523,y:731,t:1528143881293};\\\", \\\"{x:521,y:735,t:1528143881309};\\\", \\\"{x:519,y:737,t:1528143881326};\\\", \\\"{x:519,y:738,t:1528143881352};\\\", \\\"{x:519,y:740,t:1528143881393};\\\", \\\"{x:522,y:751,t:1528143881783};\\\", \\\"{x:531,y:772,t:1528143881794};\\\", \\\"{x:553,y:819,t:1528143881811};\\\", \\\"{x:573,y:866,t:1528143881827};\\\", \\\"{x:589,y:904,t:1528143881844};\\\", \\\"{x:600,y:930,t:1528143881861};\\\", \\\"{x:608,y:950,t:1528143881877};\\\", \\\"{x:612,y:959,t:1528143881893};\\\", \\\"{x:612,y:961,t:1528143881911};\\\", \\\"{x:608,y:960,t:1528143882128};\\\", \\\"{x:604,y:957,t:1528143882144};\\\", \\\"{x:602,y:955,t:1528143882160};\\\" ] }, { \\\"rt\\\": 14900, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 579711, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"TTCWS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-05 PM-02 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:605,y:956,t:1528143885393};\\\", \\\"{x:630,y:974,t:1528143885413};\\\", \\\"{x:658,y:993,t:1528143885430};\\\", \\\"{x:699,y:1011,t:1528143885449};\\\", \\\"{x:711,y:1015,t:1528143885463};\\\", \\\"{x:740,y:1023,t:1528143885480};\\\", \\\"{x:755,y:1029,t:1528143885497};\\\", \\\"{x:768,y:1033,t:1528143885512};\\\", \\\"{x:778,y:1034,t:1528143885530};\\\", \\\"{x:780,y:1035,t:1528143885547};\\\", \\\"{x:783,y:1035,t:1528143885563};\\\", \\\"{x:788,y:1035,t:1528143885580};\\\", \\\"{x:802,y:1035,t:1528143885596};\\\", \\\"{x:828,y:1035,t:1528143885614};\\\", \\\"{x:853,y:1035,t:1528143885630};\\\", \\\"{x:878,y:1035,t:1528143885647};\\\", \\\"{x:926,y:1024,t:1528143885664};\\\", \\\"{x:963,y:1018,t:1528143885680};\\\", \\\"{x:991,y:1009,t:1528143885697};\\\", \\\"{x:1023,y:998,t:1528143885715};\\\", \\\"{x:1058,y:983,t:1528143885731};\\\", \\\"{x:1099,y:966,t:1528143885748};\\\", \\\"{x:1127,y:954,t:1528143885764};\\\", \\\"{x:1143,y:945,t:1528143885780};\\\", \\\"{x:1156,y:937,t:1528143885797};\\\", \\\"{x:1165,y:930,t:1528143885814};\\\", \\\"{x:1171,y:924,t:1528143885830};\\\", \\\"{x:1173,y:922,t:1528143885848};\\\", \\\"{x:1178,y:916,t:1528143885865};\\\", \\\"{x:1180,y:911,t:1528143885880};\\\", \\\"{x:1182,y:908,t:1528143885898};\\\", \\\"{x:1183,y:906,t:1528143885914};\\\", \\\"{x:1183,y:905,t:1528143885930};\\\", \\\"{x:1183,y:904,t:1528143885968};\\\", \\\"{x:1183,y:903,t:1528143885984};\\\", \\\"{x:1182,y:903,t:1528143886001};\\\", \\\"{x:1182,y:902,t:1528143886015};\\\", \\\"{x:1172,y:901,t:1528143886031};\\\", \\\"{x:1155,y:901,t:1528143886048};\\\", \\\"{x:1124,y:906,t:1528143886064};\\\", \\\"{x:1096,y:914,t:1528143886081};\\\", \\\"{x:1050,y:924,t:1528143886097};\\\", \\\"{x:982,y:934,t:1528143886114};\\\", \\\"{x:899,y:947,t:1528143886132};\\\", \\\"{x:815,y:949,t:1528143886147};\\\", \\\"{x:714,y:944,t:1528143886165};\\\", \\\"{x:582,y:892,t:1528143886181};\\\", \\\"{x:436,y:824,t:1528143886197};\\\", \\\"{x:269,y:737,t:1528143886214};\\\", \\\"{x:107,y:634,t:1528143886232};\\\", \\\"{x:0,y:527,t:1528143886248};\\\", \\\"{x:0,y:366,t:1528143886265};\\\", \\\"{x:0,y:265,t:1528143886282};\\\", \\\"{x:0,y:171,t:1528143886298};\\\", \\\"{x:0,y:69,t:1528143886314};\\\", \\\"{x:0,y:0,t:1528143886331};\\\", \\\"{x:1,y:0,t:1528143886440};\\\", \\\"{x:13,y:0,t:1528143886448};\\\", \\\"{x:111,y:0,t:1528143886465};\\\", \\\"{x:291,y:0,t:1528143886481};\\\", \\\"{x:528,y:0,t:1528143886498};\\\", \\\"{x:817,y:0,t:1528143886515};\\\", \\\"{x:1145,y:0,t:1528143886531};\\\", \\\"{x:1477,y:0,t:1528143886548};\\\", \\\"{x:1800,y:0,t:1528143886565};\\\", \\\"{x:1919,y:0,t:1528143886582};\\\", \\\"{x:1919,y:4,t:1528143886600};\\\", \\\"{x:1919,y:16,t:1528143886615};\\\", \\\"{x:1919,y:64,t:1528143886632};\\\", \\\"{x:1919,y:120,t:1528143886647};\\\", \\\"{x:1919,y:144,t:1528143886665};\\\", \\\"{x:1919,y:180,t:1528143886681};\\\", \\\"{x:1919,y:222,t:1528143886698};\\\", \\\"{x:1906,y:270,t:1528143886715};\\\", \\\"{x:1900,y:286,t:1528143886731};\\\", \\\"{x:1888,y:301,t:1528143886748};\\\", \\\"{x:1868,y:312,t:1528143886765};\\\", \\\"{x:1853,y:321,t:1528143886781};\\\", \\\"{x:1848,y:322,t:1528143886798};\\\", \\\"{x:1845,y:324,t:1528143886816};\\\", \\\"{x:1844,y:324,t:1528143886840};\\\", \\\"{x:1842,y:324,t:1528143886848};\\\", \\\"{x:1819,y:326,t:1528143886865};\\\", \\\"{x:1761,y:335,t:1528143886881};\\\", \\\"{x:1676,y:344,t:1528143886899};\\\", \\\"{x:1628,y:352,t:1528143886915};\\\", \\\"{x:1611,y:355,t:1528143886932};\\\", \\\"{x:1609,y:356,t:1528143886949};\\\", \\\"{x:1606,y:358,t:1528143886965};\\\", \\\"{x:1603,y:362,t:1528143886981};\\\", \\\"{x:1602,y:377,t:1528143886998};\\\", \\\"{x:1602,y:419,t:1528143887015};\\\", \\\"{x:1614,y:513,t:1528143887031};\\\", \\\"{x:1655,y:676,t:1528143887048};\\\", \\\"{x:1690,y:787,t:1528143887065};\\\", \\\"{x:1728,y:909,t:1528143887082};\\\", \\\"{x:1756,y:1014,t:1528143887098};\\\", \\\"{x:1780,y:1107,t:1528143887116};\\\", \\\"{x:1790,y:1166,t:1528143887132};\\\", \\\"{x:1793,y:1183,t:1528143887148};\\\", \\\"{x:1793,y:1184,t:1528143887165};\\\", \\\"{x:1793,y:1185,t:1528143887184};\\\", \\\"{x:1791,y:1181,t:1528143887200};\\\", \\\"{x:1789,y:1173,t:1528143887215};\\\", \\\"{x:1764,y:1088,t:1528143887232};\\\", \\\"{x:1733,y:1019,t:1528143887249};\\\", \\\"{x:1709,y:987,t:1528143887265};\\\", \\\"{x:1706,y:982,t:1528143887282};\\\", \\\"{x:1705,y:982,t:1528143887298};\\\", \\\"{x:1701,y:976,t:1528143887315};\\\", \\\"{x:1696,y:964,t:1528143887333};\\\", \\\"{x:1691,y:944,t:1528143887349};\\\", \\\"{x:1684,y:916,t:1528143887366};\\\", \\\"{x:1676,y:895,t:1528143887383};\\\", \\\"{x:1670,y:874,t:1528143887399};\\\", \\\"{x:1668,y:864,t:1528143887416};\\\", \\\"{x:1666,y:855,t:1528143887433};\\\", \\\"{x:1665,y:852,t:1528143887449};\\\", \\\"{x:1663,y:843,t:1528143887466};\\\", \\\"{x:1662,y:823,t:1528143887482};\\\", \\\"{x:1659,y:803,t:1528143887499};\\\", \\\"{x:1654,y:780,t:1528143887516};\\\", \\\"{x:1646,y:760,t:1528143887533};\\\", \\\"{x:1642,y:753,t:1528143887550};\\\", \\\"{x:1641,y:748,t:1528143887566};\\\", \\\"{x:1638,y:742,t:1528143887583};\\\", \\\"{x:1636,y:736,t:1528143887600};\\\", \\\"{x:1634,y:732,t:1528143887615};\\\", \\\"{x:1630,y:727,t:1528143887633};\\\", \\\"{x:1629,y:726,t:1528143887649};\\\", \\\"{x:1627,y:725,t:1528143887722};\\\", \\\"{x:1627,y:722,t:1528143887733};\\\", \\\"{x:1626,y:715,t:1528143887750};\\\", \\\"{x:1623,y:710,t:1528143887766};\\\", \\\"{x:1623,y:707,t:1528143887783};\\\", \\\"{x:1623,y:706,t:1528143887808};\\\", \\\"{x:1623,y:704,t:1528143887824};\\\", \\\"{x:1623,y:703,t:1528143887832};\\\", \\\"{x:1623,y:700,t:1528143887850};\\\", \\\"{x:1623,y:696,t:1528143887866};\\\", \\\"{x:1623,y:694,t:1528143887883};\\\", \\\"{x:1620,y:699,t:1528143887953};\\\", \\\"{x:1615,y:715,t:1528143887966};\\\", \\\"{x:1600,y:763,t:1528143887983};\\\", \\\"{x:1583,y:819,t:1528143888000};\\\", \\\"{x:1562,y:886,t:1528143888017};\\\", \\\"{x:1547,y:922,t:1528143888033};\\\", \\\"{x:1535,y:950,t:1528143888050};\\\", \\\"{x:1525,y:973,t:1528143888067};\\\", \\\"{x:1516,y:997,t:1528143888082};\\\", \\\"{x:1512,y:1011,t:1528143888100};\\\", \\\"{x:1508,y:1027,t:1528143888117};\\\", \\\"{x:1504,y:1038,t:1528143888132};\\\", \\\"{x:1503,y:1044,t:1528143888149};\\\", \\\"{x:1503,y:1046,t:1528143888167};\\\", \\\"{x:1503,y:1045,t:1528143888273};\\\", \\\"{x:1502,y:1039,t:1528143888282};\\\", \\\"{x:1500,y:1028,t:1528143888299};\\\", \\\"{x:1499,y:1019,t:1528143888317};\\\", \\\"{x:1498,y:1010,t:1528143888333};\\\", \\\"{x:1497,y:1005,t:1528143888350};\\\", \\\"{x:1497,y:1000,t:1528143888367};\\\", \\\"{x:1496,y:998,t:1528143888383};\\\", \\\"{x:1495,y:995,t:1528143888399};\\\", \\\"{x:1495,y:994,t:1528143888417};\\\", \\\"{x:1495,y:993,t:1528143888434};\\\", \\\"{x:1494,y:993,t:1528143888513};\\\", \\\"{x:1491,y:989,t:1528143888520};\\\", \\\"{x:1488,y:983,t:1528143888534};\\\", \\\"{x:1486,y:978,t:1528143888550};\\\", \\\"{x:1484,y:974,t:1528143888567};\\\", \\\"{x:1481,y:970,t:1528143888583};\\\", \\\"{x:1477,y:965,t:1528143888600};\\\", \\\"{x:1470,y:959,t:1528143888616};\\\", \\\"{x:1469,y:958,t:1528143888634};\\\", \\\"{x:1468,y:958,t:1528143888673};\\\", \\\"{x:1469,y:958,t:1528143889073};\\\", \\\"{x:1469,y:959,t:1528143889083};\\\", \\\"{x:1472,y:961,t:1528143889101};\\\", \\\"{x:1474,y:962,t:1528143889117};\\\", \\\"{x:1475,y:963,t:1528143889134};\\\", \\\"{x:1476,y:963,t:1528143889151};\\\", \\\"{x:1476,y:964,t:1528143889167};\\\", \\\"{x:1479,y:964,t:1528143889184};\\\", \\\"{x:1479,y:965,t:1528143889201};\\\", \\\"{x:1480,y:966,t:1528143889216};\\\", \\\"{x:1481,y:966,t:1528143889273};\\\", \\\"{x:1481,y:965,t:1528143889360};\\\", \\\"{x:1481,y:963,t:1528143889376};\\\", \\\"{x:1481,y:962,t:1528143889392};\\\", \\\"{x:1481,y:961,t:1528143889505};\\\", \\\"{x:1482,y:961,t:1528143891033};\\\", \\\"{x:1483,y:961,t:1528143891074};\\\", \\\"{x:1485,y:961,t:1528143891104};\\\", \\\"{x:1485,y:962,t:1528143891119};\\\", \\\"{x:1487,y:963,t:1528143891136};\\\", \\\"{x:1488,y:963,t:1528143891152};\\\", \\\"{x:1489,y:964,t:1528143891225};\\\", \\\"{x:1489,y:965,t:1528143891236};\\\", \\\"{x:1489,y:967,t:1528143891252};\\\", \\\"{x:1489,y:968,t:1528143891269};\\\", \\\"{x:1489,y:969,t:1528143891288};\\\", \\\"{x:1489,y:970,t:1528143891425};\\\", \\\"{x:1488,y:970,t:1528143891456};\\\", \\\"{x:1487,y:970,t:1528143891469};\\\", \\\"{x:1486,y:970,t:1528143891505};\\\", \\\"{x:1485,y:970,t:1528143891520};\\\", \\\"{x:1484,y:970,t:1528143891536};\\\", \\\"{x:1483,y:970,t:1528143891560};\\\", \\\"{x:1482,y:970,t:1528143891577};\\\", \\\"{x:1481,y:970,t:1528143891585};\\\", \\\"{x:1480,y:970,t:1528143891616};\\\", \\\"{x:1479,y:970,t:1528143891657};\\\", \\\"{x:1478,y:970,t:1528143891745};\\\", \\\"{x:1477,y:970,t:1528143891976};\\\", \\\"{x:1476,y:970,t:1528143891985};\\\", \\\"{x:1475,y:969,t:1528143892040};\\\", \\\"{x:1475,y:968,t:1528143892393};\\\", \\\"{x:1475,y:966,t:1528143892403};\\\", \\\"{x:1474,y:961,t:1528143892420};\\\", \\\"{x:1472,y:955,t:1528143892437};\\\", \\\"{x:1472,y:950,t:1528143892453};\\\", \\\"{x:1470,y:940,t:1528143892470};\\\", \\\"{x:1467,y:932,t:1528143892488};\\\", \\\"{x:1466,y:926,t:1528143892502};\\\", \\\"{x:1464,y:922,t:1528143892520};\\\", \\\"{x:1464,y:920,t:1528143892536};\\\", \\\"{x:1462,y:918,t:1528143892553};\\\", \\\"{x:1461,y:916,t:1528143892570};\\\", \\\"{x:1460,y:915,t:1528143892587};\\\", \\\"{x:1460,y:913,t:1528143892603};\\\", \\\"{x:1459,y:911,t:1528143892620};\\\", \\\"{x:1457,y:908,t:1528143892637};\\\", \\\"{x:1456,y:906,t:1528143892653};\\\", \\\"{x:1453,y:901,t:1528143892670};\\\", \\\"{x:1448,y:895,t:1528143892688};\\\", \\\"{x:1445,y:889,t:1528143892702};\\\", \\\"{x:1440,y:882,t:1528143892719};\\\", \\\"{x:1437,y:877,t:1528143892736};\\\", \\\"{x:1433,y:871,t:1528143892752};\\\", \\\"{x:1429,y:863,t:1528143892769};\\\", \\\"{x:1427,y:859,t:1528143892786};\\\", \\\"{x:1423,y:854,t:1528143892804};\\\", \\\"{x:1421,y:849,t:1528143892819};\\\", \\\"{x:1419,y:846,t:1528143892837};\\\", \\\"{x:1416,y:839,t:1528143892853};\\\", \\\"{x:1412,y:830,t:1528143892870};\\\", \\\"{x:1404,y:816,t:1528143892887};\\\", \\\"{x:1393,y:801,t:1528143892904};\\\", \\\"{x:1390,y:796,t:1528143892919};\\\", \\\"{x:1383,y:786,t:1528143892936};\\\", \\\"{x:1379,y:778,t:1528143892953};\\\", \\\"{x:1376,y:771,t:1528143892970};\\\", \\\"{x:1369,y:760,t:1528143892987};\\\", \\\"{x:1361,y:746,t:1528143893003};\\\", \\\"{x:1355,y:735,t:1528143893020};\\\", \\\"{x:1352,y:729,t:1528143893037};\\\", \\\"{x:1350,y:726,t:1528143893054};\\\", \\\"{x:1348,y:722,t:1528143893070};\\\", \\\"{x:1346,y:720,t:1528143893087};\\\", \\\"{x:1345,y:717,t:1528143893103};\\\", \\\"{x:1343,y:713,t:1528143893119};\\\", \\\"{x:1338,y:704,t:1528143893137};\\\", \\\"{x:1334,y:694,t:1528143893154};\\\", \\\"{x:1330,y:686,t:1528143893169};\\\", \\\"{x:1327,y:678,t:1528143893187};\\\", \\\"{x:1321,y:669,t:1528143893203};\\\", \\\"{x:1315,y:658,t:1528143893221};\\\", \\\"{x:1308,y:647,t:1528143893236};\\\", \\\"{x:1305,y:643,t:1528143893253};\\\", \\\"{x:1302,y:638,t:1528143893270};\\\", \\\"{x:1299,y:633,t:1528143893286};\\\", \\\"{x:1296,y:628,t:1528143893304};\\\", \\\"{x:1290,y:614,t:1528143893320};\\\", \\\"{x:1286,y:607,t:1528143893336};\\\", \\\"{x:1283,y:603,t:1528143893353};\\\", \\\"{x:1283,y:601,t:1528143893370};\\\", \\\"{x:1281,y:598,t:1528143893386};\\\", \\\"{x:1279,y:594,t:1528143893404};\\\", \\\"{x:1277,y:591,t:1528143893421};\\\", \\\"{x:1275,y:585,t:1528143893436};\\\", \\\"{x:1272,y:580,t:1528143893454};\\\", \\\"{x:1268,y:573,t:1528143893471};\\\", \\\"{x:1264,y:567,t:1528143893487};\\\", \\\"{x:1259,y:558,t:1528143893503};\\\", \\\"{x:1255,y:552,t:1528143893520};\\\", \\\"{x:1253,y:550,t:1528143893537};\\\", \\\"{x:1252,y:548,t:1528143893554};\\\", \\\"{x:1251,y:546,t:1528143893576};\\\", \\\"{x:1246,y:546,t:1528143893801};\\\", \\\"{x:1234,y:550,t:1528143893808};\\\", \\\"{x:1216,y:558,t:1528143893821};\\\", \\\"{x:1169,y:578,t:1528143893838};\\\", \\\"{x:1101,y:603,t:1528143893854};\\\", \\\"{x:1023,y:624,t:1528143893872};\\\", \\\"{x:957,y:641,t:1528143893888};\\\", \\\"{x:901,y:655,t:1528143893904};\\\", \\\"{x:804,y:674,t:1528143893921};\\\", \\\"{x:740,y:693,t:1528143893938};\\\", \\\"{x:695,y:705,t:1528143893954};\\\", \\\"{x:662,y:718,t:1528143893971};\\\", \\\"{x:641,y:731,t:1528143893988};\\\", \\\"{x:626,y:739,t:1528143894004};\\\", \\\"{x:618,y:744,t:1528143894020};\\\", \\\"{x:614,y:745,t:1528143894038};\\\", \\\"{x:612,y:745,t:1528143894054};\\\", \\\"{x:610,y:745,t:1528143894071};\\\", \\\"{x:609,y:745,t:1528143894087};\\\", \\\"{x:606,y:745,t:1528143894113};\\\", \\\"{x:601,y:740,t:1528143894121};\\\", \\\"{x:579,y:719,t:1528143894138};\\\", \\\"{x:532,y:679,t:1528143894155};\\\", \\\"{x:491,y:646,t:1528143894172};\\\", \\\"{x:444,y:613,t:1528143894188};\\\", \\\"{x:398,y:588,t:1528143894204};\\\", \\\"{x:370,y:573,t:1528143894232};\\\", \\\"{x:364,y:569,t:1528143894249};\\\", \\\"{x:362,y:568,t:1528143894266};\\\", \\\"{x:360,y:566,t:1528143894283};\\\", \\\"{x:360,y:565,t:1528143894299};\\\", \\\"{x:360,y:564,t:1528143894316};\\\", \\\"{x:360,y:562,t:1528143894334};\\\", \\\"{x:361,y:559,t:1528143894349};\\\", \\\"{x:376,y:552,t:1528143894372};\\\", \\\"{x:383,y:550,t:1528143894387};\\\", \\\"{x:387,y:548,t:1528143894404};\\\", \\\"{x:390,y:547,t:1528143894421};\\\", \\\"{x:392,y:546,t:1528143894438};\\\", \\\"{x:396,y:545,t:1528143894455};\\\", \\\"{x:407,y:545,t:1528143894471};\\\", \\\"{x:419,y:545,t:1528143894488};\\\", \\\"{x:429,y:545,t:1528143894505};\\\", \\\"{x:432,y:545,t:1528143894520};\\\", \\\"{x:435,y:544,t:1528143894537};\\\", \\\"{x:437,y:544,t:1528143894554};\\\", \\\"{x:447,y:543,t:1528143894571};\\\", \\\"{x:469,y:543,t:1528143894587};\\\", \\\"{x:493,y:542,t:1528143894604};\\\", \\\"{x:518,y:539,t:1528143894622};\\\", \\\"{x:536,y:534,t:1528143894637};\\\", \\\"{x:552,y:532,t:1528143894654};\\\", \\\"{x:561,y:530,t:1528143894672};\\\", \\\"{x:573,y:519,t:1528143894688};\\\", \\\"{x:578,y:513,t:1528143894705};\\\", \\\"{x:580,y:511,t:1528143894721};\\\", \\\"{x:580,y:510,t:1528143894737};\\\", \\\"{x:582,y:509,t:1528143894755};\\\", \\\"{x:583,y:509,t:1528143894840};\\\", \\\"{x:583,y:510,t:1528143894855};\\\", \\\"{x:583,y:515,t:1528143894871};\\\", \\\"{x:585,y:522,t:1528143894889};\\\", \\\"{x:587,y:525,t:1528143894905};\\\", \\\"{x:592,y:530,t:1528143894921};\\\", \\\"{x:605,y:538,t:1528143894939};\\\", \\\"{x:623,y:545,t:1528143894955};\\\", \\\"{x:650,y:556,t:1528143894972};\\\", \\\"{x:673,y:562,t:1528143894988};\\\", \\\"{x:711,y:564,t:1528143895006};\\\", \\\"{x:744,y:564,t:1528143895022};\\\", \\\"{x:782,y:564,t:1528143895038};\\\", \\\"{x:821,y:555,t:1528143895056};\\\", \\\"{x:872,y:540,t:1528143895071};\\\", \\\"{x:894,y:535,t:1528143895088};\\\", \\\"{x:900,y:531,t:1528143895104};\\\", \\\"{x:914,y:520,t:1528143895122};\\\", \\\"{x:920,y:511,t:1528143895139};\\\", \\\"{x:920,y:508,t:1528143895155};\\\", \\\"{x:920,y:504,t:1528143895172};\\\", \\\"{x:917,y:499,t:1528143895188};\\\", \\\"{x:904,y:491,t:1528143895205};\\\", \\\"{x:898,y:489,t:1528143895222};\\\", \\\"{x:895,y:488,t:1528143895239};\\\", \\\"{x:889,y:487,t:1528143895255};\\\", \\\"{x:879,y:487,t:1528143895271};\\\", \\\"{x:872,y:487,t:1528143895288};\\\", \\\"{x:872,y:488,t:1528143895305};\\\", \\\"{x:871,y:488,t:1528143895322};\\\", \\\"{x:871,y:489,t:1528143895368};\\\", \\\"{x:871,y:490,t:1528143895376};\\\", \\\"{x:869,y:490,t:1528143895389};\\\", \\\"{x:866,y:492,t:1528143895405};\\\", \\\"{x:860,y:494,t:1528143895422};\\\", \\\"{x:855,y:497,t:1528143895438};\\\", \\\"{x:852,y:498,t:1528143895455};\\\", \\\"{x:851,y:499,t:1528143895471};\\\", \\\"{x:850,y:499,t:1528143895488};\\\", \\\"{x:848,y:500,t:1528143895505};\\\", \\\"{x:846,y:501,t:1528143895522};\\\", \\\"{x:845,y:501,t:1528143895539};\\\", \\\"{x:844,y:502,t:1528143895555};\\\", \\\"{x:842,y:502,t:1528143895681};\\\", \\\"{x:841,y:502,t:1528143895688};\\\", \\\"{x:835,y:502,t:1528143896007};\\\", \\\"{x:827,y:502,t:1528143896022};\\\", \\\"{x:809,y:502,t:1528143896039};\\\", \\\"{x:774,y:502,t:1528143896055};\\\", \\\"{x:746,y:502,t:1528143896073};\\\", \\\"{x:725,y:502,t:1528143896088};\\\", \\\"{x:709,y:502,t:1528143896107};\\\", \\\"{x:696,y:502,t:1528143896122};\\\", \\\"{x:685,y:502,t:1528143896139};\\\", \\\"{x:681,y:502,t:1528143896155};\\\", \\\"{x:680,y:502,t:1528143896200};\\\", \\\"{x:679,y:502,t:1528143896216};\\\", \\\"{x:678,y:502,t:1528143896224};\\\", \\\"{x:675,y:502,t:1528143896240};\\\", \\\"{x:674,y:502,t:1528143896255};\\\", \\\"{x:658,y:502,t:1528143896273};\\\", \\\"{x:647,y:502,t:1528143896289};\\\", \\\"{x:639,y:502,t:1528143896307};\\\", \\\"{x:633,y:502,t:1528143896323};\\\", \\\"{x:628,y:502,t:1528143896339};\\\", \\\"{x:627,y:502,t:1528143896356};\\\", \\\"{x:626,y:502,t:1528143896373};\\\", \\\"{x:625,y:502,t:1528143896433};\\\", \\\"{x:624,y:502,t:1528143896456};\\\", \\\"{x:622,y:502,t:1528143896473};\\\", \\\"{x:620,y:517,t:1528143896912};\\\", \\\"{x:617,y:538,t:1528143896924};\\\", \\\"{x:609,y:588,t:1528143896939};\\\", \\\"{x:605,y:627,t:1528143896957};\\\", \\\"{x:600,y:657,t:1528143896974};\\\", \\\"{x:596,y:684,t:1528143896990};\\\", \\\"{x:594,y:701,t:1528143897006};\\\", \\\"{x:590,y:717,t:1528143897023};\\\", \\\"{x:590,y:723,t:1528143897040};\\\", \\\"{x:590,y:732,t:1528143897056};\\\", \\\"{x:589,y:743,t:1528143897073};\\\", \\\"{x:585,y:756,t:1528143897089};\\\", \\\"{x:582,y:761,t:1528143897106};\\\", \\\"{x:582,y:763,t:1528143897124};\\\", \\\"{x:581,y:763,t:1528143897193};\\\", \\\"{x:580,y:763,t:1528143897206};\\\", \\\"{x:579,y:761,t:1528143897224};\\\", \\\"{x:578,y:761,t:1528143897281};\\\", \\\"{x:578,y:760,t:1528143897289};\\\", \\\"{x:576,y:759,t:1528143897306};\\\", \\\"{x:574,y:759,t:1528143897344};\\\", \\\"{x:573,y:757,t:1528143897356};\\\", \\\"{x:572,y:757,t:1528143897374};\\\", \\\"{x:571,y:756,t:1528143897408};\\\", \\\"{x:571,y:755,t:1528143897424};\\\", \\\"{x:569,y:753,t:1528143897440};\\\", \\\"{x:567,y:751,t:1528143897457};\\\", \\\"{x:566,y:750,t:1528143897474};\\\", \\\"{x:565,y:749,t:1528143897490};\\\", \\\"{x:564,y:748,t:1528143897509};\\\", \\\"{x:562,y:747,t:1528143897523};\\\", \\\"{x:559,y:745,t:1528143897540};\\\", \\\"{x:556,y:742,t:1528143897556};\\\", \\\"{x:552,y:739,t:1528143897574};\\\", \\\"{x:549,y:738,t:1528143897590};\\\", \\\"{x:548,y:737,t:1528143897608};\\\", \\\"{x:547,y:737,t:1528143897680};\\\", \\\"{x:547,y:740,t:1528143897984};\\\", \\\"{x:551,y:748,t:1528143897992};\\\", \\\"{x:562,y:770,t:1528143898007};\\\", \\\"{x:573,y:789,t:1528143898024};\\\", \\\"{x:587,y:809,t:1528143898041};\\\", \\\"{x:603,y:831,t:1528143898057};\\\", \\\"{x:621,y:856,t:1528143898074};\\\", \\\"{x:655,y:899,t:1528143898090};\\\", \\\"{x:701,y:947,t:1528143898108};\\\", \\\"{x:731,y:979,t:1528143898124};\\\", \\\"{x:766,y:1006,t:1528143898140};\\\", \\\"{x:795,y:1027,t:1528143898157};\\\", \\\"{x:820,y:1044,t:1528143898174};\\\", \\\"{x:835,y:1051,t:1528143898191};\\\", \\\"{x:842,y:1054,t:1528143898207};\\\", \\\"{x:843,y:1054,t:1528143898225};\\\" ] }, { \\\"rt\\\": 9464, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 590402, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"TTCWS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 AM-03 PM-X -03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:846,y:1054,t:1528143900521};\\\", \\\"{x:930,y:1021,t:1528143900560};\\\", \\\"{x:957,y:1010,t:1528143900576};\\\", \\\"{x:996,y:999,t:1528143900593};\\\", \\\"{x:1036,y:986,t:1528143900610};\\\", \\\"{x:1068,y:979,t:1528143900626};\\\", \\\"{x:1110,y:968,t:1528143900643};\\\", \\\"{x:1171,y:949,t:1528143900660};\\\", \\\"{x:1235,y:930,t:1528143900675};\\\", \\\"{x:1294,y:911,t:1528143900693};\\\", \\\"{x:1344,y:890,t:1528143900709};\\\", \\\"{x:1390,y:872,t:1528143900726};\\\", \\\"{x:1446,y:855,t:1528143900743};\\\", \\\"{x:1509,y:849,t:1528143900760};\\\", \\\"{x:1540,y:849,t:1528143900776};\\\", \\\"{x:1558,y:849,t:1528143900793};\\\", \\\"{x:1565,y:849,t:1528143900810};\\\", \\\"{x:1574,y:849,t:1528143900826};\\\", \\\"{x:1582,y:849,t:1528143900843};\\\", \\\"{x:1593,y:850,t:1528143900860};\\\", \\\"{x:1604,y:855,t:1528143900876};\\\", \\\"{x:1618,y:861,t:1528143900892};\\\", \\\"{x:1632,y:868,t:1528143900910};\\\", \\\"{x:1642,y:877,t:1528143900927};\\\", \\\"{x:1650,y:887,t:1528143900943};\\\", \\\"{x:1652,y:904,t:1528143900960};\\\", \\\"{x:1650,y:926,t:1528143900977};\\\", \\\"{x:1644,y:944,t:1528143900992};\\\", \\\"{x:1641,y:952,t:1528143901009};\\\", \\\"{x:1636,y:958,t:1528143901027};\\\", \\\"{x:1628,y:960,t:1528143901043};\\\", \\\"{x:1615,y:960,t:1528143901060};\\\", \\\"{x:1596,y:963,t:1528143901077};\\\", \\\"{x:1580,y:966,t:1528143901093};\\\", \\\"{x:1566,y:969,t:1528143901110};\\\", \\\"{x:1560,y:970,t:1528143901127};\\\", \\\"{x:1560,y:971,t:1528143901143};\\\", \\\"{x:1559,y:971,t:1528143901521};\\\", \\\"{x:1557,y:971,t:1528143901537};\\\", \\\"{x:1556,y:971,t:1528143901544};\\\", \\\"{x:1553,y:971,t:1528143901560};\\\", \\\"{x:1552,y:971,t:1528143901578};\\\", \\\"{x:1551,y:970,t:1528143901616};\\\", \\\"{x:1550,y:969,t:1528143901632};\\\", \\\"{x:1549,y:968,t:1528143901645};\\\", \\\"{x:1548,y:968,t:1528143901661};\\\", \\\"{x:1547,y:967,t:1528143901704};\\\", \\\"{x:1546,y:966,t:1528143901713};\\\", \\\"{x:1545,y:965,t:1528143901728};\\\", \\\"{x:1543,y:962,t:1528143901744};\\\", \\\"{x:1542,y:961,t:1528143901760};\\\", \\\"{x:1541,y:959,t:1528143902608};\\\", \\\"{x:1539,y:954,t:1528143902616};\\\", \\\"{x:1535,y:946,t:1528143902629};\\\", \\\"{x:1532,y:941,t:1528143902646};\\\", \\\"{x:1531,y:937,t:1528143902661};\\\", \\\"{x:1529,y:933,t:1528143902679};\\\", \\\"{x:1526,y:929,t:1528143902695};\\\", \\\"{x:1526,y:928,t:1528143902712};\\\", \\\"{x:1524,y:926,t:1528143902729};\\\", \\\"{x:1524,y:925,t:1528143902745};\\\", \\\"{x:1523,y:921,t:1528143902761};\\\", \\\"{x:1522,y:915,t:1528143902778};\\\", \\\"{x:1520,y:910,t:1528143902795};\\\", \\\"{x:1519,y:906,t:1528143902811};\\\", \\\"{x:1516,y:897,t:1528143902827};\\\", \\\"{x:1511,y:889,t:1528143902844};\\\", \\\"{x:1508,y:884,t:1528143902861};\\\", \\\"{x:1506,y:878,t:1528143902878};\\\", \\\"{x:1503,y:873,t:1528143902895};\\\", \\\"{x:1500,y:870,t:1528143902911};\\\", \\\"{x:1495,y:864,t:1528143902928};\\\", \\\"{x:1492,y:859,t:1528143902945};\\\", \\\"{x:1489,y:857,t:1528143902961};\\\", \\\"{x:1487,y:852,t:1528143902978};\\\", \\\"{x:1483,y:848,t:1528143902995};\\\", \\\"{x:1481,y:845,t:1528143903010};\\\", \\\"{x:1479,y:842,t:1528143903028};\\\", \\\"{x:1478,y:839,t:1528143903044};\\\", \\\"{x:1476,y:836,t:1528143903061};\\\", \\\"{x:1474,y:833,t:1528143903077};\\\", \\\"{x:1473,y:833,t:1528143903095};\\\", \\\"{x:1473,y:831,t:1528143903136};\\\", \\\"{x:1473,y:830,t:1528143903145};\\\", \\\"{x:1471,y:828,t:1528143903162};\\\", \\\"{x:1472,y:827,t:1528143903313};\\\", \\\"{x:1474,y:827,t:1528143903328};\\\", \\\"{x:1475,y:827,t:1528143903353};\\\", \\\"{x:1477,y:828,t:1528143903371};\\\", \\\"{x:1478,y:829,t:1528143903832};\\\", \\\"{x:1478,y:830,t:1528143903845};\\\", \\\"{x:1481,y:839,t:1528143903864};\\\", \\\"{x:1482,y:846,t:1528143903879};\\\", \\\"{x:1485,y:854,t:1528143903896};\\\", \\\"{x:1486,y:858,t:1528143903912};\\\", \\\"{x:1486,y:859,t:1528143903929};\\\", \\\"{x:1486,y:858,t:1528143904417};\\\", \\\"{x:1486,y:857,t:1528143904429};\\\", \\\"{x:1486,y:856,t:1528143904446};\\\", \\\"{x:1486,y:855,t:1528143904463};\\\", \\\"{x:1488,y:855,t:1528143904537};\\\", \\\"{x:1489,y:855,t:1528143904547};\\\", \\\"{x:1494,y:857,t:1528143904564};\\\", \\\"{x:1497,y:857,t:1528143904579};\\\", \\\"{x:1501,y:861,t:1528143904596};\\\", \\\"{x:1511,y:876,t:1528143904614};\\\", \\\"{x:1527,y:901,t:1528143904630};\\\", \\\"{x:1537,y:916,t:1528143904646};\\\", \\\"{x:1544,y:923,t:1528143904663};\\\", \\\"{x:1547,y:927,t:1528143904679};\\\", \\\"{x:1549,y:929,t:1528143904697};\\\", \\\"{x:1550,y:930,t:1528143904713};\\\", \\\"{x:1550,y:931,t:1528143904730};\\\", \\\"{x:1551,y:934,t:1528143904747};\\\", \\\"{x:1555,y:939,t:1528143904763};\\\", \\\"{x:1557,y:943,t:1528143904780};\\\", \\\"{x:1558,y:943,t:1528143904796};\\\", \\\"{x:1558,y:944,t:1528143904814};\\\", \\\"{x:1558,y:946,t:1528143904829};\\\", \\\"{x:1560,y:948,t:1528143904846};\\\", \\\"{x:1560,y:951,t:1528143904863};\\\", \\\"{x:1561,y:958,t:1528143904880};\\\", \\\"{x:1561,y:962,t:1528143904897};\\\", \\\"{x:1561,y:963,t:1528143904914};\\\", \\\"{x:1561,y:966,t:1528143904931};\\\", \\\"{x:1562,y:968,t:1528143904947};\\\", \\\"{x:1562,y:969,t:1528143904964};\\\", \\\"{x:1562,y:963,t:1528143905041};\\\", \\\"{x:1553,y:947,t:1528143905048};\\\", \\\"{x:1542,y:931,t:1528143905064};\\\", \\\"{x:1500,y:873,t:1528143905081};\\\", \\\"{x:1478,y:844,t:1528143905097};\\\", \\\"{x:1460,y:827,t:1528143905113};\\\", \\\"{x:1448,y:818,t:1528143905131};\\\", \\\"{x:1441,y:808,t:1528143905147};\\\", \\\"{x:1438,y:804,t:1528143905164};\\\", \\\"{x:1434,y:798,t:1528143905180};\\\", \\\"{x:1427,y:783,t:1528143905197};\\\", \\\"{x:1418,y:765,t:1528143905213};\\\", \\\"{x:1408,y:740,t:1528143905231};\\\", \\\"{x:1399,y:723,t:1528143905247};\\\", \\\"{x:1394,y:713,t:1528143905264};\\\", \\\"{x:1391,y:705,t:1528143905280};\\\", \\\"{x:1388,y:700,t:1528143905296};\\\", \\\"{x:1383,y:690,t:1528143905313};\\\", \\\"{x:1376,y:676,t:1528143905331};\\\", \\\"{x:1370,y:661,t:1528143905347};\\\", \\\"{x:1359,y:640,t:1528143905364};\\\", \\\"{x:1350,y:620,t:1528143905380};\\\", \\\"{x:1339,y:599,t:1528143905398};\\\", \\\"{x:1328,y:578,t:1528143905414};\\\", \\\"{x:1315,y:560,t:1528143905431};\\\", \\\"{x:1305,y:548,t:1528143905448};\\\", \\\"{x:1290,y:538,t:1528143905464};\\\", \\\"{x:1268,y:529,t:1528143905481};\\\", \\\"{x:1257,y:529,t:1528143905498};\\\", \\\"{x:1244,y:534,t:1528143905513};\\\", \\\"{x:1218,y:561,t:1528143905531};\\\", \\\"{x:1176,y:615,t:1528143905548};\\\", \\\"{x:1112,y:700,t:1528143905563};\\\", \\\"{x:1043,y:784,t:1528143905580};\\\", \\\"{x:987,y:850,t:1528143905597};\\\", \\\"{x:948,y:887,t:1528143905614};\\\", \\\"{x:926,y:896,t:1528143905631};\\\", \\\"{x:911,y:897,t:1528143905647};\\\", \\\"{x:899,y:897,t:1528143905663};\\\", \\\"{x:880,y:890,t:1528143905681};\\\", \\\"{x:855,y:872,t:1528143905698};\\\", \\\"{x:821,y:848,t:1528143905714};\\\", \\\"{x:774,y:819,t:1528143905731};\\\", \\\"{x:728,y:794,t:1528143905748};\\\", \\\"{x:676,y:771,t:1528143905764};\\\", \\\"{x:619,y:749,t:1528143905780};\\\", \\\"{x:566,y:728,t:1528143905798};\\\", \\\"{x:525,y:703,t:1528143905815};\\\", \\\"{x:493,y:678,t:1528143905830};\\\", \\\"{x:467,y:652,t:1528143905849};\\\", \\\"{x:439,y:622,t:1528143905864};\\\", \\\"{x:421,y:607,t:1528143905880};\\\", \\\"{x:407,y:593,t:1528143905897};\\\", \\\"{x:390,y:578,t:1528143905914};\\\", \\\"{x:379,y:568,t:1528143905930};\\\", \\\"{x:367,y:557,t:1528143905948};\\\", \\\"{x:355,y:546,t:1528143905965};\\\", \\\"{x:345,y:536,t:1528143905979};\\\", \\\"{x:343,y:533,t:1528143905997};\\\", \\\"{x:344,y:533,t:1528143906056};\\\", \\\"{x:349,y:534,t:1528143906063};\\\", \\\"{x:366,y:542,t:1528143906080};\\\", \\\"{x:383,y:554,t:1528143906097};\\\", \\\"{x:394,y:563,t:1528143906115};\\\", \\\"{x:403,y:567,t:1528143906131};\\\", \\\"{x:418,y:573,t:1528143906147};\\\", \\\"{x:429,y:577,t:1528143906164};\\\", \\\"{x:435,y:580,t:1528143906181};\\\", \\\"{x:444,y:582,t:1528143906197};\\\", \\\"{x:458,y:586,t:1528143906214};\\\", \\\"{x:478,y:590,t:1528143906231};\\\", \\\"{x:500,y:597,t:1528143906249};\\\", \\\"{x:541,y:607,t:1528143906264};\\\", \\\"{x:579,y:614,t:1528143906281};\\\", \\\"{x:619,y:619,t:1528143906297};\\\", \\\"{x:643,y:621,t:1528143906314};\\\", \\\"{x:654,y:621,t:1528143906331};\\\", \\\"{x:660,y:621,t:1528143906346};\\\", \\\"{x:666,y:620,t:1528143906364};\\\", \\\"{x:674,y:620,t:1528143906381};\\\", \\\"{x:684,y:620,t:1528143906397};\\\", \\\"{x:699,y:620,t:1528143906414};\\\", \\\"{x:717,y:620,t:1528143906431};\\\", \\\"{x:736,y:620,t:1528143906448};\\\", \\\"{x:761,y:618,t:1528143906464};\\\", \\\"{x:779,y:614,t:1528143906481};\\\", \\\"{x:790,y:610,t:1528143906498};\\\", \\\"{x:800,y:606,t:1528143906514};\\\", \\\"{x:810,y:602,t:1528143906531};\\\", \\\"{x:816,y:599,t:1528143906548};\\\", \\\"{x:830,y:592,t:1528143906565};\\\", \\\"{x:843,y:587,t:1528143906581};\\\", \\\"{x:850,y:584,t:1528143906598};\\\", \\\"{x:851,y:582,t:1528143906614};\\\", \\\"{x:852,y:582,t:1528143906630};\\\", \\\"{x:852,y:579,t:1528143906647};\\\", \\\"{x:852,y:575,t:1528143906664};\\\", \\\"{x:841,y:572,t:1528143906681};\\\", \\\"{x:825,y:566,t:1528143906699};\\\", \\\"{x:802,y:566,t:1528143906714};\\\", \\\"{x:780,y:566,t:1528143906730};\\\", \\\"{x:761,y:568,t:1528143906748};\\\", \\\"{x:750,y:572,t:1528143906765};\\\", \\\"{x:745,y:575,t:1528143906781};\\\", \\\"{x:739,y:576,t:1528143906798};\\\", \\\"{x:737,y:578,t:1528143906815};\\\", \\\"{x:732,y:580,t:1528143906831};\\\", \\\"{x:727,y:589,t:1528143906848};\\\", \\\"{x:727,y:600,t:1528143906866};\\\", \\\"{x:727,y:614,t:1528143906882};\\\", \\\"{x:727,y:621,t:1528143906898};\\\", \\\"{x:727,y:627,t:1528143906914};\\\", \\\"{x:727,y:628,t:1528143906936};\\\", \\\"{x:726,y:629,t:1528143906949};\\\", \\\"{x:721,y:631,t:1528143906966};\\\", \\\"{x:714,y:634,t:1528143906982};\\\", \\\"{x:703,y:635,t:1528143906998};\\\", \\\"{x:697,y:636,t:1528143907014};\\\", \\\"{x:695,y:636,t:1528143907031};\\\", \\\"{x:695,y:635,t:1528143907113};\\\", \\\"{x:695,y:634,t:1528143907128};\\\", \\\"{x:695,y:633,t:1528143907144};\\\", \\\"{x:695,y:632,t:1528143907152};\\\", \\\"{x:693,y:630,t:1528143907169};\\\", \\\"{x:689,y:628,t:1528143907181};\\\", \\\"{x:673,y:621,t:1528143907197};\\\", \\\"{x:652,y:611,t:1528143907213};\\\", \\\"{x:630,y:601,t:1528143907231};\\\", \\\"{x:616,y:595,t:1528143907247};\\\", \\\"{x:607,y:591,t:1528143907265};\\\", \\\"{x:606,y:591,t:1528143907311};\\\", \\\"{x:606,y:590,t:1528143907400};\\\", \\\"{x:606,y:588,t:1528143907416};\\\", \\\"{x:605,y:583,t:1528143907431};\\\", \\\"{x:605,y:582,t:1528143907448};\\\", \\\"{x:605,y:581,t:1528143907472};\\\", \\\"{x:605,y:580,t:1528143907482};\\\", \\\"{x:605,y:578,t:1528143907499};\\\", \\\"{x:604,y:575,t:1528143907515};\\\", \\\"{x:604,y:572,t:1528143907532};\\\", \\\"{x:603,y:570,t:1528143907548};\\\", \\\"{x:595,y:577,t:1528143907776};\\\", \\\"{x:583,y:593,t:1528143907783};\\\", \\\"{x:571,y:614,t:1528143907799};\\\", \\\"{x:558,y:636,t:1528143907815};\\\", \\\"{x:545,y:670,t:1528143907832};\\\", \\\"{x:537,y:682,t:1528143907848};\\\", \\\"{x:533,y:687,t:1528143907865};\\\", \\\"{x:532,y:688,t:1528143907882};\\\", \\\"{x:530,y:690,t:1528143907898};\\\", \\\"{x:527,y:692,t:1528143907915};\\\", \\\"{x:524,y:692,t:1528143907933};\\\", \\\"{x:522,y:694,t:1528143907948};\\\", \\\"{x:522,y:696,t:1528143907965};\\\", \\\"{x:521,y:699,t:1528143907982};\\\", \\\"{x:520,y:701,t:1528143907999};\\\", \\\"{x:519,y:703,t:1528143908015};\\\", \\\"{x:518,y:705,t:1528143908032};\\\", \\\"{x:517,y:707,t:1528143908089};\\\", \\\"{x:515,y:708,t:1528143908099};\\\", \\\"{x:513,y:713,t:1528143908115};\\\", \\\"{x:512,y:714,t:1528143908133};\\\", \\\"{x:510,y:717,t:1528143908149};\\\", \\\"{x:508,y:720,t:1528143908167};\\\", \\\"{x:507,y:722,t:1528143908182};\\\", \\\"{x:506,y:724,t:1528143908198};\\\", \\\"{x:505,y:726,t:1528143908215};\\\", \\\"{x:505,y:727,t:1528143908232};\\\", \\\"{x:505,y:728,t:1528143908255};\\\", \\\"{x:506,y:736,t:1528143908647};\\\", \\\"{x:515,y:749,t:1528143908655};\\\", \\\"{x:527,y:764,t:1528143908666};\\\", \\\"{x:555,y:791,t:1528143908682};\\\", \\\"{x:596,y:814,t:1528143908699};\\\", \\\"{x:632,y:829,t:1528143908716};\\\", \\\"{x:673,y:839,t:1528143908732};\\\", \\\"{x:723,y:850,t:1528143908749};\\\", \\\"{x:770,y:855,t:1528143908767};\\\", \\\"{x:821,y:858,t:1528143908783};\\\", \\\"{x:874,y:858,t:1528143908800};\\\", \\\"{x:902,y:858,t:1528143908816};\\\", \\\"{x:926,y:858,t:1528143908834};\\\", \\\"{x:944,y:858,t:1528143908849};\\\", \\\"{x:952,y:858,t:1528143908866};\\\", \\\"{x:954,y:858,t:1528143908883};\\\" ] }, { \\\"rt\\\": 18441, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 610069, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"TTCWS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-05 PM-04 PM-03 PM-02 PM-02 PM-X -X -K \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:956,y:861,t:1528143914552};\\\", \\\"{x:957,y:867,t:1528143914561};\\\", \\\"{x:959,y:871,t:1528143914571};\\\", \\\"{x:967,y:885,t:1528143914588};\\\", \\\"{x:971,y:892,t:1528143914604};\\\", \\\"{x:972,y:894,t:1528143914621};\\\", \\\"{x:975,y:897,t:1528143914638};\\\", \\\"{x:979,y:900,t:1528143914655};\\\", \\\"{x:990,y:909,t:1528143914672};\\\", \\\"{x:1006,y:921,t:1528143914688};\\\", \\\"{x:1038,y:943,t:1528143914704};\\\", \\\"{x:1066,y:960,t:1528143914721};\\\", \\\"{x:1106,y:983,t:1528143914738};\\\", \\\"{x:1152,y:1006,t:1528143914756};\\\", \\\"{x:1197,y:1030,t:1528143914771};\\\", \\\"{x:1231,y:1046,t:1528143914788};\\\", \\\"{x:1280,y:1065,t:1528143914805};\\\", \\\"{x:1331,y:1081,t:1528143914821};\\\", \\\"{x:1372,y:1093,t:1528143914838};\\\", \\\"{x:1417,y:1105,t:1528143914855};\\\", \\\"{x:1502,y:1116,t:1528143914872};\\\", \\\"{x:1563,y:1124,t:1528143914888};\\\", \\\"{x:1616,y:1132,t:1528143914905};\\\", \\\"{x:1662,y:1135,t:1528143914921};\\\", \\\"{x:1704,y:1135,t:1528143914937};\\\", \\\"{x:1751,y:1125,t:1528143914954};\\\", \\\"{x:1802,y:1110,t:1528143914972};\\\", \\\"{x:1842,y:1096,t:1528143914988};\\\", \\\"{x:1864,y:1083,t:1528143915006};\\\", \\\"{x:1874,y:1071,t:1528143915022};\\\", \\\"{x:1880,y:1053,t:1528143915038};\\\", \\\"{x:1885,y:1031,t:1528143915055};\\\", \\\"{x:1886,y:1006,t:1528143915072};\\\", \\\"{x:1885,y:1002,t:1528143915088};\\\", \\\"{x:1885,y:1001,t:1528143915105};\\\", \\\"{x:1884,y:1000,t:1528143915176};\\\", \\\"{x:1883,y:999,t:1528143915188};\\\", \\\"{x:1881,y:998,t:1528143915204};\\\", \\\"{x:1874,y:994,t:1528143915221};\\\", \\\"{x:1865,y:990,t:1528143915238};\\\", \\\"{x:1859,y:988,t:1528143915255};\\\", \\\"{x:1838,y:985,t:1528143915272};\\\", \\\"{x:1818,y:985,t:1528143915288};\\\", \\\"{x:1794,y:985,t:1528143915305};\\\", \\\"{x:1771,y:985,t:1528143915321};\\\", \\\"{x:1754,y:985,t:1528143915338};\\\", \\\"{x:1738,y:985,t:1528143915355};\\\", \\\"{x:1715,y:984,t:1528143915372};\\\", \\\"{x:1693,y:980,t:1528143915389};\\\", \\\"{x:1675,y:978,t:1528143915405};\\\", \\\"{x:1664,y:976,t:1528143915422};\\\", \\\"{x:1655,y:975,t:1528143915440};\\\", \\\"{x:1647,y:974,t:1528143915455};\\\", \\\"{x:1637,y:971,t:1528143915472};\\\", \\\"{x:1629,y:970,t:1528143915489};\\\", \\\"{x:1621,y:970,t:1528143915507};\\\", \\\"{x:1605,y:970,t:1528143915521};\\\", \\\"{x:1586,y:969,t:1528143915538};\\\", \\\"{x:1568,y:969,t:1528143915555};\\\", \\\"{x:1557,y:969,t:1528143915571};\\\", \\\"{x:1555,y:969,t:1528143915588};\\\", \\\"{x:1554,y:969,t:1528143915605};\\\", \\\"{x:1552,y:969,t:1528143915621};\\\", \\\"{x:1551,y:969,t:1528143915638};\\\", \\\"{x:1549,y:969,t:1528143915655};\\\", \\\"{x:1546,y:967,t:1528143915672};\\\", \\\"{x:1543,y:967,t:1528143915689};\\\", \\\"{x:1540,y:967,t:1528143915705};\\\", \\\"{x:1534,y:967,t:1528143915721};\\\", \\\"{x:1529,y:967,t:1528143915739};\\\", \\\"{x:1528,y:967,t:1528143915755};\\\", \\\"{x:1526,y:967,t:1528143915772};\\\", \\\"{x:1524,y:967,t:1528143915788};\\\", \\\"{x:1519,y:967,t:1528143915806};\\\", \\\"{x:1510,y:967,t:1528143915822};\\\", \\\"{x:1500,y:967,t:1528143915839};\\\", \\\"{x:1481,y:969,t:1528143915856};\\\", \\\"{x:1472,y:969,t:1528143915872};\\\", \\\"{x:1467,y:969,t:1528143915889};\\\", \\\"{x:1466,y:969,t:1528143915907};\\\", \\\"{x:1465,y:969,t:1528143915936};\\\", \\\"{x:1464,y:969,t:1528143915944};\\\", \\\"{x:1463,y:969,t:1528143915956};\\\", \\\"{x:1463,y:968,t:1528143916097};\\\", \\\"{x:1463,y:967,t:1528143916108};\\\", \\\"{x:1464,y:961,t:1528143916122};\\\", \\\"{x:1465,y:959,t:1528143916139};\\\", \\\"{x:1467,y:957,t:1528143916156};\\\", \\\"{x:1467,y:956,t:1528143916173};\\\", \\\"{x:1469,y:955,t:1528143916189};\\\", \\\"{x:1470,y:954,t:1528143916273};\\\", \\\"{x:1471,y:954,t:1528143916361};\\\", \\\"{x:1472,y:954,t:1528143916373};\\\", \\\"{x:1474,y:954,t:1528143916390};\\\", \\\"{x:1475,y:954,t:1528143916406};\\\", \\\"{x:1476,y:955,t:1528143916425};\\\", \\\"{x:1478,y:956,t:1528143916439};\\\", \\\"{x:1482,y:958,t:1528143916457};\\\", \\\"{x:1482,y:959,t:1528143916537};\\\", \\\"{x:1482,y:960,t:1528143916545};\\\", \\\"{x:1483,y:960,t:1528143916561};\\\", \\\"{x:1483,y:963,t:1528143917105};\\\", \\\"{x:1483,y:964,t:1528143917112};\\\", \\\"{x:1483,y:965,t:1528143917123};\\\", \\\"{x:1482,y:968,t:1528143917140};\\\", \\\"{x:1482,y:969,t:1528143917157};\\\", \\\"{x:1481,y:969,t:1528143917173};\\\", \\\"{x:1481,y:970,t:1528143917190};\\\", \\\"{x:1481,y:969,t:1528143917401};\\\", \\\"{x:1481,y:968,t:1528143917409};\\\", \\\"{x:1481,y:966,t:1528143917424};\\\", \\\"{x:1481,y:961,t:1528143917440};\\\", \\\"{x:1481,y:956,t:1528143917456};\\\", \\\"{x:1481,y:952,t:1528143917474};\\\", \\\"{x:1481,y:946,t:1528143917490};\\\", \\\"{x:1481,y:941,t:1528143917507};\\\", \\\"{x:1481,y:938,t:1528143917525};\\\", \\\"{x:1481,y:934,t:1528143917541};\\\", \\\"{x:1479,y:928,t:1528143917557};\\\", \\\"{x:1479,y:924,t:1528143917574};\\\", \\\"{x:1479,y:922,t:1528143917590};\\\", \\\"{x:1479,y:919,t:1528143917607};\\\", \\\"{x:1479,y:914,t:1528143917624};\\\", \\\"{x:1477,y:910,t:1528143917640};\\\", \\\"{x:1476,y:904,t:1528143917658};\\\", \\\"{x:1476,y:901,t:1528143917674};\\\", \\\"{x:1475,y:895,t:1528143917691};\\\", \\\"{x:1474,y:891,t:1528143917708};\\\", \\\"{x:1473,y:886,t:1528143917724};\\\", \\\"{x:1472,y:880,t:1528143917741};\\\", \\\"{x:1472,y:876,t:1528143917757};\\\", \\\"{x:1472,y:875,t:1528143917774};\\\", \\\"{x:1471,y:872,t:1528143917790};\\\", \\\"{x:1471,y:870,t:1528143917810};\\\", \\\"{x:1471,y:869,t:1528143917826};\\\", \\\"{x:1471,y:867,t:1528143917843};\\\", \\\"{x:1471,y:866,t:1528143917859};\\\", \\\"{x:1471,y:864,t:1528143917876};\\\", \\\"{x:1471,y:863,t:1528143917892};\\\", \\\"{x:1471,y:861,t:1528143917910};\\\", \\\"{x:1471,y:860,t:1528143917927};\\\", \\\"{x:1471,y:858,t:1528143917947};\\\", \\\"{x:1472,y:857,t:1528143917960};\\\", \\\"{x:1472,y:853,t:1528143917976};\\\", \\\"{x:1475,y:849,t:1528143917993};\\\", \\\"{x:1476,y:846,t:1528143918009};\\\", \\\"{x:1477,y:843,t:1528143918026};\\\", \\\"{x:1478,y:842,t:1528143918043};\\\", \\\"{x:1478,y:840,t:1528143918058};\\\", \\\"{x:1480,y:839,t:1528143918075};\\\", \\\"{x:1480,y:838,t:1528143918093};\\\", \\\"{x:1480,y:837,t:1528143918259};\\\", \\\"{x:1481,y:834,t:1528143918279};\\\", \\\"{x:1481,y:833,t:1528143918292};\\\", \\\"{x:1481,y:831,t:1528143918308};\\\", \\\"{x:1481,y:830,t:1528143918326};\\\", \\\"{x:1481,y:829,t:1528143918402};\\\", \\\"{x:1481,y:828,t:1528143918417};\\\", \\\"{x:1481,y:827,t:1528143918434};\\\", \\\"{x:1481,y:826,t:1528143918450};\\\", \\\"{x:1481,y:824,t:1528143919148};\\\", \\\"{x:1481,y:820,t:1528143919160};\\\", \\\"{x:1480,y:810,t:1528143919178};\\\", \\\"{x:1479,y:799,t:1528143919193};\\\", \\\"{x:1477,y:782,t:1528143919210};\\\", \\\"{x:1476,y:771,t:1528143919227};\\\", \\\"{x:1476,y:761,t:1528143919245};\\\", \\\"{x:1476,y:754,t:1528143919260};\\\", \\\"{x:1476,y:747,t:1528143919277};\\\", \\\"{x:1475,y:739,t:1528143919295};\\\", \\\"{x:1474,y:730,t:1528143919310};\\\", \\\"{x:1473,y:724,t:1528143919327};\\\", \\\"{x:1472,y:720,t:1528143919344};\\\", \\\"{x:1471,y:716,t:1528143919361};\\\", \\\"{x:1471,y:714,t:1528143919378};\\\", \\\"{x:1469,y:708,t:1528143919395};\\\", \\\"{x:1469,y:704,t:1528143919411};\\\", \\\"{x:1468,y:698,t:1528143919427};\\\", \\\"{x:1468,y:694,t:1528143919445};\\\", \\\"{x:1468,y:690,t:1528143919460};\\\", \\\"{x:1467,y:687,t:1528143919478};\\\", \\\"{x:1467,y:683,t:1528143919495};\\\", \\\"{x:1467,y:677,t:1528143919511};\\\", \\\"{x:1467,y:671,t:1528143919527};\\\", \\\"{x:1467,y:666,t:1528143919544};\\\", \\\"{x:1467,y:661,t:1528143919559};\\\", \\\"{x:1467,y:657,t:1528143919577};\\\", \\\"{x:1467,y:651,t:1528143919594};\\\", \\\"{x:1467,y:647,t:1528143919610};\\\", \\\"{x:1467,y:641,t:1528143919627};\\\", \\\"{x:1470,y:632,t:1528143919644};\\\", \\\"{x:1471,y:625,t:1528143919660};\\\", \\\"{x:1473,y:614,t:1528143919677};\\\", \\\"{x:1474,y:608,t:1528143919694};\\\", \\\"{x:1475,y:603,t:1528143919711};\\\", \\\"{x:1475,y:596,t:1528143919727};\\\", \\\"{x:1476,y:590,t:1528143919744};\\\", \\\"{x:1477,y:585,t:1528143919761};\\\", \\\"{x:1478,y:581,t:1528143919777};\\\", \\\"{x:1478,y:575,t:1528143919794};\\\", \\\"{x:1478,y:569,t:1528143919811};\\\", \\\"{x:1478,y:561,t:1528143919827};\\\", \\\"{x:1479,y:557,t:1528143919844};\\\", \\\"{x:1479,y:552,t:1528143919861};\\\", \\\"{x:1481,y:548,t:1528143919878};\\\", \\\"{x:1481,y:544,t:1528143919894};\\\", \\\"{x:1481,y:541,t:1528143919911};\\\", \\\"{x:1481,y:538,t:1528143919927};\\\", \\\"{x:1481,y:533,t:1528143919944};\\\", \\\"{x:1482,y:530,t:1528143919961};\\\", \\\"{x:1482,y:525,t:1528143919977};\\\", \\\"{x:1483,y:519,t:1528143919994};\\\", \\\"{x:1483,y:511,t:1528143920011};\\\", \\\"{x:1484,y:507,t:1528143920027};\\\", \\\"{x:1484,y:503,t:1528143920044};\\\", \\\"{x:1484,y:498,t:1528143920061};\\\", \\\"{x:1484,y:491,t:1528143920077};\\\", \\\"{x:1484,y:483,t:1528143920094};\\\", \\\"{x:1484,y:473,t:1528143920111};\\\", \\\"{x:1484,y:458,t:1528143920128};\\\", \\\"{x:1484,y:445,t:1528143920144};\\\", \\\"{x:1484,y:434,t:1528143920161};\\\", \\\"{x:1486,y:409,t:1528143920178};\\\", \\\"{x:1490,y:389,t:1528143920194};\\\", \\\"{x:1492,y:368,t:1528143920211};\\\", \\\"{x:1495,y:348,t:1528143920228};\\\", \\\"{x:1497,y:332,t:1528143920244};\\\", \\\"{x:1498,y:319,t:1528143920261};\\\", \\\"{x:1501,y:304,t:1528143920279};\\\", \\\"{x:1502,y:294,t:1528143920294};\\\", \\\"{x:1503,y:285,t:1528143920311};\\\", \\\"{x:1505,y:278,t:1528143920329};\\\", \\\"{x:1505,y:274,t:1528143920345};\\\", \\\"{x:1505,y:270,t:1528143920361};\\\", \\\"{x:1506,y:267,t:1528143920378};\\\", \\\"{x:1506,y:266,t:1528143920483};\\\", \\\"{x:1505,y:266,t:1528143920494};\\\", \\\"{x:1498,y:270,t:1528143920512};\\\", \\\"{x:1494,y:272,t:1528143920528};\\\", \\\"{x:1491,y:272,t:1528143920546};\\\", \\\"{x:1489,y:273,t:1528143920561};\\\", \\\"{x:1479,y:280,t:1528143920579};\\\", \\\"{x:1462,y:291,t:1528143920596};\\\", \\\"{x:1416,y:316,t:1528143920612};\\\", \\\"{x:1331,y:363,t:1528143920629};\\\", \\\"{x:1232,y:406,t:1528143920646};\\\", \\\"{x:1129,y:455,t:1528143920661};\\\", \\\"{x:1003,y:509,t:1528143920677};\\\", \\\"{x:873,y:565,t:1528143920695};\\\", \\\"{x:758,y:613,t:1528143920711};\\\", \\\"{x:660,y:660,t:1528143920727};\\\", \\\"{x:563,y:710,t:1528143920745};\\\", \\\"{x:391,y:782,t:1528143920762};\\\", \\\"{x:335,y:798,t:1528143920777};\\\", \\\"{x:319,y:801,t:1528143920795};\\\", \\\"{x:317,y:797,t:1528143920866};\\\", \\\"{x:315,y:790,t:1528143920878};\\\", \\\"{x:306,y:769,t:1528143920895};\\\", \\\"{x:301,y:754,t:1528143920912};\\\", \\\"{x:296,y:734,t:1528143920928};\\\", \\\"{x:293,y:718,t:1528143920945};\\\", \\\"{x:290,y:697,t:1528143920961};\\\", \\\"{x:289,y:689,t:1528143920978};\\\", \\\"{x:289,y:682,t:1528143920996};\\\", \\\"{x:292,y:673,t:1528143921012};\\\", \\\"{x:295,y:667,t:1528143921027};\\\", \\\"{x:303,y:656,t:1528143921044};\\\", \\\"{x:320,y:639,t:1528143921062};\\\", \\\"{x:372,y:607,t:1528143921077};\\\", \\\"{x:394,y:595,t:1528143921095};\\\", \\\"{x:407,y:590,t:1528143921112};\\\", \\\"{x:426,y:584,t:1528143921128};\\\", \\\"{x:438,y:580,t:1528143921145};\\\", \\\"{x:454,y:577,t:1528143921162};\\\", \\\"{x:459,y:576,t:1528143921179};\\\", \\\"{x:458,y:577,t:1528143921355};\\\", \\\"{x:456,y:577,t:1528143921362};\\\", \\\"{x:453,y:578,t:1528143921379};\\\", \\\"{x:448,y:580,t:1528143921395};\\\", \\\"{x:443,y:580,t:1528143921412};\\\", \\\"{x:437,y:580,t:1528143921429};\\\", \\\"{x:436,y:580,t:1528143921446};\\\", \\\"{x:435,y:580,t:1528143921473};\\\", \\\"{x:434,y:579,t:1528143921481};\\\", \\\"{x:433,y:579,t:1528143921497};\\\", \\\"{x:432,y:578,t:1528143921511};\\\", \\\"{x:431,y:578,t:1528143921529};\\\", \\\"{x:430,y:578,t:1528143921553};\\\", \\\"{x:428,y:578,t:1528143921586};\\\", \\\"{x:427,y:578,t:1528143921596};\\\", \\\"{x:423,y:578,t:1528143921613};\\\", \\\"{x:419,y:578,t:1528143921629};\\\", \\\"{x:416,y:578,t:1528143921646};\\\", \\\"{x:414,y:578,t:1528143921663};\\\", \\\"{x:413,y:578,t:1528143921679};\\\", \\\"{x:408,y:580,t:1528143921697};\\\", \\\"{x:404,y:580,t:1528143921713};\\\", \\\"{x:399,y:582,t:1528143921728};\\\", \\\"{x:393,y:584,t:1528143921746};\\\", \\\"{x:391,y:585,t:1528143921761};\\\", \\\"{x:388,y:586,t:1528143921779};\\\", \\\"{x:388,y:587,t:1528143921796};\\\", \\\"{x:394,y:587,t:1528143922079};\\\", \\\"{x:412,y:586,t:1528143922096};\\\", \\\"{x:425,y:586,t:1528143922113};\\\", \\\"{x:440,y:586,t:1528143922129};\\\", \\\"{x:479,y:586,t:1528143922146};\\\", \\\"{x:506,y:586,t:1528143922164};\\\", \\\"{x:540,y:586,t:1528143922178};\\\", \\\"{x:598,y:586,t:1528143922196};\\\", \\\"{x:662,y:586,t:1528143922213};\\\", \\\"{x:707,y:586,t:1528143922229};\\\", \\\"{x:757,y:586,t:1528143922247};\\\", \\\"{x:792,y:586,t:1528143922263};\\\", \\\"{x:810,y:586,t:1528143922279};\\\", \\\"{x:820,y:586,t:1528143922295};\\\", \\\"{x:828,y:586,t:1528143922313};\\\", \\\"{x:839,y:586,t:1528143922330};\\\", \\\"{x:838,y:586,t:1528143922427};\\\", \\\"{x:832,y:586,t:1528143922434};\\\", \\\"{x:828,y:585,t:1528143922447};\\\", \\\"{x:820,y:581,t:1528143922465};\\\", \\\"{x:812,y:579,t:1528143922480};\\\", \\\"{x:803,y:578,t:1528143922495};\\\", \\\"{x:794,y:576,t:1528143922513};\\\", \\\"{x:776,y:573,t:1528143922529};\\\", \\\"{x:759,y:569,t:1528143922546};\\\", \\\"{x:735,y:561,t:1528143922563};\\\", \\\"{x:706,y:553,t:1528143922581};\\\", \\\"{x:677,y:545,t:1528143922596};\\\", \\\"{x:643,y:536,t:1528143922614};\\\", \\\"{x:607,y:531,t:1528143922631};\\\", \\\"{x:565,y:525,t:1528143922646};\\\", \\\"{x:524,y:522,t:1528143922663};\\\", \\\"{x:487,y:522,t:1528143922681};\\\", \\\"{x:448,y:522,t:1528143922697};\\\", \\\"{x:418,y:522,t:1528143922713};\\\", \\\"{x:388,y:529,t:1528143922729};\\\", \\\"{x:377,y:539,t:1528143922747};\\\", \\\"{x:369,y:550,t:1528143922763};\\\", \\\"{x:368,y:561,t:1528143922780};\\\", \\\"{x:368,y:571,t:1528143922797};\\\", \\\"{x:373,y:574,t:1528143922813};\\\", \\\"{x:382,y:577,t:1528143922831};\\\", \\\"{x:400,y:579,t:1528143922846};\\\", \\\"{x:420,y:582,t:1528143922863};\\\", \\\"{x:448,y:587,t:1528143922879};\\\", \\\"{x:480,y:589,t:1528143922897};\\\", \\\"{x:531,y:597,t:1528143922913};\\\", \\\"{x:652,y:613,t:1528143922931};\\\", \\\"{x:752,y:627,t:1528143922949};\\\", \\\"{x:830,y:640,t:1528143922963};\\\", \\\"{x:891,y:648,t:1528143922980};\\\", \\\"{x:945,y:656,t:1528143922997};\\\", \\\"{x:968,y:656,t:1528143923013};\\\", \\\"{x:975,y:656,t:1528143923030};\\\", \\\"{x:976,y:656,t:1528143923057};\\\", \\\"{x:975,y:655,t:1528143923074};\\\", \\\"{x:971,y:652,t:1528143923082};\\\", \\\"{x:969,y:651,t:1528143923097};\\\", \\\"{x:965,y:649,t:1528143923113};\\\", \\\"{x:956,y:648,t:1528143923130};\\\", \\\"{x:946,y:647,t:1528143923147};\\\", \\\"{x:924,y:643,t:1528143923164};\\\", \\\"{x:901,y:642,t:1528143923180};\\\", \\\"{x:869,y:639,t:1528143923196};\\\", \\\"{x:824,y:639,t:1528143923214};\\\", \\\"{x:765,y:637,t:1528143923230};\\\", \\\"{x:703,y:637,t:1528143923249};\\\", \\\"{x:659,y:637,t:1528143923264};\\\", \\\"{x:624,y:637,t:1528143923280};\\\", \\\"{x:601,y:637,t:1528143923297};\\\", \\\"{x:576,y:637,t:1528143923313};\\\", \\\"{x:563,y:637,t:1528143923330};\\\", \\\"{x:559,y:637,t:1528143923347};\\\", \\\"{x:558,y:637,t:1528143923363};\\\", \\\"{x:554,y:637,t:1528143923380};\\\", \\\"{x:546,y:637,t:1528143923396};\\\", \\\"{x:531,y:637,t:1528143923413};\\\", \\\"{x:509,y:637,t:1528143923430};\\\", \\\"{x:482,y:637,t:1528143923448};\\\", \\\"{x:455,y:637,t:1528143923463};\\\", \\\"{x:427,y:637,t:1528143923480};\\\", \\\"{x:396,y:637,t:1528143923498};\\\", \\\"{x:353,y:637,t:1528143923514};\\\", \\\"{x:334,y:637,t:1528143923530};\\\", \\\"{x:319,y:637,t:1528143923547};\\\", \\\"{x:310,y:637,t:1528143923564};\\\", \\\"{x:303,y:637,t:1528143923580};\\\", \\\"{x:297,y:637,t:1528143923597};\\\", \\\"{x:290,y:637,t:1528143923613};\\\", \\\"{x:282,y:637,t:1528143923630};\\\", \\\"{x:272,y:637,t:1528143923649};\\\", \\\"{x:264,y:637,t:1528143923664};\\\", \\\"{x:257,y:636,t:1528143923680};\\\", \\\"{x:253,y:635,t:1528143923697};\\\", \\\"{x:250,y:635,t:1528143923714};\\\", \\\"{x:248,y:635,t:1528143923731};\\\", \\\"{x:242,y:634,t:1528143923748};\\\", \\\"{x:235,y:633,t:1528143923764};\\\", \\\"{x:229,y:633,t:1528143923781};\\\", \\\"{x:224,y:633,t:1528143923798};\\\", \\\"{x:221,y:633,t:1528143923814};\\\", \\\"{x:217,y:633,t:1528143923831};\\\", \\\"{x:213,y:633,t:1528143923849};\\\", \\\"{x:206,y:633,t:1528143923864};\\\", \\\"{x:202,y:633,t:1528143923882};\\\", \\\"{x:198,y:635,t:1528143923898};\\\", \\\"{x:195,y:637,t:1528143923916};\\\", \\\"{x:193,y:638,t:1528143923931};\\\", \\\"{x:190,y:640,t:1528143923949};\\\", \\\"{x:187,y:643,t:1528143923966};\\\", \\\"{x:184,y:647,t:1528143923981};\\\", \\\"{x:183,y:648,t:1528143923997};\\\", \\\"{x:183,y:651,t:1528143924014};\\\", \\\"{x:183,y:654,t:1528143924031};\\\", \\\"{x:183,y:656,t:1528143924047};\\\", \\\"{x:183,y:657,t:1528143924064};\\\", \\\"{x:184,y:659,t:1528143924081};\\\", \\\"{x:192,y:661,t:1528143924097};\\\", \\\"{x:215,y:661,t:1528143924114};\\\", \\\"{x:237,y:658,t:1528143924131};\\\", \\\"{x:265,y:643,t:1528143924148};\\\", \\\"{x:312,y:616,t:1528143924164};\\\", \\\"{x:356,y:595,t:1528143924182};\\\", \\\"{x:388,y:578,t:1528143924198};\\\", \\\"{x:410,y:567,t:1528143924214};\\\", \\\"{x:422,y:558,t:1528143924231};\\\", \\\"{x:436,y:552,t:1528143924248};\\\", \\\"{x:455,y:549,t:1528143924264};\\\", \\\"{x:471,y:549,t:1528143924281};\\\", \\\"{x:492,y:549,t:1528143924298};\\\", \\\"{x:503,y:549,t:1528143924316};\\\", \\\"{x:516,y:550,t:1528143924331};\\\", \\\"{x:536,y:553,t:1528143924348};\\\", \\\"{x:556,y:555,t:1528143924364};\\\", \\\"{x:571,y:559,t:1528143924381};\\\", \\\"{x:588,y:560,t:1528143924398};\\\", \\\"{x:598,y:561,t:1528143924414};\\\", \\\"{x:608,y:563,t:1528143924432};\\\", \\\"{x:620,y:565,t:1528143924448};\\\", \\\"{x:630,y:566,t:1528143924465};\\\", \\\"{x:641,y:568,t:1528143924482};\\\", \\\"{x:662,y:571,t:1528143924499};\\\", \\\"{x:679,y:571,t:1528143924514};\\\", \\\"{x:695,y:573,t:1528143924531};\\\", \\\"{x:708,y:573,t:1528143924548};\\\", \\\"{x:723,y:572,t:1528143924564};\\\", \\\"{x:748,y:569,t:1528143924583};\\\", \\\"{x:770,y:567,t:1528143924598};\\\", \\\"{x:791,y:562,t:1528143924614};\\\", \\\"{x:808,y:560,t:1528143924631};\\\", \\\"{x:822,y:558,t:1528143924648};\\\", \\\"{x:828,y:556,t:1528143924666};\\\", \\\"{x:834,y:554,t:1528143924681};\\\", \\\"{x:836,y:554,t:1528143924698};\\\", \\\"{x:837,y:554,t:1528143924714};\\\", \\\"{x:837,y:553,t:1528143924731};\\\", \\\"{x:838,y:553,t:1528143924761};\\\", \\\"{x:839,y:553,t:1528143924778};\\\", \\\"{x:840,y:553,t:1528143924786};\\\", \\\"{x:841,y:552,t:1528143924798};\\\", \\\"{x:843,y:551,t:1528143924815};\\\", \\\"{x:848,y:549,t:1528143924832};\\\", \\\"{x:850,y:549,t:1528143924851};\\\", \\\"{x:852,y:547,t:1528143924864};\\\", \\\"{x:855,y:545,t:1528143924881};\\\", \\\"{x:859,y:542,t:1528143924898};\\\", \\\"{x:862,y:542,t:1528143924914};\\\", \\\"{x:866,y:540,t:1528143924932};\\\", \\\"{x:869,y:539,t:1528143924948};\\\", \\\"{x:873,y:536,t:1528143924966};\\\", \\\"{x:876,y:535,t:1528143924982};\\\", \\\"{x:879,y:534,t:1528143924998};\\\", \\\"{x:878,y:532,t:1528143925395};\\\", \\\"{x:875,y:531,t:1528143925403};\\\", \\\"{x:872,y:531,t:1528143925415};\\\", \\\"{x:870,y:529,t:1528143925432};\\\", \\\"{x:869,y:528,t:1528143925449};\\\", \\\"{x:864,y:519,t:1528143925466};\\\", \\\"{x:857,y:505,t:1528143925482};\\\", \\\"{x:852,y:498,t:1528143925499};\\\", \\\"{x:851,y:495,t:1528143925515};\\\", \\\"{x:850,y:501,t:1528143925635};\\\", \\\"{x:849,y:509,t:1528143925651};\\\", \\\"{x:843,y:529,t:1528143925666};\\\", \\\"{x:840,y:538,t:1528143925683};\\\", \\\"{x:838,y:543,t:1528143925700};\\\", \\\"{x:835,y:547,t:1528143925715};\\\", \\\"{x:833,y:549,t:1528143925732};\\\", \\\"{x:823,y:551,t:1528143925750};\\\", \\\"{x:808,y:553,t:1528143925766};\\\", \\\"{x:779,y:553,t:1528143925781};\\\", \\\"{x:737,y:553,t:1528143925800};\\\", \\\"{x:687,y:553,t:1528143925816};\\\", \\\"{x:629,y:558,t:1528143925832};\\\", \\\"{x:571,y:558,t:1528143925849};\\\", \\\"{x:501,y:558,t:1528143925865};\\\", \\\"{x:415,y:558,t:1528143925883};\\\", \\\"{x:382,y:558,t:1528143925899};\\\", \\\"{x:363,y:558,t:1528143925917};\\\", \\\"{x:354,y:560,t:1528143925932};\\\", \\\"{x:344,y:563,t:1528143925949};\\\", \\\"{x:339,y:567,t:1528143925965};\\\", \\\"{x:336,y:568,t:1528143925982};\\\", \\\"{x:333,y:570,t:1528143926000};\\\", \\\"{x:329,y:571,t:1528143926015};\\\", \\\"{x:324,y:574,t:1528143926032};\\\", \\\"{x:317,y:579,t:1528143926050};\\\", \\\"{x:311,y:587,t:1528143926065};\\\", \\\"{x:310,y:591,t:1528143926084};\\\", \\\"{x:310,y:595,t:1528143926099};\\\", \\\"{x:310,y:601,t:1528143926116};\\\", \\\"{x:310,y:611,t:1528143926134};\\\", \\\"{x:324,y:629,t:1528143926150};\\\", \\\"{x:350,y:645,t:1528143926166};\\\", \\\"{x:384,y:655,t:1528143926183};\\\", \\\"{x:426,y:661,t:1528143926199};\\\", \\\"{x:471,y:662,t:1528143926216};\\\", \\\"{x:516,y:662,t:1528143926232};\\\", \\\"{x:567,y:662,t:1528143926249};\\\", \\\"{x:640,y:632,t:1528143926266};\\\", \\\"{x:675,y:613,t:1528143926282};\\\", \\\"{x:698,y:598,t:1528143926299};\\\", \\\"{x:717,y:586,t:1528143926316};\\\", \\\"{x:727,y:581,t:1528143926333};\\\", \\\"{x:730,y:579,t:1528143926349};\\\", \\\"{x:732,y:577,t:1528143926366};\\\", \\\"{x:736,y:569,t:1528143926382};\\\", \\\"{x:737,y:563,t:1528143926399};\\\", \\\"{x:740,y:556,t:1528143926416};\\\", \\\"{x:745,y:544,t:1528143926433};\\\", \\\"{x:750,y:534,t:1528143926450};\\\", \\\"{x:755,y:527,t:1528143926467};\\\", \\\"{x:755,y:526,t:1528143926483};\\\", \\\"{x:756,y:525,t:1528143926529};\\\", \\\"{x:757,y:525,t:1528143926553};\\\", \\\"{x:758,y:525,t:1528143926567};\\\", \\\"{x:761,y:525,t:1528143926583};\\\", \\\"{x:768,y:529,t:1528143926599};\\\", \\\"{x:775,y:536,t:1528143926617};\\\", \\\"{x:783,y:548,t:1528143926633};\\\", \\\"{x:793,y:573,t:1528143926650};\\\", \\\"{x:795,y:584,t:1528143926667};\\\", \\\"{x:795,y:595,t:1528143926683};\\\", \\\"{x:795,y:608,t:1528143926700};\\\", \\\"{x:792,y:617,t:1528143926716};\\\", \\\"{x:785,y:623,t:1528143926733};\\\", \\\"{x:778,y:626,t:1528143926749};\\\", \\\"{x:766,y:630,t:1528143926766};\\\", \\\"{x:755,y:633,t:1528143926783};\\\", \\\"{x:740,y:637,t:1528143926800};\\\", \\\"{x:729,y:640,t:1528143926816};\\\", \\\"{x:717,y:641,t:1528143926834};\\\", \\\"{x:702,y:641,t:1528143926850};\\\", \\\"{x:692,y:640,t:1528143926866};\\\", \\\"{x:679,y:635,t:1528143926884};\\\", \\\"{x:669,y:630,t:1528143926900};\\\", \\\"{x:662,y:626,t:1528143926916};\\\", \\\"{x:655,y:621,t:1528143926933};\\\", \\\"{x:646,y:618,t:1528143926949};\\\", \\\"{x:640,y:612,t:1528143926967};\\\", \\\"{x:632,y:605,t:1528143926984};\\\", \\\"{x:626,y:599,t:1528143927000};\\\", \\\"{x:624,y:598,t:1528143927017};\\\", \\\"{x:622,y:596,t:1528143927034};\\\", \\\"{x:622,y:594,t:1528143927050};\\\", \\\"{x:621,y:593,t:1528143927067};\\\", \\\"{x:620,y:592,t:1528143927084};\\\", \\\"{x:620,y:591,t:1528143927114};\\\", \\\"{x:619,y:591,t:1528143927122};\\\", \\\"{x:619,y:590,t:1528143927138};\\\", \\\"{x:618,y:590,t:1528143927154};\\\", \\\"{x:614,y:591,t:1528143927457};\\\", \\\"{x:606,y:604,t:1528143927467};\\\", \\\"{x:589,y:629,t:1528143927484};\\\", \\\"{x:577,y:644,t:1528143927500};\\\", \\\"{x:564,y:661,t:1528143927517};\\\", \\\"{x:554,y:673,t:1528143927533};\\\", \\\"{x:546,y:686,t:1528143927550};\\\", \\\"{x:545,y:692,t:1528143927567};\\\", \\\"{x:544,y:697,t:1528143927584};\\\", \\\"{x:544,y:701,t:1528143927601};\\\", \\\"{x:543,y:706,t:1528143927617};\\\", \\\"{x:543,y:710,t:1528143927634};\\\", \\\"{x:543,y:711,t:1528143927651};\\\", \\\"{x:543,y:713,t:1528143927690};\\\", \\\"{x:542,y:714,t:1528143927700};\\\", \\\"{x:541,y:720,t:1528143927717};\\\", \\\"{x:541,y:725,t:1528143927734};\\\", \\\"{x:539,y:728,t:1528143927750};\\\", \\\"{x:539,y:731,t:1528143927767};\\\", \\\"{x:539,y:732,t:1528143927786};\\\", \\\"{x:537,y:733,t:1528143927802};\\\", \\\"{x:537,y:735,t:1528143927819};\\\", \\\"{x:535,y:739,t:1528143927834};\\\", \\\"{x:532,y:745,t:1528143927850};\\\", \\\"{x:530,y:747,t:1528143927867};\\\", \\\"{x:530,y:749,t:1528143927954};\\\", \\\"{x:530,y:750,t:1528143927995};\\\", \\\"{x:530,y:751,t:1528143928083};\\\", \\\"{x:530,y:751,t:1528143928162};\\\", \\\"{x:530,y:754,t:1528143928322};\\\", \\\"{x:530,y:757,t:1528143928334};\\\", \\\"{x:531,y:762,t:1528143928351};\\\", \\\"{x:535,y:765,t:1528143928367};\\\", \\\"{x:541,y:768,t:1528143928384};\\\", \\\"{x:554,y:774,t:1528143928401};\\\", \\\"{x:589,y:783,t:1528143928418};\\\", \\\"{x:625,y:786,t:1528143928434};\\\", \\\"{x:681,y:796,t:1528143928451};\\\", \\\"{x:754,y:807,t:1528143928468};\\\", \\\"{x:830,y:812,t:1528143928484};\\\", \\\"{x:902,y:819,t:1528143928501};\\\", \\\"{x:977,y:821,t:1528143928517};\\\", \\\"{x:1044,y:821,t:1528143928535};\\\", \\\"{x:1103,y:821,t:1528143928552};\\\", \\\"{x:1147,y:821,t:1528143928569};\\\", \\\"{x:1187,y:821,t:1528143928585};\\\", \\\"{x:1212,y:821,t:1528143928601};\\\", \\\"{x:1225,y:821,t:1528143928619};\\\" ] }, { \\\"rt\\\": 86578, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 697994, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"TTCWS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Trace the diagonal line the starts at 12 pm and scales up the right of the screen. Whatever points fall on that line are the shifts that start at 12pm.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 12856, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States of America\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 711857, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"TTCWS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 11135, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Other\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 724009, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"TTCWS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 33159, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 758497, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"TTCWS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"TTCWS\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 134, dom: 173, initialDom: 219",
  "javascriptErrors": []
}