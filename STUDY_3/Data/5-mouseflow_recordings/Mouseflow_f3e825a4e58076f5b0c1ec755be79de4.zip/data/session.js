var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "f3e825a4e58076f5b0c1ec755be79de4",
  "created": "2018-05-22T14:12:36.2578119-07:00",
  "lastActivity": "2018-05-22T14:13:42.9846028-07:00",
  "pageViews": [
    {
      "id": "05223661d8c658e71494d15115d43cfcf93dea7f",
      "startTime": "2018-05-22T14:12:36.336119-07:00",
      "endTime": "2018-05-22T14:13:42.9846028-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 66834,
      "engagementTime": 66540,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 66834,
  "engagementTime": 66540,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=YP2FK",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "8b4a2646472387727cd8525567dd2cab",
  "gdpr": false
}