var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "13f5c85d95871c1bc6888932dfed8baf",
  "created": "2018-05-24T12:03:36.1434098-07:00",
  "lastActivity": "2018-05-24T12:05:22.8478556-07:00",
  "pageViews": [
    {
      "id": "05243625e34ab58ad96adc0100aef41ad63ccdfb",
      "startTime": "2018-05-24T12:03:36.1650284-07:00",
      "endTime": "2018-05-24T12:05:22.8478556-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 106918,
      "engagementTime": 53785,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 106918,
  "engagementTime": 53785,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "bdf4b2e741454662e119f39271bf79a6",
  "gdpr": false
}