var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05243625e34ab58ad96adc0100aef41ad63ccdfb"] = {
  "startTime": "2018-05-24T19:03:36.1650284Z",
  "websitePageUrl": "/",
  "visitTime": 106918,
  "engagementTime": 53785,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "13f5c85d95871c1bc6888932dfed8baf",
    "created": "2018-05-24T19:03:36.1434098+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "bdf4b2e741454662e119f39271bf79a6",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/13f5c85d95871c1bc6888932dfed8baf/play"
  },
  "events": [
    {
      "t": 102,
      "e": 102,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 268,
      "e": 268,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 1252,
      "e": 1252,
      "ty": 41,
      "x": 25862,
      "y": 3434,
      "ta": "html > body"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 759,
      "y": 70
    },
    {
      "t": 10001,
      "e": 6301,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 16901,
      "e": 6301,
      "ty": 2,
      "x": 750,
      "y": 77
    },
    {
      "t": 17001,
      "e": 6401,
      "ty": 2,
      "x": 712,
      "y": 108
    },
    {
      "t": 17001,
      "e": 6401,
      "ty": 41,
      "x": 24244,
      "y": 5539,
      "ta": "html > body"
    },
    {
      "t": 17100,
      "e": 6500,
      "ty": 2,
      "x": 710,
      "y": 109
    },
    {
      "t": 17250,
      "e": 6650,
      "ty": 41,
      "x": 24175,
      "y": 5595,
      "ta": "html > body"
    },
    {
      "t": 22600,
      "e": 11650,
      "ty": 2,
      "x": 680,
      "y": 109
    },
    {
      "t": 22700,
      "e": 11750,
      "ty": 2,
      "x": 569,
      "y": 92
    },
    {
      "t": 22750,
      "e": 11800,
      "ty": 41,
      "x": 19285,
      "y": 4653,
      "ta": "html > body"
    },
    {
      "t": 22801,
      "e": 11851,
      "ty": 2,
      "x": 568,
      "y": 92
    },
    {
      "t": 30001,
      "e": 16851,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 66704,
      "e": 16851,
      "ty": 2,
      "x": 593,
      "y": 115
    },
    {
      "t": 66755,
      "e": 16902,
      "ty": 41,
      "x": 24209,
      "y": 13849,
      "ta": "html > body"
    },
    {
      "t": 66804,
      "e": 16951,
      "ty": 2,
      "x": 791,
      "y": 325
    },
    {
      "t": 66904,
      "e": 17051,
      "ty": 2,
      "x": 893,
      "y": 354
    },
    {
      "t": 67005,
      "e": 17152,
      "ty": 41,
      "x": 30477,
      "y": 19167,
      "ta": "html > body"
    },
    {
      "t": 67130,
      "e": 17277,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 67704,
      "e": 17851,
      "ty": 2,
      "x": 894,
      "y": 354
    },
    {
      "t": 67755,
      "e": 17902,
      "ty": 41,
      "x": 29545,
      "y": 42393,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 67804,
      "e": 17951,
      "ty": 2,
      "x": 946,
      "y": 1015
    },
    {
      "t": 67904,
      "e": 18051,
      "ty": 2,
      "x": 994,
      "y": 1199
    },
    {
      "t": 68005,
      "e": 18152,
      "ty": 2,
      "x": 824,
      "y": 1082
    },
    {
      "t": 68005,
      "e": 18152,
      "ty": 41,
      "x": 28101,
      "y": 59496,
      "ta": "> div.masterdiv"
    },
    {
      "t": 68105,
      "e": 18252,
      "ty": 2,
      "x": 701,
      "y": 752
    },
    {
      "t": 68205,
      "e": 18352,
      "ty": 2,
      "x": 709,
      "y": 695
    },
    {
      "t": 68255,
      "e": 18402,
      "ty": 41,
      "x": 22460,
      "y": 58520,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 68304,
      "e": 18451,
      "ty": 2,
      "x": 790,
      "y": 922
    },
    {
      "t": 68405,
      "e": 18552,
      "ty": 2,
      "x": 794,
      "y": 948
    },
    {
      "t": 68505,
      "e": 18652,
      "ty": 2,
      "x": 800,
      "y": 974
    },
    {
      "t": 68505,
      "e": 18652,
      "ty": 41,
      "x": 24920,
      "y": 58701,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 68604,
      "e": 18751,
      "ty": 2,
      "x": 812,
      "y": 960
    },
    {
      "t": 68704,
      "e": 18851,
      "ty": 2,
      "x": 814,
      "y": 937
    },
    {
      "t": 68755,
      "e": 18902,
      "ty": 41,
      "x": 34610,
      "y": 55755,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 68804,
      "e": 18951,
      "ty": 2,
      "x": 813,
      "y": 922
    },
    {
      "t": 68866,
      "e": 19013,
      "ty": 3,
      "x": 813,
      "y": 921,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 68905,
      "e": 19052,
      "ty": 2,
      "x": 813,
      "y": 921
    },
    {
      "t": 68963,
      "e": 19110,
      "ty": 4,
      "x": 31333,
      "y": 32818,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 68963,
      "e": 19110,
      "ty": 5,
      "x": 813,
      "y": 921,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 68966,
      "e": 19113,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 68975,
      "e": 19122,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 69004,
      "e": 19151,
      "ty": 41,
      "x": 31333,
      "y": 32818,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 69105,
      "e": 19252,
      "ty": 2,
      "x": 861,
      "y": 1053
    },
    {
      "t": 69204,
      "e": 19351,
      "ty": 2,
      "x": 937,
      "y": 1131
    },
    {
      "t": 69255,
      "e": 19402,
      "ty": 41,
      "x": 24575,
      "y": 32304,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 69304,
      "e": 19451,
      "ty": 2,
      "x": 972,
      "y": 1122
    },
    {
      "t": 69404,
      "e": 19551,
      "ty": 2,
      "x": 988,
      "y": 1111
    },
    {
      "t": 69492,
      "e": 19639,
      "ty": 6,
      "x": 991,
      "y": 1104,
      "ta": "#start"
    },
    {
      "t": 69504,
      "e": 19651,
      "ty": 2,
      "x": 991,
      "y": 1104
    },
    {
      "t": 69504,
      "e": 19651,
      "ty": 41,
      "x": 44509,
      "y": 60354,
      "ta": "#start"
    },
    {
      "t": 69604,
      "e": 19751,
      "ty": 2,
      "x": 994,
      "y": 1075
    },
    {
      "t": 69634,
      "e": 19781,
      "ty": 3,
      "x": 994,
      "y": 1075,
      "ta": "#start"
    },
    {
      "t": 69634,
      "e": 19781,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 69635,
      "e": 19782,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 69730,
      "e": 19877,
      "ty": 4,
      "x": 46147,
      "y": 4457,
      "ta": "#start"
    },
    {
      "t": 69733,
      "e": 19880,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 69735,
      "e": 19882,
      "ty": 5,
      "x": 994,
      "y": 1075,
      "ta": "#start"
    },
    {
      "t": 69737,
      "e": 19884,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 69755,
      "e": 19902,
      "ty": 41,
      "x": 33955,
      "y": 59108,
      "ta": "html > body"
    },
    {
      "t": 70105,
      "e": 20252,
      "ty": 2,
      "x": 988,
      "y": 1072
    },
    {
      "t": 70205,
      "e": 20352,
      "ty": 2,
      "x": 924,
      "y": 853
    },
    {
      "t": 70254,
      "e": 20401,
      "ty": 41,
      "x": 32371,
      "y": 25094,
      "ta": "html > body"
    },
    {
      "t": 70305,
      "e": 20452,
      "ty": 2,
      "x": 1007,
      "y": 91
    },
    {
      "t": 70404,
      "e": 20551,
      "ty": 2,
      "x": 1030,
      "y": 0
    },
    {
      "t": 70505,
      "e": 20652,
      "ty": 41,
      "x": 35470,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 70704,
      "e": 20851,
      "ty": 2,
      "x": 1002,
      "y": 0
    },
    {
      "t": 70745,
      "e": 20892,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 70754,
      "e": 20901,
      "ty": 41,
      "x": 34506,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 71205,
      "e": 21352,
      "ty": 2,
      "x": 1009,
      "y": 203
    },
    {
      "t": 71257,
      "e": 21404,
      "ty": 41,
      "x": 31577,
      "y": 32415,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 71292,
      "e": 21439,
      "ty": 6,
      "x": 904,
      "y": 719,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 71305,
      "e": 21452,
      "ty": 2,
      "x": 904,
      "y": 719
    },
    {
      "t": 71309,
      "e": 21456,
      "ty": 7,
      "x": 883,
      "y": 762,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 71405,
      "e": 21552,
      "ty": 2,
      "x": 835,
      "y": 804
    },
    {
      "t": 71504,
      "e": 21651,
      "ty": 2,
      "x": 845,
      "y": 667
    },
    {
      "t": 71505,
      "e": 21652,
      "ty": 41,
      "x": 8002,
      "y": 36643,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 71526,
      "e": 21673,
      "ty": 6,
      "x": 871,
      "y": 606,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 71543,
      "e": 21690,
      "ty": 7,
      "x": 886,
      "y": 580,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 71604,
      "e": 21751,
      "ty": 2,
      "x": 917,
      "y": 537
    },
    {
      "t": 71755,
      "e": 21902,
      "ty": 41,
      "x": 23575,
      "y": 9362,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 71805,
      "e": 21952,
      "ty": 2,
      "x": 905,
      "y": 568
    },
    {
      "t": 71843,
      "e": 21990,
      "ty": 6,
      "x": 890,
      "y": 588,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 71905,
      "e": 22052,
      "ty": 2,
      "x": 888,
      "y": 588
    },
    {
      "t": 72005,
      "e": 22152,
      "ty": 2,
      "x": 885,
      "y": 590
    },
    {
      "t": 72005,
      "e": 22152,
      "ty": 41,
      "x": 16654,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 72066,
      "e": 22213,
      "ty": 3,
      "x": 885,
      "y": 590,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 72067,
      "e": 22214,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 72137,
      "e": 22284,
      "ty": 4,
      "x": 16654,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 72137,
      "e": 22284,
      "ty": 5,
      "x": 885,
      "y": 590,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 73862,
      "e": 24009,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 74021,
      "e": 24168,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "75"
    },
    {
      "t": 74023,
      "e": 24170,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 74141,
      "e": 24288,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "K"
    },
    {
      "t": 74157,
      "e": 24304,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "K"
    },
    {
      "t": 74444,
      "e": 24591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 74445,
      "e": 24592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 74557,
      "e": 24704,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Ki"
    },
    {
      "t": 74677,
      "e": 24824,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "76"
    },
    {
      "t": 74679,
      "e": 24826,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 74789,
      "e": 24936,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Kil"
    },
    {
      "t": 75214,
      "e": 25361,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 75215,
      "e": 25362,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 75285,
      "e": 25432,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Kilo"
    },
    {
      "t": 75410,
      "e": 25557,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Kilo"
    },
    {
      "t": 75965,
      "e": 26112,
      "ty": 7,
      "x": 884,
      "y": 609,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 76005,
      "e": 26152,
      "ty": 2,
      "x": 889,
      "y": 650
    },
    {
      "t": 76008,
      "e": 26155,
      "ty": 41,
      "x": 17519,
      "y": 39789,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 76030,
      "e": 26177,
      "ty": 6,
      "x": 891,
      "y": 682,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76064,
      "e": 26211,
      "ty": 7,
      "x": 883,
      "y": 713,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76105,
      "e": 26252,
      "ty": 2,
      "x": 879,
      "y": 727
    },
    {
      "t": 76255,
      "e": 26402,
      "ty": 41,
      "x": 29926,
      "y": 39498,
      "ta": "html > body"
    },
    {
      "t": 76305,
      "e": 26452,
      "ty": 2,
      "x": 877,
      "y": 705
    },
    {
      "t": 76314,
      "e": 26461,
      "ty": 6,
      "x": 881,
      "y": 691,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76405,
      "e": 26552,
      "ty": 2,
      "x": 884,
      "y": 680
    },
    {
      "t": 76505,
      "e": 26652,
      "ty": 41,
      "x": 16437,
      "y": 3120,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76537,
      "e": 26684,
      "ty": 3,
      "x": 884,
      "y": 680,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76538,
      "e": 26685,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Kilo"
    },
    {
      "t": 76538,
      "e": 26685,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 76538,
      "e": 26685,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76649,
      "e": 26796,
      "ty": 4,
      "x": 16437,
      "y": 3120,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76650,
      "e": 26797,
      "ty": 5,
      "x": 884,
      "y": 680,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76730,
      "e": 26877,
      "ty": 7,
      "x": 877,
      "y": 678,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76755,
      "e": 26902,
      "ty": 41,
      "x": 14707,
      "y": 44394,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 76805,
      "e": 26952,
      "ty": 2,
      "x": 876,
      "y": 678
    },
    {
      "t": 76905,
      "e": 27052,
      "ty": 2,
      "x": 874,
      "y": 678
    },
    {
      "t": 77006,
      "e": 27153,
      "ty": 41,
      "x": 14274,
      "y": 44394,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 77173,
      "e": 27320,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 77175,
      "e": 27322,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 77252,
      "e": 27399,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 77333,
      "e": 27480,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 77334,
      "e": 27481,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 77413,
      "e": 27560,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 77484,
      "e": 27631,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "99"
    },
    {
      "t": 77485,
      "e": 27632,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 77557,
      "e": 27704,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 78104,
      "e": 28251,
      "ty": 2,
      "x": 827,
      "y": 653
    },
    {
      "t": 78199,
      "e": 28346,
      "ty": 6,
      "x": 851,
      "y": 680,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 78205,
      "e": 28352,
      "ty": 2,
      "x": 851,
      "y": 680
    },
    {
      "t": 78232,
      "e": 28379,
      "ty": 7,
      "x": 891,
      "y": 711,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 78249,
      "e": 28396,
      "ty": 6,
      "x": 900,
      "y": 717,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 78255,
      "e": 28402,
      "ty": 41,
      "x": 2101,
      "y": 17873,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 78304,
      "e": 28451,
      "ty": 2,
      "x": 921,
      "y": 734
    },
    {
      "t": 78405,
      "e": 28552,
      "ty": 2,
      "x": 928,
      "y": 736
    },
    {
      "t": 78505,
      "e": 28652,
      "ty": 41,
      "x": 16532,
      "y": 55605,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 78529,
      "e": 28676,
      "ty": 3,
      "x": 928,
      "y": 736,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 78529,
      "e": 28676,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 78529,
      "e": 28676,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 78529,
      "e": 28676,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 78593,
      "e": 28740,
      "ty": 4,
      "x": 16532,
      "y": 55605,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 78594,
      "e": 28741,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 78595,
      "e": 28742,
      "ty": 5,
      "x": 928,
      "y": 736,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 78595,
      "e": 28742,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 79205,
      "e": 29352,
      "ty": 2,
      "x": 1506,
      "y": 0
    },
    {
      "t": 79256,
      "e": 29403,
      "ty": 41,
      "x": 54239,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 79305,
      "e": 29452,
      "ty": 2,
      "x": 1575,
      "y": 0
    },
    {
      "t": 79692,
      "e": 29839,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 79904,
      "e": 30051,
      "ty": 2,
      "x": 1584,
      "y": 5
    },
    {
      "t": 80005,
      "e": 30152,
      "ty": 2,
      "x": 1610,
      "y": 90
    },
    {
      "t": 80005,
      "e": 30152,
      "ty": 41,
      "x": 55169,
      "y": 4542,
      "ta": "> div.masterdiv"
    },
    {
      "t": 80107,
      "e": 30254,
      "ty": 2,
      "x": 1131,
      "y": 493
    },
    {
      "t": 80205,
      "e": 30352,
      "ty": 2,
      "x": 756,
      "y": 623
    },
    {
      "t": 80255,
      "e": 30402,
      "ty": 41,
      "x": 45731,
      "y": 49202,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[5] > td > i"
    },
    {
      "t": 80305,
      "e": 30452,
      "ty": 2,
      "x": 645,
      "y": 581
    },
    {
      "t": 80405,
      "e": 30552,
      "ty": 2,
      "x": 548,
      "y": 551
    },
    {
      "t": 80504,
      "e": 30651,
      "ty": 2,
      "x": 548,
      "y": 550
    },
    {
      "t": 80504,
      "e": 30651,
      "ty": 41,
      "x": 12522,
      "y": 36129,
      "ta": "> div.masterdiv > div:[2] > div > table"
    },
    {
      "t": 80605,
      "e": 30752,
      "ty": 2,
      "x": 553,
      "y": 549
    },
    {
      "t": 80668,
      "e": 30815,
      "ty": 6,
      "x": 610,
      "y": 673,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 80685,
      "e": 30832,
      "ty": 7,
      "x": 644,
      "y": 723,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 80685,
      "e": 30832,
      "ty": 6,
      "x": 644,
      "y": 723,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 80701,
      "e": 30848,
      "ty": 7,
      "x": 688,
      "y": 780,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 80701,
      "e": 30848,
      "ty": 6,
      "x": 688,
      "y": 780,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 80704,
      "e": 30851,
      "ty": 2,
      "x": 688,
      "y": 780
    },
    {
      "t": 80718,
      "e": 30865,
      "ty": 7,
      "x": 737,
      "y": 838,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 80755,
      "e": 30902,
      "ty": 41,
      "x": 27232,
      "y": 56623,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 80805,
      "e": 30952,
      "ty": 2,
      "x": 952,
      "y": 1059
    },
    {
      "t": 80835,
      "e": 30982,
      "ty": 6,
      "x": 968,
      "y": 1074,
      "ta": "#start"
    },
    {
      "t": 80901,
      "e": 31048,
      "ty": 7,
      "x": 965,
      "y": 1071,
      "ta": "#start"
    },
    {
      "t": 80905,
      "e": 31052,
      "ty": 2,
      "x": 965,
      "y": 1071
    },
    {
      "t": 81005,
      "e": 31152,
      "ty": 2,
      "x": 959,
      "y": 1055
    },
    {
      "t": 81005,
      "e": 31152,
      "ty": 41,
      "x": 32742,
      "y": 64310,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 81104,
      "e": 31251,
      "ty": 2,
      "x": 951,
      "y": 1039
    },
    {
      "t": 81206,
      "e": 31353,
      "ty": 2,
      "x": 906,
      "y": 982
    },
    {
      "t": 81255,
      "e": 31402,
      "ty": 41,
      "x": 27528,
      "y": 55723,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 81305,
      "e": 31452,
      "ty": 2,
      "x": 817,
      "y": 881
    },
    {
      "t": 81405,
      "e": 31552,
      "ty": 2,
      "x": 817,
      "y": 859
    },
    {
      "t": 81505,
      "e": 31652,
      "ty": 41,
      "x": 25756,
      "y": 50737,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 82105,
      "e": 32252,
      "ty": 2,
      "x": 823,
      "y": 854
    },
    {
      "t": 82205,
      "e": 32352,
      "ty": 2,
      "x": 824,
      "y": 854
    },
    {
      "t": 82256,
      "e": 32403,
      "ty": 41,
      "x": 26101,
      "y": 50391,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 83805,
      "e": 33952,
      "ty": 2,
      "x": 835,
      "y": 869
    },
    {
      "t": 83905,
      "e": 34052,
      "ty": 2,
      "x": 878,
      "y": 928
    },
    {
      "t": 84005,
      "e": 34152,
      "ty": 2,
      "x": 926,
      "y": 993
    },
    {
      "t": 84006,
      "e": 34153,
      "ty": 41,
      "x": 31119,
      "y": 60016,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 84105,
      "e": 34252,
      "ty": 2,
      "x": 940,
      "y": 1051
    },
    {
      "t": 84207,
      "e": 34354,
      "ty": 2,
      "x": 944,
      "y": 1067
    },
    {
      "t": 84255,
      "e": 34402,
      "ty": 41,
      "x": 32054,
      "y": 65279,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 84290,
      "e": 34437,
      "ty": 6,
      "x": 945,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 84305,
      "e": 34452,
      "ty": 2,
      "x": 945,
      "y": 1072
    },
    {
      "t": 84405,
      "e": 34552,
      "ty": 2,
      "x": 946,
      "y": 1085
    },
    {
      "t": 84506,
      "e": 34653,
      "ty": 2,
      "x": 946,
      "y": 1090
    },
    {
      "t": 84506,
      "e": 34653,
      "ty": 41,
      "x": 19933,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 90005,
      "e": 39653,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 92786,
      "e": 39653,
      "ty": 3,
      "x": 946,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 92788,
      "e": 39655,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 92864,
      "e": 39731,
      "ty": 4,
      "x": 19933,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 92865,
      "e": 39732,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 92866,
      "e": 39733,
      "ty": 5,
      "x": 946,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 92866,
      "e": 39733,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 93868,
      "e": 40735,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 94905,
      "e": 41772,
      "ty": 2,
      "x": 955,
      "y": 1063
    },
    {
      "t": 95005,
      "e": 41872,
      "ty": 2,
      "x": 980,
      "y": 967
    },
    {
      "t": 95005,
      "e": 41872,
      "ty": 41,
      "x": 33762,
      "y": 63787,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 97905,
      "e": 44772,
      "ty": 2,
      "x": 981,
      "y": 963
    },
    {
      "t": 98005,
      "e": 44872,
      "ty": 2,
      "x": 981,
      "y": 960
    },
    {
      "t": 98005,
      "e": 44872,
      "ty": 41,
      "x": 33811,
      "y": 63244,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 100004,
      "e": 46871,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 102405,
      "e": 49272,
      "ty": 2,
      "x": 986,
      "y": 985
    },
    {
      "t": 102504,
      "e": 49371,
      "ty": 2,
      "x": 1000,
      "y": 1016
    },
    {
      "t": 102505,
      "e": 49372,
      "ty": 41,
      "x": 47108,
      "y": 19894,
      "ta": "> p"
    },
    {
      "t": 102605,
      "e": 49472,
      "ty": 2,
      "x": 1009,
      "y": 1031
    },
    {
      "t": 102705,
      "e": 49572,
      "ty": 2,
      "x": 1013,
      "y": 1035
    },
    {
      "t": 102755,
      "e": 49622,
      "ty": 41,
      "x": 34609,
      "y": 56948,
      "ta": "html > body"
    },
    {
      "t": 102805,
      "e": 49672,
      "ty": 2,
      "x": 1013,
      "y": 1036
    },
    {
      "t": 105911,
      "e": 52778,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 106918,
      "e": 53785,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 226, dom: 637, initialDom: 641",
  "javascriptErrors": []
}