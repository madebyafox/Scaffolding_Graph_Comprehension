var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "61b7e97d3a4d910e6e76468995e191ff",
  "created": "2018-05-25T11:18:19.6453264-07:00",
  "lastActivity": "2018-05-25T11:19:55.8283974-07:00",
  "pageViews": [
    {
      "id": "05251941ff5c7006b334e278474bc1c3f090476a",
      "startTime": "2018-05-25T11:18:19.6653974-07:00",
      "endTime": "2018-05-25T11:19:55.8283974-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 96163,
      "engagementTime": 57765,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 96163,
  "engagementTime": 57765,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.43",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=ESMO3",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "f74051731b4d7352299867e89ce0a68b",
  "gdpr": false
}