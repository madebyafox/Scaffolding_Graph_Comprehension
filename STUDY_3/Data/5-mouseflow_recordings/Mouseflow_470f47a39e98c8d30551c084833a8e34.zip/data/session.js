var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "470f47a39e98c8d30551c084833a8e34",
  "created": "2018-05-15T14:14:05.3529433-07:00",
  "lastActivity": "2018-05-15T14:14:55.1359433-07:00",
  "pageViews": [
    {
      "id": "0515059824b5b8934cc824810605f1683731c6e3",
      "startTime": "2018-05-15T14:14:05.3529433-07:00",
      "endTime": "2018-05-15T14:14:55.1359433-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 49783,
      "engagementTime": 29754,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 49783,
  "engagementTime": 29754,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=8LGZ4",
    "CONDITION=111"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "920a7c423fc92e1a6eb7cb858ee3b3e4",
  "gdpr": false
}