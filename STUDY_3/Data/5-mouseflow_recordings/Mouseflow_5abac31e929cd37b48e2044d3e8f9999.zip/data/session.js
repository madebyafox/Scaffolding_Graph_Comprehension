var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "5abac31e929cd37b48e2044d3e8f9999",
  "created": "2018-05-18T10:22:48.6125697-07:00",
  "lastActivity": "2018-05-18T10:22:55.4625697-07:00",
  "pageViews": [
    {
      "id": "05184853caabd3696a176e0b578aca4b1e4b1a13",
      "startTime": "2018-05-18T10:22:48.6125697-07:00",
      "endTime": "2018-05-18T10:22:55.4625697-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/12",
      "visitTime": 6850,
      "engagementTime": 6850,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 6850,
  "engagementTime": 6850,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.35",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=JTARS",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "29cbcee539c06595eb30d3cae37e17b0",
  "gdpr": false
}