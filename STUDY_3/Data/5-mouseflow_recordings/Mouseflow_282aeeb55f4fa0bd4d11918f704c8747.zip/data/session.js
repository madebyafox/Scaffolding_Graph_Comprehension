var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "282aeeb55f4fa0bd4d11918f704c8747",
  "created": "2018-05-21T09:19:56.8451744-07:00",
  "lastActivity": "2018-05-21T09:21:42.9818923-07:00",
  "pageViews": [
    {
      "id": "052156920b2064b6fb6a9c0dc4e7de791d3343d7",
      "startTime": "2018-05-21T09:19:56.8451744-07:00",
      "endTime": "2018-05-21T09:21:42.9818923-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 106225,
      "engagementTime": 84576,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 106225,
  "engagementTime": 84576,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=781AU",
    "CONDITION=111"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "4ba56d39bdb3b34cc8accb6a531a6272",
  "gdpr": false
}