var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "db9be066e727067872400e7efc16e329",
  "created": "2018-06-04T13:25:52.7279014-07:00",
  "lastActivity": "2018-06-04T13:28:52.4926402-07:00",
  "pageViews": [
    {
      "id": "06045313be402f6e8e85b33448f1c5120ce2cccf",
      "startTime": "2018-06-04T13:25:52.7546402-07:00",
      "endTime": "2018-06-04T13:28:52.4926402-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 179738,
      "engagementTime": 178391,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 179738,
  "engagementTime": 178391,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=BHZYG",
    "CONDITION=211"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "0bbd8c21e31b32d991e6db13ad148804",
  "gdpr": false
}