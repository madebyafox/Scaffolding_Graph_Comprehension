var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052435414b732fcda00f88f0fe8624b6af561936"] = {
  "startTime": "2018-05-24T19:29:35.1439622Z",
  "websitePageUrl": "/16",
  "visitTime": 103334,
  "engagementTime": 96271,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "1cf6feacf929533236291db898317ae5",
    "created": "2018-05-24T19:29:35.1439622+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=F98S2",
      "CONDITION=113"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "785ead696e3be795bf4d63a1dce7d5c0",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/1cf6feacf929533236291db898317ae5/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 501,
      "y": 745
    },
    {
      "t": 1002,
      "e": 1002,
      "ty": 41,
      "x": 45403,
      "y": 40827,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 491,
      "y": 690
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 459,
      "y": 633
    },
    {
      "t": 1252,
      "e": 1252,
      "ty": 41,
      "x": 39894,
      "y": 64294,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 449,
      "y": 614
    },
    {
      "t": 1343,
      "e": 1343,
      "ty": 6,
      "x": 449,
      "y": 600,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 449,
      "y": 582
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 2,
      "x": 454,
      "y": 563
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 41,
      "x": 40119,
      "y": 32577,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1601,
      "e": 1601,
      "ty": 2,
      "x": 460,
      "y": 552
    },
    {
      "t": 1752,
      "e": 1752,
      "ty": 41,
      "x": 40794,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 2,
      "x": 487,
      "y": 570
    },
    {
      "t": 2502,
      "e": 2502,
      "ty": 41,
      "x": 43829,
      "y": 38241,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2559,
      "e": 2559,
      "ty": 7,
      "x": 534,
      "y": 611,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2602,
      "e": 2602,
      "ty": 2,
      "x": 584,
      "y": 638
    },
    {
      "t": 2701,
      "e": 2701,
      "ty": 2,
      "x": 794,
      "y": 771
    },
    {
      "t": 2752,
      "e": 2752,
      "ty": 41,
      "x": 9725,
      "y": 51855,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 2801,
      "e": 2801,
      "ty": 2,
      "x": 1010,
      "y": 938
    },
    {
      "t": 2901,
      "e": 2901,
      "ty": 2,
      "x": 1029,
      "y": 962
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 2,
      "x": 1043,
      "y": 963
    },
    {
      "t": 3002,
      "e": 3002,
      "ty": 41,
      "x": 12821,
      "y": 0,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > path"
    },
    {
      "t": 3102,
      "e": 3102,
      "ty": 2,
      "x": 1091,
      "y": 959
    },
    {
      "t": 3201,
      "e": 3201,
      "ty": 2,
      "x": 1095,
      "y": 959
    },
    {
      "t": 3252,
      "e": 3252,
      "ty": 41,
      "x": 21916,
      "y": 58802,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3302,
      "e": 3302,
      "ty": 2,
      "x": 1103,
      "y": 959
    },
    {
      "t": 3401,
      "e": 3401,
      "ty": 2,
      "x": 1122,
      "y": 959
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 2,
      "x": 1139,
      "y": 959
    },
    {
      "t": 3502,
      "e": 3502,
      "ty": 41,
      "x": 24876,
      "y": 58802,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3752,
      "e": 3752,
      "ty": 41,
      "x": 25017,
      "y": 58874,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3801,
      "e": 3801,
      "ty": 2,
      "x": 1147,
      "y": 960
    },
    {
      "t": 3901,
      "e": 3901,
      "ty": 2,
      "x": 1153,
      "y": 959
    },
    {
      "t": 4002,
      "e": 4002,
      "ty": 2,
      "x": 1156,
      "y": 949
    },
    {
      "t": 4002,
      "e": 4002,
      "ty": 41,
      "x": 26074,
      "y": 58086,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4102,
      "e": 4102,
      "ty": 2,
      "x": 1163,
      "y": 901
    },
    {
      "t": 4201,
      "e": 4201,
      "ty": 2,
      "x": 1159,
      "y": 850
    },
    {
      "t": 4252,
      "e": 4252,
      "ty": 41,
      "x": 26144,
      "y": 48560,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4302,
      "e": 4302,
      "ty": 2,
      "x": 1155,
      "y": 802
    },
    {
      "t": 4401,
      "e": 4401,
      "ty": 2,
      "x": 1150,
      "y": 768
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 2,
      "x": 1149,
      "y": 759
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 41,
      "x": 12828,
      "y": 10922,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[2] > circle"
    },
    {
      "t": 4601,
      "e": 4601,
      "ty": 2,
      "x": 1149,
      "y": 753
    },
    {
      "t": 4702,
      "e": 4702,
      "ty": 2,
      "x": 1151,
      "y": 748
    },
    {
      "t": 4752,
      "e": 4752,
      "ty": 41,
      "x": 27519,
      "y": 14043,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[2] > text"
    },
    {
      "t": 4801,
      "e": 4801,
      "ty": 2,
      "x": 1151,
      "y": 746
    },
    {
      "t": 4901,
      "e": 4901,
      "ty": 2,
      "x": 1151,
      "y": 731
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 2,
      "x": 1150,
      "y": 706
    },
    {
      "t": 5002,
      "e": 5002,
      "ty": 41,
      "x": 25651,
      "y": 40681,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5102,
      "e": 5102,
      "ty": 2,
      "x": 1152,
      "y": 684
    },
    {
      "t": 5253,
      "e": 5253,
      "ty": 41,
      "x": 35711,
      "y": 31231,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[6] > text"
    },
    {
      "t": 5402,
      "e": 5402,
      "ty": 2,
      "x": 1149,
      "y": 688
    },
    {
      "t": 5502,
      "e": 5502,
      "ty": 2,
      "x": 1147,
      "y": 691
    },
    {
      "t": 5502,
      "e": 5502,
      "ty": 41,
      "x": 25439,
      "y": 39607,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5602,
      "e": 5602,
      "ty": 2,
      "x": 1147,
      "y": 692
    },
    {
      "t": 5702,
      "e": 5702,
      "ty": 2,
      "x": 1147,
      "y": 697
    },
    {
      "t": 5752,
      "e": 5752,
      "ty": 41,
      "x": 25439,
      "y": 41183,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5801,
      "e": 5801,
      "ty": 2,
      "x": 1147,
      "y": 715
    },
    {
      "t": 5902,
      "e": 5902,
      "ty": 2,
      "x": 1148,
      "y": 729
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 2,
      "x": 1152,
      "y": 753
    },
    {
      "t": 6002,
      "e": 6002,
      "ty": 41,
      "x": 35711,
      "y": 42129,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[2] > text"
    },
    {
      "t": 6101,
      "e": 6101,
      "ty": 2,
      "x": 1155,
      "y": 760
    },
    {
      "t": 6252,
      "e": 6252,
      "ty": 41,
      "x": 45595,
      "y": 16383,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[2] > circle"
    },
    {
      "t": 10002,
      "e": 10002,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 13702,
      "e": 11252,
      "ty": 2,
      "x": 1069,
      "y": 712
    },
    {
      "t": 13736,
      "e": 11286,
      "ty": 6,
      "x": 529,
      "y": 532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13752,
      "e": 11302,
      "ty": 41,
      "x": 48550,
      "y": 7496,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13802,
      "e": 11352,
      "ty": 2,
      "x": 448,
      "y": 533
    },
    {
      "t": 13885,
      "e": 11435,
      "ty": 7,
      "x": 382,
      "y": 621,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13902,
      "e": 11452,
      "ty": 2,
      "x": 382,
      "y": 621
    },
    {
      "t": 14002,
      "e": 11552,
      "ty": 2,
      "x": 375,
      "y": 631
    },
    {
      "t": 14003,
      "e": 11553,
      "ty": 41,
      "x": 26404,
      "y": 6072,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 14101,
      "e": 11651,
      "ty": 2,
      "x": 385,
      "y": 615
    },
    {
      "t": 14120,
      "e": 11670,
      "ty": 6,
      "x": 389,
      "y": 591,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14202,
      "e": 11752,
      "ty": 2,
      "x": 390,
      "y": 585
    },
    {
      "t": 14252,
      "e": 11802,
      "ty": 41,
      "x": 32925,
      "y": 50377,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14258,
      "e": 11808,
      "ty": 3,
      "x": 390,
      "y": 585,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14261,
      "e": 11811,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14353,
      "e": 11903,
      "ty": 4,
      "x": 32925,
      "y": 50377,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14354,
      "e": 11904,
      "ty": 5,
      "x": 390,
      "y": 585,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15086,
      "e": 12636,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 15087,
      "e": 12637,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15189,
      "e": 12739,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i"
    },
    {
      "t": 15213,
      "e": 12763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 15214,
      "e": 12764,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15221,
      "e": 12771,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15221,
      "e": 12771,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15325,
      "e": 12875,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "in "
    },
    {
      "t": 15477,
      "e": 13027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "in "
    },
    {
      "t": 15981,
      "e": 13531,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16044,
      "e": 13594,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "in"
    },
    {
      "t": 16124,
      "e": 13674,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16181,
      "e": 13731,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i"
    },
    {
      "t": 16860,
      "e": 14410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16860,
      "e": 14410,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16941,
      "e": 14491,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i "
    },
    {
      "t": 17181,
      "e": 14731,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 17182,
      "e": 14732,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17340,
      "e": 14890,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 17342,
      "e": 14892,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17365,
      "e": 14915,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i pe"
    },
    {
      "t": 17454,
      "e": 15004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 17454,
      "e": 15004,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17581,
      "e": 15131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 17581,
      "e": 15131,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17605,
      "e": 15155,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||rs"
    },
    {
      "t": 17628,
      "e": 15178,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17660,
      "e": 15210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 17661,
      "e": 15211,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17701,
      "e": 15251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 17733,
      "e": 15283,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 17734,
      "e": 15284,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17805,
      "e": 15355,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 17820,
      "e": 15370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 17820,
      "e": 15370,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17853,
      "e": 15403,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 17933,
      "e": 15483,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17941,
      "e": 15491,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 17942,
      "e": 15492,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17988,
      "e": 15538,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 18077,
      "e": 15627,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 18077,
      "e": 15627,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18165,
      "e": 15715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 18197,
      "e": 15747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 18198,
      "e": 15748,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18300,
      "e": 15850,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 18325,
      "e": 15875,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18325,
      "e": 15875,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18406,
      "e": 15956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19029,
      "e": 16579,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 19030,
      "e": 16580,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19133,
      "e": 16683,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 19134,
      "e": 16684,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 19135,
      "e": 16685,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19237,
      "e": 16787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 19237,
      "e": 16787,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19284,
      "e": 16834,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 19292,
      "e": 16842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 19292,
      "e": 16842,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19316,
      "e": 16866,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 19381,
      "e": 16931,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19413,
      "e": 16963,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19414,
      "e": 16964,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19525,
      "e": 17075,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20001,
      "e": 17551,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20285,
      "e": 17835,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 20285,
      "e": 17835,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20404,
      "e": 17954,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i personally find 1"
    },
    {
      "t": 20429,
      "e": 17979,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 20429,
      "e": 17979,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20477,
      "e": 18027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 20573,
      "e": 18123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20605,
      "e": 18155,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 20606,
      "e": 18156,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20685,
      "e": 18235,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 20686,
      "e": 18236,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20757,
      "e": 18307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 20788,
      "e": 18338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20845,
      "e": 18395,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20845,
      "e": 18395,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20932,
      "e": 18482,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21094,
      "e": 18644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 21094,
      "e": 18644,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21125,
      "e": 18675,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 21125,
      "e": 18675,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21212,
      "e": 18762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 21260,
      "e": 18810,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21317,
      "e": 18867,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21317,
      "e": 18867,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21429,
      "e": 18979,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22150,
      "e": 19700,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22150,
      "e": 19700,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22245,
      "e": 19795,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 22246,
      "e": 19796,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 22247,
      "e": 19797,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22325,
      "e": 19875,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 22332,
      "e": 19882,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22333,
      "e": 19883,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22380,
      "e": 19930,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22381,
      "e": 19931,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22420,
      "e": 19970,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 22485,
      "e": 20035,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23541,
      "e": 21091,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 23542,
      "e": 21092,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23605,
      "e": 21155,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 24526,
      "e": 22076,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 24527,
      "e": 22077,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24621,
      "e": 22171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 24709,
      "e": 22259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 24709,
      "e": 22259,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24816,
      "e": 22366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 24961,
      "e": 22511,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 24961,
      "e": 22511,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25024,
      "e": 22574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 25177,
      "e": 22727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 25178,
      "e": 22728,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25248,
      "e": 22798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 25264,
      "e": 22814,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 25264,
      "e": 22814,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25344,
      "e": 22894,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 25400,
      "e": 22950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25401,
      "e": 22951,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25431,
      "e": 22981,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 25433,
      "e": 22983,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25488,
      "e": 23038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 25576,
      "e": 23126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25584,
      "e": 23134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 25584,
      "e": 23134,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25640,
      "e": 23190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 25648,
      "e": 23198,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 25649,
      "e": 23199,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25737,
      "e": 23287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25737,
      "e": 23287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25744,
      "e": 23294,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 25832,
      "e": 23382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30005,
      "e": 27555,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 31336,
      "e": 28382,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 31337,
      "e": 28383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31456,
      "e": 28502,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 31608,
      "e": 28654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 31610,
      "e": 28656,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31695,
      "e": 28741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 31784,
      "e": 28830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 31784,
      "e": 28830,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31881,
      "e": 28927,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 31882,
      "e": 28928,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31904,
      "e": 28950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ag"
    },
    {
      "t": 31984,
      "e": 29030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31985,
      "e": 29031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32000,
      "e": 29046,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32113,
      "e": 29159,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32273,
      "e": 29319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 32273,
      "e": 29319,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32384,
      "e": 29430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 32408,
      "e": 29454,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 32409,
      "e": 29455,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32505,
      "e": 29551,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 32520,
      "e": 29566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32520,
      "e": 29566,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32601,
      "e": 29647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32936,
      "e": 29982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 32937,
      "e": 29983,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33009,
      "e": 30055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 33024,
      "e": 30070,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 33025,
      "e": 30071,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33112,
      "e": 30158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 33112,
      "e": 30158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33176,
      "e": 30222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 33224,
      "e": 30270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 33224,
      "e": 30270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33256,
      "e": 30302,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 33296,
      "e": 30342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33408,
      "e": 30454,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i personally find 12pm on the x-axis and drag my fing"
    },
    {
      "t": 33481,
      "e": 30527,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 33483,
      "e": 30529,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33584,
      "e": 30630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 33584,
      "e": 30630,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33617,
      "e": 30663,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 33664,
      "e": 30710,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33664,
      "e": 30710,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33704,
      "e": 30750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33760,
      "e": 30806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33945,
      "e": 30991,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 33946,
      "e": 30992,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34056,
      "e": 31102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 34056,
      "e": 31102,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34177,
      "e": 31223,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||up"
    },
    {
      "t": 34225,
      "e": 31271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34305,
      "e": 31351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 34306,
      "e": 31352,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34407,
      "e": 31453,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i personally find 12pm on the x-axis and drag my finger upw"
    },
    {
      "t": 34464,
      "e": 31510,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 34465,
      "e": 31511,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34545,
      "e": 31591,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wa"
    },
    {
      "t": 34610,
      "e": 31656,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34793,
      "e": 31839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 34795,
      "e": 31841,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34888,
      "e": 31934,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 34888,
      "e": 31934,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34968,
      "e": 32014,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||rd"
    },
    {
      "t": 35072,
      "e": 32118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36449,
      "e": 33495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36450,
      "e": 33496,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36608,
      "e": 33654,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i personally find 12pm on the x-axis and drag my finger upward "
    },
    {
      "t": 36617,
      "e": 33663,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36985,
      "e": 34031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37104,
      "e": 34150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i personally find 12pm on the x-axis and drag my finger upward"
    },
    {
      "t": 37385,
      "e": 34431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 37386,
      "e": 34432,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37480,
      "e": 34526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 37585,
      "e": 34631,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37585,
      "e": 34631,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37672,
      "e": 34718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37800,
      "e": 34846,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 37801,
      "e": 34847,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37911,
      "e": 34957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 37936,
      "e": 34982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 37936,
      "e": 34982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38040,
      "e": 35086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 38193,
      "e": 35239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 38193,
      "e": 35239,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38304,
      "e": 35350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 38897,
      "e": 35943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 38897,
      "e": 35943,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38968,
      "e": 36014,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 39040,
      "e": 36086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 39040,
      "e": 36086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39120,
      "e": 36166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 39121,
      "e": 36167,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39176,
      "e": 36222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 39369,
      "e": 36415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39409,
      "e": 36455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 39411,
      "e": 36457,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39528,
      "e": 36574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 39529,
      "e": 36575,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39559,
      "e": 36605,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ve"
    },
    {
      "t": 39649,
      "e": 36695,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 39649,
      "e": 36695,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39696,
      "e": 36695,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 39720,
      "e": 36719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39720,
      "e": 36719,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39743,
      "e": 36742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39792,
      "e": 36791,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43424,
      "e": 40423,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 43425,
      "e": 40424,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43536,
      "e": 40535,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 44096,
      "e": 41095,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 44097,
      "e": 41096,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44185,
      "e": 41184,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 44185,
      "e": 41184,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44264,
      "e": 41263,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 44296,
      "e": 41295,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 44296,
      "e": 41295,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44319,
      "e": 41318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 44440,
      "e": 41439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 44441,
      "e": 41440,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44463,
      "e": 41462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 44608,
      "e": 41607,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i personally find 12pm on the x-axis and drag my finger upward. whichever shift"
    },
    {
      "t": 44608,
      "e": 41607,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44616,
      "e": 41615,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44617,
      "e": 41616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44711,
      "e": 41710,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45233,
      "e": 42232,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 45233,
      "e": 42232,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45351,
      "e": 42350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 45417,
      "e": 42416,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 45417,
      "e": 42416,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45521,
      "e": 42520,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 45625,
      "e": 42624,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 45625,
      "e": 42624,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45695,
      "e": 42694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 45696,
      "e": 42695,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45767,
      "e": 42766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 45808,
      "e": 42807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45889,
      "e": 42888,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 45889,
      "e": 42888,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46007,
      "e": 43006,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i personally find 12pm on the x-axis and drag my finger upward. whichever shift overl"
    },
    {
      "t": 46048,
      "e": 43047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 46113,
      "e": 43112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 46113,
      "e": 43112,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46224,
      "e": 43223,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 46336,
      "e": 43335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 46337,
      "e": 43336,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46440,
      "e": 43439,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 46520,
      "e": 43519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 46521,
      "e": 43520,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46680,
      "e": 43679,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 46704,
      "e": 43703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46704,
      "e": 43703,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46784,
      "e": 43783,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48400,
      "e": 45399,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 48401,
      "e": 45400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48496,
      "e": 45495,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 48569,
      "e": 45568,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48569,
      "e": 45568,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48648,
      "e": 45647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48816,
      "e": 45815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 48818,
      "e": 45817,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48912,
      "e": 45911,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 48912,
      "e": 45911,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48976,
      "e": 45975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 48976,
      "e": 45975,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48984,
      "e": 45983,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||not"
    },
    {
      "t": 49015,
      "e": 46014,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49047,
      "e": 46046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 49047,
      "e": 46046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49120,
      "e": 46119,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 49160,
      "e": 46159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49160,
      "e": 46159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49199,
      "e": 46198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49255,
      "e": 46254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49704,
      "e": 46703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 49706,
      "e": 46705,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49776,
      "e": 46775,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 49792,
      "e": 46791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 49792,
      "e": 46791,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49896,
      "e": 46895,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 49968,
      "e": 46967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 49970,
      "e": 46969,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50005,
      "e": 47004,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50072,
      "e": 47071,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 50087,
      "e": 47086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 50087,
      "e": 47086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50176,
      "e": 47175,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 51113,
      "e": 48112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 51113,
      "e": 48112,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51160,
      "e": 48159,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 51670,
      "e": 48669,
      "ty": 7,
      "x": 273,
      "y": 609,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51705,
      "e": 48704,
      "ty": 2,
      "x": 107,
      "y": 641
    },
    {
      "t": 51755,
      "e": 48754,
      "ty": 41,
      "x": 0,
      "y": 35232,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 51805,
      "e": 48804,
      "ty": 2,
      "x": 92,
      "y": 649
    },
    {
      "t": 51905,
      "e": 48904,
      "ty": 2,
      "x": 124,
      "y": 743
    },
    {
      "t": 52005,
      "e": 49004,
      "ty": 2,
      "x": 163,
      "y": 718
    },
    {
      "t": 52006,
      "e": 49005,
      "ty": 41,
      "x": 7408,
      "y": 39332,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 52106,
      "e": 49105,
      "ty": 2,
      "x": 223,
      "y": 669
    },
    {
      "t": 52205,
      "e": 49204,
      "ty": 2,
      "x": 284,
      "y": 677
    },
    {
      "t": 52255,
      "e": 49254,
      "ty": 41,
      "x": 190,
      "y": 42116,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 52305,
      "e": 49304,
      "ty": 2,
      "x": 338,
      "y": 685
    },
    {
      "t": 52321,
      "e": 49320,
      "ty": 6,
      "x": 346,
      "y": 685,
      "ta": "#strategyButton"
    },
    {
      "t": 52405,
      "e": 49404,
      "ty": 2,
      "x": 365,
      "y": 683
    },
    {
      "t": 52505,
      "e": 49504,
      "ty": 2,
      "x": 366,
      "y": 682
    },
    {
      "t": 52505,
      "e": 49504,
      "ty": 41,
      "x": 14967,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 52509,
      "e": 49508,
      "ty": 3,
      "x": 366,
      "y": 682,
      "ta": "#strategyButton"
    },
    {
      "t": 52509,
      "e": 49508,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i personally find 12pm on the x-axis and drag my finger upward. whichever shift overlaps i note down."
    },
    {
      "t": 52511,
      "e": 49510,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52511,
      "e": 49510,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 52588,
      "e": 49587,
      "ty": 4,
      "x": 15513,
      "y": 50626,
      "ta": "#strategyButton"
    },
    {
      "t": 52597,
      "e": 49596,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 52599,
      "e": 49598,
      "ty": 5,
      "x": 367,
      "y": 681,
      "ta": "#strategyButton"
    },
    {
      "t": 52608,
      "e": 49607,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 52611,
      "e": 49610,
      "ty": 2,
      "x": 367,
      "y": 681
    },
    {
      "t": 52756,
      "e": 49755,
      "ty": 41,
      "x": 12363,
      "y": 37282,
      "ta": "html > body"
    },
    {
      "t": 53606,
      "e": 50605,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 54255,
      "e": 51254,
      "ty": 41,
      "x": 12535,
      "y": 37226,
      "ta": "html > body"
    },
    {
      "t": 54306,
      "e": 51305,
      "ty": 2,
      "x": 425,
      "y": 666
    },
    {
      "t": 54406,
      "e": 51405,
      "ty": 2,
      "x": 847,
      "y": 614
    },
    {
      "t": 54505,
      "e": 51504,
      "ty": 2,
      "x": 865,
      "y": 603
    },
    {
      "t": 54505,
      "e": 51504,
      "ty": 41,
      "x": 12328,
      "y": 4681,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 54606,
      "e": 51605,
      "ty": 2,
      "x": 900,
      "y": 579
    },
    {
      "t": 54640,
      "e": 51639,
      "ty": 6,
      "x": 900,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54705,
      "e": 51704,
      "ty": 2,
      "x": 901,
      "y": 570
    },
    {
      "t": 54755,
      "e": 51754,
      "ty": 41,
      "x": 20114,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54805,
      "e": 51804,
      "ty": 2,
      "x": 901,
      "y": 563
    },
    {
      "t": 54829,
      "e": 51828,
      "ty": 3,
      "x": 901,
      "y": 563,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54830,
      "e": 51829,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54924,
      "e": 51923,
      "ty": 4,
      "x": 20114,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54924,
      "e": 51923,
      "ty": 5,
      "x": 901,
      "y": 563,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55006,
      "e": 52005,
      "ty": 41,
      "x": 20114,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55536,
      "e": 52535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 55536,
      "e": 52535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55600,
      "e": 52599,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 55793,
      "e": 52792,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 55793,
      "e": 52792,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55824,
      "e": 52823,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "22"
    },
    {
      "t": 56505,
      "e": 53504,
      "ty": 2,
      "x": 900,
      "y": 563
    },
    {
      "t": 56506,
      "e": 53505,
      "ty": 41,
      "x": 19898,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56524,
      "e": 53523,
      "ty": 7,
      "x": 904,
      "y": 577,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56605,
      "e": 53604,
      "ty": 2,
      "x": 920,
      "y": 622
    },
    {
      "t": 56705,
      "e": 53704,
      "ty": 2,
      "x": 927,
      "y": 645
    },
    {
      "t": 56756,
      "e": 53755,
      "ty": 41,
      "x": 25738,
      "y": 43690,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 56997,
      "e": 53996,
      "ty": 6,
      "x": 928,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57005,
      "e": 54004,
      "ty": 2,
      "x": 928,
      "y": 647
    },
    {
      "t": 57005,
      "e": 54004,
      "ty": 41,
      "x": 25954,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57105,
      "e": 54104,
      "ty": 2,
      "x": 929,
      "y": 649
    },
    {
      "t": 57180,
      "e": 54179,
      "ty": 3,
      "x": 929,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57181,
      "e": 54180,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "22"
    },
    {
      "t": 57181,
      "e": 54180,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 57181,
      "e": 54180,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57255,
      "e": 54254,
      "ty": 41,
      "x": 26170,
      "y": 6241,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57268,
      "e": 54267,
      "ty": 4,
      "x": 26170,
      "y": 6241,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57268,
      "e": 54267,
      "ty": 5,
      "x": 929,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58480,
      "e": 55479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 58481,
      "e": 55480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58536,
      "e": 55535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 58536,
      "e": 55535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58592,
      "e": 55591,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "th"
    },
    {
      "t": 58623,
      "e": 55622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 58624,
      "e": 55623,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58647,
      "e": 55646,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "the"
    },
    {
      "t": 58705,
      "e": 55704,
      "ty": 2,
      "x": 930,
      "y": 649
    },
    {
      "t": 58720,
      "e": 55719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 58720,
      "e": 55719,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58752,
      "e": 55751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "the "
    },
    {
      "t": 58755,
      "e": 55754,
      "ty": 41,
      "x": 26387,
      "y": 6241,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58808,
      "e": 55807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 59264,
      "e": 56263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 59265,
      "e": 56264,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59335,
      "e": 56334,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 59335,
      "e": 56334,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59367,
      "e": 56366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||un"
    },
    {
      "t": 59487,
      "e": 56486,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 59488,
      "e": 56487,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59551,
      "e": 56550,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||i"
    },
    {
      "t": 59592,
      "e": 56591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 59592,
      "e": 56591,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59648,
      "e": 56647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 59671,
      "e": 56670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 59792,
      "e": 56791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 59793,
      "e": 56792,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59944,
      "e": 56943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 59944,
      "e": 56943,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59999,
      "e": 56998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||es"
    },
    {
      "t": 60006,
      "e": 57005,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60055,
      "e": 57054,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 60368,
      "e": 57367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 60431,
      "e": 57430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "the unite"
    },
    {
      "t": 60440,
      "e": 57439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 60440,
      "e": 57439,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60552,
      "e": 57551,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 60824,
      "e": 57823,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 60825,
      "e": 57824,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60936,
      "e": 57935,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 61008,
      "e": 58007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 61009,
      "e": 58008,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61112,
      "e": 58111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 61232,
      "e": 58231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 61233,
      "e": 58232,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61296,
      "e": 58295,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 61296,
      "e": 58295,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 61296,
      "e": 58295,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61376,
      "e": 58375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 61432,
      "e": 58431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 61432,
      "e": 58431,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61512,
      "e": 58511,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 61513,
      "e": 58512,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 61513,
      "e": 58512,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61616,
      "e": 58615,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 61617,
      "e": 58616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61687,
      "e": 58686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||es"
    },
    {
      "t": 61743,
      "e": 58742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 62397,
      "e": 59396,
      "ty": 7,
      "x": 958,
      "y": 640,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62405,
      "e": 59404,
      "ty": 2,
      "x": 958,
      "y": 640
    },
    {
      "t": 62467,
      "e": 59466,
      "ty": 6,
      "x": 961,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62506,
      "e": 59505,
      "ty": 2,
      "x": 963,
      "y": 653
    },
    {
      "t": 62506,
      "e": 59505,
      "ty": 41,
      "x": 33524,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62605,
      "e": 59604,
      "ty": 2,
      "x": 965,
      "y": 657
    },
    {
      "t": 62705,
      "e": 59704,
      "ty": 2,
      "x": 970,
      "y": 663
    },
    {
      "t": 62729,
      "e": 59728,
      "ty": 7,
      "x": 974,
      "y": 672,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62755,
      "e": 59754,
      "ty": 41,
      "x": 36119,
      "y": 63420,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 62805,
      "e": 59804,
      "ty": 2,
      "x": 976,
      "y": 674
    },
    {
      "t": 62814,
      "e": 59813,
      "ty": 6,
      "x": 976,
      "y": 677,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 62906,
      "e": 59905,
      "ty": 2,
      "x": 976,
      "y": 686
    },
    {
      "t": 63005,
      "e": 60004,
      "ty": 2,
      "x": 976,
      "y": 687
    },
    {
      "t": 63005,
      "e": 60004,
      "ty": 41,
      "x": 41271,
      "y": 21845,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63036,
      "e": 60035,
      "ty": 3,
      "x": 976,
      "y": 687,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63038,
      "e": 60037,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "the united states"
    },
    {
      "t": 63039,
      "e": 60038,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63039,
      "e": 60038,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63172,
      "e": 60171,
      "ty": 4,
      "x": 41271,
      "y": 21845,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63173,
      "e": 60172,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63173,
      "e": 60172,
      "ty": 5,
      "x": 976,
      "y": 687,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63173,
      "e": 60172,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 64192,
      "e": 61191,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 64805,
      "e": 61804,
      "ty": 2,
      "x": 979,
      "y": 688
    },
    {
      "t": 64904,
      "e": 61903,
      "ty": 2,
      "x": 993,
      "y": 632
    },
    {
      "t": 65004,
      "e": 62003,
      "ty": 2,
      "x": 931,
      "y": 464
    },
    {
      "t": 65005,
      "e": 62004,
      "ty": 41,
      "x": 26005,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 65104,
      "e": 62103,
      "ty": 2,
      "x": 909,
      "y": 389
    },
    {
      "t": 65205,
      "e": 62204,
      "ty": 2,
      "x": 905,
      "y": 308
    },
    {
      "t": 65254,
      "e": 62253,
      "ty": 41,
      "x": 20547,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 65305,
      "e": 62304,
      "ty": 2,
      "x": 905,
      "y": 248
    },
    {
      "t": 65404,
      "e": 62403,
      "ty": 2,
      "x": 853,
      "y": 193
    },
    {
      "t": 65505,
      "e": 62504,
      "ty": 2,
      "x": 836,
      "y": 181
    },
    {
      "t": 65505,
      "e": 62504,
      "ty": 41,
      "x": 3459,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-0 > p"
    },
    {
      "t": 65605,
      "e": 62604,
      "ty": 2,
      "x": 830,
      "y": 195
    },
    {
      "t": 65705,
      "e": 62704,
      "ty": 2,
      "x": 830,
      "y": 224
    },
    {
      "t": 65755,
      "e": 62754,
      "ty": 41,
      "x": 2510,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 65805,
      "e": 62804,
      "ty": 2,
      "x": 833,
      "y": 230
    },
    {
      "t": 65899,
      "e": 62898,
      "ty": 6,
      "x": 833,
      "y": 232,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 65905,
      "e": 62904,
      "ty": 2,
      "x": 833,
      "y": 232
    },
    {
      "t": 66005,
      "e": 63004,
      "ty": 2,
      "x": 833,
      "y": 234
    },
    {
      "t": 66006,
      "e": 63005,
      "ty": 41,
      "x": 33161,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 66118,
      "e": 63117,
      "ty": 3,
      "x": 833,
      "y": 234,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 66119,
      "e": 63118,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 66220,
      "e": 63219,
      "ty": 4,
      "x": 33161,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 66221,
      "e": 63220,
      "ty": 5,
      "x": 833,
      "y": 234,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 66222,
      "e": 63221,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 66305,
      "e": 63304,
      "ty": 2,
      "x": 835,
      "y": 242
    },
    {
      "t": 66315,
      "e": 63314,
      "ty": 7,
      "x": 835,
      "y": 248,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 66332,
      "e": 63331,
      "ty": 6,
      "x": 837,
      "y": 262,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 66365,
      "e": 63364,
      "ty": 7,
      "x": 841,
      "y": 281,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 66404,
      "e": 63403,
      "ty": 2,
      "x": 846,
      "y": 299
    },
    {
      "t": 66505,
      "e": 63504,
      "ty": 2,
      "x": 853,
      "y": 336
    },
    {
      "t": 66505,
      "e": 63504,
      "ty": 41,
      "x": 7494,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 66604,
      "e": 63603,
      "ty": 2,
      "x": 853,
      "y": 364
    },
    {
      "t": 66705,
      "e": 63704,
      "ty": 2,
      "x": 854,
      "y": 380
    },
    {
      "t": 66759,
      "e": 63708,
      "ty": 41,
      "x": 7731,
      "y": 8665,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 66805,
      "e": 63754,
      "ty": 2,
      "x": 853,
      "y": 393
    },
    {
      "t": 66905,
      "e": 63854,
      "ty": 2,
      "x": 849,
      "y": 401
    },
    {
      "t": 67005,
      "e": 63954,
      "ty": 2,
      "x": 845,
      "y": 407
    },
    {
      "t": 67005,
      "e": 63954,
      "ty": 41,
      "x": 27600,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 67066,
      "e": 64015,
      "ty": 6,
      "x": 838,
      "y": 414,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 67105,
      "e": 64054,
      "ty": 2,
      "x": 838,
      "y": 417
    },
    {
      "t": 67149,
      "e": 64098,
      "ty": 7,
      "x": 837,
      "y": 422,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 67205,
      "e": 64154,
      "ty": 2,
      "x": 836,
      "y": 433
    },
    {
      "t": 67250,
      "e": 64199,
      "ty": 6,
      "x": 835,
      "y": 436,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 67255,
      "e": 64204,
      "ty": 41,
      "x": 43243,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 67305,
      "e": 64254,
      "ty": 2,
      "x": 835,
      "y": 445
    },
    {
      "t": 67316,
      "e": 64265,
      "ty": 7,
      "x": 835,
      "y": 449,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 67405,
      "e": 64354,
      "ty": 2,
      "x": 835,
      "y": 451
    },
    {
      "t": 67505,
      "e": 64454,
      "ty": 2,
      "x": 835,
      "y": 459
    },
    {
      "t": 67505,
      "e": 64454,
      "ty": 41,
      "x": 3222,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 67533,
      "e": 64482,
      "ty": 6,
      "x": 833,
      "y": 465,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 67605,
      "e": 64554,
      "ty": 2,
      "x": 833,
      "y": 476
    },
    {
      "t": 67617,
      "e": 64566,
      "ty": 7,
      "x": 833,
      "y": 480,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 67666,
      "e": 64615,
      "ty": 6,
      "x": 834,
      "y": 494,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 67705,
      "e": 64654,
      "ty": 2,
      "x": 837,
      "y": 498
    },
    {
      "t": 67755,
      "e": 64704,
      "ty": 41,
      "x": 53325,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 67766,
      "e": 64715,
      "ty": 7,
      "x": 839,
      "y": 507,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 67804,
      "e": 64753,
      "ty": 2,
      "x": 840,
      "y": 510
    },
    {
      "t": 67904,
      "e": 64853,
      "ty": 2,
      "x": 841,
      "y": 519
    },
    {
      "t": 68001,
      "e": 64950,
      "ty": 6,
      "x": 839,
      "y": 529,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 68005,
      "e": 64954,
      "ty": 2,
      "x": 839,
      "y": 529
    },
    {
      "t": 68006,
      "e": 64955,
      "ty": 41,
      "x": 63408,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 68105,
      "e": 65054,
      "ty": 2,
      "x": 837,
      "y": 530
    },
    {
      "t": 68168,
      "e": 65117,
      "ty": 7,
      "x": 833,
      "y": 518,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 68204,
      "e": 65153,
      "ty": 2,
      "x": 833,
      "y": 510
    },
    {
      "t": 68250,
      "e": 65199,
      "ty": 6,
      "x": 831,
      "y": 502,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 68255,
      "e": 65204,
      "ty": 41,
      "x": 23079,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 68304,
      "e": 65253,
      "ty": 2,
      "x": 830,
      "y": 500
    },
    {
      "t": 68405,
      "e": 65354,
      "ty": 2,
      "x": 830,
      "y": 498
    },
    {
      "t": 68485,
      "e": 65434,
      "ty": 3,
      "x": 830,
      "y": 498,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 68486,
      "e": 65435,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 68486,
      "e": 65435,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 68505,
      "e": 65454,
      "ty": 41,
      "x": 18037,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 68612,
      "e": 65561,
      "ty": 4,
      "x": 18037,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 68612,
      "e": 65561,
      "ty": 5,
      "x": 830,
      "y": 498,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 68613,
      "e": 65562,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf",
      "v": "Fourth"
    },
    {
      "t": 68800,
      "e": 65749,
      "ty": 7,
      "x": 830,
      "y": 510,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 68804,
      "e": 65753,
      "ty": 2,
      "x": 830,
      "y": 510
    },
    {
      "t": 68834,
      "e": 65783,
      "ty": 6,
      "x": 831,
      "y": 523,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 68884,
      "e": 65833,
      "ty": 7,
      "x": 831,
      "y": 542,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 68904,
      "e": 65853,
      "ty": 2,
      "x": 831,
      "y": 547
    },
    {
      "t": 68918,
      "e": 65867,
      "ty": 6,
      "x": 831,
      "y": 550,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 69002,
      "e": 65951,
      "ty": 7,
      "x": 831,
      "y": 561,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 69005,
      "e": 65954,
      "ty": 2,
      "x": 831,
      "y": 561
    },
    {
      "t": 69006,
      "e": 65955,
      "ty": 41,
      "x": 6535,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 69084,
      "e": 66033,
      "ty": 6,
      "x": 834,
      "y": 576,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 69105,
      "e": 66054,
      "ty": 2,
      "x": 836,
      "y": 576
    },
    {
      "t": 69202,
      "e": 66151,
      "ty": 7,
      "x": 833,
      "y": 589,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 69205,
      "e": 66154,
      "ty": 2,
      "x": 833,
      "y": 589
    },
    {
      "t": 69255,
      "e": 66204,
      "ty": 41,
      "x": 27791,
      "y": 32961,
      "ta": "html > body"
    },
    {
      "t": 69305,
      "e": 66254,
      "ty": 2,
      "x": 809,
      "y": 609
    },
    {
      "t": 69405,
      "e": 66354,
      "ty": 2,
      "x": 805,
      "y": 613
    },
    {
      "t": 69505,
      "e": 66454,
      "ty": 41,
      "x": 27446,
      "y": 33515,
      "ta": "html > body"
    },
    {
      "t": 69806,
      "e": 66755,
      "ty": 2,
      "x": 805,
      "y": 615
    },
    {
      "t": 69905,
      "e": 66854,
      "ty": 2,
      "x": 805,
      "y": 627
    },
    {
      "t": 70004,
      "e": 66953,
      "ty": 2,
      "x": 802,
      "y": 649
    },
    {
      "t": 70005,
      "e": 66954,
      "ty": 41,
      "x": 27343,
      "y": 35509,
      "ta": "html > body"
    },
    {
      "t": 70105,
      "e": 67054,
      "ty": 2,
      "x": 800,
      "y": 664
    },
    {
      "t": 70205,
      "e": 67154,
      "ty": 2,
      "x": 799,
      "y": 666
    },
    {
      "t": 70256,
      "e": 67205,
      "ty": 41,
      "x": 27240,
      "y": 36506,
      "ta": "html > body"
    },
    {
      "t": 70305,
      "e": 67254,
      "ty": 2,
      "x": 801,
      "y": 671
    },
    {
      "t": 70405,
      "e": 67354,
      "ty": 2,
      "x": 803,
      "y": 673
    },
    {
      "t": 70505,
      "e": 67454,
      "ty": 41,
      "x": 27377,
      "y": 36839,
      "ta": "html > body"
    },
    {
      "t": 70705,
      "e": 67654,
      "ty": 2,
      "x": 805,
      "y": 674
    },
    {
      "t": 70755,
      "e": 67704,
      "ty": 41,
      "x": 27550,
      "y": 37060,
      "ta": "html > body"
    },
    {
      "t": 70805,
      "e": 67754,
      "ty": 2,
      "x": 811,
      "y": 682
    },
    {
      "t": 70905,
      "e": 67854,
      "ty": 2,
      "x": 818,
      "y": 694
    },
    {
      "t": 71004,
      "e": 67953,
      "ty": 2,
      "x": 822,
      "y": 699
    },
    {
      "t": 71004,
      "e": 67953,
      "ty": 41,
      "x": 145,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 71045,
      "e": 67994,
      "ty": 6,
      "x": 826,
      "y": 705,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 71078,
      "e": 68027,
      "ty": 7,
      "x": 829,
      "y": 711,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 71105,
      "e": 68054,
      "ty": 2,
      "x": 831,
      "y": 714
    },
    {
      "t": 71185,
      "e": 68134,
      "ty": 6,
      "x": 834,
      "y": 724,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 71205,
      "e": 68154,
      "ty": 2,
      "x": 834,
      "y": 725
    },
    {
      "t": 71255,
      "e": 68204,
      "ty": 41,
      "x": 58367,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 71270,
      "e": 68219,
      "ty": 7,
      "x": 840,
      "y": 739,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 71305,
      "e": 68254,
      "ty": 2,
      "x": 843,
      "y": 745
    },
    {
      "t": 71405,
      "e": 68354,
      "ty": 2,
      "x": 847,
      "y": 757
    },
    {
      "t": 71505,
      "e": 68454,
      "ty": 2,
      "x": 849,
      "y": 769
    },
    {
      "t": 71505,
      "e": 68454,
      "ty": 41,
      "x": 6544,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 71605,
      "e": 68554,
      "ty": 2,
      "x": 849,
      "y": 786
    },
    {
      "t": 71704,
      "e": 68653,
      "ty": 2,
      "x": 844,
      "y": 805
    },
    {
      "t": 71755,
      "e": 68704,
      "ty": 41,
      "x": 12146,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 71804,
      "e": 68753,
      "ty": 6,
      "x": 839,
      "y": 818,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 71805,
      "e": 68754,
      "ty": 2,
      "x": 839,
      "y": 818
    },
    {
      "t": 71837,
      "e": 68786,
      "ty": 7,
      "x": 838,
      "y": 823,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 71905,
      "e": 68854,
      "ty": 2,
      "x": 834,
      "y": 831
    },
    {
      "t": 71971,
      "e": 68920,
      "ty": 6,
      "x": 828,
      "y": 840,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 72005,
      "e": 68954,
      "ty": 2,
      "x": 826,
      "y": 845
    },
    {
      "t": 72006,
      "e": 68955,
      "ty": 41,
      "x": 0,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 72030,
      "e": 68956,
      "ty": 7,
      "x": 825,
      "y": 846,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 72105,
      "e": 69031,
      "ty": 2,
      "x": 825,
      "y": 846
    },
    {
      "t": 72205,
      "e": 69131,
      "ty": 2,
      "x": 816,
      "y": 823
    },
    {
      "t": 72255,
      "e": 69181,
      "ty": 41,
      "x": 27791,
      "y": 44871,
      "ta": "html > body"
    },
    {
      "t": 72305,
      "e": 69231,
      "ty": 2,
      "x": 815,
      "y": 813
    },
    {
      "t": 72405,
      "e": 69331,
      "ty": 2,
      "x": 815,
      "y": 808
    },
    {
      "t": 72505,
      "e": 69431,
      "ty": 2,
      "x": 813,
      "y": 804
    },
    {
      "t": 72506,
      "e": 69432,
      "ty": 41,
      "x": 27722,
      "y": 44096,
      "ta": "html > body"
    },
    {
      "t": 72605,
      "e": 69531,
      "ty": 2,
      "x": 812,
      "y": 801
    },
    {
      "t": 72755,
      "e": 69681,
      "ty": 41,
      "x": 27687,
      "y": 43930,
      "ta": "html > body"
    },
    {
      "t": 73105,
      "e": 70031,
      "ty": 2,
      "x": 821,
      "y": 811
    },
    {
      "t": 73205,
      "e": 70131,
      "ty": 2,
      "x": 828,
      "y": 823
    },
    {
      "t": 73255,
      "e": 70181,
      "ty": 41,
      "x": 2035,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 73306,
      "e": 70232,
      "ty": 2,
      "x": 833,
      "y": 830
    },
    {
      "t": 73355,
      "e": 70281,
      "ty": 6,
      "x": 837,
      "y": 837,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 73405,
      "e": 70331,
      "ty": 2,
      "x": 837,
      "y": 837
    },
    {
      "t": 73487,
      "e": 70413,
      "ty": 7,
      "x": 840,
      "y": 844,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 73504,
      "e": 70430,
      "ty": 2,
      "x": 841,
      "y": 846
    },
    {
      "t": 73504,
      "e": 70430,
      "ty": 41,
      "x": 13793,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 73606,
      "e": 70532,
      "ty": 2,
      "x": 841,
      "y": 847
    },
    {
      "t": 73755,
      "e": 70681,
      "ty": 41,
      "x": 13793,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 74006,
      "e": 70932,
      "ty": 2,
      "x": 845,
      "y": 832
    },
    {
      "t": 74007,
      "e": 70933,
      "ty": 41,
      "x": 5595,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 74105,
      "e": 71031,
      "ty": 2,
      "x": 847,
      "y": 828
    },
    {
      "t": 74205,
      "e": 71131,
      "ty": 2,
      "x": 851,
      "y": 820
    },
    {
      "t": 74255,
      "e": 71181,
      "ty": 41,
      "x": 18638,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 74306,
      "e": 71232,
      "ty": 2,
      "x": 854,
      "y": 812
    },
    {
      "t": 74405,
      "e": 71331,
      "ty": 2,
      "x": 855,
      "y": 805
    },
    {
      "t": 74505,
      "e": 71431,
      "ty": 2,
      "x": 855,
      "y": 796
    },
    {
      "t": 74506,
      "e": 71432,
      "ty": 41,
      "x": 18798,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 74604,
      "e": 71530,
      "ty": 2,
      "x": 855,
      "y": 789
    },
    {
      "t": 74705,
      "e": 71631,
      "ty": 2,
      "x": 857,
      "y": 784
    },
    {
      "t": 74755,
      "e": 71681,
      "ty": 41,
      "x": 19917,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 74805,
      "e": 71731,
      "ty": 2,
      "x": 858,
      "y": 780
    },
    {
      "t": 74906,
      "e": 71832,
      "ty": 2,
      "x": 860,
      "y": 778
    },
    {
      "t": 75004,
      "e": 71930,
      "ty": 2,
      "x": 861,
      "y": 774
    },
    {
      "t": 75005,
      "e": 71931,
      "ty": 41,
      "x": 9392,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 75105,
      "e": 72031,
      "ty": 2,
      "x": 861,
      "y": 769
    },
    {
      "t": 75205,
      "e": 72131,
      "ty": 2,
      "x": 862,
      "y": 768
    },
    {
      "t": 75256,
      "e": 72182,
      "ty": 41,
      "x": 16931,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 75305,
      "e": 72231,
      "ty": 2,
      "x": 862,
      "y": 767
    },
    {
      "t": 76505,
      "e": 73431,
      "ty": 2,
      "x": 862,
      "y": 762
    },
    {
      "t": 76505,
      "e": 73431,
      "ty": 41,
      "x": 16931,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 76605,
      "e": 73531,
      "ty": 2,
      "x": 845,
      "y": 751
    },
    {
      "t": 76705,
      "e": 73631,
      "ty": 2,
      "x": 826,
      "y": 737
    },
    {
      "t": 76756,
      "e": 73682,
      "ty": 41,
      "x": 27928,
      "y": 40107,
      "ta": "html > body"
    },
    {
      "t": 76806,
      "e": 73732,
      "ty": 2,
      "x": 816,
      "y": 728
    },
    {
      "t": 76905,
      "e": 73831,
      "ty": 2,
      "x": 816,
      "y": 718
    },
    {
      "t": 77005,
      "e": 73931,
      "ty": 2,
      "x": 816,
      "y": 715
    },
    {
      "t": 77005,
      "e": 73931,
      "ty": 41,
      "x": 27825,
      "y": 39165,
      "ta": "html > body"
    },
    {
      "t": 77105,
      "e": 74031,
      "ty": 2,
      "x": 821,
      "y": 709
    },
    {
      "t": 77125,
      "e": 74051,
      "ty": 6,
      "x": 826,
      "y": 706,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 77205,
      "e": 74131,
      "ty": 2,
      "x": 827,
      "y": 704
    },
    {
      "t": 77256,
      "e": 74182,
      "ty": 41,
      "x": 2914,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 77421,
      "e": 74347,
      "ty": 3,
      "x": 827,
      "y": 704,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 77422,
      "e": 74348,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 77423,
      "e": 74349,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 77547,
      "e": 74473,
      "ty": 4,
      "x": 2914,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 77547,
      "e": 74473,
      "ty": 5,
      "x": 827,
      "y": 704,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 77548,
      "e": 74474,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 77792,
      "e": 74718,
      "ty": 7,
      "x": 827,
      "y": 713,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 77805,
      "e": 74731,
      "ty": 2,
      "x": 827,
      "y": 713
    },
    {
      "t": 77905,
      "e": 74831,
      "ty": 2,
      "x": 803,
      "y": 777
    },
    {
      "t": 78006,
      "e": 74932,
      "ty": 41,
      "x": 27377,
      "y": 42600,
      "ta": "html > body"
    },
    {
      "t": 78106,
      "e": 75032,
      "ty": 1,
      "x": 0,
      "y": 6
    },
    {
      "t": 78205,
      "e": 75131,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 78405,
      "e": 75331,
      "ty": 2,
      "x": 802,
      "y": 806
    },
    {
      "t": 78505,
      "e": 75431,
      "ty": 2,
      "x": 815,
      "y": 902
    },
    {
      "t": 78506,
      "e": 75432,
      "ty": 41,
      "x": 27791,
      "y": 49525,
      "ta": "html > body"
    },
    {
      "t": 78576,
      "e": 75502,
      "ty": 6,
      "x": 827,
      "y": 931,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 78606,
      "e": 75532,
      "ty": 2,
      "x": 829,
      "y": 936
    },
    {
      "t": 78705,
      "e": 75631,
      "ty": 2,
      "x": 833,
      "y": 939
    },
    {
      "t": 78755,
      "e": 75681,
      "ty": 41,
      "x": 33161,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 78843,
      "e": 75769,
      "ty": 7,
      "x": 834,
      "y": 941,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 78905,
      "e": 75831,
      "ty": 2,
      "x": 835,
      "y": 948
    },
    {
      "t": 79005,
      "e": 75931,
      "ty": 2,
      "x": 837,
      "y": 955
    },
    {
      "t": 79006,
      "e": 75932,
      "ty": 41,
      "x": 12601,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 79285,
      "e": 76211,
      "ty": 3,
      "x": 837,
      "y": 955,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 79286,
      "e": 76212,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 79363,
      "e": 76289,
      "ty": 4,
      "x": 12601,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 79363,
      "e": 76289,
      "ty": 5,
      "x": 837,
      "y": 955,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 79363,
      "e": 76289,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 79364,
      "e": 76290,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 79500,
      "e": 76426,
      "ty": 6,
      "x": 837,
      "y": 956,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 79505,
      "e": 76431,
      "ty": 2,
      "x": 837,
      "y": 956
    },
    {
      "t": 79506,
      "e": 76432,
      "ty": 41,
      "x": 53325,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 79605,
      "e": 76531,
      "ty": 2,
      "x": 832,
      "y": 964
    },
    {
      "t": 79626,
      "e": 76552,
      "ty": 7,
      "x": 834,
      "y": 970,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 79706,
      "e": 76632,
      "ty": 2,
      "x": 849,
      "y": 984
    },
    {
      "t": 79755,
      "e": 76681,
      "ty": 41,
      "x": 28370,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 79805,
      "e": 76731,
      "ty": 2,
      "x": 850,
      "y": 984
    },
    {
      "t": 79906,
      "e": 76832,
      "ty": 2,
      "x": 870,
      "y": 996
    },
    {
      "t": 79926,
      "e": 76852,
      "ty": 6,
      "x": 886,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80005,
      "e": 76931,
      "ty": 2,
      "x": 891,
      "y": 1008
    },
    {
      "t": 80006,
      "e": 76932,
      "ty": 41,
      "x": 31736,
      "y": 5957,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80705,
      "e": 77631,
      "ty": 2,
      "x": 895,
      "y": 1018
    },
    {
      "t": 80755,
      "e": 77681,
      "ty": 41,
      "x": 33798,
      "y": 25816,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 81316,
      "e": 78242,
      "ty": 3,
      "x": 895,
      "y": 1018,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 81318,
      "e": 78244,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 81318,
      "e": 78244,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 81475,
      "e": 78401,
      "ty": 4,
      "x": 33798,
      "y": 25816,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 81476,
      "e": 78402,
      "ty": 5,
      "x": 895,
      "y": 1018,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 81479,
      "e": 78405,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 81479,
      "e": 78405,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 81480,
      "e": 78406,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 82808,
      "e": 79734,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 87507,
      "e": 83405,
      "ty": 2,
      "x": 895,
      "y": 1010
    },
    {
      "t": 87508,
      "e": 83406,
      "ty": 41,
      "x": 29594,
      "y": 61194,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 87607,
      "e": 83505,
      "ty": 2,
      "x": 941,
      "y": 773
    },
    {
      "t": 87707,
      "e": 83605,
      "ty": 2,
      "x": 954,
      "y": 560
    },
    {
      "t": 87757,
      "e": 83655,
      "ty": 41,
      "x": 29938,
      "y": 62036,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 87806,
      "e": 83704,
      "ty": 2,
      "x": 864,
      "y": 409
    },
    {
      "t": 87906,
      "e": 83804,
      "ty": 2,
      "x": 757,
      "y": 340
    },
    {
      "t": 88006,
      "e": 83904,
      "ty": 2,
      "x": 726,
      "y": 328
    },
    {
      "t": 88007,
      "e": 83905,
      "ty": 41,
      "x": 21280,
      "y": 13967,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 88206,
      "e": 84104,
      "ty": 2,
      "x": 725,
      "y": 328
    },
    {
      "t": 88257,
      "e": 84155,
      "ty": 41,
      "x": 21230,
      "y": 14105,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 88307,
      "e": 84205,
      "ty": 2,
      "x": 722,
      "y": 334
    },
    {
      "t": 88406,
      "e": 84304,
      "ty": 2,
      "x": 717,
      "y": 338
    },
    {
      "t": 88507,
      "e": 84405,
      "ty": 2,
      "x": 715,
      "y": 340
    },
    {
      "t": 88507,
      "e": 84405,
      "ty": 41,
      "x": 20738,
      "y": 12909,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 88606,
      "e": 84504,
      "ty": 2,
      "x": 713,
      "y": 341
    },
    {
      "t": 88706,
      "e": 84604,
      "ty": 2,
      "x": 713,
      "y": 343
    },
    {
      "t": 88757,
      "e": 84655,
      "ty": 41,
      "x": 20542,
      "y": 22271,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 88806,
      "e": 84704,
      "ty": 2,
      "x": 710,
      "y": 344
    },
    {
      "t": 89006,
      "e": 84904,
      "ty": 41,
      "x": 20492,
      "y": 22271,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 89106,
      "e": 85004,
      "ty": 2,
      "x": 692,
      "y": 354
    },
    {
      "t": 89207,
      "e": 85105,
      "ty": 2,
      "x": 593,
      "y": 366
    },
    {
      "t": 89257,
      "e": 85155,
      "ty": 41,
      "x": 14244,
      "y": 3880,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 89306,
      "e": 85204,
      "ty": 2,
      "x": 582,
      "y": 368
    },
    {
      "t": 89407,
      "e": 85305,
      "ty": 2,
      "x": 581,
      "y": 368
    },
    {
      "t": 89507,
      "e": 85405,
      "ty": 41,
      "x": 14146,
      "y": 3880,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 90006,
      "e": 85904,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 91707,
      "e": 87605,
      "ty": 2,
      "x": 582,
      "y": 393
    },
    {
      "t": 91757,
      "e": 87655,
      "ty": 41,
      "x": 14638,
      "y": 26148,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 91806,
      "e": 87704,
      "ty": 2,
      "x": 611,
      "y": 457
    },
    {
      "t": 91906,
      "e": 87804,
      "ty": 2,
      "x": 660,
      "y": 547
    },
    {
      "t": 92006,
      "e": 87904,
      "ty": 2,
      "x": 706,
      "y": 643
    },
    {
      "t": 92007,
      "e": 87905,
      "ty": 41,
      "x": 20296,
      "y": 62615,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 92107,
      "e": 88005,
      "ty": 2,
      "x": 827,
      "y": 839
    },
    {
      "t": 92206,
      "e": 88104,
      "ty": 2,
      "x": 891,
      "y": 949
    },
    {
      "t": 92257,
      "e": 88155,
      "ty": 41,
      "x": 29692,
      "y": 57800,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 92306,
      "e": 88204,
      "ty": 2,
      "x": 897,
      "y": 977
    },
    {
      "t": 92407,
      "e": 88305,
      "ty": 2,
      "x": 910,
      "y": 1031
    },
    {
      "t": 92455,
      "e": 88353,
      "ty": 6,
      "x": 935,
      "y": 1074,
      "ta": "#start"
    },
    {
      "t": 92507,
      "e": 88405,
      "ty": 2,
      "x": 942,
      "y": 1085
    },
    {
      "t": 92507,
      "e": 88405,
      "ty": 41,
      "x": 17749,
      "y": 23732,
      "ta": "#start"
    },
    {
      "t": 92607,
      "e": 88505,
      "ty": 2,
      "x": 942,
      "y": 1086
    },
    {
      "t": 92706,
      "e": 88604,
      "ty": 2,
      "x": 944,
      "y": 1089
    },
    {
      "t": 92756,
      "e": 88654,
      "ty": 41,
      "x": 19387,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 92806,
      "e": 88704,
      "ty": 2,
      "x": 945,
      "y": 1091
    },
    {
      "t": 100007,
      "e": 93704,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 100767,
      "e": 93704,
      "ty": 3,
      "x": 945,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 100768,
      "e": 93705,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 100852,
      "e": 93789,
      "ty": 4,
      "x": 19387,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 100853,
      "e": 93790,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 100853,
      "e": 93790,
      "ty": 5,
      "x": 945,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 100854,
      "e": 93791,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 101892,
      "e": 94829,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 103334,
      "e": 96271,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"id\":2593},{\"id\":2594},{\"id\":2595},{\"id\":2596},{\"id\":2597},{\"id\":2598},{\"id\":2599},{\"id\":2600},{\"nodeType\":3,\"id\":2604,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2601},{\"id\":2602},{\"nodeType\":3,\"id\":2605,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2603}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2606,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2607,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2606},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2608,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2607},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2609,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2608},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2607}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2607}},{\"nodeType\":3,\"id\":2612,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2608}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2608}},{\"nodeType\":3,\"id\":2615,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2616,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2609}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2606},{\"id\":2607},{\"id\":2610},{\"id\":2612},{\"id\":2611},{\"id\":2608},{\"id\":2613},{\"id\":2615},{\"id\":2614},{\"id\":2609},{\"id\":2616}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2617,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2621,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2620},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2622},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2625,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2625},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2626},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2628,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2619}},{\"nodeType\":3,\"id\":2629,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2629},\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2631,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2625}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2631}},{\"nodeType\":3,\"id\":2633,\"textContent\":\"English\",\"previousSibling\":{\"id\":2632},\"parentNode\":{\"id\":2631}},{\"nodeType\":1,\"id\":2634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2635,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2634}},{\"nodeType\":3,\"id\":2636,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2635},\"parentNode\":{\"id\":2634}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2627}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":3,\"id\":2639,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2628}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":3,\"id\":2642,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2640}},{\"nodeType\":3,\"id\":2643,\"textContent\":\"*\",\"parentNode\":{\"id\":2630}},{\"nodeType\":1,\"id\":2644,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2645},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2646},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2648,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2648},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2649},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2651,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2620}},{\"nodeType\":3,\"id\":2652,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2652},\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2654,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2654}},{\"nodeType\":3,\"id\":2656,\"textContent\":\"First\",\"previousSibling\":{\"id\":2655},\"parentNode\":{\"id\":2654}},{\"nodeType\":1,\"id\":2657,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2657}},{\"nodeType\":3,\"id\":2659,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2658},\"parentNode\":{\"id\":2657}},{\"nodeType\":1,\"id\":2660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2647}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2660}},{\"nodeType\":3,\"id\":2662,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2661},\"parentNode\":{\"id\":2660}},{\"nodeType\":1,\"id\":2663,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2648}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2663}},{\"nodeType\":3,\"id\":2665,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2664},\"parentNode\":{\"id\":2663}},{\"nodeType\":1,\"id\":2666,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2667,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2666}},{\"nodeType\":3,\"id\":2668,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2667},\"parentNode\":{\"id\":2666}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2650}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":3,\"id\":2671,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2651}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":3,\"id\":2674,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2672}},{\"nodeType\":3,\"id\":2675,\"textContent\":\"*\",\"parentNode\":{\"id\":2653}},{\"nodeType\":1,\"id\":2676,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2677},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2678},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2680,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2680},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2681},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2683,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2621}},{\"nodeType\":3,\"id\":2684,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2684},\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2686,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2686}},{\"nodeType\":3,\"id\":2688,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2687},\"parentNode\":{\"id\":2686}},{\"nodeType\":1,\"id\":2689,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2689}},{\"nodeType\":3,\"id\":2691,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2690},\"parentNode\":{\"id\":2689}},{\"nodeType\":1,\"id\":2692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2679}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2692}},{\"nodeType\":3,\"id\":2694,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2693},\"parentNode\":{\"id\":2692}},{\"nodeType\":1,\"id\":2695,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2680}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2695}},{\"nodeType\":3,\"id\":2697,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2696},\"parentNode\":{\"id\":2695}},{\"nodeType\":1,\"id\":2698,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2699,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2698}},{\"nodeType\":3,\"id\":2700,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2699},\"parentNode\":{\"id\":2698}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2682}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":3,\"id\":2703,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2704,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2683}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2704}},{\"nodeType\":3,\"id\":2706,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2705},\"parentNode\":{\"id\":2704}},{\"nodeType\":3,\"id\":2707,\"textContent\":\"*\",\"parentNode\":{\"id\":2685}},{\"nodeType\":1,\"id\":2708,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2708},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2709},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2711,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2622}},{\"nodeType\":3,\"id\":2712,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2712},\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2714,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2715,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2714}},{\"nodeType\":3,\"id\":2716,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2715},\"parentNode\":{\"id\":2714}},{\"nodeType\":1,\"id\":2717,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2710}},{\"nodeType\":1,\"id\":2718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2717}},{\"nodeType\":3,\"id\":2719,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2717}},{\"nodeType\":1,\"id\":2720,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2711}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2722,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2723,\"textContent\":\"*\",\"parentNode\":{\"id\":2713}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2617},{\"id\":2618},{\"id\":2619},{\"id\":2624},{\"id\":2629},{\"id\":2630},{\"id\":2643},{\"id\":2625},{\"id\":2631},{\"id\":2632},{\"id\":2633},{\"id\":2626},{\"id\":2634},{\"id\":2635},{\"id\":2636},{\"id\":2627},{\"id\":2637},{\"id\":2638},{\"id\":2639},{\"id\":2628},{\"id\":2640},{\"id\":2641},{\"id\":2642},{\"id\":2620},{\"id\":2644},{\"id\":2652},{\"id\":2653},{\"id\":2675},{\"id\":2645},{\"id\":2654},{\"id\":2655},{\"id\":2656},{\"id\":2646},{\"id\":2657},{\"id\":2658},{\"id\":2659},{\"id\":2647},{\"id\":2660},{\"id\":2661},{\"id\":2662},{\"id\":2648},{\"id\":2663},{\"id\":2664},{\"id\":2665},{\"id\":2649},{\"id\":2666},{\"id\":2667},{\"id\":2668},{\"id\":2650},{\"id\":2669},{\"id\":2670},{\"id\":2671},{\"id\":2651},{\"id\":2672},{\"id\":2673},{\"id\":2674},{\"id\":2621},{\"id\":2676},{\"id\":2684},{\"id\":2685},{\"id\":2707},{\"id\":2677},{\"id\":2686},{\"id\":2687},{\"id\":2688},{\"id\":2678},{\"id\":2689},{\"id\":2690},{\"id\":2691},{\"id\":2679},{\"id\":2692},{\"id\":2693},{\"id\":2694},{\"id\":2680},{\"id\":2695},{\"id\":2696},{\"id\":2697},{\"id\":2681},{\"id\":2698},{\"id\":2699},{\"id\":2700},{\"id\":2682},{\"id\":2701},{\"id\":2702},{\"id\":2703},{\"id\":2683},{\"id\":2704},{\"id\":2705},{\"id\":2706},{\"id\":2622},{\"id\":2708},{\"id\":2712},{\"id\":2713},{\"id\":2723},{\"id\":2709},{\"id\":2714},{\"id\":2715},{\"id\":2716},{\"id\":2710},{\"id\":2717},{\"id\":2718},{\"id\":2719},{\"id\":2711},{\"id\":2720},{\"id\":2721},{\"id\":2722},{\"id\":2623}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2724,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"previousSibling\":{\"id\":2724},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2726,\"textContent\":\" \",\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"previousSibling\":{\"id\":2727},\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2731,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2730},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"previousSibling\":{\"id\":2731},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2733,\"textContent\":\" \",\"parentNode\":{\"id\":2727}},{\"nodeType\":1,\"id\":2734,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"previousSibling\":{\"id\":2734},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2736,\"textContent\":\" \",\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2739,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"parentNode\":{\"id\":2729}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2743,\"textContent\":\" \",\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2744,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2747,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2746},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"previousSibling\":{\"id\":2747},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" \",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2751,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2750},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"previousSibling\":{\"id\":2751},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2744}},{\"nodeType\":3,\"id\":2756,\"textContent\":\" \",\"parentNode\":{\"id\":2745}},{\"nodeType\":1,\"id\":2757,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2758,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2757},\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2757}},{\"nodeType\":3,\"id\":2760,\"textContent\":\" \",\"parentNode\":{\"id\":2747}},{\"nodeType\":1,\"id\":2761,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2760},\"parentNode\":{\"id\":2747}},{\"nodeType\":3,\"id\":2762,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2747}},{\"nodeType\":3,\"id\":2763,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2761}},{\"nodeType\":1,\"id\":2764,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2765,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2764},\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2764}},{\"nodeType\":3,\"id\":2767,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2751}},{\"nodeType\":3,\"id\":2768,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2753}},{\"nodeType\":3,\"id\":2769,\"textContent\":\" \",\"parentNode\":{\"id\":2731}},{\"nodeType\":1,\"id\":2770,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2769},\"parentNode\":{\"id\":2731}},{\"nodeType\":3,\"id\":2771,\"textContent\":\" \",\"previousSibling\":{\"id\":2770},\"parentNode\":{\"id\":2731}},{\"nodeType\":3,\"id\":2772,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2770}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2724},{\"id\":2726},{\"id\":2727},{\"id\":2733},{\"id\":2734},{\"id\":2736},{\"id\":2737},{\"id\":2739},{\"id\":2738},{\"id\":2735},{\"id\":2728},{\"id\":2729},{\"id\":2740},{\"id\":2741},{\"id\":2743},{\"id\":2744},{\"id\":2755},{\"id\":2745},{\"id\":2756},{\"id\":2757},{\"id\":2759},{\"id\":2758},{\"id\":2746},{\"id\":2747},{\"id\":2760},{\"id\":2761},{\"id\":2763},{\"id\":2762},{\"id\":2748},{\"id\":2749},{\"id\":2764},{\"id\":2766},{\"id\":2765},{\"id\":2750},{\"id\":2751},{\"id\":2767},{\"id\":2752},{\"id\":2753},{\"id\":2768},{\"id\":2754},{\"id\":2742},{\"id\":2730},{\"id\":2731},{\"id\":2769},{\"id\":2770},{\"id\":2772},{\"id\":2771},{\"id\":2732},{\"id\":2725}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2773,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2774,\"textContent\":\"[ { \\\"rt\\\": 33780, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 33784, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"F98S2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 45928, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 80804, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"F98S2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 10187, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"kilo\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"113\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 91999, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"F98S2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 32211, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 125301, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"F98S2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 26528, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 152833, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"F98S2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 55480, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 209916, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"F98S2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -08 AM-06 PM-05 PM-04 PM-01 PM-12 PM-11 AM-2-1-A -A -H -E -12 PM-11 AM-A -A -A -04 PM-12 PM-11 AM-10 AM-11 AM-11 AM-10 AM-09 AM-12-X -X \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1781,y:870,t:1527189576352};\\\", \\\"{x:1762,y:859,t:1527189576360};\\\", \\\"{x:1751,y:846,t:1527189576376};\\\", \\\"{x:1726,y:823,t:1527189576392};\\\", \\\"{x:1701,y:808,t:1527189576410};\\\", \\\"{x:1670,y:793,t:1527189576425};\\\", \\\"{x:1647,y:784,t:1527189576442};\\\", \\\"{x:1625,y:774,t:1527189576459};\\\", \\\"{x:1596,y:764,t:1527189576476};\\\", \\\"{x:1570,y:758,t:1527189576493};\\\", \\\"{x:1549,y:753,t:1527189576510};\\\", \\\"{x:1532,y:751,t:1527189576526};\\\", \\\"{x:1514,y:750,t:1527189576543};\\\", \\\"{x:1502,y:750,t:1527189576559};\\\", \\\"{x:1488,y:750,t:1527189576575};\\\", \\\"{x:1459,y:750,t:1527189576592};\\\", \\\"{x:1437,y:750,t:1527189576609};\\\", \\\"{x:1426,y:750,t:1527189576627};\\\", \\\"{x:1414,y:755,t:1527189576643};\\\", \\\"{x:1406,y:762,t:1527189576660};\\\", \\\"{x:1383,y:773,t:1527189576683};\\\", \\\"{x:1372,y:774,t:1527189576692};\\\", \\\"{x:1355,y:779,t:1527189576710};\\\", \\\"{x:1345,y:780,t:1527189576727};\\\", \\\"{x:1342,y:780,t:1527189576742};\\\", \\\"{x:1333,y:780,t:1527189576759};\\\", \\\"{x:1326,y:780,t:1527189576776};\\\", \\\"{x:1321,y:780,t:1527189576792};\\\", \\\"{x:1320,y:780,t:1527189576809};\\\", \\\"{x:1317,y:780,t:1527189576826};\\\", \\\"{x:1316,y:780,t:1527189576849};\\\", \\\"{x:1314,y:780,t:1527189576864};\\\", \\\"{x:1313,y:780,t:1527189576876};\\\", \\\"{x:1304,y:780,t:1527189576893};\\\", \\\"{x:1294,y:780,t:1527189576910};\\\", \\\"{x:1286,y:780,t:1527189576927};\\\", \\\"{x:1271,y:780,t:1527189576943};\\\", \\\"{x:1261,y:780,t:1527189576960};\\\", \\\"{x:1258,y:780,t:1527189576977};\\\", \\\"{x:1257,y:776,t:1527189577281};\\\", \\\"{x:1268,y:751,t:1527189577294};\\\", \\\"{x:1298,y:684,t:1527189577310};\\\", \\\"{x:1332,y:607,t:1527189577327};\\\", \\\"{x:1353,y:540,t:1527189577344};\\\", \\\"{x:1363,y:507,t:1527189577360};\\\", \\\"{x:1380,y:470,t:1527189577377};\\\", \\\"{x:1391,y:451,t:1527189577394};\\\", \\\"{x:1402,y:409,t:1527189577410};\\\", \\\"{x:1407,y:367,t:1527189577427};\\\", \\\"{x:1412,y:328,t:1527189577444};\\\", \\\"{x:1413,y:302,t:1527189577460};\\\", \\\"{x:1418,y:273,t:1527189577477};\\\", \\\"{x:1420,y:268,t:1527189577493};\\\", \\\"{x:1422,y:267,t:1527189577510};\\\", \\\"{x:1422,y:266,t:1527189577738};\\\", \\\"{x:1422,y:264,t:1527189577745};\\\", \\\"{x:1423,y:258,t:1527189577760};\\\", \\\"{x:1425,y:251,t:1527189577776};\\\", \\\"{x:1426,y:249,t:1527189577794};\\\", \\\"{x:1426,y:245,t:1527189577811};\\\", \\\"{x:1427,y:242,t:1527189577827};\\\", \\\"{x:1430,y:236,t:1527189577844};\\\", \\\"{x:1436,y:228,t:1527189577861};\\\", \\\"{x:1440,y:221,t:1527189577876};\\\", \\\"{x:1443,y:214,t:1527189577893};\\\", \\\"{x:1444,y:211,t:1527189577910};\\\", \\\"{x:1444,y:210,t:1527189577927};\\\", \\\"{x:1445,y:209,t:1527189577944};\\\", \\\"{x:1445,y:214,t:1527189578034};\\\", \\\"{x:1445,y:224,t:1527189578044};\\\", \\\"{x:1439,y:246,t:1527189578061};\\\", \\\"{x:1430,y:267,t:1527189578078};\\\", \\\"{x:1427,y:284,t:1527189578094};\\\", \\\"{x:1423,y:296,t:1527189578111};\\\", \\\"{x:1418,y:316,t:1527189578128};\\\", \\\"{x:1409,y:341,t:1527189578144};\\\", \\\"{x:1399,y:372,t:1527189578161};\\\", \\\"{x:1391,y:391,t:1527189578177};\\\", \\\"{x:1385,y:407,t:1527189578194};\\\", \\\"{x:1376,y:417,t:1527189578210};\\\", \\\"{x:1372,y:427,t:1527189578228};\\\", \\\"{x:1363,y:444,t:1527189578243};\\\", \\\"{x:1357,y:458,t:1527189578261};\\\", \\\"{x:1353,y:467,t:1527189578278};\\\", \\\"{x:1346,y:477,t:1527189578293};\\\", \\\"{x:1339,y:494,t:1527189578310};\\\", \\\"{x:1333,y:509,t:1527189578327};\\\", \\\"{x:1328,y:523,t:1527189578343};\\\", \\\"{x:1314,y:547,t:1527189578361};\\\", \\\"{x:1301,y:567,t:1527189578377};\\\", \\\"{x:1290,y:589,t:1527189578394};\\\", \\\"{x:1279,y:608,t:1527189578411};\\\", \\\"{x:1268,y:630,t:1527189578428};\\\", \\\"{x:1262,y:644,t:1527189578444};\\\", \\\"{x:1258,y:653,t:1527189578461};\\\", \\\"{x:1253,y:663,t:1527189578478};\\\", \\\"{x:1247,y:673,t:1527189578493};\\\", \\\"{x:1244,y:675,t:1527189578511};\\\", \\\"{x:1238,y:680,t:1527189578528};\\\", \\\"{x:1230,y:691,t:1527189578545};\\\", \\\"{x:1226,y:693,t:1527189578561};\\\", \\\"{x:1221,y:699,t:1527189578578};\\\", \\\"{x:1221,y:700,t:1527189578675};\\\", \\\"{x:1221,y:698,t:1527189579066};\\\", \\\"{x:1222,y:690,t:1527189579078};\\\", \\\"{x:1225,y:675,t:1527189579095};\\\", \\\"{x:1227,y:663,t:1527189579112};\\\", \\\"{x:1230,y:653,t:1527189579128};\\\", \\\"{x:1230,y:644,t:1527189579145};\\\", \\\"{x:1230,y:636,t:1527189579162};\\\", \\\"{x:1230,y:630,t:1527189579179};\\\", \\\"{x:1233,y:621,t:1527189579195};\\\", \\\"{x:1233,y:618,t:1527189579212};\\\", \\\"{x:1236,y:616,t:1527189579228};\\\", \\\"{x:1237,y:611,t:1527189579245};\\\", \\\"{x:1241,y:600,t:1527189579262};\\\", \\\"{x:1250,y:590,t:1527189579278};\\\", \\\"{x:1255,y:577,t:1527189579295};\\\", \\\"{x:1266,y:567,t:1527189579312};\\\", \\\"{x:1271,y:556,t:1527189579328};\\\", \\\"{x:1297,y:519,t:1527189579345};\\\", \\\"{x:1313,y:496,t:1527189579365};\\\", \\\"{x:1327,y:480,t:1527189579378};\\\", \\\"{x:1335,y:471,t:1527189579394};\\\", \\\"{x:1336,y:470,t:1527189579913};\\\", \\\"{x:1338,y:470,t:1527189579929};\\\", \\\"{x:1340,y:472,t:1527189579946};\\\", \\\"{x:1342,y:473,t:1527189579962};\\\", \\\"{x:1343,y:474,t:1527189579979};\\\", \\\"{x:1344,y:474,t:1527189580033};\\\", \\\"{x:1346,y:475,t:1527189580082};\\\", \\\"{x:1347,y:476,t:1527189580097};\\\", \\\"{x:1348,y:476,t:1527189580146};\\\", \\\"{x:1348,y:477,t:1527189580162};\\\", \\\"{x:1348,y:480,t:1527189580179};\\\", \\\"{x:1348,y:481,t:1527189580202};\\\", \\\"{x:1348,y:483,t:1527189580225};\\\", \\\"{x:1348,y:485,t:1527189580233};\\\", \\\"{x:1348,y:488,t:1527189580246};\\\", \\\"{x:1346,y:499,t:1527189580263};\\\", \\\"{x:1346,y:501,t:1527189580362};\\\", \\\"{x:1339,y:510,t:1527189580379};\\\", \\\"{x:1337,y:514,t:1527189580396};\\\", \\\"{x:1331,y:522,t:1527189580413};\\\", \\\"{x:1329,y:527,t:1527189580429};\\\", \\\"{x:1323,y:537,t:1527189580446};\\\", \\\"{x:1317,y:549,t:1527189580463};\\\", \\\"{x:1309,y:565,t:1527189580479};\\\", \\\"{x:1303,y:574,t:1527189580496};\\\", \\\"{x:1297,y:584,t:1527189580514};\\\", \\\"{x:1293,y:590,t:1527189580529};\\\", \\\"{x:1288,y:602,t:1527189580546};\\\", \\\"{x:1279,y:615,t:1527189580563};\\\", \\\"{x:1273,y:629,t:1527189580579};\\\", \\\"{x:1265,y:641,t:1527189580597};\\\", \\\"{x:1259,y:652,t:1527189580613};\\\", \\\"{x:1253,y:663,t:1527189580630};\\\", \\\"{x:1245,y:671,t:1527189580647};\\\", \\\"{x:1239,y:676,t:1527189580664};\\\", \\\"{x:1231,y:685,t:1527189580679};\\\", \\\"{x:1222,y:701,t:1527189580696};\\\", \\\"{x:1198,y:723,t:1527189580713};\\\", \\\"{x:1188,y:736,t:1527189580729};\\\", \\\"{x:1180,y:748,t:1527189580746};\\\", \\\"{x:1171,y:757,t:1527189580763};\\\", \\\"{x:1168,y:764,t:1527189580779};\\\", \\\"{x:1165,y:769,t:1527189580796};\\\", \\\"{x:1163,y:774,t:1527189580813};\\\", \\\"{x:1158,y:781,t:1527189580830};\\\", \\\"{x:1153,y:793,t:1527189580846};\\\", \\\"{x:1149,y:801,t:1527189580863};\\\", \\\"{x:1145,y:808,t:1527189580880};\\\", \\\"{x:1145,y:813,t:1527189580897};\\\", \\\"{x:1144,y:823,t:1527189580913};\\\", \\\"{x:1144,y:829,t:1527189580930};\\\", \\\"{x:1144,y:832,t:1527189580946};\\\", \\\"{x:1144,y:833,t:1527189581017};\\\", \\\"{x:1145,y:833,t:1527189581033};\\\", \\\"{x:1146,y:833,t:1527189581090};\\\", \\\"{x:1146,y:832,t:1527189581225};\\\", \\\"{x:1148,y:831,t:1527189581458};\\\", \\\"{x:1149,y:829,t:1527189581466};\\\", \\\"{x:1146,y:829,t:1527189581514};\\\", \\\"{x:1144,y:829,t:1527189581530};\\\", \\\"{x:1143,y:829,t:1527189581762};\\\", \\\"{x:1141,y:836,t:1527189581769};\\\", \\\"{x:1140,y:843,t:1527189581781};\\\", \\\"{x:1133,y:860,t:1527189581797};\\\", \\\"{x:1130,y:873,t:1527189581814};\\\", \\\"{x:1128,y:888,t:1527189581830};\\\", \\\"{x:1125,y:900,t:1527189581847};\\\", \\\"{x:1121,y:913,t:1527189581864};\\\", \\\"{x:1119,y:922,t:1527189581881};\\\", \\\"{x:1116,y:932,t:1527189581897};\\\", \\\"{x:1114,y:940,t:1527189581914};\\\", \\\"{x:1109,y:951,t:1527189581930};\\\", \\\"{x:1107,y:958,t:1527189581947};\\\", \\\"{x:1106,y:963,t:1527189581965};\\\", \\\"{x:1105,y:966,t:1527189581981};\\\", \\\"{x:1104,y:968,t:1527189581998};\\\", \\\"{x:1103,y:973,t:1527189582014};\\\", \\\"{x:1101,y:977,t:1527189582031};\\\", \\\"{x:1100,y:979,t:1527189582048};\\\", \\\"{x:1099,y:981,t:1527189582065};\\\", \\\"{x:1098,y:982,t:1527189582081};\\\", \\\"{x:1100,y:983,t:1527189582178};\\\", \\\"{x:1103,y:983,t:1527189582186};\\\", \\\"{x:1104,y:983,t:1527189582198};\\\", \\\"{x:1112,y:985,t:1527189582215};\\\", \\\"{x:1118,y:985,t:1527189582230};\\\", \\\"{x:1123,y:985,t:1527189582248};\\\", \\\"{x:1130,y:985,t:1527189582265};\\\", \\\"{x:1141,y:988,t:1527189582281};\\\", \\\"{x:1148,y:988,t:1527189582298};\\\", \\\"{x:1155,y:988,t:1527189582315};\\\", \\\"{x:1159,y:988,t:1527189582331};\\\", \\\"{x:1160,y:988,t:1527189582347};\\\", \\\"{x:1167,y:988,t:1527189582364};\\\", \\\"{x:1175,y:988,t:1527189582381};\\\", \\\"{x:1177,y:988,t:1527189582397};\\\", \\\"{x:1184,y:989,t:1527189582415};\\\", \\\"{x:1191,y:989,t:1527189582431};\\\", \\\"{x:1198,y:989,t:1527189582447};\\\", \\\"{x:1201,y:989,t:1527189582465};\\\", \\\"{x:1203,y:989,t:1527189582481};\\\", \\\"{x:1212,y:989,t:1527189582497};\\\", \\\"{x:1217,y:989,t:1527189582514};\\\", \\\"{x:1220,y:989,t:1527189582531};\\\", \\\"{x:1228,y:989,t:1527189582547};\\\", \\\"{x:1230,y:989,t:1527189582564};\\\", \\\"{x:1232,y:989,t:1527189582582};\\\", \\\"{x:1244,y:988,t:1527189582598};\\\", \\\"{x:1253,y:988,t:1527189582615};\\\", \\\"{x:1266,y:988,t:1527189582631};\\\", \\\"{x:1275,y:988,t:1527189582647};\\\", \\\"{x:1289,y:988,t:1527189582664};\\\", \\\"{x:1311,y:988,t:1527189582681};\\\", \\\"{x:1333,y:988,t:1527189582698};\\\", \\\"{x:1353,y:988,t:1527189582715};\\\", \\\"{x:1390,y:988,t:1527189582732};\\\", \\\"{x:1465,y:988,t:1527189582748};\\\", \\\"{x:1549,y:988,t:1527189582765};\\\", \\\"{x:1618,y:988,t:1527189582781};\\\", \\\"{x:1696,y:988,t:1527189582798};\\\", \\\"{x:1768,y:988,t:1527189582814};\\\", \\\"{x:1836,y:990,t:1527189582831};\\\", \\\"{x:1898,y:992,t:1527189582847};\\\", \\\"{x:1919,y:992,t:1527189582865};\\\", \\\"{x:1919,y:988,t:1527189582881};\\\", \\\"{x:1919,y:989,t:1527189582905};\\\", \\\"{x:1919,y:988,t:1527189582914};\\\", \\\"{x:1919,y:987,t:1527189582931};\\\", \\\"{x:1919,y:984,t:1527189582948};\\\", \\\"{x:1919,y:985,t:1527189583146};\\\", \\\"{x:1913,y:985,t:1527189583153};\\\", \\\"{x:1906,y:988,t:1527189583165};\\\", \\\"{x:1901,y:989,t:1527189583182};\\\", \\\"{x:1898,y:989,t:1527189583198};\\\", \\\"{x:1896,y:989,t:1527189583215};\\\", \\\"{x:1892,y:989,t:1527189583232};\\\", \\\"{x:1888,y:990,t:1527189583248};\\\", \\\"{x:1882,y:990,t:1527189583265};\\\", \\\"{x:1879,y:990,t:1527189583282};\\\", \\\"{x:1875,y:990,t:1527189583299};\\\", \\\"{x:1864,y:990,t:1527189583315};\\\", \\\"{x:1854,y:990,t:1527189583331};\\\", \\\"{x:1851,y:990,t:1527189583349};\\\", \\\"{x:1836,y:989,t:1527189583365};\\\", \\\"{x:1824,y:989,t:1527189583381};\\\", \\\"{x:1816,y:988,t:1527189583399};\\\", \\\"{x:1809,y:987,t:1527189583415};\\\", \\\"{x:1793,y:983,t:1527189583432};\\\", \\\"{x:1762,y:983,t:1527189583449};\\\", \\\"{x:1739,y:983,t:1527189583464};\\\", \\\"{x:1721,y:983,t:1527189583482};\\\", \\\"{x:1702,y:983,t:1527189583499};\\\", \\\"{x:1686,y:983,t:1527189583516};\\\", \\\"{x:1665,y:983,t:1527189583532};\\\", \\\"{x:1650,y:983,t:1527189583549};\\\", \\\"{x:1629,y:983,t:1527189583567};\\\", \\\"{x:1599,y:983,t:1527189583582};\\\", \\\"{x:1582,y:984,t:1527189583600};\\\", \\\"{x:1569,y:984,t:1527189583615};\\\", \\\"{x:1557,y:985,t:1527189583633};\\\", \\\"{x:1527,y:987,t:1527189583649};\\\", \\\"{x:1509,y:987,t:1527189583665};\\\", \\\"{x:1495,y:987,t:1527189583682};\\\", \\\"{x:1488,y:987,t:1527189583699};\\\", \\\"{x:1479,y:988,t:1527189583717};\\\", \\\"{x:1475,y:988,t:1527189583732};\\\", \\\"{x:1471,y:988,t:1527189583750};\\\", \\\"{x:1469,y:988,t:1527189583766};\\\", \\\"{x:1461,y:988,t:1527189583783};\\\", \\\"{x:1457,y:988,t:1527189583799};\\\", \\\"{x:1452,y:988,t:1527189583817};\\\", \\\"{x:1449,y:988,t:1527189583833};\\\", \\\"{x:1441,y:988,t:1527189583849};\\\", \\\"{x:1438,y:988,t:1527189583866};\\\", \\\"{x:1433,y:988,t:1527189583882};\\\", \\\"{x:1423,y:988,t:1527189583906};\\\", \\\"{x:1420,y:988,t:1527189583915};\\\", \\\"{x:1414,y:986,t:1527189583932};\\\", \\\"{x:1411,y:985,t:1527189583948};\\\", \\\"{x:1408,y:984,t:1527189583966};\\\", \\\"{x:1405,y:983,t:1527189583982};\\\", \\\"{x:1403,y:982,t:1527189583998};\\\", \\\"{x:1401,y:981,t:1527189584016};\\\", \\\"{x:1399,y:979,t:1527189584032};\\\", \\\"{x:1398,y:979,t:1527189584096};\\\", \\\"{x:1394,y:979,t:1527189584105};\\\", \\\"{x:1394,y:977,t:1527189584116};\\\", \\\"{x:1391,y:977,t:1527189584133};\\\", \\\"{x:1386,y:975,t:1527189584149};\\\", \\\"{x:1384,y:975,t:1527189584166};\\\", \\\"{x:1376,y:975,t:1527189584183};\\\", \\\"{x:1362,y:975,t:1527189584199};\\\", \\\"{x:1356,y:975,t:1527189584216};\\\", \\\"{x:1337,y:973,t:1527189584233};\\\", \\\"{x:1333,y:973,t:1527189584249};\\\", \\\"{x:1328,y:977,t:1527189584266};\\\", \\\"{x:1323,y:977,t:1527189584283};\\\", \\\"{x:1318,y:977,t:1527189584298};\\\", \\\"{x:1310,y:977,t:1527189584316};\\\", \\\"{x:1304,y:977,t:1527189584333};\\\", \\\"{x:1299,y:976,t:1527189584349};\\\", \\\"{x:1298,y:976,t:1527189584366};\\\", \\\"{x:1297,y:976,t:1527189584383};\\\", \\\"{x:1295,y:975,t:1527189584400};\\\", \\\"{x:1294,y:975,t:1527189584416};\\\", \\\"{x:1289,y:972,t:1527189584433};\\\", \\\"{x:1284,y:971,t:1527189584449};\\\", \\\"{x:1281,y:971,t:1527189584466};\\\", \\\"{x:1279,y:971,t:1527189584482};\\\", \\\"{x:1279,y:969,t:1527189584498};\\\", \\\"{x:1277,y:967,t:1527189584516};\\\", \\\"{x:1276,y:966,t:1527189584533};\\\", \\\"{x:1275,y:966,t:1527189584553};\\\", \\\"{x:1273,y:966,t:1527189584566};\\\", \\\"{x:1273,y:965,t:1527189585130};\\\", \\\"{x:1274,y:965,t:1527189585137};\\\", \\\"{x:1275,y:965,t:1527189585154};\\\", \\\"{x:1276,y:965,t:1527189585167};\\\", \\\"{x:1280,y:962,t:1527189585184};\\\", \\\"{x:1286,y:962,t:1527189585201};\\\", \\\"{x:1288,y:962,t:1527189585218};\\\", \\\"{x:1288,y:961,t:1527189585378};\\\", \\\"{x:1289,y:958,t:1527189585474};\\\", \\\"{x:1289,y:957,t:1527189585489};\\\", \\\"{x:1289,y:955,t:1527189585505};\\\", \\\"{x:1288,y:955,t:1527189585518};\\\", \\\"{x:1288,y:947,t:1527189585534};\\\", \\\"{x:1289,y:940,t:1527189585551};\\\", \\\"{x:1291,y:935,t:1527189585567};\\\", \\\"{x:1295,y:930,t:1527189585584};\\\", \\\"{x:1297,y:923,t:1527189585601};\\\", \\\"{x:1299,y:913,t:1527189585618};\\\", \\\"{x:1301,y:904,t:1527189585634};\\\", \\\"{x:1302,y:898,t:1527189585651};\\\", \\\"{x:1305,y:889,t:1527189585667};\\\", \\\"{x:1308,y:877,t:1527189585684};\\\", \\\"{x:1314,y:863,t:1527189585701};\\\", \\\"{x:1316,y:858,t:1527189585717};\\\", \\\"{x:1318,y:852,t:1527189585734};\\\", \\\"{x:1319,y:848,t:1527189585751};\\\", \\\"{x:1319,y:847,t:1527189585767};\\\", \\\"{x:1319,y:846,t:1527189585809};\\\", \\\"{x:1319,y:845,t:1527189585824};\\\", \\\"{x:1316,y:843,t:1527189585848};\\\", \\\"{x:1314,y:843,t:1527189585864};\\\", \\\"{x:1313,y:843,t:1527189585896};\\\", \\\"{x:1310,y:843,t:1527189585912};\\\", \\\"{x:1307,y:843,t:1527189585920};\\\", \\\"{x:1303,y:843,t:1527189585934};\\\", \\\"{x:1298,y:843,t:1527189585951};\\\", \\\"{x:1296,y:843,t:1527189585966};\\\", \\\"{x:1294,y:841,t:1527189585984};\\\", \\\"{x:1292,y:840,t:1527189586001};\\\", \\\"{x:1292,y:839,t:1527189586089};\\\", \\\"{x:1292,y:838,t:1527189586101};\\\", \\\"{x:1292,y:835,t:1527189586118};\\\", \\\"{x:1292,y:832,t:1527189586134};\\\", \\\"{x:1292,y:831,t:1527189586151};\\\", \\\"{x:1292,y:829,t:1527189586167};\\\", \\\"{x:1292,y:828,t:1527189586185};\\\", \\\"{x:1292,y:827,t:1527189586282};\\\", \\\"{x:1292,y:826,t:1527189586394};\\\", \\\"{x:1292,y:825,t:1527189586401};\\\", \\\"{x:1292,y:824,t:1527189586434};\\\", \\\"{x:1291,y:824,t:1527189586451};\\\", \\\"{x:1291,y:823,t:1527189586468};\\\", \\\"{x:1288,y:819,t:1527189587298};\\\", \\\"{x:1288,y:816,t:1527189587305};\\\", \\\"{x:1288,y:812,t:1527189587319};\\\", \\\"{x:1283,y:807,t:1527189587336};\\\", \\\"{x:1281,y:803,t:1527189587353};\\\", \\\"{x:1280,y:802,t:1527189587377};\\\", \\\"{x:1279,y:801,t:1527189587393};\\\", \\\"{x:1278,y:800,t:1527189587402};\\\", \\\"{x:1278,y:799,t:1527189587418};\\\", \\\"{x:1278,y:797,t:1527189587435};\\\", \\\"{x:1278,y:795,t:1527189587457};\\\", \\\"{x:1278,y:793,t:1527189587473};\\\", \\\"{x:1278,y:792,t:1527189587506};\\\", \\\"{x:1276,y:787,t:1527189587518};\\\", \\\"{x:1276,y:779,t:1527189587535};\\\", \\\"{x:1276,y:777,t:1527189587552};\\\", \\\"{x:1274,y:773,t:1527189587568};\\\", \\\"{x:1274,y:764,t:1527189587585};\\\", \\\"{x:1274,y:756,t:1527189587603};\\\", \\\"{x:1274,y:749,t:1527189587618};\\\", \\\"{x:1274,y:744,t:1527189587636};\\\", \\\"{x:1274,y:734,t:1527189587653};\\\", \\\"{x:1274,y:726,t:1527189587670};\\\", \\\"{x:1274,y:717,t:1527189587685};\\\", \\\"{x:1274,y:715,t:1527189587703};\\\", \\\"{x:1274,y:712,t:1527189587720};\\\", \\\"{x:1274,y:711,t:1527189587735};\\\", \\\"{x:1274,y:706,t:1527189587752};\\\", \\\"{x:1277,y:701,t:1527189587770};\\\", \\\"{x:1277,y:698,t:1527189587786};\\\", \\\"{x:1277,y:694,t:1527189587803};\\\", \\\"{x:1277,y:688,t:1527189587820};\\\", \\\"{x:1276,y:684,t:1527189587836};\\\", \\\"{x:1275,y:675,t:1527189587852};\\\", \\\"{x:1274,y:671,t:1527189587869};\\\", \\\"{x:1273,y:664,t:1527189587886};\\\", \\\"{x:1272,y:655,t:1527189587902};\\\", \\\"{x:1271,y:648,t:1527189587919};\\\", \\\"{x:1270,y:642,t:1527189587936};\\\", \\\"{x:1269,y:633,t:1527189587953};\\\", \\\"{x:1268,y:616,t:1527189587969};\\\", \\\"{x:1268,y:609,t:1527189587986};\\\", \\\"{x:1268,y:600,t:1527189588003};\\\", \\\"{x:1268,y:598,t:1527189588019};\\\", \\\"{x:1268,y:597,t:1527189588036};\\\", \\\"{x:1268,y:596,t:1527189588058};\\\", \\\"{x:1269,y:595,t:1527189588089};\\\", \\\"{x:1269,y:593,t:1527189588146};\\\", \\\"{x:1270,y:593,t:1527189588153};\\\", \\\"{x:1270,y:591,t:1527189588169};\\\", \\\"{x:1272,y:589,t:1527189588187};\\\", \\\"{x:1272,y:588,t:1527189588202};\\\", \\\"{x:1272,y:586,t:1527189588219};\\\", \\\"{x:1272,y:585,t:1527189588418};\\\", \\\"{x:1272,y:586,t:1527189588441};\\\", \\\"{x:1272,y:587,t:1527189588457};\\\", \\\"{x:1272,y:589,t:1527189588474};\\\", \\\"{x:1272,y:590,t:1527189588487};\\\", \\\"{x:1272,y:592,t:1527189588503};\\\", \\\"{x:1272,y:596,t:1527189588520};\\\", \\\"{x:1271,y:601,t:1527189588537};\\\", \\\"{x:1270,y:611,t:1527189588554};\\\", \\\"{x:1270,y:620,t:1527189588570};\\\", \\\"{x:1270,y:626,t:1527189588586};\\\", \\\"{x:1270,y:632,t:1527189588604};\\\", \\\"{x:1270,y:637,t:1527189588620};\\\", \\\"{x:1269,y:642,t:1527189588637};\\\", \\\"{x:1268,y:648,t:1527189588653};\\\", \\\"{x:1268,y:651,t:1527189588669};\\\", \\\"{x:1268,y:657,t:1527189588686};\\\", \\\"{x:1268,y:662,t:1527189588703};\\\", \\\"{x:1268,y:666,t:1527189588719};\\\", \\\"{x:1268,y:671,t:1527189588737};\\\", \\\"{x:1267,y:674,t:1527189588753};\\\", \\\"{x:1267,y:680,t:1527189588769};\\\", \\\"{x:1267,y:682,t:1527189588786};\\\", \\\"{x:1267,y:688,t:1527189588803};\\\", \\\"{x:1268,y:692,t:1527189588819};\\\", \\\"{x:1269,y:697,t:1527189588836};\\\", \\\"{x:1269,y:702,t:1527189588854};\\\", \\\"{x:1269,y:705,t:1527189588869};\\\", \\\"{x:1269,y:709,t:1527189588887};\\\", \\\"{x:1269,y:713,t:1527189588904};\\\", \\\"{x:1272,y:717,t:1527189588919};\\\", \\\"{x:1273,y:722,t:1527189588936};\\\", \\\"{x:1273,y:728,t:1527189588954};\\\", \\\"{x:1273,y:732,t:1527189588971};\\\", \\\"{x:1273,y:739,t:1527189588987};\\\", \\\"{x:1271,y:749,t:1527189589003};\\\", \\\"{x:1268,y:756,t:1527189589021};\\\", \\\"{x:1268,y:762,t:1527189589037};\\\", \\\"{x:1269,y:772,t:1527189589054};\\\", \\\"{x:1269,y:783,t:1527189589071};\\\", \\\"{x:1270,y:785,t:1527189589087};\\\", \\\"{x:1271,y:787,t:1527189589103};\\\", \\\"{x:1271,y:789,t:1527189589121};\\\", \\\"{x:1271,y:791,t:1527189589137};\\\", \\\"{x:1268,y:794,t:1527189589153};\\\", \\\"{x:1263,y:797,t:1527189589171};\\\", \\\"{x:1260,y:797,t:1527189589186};\\\", \\\"{x:1252,y:798,t:1527189589203};\\\", \\\"{x:1243,y:799,t:1527189589221};\\\", \\\"{x:1237,y:799,t:1527189589236};\\\", \\\"{x:1226,y:801,t:1527189589254};\\\", \\\"{x:1210,y:799,t:1527189589270};\\\", \\\"{x:1182,y:791,t:1527189589287};\\\", \\\"{x:1140,y:784,t:1527189589304};\\\", \\\"{x:1115,y:778,t:1527189589320};\\\", \\\"{x:1013,y:751,t:1527189589337};\\\", \\\"{x:917,y:732,t:1527189589354};\\\", \\\"{x:819,y:710,t:1527189589370};\\\", \\\"{x:721,y:692,t:1527189589387};\\\", \\\"{x:633,y:674,t:1527189589403};\\\", \\\"{x:535,y:670,t:1527189589420};\\\", \\\"{x:428,y:659,t:1527189589437};\\\", \\\"{x:324,y:637,t:1527189589454};\\\", \\\"{x:216,y:623,t:1527189589471};\\\", \\\"{x:135,y:624,t:1527189589486};\\\", \\\"{x:87,y:624,t:1527189589503};\\\", \\\"{x:32,y:624,t:1527189589520};\\\", \\\"{x:0,y:624,t:1527189589536};\\\", \\\"{x:0,y:625,t:1527189589553};\\\", \\\"{x:0,y:624,t:1527189589576};\\\", \\\"{x:0,y:621,t:1527189589592};\\\", \\\"{x:0,y:620,t:1527189589617};\\\", \\\"{x:0,y:619,t:1527189589632};\\\", \\\"{x:1,y:617,t:1527189589641};\\\", \\\"{x:5,y:614,t:1527189589652};\\\", \\\"{x:18,y:610,t:1527189589670};\\\", \\\"{x:32,y:605,t:1527189589686};\\\", \\\"{x:56,y:597,t:1527189589704};\\\", \\\"{x:73,y:591,t:1527189589720};\\\", \\\"{x:74,y:590,t:1527189589737};\\\", \\\"{x:77,y:590,t:1527189589754};\\\", \\\"{x:78,y:590,t:1527189589770};\\\", \\\"{x:86,y:585,t:1527189589787};\\\", \\\"{x:89,y:584,t:1527189589804};\\\", \\\"{x:92,y:583,t:1527189589820};\\\", \\\"{x:101,y:582,t:1527189589837};\\\", \\\"{x:108,y:578,t:1527189589855};\\\", \\\"{x:110,y:577,t:1527189589870};\\\", \\\"{x:113,y:574,t:1527189589888};\\\", \\\"{x:115,y:572,t:1527189589904};\\\", \\\"{x:126,y:568,t:1527189589920};\\\", \\\"{x:167,y:558,t:1527189589937};\\\", \\\"{x:189,y:553,t:1527189589954};\\\", \\\"{x:207,y:549,t:1527189589972};\\\", \\\"{x:235,y:549,t:1527189589987};\\\", \\\"{x:241,y:548,t:1527189590004};\\\", \\\"{x:265,y:545,t:1527189590019};\\\", \\\"{x:317,y:542,t:1527189590037};\\\", \\\"{x:359,y:540,t:1527189590054};\\\", \\\"{x:373,y:540,t:1527189590069};\\\", \\\"{x:381,y:541,t:1527189590087};\\\", \\\"{x:383,y:541,t:1527189590328};\\\", \\\"{x:384,y:540,t:1527189590337};\\\", \\\"{x:385,y:538,t:1527189590354};\\\", \\\"{x:386,y:536,t:1527189590371};\\\", \\\"{x:387,y:535,t:1527189590387};\\\", \\\"{x:388,y:534,t:1527189590417};\\\", \\\"{x:389,y:534,t:1527189591113};\\\", \\\"{x:390,y:534,t:1527189591121};\\\", \\\"{x:392,y:534,t:1527189591138};\\\", \\\"{x:392,y:536,t:1527189591156};\\\", \\\"{x:393,y:536,t:1527189591173};\\\", \\\"{x:393,y:537,t:1527189591190};\\\", \\\"{x:394,y:537,t:1527189591205};\\\", \\\"{x:395,y:538,t:1527189591220};\\\", \\\"{x:397,y:542,t:1527189591238};\\\", \\\"{x:401,y:548,t:1527189591255};\\\", \\\"{x:405,y:554,t:1527189591271};\\\", \\\"{x:411,y:567,t:1527189591287};\\\", \\\"{x:417,y:579,t:1527189591305};\\\", \\\"{x:419,y:582,t:1527189591321};\\\", \\\"{x:420,y:582,t:1527189591337};\\\", \\\"{x:421,y:582,t:1527189591355};\\\", \\\"{x:421,y:584,t:1527189591371};\\\", \\\"{x:421,y:583,t:1527189591545};\\\", \\\"{x:421,y:582,t:1527189591556};\\\", \\\"{x:413,y:568,t:1527189591572};\\\", \\\"{x:403,y:553,t:1527189591587};\\\", \\\"{x:392,y:540,t:1527189591605};\\\", \\\"{x:383,y:531,t:1527189591622};\\\", \\\"{x:381,y:529,t:1527189591637};\\\", \\\"{x:381,y:528,t:1527189591664};\\\", \\\"{x:381,y:527,t:1527189591688};\\\", \\\"{x:380,y:525,t:1527189591705};\\\", \\\"{x:380,y:523,t:1527189591849};\\\", \\\"{x:380,y:521,t:1527189591865};\\\", \\\"{x:382,y:521,t:1527189592129};\\\", \\\"{x:385,y:521,t:1527189592139};\\\", \\\"{x:391,y:525,t:1527189592155};\\\", \\\"{x:403,y:534,t:1527189592172};\\\", \\\"{x:415,y:543,t:1527189592189};\\\", \\\"{x:433,y:556,t:1527189592206};\\\", \\\"{x:453,y:566,t:1527189592222};\\\", \\\"{x:481,y:582,t:1527189592240};\\\", \\\"{x:522,y:605,t:1527189592257};\\\", \\\"{x:540,y:619,t:1527189592272};\\\", \\\"{x:551,y:625,t:1527189592290};\\\", \\\"{x:566,y:635,t:1527189592305};\\\", \\\"{x:593,y:653,t:1527189592323};\\\", \\\"{x:618,y:667,t:1527189592339};\\\", \\\"{x:638,y:679,t:1527189592356};\\\", \\\"{x:660,y:687,t:1527189592373};\\\", \\\"{x:680,y:693,t:1527189592389};\\\", \\\"{x:689,y:695,t:1527189592406};\\\", \\\"{x:701,y:700,t:1527189592422};\\\", \\\"{x:719,y:708,t:1527189592439};\\\", \\\"{x:738,y:711,t:1527189592457};\\\", \\\"{x:747,y:711,t:1527189592472};\\\", \\\"{x:755,y:712,t:1527189592489};\\\", \\\"{x:761,y:712,t:1527189592507};\\\", \\\"{x:775,y:712,t:1527189592523};\\\", \\\"{x:790,y:712,t:1527189592540};\\\", \\\"{x:807,y:707,t:1527189592556};\\\", \\\"{x:830,y:698,t:1527189592574};\\\", \\\"{x:862,y:682,t:1527189592590};\\\", \\\"{x:895,y:668,t:1527189592607};\\\", \\\"{x:929,y:651,t:1527189592623};\\\", \\\"{x:976,y:629,t:1527189592641};\\\", \\\"{x:1006,y:615,t:1527189592658};\\\", \\\"{x:1025,y:600,t:1527189592673};\\\", \\\"{x:1039,y:587,t:1527189592691};\\\", \\\"{x:1063,y:576,t:1527189592707};\\\", \\\"{x:1086,y:567,t:1527189592724};\\\", \\\"{x:1101,y:559,t:1527189592740};\\\", \\\"{x:1110,y:555,t:1527189592757};\\\", \\\"{x:1122,y:548,t:1527189592774};\\\", \\\"{x:1134,y:540,t:1527189592791};\\\", \\\"{x:1140,y:535,t:1527189592807};\\\", \\\"{x:1142,y:533,t:1527189592824};\\\", \\\"{x:1144,y:533,t:1527189593362};\\\", \\\"{x:1145,y:535,t:1527189593377};\\\", \\\"{x:1150,y:540,t:1527189593392};\\\", \\\"{x:1151,y:544,t:1527189593409};\\\", \\\"{x:1152,y:546,t:1527189593425};\\\", \\\"{x:1161,y:548,t:1527189593442};\\\", \\\"{x:1178,y:553,t:1527189593459};\\\", \\\"{x:1194,y:557,t:1527189593476};\\\", \\\"{x:1198,y:560,t:1527189593491};\\\", \\\"{x:1201,y:563,t:1527189593508};\\\", \\\"{x:1206,y:564,t:1527189593525};\\\", \\\"{x:1213,y:568,t:1527189593541};\\\", \\\"{x:1220,y:573,t:1527189593558};\\\", \\\"{x:1228,y:584,t:1527189593575};\\\", \\\"{x:1232,y:592,t:1527189593592};\\\", \\\"{x:1237,y:607,t:1527189593608};\\\", \\\"{x:1246,y:627,t:1527189593625};\\\", \\\"{x:1252,y:651,t:1527189593642};\\\", \\\"{x:1252,y:674,t:1527189593658};\\\", \\\"{x:1252,y:701,t:1527189593675};\\\", \\\"{x:1251,y:716,t:1527189593692};\\\", \\\"{x:1245,y:738,t:1527189593708};\\\", \\\"{x:1235,y:759,t:1527189593725};\\\", \\\"{x:1229,y:776,t:1527189593742};\\\", \\\"{x:1223,y:785,t:1527189593760};\\\", \\\"{x:1219,y:791,t:1527189593776};\\\", \\\"{x:1205,y:807,t:1527189593792};\\\", \\\"{x:1202,y:808,t:1527189593809};\\\", \\\"{x:1201,y:808,t:1527189593882};\\\", \\\"{x:1199,y:808,t:1527189593893};\\\", \\\"{x:1191,y:805,t:1527189593910};\\\", \\\"{x:1185,y:800,t:1527189593926};\\\", \\\"{x:1175,y:797,t:1527189593942};\\\", \\\"{x:1171,y:796,t:1527189593960};\\\", \\\"{x:1167,y:796,t:1527189593977};\\\", \\\"{x:1166,y:796,t:1527189593994};\\\", \\\"{x:1165,y:795,t:1527189594393};\\\", \\\"{x:1165,y:794,t:1527189594410};\\\", \\\"{x:1166,y:793,t:1527189594427};\\\", \\\"{x:1168,y:792,t:1527189594446};\\\", \\\"{x:1168,y:791,t:1527189594461};\\\", \\\"{x:1171,y:791,t:1527189595098};\\\", \\\"{x:1172,y:791,t:1527189595111};\\\", \\\"{x:1182,y:791,t:1527189595129};\\\", \\\"{x:1187,y:791,t:1527189595146};\\\", \\\"{x:1194,y:791,t:1527189595162};\\\", \\\"{x:1204,y:791,t:1527189595178};\\\", \\\"{x:1218,y:797,t:1527189595196};\\\", \\\"{x:1234,y:800,t:1527189595213};\\\", \\\"{x:1239,y:801,t:1527189595228};\\\", \\\"{x:1247,y:807,t:1527189595246};\\\", \\\"{x:1251,y:809,t:1527189595263};\\\", \\\"{x:1252,y:809,t:1527189595279};\\\", \\\"{x:1253,y:809,t:1527189595297};\\\", \\\"{x:1254,y:809,t:1527189595313};\\\", \\\"{x:1255,y:809,t:1527189595329};\\\", \\\"{x:1257,y:812,t:1527189595346};\\\", \\\"{x:1257,y:813,t:1527189595377};\\\", \\\"{x:1258,y:813,t:1527189595529};\\\", \\\"{x:1259,y:815,t:1527189595553};\\\", \\\"{x:1259,y:816,t:1527189595569};\\\", \\\"{x:1260,y:816,t:1527189595584};\\\", \\\"{x:1261,y:816,t:1527189595745};\\\", \\\"{x:1262,y:819,t:1527189595764};\\\", \\\"{x:1264,y:820,t:1527189595922};\\\", \\\"{x:1265,y:820,t:1527189595931};\\\", \\\"{x:1269,y:815,t:1527189595946};\\\", \\\"{x:1276,y:810,t:1527189595964};\\\", \\\"{x:1282,y:805,t:1527189595981};\\\", \\\"{x:1287,y:796,t:1527189595997};\\\", \\\"{x:1292,y:781,t:1527189596014};\\\", \\\"{x:1298,y:766,t:1527189596030};\\\", \\\"{x:1301,y:746,t:1527189596048};\\\", \\\"{x:1301,y:725,t:1527189596063};\\\", \\\"{x:1304,y:686,t:1527189596081};\\\", \\\"{x:1308,y:648,t:1527189596097};\\\", \\\"{x:1318,y:604,t:1527189596114};\\\", \\\"{x:1329,y:560,t:1527189596130};\\\", \\\"{x:1344,y:512,t:1527189596147};\\\", \\\"{x:1355,y:474,t:1527189596164};\\\", \\\"{x:1372,y:447,t:1527189596181};\\\", \\\"{x:1384,y:419,t:1527189596198};\\\", \\\"{x:1388,y:407,t:1527189596215};\\\", \\\"{x:1393,y:390,t:1527189596231};\\\", \\\"{x:1396,y:379,t:1527189596248};\\\", \\\"{x:1400,y:370,t:1527189596265};\\\", \\\"{x:1401,y:369,t:1527189596281};\\\", \\\"{x:1402,y:368,t:1527189596298};\\\", \\\"{x:1403,y:365,t:1527189596315};\\\", \\\"{x:1404,y:363,t:1527189596331};\\\", \\\"{x:1405,y:359,t:1527189596348};\\\", \\\"{x:1406,y:358,t:1527189596364};\\\", \\\"{x:1406,y:359,t:1527189596506};\\\", \\\"{x:1399,y:364,t:1527189596515};\\\", \\\"{x:1364,y:407,t:1527189596532};\\\", \\\"{x:1324,y:463,t:1527189596549};\\\", \\\"{x:1286,y:526,t:1527189596565};\\\", \\\"{x:1249,y:594,t:1527189596582};\\\", \\\"{x:1216,y:647,t:1527189596598};\\\", \\\"{x:1193,y:700,t:1527189596614};\\\", \\\"{x:1170,y:736,t:1527189596632};\\\", \\\"{x:1150,y:772,t:1527189596649};\\\", \\\"{x:1138,y:795,t:1527189596665};\\\", \\\"{x:1129,y:811,t:1527189596682};\\\", \\\"{x:1126,y:817,t:1527189596699};\\\", \\\"{x:1123,y:827,t:1527189596715};\\\", \\\"{x:1116,y:836,t:1527189596732};\\\", \\\"{x:1113,y:848,t:1527189596749};\\\", \\\"{x:1106,y:856,t:1527189596766};\\\", \\\"{x:1097,y:872,t:1527189596782};\\\", \\\"{x:1092,y:884,t:1527189596799};\\\", \\\"{x:1087,y:894,t:1527189596816};\\\", \\\"{x:1084,y:903,t:1527189596832};\\\", \\\"{x:1081,y:907,t:1527189596849};\\\", \\\"{x:1080,y:912,t:1527189596866};\\\", \\\"{x:1077,y:918,t:1527189596883};\\\", \\\"{x:1073,y:931,t:1527189596899};\\\", \\\"{x:1073,y:934,t:1527189596916};\\\", \\\"{x:1070,y:938,t:1527189596933};\\\", \\\"{x:1070,y:939,t:1527189596949};\\\", \\\"{x:1071,y:937,t:1527189597097};\\\", \\\"{x:1072,y:936,t:1527189597105};\\\", \\\"{x:1073,y:933,t:1527189597116};\\\", \\\"{x:1075,y:932,t:1527189597133};\\\", \\\"{x:1076,y:930,t:1527189597153};\\\", \\\"{x:1077,y:929,t:1527189597167};\\\", \\\"{x:1077,y:928,t:1527189597183};\\\", \\\"{x:1077,y:927,t:1527189597274};\\\", \\\"{x:1078,y:926,t:1527189597721};\\\", \\\"{x:1078,y:925,t:1527189597734};\\\", \\\"{x:1078,y:923,t:1527189597751};\\\", \\\"{x:1079,y:920,t:1527189597768};\\\", \\\"{x:1081,y:919,t:1527189597785};\\\", \\\"{x:1082,y:918,t:1527189597803};\\\", \\\"{x:1082,y:917,t:1527189597824};\\\", \\\"{x:1083,y:917,t:1527189597834};\\\", \\\"{x:1084,y:916,t:1527189597850};\\\", \\\"{x:1085,y:916,t:1527189597867};\\\", \\\"{x:1085,y:915,t:1527189597884};\\\", \\\"{x:1087,y:915,t:1527189597900};\\\", \\\"{x:1087,y:914,t:1527189597918};\\\", \\\"{x:1087,y:913,t:1527189597934};\\\", \\\"{x:1087,y:911,t:1527189597952};\\\", \\\"{x:1089,y:910,t:1527189597967};\\\", \\\"{x:1090,y:908,t:1527189597984};\\\", \\\"{x:1091,y:908,t:1527189598001};\\\", \\\"{x:1093,y:908,t:1527189598017};\\\", \\\"{x:1096,y:907,t:1527189598034};\\\", \\\"{x:1097,y:907,t:1527189598057};\\\", \\\"{x:1104,y:907,t:1527189598068};\\\", \\\"{x:1108,y:908,t:1527189598085};\\\", \\\"{x:1112,y:910,t:1527189598102};\\\", \\\"{x:1119,y:911,t:1527189598118};\\\", \\\"{x:1129,y:913,t:1527189598134};\\\", \\\"{x:1136,y:917,t:1527189598151};\\\", \\\"{x:1151,y:919,t:1527189598169};\\\", \\\"{x:1157,y:920,t:1527189598185};\\\", \\\"{x:1163,y:920,t:1527189598202};\\\", \\\"{x:1167,y:922,t:1527189598218};\\\", \\\"{x:1175,y:924,t:1527189598235};\\\", \\\"{x:1184,y:924,t:1527189598252};\\\", \\\"{x:1200,y:926,t:1527189598269};\\\", \\\"{x:1203,y:926,t:1527189598286};\\\", \\\"{x:1213,y:928,t:1527189598302};\\\", \\\"{x:1226,y:930,t:1527189598319};\\\", \\\"{x:1228,y:930,t:1527189598336};\\\", \\\"{x:1235,y:931,t:1527189598352};\\\", \\\"{x:1245,y:934,t:1527189598369};\\\", \\\"{x:1255,y:938,t:1527189598385};\\\", \\\"{x:1261,y:939,t:1527189598402};\\\", \\\"{x:1265,y:940,t:1527189598419};\\\", \\\"{x:1265,y:941,t:1527189598436};\\\", \\\"{x:1267,y:942,t:1527189598453};\\\", \\\"{x:1271,y:942,t:1527189598469};\\\", \\\"{x:1273,y:942,t:1527189598486};\\\", \\\"{x:1277,y:945,t:1527189598503};\\\", \\\"{x:1279,y:945,t:1527189598519};\\\", \\\"{x:1280,y:945,t:1527189598537};\\\", \\\"{x:1281,y:944,t:1527189598666};\\\", \\\"{x:1282,y:938,t:1527189598674};\\\", \\\"{x:1283,y:934,t:1527189598686};\\\", \\\"{x:1283,y:924,t:1527189598703};\\\", \\\"{x:1285,y:914,t:1527189598719};\\\", \\\"{x:1287,y:906,t:1527189598736};\\\", \\\"{x:1287,y:897,t:1527189598752};\\\", \\\"{x:1287,y:884,t:1527189598769};\\\", \\\"{x:1287,y:869,t:1527189598786};\\\", \\\"{x:1287,y:859,t:1527189598803};\\\", \\\"{x:1287,y:852,t:1527189598819};\\\", \\\"{x:1286,y:849,t:1527189598837};\\\", \\\"{x:1286,y:848,t:1527189598853};\\\", \\\"{x:1285,y:845,t:1527189598870};\\\", \\\"{x:1285,y:839,t:1527189598887};\\\", \\\"{x:1285,y:836,t:1527189598903};\\\", \\\"{x:1285,y:828,t:1527189598920};\\\", \\\"{x:1285,y:823,t:1527189598938};\\\", \\\"{x:1284,y:821,t:1527189599297};\\\", \\\"{x:1284,y:819,t:1527189599313};\\\", \\\"{x:1282,y:817,t:1527189599329};\\\", \\\"{x:1282,y:815,t:1527189599345};\\\", \\\"{x:1282,y:814,t:1527189599354};\\\", \\\"{x:1280,y:808,t:1527189599372};\\\", \\\"{x:1279,y:801,t:1527189599388};\\\", \\\"{x:1277,y:796,t:1527189599405};\\\", \\\"{x:1274,y:791,t:1527189599421};\\\", \\\"{x:1273,y:783,t:1527189599438};\\\", \\\"{x:1272,y:776,t:1527189599456};\\\", \\\"{x:1269,y:765,t:1527189599471};\\\", \\\"{x:1267,y:760,t:1527189599489};\\\", \\\"{x:1264,y:748,t:1527189599505};\\\", \\\"{x:1264,y:740,t:1527189599521};\\\", \\\"{x:1261,y:734,t:1527189599538};\\\", \\\"{x:1259,y:728,t:1527189599555};\\\", \\\"{x:1257,y:724,t:1527189599573};\\\", \\\"{x:1256,y:716,t:1527189599588};\\\", \\\"{x:1256,y:708,t:1527189599605};\\\", \\\"{x:1256,y:699,t:1527189599622};\\\", \\\"{x:1256,y:692,t:1527189599638};\\\", \\\"{x:1256,y:681,t:1527189599655};\\\", \\\"{x:1255,y:668,t:1527189599674};\\\", \\\"{x:1255,y:664,t:1527189599688};\\\", \\\"{x:1252,y:651,t:1527189599704};\\\", \\\"{x:1252,y:645,t:1527189599722};\\\", \\\"{x:1252,y:639,t:1527189599739};\\\", \\\"{x:1252,y:631,t:1527189599755};\\\", \\\"{x:1252,y:623,t:1527189599771};\\\", \\\"{x:1253,y:612,t:1527189599792};\\\", \\\"{x:1256,y:600,t:1527189599808};\\\", \\\"{x:1257,y:588,t:1527189599826};\\\", \\\"{x:1259,y:574,t:1527189599842};\\\", \\\"{x:1259,y:568,t:1527189599859};\\\", \\\"{x:1262,y:558,t:1527189599877};\\\", \\\"{x:1262,y:554,t:1527189599892};\\\", \\\"{x:1263,y:543,t:1527189599908};\\\", \\\"{x:1264,y:536,t:1527189599925};\\\", \\\"{x:1265,y:532,t:1527189599942};\\\", \\\"{x:1266,y:531,t:1527189599959};\\\", \\\"{x:1266,y:532,t:1527189600140};\\\", \\\"{x:1266,y:537,t:1527189600148};\\\", \\\"{x:1266,y:542,t:1527189600159};\\\", \\\"{x:1266,y:546,t:1527189600176};\\\", \\\"{x:1267,y:551,t:1527189600194};\\\", \\\"{x:1267,y:554,t:1527189600212};\\\", \\\"{x:1267,y:557,t:1527189600226};\\\", \\\"{x:1269,y:559,t:1527189600243};\\\", \\\"{x:1269,y:560,t:1527189600258};\\\", \\\"{x:1269,y:564,t:1527189600275};\\\", \\\"{x:1269,y:566,t:1527189600292};\\\", \\\"{x:1269,y:567,t:1527189600331};\\\", \\\"{x:1270,y:566,t:1527189600596};\\\", \\\"{x:1271,y:565,t:1527189600612};\\\", \\\"{x:1271,y:564,t:1527189600629};\\\", \\\"{x:1272,y:564,t:1527189600709};\\\", \\\"{x:1274,y:563,t:1527189600732};\\\", \\\"{x:1277,y:563,t:1527189600744};\\\", \\\"{x:1284,y:562,t:1527189600760};\\\", \\\"{x:1290,y:562,t:1527189600777};\\\", \\\"{x:1296,y:562,t:1527189600794};\\\", \\\"{x:1303,y:561,t:1527189600811};\\\", \\\"{x:1308,y:559,t:1527189600827};\\\", \\\"{x:1321,y:558,t:1527189600844};\\\", \\\"{x:1327,y:561,t:1527189600861};\\\", \\\"{x:1338,y:561,t:1527189600877};\\\", \\\"{x:1344,y:561,t:1527189600895};\\\", \\\"{x:1350,y:561,t:1527189600911};\\\", \\\"{x:1356,y:561,t:1527189600928};\\\", \\\"{x:1365,y:561,t:1527189600945};\\\", \\\"{x:1370,y:561,t:1527189600962};\\\", \\\"{x:1377,y:561,t:1527189600977};\\\", \\\"{x:1387,y:561,t:1527189600994};\\\", \\\"{x:1398,y:561,t:1527189601011};\\\", \\\"{x:1410,y:561,t:1527189601029};\\\", \\\"{x:1421,y:561,t:1527189601045};\\\", \\\"{x:1428,y:561,t:1527189601062};\\\", \\\"{x:1437,y:561,t:1527189601079};\\\", \\\"{x:1445,y:561,t:1527189601094};\\\", \\\"{x:1453,y:559,t:1527189601112};\\\", \\\"{x:1462,y:558,t:1527189601128};\\\", \\\"{x:1470,y:558,t:1527189601144};\\\", \\\"{x:1480,y:558,t:1527189601161};\\\", \\\"{x:1487,y:558,t:1527189601178};\\\", \\\"{x:1494,y:558,t:1527189601195};\\\", \\\"{x:1500,y:557,t:1527189601211};\\\", \\\"{x:1508,y:555,t:1527189601228};\\\", \\\"{x:1512,y:554,t:1527189601245};\\\", \\\"{x:1517,y:553,t:1527189601261};\\\", \\\"{x:1525,y:550,t:1527189601278};\\\", \\\"{x:1532,y:550,t:1527189601295};\\\", \\\"{x:1543,y:550,t:1527189601312};\\\", \\\"{x:1555,y:550,t:1527189601328};\\\", \\\"{x:1570,y:550,t:1527189601345};\\\", \\\"{x:1580,y:550,t:1527189601362};\\\", \\\"{x:1591,y:550,t:1527189601378};\\\", \\\"{x:1595,y:550,t:1527189601395};\\\", \\\"{x:1602,y:550,t:1527189601412};\\\", \\\"{x:1609,y:550,t:1527189601428};\\\", \\\"{x:1611,y:550,t:1527189601446};\\\", \\\"{x:1618,y:552,t:1527189601462};\\\", \\\"{x:1627,y:554,t:1527189601478};\\\", \\\"{x:1629,y:554,t:1527189601495};\\\", \\\"{x:1630,y:555,t:1527189601512};\\\", \\\"{x:1631,y:555,t:1527189601528};\\\", \\\"{x:1632,y:555,t:1527189601676};\\\", \\\"{x:1631,y:558,t:1527189602629};\\\", \\\"{x:1628,y:563,t:1527189602636};\\\", \\\"{x:1622,y:567,t:1527189602648};\\\", \\\"{x:1605,y:578,t:1527189602664};\\\", \\\"{x:1593,y:586,t:1527189602681};\\\", \\\"{x:1568,y:603,t:1527189602699};\\\", \\\"{x:1540,y:626,t:1527189602715};\\\", \\\"{x:1508,y:658,t:1527189602731};\\\", \\\"{x:1475,y:703,t:1527189602748};\\\", \\\"{x:1458,y:737,t:1527189602764};\\\", \\\"{x:1437,y:765,t:1527189602781};\\\", \\\"{x:1421,y:786,t:1527189602798};\\\", \\\"{x:1406,y:807,t:1527189602815};\\\", \\\"{x:1391,y:833,t:1527189602832};\\\", \\\"{x:1382,y:854,t:1527189602848};\\\", \\\"{x:1378,y:875,t:1527189602866};\\\", \\\"{x:1371,y:895,t:1527189602881};\\\", \\\"{x:1362,y:915,t:1527189602898};\\\", \\\"{x:1358,y:928,t:1527189602915};\\\", \\\"{x:1355,y:940,t:1527189602932};\\\", \\\"{x:1353,y:946,t:1527189602948};\\\", \\\"{x:1349,y:951,t:1527189602965};\\\", \\\"{x:1344,y:961,t:1527189602982};\\\", \\\"{x:1338,y:975,t:1527189602998};\\\", \\\"{x:1329,y:989,t:1527189603016};\\\", \\\"{x:1321,y:996,t:1527189603032};\\\", \\\"{x:1314,y:999,t:1527189603048};\\\", \\\"{x:1302,y:1003,t:1527189603065};\\\", \\\"{x:1298,y:1003,t:1527189603082};\\\", \\\"{x:1287,y:1003,t:1527189603100};\\\", \\\"{x:1282,y:1003,t:1527189603115};\\\", \\\"{x:1273,y:1001,t:1527189603132};\\\", \\\"{x:1271,y:1000,t:1527189603149};\\\", \\\"{x:1268,y:998,t:1527189603165};\\\", \\\"{x:1268,y:992,t:1527189603183};\\\", \\\"{x:1268,y:983,t:1527189603199};\\\", \\\"{x:1270,y:971,t:1527189603215};\\\", \\\"{x:1274,y:965,t:1527189603233};\\\", \\\"{x:1280,y:956,t:1527189603250};\\\", \\\"{x:1286,y:946,t:1527189603266};\\\", \\\"{x:1289,y:941,t:1527189603282};\\\", \\\"{x:1293,y:935,t:1527189603300};\\\", \\\"{x:1300,y:925,t:1527189603316};\\\", \\\"{x:1302,y:921,t:1527189603332};\\\", \\\"{x:1305,y:916,t:1527189603348};\\\", \\\"{x:1308,y:909,t:1527189603366};\\\", \\\"{x:1312,y:898,t:1527189603382};\\\", \\\"{x:1316,y:888,t:1527189603399};\\\", \\\"{x:1316,y:877,t:1527189603415};\\\", \\\"{x:1316,y:870,t:1527189603432};\\\", \\\"{x:1317,y:867,t:1527189603448};\\\", \\\"{x:1317,y:864,t:1527189603465};\\\", \\\"{x:1316,y:859,t:1527189603483};\\\", \\\"{x:1314,y:853,t:1527189603499};\\\", \\\"{x:1314,y:845,t:1527189603515};\\\", \\\"{x:1308,y:837,t:1527189603534};\\\", \\\"{x:1305,y:834,t:1527189603549};\\\", \\\"{x:1304,y:832,t:1527189603566};\\\", \\\"{x:1301,y:828,t:1527189603582};\\\", \\\"{x:1297,y:824,t:1527189603600};\\\", \\\"{x:1295,y:820,t:1527189603616};\\\", \\\"{x:1292,y:813,t:1527189603633};\\\", \\\"{x:1290,y:810,t:1527189603650};\\\", \\\"{x:1290,y:808,t:1527189603667};\\\", \\\"{x:1290,y:807,t:1527189603732};\\\", \\\"{x:1290,y:806,t:1527189603750};\\\", \\\"{x:1290,y:803,t:1527189603767};\\\", \\\"{x:1290,y:801,t:1527189603784};\\\", \\\"{x:1290,y:800,t:1527189603801};\\\", \\\"{x:1290,y:799,t:1527189603900};\\\", \\\"{x:1288,y:804,t:1527189603917};\\\", \\\"{x:1287,y:813,t:1527189603934};\\\", \\\"{x:1283,y:821,t:1527189603951};\\\", \\\"{x:1281,y:828,t:1527189603967};\\\", \\\"{x:1281,y:833,t:1527189603983};\\\", \\\"{x:1281,y:831,t:1527189604091};\\\", \\\"{x:1281,y:824,t:1527189604101};\\\", \\\"{x:1284,y:811,t:1527189604117};\\\", \\\"{x:1288,y:799,t:1527189604134};\\\", \\\"{x:1290,y:785,t:1527189604151};\\\", \\\"{x:1293,y:776,t:1527189604166};\\\", \\\"{x:1295,y:765,t:1527189604184};\\\", \\\"{x:1300,y:756,t:1527189604201};\\\", \\\"{x:1303,y:742,t:1527189604218};\\\", \\\"{x:1305,y:727,t:1527189604234};\\\", \\\"{x:1305,y:715,t:1527189604251};\\\", \\\"{x:1305,y:699,t:1527189604268};\\\", \\\"{x:1303,y:693,t:1527189604284};\\\", \\\"{x:1303,y:687,t:1527189604301};\\\", \\\"{x:1303,y:684,t:1527189604319};\\\", \\\"{x:1301,y:677,t:1527189604335};\\\", \\\"{x:1298,y:664,t:1527189604351};\\\", \\\"{x:1297,y:650,t:1527189604368};\\\", \\\"{x:1296,y:648,t:1527189604385};\\\", \\\"{x:1291,y:633,t:1527189604401};\\\", \\\"{x:1289,y:625,t:1527189604418};\\\", \\\"{x:1287,y:617,t:1527189604435};\\\", \\\"{x:1285,y:613,t:1527189604452};\\\", \\\"{x:1282,y:604,t:1527189604468};\\\", \\\"{x:1280,y:597,t:1527189604485};\\\", \\\"{x:1279,y:594,t:1527189604500};\\\", \\\"{x:1275,y:588,t:1527189604517};\\\", \\\"{x:1270,y:578,t:1527189604534};\\\", \\\"{x:1268,y:575,t:1527189604551};\\\", \\\"{x:1267,y:571,t:1527189604568};\\\", \\\"{x:1267,y:569,t:1527189604585};\\\", \\\"{x:1267,y:568,t:1527189604602};\\\", \\\"{x:1267,y:567,t:1527189604618};\\\", \\\"{x:1267,y:565,t:1527189604635};\\\", \\\"{x:1267,y:564,t:1527189604652};\\\", \\\"{x:1267,y:563,t:1527189604668};\\\", \\\"{x:1267,y:562,t:1527189604685};\\\", \\\"{x:1267,y:560,t:1527189604702};\\\", \\\"{x:1267,y:559,t:1527189604719};\\\", \\\"{x:1268,y:558,t:1527189604748};\\\", \\\"{x:1269,y:557,t:1527189604764};\\\", \\\"{x:1269,y:556,t:1527189604772};\\\", \\\"{x:1270,y:556,t:1527189604785};\\\", \\\"{x:1270,y:555,t:1527189604802};\\\", \\\"{x:1271,y:555,t:1527189604819};\\\", \\\"{x:1273,y:555,t:1527189604836};\\\", \\\"{x:1274,y:554,t:1527189604853};\\\", \\\"{x:1277,y:554,t:1527189604877};\\\", \\\"{x:1279,y:554,t:1527189604886};\\\", \\\"{x:1284,y:554,t:1527189604902};\\\", \\\"{x:1293,y:556,t:1527189604919};\\\", \\\"{x:1301,y:558,t:1527189604936};\\\", \\\"{x:1316,y:563,t:1527189604952};\\\", \\\"{x:1335,y:567,t:1527189604970};\\\", \\\"{x:1356,y:572,t:1527189604986};\\\", \\\"{x:1376,y:575,t:1527189605002};\\\", \\\"{x:1395,y:577,t:1527189605019};\\\", \\\"{x:1413,y:582,t:1527189605036};\\\", \\\"{x:1432,y:582,t:1527189605054};\\\", \\\"{x:1443,y:582,t:1527189605069};\\\", \\\"{x:1458,y:583,t:1527189605087};\\\", \\\"{x:1466,y:583,t:1527189605103};\\\", \\\"{x:1471,y:583,t:1527189605120};\\\", \\\"{x:1477,y:582,t:1527189605137};\\\", \\\"{x:1482,y:580,t:1527189605154};\\\", \\\"{x:1488,y:577,t:1527189605170};\\\", \\\"{x:1493,y:576,t:1527189605186};\\\", \\\"{x:1498,y:574,t:1527189605203};\\\", \\\"{x:1506,y:570,t:1527189605220};\\\", \\\"{x:1510,y:569,t:1527189605236};\\\", \\\"{x:1520,y:563,t:1527189605254};\\\", \\\"{x:1534,y:558,t:1527189605271};\\\", \\\"{x:1548,y:555,t:1527189605286};\\\", \\\"{x:1555,y:553,t:1527189605303};\\\", \\\"{x:1571,y:545,t:1527189605321};\\\", \\\"{x:1590,y:537,t:1527189605337};\\\", \\\"{x:1606,y:537,t:1527189605353};\\\", \\\"{x:1616,y:537,t:1527189605370};\\\", \\\"{x:1625,y:537,t:1527189605387};\\\", \\\"{x:1633,y:537,t:1527189605404};\\\", \\\"{x:1641,y:538,t:1527189605419};\\\", \\\"{x:1645,y:539,t:1527189605438};\\\", \\\"{x:1647,y:541,t:1527189605453};\\\", \\\"{x:1651,y:543,t:1527189605470};\\\", \\\"{x:1653,y:544,t:1527189605488};\\\", \\\"{x:1654,y:546,t:1527189605503};\\\", \\\"{x:1654,y:547,t:1527189605521};\\\", \\\"{x:1655,y:548,t:1527189605538};\\\", \\\"{x:1655,y:549,t:1527189605554};\\\", \\\"{x:1655,y:552,t:1527189605570};\\\", \\\"{x:1655,y:553,t:1527189605588};\\\", \\\"{x:1655,y:557,t:1527189605604};\\\", \\\"{x:1654,y:560,t:1527189605621};\\\", \\\"{x:1653,y:562,t:1527189605638};\\\", \\\"{x:1651,y:567,t:1527189605654};\\\", \\\"{x:1647,y:571,t:1527189605671};\\\", \\\"{x:1642,y:581,t:1527189605688};\\\", \\\"{x:1640,y:585,t:1527189605704};\\\", \\\"{x:1637,y:591,t:1527189605721};\\\", \\\"{x:1636,y:597,t:1527189605738};\\\", \\\"{x:1633,y:603,t:1527189605755};\\\", \\\"{x:1630,y:613,t:1527189605771};\\\", \\\"{x:1628,y:622,t:1527189605787};\\\", \\\"{x:1627,y:637,t:1527189605804};\\\", \\\"{x:1623,y:651,t:1527189605822};\\\", \\\"{x:1623,y:658,t:1527189605838};\\\", \\\"{x:1623,y:666,t:1527189605854};\\\", \\\"{x:1623,y:674,t:1527189605871};\\\", \\\"{x:1623,y:683,t:1527189605888};\\\", \\\"{x:1623,y:694,t:1527189605904};\\\", \\\"{x:1623,y:710,t:1527189605921};\\\", \\\"{x:1624,y:720,t:1527189605938};\\\", \\\"{x:1625,y:735,t:1527189605954};\\\", \\\"{x:1627,y:748,t:1527189605970};\\\", \\\"{x:1632,y:773,t:1527189605987};\\\", \\\"{x:1636,y:790,t:1527189606004};\\\", \\\"{x:1637,y:803,t:1527189606021};\\\", \\\"{x:1637,y:814,t:1527189606038};\\\", \\\"{x:1640,y:831,t:1527189606055};\\\", \\\"{x:1642,y:852,t:1527189606071};\\\", \\\"{x:1645,y:870,t:1527189606088};\\\", \\\"{x:1647,y:892,t:1527189606105};\\\", \\\"{x:1651,y:901,t:1527189606120};\\\", \\\"{x:1652,y:913,t:1527189606138};\\\", \\\"{x:1655,y:926,t:1527189606155};\\\", \\\"{x:1655,y:935,t:1527189606171};\\\", \\\"{x:1656,y:939,t:1527189606188};\\\", \\\"{x:1656,y:943,t:1527189606205};\\\", \\\"{x:1656,y:944,t:1527189606236};\\\", \\\"{x:1657,y:946,t:1527189606244};\\\", \\\"{x:1657,y:949,t:1527189606276};\\\", \\\"{x:1657,y:952,t:1527189606288};\\\", \\\"{x:1657,y:960,t:1527189606305};\\\", \\\"{x:1657,y:965,t:1527189606323};\\\", \\\"{x:1657,y:966,t:1527189606356};\\\", \\\"{x:1657,y:967,t:1527189606388};\\\", \\\"{x:1657,y:968,t:1527189606406};\\\", \\\"{x:1657,y:969,t:1527189606422};\\\", \\\"{x:1657,y:971,t:1527189606439};\\\", \\\"{x:1657,y:972,t:1527189606556};\\\", \\\"{x:1657,y:973,t:1527189606573};\\\", \\\"{x:1657,y:975,t:1527189606589};\\\", \\\"{x:1657,y:977,t:1527189606612};\\\", \\\"{x:1658,y:976,t:1527189610428};\\\", \\\"{x:1659,y:975,t:1527189610452};\\\", \\\"{x:1659,y:974,t:1527189610468};\\\", \\\"{x:1660,y:973,t:1527189610484};\\\", \\\"{x:1660,y:972,t:1527189610517};\\\", \\\"{x:1661,y:972,t:1527189610532};\\\", \\\"{x:1659,y:972,t:1527189611333};\\\", \\\"{x:1632,y:973,t:1527189611350};\\\", \\\"{x:1613,y:982,t:1527189611367};\\\", \\\"{x:1587,y:988,t:1527189611382};\\\", \\\"{x:1568,y:991,t:1527189611399};\\\", \\\"{x:1545,y:995,t:1527189611417};\\\", \\\"{x:1529,y:1000,t:1527189611433};\\\", \\\"{x:1513,y:1000,t:1527189611449};\\\", \\\"{x:1498,y:1000,t:1527189611467};\\\", \\\"{x:1481,y:1000,t:1527189611484};\\\", \\\"{x:1473,y:1000,t:1527189611500};\\\", \\\"{x:1467,y:1000,t:1527189611516};\\\", \\\"{x:1463,y:1000,t:1527189611534};\\\", \\\"{x:1461,y:1000,t:1527189611550};\\\", \\\"{x:1459,y:999,t:1527189611566};\\\", \\\"{x:1456,y:998,t:1527189611583};\\\", \\\"{x:1449,y:998,t:1527189611599};\\\", \\\"{x:1444,y:998,t:1527189611617};\\\", \\\"{x:1441,y:998,t:1527189611633};\\\", \\\"{x:1438,y:998,t:1527189611651};\\\", \\\"{x:1436,y:998,t:1527189611666};\\\", \\\"{x:1434,y:998,t:1527189611684};\\\", \\\"{x:1428,y:998,t:1527189611700};\\\", \\\"{x:1423,y:998,t:1527189611717};\\\", \\\"{x:1414,y:995,t:1527189611733};\\\", \\\"{x:1407,y:995,t:1527189611751};\\\", \\\"{x:1396,y:993,t:1527189611768};\\\", \\\"{x:1384,y:991,t:1527189611783};\\\", \\\"{x:1373,y:989,t:1527189611800};\\\", \\\"{x:1359,y:988,t:1527189611817};\\\", \\\"{x:1343,y:985,t:1527189611833};\\\", \\\"{x:1335,y:984,t:1527189611850};\\\", \\\"{x:1327,y:983,t:1527189611868};\\\", \\\"{x:1325,y:983,t:1527189611884};\\\", \\\"{x:1324,y:983,t:1527189611916};\\\", \\\"{x:1319,y:983,t:1527189611924};\\\", \\\"{x:1317,y:983,t:1527189611935};\\\", \\\"{x:1314,y:982,t:1527189611951};\\\", \\\"{x:1306,y:980,t:1527189611967};\\\", \\\"{x:1304,y:979,t:1527189611985};\\\", \\\"{x:1300,y:979,t:1527189612001};\\\", \\\"{x:1299,y:979,t:1527189612018};\\\", \\\"{x:1298,y:979,t:1527189612036};\\\", \\\"{x:1298,y:978,t:1527189612050};\\\", \\\"{x:1297,y:978,t:1527189612221};\\\", \\\"{x:1296,y:978,t:1527189612244};\\\", \\\"{x:1294,y:978,t:1527189612372};\\\", \\\"{x:1293,y:978,t:1527189612404};\\\", \\\"{x:1292,y:977,t:1527189612418};\\\", \\\"{x:1291,y:977,t:1527189612436};\\\", \\\"{x:1290,y:977,t:1527189612451};\\\", \\\"{x:1289,y:976,t:1527189612469};\\\", \\\"{x:1287,y:975,t:1527189612485};\\\", \\\"{x:1284,y:973,t:1527189612501};\\\", \\\"{x:1280,y:970,t:1527189612518};\\\", \\\"{x:1277,y:968,t:1527189612536};\\\", \\\"{x:1276,y:968,t:1527189612552};\\\", \\\"{x:1276,y:967,t:1527189612569};\\\", \\\"{x:1275,y:966,t:1527189612588};\\\", \\\"{x:1274,y:965,t:1527189612612};\\\", \\\"{x:1275,y:965,t:1527189615189};\\\", \\\"{x:1275,y:964,t:1527189615196};\\\", \\\"{x:1275,y:962,t:1527189615208};\\\", \\\"{x:1276,y:962,t:1527189615224};\\\", \\\"{x:1277,y:957,t:1527189615240};\\\", \\\"{x:1277,y:952,t:1527189615257};\\\", \\\"{x:1277,y:948,t:1527189615274};\\\", \\\"{x:1278,y:945,t:1527189615290};\\\", \\\"{x:1280,y:939,t:1527189615307};\\\", \\\"{x:1281,y:936,t:1527189615324};\\\", \\\"{x:1281,y:934,t:1527189615355};\\\", \\\"{x:1282,y:933,t:1527189615363};\\\", \\\"{x:1283,y:933,t:1527189615387};\\\", \\\"{x:1284,y:931,t:1527189615396};\\\", \\\"{x:1285,y:930,t:1527189615411};\\\", \\\"{x:1286,y:927,t:1527189615424};\\\", \\\"{x:1288,y:926,t:1527189615441};\\\", \\\"{x:1288,y:923,t:1527189615458};\\\", \\\"{x:1292,y:912,t:1527189615475};\\\", \\\"{x:1294,y:904,t:1527189615491};\\\", \\\"{x:1296,y:899,t:1527189615508};\\\", \\\"{x:1297,y:891,t:1527189615525};\\\", \\\"{x:1298,y:885,t:1527189615541};\\\", \\\"{x:1299,y:881,t:1527189615559};\\\", \\\"{x:1299,y:878,t:1527189615574};\\\", \\\"{x:1299,y:875,t:1527189615591};\\\", \\\"{x:1299,y:873,t:1527189615620};\\\", \\\"{x:1299,y:872,t:1527189615749};\\\", \\\"{x:1300,y:869,t:1527189615759};\\\", \\\"{x:1302,y:864,t:1527189615776};\\\", \\\"{x:1302,y:851,t:1527189615792};\\\", \\\"{x:1302,y:844,t:1527189615809};\\\", \\\"{x:1302,y:840,t:1527189615826};\\\", \\\"{x:1302,y:835,t:1527189615842};\\\", \\\"{x:1302,y:828,t:1527189615859};\\\", \\\"{x:1301,y:824,t:1527189615875};\\\", \\\"{x:1301,y:823,t:1527189615893};\\\", \\\"{x:1300,y:823,t:1527189616052};\\\", \\\"{x:1299,y:823,t:1527189616060};\\\", \\\"{x:1296,y:825,t:1527189616075};\\\", \\\"{x:1294,y:827,t:1527189616092};\\\", \\\"{x:1292,y:831,t:1527189616109};\\\", \\\"{x:1291,y:835,t:1527189616126};\\\", \\\"{x:1291,y:836,t:1527189616155};\\\", \\\"{x:1290,y:837,t:1527189616163};\\\", \\\"{x:1290,y:838,t:1527189616211};\\\", \\\"{x:1290,y:839,t:1527189616243};\\\", \\\"{x:1290,y:841,t:1527189616259};\\\", \\\"{x:1290,y:843,t:1527189616299};\\\", \\\"{x:1290,y:844,t:1527189616324};\\\", \\\"{x:1290,y:845,t:1527189616365};\\\", \\\"{x:1290,y:846,t:1527189616377};\\\", \\\"{x:1291,y:849,t:1527189616394};\\\", \\\"{x:1292,y:850,t:1527189616410};\\\", \\\"{x:1292,y:851,t:1527189616436};\\\", \\\"{x:1292,y:852,t:1527189616452};\\\", \\\"{x:1292,y:853,t:1527189616460};\\\", \\\"{x:1293,y:854,t:1527189616477};\\\", \\\"{x:1294,y:857,t:1527189616495};\\\", \\\"{x:1294,y:858,t:1527189616511};\\\", \\\"{x:1294,y:860,t:1527189616527};\\\", \\\"{x:1295,y:862,t:1527189616544};\\\", \\\"{x:1295,y:863,t:1527189616561};\\\", \\\"{x:1295,y:866,t:1527189616576};\\\", \\\"{x:1296,y:867,t:1527189616594};\\\", \\\"{x:1296,y:870,t:1527189616611};\\\", \\\"{x:1296,y:873,t:1527189616627};\\\", \\\"{x:1298,y:880,t:1527189616644};\\\", \\\"{x:1299,y:884,t:1527189616661};\\\", \\\"{x:1299,y:889,t:1527189616678};\\\", \\\"{x:1300,y:895,t:1527189616694};\\\", \\\"{x:1300,y:899,t:1527189616711};\\\", \\\"{x:1301,y:905,t:1527189616728};\\\", \\\"{x:1303,y:910,t:1527189616745};\\\", \\\"{x:1303,y:915,t:1527189616761};\\\", \\\"{x:1303,y:920,t:1527189616778};\\\", \\\"{x:1303,y:925,t:1527189616795};\\\", \\\"{x:1303,y:928,t:1527189616811};\\\", \\\"{x:1303,y:930,t:1527189616828};\\\", \\\"{x:1303,y:932,t:1527189616852};\\\", \\\"{x:1303,y:933,t:1527189616861};\\\", \\\"{x:1303,y:935,t:1527189616877};\\\", \\\"{x:1303,y:937,t:1527189616895};\\\", \\\"{x:1303,y:940,t:1527189616912};\\\", \\\"{x:1303,y:944,t:1527189616928};\\\", \\\"{x:1303,y:949,t:1527189616945};\\\", \\\"{x:1301,y:952,t:1527189616962};\\\", \\\"{x:1301,y:954,t:1527189616978};\\\", \\\"{x:1301,y:956,t:1527189617028};\\\", \\\"{x:1300,y:958,t:1527189617084};\\\", \\\"{x:1299,y:959,t:1527189617095};\\\", \\\"{x:1299,y:960,t:1527189617116};\\\", \\\"{x:1299,y:957,t:1527189617564};\\\", \\\"{x:1299,y:941,t:1527189617580};\\\", \\\"{x:1299,y:937,t:1527189617596};\\\", \\\"{x:1299,y:929,t:1527189617613};\\\", \\\"{x:1299,y:919,t:1527189617630};\\\", \\\"{x:1300,y:913,t:1527189617646};\\\", \\\"{x:1301,y:906,t:1527189617663};\\\", \\\"{x:1301,y:901,t:1527189617680};\\\", \\\"{x:1303,y:897,t:1527189617695};\\\", \\\"{x:1303,y:893,t:1527189617713};\\\", \\\"{x:1303,y:889,t:1527189617730};\\\", \\\"{x:1304,y:885,t:1527189617747};\\\", \\\"{x:1304,y:880,t:1527189617763};\\\", \\\"{x:1305,y:876,t:1527189617780};\\\", \\\"{x:1305,y:874,t:1527189617797};\\\", \\\"{x:1306,y:869,t:1527189617813};\\\", \\\"{x:1306,y:862,t:1527189617830};\\\", \\\"{x:1306,y:858,t:1527189617847};\\\", \\\"{x:1306,y:853,t:1527189617863};\\\", \\\"{x:1306,y:847,t:1527189617879};\\\", \\\"{x:1306,y:842,t:1527189617897};\\\", \\\"{x:1306,y:835,t:1527189617914};\\\", \\\"{x:1306,y:829,t:1527189617929};\\\", \\\"{x:1304,y:815,t:1527189617947};\\\", \\\"{x:1302,y:802,t:1527189617964};\\\", \\\"{x:1302,y:797,t:1527189617980};\\\", \\\"{x:1301,y:789,t:1527189617997};\\\", \\\"{x:1300,y:782,t:1527189618014};\\\", \\\"{x:1298,y:775,t:1527189618031};\\\", \\\"{x:1297,y:761,t:1527189618047};\\\", \\\"{x:1296,y:747,t:1527189618064};\\\", \\\"{x:1292,y:737,t:1527189618080};\\\", \\\"{x:1291,y:726,t:1527189618097};\\\", \\\"{x:1286,y:717,t:1527189618114};\\\", \\\"{x:1282,y:708,t:1527189618131};\\\", \\\"{x:1278,y:700,t:1527189618147};\\\", \\\"{x:1274,y:691,t:1527189618164};\\\", \\\"{x:1273,y:685,t:1527189618181};\\\", \\\"{x:1272,y:678,t:1527189618197};\\\", \\\"{x:1269,y:669,t:1527189618214};\\\", \\\"{x:1268,y:661,t:1527189618231};\\\", \\\"{x:1263,y:650,t:1527189618248};\\\", \\\"{x:1262,y:638,t:1527189618264};\\\", \\\"{x:1259,y:625,t:1527189618281};\\\", \\\"{x:1259,y:619,t:1527189618298};\\\", \\\"{x:1259,y:614,t:1527189618314};\\\", \\\"{x:1258,y:611,t:1527189618331};\\\", \\\"{x:1258,y:609,t:1527189618347};\\\", \\\"{x:1258,y:605,t:1527189618365};\\\", \\\"{x:1258,y:604,t:1527189618381};\\\", \\\"{x:1258,y:602,t:1527189618398};\\\", \\\"{x:1258,y:601,t:1527189618415};\\\", \\\"{x:1258,y:599,t:1527189618431};\\\", \\\"{x:1258,y:598,t:1527189618460};\\\", \\\"{x:1259,y:598,t:1527189618652};\\\", \\\"{x:1259,y:597,t:1527189618665};\\\", \\\"{x:1259,y:594,t:1527189618681};\\\", \\\"{x:1259,y:592,t:1527189618698};\\\", \\\"{x:1259,y:589,t:1527189618714};\\\", \\\"{x:1260,y:584,t:1527189618731};\\\", \\\"{x:1260,y:581,t:1527189618748};\\\", \\\"{x:1263,y:572,t:1527189618764};\\\", \\\"{x:1264,y:569,t:1527189618782};\\\", \\\"{x:1265,y:562,t:1527189618799};\\\", \\\"{x:1265,y:560,t:1527189618814};\\\", \\\"{x:1265,y:559,t:1527189618832};\\\", \\\"{x:1266,y:561,t:1527189619420};\\\", \\\"{x:1266,y:563,t:1527189619443};\\\", \\\"{x:1266,y:566,t:1527189619468};\\\", \\\"{x:1265,y:566,t:1527189619483};\\\", \\\"{x:1264,y:574,t:1527189619500};\\\", \\\"{x:1264,y:579,t:1527189619517};\\\", \\\"{x:1264,y:583,t:1527189619534};\\\", \\\"{x:1264,y:587,t:1527189619549};\\\", \\\"{x:1264,y:592,t:1527189619566};\\\", \\\"{x:1264,y:599,t:1527189619583};\\\", \\\"{x:1263,y:606,t:1527189619599};\\\", \\\"{x:1262,y:616,t:1527189619616};\\\", \\\"{x:1262,y:624,t:1527189619634};\\\", \\\"{x:1262,y:633,t:1527189619650};\\\", \\\"{x:1262,y:642,t:1527189619666};\\\", \\\"{x:1262,y:654,t:1527189619683};\\\", \\\"{x:1262,y:665,t:1527189619700};\\\", \\\"{x:1262,y:671,t:1527189619716};\\\", \\\"{x:1262,y:677,t:1527189619733};\\\", \\\"{x:1262,y:683,t:1527189619750};\\\", \\\"{x:1262,y:686,t:1527189619766};\\\", \\\"{x:1262,y:687,t:1527189619784};\\\", \\\"{x:1262,y:690,t:1527189619800};\\\", \\\"{x:1262,y:693,t:1527189619817};\\\", \\\"{x:1262,y:697,t:1527189619834};\\\", \\\"{x:1262,y:704,t:1527189619850};\\\", \\\"{x:1263,y:716,t:1527189619868};\\\", \\\"{x:1264,y:721,t:1527189619884};\\\", \\\"{x:1264,y:724,t:1527189619901};\\\", \\\"{x:1266,y:727,t:1527189619918};\\\", \\\"{x:1267,y:730,t:1527189619933};\\\", \\\"{x:1268,y:732,t:1527189619950};\\\", \\\"{x:1270,y:737,t:1527189619968};\\\", \\\"{x:1272,y:745,t:1527189619984};\\\", \\\"{x:1274,y:753,t:1527189620001};\\\", \\\"{x:1275,y:759,t:1527189620018};\\\", \\\"{x:1277,y:761,t:1527189620035};\\\", \\\"{x:1279,y:768,t:1527189620051};\\\", \\\"{x:1281,y:777,t:1527189620068};\\\", \\\"{x:1283,y:786,t:1527189620084};\\\", \\\"{x:1285,y:796,t:1527189620101};\\\", \\\"{x:1286,y:801,t:1527189620118};\\\", \\\"{x:1287,y:807,t:1527189620135};\\\", \\\"{x:1288,y:809,t:1527189620152};\\\", \\\"{x:1289,y:814,t:1527189620168};\\\", \\\"{x:1291,y:821,t:1527189620185};\\\", \\\"{x:1293,y:830,t:1527189620203};\\\", \\\"{x:1296,y:837,t:1527189620218};\\\", \\\"{x:1297,y:843,t:1527189620235};\\\", \\\"{x:1297,y:848,t:1527189620252};\\\", \\\"{x:1298,y:850,t:1527189620268};\\\", \\\"{x:1300,y:853,t:1527189620285};\\\", \\\"{x:1300,y:855,t:1527189620302};\\\", \\\"{x:1300,y:860,t:1527189620319};\\\", \\\"{x:1301,y:865,t:1527189620335};\\\", \\\"{x:1302,y:868,t:1527189620352};\\\", \\\"{x:1306,y:871,t:1527189620369};\\\", \\\"{x:1307,y:873,t:1527189620385};\\\", \\\"{x:1308,y:876,t:1527189620403};\\\", \\\"{x:1308,y:877,t:1527189620419};\\\", \\\"{x:1309,y:878,t:1527189620436};\\\", \\\"{x:1309,y:879,t:1527189620467};\\\", \\\"{x:1309,y:880,t:1527189620486};\\\", \\\"{x:1309,y:882,t:1527189620502};\\\", \\\"{x:1309,y:884,t:1527189620519};\\\", \\\"{x:1309,y:888,t:1527189620536};\\\", \\\"{x:1309,y:892,t:1527189620552};\\\", \\\"{x:1309,y:896,t:1527189620570};\\\", \\\"{x:1309,y:902,t:1527189620586};\\\", \\\"{x:1309,y:903,t:1527189620602};\\\", \\\"{x:1308,y:906,t:1527189620618};\\\", \\\"{x:1308,y:909,t:1527189620636};\\\", \\\"{x:1308,y:910,t:1527189620652};\\\", \\\"{x:1307,y:912,t:1527189620669};\\\", \\\"{x:1306,y:916,t:1527189620687};\\\", \\\"{x:1303,y:918,t:1527189620703};\\\", \\\"{x:1298,y:921,t:1527189620719};\\\", \\\"{x:1292,y:925,t:1527189620736};\\\", \\\"{x:1284,y:928,t:1527189620753};\\\", \\\"{x:1271,y:933,t:1527189620769};\\\", \\\"{x:1262,y:935,t:1527189620786};\\\", \\\"{x:1255,y:938,t:1527189620802};\\\", \\\"{x:1249,y:941,t:1527189620820};\\\", \\\"{x:1245,y:942,t:1527189620836};\\\", \\\"{x:1242,y:944,t:1527189620853};\\\", \\\"{x:1238,y:945,t:1527189620870};\\\", \\\"{x:1230,y:948,t:1527189620886};\\\", \\\"{x:1224,y:952,t:1527189620903};\\\", \\\"{x:1216,y:957,t:1527189620920};\\\", \\\"{x:1210,y:961,t:1527189620937};\\\", \\\"{x:1203,y:963,t:1527189620953};\\\", \\\"{x:1195,y:970,t:1527189620970};\\\", \\\"{x:1188,y:975,t:1527189620987};\\\", \\\"{x:1183,y:979,t:1527189621003};\\\", \\\"{x:1174,y:986,t:1527189621020};\\\", \\\"{x:1169,y:990,t:1527189621037};\\\", \\\"{x:1162,y:994,t:1527189621053};\\\", \\\"{x:1156,y:997,t:1527189621070};\\\", \\\"{x:1154,y:999,t:1527189621087};\\\", \\\"{x:1153,y:1000,t:1527189621104};\\\", \\\"{x:1152,y:1001,t:1527189621120};\\\", \\\"{x:1152,y:1002,t:1527189621156};\\\", \\\"{x:1152,y:1004,t:1527189621180};\\\", \\\"{x:1154,y:1006,t:1527189621195};\\\", \\\"{x:1156,y:1007,t:1527189621203};\\\", \\\"{x:1160,y:1008,t:1527189621219};\\\", \\\"{x:1167,y:1011,t:1527189621236};\\\", \\\"{x:1176,y:1013,t:1527189621254};\\\", \\\"{x:1179,y:1016,t:1527189621270};\\\", \\\"{x:1188,y:1020,t:1527189621287};\\\", \\\"{x:1200,y:1026,t:1527189621303};\\\", \\\"{x:1213,y:1029,t:1527189621320};\\\", \\\"{x:1222,y:1030,t:1527189621336};\\\", \\\"{x:1226,y:1030,t:1527189621353};\\\", \\\"{x:1229,y:1030,t:1527189621370};\\\", \\\"{x:1230,y:1030,t:1527189621387};\\\", \\\"{x:1232,y:1030,t:1527189621404};\\\", \\\"{x:1234,y:1029,t:1527189621548};\\\", \\\"{x:1237,y:1025,t:1527189621556};\\\", \\\"{x:1238,y:1023,t:1527189621570};\\\", \\\"{x:1243,y:1013,t:1527189621587};\\\", \\\"{x:1247,y:1004,t:1527189621604};\\\", \\\"{x:1252,y:996,t:1527189621621};\\\", \\\"{x:1256,y:988,t:1527189621638};\\\", \\\"{x:1259,y:984,t:1527189621655};\\\", \\\"{x:1263,y:977,t:1527189621671};\\\", \\\"{x:1265,y:968,t:1527189621688};\\\", \\\"{x:1268,y:960,t:1527189621705};\\\", \\\"{x:1269,y:954,t:1527189621721};\\\", \\\"{x:1269,y:952,t:1527189621738};\\\", \\\"{x:1270,y:950,t:1527189621763};\\\", \\\"{x:1271,y:950,t:1527189621772};\\\", \\\"{x:1271,y:949,t:1527189621788};\\\", \\\"{x:1271,y:948,t:1527189621804};\\\", \\\"{x:1272,y:946,t:1527189621822};\\\", \\\"{x:1272,y:945,t:1527189621860};\\\", \\\"{x:1273,y:945,t:1527189621981};\\\", \\\"{x:1274,y:945,t:1527189621989};\\\", \\\"{x:1275,y:949,t:1527189622006};\\\", \\\"{x:1276,y:955,t:1527189622023};\\\", \\\"{x:1279,y:963,t:1527189622039};\\\", \\\"{x:1279,y:969,t:1527189622056};\\\", \\\"{x:1279,y:972,t:1527189622072};\\\", \\\"{x:1280,y:973,t:1527189622089};\\\", \\\"{x:1281,y:971,t:1527189622492};\\\", \\\"{x:1281,y:969,t:1527189622506};\\\", \\\"{x:1282,y:965,t:1527189622523};\\\", \\\"{x:1282,y:960,t:1527189622540};\\\", \\\"{x:1282,y:958,t:1527189622557};\\\", \\\"{x:1282,y:957,t:1527189622573};\\\", \\\"{x:1282,y:954,t:1527189622590};\\\", \\\"{x:1282,y:952,t:1527189622607};\\\", \\\"{x:1282,y:949,t:1527189622623};\\\", \\\"{x:1282,y:945,t:1527189622640};\\\", \\\"{x:1282,y:942,t:1527189622658};\\\", \\\"{x:1282,y:941,t:1527189622673};\\\", \\\"{x:1282,y:940,t:1527189622690};\\\", \\\"{x:1282,y:939,t:1527189622707};\\\", \\\"{x:1282,y:938,t:1527189622725};\\\", \\\"{x:1282,y:937,t:1527189622740};\\\", \\\"{x:1282,y:936,t:1527189622757};\\\", \\\"{x:1282,y:933,t:1527189622774};\\\", \\\"{x:1283,y:930,t:1527189622790};\\\", \\\"{x:1284,y:927,t:1527189622807};\\\", \\\"{x:1285,y:923,t:1527189622824};\\\", \\\"{x:1285,y:922,t:1527189622841};\\\", \\\"{x:1285,y:918,t:1527189622857};\\\", \\\"{x:1285,y:915,t:1527189622874};\\\", \\\"{x:1285,y:913,t:1527189622891};\\\", \\\"{x:1285,y:912,t:1527189622924};\\\", \\\"{x:1286,y:912,t:1527189622941};\\\", \\\"{x:1285,y:913,t:1527189623069};\\\", \\\"{x:1280,y:918,t:1527189623076};\\\", \\\"{x:1277,y:921,t:1527189623091};\\\", \\\"{x:1264,y:941,t:1527189623108};\\\", \\\"{x:1259,y:948,t:1527189623124};\\\", \\\"{x:1257,y:952,t:1527189623141};\\\", \\\"{x:1254,y:955,t:1527189623159};\\\", \\\"{x:1252,y:958,t:1527189623174};\\\", \\\"{x:1250,y:959,t:1527189623191};\\\", \\\"{x:1246,y:962,t:1527189623208};\\\", \\\"{x:1242,y:965,t:1527189623225};\\\", \\\"{x:1238,y:967,t:1527189623241};\\\", \\\"{x:1232,y:971,t:1527189623259};\\\", \\\"{x:1217,y:974,t:1527189623276};\\\", \\\"{x:1216,y:974,t:1527189623291};\\\", \\\"{x:1193,y:979,t:1527189623308};\\\", \\\"{x:1173,y:980,t:1527189623325};\\\", \\\"{x:1167,y:981,t:1527189623342};\\\", \\\"{x:1154,y:981,t:1527189623358};\\\", \\\"{x:1142,y:981,t:1527189623375};\\\", \\\"{x:1139,y:981,t:1527189623391};\\\", \\\"{x:1137,y:981,t:1527189623407};\\\", \\\"{x:1138,y:980,t:1527189623636};\\\", \\\"{x:1139,y:979,t:1527189623643};\\\", \\\"{x:1140,y:978,t:1527189623660};\\\", \\\"{x:1141,y:977,t:1527189623684};\\\", \\\"{x:1141,y:976,t:1527189623692};\\\", \\\"{x:1143,y:976,t:1527189623709};\\\", \\\"{x:1143,y:975,t:1527189623726};\\\", \\\"{x:1144,y:974,t:1527189623764};\\\", \\\"{x:1145,y:971,t:1527189623779};\\\", \\\"{x:1145,y:970,t:1527189623792};\\\", \\\"{x:1146,y:967,t:1527189623809};\\\", \\\"{x:1148,y:961,t:1527189623826};\\\", \\\"{x:1150,y:958,t:1527189623843};\\\", \\\"{x:1151,y:950,t:1527189623859};\\\", \\\"{x:1156,y:936,t:1527189623876};\\\", \\\"{x:1160,y:922,t:1527189623894};\\\", \\\"{x:1163,y:912,t:1527189623909};\\\", \\\"{x:1165,y:904,t:1527189623927};\\\", \\\"{x:1166,y:899,t:1527189623943};\\\", \\\"{x:1167,y:897,t:1527189623959};\\\", \\\"{x:1167,y:892,t:1527189623976};\\\", \\\"{x:1168,y:884,t:1527189623993};\\\", \\\"{x:1169,y:877,t:1527189624010};\\\", \\\"{x:1169,y:868,t:1527189624026};\\\", \\\"{x:1169,y:864,t:1527189624043};\\\", \\\"{x:1169,y:863,t:1527189624060};\\\", \\\"{x:1169,y:862,t:1527189624132};\\\", \\\"{x:1169,y:861,t:1527189624143};\\\", \\\"{x:1169,y:860,t:1527189624160};\\\", \\\"{x:1169,y:859,t:1527189624177};\\\", \\\"{x:1169,y:858,t:1527189624194};\\\", \\\"{x:1169,y:857,t:1527189624210};\\\", \\\"{x:1169,y:854,t:1527189624279};\\\", \\\"{x:1168,y:854,t:1527189624587};\\\", \\\"{x:1167,y:854,t:1527189625180};\\\", \\\"{x:1166,y:854,t:1527189625195};\\\", \\\"{x:1161,y:857,t:1527189625212};\\\", \\\"{x:1149,y:864,t:1527189625230};\\\", \\\"{x:1136,y:870,t:1527189625245};\\\", \\\"{x:1123,y:878,t:1527189625262};\\\", \\\"{x:1111,y:884,t:1527189625279};\\\", \\\"{x:1104,y:888,t:1527189625295};\\\", \\\"{x:1102,y:888,t:1527189625312};\\\", \\\"{x:1103,y:888,t:1527189625716};\\\", \\\"{x:1104,y:888,t:1527189625731};\\\", \\\"{x:1110,y:888,t:1527189625747};\\\", \\\"{x:1116,y:888,t:1527189625763};\\\", \\\"{x:1123,y:889,t:1527189625780};\\\", \\\"{x:1127,y:889,t:1527189625797};\\\", \\\"{x:1130,y:889,t:1527189625813};\\\", \\\"{x:1132,y:889,t:1527189625831};\\\", \\\"{x:1134,y:889,t:1527189625847};\\\", \\\"{x:1135,y:889,t:1527189625892};\\\", \\\"{x:1137,y:889,t:1527189625900};\\\", \\\"{x:1138,y:889,t:1527189625915};\\\", \\\"{x:1140,y:889,t:1527189625930};\\\", \\\"{x:1144,y:889,t:1527189625947};\\\", \\\"{x:1145,y:889,t:1527189625965};\\\", \\\"{x:1146,y:890,t:1527189626045};\\\", \\\"{x:1146,y:894,t:1527189626052};\\\", \\\"{x:1146,y:895,t:1527189626064};\\\", \\\"{x:1146,y:899,t:1527189626081};\\\", \\\"{x:1149,y:905,t:1527189626096};\\\", \\\"{x:1149,y:906,t:1527189626114};\\\", \\\"{x:1149,y:907,t:1527189626130};\\\", \\\"{x:1149,y:908,t:1527189626146};\\\", \\\"{x:1149,y:910,t:1527189626164};\\\", \\\"{x:1149,y:911,t:1527189626804};\\\", \\\"{x:1154,y:909,t:1527189626815};\\\", \\\"{x:1173,y:874,t:1527189626832};\\\", \\\"{x:1200,y:788,t:1527189626849};\\\", \\\"{x:1212,y:680,t:1527189626866};\\\", \\\"{x:1225,y:543,t:1527189626883};\\\", \\\"{x:1244,y:413,t:1527189626900};\\\", \\\"{x:1268,y:285,t:1527189626916};\\\", \\\"{x:1280,y:212,t:1527189626932};\\\", \\\"{x:1300,y:167,t:1527189626949};\\\", \\\"{x:1314,y:140,t:1527189626966};\\\", \\\"{x:1320,y:119,t:1527189626982};\\\", \\\"{x:1325,y:108,t:1527189626999};\\\", \\\"{x:1331,y:93,t:1527189627016};\\\", \\\"{x:1346,y:80,t:1527189627032};\\\", \\\"{x:1360,y:71,t:1527189627049};\\\", \\\"{x:1365,y:68,t:1527189627066};\\\", \\\"{x:1370,y:67,t:1527189627083};\\\", \\\"{x:1383,y:66,t:1527189627099};\\\", \\\"{x:1397,y:70,t:1527189627116};\\\", \\\"{x:1407,y:78,t:1527189627133};\\\", \\\"{x:1417,y:85,t:1527189627149};\\\", \\\"{x:1425,y:100,t:1527189627166};\\\", \\\"{x:1439,y:123,t:1527189627182};\\\", \\\"{x:1450,y:149,t:1527189627200};\\\", \\\"{x:1456,y:163,t:1527189627215};\\\", \\\"{x:1460,y:177,t:1527189627233};\\\", \\\"{x:1462,y:182,t:1527189627249};\\\", \\\"{x:1462,y:185,t:1527189627266};\\\", \\\"{x:1462,y:187,t:1527189627283};\\\", \\\"{x:1462,y:189,t:1527189627299};\\\", \\\"{x:1462,y:190,t:1527189627316};\\\", \\\"{x:1462,y:191,t:1527189627332};\\\", \\\"{x:1464,y:191,t:1527189627444};\\\", \\\"{x:1465,y:187,t:1527189627451};\\\", \\\"{x:1469,y:177,t:1527189627468};\\\", \\\"{x:1471,y:171,t:1527189627484};\\\", \\\"{x:1473,y:167,t:1527189627500};\\\", \\\"{x:1475,y:165,t:1527189627516};\\\", \\\"{x:1475,y:164,t:1527189627534};\\\", \\\"{x:1475,y:163,t:1527189627550};\\\", \\\"{x:1477,y:163,t:1527189627812};\\\", \\\"{x:1478,y:162,t:1527189627827};\\\", \\\"{x:1479,y:162,t:1527189627836};\\\", \\\"{x:1483,y:162,t:1527189627852};\\\", \\\"{x:1485,y:161,t:1527189627868};\\\", \\\"{x:1486,y:161,t:1527189627884};\\\", \\\"{x:1487,y:161,t:1527189627908};\\\", \\\"{x:1487,y:162,t:1527189628964};\\\", \\\"{x:1487,y:163,t:1527189628980};\\\", \\\"{x:1486,y:165,t:1527189629011};\\\", \\\"{x:1486,y:166,t:1527189629036};\\\", \\\"{x:1486,y:168,t:1527189629053};\\\", \\\"{x:1484,y:172,t:1527189629070};\\\", \\\"{x:1483,y:176,t:1527189629087};\\\", \\\"{x:1482,y:177,t:1527189629103};\\\", \\\"{x:1482,y:179,t:1527189629188};\\\", \\\"{x:1481,y:183,t:1527189629204};\\\", \\\"{x:1478,y:188,t:1527189629220};\\\", \\\"{x:1475,y:195,t:1527189629237};\\\", \\\"{x:1470,y:204,t:1527189629254};\\\", \\\"{x:1461,y:222,t:1527189629271};\\\", \\\"{x:1448,y:238,t:1527189629288};\\\", \\\"{x:1419,y:275,t:1527189629304};\\\", \\\"{x:1327,y:365,t:1527189629322};\\\", \\\"{x:1220,y:457,t:1527189629337};\\\", \\\"{x:1124,y:539,t:1527189629354};\\\", \\\"{x:995,y:640,t:1527189629372};\\\", \\\"{x:919,y:694,t:1527189629388};\\\", \\\"{x:861,y:729,t:1527189629404};\\\", \\\"{x:818,y:754,t:1527189629422};\\\", \\\"{x:787,y:769,t:1527189629437};\\\", \\\"{x:764,y:783,t:1527189629455};\\\", \\\"{x:749,y:794,t:1527189629471};\\\", \\\"{x:738,y:802,t:1527189629489};\\\", \\\"{x:723,y:814,t:1527189629504};\\\", \\\"{x:703,y:827,t:1527189629521};\\\", \\\"{x:682,y:834,t:1527189629539};\\\", \\\"{x:664,y:835,t:1527189629554};\\\", \\\"{x:641,y:836,t:1527189629572};\\\", \\\"{x:624,y:830,t:1527189629588};\\\", \\\"{x:608,y:825,t:1527189629606};\\\", \\\"{x:600,y:818,t:1527189629621};\\\", \\\"{x:593,y:811,t:1527189629638};\\\", \\\"{x:589,y:803,t:1527189629655};\\\", \\\"{x:586,y:787,t:1527189629671};\\\", \\\"{x:582,y:773,t:1527189629688};\\\", \\\"{x:582,y:766,t:1527189629705};\\\", \\\"{x:582,y:761,t:1527189629721};\\\", \\\"{x:582,y:757,t:1527189629738};\\\", \\\"{x:582,y:745,t:1527189629756};\\\", \\\"{x:582,y:737,t:1527189629771};\\\", \\\"{x:582,y:734,t:1527189629788};\\\", \\\"{x:582,y:730,t:1527189629805};\\\", \\\"{x:582,y:729,t:1527189629822};\\\", \\\"{x:582,y:728,t:1527189629948};\\\", \\\"{x:580,y:727,t:1527189630036};\\\", \\\"{x:580,y:726,t:1527189630044};\\\", \\\"{x:579,y:725,t:1527189630055};\\\", \\\"{x:574,y:722,t:1527189630073};\\\", \\\"{x:566,y:719,t:1527189630090};\\\", \\\"{x:565,y:718,t:1527189630106};\\\", \\\"{x:564,y:718,t:1527189630124};\\\", \\\"{x:563,y:718,t:1527189630139};\\\", \\\"{x:563,y:717,t:1527189630186};\\\", \\\"{x:562,y:716,t:1527189630195};\\\", \\\"{x:560,y:716,t:1527189630204};\\\", \\\"{x:558,y:716,t:1527189630220};\\\", \\\"{x:557,y:716,t:1527189630238};\\\", \\\"{x:555,y:716,t:1527189630795};\\\" ] }, { \\\"rt\\\": 12540, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 223715, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"F98S2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"J\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z -O -H -D -J \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:563,y:716,t:1527189634260};\\\", \\\"{x:574,y:716,t:1527189634269};\\\", \\\"{x:586,y:716,t:1527189634281};\\\", \\\"{x:615,y:716,t:1527189634298};\\\", \\\"{x:671,y:714,t:1527189634309};\\\", \\\"{x:722,y:714,t:1527189634326};\\\", \\\"{x:764,y:714,t:1527189634343};\\\", \\\"{x:813,y:714,t:1527189634360};\\\", \\\"{x:852,y:714,t:1527189634376};\\\", \\\"{x:881,y:710,t:1527189634393};\\\", \\\"{x:896,y:708,t:1527189634409};\\\", \\\"{x:917,y:708,t:1527189634425};\\\", \\\"{x:941,y:708,t:1527189634442};\\\", \\\"{x:951,y:708,t:1527189634459};\\\", \\\"{x:962,y:708,t:1527189634476};\\\", \\\"{x:967,y:708,t:1527189634493};\\\", \\\"{x:973,y:708,t:1527189634509};\\\", \\\"{x:982,y:708,t:1527189634527};\\\", \\\"{x:987,y:710,t:1527189634543};\\\", \\\"{x:995,y:715,t:1527189634560};\\\", \\\"{x:1010,y:719,t:1527189634576};\\\", \\\"{x:1029,y:724,t:1527189634593};\\\", \\\"{x:1052,y:731,t:1527189634610};\\\", \\\"{x:1101,y:742,t:1527189634627};\\\", \\\"{x:1137,y:755,t:1527189634643};\\\", \\\"{x:1171,y:760,t:1527189634660};\\\", \\\"{x:1203,y:766,t:1527189634677};\\\", \\\"{x:1227,y:776,t:1527189634693};\\\", \\\"{x:1256,y:786,t:1527189634710};\\\", \\\"{x:1280,y:794,t:1527189634728};\\\", \\\"{x:1294,y:799,t:1527189634743};\\\", \\\"{x:1311,y:803,t:1527189634760};\\\", \\\"{x:1325,y:807,t:1527189634777};\\\", \\\"{x:1333,y:810,t:1527189634793};\\\", \\\"{x:1343,y:815,t:1527189634810};\\\", \\\"{x:1353,y:817,t:1527189634826};\\\", \\\"{x:1370,y:824,t:1527189634843};\\\", \\\"{x:1379,y:831,t:1527189634861};\\\", \\\"{x:1391,y:834,t:1527189634877};\\\", \\\"{x:1400,y:839,t:1527189634893};\\\", \\\"{x:1411,y:843,t:1527189634910};\\\", \\\"{x:1420,y:845,t:1527189634927};\\\", \\\"{x:1429,y:847,t:1527189634944};\\\", \\\"{x:1437,y:850,t:1527189634960};\\\", \\\"{x:1440,y:851,t:1527189634977};\\\", \\\"{x:1446,y:854,t:1527189634993};\\\", \\\"{x:1449,y:854,t:1527189635010};\\\", \\\"{x:1451,y:855,t:1527189635027};\\\", \\\"{x:1452,y:856,t:1527189635043};\\\", \\\"{x:1454,y:858,t:1527189635060};\\\", \\\"{x:1455,y:858,t:1527189635077};\\\", \\\"{x:1457,y:858,t:1527189635095};\\\", \\\"{x:1458,y:858,t:1527189635111};\\\", \\\"{x:1458,y:860,t:1527189635196};\\\", \\\"{x:1459,y:861,t:1527189635211};\\\", \\\"{x:1459,y:863,t:1527189635228};\\\", \\\"{x:1459,y:864,t:1527189635245};\\\", \\\"{x:1459,y:868,t:1527189635260};\\\", \\\"{x:1459,y:869,t:1527189635278};\\\", \\\"{x:1458,y:870,t:1527189635294};\\\", \\\"{x:1457,y:875,t:1527189635310};\\\", \\\"{x:1454,y:880,t:1527189635327};\\\", \\\"{x:1452,y:890,t:1527189635344};\\\", \\\"{x:1450,y:896,t:1527189635361};\\\", \\\"{x:1448,y:898,t:1527189635378};\\\", \\\"{x:1446,y:902,t:1527189635395};\\\", \\\"{x:1442,y:907,t:1527189635410};\\\", \\\"{x:1439,y:910,t:1527189635427};\\\", \\\"{x:1435,y:916,t:1527189635444};\\\", \\\"{x:1432,y:919,t:1527189635461};\\\", \\\"{x:1426,y:924,t:1527189635477};\\\", \\\"{x:1421,y:929,t:1527189635494};\\\", \\\"{x:1417,y:932,t:1527189635512};\\\", \\\"{x:1407,y:936,t:1527189635528};\\\", \\\"{x:1393,y:940,t:1527189635544};\\\", \\\"{x:1385,y:943,t:1527189635561};\\\", \\\"{x:1384,y:943,t:1527189635578};\\\", \\\"{x:1383,y:944,t:1527189635594};\\\", \\\"{x:1382,y:944,t:1527189635610};\\\", \\\"{x:1379,y:943,t:1527189635627};\\\", \\\"{x:1377,y:943,t:1527189635644};\\\", \\\"{x:1372,y:943,t:1527189635661};\\\", \\\"{x:1371,y:943,t:1527189635677};\\\", \\\"{x:1368,y:943,t:1527189635694};\\\", \\\"{x:1366,y:943,t:1527189635711};\\\", \\\"{x:1362,y:943,t:1527189635727};\\\", \\\"{x:1361,y:942,t:1527189635744};\\\", \\\"{x:1360,y:942,t:1527189635762};\\\", \\\"{x:1359,y:942,t:1527189635777};\\\", \\\"{x:1358,y:940,t:1527189635836};\\\", \\\"{x:1357,y:939,t:1527189635845};\\\", \\\"{x:1355,y:934,t:1527189635861};\\\", \\\"{x:1354,y:931,t:1527189635877};\\\", \\\"{x:1351,y:926,t:1527189635894};\\\", \\\"{x:1351,y:920,t:1527189635911};\\\", \\\"{x:1348,y:913,t:1527189635927};\\\", \\\"{x:1347,y:907,t:1527189635944};\\\", \\\"{x:1347,y:902,t:1527189635964};\\\", \\\"{x:1346,y:896,t:1527189635978};\\\", \\\"{x:1344,y:894,t:1527189635993};\\\", \\\"{x:1343,y:888,t:1527189636011};\\\", \\\"{x:1339,y:878,t:1527189636029};\\\", \\\"{x:1333,y:865,t:1527189636043};\\\", \\\"{x:1325,y:854,t:1527189636061};\\\", \\\"{x:1319,y:845,t:1527189636078};\\\", \\\"{x:1315,y:837,t:1527189636094};\\\", \\\"{x:1308,y:822,t:1527189636111};\\\", \\\"{x:1300,y:809,t:1527189636128};\\\", \\\"{x:1292,y:794,t:1527189636144};\\\", \\\"{x:1286,y:779,t:1527189636161};\\\", \\\"{x:1279,y:766,t:1527189636178};\\\", \\\"{x:1274,y:759,t:1527189636194};\\\", \\\"{x:1270,y:747,t:1527189636211};\\\", \\\"{x:1269,y:737,t:1527189636228};\\\", \\\"{x:1269,y:727,t:1527189636244};\\\", \\\"{x:1269,y:712,t:1527189636262};\\\", \\\"{x:1269,y:697,t:1527189636278};\\\", \\\"{x:1269,y:689,t:1527189636295};\\\", \\\"{x:1269,y:682,t:1527189636311};\\\", \\\"{x:1270,y:677,t:1527189636329};\\\", \\\"{x:1273,y:671,t:1527189636345};\\\", \\\"{x:1276,y:665,t:1527189636362};\\\", \\\"{x:1279,y:657,t:1527189636378};\\\", \\\"{x:1287,y:646,t:1527189636395};\\\", \\\"{x:1293,y:638,t:1527189636411};\\\", \\\"{x:1298,y:633,t:1527189636428};\\\", \\\"{x:1305,y:626,t:1527189636446};\\\", \\\"{x:1310,y:622,t:1527189636461};\\\", \\\"{x:1316,y:617,t:1527189636479};\\\", \\\"{x:1321,y:612,t:1527189636496};\\\", \\\"{x:1327,y:609,t:1527189636512};\\\", \\\"{x:1332,y:605,t:1527189636529};\\\", \\\"{x:1338,y:601,t:1527189636545};\\\", \\\"{x:1344,y:598,t:1527189636561};\\\", \\\"{x:1349,y:596,t:1527189636578};\\\", \\\"{x:1355,y:593,t:1527189636595};\\\", \\\"{x:1359,y:593,t:1527189636611};\\\", \\\"{x:1360,y:592,t:1527189636628};\\\", \\\"{x:1366,y:589,t:1527189636645};\\\", \\\"{x:1369,y:589,t:1527189636662};\\\", \\\"{x:1374,y:588,t:1527189636679};\\\", \\\"{x:1378,y:585,t:1527189636696};\\\", \\\"{x:1383,y:583,t:1527189636711};\\\", \\\"{x:1385,y:581,t:1527189636728};\\\", \\\"{x:1388,y:581,t:1527189636745};\\\", \\\"{x:1390,y:581,t:1527189636763};\\\", \\\"{x:1392,y:580,t:1527189636778};\\\", \\\"{x:1393,y:578,t:1527189636796};\\\", \\\"{x:1397,y:575,t:1527189636812};\\\", \\\"{x:1400,y:574,t:1527189636828};\\\", \\\"{x:1404,y:572,t:1527189636845};\\\", \\\"{x:1407,y:568,t:1527189636861};\\\", \\\"{x:1411,y:566,t:1527189636878};\\\", \\\"{x:1414,y:563,t:1527189636895};\\\", \\\"{x:1418,y:563,t:1527189636912};\\\", \\\"{x:1423,y:559,t:1527189636929};\\\", \\\"{x:1426,y:557,t:1527189636945};\\\", \\\"{x:1434,y:555,t:1527189636962};\\\", \\\"{x:1439,y:551,t:1527189636977};\\\", \\\"{x:1458,y:543,t:1527189636995};\\\", \\\"{x:1477,y:535,t:1527189637012};\\\", \\\"{x:1490,y:528,t:1527189637028};\\\", \\\"{x:1505,y:522,t:1527189637045};\\\", \\\"{x:1514,y:516,t:1527189637062};\\\", \\\"{x:1526,y:510,t:1527189637078};\\\", \\\"{x:1537,y:503,t:1527189637095};\\\", \\\"{x:1546,y:497,t:1527189637112};\\\", \\\"{x:1556,y:492,t:1527189637128};\\\", \\\"{x:1564,y:487,t:1527189637145};\\\", \\\"{x:1568,y:484,t:1527189637163};\\\", \\\"{x:1574,y:480,t:1527189637178};\\\", \\\"{x:1584,y:470,t:1527189637194};\\\", \\\"{x:1588,y:466,t:1527189637212};\\\", \\\"{x:1590,y:462,t:1527189637228};\\\", \\\"{x:1593,y:460,t:1527189637245};\\\", \\\"{x:1596,y:457,t:1527189637262};\\\", \\\"{x:1597,y:455,t:1527189637283};\\\", \\\"{x:1598,y:455,t:1527189637296};\\\", \\\"{x:1600,y:452,t:1527189637312};\\\", \\\"{x:1603,y:450,t:1527189637329};\\\", \\\"{x:1606,y:446,t:1527189637345};\\\", \\\"{x:1608,y:444,t:1527189637362};\\\", \\\"{x:1612,y:441,t:1527189637379};\\\", \\\"{x:1614,y:439,t:1527189637395};\\\", \\\"{x:1615,y:438,t:1527189637419};\\\", \\\"{x:1617,y:437,t:1527189637436};\\\", \\\"{x:1618,y:435,t:1527189637446};\\\", \\\"{x:1620,y:434,t:1527189637463};\\\", \\\"{x:1621,y:433,t:1527189637480};\\\", \\\"{x:1621,y:432,t:1527189637495};\\\", \\\"{x:1617,y:432,t:1527189638676};\\\", \\\"{x:1604,y:432,t:1527189638697};\\\", \\\"{x:1590,y:432,t:1527189638713};\\\", \\\"{x:1578,y:432,t:1527189638731};\\\", \\\"{x:1571,y:432,t:1527189638746};\\\", \\\"{x:1565,y:434,t:1527189638764};\\\", \\\"{x:1561,y:434,t:1527189638780};\\\", \\\"{x:1554,y:436,t:1527189638797};\\\", \\\"{x:1544,y:438,t:1527189638813};\\\", \\\"{x:1535,y:438,t:1527189638831};\\\", \\\"{x:1531,y:439,t:1527189638847};\\\", \\\"{x:1523,y:440,t:1527189638863};\\\", \\\"{x:1515,y:441,t:1527189638881};\\\", \\\"{x:1502,y:441,t:1527189638897};\\\", \\\"{x:1492,y:443,t:1527189638913};\\\", \\\"{x:1482,y:443,t:1527189638931};\\\", \\\"{x:1476,y:443,t:1527189638946};\\\", \\\"{x:1468,y:443,t:1527189638963};\\\", \\\"{x:1467,y:443,t:1527189638981};\\\", \\\"{x:1459,y:443,t:1527189638996};\\\", \\\"{x:1456,y:443,t:1527189639014};\\\", \\\"{x:1453,y:442,t:1527189639031};\\\", \\\"{x:1448,y:442,t:1527189639047};\\\", \\\"{x:1443,y:441,t:1527189639063};\\\", \\\"{x:1440,y:440,t:1527189639081};\\\", \\\"{x:1436,y:439,t:1527189639098};\\\", \\\"{x:1434,y:439,t:1527189639114};\\\", \\\"{x:1432,y:439,t:1527189639131};\\\", \\\"{x:1430,y:437,t:1527189639148};\\\", \\\"{x:1427,y:436,t:1527189639164};\\\", \\\"{x:1426,y:436,t:1527189639181};\\\", \\\"{x:1422,y:434,t:1527189639198};\\\", \\\"{x:1421,y:434,t:1527189639213};\\\", \\\"{x:1417,y:432,t:1527189639231};\\\", \\\"{x:1416,y:432,t:1527189639247};\\\", \\\"{x:1413,y:431,t:1527189639263};\\\", \\\"{x:1412,y:431,t:1527189639281};\\\", \\\"{x:1410,y:430,t:1527189639297};\\\", \\\"{x:1409,y:430,t:1527189640220};\\\", \\\"{x:1407,y:430,t:1527189640233};\\\", \\\"{x:1396,y:431,t:1527189640248};\\\", \\\"{x:1380,y:440,t:1527189640265};\\\", \\\"{x:1362,y:447,t:1527189640282};\\\", \\\"{x:1335,y:458,t:1527189640297};\\\", \\\"{x:1306,y:467,t:1527189640314};\\\", \\\"{x:1256,y:487,t:1527189640331};\\\", \\\"{x:1219,y:506,t:1527189640348};\\\", \\\"{x:1176,y:525,t:1527189640365};\\\", \\\"{x:1116,y:547,t:1527189640381};\\\", \\\"{x:1061,y:558,t:1527189640398};\\\", \\\"{x:1014,y:572,t:1527189640414};\\\", \\\"{x:966,y:587,t:1527189640432};\\\", \\\"{x:916,y:601,t:1527189640450};\\\", \\\"{x:876,y:608,t:1527189640464};\\\", \\\"{x:841,y:615,t:1527189640481};\\\", \\\"{x:801,y:622,t:1527189640498};\\\", \\\"{x:771,y:628,t:1527189640513};\\\", \\\"{x:744,y:635,t:1527189640531};\\\", \\\"{x:729,y:640,t:1527189640548};\\\", \\\"{x:718,y:646,t:1527189640565};\\\", \\\"{x:704,y:649,t:1527189640581};\\\", \\\"{x:692,y:652,t:1527189640599};\\\", \\\"{x:687,y:653,t:1527189640615};\\\", \\\"{x:686,y:653,t:1527189640631};\\\", \\\"{x:685,y:653,t:1527189640648};\\\", \\\"{x:682,y:654,t:1527189640664};\\\", \\\"{x:675,y:656,t:1527189640681};\\\", \\\"{x:670,y:656,t:1527189640698};\\\", \\\"{x:642,y:655,t:1527189640715};\\\", \\\"{x:624,y:653,t:1527189640731};\\\", \\\"{x:605,y:650,t:1527189640749};\\\", \\\"{x:601,y:650,t:1527189640765};\\\", \\\"{x:587,y:649,t:1527189640781};\\\", \\\"{x:576,y:648,t:1527189640798};\\\", \\\"{x:565,y:645,t:1527189640815};\\\", \\\"{x:557,y:645,t:1527189640830};\\\", \\\"{x:547,y:644,t:1527189640848};\\\", \\\"{x:528,y:643,t:1527189640865};\\\", \\\"{x:506,y:641,t:1527189640881};\\\", \\\"{x:490,y:640,t:1527189640899};\\\", \\\"{x:471,y:639,t:1527189640914};\\\", \\\"{x:465,y:638,t:1527189640931};\\\", \\\"{x:459,y:638,t:1527189640948};\\\", \\\"{x:458,y:638,t:1527189640965};\\\", \\\"{x:455,y:635,t:1527189641124};\\\", \\\"{x:450,y:635,t:1527189641132};\\\", \\\"{x:445,y:631,t:1527189641148};\\\", \\\"{x:440,y:630,t:1527189641165};\\\", \\\"{x:434,y:627,t:1527189641182};\\\", \\\"{x:431,y:626,t:1527189641198};\\\", \\\"{x:428,y:625,t:1527189641215};\\\", \\\"{x:426,y:624,t:1527189641233};\\\", \\\"{x:425,y:624,t:1527189641248};\\\", \\\"{x:421,y:624,t:1527189641265};\\\", \\\"{x:417,y:623,t:1527189641283};\\\", \\\"{x:415,y:623,t:1527189641298};\\\", \\\"{x:410,y:621,t:1527189641316};\\\", \\\"{x:408,y:621,t:1527189641332};\\\", \\\"{x:407,y:621,t:1527189641355};\\\", \\\"{x:406,y:621,t:1527189641365};\\\", \\\"{x:404,y:620,t:1527189641382};\\\", \\\"{x:399,y:620,t:1527189641398};\\\", \\\"{x:398,y:620,t:1527189641418};\\\", \\\"{x:396,y:620,t:1527189641432};\\\", \\\"{x:393,y:620,t:1527189641448};\\\", \\\"{x:388,y:617,t:1527189641466};\\\", \\\"{x:386,y:617,t:1527189641482};\\\", \\\"{x:385,y:617,t:1527189641499};\\\", \\\"{x:379,y:614,t:1527189641515};\\\", \\\"{x:376,y:614,t:1527189641532};\\\", \\\"{x:371,y:612,t:1527189641551};\\\", \\\"{x:363,y:610,t:1527189641566};\\\", \\\"{x:358,y:610,t:1527189641582};\\\", \\\"{x:350,y:606,t:1527189641601};\\\", \\\"{x:345,y:606,t:1527189641615};\\\", \\\"{x:337,y:604,t:1527189641632};\\\", \\\"{x:332,y:602,t:1527189641649};\\\", \\\"{x:324,y:600,t:1527189641665};\\\", \\\"{x:314,y:600,t:1527189641682};\\\", \\\"{x:300,y:596,t:1527189641699};\\\", \\\"{x:294,y:594,t:1527189641715};\\\", \\\"{x:290,y:593,t:1527189641732};\\\", \\\"{x:287,y:592,t:1527189641749};\\\", \\\"{x:283,y:592,t:1527189641765};\\\", \\\"{x:275,y:592,t:1527189641782};\\\", \\\"{x:260,y:592,t:1527189641800};\\\", \\\"{x:245,y:592,t:1527189641815};\\\", \\\"{x:237,y:592,t:1527189641832};\\\", \\\"{x:231,y:592,t:1527189641849};\\\", \\\"{x:231,y:593,t:1527189641916};\\\", \\\"{x:244,y:594,t:1527189641933};\\\", \\\"{x:271,y:594,t:1527189641950};\\\", \\\"{x:308,y:594,t:1527189641968};\\\", \\\"{x:333,y:594,t:1527189641982};\\\", \\\"{x:367,y:595,t:1527189641999};\\\", \\\"{x:392,y:596,t:1527189642016};\\\", \\\"{x:429,y:596,t:1527189642032};\\\", \\\"{x:456,y:596,t:1527189642049};\\\", \\\"{x:485,y:596,t:1527189642066};\\\", \\\"{x:503,y:596,t:1527189642082};\\\", \\\"{x:530,y:596,t:1527189642099};\\\", \\\"{x:535,y:596,t:1527189642116};\\\", \\\"{x:537,y:596,t:1527189642244};\\\", \\\"{x:541,y:596,t:1527189642251};\\\", \\\"{x:544,y:596,t:1527189642265};\\\", \\\"{x:559,y:592,t:1527189642283};\\\", \\\"{x:627,y:577,t:1527189642300};\\\", \\\"{x:720,y:568,t:1527189642316};\\\", \\\"{x:813,y:564,t:1527189642334};\\\", \\\"{x:885,y:564,t:1527189642350};\\\", \\\"{x:964,y:568,t:1527189642366};\\\", \\\"{x:1006,y:574,t:1527189642384};\\\", \\\"{x:1027,y:578,t:1527189642399};\\\", \\\"{x:1028,y:579,t:1527189642417};\\\", \\\"{x:1027,y:581,t:1527189642492};\\\", \\\"{x:1026,y:582,t:1527189642500};\\\", \\\"{x:1007,y:586,t:1527189642516};\\\", \\\"{x:982,y:588,t:1527189642534};\\\", \\\"{x:960,y:593,t:1527189642550};\\\", \\\"{x:947,y:598,t:1527189642570};\\\", \\\"{x:934,y:600,t:1527189642583};\\\", \\\"{x:918,y:600,t:1527189642599};\\\", \\\"{x:911,y:600,t:1527189642616};\\\", \\\"{x:910,y:600,t:1527189642633};\\\", \\\"{x:908,y:600,t:1527189642648};\\\", \\\"{x:906,y:600,t:1527189642707};\\\", \\\"{x:906,y:599,t:1527189642716};\\\", \\\"{x:903,y:595,t:1527189642733};\\\", \\\"{x:901,y:592,t:1527189642749};\\\", \\\"{x:899,y:589,t:1527189642766};\\\", \\\"{x:897,y:585,t:1527189642783};\\\", \\\"{x:893,y:583,t:1527189642801};\\\", \\\"{x:888,y:577,t:1527189642817};\\\", \\\"{x:880,y:571,t:1527189642834};\\\", \\\"{x:873,y:569,t:1527189642850};\\\", \\\"{x:865,y:567,t:1527189642866};\\\", \\\"{x:859,y:566,t:1527189642883};\\\", \\\"{x:856,y:566,t:1527189642900};\\\", \\\"{x:855,y:566,t:1527189642930};\\\", \\\"{x:853,y:566,t:1527189642938};\\\", \\\"{x:852,y:566,t:1527189642950};\\\", \\\"{x:850,y:565,t:1527189642966};\\\", \\\"{x:848,y:565,t:1527189643498};\\\", \\\"{x:846,y:565,t:1527189643506};\\\", \\\"{x:842,y:566,t:1527189643517};\\\", \\\"{x:832,y:568,t:1527189643533};\\\", \\\"{x:822,y:572,t:1527189643550};\\\", \\\"{x:815,y:572,t:1527189643567};\\\", \\\"{x:809,y:573,t:1527189643584};\\\", \\\"{x:808,y:573,t:1527189643600};\\\", \\\"{x:805,y:575,t:1527189643618};\\\", \\\"{x:795,y:577,t:1527189643634};\\\", \\\"{x:780,y:585,t:1527189643651};\\\", \\\"{x:755,y:601,t:1527189643667};\\\", \\\"{x:740,y:610,t:1527189643684};\\\", \\\"{x:728,y:619,t:1527189643701};\\\", \\\"{x:713,y:631,t:1527189643718};\\\", \\\"{x:694,y:646,t:1527189643734};\\\", \\\"{x:674,y:665,t:1527189643750};\\\", \\\"{x:652,y:682,t:1527189643767};\\\", \\\"{x:638,y:697,t:1527189643784};\\\", \\\"{x:623,y:709,t:1527189643801};\\\", \\\"{x:613,y:718,t:1527189643817};\\\", \\\"{x:606,y:721,t:1527189643834};\\\", \\\"{x:589,y:730,t:1527189643850};\\\", \\\"{x:571,y:739,t:1527189643867};\\\", \\\"{x:552,y:749,t:1527189643884};\\\", \\\"{x:543,y:753,t:1527189643901};\\\", \\\"{x:534,y:754,t:1527189643917};\\\", \\\"{x:528,y:754,t:1527189643934};\\\", \\\"{x:525,y:754,t:1527189643951};\\\", \\\"{x:519,y:753,t:1527189643969};\\\", \\\"{x:512,y:747,t:1527189643985};\\\", \\\"{x:508,y:744,t:1527189644002};\\\", \\\"{x:504,y:739,t:1527189644018};\\\", \\\"{x:500,y:729,t:1527189644035};\\\", \\\"{x:499,y:725,t:1527189644052};\\\", \\\"{x:499,y:722,t:1527189644067};\\\", \\\"{x:499,y:721,t:1527189644084};\\\", \\\"{x:499,y:717,t:1527189644100};\\\", \\\"{x:499,y:715,t:1527189644118};\\\" ] }, { \\\"rt\\\": 39884, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 265040, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"F98S2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -C -A -C -C -C -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:499,y:710,t:1527189647395};\\\", \\\"{x:495,y:699,t:1527189647402};\\\", \\\"{x:491,y:671,t:1527189647420};\\\", \\\"{x:489,y:638,t:1527189647437};\\\", \\\"{x:487,y:623,t:1527189647453};\\\", \\\"{x:484,y:597,t:1527189647471};\\\", \\\"{x:482,y:568,t:1527189647488};\\\", \\\"{x:480,y:546,t:1527189647503};\\\", \\\"{x:478,y:527,t:1527189647521};\\\", \\\"{x:477,y:504,t:1527189647537};\\\", \\\"{x:473,y:481,t:1527189647553};\\\", \\\"{x:471,y:466,t:1527189647570};\\\", \\\"{x:470,y:462,t:1527189647587};\\\", \\\"{x:470,y:458,t:1527189647604};\\\", \\\"{x:470,y:457,t:1527189647626};\\\", \\\"{x:470,y:456,t:1527189647637};\\\", \\\"{x:469,y:455,t:1527189647653};\\\", \\\"{x:469,y:456,t:1527189647835};\\\", \\\"{x:477,y:460,t:1527189647843};\\\", \\\"{x:483,y:461,t:1527189647854};\\\", \\\"{x:493,y:468,t:1527189647870};\\\", \\\"{x:510,y:474,t:1527189647888};\\\", \\\"{x:528,y:479,t:1527189647903};\\\", \\\"{x:535,y:482,t:1527189647921};\\\", \\\"{x:554,y:487,t:1527189647938};\\\", \\\"{x:567,y:492,t:1527189647955};\\\", \\\"{x:588,y:495,t:1527189647971};\\\", \\\"{x:593,y:496,t:1527189647987};\\\", \\\"{x:601,y:497,t:1527189648005};\\\", \\\"{x:605,y:498,t:1527189648021};\\\", \\\"{x:608,y:498,t:1527189648038};\\\", \\\"{x:613,y:500,t:1527189648055};\\\", \\\"{x:621,y:501,t:1527189648070};\\\", \\\"{x:630,y:504,t:1527189648088};\\\", \\\"{x:644,y:505,t:1527189648104};\\\", \\\"{x:654,y:508,t:1527189648122};\\\", \\\"{x:679,y:514,t:1527189648137};\\\", \\\"{x:708,y:522,t:1527189648153};\\\", \\\"{x:734,y:530,t:1527189648171};\\\", \\\"{x:805,y:543,t:1527189648186};\\\", \\\"{x:935,y:562,t:1527189648205};\\\", \\\"{x:1019,y:579,t:1527189648220};\\\", \\\"{x:1044,y:588,t:1527189648237};\\\", \\\"{x:1099,y:600,t:1527189648254};\\\", \\\"{x:1148,y:611,t:1527189648272};\\\", \\\"{x:1179,y:618,t:1527189648287};\\\", \\\"{x:1204,y:626,t:1527189648305};\\\", \\\"{x:1225,y:634,t:1527189648320};\\\", \\\"{x:1241,y:642,t:1527189648337};\\\", \\\"{x:1260,y:651,t:1527189648354};\\\", \\\"{x:1275,y:657,t:1527189648371};\\\", \\\"{x:1287,y:661,t:1527189648387};\\\", \\\"{x:1304,y:668,t:1527189648405};\\\", \\\"{x:1323,y:678,t:1527189648421};\\\", \\\"{x:1336,y:688,t:1527189648438};\\\", \\\"{x:1346,y:694,t:1527189648454};\\\", \\\"{x:1351,y:698,t:1527189648472};\\\", \\\"{x:1355,y:702,t:1527189648488};\\\", \\\"{x:1360,y:709,t:1527189648504};\\\", \\\"{x:1363,y:713,t:1527189648522};\\\", \\\"{x:1368,y:719,t:1527189648538};\\\", \\\"{x:1374,y:730,t:1527189648555};\\\", \\\"{x:1378,y:735,t:1527189648571};\\\", \\\"{x:1382,y:741,t:1527189648587};\\\", \\\"{x:1385,y:748,t:1527189648605};\\\", \\\"{x:1386,y:753,t:1527189648622};\\\", \\\"{x:1388,y:758,t:1527189648639};\\\", \\\"{x:1390,y:769,t:1527189648655};\\\", \\\"{x:1392,y:777,t:1527189648672};\\\", \\\"{x:1393,y:779,t:1527189648689};\\\", \\\"{x:1394,y:781,t:1527189648704};\\\", \\\"{x:1394,y:783,t:1527189648722};\\\", \\\"{x:1394,y:784,t:1527189648739};\\\", \\\"{x:1394,y:785,t:1527189648755};\\\", \\\"{x:1394,y:787,t:1527189648772};\\\", \\\"{x:1394,y:790,t:1527189648789};\\\", \\\"{x:1394,y:792,t:1527189648805};\\\", \\\"{x:1391,y:798,t:1527189648822};\\\", \\\"{x:1390,y:803,t:1527189648839};\\\", \\\"{x:1387,y:807,t:1527189648854};\\\", \\\"{x:1387,y:809,t:1527189648872};\\\", \\\"{x:1386,y:813,t:1527189648889};\\\", \\\"{x:1386,y:816,t:1527189648904};\\\", \\\"{x:1383,y:820,t:1527189648922};\\\", \\\"{x:1382,y:828,t:1527189648939};\\\", \\\"{x:1381,y:832,t:1527189648955};\\\", \\\"{x:1380,y:836,t:1527189648972};\\\", \\\"{x:1379,y:838,t:1527189648988};\\\", \\\"{x:1379,y:839,t:1527189649006};\\\", \\\"{x:1378,y:841,t:1527189649022};\\\", \\\"{x:1378,y:842,t:1527189649039};\\\", \\\"{x:1377,y:844,t:1527189649056};\\\", \\\"{x:1374,y:847,t:1527189649072};\\\", \\\"{x:1374,y:850,t:1527189649088};\\\", \\\"{x:1367,y:854,t:1527189649106};\\\", \\\"{x:1353,y:863,t:1527189649122};\\\", \\\"{x:1335,y:870,t:1527189649139};\\\", \\\"{x:1317,y:874,t:1527189649156};\\\", \\\"{x:1303,y:875,t:1527189649171};\\\", \\\"{x:1282,y:878,t:1527189649189};\\\", \\\"{x:1264,y:878,t:1527189649206};\\\", \\\"{x:1249,y:879,t:1527189649221};\\\", \\\"{x:1239,y:879,t:1527189649239};\\\", \\\"{x:1232,y:879,t:1527189649256};\\\", \\\"{x:1227,y:879,t:1527189649272};\\\", \\\"{x:1226,y:877,t:1527189649289};\\\", \\\"{x:1225,y:877,t:1527189649306};\\\", \\\"{x:1224,y:876,t:1527189649363};\\\", \\\"{x:1224,y:875,t:1527189649373};\\\", \\\"{x:1222,y:871,t:1527189649389};\\\", \\\"{x:1219,y:866,t:1527189649406};\\\", \\\"{x:1217,y:862,t:1527189649424};\\\", \\\"{x:1215,y:860,t:1527189649439};\\\", \\\"{x:1214,y:858,t:1527189649456};\\\", \\\"{x:1213,y:857,t:1527189649473};\\\", \\\"{x:1213,y:856,t:1527189649507};\\\", \\\"{x:1211,y:852,t:1527189649523};\\\", \\\"{x:1210,y:850,t:1527189649539};\\\", \\\"{x:1210,y:849,t:1527189649556};\\\", \\\"{x:1209,y:847,t:1527189649573};\\\", \\\"{x:1209,y:846,t:1527189649596};\\\", \\\"{x:1209,y:845,t:1527189649606};\\\", \\\"{x:1209,y:844,t:1527189649623};\\\", \\\"{x:1209,y:843,t:1527189649643};\\\", \\\"{x:1209,y:842,t:1527189649657};\\\", \\\"{x:1209,y:840,t:1527189649674};\\\", \\\"{x:1209,y:839,t:1527189649689};\\\", \\\"{x:1209,y:838,t:1527189649788};\\\", \\\"{x:1209,y:837,t:1527189649803};\\\", \\\"{x:1209,y:836,t:1527189649827};\\\", \\\"{x:1210,y:835,t:1527189649840};\\\", \\\"{x:1210,y:834,t:1527189649860};\\\", \\\"{x:1211,y:832,t:1527189649894};\\\", \\\"{x:1212,y:831,t:1527189649946};\\\", \\\"{x:1212,y:830,t:1527189649963};\\\", \\\"{x:1213,y:830,t:1527189651339};\\\", \\\"{x:1213,y:828,t:1527189651347};\\\", \\\"{x:1213,y:826,t:1527189651358};\\\", \\\"{x:1213,y:825,t:1527189651374};\\\", \\\"{x:1213,y:823,t:1527189651392};\\\", \\\"{x:1213,y:822,t:1527189651408};\\\", \\\"{x:1213,y:821,t:1527189651699};\\\", \\\"{x:1213,y:820,t:1527189651730};\\\", \\\"{x:1213,y:822,t:1527189652532};\\\", \\\"{x:1212,y:822,t:1527189652542};\\\", \\\"{x:1211,y:822,t:1527189652563};\\\", \\\"{x:1210,y:823,t:1527189652579};\\\", \\\"{x:1211,y:823,t:1527189653748};\\\", \\\"{x:1212,y:822,t:1527189653763};\\\", \\\"{x:1212,y:821,t:1527189653787};\\\", \\\"{x:1213,y:819,t:1527189653795};\\\", \\\"{x:1213,y:817,t:1527189653810};\\\", \\\"{x:1214,y:812,t:1527189653827};\\\", \\\"{x:1214,y:809,t:1527189653844};\\\", \\\"{x:1215,y:805,t:1527189653860};\\\", \\\"{x:1216,y:800,t:1527189653877};\\\", \\\"{x:1216,y:796,t:1527189653893};\\\", \\\"{x:1218,y:792,t:1527189653910};\\\", \\\"{x:1218,y:786,t:1527189653927};\\\", \\\"{x:1218,y:781,t:1527189653943};\\\", \\\"{x:1220,y:775,t:1527189653960};\\\", \\\"{x:1222,y:770,t:1527189653978};\\\", \\\"{x:1222,y:763,t:1527189653994};\\\", \\\"{x:1225,y:757,t:1527189654011};\\\", \\\"{x:1225,y:750,t:1527189654027};\\\", \\\"{x:1225,y:743,t:1527189654043};\\\", \\\"{x:1225,y:740,t:1527189654060};\\\", \\\"{x:1226,y:736,t:1527189654078};\\\", \\\"{x:1228,y:734,t:1527189654094};\\\", \\\"{x:1228,y:730,t:1527189654110};\\\", \\\"{x:1228,y:727,t:1527189654127};\\\", \\\"{x:1228,y:725,t:1527189654144};\\\", \\\"{x:1228,y:721,t:1527189654161};\\\", \\\"{x:1228,y:718,t:1527189654177};\\\", \\\"{x:1227,y:714,t:1527189654194};\\\", \\\"{x:1227,y:712,t:1527189654210};\\\", \\\"{x:1225,y:709,t:1527189654227};\\\", \\\"{x:1225,y:712,t:1527189654380};\\\", \\\"{x:1224,y:717,t:1527189654395};\\\", \\\"{x:1220,y:729,t:1527189654411};\\\", \\\"{x:1219,y:739,t:1527189654427};\\\", \\\"{x:1218,y:742,t:1527189654444};\\\", \\\"{x:1217,y:745,t:1527189654462};\\\", \\\"{x:1217,y:746,t:1527189654477};\\\", \\\"{x:1216,y:748,t:1527189654494};\\\", \\\"{x:1216,y:749,t:1527189654511};\\\", \\\"{x:1215,y:752,t:1527189654527};\\\", \\\"{x:1215,y:756,t:1527189654544};\\\", \\\"{x:1212,y:760,t:1527189654561};\\\", \\\"{x:1212,y:764,t:1527189654578};\\\", \\\"{x:1211,y:766,t:1527189654595};\\\", \\\"{x:1207,y:770,t:1527189654611};\\\", \\\"{x:1206,y:774,t:1527189654627};\\\", \\\"{x:1205,y:778,t:1527189654644};\\\", \\\"{x:1204,y:782,t:1527189654661};\\\", \\\"{x:1204,y:788,t:1527189654677};\\\", \\\"{x:1204,y:793,t:1527189654694};\\\", \\\"{x:1204,y:799,t:1527189654711};\\\", \\\"{x:1204,y:803,t:1527189654728};\\\", \\\"{x:1204,y:809,t:1527189654745};\\\", \\\"{x:1204,y:815,t:1527189654762};\\\", \\\"{x:1204,y:822,t:1527189654778};\\\", \\\"{x:1206,y:826,t:1527189654795};\\\", \\\"{x:1207,y:830,t:1527189654811};\\\", \\\"{x:1207,y:832,t:1527189654836};\\\", \\\"{x:1207,y:833,t:1527189654851};\\\", \\\"{x:1207,y:834,t:1527189654907};\\\", \\\"{x:1208,y:835,t:1527189654996};\\\", \\\"{x:1209,y:835,t:1527189655011};\\\", \\\"{x:1211,y:835,t:1527189655035};\\\", \\\"{x:1211,y:834,t:1527189656228};\\\", \\\"{x:1217,y:832,t:1527189656246};\\\", \\\"{x:1224,y:832,t:1527189656263};\\\", \\\"{x:1227,y:832,t:1527189656280};\\\", \\\"{x:1228,y:832,t:1527189656356};\\\", \\\"{x:1229,y:832,t:1527189656371};\\\", \\\"{x:1231,y:832,t:1527189656379};\\\", \\\"{x:1235,y:830,t:1527189656397};\\\", \\\"{x:1238,y:830,t:1527189656412};\\\", \\\"{x:1242,y:830,t:1527189656429};\\\", \\\"{x:1244,y:830,t:1527189656446};\\\", \\\"{x:1248,y:830,t:1527189656462};\\\", \\\"{x:1252,y:830,t:1527189656479};\\\", \\\"{x:1258,y:829,t:1527189656497};\\\", \\\"{x:1263,y:829,t:1527189656513};\\\", \\\"{x:1268,y:829,t:1527189656529};\\\", \\\"{x:1270,y:829,t:1527189656546};\\\", \\\"{x:1273,y:828,t:1527189656563};\\\", \\\"{x:1276,y:828,t:1527189656580};\\\", \\\"{x:1277,y:828,t:1527189656596};\\\", \\\"{x:1278,y:828,t:1527189656613};\\\", \\\"{x:1279,y:828,t:1527189656635};\\\", \\\"{x:1280,y:827,t:1527189656646};\\\", \\\"{x:1281,y:827,t:1527189656663};\\\", \\\"{x:1282,y:826,t:1527189656679};\\\", \\\"{x:1286,y:826,t:1527189657293};\\\", \\\"{x:1288,y:826,t:1527189657299};\\\", \\\"{x:1291,y:826,t:1527189657313};\\\", \\\"{x:1300,y:826,t:1527189657331};\\\", \\\"{x:1308,y:826,t:1527189657347};\\\", \\\"{x:1312,y:826,t:1527189657363};\\\", \\\"{x:1313,y:826,t:1527189657379};\\\", \\\"{x:1314,y:826,t:1527189657397};\\\", \\\"{x:1316,y:825,t:1527189657571};\\\", \\\"{x:1319,y:825,t:1527189657580};\\\", \\\"{x:1325,y:825,t:1527189657596};\\\", \\\"{x:1332,y:822,t:1527189657614};\\\", \\\"{x:1338,y:822,t:1527189657629};\\\", \\\"{x:1340,y:822,t:1527189657647};\\\", \\\"{x:1342,y:822,t:1527189657664};\\\", \\\"{x:1343,y:822,t:1527189657680};\\\", \\\"{x:1345,y:822,t:1527189658388};\\\", \\\"{x:1348,y:822,t:1527189658399};\\\", \\\"{x:1352,y:822,t:1527189658415};\\\", \\\"{x:1356,y:822,t:1527189658432};\\\", \\\"{x:1363,y:822,t:1527189658448};\\\", \\\"{x:1366,y:822,t:1527189658465};\\\", \\\"{x:1368,y:822,t:1527189658482};\\\", \\\"{x:1369,y:822,t:1527189658499};\\\", \\\"{x:1371,y:822,t:1527189658514};\\\", \\\"{x:1375,y:822,t:1527189658531};\\\", \\\"{x:1379,y:823,t:1527189658548};\\\", \\\"{x:1385,y:823,t:1527189658565};\\\", \\\"{x:1387,y:823,t:1527189658581};\\\", \\\"{x:1389,y:823,t:1527189658597};\\\", \\\"{x:1391,y:824,t:1527189658615};\\\", \\\"{x:1394,y:824,t:1527189658631};\\\", \\\"{x:1398,y:824,t:1527189658648};\\\", \\\"{x:1405,y:824,t:1527189658665};\\\", \\\"{x:1412,y:826,t:1527189658681};\\\", \\\"{x:1416,y:826,t:1527189658698};\\\", \\\"{x:1419,y:827,t:1527189658844};\\\", \\\"{x:1420,y:827,t:1527189658859};\\\", \\\"{x:1423,y:827,t:1527189658867};\\\", \\\"{x:1425,y:828,t:1527189658881};\\\", \\\"{x:1431,y:828,t:1527189658898};\\\", \\\"{x:1436,y:830,t:1527189658916};\\\", \\\"{x:1441,y:831,t:1527189658931};\\\", \\\"{x:1443,y:831,t:1527189658963};\\\", \\\"{x:1445,y:831,t:1527189658972};\\\", \\\"{x:1447,y:831,t:1527189658981};\\\", \\\"{x:1450,y:831,t:1527189658999};\\\", \\\"{x:1452,y:831,t:1527189659015};\\\", \\\"{x:1453,y:831,t:1527189659033};\\\", \\\"{x:1454,y:831,t:1527189659083};\\\", \\\"{x:1455,y:831,t:1527189659107};\\\", \\\"{x:1456,y:831,t:1527189659147};\\\", \\\"{x:1462,y:830,t:1527189659166};\\\", \\\"{x:1468,y:828,t:1527189659183};\\\", \\\"{x:1471,y:828,t:1527189659199};\\\", \\\"{x:1475,y:826,t:1527189659216};\\\", \\\"{x:1476,y:826,t:1527189659233};\\\", \\\"{x:1475,y:825,t:1527189659419};\\\", \\\"{x:1466,y:825,t:1527189659433};\\\", \\\"{x:1442,y:820,t:1527189659450};\\\", \\\"{x:1414,y:818,t:1527189659466};\\\", \\\"{x:1374,y:812,t:1527189659483};\\\", \\\"{x:1291,y:792,t:1527189659499};\\\", \\\"{x:1262,y:789,t:1527189659515};\\\", \\\"{x:1223,y:780,t:1527189659533};\\\", \\\"{x:1190,y:772,t:1527189659550};\\\", \\\"{x:1165,y:765,t:1527189659565};\\\", \\\"{x:1144,y:759,t:1527189659582};\\\", \\\"{x:1121,y:754,t:1527189659599};\\\", \\\"{x:1100,y:752,t:1527189659615};\\\", \\\"{x:1077,y:748,t:1527189659632};\\\", \\\"{x:1050,y:743,t:1527189659649};\\\", \\\"{x:1022,y:737,t:1527189659666};\\\", \\\"{x:982,y:732,t:1527189659682};\\\", \\\"{x:920,y:721,t:1527189659698};\\\", \\\"{x:878,y:711,t:1527189659715};\\\", \\\"{x:844,y:705,t:1527189659732};\\\", \\\"{x:820,y:697,t:1527189659749};\\\", \\\"{x:788,y:689,t:1527189659766};\\\", \\\"{x:758,y:681,t:1527189659782};\\\", \\\"{x:735,y:675,t:1527189659803};\\\", \\\"{x:705,y:668,t:1527189659820};\\\", \\\"{x:682,y:662,t:1527189659835};\\\", \\\"{x:658,y:658,t:1527189659853};\\\", \\\"{x:628,y:649,t:1527189659871};\\\", \\\"{x:614,y:645,t:1527189659885};\\\", \\\"{x:579,y:629,t:1527189659920};\\\", \\\"{x:575,y:628,t:1527189659933};\\\", \\\"{x:549,y:620,t:1527189659949};\\\", \\\"{x:536,y:615,t:1527189659967};\\\", \\\"{x:529,y:611,t:1527189659985};\\\", \\\"{x:523,y:608,t:1527189660000};\\\", \\\"{x:515,y:603,t:1527189660017};\\\", \\\"{x:513,y:602,t:1527189660033};\\\", \\\"{x:505,y:598,t:1527189660050};\\\", \\\"{x:494,y:594,t:1527189660068};\\\", \\\"{x:480,y:589,t:1527189660084};\\\", \\\"{x:465,y:588,t:1527189660100};\\\", \\\"{x:460,y:587,t:1527189660117};\\\", \\\"{x:458,y:587,t:1527189660133};\\\", \\\"{x:453,y:587,t:1527189660150};\\\", \\\"{x:451,y:588,t:1527189660167};\\\", \\\"{x:450,y:588,t:1527189660197};\\\", \\\"{x:449,y:588,t:1527189660287};\\\", \\\"{x:448,y:589,t:1527189660310};\\\", \\\"{x:448,y:590,t:1527189660318};\\\", \\\"{x:446,y:596,t:1527189660334};\\\", \\\"{x:445,y:600,t:1527189660350};\\\", \\\"{x:445,y:601,t:1527189660367};\\\", \\\"{x:445,y:602,t:1527189660389};\\\", \\\"{x:443,y:603,t:1527189660401};\\\", \\\"{x:447,y:603,t:1527189660510};\\\", \\\"{x:452,y:603,t:1527189660518};\\\", \\\"{x:455,y:603,t:1527189660535};\\\", \\\"{x:464,y:603,t:1527189660551};\\\", \\\"{x:484,y:601,t:1527189660568};\\\", \\\"{x:510,y:599,t:1527189660585};\\\", \\\"{x:543,y:599,t:1527189660601};\\\", \\\"{x:572,y:599,t:1527189660617};\\\", \\\"{x:593,y:599,t:1527189660634};\\\", \\\"{x:610,y:599,t:1527189660652};\\\", \\\"{x:623,y:599,t:1527189660667};\\\", \\\"{x:634,y:601,t:1527189660684};\\\", \\\"{x:641,y:602,t:1527189660702};\\\", \\\"{x:642,y:602,t:1527189660717};\\\", \\\"{x:638,y:602,t:1527189660951};\\\", \\\"{x:626,y:597,t:1527189660969};\\\", \\\"{x:615,y:595,t:1527189660984};\\\", \\\"{x:604,y:591,t:1527189661002};\\\", \\\"{x:598,y:589,t:1527189661019};\\\", \\\"{x:597,y:589,t:1527189661034};\\\", \\\"{x:598,y:589,t:1527189661197};\\\", \\\"{x:599,y:589,t:1527189661206};\\\", \\\"{x:601,y:589,t:1527189661218};\\\", \\\"{x:602,y:589,t:1527189661234};\\\", \\\"{x:603,y:590,t:1527189661251};\\\", \\\"{x:604,y:590,t:1527189661268};\\\", \\\"{x:604,y:591,t:1527189661325};\\\", \\\"{x:609,y:591,t:1527189663975};\\\", \\\"{x:619,y:596,t:1527189663987};\\\", \\\"{x:655,y:613,t:1527189664005};\\\", \\\"{x:702,y:631,t:1527189664022};\\\", \\\"{x:772,y:663,t:1527189664038};\\\", \\\"{x:874,y:715,t:1527189664069};\\\", \\\"{x:904,y:739,t:1527189664087};\\\", \\\"{x:938,y:763,t:1527189664102};\\\", \\\"{x:967,y:791,t:1527189664119};\\\", \\\"{x:972,y:797,t:1527189664136};\\\", \\\"{x:994,y:829,t:1527189664153};\\\", \\\"{x:1015,y:860,t:1527189664169};\\\", \\\"{x:1028,y:882,t:1527189664186};\\\", \\\"{x:1054,y:922,t:1527189664203};\\\", \\\"{x:1067,y:941,t:1527189664220};\\\", \\\"{x:1083,y:961,t:1527189664236};\\\", \\\"{x:1108,y:998,t:1527189664254};\\\", \\\"{x:1121,y:1017,t:1527189664270};\\\", \\\"{x:1136,y:1033,t:1527189664287};\\\", \\\"{x:1152,y:1058,t:1527189664304};\\\", \\\"{x:1169,y:1077,t:1527189664319};\\\", \\\"{x:1193,y:1113,t:1527189664336};\\\", \\\"{x:1224,y:1158,t:1527189664354};\\\", \\\"{x:1265,y:1190,t:1527189664370};\\\", \\\"{x:1287,y:1199,t:1527189664386};\\\", \\\"{x:1314,y:1199,t:1527189664404};\\\", \\\"{x:1336,y:1199,t:1527189664421};\\\", \\\"{x:1348,y:1199,t:1527189664437};\\\", \\\"{x:1362,y:1199,t:1527189664455};\\\", \\\"{x:1374,y:1199,t:1527189664471};\\\", \\\"{x:1379,y:1199,t:1527189664487};\\\", \\\"{x:1381,y:1196,t:1527189664533};\\\", \\\"{x:1381,y:1186,t:1527189664542};\\\", \\\"{x:1383,y:1178,t:1527189664555};\\\", \\\"{x:1383,y:1154,t:1527189664571};\\\", \\\"{x:1384,y:1133,t:1527189664588};\\\", \\\"{x:1384,y:1110,t:1527189664605};\\\", \\\"{x:1384,y:1093,t:1527189664620};\\\", \\\"{x:1377,y:1063,t:1527189664638};\\\", \\\"{x:1373,y:1050,t:1527189664654};\\\", \\\"{x:1363,y:1040,t:1527189664671};\\\", \\\"{x:1353,y:1029,t:1527189664687};\\\", \\\"{x:1342,y:1014,t:1527189664705};\\\", \\\"{x:1332,y:999,t:1527189664721};\\\", \\\"{x:1326,y:988,t:1527189664737};\\\", \\\"{x:1321,y:981,t:1527189664754};\\\", \\\"{x:1317,y:976,t:1527189664771};\\\", \\\"{x:1314,y:974,t:1527189664787};\\\", \\\"{x:1302,y:968,t:1527189664805};\\\", \\\"{x:1291,y:961,t:1527189664821};\\\", \\\"{x:1280,y:952,t:1527189664838};\\\", \\\"{x:1266,y:941,t:1527189664855};\\\", \\\"{x:1252,y:931,t:1527189664871};\\\", \\\"{x:1244,y:926,t:1527189664888};\\\", \\\"{x:1234,y:915,t:1527189664904};\\\", \\\"{x:1231,y:907,t:1527189664922};\\\", \\\"{x:1226,y:899,t:1527189664937};\\\", \\\"{x:1221,y:894,t:1527189664955};\\\", \\\"{x:1217,y:887,t:1527189664972};\\\", \\\"{x:1215,y:883,t:1527189664987};\\\", \\\"{x:1213,y:880,t:1527189665004};\\\", \\\"{x:1212,y:878,t:1527189665022};\\\", \\\"{x:1212,y:877,t:1527189665062};\\\", \\\"{x:1212,y:876,t:1527189665072};\\\", \\\"{x:1210,y:868,t:1527189665088};\\\", \\\"{x:1209,y:864,t:1527189665104};\\\", \\\"{x:1209,y:863,t:1527189665122};\\\", \\\"{x:1209,y:862,t:1527189665142};\\\", \\\"{x:1210,y:861,t:1527189665174};\\\", \\\"{x:1210,y:860,t:1527189665188};\\\", \\\"{x:1210,y:858,t:1527189665205};\\\", \\\"{x:1212,y:853,t:1527189665222};\\\", \\\"{x:1213,y:851,t:1527189665238};\\\", \\\"{x:1214,y:850,t:1527189665262};\\\", \\\"{x:1214,y:849,t:1527189665310};\\\", \\\"{x:1214,y:848,t:1527189665343};\\\", \\\"{x:1215,y:847,t:1527189665494};\\\", \\\"{x:1216,y:846,t:1527189665504};\\\", \\\"{x:1217,y:845,t:1527189665522};\\\", \\\"{x:1220,y:845,t:1527189665539};\\\", \\\"{x:1229,y:845,t:1527189665554};\\\", \\\"{x:1242,y:845,t:1527189665571};\\\", \\\"{x:1256,y:845,t:1527189665588};\\\", \\\"{x:1267,y:845,t:1527189665604};\\\", \\\"{x:1282,y:845,t:1527189665622};\\\", \\\"{x:1287,y:844,t:1527189665638};\\\", \\\"{x:1291,y:844,t:1527189665655};\\\", \\\"{x:1294,y:844,t:1527189665671};\\\", \\\"{x:1296,y:844,t:1527189665689};\\\", \\\"{x:1297,y:844,t:1527189665704};\\\", \\\"{x:1298,y:843,t:1527189665895};\\\", \\\"{x:1300,y:841,t:1527189665905};\\\", \\\"{x:1305,y:841,t:1527189665922};\\\", \\\"{x:1312,y:841,t:1527189665939};\\\", \\\"{x:1318,y:841,t:1527189665956};\\\", \\\"{x:1321,y:841,t:1527189665972};\\\", \\\"{x:1322,y:841,t:1527189665988};\\\", \\\"{x:1324,y:840,t:1527189666006};\\\", \\\"{x:1324,y:839,t:1527189666029};\\\", \\\"{x:1326,y:839,t:1527189666039};\\\", \\\"{x:1328,y:839,t:1527189666061};\\\", \\\"{x:1330,y:838,t:1527189666071};\\\", \\\"{x:1335,y:837,t:1527189666088};\\\", \\\"{x:1338,y:837,t:1527189666105};\\\", \\\"{x:1341,y:834,t:1527189666121};\\\", \\\"{x:1343,y:834,t:1527189666139};\\\", \\\"{x:1344,y:833,t:1527189666174};\\\", \\\"{x:1340,y:838,t:1527189669551};\\\", \\\"{x:1338,y:843,t:1527189669558};\\\", \\\"{x:1331,y:851,t:1527189669575};\\\", \\\"{x:1327,y:858,t:1527189669591};\\\", \\\"{x:1321,y:864,t:1527189669608};\\\", \\\"{x:1317,y:869,t:1527189669626};\\\", \\\"{x:1313,y:874,t:1527189669641};\\\", \\\"{x:1307,y:883,t:1527189669658};\\\", \\\"{x:1302,y:888,t:1527189669676};\\\", \\\"{x:1298,y:896,t:1527189669691};\\\", \\\"{x:1292,y:903,t:1527189669709};\\\", \\\"{x:1282,y:915,t:1527189669725};\\\", \\\"{x:1276,y:919,t:1527189669741};\\\", \\\"{x:1270,y:923,t:1527189669758};\\\", \\\"{x:1262,y:928,t:1527189669775};\\\", \\\"{x:1256,y:931,t:1527189669791};\\\", \\\"{x:1248,y:937,t:1527189669808};\\\", \\\"{x:1239,y:943,t:1527189669825};\\\", \\\"{x:1231,y:951,t:1527189669841};\\\", \\\"{x:1228,y:955,t:1527189669858};\\\", \\\"{x:1225,y:958,t:1527189669875};\\\", \\\"{x:1225,y:961,t:1527189669891};\\\", \\\"{x:1223,y:961,t:1527189669908};\\\", \\\"{x:1223,y:962,t:1527189669942};\\\", \\\"{x:1223,y:959,t:1527189670206};\\\", \\\"{x:1223,y:955,t:1527189670214};\\\", \\\"{x:1223,y:950,t:1527189670225};\\\", \\\"{x:1226,y:942,t:1527189670242};\\\", \\\"{x:1226,y:938,t:1527189670258};\\\", \\\"{x:1226,y:933,t:1527189670275};\\\", \\\"{x:1228,y:929,t:1527189670292};\\\", \\\"{x:1229,y:923,t:1527189670308};\\\", \\\"{x:1230,y:916,t:1527189670325};\\\", \\\"{x:1231,y:899,t:1527189670341};\\\", \\\"{x:1231,y:893,t:1527189670357};\\\", \\\"{x:1231,y:886,t:1527189670375};\\\", \\\"{x:1231,y:884,t:1527189670391};\\\", \\\"{x:1232,y:883,t:1527189670407};\\\", \\\"{x:1233,y:881,t:1527189670424};\\\", \\\"{x:1233,y:880,t:1527189670441};\\\", \\\"{x:1233,y:878,t:1527189670458};\\\", \\\"{x:1233,y:875,t:1527189670475};\\\", \\\"{x:1233,y:869,t:1527189670491};\\\", \\\"{x:1233,y:863,t:1527189670507};\\\", \\\"{x:1233,y:859,t:1527189670525};\\\", \\\"{x:1231,y:855,t:1527189670542};\\\", \\\"{x:1231,y:853,t:1527189670558};\\\", \\\"{x:1230,y:848,t:1527189670575};\\\", \\\"{x:1229,y:845,t:1527189670592};\\\", \\\"{x:1228,y:842,t:1527189670608};\\\", \\\"{x:1228,y:841,t:1527189670630};\\\", \\\"{x:1228,y:840,t:1527189670655};\\\", \\\"{x:1228,y:839,t:1527189670663};\\\", \\\"{x:1228,y:838,t:1527189670678};\\\", \\\"{x:1228,y:837,t:1527189670692};\\\", \\\"{x:1226,y:834,t:1527189670709};\\\", \\\"{x:1226,y:832,t:1527189670725};\\\", \\\"{x:1225,y:829,t:1527189670742};\\\", \\\"{x:1225,y:827,t:1527189671183};\\\", \\\"{x:1225,y:826,t:1527189671192};\\\", \\\"{x:1223,y:825,t:1527189671210};\\\", \\\"{x:1222,y:824,t:1527189671226};\\\", \\\"{x:1221,y:824,t:1527189671607};\\\", \\\"{x:1219,y:831,t:1527189671615};\\\", \\\"{x:1218,y:841,t:1527189671627};\\\", \\\"{x:1214,y:860,t:1527189671642};\\\", \\\"{x:1210,y:881,t:1527189671659};\\\", \\\"{x:1208,y:895,t:1527189671676};\\\", \\\"{x:1208,y:904,t:1527189671692};\\\", \\\"{x:1208,y:912,t:1527189671709};\\\", \\\"{x:1208,y:918,t:1527189671727};\\\", \\\"{x:1208,y:924,t:1527189671743};\\\", \\\"{x:1208,y:931,t:1527189671760};\\\", \\\"{x:1208,y:938,t:1527189671777};\\\", \\\"{x:1208,y:942,t:1527189671793};\\\", \\\"{x:1208,y:945,t:1527189671809};\\\", \\\"{x:1208,y:947,t:1527189671826};\\\", \\\"{x:1208,y:949,t:1527189671895};\\\", \\\"{x:1207,y:949,t:1527189671910};\\\", \\\"{x:1207,y:952,t:1527189671926};\\\", \\\"{x:1207,y:953,t:1527189671950};\\\", \\\"{x:1207,y:954,t:1527189671959};\\\", \\\"{x:1207,y:955,t:1527189671976};\\\", \\\"{x:1207,y:956,t:1527189672030};\\\", \\\"{x:1207,y:955,t:1527189672294};\\\", \\\"{x:1207,y:953,t:1527189672318};\\\", \\\"{x:1207,y:952,t:1527189672463};\\\", \\\"{x:1207,y:950,t:1527189672476};\\\", \\\"{x:1207,y:945,t:1527189672493};\\\", \\\"{x:1207,y:934,t:1527189672510};\\\", \\\"{x:1207,y:926,t:1527189672526};\\\", \\\"{x:1207,y:920,t:1527189672543};\\\", \\\"{x:1207,y:911,t:1527189672560};\\\", \\\"{x:1205,y:904,t:1527189672576};\\\", \\\"{x:1205,y:891,t:1527189672594};\\\", \\\"{x:1207,y:879,t:1527189672611};\\\", \\\"{x:1209,y:872,t:1527189672627};\\\", \\\"{x:1210,y:867,t:1527189672643};\\\", \\\"{x:1210,y:863,t:1527189672660};\\\", \\\"{x:1210,y:859,t:1527189672677};\\\", \\\"{x:1210,y:856,t:1527189672693};\\\", \\\"{x:1210,y:850,t:1527189672710};\\\", \\\"{x:1211,y:846,t:1527189672727};\\\", \\\"{x:1211,y:838,t:1527189672743};\\\", \\\"{x:1213,y:834,t:1527189672761};\\\", \\\"{x:1213,y:831,t:1527189672778};\\\", \\\"{x:1213,y:828,t:1527189672793};\\\", \\\"{x:1215,y:823,t:1527189672817};\\\", \\\"{x:1216,y:822,t:1527189672827};\\\", \\\"{x:1216,y:820,t:1527189672842};\\\", \\\"{x:1217,y:818,t:1527189672869};\\\", \\\"{x:1216,y:818,t:1527189673166};\\\", \\\"{x:1215,y:821,t:1527189673189};\\\", \\\"{x:1215,y:823,t:1527189673213};\\\", \\\"{x:1215,y:824,t:1527189673638};\\\", \\\"{x:1215,y:826,t:1527189673663};\\\", \\\"{x:1215,y:828,t:1527189673694};\\\", \\\"{x:1214,y:830,t:1527189673710};\\\", \\\"{x:1216,y:831,t:1527189677637};\\\", \\\"{x:1226,y:832,t:1527189677646};\\\", \\\"{x:1241,y:836,t:1527189677663};\\\", \\\"{x:1253,y:837,t:1527189677680};\\\", \\\"{x:1267,y:841,t:1527189677695};\\\", \\\"{x:1280,y:844,t:1527189677712};\\\", \\\"{x:1284,y:844,t:1527189677729};\\\", \\\"{x:1286,y:844,t:1527189677746};\\\", \\\"{x:1289,y:844,t:1527189677763};\\\", \\\"{x:1290,y:844,t:1527189677780};\\\", \\\"{x:1292,y:844,t:1527189677796};\\\", \\\"{x:1293,y:844,t:1527189677813};\\\", \\\"{x:1296,y:844,t:1527189677830};\\\", \\\"{x:1298,y:844,t:1527189677846};\\\", \\\"{x:1301,y:844,t:1527189677863};\\\", \\\"{x:1302,y:845,t:1527189677976};\\\", \\\"{x:1305,y:845,t:1527189677991};\\\", \\\"{x:1306,y:845,t:1527189678006};\\\", \\\"{x:1307,y:845,t:1527189678014};\\\", \\\"{x:1311,y:845,t:1527189678030};\\\", \\\"{x:1319,y:846,t:1527189678047};\\\", \\\"{x:1325,y:846,t:1527189678064};\\\", \\\"{x:1333,y:847,t:1527189678080};\\\", \\\"{x:1337,y:848,t:1527189678098};\\\", \\\"{x:1342,y:849,t:1527189678114};\\\", \\\"{x:1344,y:849,t:1527189678131};\\\", \\\"{x:1345,y:848,t:1527189678148};\\\", \\\"{x:1346,y:848,t:1527189680015};\\\", \\\"{x:1346,y:851,t:1527189680031};\\\", \\\"{x:1343,y:855,t:1527189680049};\\\", \\\"{x:1343,y:858,t:1527189680066};\\\", \\\"{x:1341,y:859,t:1527189680082};\\\", \\\"{x:1341,y:862,t:1527189680255};\\\", \\\"{x:1341,y:863,t:1527189680266};\\\", \\\"{x:1341,y:865,t:1527189680281};\\\", \\\"{x:1341,y:868,t:1527189680298};\\\", \\\"{x:1341,y:871,t:1527189680315};\\\", \\\"{x:1341,y:873,t:1527189680331};\\\", \\\"{x:1341,y:874,t:1527189680349};\\\", \\\"{x:1341,y:876,t:1527189680365};\\\", \\\"{x:1341,y:877,t:1527189680405};\\\", \\\"{x:1341,y:878,t:1527189680453};\\\", \\\"{x:1341,y:879,t:1527189680465};\\\", \\\"{x:1341,y:880,t:1527189680482};\\\", \\\"{x:1341,y:882,t:1527189680498};\\\", \\\"{x:1341,y:884,t:1527189680515};\\\", \\\"{x:1341,y:887,t:1527189680532};\\\", \\\"{x:1341,y:888,t:1527189680548};\\\", \\\"{x:1341,y:890,t:1527189680574};\\\", \\\"{x:1341,y:891,t:1527189680597};\\\", \\\"{x:1341,y:893,t:1527189680616};\\\", \\\"{x:1341,y:897,t:1527189680632};\\\", \\\"{x:1341,y:899,t:1527189680648};\\\", \\\"{x:1341,y:901,t:1527189680665};\\\", \\\"{x:1342,y:903,t:1527189680766};\\\", \\\"{x:1342,y:904,t:1527189680783};\\\", \\\"{x:1342,y:901,t:1527189681062};\\\", \\\"{x:1342,y:899,t:1527189681070};\\\", \\\"{x:1341,y:896,t:1527189681082};\\\", \\\"{x:1341,y:893,t:1527189681099};\\\", \\\"{x:1340,y:891,t:1527189681115};\\\", \\\"{x:1339,y:886,t:1527189681133};\\\", \\\"{x:1340,y:879,t:1527189681149};\\\", \\\"{x:1342,y:869,t:1527189681165};\\\", \\\"{x:1343,y:859,t:1527189681182};\\\", \\\"{x:1345,y:853,t:1527189681199};\\\", \\\"{x:1346,y:847,t:1527189681216};\\\", \\\"{x:1346,y:842,t:1527189681233};\\\", \\\"{x:1346,y:840,t:1527189681250};\\\", \\\"{x:1345,y:836,t:1527189681871};\\\", \\\"{x:1344,y:834,t:1527189681883};\\\", \\\"{x:1342,y:828,t:1527189681899};\\\", \\\"{x:1341,y:825,t:1527189681917};\\\", \\\"{x:1340,y:822,t:1527189681932};\\\", \\\"{x:1339,y:822,t:1527189681950};\\\", \\\"{x:1339,y:820,t:1527189681975};\\\", \\\"{x:1339,y:818,t:1527189681982};\\\", \\\"{x:1338,y:811,t:1527189682000};\\\", \\\"{x:1337,y:803,t:1527189682017};\\\", \\\"{x:1336,y:794,t:1527189682033};\\\", \\\"{x:1333,y:785,t:1527189682050};\\\", \\\"{x:1332,y:780,t:1527189682066};\\\", \\\"{x:1332,y:774,t:1527189682083};\\\", \\\"{x:1332,y:766,t:1527189682100};\\\", \\\"{x:1333,y:760,t:1527189682117};\\\", \\\"{x:1334,y:746,t:1527189682134};\\\", \\\"{x:1333,y:728,t:1527189682150};\\\", \\\"{x:1333,y:718,t:1527189682166};\\\", \\\"{x:1333,y:710,t:1527189682184};\\\", \\\"{x:1333,y:704,t:1527189682200};\\\", \\\"{x:1333,y:701,t:1527189682216};\\\", \\\"{x:1333,y:699,t:1527189682326};\\\", \\\"{x:1334,y:697,t:1527189682334};\\\", \\\"{x:1334,y:695,t:1527189682350};\\\", \\\"{x:1334,y:694,t:1527189682366};\\\", \\\"{x:1334,y:691,t:1527189682384};\\\", \\\"{x:1334,y:687,t:1527189682400};\\\", \\\"{x:1334,y:680,t:1527189682417};\\\", \\\"{x:1334,y:674,t:1527189682433};\\\", \\\"{x:1334,y:669,t:1527189682450};\\\", \\\"{x:1334,y:661,t:1527189682467};\\\", \\\"{x:1334,y:654,t:1527189682484};\\\", \\\"{x:1334,y:648,t:1527189682500};\\\", \\\"{x:1334,y:642,t:1527189682517};\\\", \\\"{x:1334,y:632,t:1527189682534};\\\", \\\"{x:1335,y:628,t:1527189682550};\\\", \\\"{x:1337,y:625,t:1527189682566};\\\", \\\"{x:1339,y:617,t:1527189682583};\\\", \\\"{x:1339,y:611,t:1527189682599};\\\", \\\"{x:1339,y:607,t:1527189682617};\\\", \\\"{x:1341,y:603,t:1527189682634};\\\", \\\"{x:1341,y:597,t:1527189682650};\\\", \\\"{x:1341,y:595,t:1527189682666};\\\", \\\"{x:1341,y:590,t:1527189682684};\\\", \\\"{x:1341,y:586,t:1527189682701};\\\", \\\"{x:1342,y:584,t:1527189682717};\\\", \\\"{x:1345,y:578,t:1527189682734};\\\", \\\"{x:1346,y:576,t:1527189682750};\\\", \\\"{x:1346,y:573,t:1527189682766};\\\", \\\"{x:1346,y:570,t:1527189682784};\\\", \\\"{x:1346,y:567,t:1527189682807};\\\", \\\"{x:1346,y:563,t:1527189682822};\\\", \\\"{x:1346,y:562,t:1527189682834};\\\", \\\"{x:1346,y:561,t:1527189682850};\\\", \\\"{x:1346,y:559,t:1527189682867};\\\", \\\"{x:1346,y:558,t:1527189682884};\\\", \\\"{x:1346,y:557,t:1527189682901};\\\", \\\"{x:1346,y:556,t:1527189682918};\\\", \\\"{x:1346,y:561,t:1527189683262};\\\", \\\"{x:1345,y:567,t:1527189683270};\\\", \\\"{x:1342,y:576,t:1527189683283};\\\", \\\"{x:1334,y:589,t:1527189683301};\\\", \\\"{x:1306,y:616,t:1527189683318};\\\", \\\"{x:1289,y:628,t:1527189683334};\\\", \\\"{x:1273,y:639,t:1527189683350};\\\", \\\"{x:1247,y:654,t:1527189683368};\\\", \\\"{x:1222,y:661,t:1527189683384};\\\", \\\"{x:1197,y:671,t:1527189683400};\\\", \\\"{x:1160,y:681,t:1527189683418};\\\", \\\"{x:1123,y:700,t:1527189683434};\\\", \\\"{x:1056,y:722,t:1527189683450};\\\", \\\"{x:1001,y:737,t:1527189683468};\\\", \\\"{x:952,y:746,t:1527189683484};\\\", \\\"{x:913,y:757,t:1527189683500};\\\", \\\"{x:872,y:765,t:1527189683517};\\\", \\\"{x:849,y:769,t:1527189683534};\\\", \\\"{x:829,y:773,t:1527189683551};\\\", \\\"{x:813,y:778,t:1527189683568};\\\", \\\"{x:806,y:783,t:1527189683584};\\\", \\\"{x:800,y:783,t:1527189683601};\\\", \\\"{x:792,y:783,t:1527189683618};\\\", \\\"{x:781,y:783,t:1527189683634};\\\", \\\"{x:770,y:782,t:1527189683651};\\\", \\\"{x:747,y:778,t:1527189683667};\\\", \\\"{x:730,y:777,t:1527189683683};\\\", \\\"{x:706,y:770,t:1527189683700};\\\", \\\"{x:680,y:761,t:1527189683717};\\\", \\\"{x:651,y:756,t:1527189683734};\\\", \\\"{x:622,y:747,t:1527189683751};\\\", \\\"{x:585,y:737,t:1527189683767};\\\", \\\"{x:548,y:723,t:1527189683785};\\\", \\\"{x:521,y:715,t:1527189683800};\\\", \\\"{x:495,y:709,t:1527189683817};\\\", \\\"{x:458,y:695,t:1527189683836};\\\", \\\"{x:415,y:680,t:1527189683852};\\\", \\\"{x:400,y:673,t:1527189683870};\\\", \\\"{x:371,y:660,t:1527189683886};\\\", \\\"{x:341,y:651,t:1527189683903};\\\", \\\"{x:305,y:639,t:1527189683920};\\\", \\\"{x:289,y:634,t:1527189683936};\\\", \\\"{x:274,y:630,t:1527189683953};\\\", \\\"{x:255,y:624,t:1527189683971};\\\", \\\"{x:254,y:624,t:1527189683986};\\\", \\\"{x:253,y:624,t:1527189684003};\\\", \\\"{x:253,y:622,t:1527189684102};\\\", \\\"{x:251,y:620,t:1527189684110};\\\", \\\"{x:248,y:618,t:1527189684122};\\\", \\\"{x:241,y:615,t:1527189684137};\\\", \\\"{x:233,y:610,t:1527189684154};\\\", \\\"{x:226,y:606,t:1527189684171};\\\", \\\"{x:220,y:602,t:1527189684187};\\\", \\\"{x:218,y:599,t:1527189684203};\\\", \\\"{x:216,y:596,t:1527189684220};\\\", \\\"{x:215,y:592,t:1527189684237};\\\", \\\"{x:214,y:592,t:1527189684462};\\\", \\\"{x:213,y:590,t:1527189684470};\\\", \\\"{x:210,y:585,t:1527189684487};\\\", \\\"{x:209,y:582,t:1527189684504};\\\", \\\"{x:202,y:580,t:1527189684522};\\\", \\\"{x:200,y:578,t:1527189684537};\\\", \\\"{x:195,y:577,t:1527189684553};\\\", \\\"{x:194,y:577,t:1527189684570};\\\", \\\"{x:190,y:575,t:1527189684586};\\\", \\\"{x:185,y:573,t:1527189684603};\\\", \\\"{x:181,y:571,t:1527189684619};\\\", \\\"{x:173,y:570,t:1527189684637};\\\", \\\"{x:172,y:569,t:1527189684654};\\\", \\\"{x:169,y:568,t:1527189684671};\\\", \\\"{x:167,y:567,t:1527189684687};\\\", \\\"{x:166,y:566,t:1527189684704};\\\", \\\"{x:168,y:566,t:1527189685053};\\\", \\\"{x:173,y:566,t:1527189685061};\\\", \\\"{x:179,y:570,t:1527189685071};\\\", \\\"{x:202,y:582,t:1527189685088};\\\", \\\"{x:217,y:592,t:1527189685104};\\\", \\\"{x:242,y:608,t:1527189685121};\\\", \\\"{x:265,y:620,t:1527189685138};\\\", \\\"{x:286,y:631,t:1527189685154};\\\", \\\"{x:308,y:649,t:1527189685171};\\\", \\\"{x:329,y:665,t:1527189685188};\\\", \\\"{x:363,y:680,t:1527189685204};\\\", \\\"{x:417,y:703,t:1527189685221};\\\", \\\"{x:437,y:712,t:1527189685237};\\\", \\\"{x:449,y:717,t:1527189685254};\\\", \\\"{x:452,y:719,t:1527189685271};\\\", \\\"{x:453,y:720,t:1527189685287};\\\", \\\"{x:455,y:720,t:1527189685342};\\\", \\\"{x:456,y:720,t:1527189685366};\\\", \\\"{x:458,y:720,t:1527189685421};\\\", \\\"{x:464,y:719,t:1527189685438};\\\", \\\"{x:471,y:716,t:1527189685454};\\\", \\\"{x:473,y:714,t:1527189685471};\\\", \\\"{x:474,y:713,t:1527189685487};\\\" ] }, { \\\"rt\\\": 19541, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 285857, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"F98S2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -03 PM-04 PM-1-Z -U -U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:480,y:710,t:1527189687966};\\\", \\\"{x:490,y:705,t:1527189687974};\\\", \\\"{x:514,y:700,t:1527189687990};\\\", \\\"{x:570,y:700,t:1527189688006};\\\", \\\"{x:623,y:700,t:1527189688023};\\\", \\\"{x:684,y:700,t:1527189688040};\\\", \\\"{x:765,y:700,t:1527189688056};\\\", \\\"{x:851,y:700,t:1527189688073};\\\", \\\"{x:915,y:700,t:1527189688090};\\\", \\\"{x:942,y:697,t:1527189688106};\\\", \\\"{x:964,y:697,t:1527189688123};\\\", \\\"{x:975,y:697,t:1527189688141};\\\", \\\"{x:981,y:697,t:1527189688156};\\\", \\\"{x:990,y:697,t:1527189688173};\\\", \\\"{x:999,y:697,t:1527189688190};\\\", \\\"{x:1007,y:696,t:1527189688206};\\\", \\\"{x:1028,y:697,t:1527189688223};\\\", \\\"{x:1042,y:698,t:1527189688241};\\\", \\\"{x:1055,y:700,t:1527189688257};\\\", \\\"{x:1074,y:700,t:1527189688273};\\\", \\\"{x:1093,y:704,t:1527189688291};\\\", \\\"{x:1107,y:707,t:1527189688306};\\\", \\\"{x:1120,y:709,t:1527189688323};\\\", \\\"{x:1130,y:712,t:1527189688341};\\\", \\\"{x:1137,y:715,t:1527189688357};\\\", \\\"{x:1150,y:719,t:1527189688373};\\\", \\\"{x:1156,y:723,t:1527189688391};\\\", \\\"{x:1163,y:723,t:1527189688406};\\\", \\\"{x:1171,y:724,t:1527189688423};\\\", \\\"{x:1177,y:727,t:1527189688441};\\\", \\\"{x:1182,y:728,t:1527189688457};\\\", \\\"{x:1184,y:729,t:1527189688474};\\\", \\\"{x:1189,y:731,t:1527189688491};\\\", \\\"{x:1192,y:732,t:1527189688507};\\\", \\\"{x:1194,y:733,t:1527189688524};\\\", \\\"{x:1199,y:734,t:1527189688541};\\\", \\\"{x:1208,y:739,t:1527189688557};\\\", \\\"{x:1215,y:745,t:1527189688574};\\\", \\\"{x:1223,y:750,t:1527189688590};\\\", \\\"{x:1230,y:755,t:1527189688608};\\\", \\\"{x:1234,y:758,t:1527189688623};\\\", \\\"{x:1238,y:761,t:1527189688641};\\\", \\\"{x:1241,y:764,t:1527189688658};\\\", \\\"{x:1244,y:768,t:1527189688674};\\\", \\\"{x:1249,y:775,t:1527189688691};\\\", \\\"{x:1254,y:780,t:1527189688707};\\\", \\\"{x:1262,y:788,t:1527189688724};\\\", \\\"{x:1269,y:797,t:1527189688741};\\\", \\\"{x:1283,y:811,t:1527189688758};\\\", \\\"{x:1293,y:820,t:1527189688774};\\\", \\\"{x:1301,y:829,t:1527189688790};\\\", \\\"{x:1306,y:836,t:1527189688807};\\\", \\\"{x:1314,y:846,t:1527189688824};\\\", \\\"{x:1322,y:853,t:1527189688841};\\\", \\\"{x:1331,y:859,t:1527189688857};\\\", \\\"{x:1340,y:866,t:1527189688875};\\\", \\\"{x:1352,y:875,t:1527189688890};\\\", \\\"{x:1364,y:883,t:1527189688908};\\\", \\\"{x:1377,y:893,t:1527189688925};\\\", \\\"{x:1385,y:898,t:1527189688941};\\\", \\\"{x:1400,y:908,t:1527189688958};\\\", \\\"{x:1408,y:914,t:1527189688975};\\\", \\\"{x:1413,y:921,t:1527189688991};\\\", \\\"{x:1418,y:923,t:1527189689008};\\\", \\\"{x:1423,y:925,t:1527189689024};\\\", \\\"{x:1428,y:928,t:1527189689041};\\\", \\\"{x:1431,y:929,t:1527189689059};\\\", \\\"{x:1437,y:932,t:1527189689075};\\\", \\\"{x:1440,y:933,t:1527189689091};\\\", \\\"{x:1447,y:936,t:1527189689108};\\\", \\\"{x:1452,y:937,t:1527189689125};\\\", \\\"{x:1461,y:941,t:1527189689141};\\\", \\\"{x:1480,y:946,t:1527189689158};\\\", \\\"{x:1496,y:953,t:1527189689175};\\\", \\\"{x:1509,y:956,t:1527189689191};\\\", \\\"{x:1524,y:961,t:1527189689208};\\\", \\\"{x:1531,y:962,t:1527189689225};\\\", \\\"{x:1544,y:965,t:1527189689241};\\\", \\\"{x:1554,y:967,t:1527189689257};\\\", \\\"{x:1560,y:969,t:1527189689275};\\\", \\\"{x:1562,y:969,t:1527189689291};\\\", \\\"{x:1566,y:970,t:1527189689308};\\\", \\\"{x:1567,y:970,t:1527189689325};\\\", \\\"{x:1568,y:970,t:1527189689341};\\\", \\\"{x:1572,y:971,t:1527189689358};\\\", \\\"{x:1574,y:971,t:1527189689375};\\\", \\\"{x:1576,y:971,t:1527189689392};\\\", \\\"{x:1580,y:973,t:1527189689408};\\\", \\\"{x:1582,y:973,t:1527189689425};\\\", \\\"{x:1586,y:973,t:1527189689442};\\\", \\\"{x:1589,y:973,t:1527189689458};\\\", \\\"{x:1593,y:973,t:1527189689475};\\\", \\\"{x:1595,y:973,t:1527189689492};\\\", \\\"{x:1596,y:973,t:1527189689508};\\\", \\\"{x:1599,y:973,t:1527189689525};\\\", \\\"{x:1601,y:972,t:1527189689541};\\\", \\\"{x:1603,y:972,t:1527189689558};\\\", \\\"{x:1604,y:972,t:1527189689581};\\\", \\\"{x:1604,y:971,t:1527189689592};\\\", \\\"{x:1605,y:971,t:1527189689607};\\\", \\\"{x:1606,y:971,t:1527189689638};\\\", \\\"{x:1607,y:970,t:1527189689646};\\\", \\\"{x:1608,y:970,t:1527189689661};\\\", \\\"{x:1609,y:969,t:1527189689674};\\\", \\\"{x:1610,y:968,t:1527189689693};\\\", \\\"{x:1611,y:966,t:1527189689717};\\\", \\\"{x:1612,y:966,t:1527189689725};\\\", \\\"{x:1612,y:965,t:1527189689741};\\\", \\\"{x:1612,y:963,t:1527189689757};\\\", \\\"{x:1613,y:960,t:1527189689774};\\\", \\\"{x:1614,y:957,t:1527189689792};\\\", \\\"{x:1614,y:953,t:1527189689809};\\\", \\\"{x:1615,y:950,t:1527189689824};\\\", \\\"{x:1615,y:948,t:1527189689841};\\\", \\\"{x:1615,y:946,t:1527189689858};\\\", \\\"{x:1616,y:945,t:1527189689874};\\\", \\\"{x:1616,y:944,t:1527189689891};\\\", \\\"{x:1616,y:943,t:1527189689909};\\\", \\\"{x:1616,y:941,t:1527189689925};\\\", \\\"{x:1616,y:939,t:1527189689942};\\\", \\\"{x:1616,y:937,t:1527189689959};\\\", \\\"{x:1616,y:935,t:1527189689974};\\\", \\\"{x:1616,y:933,t:1527189689991};\\\", \\\"{x:1616,y:931,t:1527189690009};\\\", \\\"{x:1615,y:929,t:1527189690025};\\\", \\\"{x:1614,y:926,t:1527189690041};\\\", \\\"{x:1614,y:924,t:1527189690059};\\\", \\\"{x:1613,y:920,t:1527189690075};\\\", \\\"{x:1612,y:919,t:1527189690102};\\\", \\\"{x:1612,y:918,t:1527189690109};\\\", \\\"{x:1612,y:917,t:1527189690126};\\\", \\\"{x:1611,y:916,t:1527189690150};\\\", \\\"{x:1611,y:915,t:1527189690165};\\\", \\\"{x:1610,y:914,t:1527189690181};\\\", \\\"{x:1609,y:913,t:1527189690198};\\\", \\\"{x:1608,y:910,t:1527189690230};\\\", \\\"{x:1608,y:909,t:1527189690246};\\\", \\\"{x:1606,y:907,t:1527189690259};\\\", \\\"{x:1606,y:904,t:1527189690276};\\\", \\\"{x:1606,y:902,t:1527189690292};\\\", \\\"{x:1606,y:901,t:1527189690309};\\\", \\\"{x:1605,y:900,t:1527189690326};\\\", \\\"{x:1604,y:900,t:1527189690373};\\\", \\\"{x:1604,y:899,t:1527189690398};\\\", \\\"{x:1604,y:898,t:1527189690422};\\\", \\\"{x:1604,y:897,t:1527189690470};\\\", \\\"{x:1604,y:896,t:1527189690486};\\\", \\\"{x:1604,y:895,t:1527189690502};\\\", \\\"{x:1604,y:894,t:1527189690518};\\\", \\\"{x:1604,y:893,t:1527189690526};\\\", \\\"{x:1604,y:892,t:1527189690541};\\\", \\\"{x:1604,y:891,t:1527189690559};\\\", \\\"{x:1604,y:890,t:1527189690582};\\\", \\\"{x:1604,y:889,t:1527189690622};\\\", \\\"{x:1604,y:888,t:1527189691254};\\\", \\\"{x:1604,y:887,t:1527189693757};\\\", \\\"{x:1604,y:886,t:1527189693765};\\\", \\\"{x:1603,y:886,t:1527189693942};\\\", \\\"{x:1602,y:886,t:1527189693950};\\\", \\\"{x:1601,y:886,t:1527189693962};\\\", \\\"{x:1597,y:886,t:1527189693978};\\\", \\\"{x:1594,y:886,t:1527189693994};\\\", \\\"{x:1591,y:886,t:1527189694011};\\\", \\\"{x:1589,y:886,t:1527189694027};\\\", \\\"{x:1586,y:886,t:1527189694045};\\\", \\\"{x:1583,y:886,t:1527189694062};\\\", \\\"{x:1582,y:886,t:1527189694093};\\\", \\\"{x:1581,y:886,t:1527189694135};\\\", \\\"{x:1580,y:886,t:1527189694174};\\\", \\\"{x:1579,y:886,t:1527189694254};\\\", \\\"{x:1577,y:886,t:1527189694262};\\\", \\\"{x:1573,y:886,t:1527189694279};\\\", \\\"{x:1568,y:886,t:1527189694295};\\\", \\\"{x:1558,y:886,t:1527189694312};\\\", \\\"{x:1544,y:886,t:1527189694329};\\\", \\\"{x:1530,y:886,t:1527189694345};\\\", \\\"{x:1514,y:886,t:1527189694362};\\\", \\\"{x:1502,y:886,t:1527189694379};\\\", \\\"{x:1481,y:886,t:1527189694394};\\\", \\\"{x:1457,y:886,t:1527189694412};\\\", \\\"{x:1435,y:890,t:1527189694429};\\\", \\\"{x:1416,y:893,t:1527189694445};\\\", \\\"{x:1395,y:896,t:1527189694462};\\\", \\\"{x:1386,y:897,t:1527189694480};\\\", \\\"{x:1379,y:897,t:1527189694495};\\\", \\\"{x:1374,y:898,t:1527189694512};\\\", \\\"{x:1370,y:899,t:1527189694529};\\\", \\\"{x:1362,y:901,t:1527189694545};\\\", \\\"{x:1350,y:905,t:1527189694562};\\\", \\\"{x:1335,y:910,t:1527189694579};\\\", \\\"{x:1308,y:917,t:1527189694595};\\\", \\\"{x:1292,y:920,t:1527189694611};\\\", \\\"{x:1271,y:923,t:1527189694628};\\\", \\\"{x:1251,y:925,t:1527189694645};\\\", \\\"{x:1242,y:926,t:1527189694662};\\\", \\\"{x:1231,y:926,t:1527189694679};\\\", \\\"{x:1220,y:926,t:1527189694696};\\\", \\\"{x:1205,y:926,t:1527189694711};\\\", \\\"{x:1195,y:926,t:1527189694728};\\\", \\\"{x:1187,y:926,t:1527189694745};\\\", \\\"{x:1182,y:926,t:1527189694761};\\\", \\\"{x:1178,y:926,t:1527189694778};\\\", \\\"{x:1172,y:926,t:1527189694796};\\\", \\\"{x:1167,y:926,t:1527189694811};\\\", \\\"{x:1156,y:926,t:1527189694829};\\\", \\\"{x:1144,y:926,t:1527189694845};\\\", \\\"{x:1133,y:923,t:1527189694862};\\\", \\\"{x:1125,y:922,t:1527189694879};\\\", \\\"{x:1120,y:921,t:1527189694896};\\\", \\\"{x:1117,y:920,t:1527189694911};\\\", \\\"{x:1113,y:920,t:1527189694929};\\\", \\\"{x:1110,y:917,t:1527189694946};\\\", \\\"{x:1107,y:916,t:1527189694962};\\\", \\\"{x:1103,y:914,t:1527189694979};\\\", \\\"{x:1101,y:913,t:1527189694996};\\\", \\\"{x:1094,y:909,t:1527189695012};\\\", \\\"{x:1092,y:908,t:1527189695029};\\\", \\\"{x:1088,y:906,t:1527189695045};\\\", \\\"{x:1087,y:905,t:1527189695078};\\\", \\\"{x:1086,y:904,t:1527189695096};\\\", \\\"{x:1085,y:904,t:1527189695113};\\\", \\\"{x:1084,y:902,t:1527189695129};\\\", \\\"{x:1084,y:900,t:1527189695237};\\\", \\\"{x:1085,y:898,t:1527189695245};\\\", \\\"{x:1091,y:898,t:1527189695262};\\\", \\\"{x:1105,y:894,t:1527189695279};\\\", \\\"{x:1124,y:890,t:1527189695296};\\\", \\\"{x:1141,y:889,t:1527189695313};\\\", \\\"{x:1150,y:889,t:1527189695329};\\\", \\\"{x:1151,y:890,t:1527189695345};\\\", \\\"{x:1155,y:891,t:1527189695363};\\\", \\\"{x:1157,y:891,t:1527189695379};\\\", \\\"{x:1160,y:891,t:1527189695662};\\\", \\\"{x:1166,y:891,t:1527189695680};\\\", \\\"{x:1177,y:891,t:1527189695696};\\\", \\\"{x:1181,y:891,t:1527189695714};\\\", \\\"{x:1185,y:891,t:1527189695730};\\\", \\\"{x:1186,y:891,t:1527189695814};\\\", \\\"{x:1193,y:891,t:1527189696350};\\\", \\\"{x:1199,y:891,t:1527189696363};\\\", \\\"{x:1223,y:891,t:1527189696380};\\\", \\\"{x:1252,y:891,t:1527189696397};\\\", \\\"{x:1277,y:896,t:1527189696414};\\\", \\\"{x:1280,y:896,t:1527189696430};\\\", \\\"{x:1282,y:896,t:1527189696447};\\\", \\\"{x:1284,y:896,t:1527189696613};\\\", \\\"{x:1291,y:896,t:1527189696630};\\\", \\\"{x:1303,y:896,t:1527189696647};\\\", \\\"{x:1314,y:896,t:1527189696664};\\\", \\\"{x:1323,y:896,t:1527189696680};\\\", \\\"{x:1324,y:896,t:1527189696697};\\\", \\\"{x:1325,y:896,t:1527189697607};\\\", \\\"{x:1329,y:896,t:1527189697614};\\\", \\\"{x:1332,y:896,t:1527189697631};\\\", \\\"{x:1339,y:896,t:1527189697649};\\\", \\\"{x:1345,y:896,t:1527189697667};\\\", \\\"{x:1348,y:896,t:1527189697681};\\\", \\\"{x:1350,y:896,t:1527189697698};\\\", \\\"{x:1351,y:895,t:1527189697715};\\\", \\\"{x:1352,y:895,t:1527189697733};\\\", \\\"{x:1353,y:894,t:1527189697749};\\\", \\\"{x:1355,y:894,t:1527189697775};\\\", \\\"{x:1356,y:893,t:1527189697790};\\\", \\\"{x:1357,y:892,t:1527189697839};\\\", \\\"{x:1358,y:891,t:1527189697848};\\\", \\\"{x:1358,y:890,t:1527189698894};\\\", \\\"{x:1360,y:889,t:1527189698902};\\\", \\\"{x:1362,y:884,t:1527189698915};\\\", \\\"{x:1365,y:881,t:1527189698932};\\\", \\\"{x:1371,y:875,t:1527189698949};\\\", \\\"{x:1377,y:871,t:1527189698965};\\\", \\\"{x:1382,y:868,t:1527189698983};\\\", \\\"{x:1385,y:865,t:1527189698999};\\\", \\\"{x:1386,y:864,t:1527189699016};\\\", \\\"{x:1388,y:862,t:1527189699033};\\\", \\\"{x:1388,y:861,t:1527189699078};\\\", \\\"{x:1389,y:859,t:1527189699102};\\\", \\\"{x:1390,y:858,t:1527189699117};\\\", \\\"{x:1392,y:857,t:1527189699133};\\\", \\\"{x:1394,y:856,t:1527189699149};\\\", \\\"{x:1399,y:852,t:1527189699166};\\\", \\\"{x:1403,y:851,t:1527189699183};\\\", \\\"{x:1409,y:849,t:1527189699199};\\\", \\\"{x:1416,y:846,t:1527189699217};\\\", \\\"{x:1423,y:843,t:1527189699233};\\\", \\\"{x:1428,y:842,t:1527189699249};\\\", \\\"{x:1433,y:839,t:1527189699266};\\\", \\\"{x:1439,y:839,t:1527189699283};\\\", \\\"{x:1445,y:838,t:1527189699299};\\\", \\\"{x:1449,y:836,t:1527189699317};\\\", \\\"{x:1453,y:835,t:1527189699332};\\\", \\\"{x:1454,y:835,t:1527189699349};\\\", \\\"{x:1459,y:833,t:1527189699366};\\\", \\\"{x:1460,y:833,t:1527189699383};\\\", \\\"{x:1464,y:832,t:1527189699399};\\\", \\\"{x:1466,y:831,t:1527189699416};\\\", \\\"{x:1469,y:831,t:1527189699433};\\\", \\\"{x:1470,y:831,t:1527189699449};\\\", \\\"{x:1472,y:830,t:1527189699542};\\\", \\\"{x:1473,y:829,t:1527189699599};\\\", \\\"{x:1474,y:828,t:1527189699646};\\\", \\\"{x:1475,y:828,t:1527189699654};\\\", \\\"{x:1476,y:828,t:1527189699670};\\\", \\\"{x:1477,y:826,t:1527189699683};\\\", \\\"{x:1478,y:826,t:1527189699701};\\\", \\\"{x:1479,y:825,t:1527189699725};\\\", \\\"{x:1480,y:825,t:1527189699734};\\\", \\\"{x:1481,y:825,t:1527189699749};\\\", \\\"{x:1482,y:823,t:1527189699790};\\\", \\\"{x:1484,y:823,t:1527189700230};\\\", \\\"{x:1487,y:823,t:1527189700246};\\\", \\\"{x:1493,y:824,t:1527189700254};\\\", \\\"{x:1496,y:826,t:1527189700266};\\\", \\\"{x:1499,y:827,t:1527189700283};\\\", \\\"{x:1504,y:829,t:1527189700300};\\\", \\\"{x:1508,y:829,t:1527189700316};\\\", \\\"{x:1510,y:829,t:1527189700334};\\\", \\\"{x:1511,y:830,t:1527189700351};\\\", \\\"{x:1514,y:830,t:1527189700366};\\\", \\\"{x:1519,y:830,t:1527189700382};\\\", \\\"{x:1524,y:831,t:1527189700399};\\\", \\\"{x:1525,y:831,t:1527189700416};\\\", \\\"{x:1527,y:831,t:1527189700542};\\\", \\\"{x:1528,y:831,t:1527189700670};\\\", \\\"{x:1529,y:830,t:1527189700686};\\\", \\\"{x:1530,y:830,t:1527189700724};\\\", \\\"{x:1531,y:830,t:1527189700853};\\\", \\\"{x:1533,y:830,t:1527189700878};\\\", \\\"{x:1534,y:830,t:1527189700885};\\\", \\\"{x:1535,y:830,t:1527189700900};\\\", \\\"{x:1541,y:830,t:1527189700917};\\\", \\\"{x:1546,y:831,t:1527189700933};\\\", \\\"{x:1552,y:832,t:1527189700950};\\\", \\\"{x:1557,y:832,t:1527189700967};\\\", \\\"{x:1563,y:834,t:1527189700984};\\\", \\\"{x:1564,y:834,t:1527189701000};\\\", \\\"{x:1565,y:834,t:1527189701017};\\\", \\\"{x:1566,y:834,t:1527189701034};\\\", \\\"{x:1568,y:834,t:1527189701050};\\\", \\\"{x:1570,y:834,t:1527189701068};\\\", \\\"{x:1573,y:834,t:1527189701085};\\\", \\\"{x:1576,y:834,t:1527189701101};\\\", \\\"{x:1586,y:834,t:1527189701118};\\\", \\\"{x:1589,y:834,t:1527189701134};\\\", \\\"{x:1593,y:834,t:1527189701151};\\\", \\\"{x:1594,y:834,t:1527189701168};\\\", \\\"{x:1595,y:834,t:1527189701238};\\\", \\\"{x:1596,y:833,t:1527189701269};\\\", \\\"{x:1599,y:831,t:1527189701326};\\\", \\\"{x:1600,y:830,t:1527189701350};\\\", \\\"{x:1602,y:828,t:1527189701358};\\\", \\\"{x:1603,y:828,t:1527189701367};\\\", \\\"{x:1603,y:827,t:1527189701385};\\\", \\\"{x:1604,y:827,t:1527189701401};\\\", \\\"{x:1606,y:825,t:1527189701438};\\\", \\\"{x:1607,y:825,t:1527189701462};\\\", \\\"{x:1608,y:824,t:1527189701486};\\\", \\\"{x:1609,y:823,t:1527189701510};\\\", \\\"{x:1610,y:823,t:1527189701525};\\\", \\\"{x:1611,y:823,t:1527189701535};\\\", \\\"{x:1611,y:822,t:1527189701551};\\\", \\\"{x:1606,y:822,t:1527189703838};\\\", \\\"{x:1587,y:823,t:1527189703852};\\\", \\\"{x:1504,y:821,t:1527189703869};\\\", \\\"{x:1423,y:819,t:1527189703886};\\\", \\\"{x:1332,y:811,t:1527189703904};\\\", \\\"{x:1229,y:807,t:1527189703919};\\\", \\\"{x:1133,y:800,t:1527189703937};\\\", \\\"{x:1048,y:793,t:1527189703954};\\\", \\\"{x:976,y:787,t:1527189703969};\\\", \\\"{x:941,y:779,t:1527189703987};\\\", \\\"{x:909,y:778,t:1527189704003};\\\", \\\"{x:883,y:777,t:1527189704019};\\\", \\\"{x:854,y:777,t:1527189704036};\\\", \\\"{x:822,y:777,t:1527189704054};\\\", \\\"{x:801,y:777,t:1527189704069};\\\", \\\"{x:780,y:773,t:1527189704086};\\\", \\\"{x:761,y:773,t:1527189704104};\\\", \\\"{x:739,y:773,t:1527189704120};\\\", \\\"{x:723,y:766,t:1527189704136};\\\", \\\"{x:697,y:762,t:1527189704154};\\\", \\\"{x:653,y:753,t:1527189704170};\\\", \\\"{x:626,y:747,t:1527189704186};\\\", \\\"{x:599,y:736,t:1527189704203};\\\", \\\"{x:568,y:725,t:1527189704219};\\\", \\\"{x:544,y:716,t:1527189704238};\\\", \\\"{x:519,y:699,t:1527189704253};\\\", \\\"{x:506,y:694,t:1527189704270};\\\", \\\"{x:487,y:687,t:1527189704285};\\\", \\\"{x:481,y:685,t:1527189704303};\\\", \\\"{x:479,y:683,t:1527189704320};\\\", \\\"{x:479,y:679,t:1527189704336};\\\", \\\"{x:481,y:675,t:1527189704353};\\\", \\\"{x:483,y:674,t:1527189704370};\\\", \\\"{x:491,y:666,t:1527189704386};\\\", \\\"{x:499,y:659,t:1527189704403};\\\", \\\"{x:515,y:651,t:1527189704419};\\\", \\\"{x:524,y:650,t:1527189704437};\\\", \\\"{x:551,y:641,t:1527189704453};\\\", \\\"{x:573,y:636,t:1527189704470};\\\", \\\"{x:592,y:631,t:1527189704487};\\\", \\\"{x:615,y:625,t:1527189704503};\\\", \\\"{x:636,y:623,t:1527189704520};\\\", \\\"{x:649,y:619,t:1527189704537};\\\", \\\"{x:654,y:618,t:1527189704553};\\\", \\\"{x:653,y:618,t:1527189704646};\\\", \\\"{x:641,y:615,t:1527189704653};\\\", \\\"{x:611,y:612,t:1527189704671};\\\", \\\"{x:606,y:609,t:1527189704687};\\\", \\\"{x:604,y:607,t:1527189704704};\\\", \\\"{x:603,y:606,t:1527189704720};\\\", \\\"{x:604,y:606,t:1527189704790};\\\", \\\"{x:605,y:606,t:1527189704803};\\\", \\\"{x:609,y:605,t:1527189704820};\\\", \\\"{x:617,y:605,t:1527189704837};\\\", \\\"{x:631,y:605,t:1527189704854};\\\", \\\"{x:644,y:608,t:1527189704871};\\\", \\\"{x:655,y:612,t:1527189704887};\\\", \\\"{x:657,y:615,t:1527189704905};\\\", \\\"{x:659,y:616,t:1527189704920};\\\", \\\"{x:659,y:615,t:1527189705062};\\\", \\\"{x:658,y:614,t:1527189705077};\\\", \\\"{x:657,y:613,t:1527189705101};\\\", \\\"{x:656,y:612,t:1527189705110};\\\", \\\"{x:655,y:612,t:1527189705120};\\\", \\\"{x:653,y:612,t:1527189705137};\\\", \\\"{x:651,y:611,t:1527189705154};\\\", \\\"{x:650,y:610,t:1527189705171};\\\", \\\"{x:649,y:610,t:1527189705187};\\\", \\\"{x:646,y:609,t:1527189705203};\\\", \\\"{x:636,y:605,t:1527189705221};\\\", \\\"{x:633,y:605,t:1527189705238};\\\", \\\"{x:633,y:604,t:1527189705254};\\\", \\\"{x:631,y:604,t:1527189705349};\\\", \\\"{x:630,y:604,t:1527189705380};\\\", \\\"{x:628,y:603,t:1527189705389};\\\", \\\"{x:627,y:603,t:1527189705405};\\\", \\\"{x:626,y:602,t:1527189705421};\\\", \\\"{x:623,y:601,t:1527189705436};\\\", \\\"{x:621,y:600,t:1527189705454};\\\", \\\"{x:620,y:599,t:1527189705485};\\\", \\\"{x:619,y:598,t:1527189705493};\\\", \\\"{x:618,y:598,t:1527189705503};\\\", \\\"{x:617,y:598,t:1527189705520};\\\", \\\"{x:614,y:597,t:1527189705537};\\\", \\\"{x:612,y:596,t:1527189705773};\\\", \\\"{x:607,y:598,t:1527189705788};\\\", \\\"{x:595,y:614,t:1527189705804};\\\", \\\"{x:583,y:629,t:1527189705821};\\\", \\\"{x:580,y:637,t:1527189705838};\\\", \\\"{x:576,y:642,t:1527189705853};\\\", \\\"{x:572,y:648,t:1527189705870};\\\", \\\"{x:569,y:655,t:1527189705888};\\\", \\\"{x:567,y:661,t:1527189705904};\\\", \\\"{x:558,y:675,t:1527189705921};\\\", \\\"{x:554,y:689,t:1527189705938};\\\", \\\"{x:554,y:694,t:1527189705954};\\\", \\\"{x:553,y:698,t:1527189705971};\\\", \\\"{x:552,y:702,t:1527189705988};\\\", \\\"{x:551,y:706,t:1527189706004};\\\", \\\"{x:549,y:710,t:1527189706020};\\\", \\\"{x:547,y:715,t:1527189706038};\\\", \\\"{x:542,y:721,t:1527189706054};\\\", \\\"{x:540,y:729,t:1527189706071};\\\", \\\"{x:540,y:730,t:1527189706088};\\\" ] }, { \\\"rt\\\": 115142, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 402224, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"F98S2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -I -I -I -O -12 PM-01 PM-02 PM-03 PM-04 PM-05 PM-06 PM-06 PM-05 PM-11 AM-12 PM-12 PM-01 PM-03 PM-02 PM-02 PM-02 PM-01 PM-02 PM-03 PM-02 PM-12 PM-12 PM-01 PM-02 PM-02 PM-03 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:548,y:730,t:1527189718502};\\\", \\\"{x:598,y:717,t:1527189718522};\\\", \\\"{x:655,y:705,t:1527189718533};\\\", \\\"{x:707,y:695,t:1527189718549};\\\", \\\"{x:750,y:688,t:1527189718563};\\\", \\\"{x:856,y:669,t:1527189718580};\\\", \\\"{x:899,y:654,t:1527189718597};\\\", \\\"{x:947,y:622,t:1527189718614};\\\", \\\"{x:1005,y:585,t:1527189718631};\\\", \\\"{x:1047,y:555,t:1527189718648};\\\", \\\"{x:1077,y:535,t:1527189718664};\\\", \\\"{x:1099,y:517,t:1527189718681};\\\", \\\"{x:1116,y:501,t:1527189718698};\\\", \\\"{x:1128,y:494,t:1527189718714};\\\", \\\"{x:1136,y:487,t:1527189718731};\\\", \\\"{x:1140,y:486,t:1527189718749};\\\", \\\"{x:1143,y:485,t:1527189718765};\\\", \\\"{x:1144,y:484,t:1527189718782};\\\", \\\"{x:1145,y:484,t:1527189718805};\\\", \\\"{x:1150,y:484,t:1527189718814};\\\", \\\"{x:1162,y:485,t:1527189718831};\\\", \\\"{x:1182,y:494,t:1527189718849};\\\", \\\"{x:1196,y:501,t:1527189718865};\\\", \\\"{x:1205,y:510,t:1527189718882};\\\", \\\"{x:1214,y:518,t:1527189718899};\\\", \\\"{x:1222,y:527,t:1527189718915};\\\", \\\"{x:1229,y:535,t:1527189718932};\\\", \\\"{x:1240,y:544,t:1527189718949};\\\", \\\"{x:1244,y:545,t:1527189718965};\\\", \\\"{x:1246,y:546,t:1527189718982};\\\", \\\"{x:1256,y:551,t:1527189719000};\\\", \\\"{x:1263,y:554,t:1527189719016};\\\", \\\"{x:1268,y:555,t:1527189719032};\\\", \\\"{x:1270,y:555,t:1527189719049};\\\", \\\"{x:1271,y:556,t:1527189719066};\\\", \\\"{x:1272,y:556,t:1527189719110};\\\", \\\"{x:1273,y:556,t:1527189719118};\\\", \\\"{x:1275,y:556,t:1527189719141};\\\", \\\"{x:1277,y:555,t:1527189719149};\\\", \\\"{x:1283,y:551,t:1527189719165};\\\", \\\"{x:1285,y:550,t:1527189719182};\\\", \\\"{x:1288,y:547,t:1527189719199};\\\", \\\"{x:1289,y:546,t:1527189719217};\\\", \\\"{x:1290,y:545,t:1527189719232};\\\", \\\"{x:1291,y:544,t:1527189719250};\\\", \\\"{x:1291,y:543,t:1527189719267};\\\", \\\"{x:1293,y:541,t:1527189719282};\\\", \\\"{x:1294,y:540,t:1527189719300};\\\", \\\"{x:1295,y:538,t:1527189719316};\\\", \\\"{x:1297,y:535,t:1527189719333};\\\", \\\"{x:1297,y:533,t:1527189719349};\\\", \\\"{x:1298,y:532,t:1527189719374};\\\", \\\"{x:1299,y:532,t:1527189719389};\\\", \\\"{x:1300,y:530,t:1527189719405};\\\", \\\"{x:1301,y:529,t:1527189719416};\\\", \\\"{x:1301,y:527,t:1527189719432};\\\", \\\"{x:1303,y:525,t:1527189719449};\\\", \\\"{x:1304,y:524,t:1527189719466};\\\", \\\"{x:1305,y:523,t:1527189719482};\\\", \\\"{x:1305,y:522,t:1527189719534};\\\", \\\"{x:1307,y:520,t:1527189719557};\\\", \\\"{x:1309,y:519,t:1527189719590};\\\", \\\"{x:1310,y:518,t:1527189719614};\\\", \\\"{x:1310,y:517,t:1527189719638};\\\", \\\"{x:1311,y:516,t:1527189719654};\\\", \\\"{x:1312,y:516,t:1527189719666};\\\", \\\"{x:1313,y:514,t:1527189719683};\\\", \\\"{x:1315,y:512,t:1527189719699};\\\", \\\"{x:1315,y:510,t:1527189719716};\\\", \\\"{x:1317,y:508,t:1527189719733};\\\", \\\"{x:1317,y:507,t:1527189719758};\\\", \\\"{x:1317,y:506,t:1527189719766};\\\", \\\"{x:1318,y:505,t:1527189719783};\\\", \\\"{x:1319,y:504,t:1527189719800};\\\", \\\"{x:1320,y:502,t:1527189719821};\\\", \\\"{x:1320,y:500,t:1527189719850};\\\", \\\"{x:1321,y:503,t:1527189721666};\\\", \\\"{x:1321,y:509,t:1527189721674};\\\", \\\"{x:1323,y:515,t:1527189721688};\\\", \\\"{x:1325,y:528,t:1527189721706};\\\", \\\"{x:1326,y:539,t:1527189721722};\\\", \\\"{x:1327,y:546,t:1527189721739};\\\", \\\"{x:1329,y:550,t:1527189721756};\\\", \\\"{x:1330,y:554,t:1527189721772};\\\", \\\"{x:1331,y:558,t:1527189721789};\\\", \\\"{x:1332,y:559,t:1527189721805};\\\", \\\"{x:1333,y:562,t:1527189721823};\\\", \\\"{x:1333,y:565,t:1527189721838};\\\", \\\"{x:1333,y:566,t:1527189721856};\\\", \\\"{x:1333,y:568,t:1527189721897};\\\", \\\"{x:1333,y:569,t:1527189721922};\\\", \\\"{x:1333,y:570,t:1527189721938};\\\", \\\"{x:1333,y:573,t:1527189721956};\\\", \\\"{x:1333,y:576,t:1527189721972};\\\", \\\"{x:1335,y:580,t:1527189721988};\\\", \\\"{x:1335,y:582,t:1527189722009};\\\", \\\"{x:1336,y:584,t:1527189722042};\\\", \\\"{x:1337,y:588,t:1527189722057};\\\", \\\"{x:1338,y:590,t:1527189722072};\\\", \\\"{x:1340,y:598,t:1527189722088};\\\", \\\"{x:1344,y:618,t:1527189722106};\\\", \\\"{x:1348,y:624,t:1527189722123};\\\", \\\"{x:1350,y:637,t:1527189722139};\\\", \\\"{x:1354,y:654,t:1527189722156};\\\", \\\"{x:1358,y:670,t:1527189722172};\\\", \\\"{x:1360,y:685,t:1527189722189};\\\", \\\"{x:1362,y:699,t:1527189722205};\\\", \\\"{x:1363,y:705,t:1527189722222};\\\", \\\"{x:1364,y:708,t:1527189722239};\\\", \\\"{x:1364,y:710,t:1527189722255};\\\", \\\"{x:1364,y:712,t:1527189723034};\\\", \\\"{x:1365,y:718,t:1527189723041};\\\", \\\"{x:1367,y:723,t:1527189723057};\\\", \\\"{x:1370,y:734,t:1527189723073};\\\", \\\"{x:1383,y:759,t:1527189723092};\\\", \\\"{x:1386,y:772,t:1527189723107};\\\", \\\"{x:1389,y:781,t:1527189723124};\\\", \\\"{x:1393,y:787,t:1527189723139};\\\", \\\"{x:1396,y:792,t:1527189723157};\\\", \\\"{x:1399,y:797,t:1527189723173};\\\", \\\"{x:1401,y:799,t:1527189723190};\\\", \\\"{x:1403,y:799,t:1527189723206};\\\", \\\"{x:1405,y:801,t:1527189723290};\\\", \\\"{x:1407,y:803,t:1527189723306};\\\", \\\"{x:1410,y:807,t:1527189723323};\\\", \\\"{x:1414,y:815,t:1527189723340};\\\", \\\"{x:1431,y:828,t:1527189723356};\\\", \\\"{x:1450,y:842,t:1527189723374};\\\", \\\"{x:1460,y:850,t:1527189723390};\\\", \\\"{x:1471,y:860,t:1527189723406};\\\", \\\"{x:1482,y:869,t:1527189723423};\\\", \\\"{x:1495,y:878,t:1527189723440};\\\", \\\"{x:1501,y:883,t:1527189723457};\\\", \\\"{x:1507,y:887,t:1527189723474};\\\", \\\"{x:1509,y:890,t:1527189723490};\\\", \\\"{x:1511,y:892,t:1527189723507};\\\", \\\"{x:1511,y:890,t:1527189723962};\\\", \\\"{x:1511,y:888,t:1527189723974};\\\", \\\"{x:1512,y:878,t:1527189723990};\\\", \\\"{x:1515,y:862,t:1527189724008};\\\", \\\"{x:1514,y:843,t:1527189724023};\\\", \\\"{x:1511,y:830,t:1527189724041};\\\", \\\"{x:1510,y:828,t:1527189724058};\\\", \\\"{x:1510,y:826,t:1527189724081};\\\", \\\"{x:1508,y:823,t:1527189724091};\\\", \\\"{x:1506,y:818,t:1527189724107};\\\", \\\"{x:1501,y:807,t:1527189724124};\\\", \\\"{x:1497,y:794,t:1527189724140};\\\", \\\"{x:1490,y:778,t:1527189724158};\\\", \\\"{x:1490,y:770,t:1527189724174};\\\", \\\"{x:1487,y:762,t:1527189724190};\\\", \\\"{x:1486,y:755,t:1527189724208};\\\", \\\"{x:1485,y:746,t:1527189724224};\\\", \\\"{x:1482,y:739,t:1527189724241};\\\", \\\"{x:1480,y:734,t:1527189724258};\\\", \\\"{x:1479,y:733,t:1527189724274};\\\", \\\"{x:1478,y:731,t:1527189724291};\\\", \\\"{x:1475,y:729,t:1527189724308};\\\", \\\"{x:1475,y:726,t:1527189724323};\\\", \\\"{x:1473,y:724,t:1527189724340};\\\", \\\"{x:1472,y:723,t:1527189724357};\\\", \\\"{x:1468,y:714,t:1527189724375};\\\", \\\"{x:1465,y:706,t:1527189724391};\\\", \\\"{x:1463,y:702,t:1527189724408};\\\", \\\"{x:1462,y:699,t:1527189724424};\\\", \\\"{x:1460,y:695,t:1527189724441};\\\", \\\"{x:1460,y:694,t:1527189724457};\\\", \\\"{x:1458,y:691,t:1527189724474};\\\", \\\"{x:1457,y:686,t:1527189724490};\\\", \\\"{x:1457,y:684,t:1527189724514};\\\", \\\"{x:1456,y:683,t:1527189724524};\\\", \\\"{x:1455,y:680,t:1527189724545};\\\", \\\"{x:1454,y:679,t:1527189724562};\\\", \\\"{x:1453,y:679,t:1527189724574};\\\", \\\"{x:1453,y:678,t:1527189724590};\\\", \\\"{x:1453,y:674,t:1527189724818};\\\", \\\"{x:1451,y:667,t:1527189724825};\\\", \\\"{x:1443,y:651,t:1527189724841};\\\", \\\"{x:1437,y:634,t:1527189724858};\\\", \\\"{x:1430,y:626,t:1527189724875};\\\", \\\"{x:1422,y:614,t:1527189724892};\\\", \\\"{x:1419,y:610,t:1527189724907};\\\", \\\"{x:1418,y:609,t:1527189724924};\\\", \\\"{x:1417,y:604,t:1527189724941};\\\", \\\"{x:1413,y:597,t:1527189724957};\\\", \\\"{x:1410,y:591,t:1527189724975};\\\", \\\"{x:1405,y:584,t:1527189724991};\\\", \\\"{x:1404,y:578,t:1527189725007};\\\", \\\"{x:1402,y:577,t:1527189725025};\\\", \\\"{x:1399,y:573,t:1527189725042};\\\", \\\"{x:1398,y:571,t:1527189725058};\\\", \\\"{x:1395,y:566,t:1527189725075};\\\", \\\"{x:1392,y:561,t:1527189725092};\\\", \\\"{x:1390,y:560,t:1527189725107};\\\", \\\"{x:1387,y:556,t:1527189725124};\\\", \\\"{x:1385,y:554,t:1527189725142};\\\", \\\"{x:1380,y:550,t:1527189725158};\\\", \\\"{x:1377,y:547,t:1527189725174};\\\", \\\"{x:1375,y:544,t:1527189725191};\\\", \\\"{x:1368,y:536,t:1527189725207};\\\", \\\"{x:1362,y:532,t:1527189725225};\\\", \\\"{x:1355,y:526,t:1527189725242};\\\", \\\"{x:1353,y:522,t:1527189725258};\\\", \\\"{x:1351,y:521,t:1527189725274};\\\", \\\"{x:1348,y:520,t:1527189725292};\\\", \\\"{x:1344,y:515,t:1527189725307};\\\", \\\"{x:1341,y:512,t:1527189725324};\\\", \\\"{x:1337,y:510,t:1527189725342};\\\", \\\"{x:1333,y:507,t:1527189725358};\\\", \\\"{x:1330,y:506,t:1527189725375};\\\", \\\"{x:1328,y:506,t:1527189725553};\\\", \\\"{x:1326,y:506,t:1527189725569};\\\", \\\"{x:1323,y:506,t:1527189725577};\\\", \\\"{x:1319,y:506,t:1527189725593};\\\", \\\"{x:1314,y:502,t:1527189725609};\\\", \\\"{x:1309,y:498,t:1527189725624};\\\", \\\"{x:1305,y:494,t:1527189725643};\\\", \\\"{x:1304,y:493,t:1527189725658};\\\", \\\"{x:1306,y:493,t:1527189725970};\\\", \\\"{x:1307,y:493,t:1527189725994};\\\", \\\"{x:1307,y:495,t:1527189726266};\\\", \\\"{x:1310,y:495,t:1527189726276};\\\", \\\"{x:1312,y:495,t:1527189726321};\\\", \\\"{x:1312,y:500,t:1527189726802};\\\", \\\"{x:1310,y:504,t:1527189726810};\\\", \\\"{x:1308,y:520,t:1527189726826};\\\", \\\"{x:1307,y:532,t:1527189726842};\\\", \\\"{x:1307,y:537,t:1527189726859};\\\", \\\"{x:1306,y:551,t:1527189726875};\\\", \\\"{x:1306,y:585,t:1527189726892};\\\", \\\"{x:1301,y:659,t:1527189726909};\\\", \\\"{x:1299,y:751,t:1527189726925};\\\", \\\"{x:1299,y:837,t:1527189726943};\\\", \\\"{x:1303,y:910,t:1527189726960};\\\", \\\"{x:1304,y:942,t:1527189726976};\\\", \\\"{x:1311,y:983,t:1527189726993};\\\", \\\"{x:1317,y:1027,t:1527189727009};\\\", \\\"{x:1318,y:1050,t:1527189727026};\\\", \\\"{x:1319,y:1078,t:1527189727043};\\\", \\\"{x:1323,y:1097,t:1527189727059};\\\", \\\"{x:1328,y:1112,t:1527189727075};\\\", \\\"{x:1333,y:1125,t:1527189727093};\\\", \\\"{x:1335,y:1131,t:1527189727109};\\\", \\\"{x:1336,y:1130,t:1527189727194};\\\", \\\"{x:1336,y:1113,t:1527189727209};\\\", \\\"{x:1336,y:1092,t:1527189727227};\\\", \\\"{x:1331,y:1070,t:1527189727242};\\\", \\\"{x:1330,y:1057,t:1527189727259};\\\", \\\"{x:1329,y:1050,t:1527189727276};\\\", \\\"{x:1328,y:1042,t:1527189727292};\\\", \\\"{x:1327,y:1037,t:1527189727309};\\\", \\\"{x:1326,y:1032,t:1527189727326};\\\", \\\"{x:1326,y:1026,t:1527189727342};\\\", \\\"{x:1325,y:1018,t:1527189727359};\\\", \\\"{x:1325,y:1007,t:1527189727376};\\\", \\\"{x:1324,y:998,t:1527189727392};\\\", \\\"{x:1323,y:991,t:1527189727409};\\\", \\\"{x:1323,y:988,t:1527189727427};\\\", \\\"{x:1323,y:984,t:1527189727443};\\\", \\\"{x:1322,y:976,t:1527189727459};\\\", \\\"{x:1322,y:969,t:1527189727476};\\\", \\\"{x:1320,y:963,t:1527189727494};\\\", \\\"{x:1320,y:956,t:1527189727509};\\\", \\\"{x:1318,y:952,t:1527189727526};\\\", \\\"{x:1317,y:950,t:1527189727543};\\\", \\\"{x:1317,y:948,t:1527189727569};\\\", \\\"{x:1317,y:947,t:1527189727577};\\\", \\\"{x:1315,y:944,t:1527189727593};\\\", \\\"{x:1315,y:943,t:1527189727609};\\\", \\\"{x:1315,y:942,t:1527189727633};\\\", \\\"{x:1315,y:940,t:1527189727649};\\\", \\\"{x:1315,y:939,t:1527189727665};\\\", \\\"{x:1315,y:937,t:1527189727681};\\\", \\\"{x:1315,y:936,t:1527189727697};\\\", \\\"{x:1315,y:934,t:1527189727710};\\\", \\\"{x:1315,y:933,t:1527189727726};\\\", \\\"{x:1316,y:930,t:1527189727743};\\\", \\\"{x:1317,y:928,t:1527189727760};\\\", \\\"{x:1317,y:927,t:1527189727777};\\\", \\\"{x:1317,y:924,t:1527189727794};\\\", \\\"{x:1319,y:921,t:1527189727809};\\\", \\\"{x:1319,y:918,t:1527189727827};\\\", \\\"{x:1321,y:914,t:1527189727844};\\\", \\\"{x:1322,y:910,t:1527189727859};\\\", \\\"{x:1322,y:906,t:1527189727877};\\\", \\\"{x:1323,y:904,t:1527189727893};\\\", \\\"{x:1323,y:902,t:1527189727910};\\\", \\\"{x:1323,y:900,t:1527189727926};\\\", \\\"{x:1323,y:898,t:1527189727944};\\\", \\\"{x:1325,y:895,t:1527189727961};\\\", \\\"{x:1325,y:893,t:1527189727993};\\\", \\\"{x:1325,y:892,t:1527189728018};\\\", \\\"{x:1325,y:890,t:1527189728034};\\\", \\\"{x:1325,y:889,t:1527189728065};\\\", \\\"{x:1324,y:889,t:1527189728077};\\\", \\\"{x:1324,y:887,t:1527189728093};\\\", \\\"{x:1324,y:886,t:1527189728113};\\\", \\\"{x:1324,y:884,t:1527189728137};\\\", \\\"{x:1324,y:883,t:1527189728153};\\\", \\\"{x:1324,y:881,t:1527189728194};\\\", \\\"{x:1322,y:880,t:1527189728211};\\\", \\\"{x:1322,y:879,t:1527189728234};\\\", \\\"{x:1322,y:878,t:1527189728244};\\\", \\\"{x:1322,y:877,t:1527189728261};\\\", \\\"{x:1322,y:875,t:1527189728277};\\\", \\\"{x:1322,y:874,t:1527189728293};\\\", \\\"{x:1321,y:872,t:1527189728311};\\\", \\\"{x:1321,y:869,t:1527189728327};\\\", \\\"{x:1320,y:867,t:1527189728343};\\\", \\\"{x:1320,y:864,t:1527189728361};\\\", \\\"{x:1319,y:861,t:1527189728378};\\\", \\\"{x:1318,y:857,t:1527189728394};\\\", \\\"{x:1318,y:854,t:1527189728411};\\\", \\\"{x:1318,y:849,t:1527189728428};\\\", \\\"{x:1318,y:844,t:1527189728443};\\\", \\\"{x:1317,y:838,t:1527189728461};\\\", \\\"{x:1317,y:832,t:1527189728478};\\\", \\\"{x:1315,y:826,t:1527189728493};\\\", \\\"{x:1314,y:821,t:1527189728510};\\\", \\\"{x:1313,y:812,t:1527189728527};\\\", \\\"{x:1313,y:806,t:1527189728543};\\\", \\\"{x:1313,y:805,t:1527189728560};\\\", \\\"{x:1316,y:785,t:1527189728577};\\\", \\\"{x:1320,y:770,t:1527189728593};\\\", \\\"{x:1322,y:761,t:1527189728610};\\\", \\\"{x:1325,y:744,t:1527189728627};\\\", \\\"{x:1326,y:736,t:1527189728644};\\\", \\\"{x:1327,y:722,t:1527189728660};\\\", \\\"{x:1331,y:704,t:1527189728678};\\\", \\\"{x:1332,y:689,t:1527189728694};\\\", \\\"{x:1334,y:676,t:1527189728711};\\\", \\\"{x:1334,y:669,t:1527189728728};\\\", \\\"{x:1336,y:662,t:1527189728744};\\\", \\\"{x:1336,y:658,t:1527189728760};\\\", \\\"{x:1338,y:641,t:1527189728777};\\\", \\\"{x:1338,y:632,t:1527189728793};\\\", \\\"{x:1338,y:618,t:1527189728810};\\\", \\\"{x:1339,y:608,t:1527189728827};\\\", \\\"{x:1339,y:602,t:1527189728844};\\\", \\\"{x:1339,y:596,t:1527189728860};\\\", \\\"{x:1340,y:592,t:1527189728877};\\\", \\\"{x:1340,y:587,t:1527189728894};\\\", \\\"{x:1340,y:581,t:1527189728910};\\\", \\\"{x:1339,y:578,t:1527189728927};\\\", \\\"{x:1339,y:574,t:1527189728944};\\\", \\\"{x:1338,y:570,t:1527189728960};\\\", \\\"{x:1334,y:567,t:1527189729074};\\\", \\\"{x:1328,y:567,t:1527189729081};\\\", \\\"{x:1320,y:565,t:1527189729094};\\\", \\\"{x:1303,y:560,t:1527189729111};\\\", \\\"{x:1298,y:560,t:1527189729127};\\\", \\\"{x:1297,y:560,t:1527189729153};\\\", \\\"{x:1297,y:558,t:1527189729161};\\\", \\\"{x:1297,y:553,t:1527189729178};\\\", \\\"{x:1299,y:544,t:1527189729194};\\\", \\\"{x:1302,y:537,t:1527189729210};\\\", \\\"{x:1307,y:526,t:1527189729227};\\\", \\\"{x:1312,y:518,t:1527189729244};\\\", \\\"{x:1315,y:514,t:1527189729261};\\\", \\\"{x:1316,y:510,t:1527189729278};\\\", \\\"{x:1318,y:507,t:1527189729295};\\\", \\\"{x:1320,y:502,t:1527189729312};\\\", \\\"{x:1321,y:496,t:1527189729328};\\\", \\\"{x:1323,y:490,t:1527189729344};\\\", \\\"{x:1325,y:486,t:1527189729361};\\\", \\\"{x:1326,y:486,t:1527189729378};\\\", \\\"{x:1326,y:485,t:1527189729418};\\\", \\\"{x:1326,y:484,t:1527189729427};\\\", \\\"{x:1326,y:483,t:1527189729445};\\\", \\\"{x:1326,y:482,t:1527189729473};\\\", \\\"{x:1325,y:481,t:1527189729481};\\\", \\\"{x:1324,y:481,t:1527189729642};\\\", \\\"{x:1324,y:482,t:1527189729650};\\\", \\\"{x:1324,y:484,t:1527189729662};\\\", \\\"{x:1322,y:485,t:1527189729678};\\\", \\\"{x:1321,y:487,t:1527189729695};\\\", \\\"{x:1321,y:489,t:1527189729711};\\\", \\\"{x:1320,y:489,t:1527189729729};\\\", \\\"{x:1319,y:491,t:1527189729746};\\\", \\\"{x:1318,y:491,t:1527189729762};\\\", \\\"{x:1317,y:493,t:1527189729779};\\\", \\\"{x:1317,y:494,t:1527189729795};\\\", \\\"{x:1316,y:494,t:1527189733754};\\\", \\\"{x:1316,y:498,t:1527189733765};\\\", \\\"{x:1316,y:504,t:1527189733783};\\\", \\\"{x:1317,y:510,t:1527189733798};\\\", \\\"{x:1319,y:514,t:1527189733815};\\\", \\\"{x:1319,y:516,t:1527189733832};\\\", \\\"{x:1320,y:518,t:1527189733848};\\\", \\\"{x:1320,y:521,t:1527189733865};\\\", \\\"{x:1321,y:528,t:1527189733881};\\\", \\\"{x:1323,y:533,t:1527189733898};\\\", \\\"{x:1323,y:538,t:1527189733915};\\\", \\\"{x:1323,y:543,t:1527189733932};\\\", \\\"{x:1323,y:550,t:1527189733948};\\\", \\\"{x:1320,y:559,t:1527189733965};\\\", \\\"{x:1320,y:563,t:1527189733982};\\\", \\\"{x:1319,y:567,t:1527189733999};\\\", \\\"{x:1319,y:571,t:1527189734015};\\\", \\\"{x:1319,y:579,t:1527189734032};\\\", \\\"{x:1319,y:592,t:1527189734048};\\\", \\\"{x:1319,y:608,t:1527189734065};\\\", \\\"{x:1319,y:633,t:1527189734082};\\\", \\\"{x:1317,y:650,t:1527189734100};\\\", \\\"{x:1317,y:666,t:1527189734115};\\\", \\\"{x:1317,y:684,t:1527189734132};\\\", \\\"{x:1317,y:703,t:1527189734149};\\\", \\\"{x:1317,y:721,t:1527189734165};\\\", \\\"{x:1317,y:745,t:1527189734182};\\\", \\\"{x:1317,y:775,t:1527189734199};\\\", \\\"{x:1317,y:801,t:1527189734215};\\\", \\\"{x:1317,y:820,t:1527189734232};\\\", \\\"{x:1317,y:847,t:1527189734249};\\\", \\\"{x:1317,y:853,t:1527189734265};\\\", \\\"{x:1317,y:865,t:1527189734282};\\\", \\\"{x:1317,y:880,t:1527189734299};\\\", \\\"{x:1320,y:899,t:1527189734315};\\\", \\\"{x:1321,y:914,t:1527189734332};\\\", \\\"{x:1324,y:933,t:1527189734349};\\\", \\\"{x:1326,y:945,t:1527189734365};\\\", \\\"{x:1327,y:951,t:1527189734382};\\\", \\\"{x:1330,y:955,t:1527189734399};\\\", \\\"{x:1331,y:958,t:1527189734415};\\\", \\\"{x:1331,y:964,t:1527189734433};\\\", \\\"{x:1331,y:985,t:1527189734450};\\\", \\\"{x:1331,y:997,t:1527189734465};\\\", \\\"{x:1331,y:1001,t:1527189734482};\\\", \\\"{x:1331,y:1003,t:1527189734498};\\\", \\\"{x:1331,y:1004,t:1527189734618};\\\", \\\"{x:1329,y:1004,t:1527189734631};\\\", \\\"{x:1322,y:1002,t:1527189734649};\\\", \\\"{x:1322,y:1000,t:1527189734665};\\\", \\\"{x:1319,y:997,t:1527189734681};\\\", \\\"{x:1317,y:994,t:1527189734698};\\\", \\\"{x:1312,y:989,t:1527189734716};\\\", \\\"{x:1312,y:988,t:1527189734731};\\\", \\\"{x:1312,y:986,t:1527189734761};\\\", \\\"{x:1312,y:985,t:1527189734776};\\\", \\\"{x:1311,y:985,t:1527189734784};\\\", \\\"{x:1311,y:983,t:1527189734798};\\\", \\\"{x:1311,y:982,t:1527189734825};\\\", \\\"{x:1311,y:980,t:1527189734857};\\\", \\\"{x:1311,y:979,t:1527189734872};\\\", \\\"{x:1312,y:976,t:1527189734881};\\\", \\\"{x:1312,y:969,t:1527189734898};\\\", \\\"{x:1316,y:964,t:1527189734915};\\\", \\\"{x:1318,y:961,t:1527189734932};\\\", \\\"{x:1319,y:960,t:1527189734948};\\\", \\\"{x:1319,y:958,t:1527189734965};\\\", \\\"{x:1319,y:956,t:1527189734982};\\\", \\\"{x:1319,y:954,t:1527189734999};\\\", \\\"{x:1320,y:954,t:1527189735015};\\\", \\\"{x:1320,y:956,t:1527189735217};\\\", \\\"{x:1320,y:957,t:1527189735289};\\\", \\\"{x:1320,y:958,t:1527189735298};\\\", \\\"{x:1319,y:959,t:1527189735315};\\\", \\\"{x:1318,y:961,t:1527189735332};\\\", \\\"{x:1318,y:962,t:1527189735349};\\\", \\\"{x:1318,y:963,t:1527189735401};\\\", \\\"{x:1318,y:965,t:1527189735417};\\\", \\\"{x:1318,y:967,t:1527189735440};\\\", \\\"{x:1318,y:969,t:1527189735457};\\\", \\\"{x:1318,y:970,t:1527189735537};\\\", \\\"{x:1318,y:971,t:1527189735561};\\\", \\\"{x:1318,y:972,t:1527189735634};\\\", \\\"{x:1330,y:974,t:1527189735650};\\\", \\\"{x:1350,y:977,t:1527189735666};\\\", \\\"{x:1362,y:979,t:1527189735683};\\\", \\\"{x:1373,y:980,t:1527189735701};\\\", \\\"{x:1378,y:980,t:1527189735716};\\\", \\\"{x:1380,y:980,t:1527189735733};\\\", \\\"{x:1381,y:981,t:1527189735750};\\\", \\\"{x:1381,y:980,t:1527189736042};\\\", \\\"{x:1381,y:978,t:1527189736049};\\\", \\\"{x:1381,y:976,t:1527189736067};\\\", \\\"{x:1381,y:973,t:1527189736083};\\\", \\\"{x:1381,y:972,t:1527189736106};\\\", \\\"{x:1381,y:970,t:1527189736145};\\\", \\\"{x:1381,y:969,t:1527189736265};\\\", \\\"{x:1382,y:969,t:1527189736530};\\\", \\\"{x:1385,y:969,t:1527189736538};\\\", \\\"{x:1388,y:969,t:1527189736550};\\\", \\\"{x:1390,y:971,t:1527189736567};\\\", \\\"{x:1392,y:971,t:1527189736584};\\\", \\\"{x:1396,y:972,t:1527189736601};\\\", \\\"{x:1402,y:972,t:1527189736617};\\\", \\\"{x:1405,y:972,t:1527189736633};\\\", \\\"{x:1406,y:972,t:1527189736650};\\\", \\\"{x:1410,y:973,t:1527189736667};\\\", \\\"{x:1413,y:973,t:1527189736684};\\\", \\\"{x:1416,y:973,t:1527189736700};\\\", \\\"{x:1418,y:973,t:1527189736745};\\\", \\\"{x:1419,y:973,t:1527189736770};\\\", \\\"{x:1420,y:973,t:1527189736786};\\\", \\\"{x:1421,y:973,t:1527189736801};\\\", \\\"{x:1422,y:973,t:1527189736818};\\\", \\\"{x:1425,y:972,t:1527189736834};\\\", \\\"{x:1431,y:969,t:1527189736852};\\\", \\\"{x:1434,y:968,t:1527189736867};\\\", \\\"{x:1437,y:968,t:1527189736884};\\\", \\\"{x:1439,y:968,t:1527189736901};\\\", \\\"{x:1440,y:968,t:1527189736917};\\\", \\\"{x:1441,y:967,t:1527189737034};\\\", \\\"{x:1443,y:967,t:1527189737051};\\\", \\\"{x:1444,y:967,t:1527189737209};\\\", \\\"{x:1445,y:966,t:1527189737217};\\\", \\\"{x:1446,y:966,t:1527189737234};\\\", \\\"{x:1448,y:966,t:1527189737458};\\\", \\\"{x:1449,y:966,t:1527189737468};\\\", \\\"{x:1450,y:966,t:1527189737484};\\\", \\\"{x:1454,y:968,t:1527189737501};\\\", \\\"{x:1458,y:969,t:1527189737518};\\\", \\\"{x:1464,y:971,t:1527189737533};\\\", \\\"{x:1471,y:973,t:1527189737550};\\\", \\\"{x:1480,y:975,t:1527189737568};\\\", \\\"{x:1484,y:976,t:1527189737584};\\\", \\\"{x:1485,y:976,t:1527189737600};\\\", \\\"{x:1488,y:977,t:1527189737617};\\\", \\\"{x:1489,y:977,t:1527189737635};\\\", \\\"{x:1491,y:977,t:1527189737673};\\\", \\\"{x:1492,y:977,t:1527189737684};\\\", \\\"{x:1493,y:977,t:1527189737753};\\\", \\\"{x:1494,y:977,t:1527189737768};\\\", \\\"{x:1500,y:977,t:1527189737786};\\\", \\\"{x:1502,y:977,t:1527189737802};\\\", \\\"{x:1506,y:977,t:1527189737817};\\\", \\\"{x:1508,y:977,t:1527189737835};\\\", \\\"{x:1509,y:977,t:1527189737851};\\\", \\\"{x:1512,y:977,t:1527189737868};\\\", \\\"{x:1515,y:976,t:1527189737885};\\\", \\\"{x:1519,y:974,t:1527189737901};\\\", \\\"{x:1522,y:973,t:1527189737918};\\\", \\\"{x:1522,y:971,t:1527189738138};\\\", \\\"{x:1522,y:970,t:1527189738306};\\\", \\\"{x:1523,y:970,t:1527189738457};\\\", \\\"{x:1525,y:970,t:1527189738497};\\\", \\\"{x:1526,y:970,t:1527189738505};\\\", \\\"{x:1529,y:970,t:1527189738520};\\\", \\\"{x:1534,y:970,t:1527189738535};\\\", \\\"{x:1536,y:970,t:1527189738552};\\\", \\\"{x:1537,y:971,t:1527189738569};\\\", \\\"{x:1538,y:971,t:1527189738602};\\\", \\\"{x:1539,y:971,t:1527189738619};\\\", \\\"{x:1542,y:972,t:1527189738635};\\\", \\\"{x:1545,y:972,t:1527189738652};\\\", \\\"{x:1547,y:972,t:1527189738681};\\\", \\\"{x:1549,y:973,t:1527189738689};\\\", \\\"{x:1553,y:974,t:1527189738702};\\\", \\\"{x:1558,y:974,t:1527189738719};\\\", \\\"{x:1565,y:976,t:1527189738736};\\\", \\\"{x:1569,y:976,t:1527189738753};\\\", \\\"{x:1572,y:976,t:1527189738801};\\\", \\\"{x:1573,y:976,t:1527189738841};\\\", \\\"{x:1574,y:976,t:1527189738914};\\\", \\\"{x:1576,y:976,t:1527189738929};\\\", \\\"{x:1577,y:976,t:1527189738993};\\\", \\\"{x:1578,y:975,t:1527189739002};\\\", \\\"{x:1578,y:974,t:1527189739033};\\\", \\\"{x:1579,y:974,t:1527189739041};\\\", \\\"{x:1579,y:972,t:1527189739058};\\\", \\\"{x:1580,y:970,t:1527189739073};\\\", \\\"{x:1581,y:970,t:1527189739086};\\\", \\\"{x:1581,y:969,t:1527189739103};\\\", \\\"{x:1581,y:968,t:1527189739119};\\\", \\\"{x:1582,y:967,t:1527189739136};\\\", \\\"{x:1583,y:967,t:1527189739322};\\\", \\\"{x:1584,y:967,t:1527189739336};\\\", \\\"{x:1595,y:967,t:1527189739352};\\\", \\\"{x:1602,y:969,t:1527189739370};\\\", \\\"{x:1605,y:970,t:1527189739385};\\\", \\\"{x:1607,y:970,t:1527189739403};\\\", \\\"{x:1608,y:970,t:1527189739433};\\\", \\\"{x:1609,y:970,t:1527189739449};\\\", \\\"{x:1610,y:970,t:1527189739465};\\\", \\\"{x:1612,y:970,t:1527189739474};\\\", \\\"{x:1616,y:970,t:1527189739486};\\\", \\\"{x:1620,y:970,t:1527189739504};\\\", \\\"{x:1624,y:970,t:1527189739519};\\\", \\\"{x:1628,y:970,t:1527189739536};\\\", \\\"{x:1634,y:969,t:1527189739553};\\\", \\\"{x:1634,y:968,t:1527189739570};\\\", \\\"{x:1637,y:968,t:1527189739586};\\\", \\\"{x:1641,y:968,t:1527189739604};\\\", \\\"{x:1644,y:967,t:1527189739620};\\\", \\\"{x:1645,y:967,t:1527189739637};\\\", \\\"{x:1648,y:967,t:1527189739654};\\\", \\\"{x:1651,y:965,t:1527189739670};\\\", \\\"{x:1655,y:965,t:1527189739686};\\\", \\\"{x:1659,y:965,t:1527189739702};\\\", \\\"{x:1662,y:965,t:1527189739719};\\\", \\\"{x:1665,y:965,t:1527189739736};\\\", \\\"{x:1666,y:965,t:1527189739753};\\\", \\\"{x:1667,y:967,t:1527189739961};\\\", \\\"{x:1667,y:968,t:1527189739970};\\\", \\\"{x:1669,y:970,t:1527189739986};\\\", \\\"{x:1669,y:972,t:1527189740004};\\\", \\\"{x:1671,y:974,t:1527189740020};\\\", \\\"{x:1672,y:975,t:1527189740057};\\\", \\\"{x:1675,y:976,t:1527189740070};\\\", \\\"{x:1683,y:978,t:1527189740086};\\\", \\\"{x:1694,y:979,t:1527189740103};\\\", \\\"{x:1704,y:982,t:1527189740120};\\\", \\\"{x:1710,y:983,t:1527189740136};\\\", \\\"{x:1712,y:984,t:1527189740153};\\\", \\\"{x:1713,y:984,t:1527189740192};\\\", \\\"{x:1714,y:984,t:1527189740216};\\\", \\\"{x:1716,y:984,t:1527189740257};\\\", \\\"{x:1716,y:983,t:1527189740272};\\\", \\\"{x:1717,y:981,t:1527189740289};\\\", \\\"{x:1717,y:980,t:1527189740303};\\\", \\\"{x:1717,y:979,t:1527189740320};\\\", \\\"{x:1717,y:978,t:1527189740360};\\\", \\\"{x:1717,y:977,t:1527189740369};\\\", \\\"{x:1717,y:976,t:1527189740387};\\\", \\\"{x:1717,y:975,t:1527189740409};\\\", \\\"{x:1718,y:974,t:1527189740419};\\\", \\\"{x:1720,y:972,t:1527189740437};\\\", \\\"{x:1720,y:971,t:1527189740453};\\\", \\\"{x:1720,y:970,t:1527189740474};\\\", \\\"{x:1721,y:970,t:1527189740593};\\\", \\\"{x:1723,y:970,t:1527189740617};\\\", \\\"{x:1726,y:971,t:1527189740624};\\\", \\\"{x:1727,y:972,t:1527189740637};\\\", \\\"{x:1734,y:976,t:1527189740654};\\\", \\\"{x:1739,y:979,t:1527189740670};\\\", \\\"{x:1744,y:981,t:1527189740687};\\\", \\\"{x:1749,y:982,t:1527189740704};\\\", \\\"{x:1750,y:982,t:1527189740729};\\\", \\\"{x:1751,y:982,t:1527189740744};\\\", \\\"{x:1753,y:982,t:1527189740753};\\\", \\\"{x:1760,y:983,t:1527189740770};\\\", \\\"{x:1768,y:984,t:1527189740787};\\\", \\\"{x:1775,y:985,t:1527189740804};\\\", \\\"{x:1782,y:985,t:1527189740820};\\\", \\\"{x:1783,y:985,t:1527189740837};\\\", \\\"{x:1785,y:986,t:1527189740854};\\\", \\\"{x:1786,y:986,t:1527189740870};\\\", \\\"{x:1786,y:984,t:1527189741026};\\\", \\\"{x:1785,y:983,t:1527189741066};\\\", \\\"{x:1785,y:981,t:1527189741073};\\\", \\\"{x:1785,y:980,t:1527189741087};\\\", \\\"{x:1781,y:974,t:1527189741106};\\\", \\\"{x:1779,y:973,t:1527189741121};\\\", \\\"{x:1778,y:972,t:1527189741137};\\\", \\\"{x:1777,y:971,t:1527189741186};\\\", \\\"{x:1777,y:970,t:1527189741194};\\\", \\\"{x:1774,y:967,t:1527189741204};\\\", \\\"{x:1773,y:966,t:1527189741221};\\\", \\\"{x:1773,y:965,t:1527189741238};\\\", \\\"{x:1772,y:964,t:1527189741255};\\\", \\\"{x:1771,y:963,t:1527189741272};\\\", \\\"{x:1771,y:962,t:1527189741818};\\\", \\\"{x:1772,y:962,t:1527189741850};\\\", \\\"{x:1774,y:962,t:1527189741874};\\\", \\\"{x:1775,y:962,t:1527189742042};\\\", \\\"{x:1776,y:962,t:1527189744633};\\\", \\\"{x:1775,y:963,t:1527189744682};\\\", \\\"{x:1774,y:964,t:1527189744697};\\\", \\\"{x:1771,y:964,t:1527189744707};\\\", \\\"{x:1763,y:965,t:1527189744724};\\\", \\\"{x:1750,y:967,t:1527189744741};\\\", \\\"{x:1742,y:969,t:1527189744758};\\\", \\\"{x:1728,y:971,t:1527189744774};\\\", \\\"{x:1715,y:974,t:1527189744791};\\\", \\\"{x:1703,y:975,t:1527189744807};\\\", \\\"{x:1697,y:977,t:1527189744824};\\\", \\\"{x:1695,y:977,t:1527189744841};\\\", \\\"{x:1694,y:977,t:1527189744857};\\\", \\\"{x:1693,y:978,t:1527189744873};\\\", \\\"{x:1684,y:981,t:1527189744889};\\\", \\\"{x:1670,y:983,t:1527189744906};\\\", \\\"{x:1654,y:985,t:1527189744923};\\\", \\\"{x:1647,y:987,t:1527189744940};\\\", \\\"{x:1645,y:989,t:1527189744957};\\\", \\\"{x:1636,y:991,t:1527189744973};\\\", \\\"{x:1630,y:993,t:1527189744990};\\\", \\\"{x:1621,y:993,t:1527189745007};\\\", \\\"{x:1612,y:995,t:1527189745023};\\\", \\\"{x:1608,y:995,t:1527189745040};\\\", \\\"{x:1607,y:995,t:1527189745065};\\\", \\\"{x:1606,y:996,t:1527189745089};\\\", \\\"{x:1599,y:998,t:1527189745107};\\\", \\\"{x:1593,y:998,t:1527189745124};\\\", \\\"{x:1590,y:998,t:1527189745141};\\\", \\\"{x:1582,y:998,t:1527189745157};\\\", \\\"{x:1569,y:998,t:1527189745174};\\\", \\\"{x:1555,y:998,t:1527189745191};\\\", \\\"{x:1537,y:999,t:1527189745207};\\\", \\\"{x:1519,y:999,t:1527189745225};\\\", \\\"{x:1513,y:999,t:1527189745240};\\\", \\\"{x:1487,y:999,t:1527189745257};\\\", \\\"{x:1468,y:999,t:1527189745275};\\\", \\\"{x:1461,y:999,t:1527189745290};\\\", \\\"{x:1448,y:999,t:1527189745308};\\\", \\\"{x:1431,y:998,t:1527189745325};\\\", \\\"{x:1409,y:996,t:1527189745340};\\\", \\\"{x:1386,y:995,t:1527189745358};\\\", \\\"{x:1372,y:995,t:1527189745375};\\\", \\\"{x:1359,y:995,t:1527189745391};\\\", \\\"{x:1347,y:993,t:1527189745407};\\\", \\\"{x:1330,y:990,t:1527189745423};\\\", \\\"{x:1315,y:986,t:1527189745440};\\\", \\\"{x:1290,y:982,t:1527189745457};\\\", \\\"{x:1281,y:981,t:1527189745474};\\\", \\\"{x:1281,y:980,t:1527189745569};\\\", \\\"{x:1281,y:979,t:1527189745609};\\\", \\\"{x:1282,y:978,t:1527189745624};\\\", \\\"{x:1289,y:977,t:1527189745641};\\\", \\\"{x:1292,y:977,t:1527189745657};\\\", \\\"{x:1293,y:977,t:1527189745977};\\\", \\\"{x:1298,y:977,t:1527189745992};\\\", \\\"{x:1311,y:977,t:1527189746009};\\\", \\\"{x:1326,y:977,t:1527189746024};\\\", \\\"{x:1339,y:977,t:1527189746041};\\\", \\\"{x:1345,y:977,t:1527189746059};\\\", \\\"{x:1346,y:976,t:1527189746313};\\\", \\\"{x:1346,y:975,t:1527189746325};\\\", \\\"{x:1343,y:975,t:1527189746341};\\\", \\\"{x:1340,y:975,t:1527189746358};\\\", \\\"{x:1336,y:975,t:1527189746374};\\\", \\\"{x:1332,y:975,t:1527189746391};\\\", \\\"{x:1331,y:975,t:1527189746408};\\\", \\\"{x:1329,y:975,t:1527189746425};\\\", \\\"{x:1328,y:975,t:1527189746441};\\\", \\\"{x:1324,y:975,t:1527189746459};\\\", \\\"{x:1318,y:973,t:1527189746476};\\\", \\\"{x:1316,y:972,t:1527189746492};\\\", \\\"{x:1314,y:971,t:1527189746508};\\\", \\\"{x:1314,y:969,t:1527189746690};\\\", \\\"{x:1314,y:968,t:1527189747002};\\\", \\\"{x:1315,y:968,t:1527189747154};\\\", \\\"{x:1317,y:969,t:1527189747170};\\\", \\\"{x:1318,y:969,t:1527189747185};\\\", \\\"{x:1319,y:969,t:1527189747193};\\\", \\\"{x:1320,y:970,t:1527189747209};\\\", \\\"{x:1323,y:972,t:1527189747226};\\\", \\\"{x:1324,y:973,t:1527189747242};\\\", \\\"{x:1325,y:973,t:1527189747298};\\\", \\\"{x:1326,y:973,t:1527189747321};\\\", \\\"{x:1327,y:974,t:1527189747337};\\\", \\\"{x:1328,y:974,t:1527189747345};\\\", \\\"{x:1329,y:975,t:1527189747359};\\\", \\\"{x:1330,y:976,t:1527189747375};\\\", \\\"{x:1333,y:977,t:1527189747393};\\\", \\\"{x:1335,y:979,t:1527189747408};\\\", \\\"{x:1339,y:979,t:1527189747425};\\\", \\\"{x:1342,y:981,t:1527189747442};\\\", \\\"{x:1347,y:982,t:1527189747459};\\\", \\\"{x:1349,y:982,t:1527189747475};\\\", \\\"{x:1350,y:982,t:1527189747493};\\\", \\\"{x:1353,y:983,t:1527189747509};\\\", \\\"{x:1356,y:983,t:1527189747525};\\\", \\\"{x:1357,y:983,t:1527189747542};\\\", \\\"{x:1359,y:983,t:1527189747559};\\\", \\\"{x:1364,y:984,t:1527189747575};\\\", \\\"{x:1365,y:984,t:1527189747592};\\\", \\\"{x:1366,y:984,t:1527189747609};\\\", \\\"{x:1368,y:984,t:1527189747648};\\\", \\\"{x:1370,y:984,t:1527189747673};\\\", \\\"{x:1373,y:984,t:1527189747696};\\\", \\\"{x:1375,y:984,t:1527189747712};\\\", \\\"{x:1376,y:983,t:1527189747726};\\\", \\\"{x:1379,y:983,t:1527189747742};\\\", \\\"{x:1381,y:983,t:1527189747759};\\\", \\\"{x:1383,y:982,t:1527189747776};\\\", \\\"{x:1385,y:982,t:1527189747792};\\\", \\\"{x:1387,y:981,t:1527189747808};\\\", \\\"{x:1387,y:980,t:1527189747826};\\\", \\\"{x:1388,y:980,t:1527189747842};\\\", \\\"{x:1389,y:980,t:1527189747859};\\\", \\\"{x:1390,y:979,t:1527189747876};\\\", \\\"{x:1390,y:978,t:1527189747892};\\\", \\\"{x:1390,y:977,t:1527189747913};\\\", \\\"{x:1390,y:976,t:1527189747945};\\\", \\\"{x:1390,y:974,t:1527189748073};\\\", \\\"{x:1390,y:972,t:1527189748113};\\\", \\\"{x:1390,y:970,t:1527189748145};\\\", \\\"{x:1391,y:969,t:1527189748169};\\\", \\\"{x:1393,y:969,t:1527189748386};\\\", \\\"{x:1394,y:969,t:1527189748394};\\\", \\\"{x:1395,y:969,t:1527189748409};\\\", \\\"{x:1396,y:969,t:1527189748427};\\\", \\\"{x:1398,y:970,t:1527189748457};\\\", \\\"{x:1399,y:972,t:1527189748514};\\\", \\\"{x:1400,y:973,t:1527189748529};\\\", \\\"{x:1402,y:976,t:1527189748543};\\\", \\\"{x:1404,y:977,t:1527189748559};\\\", \\\"{x:1408,y:979,t:1527189748576};\\\", \\\"{x:1409,y:980,t:1527189748593};\\\", \\\"{x:1411,y:980,t:1527189748616};\\\", \\\"{x:1412,y:980,t:1527189748626};\\\", \\\"{x:1413,y:980,t:1527189748643};\\\", \\\"{x:1414,y:980,t:1527189748660};\\\", \\\"{x:1417,y:981,t:1527189748676};\\\", \\\"{x:1419,y:981,t:1527189748693};\\\", \\\"{x:1421,y:981,t:1527189748710};\\\", \\\"{x:1424,y:981,t:1527189748726};\\\", \\\"{x:1427,y:981,t:1527189748743};\\\", \\\"{x:1430,y:982,t:1527189748760};\\\", \\\"{x:1434,y:982,t:1527189748776};\\\", \\\"{x:1435,y:982,t:1527189748794};\\\", \\\"{x:1437,y:982,t:1527189748811};\\\", \\\"{x:1438,y:982,t:1527189748826};\\\", \\\"{x:1439,y:982,t:1527189748849};\\\", \\\"{x:1440,y:982,t:1527189748873};\\\", \\\"{x:1441,y:982,t:1527189748905};\\\", \\\"{x:1442,y:982,t:1527189748962};\\\", \\\"{x:1443,y:980,t:1527189749001};\\\", \\\"{x:1444,y:979,t:1527189749041};\\\", \\\"{x:1444,y:978,t:1527189749073};\\\", \\\"{x:1444,y:977,t:1527189749081};\\\", \\\"{x:1445,y:976,t:1527189749114};\\\", \\\"{x:1445,y:975,t:1527189749137};\\\", \\\"{x:1446,y:974,t:1527189749169};\\\", \\\"{x:1447,y:973,t:1527189749209};\\\", \\\"{x:1448,y:972,t:1527189749233};\\\", \\\"{x:1449,y:971,t:1527189749249};\\\", \\\"{x:1449,y:972,t:1527189749498};\\\", \\\"{x:1449,y:973,t:1527189749511};\\\", \\\"{x:1449,y:975,t:1527189749527};\\\", \\\"{x:1450,y:977,t:1527189749544};\\\", \\\"{x:1451,y:978,t:1527189749560};\\\", \\\"{x:1454,y:981,t:1527189749578};\\\", \\\"{x:1455,y:982,t:1527189749595};\\\", \\\"{x:1457,y:984,t:1527189749611};\\\", \\\"{x:1460,y:987,t:1527189749628};\\\", \\\"{x:1461,y:987,t:1527189749644};\\\", \\\"{x:1463,y:989,t:1527189749661};\\\", \\\"{x:1465,y:990,t:1527189749677};\\\", \\\"{x:1466,y:990,t:1527189749694};\\\", \\\"{x:1469,y:991,t:1527189749711};\\\", \\\"{x:1471,y:992,t:1527189749728};\\\", \\\"{x:1482,y:993,t:1527189749745};\\\", \\\"{x:1486,y:993,t:1527189749761};\\\", \\\"{x:1494,y:993,t:1527189749777};\\\", \\\"{x:1499,y:993,t:1527189749794};\\\", \\\"{x:1500,y:993,t:1527189749810};\\\", \\\"{x:1503,y:993,t:1527189749828};\\\", \\\"{x:1504,y:993,t:1527189749844};\\\", \\\"{x:1505,y:993,t:1527189749873};\\\", \\\"{x:1506,y:991,t:1527189749881};\\\", \\\"{x:1507,y:991,t:1527189749894};\\\", \\\"{x:1508,y:989,t:1527189749912};\\\", \\\"{x:1510,y:988,t:1527189749928};\\\", \\\"{x:1510,y:987,t:1527189749961};\\\", \\\"{x:1510,y:985,t:1527189749978};\\\", \\\"{x:1511,y:984,t:1527189749994};\\\", \\\"{x:1512,y:981,t:1527189750011};\\\", \\\"{x:1513,y:979,t:1527189750033};\\\", \\\"{x:1513,y:978,t:1527189750057};\\\", \\\"{x:1514,y:976,t:1527189750073};\\\", \\\"{x:1514,y:975,t:1527189750097};\\\", \\\"{x:1514,y:974,t:1527189750121};\\\", \\\"{x:1514,y:973,t:1527189750129};\\\", \\\"{x:1516,y:972,t:1527189750144};\\\", \\\"{x:1516,y:969,t:1527189750161};\\\", \\\"{x:1517,y:969,t:1527189752817};\\\", \\\"{x:1519,y:969,t:1527189752829};\\\", \\\"{x:1519,y:970,t:1527189752846};\\\", \\\"{x:1523,y:972,t:1527189752863};\\\", \\\"{x:1526,y:972,t:1527189752879};\\\", \\\"{x:1534,y:974,t:1527189752897};\\\", \\\"{x:1537,y:975,t:1527189752913};\\\", \\\"{x:1538,y:975,t:1527189752929};\\\", \\\"{x:1541,y:975,t:1527189752946};\\\", \\\"{x:1543,y:975,t:1527189752968};\\\", \\\"{x:1543,y:976,t:1527189752980};\\\", \\\"{x:1546,y:976,t:1527189752996};\\\", \\\"{x:1548,y:976,t:1527189753014};\\\", \\\"{x:1549,y:976,t:1527189753031};\\\", \\\"{x:1550,y:976,t:1527189753047};\\\", \\\"{x:1551,y:976,t:1527189753617};\\\", \\\"{x:1551,y:975,t:1527189753752};\\\", \\\"{x:1551,y:974,t:1527189753764};\\\", \\\"{x:1551,y:972,t:1527189753784};\\\", \\\"{x:1551,y:971,t:1527189753840};\\\", \\\"{x:1551,y:970,t:1527189753945};\\\", \\\"{x:1551,y:969,t:1527189755338};\\\", \\\"{x:1550,y:969,t:1527189755377};\\\", \\\"{x:1549,y:969,t:1527189761842};\\\", \\\"{x:1544,y:969,t:1527189761854};\\\", \\\"{x:1539,y:970,t:1527189761871};\\\", \\\"{x:1532,y:971,t:1527189761887};\\\", \\\"{x:1516,y:971,t:1527189761906};\\\", \\\"{x:1506,y:973,t:1527189761921};\\\", \\\"{x:1499,y:973,t:1527189761937};\\\", \\\"{x:1491,y:973,t:1527189761954};\\\", \\\"{x:1475,y:972,t:1527189761971};\\\", \\\"{x:1464,y:972,t:1527189761987};\\\", \\\"{x:1453,y:972,t:1527189762005};\\\", \\\"{x:1440,y:969,t:1527189762021};\\\", \\\"{x:1428,y:968,t:1527189762037};\\\", \\\"{x:1426,y:967,t:1527189762054};\\\", \\\"{x:1414,y:967,t:1527189762072};\\\", \\\"{x:1408,y:967,t:1527189762087};\\\", \\\"{x:1398,y:967,t:1527189762106};\\\", \\\"{x:1396,y:965,t:1527189762121};\\\", \\\"{x:1395,y:965,t:1527189762138};\\\", \\\"{x:1393,y:965,t:1527189762162};\\\", \\\"{x:1392,y:964,t:1527189762171};\\\", \\\"{x:1389,y:963,t:1527189762187};\\\", \\\"{x:1383,y:961,t:1527189762205};\\\", \\\"{x:1376,y:959,t:1527189762221};\\\", \\\"{x:1366,y:957,t:1527189762237};\\\", \\\"{x:1353,y:951,t:1527189762254};\\\", \\\"{x:1349,y:950,t:1527189762271};\\\", \\\"{x:1348,y:950,t:1527189762288};\\\", \\\"{x:1347,y:949,t:1527189762473};\\\", \\\"{x:1347,y:948,t:1527189762489};\\\", \\\"{x:1347,y:946,t:1527189762521};\\\", \\\"{x:1347,y:945,t:1527189762544};\\\", \\\"{x:1347,y:943,t:1527189762561};\\\", \\\"{x:1347,y:942,t:1527189762592};\\\", \\\"{x:1347,y:941,t:1527189762604};\\\", \\\"{x:1347,y:940,t:1527189762621};\\\", \\\"{x:1347,y:939,t:1527189762637};\\\", \\\"{x:1347,y:938,t:1527189762654};\\\", \\\"{x:1347,y:937,t:1527189762672};\\\", \\\"{x:1347,y:936,t:1527189762729};\\\", \\\"{x:1350,y:935,t:1527189762738};\\\", \\\"{x:1362,y:936,t:1527189762754};\\\", \\\"{x:1377,y:940,t:1527189762771};\\\", \\\"{x:1393,y:948,t:1527189762788};\\\", \\\"{x:1413,y:955,t:1527189762805};\\\", \\\"{x:1434,y:961,t:1527189762821};\\\", \\\"{x:1447,y:966,t:1527189762838};\\\", \\\"{x:1463,y:970,t:1527189762855};\\\", \\\"{x:1466,y:974,t:1527189762870};\\\", \\\"{x:1469,y:974,t:1527189762888};\\\", \\\"{x:1473,y:974,t:1527189762905};\\\", \\\"{x:1477,y:975,t:1527189762921};\\\", \\\"{x:1484,y:975,t:1527189762938};\\\", \\\"{x:1498,y:977,t:1527189762955};\\\", \\\"{x:1510,y:979,t:1527189762972};\\\", \\\"{x:1518,y:980,t:1527189762988};\\\", \\\"{x:1521,y:980,t:1527189763005};\\\", \\\"{x:1522,y:980,t:1527189763021};\\\", \\\"{x:1523,y:981,t:1527189763106};\\\", \\\"{x:1524,y:981,t:1527189763225};\\\", \\\"{x:1522,y:980,t:1527189763241};\\\", \\\"{x:1520,y:980,t:1527189763255};\\\", \\\"{x:1502,y:980,t:1527189763272};\\\", \\\"{x:1493,y:980,t:1527189763288};\\\", \\\"{x:1476,y:977,t:1527189763305};\\\", \\\"{x:1457,y:975,t:1527189763322};\\\", \\\"{x:1440,y:977,t:1527189763338};\\\", \\\"{x:1436,y:977,t:1527189763355};\\\", \\\"{x:1429,y:979,t:1527189763372};\\\", \\\"{x:1426,y:981,t:1527189763388};\\\", \\\"{x:1425,y:981,t:1527189763441};\\\", \\\"{x:1429,y:981,t:1527189763626};\\\", \\\"{x:1436,y:981,t:1527189763639};\\\", \\\"{x:1450,y:982,t:1527189763656};\\\", \\\"{x:1470,y:982,t:1527189763672};\\\", \\\"{x:1491,y:983,t:1527189763689};\\\", \\\"{x:1498,y:983,t:1527189763706};\\\", \\\"{x:1508,y:983,t:1527189763722};\\\", \\\"{x:1518,y:983,t:1527189763739};\\\", \\\"{x:1529,y:983,t:1527189763755};\\\", \\\"{x:1537,y:983,t:1527189763772};\\\", \\\"{x:1538,y:983,t:1527189763789};\\\", \\\"{x:1539,y:982,t:1527189763805};\\\", \\\"{x:1540,y:981,t:1527189763897};\\\", \\\"{x:1542,y:981,t:1527189763905};\\\", \\\"{x:1544,y:980,t:1527189763922};\\\", \\\"{x:1545,y:978,t:1527189763939};\\\", \\\"{x:1545,y:977,t:1527189763956};\\\", \\\"{x:1546,y:977,t:1527189763973};\\\", \\\"{x:1547,y:976,t:1527189764058};\\\", \\\"{x:1547,y:975,t:1527189764378};\\\", \\\"{x:1547,y:974,t:1527189764633};\\\", \\\"{x:1547,y:973,t:1527189764897};\\\", \\\"{x:1547,y:972,t:1527189764906};\\\", \\\"{x:1548,y:970,t:1527189765057};\\\", \\\"{x:1548,y:969,t:1527189765072};\\\", \\\"{x:1549,y:967,t:1527189765091};\\\", \\\"{x:1549,y:966,t:1527189765106};\\\", \\\"{x:1549,y:963,t:1527189765123};\\\", \\\"{x:1552,y:962,t:1527189765141};\\\", \\\"{x:1552,y:959,t:1527189765157};\\\", \\\"{x:1552,y:957,t:1527189765173};\\\", \\\"{x:1552,y:955,t:1527189765191};\\\", \\\"{x:1552,y:949,t:1527189765207};\\\", \\\"{x:1552,y:946,t:1527189765223};\\\", \\\"{x:1551,y:939,t:1527189765241};\\\", \\\"{x:1550,y:932,t:1527189765257};\\\", \\\"{x:1549,y:928,t:1527189765273};\\\", \\\"{x:1549,y:927,t:1527189765290};\\\", \\\"{x:1549,y:918,t:1527189765306};\\\", \\\"{x:1549,y:915,t:1527189765322};\\\", \\\"{x:1549,y:912,t:1527189765340};\\\", \\\"{x:1549,y:911,t:1527189765357};\\\", \\\"{x:1549,y:909,t:1527189765373};\\\", \\\"{x:1549,y:908,t:1527189765392};\\\", \\\"{x:1549,y:906,t:1527189765432};\\\", \\\"{x:1549,y:905,t:1527189765456};\\\", \\\"{x:1549,y:903,t:1527189765473};\\\", \\\"{x:1548,y:901,t:1527189765490};\\\", \\\"{x:1548,y:899,t:1527189765507};\\\", \\\"{x:1548,y:895,t:1527189765523};\\\", \\\"{x:1548,y:892,t:1527189765540};\\\", \\\"{x:1547,y:887,t:1527189765557};\\\", \\\"{x:1545,y:883,t:1527189765573};\\\", \\\"{x:1545,y:876,t:1527189765590};\\\", \\\"{x:1545,y:874,t:1527189765607};\\\", \\\"{x:1545,y:870,t:1527189765623};\\\", \\\"{x:1544,y:866,t:1527189765641};\\\", \\\"{x:1543,y:863,t:1527189765658};\\\", \\\"{x:1543,y:862,t:1527189765674};\\\", \\\"{x:1543,y:861,t:1527189765697};\\\", \\\"{x:1542,y:861,t:1527189765713};\\\", \\\"{x:1541,y:860,t:1527189765723};\\\", \\\"{x:1541,y:859,t:1527189765740};\\\", \\\"{x:1541,y:858,t:1527189765757};\\\", \\\"{x:1541,y:857,t:1527189765810};\\\", \\\"{x:1541,y:856,t:1527189766113};\\\", \\\"{x:1541,y:855,t:1527189766125};\\\", \\\"{x:1542,y:853,t:1527189766161};\\\", \\\"{x:1542,y:852,t:1527189766185};\\\", \\\"{x:1542,y:854,t:1527189766546};\\\", \\\"{x:1542,y:857,t:1527189766557};\\\", \\\"{x:1537,y:869,t:1527189766574};\\\", \\\"{x:1531,y:883,t:1527189766591};\\\", \\\"{x:1525,y:897,t:1527189766608};\\\", \\\"{x:1519,y:907,t:1527189766623};\\\", \\\"{x:1514,y:923,t:1527189766640};\\\", \\\"{x:1512,y:927,t:1527189766657};\\\", \\\"{x:1504,y:941,t:1527189766674};\\\", \\\"{x:1496,y:952,t:1527189766691};\\\", \\\"{x:1486,y:961,t:1527189766708};\\\", \\\"{x:1470,y:971,t:1527189766724};\\\", \\\"{x:1449,y:979,t:1527189766742};\\\", \\\"{x:1424,y:985,t:1527189766758};\\\", \\\"{x:1407,y:987,t:1527189766774};\\\", \\\"{x:1400,y:989,t:1527189766792};\\\", \\\"{x:1392,y:989,t:1527189766808};\\\", \\\"{x:1384,y:990,t:1527189766824};\\\", \\\"{x:1378,y:992,t:1527189766841};\\\", \\\"{x:1377,y:993,t:1527189766858};\\\", \\\"{x:1375,y:994,t:1527189766874};\\\", \\\"{x:1374,y:994,t:1527189766891};\\\", \\\"{x:1373,y:995,t:1527189766920};\\\", \\\"{x:1372,y:995,t:1527189766937};\\\", \\\"{x:1370,y:995,t:1527189766945};\\\", \\\"{x:1367,y:995,t:1527189766958};\\\", \\\"{x:1361,y:995,t:1527189766974};\\\", \\\"{x:1356,y:995,t:1527189766992};\\\", \\\"{x:1352,y:996,t:1527189767008};\\\", \\\"{x:1348,y:996,t:1527189767025};\\\", \\\"{x:1348,y:994,t:1527189767346};\\\", \\\"{x:1348,y:991,t:1527189767358};\\\", \\\"{x:1349,y:987,t:1527189767376};\\\", \\\"{x:1350,y:986,t:1527189767392};\\\", \\\"{x:1351,y:986,t:1527189767408};\\\", \\\"{x:1351,y:985,t:1527189767536};\\\", \\\"{x:1350,y:984,t:1527189767810};\\\", \\\"{x:1346,y:985,t:1527189767826};\\\", \\\"{x:1341,y:986,t:1527189767842};\\\", \\\"{x:1340,y:986,t:1527189767858};\\\", \\\"{x:1338,y:986,t:1527189767881};\\\", \\\"{x:1336,y:986,t:1527189767920};\\\", \\\"{x:1334,y:986,t:1527189767936};\\\", \\\"{x:1330,y:986,t:1527189767943};\\\", \\\"{x:1328,y:985,t:1527189767958};\\\", \\\"{x:1321,y:983,t:1527189767974};\\\", \\\"{x:1318,y:981,t:1527189767992};\\\", \\\"{x:1317,y:980,t:1527189768057};\\\", \\\"{x:1317,y:979,t:1527189768080};\\\", \\\"{x:1317,y:978,t:1527189768145};\\\", \\\"{x:1316,y:976,t:1527189768161};\\\", \\\"{x:1315,y:975,t:1527189768177};\\\", \\\"{x:1315,y:974,t:1527189768314};\\\", \\\"{x:1315,y:973,t:1527189768449};\\\", \\\"{x:1316,y:971,t:1527189768473};\\\", \\\"{x:1318,y:971,t:1527189768625};\\\", \\\"{x:1322,y:972,t:1527189768643};\\\", \\\"{x:1327,y:975,t:1527189768659};\\\", \\\"{x:1333,y:977,t:1527189768676};\\\", \\\"{x:1342,y:979,t:1527189768692};\\\", \\\"{x:1348,y:981,t:1527189768709};\\\", \\\"{x:1354,y:983,t:1527189768726};\\\", \\\"{x:1356,y:984,t:1527189768742};\\\", \\\"{x:1357,y:984,t:1527189768759};\\\", \\\"{x:1358,y:984,t:1527189768776};\\\", \\\"{x:1360,y:984,t:1527189768817};\\\", \\\"{x:1362,y:984,t:1527189768857};\\\", \\\"{x:1364,y:984,t:1527189768873};\\\", \\\"{x:1365,y:984,t:1527189768881};\\\", \\\"{x:1366,y:984,t:1527189768893};\\\", \\\"{x:1368,y:983,t:1527189768910};\\\", \\\"{x:1370,y:983,t:1527189768927};\\\", \\\"{x:1371,y:983,t:1527189768961};\\\", \\\"{x:1372,y:983,t:1527189768977};\\\", \\\"{x:1373,y:983,t:1527189768993};\\\", \\\"{x:1374,y:982,t:1527189769010};\\\", \\\"{x:1376,y:980,t:1527189769026};\\\", \\\"{x:1377,y:980,t:1527189769106};\\\", \\\"{x:1377,y:979,t:1527189769113};\\\", \\\"{x:1378,y:979,t:1527189769136};\\\", \\\"{x:1379,y:977,t:1527189769168};\\\", \\\"{x:1379,y:976,t:1527189769233};\\\", \\\"{x:1380,y:975,t:1527189769248};\\\", \\\"{x:1380,y:974,t:1527189769260};\\\", \\\"{x:1380,y:973,t:1527189769288};\\\", \\\"{x:1380,y:972,t:1527189769329};\\\", \\\"{x:1381,y:972,t:1527189769482};\\\", \\\"{x:1382,y:973,t:1527189769493};\\\", \\\"{x:1382,y:974,t:1527189769513};\\\", \\\"{x:1382,y:975,t:1527189769529};\\\", \\\"{x:1382,y:976,t:1527189769544};\\\", \\\"{x:1383,y:977,t:1527189769560};\\\", \\\"{x:1384,y:978,t:1527189769577};\\\", \\\"{x:1387,y:979,t:1527189769593};\\\", \\\"{x:1392,y:980,t:1527189769610};\\\", \\\"{x:1400,y:981,t:1527189769627};\\\", \\\"{x:1411,y:983,t:1527189769643};\\\", \\\"{x:1416,y:984,t:1527189769660};\\\", \\\"{x:1421,y:984,t:1527189769677};\\\", \\\"{x:1425,y:984,t:1527189769693};\\\", \\\"{x:1426,y:984,t:1527189769721};\\\", \\\"{x:1427,y:984,t:1527189769737};\\\", \\\"{x:1428,y:984,t:1527189769753};\\\", \\\"{x:1429,y:984,t:1527189769760};\\\", \\\"{x:1433,y:984,t:1527189769777};\\\", \\\"{x:1437,y:984,t:1527189769801};\\\", \\\"{x:1439,y:984,t:1527189769817};\\\", \\\"{x:1441,y:983,t:1527189769827};\\\", \\\"{x:1443,y:983,t:1527189769843};\\\", \\\"{x:1446,y:982,t:1527189769860};\\\", \\\"{x:1447,y:981,t:1527189769888};\\\", \\\"{x:1448,y:981,t:1527189769896};\\\", \\\"{x:1449,y:979,t:1527189769910};\\\", \\\"{x:1450,y:977,t:1527189769927};\\\", \\\"{x:1451,y:977,t:1527189769943};\\\", \\\"{x:1451,y:976,t:1527189769960};\\\", \\\"{x:1451,y:975,t:1527189770000};\\\", \\\"{x:1451,y:973,t:1527189770016};\\\", \\\"{x:1451,y:972,t:1527189770113};\\\", \\\"{x:1450,y:971,t:1527189771162};\\\", \\\"{x:1450,y:972,t:1527189772458};\\\", \\\"{x:1450,y:974,t:1527189772473};\\\", \\\"{x:1452,y:975,t:1527189772481};\\\", \\\"{x:1453,y:976,t:1527189772497};\\\", \\\"{x:1456,y:978,t:1527189772512};\\\", \\\"{x:1459,y:979,t:1527189772529};\\\", \\\"{x:1462,y:981,t:1527189772546};\\\", \\\"{x:1469,y:982,t:1527189772562};\\\", \\\"{x:1474,y:984,t:1527189772580};\\\", \\\"{x:1479,y:985,t:1527189772596};\\\", \\\"{x:1481,y:985,t:1527189772612};\\\", \\\"{x:1484,y:985,t:1527189772630};\\\", \\\"{x:1485,y:985,t:1527189772665};\\\", \\\"{x:1486,y:985,t:1527189772679};\\\", \\\"{x:1490,y:985,t:1527189772696};\\\", \\\"{x:1493,y:985,t:1527189772712};\\\", \\\"{x:1497,y:982,t:1527189772736};\\\", \\\"{x:1498,y:982,t:1527189772745};\\\", \\\"{x:1499,y:982,t:1527189772784};\\\", \\\"{x:1501,y:981,t:1527189772841};\\\", \\\"{x:1502,y:981,t:1527189772848};\\\", \\\"{x:1503,y:980,t:1527189772862};\\\", \\\"{x:1504,y:979,t:1527189772880};\\\", \\\"{x:1506,y:979,t:1527189772953};\\\", \\\"{x:1507,y:978,t:1527189772977};\\\", \\\"{x:1508,y:977,t:1527189773113};\\\", \\\"{x:1509,y:977,t:1527189773129};\\\", \\\"{x:1509,y:976,t:1527189773146};\\\", \\\"{x:1510,y:976,t:1527189773163};\\\", \\\"{x:1510,y:975,t:1527189773185};\\\", \\\"{x:1511,y:974,t:1527189773217};\\\", \\\"{x:1511,y:973,t:1527189773273};\\\", \\\"{x:1513,y:973,t:1527189773665};\\\", \\\"{x:1515,y:973,t:1527189773681};\\\", \\\"{x:1521,y:973,t:1527189773697};\\\", \\\"{x:1528,y:973,t:1527189773714};\\\", \\\"{x:1530,y:974,t:1527189773730};\\\", \\\"{x:1531,y:975,t:1527189773746};\\\", \\\"{x:1533,y:975,t:1527189773777};\\\", \\\"{x:1534,y:975,t:1527189773801};\\\", \\\"{x:1535,y:975,t:1527189773817};\\\", \\\"{x:1536,y:975,t:1527189773833};\\\", \\\"{x:1537,y:975,t:1527189773937};\\\", \\\"{x:1538,y:975,t:1527189773946};\\\", \\\"{x:1544,y:974,t:1527189773963};\\\", \\\"{x:1545,y:974,t:1527189773984};\\\", \\\"{x:1546,y:973,t:1527189773997};\\\", \\\"{x:1548,y:973,t:1527189774013};\\\", \\\"{x:1549,y:973,t:1527189774031};\\\", \\\"{x:1550,y:973,t:1527189774046};\\\", \\\"{x:1550,y:972,t:1527189774129};\\\", \\\"{x:1552,y:972,t:1527189774136};\\\", \\\"{x:1552,y:971,t:1527189774352};\\\", \\\"{x:1552,y:970,t:1527189774363};\\\", \\\"{x:1551,y:968,t:1527189774770};\\\", \\\"{x:1547,y:966,t:1527189820898};\\\", \\\"{x:1534,y:960,t:1527189820906};\\\", \\\"{x:1516,y:954,t:1527189820919};\\\", \\\"{x:1475,y:939,t:1527189820937};\\\", \\\"{x:1422,y:927,t:1527189820954};\\\", \\\"{x:1383,y:923,t:1527189820970};\\\", \\\"{x:1340,y:916,t:1527189820986};\\\", \\\"{x:1254,y:893,t:1527189821003};\\\", \\\"{x:1200,y:863,t:1527189821020};\\\", \\\"{x:1128,y:802,t:1527189821037};\\\", \\\"{x:1054,y:696,t:1527189821054};\\\", \\\"{x:1023,y:639,t:1527189821069};\\\", \\\"{x:998,y:615,t:1527189821087};\\\", \\\"{x:991,y:605,t:1527189821103};\\\", \\\"{x:986,y:602,t:1527189821119};\\\", \\\"{x:983,y:597,t:1527189821136};\\\", \\\"{x:973,y:597,t:1527189821154};\\\", \\\"{x:949,y:602,t:1527189821170};\\\", \\\"{x:887,y:629,t:1527189821187};\\\", \\\"{x:803,y:646,t:1527189821203};\\\", \\\"{x:769,y:652,t:1527189821221};\\\", \\\"{x:728,y:660,t:1527189821238};\\\", \\\"{x:705,y:673,t:1527189821255};\\\", \\\"{x:682,y:692,t:1527189821272};\\\", \\\"{x:665,y:706,t:1527189821289};\\\", \\\"{x:645,y:722,t:1527189821306};\\\", \\\"{x:637,y:728,t:1527189821322};\\\", \\\"{x:630,y:731,t:1527189821338};\\\", \\\"{x:620,y:730,t:1527189821355};\\\", \\\"{x:607,y:721,t:1527189821372};\\\", \\\"{x:600,y:715,t:1527189821389};\\\", \\\"{x:595,y:711,t:1527189821406};\\\", \\\"{x:588,y:698,t:1527189821423};\\\", \\\"{x:587,y:687,t:1527189821440};\\\", \\\"{x:587,y:683,t:1527189821456};\\\", \\\"{x:588,y:675,t:1527189821473};\\\", \\\"{x:590,y:668,t:1527189821490};\\\", \\\"{x:594,y:658,t:1527189821507};\\\", \\\"{x:597,y:654,t:1527189821523};\\\", \\\"{x:599,y:651,t:1527189821538};\\\", \\\"{x:602,y:649,t:1527189821556};\\\", \\\"{x:605,y:645,t:1527189821573};\\\", \\\"{x:605,y:643,t:1527189821589};\\\", \\\"{x:606,y:640,t:1527189821606};\\\", \\\"{x:608,y:637,t:1527189821623};\\\", \\\"{x:610,y:632,t:1527189821640};\\\", \\\"{x:612,y:630,t:1527189821656};\\\", \\\"{x:612,y:627,t:1527189821673};\\\", \\\"{x:612,y:625,t:1527189821689};\\\", \\\"{x:613,y:625,t:1527189821754};\\\", \\\"{x:613,y:624,t:1527189821762};\\\", \\\"{x:614,y:622,t:1527189821772};\\\", \\\"{x:614,y:620,t:1527189821789};\\\", \\\"{x:614,y:619,t:1527189822010};\\\", \\\"{x:610,y:621,t:1527189822026};\\\", \\\"{x:605,y:624,t:1527189822039};\\\", \\\"{x:600,y:629,t:1527189822056};\\\", \\\"{x:591,y:643,t:1527189822073};\\\", \\\"{x:582,y:665,t:1527189822090};\\\", \\\"{x:579,y:670,t:1527189822105};\\\", \\\"{x:576,y:677,t:1527189822122};\\\", \\\"{x:572,y:685,t:1527189822140};\\\", \\\"{x:567,y:693,t:1527189822156};\\\", \\\"{x:563,y:700,t:1527189822173};\\\", \\\"{x:559,y:708,t:1527189822189};\\\", \\\"{x:555,y:719,t:1527189822206};\\\", \\\"{x:550,y:727,t:1527189822223};\\\", \\\"{x:546,y:734,t:1527189822239};\\\", \\\"{x:542,y:742,t:1527189822255};\\\", \\\"{x:541,y:749,t:1527189822273};\\\", \\\"{x:540,y:753,t:1527189822290};\\\", \\\"{x:538,y:759,t:1527189822306};\\\", \\\"{x:534,y:764,t:1527189822322};\\\", \\\"{x:533,y:764,t:1527189822572};\\\", \\\"{x:533,y:763,t:1527189822579};\\\", \\\"{x:531,y:759,t:1527189822590};\\\", \\\"{x:531,y:751,t:1527189822607};\\\", \\\"{x:530,y:747,t:1527189822624};\\\", \\\"{x:530,y:744,t:1527189822640};\\\", \\\"{x:530,y:743,t:1527189822657};\\\", \\\"{x:530,y:742,t:1527189823411};\\\", \\\"{x:530,y:741,t:1527189823424};\\\", \\\"{x:530,y:739,t:1527189823450};\\\", \\\"{x:530,y:738,t:1527189823459};\\\", \\\"{x:530,y:737,t:1527189823490};\\\", \\\"{x:530,y:736,t:1527189823508};\\\", \\\"{x:530,y:735,t:1527189823524};\\\" ] }, { \\\"rt\\\": 8976, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 412737, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"F98S2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6-G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:531,y:735,t:1527189825906};\\\", \\\"{x:533,y:735,t:1527189825970};\\\", \\\"{x:539,y:735,t:1527189825986};\\\", \\\"{x:545,y:735,t:1527189825994};\\\", \\\"{x:554,y:735,t:1527189826007};\\\", \\\"{x:571,y:735,t:1527189826024};\\\", \\\"{x:586,y:735,t:1527189826040};\\\", \\\"{x:634,y:735,t:1527189826059};\\\", \\\"{x:666,y:735,t:1527189826075};\\\", \\\"{x:693,y:727,t:1527189826092};\\\", \\\"{x:709,y:724,t:1527189826109};\\\", \\\"{x:742,y:718,t:1527189826126};\\\", \\\"{x:752,y:712,t:1527189826143};\\\", \\\"{x:757,y:709,t:1527189826160};\\\", \\\"{x:758,y:709,t:1527189826178};\\\", \\\"{x:759,y:709,t:1527189826193};\\\", \\\"{x:778,y:704,t:1527189826210};\\\", \\\"{x:793,y:701,t:1527189826226};\\\", \\\"{x:807,y:697,t:1527189826244};\\\", \\\"{x:826,y:692,t:1527189826260};\\\", \\\"{x:841,y:689,t:1527189826276};\\\", \\\"{x:853,y:686,t:1527189826293};\\\", \\\"{x:866,y:682,t:1527189826310};\\\", \\\"{x:880,y:678,t:1527189826327};\\\", \\\"{x:889,y:678,t:1527189826343};\\\", \\\"{x:911,y:674,t:1527189826360};\\\", \\\"{x:945,y:672,t:1527189826377};\\\", \\\"{x:960,y:672,t:1527189826394};\\\", \\\"{x:987,y:672,t:1527189826411};\\\", \\\"{x:1013,y:670,t:1527189826427};\\\", \\\"{x:1056,y:663,t:1527189826443};\\\", \\\"{x:1080,y:661,t:1527189826460};\\\", \\\"{x:1103,y:655,t:1527189826477};\\\", \\\"{x:1117,y:653,t:1527189826494};\\\", \\\"{x:1131,y:652,t:1527189826511};\\\", \\\"{x:1144,y:658,t:1527189826528};\\\", \\\"{x:1159,y:661,t:1527189826545};\\\", \\\"{x:1172,y:661,t:1527189826560};\\\", \\\"{x:1187,y:660,t:1527189826578};\\\", \\\"{x:1215,y:652,t:1527189826595};\\\", \\\"{x:1238,y:647,t:1527189826611};\\\", \\\"{x:1249,y:637,t:1527189826628};\\\", \\\"{x:1267,y:625,t:1527189826645};\\\", \\\"{x:1280,y:616,t:1527189826661};\\\", \\\"{x:1290,y:607,t:1527189826677};\\\", \\\"{x:1292,y:606,t:1527189826715};\\\", \\\"{x:1292,y:604,t:1527189826732};\\\", \\\"{x:1292,y:602,t:1527189826745};\\\", \\\"{x:1292,y:600,t:1527189826761};\\\", \\\"{x:1292,y:598,t:1527189826778};\\\", \\\"{x:1291,y:593,t:1527189826794};\\\", \\\"{x:1288,y:589,t:1527189826811};\\\", \\\"{x:1285,y:587,t:1527189826828};\\\", \\\"{x:1284,y:586,t:1527189826845};\\\", \\\"{x:1281,y:583,t:1527189826862};\\\", \\\"{x:1279,y:582,t:1527189826878};\\\", \\\"{x:1275,y:580,t:1527189826895};\\\", \\\"{x:1274,y:578,t:1527189826912};\\\", \\\"{x:1273,y:578,t:1527189826928};\\\", \\\"{x:1273,y:577,t:1527189826979};\\\", \\\"{x:1271,y:574,t:1527189826995};\\\", \\\"{x:1271,y:572,t:1527189827011};\\\", \\\"{x:1271,y:571,t:1527189827035};\\\", \\\"{x:1271,y:570,t:1527189827059};\\\", \\\"{x:1273,y:569,t:1527189827395};\\\", \\\"{x:1282,y:569,t:1527189827413};\\\", \\\"{x:1289,y:569,t:1527189827429};\\\", \\\"{x:1297,y:570,t:1527189827446};\\\", \\\"{x:1307,y:571,t:1527189827462};\\\", \\\"{x:1317,y:571,t:1527189827480};\\\", \\\"{x:1323,y:571,t:1527189827496};\\\", \\\"{x:1324,y:571,t:1527189827515};\\\", \\\"{x:1326,y:571,t:1527189827539};\\\", \\\"{x:1327,y:571,t:1527189827547};\\\", \\\"{x:1328,y:571,t:1527189827563};\\\", \\\"{x:1330,y:571,t:1527189827587};\\\", \\\"{x:1333,y:571,t:1527189827595};\\\", \\\"{x:1342,y:571,t:1527189827613};\\\", \\\"{x:1357,y:571,t:1527189827630};\\\", \\\"{x:1372,y:571,t:1527189827647};\\\", \\\"{x:1386,y:571,t:1527189827662};\\\", \\\"{x:1397,y:571,t:1527189827680};\\\", \\\"{x:1402,y:572,t:1527189827696};\\\", \\\"{x:1396,y:577,t:1527189827739};\\\", \\\"{x:1387,y:583,t:1527189827746};\\\", \\\"{x:1347,y:595,t:1527189827762};\\\", \\\"{x:1276,y:609,t:1527189827780};\\\", \\\"{x:1232,y:613,t:1527189827796};\\\", \\\"{x:1193,y:617,t:1527189827813};\\\", \\\"{x:1162,y:613,t:1527189827829};\\\", \\\"{x:1111,y:606,t:1527189827846};\\\", \\\"{x:1059,y:593,t:1527189827863};\\\", \\\"{x:1004,y:578,t:1527189827879};\\\", \\\"{x:921,y:578,t:1527189827896};\\\", \\\"{x:840,y:578,t:1527189827913};\\\", \\\"{x:812,y:578,t:1527189827927};\\\", \\\"{x:781,y:583,t:1527189827944};\\\", \\\"{x:759,y:585,t:1527189827960};\\\", \\\"{x:721,y:591,t:1527189827979};\\\", \\\"{x:701,y:592,t:1527189827994};\\\", \\\"{x:686,y:597,t:1527189828011};\\\", \\\"{x:669,y:601,t:1527189828028};\\\", \\\"{x:651,y:601,t:1527189828044};\\\", \\\"{x:632,y:601,t:1527189828061};\\\", \\\"{x:619,y:600,t:1527189828078};\\\", \\\"{x:608,y:595,t:1527189828094};\\\", \\\"{x:602,y:593,t:1527189828111};\\\", \\\"{x:594,y:589,t:1527189828128};\\\", \\\"{x:588,y:586,t:1527189828143};\\\", \\\"{x:584,y:583,t:1527189828161};\\\", \\\"{x:581,y:580,t:1527189828178};\\\", \\\"{x:581,y:578,t:1527189828194};\\\", \\\"{x:581,y:573,t:1527189828211};\\\", \\\"{x:582,y:564,t:1527189828228};\\\", \\\"{x:584,y:553,t:1527189828245};\\\", \\\"{x:586,y:546,t:1527189828261};\\\", \\\"{x:587,y:541,t:1527189828278};\\\", \\\"{x:587,y:539,t:1527189828293};\\\", \\\"{x:590,y:537,t:1527189828311};\\\", \\\"{x:592,y:534,t:1527189828329};\\\", \\\"{x:594,y:532,t:1527189828344};\\\", \\\"{x:595,y:530,t:1527189828362};\\\", \\\"{x:596,y:530,t:1527189828411};\\\", \\\"{x:597,y:528,t:1527189828429};\\\", \\\"{x:598,y:527,t:1527189828445};\\\", \\\"{x:599,y:527,t:1527189828461};\\\", \\\"{x:601,y:524,t:1527189828478};\\\", \\\"{x:603,y:521,t:1527189828495};\\\", \\\"{x:604,y:518,t:1527189828511};\\\", \\\"{x:607,y:515,t:1527189828528};\\\", \\\"{x:608,y:513,t:1527189828544};\\\", \\\"{x:611,y:509,t:1527189828561};\\\", \\\"{x:611,y:507,t:1527189828578};\\\", \\\"{x:612,y:506,t:1527189828810};\\\", \\\"{x:617,y:505,t:1527189828818};\\\", \\\"{x:629,y:508,t:1527189828828};\\\", \\\"{x:650,y:517,t:1527189828846};\\\", \\\"{x:663,y:520,t:1527189828863};\\\", \\\"{x:683,y:526,t:1527189828879};\\\", \\\"{x:703,y:533,t:1527189828895};\\\", \\\"{x:730,y:537,t:1527189828911};\\\", \\\"{x:756,y:542,t:1527189828928};\\\", \\\"{x:774,y:547,t:1527189828945};\\\", \\\"{x:792,y:553,t:1527189828962};\\\", \\\"{x:796,y:554,t:1527189828978};\\\", \\\"{x:797,y:554,t:1527189829018};\\\", \\\"{x:798,y:554,t:1527189829155};\\\", \\\"{x:798,y:553,t:1527189829171};\\\", \\\"{x:799,y:553,t:1527189829267};\\\", \\\"{x:800,y:553,t:1527189829282};\\\", \\\"{x:801,y:553,t:1527189829295};\\\", \\\"{x:802,y:553,t:1527189829312};\\\", \\\"{x:803,y:553,t:1527189829339};\\\", \\\"{x:804,y:553,t:1527189829347};\\\", \\\"{x:806,y:553,t:1527189829363};\\\", \\\"{x:809,y:553,t:1527189829379};\\\", \\\"{x:813,y:553,t:1527189829395};\\\", \\\"{x:815,y:553,t:1527189829412};\\\", \\\"{x:819,y:553,t:1527189829428};\\\", \\\"{x:821,y:553,t:1527189829445};\\\", \\\"{x:823,y:553,t:1527189829491};\\\", \\\"{x:825,y:552,t:1527189829523};\\\", \\\"{x:827,y:551,t:1527189829531};\\\", \\\"{x:830,y:549,t:1527189829579};\\\", \\\"{x:831,y:548,t:1527189829602};\\\", \\\"{x:832,y:548,t:1527189829618};\\\", \\\"{x:833,y:546,t:1527189829629};\\\", \\\"{x:834,y:545,t:1527189829650};\\\", \\\"{x:843,y:543,t:1527189830010};\\\", \\\"{x:846,y:543,t:1527189830018};\\\", \\\"{x:851,y:543,t:1527189830029};\\\", \\\"{x:878,y:543,t:1527189830047};\\\", \\\"{x:898,y:543,t:1527189830062};\\\", \\\"{x:931,y:544,t:1527189830079};\\\", \\\"{x:977,y:549,t:1527189830097};\\\", \\\"{x:1011,y:551,t:1527189830112};\\\", \\\"{x:1035,y:554,t:1527189830130};\\\", \\\"{x:1066,y:557,t:1527189830147};\\\", \\\"{x:1083,y:557,t:1527189830162};\\\", \\\"{x:1099,y:558,t:1527189830180};\\\", \\\"{x:1116,y:560,t:1527189830197};\\\", \\\"{x:1126,y:560,t:1527189830213};\\\", \\\"{x:1131,y:560,t:1527189830230};\\\", \\\"{x:1136,y:560,t:1527189830246};\\\", \\\"{x:1141,y:560,t:1527189830262};\\\", \\\"{x:1154,y:559,t:1527189830280};\\\", \\\"{x:1174,y:558,t:1527189830297};\\\", \\\"{x:1198,y:558,t:1527189830313};\\\", \\\"{x:1219,y:561,t:1527189830330};\\\", \\\"{x:1252,y:566,t:1527189830347};\\\", \\\"{x:1274,y:567,t:1527189830363};\\\", \\\"{x:1286,y:568,t:1527189830379};\\\", \\\"{x:1311,y:569,t:1527189830396};\\\", \\\"{x:1321,y:571,t:1527189830412};\\\", \\\"{x:1328,y:571,t:1527189830430};\\\", \\\"{x:1333,y:571,t:1527189830447};\\\", \\\"{x:1333,y:572,t:1527189830463};\\\", \\\"{x:1332,y:573,t:1527189830499};\\\", \\\"{x:1325,y:573,t:1527189830513};\\\", \\\"{x:1320,y:573,t:1527189830529};\\\", \\\"{x:1311,y:571,t:1527189830547};\\\", \\\"{x:1307,y:571,t:1527189830562};\\\", \\\"{x:1303,y:570,t:1527189830579};\\\", \\\"{x:1300,y:570,t:1527189830597};\\\", \\\"{x:1298,y:570,t:1527189830613};\\\", \\\"{x:1297,y:570,t:1527189830691};\\\", \\\"{x:1294,y:570,t:1527189830699};\\\", \\\"{x:1291,y:570,t:1527189830713};\\\", \\\"{x:1287,y:570,t:1527189830730};\\\", \\\"{x:1282,y:570,t:1527189830747};\\\", \\\"{x:1281,y:570,t:1527189830763};\\\", \\\"{x:1282,y:570,t:1527189830939};\\\", \\\"{x:1283,y:570,t:1527189830946};\\\", \\\"{x:1291,y:571,t:1527189830963};\\\", \\\"{x:1302,y:571,t:1527189830979};\\\", \\\"{x:1312,y:571,t:1527189830997};\\\", \\\"{x:1326,y:571,t:1527189831013};\\\", \\\"{x:1339,y:571,t:1527189831030};\\\", \\\"{x:1349,y:572,t:1527189831047};\\\", \\\"{x:1363,y:572,t:1527189831063};\\\", \\\"{x:1373,y:572,t:1527189831080};\\\", \\\"{x:1381,y:572,t:1527189831097};\\\", \\\"{x:1384,y:572,t:1527189831113};\\\", \\\"{x:1392,y:572,t:1527189831130};\\\", \\\"{x:1398,y:575,t:1527189831147};\\\", \\\"{x:1400,y:575,t:1527189831292};\\\", \\\"{x:1403,y:573,t:1527189831299};\\\", \\\"{x:1405,y:571,t:1527189831313};\\\", \\\"{x:1409,y:570,t:1527189831330};\\\", \\\"{x:1412,y:568,t:1527189831349};\\\", \\\"{x:1413,y:568,t:1527189831385};\\\", \\\"{x:1414,y:568,t:1527189831466};\\\", \\\"{x:1414,y:567,t:1527189831479};\\\", \\\"{x:1412,y:567,t:1527189831633};\\\", \\\"{x:1409,y:566,t:1527189831646};\\\", \\\"{x:1403,y:564,t:1527189831662};\\\", \\\"{x:1399,y:564,t:1527189831679};\\\", \\\"{x:1394,y:563,t:1527189831697};\\\", \\\"{x:1393,y:563,t:1527189831722};\\\", \\\"{x:1395,y:563,t:1527189831867};\\\", \\\"{x:1398,y:563,t:1527189831880};\\\", \\\"{x:1402,y:563,t:1527189831897};\\\", \\\"{x:1404,y:563,t:1527189831913};\\\", \\\"{x:1406,y:565,t:1527189831930};\\\", \\\"{x:1400,y:566,t:1527189832139};\\\", \\\"{x:1397,y:566,t:1527189832147};\\\", \\\"{x:1395,y:566,t:1527189832163};\\\", \\\"{x:1380,y:568,t:1527189832180};\\\", \\\"{x:1366,y:568,t:1527189832197};\\\", \\\"{x:1355,y:570,t:1527189832214};\\\", \\\"{x:1346,y:571,t:1527189832230};\\\", \\\"{x:1343,y:571,t:1527189832247};\\\", \\\"{x:1341,y:572,t:1527189832264};\\\", \\\"{x:1340,y:572,t:1527189832279};\\\", \\\"{x:1337,y:573,t:1527189832339};\\\", \\\"{x:1334,y:574,t:1527189832347};\\\", \\\"{x:1325,y:574,t:1527189832363};\\\", \\\"{x:1313,y:575,t:1527189832380};\\\", \\\"{x:1299,y:575,t:1527189832397};\\\", \\\"{x:1289,y:575,t:1527189832414};\\\", \\\"{x:1282,y:576,t:1527189832430};\\\", \\\"{x:1279,y:577,t:1527189832446};\\\", \\\"{x:1276,y:577,t:1527189832464};\\\", \\\"{x:1274,y:578,t:1527189832571};\\\", \\\"{x:1267,y:579,t:1527189832580};\\\", \\\"{x:1249,y:582,t:1527189832597};\\\", \\\"{x:1221,y:588,t:1527189832614};\\\", \\\"{x:1194,y:594,t:1527189832629};\\\", \\\"{x:1141,y:600,t:1527189832646};\\\", \\\"{x:1066,y:609,t:1527189832664};\\\", \\\"{x:993,y:623,t:1527189832680};\\\", \\\"{x:909,y:636,t:1527189832697};\\\", \\\"{x:835,y:656,t:1527189832714};\\\", \\\"{x:728,y:680,t:1527189832730};\\\", \\\"{x:599,y:709,t:1527189832747};\\\", \\\"{x:539,y:722,t:1527189832765};\\\", \\\"{x:510,y:727,t:1527189832780};\\\", \\\"{x:496,y:728,t:1527189832796};\\\", \\\"{x:485,y:728,t:1527189832813};\\\", \\\"{x:478,y:728,t:1527189832831};\\\", \\\"{x:470,y:728,t:1527189832848};\\\", \\\"{x:458,y:728,t:1527189832865};\\\", \\\"{x:440,y:730,t:1527189832881};\\\", \\\"{x:410,y:735,t:1527189832897};\\\", \\\"{x:389,y:739,t:1527189832916};\\\", \\\"{x:377,y:739,t:1527189832931};\\\", \\\"{x:376,y:739,t:1527189832948};\\\", \\\"{x:377,y:739,t:1527189833003};\\\", \\\"{x:383,y:739,t:1527189833015};\\\", \\\"{x:399,y:739,t:1527189833031};\\\", \\\"{x:419,y:739,t:1527189833049};\\\", \\\"{x:437,y:736,t:1527189833066};\\\", \\\"{x:457,y:736,t:1527189833082};\\\", \\\"{x:474,y:736,t:1527189833098};\\\", \\\"{x:477,y:736,t:1527189833115};\\\", \\\"{x:478,y:736,t:1527189833145};\\\" ] }, { \\\"rt\\\": 21570, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 435550, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"F98S2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:478,y:735,t:1527189834826};\\\", \\\"{x:478,y:734,t:1527189834834};\\\", \\\"{x:478,y:733,t:1527189834849};\\\", \\\"{x:478,y:732,t:1527189834866};\\\", \\\"{x:478,y:731,t:1527189834883};\\\", \\\"{x:474,y:731,t:1527189834930};\\\", \\\"{x:473,y:731,t:1527189834946};\\\", \\\"{x:473,y:728,t:1527189835794};\\\", \\\"{x:473,y:724,t:1527189835802};\\\", \\\"{x:473,y:721,t:1527189835817};\\\", \\\"{x:470,y:710,t:1527189835835};\\\", \\\"{x:466,y:698,t:1527189835850};\\\", \\\"{x:462,y:687,t:1527189835866};\\\", \\\"{x:461,y:678,t:1527189835884};\\\", \\\"{x:454,y:664,t:1527189835901};\\\", \\\"{x:450,y:652,t:1527189835917};\\\", \\\"{x:448,y:638,t:1527189835934};\\\", \\\"{x:443,y:626,t:1527189835951};\\\", \\\"{x:440,y:608,t:1527189835967};\\\", \\\"{x:438,y:594,t:1527189835985};\\\", \\\"{x:432,y:582,t:1527189836001};\\\", \\\"{x:430,y:573,t:1527189836017};\\\", \\\"{x:427,y:569,t:1527189836034};\\\", \\\"{x:426,y:567,t:1527189836050};\\\", \\\"{x:424,y:565,t:1527189836067};\\\", \\\"{x:422,y:563,t:1527189836084};\\\", \\\"{x:421,y:562,t:1527189836101};\\\", \\\"{x:420,y:562,t:1527189836117};\\\", \\\"{x:417,y:559,t:1527189836134};\\\", \\\"{x:411,y:553,t:1527189836151};\\\", \\\"{x:405,y:542,t:1527189836167};\\\", \\\"{x:401,y:529,t:1527189836184};\\\", \\\"{x:398,y:517,t:1527189836201};\\\", \\\"{x:396,y:510,t:1527189836217};\\\", \\\"{x:392,y:495,t:1527189836234};\\\", \\\"{x:391,y:490,t:1527189836252};\\\", \\\"{x:391,y:489,t:1527189836268};\\\", \\\"{x:391,y:486,t:1527189836285};\\\", \\\"{x:391,y:480,t:1527189836301};\\\", \\\"{x:391,y:476,t:1527189836318};\\\", \\\"{x:392,y:475,t:1527189836334};\\\", \\\"{x:393,y:475,t:1527189836555};\\\", \\\"{x:395,y:475,t:1527189836595};\\\", \\\"{x:396,y:475,t:1527189836602};\\\", \\\"{x:399,y:475,t:1527189836619};\\\", \\\"{x:403,y:475,t:1527189836635};\\\", \\\"{x:406,y:475,t:1527189836658};\\\", \\\"{x:408,y:475,t:1527189836670};\\\", \\\"{x:411,y:475,t:1527189836685};\\\", \\\"{x:414,y:475,t:1527189836703};\\\", \\\"{x:418,y:475,t:1527189836719};\\\", \\\"{x:419,y:475,t:1527189836737};\\\", \\\"{x:421,y:475,t:1527189836752};\\\", \\\"{x:424,y:475,t:1527189836770};\\\", \\\"{x:425,y:476,t:1527189836786};\\\", \\\"{x:426,y:476,t:1527189836804};\\\", \\\"{x:429,y:476,t:1527189836819};\\\", \\\"{x:433,y:477,t:1527189836837};\\\", \\\"{x:434,y:477,t:1527189836853};\\\", \\\"{x:436,y:477,t:1527189836869};\\\", \\\"{x:438,y:477,t:1527189836915};\\\", \\\"{x:440,y:477,t:1527189836931};\\\", \\\"{x:442,y:477,t:1527189836946};\\\", \\\"{x:443,y:477,t:1527189836954};\\\", \\\"{x:444,y:477,t:1527189836979};\\\", \\\"{x:448,y:478,t:1527189841959};\\\", \\\"{x:465,y:485,t:1527189841966};\\\", \\\"{x:481,y:494,t:1527189841979};\\\", \\\"{x:550,y:510,t:1527189841994};\\\", \\\"{x:629,y:527,t:1527189842011};\\\", \\\"{x:720,y:541,t:1527189842037};\\\", \\\"{x:782,y:553,t:1527189842054};\\\", \\\"{x:833,y:563,t:1527189842070};\\\", \\\"{x:865,y:571,t:1527189842093};\\\", \\\"{x:897,y:579,t:1527189842110};\\\", \\\"{x:910,y:585,t:1527189842126};\\\", \\\"{x:924,y:591,t:1527189842142};\\\", \\\"{x:944,y:604,t:1527189842160};\\\", \\\"{x:963,y:615,t:1527189842177};\\\", \\\"{x:982,y:626,t:1527189842193};\\\", \\\"{x:1001,y:643,t:1527189842209};\\\", \\\"{x:1025,y:656,t:1527189842226};\\\", \\\"{x:1073,y:677,t:1527189842243};\\\", \\\"{x:1130,y:699,t:1527189842260};\\\", \\\"{x:1174,y:716,t:1527189842277};\\\", \\\"{x:1220,y:728,t:1527189842293};\\\", \\\"{x:1242,y:728,t:1527189842310};\\\", \\\"{x:1254,y:726,t:1527189842326};\\\", \\\"{x:1263,y:720,t:1527189842344};\\\", \\\"{x:1278,y:712,t:1527189842360};\\\", \\\"{x:1291,y:702,t:1527189842377};\\\", \\\"{x:1297,y:697,t:1527189842394};\\\", \\\"{x:1299,y:690,t:1527189842411};\\\", \\\"{x:1296,y:679,t:1527189842428};\\\", \\\"{x:1289,y:664,t:1527189842444};\\\", \\\"{x:1278,y:652,t:1527189842461};\\\", \\\"{x:1260,y:634,t:1527189842478};\\\", \\\"{x:1242,y:618,t:1527189842494};\\\", \\\"{x:1225,y:605,t:1527189842511};\\\", \\\"{x:1208,y:594,t:1527189842527};\\\", \\\"{x:1188,y:579,t:1527189842545};\\\", \\\"{x:1178,y:571,t:1527189842561};\\\", \\\"{x:1176,y:567,t:1527189842577};\\\", \\\"{x:1174,y:566,t:1527189842595};\\\", \\\"{x:1174,y:564,t:1527189842612};\\\", \\\"{x:1174,y:562,t:1527189842627};\\\", \\\"{x:1174,y:556,t:1527189842645};\\\", \\\"{x:1180,y:548,t:1527189842662};\\\", \\\"{x:1188,y:542,t:1527189842678};\\\", \\\"{x:1202,y:541,t:1527189842695};\\\", \\\"{x:1207,y:540,t:1527189842712};\\\", \\\"{x:1215,y:540,t:1527189842729};\\\", \\\"{x:1221,y:540,t:1527189842746};\\\", \\\"{x:1232,y:540,t:1527189842762};\\\", \\\"{x:1242,y:540,t:1527189842779};\\\", \\\"{x:1259,y:540,t:1527189842796};\\\", \\\"{x:1266,y:540,t:1527189842812};\\\", \\\"{x:1270,y:544,t:1527189842829};\\\", \\\"{x:1273,y:554,t:1527189842846};\\\", \\\"{x:1274,y:564,t:1527189842862};\\\", \\\"{x:1271,y:575,t:1527189842879};\\\", \\\"{x:1267,y:589,t:1527189842896};\\\", \\\"{x:1262,y:602,t:1527189842913};\\\", \\\"{x:1257,y:614,t:1527189842930};\\\", \\\"{x:1250,y:628,t:1527189842946};\\\", \\\"{x:1246,y:636,t:1527189842963};\\\", \\\"{x:1241,y:642,t:1527189842980};\\\", \\\"{x:1240,y:643,t:1527189842996};\\\", \\\"{x:1239,y:644,t:1527189843013};\\\", \\\"{x:1238,y:644,t:1527189843054};\\\", \\\"{x:1238,y:645,t:1527189843063};\\\", \\\"{x:1237,y:645,t:1527189843087};\\\", \\\"{x:1236,y:646,t:1527189843102};\\\", \\\"{x:1235,y:646,t:1527189843162};\\\", \\\"{x:1234,y:645,t:1527189843165};\\\", \\\"{x:1234,y:643,t:1527189843198};\\\", \\\"{x:1234,y:642,t:1527189843213};\\\", \\\"{x:1234,y:641,t:1527189843231};\\\", \\\"{x:1234,y:639,t:1527189843246};\\\", \\\"{x:1234,y:637,t:1527189843264};\\\", \\\"{x:1234,y:636,t:1527189843280};\\\", \\\"{x:1234,y:634,t:1527189843341};\\\", \\\"{x:1235,y:633,t:1527189843429};\\\", \\\"{x:1236,y:633,t:1527189843445};\\\", \\\"{x:1237,y:633,t:1527189843454};\\\", \\\"{x:1238,y:632,t:1527189843470};\\\", \\\"{x:1239,y:631,t:1527189843974};\\\", \\\"{x:1239,y:634,t:1527189844486};\\\", \\\"{x:1239,y:638,t:1527189844501};\\\", \\\"{x:1239,y:641,t:1527189844519};\\\", \\\"{x:1239,y:644,t:1527189844534};\\\", \\\"{x:1239,y:646,t:1527189844552};\\\", \\\"{x:1238,y:648,t:1527189844568};\\\", \\\"{x:1238,y:649,t:1527189844585};\\\", \\\"{x:1238,y:653,t:1527189844602};\\\", \\\"{x:1236,y:656,t:1527189844618};\\\", \\\"{x:1234,y:663,t:1527189844635};\\\", \\\"{x:1232,y:669,t:1527189844652};\\\", \\\"{x:1230,y:677,t:1527189844669};\\\", \\\"{x:1227,y:685,t:1527189844686};\\\", \\\"{x:1226,y:686,t:1527189844701};\\\", \\\"{x:1225,y:688,t:1527189844718};\\\", \\\"{x:1224,y:689,t:1527189844736};\\\", \\\"{x:1224,y:690,t:1527189844752};\\\", \\\"{x:1224,y:692,t:1527189844768};\\\", \\\"{x:1223,y:694,t:1527189844786};\\\", \\\"{x:1222,y:697,t:1527189844803};\\\", \\\"{x:1222,y:698,t:1527189844822};\\\", \\\"{x:1221,y:698,t:1527189844836};\\\", \\\"{x:1226,y:699,t:1527189847246};\\\", \\\"{x:1247,y:702,t:1527189847262};\\\", \\\"{x:1272,y:705,t:1527189847278};\\\", \\\"{x:1303,y:712,t:1527189847295};\\\", \\\"{x:1332,y:718,t:1527189847312};\\\", \\\"{x:1364,y:731,t:1527189847329};\\\", \\\"{x:1377,y:737,t:1527189847345};\\\", \\\"{x:1379,y:737,t:1527189847362};\\\", \\\"{x:1380,y:737,t:1527189847379};\\\", \\\"{x:1381,y:737,t:1527189847431};\\\", \\\"{x:1382,y:737,t:1527189847478};\\\", \\\"{x:1383,y:737,t:1527189847496};\\\", \\\"{x:1384,y:737,t:1527189847513};\\\", \\\"{x:1384,y:736,t:1527189847567};\\\", \\\"{x:1384,y:735,t:1527189847579};\\\", \\\"{x:1383,y:732,t:1527189847596};\\\", \\\"{x:1379,y:728,t:1527189847613};\\\", \\\"{x:1376,y:725,t:1527189847630};\\\", \\\"{x:1375,y:722,t:1527189847646};\\\", \\\"{x:1373,y:721,t:1527189847663};\\\", \\\"{x:1372,y:719,t:1527189847680};\\\", \\\"{x:1371,y:719,t:1527189847696};\\\", \\\"{x:1368,y:717,t:1527189847713};\\\", \\\"{x:1366,y:715,t:1527189847730};\\\", \\\"{x:1364,y:713,t:1527189847747};\\\", \\\"{x:1363,y:712,t:1527189847791};\\\", \\\"{x:1362,y:711,t:1527189847822};\\\", \\\"{x:1361,y:710,t:1527189847830};\\\", \\\"{x:1360,y:710,t:1527189847847};\\\", \\\"{x:1357,y:708,t:1527189847864};\\\", \\\"{x:1356,y:708,t:1527189847880};\\\", \\\"{x:1348,y:703,t:1527189847898};\\\", \\\"{x:1344,y:699,t:1527189847916};\\\", \\\"{x:1338,y:697,t:1527189847932};\\\", \\\"{x:1335,y:695,t:1527189847947};\\\", \\\"{x:1334,y:693,t:1527189847964};\\\", \\\"{x:1333,y:693,t:1527189848167};\\\", \\\"{x:1333,y:697,t:1527189848182};\\\", \\\"{x:1335,y:702,t:1527189848198};\\\", \\\"{x:1335,y:704,t:1527189848215};\\\", \\\"{x:1335,y:706,t:1527189848238};\\\", \\\"{x:1335,y:707,t:1527189848255};\\\", \\\"{x:1335,y:709,t:1527189848265};\\\", \\\"{x:1335,y:714,t:1527189848282};\\\", \\\"{x:1335,y:716,t:1527189848299};\\\", \\\"{x:1336,y:720,t:1527189848315};\\\", \\\"{x:1336,y:721,t:1527189848332};\\\", \\\"{x:1337,y:724,t:1527189848349};\\\", \\\"{x:1338,y:729,t:1527189848366};\\\", \\\"{x:1338,y:731,t:1527189848382};\\\", \\\"{x:1338,y:734,t:1527189848399};\\\", \\\"{x:1340,y:738,t:1527189848416};\\\", \\\"{x:1341,y:740,t:1527189848432};\\\", \\\"{x:1342,y:743,t:1527189848449};\\\", \\\"{x:1342,y:747,t:1527189848467};\\\", \\\"{x:1342,y:751,t:1527189848483};\\\", \\\"{x:1343,y:755,t:1527189848499};\\\", \\\"{x:1343,y:759,t:1527189848517};\\\", \\\"{x:1343,y:761,t:1527189848534};\\\", \\\"{x:1345,y:764,t:1527189848550};\\\", \\\"{x:1345,y:766,t:1527189848566};\\\", \\\"{x:1345,y:767,t:1527189848583};\\\", \\\"{x:1345,y:771,t:1527189848601};\\\", \\\"{x:1345,y:773,t:1527189848622};\\\", \\\"{x:1345,y:774,t:1527189848646};\\\", \\\"{x:1345,y:775,t:1527189848654};\\\", \\\"{x:1345,y:776,t:1527189848679};\\\", \\\"{x:1345,y:777,t:1527189848694};\\\", \\\"{x:1345,y:778,t:1527189848710};\\\", \\\"{x:1344,y:778,t:1527189849695};\\\", \\\"{x:1339,y:778,t:1527189849705};\\\", \\\"{x:1309,y:765,t:1527189849720};\\\", \\\"{x:1238,y:738,t:1527189849737};\\\", \\\"{x:1159,y:710,t:1527189849755};\\\", \\\"{x:1060,y:688,t:1527189849772};\\\", \\\"{x:965,y:670,t:1527189849787};\\\", \\\"{x:873,y:653,t:1527189849804};\\\", \\\"{x:796,y:635,t:1527189849821};\\\", \\\"{x:728,y:623,t:1527189849838};\\\", \\\"{x:660,y:608,t:1527189849854};\\\", \\\"{x:640,y:603,t:1527189849870};\\\", \\\"{x:628,y:598,t:1527189849883};\\\", \\\"{x:604,y:590,t:1527189849899};\\\", \\\"{x:588,y:584,t:1527189849915};\\\", \\\"{x:563,y:576,t:1527189849933};\\\", \\\"{x:553,y:576,t:1527189849949};\\\", \\\"{x:515,y:566,t:1527189849965};\\\", \\\"{x:494,y:560,t:1527189849983};\\\", \\\"{x:483,y:557,t:1527189849998};\\\", \\\"{x:473,y:554,t:1527189850016};\\\", \\\"{x:472,y:554,t:1527189850032};\\\", \\\"{x:471,y:553,t:1527189850049};\\\", \\\"{x:467,y:555,t:1527189850206};\\\", \\\"{x:462,y:557,t:1527189850217};\\\", \\\"{x:454,y:559,t:1527189850232};\\\", \\\"{x:438,y:563,t:1527189850250};\\\", \\\"{x:425,y:569,t:1527189850266};\\\", \\\"{x:412,y:570,t:1527189850283};\\\", \\\"{x:400,y:575,t:1527189850300};\\\", \\\"{x:388,y:576,t:1527189850315};\\\", \\\"{x:375,y:577,t:1527189850332};\\\", \\\"{x:362,y:577,t:1527189850350};\\\", \\\"{x:361,y:577,t:1527189850365};\\\", \\\"{x:360,y:577,t:1527189850549};\\\", \\\"{x:357,y:577,t:1527189850566};\\\", \\\"{x:350,y:579,t:1527189850582};\\\", \\\"{x:338,y:580,t:1527189850599};\\\", \\\"{x:317,y:580,t:1527189850617};\\\", \\\"{x:294,y:580,t:1527189850632};\\\", \\\"{x:284,y:580,t:1527189850650};\\\", \\\"{x:278,y:580,t:1527189850666};\\\", \\\"{x:261,y:584,t:1527189850684};\\\", \\\"{x:252,y:585,t:1527189850699};\\\", \\\"{x:250,y:587,t:1527189850716};\\\", \\\"{x:249,y:587,t:1527189850733};\\\", \\\"{x:248,y:588,t:1527189850781};\\\", \\\"{x:247,y:589,t:1527189850800};\\\", \\\"{x:244,y:590,t:1527189850817};\\\", \\\"{x:242,y:591,t:1527189850833};\\\", \\\"{x:237,y:592,t:1527189850850};\\\", \\\"{x:231,y:592,t:1527189850867};\\\", \\\"{x:227,y:592,t:1527189850883};\\\", \\\"{x:221,y:587,t:1527189850899};\\\", \\\"{x:211,y:581,t:1527189850917};\\\", \\\"{x:201,y:575,t:1527189850934};\\\", \\\"{x:199,y:574,t:1527189850950};\\\", \\\"{x:203,y:572,t:1527189851031};\\\", \\\"{x:213,y:572,t:1527189851038};\\\", \\\"{x:225,y:572,t:1527189851050};\\\", \\\"{x:253,y:572,t:1527189851067};\\\", \\\"{x:275,y:572,t:1527189851085};\\\", \\\"{x:300,y:572,t:1527189851099};\\\", \\\"{x:328,y:572,t:1527189851116};\\\", \\\"{x:352,y:571,t:1527189851133};\\\", \\\"{x:357,y:568,t:1527189851149};\\\", \\\"{x:361,y:565,t:1527189851167};\\\", \\\"{x:364,y:563,t:1527189851183};\\\", \\\"{x:368,y:559,t:1527189851200};\\\", \\\"{x:374,y:556,t:1527189851216};\\\", \\\"{x:385,y:550,t:1527189851234};\\\", \\\"{x:397,y:547,t:1527189851249};\\\", \\\"{x:409,y:543,t:1527189851267};\\\", \\\"{x:433,y:543,t:1527189851284};\\\", \\\"{x:453,y:543,t:1527189851300};\\\", \\\"{x:477,y:543,t:1527189851317};\\\", \\\"{x:513,y:543,t:1527189851335};\\\", \\\"{x:545,y:543,t:1527189851350};\\\", \\\"{x:568,y:543,t:1527189851367};\\\", \\\"{x:587,y:544,t:1527189851384};\\\", \\\"{x:598,y:544,t:1527189851400};\\\", \\\"{x:601,y:544,t:1527189851417};\\\", \\\"{x:604,y:545,t:1527189851434};\\\", \\\"{x:608,y:547,t:1527189851451};\\\", \\\"{x:612,y:547,t:1527189851467};\\\", \\\"{x:633,y:549,t:1527189851484};\\\", \\\"{x:649,y:549,t:1527189851502};\\\", \\\"{x:665,y:550,t:1527189851517};\\\", \\\"{x:671,y:550,t:1527189851534};\\\", \\\"{x:672,y:550,t:1527189851597};\\\", \\\"{x:673,y:550,t:1527189851621};\\\", \\\"{x:674,y:550,t:1527189851727};\\\", \\\"{x:673,y:552,t:1527189851734};\\\", \\\"{x:657,y:555,t:1527189851751};\\\", \\\"{x:636,y:559,t:1527189851768};\\\", \\\"{x:596,y:564,t:1527189851784};\\\", \\\"{x:560,y:568,t:1527189851800};\\\", \\\"{x:538,y:576,t:1527189851818};\\\", \\\"{x:519,y:581,t:1527189851833};\\\", \\\"{x:505,y:587,t:1527189851851};\\\", \\\"{x:495,y:591,t:1527189851868};\\\", \\\"{x:486,y:596,t:1527189851884};\\\", \\\"{x:479,y:599,t:1527189851901};\\\", \\\"{x:473,y:601,t:1527189851917};\\\", \\\"{x:469,y:603,t:1527189851933};\\\", \\\"{x:466,y:604,t:1527189851950};\\\", \\\"{x:462,y:606,t:1527189851967};\\\", \\\"{x:455,y:611,t:1527189851984};\\\", \\\"{x:452,y:612,t:1527189852001};\\\", \\\"{x:447,y:614,t:1527189852016};\\\", \\\"{x:446,y:614,t:1527189852034};\\\", \\\"{x:444,y:615,t:1527189852051};\\\", \\\"{x:438,y:618,t:1527189852067};\\\", \\\"{x:434,y:619,t:1527189852083};\\\", \\\"{x:430,y:623,t:1527189852101};\\\", \\\"{x:421,y:628,t:1527189852117};\\\", \\\"{x:413,y:635,t:1527189852135};\\\", \\\"{x:409,y:638,t:1527189852151};\\\", \\\"{x:407,y:640,t:1527189852168};\\\", \\\"{x:406,y:641,t:1527189852184};\\\", \\\"{x:405,y:642,t:1527189852200};\\\", \\\"{x:402,y:642,t:1527189852221};\\\", \\\"{x:401,y:643,t:1527189852234};\\\", \\\"{x:395,y:643,t:1527189852250};\\\", \\\"{x:391,y:643,t:1527189852267};\\\", \\\"{x:386,y:642,t:1527189852285};\\\", \\\"{x:382,y:637,t:1527189852301};\\\", \\\"{x:375,y:629,t:1527189852318};\\\", \\\"{x:373,y:623,t:1527189852335};\\\", \\\"{x:370,y:618,t:1527189852351};\\\", \\\"{x:367,y:614,t:1527189852367};\\\", \\\"{x:367,y:610,t:1527189852385};\\\", \\\"{x:366,y:606,t:1527189852401};\\\", \\\"{x:363,y:599,t:1527189852419};\\\", \\\"{x:362,y:592,t:1527189852435};\\\", \\\"{x:362,y:587,t:1527189852451};\\\", \\\"{x:361,y:581,t:1527189852467};\\\", \\\"{x:359,y:577,t:1527189852484};\\\", \\\"{x:357,y:569,t:1527189852501};\\\", \\\"{x:353,y:561,t:1527189852518};\\\", \\\"{x:353,y:558,t:1527189852534};\\\", \\\"{x:350,y:554,t:1527189852551};\\\", \\\"{x:348,y:549,t:1527189852567};\\\", \\\"{x:343,y:542,t:1527189852584};\\\", \\\"{x:338,y:539,t:1527189852601};\\\", \\\"{x:333,y:537,t:1527189852617};\\\", \\\"{x:327,y:537,t:1527189852634};\\\", \\\"{x:318,y:537,t:1527189852652};\\\", \\\"{x:301,y:537,t:1527189852668};\\\", \\\"{x:285,y:537,t:1527189852685};\\\", \\\"{x:262,y:537,t:1527189852703};\\\", \\\"{x:244,y:538,t:1527189852718};\\\", \\\"{x:234,y:539,t:1527189852734};\\\", \\\"{x:230,y:539,t:1527189852752};\\\", \\\"{x:228,y:541,t:1527189852767};\\\", \\\"{x:228,y:542,t:1527189852789};\\\", \\\"{x:226,y:542,t:1527189852813};\\\", \\\"{x:222,y:543,t:1527189852821};\\\", \\\"{x:219,y:545,t:1527189852835};\\\", \\\"{x:216,y:546,t:1527189852852};\\\", \\\"{x:212,y:546,t:1527189852867};\\\", \\\"{x:208,y:547,t:1527189852885};\\\", \\\"{x:206,y:547,t:1527189852902};\\\", \\\"{x:205,y:547,t:1527189852917};\\\", \\\"{x:204,y:547,t:1527189852965};\\\", \\\"{x:203,y:547,t:1527189852973};\\\", \\\"{x:199,y:547,t:1527189852985};\\\", \\\"{x:190,y:547,t:1527189853003};\\\", \\\"{x:177,y:545,t:1527189853018};\\\", \\\"{x:172,y:543,t:1527189853035};\\\", \\\"{x:166,y:541,t:1527189853053};\\\", \\\"{x:165,y:540,t:1527189853070};\\\", \\\"{x:164,y:540,t:1527189853126};\\\", \\\"{x:164,y:539,t:1527189853175};\\\", \\\"{x:164,y:537,t:1527189853710};\\\", \\\"{x:171,y:537,t:1527189853720};\\\", \\\"{x:191,y:545,t:1527189853736};\\\", \\\"{x:197,y:551,t:1527189853753};\\\", \\\"{x:219,y:552,t:1527189853769};\\\", \\\"{x:258,y:558,t:1527189853786};\\\", \\\"{x:292,y:562,t:1527189853802};\\\", \\\"{x:311,y:566,t:1527189853819};\\\", \\\"{x:332,y:570,t:1527189853836};\\\", \\\"{x:341,y:572,t:1527189853852};\\\", \\\"{x:342,y:572,t:1527189853869};\\\", \\\"{x:346,y:572,t:1527189853885};\\\", \\\"{x:348,y:572,t:1527189853902};\\\", \\\"{x:352,y:569,t:1527189853919};\\\", \\\"{x:356,y:567,t:1527189853936};\\\", \\\"{x:358,y:566,t:1527189853952};\\\", \\\"{x:362,y:565,t:1527189853968};\\\", \\\"{x:363,y:563,t:1527189853986};\\\", \\\"{x:372,y:562,t:1527189854003};\\\", \\\"{x:380,y:559,t:1527189854019};\\\", \\\"{x:387,y:558,t:1527189854036};\\\", \\\"{x:392,y:557,t:1527189854053};\\\", \\\"{x:399,y:555,t:1527189854069};\\\", \\\"{x:410,y:555,t:1527189854086};\\\", \\\"{x:423,y:555,t:1527189854103};\\\", \\\"{x:438,y:555,t:1527189854119};\\\", \\\"{x:452,y:555,t:1527189854135};\\\", \\\"{x:462,y:555,t:1527189854153};\\\", \\\"{x:471,y:554,t:1527189854169};\\\", \\\"{x:484,y:554,t:1527189854185};\\\", \\\"{x:495,y:554,t:1527189854203};\\\", \\\"{x:510,y:553,t:1527189854219};\\\", \\\"{x:524,y:553,t:1527189854235};\\\", \\\"{x:536,y:553,t:1527189854252};\\\", \\\"{x:540,y:553,t:1527189854269};\\\", \\\"{x:548,y:553,t:1527189854285};\\\", \\\"{x:557,y:553,t:1527189854303};\\\", \\\"{x:564,y:553,t:1527189854319};\\\", \\\"{x:575,y:553,t:1527189854336};\\\", \\\"{x:589,y:553,t:1527189854353};\\\", \\\"{x:605,y:553,t:1527189854369};\\\", \\\"{x:626,y:553,t:1527189854386};\\\", \\\"{x:642,y:553,t:1527189854403};\\\", \\\"{x:667,y:553,t:1527189854419};\\\", \\\"{x:690,y:553,t:1527189854436};\\\", \\\"{x:709,y:553,t:1527189854453};\\\", \\\"{x:727,y:553,t:1527189854471};\\\", \\\"{x:746,y:551,t:1527189854486};\\\", \\\"{x:758,y:549,t:1527189854503};\\\", \\\"{x:771,y:546,t:1527189854520};\\\", \\\"{x:781,y:544,t:1527189854536};\\\", \\\"{x:793,y:540,t:1527189854552};\\\", \\\"{x:808,y:536,t:1527189854570};\\\", \\\"{x:823,y:531,t:1527189854587};\\\", \\\"{x:831,y:528,t:1527189854603};\\\", \\\"{x:834,y:525,t:1527189854620};\\\", \\\"{x:839,y:521,t:1527189854636};\\\", \\\"{x:845,y:514,t:1527189854653};\\\", \\\"{x:849,y:510,t:1527189854669};\\\", \\\"{x:851,y:509,t:1527189854686};\\\", \\\"{x:852,y:507,t:1527189854702};\\\", \\\"{x:852,y:505,t:1527189854720};\\\", \\\"{x:853,y:503,t:1527189854757};\\\", \\\"{x:854,y:503,t:1527189854934};\\\", \\\"{x:853,y:502,t:1527189854941};\\\", \\\"{x:851,y:502,t:1527189854954};\\\", \\\"{x:850,y:502,t:1527189855014};\\\", \\\"{x:849,y:502,t:1527189855038};\\\", \\\"{x:847,y:504,t:1527189855237};\\\", \\\"{x:843,y:508,t:1527189855253};\\\", \\\"{x:838,y:517,t:1527189855270};\\\", \\\"{x:831,y:528,t:1527189855287};\\\", \\\"{x:819,y:540,t:1527189855304};\\\", \\\"{x:812,y:551,t:1527189855319};\\\", \\\"{x:801,y:561,t:1527189855337};\\\", \\\"{x:787,y:572,t:1527189855353};\\\", \\\"{x:775,y:584,t:1527189855370};\\\", \\\"{x:753,y:600,t:1527189855387};\\\", \\\"{x:729,y:615,t:1527189855404};\\\", \\\"{x:708,y:631,t:1527189855420};\\\", \\\"{x:695,y:642,t:1527189855437};\\\", \\\"{x:688,y:651,t:1527189855453};\\\", \\\"{x:682,y:657,t:1527189855470};\\\", \\\"{x:676,y:659,t:1527189855487};\\\", \\\"{x:668,y:663,t:1527189855504};\\\", \\\"{x:661,y:667,t:1527189855519};\\\", \\\"{x:656,y:671,t:1527189855537};\\\", \\\"{x:653,y:677,t:1527189855554};\\\", \\\"{x:641,y:687,t:1527189855570};\\\", \\\"{x:632,y:693,t:1527189855587};\\\", \\\"{x:623,y:700,t:1527189855604};\\\", \\\"{x:614,y:704,t:1527189855620};\\\", \\\"{x:607,y:710,t:1527189855637};\\\", \\\"{x:598,y:717,t:1527189855654};\\\", \\\"{x:593,y:722,t:1527189855670};\\\", \\\"{x:589,y:726,t:1527189855688};\\\", \\\"{x:583,y:730,t:1527189855704};\\\", \\\"{x:572,y:735,t:1527189855720};\\\", \\\"{x:565,y:739,t:1527189855737};\\\", \\\"{x:555,y:745,t:1527189855755};\\\", \\\"{x:539,y:750,t:1527189855770};\\\", \\\"{x:531,y:754,t:1527189855787};\\\", \\\"{x:518,y:754,t:1527189855804};\\\", \\\"{x:515,y:754,t:1527189855821};\\\", \\\"{x:509,y:750,t:1527189855836};\\\", \\\"{x:509,y:749,t:1527189855854};\\\", \\\"{x:509,y:746,t:1527189855885};\\\", \\\"{x:509,y:743,t:1527189855893};\\\", \\\"{x:507,y:741,t:1527189855903};\\\", \\\"{x:506,y:736,t:1527189855921};\\\", \\\"{x:506,y:735,t:1527189855990};\\\", \\\"{x:506,y:733,t:1527189856013};\\\" ] }, { \\\"rt\\\": 46444, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 483273, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"F98S2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -B -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:506,y:729,t:1527189862447};\\\", \\\"{x:506,y:724,t:1527189862454};\\\", \\\"{x:504,y:711,t:1527189862471};\\\", \\\"{x:503,y:694,t:1527189862486};\\\", \\\"{x:503,y:678,t:1527189862503};\\\", \\\"{x:502,y:658,t:1527189862526};\\\", \\\"{x:499,y:651,t:1527189862543};\\\", \\\"{x:495,y:640,t:1527189862559};\\\", \\\"{x:492,y:636,t:1527189862577};\\\", \\\"{x:488,y:632,t:1527189862593};\\\", \\\"{x:481,y:621,t:1527189862609};\\\", \\\"{x:475,y:614,t:1527189862626};\\\", \\\"{x:469,y:606,t:1527189862643};\\\", \\\"{x:464,y:602,t:1527189862659};\\\", \\\"{x:459,y:599,t:1527189862677};\\\", \\\"{x:441,y:592,t:1527189862694};\\\", \\\"{x:425,y:585,t:1527189862709};\\\", \\\"{x:414,y:579,t:1527189862727};\\\", \\\"{x:402,y:575,t:1527189862742};\\\", \\\"{x:381,y:562,t:1527189862759};\\\", \\\"{x:356,y:542,t:1527189862777};\\\", \\\"{x:334,y:526,t:1527189862793};\\\", \\\"{x:300,y:510,t:1527189862809};\\\", \\\"{x:248,y:498,t:1527189862826};\\\", \\\"{x:234,y:493,t:1527189862843};\\\", \\\"{x:222,y:487,t:1527189862859};\\\", \\\"{x:220,y:487,t:1527189862876};\\\", \\\"{x:220,y:485,t:1527189863039};\\\", \\\"{x:222,y:485,t:1527189863060};\\\", \\\"{x:226,y:483,t:1527189863076};\\\", \\\"{x:231,y:481,t:1527189863093};\\\", \\\"{x:236,y:477,t:1527189863110};\\\", \\\"{x:242,y:474,t:1527189863126};\\\", \\\"{x:246,y:472,t:1527189863143};\\\", \\\"{x:249,y:470,t:1527189863160};\\\", \\\"{x:253,y:470,t:1527189863176};\\\", \\\"{x:257,y:468,t:1527189863193};\\\", \\\"{x:265,y:466,t:1527189863210};\\\", \\\"{x:273,y:465,t:1527189863228};\\\", \\\"{x:278,y:463,t:1527189863244};\\\", \\\"{x:282,y:462,t:1527189863260};\\\", \\\"{x:290,y:460,t:1527189863277};\\\", \\\"{x:292,y:460,t:1527189863293};\\\", \\\"{x:296,y:459,t:1527189863311};\\\", \\\"{x:305,y:458,t:1527189863327};\\\", \\\"{x:308,y:457,t:1527189863343};\\\", \\\"{x:311,y:456,t:1527189863360};\\\", \\\"{x:321,y:455,t:1527189863377};\\\", \\\"{x:331,y:455,t:1527189863393};\\\", \\\"{x:339,y:455,t:1527189863410};\\\", \\\"{x:346,y:455,t:1527189863428};\\\", \\\"{x:354,y:455,t:1527189863443};\\\", \\\"{x:360,y:455,t:1527189863460};\\\", \\\"{x:372,y:455,t:1527189863477};\\\", \\\"{x:376,y:456,t:1527189863494};\\\", \\\"{x:377,y:457,t:1527189863511};\\\", \\\"{x:379,y:458,t:1527189863542};\\\", \\\"{x:380,y:458,t:1527189863550};\\\", \\\"{x:381,y:459,t:1527189863566};\\\", \\\"{x:383,y:459,t:1527189863582};\\\", \\\"{x:386,y:459,t:1527189863595};\\\", \\\"{x:389,y:459,t:1527189863610};\\\", \\\"{x:393,y:459,t:1527189863627};\\\", \\\"{x:399,y:461,t:1527189863644};\\\", \\\"{x:408,y:463,t:1527189863660};\\\", \\\"{x:421,y:464,t:1527189863677};\\\", \\\"{x:426,y:464,t:1527189863693};\\\", \\\"{x:436,y:465,t:1527189863710};\\\", \\\"{x:450,y:465,t:1527189863728};\\\", \\\"{x:469,y:468,t:1527189863745};\\\", \\\"{x:486,y:469,t:1527189863761};\\\", \\\"{x:498,y:469,t:1527189863778};\\\", \\\"{x:503,y:469,t:1527189863795};\\\", \\\"{x:510,y:469,t:1527189863811};\\\", \\\"{x:514,y:469,t:1527189863827};\\\", \\\"{x:524,y:467,t:1527189863845};\\\", \\\"{x:529,y:467,t:1527189863861};\\\", \\\"{x:536,y:467,t:1527189863877};\\\", \\\"{x:542,y:467,t:1527189863894};\\\", \\\"{x:548,y:467,t:1527189863912};\\\", \\\"{x:554,y:468,t:1527189863928};\\\", \\\"{x:557,y:468,t:1527189863945};\\\", \\\"{x:558,y:468,t:1527189863961};\\\", \\\"{x:563,y:469,t:1527189864454};\\\", \\\"{x:572,y:473,t:1527189864461};\\\", \\\"{x:583,y:481,t:1527189864479};\\\", \\\"{x:587,y:486,t:1527189864496};\\\", \\\"{x:587,y:487,t:1527189864513};\\\", \\\"{x:589,y:487,t:1527189864613};\\\", \\\"{x:592,y:489,t:1527189864627};\\\", \\\"{x:599,y:491,t:1527189864644};\\\", \\\"{x:622,y:499,t:1527189864661};\\\", \\\"{x:638,y:502,t:1527189864677};\\\", \\\"{x:670,y:508,t:1527189864694};\\\", \\\"{x:705,y:520,t:1527189864711};\\\", \\\"{x:796,y:529,t:1527189864729};\\\", \\\"{x:898,y:543,t:1527189864744};\\\", \\\"{x:990,y:543,t:1527189864762};\\\", \\\"{x:1074,y:547,t:1527189864778};\\\", \\\"{x:1147,y:557,t:1527189864794};\\\", \\\"{x:1185,y:565,t:1527189864812};\\\", \\\"{x:1255,y:595,t:1527189864830};\\\", \\\"{x:1288,y:600,t:1527189864844};\\\", \\\"{x:1340,y:601,t:1527189864861};\\\", \\\"{x:1355,y:601,t:1527189864878};\\\", \\\"{x:1357,y:601,t:1527189864894};\\\", \\\"{x:1357,y:600,t:1527189864926};\\\", \\\"{x:1357,y:599,t:1527189864934};\\\", \\\"{x:1357,y:598,t:1527189864945};\\\", \\\"{x:1358,y:595,t:1527189864962};\\\", \\\"{x:1358,y:592,t:1527189864979};\\\", \\\"{x:1358,y:589,t:1527189864995};\\\", \\\"{x:1358,y:584,t:1527189865011};\\\", \\\"{x:1356,y:579,t:1527189865029};\\\", \\\"{x:1353,y:577,t:1527189865045};\\\", \\\"{x:1345,y:571,t:1527189865062};\\\", \\\"{x:1334,y:565,t:1527189865078};\\\", \\\"{x:1328,y:562,t:1527189865095};\\\", \\\"{x:1321,y:561,t:1527189865112};\\\", \\\"{x:1309,y:561,t:1527189865129};\\\", \\\"{x:1297,y:559,t:1527189865145};\\\", \\\"{x:1292,y:559,t:1527189865162};\\\", \\\"{x:1290,y:559,t:1527189865178};\\\", \\\"{x:1287,y:559,t:1527189865196};\\\", \\\"{x:1286,y:559,t:1527189865211};\\\", \\\"{x:1285,y:559,t:1527189865265};\\\", \\\"{x:1285,y:557,t:1527189865341};\\\", \\\"{x:1285,y:556,t:1527189865357};\\\", \\\"{x:1285,y:554,t:1527189865365};\\\", \\\"{x:1286,y:552,t:1527189865379};\\\", \\\"{x:1289,y:547,t:1527189865395};\\\", \\\"{x:1293,y:541,t:1527189865411};\\\", \\\"{x:1298,y:533,t:1527189865430};\\\", \\\"{x:1303,y:526,t:1527189865445};\\\", \\\"{x:1304,y:523,t:1527189865461};\\\", \\\"{x:1306,y:518,t:1527189865478};\\\", \\\"{x:1309,y:516,t:1527189865496};\\\", \\\"{x:1311,y:511,t:1527189865512};\\\", \\\"{x:1312,y:509,t:1527189865528};\\\", \\\"{x:1313,y:508,t:1527189865546};\\\", \\\"{x:1313,y:507,t:1527189865562};\\\", \\\"{x:1315,y:506,t:1527189865578};\\\", \\\"{x:1315,y:505,t:1527189865670};\\\", \\\"{x:1315,y:506,t:1527189865910};\\\", \\\"{x:1315,y:507,t:1527189865918};\\\", \\\"{x:1315,y:508,t:1527189865928};\\\", \\\"{x:1315,y:511,t:1527189865946};\\\", \\\"{x:1314,y:515,t:1527189865963};\\\", \\\"{x:1314,y:517,t:1527189865978};\\\", \\\"{x:1314,y:521,t:1527189865996};\\\", \\\"{x:1312,y:524,t:1527189866013};\\\", \\\"{x:1312,y:526,t:1527189866030};\\\", \\\"{x:1311,y:528,t:1527189866045};\\\", \\\"{x:1311,y:529,t:1527189866063};\\\", \\\"{x:1311,y:531,t:1527189866102};\\\", \\\"{x:1311,y:532,t:1527189866134};\\\", \\\"{x:1311,y:534,t:1527189866157};\\\", \\\"{x:1311,y:535,t:1527189866165};\\\", \\\"{x:1310,y:537,t:1527189866179};\\\", \\\"{x:1310,y:539,t:1527189866195};\\\", \\\"{x:1309,y:542,t:1527189866212};\\\", \\\"{x:1309,y:544,t:1527189866245};\\\", \\\"{x:1309,y:545,t:1527189866277};\\\", \\\"{x:1308,y:546,t:1527189866285};\\\", \\\"{x:1308,y:547,t:1527189867863};\\\", \\\"{x:1308,y:549,t:1527189867870};\\\", \\\"{x:1308,y:552,t:1527189867881};\\\", \\\"{x:1313,y:564,t:1527189867898};\\\", \\\"{x:1322,y:577,t:1527189867914};\\\", \\\"{x:1332,y:588,t:1527189867931};\\\", \\\"{x:1341,y:597,t:1527189867948};\\\", \\\"{x:1351,y:607,t:1527189867964};\\\", \\\"{x:1358,y:614,t:1527189867981};\\\", \\\"{x:1364,y:623,t:1527189867998};\\\", \\\"{x:1366,y:630,t:1527189868014};\\\", \\\"{x:1371,y:636,t:1527189868031};\\\", \\\"{x:1372,y:638,t:1527189868048};\\\", \\\"{x:1372,y:645,t:1527189868064};\\\", \\\"{x:1373,y:652,t:1527189868081};\\\", \\\"{x:1374,y:662,t:1527189868098};\\\", \\\"{x:1376,y:663,t:1527189868114};\\\", \\\"{x:1376,y:670,t:1527189868131};\\\", \\\"{x:1376,y:676,t:1527189868148};\\\", \\\"{x:1374,y:681,t:1527189868164};\\\", \\\"{x:1370,y:690,t:1527189868181};\\\", \\\"{x:1361,y:707,t:1527189868198};\\\", \\\"{x:1356,y:718,t:1527189868214};\\\", \\\"{x:1350,y:725,t:1527189868231};\\\", \\\"{x:1348,y:733,t:1527189868248};\\\", \\\"{x:1346,y:738,t:1527189868265};\\\", \\\"{x:1344,y:743,t:1527189868281};\\\", \\\"{x:1342,y:748,t:1527189868298};\\\", \\\"{x:1339,y:752,t:1527189868315};\\\", \\\"{x:1335,y:757,t:1527189868331};\\\", \\\"{x:1330,y:766,t:1527189868348};\\\", \\\"{x:1325,y:775,t:1527189868365};\\\", \\\"{x:1320,y:781,t:1527189868381};\\\", \\\"{x:1317,y:786,t:1527189868398};\\\", \\\"{x:1316,y:786,t:1527189868415};\\\", \\\"{x:1317,y:786,t:1527189868558};\\\", \\\"{x:1319,y:785,t:1527189868566};\\\", \\\"{x:1319,y:784,t:1527189868582};\\\", \\\"{x:1321,y:783,t:1527189868598};\\\", \\\"{x:1322,y:782,t:1527189868615};\\\", \\\"{x:1324,y:780,t:1527189868631};\\\", \\\"{x:1325,y:779,t:1527189868678};\\\", \\\"{x:1327,y:778,t:1527189868694};\\\", \\\"{x:1328,y:777,t:1527189868710};\\\", \\\"{x:1328,y:775,t:1527189868717};\\\", \\\"{x:1329,y:775,t:1527189868732};\\\", \\\"{x:1329,y:774,t:1527189868748};\\\", \\\"{x:1329,y:773,t:1527189868765};\\\", \\\"{x:1330,y:773,t:1527189868782};\\\", \\\"{x:1330,y:772,t:1527189868798};\\\", \\\"{x:1331,y:770,t:1527189868815};\\\", \\\"{x:1333,y:768,t:1527189868832};\\\", \\\"{x:1334,y:766,t:1527189868848};\\\", \\\"{x:1334,y:765,t:1527189868865};\\\", \\\"{x:1335,y:761,t:1527189868886};\\\", \\\"{x:1336,y:761,t:1527189868902};\\\", \\\"{x:1337,y:760,t:1527189868958};\\\", \\\"{x:1338,y:759,t:1527189868966};\\\", \\\"{x:1338,y:758,t:1527189868997};\\\", \\\"{x:1344,y:759,t:1527189882598};\\\", \\\"{x:1346,y:766,t:1527189882609};\\\", \\\"{x:1353,y:774,t:1527189882626};\\\", \\\"{x:1354,y:774,t:1527189882642};\\\", \\\"{x:1349,y:773,t:1527189901073};\\\", \\\"{x:1343,y:770,t:1527189901080};\\\", \\\"{x:1332,y:768,t:1527189901094};\\\", \\\"{x:1314,y:766,t:1527189901110};\\\", \\\"{x:1301,y:761,t:1527189901127};\\\", \\\"{x:1294,y:757,t:1527189901143};\\\", \\\"{x:1288,y:754,t:1527189901161};\\\", \\\"{x:1286,y:753,t:1527189901177};\\\", \\\"{x:1285,y:753,t:1527189901401};\\\", \\\"{x:1284,y:753,t:1527189901441};\\\", \\\"{x:1283,y:753,t:1527189901497};\\\", \\\"{x:1282,y:755,t:1527189901510};\\\", \\\"{x:1281,y:757,t:1527189901528};\\\", \\\"{x:1279,y:761,t:1527189901544};\\\", \\\"{x:1277,y:764,t:1527189901560};\\\", \\\"{x:1275,y:767,t:1527189901577};\\\", \\\"{x:1272,y:772,t:1527189901594};\\\", \\\"{x:1268,y:778,t:1527189901610};\\\", \\\"{x:1263,y:784,t:1527189901627};\\\", \\\"{x:1260,y:789,t:1527189901644};\\\", \\\"{x:1257,y:793,t:1527189901660};\\\", \\\"{x:1255,y:801,t:1527189901677};\\\", \\\"{x:1252,y:806,t:1527189901694};\\\", \\\"{x:1248,y:812,t:1527189901711};\\\", \\\"{x:1245,y:818,t:1527189901727};\\\", \\\"{x:1241,y:824,t:1527189901744};\\\", \\\"{x:1239,y:826,t:1527189901762};\\\", \\\"{x:1238,y:827,t:1527189901777};\\\", \\\"{x:1236,y:829,t:1527189901795};\\\", \\\"{x:1236,y:830,t:1527189901812};\\\", \\\"{x:1236,y:831,t:1527189901833};\\\", \\\"{x:1235,y:831,t:1527189901856};\\\", \\\"{x:1234,y:832,t:1527189901864};\\\", \\\"{x:1233,y:832,t:1527189901889};\\\", \\\"{x:1232,y:832,t:1527189901896};\\\", \\\"{x:1231,y:832,t:1527189901912};\\\", \\\"{x:1230,y:832,t:1527189901928};\\\", \\\"{x:1225,y:832,t:1527189901945};\\\", \\\"{x:1219,y:832,t:1527189901962};\\\", \\\"{x:1213,y:832,t:1527189901977};\\\", \\\"{x:1199,y:828,t:1527189901995};\\\", \\\"{x:1192,y:827,t:1527189902011};\\\", \\\"{x:1189,y:825,t:1527189902041};\\\", \\\"{x:1189,y:824,t:1527189902056};\\\", \\\"{x:1186,y:824,t:1527189902186};\\\", \\\"{x:1182,y:822,t:1527189902194};\\\", \\\"{x:1162,y:813,t:1527189902212};\\\", \\\"{x:1140,y:804,t:1527189902229};\\\", \\\"{x:1101,y:796,t:1527189902244};\\\", \\\"{x:1075,y:785,t:1527189902262};\\\", \\\"{x:1041,y:778,t:1527189902279};\\\", \\\"{x:997,y:768,t:1527189902295};\\\", \\\"{x:968,y:763,t:1527189902312};\\\", \\\"{x:890,y:748,t:1527189902328};\\\", \\\"{x:842,y:741,t:1527189902345};\\\", \\\"{x:797,y:734,t:1527189902362};\\\", \\\"{x:772,y:731,t:1527189902379};\\\", \\\"{x:752,y:729,t:1527189902394};\\\", \\\"{x:731,y:727,t:1527189902412};\\\", \\\"{x:712,y:717,t:1527189902429};\\\", \\\"{x:682,y:705,t:1527189902445};\\\", \\\"{x:637,y:697,t:1527189902461};\\\", \\\"{x:593,y:687,t:1527189902479};\\\", \\\"{x:570,y:673,t:1527189902494};\\\", \\\"{x:560,y:666,t:1527189902512};\\\", \\\"{x:556,y:653,t:1527189902528};\\\", \\\"{x:556,y:634,t:1527189902545};\\\", \\\"{x:562,y:615,t:1527189902563};\\\", \\\"{x:574,y:599,t:1527189902579};\\\", \\\"{x:589,y:584,t:1527189902596};\\\", \\\"{x:603,y:567,t:1527189902613};\\\", \\\"{x:617,y:547,t:1527189902629};\\\", \\\"{x:621,y:536,t:1527189902645};\\\", \\\"{x:624,y:532,t:1527189902662};\\\", \\\"{x:625,y:532,t:1527189902679};\\\", \\\"{x:626,y:531,t:1527189902695};\\\", \\\"{x:629,y:527,t:1527189902712};\\\", \\\"{x:630,y:525,t:1527189902729};\\\", \\\"{x:630,y:523,t:1527189902745};\\\", \\\"{x:630,y:521,t:1527189902800};\\\", \\\"{x:630,y:519,t:1527189902812};\\\", \\\"{x:630,y:518,t:1527189902829};\\\", \\\"{x:630,y:516,t:1527189902845};\\\", \\\"{x:626,y:514,t:1527189902862};\\\", \\\"{x:624,y:511,t:1527189902879};\\\", \\\"{x:623,y:510,t:1527189902895};\\\", \\\"{x:622,y:509,t:1527189902913};\\\", \\\"{x:621,y:508,t:1527189902944};\\\", \\\"{x:621,y:506,t:1527189902960};\\\", \\\"{x:621,y:505,t:1527189902968};\\\", \\\"{x:619,y:504,t:1527189902980};\\\", \\\"{x:619,y:503,t:1527189903000};\\\", \\\"{x:618,y:503,t:1527189903199};\\\", \\\"{x:617,y:506,t:1527189903212};\\\", \\\"{x:610,y:525,t:1527189903229};\\\", \\\"{x:604,y:542,t:1527189903246};\\\", \\\"{x:603,y:556,t:1527189903262};\\\", \\\"{x:602,y:580,t:1527189903279};\\\", \\\"{x:593,y:609,t:1527189903296};\\\", \\\"{x:588,y:630,t:1527189903312};\\\", \\\"{x:581,y:653,t:1527189903330};\\\", \\\"{x:573,y:678,t:1527189903346};\\\", \\\"{x:569,y:698,t:1527189903362};\\\", \\\"{x:562,y:717,t:1527189903380};\\\", \\\"{x:558,y:727,t:1527189903397};\\\", \\\"{x:553,y:734,t:1527189903413};\\\", \\\"{x:546,y:744,t:1527189903429};\\\", \\\"{x:541,y:753,t:1527189903446};\\\", \\\"{x:536,y:761,t:1527189903464};\\\", \\\"{x:531,y:769,t:1527189903479};\\\", \\\"{x:530,y:770,t:1527189903496};\\\", \\\"{x:530,y:771,t:1527189903593};\\\", \\\"{x:529,y:771,t:1527189903601};\\\", \\\"{x:528,y:769,t:1527189903613};\\\", \\\"{x:528,y:763,t:1527189903630};\\\", \\\"{x:526,y:755,t:1527189903646};\\\", \\\"{x:524,y:752,t:1527189903664};\\\", \\\"{x:519,y:748,t:1527189903679};\\\", \\\"{x:519,y:743,t:1527189903697};\\\" ] }, { \\\"rt\\\": 16556, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 501192, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"F98S2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:519,y:742,t:1527189909161};\\\", \\\"{x:519,y:736,t:1527189909174};\\\", \\\"{x:518,y:726,t:1527189909190};\\\", \\\"{x:516,y:722,t:1527189909207};\\\", \\\"{x:515,y:716,t:1527189909223};\\\", \\\"{x:511,y:704,t:1527189909240};\\\", \\\"{x:511,y:701,t:1527189909257};\\\", \\\"{x:511,y:699,t:1527189909267};\\\", \\\"{x:510,y:688,t:1527189909283};\\\", \\\"{x:507,y:675,t:1527189909300};\\\", \\\"{x:507,y:664,t:1527189909317};\\\", \\\"{x:507,y:652,t:1527189909335};\\\", \\\"{x:507,y:644,t:1527189909350};\\\", \\\"{x:508,y:629,t:1527189909368};\\\", \\\"{x:512,y:619,t:1527189909383};\\\", \\\"{x:516,y:609,t:1527189909400};\\\", \\\"{x:517,y:602,t:1527189909417};\\\", \\\"{x:518,y:598,t:1527189909436};\\\", \\\"{x:519,y:593,t:1527189909451};\\\", \\\"{x:519,y:589,t:1527189909467};\\\", \\\"{x:520,y:587,t:1527189909484};\\\", \\\"{x:520,y:584,t:1527189909502};\\\", \\\"{x:521,y:584,t:1527189909517};\\\", \\\"{x:520,y:581,t:1527189909665};\\\", \\\"{x:519,y:580,t:1527189909672};\\\", \\\"{x:514,y:576,t:1527189909684};\\\", \\\"{x:500,y:570,t:1527189909702};\\\", \\\"{x:479,y:561,t:1527189909719};\\\", \\\"{x:460,y:549,t:1527189909735};\\\", \\\"{x:429,y:531,t:1527189909752};\\\", \\\"{x:421,y:522,t:1527189909768};\\\", \\\"{x:409,y:517,t:1527189909785};\\\", \\\"{x:402,y:512,t:1527189909801};\\\", \\\"{x:400,y:511,t:1527189909818};\\\", \\\"{x:398,y:508,t:1527189909834};\\\", \\\"{x:397,y:508,t:1527189909851};\\\", \\\"{x:397,y:507,t:1527189909880};\\\", \\\"{x:397,y:506,t:1527189909913};\\\", \\\"{x:397,y:505,t:1527189909944};\\\", \\\"{x:399,y:504,t:1527189909951};\\\", \\\"{x:400,y:504,t:1527189909968};\\\", \\\"{x:401,y:501,t:1527189909985};\\\", \\\"{x:406,y:499,t:1527189910001};\\\", \\\"{x:410,y:497,t:1527189910017};\\\", \\\"{x:413,y:496,t:1527189910034};\\\", \\\"{x:417,y:494,t:1527189910053};\\\", \\\"{x:421,y:494,t:1527189910067};\\\", \\\"{x:425,y:490,t:1527189910084};\\\", \\\"{x:433,y:487,t:1527189910101};\\\", \\\"{x:438,y:486,t:1527189910119};\\\", \\\"{x:447,y:484,t:1527189910134};\\\", \\\"{x:456,y:483,t:1527189910151};\\\", \\\"{x:466,y:483,t:1527189910167};\\\", \\\"{x:472,y:483,t:1527189910185};\\\", \\\"{x:478,y:483,t:1527189910202};\\\", \\\"{x:487,y:483,t:1527189910219};\\\", \\\"{x:500,y:485,t:1527189910235};\\\", \\\"{x:506,y:485,t:1527189910252};\\\", \\\"{x:519,y:488,t:1527189910269};\\\", \\\"{x:540,y:490,t:1527189910285};\\\", \\\"{x:566,y:495,t:1527189910302};\\\", \\\"{x:587,y:499,t:1527189910318};\\\", \\\"{x:605,y:499,t:1527189910334};\\\", \\\"{x:615,y:502,t:1527189910352};\\\", \\\"{x:625,y:504,t:1527189910368};\\\", \\\"{x:647,y:506,t:1527189910386};\\\", \\\"{x:674,y:515,t:1527189910401};\\\", \\\"{x:693,y:522,t:1527189910420};\\\", \\\"{x:724,y:533,t:1527189910435};\\\", \\\"{x:755,y:549,t:1527189910452};\\\", \\\"{x:776,y:559,t:1527189910469};\\\", \\\"{x:839,y:585,t:1527189910486};\\\", \\\"{x:934,y:615,t:1527189910502};\\\", \\\"{x:1014,y:653,t:1527189910520};\\\", \\\"{x:1100,y:696,t:1527189910536};\\\", \\\"{x:1121,y:705,t:1527189910552};\\\", \\\"{x:1184,y:734,t:1527189910569};\\\", \\\"{x:1225,y:749,t:1527189910586};\\\", \\\"{x:1238,y:758,t:1527189910601};\\\", \\\"{x:1247,y:762,t:1527189910619};\\\", \\\"{x:1254,y:766,t:1527189910636};\\\", \\\"{x:1259,y:768,t:1527189910652};\\\", \\\"{x:1263,y:772,t:1527189910668};\\\", \\\"{x:1266,y:775,t:1527189910685};\\\", \\\"{x:1269,y:778,t:1527189910701};\\\", \\\"{x:1270,y:779,t:1527189910719};\\\", \\\"{x:1273,y:782,t:1527189910736};\\\", \\\"{x:1274,y:783,t:1527189910752};\\\", \\\"{x:1275,y:784,t:1527189910769};\\\", \\\"{x:1277,y:786,t:1527189910786};\\\", \\\"{x:1277,y:787,t:1527189910841};\\\", \\\"{x:1277,y:788,t:1527189910993};\\\", \\\"{x:1277,y:790,t:1527189911003};\\\", \\\"{x:1277,y:792,t:1527189911032};\\\", \\\"{x:1277,y:793,t:1527189911089};\\\", \\\"{x:1277,y:794,t:1527189911113};\\\", \\\"{x:1276,y:796,t:1527189911145};\\\", \\\"{x:1275,y:798,t:1527189911169};\\\", \\\"{x:1275,y:799,t:1527189911186};\\\", \\\"{x:1273,y:801,t:1527189911203};\\\", \\\"{x:1273,y:803,t:1527189911218};\\\", \\\"{x:1272,y:804,t:1527189911236};\\\", \\\"{x:1271,y:806,t:1527189911253};\\\", \\\"{x:1271,y:807,t:1527189911269};\\\", \\\"{x:1266,y:811,t:1527189911286};\\\", \\\"{x:1263,y:813,t:1527189911303};\\\", \\\"{x:1255,y:816,t:1527189911319};\\\", \\\"{x:1246,y:820,t:1527189911336};\\\", \\\"{x:1236,y:822,t:1527189911353};\\\", \\\"{x:1232,y:823,t:1527189911369};\\\", \\\"{x:1228,y:824,t:1527189911386};\\\", \\\"{x:1225,y:824,t:1527189911404};\\\", \\\"{x:1217,y:824,t:1527189911421};\\\", \\\"{x:1210,y:824,t:1527189911436};\\\", \\\"{x:1201,y:827,t:1527189911455};\\\", \\\"{x:1194,y:829,t:1527189911470};\\\", \\\"{x:1190,y:829,t:1527189911485};\\\", \\\"{x:1190,y:830,t:1527189911777};\\\", \\\"{x:1191,y:831,t:1527189911793};\\\", \\\"{x:1192,y:831,t:1527189911803};\\\", \\\"{x:1193,y:831,t:1527189911820};\\\", \\\"{x:1196,y:831,t:1527189911836};\\\", \\\"{x:1198,y:831,t:1527189911913};\\\", \\\"{x:1198,y:832,t:1527189911985};\\\", \\\"{x:1199,y:833,t:1527189911993};\\\", \\\"{x:1199,y:836,t:1527189912003};\\\", \\\"{x:1200,y:840,t:1527189912020};\\\", \\\"{x:1200,y:845,t:1527189912037};\\\", \\\"{x:1200,y:850,t:1527189912053};\\\", \\\"{x:1200,y:855,t:1527189912070};\\\", \\\"{x:1202,y:859,t:1527189912087};\\\", \\\"{x:1202,y:867,t:1527189912103};\\\", \\\"{x:1200,y:882,t:1527189912120};\\\", \\\"{x:1198,y:893,t:1527189912137};\\\", \\\"{x:1197,y:896,t:1527189912154};\\\", \\\"{x:1196,y:902,t:1527189912170};\\\", \\\"{x:1196,y:907,t:1527189912187};\\\", \\\"{x:1195,y:910,t:1527189912203};\\\", \\\"{x:1195,y:913,t:1527189912220};\\\", \\\"{x:1195,y:917,t:1527189912237};\\\", \\\"{x:1195,y:920,t:1527189912253};\\\", \\\"{x:1195,y:924,t:1527189912270};\\\", \\\"{x:1196,y:928,t:1527189912287};\\\", \\\"{x:1197,y:930,t:1527189912303};\\\", \\\"{x:1197,y:931,t:1527189912320};\\\", \\\"{x:1198,y:927,t:1527189912424};\\\", \\\"{x:1202,y:921,t:1527189912437};\\\", \\\"{x:1203,y:906,t:1527189912454};\\\", \\\"{x:1205,y:886,t:1527189912471};\\\", \\\"{x:1207,y:871,t:1527189912487};\\\", \\\"{x:1208,y:857,t:1527189912505};\\\", \\\"{x:1208,y:850,t:1527189912520};\\\", \\\"{x:1207,y:833,t:1527189912537};\\\", \\\"{x:1207,y:828,t:1527189912554};\\\", \\\"{x:1206,y:824,t:1527189912570};\\\", \\\"{x:1205,y:822,t:1527189912587};\\\", \\\"{x:1205,y:821,t:1527189912604};\\\", \\\"{x:1202,y:819,t:1527189912624};\\\", \\\"{x:1202,y:817,t:1527189912640};\\\", \\\"{x:1200,y:814,t:1527189912654};\\\", \\\"{x:1199,y:812,t:1527189912670};\\\", \\\"{x:1196,y:808,t:1527189912687};\\\", \\\"{x:1196,y:806,t:1527189912704};\\\", \\\"{x:1196,y:803,t:1527189912721};\\\", \\\"{x:1192,y:796,t:1527189912737};\\\", \\\"{x:1189,y:792,t:1527189912754};\\\", \\\"{x:1181,y:782,t:1527189912771};\\\", \\\"{x:1176,y:778,t:1527189912786};\\\", \\\"{x:1172,y:775,t:1527189912804};\\\", \\\"{x:1171,y:772,t:1527189912820};\\\", \\\"{x:1170,y:770,t:1527189912837};\\\", \\\"{x:1169,y:768,t:1527189912853};\\\", \\\"{x:1169,y:766,t:1527189912871};\\\", \\\"{x:1168,y:764,t:1527189912887};\\\", \\\"{x:1168,y:761,t:1527189912904};\\\", \\\"{x:1169,y:762,t:1527189913113};\\\", \\\"{x:1169,y:763,t:1527189913121};\\\", \\\"{x:1169,y:764,t:1527189913225};\\\", \\\"{x:1171,y:765,t:1527189913538};\\\", \\\"{x:1173,y:765,t:1527189913554};\\\", \\\"{x:1174,y:765,t:1527189913571};\\\", \\\"{x:1175,y:765,t:1527189913593};\\\", \\\"{x:1176,y:764,t:1527189916996};\\\", \\\"{x:1178,y:764,t:1527189917007};\\\", \\\"{x:1182,y:764,t:1527189917023};\\\", \\\"{x:1185,y:764,t:1527189917040};\\\", \\\"{x:1187,y:764,t:1527189917064};\\\", \\\"{x:1188,y:764,t:1527189917103};\\\", \\\"{x:1190,y:765,t:1527189917120};\\\", \\\"{x:1191,y:765,t:1527189917136};\\\", \\\"{x:1194,y:765,t:1527189917143};\\\", \\\"{x:1196,y:766,t:1527189917157};\\\", \\\"{x:1201,y:767,t:1527189917174};\\\", \\\"{x:1205,y:769,t:1527189917190};\\\", \\\"{x:1210,y:770,t:1527189917207};\\\", \\\"{x:1214,y:770,t:1527189917223};\\\", \\\"{x:1216,y:770,t:1527189917264};\\\", \\\"{x:1216,y:771,t:1527189917274};\\\", \\\"{x:1218,y:771,t:1527189917290};\\\", \\\"{x:1222,y:772,t:1527189917307};\\\", \\\"{x:1226,y:773,t:1527189917324};\\\", \\\"{x:1230,y:774,t:1527189917340};\\\", \\\"{x:1233,y:774,t:1527189917357};\\\", \\\"{x:1234,y:774,t:1527189917375};\\\", \\\"{x:1236,y:774,t:1527189917390};\\\", \\\"{x:1237,y:774,t:1527189917408};\\\", \\\"{x:1240,y:774,t:1527189917424};\\\", \\\"{x:1243,y:774,t:1527189917440};\\\", \\\"{x:1245,y:774,t:1527189917458};\\\", \\\"{x:1247,y:773,t:1527189917474};\\\", \\\"{x:1248,y:772,t:1527189917497};\\\", \\\"{x:1248,y:771,t:1527189917508};\\\", \\\"{x:1250,y:770,t:1527189917525};\\\", \\\"{x:1251,y:769,t:1527189917560};\\\", \\\"{x:1252,y:768,t:1527189917706};\\\", \\\"{x:1255,y:768,t:1527189917712};\\\", \\\"{x:1258,y:768,t:1527189917725};\\\", \\\"{x:1268,y:770,t:1527189917741};\\\", \\\"{x:1284,y:773,t:1527189917757};\\\", \\\"{x:1291,y:776,t:1527189917774};\\\", \\\"{x:1292,y:776,t:1527189917792};\\\", \\\"{x:1293,y:776,t:1527189917808};\\\", \\\"{x:1295,y:776,t:1527189917856};\\\", \\\"{x:1296,y:775,t:1527189917880};\\\", \\\"{x:1297,y:775,t:1527189917892};\\\", \\\"{x:1299,y:774,t:1527189917907};\\\", \\\"{x:1301,y:774,t:1527189917925};\\\", \\\"{x:1303,y:773,t:1527189917942};\\\", \\\"{x:1304,y:772,t:1527189917959};\\\", \\\"{x:1305,y:772,t:1527189917974};\\\", \\\"{x:1306,y:771,t:1527189917991};\\\", \\\"{x:1308,y:770,t:1527189918007};\\\", \\\"{x:1308,y:769,t:1527189918024};\\\", \\\"{x:1309,y:769,t:1527189918047};\\\", \\\"{x:1311,y:769,t:1527189918088};\\\", \\\"{x:1313,y:768,t:1527189918120};\\\", \\\"{x:1314,y:768,t:1527189918160};\\\", \\\"{x:1314,y:767,t:1527189918174};\\\", \\\"{x:1316,y:767,t:1527189918322};\\\", \\\"{x:1318,y:768,t:1527189918329};\\\", \\\"{x:1320,y:770,t:1527189918345};\\\", \\\"{x:1322,y:771,t:1527189918360};\\\", \\\"{x:1325,y:774,t:1527189918374};\\\", \\\"{x:1327,y:775,t:1527189918392};\\\", \\\"{x:1330,y:778,t:1527189918408};\\\", \\\"{x:1332,y:778,t:1527189918424};\\\", \\\"{x:1333,y:779,t:1527189918442};\\\", \\\"{x:1335,y:781,t:1527189918458};\\\", \\\"{x:1336,y:783,t:1527189918481};\\\", \\\"{x:1337,y:783,t:1527189918491};\\\", \\\"{x:1339,y:783,t:1527189918508};\\\", \\\"{x:1341,y:783,t:1527189918528};\\\", \\\"{x:1341,y:784,t:1527189918541};\\\", \\\"{x:1346,y:786,t:1527189918559};\\\", \\\"{x:1350,y:787,t:1527189918574};\\\", \\\"{x:1354,y:787,t:1527189918591};\\\", \\\"{x:1356,y:787,t:1527189918608};\\\", \\\"{x:1357,y:787,t:1527189918626};\\\", \\\"{x:1358,y:787,t:1527189918641};\\\", \\\"{x:1359,y:787,t:1527189918659};\\\", \\\"{x:1360,y:787,t:1527189918675};\\\", \\\"{x:1362,y:787,t:1527189918691};\\\", \\\"{x:1363,y:786,t:1527189918708};\\\", \\\"{x:1365,y:785,t:1527189918737};\\\", \\\"{x:1367,y:784,t:1527189918768};\\\", \\\"{x:1367,y:783,t:1527189918776};\\\", \\\"{x:1368,y:783,t:1527189918791};\\\", \\\"{x:1374,y:779,t:1527189918808};\\\", \\\"{x:1376,y:778,t:1527189918825};\\\", \\\"{x:1379,y:776,t:1527189918842};\\\", \\\"{x:1381,y:775,t:1527189918858};\\\", \\\"{x:1384,y:772,t:1527189918875};\\\", \\\"{x:1385,y:772,t:1527189918891};\\\", \\\"{x:1386,y:771,t:1527189918909};\\\", \\\"{x:1387,y:771,t:1527189918928};\\\", \\\"{x:1387,y:769,t:1527189918942};\\\", \\\"{x:1386,y:769,t:1527189919073};\\\", \\\"{x:1383,y:769,t:1527189919080};\\\", \\\"{x:1378,y:770,t:1527189919092};\\\", \\\"{x:1371,y:772,t:1527189919109};\\\", \\\"{x:1362,y:772,t:1527189919125};\\\", \\\"{x:1355,y:773,t:1527189919143};\\\", \\\"{x:1343,y:773,t:1527189919159};\\\", \\\"{x:1325,y:773,t:1527189919176};\\\", \\\"{x:1298,y:773,t:1527189919193};\\\", \\\"{x:1280,y:773,t:1527189919209};\\\", \\\"{x:1261,y:773,t:1527189919225};\\\", \\\"{x:1245,y:773,t:1527189919242};\\\", \\\"{x:1236,y:773,t:1527189919258};\\\", \\\"{x:1224,y:773,t:1527189919276};\\\", \\\"{x:1202,y:773,t:1527189919293};\\\", \\\"{x:1177,y:773,t:1527189919309};\\\", \\\"{x:1163,y:773,t:1527189919329};\\\", \\\"{x:1134,y:767,t:1527189919342};\\\", \\\"{x:1076,y:752,t:1527189919359};\\\", \\\"{x:983,y:731,t:1527189919375};\\\", \\\"{x:821,y:697,t:1527189919392};\\\", \\\"{x:741,y:674,t:1527189919408};\\\", \\\"{x:694,y:656,t:1527189919425};\\\", \\\"{x:664,y:643,t:1527189919441};\\\", \\\"{x:658,y:637,t:1527189919459};\\\", \\\"{x:647,y:627,t:1527189919475};\\\", \\\"{x:640,y:619,t:1527189919491};\\\", \\\"{x:634,y:610,t:1527189919509};\\\", \\\"{x:631,y:604,t:1527189919521};\\\", \\\"{x:626,y:595,t:1527189919537};\\\", \\\"{x:617,y:582,t:1527189919554};\\\", \\\"{x:612,y:572,t:1527189919576};\\\", \\\"{x:612,y:568,t:1527189919592};\\\", \\\"{x:611,y:564,t:1527189919609};\\\", \\\"{x:611,y:560,t:1527189919626};\\\", \\\"{x:611,y:556,t:1527189919643};\\\", \\\"{x:611,y:552,t:1527189919660};\\\", \\\"{x:611,y:549,t:1527189919676};\\\", \\\"{x:611,y:547,t:1527189919693};\\\", \\\"{x:609,y:545,t:1527189919744};\\\", \\\"{x:608,y:544,t:1527189919760};\\\", \\\"{x:607,y:543,t:1527189919776};\\\", \\\"{x:605,y:542,t:1527189919793};\\\", \\\"{x:601,y:540,t:1527189919810};\\\", \\\"{x:595,y:540,t:1527189919827};\\\", \\\"{x:583,y:540,t:1527189919843};\\\", \\\"{x:564,y:544,t:1527189919859};\\\", \\\"{x:543,y:548,t:1527189919877};\\\", \\\"{x:520,y:551,t:1527189919893};\\\", \\\"{x:508,y:554,t:1527189919909};\\\", \\\"{x:492,y:559,t:1527189919927};\\\", \\\"{x:477,y:561,t:1527189919943};\\\", \\\"{x:461,y:566,t:1527189919959};\\\", \\\"{x:442,y:570,t:1527189919976};\\\", \\\"{x:434,y:572,t:1527189919993};\\\", \\\"{x:427,y:574,t:1527189920008};\\\", \\\"{x:424,y:574,t:1527189920026};\\\", \\\"{x:422,y:574,t:1527189920043};\\\", \\\"{x:415,y:575,t:1527189920059};\\\", \\\"{x:401,y:576,t:1527189920076};\\\", \\\"{x:385,y:579,t:1527189920093};\\\", \\\"{x:375,y:580,t:1527189920109};\\\", \\\"{x:368,y:583,t:1527189920127};\\\", \\\"{x:367,y:584,t:1527189920142};\\\", \\\"{x:363,y:590,t:1527189920160};\\\", \\\"{x:361,y:594,t:1527189920176};\\\", \\\"{x:360,y:597,t:1527189920193};\\\", \\\"{x:360,y:598,t:1527189920210};\\\", \\\"{x:359,y:599,t:1527189920225};\\\", \\\"{x:355,y:599,t:1527189920297};\\\", \\\"{x:352,y:599,t:1527189920310};\\\", \\\"{x:338,y:599,t:1527189920327};\\\", \\\"{x:322,y:596,t:1527189920343};\\\", \\\"{x:297,y:588,t:1527189920362};\\\", \\\"{x:281,y:585,t:1527189920376};\\\", \\\"{x:276,y:582,t:1527189920393};\\\", \\\"{x:264,y:580,t:1527189920410};\\\", \\\"{x:253,y:577,t:1527189920427};\\\", \\\"{x:247,y:577,t:1527189920442};\\\", \\\"{x:242,y:576,t:1527189920460};\\\", \\\"{x:240,y:576,t:1527189920477};\\\", \\\"{x:238,y:576,t:1527189920492};\\\", \\\"{x:236,y:576,t:1527189920510};\\\", \\\"{x:234,y:576,t:1527189920527};\\\", \\\"{x:228,y:576,t:1527189920543};\\\", \\\"{x:219,y:578,t:1527189920560};\\\", \\\"{x:214,y:581,t:1527189920577};\\\", \\\"{x:212,y:581,t:1527189920593};\\\", \\\"{x:209,y:581,t:1527189920610};\\\", \\\"{x:206,y:581,t:1527189920627};\\\", \\\"{x:198,y:580,t:1527189920643};\\\", \\\"{x:194,y:579,t:1527189920660};\\\", \\\"{x:186,y:575,t:1527189920678};\\\", \\\"{x:179,y:566,t:1527189920694};\\\", \\\"{x:175,y:559,t:1527189920711};\\\", \\\"{x:173,y:554,t:1527189920727};\\\", \\\"{x:172,y:543,t:1527189920743};\\\", \\\"{x:171,y:540,t:1527189920759};\\\", \\\"{x:171,y:532,t:1527189920777};\\\", \\\"{x:170,y:528,t:1527189920794};\\\", \\\"{x:169,y:525,t:1527189920810};\\\", \\\"{x:169,y:524,t:1527189920827};\\\", \\\"{x:168,y:522,t:1527189920844};\\\", \\\"{x:168,y:521,t:1527189920860};\\\", \\\"{x:168,y:518,t:1527189920876};\\\", \\\"{x:168,y:517,t:1527189920895};\\\", \\\"{x:168,y:515,t:1527189920911};\\\", \\\"{x:168,y:513,t:1527189920927};\\\", \\\"{x:168,y:511,t:1527189920943};\\\", \\\"{x:168,y:509,t:1527189920960};\\\", \\\"{x:168,y:506,t:1527189920977};\\\", \\\"{x:168,y:505,t:1527189921007};\\\", \\\"{x:176,y:507,t:1527189921224};\\\", \\\"{x:188,y:520,t:1527189921232};\\\", \\\"{x:199,y:528,t:1527189921244};\\\", \\\"{x:231,y:559,t:1527189921261};\\\", \\\"{x:263,y:584,t:1527189921277};\\\", \\\"{x:285,y:605,t:1527189921294};\\\", \\\"{x:308,y:627,t:1527189921310};\\\", \\\"{x:344,y:651,t:1527189921327};\\\", \\\"{x:405,y:688,t:1527189921344};\\\", \\\"{x:428,y:701,t:1527189921361};\\\", \\\"{x:443,y:713,t:1527189921377};\\\", \\\"{x:456,y:723,t:1527189921394};\\\", \\\"{x:472,y:733,t:1527189921411};\\\", \\\"{x:481,y:738,t:1527189921426};\\\", \\\"{x:482,y:738,t:1527189921444};\\\", \\\"{x:483,y:739,t:1527189921461};\\\", \\\"{x:483,y:740,t:1527189921511};\\\", \\\"{x:483,y:741,t:1527189921528};\\\", \\\"{x:484,y:743,t:1527189921544};\\\" ] }, { \\\"rt\\\": 86807, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 589207, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"F98S2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -Z -04 PM-Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:485,y:743,t:1527189924920};\\\", \\\"{x:487,y:742,t:1527189924936};\\\", \\\"{x:487,y:741,t:1527189924957};\\\", \\\"{x:488,y:740,t:1527189924968};\\\", \\\"{x:489,y:738,t:1527189924999};\\\", \\\"{x:489,y:737,t:1527189925031};\\\", \\\"{x:490,y:737,t:1527189925063};\\\", \\\"{x:491,y:736,t:1527189925088};\\\", \\\"{x:493,y:733,t:1527189925103};\\\", \\\"{x:496,y:729,t:1527189925119};\\\", \\\"{x:503,y:722,t:1527189925136};\\\", \\\"{x:517,y:714,t:1527189925154};\\\", \\\"{x:530,y:710,t:1527189925169};\\\", \\\"{x:546,y:704,t:1527189925185};\\\", \\\"{x:559,y:702,t:1527189925197};\\\", \\\"{x:577,y:695,t:1527189925214};\\\", \\\"{x:604,y:691,t:1527189925229};\\\", \\\"{x:661,y:688,t:1527189925247};\\\", \\\"{x:751,y:688,t:1527189925263};\\\", \\\"{x:828,y:688,t:1527189925280};\\\", \\\"{x:909,y:688,t:1527189925297};\\\", \\\"{x:990,y:688,t:1527189925314};\\\", \\\"{x:1056,y:682,t:1527189925330};\\\", \\\"{x:1144,y:672,t:1527189925347};\\\", \\\"{x:1206,y:671,t:1527189925364};\\\", \\\"{x:1249,y:671,t:1527189925380};\\\", \\\"{x:1271,y:671,t:1527189925397};\\\", \\\"{x:1283,y:671,t:1527189925414};\\\", \\\"{x:1290,y:671,t:1527189925431};\\\", \\\"{x:1292,y:671,t:1527189925448};\\\", \\\"{x:1294,y:671,t:1527189925537};\\\", \\\"{x:1295,y:671,t:1527189925548};\\\", \\\"{x:1300,y:671,t:1527189925564};\\\", \\\"{x:1303,y:674,t:1527189925582};\\\", \\\"{x:1307,y:678,t:1527189925597};\\\", \\\"{x:1314,y:681,t:1527189925614};\\\", \\\"{x:1322,y:683,t:1527189925631};\\\", \\\"{x:1327,y:685,t:1527189925647};\\\", \\\"{x:1330,y:685,t:1527189925664};\\\", \\\"{x:1331,y:685,t:1527189925681};\\\", \\\"{x:1333,y:685,t:1527189925809};\\\", \\\"{x:1334,y:685,t:1527189925816};\\\", \\\"{x:1336,y:685,t:1527189925833};\\\", \\\"{x:1337,y:685,t:1527189925848};\\\", \\\"{x:1340,y:687,t:1527189925865};\\\", \\\"{x:1342,y:687,t:1527189925881};\\\", \\\"{x:1343,y:688,t:1527189925905};\\\", \\\"{x:1344,y:689,t:1527189925944};\\\", \\\"{x:1344,y:690,t:1527189925961};\\\", \\\"{x:1345,y:690,t:1527189925968};\\\", \\\"{x:1346,y:690,t:1527189925982};\\\", \\\"{x:1347,y:691,t:1527189927905};\\\", \\\"{x:1348,y:692,t:1527189927920};\\\", \\\"{x:1350,y:693,t:1527189927932};\\\", \\\"{x:1351,y:693,t:1527189927952};\\\", \\\"{x:1352,y:693,t:1527189927967};\\\", \\\"{x:1352,y:694,t:1527189928072};\\\", \\\"{x:1354,y:695,t:1527189928083};\\\", \\\"{x:1361,y:697,t:1527189928100};\\\", \\\"{x:1368,y:699,t:1527189928117};\\\", \\\"{x:1376,y:700,t:1527189928134};\\\", \\\"{x:1379,y:701,t:1527189928150};\\\", \\\"{x:1381,y:702,t:1527189928167};\\\", \\\"{x:1384,y:702,t:1527189928183};\\\", \\\"{x:1386,y:703,t:1527189928199};\\\", \\\"{x:1390,y:703,t:1527189928216};\\\", \\\"{x:1395,y:705,t:1527189928233};\\\", \\\"{x:1400,y:705,t:1527189928250};\\\", \\\"{x:1405,y:706,t:1527189928267};\\\", \\\"{x:1412,y:706,t:1527189928284};\\\", \\\"{x:1417,y:708,t:1527189928300};\\\", \\\"{x:1418,y:708,t:1527189928317};\\\", \\\"{x:1420,y:708,t:1527189928334};\\\", \\\"{x:1421,y:708,t:1527189928377};\\\", \\\"{x:1423,y:707,t:1527189928401};\\\", \\\"{x:1423,y:706,t:1527189928417};\\\", \\\"{x:1423,y:705,t:1527189928434};\\\", \\\"{x:1424,y:702,t:1527189928449};\\\", \\\"{x:1424,y:700,t:1527189928473};\\\", \\\"{x:1424,y:699,t:1527189928484};\\\", \\\"{x:1424,y:698,t:1527189928513};\\\", \\\"{x:1424,y:697,t:1527189928528};\\\", \\\"{x:1424,y:696,t:1527189928553};\\\", \\\"{x:1424,y:695,t:1527189928609};\\\", \\\"{x:1424,y:694,t:1527189928617};\\\", \\\"{x:1425,y:693,t:1527189928833};\\\", \\\"{x:1426,y:694,t:1527189928850};\\\", \\\"{x:1427,y:694,t:1527189928867};\\\", \\\"{x:1428,y:695,t:1527189928884};\\\", \\\"{x:1429,y:696,t:1527189928901};\\\", \\\"{x:1431,y:696,t:1527189928917};\\\", \\\"{x:1433,y:696,t:1527189928934};\\\", \\\"{x:1433,y:697,t:1527189928951};\\\", \\\"{x:1434,y:697,t:1527189928967};\\\", \\\"{x:1435,y:697,t:1527189928992};\\\", \\\"{x:1436,y:698,t:1527189929000};\\\", \\\"{x:1437,y:698,t:1527189929032};\\\", \\\"{x:1438,y:698,t:1527189929040};\\\", \\\"{x:1440,y:698,t:1527189929051};\\\", \\\"{x:1447,y:698,t:1527189929068};\\\", \\\"{x:1454,y:698,t:1527189929084};\\\", \\\"{x:1459,y:699,t:1527189929101};\\\", \\\"{x:1464,y:700,t:1527189929118};\\\", \\\"{x:1465,y:701,t:1527189929134};\\\", \\\"{x:1466,y:701,t:1527189929169};\\\", \\\"{x:1467,y:701,t:1527189929184};\\\", \\\"{x:1469,y:701,t:1527189929233};\\\", \\\"{x:1470,y:700,t:1527189929257};\\\", \\\"{x:1471,y:700,t:1527189929280};\\\", \\\"{x:1472,y:699,t:1527189929289};\\\", \\\"{x:1474,y:698,t:1527189929304};\\\", \\\"{x:1474,y:697,t:1527189929328};\\\", \\\"{x:1475,y:696,t:1527189929344};\\\", \\\"{x:1476,y:696,t:1527189929401};\\\", \\\"{x:1477,y:695,t:1527189929448};\\\", \\\"{x:1477,y:694,t:1527189929496};\\\", \\\"{x:1479,y:694,t:1527189929649};\\\", \\\"{x:1481,y:696,t:1527189929681};\\\", \\\"{x:1481,y:697,t:1527189929688};\\\", \\\"{x:1482,y:698,t:1527189929700};\\\", \\\"{x:1483,y:698,t:1527189929718};\\\", \\\"{x:1484,y:698,t:1527189929735};\\\", \\\"{x:1485,y:698,t:1527189929776};\\\", \\\"{x:1487,y:699,t:1527189929793};\\\", \\\"{x:1488,y:699,t:1527189929801};\\\", \\\"{x:1489,y:699,t:1527189929818};\\\", \\\"{x:1491,y:699,t:1527189929864};\\\", \\\"{x:1493,y:699,t:1527189929880};\\\", \\\"{x:1496,y:699,t:1527189929888};\\\", \\\"{x:1498,y:699,t:1527189929902};\\\", \\\"{x:1504,y:699,t:1527189929918};\\\", \\\"{x:1513,y:700,t:1527189929935};\\\", \\\"{x:1524,y:702,t:1527189929952};\\\", \\\"{x:1526,y:702,t:1527189929968};\\\", \\\"{x:1530,y:702,t:1527189929985};\\\", \\\"{x:1531,y:702,t:1527189930009};\\\", \\\"{x:1532,y:702,t:1527189930024};\\\", \\\"{x:1533,y:701,t:1527189930035};\\\", \\\"{x:1534,y:701,t:1527189930052};\\\", \\\"{x:1535,y:699,t:1527189930068};\\\", \\\"{x:1538,y:698,t:1527189930085};\\\", \\\"{x:1541,y:696,t:1527189930113};\\\", \\\"{x:1543,y:694,t:1527189930129};\\\", \\\"{x:1544,y:694,t:1527189930137};\\\", \\\"{x:1545,y:693,t:1527189930161};\\\", \\\"{x:1547,y:693,t:1527189930264};\\\", \\\"{x:1548,y:693,t:1527189930271};\\\", \\\"{x:1549,y:694,t:1527189930285};\\\", \\\"{x:1552,y:697,t:1527189930301};\\\", \\\"{x:1556,y:700,t:1527189930317};\\\", \\\"{x:1559,y:702,t:1527189930335};\\\", \\\"{x:1561,y:702,t:1527189930352};\\\", \\\"{x:1563,y:703,t:1527189930368};\\\", \\\"{x:1565,y:704,t:1527189930385};\\\", \\\"{x:1566,y:705,t:1527189930402};\\\", \\\"{x:1567,y:705,t:1527189930419};\\\", \\\"{x:1570,y:705,t:1527189930434};\\\", \\\"{x:1572,y:705,t:1527189930452};\\\", \\\"{x:1575,y:705,t:1527189930469};\\\", \\\"{x:1579,y:705,t:1527189930485};\\\", \\\"{x:1584,y:705,t:1527189930502};\\\", \\\"{x:1587,y:705,t:1527189930519};\\\", \\\"{x:1591,y:705,t:1527189930535};\\\", \\\"{x:1596,y:704,t:1527189930553};\\\", \\\"{x:1597,y:704,t:1527189930568};\\\", \\\"{x:1601,y:702,t:1527189930585};\\\", \\\"{x:1601,y:701,t:1527189930601};\\\", \\\"{x:1602,y:701,t:1527189930618};\\\", \\\"{x:1603,y:700,t:1527189930634};\\\", \\\"{x:1605,y:700,t:1527189930651};\\\", \\\"{x:1606,y:698,t:1527189930668};\\\", \\\"{x:1607,y:697,t:1527189930685};\\\", \\\"{x:1610,y:695,t:1527189930702};\\\", \\\"{x:1612,y:694,t:1527189930736};\\\", \\\"{x:1613,y:693,t:1527189930759};\\\", \\\"{x:1613,y:694,t:1527189935727};\\\", \\\"{x:1612,y:695,t:1527189935739};\\\", \\\"{x:1612,y:696,t:1527189935807};\\\", \\\"{x:1612,y:697,t:1527189935823};\\\", \\\"{x:1612,y:698,t:1527189935838};\\\", \\\"{x:1612,y:700,t:1527189935856};\\\", \\\"{x:1612,y:701,t:1527189935872};\\\", \\\"{x:1612,y:703,t:1527189935888};\\\", \\\"{x:1612,y:704,t:1527189935911};\\\", \\\"{x:1611,y:704,t:1527189935922};\\\", \\\"{x:1611,y:705,t:1527189935939};\\\", \\\"{x:1610,y:707,t:1527189935956};\\\", \\\"{x:1609,y:708,t:1527189935972};\\\", \\\"{x:1609,y:709,t:1527189936000};\\\", \\\"{x:1609,y:710,t:1527189936006};\\\", \\\"{x:1609,y:711,t:1527189936023};\\\", \\\"{x:1609,y:712,t:1527189936038};\\\", \\\"{x:1607,y:715,t:1527189936055};\\\", \\\"{x:1607,y:718,t:1527189936073};\\\", \\\"{x:1607,y:722,t:1527189936090};\\\", \\\"{x:1607,y:723,t:1527189936106};\\\", \\\"{x:1607,y:725,t:1527189936123};\\\", \\\"{x:1607,y:728,t:1527189936140};\\\", \\\"{x:1607,y:731,t:1527189936155};\\\", \\\"{x:1607,y:736,t:1527189936172};\\\", \\\"{x:1607,y:738,t:1527189936189};\\\", \\\"{x:1607,y:740,t:1527189936205};\\\", \\\"{x:1607,y:742,t:1527189936222};\\\", \\\"{x:1607,y:745,t:1527189936240};\\\", \\\"{x:1607,y:750,t:1527189936255};\\\", \\\"{x:1607,y:753,t:1527189936272};\\\", \\\"{x:1608,y:759,t:1527189936290};\\\", \\\"{x:1609,y:764,t:1527189936306};\\\", \\\"{x:1611,y:770,t:1527189936323};\\\", \\\"{x:1611,y:773,t:1527189936339};\\\", \\\"{x:1612,y:776,t:1527189936355};\\\", \\\"{x:1612,y:782,t:1527189936372};\\\", \\\"{x:1615,y:786,t:1527189936390};\\\", \\\"{x:1615,y:791,t:1527189936406};\\\", \\\"{x:1616,y:798,t:1527189936422};\\\", \\\"{x:1618,y:803,t:1527189936440};\\\", \\\"{x:1620,y:807,t:1527189936455};\\\", \\\"{x:1620,y:809,t:1527189936473};\\\", \\\"{x:1620,y:814,t:1527189936490};\\\", \\\"{x:1622,y:817,t:1527189936507};\\\", \\\"{x:1623,y:823,t:1527189936523};\\\", \\\"{x:1623,y:828,t:1527189936540};\\\", \\\"{x:1623,y:838,t:1527189936557};\\\", \\\"{x:1623,y:842,t:1527189936572};\\\", \\\"{x:1623,y:848,t:1527189936590};\\\", \\\"{x:1623,y:854,t:1527189936606};\\\", \\\"{x:1624,y:860,t:1527189936623};\\\", \\\"{x:1627,y:869,t:1527189936639};\\\", \\\"{x:1628,y:872,t:1527189936657};\\\", \\\"{x:1628,y:880,t:1527189936673};\\\", \\\"{x:1628,y:888,t:1527189936689};\\\", \\\"{x:1628,y:894,t:1527189936707};\\\", \\\"{x:1628,y:896,t:1527189936722};\\\", \\\"{x:1628,y:900,t:1527189936740};\\\", \\\"{x:1628,y:908,t:1527189936757};\\\", \\\"{x:1628,y:915,t:1527189936772};\\\", \\\"{x:1630,y:925,t:1527189936790};\\\", \\\"{x:1630,y:933,t:1527189936807};\\\", \\\"{x:1630,y:937,t:1527189936823};\\\", \\\"{x:1629,y:943,t:1527189936840};\\\", \\\"{x:1629,y:946,t:1527189936857};\\\", \\\"{x:1629,y:950,t:1527189936873};\\\", \\\"{x:1629,y:951,t:1527189936890};\\\", \\\"{x:1629,y:957,t:1527189936907};\\\", \\\"{x:1629,y:966,t:1527189936923};\\\", \\\"{x:1629,y:975,t:1527189936939};\\\", \\\"{x:1629,y:978,t:1527189936957};\\\", \\\"{x:1629,y:982,t:1527189936974};\\\", \\\"{x:1629,y:983,t:1527189937039};\\\", \\\"{x:1629,y:982,t:1527189937279};\\\", \\\"{x:1629,y:979,t:1527189937290};\\\", \\\"{x:1629,y:974,t:1527189937307};\\\", \\\"{x:1630,y:967,t:1527189937324};\\\", \\\"{x:1631,y:963,t:1527189937341};\\\", \\\"{x:1631,y:957,t:1527189937356};\\\", \\\"{x:1631,y:953,t:1527189937373};\\\", \\\"{x:1631,y:945,t:1527189937390};\\\", \\\"{x:1631,y:937,t:1527189937406};\\\", \\\"{x:1631,y:927,t:1527189937423};\\\", \\\"{x:1631,y:919,t:1527189937441};\\\", \\\"{x:1631,y:910,t:1527189937457};\\\", \\\"{x:1629,y:902,t:1527189937474};\\\", \\\"{x:1625,y:891,t:1527189937490};\\\", \\\"{x:1624,y:875,t:1527189937506};\\\", \\\"{x:1624,y:865,t:1527189937524};\\\", \\\"{x:1623,y:855,t:1527189937541};\\\", \\\"{x:1621,y:842,t:1527189937557};\\\", \\\"{x:1620,y:836,t:1527189937573};\\\", \\\"{x:1619,y:828,t:1527189937591};\\\", \\\"{x:1617,y:814,t:1527189937606};\\\", \\\"{x:1614,y:787,t:1527189937623};\\\", \\\"{x:1611,y:772,t:1527189937640};\\\", \\\"{x:1611,y:758,t:1527189937656};\\\", \\\"{x:1610,y:750,t:1527189937674};\\\", \\\"{x:1606,y:733,t:1527189937691};\\\", \\\"{x:1606,y:724,t:1527189937706};\\\", \\\"{x:1604,y:714,t:1527189937724};\\\", \\\"{x:1602,y:708,t:1527189937741};\\\", \\\"{x:1601,y:705,t:1527189937758};\\\", \\\"{x:1601,y:703,t:1527189937774};\\\", \\\"{x:1601,y:701,t:1527189937790};\\\", \\\"{x:1601,y:698,t:1527189937807};\\\", \\\"{x:1601,y:696,t:1527189937823};\\\", \\\"{x:1601,y:695,t:1527189937999};\\\", \\\"{x:1601,y:694,t:1527189938015};\\\", \\\"{x:1601,y:693,t:1527189938303};\\\", \\\"{x:1602,y:693,t:1527189938319};\\\", \\\"{x:1603,y:693,t:1527189938327};\\\", \\\"{x:1604,y:693,t:1527189938367};\\\", \\\"{x:1606,y:692,t:1527189938471};\\\", \\\"{x:1607,y:692,t:1527189938519};\\\", \\\"{x:1608,y:691,t:1527189938527};\\\", \\\"{x:1609,y:691,t:1527189938559};\\\", \\\"{x:1610,y:691,t:1527189938575};\\\", \\\"{x:1611,y:690,t:1527189938599};\\\", \\\"{x:1612,y:690,t:1527189938631};\\\", \\\"{x:1613,y:690,t:1527189939455};\\\", \\\"{x:1611,y:690,t:1527190007387};\\\", \\\"{x:1606,y:690,t:1527190007403};\\\", \\\"{x:1600,y:688,t:1527190007417};\\\", \\\"{x:1580,y:681,t:1527190007434};\\\", \\\"{x:1542,y:676,t:1527190007450};\\\", \\\"{x:1505,y:669,t:1527190007467};\\\", \\\"{x:1472,y:664,t:1527190007484};\\\", \\\"{x:1444,y:657,t:1527190007501};\\\", \\\"{x:1386,y:650,t:1527190007517};\\\", \\\"{x:1303,y:639,t:1527190007533};\\\", \\\"{x:1230,y:631,t:1527190007550};\\\", \\\"{x:1161,y:620,t:1527190007567};\\\", \\\"{x:1111,y:616,t:1527190007584};\\\", \\\"{x:1099,y:616,t:1527190007600};\\\", \\\"{x:1092,y:616,t:1527190007617};\\\", \\\"{x:1088,y:616,t:1527190007634};\\\", \\\"{x:1087,y:616,t:1527190007651};\\\", \\\"{x:1086,y:617,t:1527190007691};\\\", \\\"{x:1083,y:620,t:1527190007701};\\\", \\\"{x:1062,y:630,t:1527190007717};\\\", \\\"{x:1014,y:652,t:1527190007733};\\\", \\\"{x:919,y:658,t:1527190007751};\\\", \\\"{x:826,y:664,t:1527190007767};\\\", \\\"{x:743,y:664,t:1527190007783};\\\", \\\"{x:654,y:664,t:1527190007800};\\\", \\\"{x:565,y:664,t:1527190007817};\\\", \\\"{x:493,y:664,t:1527190007835};\\\", \\\"{x:445,y:658,t:1527190007850};\\\", \\\"{x:425,y:650,t:1527190007867};\\\", \\\"{x:412,y:642,t:1527190007882};\\\", \\\"{x:399,y:635,t:1527190007900};\\\", \\\"{x:397,y:632,t:1527190007915};\\\", \\\"{x:397,y:631,t:1527190007954};\\\", \\\"{x:397,y:630,t:1527190007968};\\\", \\\"{x:405,y:619,t:1527190007985};\\\", \\\"{x:426,y:610,t:1527190008001};\\\", \\\"{x:462,y:600,t:1527190008018};\\\", \\\"{x:518,y:592,t:1527190008036};\\\", \\\"{x:616,y:595,t:1527190008051};\\\", \\\"{x:686,y:595,t:1527190008068};\\\", \\\"{x:762,y:595,t:1527190008085};\\\", \\\"{x:789,y:590,t:1527190008101};\\\", \\\"{x:797,y:588,t:1527190008118};\\\", \\\"{x:799,y:586,t:1527190008135};\\\", \\\"{x:799,y:585,t:1527190008178};\\\", \\\"{x:799,y:583,t:1527190008186};\\\", \\\"{x:792,y:578,t:1527190008202};\\\", \\\"{x:785,y:576,t:1527190008218};\\\", \\\"{x:774,y:576,t:1527190008235};\\\", \\\"{x:768,y:576,t:1527190008252};\\\", \\\"{x:764,y:576,t:1527190008269};\\\", \\\"{x:751,y:574,t:1527190008286};\\\", \\\"{x:740,y:572,t:1527190008302};\\\", \\\"{x:726,y:572,t:1527190008319};\\\", \\\"{x:709,y:571,t:1527190008336};\\\", \\\"{x:697,y:571,t:1527190008352};\\\", \\\"{x:680,y:568,t:1527190008368};\\\", \\\"{x:669,y:567,t:1527190008385};\\\", \\\"{x:660,y:566,t:1527190008402};\\\", \\\"{x:658,y:566,t:1527190008419};\\\", \\\"{x:656,y:566,t:1527190008436};\\\", \\\"{x:655,y:568,t:1527190008452};\\\", \\\"{x:655,y:569,t:1527190008482};\\\", \\\"{x:654,y:570,t:1527190008491};\\\", \\\"{x:653,y:571,t:1527190008502};\\\", \\\"{x:652,y:572,t:1527190008538};\\\", \\\"{x:652,y:573,t:1527190008619};\\\", \\\"{x:649,y:574,t:1527190008636};\\\", \\\"{x:645,y:574,t:1527190008653};\\\", \\\"{x:642,y:575,t:1527190008669};\\\", \\\"{x:637,y:578,t:1527190008685};\\\", \\\"{x:635,y:578,t:1527190008705};\\\", \\\"{x:633,y:578,t:1527190008719};\\\", \\\"{x:631,y:579,t:1527190008735};\\\", \\\"{x:630,y:579,t:1527190008761};\\\", \\\"{x:628,y:579,t:1527190008786};\\\", \\\"{x:628,y:581,t:1527190009185};\\\", \\\"{x:626,y:584,t:1527190009202};\\\", \\\"{x:623,y:591,t:1527190009219};\\\", \\\"{x:619,y:599,t:1527190009237};\\\", \\\"{x:615,y:609,t:1527190009252};\\\", \\\"{x:610,y:621,t:1527190009269};\\\", \\\"{x:603,y:636,t:1527190009286};\\\", \\\"{x:598,y:646,t:1527190009302};\\\", \\\"{x:590,y:658,t:1527190009320};\\\", \\\"{x:587,y:668,t:1527190009336};\\\", \\\"{x:578,y:682,t:1527190009352};\\\", \\\"{x:576,y:695,t:1527190009369};\\\", \\\"{x:566,y:705,t:1527190009386};\\\", \\\"{x:563,y:709,t:1527190009403};\\\", \\\"{x:562,y:709,t:1527190009419};\\\", \\\"{x:561,y:711,t:1527190009475};\\\", \\\"{x:559,y:712,t:1527190009487};\\\", \\\"{x:556,y:715,t:1527190009502};\\\", \\\"{x:552,y:718,t:1527190009519};\\\", \\\"{x:549,y:721,t:1527190009538};\\\", \\\"{x:548,y:721,t:1527190009552};\\\", \\\"{x:547,y:723,t:1527190009585};\\\", \\\"{x:547,y:724,t:1527190009602};\\\", \\\"{x:547,y:726,t:1527190009619};\\\", \\\"{x:547,y:727,t:1527190009636};\\\", \\\"{x:546,y:728,t:1527190010195};\\\", \\\"{x:541,y:732,t:1527190010204};\\\", \\\"{x:518,y:762,t:1527190010220};\\\", \\\"{x:486,y:870,t:1527190010236};\\\", \\\"{x:431,y:1013,t:1527190010254};\\\", \\\"{x:387,y:1128,t:1527190010271};\\\", \\\"{x:318,y:1199,t:1527190010287};\\\", \\\"{x:276,y:1199,t:1527190010303};\\\", \\\"{x:233,y:1199,t:1527190010320};\\\", \\\"{x:185,y:1199,t:1527190010336};\\\", \\\"{x:147,y:1199,t:1527190010353};\\\", \\\"{x:91,y:1199,t:1527190010370};\\\", \\\"{x:70,y:1199,t:1527190010386};\\\", \\\"{x:61,y:1199,t:1527190010403};\\\", \\\"{x:59,y:1199,t:1527190010420};\\\", \\\"{x:59,y:1198,t:1527190011034};\\\", \\\"{x:59,y:1197,t:1527190011050};\\\", \\\"{x:59,y:1196,t:1527190011058};\\\", \\\"{x:59,y:1195,t:1527190011082};\\\" ] }, { \\\"rt\\\": 14786, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 605548, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"F98S2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 3.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-B -B -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:59,y:1192,t:1527190012235};\\\", \\\"{x:63,y:1183,t:1527190012253};\\\", \\\"{x:66,y:1177,t:1527190012271};\\\", \\\"{x:70,y:1165,t:1527190012286};\\\", \\\"{x:76,y:1155,t:1527190012306};\\\", \\\"{x:78,y:1145,t:1527190012322};\\\", \\\"{x:84,y:1130,t:1527190012338};\\\", \\\"{x:87,y:1117,t:1527190012355};\\\", \\\"{x:90,y:1111,t:1527190012372};\\\", \\\"{x:94,y:1101,t:1527190012389};\\\", \\\"{x:95,y:1089,t:1527190012406};\\\", \\\"{x:95,y:1078,t:1527190012422};\\\", \\\"{x:95,y:1063,t:1527190012439};\\\", \\\"{x:95,y:1053,t:1527190012456};\\\", \\\"{x:97,y:1035,t:1527190012473};\\\", \\\"{x:101,y:1001,t:1527190012490};\\\", \\\"{x:101,y:987,t:1527190012505};\\\", \\\"{x:104,y:953,t:1527190012523};\\\", \\\"{x:107,y:937,t:1527190012539};\\\", \\\"{x:113,y:920,t:1527190012555};\\\", \\\"{x:123,y:902,t:1527190012572};\\\", \\\"{x:132,y:878,t:1527190012588};\\\", \\\"{x:146,y:854,t:1527190012606};\\\", \\\"{x:163,y:827,t:1527190012622};\\\", \\\"{x:174,y:805,t:1527190012638};\\\", \\\"{x:186,y:789,t:1527190012656};\\\", \\\"{x:196,y:771,t:1527190012673};\\\", \\\"{x:211,y:755,t:1527190012690};\\\", \\\"{x:213,y:750,t:1527190012706};\\\", \\\"{x:222,y:742,t:1527190012722};\\\", \\\"{x:229,y:731,t:1527190012738};\\\", \\\"{x:235,y:725,t:1527190012755};\\\", \\\"{x:240,y:722,t:1527190012773};\\\", \\\"{x:248,y:718,t:1527190012789};\\\", \\\"{x:252,y:716,t:1527190012805};\\\", \\\"{x:253,y:713,t:1527190012822};\\\", \\\"{x:270,y:702,t:1527190012839};\\\", \\\"{x:277,y:697,t:1527190012856};\\\", \\\"{x:289,y:692,t:1527190012873};\\\", \\\"{x:305,y:688,t:1527190012890};\\\", \\\"{x:308,y:687,t:1527190012906};\\\", \\\"{x:317,y:685,t:1527190012922};\\\", \\\"{x:319,y:683,t:1527190012939};\\\", \\\"{x:320,y:680,t:1527190013171};\\\", \\\"{x:320,y:675,t:1527190013179};\\\", \\\"{x:320,y:672,t:1527190013189};\\\", \\\"{x:320,y:670,t:1527190013206};\\\", \\\"{x:320,y:668,t:1527190013223};\\\", \\\"{x:320,y:665,t:1527190013239};\\\", \\\"{x:326,y:653,t:1527190013255};\\\", \\\"{x:330,y:644,t:1527190013272};\\\", \\\"{x:336,y:636,t:1527190013289};\\\", \\\"{x:351,y:620,t:1527190013306};\\\", \\\"{x:361,y:610,t:1527190013323};\\\", \\\"{x:369,y:600,t:1527190013339};\\\", \\\"{x:386,y:588,t:1527190013356};\\\", \\\"{x:404,y:575,t:1527190013373};\\\", \\\"{x:425,y:565,t:1527190013390};\\\", \\\"{x:447,y:555,t:1527190013407};\\\", \\\"{x:464,y:548,t:1527190013422};\\\", \\\"{x:481,y:539,t:1527190013439};\\\", \\\"{x:505,y:525,t:1527190013456};\\\", \\\"{x:525,y:517,t:1527190013474};\\\", \\\"{x:539,y:510,t:1527190013489};\\\", \\\"{x:560,y:500,t:1527190013505};\\\", \\\"{x:575,y:494,t:1527190013522};\\\", \\\"{x:583,y:490,t:1527190013540};\\\", \\\"{x:595,y:486,t:1527190013557};\\\", \\\"{x:612,y:485,t:1527190013572};\\\", \\\"{x:631,y:482,t:1527190013590};\\\", \\\"{x:640,y:479,t:1527190013605};\\\", \\\"{x:650,y:479,t:1527190013623};\\\", \\\"{x:661,y:479,t:1527190013639};\\\", \\\"{x:671,y:479,t:1527190013655};\\\", \\\"{x:679,y:479,t:1527190013672};\\\", \\\"{x:699,y:481,t:1527190013689};\\\", \\\"{x:713,y:483,t:1527190013706};\\\", \\\"{x:728,y:484,t:1527190013722};\\\", \\\"{x:746,y:487,t:1527190013741};\\\", \\\"{x:765,y:487,t:1527190013756};\\\", \\\"{x:781,y:489,t:1527190013773};\\\", \\\"{x:794,y:497,t:1527190013789};\\\", \\\"{x:801,y:499,t:1527190013806};\\\", \\\"{x:810,y:508,t:1527190013824};\\\", \\\"{x:821,y:518,t:1527190013839};\\\", \\\"{x:830,y:534,t:1527190013857};\\\", \\\"{x:836,y:552,t:1527190013874};\\\", \\\"{x:846,y:573,t:1527190013890};\\\", \\\"{x:854,y:591,t:1527190013907};\\\", \\\"{x:862,y:610,t:1527190013923};\\\", \\\"{x:867,y:631,t:1527190013939};\\\", \\\"{x:876,y:652,t:1527190013956};\\\", \\\"{x:887,y:672,t:1527190013974};\\\", \\\"{x:901,y:692,t:1527190013989};\\\", \\\"{x:910,y:714,t:1527190014006};\\\", \\\"{x:921,y:735,t:1527190014024};\\\", \\\"{x:931,y:755,t:1527190014039};\\\", \\\"{x:943,y:778,t:1527190014056};\\\", \\\"{x:953,y:789,t:1527190014073};\\\", \\\"{x:958,y:801,t:1527190014090};\\\", \\\"{x:972,y:818,t:1527190014106};\\\", \\\"{x:983,y:833,t:1527190014124};\\\", \\\"{x:994,y:851,t:1527190014140};\\\", \\\"{x:1007,y:867,t:1527190014157};\\\", \\\"{x:1023,y:884,t:1527190014174};\\\", \\\"{x:1041,y:901,t:1527190014190};\\\", \\\"{x:1067,y:919,t:1527190014206};\\\", \\\"{x:1086,y:932,t:1527190014224};\\\", \\\"{x:1119,y:952,t:1527190014239};\\\", \\\"{x:1146,y:968,t:1527190014256};\\\", \\\"{x:1171,y:980,t:1527190014273};\\\", \\\"{x:1219,y:999,t:1527190014290};\\\", \\\"{x:1239,y:1007,t:1527190014306};\\\", \\\"{x:1260,y:1011,t:1527190014324};\\\", \\\"{x:1276,y:1017,t:1527190014340};\\\", \\\"{x:1286,y:1020,t:1527190014356};\\\", \\\"{x:1303,y:1026,t:1527190014373};\\\", \\\"{x:1315,y:1027,t:1527190014391};\\\", \\\"{x:1319,y:1028,t:1527190014407};\\\", \\\"{x:1320,y:1028,t:1527190014423};\\\", \\\"{x:1321,y:1028,t:1527190014441};\\\", \\\"{x:1322,y:1028,t:1527190014466};\\\", \\\"{x:1324,y:1026,t:1527190014474};\\\", \\\"{x:1325,y:1024,t:1527190014490};\\\", \\\"{x:1326,y:1019,t:1527190014506};\\\", \\\"{x:1329,y:1015,t:1527190014524};\\\", \\\"{x:1331,y:1011,t:1527190014541};\\\", \\\"{x:1333,y:1009,t:1527190014557};\\\", \\\"{x:1334,y:1007,t:1527190014574};\\\", \\\"{x:1335,y:1006,t:1527190014591};\\\", \\\"{x:1335,y:1005,t:1527190014607};\\\", \\\"{x:1335,y:1002,t:1527190014675};\\\", \\\"{x:1336,y:1001,t:1527190014691};\\\", \\\"{x:1337,y:998,t:1527190014738};\\\", \\\"{x:1339,y:998,t:1527190014755};\\\", \\\"{x:1339,y:997,t:1527190014762};\\\", \\\"{x:1341,y:995,t:1527190014779};\\\", \\\"{x:1342,y:994,t:1527190014791};\\\", \\\"{x:1345,y:991,t:1527190014807};\\\", \\\"{x:1349,y:986,t:1527190014824};\\\", \\\"{x:1352,y:982,t:1527190014841};\\\", \\\"{x:1353,y:980,t:1527190014858};\\\", \\\"{x:1354,y:979,t:1527190014874};\\\", \\\"{x:1354,y:978,t:1527190014891};\\\", \\\"{x:1355,y:977,t:1527190014907};\\\", \\\"{x:1357,y:973,t:1527190014924};\\\", \\\"{x:1358,y:971,t:1527190014941};\\\", \\\"{x:1361,y:967,t:1527190014959};\\\", \\\"{x:1362,y:966,t:1527190014974};\\\", \\\"{x:1362,y:965,t:1527190014991};\\\", \\\"{x:1362,y:964,t:1527190015284};\\\", \\\"{x:1361,y:964,t:1527190015290};\\\", \\\"{x:1360,y:964,t:1527190015308};\\\", \\\"{x:1357,y:964,t:1527190015325};\\\", \\\"{x:1356,y:964,t:1527190015341};\\\", \\\"{x:1355,y:964,t:1527190015401};\\\", \\\"{x:1354,y:964,t:1527190015434};\\\", \\\"{x:1353,y:962,t:1527190015761};\\\", \\\"{x:1353,y:959,t:1527190015777};\\\", \\\"{x:1353,y:957,t:1527190015794};\\\", \\\"{x:1353,y:954,t:1527190015808};\\\", \\\"{x:1353,y:950,t:1527190015825};\\\", \\\"{x:1353,y:947,t:1527190015842};\\\", \\\"{x:1353,y:942,t:1527190015858};\\\", \\\"{x:1353,y:935,t:1527190015875};\\\", \\\"{x:1353,y:931,t:1527190015892};\\\", \\\"{x:1353,y:927,t:1527190015909};\\\", \\\"{x:1356,y:922,t:1527190015925};\\\", \\\"{x:1359,y:916,t:1527190015942};\\\", \\\"{x:1359,y:908,t:1527190015958};\\\", \\\"{x:1358,y:902,t:1527190015975};\\\", \\\"{x:1358,y:900,t:1527190015992};\\\", \\\"{x:1358,y:896,t:1527190016008};\\\", \\\"{x:1359,y:890,t:1527190016025};\\\", \\\"{x:1360,y:887,t:1527190016042};\\\", \\\"{x:1361,y:881,t:1527190016058};\\\", \\\"{x:1361,y:873,t:1527190016075};\\\", \\\"{x:1361,y:867,t:1527190016092};\\\", \\\"{x:1361,y:865,t:1527190016108};\\\", \\\"{x:1361,y:861,t:1527190016125};\\\", \\\"{x:1361,y:857,t:1527190016143};\\\", \\\"{x:1361,y:851,t:1527190016158};\\\", \\\"{x:1360,y:847,t:1527190016175};\\\", \\\"{x:1360,y:842,t:1527190016192};\\\", \\\"{x:1359,y:836,t:1527190016208};\\\", \\\"{x:1357,y:827,t:1527190016225};\\\", \\\"{x:1355,y:820,t:1527190016242};\\\", \\\"{x:1355,y:817,t:1527190016259};\\\", \\\"{x:1355,y:813,t:1527190016275};\\\", \\\"{x:1355,y:812,t:1527190016292};\\\", \\\"{x:1353,y:807,t:1527190016309};\\\", \\\"{x:1353,y:804,t:1527190016325};\\\", \\\"{x:1352,y:802,t:1527190016342};\\\", \\\"{x:1351,y:802,t:1527190016359};\\\", \\\"{x:1351,y:799,t:1527190016375};\\\", \\\"{x:1351,y:796,t:1527190016392};\\\", \\\"{x:1351,y:794,t:1527190016409};\\\", \\\"{x:1350,y:790,t:1527190016426};\\\", \\\"{x:1350,y:788,t:1527190016442};\\\", \\\"{x:1348,y:783,t:1527190016459};\\\", \\\"{x:1348,y:782,t:1527190016475};\\\", \\\"{x:1348,y:779,t:1527190016492};\\\", \\\"{x:1348,y:778,t:1527190016509};\\\", \\\"{x:1348,y:776,t:1527190016525};\\\", \\\"{x:1348,y:774,t:1527190016542};\\\", \\\"{x:1348,y:772,t:1527190016559};\\\", \\\"{x:1347,y:768,t:1527190016578};\\\", \\\"{x:1347,y:766,t:1527190016591};\\\", \\\"{x:1347,y:765,t:1527190016610};\\\", \\\"{x:1346,y:762,t:1527190016625};\\\", \\\"{x:1346,y:760,t:1527190016650};\\\", \\\"{x:1346,y:759,t:1527190016658};\\\", \\\"{x:1345,y:758,t:1527190016675};\\\", \\\"{x:1344,y:757,t:1527190016692};\\\", \\\"{x:1344,y:755,t:1527190016709};\\\", \\\"{x:1344,y:754,t:1527190016725};\\\", \\\"{x:1344,y:752,t:1527190016742};\\\", \\\"{x:1343,y:749,t:1527190016758};\\\", \\\"{x:1343,y:747,t:1527190016776};\\\", \\\"{x:1343,y:743,t:1527190016792};\\\", \\\"{x:1342,y:738,t:1527190016809};\\\", \\\"{x:1342,y:731,t:1527190016826};\\\", \\\"{x:1342,y:729,t:1527190016842};\\\", \\\"{x:1341,y:727,t:1527190016858};\\\", \\\"{x:1341,y:724,t:1527190016876};\\\", \\\"{x:1341,y:723,t:1527190016893};\\\", \\\"{x:1341,y:719,t:1527190016909};\\\", \\\"{x:1341,y:718,t:1527190016926};\\\", \\\"{x:1341,y:717,t:1527190016942};\\\", \\\"{x:1341,y:716,t:1527190016959};\\\", \\\"{x:1341,y:714,t:1527190016976};\\\", \\\"{x:1341,y:713,t:1527190016993};\\\", \\\"{x:1341,y:711,t:1527190017010};\\\", \\\"{x:1341,y:709,t:1527190017026};\\\", \\\"{x:1341,y:708,t:1527190017042};\\\", \\\"{x:1341,y:706,t:1527190017058};\\\", \\\"{x:1341,y:705,t:1527190017075};\\\", \\\"{x:1342,y:702,t:1527190017091};\\\", \\\"{x:1342,y:700,t:1527190017109};\\\", \\\"{x:1343,y:695,t:1527190017125};\\\", \\\"{x:1344,y:693,t:1527190017142};\\\", \\\"{x:1344,y:692,t:1527190017162};\\\", \\\"{x:1344,y:691,t:1527190017227};\\\", \\\"{x:1344,y:690,t:1527190017587};\\\", \\\"{x:1341,y:687,t:1527190017595};\\\", \\\"{x:1331,y:684,t:1527190017609};\\\", \\\"{x:1311,y:677,t:1527190017626};\\\", \\\"{x:1272,y:669,t:1527190017642};\\\", \\\"{x:1211,y:653,t:1527190017659};\\\", \\\"{x:1146,y:630,t:1527190017676};\\\", \\\"{x:1086,y:618,t:1527190017693};\\\", \\\"{x:1018,y:604,t:1527190017710};\\\", \\\"{x:944,y:588,t:1527190017727};\\\", \\\"{x:853,y:577,t:1527190017743};\\\", \\\"{x:797,y:569,t:1527190017760};\\\", \\\"{x:721,y:565,t:1527190017776};\\\", \\\"{x:646,y:558,t:1527190017793};\\\", \\\"{x:589,y:551,t:1527190017810};\\\", \\\"{x:556,y:545,t:1527190017826};\\\", \\\"{x:495,y:545,t:1527190017842};\\\", \\\"{x:439,y:545,t:1527190017859};\\\", \\\"{x:384,y:545,t:1527190017877};\\\", \\\"{x:336,y:544,t:1527190017892};\\\", \\\"{x:284,y:539,t:1527190017910};\\\", \\\"{x:252,y:539,t:1527190017927};\\\", \\\"{x:239,y:537,t:1527190017942};\\\", \\\"{x:231,y:537,t:1527190017959};\\\", \\\"{x:229,y:537,t:1527190017977};\\\", \\\"{x:229,y:536,t:1527190018066};\\\", \\\"{x:229,y:535,t:1527190018090};\\\", \\\"{x:229,y:533,t:1527190018147};\\\", \\\"{x:232,y:531,t:1527190018160};\\\", \\\"{x:246,y:528,t:1527190018176};\\\", \\\"{x:255,y:526,t:1527190018192};\\\", \\\"{x:278,y:523,t:1527190018210};\\\", \\\"{x:285,y:523,t:1527190018225};\\\", \\\"{x:295,y:521,t:1527190018244};\\\", \\\"{x:305,y:521,t:1527190018260};\\\", \\\"{x:311,y:521,t:1527190018277};\\\", \\\"{x:313,y:521,t:1527190018294};\\\", \\\"{x:317,y:521,t:1527190018310};\\\", \\\"{x:322,y:521,t:1527190018327};\\\", \\\"{x:326,y:522,t:1527190018343};\\\", \\\"{x:331,y:524,t:1527190018361};\\\", \\\"{x:338,y:525,t:1527190018378};\\\", \\\"{x:346,y:529,t:1527190018394};\\\", \\\"{x:356,y:532,t:1527190018410};\\\", \\\"{x:382,y:536,t:1527190018428};\\\", \\\"{x:405,y:539,t:1527190018444};\\\", \\\"{x:431,y:545,t:1527190018460};\\\", \\\"{x:452,y:549,t:1527190018477};\\\", \\\"{x:474,y:553,t:1527190018494};\\\", \\\"{x:486,y:555,t:1527190018511};\\\", \\\"{x:502,y:556,t:1527190018528};\\\", \\\"{x:526,y:560,t:1527190018543};\\\", \\\"{x:545,y:563,t:1527190018562};\\\", \\\"{x:563,y:564,t:1527190018577};\\\", \\\"{x:583,y:565,t:1527190018594};\\\", \\\"{x:584,y:565,t:1527190018609};\\\", \\\"{x:586,y:564,t:1527190018627};\\\", \\\"{x:587,y:564,t:1527190018675};\\\", \\\"{x:588,y:563,t:1527190018683};\\\", \\\"{x:588,y:562,t:1527190018695};\\\", \\\"{x:591,y:560,t:1527190018710};\\\", \\\"{x:592,y:557,t:1527190018727};\\\", \\\"{x:595,y:554,t:1527190018745};\\\", \\\"{x:596,y:552,t:1527190018761};\\\", \\\"{x:597,y:551,t:1527190018810};\\\", \\\"{x:598,y:548,t:1527190018826};\\\", \\\"{x:600,y:545,t:1527190018844};\\\", \\\"{x:601,y:544,t:1527190018860};\\\", \\\"{x:603,y:540,t:1527190018876};\\\", \\\"{x:604,y:538,t:1527190018894};\\\", \\\"{x:600,y:538,t:1527190019003};\\\", \\\"{x:594,y:540,t:1527190019011};\\\", \\\"{x:584,y:543,t:1527190019026};\\\", \\\"{x:579,y:543,t:1527190019044};\\\", \\\"{x:575,y:546,t:1527190019061};\\\", \\\"{x:564,y:547,t:1527190019078};\\\", \\\"{x:556,y:547,t:1527190019094};\\\", \\\"{x:545,y:550,t:1527190019111};\\\", \\\"{x:533,y:552,t:1527190019128};\\\", \\\"{x:509,y:556,t:1527190019145};\\\", \\\"{x:492,y:557,t:1527190019160};\\\", \\\"{x:466,y:557,t:1527190019178};\\\", \\\"{x:453,y:557,t:1527190019194};\\\", \\\"{x:419,y:557,t:1527190019211};\\\", \\\"{x:394,y:557,t:1527190019228};\\\", \\\"{x:367,y:559,t:1527190019244};\\\", \\\"{x:341,y:562,t:1527190019261};\\\", \\\"{x:305,y:568,t:1527190019279};\\\", \\\"{x:267,y:571,t:1527190019295};\\\", \\\"{x:244,y:571,t:1527190019310};\\\", \\\"{x:222,y:571,t:1527190019328};\\\", \\\"{x:197,y:571,t:1527190019344};\\\", \\\"{x:176,y:571,t:1527190019361};\\\", \\\"{x:159,y:571,t:1527190019377};\\\", \\\"{x:150,y:571,t:1527190019393};\\\", \\\"{x:144,y:571,t:1527190019410};\\\", \\\"{x:140,y:571,t:1527190019427};\\\", \\\"{x:135,y:571,t:1527190019444};\\\", \\\"{x:132,y:571,t:1527190019461};\\\", \\\"{x:128,y:571,t:1527190019478};\\\", \\\"{x:126,y:571,t:1527190019494};\\\", \\\"{x:125,y:571,t:1527190019522};\\\", \\\"{x:123,y:570,t:1527190019538};\\\", \\\"{x:119,y:568,t:1527190019554};\\\", \\\"{x:118,y:567,t:1527190019562};\\\", \\\"{x:117,y:565,t:1527190019578};\\\", \\\"{x:117,y:563,t:1527190019594};\\\", \\\"{x:117,y:561,t:1527190019612};\\\", \\\"{x:117,y:560,t:1527190019628};\\\", \\\"{x:117,y:558,t:1527190019644};\\\", \\\"{x:117,y:557,t:1527190019662};\\\", \\\"{x:118,y:556,t:1527190019678};\\\", \\\"{x:118,y:554,t:1527190019695};\\\", \\\"{x:119,y:554,t:1527190019730};\\\", \\\"{x:121,y:554,t:1527190019745};\\\", \\\"{x:126,y:552,t:1527190019760};\\\", \\\"{x:136,y:550,t:1527190019778};\\\", \\\"{x:139,y:548,t:1527190019794};\\\", \\\"{x:140,y:548,t:1527190019827};\\\", \\\"{x:141,y:547,t:1527190019859};\\\", \\\"{x:142,y:546,t:1527190019931};\\\", \\\"{x:144,y:546,t:1527190021030};\\\", \\\"{x:146,y:546,t:1527190021037};\\\", \\\"{x:147,y:546,t:1527190021061};\\\", \\\"{x:148,y:546,t:1527190021070};\\\", \\\"{x:149,y:546,t:1527190021081};\\\", \\\"{x:150,y:546,t:1527190021098};\\\", \\\"{x:151,y:546,t:1527190021117};\\\", \\\"{x:153,y:546,t:1527190021526};\\\", \\\"{x:154,y:546,t:1527190021534};\\\", \\\"{x:156,y:551,t:1527190021549};\\\", \\\"{x:159,y:556,t:1527190021567};\\\", \\\"{x:161,y:561,t:1527190021584};\\\", \\\"{x:162,y:564,t:1527190021600};\\\", \\\"{x:164,y:565,t:1527190021617};\\\", \\\"{x:165,y:569,t:1527190021633};\\\", \\\"{x:167,y:571,t:1527190021649};\\\", \\\"{x:169,y:577,t:1527190021667};\\\", \\\"{x:172,y:583,t:1527190021683};\\\", \\\"{x:177,y:589,t:1527190021700};\\\", \\\"{x:181,y:596,t:1527190021717};\\\", \\\"{x:187,y:606,t:1527190021734};\\\", \\\"{x:191,y:612,t:1527190021748};\\\", \\\"{x:198,y:620,t:1527190021766};\\\", \\\"{x:201,y:625,t:1527190021783};\\\", \\\"{x:208,y:631,t:1527190021799};\\\", \\\"{x:210,y:633,t:1527190021816};\\\", \\\"{x:212,y:635,t:1527190021833};\\\", \\\"{x:214,y:636,t:1527190021849};\\\", \\\"{x:216,y:638,t:1527190021866};\\\", \\\"{x:222,y:641,t:1527190021884};\\\", \\\"{x:229,y:643,t:1527190021899};\\\", \\\"{x:234,y:644,t:1527190021916};\\\", \\\"{x:246,y:647,t:1527190021933};\\\", \\\"{x:258,y:648,t:1527190021949};\\\", \\\"{x:271,y:648,t:1527190021967};\\\", \\\"{x:283,y:649,t:1527190021984};\\\", \\\"{x:292,y:649,t:1527190022000};\\\", \\\"{x:298,y:649,t:1527190022016};\\\", \\\"{x:304,y:649,t:1527190022033};\\\", \\\"{x:306,y:649,t:1527190022050};\\\", \\\"{x:309,y:651,t:1527190022066};\\\", \\\"{x:310,y:651,t:1527190022083};\\\", \\\"{x:312,y:651,t:1527190022109};\\\", \\\"{x:313,y:651,t:1527190022117};\\\", \\\"{x:314,y:652,t:1527190022134};\\\", \\\"{x:315,y:652,t:1527190022158};\\\", \\\"{x:317,y:652,t:1527190022166};\\\", \\\"{x:318,y:652,t:1527190022183};\\\", \\\"{x:322,y:653,t:1527190022201};\\\", \\\"{x:325,y:654,t:1527190022217};\\\", \\\"{x:327,y:654,t:1527190022233};\\\", \\\"{x:332,y:653,t:1527190022250};\\\", \\\"{x:336,y:653,t:1527190022267};\\\", \\\"{x:342,y:653,t:1527190022283};\\\", \\\"{x:347,y:653,t:1527190022300};\\\", \\\"{x:354,y:651,t:1527190022316};\\\", \\\"{x:365,y:647,t:1527190022333};\\\", \\\"{x:371,y:646,t:1527190022350};\\\", \\\"{x:378,y:645,t:1527190022367};\\\", \\\"{x:384,y:642,t:1527190022383};\\\", \\\"{x:394,y:642,t:1527190022400};\\\", \\\"{x:405,y:642,t:1527190022416};\\\", \\\"{x:415,y:640,t:1527190022433};\\\", \\\"{x:422,y:640,t:1527190022450};\\\", \\\"{x:431,y:637,t:1527190022466};\\\", \\\"{x:444,y:632,t:1527190022483};\\\", \\\"{x:458,y:631,t:1527190022500};\\\", \\\"{x:484,y:628,t:1527190022516};\\\", \\\"{x:505,y:623,t:1527190022533};\\\", \\\"{x:523,y:621,t:1527190022550};\\\", \\\"{x:543,y:620,t:1527190022567};\\\", \\\"{x:563,y:616,t:1527190022583};\\\", \\\"{x:577,y:615,t:1527190022601};\\\", \\\"{x:601,y:611,t:1527190022617};\\\", \\\"{x:624,y:610,t:1527190022633};\\\", \\\"{x:642,y:609,t:1527190022650};\\\", \\\"{x:646,y:608,t:1527190022668};\\\", \\\"{x:652,y:606,t:1527190022683};\\\", \\\"{x:657,y:606,t:1527190022701};\\\", \\\"{x:661,y:605,t:1527190022717};\\\", \\\"{x:665,y:605,t:1527190022733};\\\", \\\"{x:670,y:602,t:1527190022751};\\\", \\\"{x:676,y:598,t:1527190022768};\\\", \\\"{x:692,y:593,t:1527190022784};\\\", \\\"{x:706,y:589,t:1527190022801};\\\", \\\"{x:726,y:584,t:1527190022817};\\\", \\\"{x:734,y:579,t:1527190022834};\\\", \\\"{x:742,y:575,t:1527190022850};\\\", \\\"{x:748,y:571,t:1527190022867};\\\", \\\"{x:751,y:566,t:1527190022883};\\\", \\\"{x:754,y:561,t:1527190022901};\\\", \\\"{x:760,y:553,t:1527190022918};\\\", \\\"{x:764,y:549,t:1527190022935};\\\", \\\"{x:770,y:543,t:1527190022951};\\\", \\\"{x:776,y:536,t:1527190022967};\\\", \\\"{x:780,y:530,t:1527190022983};\\\", \\\"{x:783,y:527,t:1527190023001};\\\", \\\"{x:785,y:524,t:1527190023018};\\\", \\\"{x:789,y:517,t:1527190023034};\\\", \\\"{x:795,y:510,t:1527190023051};\\\", \\\"{x:799,y:505,t:1527190023067};\\\", \\\"{x:800,y:505,t:1527190023166};\\\", \\\"{x:801,y:505,t:1527190023174};\\\", \\\"{x:802,y:505,t:1527190023185};\\\", \\\"{x:804,y:505,t:1527190023202};\\\", \\\"{x:805,y:505,t:1527190023219};\\\", \\\"{x:807,y:506,t:1527190023234};\\\", \\\"{x:809,y:507,t:1527190023251};\\\", \\\"{x:810,y:509,t:1527190023268};\\\", \\\"{x:811,y:509,t:1527190023286};\\\", \\\"{x:813,y:509,t:1527190023301};\\\", \\\"{x:815,y:509,t:1527190023318};\\\", \\\"{x:816,y:509,t:1527190023357};\\\", \\\"{x:817,y:509,t:1527190023406};\\\", \\\"{x:817,y:510,t:1527190023702};\\\", \\\"{x:817,y:511,t:1527190023718};\\\", \\\"{x:817,y:513,t:1527190023735};\\\", \\\"{x:814,y:519,t:1527190023753};\\\", \\\"{x:810,y:524,t:1527190023769};\\\", \\\"{x:809,y:525,t:1527190023786};\\\", \\\"{x:809,y:524,t:1527190023903};\\\", \\\"{x:813,y:521,t:1527190023918};\\\", \\\"{x:814,y:518,t:1527190023934};\\\", \\\"{x:818,y:515,t:1527190023952};\\\", \\\"{x:820,y:514,t:1527190023968};\\\", \\\"{x:821,y:514,t:1527190023985};\\\", \\\"{x:822,y:514,t:1527190024005};\\\", \\\"{x:822,y:513,t:1527190024019};\\\", \\\"{x:823,y:511,t:1527190024034};\\\", \\\"{x:823,y:510,t:1527190024053};\\\", \\\"{x:824,y:509,t:1527190024068};\\\", \\\"{x:825,y:508,t:1527190024084};\\\", \\\"{x:822,y:515,t:1527190024295};\\\", \\\"{x:816,y:523,t:1527190024303};\\\", \\\"{x:803,y:538,t:1527190024318};\\\", \\\"{x:792,y:557,t:1527190024335};\\\", \\\"{x:774,y:575,t:1527190024351};\\\", \\\"{x:757,y:592,t:1527190024368};\\\", \\\"{x:740,y:610,t:1527190024385};\\\", \\\"{x:717,y:629,t:1527190024402};\\\", \\\"{x:678,y:659,t:1527190024418};\\\", \\\"{x:639,y:686,t:1527190024435};\\\", \\\"{x:614,y:706,t:1527190024451};\\\", \\\"{x:598,y:716,t:1527190024468};\\\", \\\"{x:586,y:726,t:1527190024485};\\\", \\\"{x:577,y:729,t:1527190024502};\\\", \\\"{x:561,y:735,t:1527190024519};\\\", \\\"{x:550,y:742,t:1527190024535};\\\", \\\"{x:546,y:745,t:1527190024552};\\\", \\\"{x:542,y:746,t:1527190024568};\\\", \\\"{x:541,y:746,t:1527190024585};\\\", \\\"{x:540,y:746,t:1527190024621};\\\", \\\"{x:539,y:744,t:1527190024645};\\\", \\\"{x:540,y:734,t:1527190024653};\\\", \\\"{x:546,y:727,t:1527190024668};\\\", \\\"{x:569,y:692,t:1527190024686};\\\", \\\"{x:589,y:662,t:1527190024702};\\\", \\\"{x:619,y:634,t:1527190024718};\\\", \\\"{x:641,y:610,t:1527190024735};\\\", \\\"{x:666,y:589,t:1527190024753};\\\", \\\"{x:687,y:571,t:1527190024768};\\\", \\\"{x:701,y:560,t:1527190024786};\\\", \\\"{x:710,y:550,t:1527190024803};\\\", \\\"{x:729,y:542,t:1527190024819};\\\", \\\"{x:750,y:536,t:1527190024835};\\\", \\\"{x:764,y:531,t:1527190024853};\\\", \\\"{x:781,y:526,t:1527190024868};\\\", \\\"{x:795,y:520,t:1527190024886};\\\", \\\"{x:799,y:519,t:1527190024903};\\\", \\\"{x:802,y:517,t:1527190024918};\\\", \\\"{x:803,y:517,t:1527190024935};\\\", \\\"{x:810,y:517,t:1527190024952};\\\", \\\"{x:815,y:517,t:1527190024968};\\\", \\\"{x:822,y:518,t:1527190024987};\\\", \\\"{x:823,y:518,t:1527190025003};\\\", \\\"{x:824,y:519,t:1527190025019};\\\", \\\"{x:825,y:518,t:1527190025086};\\\", \\\"{x:827,y:516,t:1527190025103};\\\", \\\"{x:829,y:514,t:1527190025120};\\\", \\\"{x:832,y:512,t:1527190025136};\\\", \\\"{x:833,y:507,t:1527190025153};\\\", \\\"{x:833,y:506,t:1527190025169};\\\", \\\"{x:836,y:504,t:1527190025185};\\\", \\\"{x:836,y:503,t:1527190025202};\\\", \\\"{x:837,y:499,t:1527190025219};\\\", \\\"{x:837,y:498,t:1527190025469};\\\", \\\"{x:829,y:509,t:1527190025485};\\\", \\\"{x:820,y:527,t:1527190025503};\\\", \\\"{x:808,y:552,t:1527190025519};\\\", \\\"{x:794,y:578,t:1527190025536};\\\", \\\"{x:783,y:603,t:1527190025553};\\\", \\\"{x:770,y:625,t:1527190025569};\\\", \\\"{x:751,y:645,t:1527190025587};\\\", \\\"{x:721,y:673,t:1527190025602};\\\", \\\"{x:672,y:702,t:1527190025619};\\\", \\\"{x:624,y:725,t:1527190025636};\\\", \\\"{x:587,y:743,t:1527190025653};\\\", \\\"{x:550,y:758,t:1527190025670};\\\", \\\"{x:525,y:761,t:1527190025686};\\\", \\\"{x:500,y:766,t:1527190025702};\\\", \\\"{x:481,y:769,t:1527190025720};\\\", \\\"{x:469,y:769,t:1527190025736};\\\", \\\"{x:461,y:769,t:1527190025753};\\\", \\\"{x:457,y:766,t:1527190025769};\\\", \\\"{x:455,y:765,t:1527190025785};\\\", \\\"{x:453,y:762,t:1527190025803};\\\", \\\"{x:451,y:759,t:1527190025821};\\\", \\\"{x:450,y:756,t:1527190025837};\\\", \\\"{x:450,y:750,t:1527190025854};\\\", \\\"{x:450,y:738,t:1527190025870};\\\", \\\"{x:450,y:731,t:1527190025887};\\\", \\\"{x:450,y:725,t:1527190025903};\\\", \\\"{x:451,y:722,t:1527190025920};\\\", \\\"{x:453,y:722,t:1527190026334};\\\", \\\"{x:455,y:722,t:1527190026349};\\\", \\\"{x:456,y:722,t:1527190026357};\\\", \\\"{x:458,y:722,t:1527190026370};\\\", \\\"{x:458,y:723,t:1527190026386};\\\", \\\"{x:459,y:723,t:1527190026404};\\\", \\\"{x:461,y:723,t:1527190026420};\\\", \\\"{x:461,y:724,t:1527190026436};\\\", \\\"{x:464,y:725,t:1527190026453};\\\", \\\"{x:465,y:726,t:1527190026469};\\\", \\\"{x:466,y:726,t:1527190026487};\\\", \\\"{x:470,y:728,t:1527190026504};\\\", \\\"{x:477,y:731,t:1527190026521};\\\", \\\"{x:490,y:735,t:1527190026536};\\\", \\\"{x:505,y:740,t:1527190026554};\\\", \\\"{x:524,y:748,t:1527190026571};\\\", \\\"{x:545,y:755,t:1527190026586};\\\", \\\"{x:561,y:761,t:1527190026604};\\\", \\\"{x:589,y:769,t:1527190026621};\\\", \\\"{x:607,y:782,t:1527190026637};\\\", \\\"{x:642,y:796,t:1527190026654};\\\", \\\"{x:664,y:809,t:1527190026670};\\\", \\\"{x:682,y:823,t:1527190026686};\\\", \\\"{x:694,y:841,t:1527190026704};\\\", \\\"{x:701,y:854,t:1527190026721};\\\", \\\"{x:702,y:871,t:1527190026737};\\\", \\\"{x:704,y:896,t:1527190026754};\\\", \\\"{x:707,y:925,t:1527190026771};\\\", \\\"{x:705,y:962,t:1527190026787};\\\", \\\"{x:704,y:984,t:1527190026804};\\\", \\\"{x:704,y:999,t:1527190026821};\\\", \\\"{x:704,y:1003,t:1527190026836};\\\", \\\"{x:702,y:1006,t:1527190026854};\\\" ] }, { \\\"rt\\\": 10223, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 616988, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"F98S2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 AM-02 PM-01 PM-F -M -B -B -3\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:703,y:1003,t:1527190029254};\\\", \\\"{x:797,y:828,t:1527190029287};\\\", \\\"{x:818,y:789,t:1527190029292};\\\", \\\"{x:837,y:764,t:1527190029305};\\\", \\\"{x:856,y:736,t:1527190029323};\\\", \\\"{x:877,y:712,t:1527190029338};\\\", \\\"{x:894,y:687,t:1527190029356};\\\", \\\"{x:908,y:669,t:1527190029372};\\\", \\\"{x:918,y:654,t:1527190029389};\\\", \\\"{x:923,y:646,t:1527190029405};\\\", \\\"{x:923,y:644,t:1527190029422};\\\", \\\"{x:925,y:640,t:1527190029438};\\\", \\\"{x:927,y:634,t:1527190029456};\\\", \\\"{x:930,y:629,t:1527190029473};\\\", \\\"{x:930,y:623,t:1527190029488};\\\", \\\"{x:930,y:616,t:1527190029505};\\\", \\\"{x:930,y:612,t:1527190029522};\\\", \\\"{x:929,y:608,t:1527190029539};\\\", \\\"{x:925,y:600,t:1527190029556};\\\", \\\"{x:924,y:596,t:1527190029573};\\\", \\\"{x:918,y:588,t:1527190029589};\\\", \\\"{x:915,y:581,t:1527190029605};\\\", \\\"{x:909,y:575,t:1527190029622};\\\", \\\"{x:905,y:570,t:1527190029639};\\\", \\\"{x:903,y:566,t:1527190029655};\\\", \\\"{x:900,y:564,t:1527190029672};\\\", \\\"{x:896,y:561,t:1527190029691};\\\", \\\"{x:893,y:558,t:1527190029705};\\\", \\\"{x:890,y:555,t:1527190029723};\\\", \\\"{x:889,y:555,t:1527190029772};\\\", \\\"{x:889,y:556,t:1527190029943};\\\", \\\"{x:889,y:559,t:1527190029957};\\\", \\\"{x:889,y:569,t:1527190029973};\\\", \\\"{x:889,y:584,t:1527190029990};\\\", \\\"{x:891,y:601,t:1527190030007};\\\", \\\"{x:898,y:624,t:1527190030022};\\\", \\\"{x:908,y:651,t:1527190030040};\\\", \\\"{x:926,y:674,t:1527190030057};\\\", \\\"{x:944,y:709,t:1527190030073};\\\", \\\"{x:978,y:759,t:1527190030089};\\\", \\\"{x:1011,y:818,t:1527190030107};\\\", \\\"{x:1041,y:875,t:1527190030123};\\\", \\\"{x:1067,y:919,t:1527190030139};\\\", \\\"{x:1081,y:938,t:1527190030157};\\\", \\\"{x:1086,y:951,t:1527190030173};\\\", \\\"{x:1089,y:964,t:1527190030190};\\\", \\\"{x:1092,y:977,t:1527190030207};\\\", \\\"{x:1101,y:987,t:1527190030224};\\\", \\\"{x:1121,y:996,t:1527190030240};\\\", \\\"{x:1157,y:1003,t:1527190030257};\\\", \\\"{x:1234,y:1012,t:1527190030273};\\\", \\\"{x:1328,y:1022,t:1527190030290};\\\", \\\"{x:1386,y:1024,t:1527190030306};\\\", \\\"{x:1453,y:1024,t:1527190030323};\\\", \\\"{x:1471,y:1016,t:1527190030340};\\\", \\\"{x:1485,y:1006,t:1527190030357};\\\", \\\"{x:1489,y:1004,t:1527190030373};\\\", \\\"{x:1497,y:995,t:1527190030390};\\\", \\\"{x:1499,y:992,t:1527190030407};\\\", \\\"{x:1499,y:987,t:1527190030425};\\\", \\\"{x:1495,y:983,t:1527190030440};\\\", \\\"{x:1491,y:981,t:1527190030457};\\\", \\\"{x:1490,y:981,t:1527190030475};\\\", \\\"{x:1487,y:981,t:1527190030599};\\\", \\\"{x:1485,y:981,t:1527190030741};\\\", \\\"{x:1484,y:981,t:1527190030757};\\\", \\\"{x:1482,y:981,t:1527190030774};\\\", \\\"{x:1480,y:981,t:1527190030791};\\\", \\\"{x:1475,y:982,t:1527190030807};\\\", \\\"{x:1471,y:985,t:1527190030824};\\\", \\\"{x:1469,y:985,t:1527190030840};\\\", \\\"{x:1465,y:986,t:1527190030856};\\\", \\\"{x:1464,y:986,t:1527190030874};\\\", \\\"{x:1462,y:986,t:1527190030891};\\\", \\\"{x:1461,y:986,t:1527190030907};\\\", \\\"{x:1457,y:985,t:1527190030924};\\\", \\\"{x:1448,y:982,t:1527190030941};\\\", \\\"{x:1439,y:979,t:1527190030957};\\\", \\\"{x:1425,y:972,t:1527190030973};\\\", \\\"{x:1405,y:966,t:1527190030992};\\\", \\\"{x:1385,y:959,t:1527190031007};\\\", \\\"{x:1372,y:952,t:1527190031024};\\\", \\\"{x:1359,y:942,t:1527190031040};\\\", \\\"{x:1352,y:937,t:1527190031056};\\\", \\\"{x:1346,y:930,t:1527190031074};\\\", \\\"{x:1344,y:921,t:1527190031091};\\\", \\\"{x:1343,y:896,t:1527190031106};\\\", \\\"{x:1343,y:871,t:1527190031124};\\\", \\\"{x:1349,y:850,t:1527190031141};\\\", \\\"{x:1355,y:818,t:1527190031158};\\\", \\\"{x:1361,y:795,t:1527190031174};\\\", \\\"{x:1368,y:776,t:1527190031191};\\\", \\\"{x:1375,y:759,t:1527190031208};\\\", \\\"{x:1381,y:746,t:1527190031224};\\\", \\\"{x:1382,y:740,t:1527190031241};\\\", \\\"{x:1385,y:736,t:1527190031258};\\\", \\\"{x:1386,y:732,t:1527190031274};\\\", \\\"{x:1389,y:728,t:1527190031291};\\\", \\\"{x:1390,y:726,t:1527190031308};\\\", \\\"{x:1392,y:721,t:1527190031324};\\\", \\\"{x:1393,y:720,t:1527190031341};\\\", \\\"{x:1394,y:719,t:1527190031358};\\\", \\\"{x:1395,y:718,t:1527190031406};\\\", \\\"{x:1396,y:717,t:1527190031422};\\\", \\\"{x:1398,y:715,t:1527190031430};\\\", \\\"{x:1398,y:713,t:1527190031462};\\\", \\\"{x:1397,y:713,t:1527190031662};\\\", \\\"{x:1394,y:713,t:1527190031675};\\\", \\\"{x:1386,y:712,t:1527190031691};\\\", \\\"{x:1377,y:709,t:1527190031708};\\\", \\\"{x:1372,y:708,t:1527190031725};\\\", \\\"{x:1366,y:707,t:1527190031741};\\\", \\\"{x:1364,y:705,t:1527190031758};\\\", \\\"{x:1362,y:703,t:1527190031775};\\\", \\\"{x:1360,y:701,t:1527190031791};\\\", \\\"{x:1358,y:700,t:1527190031809};\\\", \\\"{x:1356,y:699,t:1527190031825};\\\", \\\"{x:1355,y:697,t:1527190031841};\\\", \\\"{x:1354,y:697,t:1527190031903};\\\", \\\"{x:1354,y:696,t:1527190031926};\\\", \\\"{x:1354,y:695,t:1527190032015};\\\", \\\"{x:1352,y:695,t:1527190032040};\\\", \\\"{x:1350,y:697,t:1527190032057};\\\", \\\"{x:1349,y:700,t:1527190032075};\\\", \\\"{x:1348,y:702,t:1527190032092};\\\", \\\"{x:1346,y:706,t:1527190032108};\\\", \\\"{x:1344,y:712,t:1527190032125};\\\", \\\"{x:1343,y:718,t:1527190032141};\\\", \\\"{x:1342,y:721,t:1527190032157};\\\", \\\"{x:1342,y:722,t:1527190032174};\\\", \\\"{x:1341,y:722,t:1527190032205};\\\", \\\"{x:1340,y:724,t:1527190032213};\\\", \\\"{x:1340,y:725,t:1527190032224};\\\", \\\"{x:1340,y:727,t:1527190032241};\\\", \\\"{x:1340,y:729,t:1527190032257};\\\", \\\"{x:1340,y:731,t:1527190032275};\\\", \\\"{x:1340,y:733,t:1527190032292};\\\", \\\"{x:1339,y:735,t:1527190032308};\\\", \\\"{x:1339,y:739,t:1527190032325};\\\", \\\"{x:1339,y:743,t:1527190032342};\\\", \\\"{x:1339,y:746,t:1527190032358};\\\", \\\"{x:1337,y:749,t:1527190032375};\\\", \\\"{x:1337,y:751,t:1527190032392};\\\", \\\"{x:1337,y:753,t:1527190032408};\\\", \\\"{x:1338,y:755,t:1527190032425};\\\", \\\"{x:1339,y:757,t:1527190032443};\\\", \\\"{x:1340,y:759,t:1527190032458};\\\", \\\"{x:1341,y:760,t:1527190032494};\\\", \\\"{x:1341,y:762,t:1527190032508};\\\", \\\"{x:1341,y:764,t:1527190032525};\\\", \\\"{x:1344,y:770,t:1527190032542};\\\", \\\"{x:1344,y:773,t:1527190032560};\\\", \\\"{x:1345,y:777,t:1527190032575};\\\", \\\"{x:1347,y:780,t:1527190032593};\\\", \\\"{x:1348,y:783,t:1527190032610};\\\", \\\"{x:1349,y:786,t:1527190032625};\\\", \\\"{x:1351,y:789,t:1527190032643};\\\", \\\"{x:1352,y:791,t:1527190032659};\\\", \\\"{x:1354,y:796,t:1527190032675};\\\", \\\"{x:1355,y:800,t:1527190032692};\\\", \\\"{x:1357,y:808,t:1527190032709};\\\", \\\"{x:1360,y:814,t:1527190032725};\\\", \\\"{x:1364,y:825,t:1527190032742};\\\", \\\"{x:1368,y:837,t:1527190032759};\\\", \\\"{x:1369,y:839,t:1527190032775};\\\", \\\"{x:1370,y:844,t:1527190032792};\\\", \\\"{x:1370,y:848,t:1527190032809};\\\", \\\"{x:1372,y:856,t:1527190032825};\\\", \\\"{x:1372,y:867,t:1527190032842};\\\", \\\"{x:1372,y:872,t:1527190032860};\\\", \\\"{x:1373,y:879,t:1527190032875};\\\", \\\"{x:1373,y:885,t:1527190032892};\\\", \\\"{x:1373,y:890,t:1527190032909};\\\", \\\"{x:1373,y:899,t:1527190032926};\\\", \\\"{x:1373,y:906,t:1527190032942};\\\", \\\"{x:1371,y:920,t:1527190032959};\\\", \\\"{x:1367,y:936,t:1527190032976};\\\", \\\"{x:1366,y:946,t:1527190032992};\\\", \\\"{x:1365,y:952,t:1527190033009};\\\", \\\"{x:1365,y:955,t:1527190033027};\\\", \\\"{x:1365,y:959,t:1527190033043};\\\", \\\"{x:1363,y:963,t:1527190033059};\\\", \\\"{x:1362,y:964,t:1527190033076};\\\", \\\"{x:1362,y:966,t:1527190033093};\\\", \\\"{x:1361,y:968,t:1527190033109};\\\", \\\"{x:1360,y:968,t:1527190033142};\\\", \\\"{x:1360,y:963,t:1527190033247};\\\", \\\"{x:1365,y:951,t:1527190033259};\\\", \\\"{x:1369,y:927,t:1527190033276};\\\", \\\"{x:1375,y:904,t:1527190033293};\\\", \\\"{x:1382,y:878,t:1527190033310};\\\", \\\"{x:1383,y:866,t:1527190033326};\\\", \\\"{x:1385,y:857,t:1527190033344};\\\", \\\"{x:1385,y:850,t:1527190033360};\\\", \\\"{x:1385,y:837,t:1527190033377};\\\", \\\"{x:1385,y:828,t:1527190033394};\\\", \\\"{x:1388,y:819,t:1527190033410};\\\", \\\"{x:1388,y:806,t:1527190033426};\\\", \\\"{x:1390,y:797,t:1527190033443};\\\", \\\"{x:1390,y:788,t:1527190033459};\\\", \\\"{x:1391,y:781,t:1527190033477};\\\", \\\"{x:1391,y:774,t:1527190033493};\\\", \\\"{x:1391,y:767,t:1527190033509};\\\", \\\"{x:1392,y:754,t:1527190033526};\\\", \\\"{x:1392,y:739,t:1527190033544};\\\", \\\"{x:1392,y:728,t:1527190033559};\\\", \\\"{x:1392,y:714,t:1527190033576};\\\", \\\"{x:1392,y:706,t:1527190033594};\\\", \\\"{x:1392,y:702,t:1527190033610};\\\", \\\"{x:1392,y:695,t:1527190033627};\\\", \\\"{x:1392,y:688,t:1527190033644};\\\", \\\"{x:1392,y:682,t:1527190033660};\\\", \\\"{x:1390,y:672,t:1527190033677};\\\", \\\"{x:1390,y:666,t:1527190033693};\\\", \\\"{x:1389,y:658,t:1527190033709};\\\", \\\"{x:1388,y:649,t:1527190033726};\\\", \\\"{x:1388,y:640,t:1527190033743};\\\", \\\"{x:1388,y:632,t:1527190033759};\\\", \\\"{x:1386,y:626,t:1527190033776};\\\", \\\"{x:1385,y:618,t:1527190033793};\\\", \\\"{x:1384,y:613,t:1527190033810};\\\", \\\"{x:1384,y:610,t:1527190033826};\\\", \\\"{x:1384,y:609,t:1527190033844};\\\", \\\"{x:1383,y:608,t:1527190033975};\\\", \\\"{x:1381,y:610,t:1527190033982};\\\", \\\"{x:1378,y:615,t:1527190033993};\\\", \\\"{x:1375,y:625,t:1527190034010};\\\", \\\"{x:1372,y:634,t:1527190034026};\\\", \\\"{x:1372,y:637,t:1527190034043};\\\", \\\"{x:1371,y:642,t:1527190034060};\\\", \\\"{x:1369,y:648,t:1527190034076};\\\", \\\"{x:1367,y:651,t:1527190034094};\\\", \\\"{x:1365,y:657,t:1527190034110};\\\", \\\"{x:1364,y:664,t:1527190034127};\\\", \\\"{x:1361,y:671,t:1527190034144};\\\", \\\"{x:1360,y:677,t:1527190034160};\\\", \\\"{x:1357,y:684,t:1527190034177};\\\", \\\"{x:1357,y:693,t:1527190034193};\\\", \\\"{x:1357,y:702,t:1527190034210};\\\", \\\"{x:1355,y:710,t:1527190034227};\\\", \\\"{x:1354,y:720,t:1527190034244};\\\", \\\"{x:1351,y:725,t:1527190034261};\\\", \\\"{x:1349,y:733,t:1527190034277};\\\", \\\"{x:1349,y:737,t:1527190034294};\\\", \\\"{x:1348,y:741,t:1527190034310};\\\", \\\"{x:1348,y:742,t:1527190034328};\\\", \\\"{x:1347,y:745,t:1527190034343};\\\", \\\"{x:1347,y:749,t:1527190034361};\\\", \\\"{x:1347,y:759,t:1527190034378};\\\", \\\"{x:1347,y:769,t:1527190034394};\\\", \\\"{x:1347,y:774,t:1527190034409};\\\", \\\"{x:1347,y:780,t:1527190034427};\\\", \\\"{x:1347,y:786,t:1527190034442};\\\", \\\"{x:1348,y:793,t:1527190034460};\\\", \\\"{x:1351,y:808,t:1527190034477};\\\", \\\"{x:1353,y:814,t:1527190034492};\\\", \\\"{x:1356,y:833,t:1527190034510};\\\", \\\"{x:1359,y:845,t:1527190034526};\\\", \\\"{x:1360,y:854,t:1527190034543};\\\", \\\"{x:1361,y:864,t:1527190034560};\\\", \\\"{x:1364,y:876,t:1527190034577};\\\", \\\"{x:1365,y:883,t:1527190034593};\\\", \\\"{x:1365,y:888,t:1527190034610};\\\", \\\"{x:1365,y:895,t:1527190034627};\\\", \\\"{x:1367,y:901,t:1527190034643};\\\", \\\"{x:1368,y:908,t:1527190034660};\\\", \\\"{x:1369,y:913,t:1527190034677};\\\", \\\"{x:1374,y:929,t:1527190034694};\\\", \\\"{x:1376,y:937,t:1527190034710};\\\", \\\"{x:1377,y:942,t:1527190034727};\\\", \\\"{x:1378,y:945,t:1527190034743};\\\", \\\"{x:1380,y:949,t:1527190034759};\\\", \\\"{x:1381,y:951,t:1527190034777};\\\", \\\"{x:1381,y:952,t:1527190034794};\\\", \\\"{x:1384,y:957,t:1527190034809};\\\", \\\"{x:1384,y:960,t:1527190034827};\\\", \\\"{x:1386,y:965,t:1527190034843};\\\", \\\"{x:1387,y:969,t:1527190034860};\\\", \\\"{x:1388,y:972,t:1527190034877};\\\", \\\"{x:1388,y:973,t:1527190034894};\\\", \\\"{x:1388,y:975,t:1527190034909};\\\", \\\"{x:1389,y:975,t:1527190034933};\\\", \\\"{x:1389,y:977,t:1527190034949};\\\", \\\"{x:1389,y:978,t:1527190034960};\\\", \\\"{x:1389,y:975,t:1527190035229};\\\", \\\"{x:1389,y:973,t:1527190035244};\\\", \\\"{x:1379,y:953,t:1527190035260};\\\", \\\"{x:1371,y:936,t:1527190035277};\\\", \\\"{x:1356,y:919,t:1527190035294};\\\", \\\"{x:1341,y:901,t:1527190035311};\\\", \\\"{x:1326,y:879,t:1527190035327};\\\", \\\"{x:1306,y:862,t:1527190035343};\\\", \\\"{x:1272,y:836,t:1527190035361};\\\", \\\"{x:1237,y:815,t:1527190035377};\\\", \\\"{x:1198,y:789,t:1527190035394};\\\", \\\"{x:1152,y:762,t:1527190035411};\\\", \\\"{x:1105,y:742,t:1527190035427};\\\", \\\"{x:1065,y:721,t:1527190035444};\\\", \\\"{x:999,y:690,t:1527190035461};\\\", \\\"{x:961,y:677,t:1527190035477};\\\", \\\"{x:934,y:666,t:1527190035494};\\\", \\\"{x:908,y:655,t:1527190035511};\\\", \\\"{x:887,y:648,t:1527190035528};\\\", \\\"{x:871,y:638,t:1527190035544};\\\", \\\"{x:839,y:630,t:1527190035563};\\\", \\\"{x:801,y:622,t:1527190035578};\\\", \\\"{x:775,y:618,t:1527190035593};\\\", \\\"{x:756,y:613,t:1527190035611};\\\", \\\"{x:736,y:611,t:1527190035627};\\\", \\\"{x:709,y:605,t:1527190035644};\\\", \\\"{x:682,y:597,t:1527190035661};\\\", \\\"{x:665,y:596,t:1527190035678};\\\", \\\"{x:646,y:592,t:1527190035694};\\\", \\\"{x:633,y:587,t:1527190035711};\\\", \\\"{x:625,y:587,t:1527190035727};\\\", \\\"{x:603,y:587,t:1527190035745};\\\", \\\"{x:580,y:584,t:1527190035761};\\\", \\\"{x:568,y:581,t:1527190035778};\\\", \\\"{x:545,y:578,t:1527190035795};\\\", \\\"{x:526,y:570,t:1527190035811};\\\", \\\"{x:497,y:565,t:1527190035829};\\\", \\\"{x:459,y:559,t:1527190035845};\\\", \\\"{x:431,y:556,t:1527190035861};\\\", \\\"{x:404,y:551,t:1527190035879};\\\", \\\"{x:379,y:548,t:1527190035895};\\\", \\\"{x:357,y:546,t:1527190035911};\\\", \\\"{x:340,y:542,t:1527190035928};\\\", \\\"{x:325,y:540,t:1527190035944};\\\", \\\"{x:309,y:537,t:1527190035961};\\\", \\\"{x:299,y:536,t:1527190035978};\\\", \\\"{x:293,y:536,t:1527190035995};\\\", \\\"{x:288,y:536,t:1527190036011};\\\", \\\"{x:280,y:536,t:1527190036028};\\\", \\\"{x:255,y:539,t:1527190036046};\\\", \\\"{x:238,y:542,t:1527190036060};\\\", \\\"{x:223,y:547,t:1527190036078};\\\", \\\"{x:206,y:547,t:1527190036095};\\\", \\\"{x:186,y:546,t:1527190036111};\\\", \\\"{x:168,y:544,t:1527190036128};\\\", \\\"{x:146,y:542,t:1527190036145};\\\", \\\"{x:133,y:542,t:1527190036160};\\\", \\\"{x:124,y:541,t:1527190036178};\\\", \\\"{x:114,y:540,t:1527190036195};\\\", \\\"{x:111,y:539,t:1527190036211};\\\", \\\"{x:110,y:539,t:1527190036278};\\\", \\\"{x:110,y:538,t:1527190036309};\\\", \\\"{x:112,y:537,t:1527190036333};\\\", \\\"{x:114,y:537,t:1527190036345};\\\", \\\"{x:115,y:537,t:1527190036362};\\\", \\\"{x:117,y:537,t:1527190036379};\\\", \\\"{x:124,y:537,t:1527190036397};\\\", \\\"{x:130,y:538,t:1527190036412};\\\", \\\"{x:136,y:538,t:1527190036428};\\\", \\\"{x:143,y:538,t:1527190036445};\\\", \\\"{x:148,y:539,t:1527190036462};\\\", \\\"{x:154,y:541,t:1527190036479};\\\", \\\"{x:156,y:541,t:1527190036494};\\\", \\\"{x:159,y:543,t:1527190036813};\\\", \\\"{x:177,y:549,t:1527190036829};\\\", \\\"{x:195,y:562,t:1527190036845};\\\", \\\"{x:211,y:575,t:1527190036863};\\\", \\\"{x:234,y:593,t:1527190036878};\\\", \\\"{x:259,y:612,t:1527190036895};\\\", \\\"{x:304,y:631,t:1527190036913};\\\", \\\"{x:343,y:648,t:1527190036930};\\\", \\\"{x:380,y:662,t:1527190036946};\\\", \\\"{x:413,y:670,t:1527190036962};\\\", \\\"{x:433,y:680,t:1527190036979};\\\", \\\"{x:445,y:688,t:1527190036995};\\\", \\\"{x:451,y:692,t:1527190037011};\\\", \\\"{x:455,y:693,t:1527190037028};\\\", \\\"{x:456,y:695,t:1527190037045};\\\", \\\"{x:461,y:700,t:1527190037061};\\\", \\\"{x:465,y:704,t:1527190037079};\\\", \\\"{x:471,y:711,t:1527190037096};\\\", \\\"{x:473,y:713,t:1527190037112};\\\", \\\"{x:475,y:718,t:1527190037129};\\\", \\\"{x:477,y:722,t:1527190037146};\\\", \\\"{x:486,y:732,t:1527190037162};\\\", \\\"{x:493,y:739,t:1527190037179};\\\", \\\"{x:498,y:743,t:1527190037196};\\\", \\\"{x:501,y:744,t:1527190037212};\\\" ] }, { \\\"rt\\\": 32652, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 650844, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"F98S2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:502,y:744,t:1527190040086};\\\", \\\"{x:507,y:742,t:1527190040096};\\\", \\\"{x:511,y:740,t:1527190040114};\\\", \\\"{x:513,y:740,t:1527190040130};\\\", \\\"{x:514,y:738,t:1527190040146};\\\", \\\"{x:520,y:735,t:1527190040164};\\\", \\\"{x:535,y:725,t:1527190040180};\\\", \\\"{x:559,y:718,t:1527190040197};\\\", \\\"{x:586,y:707,t:1527190040212};\\\", \\\"{x:611,y:699,t:1527190040231};\\\", \\\"{x:632,y:693,t:1527190040248};\\\", \\\"{x:650,y:686,t:1527190040264};\\\", \\\"{x:666,y:678,t:1527190040281};\\\", \\\"{x:685,y:668,t:1527190040298};\\\", \\\"{x:711,y:657,t:1527190040314};\\\", \\\"{x:740,y:639,t:1527190040337};\\\", \\\"{x:754,y:633,t:1527190040348};\\\", \\\"{x:780,y:622,t:1527190040365};\\\", \\\"{x:816,y:609,t:1527190040381};\\\", \\\"{x:845,y:599,t:1527190040398};\\\", \\\"{x:881,y:590,t:1527190040415};\\\", \\\"{x:920,y:572,t:1527190040431};\\\", \\\"{x:942,y:567,t:1527190040448};\\\", \\\"{x:970,y:561,t:1527190040465};\\\", \\\"{x:1006,y:552,t:1527190040481};\\\", \\\"{x:1044,y:543,t:1527190040498};\\\", \\\"{x:1072,y:531,t:1527190040515};\\\", \\\"{x:1081,y:529,t:1527190040531};\\\", \\\"{x:1099,y:524,t:1527190040548};\\\", \\\"{x:1111,y:522,t:1527190040565};\\\", \\\"{x:1115,y:521,t:1527190040581};\\\", \\\"{x:1115,y:522,t:1527190042511};\\\", \\\"{x:1115,y:524,t:1527190042517};\\\", \\\"{x:1115,y:531,t:1527190042534};\\\", \\\"{x:1116,y:538,t:1527190042550};\\\", \\\"{x:1119,y:548,t:1527190042567};\\\", \\\"{x:1125,y:560,t:1527190042583};\\\", \\\"{x:1131,y:569,t:1527190042600};\\\", \\\"{x:1136,y:581,t:1527190042617};\\\", \\\"{x:1139,y:587,t:1527190042633};\\\", \\\"{x:1146,y:596,t:1527190042650};\\\", \\\"{x:1151,y:602,t:1527190042667};\\\", \\\"{x:1155,y:611,t:1527190042683};\\\", \\\"{x:1163,y:624,t:1527190042700};\\\", \\\"{x:1175,y:645,t:1527190042717};\\\", \\\"{x:1185,y:663,t:1527190042733};\\\", \\\"{x:1196,y:685,t:1527190042751};\\\", \\\"{x:1208,y:705,t:1527190042767};\\\", \\\"{x:1217,y:721,t:1527190042783};\\\", \\\"{x:1228,y:741,t:1527190042800};\\\", \\\"{x:1240,y:763,t:1527190042817};\\\", \\\"{x:1252,y:787,t:1527190042833};\\\", \\\"{x:1263,y:806,t:1527190042850};\\\", \\\"{x:1271,y:820,t:1527190042867};\\\", \\\"{x:1273,y:824,t:1527190042884};\\\", \\\"{x:1274,y:829,t:1527190042900};\\\", \\\"{x:1277,y:840,t:1527190042918};\\\", \\\"{x:1278,y:852,t:1527190042933};\\\", \\\"{x:1279,y:864,t:1527190042950};\\\", \\\"{x:1280,y:868,t:1527190042968};\\\", \\\"{x:1280,y:872,t:1527190042984};\\\", \\\"{x:1280,y:875,t:1527190043001};\\\", \\\"{x:1280,y:877,t:1527190043037};\\\", \\\"{x:1279,y:877,t:1527190043050};\\\", \\\"{x:1278,y:878,t:1527190043078};\\\", \\\"{x:1277,y:878,t:1527190043134};\\\", \\\"{x:1274,y:878,t:1527190043151};\\\", \\\"{x:1273,y:878,t:1527190043168};\\\", \\\"{x:1272,y:878,t:1527190043185};\\\", \\\"{x:1266,y:878,t:1527190043200};\\\", \\\"{x:1264,y:878,t:1527190043218};\\\", \\\"{x:1257,y:877,t:1527190043235};\\\", \\\"{x:1249,y:877,t:1527190043251};\\\", \\\"{x:1243,y:877,t:1527190043268};\\\", \\\"{x:1240,y:877,t:1527190043285};\\\", \\\"{x:1236,y:878,t:1527190043301};\\\", \\\"{x:1232,y:879,t:1527190043318};\\\", \\\"{x:1230,y:880,t:1527190043342};\\\", \\\"{x:1230,y:881,t:1527190043366};\\\", \\\"{x:1228,y:881,t:1527190043558};\\\", \\\"{x:1222,y:881,t:1527190043567};\\\", \\\"{x:1209,y:880,t:1527190043585};\\\", \\\"{x:1197,y:876,t:1527190043601};\\\", \\\"{x:1180,y:870,t:1527190043618};\\\", \\\"{x:1178,y:870,t:1527190043634};\\\", \\\"{x:1177,y:867,t:1527190043652};\\\", \\\"{x:1177,y:866,t:1527190043668};\\\", \\\"{x:1176,y:864,t:1527190043684};\\\", \\\"{x:1175,y:863,t:1527190044047};\\\", \\\"{x:1177,y:863,t:1527190044062};\\\", \\\"{x:1177,y:862,t:1527190044070};\\\", \\\"{x:1179,y:861,t:1527190044085};\\\", \\\"{x:1193,y:859,t:1527190044102};\\\", \\\"{x:1211,y:858,t:1527190044119};\\\", \\\"{x:1231,y:855,t:1527190044135};\\\", \\\"{x:1251,y:855,t:1527190044152};\\\", \\\"{x:1274,y:855,t:1527190044169};\\\", \\\"{x:1296,y:855,t:1527190044185};\\\", \\\"{x:1326,y:854,t:1527190044202};\\\", \\\"{x:1340,y:850,t:1527190044219};\\\", \\\"{x:1365,y:847,t:1527190044236};\\\", \\\"{x:1406,y:842,t:1527190044252};\\\", \\\"{x:1422,y:838,t:1527190044269};\\\", \\\"{x:1468,y:830,t:1527190044286};\\\", \\\"{x:1495,y:830,t:1527190044301};\\\", \\\"{x:1515,y:830,t:1527190044319};\\\", \\\"{x:1536,y:829,t:1527190044336};\\\", \\\"{x:1550,y:827,t:1527190044352};\\\", \\\"{x:1561,y:827,t:1527190044369};\\\", \\\"{x:1567,y:827,t:1527190044386};\\\", \\\"{x:1571,y:827,t:1527190044402};\\\", \\\"{x:1576,y:828,t:1527190044419};\\\", \\\"{x:1577,y:828,t:1527190044436};\\\", \\\"{x:1580,y:828,t:1527190044452};\\\", \\\"{x:1583,y:828,t:1527190044469};\\\", \\\"{x:1588,y:829,t:1527190044486};\\\", \\\"{x:1593,y:829,t:1527190044502};\\\", \\\"{x:1598,y:826,t:1527190044519};\\\", \\\"{x:1600,y:826,t:1527190044535};\\\", \\\"{x:1598,y:826,t:1527190044845};\\\", \\\"{x:1596,y:827,t:1527190044861};\\\", \\\"{x:1596,y:828,t:1527190044868};\\\", \\\"{x:1596,y:830,t:1527190044885};\\\", \\\"{x:1596,y:831,t:1527190044902};\\\", \\\"{x:1596,y:832,t:1527190044941};\\\", \\\"{x:1596,y:834,t:1527190045005};\\\", \\\"{x:1596,y:835,t:1527190045037};\\\", \\\"{x:1596,y:836,t:1527190045052};\\\", \\\"{x:1596,y:839,t:1527190045068};\\\", \\\"{x:1590,y:846,t:1527190045086};\\\", \\\"{x:1587,y:849,t:1527190045103};\\\", \\\"{x:1585,y:852,t:1527190045119};\\\", \\\"{x:1582,y:856,t:1527190045136};\\\", \\\"{x:1580,y:860,t:1527190045153};\\\", \\\"{x:1575,y:866,t:1527190045169};\\\", \\\"{x:1567,y:873,t:1527190045186};\\\", \\\"{x:1558,y:880,t:1527190045202};\\\", \\\"{x:1550,y:889,t:1527190045220};\\\", \\\"{x:1540,y:900,t:1527190045236};\\\", \\\"{x:1528,y:909,t:1527190045253};\\\", \\\"{x:1514,y:919,t:1527190045270};\\\", \\\"{x:1505,y:924,t:1527190045285};\\\", \\\"{x:1495,y:927,t:1527190045303};\\\", \\\"{x:1486,y:929,t:1527190045320};\\\", \\\"{x:1472,y:930,t:1527190045336};\\\", \\\"{x:1458,y:933,t:1527190045353};\\\", \\\"{x:1445,y:933,t:1527190045369};\\\", \\\"{x:1421,y:940,t:1527190045386};\\\", \\\"{x:1401,y:940,t:1527190045403};\\\", \\\"{x:1380,y:940,t:1527190045420};\\\", \\\"{x:1360,y:940,t:1527190045436};\\\", \\\"{x:1339,y:939,t:1527190045453};\\\", \\\"{x:1319,y:937,t:1527190045469};\\\", \\\"{x:1301,y:932,t:1527190045486};\\\", \\\"{x:1283,y:925,t:1527190045503};\\\", \\\"{x:1264,y:920,t:1527190045519};\\\", \\\"{x:1257,y:916,t:1527190045537};\\\", \\\"{x:1250,y:911,t:1527190045553};\\\", \\\"{x:1246,y:907,t:1527190045570};\\\", \\\"{x:1241,y:902,t:1527190045587};\\\", \\\"{x:1239,y:899,t:1527190045603};\\\", \\\"{x:1235,y:893,t:1527190045620};\\\", \\\"{x:1234,y:888,t:1527190045637};\\\", \\\"{x:1231,y:881,t:1527190045652};\\\", \\\"{x:1230,y:876,t:1527190045670};\\\", \\\"{x:1230,y:874,t:1527190045687};\\\", \\\"{x:1228,y:870,t:1527190045703};\\\", \\\"{x:1227,y:866,t:1527190045719};\\\", \\\"{x:1226,y:862,t:1527190045736};\\\", \\\"{x:1226,y:861,t:1527190045753};\\\", \\\"{x:1224,y:860,t:1527190045769};\\\", \\\"{x:1224,y:859,t:1527190045787};\\\", \\\"{x:1223,y:859,t:1527190045802};\\\", \\\"{x:1222,y:858,t:1527190045820};\\\", \\\"{x:1222,y:857,t:1527190045853};\\\", \\\"{x:1221,y:856,t:1527190045870};\\\", \\\"{x:1220,y:855,t:1527190045887};\\\", \\\"{x:1220,y:853,t:1527190046902};\\\", \\\"{x:1225,y:849,t:1527190046910};\\\", \\\"{x:1226,y:848,t:1527190046921};\\\", \\\"{x:1229,y:842,t:1527190046938};\\\", \\\"{x:1235,y:835,t:1527190046954};\\\", \\\"{x:1244,y:826,t:1527190046970};\\\", \\\"{x:1253,y:815,t:1527190046988};\\\", \\\"{x:1265,y:799,t:1527190047004};\\\", \\\"{x:1277,y:784,t:1527190047021};\\\", \\\"{x:1295,y:762,t:1527190047038};\\\", \\\"{x:1309,y:744,t:1527190047053};\\\", \\\"{x:1324,y:725,t:1527190047071};\\\", \\\"{x:1336,y:706,t:1527190047088};\\\", \\\"{x:1353,y:681,t:1527190047105};\\\", \\\"{x:1364,y:665,t:1527190047121};\\\", \\\"{x:1372,y:649,t:1527190047139};\\\", \\\"{x:1381,y:635,t:1527190047155};\\\", \\\"{x:1387,y:619,t:1527190047171};\\\", \\\"{x:1392,y:612,t:1527190047187};\\\", \\\"{x:1395,y:602,t:1527190047204};\\\", \\\"{x:1396,y:588,t:1527190047220};\\\", \\\"{x:1397,y:570,t:1527190047236};\\\", \\\"{x:1397,y:564,t:1527190047255};\\\", \\\"{x:1397,y:560,t:1527190047271};\\\", \\\"{x:1397,y:556,t:1527190047287};\\\", \\\"{x:1397,y:554,t:1527190047304};\\\", \\\"{x:1397,y:551,t:1527190047321};\\\", \\\"{x:1399,y:547,t:1527190047338};\\\", \\\"{x:1399,y:544,t:1527190047355};\\\", \\\"{x:1399,y:542,t:1527190047371};\\\", \\\"{x:1400,y:539,t:1527190047388};\\\", \\\"{x:1400,y:535,t:1527190047404};\\\", \\\"{x:1400,y:533,t:1527190047421};\\\", \\\"{x:1400,y:527,t:1527190047437};\\\", \\\"{x:1405,y:520,t:1527190047455};\\\", \\\"{x:1410,y:513,t:1527190047471};\\\", \\\"{x:1416,y:507,t:1527190047487};\\\", \\\"{x:1422,y:503,t:1527190047505};\\\", \\\"{x:1429,y:498,t:1527190047522};\\\", \\\"{x:1441,y:489,t:1527190047537};\\\", \\\"{x:1455,y:479,t:1527190047555};\\\", \\\"{x:1468,y:470,t:1527190047572};\\\", \\\"{x:1482,y:461,t:1527190047588};\\\", \\\"{x:1490,y:457,t:1527190047604};\\\", \\\"{x:1499,y:453,t:1527190047621};\\\", \\\"{x:1508,y:450,t:1527190047638};\\\", \\\"{x:1510,y:449,t:1527190047654};\\\", \\\"{x:1510,y:448,t:1527190047672};\\\", \\\"{x:1512,y:448,t:1527190047774};\\\", \\\"{x:1512,y:449,t:1527190047788};\\\", \\\"{x:1516,y:454,t:1527190047805};\\\", \\\"{x:1529,y:466,t:1527190047822};\\\", \\\"{x:1536,y:476,t:1527190047838};\\\", \\\"{x:1545,y:485,t:1527190047856};\\\", \\\"{x:1552,y:491,t:1527190047872};\\\", \\\"{x:1560,y:502,t:1527190047889};\\\", \\\"{x:1564,y:515,t:1527190047904};\\\", \\\"{x:1574,y:530,t:1527190047921};\\\", \\\"{x:1580,y:545,t:1527190047937};\\\", \\\"{x:1586,y:560,t:1527190047955};\\\", \\\"{x:1590,y:571,t:1527190047971};\\\", \\\"{x:1594,y:587,t:1527190047989};\\\", \\\"{x:1598,y:600,t:1527190048005};\\\", \\\"{x:1600,y:622,t:1527190048022};\\\", \\\"{x:1603,y:634,t:1527190048039};\\\", \\\"{x:1606,y:650,t:1527190048054};\\\", \\\"{x:1611,y:660,t:1527190048072};\\\", \\\"{x:1614,y:667,t:1527190048088};\\\", \\\"{x:1616,y:676,t:1527190048105};\\\", \\\"{x:1618,y:683,t:1527190048122};\\\", \\\"{x:1620,y:690,t:1527190048139};\\\", \\\"{x:1623,y:701,t:1527190048155};\\\", \\\"{x:1626,y:707,t:1527190048172};\\\", \\\"{x:1627,y:710,t:1527190048189};\\\", \\\"{x:1628,y:716,t:1527190048205};\\\", \\\"{x:1633,y:725,t:1527190048221};\\\", \\\"{x:1635,y:730,t:1527190048239};\\\", \\\"{x:1638,y:738,t:1527190048255};\\\", \\\"{x:1639,y:743,t:1527190048272};\\\", \\\"{x:1642,y:749,t:1527190048288};\\\", \\\"{x:1643,y:756,t:1527190048305};\\\", \\\"{x:1643,y:764,t:1527190048322};\\\", \\\"{x:1643,y:773,t:1527190048339};\\\", \\\"{x:1643,y:784,t:1527190048356};\\\", \\\"{x:1636,y:795,t:1527190048372};\\\", \\\"{x:1630,y:807,t:1527190048389};\\\", \\\"{x:1620,y:824,t:1527190048406};\\\", \\\"{x:1610,y:836,t:1527190048421};\\\", \\\"{x:1598,y:851,t:1527190048440};\\\", \\\"{x:1590,y:861,t:1527190048456};\\\", \\\"{x:1580,y:872,t:1527190048472};\\\", \\\"{x:1572,y:879,t:1527190048490};\\\", \\\"{x:1568,y:883,t:1527190048506};\\\", \\\"{x:1561,y:887,t:1527190048522};\\\", \\\"{x:1556,y:893,t:1527190048539};\\\", \\\"{x:1550,y:895,t:1527190048556};\\\", \\\"{x:1543,y:901,t:1527190048573};\\\", \\\"{x:1535,y:907,t:1527190048589};\\\", \\\"{x:1521,y:915,t:1527190048605};\\\", \\\"{x:1511,y:919,t:1527190048622};\\\", \\\"{x:1495,y:927,t:1527190048642};\\\", \\\"{x:1481,y:931,t:1527190048655};\\\", \\\"{x:1478,y:932,t:1527190048671};\\\", \\\"{x:1472,y:932,t:1527190048689};\\\", \\\"{x:1469,y:932,t:1527190048705};\\\", \\\"{x:1468,y:933,t:1527190048721};\\\", \\\"{x:1467,y:934,t:1527190048738};\\\", \\\"{x:1466,y:934,t:1527190048764};\\\", \\\"{x:1465,y:935,t:1527190048773};\\\", \\\"{x:1463,y:935,t:1527190048789};\\\", \\\"{x:1450,y:939,t:1527190048805};\\\", \\\"{x:1439,y:942,t:1527190048822};\\\", \\\"{x:1426,y:943,t:1527190048839};\\\", \\\"{x:1406,y:943,t:1527190048856};\\\", \\\"{x:1391,y:943,t:1527190048873};\\\", \\\"{x:1371,y:943,t:1527190048889};\\\", \\\"{x:1357,y:938,t:1527190048906};\\\", \\\"{x:1348,y:937,t:1527190048923};\\\", \\\"{x:1340,y:937,t:1527190048939};\\\", \\\"{x:1333,y:937,t:1527190048955};\\\", \\\"{x:1330,y:937,t:1527190048972};\\\", \\\"{x:1326,y:937,t:1527190048989};\\\", \\\"{x:1321,y:937,t:1527190049005};\\\", \\\"{x:1315,y:937,t:1527190049022};\\\", \\\"{x:1305,y:936,t:1527190049039};\\\", \\\"{x:1297,y:931,t:1527190049056};\\\", \\\"{x:1287,y:925,t:1527190049073};\\\", \\\"{x:1271,y:918,t:1527190049089};\\\", \\\"{x:1254,y:911,t:1527190049106};\\\", \\\"{x:1239,y:907,t:1527190049123};\\\", \\\"{x:1221,y:901,t:1527190049140};\\\", \\\"{x:1206,y:895,t:1527190049156};\\\", \\\"{x:1202,y:895,t:1527190049173};\\\", \\\"{x:1192,y:891,t:1527190049189};\\\", \\\"{x:1191,y:891,t:1527190049206};\\\", \\\"{x:1190,y:888,t:1527190049390};\\\", \\\"{x:1190,y:886,t:1527190049406};\\\", \\\"{x:1187,y:883,t:1527190049423};\\\", \\\"{x:1187,y:882,t:1527190049440};\\\", \\\"{x:1189,y:882,t:1527190050789};\\\", \\\"{x:1195,y:882,t:1527190050797};\\\", \\\"{x:1205,y:882,t:1527190050807};\\\", \\\"{x:1213,y:881,t:1527190050823};\\\", \\\"{x:1230,y:871,t:1527190050841};\\\", \\\"{x:1268,y:863,t:1527190050857};\\\", \\\"{x:1307,y:850,t:1527190050874};\\\", \\\"{x:1347,y:838,t:1527190050891};\\\", \\\"{x:1397,y:825,t:1527190050908};\\\", \\\"{x:1437,y:818,t:1527190050924};\\\", \\\"{x:1460,y:809,t:1527190050941};\\\", \\\"{x:1469,y:803,t:1527190050957};\\\", \\\"{x:1475,y:798,t:1527190050974};\\\", \\\"{x:1479,y:792,t:1527190050991};\\\", \\\"{x:1480,y:791,t:1527190051008};\\\", \\\"{x:1483,y:788,t:1527190051024};\\\", \\\"{x:1488,y:782,t:1527190051041};\\\", \\\"{x:1495,y:768,t:1527190051058};\\\", \\\"{x:1498,y:761,t:1527190051074};\\\", \\\"{x:1503,y:753,t:1527190051090};\\\", \\\"{x:1512,y:742,t:1527190051108};\\\", \\\"{x:1522,y:734,t:1527190051123};\\\", \\\"{x:1538,y:721,t:1527190051141};\\\", \\\"{x:1551,y:714,t:1527190051158};\\\", \\\"{x:1555,y:711,t:1527190051173};\\\", \\\"{x:1563,y:707,t:1527190051190};\\\", \\\"{x:1567,y:707,t:1527190051208};\\\", \\\"{x:1576,y:705,t:1527190051224};\\\", \\\"{x:1585,y:705,t:1527190051240};\\\", \\\"{x:1593,y:704,t:1527190051258};\\\", \\\"{x:1607,y:703,t:1527190051275};\\\", \\\"{x:1620,y:703,t:1527190051290};\\\", \\\"{x:1629,y:703,t:1527190051308};\\\", \\\"{x:1633,y:703,t:1527190051325};\\\", \\\"{x:1634,y:703,t:1527190051341};\\\", \\\"{x:1635,y:702,t:1527190051702};\\\", \\\"{x:1634,y:702,t:1527190051734};\\\", \\\"{x:1633,y:702,t:1527190051742};\\\", \\\"{x:1630,y:700,t:1527190051840};\\\", \\\"{x:1629,y:700,t:1527190051854};\\\", \\\"{x:1627,y:700,t:1527190051870};\\\", \\\"{x:1626,y:700,t:1527190051885};\\\", \\\"{x:1625,y:699,t:1527190051893};\\\", \\\"{x:1624,y:699,t:1527190051907};\\\", \\\"{x:1623,y:699,t:1527190051925};\\\", \\\"{x:1620,y:699,t:1527190051941};\\\", \\\"{x:1618,y:697,t:1527190051959};\\\", \\\"{x:1617,y:697,t:1527190051974};\\\", \\\"{x:1614,y:696,t:1527190051992};\\\", \\\"{x:1613,y:695,t:1527190052008};\\\", \\\"{x:1612,y:695,t:1527190052025};\\\", \\\"{x:1611,y:695,t:1527190052041};\\\", \\\"{x:1610,y:694,t:1527190052078};\\\", \\\"{x:1608,y:694,t:1527190067535};\\\", \\\"{x:1598,y:694,t:1527190067541};\\\", \\\"{x:1586,y:695,t:1527190067556};\\\", \\\"{x:1563,y:696,t:1527190067572};\\\", \\\"{x:1534,y:697,t:1527190067589};\\\", \\\"{x:1461,y:694,t:1527190067606};\\\", \\\"{x:1437,y:694,t:1527190067621};\\\", \\\"{x:1403,y:687,t:1527190067640};\\\", \\\"{x:1367,y:687,t:1527190067655};\\\", \\\"{x:1315,y:687,t:1527190067671};\\\", \\\"{x:1270,y:687,t:1527190067689};\\\", \\\"{x:1245,y:687,t:1527190067705};\\\", \\\"{x:1221,y:682,t:1527190067721};\\\", \\\"{x:1205,y:675,t:1527190067739};\\\", \\\"{x:1184,y:667,t:1527190067755};\\\", \\\"{x:1162,y:659,t:1527190067771};\\\", \\\"{x:1135,y:656,t:1527190067788};\\\", \\\"{x:1099,y:647,t:1527190067805};\\\", \\\"{x:1070,y:638,t:1527190067821};\\\", \\\"{x:1049,y:627,t:1527190067838};\\\", \\\"{x:1008,y:616,t:1527190067855};\\\", \\\"{x:974,y:610,t:1527190067871};\\\", \\\"{x:939,y:605,t:1527190067889};\\\", \\\"{x:914,y:598,t:1527190067905};\\\", \\\"{x:901,y:596,t:1527190067922};\\\", \\\"{x:882,y:592,t:1527190067938};\\\", \\\"{x:861,y:586,t:1527190067954};\\\", \\\"{x:847,y:586,t:1527190067970};\\\", \\\"{x:827,y:581,t:1527190067987};\\\", \\\"{x:809,y:578,t:1527190068004};\\\", \\\"{x:796,y:578,t:1527190068020};\\\", \\\"{x:776,y:578,t:1527190068037};\\\", \\\"{x:759,y:578,t:1527190068054};\\\", \\\"{x:740,y:578,t:1527190068070};\\\", \\\"{x:725,y:578,t:1527190068087};\\\", \\\"{x:718,y:578,t:1527190068105};\\\", \\\"{x:714,y:578,t:1527190068120};\\\", \\\"{x:712,y:577,t:1527190068137};\\\", \\\"{x:711,y:577,t:1527190068154};\\\", \\\"{x:706,y:576,t:1527190068170};\\\", \\\"{x:702,y:574,t:1527190068188};\\\", \\\"{x:698,y:573,t:1527190068205};\\\", \\\"{x:691,y:573,t:1527190068220};\\\", \\\"{x:681,y:570,t:1527190068239};\\\", \\\"{x:671,y:570,t:1527190068255};\\\", \\\"{x:656,y:570,t:1527190068270};\\\", \\\"{x:645,y:570,t:1527190068288};\\\", \\\"{x:628,y:570,t:1527190068305};\\\", \\\"{x:618,y:571,t:1527190068320};\\\", \\\"{x:613,y:574,t:1527190068337};\\\", \\\"{x:608,y:574,t:1527190068354};\\\", \\\"{x:607,y:574,t:1527190068373};\\\", \\\"{x:606,y:575,t:1527190068388};\\\", \\\"{x:606,y:576,t:1527190068404};\\\", \\\"{x:605,y:576,t:1527190068420};\\\", \\\"{x:604,y:577,t:1527190068438};\\\", \\\"{x:603,y:577,t:1527190068990};\\\", \\\"{x:601,y:576,t:1527190069005};\\\", \\\"{x:595,y:566,t:1527190069022};\\\", \\\"{x:594,y:561,t:1527190069039};\\\", \\\"{x:592,y:553,t:1527190069056};\\\", \\\"{x:591,y:550,t:1527190069071};\\\", \\\"{x:590,y:548,t:1527190069093};\\\", \\\"{x:590,y:547,t:1527190069106};\\\", \\\"{x:588,y:546,t:1527190069125};\\\", \\\"{x:588,y:545,t:1527190069157};\\\", \\\"{x:586,y:545,t:1527190069205};\\\", \\\"{x:577,y:545,t:1527190069221};\\\", \\\"{x:566,y:545,t:1527190069239};\\\", \\\"{x:551,y:545,t:1527190069255};\\\", \\\"{x:534,y:547,t:1527190069272};\\\", \\\"{x:527,y:547,t:1527190069288};\\\", \\\"{x:516,y:547,t:1527190069305};\\\", \\\"{x:504,y:547,t:1527190069321};\\\", \\\"{x:490,y:548,t:1527190069340};\\\", \\\"{x:484,y:548,t:1527190069355};\\\", \\\"{x:476,y:548,t:1527190069371};\\\", \\\"{x:463,y:548,t:1527190069388};\\\", \\\"{x:461,y:548,t:1527190069405};\\\", \\\"{x:457,y:548,t:1527190069422};\\\", \\\"{x:452,y:548,t:1527190069438};\\\", \\\"{x:445,y:548,t:1527190069455};\\\", \\\"{x:437,y:548,t:1527190069472};\\\", \\\"{x:424,y:548,t:1527190069489};\\\", \\\"{x:407,y:548,t:1527190069506};\\\", \\\"{x:392,y:548,t:1527190069523};\\\", \\\"{x:381,y:547,t:1527190069539};\\\", \\\"{x:375,y:547,t:1527190069555};\\\", \\\"{x:371,y:547,t:1527190069572};\\\", \\\"{x:368,y:547,t:1527190069588};\\\", \\\"{x:365,y:547,t:1527190069605};\\\", \\\"{x:364,y:547,t:1527190069623};\\\", \\\"{x:363,y:548,t:1527190069638};\\\", \\\"{x:362,y:548,t:1527190069655};\\\", \\\"{x:361,y:548,t:1527190069693};\\\", \\\"{x:365,y:548,t:1527190069725};\\\", \\\"{x:376,y:545,t:1527190069740};\\\", \\\"{x:398,y:540,t:1527190069755};\\\", \\\"{x:448,y:527,t:1527190069772};\\\", \\\"{x:472,y:522,t:1527190069788};\\\", \\\"{x:559,y:514,t:1527190069806};\\\", \\\"{x:603,y:514,t:1527190069822};\\\", \\\"{x:641,y:512,t:1527190069839};\\\", \\\"{x:662,y:512,t:1527190069856};\\\", \\\"{x:680,y:510,t:1527190069873};\\\", \\\"{x:694,y:508,t:1527190069888};\\\", \\\"{x:703,y:508,t:1527190069906};\\\", \\\"{x:709,y:508,t:1527190069922};\\\", \\\"{x:718,y:506,t:1527190069938};\\\", \\\"{x:727,y:502,t:1527190069956};\\\", \\\"{x:734,y:501,t:1527190069972};\\\", \\\"{x:753,y:504,t:1527190069988};\\\", \\\"{x:762,y:504,t:1527190070005};\\\", \\\"{x:766,y:505,t:1527190070022};\\\", \\\"{x:768,y:506,t:1527190070039};\\\", \\\"{x:771,y:508,t:1527190070056};\\\", \\\"{x:773,y:509,t:1527190070072};\\\", \\\"{x:776,y:509,t:1527190070090};\\\", \\\"{x:778,y:509,t:1527190070117};\\\", \\\"{x:779,y:509,t:1527190070125};\\\", \\\"{x:781,y:509,t:1527190070157};\\\", \\\"{x:782,y:509,t:1527190070190};\\\", \\\"{x:785,y:508,t:1527190070206};\\\", \\\"{x:790,y:507,t:1527190070223};\\\", \\\"{x:795,y:506,t:1527190070241};\\\", \\\"{x:799,y:504,t:1527190070256};\\\", \\\"{x:804,y:503,t:1527190070272};\\\", \\\"{x:809,y:501,t:1527190070290};\\\", \\\"{x:810,y:501,t:1527190070305};\\\", \\\"{x:811,y:501,t:1527190070323};\\\", \\\"{x:814,y:499,t:1527190070340};\\\", \\\"{x:822,y:499,t:1527190070357};\\\", \\\"{x:833,y:497,t:1527190070374};\\\", \\\"{x:837,y:496,t:1527190070389};\\\", \\\"{x:838,y:496,t:1527190070406};\\\", \\\"{x:839,y:496,t:1527190070423};\\\", \\\"{x:838,y:498,t:1527190070709};\\\", \\\"{x:837,y:501,t:1527190070722};\\\", \\\"{x:826,y:514,t:1527190070739};\\\", \\\"{x:814,y:537,t:1527190070757};\\\", \\\"{x:805,y:548,t:1527190070772};\\\", \\\"{x:797,y:559,t:1527190070789};\\\", \\\"{x:785,y:575,t:1527190070806};\\\", \\\"{x:769,y:598,t:1527190070824};\\\", \\\"{x:744,y:624,t:1527190070840};\\\", \\\"{x:705,y:668,t:1527190070857};\\\", \\\"{x:666,y:704,t:1527190070873};\\\", \\\"{x:642,y:720,t:1527190070890};\\\", \\\"{x:627,y:731,t:1527190070906};\\\", \\\"{x:618,y:736,t:1527190070923};\\\", \\\"{x:607,y:742,t:1527190070939};\\\", \\\"{x:581,y:757,t:1527190070956};\\\", \\\"{x:558,y:764,t:1527190070973};\\\", \\\"{x:534,y:770,t:1527190070989};\\\", \\\"{x:517,y:775,t:1527190071007};\\\", \\\"{x:505,y:775,t:1527190071024};\\\", \\\"{x:495,y:775,t:1527190071040};\\\", \\\"{x:490,y:774,t:1527190071057};\\\", \\\"{x:489,y:774,t:1527190071073};\\\", \\\"{x:487,y:774,t:1527190071090};\\\", \\\"{x:486,y:770,t:1527190071107};\\\", \\\"{x:484,y:766,t:1527190071124};\\\", \\\"{x:484,y:763,t:1527190071140};\\\", \\\"{x:484,y:753,t:1527190071157};\\\", \\\"{x:484,y:750,t:1527190071173};\\\", \\\"{x:485,y:745,t:1527190071190};\\\", \\\"{x:486,y:744,t:1527190071207};\\\", \\\"{x:489,y:741,t:1527190071224};\\\", \\\"{x:490,y:738,t:1527190071240};\\\", \\\"{x:492,y:734,t:1527190071258};\\\", \\\"{x:497,y:730,t:1527190071273};\\\", \\\"{x:497,y:728,t:1527190071291};\\\" ] }, { \\\"rt\\\": 34218, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 686367, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"F98S2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-12 PM-01 PM-02 PM-03 PM-O -03 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:498,y:728,t:1527190073253};\\\", \\\"{x:499,y:727,t:1527190074397};\\\", \\\"{x:500,y:726,t:1527190074421};\\\", \\\"{x:500,y:725,t:1527190074765};\\\", \\\"{x:502,y:723,t:1527190074779};\\\", \\\"{x:509,y:719,t:1527190074797};\\\", \\\"{x:523,y:710,t:1527190074813};\\\", \\\"{x:532,y:708,t:1527190074830};\\\", \\\"{x:547,y:703,t:1527190074845};\\\", \\\"{x:557,y:700,t:1527190074860};\\\", \\\"{x:597,y:688,t:1527190074876};\\\", \\\"{x:619,y:681,t:1527190074893};\\\", \\\"{x:644,y:680,t:1527190074909};\\\", \\\"{x:685,y:673,t:1527190074926};\\\", \\\"{x:744,y:665,t:1527190074942};\\\", \\\"{x:815,y:658,t:1527190074959};\\\", \\\"{x:898,y:649,t:1527190074977};\\\", \\\"{x:985,y:643,t:1527190074992};\\\", \\\"{x:1069,y:643,t:1527190075009};\\\", \\\"{x:1134,y:640,t:1527190075027};\\\", \\\"{x:1206,y:640,t:1527190075042};\\\", \\\"{x:1285,y:644,t:1527190075060};\\\", \\\"{x:1388,y:653,t:1527190075077};\\\", \\\"{x:1434,y:654,t:1527190075094};\\\", \\\"{x:1461,y:659,t:1527190075109};\\\", \\\"{x:1484,y:662,t:1527190075127};\\\", \\\"{x:1508,y:663,t:1527190075142};\\\", \\\"{x:1527,y:667,t:1527190075160};\\\", \\\"{x:1542,y:672,t:1527190075177};\\\", \\\"{x:1562,y:682,t:1527190075193};\\\", \\\"{x:1574,y:691,t:1527190075209};\\\", \\\"{x:1584,y:698,t:1527190075227};\\\", \\\"{x:1588,y:706,t:1527190075245};\\\", \\\"{x:1591,y:714,t:1527190075260};\\\", \\\"{x:1597,y:725,t:1527190075278};\\\", \\\"{x:1597,y:731,t:1527190075295};\\\", \\\"{x:1599,y:738,t:1527190075310};\\\", \\\"{x:1601,y:745,t:1527190075327};\\\", \\\"{x:1602,y:756,t:1527190075344};\\\", \\\"{x:1602,y:761,t:1527190075360};\\\", \\\"{x:1601,y:773,t:1527190075377};\\\", \\\"{x:1596,y:789,t:1527190075394};\\\", \\\"{x:1596,y:792,t:1527190075410};\\\", \\\"{x:1596,y:795,t:1527190075427};\\\", \\\"{x:1596,y:796,t:1527190075486};\\\", \\\"{x:1596,y:798,t:1527190075501};\\\", \\\"{x:1596,y:800,t:1527190075510};\\\", \\\"{x:1592,y:805,t:1527190075527};\\\", \\\"{x:1590,y:810,t:1527190075544};\\\", \\\"{x:1587,y:816,t:1527190075560};\\\", \\\"{x:1582,y:824,t:1527190075577};\\\", \\\"{x:1577,y:834,t:1527190075594};\\\", \\\"{x:1572,y:842,t:1527190075611};\\\", \\\"{x:1564,y:853,t:1527190075627};\\\", \\\"{x:1561,y:858,t:1527190075644};\\\", \\\"{x:1555,y:868,t:1527190075660};\\\", \\\"{x:1549,y:875,t:1527190075677};\\\", \\\"{x:1545,y:879,t:1527190075695};\\\", \\\"{x:1542,y:882,t:1527190075710};\\\", \\\"{x:1537,y:888,t:1527190075727};\\\", \\\"{x:1534,y:890,t:1527190075744};\\\", \\\"{x:1526,y:895,t:1527190075760};\\\", \\\"{x:1524,y:897,t:1527190075777};\\\", \\\"{x:1515,y:901,t:1527190075794};\\\", \\\"{x:1499,y:907,t:1527190075811};\\\", \\\"{x:1486,y:911,t:1527190075826};\\\", \\\"{x:1465,y:912,t:1527190075843};\\\", \\\"{x:1408,y:916,t:1527190075860};\\\", \\\"{x:1385,y:916,t:1527190075877};\\\", \\\"{x:1359,y:916,t:1527190075893};\\\", \\\"{x:1344,y:914,t:1527190075911};\\\", \\\"{x:1334,y:913,t:1527190075927};\\\", \\\"{x:1329,y:911,t:1527190075944};\\\", \\\"{x:1326,y:911,t:1527190075961};\\\", \\\"{x:1324,y:910,t:1527190075976};\\\", \\\"{x:1323,y:910,t:1527190075994};\\\", \\\"{x:1322,y:911,t:1527190076021};\\\", \\\"{x:1322,y:913,t:1527190076029};\\\", \\\"{x:1322,y:914,t:1527190076044};\\\", \\\"{x:1321,y:917,t:1527190076061};\\\", \\\"{x:1320,y:920,t:1527190076076};\\\", \\\"{x:1320,y:925,t:1527190076094};\\\", \\\"{x:1321,y:932,t:1527190076111};\\\", \\\"{x:1323,y:938,t:1527190076127};\\\", \\\"{x:1328,y:944,t:1527190076144};\\\", \\\"{x:1333,y:949,t:1527190076161};\\\", \\\"{x:1333,y:950,t:1527190076177};\\\", \\\"{x:1335,y:952,t:1527190076194};\\\", \\\"{x:1336,y:952,t:1527190076237};\\\", \\\"{x:1341,y:954,t:1527190076245};\\\", \\\"{x:1344,y:954,t:1527190076261};\\\", \\\"{x:1345,y:956,t:1527190076302};\\\", \\\"{x:1346,y:956,t:1527190076312};\\\", \\\"{x:1347,y:956,t:1527190076328};\\\", \\\"{x:1350,y:959,t:1527190076344};\\\", \\\"{x:1353,y:959,t:1527190076361};\\\", \\\"{x:1353,y:960,t:1527190076378};\\\", \\\"{x:1354,y:961,t:1527190076394};\\\", \\\"{x:1354,y:962,t:1527190076445};\\\", \\\"{x:1354,y:963,t:1527190076470};\\\", \\\"{x:1354,y:964,t:1527190076478};\\\", \\\"{x:1354,y:966,t:1527190076495};\\\", \\\"{x:1351,y:968,t:1527190076512};\\\", \\\"{x:1349,y:970,t:1527190076528};\\\", \\\"{x:1346,y:972,t:1527190076544};\\\", \\\"{x:1344,y:974,t:1527190076561};\\\", \\\"{x:1341,y:978,t:1527190076578};\\\", \\\"{x:1339,y:979,t:1527190076594};\\\", \\\"{x:1338,y:980,t:1527190076611};\\\", \\\"{x:1337,y:982,t:1527190076628};\\\", \\\"{x:1336,y:983,t:1527190076645};\\\", \\\"{x:1336,y:984,t:1527190076677};\\\", \\\"{x:1336,y:985,t:1527190076696};\\\", \\\"{x:1336,y:983,t:1527190076855};\\\", \\\"{x:1338,y:983,t:1527190076861};\\\", \\\"{x:1354,y:982,t:1527190076878};\\\", \\\"{x:1365,y:982,t:1527190076895};\\\", \\\"{x:1373,y:982,t:1527190076911};\\\", \\\"{x:1387,y:982,t:1527190076928};\\\", \\\"{x:1400,y:981,t:1527190076946};\\\", \\\"{x:1417,y:981,t:1527190076961};\\\", \\\"{x:1428,y:981,t:1527190076978};\\\", \\\"{x:1433,y:980,t:1527190076995};\\\", \\\"{x:1439,y:980,t:1527190077011};\\\", \\\"{x:1449,y:980,t:1527190077028};\\\", \\\"{x:1463,y:980,t:1527190077046};\\\", \\\"{x:1474,y:980,t:1527190077062};\\\", \\\"{x:1477,y:980,t:1527190077078};\\\", \\\"{x:1483,y:980,t:1527190077095};\\\", \\\"{x:1487,y:980,t:1527190077111};\\\", \\\"{x:1492,y:980,t:1527190077128};\\\", \\\"{x:1497,y:980,t:1527190077145};\\\", \\\"{x:1501,y:980,t:1527190077161};\\\", \\\"{x:1503,y:980,t:1527190077178};\\\", \\\"{x:1504,y:980,t:1527190077195};\\\", \\\"{x:1505,y:980,t:1527190077254};\\\", \\\"{x:1507,y:980,t:1527190077262};\\\", \\\"{x:1512,y:980,t:1527190077278};\\\", \\\"{x:1521,y:980,t:1527190077295};\\\", \\\"{x:1532,y:977,t:1527190077312};\\\", \\\"{x:1534,y:976,t:1527190077329};\\\", \\\"{x:1548,y:976,t:1527190077345};\\\", \\\"{x:1553,y:974,t:1527190077362};\\\", \\\"{x:1556,y:974,t:1527190077378};\\\", \\\"{x:1557,y:973,t:1527190077478};\\\", \\\"{x:1556,y:973,t:1527190077597};\\\", \\\"{x:1554,y:973,t:1527190077611};\\\", \\\"{x:1552,y:973,t:1527190077629};\\\", \\\"{x:1551,y:973,t:1527190077644};\\\", \\\"{x:1550,y:973,t:1527190077685};\\\", \\\"{x:1549,y:973,t:1527190077862};\\\", \\\"{x:1549,y:972,t:1527190077894};\\\", \\\"{x:1549,y:971,t:1527190077917};\\\", \\\"{x:1549,y:969,t:1527190077933};\\\", \\\"{x:1549,y:968,t:1527190077949};\\\", \\\"{x:1549,y:967,t:1527190077962};\\\", \\\"{x:1549,y:962,t:1527190077979};\\\", \\\"{x:1549,y:960,t:1527190077995};\\\", \\\"{x:1549,y:957,t:1527190078012};\\\", \\\"{x:1549,y:955,t:1527190078222};\\\", \\\"{x:1548,y:954,t:1527190078246};\\\", \\\"{x:1547,y:953,t:1527190078262};\\\", \\\"{x:1547,y:951,t:1527190078279};\\\", \\\"{x:1546,y:950,t:1527190078334};\\\", \\\"{x:1545,y:949,t:1527190078358};\\\", \\\"{x:1545,y:948,t:1527190078381};\\\", \\\"{x:1544,y:947,t:1527190078405};\\\", \\\"{x:1544,y:946,t:1527190078421};\\\", \\\"{x:1544,y:945,t:1527190078429};\\\", \\\"{x:1544,y:943,t:1527190078454};\\\", \\\"{x:1544,y:942,t:1527190078469};\\\", \\\"{x:1543,y:942,t:1527190078494};\\\", \\\"{x:1543,y:941,t:1527190078853};\\\", \\\"{x:1543,y:940,t:1527190078868};\\\", \\\"{x:1543,y:939,t:1527190078878};\\\", \\\"{x:1543,y:938,t:1527190078895};\\\", \\\"{x:1543,y:935,t:1527190078913};\\\", \\\"{x:1543,y:933,t:1527190078929};\\\", \\\"{x:1543,y:932,t:1527190078946};\\\", \\\"{x:1543,y:930,t:1527190078963};\\\", \\\"{x:1543,y:929,t:1527190079013};\\\", \\\"{x:1543,y:926,t:1527190079037};\\\", \\\"{x:1543,y:925,t:1527190079061};\\\", \\\"{x:1543,y:924,t:1527190079077};\\\", \\\"{x:1543,y:923,t:1527190079102};\\\", \\\"{x:1543,y:922,t:1527190079125};\\\", \\\"{x:1543,y:921,t:1527190079134};\\\", \\\"{x:1543,y:920,t:1527190079146};\\\", \\\"{x:1543,y:919,t:1527190079163};\\\", \\\"{x:1543,y:917,t:1527190079181};\\\", \\\"{x:1543,y:916,t:1527190079197};\\\", \\\"{x:1543,y:915,t:1527190079213};\\\", \\\"{x:1543,y:914,t:1527190079230};\\\", \\\"{x:1543,y:912,t:1527190079246};\\\", \\\"{x:1543,y:911,t:1527190079263};\\\", \\\"{x:1543,y:910,t:1527190079326};\\\", \\\"{x:1542,y:909,t:1527190079349};\\\", \\\"{x:1541,y:907,t:1527190079365};\\\", \\\"{x:1540,y:907,t:1527190079614};\\\", \\\"{x:1538,y:908,t:1527190079630};\\\", \\\"{x:1537,y:912,t:1527190079647};\\\", \\\"{x:1536,y:916,t:1527190079664};\\\", \\\"{x:1535,y:920,t:1527190079680};\\\", \\\"{x:1535,y:925,t:1527190079697};\\\", \\\"{x:1534,y:926,t:1527190079714};\\\", \\\"{x:1534,y:929,t:1527190079730};\\\", \\\"{x:1534,y:933,t:1527190079748};\\\", \\\"{x:1533,y:940,t:1527190079763};\\\", \\\"{x:1532,y:946,t:1527190079780};\\\", \\\"{x:1531,y:955,t:1527190079797};\\\", \\\"{x:1531,y:957,t:1527190079813};\\\", \\\"{x:1531,y:959,t:1527190079829};\\\", \\\"{x:1531,y:960,t:1527190079847};\\\", \\\"{x:1531,y:961,t:1527190079998};\\\", \\\"{x:1532,y:958,t:1527190080013};\\\", \\\"{x:1532,y:950,t:1527190080030};\\\", \\\"{x:1533,y:942,t:1527190080047};\\\", \\\"{x:1534,y:934,t:1527190080063};\\\", \\\"{x:1534,y:928,t:1527190080080};\\\", \\\"{x:1536,y:924,t:1527190080101};\\\", \\\"{x:1536,y:921,t:1527190080117};\\\", \\\"{x:1536,y:917,t:1527190080134};\\\", \\\"{x:1536,y:916,t:1527190080153};\\\", \\\"{x:1536,y:914,t:1527190080168};\\\", \\\"{x:1535,y:913,t:1527190080184};\\\", \\\"{x:1535,y:911,t:1527190080201};\\\", \\\"{x:1535,y:909,t:1527190080233};\\\", \\\"{x:1535,y:907,t:1527190080251};\\\", \\\"{x:1535,y:905,t:1527190080268};\\\", \\\"{x:1534,y:902,t:1527190080284};\\\", \\\"{x:1532,y:900,t:1527190080301};\\\", \\\"{x:1532,y:897,t:1527190080318};\\\", \\\"{x:1532,y:896,t:1527190080335};\\\", \\\"{x:1532,y:895,t:1527190080378};\\\", \\\"{x:1532,y:894,t:1527190081529};\\\", \\\"{x:1532,y:892,t:1527190081537};\\\", \\\"{x:1532,y:890,t:1527190081552};\\\", \\\"{x:1532,y:883,t:1527190081569};\\\", \\\"{x:1532,y:879,t:1527190081585};\\\", \\\"{x:1532,y:875,t:1527190081603};\\\", \\\"{x:1532,y:872,t:1527190081619};\\\", \\\"{x:1532,y:864,t:1527190081636};\\\", \\\"{x:1532,y:860,t:1527190081652};\\\", \\\"{x:1530,y:856,t:1527190081669};\\\", \\\"{x:1530,y:854,t:1527190081689};\\\", \\\"{x:1530,y:851,t:1527190081702};\\\", \\\"{x:1530,y:842,t:1527190081719};\\\", \\\"{x:1530,y:834,t:1527190081735};\\\", \\\"{x:1531,y:823,t:1527190081752};\\\", \\\"{x:1532,y:820,t:1527190081769};\\\", \\\"{x:1533,y:820,t:1527190081786};\\\", \\\"{x:1533,y:816,t:1527190081803};\\\", \\\"{x:1535,y:810,t:1527190081819};\\\", \\\"{x:1535,y:807,t:1527190081835};\\\", \\\"{x:1535,y:804,t:1527190081853};\\\", \\\"{x:1535,y:798,t:1527190081869};\\\", \\\"{x:1535,y:794,t:1527190081885};\\\", \\\"{x:1535,y:791,t:1527190081902};\\\", \\\"{x:1535,y:788,t:1527190081919};\\\", \\\"{x:1535,y:785,t:1527190081935};\\\", \\\"{x:1535,y:783,t:1527190081952};\\\", \\\"{x:1535,y:781,t:1527190081969};\\\", \\\"{x:1535,y:779,t:1527190081985};\\\", \\\"{x:1535,y:778,t:1527190082025};\\\", \\\"{x:1534,y:777,t:1527190082049};\\\", \\\"{x:1534,y:776,t:1527190082057};\\\", \\\"{x:1533,y:775,t:1527190082089};\\\", \\\"{x:1532,y:774,t:1527190082105};\\\", \\\"{x:1531,y:773,t:1527190082119};\\\", \\\"{x:1531,y:772,t:1527190082136};\\\", \\\"{x:1530,y:771,t:1527190082152};\\\", \\\"{x:1527,y:768,t:1527190082169};\\\", \\\"{x:1521,y:765,t:1527190082186};\\\", \\\"{x:1519,y:763,t:1527190082205};\\\", \\\"{x:1517,y:760,t:1527190082219};\\\", \\\"{x:1516,y:760,t:1527190082235};\\\", \\\"{x:1515,y:759,t:1527190082255};\\\", \\\"{x:1514,y:758,t:1527190082272};\\\", \\\"{x:1514,y:759,t:1527190089360};\\\", \\\"{x:1513,y:761,t:1527190089376};\\\", \\\"{x:1513,y:764,t:1527190089391};\\\", \\\"{x:1513,y:766,t:1527190089407};\\\", \\\"{x:1513,y:769,t:1527190089426};\\\", \\\"{x:1513,y:772,t:1527190089441};\\\", \\\"{x:1513,y:775,t:1527190089458};\\\", \\\"{x:1513,y:781,t:1527190089474};\\\", \\\"{x:1513,y:785,t:1527190089491};\\\", \\\"{x:1513,y:792,t:1527190089507};\\\", \\\"{x:1513,y:802,t:1527190089524};\\\", \\\"{x:1513,y:810,t:1527190089541};\\\", \\\"{x:1514,y:826,t:1527190089557};\\\", \\\"{x:1515,y:844,t:1527190089575};\\\", \\\"{x:1517,y:865,t:1527190089591};\\\", \\\"{x:1523,y:879,t:1527190089608};\\\", \\\"{x:1523,y:899,t:1527190089625};\\\", \\\"{x:1528,y:914,t:1527190089641};\\\", \\\"{x:1533,y:933,t:1527190089659};\\\", \\\"{x:1540,y:946,t:1527190089675};\\\", \\\"{x:1545,y:954,t:1527190089692};\\\", \\\"{x:1549,y:959,t:1527190089708};\\\", \\\"{x:1554,y:965,t:1527190089724};\\\", \\\"{x:1560,y:970,t:1527190089742};\\\", \\\"{x:1566,y:974,t:1527190089758};\\\", \\\"{x:1571,y:978,t:1527190089775};\\\", \\\"{x:1578,y:980,t:1527190089791};\\\", \\\"{x:1581,y:981,t:1527190089809};\\\", \\\"{x:1580,y:981,t:1527190089961};\\\", \\\"{x:1577,y:981,t:1527190089977};\\\", \\\"{x:1575,y:981,t:1527190089992};\\\", \\\"{x:1573,y:980,t:1527190090008};\\\", \\\"{x:1571,y:979,t:1527190090024};\\\", \\\"{x:1570,y:979,t:1527190090049};\\\", \\\"{x:1570,y:978,t:1527190090073};\\\", \\\"{x:1569,y:978,t:1527190090113};\\\", \\\"{x:1568,y:977,t:1527190090125};\\\", \\\"{x:1565,y:976,t:1527190090141};\\\", \\\"{x:1564,y:976,t:1527190090158};\\\", \\\"{x:1562,y:975,t:1527190090175};\\\", \\\"{x:1560,y:974,t:1527190090191};\\\", \\\"{x:1558,y:974,t:1527190090208};\\\", \\\"{x:1557,y:974,t:1527190090225};\\\", \\\"{x:1556,y:973,t:1527190090241};\\\", \\\"{x:1554,y:973,t:1527190090259};\\\", \\\"{x:1553,y:972,t:1527190090275};\\\", \\\"{x:1549,y:971,t:1527190090291};\\\", \\\"{x:1548,y:971,t:1527190090313};\\\", \\\"{x:1547,y:971,t:1527190090345};\\\", \\\"{x:1547,y:970,t:1527190090358};\\\", \\\"{x:1546,y:970,t:1527190090393};\\\", \\\"{x:1545,y:970,t:1527190090408};\\\", \\\"{x:1544,y:970,t:1527190090473};\\\", \\\"{x:1544,y:969,t:1527190090553};\\\", \\\"{x:1544,y:967,t:1527190090569};\\\", \\\"{x:1544,y:965,t:1527190090577};\\\", \\\"{x:1543,y:964,t:1527190090593};\\\", \\\"{x:1543,y:961,t:1527190090609};\\\", \\\"{x:1543,y:959,t:1527190090633};\\\", \\\"{x:1543,y:958,t:1527190090665};\\\", \\\"{x:1543,y:957,t:1527190090689};\\\", \\\"{x:1543,y:956,t:1527190090705};\\\", \\\"{x:1543,y:955,t:1527190090713};\\\", \\\"{x:1543,y:953,t:1527190090737};\\\", \\\"{x:1543,y:952,t:1527190090753};\\\", \\\"{x:1544,y:951,t:1527190090760};\\\", \\\"{x:1545,y:950,t:1527190090776};\\\", \\\"{x:1546,y:945,t:1527190090793};\\\", \\\"{x:1547,y:941,t:1527190090809};\\\", \\\"{x:1548,y:935,t:1527190090825};\\\", \\\"{x:1549,y:930,t:1527190090843};\\\", \\\"{x:1550,y:925,t:1527190090859};\\\", \\\"{x:1552,y:921,t:1527190090875};\\\", \\\"{x:1552,y:918,t:1527190090892};\\\", \\\"{x:1552,y:912,t:1527190090908};\\\", \\\"{x:1556,y:906,t:1527190090926};\\\", \\\"{x:1557,y:900,t:1527190090943};\\\", \\\"{x:1558,y:897,t:1527190090959};\\\", \\\"{x:1559,y:894,t:1527190090975};\\\", \\\"{x:1560,y:890,t:1527190090993};\\\", \\\"{x:1561,y:887,t:1527190091009};\\\", \\\"{x:1561,y:886,t:1527190091025};\\\", \\\"{x:1561,y:882,t:1527190091043};\\\", \\\"{x:1562,y:878,t:1527190091059};\\\", \\\"{x:1563,y:874,t:1527190091075};\\\", \\\"{x:1564,y:871,t:1527190091092};\\\", \\\"{x:1564,y:867,t:1527190091110};\\\", \\\"{x:1564,y:865,t:1527190091125};\\\", \\\"{x:1564,y:862,t:1527190091142};\\\", \\\"{x:1564,y:858,t:1527190091160};\\\", \\\"{x:1564,y:855,t:1527190091175};\\\", \\\"{x:1563,y:851,t:1527190091193};\\\", \\\"{x:1563,y:847,t:1527190091209};\\\", \\\"{x:1563,y:845,t:1527190091225};\\\", \\\"{x:1563,y:842,t:1527190091242};\\\", \\\"{x:1562,y:840,t:1527190091260};\\\", \\\"{x:1562,y:838,t:1527190091275};\\\", \\\"{x:1561,y:835,t:1527190091292};\\\", \\\"{x:1561,y:834,t:1527190091310};\\\", \\\"{x:1560,y:830,t:1527190091326};\\\", \\\"{x:1560,y:828,t:1527190091343};\\\", \\\"{x:1560,y:827,t:1527190091360};\\\", \\\"{x:1559,y:825,t:1527190091375};\\\", \\\"{x:1558,y:823,t:1527190091393};\\\", \\\"{x:1558,y:822,t:1527190091417};\\\", \\\"{x:1556,y:819,t:1527190091425};\\\", \\\"{x:1556,y:818,t:1527190091442};\\\", \\\"{x:1556,y:816,t:1527190091460};\\\", \\\"{x:1556,y:814,t:1527190091475};\\\", \\\"{x:1556,y:810,t:1527190091493};\\\", \\\"{x:1556,y:805,t:1527190091509};\\\", \\\"{x:1555,y:801,t:1527190091526};\\\", \\\"{x:1555,y:800,t:1527190091544};\\\", \\\"{x:1554,y:799,t:1527190091561};\\\", \\\"{x:1554,y:797,t:1527190091585};\\\", \\\"{x:1554,y:796,t:1527190091593};\\\", \\\"{x:1554,y:795,t:1527190091609};\\\", \\\"{x:1554,y:794,t:1527190091632};\\\", \\\"{x:1554,y:793,t:1527190091648};\\\", \\\"{x:1554,y:792,t:1527190091680};\\\", \\\"{x:1554,y:791,t:1527190091696};\\\", \\\"{x:1554,y:790,t:1527190091709};\\\", \\\"{x:1554,y:789,t:1527190091728};\\\", \\\"{x:1554,y:788,t:1527190091760};\\\", \\\"{x:1554,y:787,t:1527190091776};\\\", \\\"{x:1554,y:785,t:1527190091792};\\\", \\\"{x:1554,y:784,t:1527190091809};\\\", \\\"{x:1554,y:782,t:1527190091826};\\\", \\\"{x:1554,y:780,t:1527190091843};\\\", \\\"{x:1554,y:779,t:1527190091859};\\\", \\\"{x:1554,y:778,t:1527190091876};\\\", \\\"{x:1554,y:777,t:1527190091897};\\\", \\\"{x:1554,y:776,t:1527190091909};\\\", \\\"{x:1554,y:775,t:1527190091926};\\\", \\\"{x:1554,y:773,t:1527190091942};\\\", \\\"{x:1554,y:772,t:1527190091959};\\\", \\\"{x:1553,y:771,t:1527190091976};\\\", \\\"{x:1553,y:769,t:1527190092009};\\\", \\\"{x:1551,y:768,t:1527190092041};\\\", \\\"{x:1550,y:767,t:1527190092057};\\\", \\\"{x:1550,y:766,t:1527190092065};\\\", \\\"{x:1549,y:765,t:1527190092089};\\\", \\\"{x:1548,y:763,t:1527190092130};\\\", \\\"{x:1547,y:763,t:1527190103103};\\\", \\\"{x:1544,y:763,t:1527190103117};\\\", \\\"{x:1528,y:770,t:1527190103134};\\\", \\\"{x:1459,y:789,t:1527190103150};\\\", \\\"{x:1331,y:805,t:1527190103167};\\\", \\\"{x:1107,y:825,t:1527190103184};\\\", \\\"{x:991,y:825,t:1527190103201};\\\", \\\"{x:903,y:814,t:1527190103218};\\\", \\\"{x:884,y:810,t:1527190103234};\\\", \\\"{x:819,y:805,t:1527190103250};\\\", \\\"{x:764,y:790,t:1527190103267};\\\", \\\"{x:704,y:759,t:1527190103284};\\\", \\\"{x:654,y:726,t:1527190103300};\\\", \\\"{x:616,y:702,t:1527190103318};\\\", \\\"{x:598,y:690,t:1527190103335};\\\", \\\"{x:587,y:678,t:1527190103350};\\\", \\\"{x:568,y:664,t:1527190103367};\\\", \\\"{x:549,y:645,t:1527190103384};\\\", \\\"{x:533,y:629,t:1527190103402};\\\", \\\"{x:504,y:607,t:1527190103417};\\\", \\\"{x:473,y:587,t:1527190103434};\\\", \\\"{x:453,y:577,t:1527190103452};\\\", \\\"{x:438,y:570,t:1527190103469};\\\", \\\"{x:423,y:566,t:1527190103486};\\\", \\\"{x:417,y:559,t:1527190103502};\\\", \\\"{x:402,y:555,t:1527190103520};\\\", \\\"{x:376,y:555,t:1527190103536};\\\", \\\"{x:354,y:554,t:1527190103553};\\\", \\\"{x:332,y:554,t:1527190103571};\\\", \\\"{x:320,y:554,t:1527190103587};\\\", \\\"{x:308,y:554,t:1527190103604};\\\", \\\"{x:299,y:554,t:1527190103620};\\\", \\\"{x:284,y:556,t:1527190103637};\\\", \\\"{x:263,y:562,t:1527190103653};\\\", \\\"{x:245,y:569,t:1527190103671};\\\", \\\"{x:234,y:570,t:1527190103686};\\\", \\\"{x:226,y:572,t:1527190103703};\\\", \\\"{x:225,y:572,t:1527190103928};\\\", \\\"{x:224,y:572,t:1527190103937};\\\", \\\"{x:222,y:572,t:1527190103953};\\\", \\\"{x:217,y:572,t:1527190103971};\\\", \\\"{x:212,y:572,t:1527190103987};\\\", \\\"{x:208,y:569,t:1527190104003};\\\", \\\"{x:205,y:568,t:1527190104020};\\\", \\\"{x:201,y:564,t:1527190104037};\\\", \\\"{x:197,y:562,t:1527190104054};\\\", \\\"{x:189,y:559,t:1527190104070};\\\", \\\"{x:188,y:559,t:1527190104096};\\\", \\\"{x:187,y:559,t:1527190104144};\\\", \\\"{x:186,y:559,t:1527190104176};\\\", \\\"{x:185,y:559,t:1527190104192};\\\", \\\"{x:183,y:557,t:1527190104204};\\\", \\\"{x:181,y:557,t:1527190104221};\\\", \\\"{x:179,y:555,t:1527190104238};\\\", \\\"{x:175,y:550,t:1527190104254};\\\", \\\"{x:175,y:549,t:1527190104271};\\\", \\\"{x:176,y:550,t:1527190104880};\\\", \\\"{x:177,y:551,t:1527190104887};\\\", \\\"{x:186,y:557,t:1527190104904};\\\", \\\"{x:201,y:563,t:1527190104922};\\\", \\\"{x:222,y:572,t:1527190104937};\\\", \\\"{x:236,y:578,t:1527190104954};\\\", \\\"{x:255,y:585,t:1527190104971};\\\", \\\"{x:268,y:600,t:1527190104987};\\\", \\\"{x:294,y:622,t:1527190105005};\\\", \\\"{x:339,y:655,t:1527190105022};\\\", \\\"{x:391,y:700,t:1527190105038};\\\", \\\"{x:449,y:747,t:1527190105054};\\\", \\\"{x:538,y:823,t:1527190105072};\\\", \\\"{x:583,y:863,t:1527190105087};\\\", \\\"{x:643,y:916,t:1527190105104};\\\", \\\"{x:679,y:939,t:1527190105121};\\\", \\\"{x:689,y:942,t:1527190105139};\\\", \\\"{x:692,y:944,t:1527190106335};\\\", \\\"{x:694,y:945,t:1527190106344};\\\", \\\"{x:698,y:947,t:1527190106359};\\\", \\\"{x:716,y:954,t:1527190106375};\\\", \\\"{x:720,y:955,t:1527190106391};\\\", \\\"{x:722,y:955,t:1527190106447};\\\", \\\"{x:721,y:950,t:1527190106487};\\\", \\\"{x:713,y:944,t:1527190106496};\\\", \\\"{x:706,y:936,t:1527190106509};\\\", \\\"{x:690,y:917,t:1527190106525};\\\", \\\"{x:673,y:898,t:1527190106542};\\\", \\\"{x:652,y:865,t:1527190106560};\\\", \\\"{x:623,y:833,t:1527190106576};\\\", \\\"{x:597,y:806,t:1527190106593};\\\", \\\"{x:566,y:777,t:1527190106610};\\\", \\\"{x:549,y:761,t:1527190106627};\\\", \\\"{x:531,y:750,t:1527190106643};\\\", \\\"{x:519,y:744,t:1527190106659};\\\", \\\"{x:517,y:742,t:1527190106676};\\\" ] }, { \\\"rt\\\": 66204, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 753797, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"F98S2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:516,y:739,t:1527190109488};\\\", \\\"{x:518,y:714,t:1527190109497};\\\", \\\"{x:519,y:688,t:1527190109509};\\\", \\\"{x:519,y:649,t:1527190109524};\\\", \\\"{x:531,y:615,t:1527190109542};\\\", \\\"{x:532,y:590,t:1527190109558};\\\", \\\"{x:530,y:565,t:1527190109575};\\\", \\\"{x:523,y:537,t:1527190109592};\\\", \\\"{x:519,y:526,t:1527190109609};\\\", \\\"{x:518,y:521,t:1527190109625};\\\", \\\"{x:517,y:520,t:1527190109642};\\\", \\\"{x:515,y:518,t:1527190109680};\\\", \\\"{x:514,y:516,t:1527190109692};\\\", \\\"{x:513,y:514,t:1527190109707};\\\", \\\"{x:511,y:511,t:1527190109725};\\\", \\\"{x:509,y:509,t:1527190109742};\\\", \\\"{x:508,y:509,t:1527190109760};\\\", \\\"{x:507,y:509,t:1527190109784};\\\", \\\"{x:505,y:509,t:1527190109792};\\\", \\\"{x:504,y:507,t:1527190109808};\\\", \\\"{x:502,y:506,t:1527190109856};\\\", \\\"{x:501,y:505,t:1527190109864};\\\", \\\"{x:500,y:505,t:1527190109875};\\\", \\\"{x:499,y:505,t:1527190109891};\\\", \\\"{x:499,y:504,t:1527190109908};\\\", \\\"{x:497,y:504,t:1527190109927};\\\", \\\"{x:497,y:503,t:1527190110200};\\\", \\\"{x:497,y:501,t:1527190110216};\\\", \\\"{x:497,y:500,t:1527190110227};\\\", \\\"{x:498,y:498,t:1527190110264};\\\", \\\"{x:498,y:497,t:1527190110304};\\\", \\\"{x:498,y:495,t:1527190110337};\\\", \\\"{x:498,y:493,t:1527190110376};\\\", \\\"{x:496,y:493,t:1527190113144};\\\", \\\"{x:495,y:495,t:1527190113161};\\\", \\\"{x:494,y:496,t:1527190113177};\\\", \\\"{x:492,y:498,t:1527190113194};\\\", \\\"{x:492,y:499,t:1527190113312};\\\", \\\"{x:492,y:502,t:1527190138410};\\\", \\\"{x:492,y:517,t:1527190138428};\\\", \\\"{x:496,y:530,t:1527190138445};\\\", \\\"{x:518,y:546,t:1527190138465};\\\", \\\"{x:540,y:553,t:1527190138482};\\\", \\\"{x:562,y:558,t:1527190138498};\\\", \\\"{x:591,y:558,t:1527190138515};\\\", \\\"{x:607,y:559,t:1527190138532};\\\", \\\"{x:618,y:559,t:1527190138549};\\\", \\\"{x:623,y:559,t:1527190138565};\\\", \\\"{x:625,y:559,t:1527190138582};\\\", \\\"{x:625,y:558,t:1527190138768};\\\", \\\"{x:625,y:556,t:1527190138782};\\\", \\\"{x:624,y:555,t:1527190138798};\\\", \\\"{x:622,y:554,t:1527190138815};\\\", \\\"{x:622,y:553,t:1527190138832};\\\", \\\"{x:620,y:552,t:1527190138848};\\\", \\\"{x:614,y:553,t:1527190138865};\\\", \\\"{x:610,y:555,t:1527190138882};\\\", \\\"{x:609,y:555,t:1527190138899};\\\", \\\"{x:613,y:555,t:1527190138960};\\\", \\\"{x:625,y:549,t:1527190138969};\\\", \\\"{x:640,y:548,t:1527190138982};\\\", \\\"{x:682,y:541,t:1527190139000};\\\", \\\"{x:745,y:528,t:1527190139016};\\\", \\\"{x:774,y:527,t:1527190139033};\\\", \\\"{x:800,y:527,t:1527190139049};\\\", \\\"{x:818,y:527,t:1527190139066};\\\", \\\"{x:834,y:527,t:1527190139082};\\\", \\\"{x:842,y:527,t:1527190139099};\\\", \\\"{x:843,y:527,t:1527190139117};\\\", \\\"{x:837,y:527,t:1527190172796};\\\", \\\"{x:761,y:540,t:1527190172815};\\\", \\\"{x:670,y:562,t:1527190172830};\\\", \\\"{x:617,y:568,t:1527190172846};\\\", \\\"{x:586,y:566,t:1527190172862};\\\", \\\"{x:567,y:561,t:1527190172879};\\\", \\\"{x:562,y:558,t:1527190172896};\\\", \\\"{x:562,y:557,t:1527190172978};\\\", \\\"{x:563,y:554,t:1527190172986};\\\", \\\"{x:564,y:553,t:1527190172996};\\\", \\\"{x:574,y:543,t:1527190173013};\\\", \\\"{x:585,y:537,t:1527190173031};\\\", \\\"{x:598,y:532,t:1527190173045};\\\", \\\"{x:617,y:523,t:1527190173063};\\\", \\\"{x:632,y:515,t:1527190173080};\\\", \\\"{x:634,y:513,t:1527190173096};\\\", \\\"{x:634,y:512,t:1527190173275};\\\", \\\"{x:633,y:512,t:1527190173283};\\\", \\\"{x:629,y:509,t:1527190173297};\\\", \\\"{x:627,y:509,t:1527190173314};\\\", \\\"{x:623,y:509,t:1527190173330};\\\", \\\"{x:623,y:508,t:1527190173347};\\\", \\\"{x:622,y:508,t:1527190173370};\\\", \\\"{x:618,y:508,t:1527190173613};\\\", \\\"{x:609,y:520,t:1527190173630};\\\", \\\"{x:598,y:536,t:1527190173646};\\\", \\\"{x:587,y:559,t:1527190173663};\\\", \\\"{x:577,y:577,t:1527190173681};\\\", \\\"{x:563,y:597,t:1527190173698};\\\", \\\"{x:549,y:615,t:1527190173714};\\\", \\\"{x:526,y:643,t:1527190173730};\\\", \\\"{x:516,y:662,t:1527190173747};\\\", \\\"{x:506,y:678,t:1527190173763};\\\", \\\"{x:494,y:698,t:1527190173781};\\\", \\\"{x:482,y:720,t:1527190173798};\\\", \\\"{x:475,y:733,t:1527190173813};\\\", \\\"{x:474,y:744,t:1527190173831};\\\", \\\"{x:473,y:750,t:1527190173848};\\\", \\\"{x:473,y:755,t:1527190173864};\\\", \\\"{x:476,y:759,t:1527190173880};\\\", \\\"{x:476,y:761,t:1527190173897};\\\", \\\"{x:480,y:764,t:1527190173914};\\\", \\\"{x:481,y:765,t:1527190173931};\\\", \\\"{x:482,y:766,t:1527190173947};\\\", \\\"{x:484,y:767,t:1527190173970};\\\", \\\"{x:485,y:768,t:1527190173981};\\\", \\\"{x:486,y:769,t:1527190173999};\\\", \\\"{x:487,y:769,t:1527190174026};\\\", \\\"{x:488,y:769,t:1527190174163};\\\", \\\"{x:489,y:768,t:1527190174188};\\\", \\\"{x:489,y:765,t:1527190174202};\\\", \\\"{x:489,y:762,t:1527190174214};\\\", \\\"{x:490,y:756,t:1527190174231};\\\", \\\"{x:490,y:754,t:1527190174247};\\\" ] }, { \\\"rt\\\": 52087, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 807411, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"F98S2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"i personally find 12pm on the x-axis and drag my finger upward. whichever shift overlaps i note down.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 9568, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"22\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"the united states\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 817986, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"F98S2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 17287, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fourth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 836292, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"F98S2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 18047, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 855666, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"F98S2\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" } ]\",\"parentNode\":{\"id\":2773}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"F98S2\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"line\",\"attributes\":{\"x1\":\"400\",\"x2\":\"0\",\"y1\":\"0\",\"y2\":\"800\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-65) translate(-200,280)\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2412,\"textContent\":\"DURATION (in hours)\"}]}]},{\"nodeType\":1,\"id\":2413,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2414,\"tagName\":\"text\",\"attributes\":{\"x\":\"-1.6666666666666714\",\"y\":\"738.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2415,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2416,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2417,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"33.33333333333333\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"text\",\"attributes\":{\"x\":\"31.666666666666657\",\"y\":\"671.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2420,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2421,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2422,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"66.66666666666666\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"x\":\"65\",\"y\":\"605\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"100\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2429,\"tagName\":\"text\",\"attributes\":{\"x\":\"98.33333333333331\",\"y\":\"538.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2430,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2432,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"133.33333333333331\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2434,\"tagName\":\"text\",\"attributes\":{\"x\":\"131.66666666666669\",\"y\":\"471.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2435,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2436,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2437,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"166.66666666666669\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"text\",\"attributes\":{\"x\":\"165\",\"y\":\"405\"},\"childNodes\":[{\"nodeType\":3,\"id\":2440,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2441,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2442,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"200\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2443,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"x\":\"198.33333333333334\",\"y\":\"338.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"233.33333333333334\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2448,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2449,\"tagName\":\"text\",\"attributes\":{\"x\":\"231.66666666666663\",\"y\":\"271.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2450,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2451,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2452,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"266.66666666666663\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2453,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2454,\"tagName\":\"text\",\"attributes\":{\"x\":\"265\",\"y\":\"205\"},\"childNodes\":[{\"nodeType\":3,\"id\":2455,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2456,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2457,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"300\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"text\",\"attributes\":{\"x\":\"298.33333333333337\",\"y\":\"138.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2460,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2461,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2462,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"333.33333333333337\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2463,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2464,\"tagName\":\"text\",\"attributes\":{\"x\":\"331.66666666666663\",\"y\":\"71.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2465,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"366.66666666666663\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"text\",\"attributes\":{\"x\":\"365\",\"y\":\"5\"},\"childNodes\":[{\"nodeType\":3,\"id\":2470,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2471,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2472,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2473,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2492,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2494,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2496,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2498,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2523,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2588,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2589,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2590,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2591,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2592,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2593,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2594,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2595,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2596,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2597,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2598},{\"nodeType\":3,\"id\":2599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2600,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2601,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2602,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2603,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 374, dom: 897, initialDom: 971",
  "javascriptErrors": []
}