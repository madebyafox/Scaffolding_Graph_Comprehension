var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0601047198ac54671b04d8692df2c6a26eb06234"] = {
  "startTime": "2018-06-01T18:20:04.7241593Z",
  "websitePageUrl": "/",
  "visitTime": 301995,
  "engagementTime": 56954,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "d8ad10d107696cbbafbc97a1cc4b0216",
    "created": "2018-06-01T18:20:04.6387332+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "67.0.3396.62",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "53c84ccf73ad6266238e99a0ffa8adc7",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/d8ad10d107696cbbafbc97a1cc4b0216/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 365,
      "e": 365,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 10002,
      "e": 5101,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30752,
      "e": 5101,
      "ty": 41,
      "x": 10434,
      "y": 425,
      "ta": "html"
    },
    {
      "t": 30800,
      "e": 5149,
      "ty": 2,
      "x": 303,
      "y": 7
    },
    {
      "t": 31101,
      "e": 5450,
      "ty": 2,
      "x": 303,
      "y": 10
    },
    {
      "t": 31201,
      "e": 5550,
      "ty": 2,
      "x": 772,
      "y": 408
    },
    {
      "t": 31250,
      "e": 5599,
      "ty": 41,
      "x": 29954,
      "y": 34610,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 31301,
      "e": 5650,
      "ty": 2,
      "x": 931,
      "y": 603
    },
    {
      "t": 31401,
      "e": 5750,
      "ty": 2,
      "x": 931,
      "y": 620
    },
    {
      "t": 31501,
      "e": 5850,
      "ty": 2,
      "x": 956,
      "y": 694
    },
    {
      "t": 31501,
      "e": 5850,
      "ty": 41,
      "x": 32576,
      "y": 44850,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 31601,
      "e": 5950,
      "ty": 2,
      "x": 979,
      "y": 737
    },
    {
      "t": 31701,
      "e": 6050,
      "ty": 2,
      "x": 999,
      "y": 758
    },
    {
      "t": 31751,
      "e": 6100,
      "ty": 41,
      "x": 34924,
      "y": 50502,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 31801,
      "e": 6150,
      "ty": 2,
      "x": 992,
      "y": 768
    },
    {
      "t": 31901,
      "e": 6250,
      "ty": 2,
      "x": 984,
      "y": 770
    },
    {
      "t": 32001,
      "e": 6350,
      "ty": 2,
      "x": 940,
      "y": 845
    },
    {
      "t": 32001,
      "e": 6350,
      "ty": 41,
      "x": 31702,
      "y": 57220,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 32101,
      "e": 6450,
      "ty": 2,
      "x": 924,
      "y": 859
    },
    {
      "t": 32251,
      "e": 6600,
      "ty": 41,
      "x": 30828,
      "y": 58367,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 32401,
      "e": 6750,
      "ty": 2,
      "x": 924,
      "y": 860
    },
    {
      "t": 32501,
      "e": 6850,
      "ty": 2,
      "x": 931,
      "y": 849
    },
    {
      "t": 32501,
      "e": 6850,
      "ty": 41,
      "x": 31211,
      "y": 57547,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 32601,
      "e": 6950,
      "ty": 2,
      "x": 938,
      "y": 836
    },
    {
      "t": 32701,
      "e": 7050,
      "ty": 2,
      "x": 944,
      "y": 828
    },
    {
      "t": 32751,
      "e": 7100,
      "ty": 41,
      "x": 32685,
      "y": 54353,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 32801,
      "e": 7150,
      "ty": 2,
      "x": 969,
      "y": 796
    },
    {
      "t": 33002,
      "e": 7351,
      "ty": 41,
      "x": 33286,
      "y": 53206,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 33201,
      "e": 7550,
      "ty": 2,
      "x": 1032,
      "y": 521
    },
    {
      "t": 33251,
      "e": 7600,
      "ty": 41,
      "x": 36945,
      "y": 23305,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 33301,
      "e": 7650,
      "ty": 2,
      "x": 1034,
      "y": 392
    },
    {
      "t": 33401,
      "e": 7750,
      "ty": 2,
      "x": 1027,
      "y": 348
    },
    {
      "t": 33501,
      "e": 7850,
      "ty": 2,
      "x": 1022,
      "y": 329
    },
    {
      "t": 33501,
      "e": 7850,
      "ty": 41,
      "x": 36180,
      "y": 14950,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 33601,
      "e": 7950,
      "ty": 2,
      "x": 1023,
      "y": 337
    },
    {
      "t": 33701,
      "e": 8050,
      "ty": 2,
      "x": 1131,
      "y": 594
    },
    {
      "t": 33751,
      "e": 8100,
      "ty": 41,
      "x": 42188,
      "y": 36740,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 33760,
      "e": 8109,
      "ty": 3,
      "x": 1132,
      "y": 595,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 33801,
      "e": 8150,
      "ty": 2,
      "x": 1132,
      "y": 595
    },
    {
      "t": 33823,
      "e": 8172,
      "ty": 4,
      "x": 42188,
      "y": 36740,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 33824,
      "e": 8173,
      "ty": 5,
      "x": 1132,
      "y": 595,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 34751,
      "e": 9100,
      "ty": 41,
      "x": 43116,
      "y": 36658,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 34801,
      "e": 9150,
      "ty": 2,
      "x": 1377,
      "y": 486
    },
    {
      "t": 34901,
      "e": 9250,
      "ty": 2,
      "x": 1837,
      "y": 13
    },
    {
      "t": 34967,
      "e": 9316,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 35001,
      "e": 9350,
      "ty": 2,
      "x": 1834,
      "y": 0
    },
    {
      "t": 35001,
      "e": 9350,
      "ty": 41,
      "x": 63158,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 35701,
      "e": 10050,
      "ty": 0,
      "x": 929,
      "y": 1047
    },
    {
      "t": 36201,
      "e": 10550,
      "ty": 2,
      "x": 790,
      "y": 26
    },
    {
      "t": 36222,
      "e": 10571,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 36251,
      "e": 10600,
      "ty": 41,
      "x": 56768,
      "y": 445,
      "ta": "html"
    },
    {
      "t": 36301,
      "e": 10650,
      "ty": 2,
      "x": 790,
      "y": 7
    },
    {
      "t": 37001,
      "e": 11350,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 38701,
      "e": 13050,
      "ty": 2,
      "x": 168,
      "y": 121
    },
    {
      "t": 38751,
      "e": 13100,
      "ty": 41,
      "x": 7300,
      "y": 11865,
      "ta": "html > body"
    },
    {
      "t": 38802,
      "e": 13151,
      "ty": 2,
      "x": 226,
      "y": 219
    },
    {
      "t": 38901,
      "e": 13250,
      "ty": 2,
      "x": 226,
      "y": 232
    },
    {
      "t": 39001,
      "e": 13350,
      "ty": 41,
      "x": 7507,
      "y": 13630,
      "ta": "html > body"
    },
    {
      "t": 39251,
      "e": 13600,
      "ty": 41,
      "x": 7507,
      "y": 14725,
      "ta": "html > body"
    },
    {
      "t": 39301,
      "e": 13650,
      "ty": 2,
      "x": 226,
      "y": 282
    },
    {
      "t": 39401,
      "e": 13750,
      "ty": 2,
      "x": 226,
      "y": 292
    },
    {
      "t": 39501,
      "e": 13850,
      "ty": 41,
      "x": 7507,
      "y": 17281,
      "ta": "html > body"
    },
    {
      "t": 40001,
      "e": 14350,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 41001,
      "e": 15350,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 41001,
      "e": 15350,
      "ty": 2,
      "x": 226,
      "y": 358
    },
    {
      "t": 41001,
      "e": 15350,
      "ty": 41,
      "x": 7507,
      "y": 19389,
      "ta": "html > body"
    },
    {
      "t": 46326,
      "e": 20350,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 47424,
      "e": 20350,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 50001,
      "e": 20350,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 144028,
      "e": 20350,
      "ty": 2,
      "x": 367,
      "y": 398
    },
    {
      "t": 144078,
      "e": 20400,
      "ty": 41,
      "x": 3618,
      "y": 10044,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 144428,
      "e": 20750,
      "ty": 2,
      "x": 414,
      "y": 465
    },
    {
      "t": 144528,
      "e": 20850,
      "ty": 2,
      "x": 610,
      "y": 682
    },
    {
      "t": 144578,
      "e": 20900,
      "ty": 41,
      "x": 19705,
      "y": 15922,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 144628,
      "e": 20950,
      "ty": 2,
      "x": 702,
      "y": 711
    },
    {
      "t": 144728,
      "e": 21050,
      "ty": 2,
      "x": 744,
      "y": 774
    },
    {
      "t": 144828,
      "e": 21150,
      "ty": 2,
      "x": 894,
      "y": 945
    },
    {
      "t": 144828,
      "e": 21150,
      "ty": 41,
      "x": 29545,
      "y": 56692,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 144928,
      "e": 21250,
      "ty": 2,
      "x": 892,
      "y": 955
    },
    {
      "t": 145028,
      "e": 21350,
      "ty": 2,
      "x": 843,
      "y": 929
    },
    {
      "t": 145079,
      "e": 21401,
      "ty": 41,
      "x": 6837,
      "y": 35792,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 145128,
      "e": 21450,
      "ty": 2,
      "x": 836,
      "y": 920
    },
    {
      "t": 145228,
      "e": 21550,
      "ty": 2,
      "x": 836,
      "y": 925
    },
    {
      "t": 145327,
      "e": 21649,
      "ty": 2,
      "x": 836,
      "y": 930
    },
    {
      "t": 145328,
      "e": 21650,
      "ty": 41,
      "x": 26691,
      "y": 56530,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 145428,
      "e": 21750,
      "ty": 2,
      "x": 820,
      "y": 922
    },
    {
      "t": 145456,
      "e": 21778,
      "ty": 3,
      "x": 820,
      "y": 922,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 145536,
      "e": 21858,
      "ty": 4,
      "x": 54271,
      "y": 36095,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 145536,
      "e": 21858,
      "ty": 5,
      "x": 820,
      "y": 922,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 145537,
      "e": 21859,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 145541,
      "e": 21863,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 145578,
      "e": 21900,
      "ty": 41,
      "x": 54271,
      "y": 36095,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 145728,
      "e": 22050,
      "ty": 2,
      "x": 872,
      "y": 982
    },
    {
      "t": 145828,
      "e": 22150,
      "ty": 2,
      "x": 893,
      "y": 1023
    },
    {
      "t": 145828,
      "e": 22150,
      "ty": 41,
      "x": 29495,
      "y": 62094,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 145928,
      "e": 22250,
      "ty": 2,
      "x": 898,
      "y": 1032
    },
    {
      "t": 146013,
      "e": 22335,
      "ty": 6,
      "x": 954,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 146028,
      "e": 22350,
      "ty": 2,
      "x": 954,
      "y": 1073
    },
    {
      "t": 146078,
      "e": 22400,
      "ty": 41,
      "x": 36863,
      "y": 23732,
      "ta": "#start"
    },
    {
      "t": 146128,
      "e": 22450,
      "ty": 2,
      "x": 977,
      "y": 1085
    },
    {
      "t": 146144,
      "e": 22466,
      "ty": 3,
      "x": 977,
      "y": 1085,
      "ta": "#start"
    },
    {
      "t": 146144,
      "e": 22466,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 146144,
      "e": 22466,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 146216,
      "e": 22538,
      "ty": 4,
      "x": 36863,
      "y": 23732,
      "ta": "#start"
    },
    {
      "t": 146216,
      "e": 22538,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 146217,
      "e": 22539,
      "ty": 5,
      "x": 977,
      "y": 1085,
      "ta": "#start"
    },
    {
      "t": 146218,
      "e": 22540,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 146528,
      "e": 22850,
      "ty": 2,
      "x": 973,
      "y": 1064
    },
    {
      "t": 146578,
      "e": 22900,
      "ty": 41,
      "x": 32750,
      "y": 55120,
      "ta": "html > body"
    },
    {
      "t": 146628,
      "e": 22950,
      "ty": 2,
      "x": 891,
      "y": 850
    },
    {
      "t": 146728,
      "e": 23050,
      "ty": 2,
      "x": 800,
      "y": 743
    },
    {
      "t": 146828,
      "e": 23150,
      "ty": 2,
      "x": 799,
      "y": 741
    },
    {
      "t": 146829,
      "e": 23151,
      "ty": 41,
      "x": 27240,
      "y": 40606,
      "ta": "html > body"
    },
    {
      "t": 147221,
      "e": 23543,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 148078,
      "e": 24400,
      "ty": 41,
      "x": 27240,
      "y": 40495,
      "ta": "html > body"
    },
    {
      "t": 148129,
      "e": 24451,
      "ty": 2,
      "x": 815,
      "y": 674
    },
    {
      "t": 148229,
      "e": 24551,
      "ty": 2,
      "x": 817,
      "y": 615
    },
    {
      "t": 148328,
      "e": 24650,
      "ty": 41,
      "x": 1946,
      "y": 0,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 148528,
      "e": 24850,
      "ty": 2,
      "x": 820,
      "y": 608
    },
    {
      "t": 148532,
      "e": 24854,
      "ty": 6,
      "x": 821,
      "y": 605,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 148578,
      "e": 24900,
      "ty": 41,
      "x": 2811,
      "y": 59293,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 148600,
      "e": 24922,
      "ty": 3,
      "x": 821,
      "y": 605,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 148601,
      "e": 24923,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 148628,
      "e": 24950,
      "ty": 2,
      "x": 821,
      "y": 605
    },
    {
      "t": 148680,
      "e": 25002,
      "ty": 4,
      "x": 2811,
      "y": 59293,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 148680,
      "e": 25002,
      "ty": 5,
      "x": 821,
      "y": 605,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 149828,
      "e": 26150,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 254204,
      "e": 30002,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 254306,
      "e": 30104,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": ""
    },
    {
      "t": 254979,
      "e": 30777,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "88"
    },
    {
      "t": 254980,
      "e": 30778,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 255042,
      "e": 30840,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "X"
    },
    {
      "t": 255171,
      "e": 30969,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 255171,
      "e": 30969,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 255234,
      "e": 31032,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "XR"
    },
    {
      "t": 255395,
      "e": 31193,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 255395,
      "e": 31193,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 255451,
      "e": 31249,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "XRA"
    },
    {
      "t": 256490,
      "e": 32288,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "89"
    },
    {
      "t": 256490,
      "e": 32288,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 256555,
      "e": 32353,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "XRAY"
    },
    {
      "t": 256851,
      "e": 32649,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 256852,
      "e": 32650,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "XRAY"
    },
    {
      "t": 256852,
      "e": 32650,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 256853,
      "e": 32651,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 256914,
      "e": 32712,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 258346,
      "e": 34144,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "51"
    },
    {
      "t": 258347,
      "e": 34145,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 258418,
      "e": 34216,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "3"
    },
    {
      "t": 258571,
      "e": 34369,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 258571,
      "e": 34369,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 258634,
      "e": 34432,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31"
    },
    {
      "t": 258683,
      "e": 34481,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 258688,
      "e": 34486,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 258737,
      "e": 34535,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31*"
    },
    {
      "t": 259708,
      "e": 35506,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 259922,
      "e": 35720,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "191"
    },
    {
      "t": 259923,
      "e": 35721,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 259978,
      "e": 35776,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31*\n"
    },
    {
      "t": 260115,
      "e": 35913,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31*\n"
    },
    {
      "t": 261037,
      "e": 36835,
      "ty": 7,
      "x": 847,
      "y": 585,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 261108,
      "e": 36906,
      "ty": 2,
      "x": 849,
      "y": 583
    },
    {
      "t": 261208,
      "e": 37006,
      "ty": 41,
      "x": 8867,
      "y": 42985,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 261515,
      "e": 37313,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "191"
    },
    {
      "t": 261562,
      "e": 37360,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31*"
    },
    {
      "t": 261887,
      "e": 37685,
      "ty": 6,
      "x": 967,
      "y": 586,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 261903,
      "e": 37701,
      "ty": 7,
      "x": 1105,
      "y": 548,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 261908,
      "e": 37706,
      "ty": 2,
      "x": 1105,
      "y": 548
    },
    {
      "t": 261958,
      "e": 37756,
      "ty": 41,
      "x": 42702,
      "y": 27698,
      "ta": "html > body"
    },
    {
      "t": 262007,
      "e": 37805,
      "ty": 2,
      "x": 1248,
      "y": 508
    },
    {
      "t": 262108,
      "e": 37906,
      "ty": 2,
      "x": 1200,
      "y": 507
    },
    {
      "t": 262208,
      "e": 38006,
      "ty": 2,
      "x": 1126,
      "y": 546
    },
    {
      "t": 262208,
      "e": 38006,
      "ty": 41,
      "x": 38501,
      "y": 29803,
      "ta": "html > body"
    },
    {
      "t": 262236,
      "e": 38034,
      "ty": 6,
      "x": 1069,
      "y": 590,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 262270,
      "e": 38068,
      "ty": 7,
      "x": 1042,
      "y": 627,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 262307,
      "e": 38105,
      "ty": 2,
      "x": 1023,
      "y": 643
    },
    {
      "t": 262370,
      "e": 38168,
      "ty": 6,
      "x": 984,
      "y": 691,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 262408,
      "e": 38206,
      "ty": 2,
      "x": 982,
      "y": 699
    },
    {
      "t": 262458,
      "e": 38256,
      "ty": 41,
      "x": 37633,
      "y": 62414,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 262478,
      "e": 38276,
      "ty": 7,
      "x": 980,
      "y": 700,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 262508,
      "e": 38306,
      "ty": 2,
      "x": 979,
      "y": 703
    },
    {
      "t": 262608,
      "e": 38406,
      "ty": 2,
      "x": 978,
      "y": 703
    },
    {
      "t": 262654,
      "e": 38452,
      "ty": 6,
      "x": 969,
      "y": 710,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 262707,
      "e": 38505,
      "ty": 2,
      "x": 959,
      "y": 721
    },
    {
      "t": 262708,
      "e": 38506,
      "ty": 41,
      "x": 32509,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 262776,
      "e": 38574,
      "ty": 3,
      "x": 958,
      "y": 722,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 262776,
      "e": 38574,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31*"
    },
    {
      "t": 262777,
      "e": 38575,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 262778,
      "e": 38576,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 262808,
      "e": 38606,
      "ty": 2,
      "x": 958,
      "y": 722
    },
    {
      "t": 262847,
      "e": 38645,
      "ty": 4,
      "x": 31994,
      "y": 27802,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 262850,
      "e": 38648,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 262851,
      "e": 38649,
      "ty": 5,
      "x": 958,
      "y": 722,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 262852,
      "e": 38650,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 262957,
      "e": 38755,
      "ty": 41,
      "x": 32715,
      "y": 39553,
      "ta": "html > body"
    },
    {
      "t": 264279,
      "e": 40077,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 264307,
      "e": 40105,
      "ty": 6,
      "x": 958,
      "y": 722,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 264708,
      "e": 40506,
      "ty": 2,
      "x": 976,
      "y": 712
    },
    {
      "t": 264709,
      "e": 40507,
      "ty": 41,
      "x": 32626,
      "y": 30463,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 265072,
      "e": 40870,
      "ty": 7,
      "x": 1002,
      "y": 728,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 265072,
      "e": 40870,
      "ty": 6,
      "x": 1002,
      "y": 728,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 265089,
      "e": 40887,
      "ty": 7,
      "x": 1046,
      "y": 765,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 265090,
      "e": 40888,
      "ty": 6,
      "x": 1046,
      "y": 765,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 265108,
      "e": 40906,
      "ty": 2,
      "x": 1046,
      "y": 765
    },
    {
      "t": 265208,
      "e": 41006,
      "ty": 41,
      "x": 36173,
      "y": 23441,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 265591,
      "e": 41389,
      "ty": 7,
      "x": 1045,
      "y": 751,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 265592,
      "e": 41390,
      "ty": 6,
      "x": 1045,
      "y": 751,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 265607,
      "e": 41405,
      "ty": 2,
      "x": 1043,
      "y": 746
    },
    {
      "t": 265707,
      "e": 41505,
      "ty": 2,
      "x": 1038,
      "y": 735
    },
    {
      "t": 265708,
      "e": 41506,
      "ty": 41,
      "x": 35767,
      "y": 18760,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 269708,
      "e": 45506,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 285679,
      "e": 46506,
      "ty": 7,
      "x": 1038,
      "y": 725,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 285680,
      "e": 46507,
      "ty": 6,
      "x": 1038,
      "y": 725,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 285707,
      "e": 46534,
      "ty": 2,
      "x": 1036,
      "y": 722
    },
    {
      "t": 285708,
      "e": 46535,
      "ty": 41,
      "x": 35666,
      "y": 53868,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 285808,
      "e": 46635,
      "ty": 2,
      "x": 1031,
      "y": 717
    },
    {
      "t": 285862,
      "e": 46689,
      "ty": 7,
      "x": 1002,
      "y": 732,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 285863,
      "e": 46690,
      "ty": 6,
      "x": 1002,
      "y": 732,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 285908,
      "e": 46735,
      "ty": 2,
      "x": 997,
      "y": 748
    },
    {
      "t": 285912,
      "e": 46739,
      "ty": 7,
      "x": 997,
      "y": 759,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 285913,
      "e": 46740,
      "ty": 6,
      "x": 997,
      "y": 759,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 285945,
      "e": 46772,
      "ty": 7,
      "x": 1006,
      "y": 788,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 285958,
      "e": 46785,
      "ty": 41,
      "x": 35055,
      "y": 59185,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 286007,
      "e": 46834,
      "ty": 2,
      "x": 1014,
      "y": 801
    },
    {
      "t": 286108,
      "e": 46935,
      "ty": 2,
      "x": 1037,
      "y": 809
    },
    {
      "t": 286207,
      "e": 47034,
      "ty": 41,
      "x": 36580,
      "y": 18760,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 286307,
      "e": 47134,
      "ty": 2,
      "x": 979,
      "y": 873
    },
    {
      "t": 286408,
      "e": 47235,
      "ty": 2,
      "x": 985,
      "y": 972
    },
    {
      "t": 286458,
      "e": 47285,
      "ty": 41,
      "x": 34071,
      "y": 60016,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 286508,
      "e": 47335,
      "ty": 2,
      "x": 986,
      "y": 1011
    },
    {
      "t": 286607,
      "e": 47434,
      "ty": 2,
      "x": 976,
      "y": 1067
    },
    {
      "t": 286662,
      "e": 47489,
      "ty": 6,
      "x": 976,
      "y": 1075,
      "ta": "#start"
    },
    {
      "t": 286708,
      "e": 47535,
      "ty": 2,
      "x": 976,
      "y": 1078
    },
    {
      "t": 286708,
      "e": 47535,
      "ty": 41,
      "x": 36317,
      "y": 10239,
      "ta": "#start"
    },
    {
      "t": 286756,
      "e": 47583,
      "ty": 7,
      "x": 978,
      "y": 1112,
      "ta": "#start"
    },
    {
      "t": 286808,
      "e": 47635,
      "ty": 2,
      "x": 979,
      "y": 1119
    },
    {
      "t": 286907,
      "e": 47734,
      "ty": 2,
      "x": 980,
      "y": 1119
    },
    {
      "t": 286958,
      "e": 47785,
      "ty": 41,
      "x": 42363,
      "y": 22332,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 287008,
      "e": 47835,
      "ty": 2,
      "x": 983,
      "y": 1107
    },
    {
      "t": 287055,
      "e": 47882,
      "ty": 6,
      "x": 984,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 287108,
      "e": 47935,
      "ty": 2,
      "x": 987,
      "y": 1102
    },
    {
      "t": 287207,
      "e": 48034,
      "ty": 2,
      "x": 988,
      "y": 1100
    },
    {
      "t": 287208,
      "e": 48035,
      "ty": 41,
      "x": 42870,
      "y": 52644,
      "ta": "#start"
    },
    {
      "t": 287591,
      "e": 48418,
      "ty": 3,
      "x": 988,
      "y": 1100,
      "ta": "#start"
    },
    {
      "t": 287593,
      "e": 48420,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 287669,
      "e": 48496,
      "ty": 4,
      "x": 42870,
      "y": 52644,
      "ta": "#start"
    },
    {
      "t": 287670,
      "e": 48497,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 287671,
      "e": 48498,
      "ty": 5,
      "x": 988,
      "y": 1100,
      "ta": "#start"
    },
    {
      "t": 287671,
      "e": 48498,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 287808,
      "e": 48635,
      "ty": 2,
      "x": 988,
      "y": 1099
    },
    {
      "t": 287907,
      "e": 48734,
      "ty": 2,
      "x": 988,
      "y": 1091
    },
    {
      "t": 287958,
      "e": 48785,
      "ty": 41,
      "x": 33163,
      "y": 56283,
      "ta": "html > body"
    },
    {
      "t": 288008,
      "e": 48835,
      "ty": 2,
      "x": 839,
      "y": 907
    },
    {
      "t": 288107,
      "e": 48934,
      "ty": 2,
      "x": 807,
      "y": 881
    },
    {
      "t": 288208,
      "e": 49035,
      "ty": 41,
      "x": 27515,
      "y": 48361,
      "ta": "html > body"
    },
    {
      "t": 288673,
      "e": 49500,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 289458,
      "e": 50285,
      "ty": 41,
      "x": 25315,
      "y": 56877,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 289508,
      "e": 50335,
      "ty": 2,
      "x": 806,
      "y": 837
    },
    {
      "t": 289607,
      "e": 50434,
      "ty": 2,
      "x": 857,
      "y": 733
    },
    {
      "t": 289707,
      "e": 50534,
      "ty": 2,
      "x": 866,
      "y": 712
    },
    {
      "t": 289708,
      "e": 50535,
      "ty": 41,
      "x": 28228,
      "y": 43987,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 289808,
      "e": 50635,
      "ty": 2,
      "x": 866,
      "y": 709
    },
    {
      "t": 289908,
      "e": 50735,
      "ty": 2,
      "x": 866,
      "y": 703
    },
    {
      "t": 289958,
      "e": 50785,
      "ty": 41,
      "x": 28277,
      "y": 43211,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 290008,
      "e": 50835,
      "ty": 2,
      "x": 867,
      "y": 702
    },
    {
      "t": 299676,
      "e": 55835,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 300876,
      "e": 55835,
      "ty": 2,
      "x": 867,
      "y": 699
    },
    {
      "t": 300927,
      "e": 55886,
      "ty": 41,
      "x": 28325,
      "y": 42745,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 300976,
      "e": 55935,
      "ty": 2,
      "x": 868,
      "y": 696
    },
    {
      "t": 300988,
      "e": 55947,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 301995,
      "e": 56954,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 144, dom: 691, initialDom: 771",
  "javascriptErrors": []
}