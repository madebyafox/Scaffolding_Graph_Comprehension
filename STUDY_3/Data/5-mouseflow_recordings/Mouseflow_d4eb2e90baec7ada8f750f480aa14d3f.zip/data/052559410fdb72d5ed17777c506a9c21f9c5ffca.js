var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052559410fdb72d5ed17777c506a9c21f9c5ffca"] = {
  "startTime": "2018-05-25T18:01:59.9521618Z",
  "websitePageUrl": "/",
  "visitTime": 436139,
  "engagementTime": 93279,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "d4eb2e90baec7ada8f750f480aa14d3f",
    "created": "2018-05-25T18:01:59.9521618+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "2f0ccac272f9682169ceb2b8cb1996d1",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/d4eb2e90baec7ada8f750f480aa14d3f/play"
  },
  "events": [
    {
      "t": 102,
      "e": 102,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 279,
      "e": 279,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 10010,
      "e": 5102,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 35902,
      "e": 5102,
      "ty": 2,
      "x": 1088,
      "y": 31
    },
    {
      "t": 36001,
      "e": 5201,
      "ty": 2,
      "x": 1029,
      "y": 205
    },
    {
      "t": 36004,
      "e": 5204,
      "ty": 41,
      "x": 36563,
      "y": 4792,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 36201,
      "e": 5401,
      "ty": 2,
      "x": 1039,
      "y": 142
    },
    {
      "t": 36252,
      "e": 5452,
      "ty": 41,
      "x": 37571,
      "y": 4381,
      "ta": "html > body"
    },
    {
      "t": 36302,
      "e": 5502,
      "ty": 2,
      "x": 1107,
      "y": 99
    },
    {
      "t": 36401,
      "e": 5601,
      "ty": 2,
      "x": 1210,
      "y": 301
    },
    {
      "t": 36501,
      "e": 5701,
      "ty": 2,
      "x": 1396,
      "y": 407
    },
    {
      "t": 36502,
      "e": 5702,
      "ty": 41,
      "x": 56605,
      "y": 21339,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 36601,
      "e": 5801,
      "ty": 2,
      "x": 1397,
      "y": 407
    },
    {
      "t": 36701,
      "e": 5901,
      "ty": 2,
      "x": 1405,
      "y": 443
    },
    {
      "t": 36701,
      "e": 5901,
      "ty": 1,
      "x": 0,
      "y": 5
    },
    {
      "t": 36751,
      "e": 5951,
      "ty": 41,
      "x": 57097,
      "y": 24862,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 36801,
      "e": 6001,
      "ty": 2,
      "x": 1406,
      "y": 464
    },
    {
      "t": 36801,
      "e": 6001,
      "ty": 1,
      "x": 0,
      "y": 13
    },
    {
      "t": 36901,
      "e": 6101,
      "ty": 2,
      "x": 1433,
      "y": 617
    },
    {
      "t": 36901,
      "e": 6101,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 37001,
      "e": 6201,
      "ty": 2,
      "x": 1446,
      "y": 729
    },
    {
      "t": 37001,
      "e": 6201,
      "ty": 41,
      "x": 59336,
      "y": 47717,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 37101,
      "e": 6301,
      "ty": 2,
      "x": 1446,
      "y": 730
    },
    {
      "t": 37252,
      "e": 6452,
      "ty": 41,
      "x": 59336,
      "y": 47799,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 37301,
      "e": 6501,
      "ty": 1,
      "x": 0,
      "y": 14
    },
    {
      "t": 37401,
      "e": 6601,
      "ty": 1,
      "x": 0,
      "y": 4
    },
    {
      "t": 37501,
      "e": 6701,
      "ty": 1,
      "x": 0,
      "y": 0
    },
    {
      "t": 37701,
      "e": 6901,
      "ty": 2,
      "x": 1446,
      "y": 716
    },
    {
      "t": 37751,
      "e": 6951,
      "ty": 41,
      "x": 59336,
      "y": 46734,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 37801,
      "e": 7001,
      "ty": 2,
      "x": 1446,
      "y": 717
    },
    {
      "t": 37901,
      "e": 7101,
      "ty": 2,
      "x": 1448,
      "y": 711
    },
    {
      "t": 38001,
      "e": 7201,
      "ty": 2,
      "x": 1402,
      "y": 618
    },
    {
      "t": 38001,
      "e": 7201,
      "ty": 41,
      "x": 56933,
      "y": 38624,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 41702,
      "e": 10902,
      "ty": 2,
      "x": 1401,
      "y": 617
    },
    {
      "t": 41752,
      "e": 10952,
      "ty": 41,
      "x": 52782,
      "y": 39443,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 41802,
      "e": 11002,
      "ty": 2,
      "x": 1229,
      "y": 641
    },
    {
      "t": 41901,
      "e": 11101,
      "ty": 2,
      "x": 1228,
      "y": 641
    },
    {
      "t": 42001,
      "e": 11201,
      "ty": 41,
      "x": 47430,
      "y": 40508,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 50001,
      "e": 16201,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 206911,
      "e": 16201,
      "ty": 2,
      "x": 1543,
      "y": 175
    },
    {
      "t": 207011,
      "e": 16301,
      "ty": 2,
      "x": 1592,
      "y": 94
    },
    {
      "t": 207011,
      "e": 16301,
      "ty": 41,
      "x": 54549,
      "y": 5233,
      "ta": "html > body"
    },
    {
      "t": 207111,
      "e": 16401,
      "ty": 2,
      "x": 1556,
      "y": 173
    },
    {
      "t": 207211,
      "e": 16501,
      "ty": 2,
      "x": 1493,
      "y": 416
    },
    {
      "t": 207261,
      "e": 16551,
      "ty": 41,
      "x": 59991,
      "y": 28630,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 207311,
      "e": 16601,
      "ty": 2,
      "x": 1442,
      "y": 517
    },
    {
      "t": 207512,
      "e": 16802,
      "ty": 41,
      "x": 59118,
      "y": 30350,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 209112,
      "e": 18402,
      "ty": 2,
      "x": 1449,
      "y": 503
    },
    {
      "t": 209212,
      "e": 18502,
      "ty": 2,
      "x": 1455,
      "y": 496
    },
    {
      "t": 209261,
      "e": 18551,
      "ty": 41,
      "x": 59827,
      "y": 28630,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 220011,
      "e": 23551,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 228411,
      "e": 23551,
      "ty": 2,
      "x": 1454,
      "y": 495
    },
    {
      "t": 228511,
      "e": 23651,
      "ty": 2,
      "x": 1443,
      "y": 498
    },
    {
      "t": 228511,
      "e": 23651,
      "ty": 41,
      "x": 59172,
      "y": 28794,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 228761,
      "e": 23901,
      "ty": 41,
      "x": 58954,
      "y": 28876,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 228811,
      "e": 23951,
      "ty": 2,
      "x": 1439,
      "y": 499
    },
    {
      "t": 240015,
      "e": 28951,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 242715,
      "e": 28951,
      "ty": 2,
      "x": 1418,
      "y": 476
    },
    {
      "t": 242766,
      "e": 29002,
      "ty": 41,
      "x": 57807,
      "y": 26992,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 244914,
      "e": 31150,
      "ty": 2,
      "x": 1406,
      "y": 465
    },
    {
      "t": 245015,
      "e": 31251,
      "ty": 41,
      "x": 57151,
      "y": 26091,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 245114,
      "e": 31350,
      "ty": 2,
      "x": 1366,
      "y": 436
    },
    {
      "t": 245214,
      "e": 31450,
      "ty": 2,
      "x": 1238,
      "y": 348
    },
    {
      "t": 245264,
      "e": 31500,
      "ty": 41,
      "x": 47977,
      "y": 16506,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 245514,
      "e": 31750,
      "ty": 2,
      "x": 1220,
      "y": 345
    },
    {
      "t": 245514,
      "e": 31750,
      "ty": 41,
      "x": 46994,
      "y": 16260,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 245614,
      "e": 31850,
      "ty": 2,
      "x": 1184,
      "y": 345
    },
    {
      "t": 245714,
      "e": 31950,
      "ty": 2,
      "x": 1138,
      "y": 359
    },
    {
      "t": 245764,
      "e": 32000,
      "ty": 41,
      "x": 42515,
      "y": 17407,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 246114,
      "e": 32350,
      "ty": 2,
      "x": 1126,
      "y": 359
    },
    {
      "t": 246214,
      "e": 32450,
      "ty": 2,
      "x": 1117,
      "y": 360
    },
    {
      "t": 246264,
      "e": 32500,
      "ty": 41,
      "x": 41368,
      "y": 17489,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 247265,
      "e": 33501,
      "ty": 41,
      "x": 41314,
      "y": 17571,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 247314,
      "e": 33550,
      "ty": 2,
      "x": 1116,
      "y": 361
    },
    {
      "t": 250014,
      "e": 36250,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 277915,
      "e": 38550,
      "ty": 2,
      "x": 1161,
      "y": 358
    },
    {
      "t": 278014,
      "e": 38649,
      "ty": 2,
      "x": 1474,
      "y": 622
    },
    {
      "t": 278015,
      "e": 38650,
      "ty": 41,
      "x": 60865,
      "y": 38952,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 278115,
      "e": 38750,
      "ty": 2,
      "x": 1443,
      "y": 683
    },
    {
      "t": 278265,
      "e": 38900,
      "ty": 41,
      "x": 59172,
      "y": 43949,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 278615,
      "e": 39250,
      "ty": 2,
      "x": 1446,
      "y": 672
    },
    {
      "t": 278715,
      "e": 39350,
      "ty": 2,
      "x": 1442,
      "y": 619
    },
    {
      "t": 278765,
      "e": 39400,
      "ty": 41,
      "x": 59118,
      "y": 38706,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 280614,
      "e": 41249,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 280714,
      "e": 41349,
      "ty": 2,
      "x": 1442,
      "y": 685
    },
    {
      "t": 280764,
      "e": 41399,
      "ty": 41,
      "x": 59118,
      "y": 39771,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 290015,
      "e": 46399,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 388711,
      "e": 46399,
      "ty": 2,
      "x": 1411,
      "y": 701
    },
    {
      "t": 388762,
      "e": 46450,
      "ty": 41,
      "x": 54783,
      "y": 14518,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 388811,
      "e": 46499,
      "ty": 2,
      "x": 1407,
      "y": 704
    },
    {
      "t": 391311,
      "e": 48999,
      "ty": 2,
      "x": 1398,
      "y": 709
    },
    {
      "t": 391411,
      "e": 49099,
      "ty": 2,
      "x": 1327,
      "y": 761
    },
    {
      "t": 391510,
      "e": 49198,
      "ty": 2,
      "x": 1326,
      "y": 761
    },
    {
      "t": 391511,
      "e": 49199,
      "ty": 41,
      "x": 50798,
      "y": 41200,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 392211,
      "e": 49899,
      "ty": 2,
      "x": 1335,
      "y": 760
    },
    {
      "t": 392261,
      "e": 49949,
      "ty": 41,
      "x": 51339,
      "y": 39796,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 392310,
      "e": 49998,
      "ty": 2,
      "x": 1339,
      "y": 758
    },
    {
      "t": 392410,
      "e": 50098,
      "ty": 2,
      "x": 1344,
      "y": 755
    },
    {
      "t": 392511,
      "e": 50199,
      "ty": 2,
      "x": 1366,
      "y": 857
    },
    {
      "t": 392511,
      "e": 50199,
      "ty": 41,
      "x": 52766,
      "y": 30445,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 392611,
      "e": 50299,
      "ty": 2,
      "x": 1340,
      "y": 957
    },
    {
      "t": 392711,
      "e": 50399,
      "ty": 2,
      "x": 1159,
      "y": 1067
    },
    {
      "t": 392761,
      "e": 50449,
      "ty": 41,
      "x": 36710,
      "y": 59275,
      "ta": "> div.masterdiv"
    },
    {
      "t": 392811,
      "e": 50499,
      "ty": 2,
      "x": 1021,
      "y": 1069
    },
    {
      "t": 392911,
      "e": 50599,
      "ty": 2,
      "x": 967,
      "y": 1058
    },
    {
      "t": 393011,
      "e": 50699,
      "ty": 2,
      "x": 965,
      "y": 1048
    },
    {
      "t": 393011,
      "e": 50699,
      "ty": 41,
      "x": 33038,
      "y": 63825,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 393111,
      "e": 50799,
      "ty": 2,
      "x": 978,
      "y": 1030
    },
    {
      "t": 393211,
      "e": 50899,
      "ty": 2,
      "x": 975,
      "y": 989
    },
    {
      "t": 393261,
      "e": 50949,
      "ty": 41,
      "x": 33480,
      "y": 59739,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 393311,
      "e": 50999,
      "ty": 2,
      "x": 974,
      "y": 989
    },
    {
      "t": 393611,
      "e": 51299,
      "ty": 2,
      "x": 969,
      "y": 989
    },
    {
      "t": 393761,
      "e": 51449,
      "ty": 41,
      "x": 32890,
      "y": 60847,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 393811,
      "e": 51499,
      "ty": 2,
      "x": 953,
      "y": 1031
    },
    {
      "t": 393910,
      "e": 51598,
      "ty": 2,
      "x": 951,
      "y": 1033
    },
    {
      "t": 394010,
      "e": 51698,
      "ty": 2,
      "x": 940,
      "y": 1037
    },
    {
      "t": 394011,
      "e": 51699,
      "ty": 41,
      "x": 31808,
      "y": 63063,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 394111,
      "e": 51799,
      "ty": 2,
      "x": 960,
      "y": 1069
    },
    {
      "t": 394261,
      "e": 51949,
      "ty": 41,
      "x": 32792,
      "y": 65279,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 395211,
      "e": 52899,
      "ty": 2,
      "x": 959,
      "y": 1068
    },
    {
      "t": 395261,
      "e": 52949,
      "ty": 41,
      "x": 32496,
      "y": 65002,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 395311,
      "e": 52999,
      "ty": 2,
      "x": 954,
      "y": 1065
    },
    {
      "t": 395411,
      "e": 53099,
      "ty": 2,
      "x": 942,
      "y": 1067
    },
    {
      "t": 395511,
      "e": 53199,
      "ty": 2,
      "x": 878,
      "y": 1095
    },
    {
      "t": 395511,
      "e": 53199,
      "ty": 41,
      "x": 29960,
      "y": 60216,
      "ta": "> div.masterdiv"
    },
    {
      "t": 395761,
      "e": 53449,
      "ty": 41,
      "x": 29960,
      "y": 60106,
      "ta": "> div.masterdiv"
    },
    {
      "t": 395811,
      "e": 53499,
      "ty": 2,
      "x": 857,
      "y": 1039
    },
    {
      "t": 395910,
      "e": 53598,
      "ty": 2,
      "x": 830,
      "y": 1001
    },
    {
      "t": 396011,
      "e": 53699,
      "ty": 2,
      "x": 810,
      "y": 974
    },
    {
      "t": 396011,
      "e": 53699,
      "ty": 41,
      "x": 25412,
      "y": 58701,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 396111,
      "e": 53799,
      "ty": 2,
      "x": 808,
      "y": 958
    },
    {
      "t": 396211,
      "e": 53899,
      "ty": 2,
      "x": 809,
      "y": 949
    },
    {
      "t": 396261,
      "e": 53949,
      "ty": 41,
      "x": 25363,
      "y": 56969,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 396411,
      "e": 54099,
      "ty": 2,
      "x": 808,
      "y": 941
    },
    {
      "t": 396511,
      "e": 54199,
      "ty": 2,
      "x": 808,
      "y": 937
    },
    {
      "t": 396512,
      "e": 54200,
      "ty": 41,
      "x": 25314,
      "y": 56139,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 396611,
      "e": 54299,
      "ty": 2,
      "x": 809,
      "y": 930
    },
    {
      "t": 396710,
      "e": 54398,
      "ty": 2,
      "x": 816,
      "y": 920
    },
    {
      "t": 396761,
      "e": 54449,
      "ty": 41,
      "x": 41164,
      "y": 29541,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 396891,
      "e": 54579,
      "ty": 3,
      "x": 816,
      "y": 920,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 396960,
      "e": 54648,
      "ty": 4,
      "x": 41164,
      "y": 29541,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 396961,
      "e": 54649,
      "ty": 5,
      "x": 816,
      "y": 920,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 396961,
      "e": 54649,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 396964,
      "e": 54652,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 397111,
      "e": 54799,
      "ty": 2,
      "x": 841,
      "y": 928
    },
    {
      "t": 397210,
      "e": 54898,
      "ty": 2,
      "x": 927,
      "y": 995
    },
    {
      "t": 397261,
      "e": 54949,
      "ty": 41,
      "x": 31758,
      "y": 61055,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 397310,
      "e": 54998,
      "ty": 2,
      "x": 959,
      "y": 1037
    },
    {
      "t": 397410,
      "e": 55098,
      "ty": 2,
      "x": 973,
      "y": 1086
    },
    {
      "t": 397511,
      "e": 55199,
      "ty": 2,
      "x": 978,
      "y": 1102
    },
    {
      "t": 397511,
      "e": 55199,
      "ty": 41,
      "x": 37409,
      "y": 56499,
      "ta": "#start"
    },
    {
      "t": 397611,
      "e": 55299,
      "ty": 2,
      "x": 981,
      "y": 1110
    },
    {
      "t": 397711,
      "e": 55399,
      "ty": 2,
      "x": 982,
      "y": 1113
    },
    {
      "t": 397761,
      "e": 55449,
      "ty": 41,
      "x": 43768,
      "y": 21778,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 397811,
      "e": 55499,
      "ty": 2,
      "x": 983,
      "y": 1105
    },
    {
      "t": 397910,
      "e": 55598,
      "ty": 2,
      "x": 983,
      "y": 1104
    },
    {
      "t": 398012,
      "e": 55700,
      "ty": 41,
      "x": 40140,
      "y": 60354,
      "ta": "#start"
    },
    {
      "t": 398042,
      "e": 55730,
      "ty": 3,
      "x": 983,
      "y": 1104,
      "ta": "#start"
    },
    {
      "t": 398043,
      "e": 55731,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 398043,
      "e": 55731,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 398168,
      "e": 55856,
      "ty": 4,
      "x": 40140,
      "y": 60354,
      "ta": "#start"
    },
    {
      "t": 398170,
      "e": 55858,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 398172,
      "e": 55860,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 398172,
      "e": 55860,
      "ty": 5,
      "x": 983,
      "y": 1104,
      "ta": "#start"
    },
    {
      "t": 398511,
      "e": 56199,
      "ty": 2,
      "x": 982,
      "y": 1070
    },
    {
      "t": 398511,
      "e": 56199,
      "ty": 41,
      "x": 33542,
      "y": 58831,
      "ta": "html > body"
    },
    {
      "t": 398611,
      "e": 56299,
      "ty": 2,
      "x": 752,
      "y": 638
    },
    {
      "t": 398761,
      "e": 56449,
      "ty": 41,
      "x": 25621,
      "y": 34900,
      "ta": "html > body"
    },
    {
      "t": 399181,
      "e": 56869,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 399911,
      "e": 57599,
      "ty": 2,
      "x": 771,
      "y": 627
    },
    {
      "t": 400008,
      "e": 57696,
      "ty": 6,
      "x": 840,
      "y": 606,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 400011,
      "e": 57699,
      "ty": 2,
      "x": 840,
      "y": 606
    },
    {
      "t": 400012,
      "e": 57700,
      "ty": 41,
      "x": 6921,
      "y": 62414,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 400012,
      "e": 57700,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 400111,
      "e": 57799,
      "ty": 2,
      "x": 857,
      "y": 600
    },
    {
      "t": 400184,
      "e": 57872,
      "ty": 3,
      "x": 863,
      "y": 596,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 400185,
      "e": 57873,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 400211,
      "e": 57899,
      "ty": 2,
      "x": 865,
      "y": 596
    },
    {
      "t": 400261,
      "e": 57949,
      "ty": 41,
      "x": 12544,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 400311,
      "e": 57999,
      "ty": 2,
      "x": 866,
      "y": 596
    },
    {
      "t": 400337,
      "e": 58025,
      "ty": 4,
      "x": 12544,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 400338,
      "e": 58026,
      "ty": 5,
      "x": 866,
      "y": 596,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 400511,
      "e": 58199,
      "ty": 2,
      "x": 867,
      "y": 596
    },
    {
      "t": 400511,
      "e": 58199,
      "ty": 41,
      "x": 12760,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 402302,
      "e": 59990,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 402445,
      "e": 60133,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 402446,
      "e": 60134,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 402525,
      "e": 60213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "N"
    },
    {
      "t": 402532,
      "e": 60220,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "N"
    },
    {
      "t": 403700,
      "e": 61388,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 403700,
      "e": 61388,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 403797,
      "e": 61485,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "No"
    },
    {
      "t": 403933,
      "e": 61621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "86"
    },
    {
      "t": 403934,
      "e": 61622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 403996,
      "e": 61684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Nov"
    },
    {
      "t": 404268,
      "e": 61956,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 404269,
      "e": 61957,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 404348,
      "e": 62036,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Nove"
    },
    {
      "t": 404444,
      "e": 62132,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "77"
    },
    {
      "t": 404444,
      "e": 62132,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 404533,
      "e": 62221,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||m"
    },
    {
      "t": 404685,
      "e": 62373,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "66"
    },
    {
      "t": 404685,
      "e": 62373,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 404765,
      "e": 62453,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||b"
    },
    {
      "t": 404965,
      "e": 62653,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 404966,
      "e": 62654,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 405052,
      "e": 62740,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||e"
    },
    {
      "t": 405260,
      "e": 62948,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 405260,
      "e": 62948,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 405325,
      "e": 63013,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||r"
    },
    {
      "t": 405997,
      "e": 63685,
      "ty": 7,
      "x": 886,
      "y": 584,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 406012,
      "e": 63700,
      "ty": 2,
      "x": 886,
      "y": 584
    },
    {
      "t": 406012,
      "e": 63700,
      "ty": 41,
      "x": 16870,
      "y": 43690,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 406111,
      "e": 63799,
      "ty": 2,
      "x": 892,
      "y": 582
    },
    {
      "t": 406200,
      "e": 63888,
      "ty": 6,
      "x": 897,
      "y": 587,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 406211,
      "e": 63899,
      "ty": 2,
      "x": 897,
      "y": 587
    },
    {
      "t": 406261,
      "e": 63949,
      "ty": 41,
      "x": 19682,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 406295,
      "e": 63983,
      "ty": 7,
      "x": 897,
      "y": 611,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 406311,
      "e": 63999,
      "ty": 2,
      "x": 897,
      "y": 611
    },
    {
      "t": 406411,
      "e": 64099,
      "ty": 2,
      "x": 868,
      "y": 666
    },
    {
      "t": 406496,
      "e": 64184,
      "ty": 6,
      "x": 868,
      "y": 679,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 406511,
      "e": 64199,
      "ty": 2,
      "x": 868,
      "y": 679
    },
    {
      "t": 406512,
      "e": 64200,
      "ty": 41,
      "x": 12977,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 406611,
      "e": 64299,
      "ty": 2,
      "x": 868,
      "y": 682
    },
    {
      "t": 406688,
      "e": 64376,
      "ty": 3,
      "x": 868,
      "y": 683,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 406689,
      "e": 64377,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "November"
    },
    {
      "t": 406689,
      "e": 64377,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 406689,
      "e": 64377,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 406711,
      "e": 64399,
      "ty": 2,
      "x": 868,
      "y": 683
    },
    {
      "t": 406762,
      "e": 64450,
      "ty": 41,
      "x": 12977,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 406784,
      "e": 64472,
      "ty": 4,
      "x": 12977,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 406784,
      "e": 64472,
      "ty": 5,
      "x": 868,
      "y": 683,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 407531,
      "e": 65219,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 407532,
      "e": 65220,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 407604,
      "e": 65292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 407707,
      "e": 65395,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 407708,
      "e": 65396,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 407796,
      "e": 65484,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 407916,
      "e": 65604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "100"
    },
    {
      "t": 407916,
      "e": 65604,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 408004,
      "e": 65692,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 410011,
      "e": 67699,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 413552,
      "e": 70692,
      "ty": 7,
      "x": 869,
      "y": 678,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 413610,
      "e": 70750,
      "ty": 2,
      "x": 865,
      "y": 677
    },
    {
      "t": 413760,
      "e": 70900,
      "ty": 41,
      "x": 12328,
      "y": 43690,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 413910,
      "e": 71050,
      "ty": 2,
      "x": 859,
      "y": 660
    },
    {
      "t": 414000,
      "e": 71140,
      "ty": 6,
      "x": 903,
      "y": 606,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 414010,
      "e": 71150,
      "ty": 2,
      "x": 903,
      "y": 606
    },
    {
      "t": 414010,
      "e": 71150,
      "ty": 41,
      "x": 20547,
      "y": 62414,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 414110,
      "e": 71250,
      "ty": 2,
      "x": 908,
      "y": 596
    },
    {
      "t": 414260,
      "e": 71400,
      "ty": 41,
      "x": 21845,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 414264,
      "e": 71404,
      "ty": 3,
      "x": 909,
      "y": 597,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 414264,
      "e": 71404,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 414264,
      "e": 71404,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 414264,
      "e": 71404,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 414310,
      "e": 71450,
      "ty": 2,
      "x": 909,
      "y": 597
    },
    {
      "t": 414411,
      "e": 71551,
      "ty": 2,
      "x": 814,
      "y": 596
    },
    {
      "t": 414419,
      "e": 71559,
      "ty": 7,
      "x": 760,
      "y": 595,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 414511,
      "e": 71651,
      "ty": 2,
      "x": 638,
      "y": 600
    },
    {
      "t": 414511,
      "e": 71651,
      "ty": 41,
      "x": 21695,
      "y": 32795,
      "ta": "html > body"
    },
    {
      "t": 414576,
      "e": 71716,
      "ty": 4,
      "x": 20456,
      "y": 33293,
      "ta": "html > body"
    },
    {
      "t": 414610,
      "e": 71750,
      "ty": 2,
      "x": 573,
      "y": 608
    },
    {
      "t": 414710,
      "e": 71850,
      "ty": 2,
      "x": 572,
      "y": 608
    },
    {
      "t": 414761,
      "e": 71901,
      "ty": 41,
      "x": 19422,
      "y": 33238,
      "ta": "html > body"
    },
    {
      "t": 415268,
      "e": 72408,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 415459,
      "e": 72599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 415461,
      "e": 72601,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 415540,
      "e": 72680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "N"
    },
    {
      "t": 415668,
      "e": 72808,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 415668,
      "e": 72808,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 415756,
      "e": 72896,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NO"
    },
    {
      "t": 415851,
      "e": 72991,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "86"
    },
    {
      "t": 415852,
      "e": 72992,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 415916,
      "e": 73056,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NOV"
    },
    {
      "t": 416043,
      "e": 73183,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 416044,
      "e": 73184,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 416139,
      "e": 73279,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NOVE"
    },
    {
      "t": 416195,
      "e": 73335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "77"
    },
    {
      "t": 416196,
      "e": 73336,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 416283,
      "e": 73423,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||M"
    },
    {
      "t": 416404,
      "e": 73544,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "66"
    },
    {
      "t": 416404,
      "e": 73544,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 416492,
      "e": 73632,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||B"
    },
    {
      "t": 416531,
      "e": 73671,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 416531,
      "e": 73671,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 416612,
      "e": 73752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||E"
    },
    {
      "t": 416747,
      "e": 73887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 416748,
      "e": 73888,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 416819,
      "e": 73959,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||R"
    },
    {
      "t": 416908,
      "e": 74048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 419510,
      "e": 76650,
      "ty": 2,
      "x": 592,
      "y": 608
    },
    {
      "t": 419511,
      "e": 76651,
      "ty": 41,
      "x": 20111,
      "y": 33238,
      "ta": "html > body"
    },
    {
      "t": 419611,
      "e": 76751,
      "ty": 2,
      "x": 671,
      "y": 616
    },
    {
      "t": 419710,
      "e": 76850,
      "ty": 2,
      "x": 757,
      "y": 688
    },
    {
      "t": 419761,
      "e": 76901,
      "ty": 41,
      "x": 27033,
      "y": 38778,
      "ta": "html > body"
    },
    {
      "t": 419811,
      "e": 76951,
      "ty": 2,
      "x": 831,
      "y": 716
    },
    {
      "t": 419870,
      "e": 77010,
      "ty": 6,
      "x": 897,
      "y": 724,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 419907,
      "e": 77047,
      "ty": 2,
      "x": 924,
      "y": 724
    },
    {
      "t": 420007,
      "e": 77147,
      "ty": 2,
      "x": 942,
      "y": 727
    },
    {
      "t": 420007,
      "e": 77147,
      "ty": 41,
      "x": 23748,
      "y": 37732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 420008,
      "e": 77148,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 420108,
      "e": 77248,
      "ty": 2,
      "x": 951,
      "y": 727
    },
    {
      "t": 420181,
      "e": 77321,
      "ty": 3,
      "x": 951,
      "y": 727,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 420181,
      "e": 77321,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NOVEMBER"
    },
    {
      "t": 420182,
      "e": 77322,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 420182,
      "e": 77322,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 420258,
      "e": 77398,
      "ty": 41,
      "x": 28386,
      "y": 37732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 420309,
      "e": 77449,
      "ty": 4,
      "x": 28386,
      "y": 37732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 420309,
      "e": 77449,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 420310,
      "e": 77450,
      "ty": 5,
      "x": 951,
      "y": 727,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 420310,
      "e": 77450,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 421396,
      "e": 78536,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 421425,
      "e": 78565,
      "ty": 6,
      "x": 951,
      "y": 727,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 424733,
      "e": 81873,
      "ty": 7,
      "x": 952,
      "y": 726,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 424733,
      "e": 81873,
      "ty": 6,
      "x": 952,
      "y": 726,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 424758,
      "e": 81898,
      "ty": 41,
      "x": 31815,
      "y": 60890,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 424758,
      "e": 81898,
      "ty": 7,
      "x": 989,
      "y": 731,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 424758,
      "e": 81898,
      "ty": 6,
      "x": 989,
      "y": 731,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 424808,
      "e": 81948,
      "ty": 2,
      "x": 990,
      "y": 731
    },
    {
      "t": 425008,
      "e": 82148,
      "ty": 41,
      "x": 33335,
      "y": 9398,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 426077,
      "e": 83217,
      "ty": 7,
      "x": 986,
      "y": 772,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 426077,
      "e": 83217,
      "ty": 6,
      "x": 986,
      "y": 772,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 426092,
      "e": 83232,
      "ty": 7,
      "x": 983,
      "y": 794,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 426108,
      "e": 83248,
      "ty": 2,
      "x": 983,
      "y": 794
    },
    {
      "t": 426208,
      "e": 83348,
      "ty": 2,
      "x": 989,
      "y": 938
    },
    {
      "t": 426258,
      "e": 83398,
      "ty": 41,
      "x": 34218,
      "y": 61540,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 426308,
      "e": 83448,
      "ty": 2,
      "x": 981,
      "y": 1061
    },
    {
      "t": 426409,
      "e": 83549,
      "ty": 2,
      "x": 979,
      "y": 1071
    },
    {
      "t": 426509,
      "e": 83649,
      "ty": 41,
      "x": 33726,
      "y": 65418,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 426517,
      "e": 83657,
      "ty": 6,
      "x": 979,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 426608,
      "e": 83748,
      "ty": 2,
      "x": 983,
      "y": 1077
    },
    {
      "t": 426708,
      "e": 83848,
      "ty": 2,
      "x": 984,
      "y": 1082
    },
    {
      "t": 426758,
      "e": 83898,
      "ty": 41,
      "x": 39594,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 426808,
      "e": 83948,
      "ty": 2,
      "x": 980,
      "y": 1090
    },
    {
      "t": 426908,
      "e": 84048,
      "ty": 2,
      "x": 977,
      "y": 1097
    },
    {
      "t": 427008,
      "e": 84148,
      "ty": 41,
      "x": 36863,
      "y": 46862,
      "ta": "#start"
    },
    {
      "t": 427349,
      "e": 84489,
      "ty": 3,
      "x": 977,
      "y": 1097,
      "ta": "#start"
    },
    {
      "t": 427349,
      "e": 84489,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 427741,
      "e": 84881,
      "ty": 4,
      "x": 36863,
      "y": 46862,
      "ta": "#start"
    },
    {
      "t": 427741,
      "e": 84881,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 427742,
      "e": 84882,
      "ty": 5,
      "x": 977,
      "y": 1097,
      "ta": "#start"
    },
    {
      "t": 427743,
      "e": 84883,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 428743,
      "e": 85883,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 429008,
      "e": 86148,
      "ty": 2,
      "x": 973,
      "y": 1094
    },
    {
      "t": 429008,
      "e": 86148,
      "ty": 41,
      "x": 33232,
      "y": 60161,
      "ta": "html > body"
    },
    {
      "t": 429208,
      "e": 86348,
      "ty": 2,
      "x": 972,
      "y": 1088
    },
    {
      "t": 429259,
      "e": 86399,
      "ty": 41,
      "x": 33129,
      "y": 59496,
      "ta": "html > body"
    },
    {
      "t": 429308,
      "e": 86448,
      "ty": 2,
      "x": 969,
      "y": 1061
    },
    {
      "t": 429508,
      "e": 86648,
      "ty": 41,
      "x": 33094,
      "y": 58333,
      "ta": "html > body"
    },
    {
      "t": 430009,
      "e": 87149,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 432608,
      "e": 89748,
      "ty": 2,
      "x": 970,
      "y": 1063
    },
    {
      "t": 432709,
      "e": 89849,
      "ty": 2,
      "x": 975,
      "y": 1070
    },
    {
      "t": 432758,
      "e": 89898,
      "ty": 41,
      "x": 33301,
      "y": 58887,
      "ta": "html > body"
    },
    {
      "t": 432809,
      "e": 89949,
      "ty": 2,
      "x": 975,
      "y": 1071
    },
    {
      "t": 432908,
      "e": 90048,
      "ty": 2,
      "x": 974,
      "y": 1062
    },
    {
      "t": 433008,
      "e": 90148,
      "ty": 2,
      "x": 981,
      "y": 1043
    },
    {
      "t": 433009,
      "e": 90149,
      "ty": 41,
      "x": 33507,
      "y": 57336,
      "ta": "html > body"
    },
    {
      "t": 433109,
      "e": 90249,
      "ty": 2,
      "x": 984,
      "y": 1033
    },
    {
      "t": 433208,
      "e": 90348,
      "ty": 2,
      "x": 987,
      "y": 1026
    },
    {
      "t": 433258,
      "e": 90398,
      "ty": 41,
      "x": 42860,
      "y": 38618,
      "ta": "> p"
    },
    {
      "t": 433309,
      "e": 90449,
      "ty": 2,
      "x": 988,
      "y": 1024
    },
    {
      "t": 433408,
      "e": 90548,
      "ty": 2,
      "x": 986,
      "y": 1027
    },
    {
      "t": 433508,
      "e": 90648,
      "ty": 2,
      "x": 977,
      "y": 1038
    },
    {
      "t": 433508,
      "e": 90648,
      "ty": 41,
      "x": 33370,
      "y": 57059,
      "ta": "html > body"
    },
    {
      "t": 433608,
      "e": 90748,
      "ty": 2,
      "x": 976,
      "y": 1038
    },
    {
      "t": 433708,
      "e": 90848,
      "ty": 2,
      "x": 985,
      "y": 1009
    },
    {
      "t": 433758,
      "e": 90898,
      "ty": 41,
      "x": 35364,
      "y": 65185,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 433809,
      "e": 90949,
      "ty": 2,
      "x": 1021,
      "y": 981
    },
    {
      "t": 434008,
      "e": 91148,
      "ty": 2,
      "x": 1022,
      "y": 982
    },
    {
      "t": 434008,
      "e": 91148,
      "ty": 41,
      "x": 35801,
      "y": 64952,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 434409,
      "e": 91549,
      "ty": 2,
      "x": 1031,
      "y": 950
    },
    {
      "t": 434509,
      "e": 91649,
      "ty": 41,
      "x": 36238,
      "y": 62467,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 435137,
      "e": 92277,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 436139,
      "e": 93279,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 235, dom: 703, initialDom: 708",
  "javascriptErrors": []
}