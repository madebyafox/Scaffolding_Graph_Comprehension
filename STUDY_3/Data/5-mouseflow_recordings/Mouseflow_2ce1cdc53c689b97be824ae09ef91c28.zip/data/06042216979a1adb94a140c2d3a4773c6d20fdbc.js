var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["06042216979a1adb94a140c2d3a4773c6d20fdbc"] = {
  "startTime": "2018-06-04T20:23:21.9559544Z",
  "websitePageUrl": "/9",
  "visitTime": 44395,
  "engagementTime": 23674,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "2ce1cdc53c689b97be824ae09ef91c28",
    "created": "2018-06-04T20:23:21.9559544+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/9",
    "tags": [
      "form-interact"
    ],
    "variables": [
      "SID=AV66J",
      "CONDITION=211",
      "TRI_CORRECT=1",
      "ORTH_CORRECT=1"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "79592e0d823d8d17906d94a43aa64e5e",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/2ce1cdc53c689b97be824ae09ef91c28/play"
  },
  "events": [
    {
      "t": 0,
      "e": 0,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 1840,
      "e": 1840,
      "ty": 7,
      "x": 529,
      "y": 714,
      "ta": "#testingButton"
    },
    {
      "t": 1900,
      "e": 1900,
      "ty": 2,
      "x": 528,
      "y": 694
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 41,
      "x": 48449,
      "y": 4526,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 10000,
      "e": 7000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 27588,
      "e": 7000,
      "ty": 6,
      "x": 690,
      "y": 622,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[15]"
    },
    {
      "t": 27597,
      "e": 7009,
      "ty": 2,
      "x": 690,
      "y": 622
    },
    {
      "t": 27603,
      "e": 7015,
      "ty": 7,
      "x": 727,
      "y": 599,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[15]"
    },
    {
      "t": 27620,
      "e": 7032,
      "ty": 6,
      "x": 738,
      "y": 586,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[12]"
    },
    {
      "t": 27655,
      "e": 7067,
      "ty": 7,
      "x": 772,
      "y": 556,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[12]"
    },
    {
      "t": 27671,
      "e": 7083,
      "ty": 6,
      "x": 788,
      "y": 549,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[8]"
    },
    {
      "t": 27698,
      "e": 7110,
      "ty": 2,
      "x": 802,
      "y": 545
    },
    {
      "t": 27748,
      "e": 7160,
      "ty": 41,
      "x": 25627,
      "y": 47854,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[8]"
    },
    {
      "t": 27755,
      "e": 7167,
      "ty": 7,
      "x": 826,
      "y": 556,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[8]"
    },
    {
      "t": 27772,
      "e": 7184,
      "ty": 6,
      "x": 842,
      "y": 575,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[12]"
    },
    {
      "t": 27788,
      "e": 7200,
      "ty": 7,
      "x": 883,
      "y": 627,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[12]"
    },
    {
      "t": 27789,
      "e": 7201,
      "ty": 6,
      "x": 883,
      "y": 627,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[16]"
    },
    {
      "t": 27797,
      "e": 7209,
      "ty": 2,
      "x": 883,
      "y": 627
    },
    {
      "t": 27805,
      "e": 7217,
      "ty": 7,
      "x": 971,
      "y": 734,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[16]"
    },
    {
      "t": 27898,
      "e": 7310,
      "ty": 2,
      "x": 1356,
      "y": 1101
    },
    {
      "t": 27997,
      "e": 7409,
      "ty": 2,
      "x": 1403,
      "y": 1114
    },
    {
      "t": 27998,
      "e": 7410,
      "ty": 41,
      "x": 48040,
      "y": 61269,
      "ta": "> div.stimulus"
    },
    {
      "t": 28098,
      "e": 7510,
      "ty": 2,
      "x": 1377,
      "y": 1097
    },
    {
      "t": 28198,
      "e": 7610,
      "ty": 2,
      "x": 1119,
      "y": 874
    },
    {
      "t": 28248,
      "e": 7660,
      "ty": 41,
      "x": 12754,
      "y": 50637,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 28298,
      "e": 7710,
      "ty": 2,
      "x": 1236,
      "y": 813
    },
    {
      "t": 28398,
      "e": 7810,
      "ty": 2,
      "x": 1257,
      "y": 807
    },
    {
      "t": 28498,
      "e": 7910,
      "ty": 2,
      "x": 1258,
      "y": 806
    },
    {
      "t": 28498,
      "e": 7910,
      "ty": 41,
      "x": 19519,
      "y": 47844,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 28598,
      "e": 8010,
      "ty": 2,
      "x": 1297,
      "y": 822
    },
    {
      "t": 28698,
      "e": 8110,
      "ty": 2,
      "x": 1316,
      "y": 832
    },
    {
      "t": 28748,
      "e": 8160,
      "ty": 41,
      "x": 23606,
      "y": 49706,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 28798,
      "e": 8210,
      "ty": 2,
      "x": 1317,
      "y": 832
    },
    {
      "t": 28897,
      "e": 8309,
      "ty": 2,
      "x": 1336,
      "y": 775
    },
    {
      "t": 28997,
      "e": 8409,
      "ty": 2,
      "x": 1352,
      "y": 767
    },
    {
      "t": 28998,
      "e": 8410,
      "ty": 41,
      "x": 56433,
      "y": 54612,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[2] > circle"
    },
    {
      "t": 29098,
      "e": 8510,
      "ty": 2,
      "x": 1357,
      "y": 762
    },
    {
      "t": 29198,
      "e": 8610,
      "ty": 2,
      "x": 1357,
      "y": 759
    },
    {
      "t": 29248,
      "e": 8660,
      "ty": 41,
      "x": 26214,
      "y": 44334,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 29297,
      "e": 8709,
      "ty": 2,
      "x": 1349,
      "y": 755
    },
    {
      "t": 29498,
      "e": 8910,
      "ty": 41,
      "x": 51967,
      "y": 51491,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[2] > text"
    },
    {
      "t": 29597,
      "e": 9009,
      "ty": 2,
      "x": 1348,
      "y": 755
    },
    {
      "t": 29697,
      "e": 9109,
      "ty": 2,
      "x": 1325,
      "y": 789
    },
    {
      "t": 29748,
      "e": 9160,
      "ty": 41,
      "x": 24099,
      "y": 46769,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 29797,
      "e": 9209,
      "ty": 2,
      "x": 1318,
      "y": 805
    },
    {
      "t": 29898,
      "e": 9310,
      "ty": 2,
      "x": 1299,
      "y": 830
    },
    {
      "t": 29998,
      "e": 9410,
      "ty": 2,
      "x": 1283,
      "y": 856
    },
    {
      "t": 29998,
      "e": 9410,
      "ty": 41,
      "x": 21281,
      "y": 51425,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 30098,
      "e": 9510,
      "ty": 2,
      "x": 1260,
      "y": 905
    },
    {
      "t": 30198,
      "e": 9610,
      "ty": 2,
      "x": 1218,
      "y": 970
    },
    {
      "t": 30248,
      "e": 9660,
      "ty": 41,
      "x": 15996,
      "y": 61309,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 30298,
      "e": 9710,
      "ty": 2,
      "x": 1207,
      "y": 999
    },
    {
      "t": 30398,
      "e": 9810,
      "ty": 2,
      "x": 1204,
      "y": 1002
    },
    {
      "t": 30498,
      "e": 9910,
      "ty": 41,
      "x": 15714,
      "y": 61882,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 30598,
      "e": 10010,
      "ty": 2,
      "x": 1204,
      "y": 1003
    },
    {
      "t": 30697,
      "e": 10109,
      "ty": 2,
      "x": 1204,
      "y": 962
    },
    {
      "t": 30749,
      "e": 10161,
      "ty": 41,
      "x": 15925,
      "y": 56009,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 30798,
      "e": 10210,
      "ty": 2,
      "x": 1209,
      "y": 860
    },
    {
      "t": 30898,
      "e": 10310,
      "ty": 2,
      "x": 1179,
      "y": 757
    },
    {
      "t": 30998,
      "e": 10410,
      "ty": 2,
      "x": 1174,
      "y": 737
    },
    {
      "t": 30999,
      "e": 10411,
      "ty": 41,
      "x": 13600,
      "y": 42902,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 31098,
      "e": 10510,
      "ty": 2,
      "x": 1187,
      "y": 744
    },
    {
      "t": 31198,
      "e": 10610,
      "ty": 2,
      "x": 1219,
      "y": 864
    },
    {
      "t": 31248,
      "e": 10660,
      "ty": 41,
      "x": 17687,
      "y": 56725,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 31298,
      "e": 10710,
      "ty": 2,
      "x": 1240,
      "y": 961
    },
    {
      "t": 31398,
      "e": 10810,
      "ty": 2,
      "x": 1260,
      "y": 1010
    },
    {
      "t": 31499,
      "e": 10911,
      "ty": 41,
      "x": 19660,
      "y": 62455,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 31698,
      "e": 11110,
      "ty": 2,
      "x": 1264,
      "y": 993
    },
    {
      "t": 31749,
      "e": 11161,
      "ty": 41,
      "x": 10312,
      "y": 49407,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[7] > text"
    },
    {
      "t": 31798,
      "e": 11210,
      "ty": 2,
      "x": 1270,
      "y": 975
    },
    {
      "t": 31898,
      "e": 11310,
      "ty": 2,
      "x": 1273,
      "y": 968
    },
    {
      "t": 31998,
      "e": 11410,
      "ty": 2,
      "x": 1273,
      "y": 946
    },
    {
      "t": 31998,
      "e": 11410,
      "ty": 41,
      "x": 60292,
      "y": 59964,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[6] > line:[20]"
    },
    {
      "t": 32097,
      "e": 11509,
      "ty": 2,
      "x": 1276,
      "y": 889
    },
    {
      "t": 32198,
      "e": 11610,
      "ty": 2,
      "x": 1284,
      "y": 864
    },
    {
      "t": 32248,
      "e": 11660,
      "ty": 41,
      "x": 37191,
      "y": 37027,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[6] > line:[18]"
    },
    {
      "t": 32299,
      "e": 11661,
      "ty": 2,
      "x": 1291,
      "y": 837
    },
    {
      "t": 32398,
      "e": 11760,
      "ty": 2,
      "x": 1291,
      "y": 828
    },
    {
      "t": 32499,
      "e": 11861,
      "ty": 41,
      "x": 21845,
      "y": 49419,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 32598,
      "e": 11960,
      "ty": 2,
      "x": 1253,
      "y": 906
    },
    {
      "t": 32698,
      "e": 12060,
      "ty": 2,
      "x": 1248,
      "y": 925
    },
    {
      "t": 32748,
      "e": 12110,
      "ty": 41,
      "x": 18603,
      "y": 56868,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 32798,
      "e": 12160,
      "ty": 2,
      "x": 1245,
      "y": 932
    },
    {
      "t": 32898,
      "e": 12260,
      "ty": 2,
      "x": 1169,
      "y": 826
    },
    {
      "t": 32998,
      "e": 12360,
      "ty": 2,
      "x": 1091,
      "y": 626
    },
    {
      "t": 32998,
      "e": 12360,
      "ty": 41,
      "x": 7751,
      "y": 34952,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 33098,
      "e": 12460,
      "ty": 2,
      "x": 1025,
      "y": 581
    },
    {
      "t": 33160,
      "e": 12522,
      "ty": 6,
      "x": 853,
      "y": 544,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[8]"
    },
    {
      "t": 33175,
      "e": 12537,
      "ty": 7,
      "x": 704,
      "y": 531,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[8]"
    },
    {
      "t": 33176,
      "e": 12538,
      "ty": 6,
      "x": 704,
      "y": 531,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[7]"
    },
    {
      "t": 33198,
      "e": 12560,
      "ty": 2,
      "x": 538,
      "y": 531
    },
    {
      "t": 33209,
      "e": 12571,
      "ty": 7,
      "x": 237,
      "y": 526,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[7]"
    },
    {
      "t": 33210,
      "e": 12572,
      "ty": 6,
      "x": 237,
      "y": 526,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[5]"
    },
    {
      "t": 33243,
      "e": 12605,
      "ty": 7,
      "x": 0,
      "y": 531,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[5]"
    },
    {
      "t": 33248,
      "e": 12610,
      "ty": 41,
      "x": 0,
      "y": 29415,
      "ta": "html"
    },
    {
      "t": 33298,
      "e": 12660,
      "ty": 2,
      "x": 0,
      "y": 541
    },
    {
      "t": 33398,
      "e": 12760,
      "ty": 2,
      "x": 19,
      "y": 532
    },
    {
      "t": 33427,
      "e": 12789,
      "ty": 6,
      "x": 59,
      "y": 533,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[5]"
    },
    {
      "t": 33498,
      "e": 12860,
      "ty": 2,
      "x": 207,
      "y": 550
    },
    {
      "t": 33498,
      "e": 12860,
      "ty": 41,
      "x": 46189,
      "y": 54407,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[5]"
    },
    {
      "t": 33527,
      "e": 12889,
      "ty": 7,
      "x": 323,
      "y": 563,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[5]"
    },
    {
      "t": 33527,
      "e": 12889,
      "ty": 6,
      "x": 323,
      "y": 563,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[10]"
    },
    {
      "t": 33598,
      "e": 12960,
      "ty": 2,
      "x": 430,
      "y": 578
    },
    {
      "t": 33748,
      "e": 13110,
      "ty": 41,
      "x": 45436,
      "y": 32562,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[10]"
    },
    {
      "t": 33798,
      "e": 13160,
      "ty": 2,
      "x": 401,
      "y": 568
    },
    {
      "t": 33809,
      "e": 13171,
      "ty": 7,
      "x": 389,
      "y": 562,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[10]"
    },
    {
      "t": 33898,
      "e": 13260,
      "ty": 2,
      "x": 386,
      "y": 560
    },
    {
      "t": 33998,
      "e": 13360,
      "ty": 41,
      "x": 25459,
      "y": 35268,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 34079,
      "e": 13441,
      "ty": 6,
      "x": 435,
      "y": 551,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[6]"
    },
    {
      "t": 34098,
      "e": 13460,
      "ty": 2,
      "x": 460,
      "y": 545
    },
    {
      "t": 34127,
      "e": 13489,
      "ty": 7,
      "x": 511,
      "y": 536,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[6]"
    },
    {
      "t": 34127,
      "e": 13489,
      "ty": 6,
      "x": 511,
      "y": 536,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[7]"
    },
    {
      "t": 34193,
      "e": 13555,
      "ty": 7,
      "x": 633,
      "y": 524,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[7]"
    },
    {
      "t": 34198,
      "e": 13560,
      "ty": 2,
      "x": 633,
      "y": 524
    },
    {
      "t": 34249,
      "e": 13611,
      "ty": 41,
      "x": 44588,
      "y": 25265,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 34298,
      "e": 13660,
      "ty": 2,
      "x": 670,
      "y": 518
    },
    {
      "t": 34398,
      "e": 13760,
      "ty": 2,
      "x": 669,
      "y": 518
    },
    {
      "t": 34498,
      "e": 13860,
      "ty": 2,
      "x": 661,
      "y": 521
    },
    {
      "t": 34498,
      "e": 13860,
      "ty": 41,
      "x": 43981,
      "y": 25980,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 34598,
      "e": 13960,
      "ty": 2,
      "x": 659,
      "y": 521
    },
    {
      "t": 34698,
      "e": 14060,
      "ty": 2,
      "x": 648,
      "y": 523
    },
    {
      "t": 34748,
      "e": 14110,
      "ty": 41,
      "x": 42971,
      "y": 26456,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 34798,
      "e": 14160,
      "ty": 2,
      "x": 646,
      "y": 523
    },
    {
      "t": 36067,
      "e": 15429,
      "ty": 6,
      "x": 654,
      "y": 516,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[3]"
    },
    {
      "t": 36098,
      "e": 15460,
      "ty": 2,
      "x": 680,
      "y": 498
    },
    {
      "t": 36198,
      "e": 15560,
      "ty": 2,
      "x": 702,
      "y": 490
    },
    {
      "t": 36248,
      "e": 15610,
      "ty": 41,
      "x": 58917,
      "y": 6348,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[3]"
    },
    {
      "t": 38699,
      "e": 18061,
      "ty": 7,
      "x": 712,
      "y": 486,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[3]"
    },
    {
      "t": 38701,
      "e": 18063,
      "ty": 2,
      "x": 712,
      "y": 486
    },
    {
      "t": 38731,
      "e": 18093,
      "ty": 6,
      "x": 744,
      "y": 488,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[4]"
    },
    {
      "t": 38747,
      "e": 18109,
      "ty": 41,
      "x": 8778,
      "y": 1979,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[4]"
    },
    {
      "t": 38797,
      "e": 18159,
      "ty": 2,
      "x": 785,
      "y": 490
    },
    {
      "t": 38898,
      "e": 18260,
      "ty": 2,
      "x": 893,
      "y": 501
    },
    {
      "t": 38981,
      "e": 18343,
      "ty": 7,
      "x": 963,
      "y": 532,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[4]"
    },
    {
      "t": 38998,
      "e": 18360,
      "ty": 2,
      "x": 982,
      "y": 546
    },
    {
      "t": 38998,
      "e": 18360,
      "ty": 41,
      "x": 70,
      "y": 29222,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 39098,
      "e": 18460,
      "ty": 2,
      "x": 1084,
      "y": 620
    },
    {
      "t": 39199,
      "e": 18561,
      "ty": 6,
      "x": 942,
      "y": 567,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[12]"
    },
    {
      "t": 39202,
      "e": 18564,
      "ty": 2,
      "x": 942,
      "y": 567
    },
    {
      "t": 39215,
      "e": 18577,
      "ty": 7,
      "x": 918,
      "y": 557,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[12]"
    },
    {
      "t": 39231,
      "e": 18593,
      "ty": 6,
      "x": 878,
      "y": 540,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[8]"
    },
    {
      "t": 39248,
      "e": 18610,
      "ty": 7,
      "x": 821,
      "y": 516,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[8]"
    },
    {
      "t": 39248,
      "e": 18610,
      "ty": 6,
      "x": 821,
      "y": 516,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[4]"
    },
    {
      "t": 39249,
      "e": 18611,
      "ty": 41,
      "x": 27951,
      "y": 63145,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[4]"
    },
    {
      "t": 39298,
      "e": 18660,
      "ty": 2,
      "x": 764,
      "y": 488
    },
    {
      "t": 39398,
      "e": 18760,
      "ty": 2,
      "x": 758,
      "y": 490
    },
    {
      "t": 39431,
      "e": 18793,
      "ty": 7,
      "x": 726,
      "y": 521,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[4]"
    },
    {
      "t": 39449,
      "e": 18811,
      "ty": 6,
      "x": 688,
      "y": 538,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[7]"
    },
    {
      "t": 39481,
      "e": 18843,
      "ty": 7,
      "x": 581,
      "y": 572,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[7]"
    },
    {
      "t": 39481,
      "e": 18843,
      "ty": 6,
      "x": 581,
      "y": 572,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[11]"
    },
    {
      "t": 39497,
      "e": 18859,
      "ty": 2,
      "x": 557,
      "y": 580
    },
    {
      "t": 39497,
      "e": 18859,
      "ty": 41,
      "x": 16794,
      "y": 36931,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[11]"
    },
    {
      "t": 39547,
      "e": 18909,
      "ty": 7,
      "x": 478,
      "y": 589,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[11]"
    },
    {
      "t": 39548,
      "e": 18910,
      "ty": 6,
      "x": 478,
      "y": 589,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[10]"
    },
    {
      "t": 39597,
      "e": 18959,
      "ty": 2,
      "x": 464,
      "y": 590
    },
    {
      "t": 39698,
      "e": 19060,
      "ty": 2,
      "x": 425,
      "y": 586
    },
    {
      "t": 39748,
      "e": 19060,
      "ty": 41,
      "x": 32948,
      "y": 38445,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[10] > label"
    },
    {
      "t": 39798,
      "e": 19110,
      "ty": 2,
      "x": 392,
      "y": 577
    },
    {
      "t": 39998,
      "e": 19310,
      "ty": 2,
      "x": 377,
      "y": 582
    },
    {
      "t": 39998,
      "e": 19310,
      "ty": 41,
      "x": 7475,
      "y": 42290,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[10] > label > div"
    },
    {
      "t": 40032,
      "e": 19344,
      "ty": 7,
      "x": 360,
      "y": 596,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[10]"
    },
    {
      "t": 40082,
      "e": 19394,
      "ty": 6,
      "x": 354,
      "y": 608,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[14]"
    },
    {
      "t": 40098,
      "e": 19410,
      "ty": 2,
      "x": 354,
      "y": 608
    },
    {
      "t": 40165,
      "e": 19477,
      "ty": 7,
      "x": 372,
      "y": 633,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[14]"
    },
    {
      "t": 40199,
      "e": 19511,
      "ty": 2,
      "x": 382,
      "y": 638
    },
    {
      "t": 40199,
      "e": 19511,
      "ty": 6,
      "x": 397,
      "y": 644,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[18]"
    },
    {
      "t": 40249,
      "e": 19561,
      "ty": 41,
      "x": 45436,
      "y": 34747,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[18]"
    },
    {
      "t": 40298,
      "e": 19610,
      "ty": 2,
      "x": 462,
      "y": 645
    },
    {
      "t": 40299,
      "e": 19611,
      "ty": 7,
      "x": 474,
      "y": 636,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[18]"
    },
    {
      "t": 40315,
      "e": 19627,
      "ty": 6,
      "x": 491,
      "y": 622,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[14]"
    },
    {
      "t": 40331,
      "e": 19643,
      "ty": 7,
      "x": 507,
      "y": 608,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[14]"
    },
    {
      "t": 40332,
      "e": 19644,
      "ty": 6,
      "x": 507,
      "y": 608,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[15]"
    },
    {
      "t": 40349,
      "e": 19661,
      "ty": 7,
      "x": 523,
      "y": 596,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[15]"
    },
    {
      "t": 40366,
      "e": 19678,
      "ty": 6,
      "x": 543,
      "y": 585,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[11]"
    },
    {
      "t": 40398,
      "e": 19710,
      "ty": 2,
      "x": 570,
      "y": 568
    },
    {
      "t": 40399,
      "e": 19711,
      "ty": 7,
      "x": 590,
      "y": 555,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[11]"
    },
    {
      "t": 40399,
      "e": 19711,
      "ty": 6,
      "x": 590,
      "y": 555,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[7]"
    },
    {
      "t": 40448,
      "e": 19760,
      "ty": 7,
      "x": 634,
      "y": 521,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[7]"
    },
    {
      "t": 40465,
      "e": 19777,
      "ty": 6,
      "x": 640,
      "y": 516,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[3]"
    },
    {
      "t": 40498,
      "e": 19810,
      "ty": 2,
      "x": 641,
      "y": 515
    },
    {
      "t": 40498,
      "e": 19810,
      "ty": 41,
      "x": 41196,
      "y": 60961,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[3]"
    },
    {
      "t": 40598,
      "e": 19910,
      "ty": 2,
      "x": 665,
      "y": 510
    },
    {
      "t": 40665,
      "e": 19977,
      "ty": 7,
      "x": 685,
      "y": 533,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[3]"
    },
    {
      "t": 40665,
      "e": 19977,
      "ty": 6,
      "x": 685,
      "y": 533,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[7]"
    },
    {
      "t": 40699,
      "e": 20011,
      "ty": 2,
      "x": 690,
      "y": 550
    },
    {
      "t": 40699,
      "e": 20011,
      "ty": 7,
      "x": 695,
      "y": 564,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[7]"
    },
    {
      "t": 40699,
      "e": 20011,
      "ty": 6,
      "x": 695,
      "y": 564,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[11]"
    },
    {
      "t": 40748,
      "e": 20060,
      "ty": 41,
      "x": 56883,
      "y": 47854,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[11]"
    },
    {
      "t": 40748,
      "e": 20060,
      "ty": 7,
      "x": 689,
      "y": 597,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[11]"
    },
    {
      "t": 40766,
      "e": 20078,
      "ty": 6,
      "x": 685,
      "y": 604,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[15]"
    },
    {
      "t": 40798,
      "e": 20110,
      "ty": 2,
      "x": 677,
      "y": 608
    },
    {
      "t": 40898,
      "e": 20210,
      "ty": 2,
      "x": 577,
      "y": 619
    },
    {
      "t": 40933,
      "e": 20245,
      "ty": 7,
      "x": 517,
      "y": 596,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[15]"
    },
    {
      "t": 40949,
      "e": 20261,
      "ty": 6,
      "x": 506,
      "y": 592,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[11]"
    },
    {
      "t": 40966,
      "e": 20278,
      "ty": 7,
      "x": 493,
      "y": 583,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[11]"
    },
    {
      "t": 40966,
      "e": 20278,
      "ty": 6,
      "x": 493,
      "y": 583,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[10]"
    },
    {
      "t": 40998,
      "e": 20310,
      "ty": 2,
      "x": 482,
      "y": 576
    },
    {
      "t": 40998,
      "e": 20310,
      "ty": 41,
      "x": 60542,
      "y": 28193,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[10]"
    },
    {
      "t": 41098,
      "e": 20410,
      "ty": 2,
      "x": 467,
      "y": 564
    },
    {
      "t": 41100,
      "e": 20412,
      "ty": 7,
      "x": 461,
      "y": 555,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[10]"
    },
    {
      "t": 41101,
      "e": 20413,
      "ty": 6,
      "x": 461,
      "y": 555,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[6]"
    },
    {
      "t": 41133,
      "e": 20445,
      "ty": 7,
      "x": 436,
      "y": 521,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[6]"
    },
    {
      "t": 41150,
      "e": 20462,
      "ty": 6,
      "x": 427,
      "y": 511,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[2]"
    },
    {
      "t": 41198,
      "e": 20510,
      "ty": 2,
      "x": 424,
      "y": 507
    },
    {
      "t": 41248,
      "e": 20560,
      "ty": 41,
      "x": 42821,
      "y": 41300,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[2]"
    },
    {
      "t": 41298,
      "e": 20610,
      "ty": 2,
      "x": 413,
      "y": 510
    },
    {
      "t": 41316,
      "e": 20628,
      "ty": 7,
      "x": 393,
      "y": 525,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[2]"
    },
    {
      "t": 41316,
      "e": 20628,
      "ty": 6,
      "x": 393,
      "y": 525,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[6]"
    },
    {
      "t": 41399,
      "e": 20711,
      "ty": 2,
      "x": 331,
      "y": 544
    },
    {
      "t": 41499,
      "e": 20811,
      "ty": 2,
      "x": 282,
      "y": 529
    },
    {
      "t": 41499,
      "e": 20811,
      "ty": 41,
      "x": 2442,
      "y": 8533,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[6]"
    },
    {
      "t": 41516,
      "e": 20828,
      "ty": 7,
      "x": 270,
      "y": 525,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[6]"
    },
    {
      "t": 41517,
      "e": 20829,
      "ty": 6,
      "x": 270,
      "y": 525,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[5]"
    },
    {
      "t": 41532,
      "e": 20844,
      "ty": 7,
      "x": 266,
      "y": 523,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[5]"
    },
    {
      "t": 41566,
      "e": 20878,
      "ty": 6,
      "x": 239,
      "y": 516,
      "ta": "#bigset.starttime+before+endtime+during > ul > li"
    },
    {
      "t": 41598,
      "e": 20910,
      "ty": 2,
      "x": 217,
      "y": 512
    },
    {
      "t": 41698,
      "e": 21010,
      "ty": 2,
      "x": 178,
      "y": 508
    },
    {
      "t": 41749,
      "e": 21061,
      "ty": 41,
      "x": 39807,
      "y": 47382,
      "ta": "#bigset.starttime+before+endtime+during > ul > li > label"
    },
    {
      "t": 41798,
      "e": 21110,
      "ty": 2,
      "x": 173,
      "y": 506
    },
    {
      "t": 41883,
      "e": 21195,
      "ty": 3,
      "x": 170,
      "y": 506,
      "ta": "#bigset.starttime+before+endtime+during > ul > li > label > div"
    },
    {
      "t": 41898,
      "e": 21210,
      "ty": 2,
      "x": 170,
      "y": 506
    },
    {
      "t": 41961,
      "e": 21273,
      "ty": 4,
      "x": 55653,
      "y": 42290,
      "ta": "#bigset.starttime+before+endtime+during > ul > li > label > div"
    },
    {
      "t": 41961,
      "e": 21273,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#bigset.starttime+before+endtime+during > ul > li > label > input"
    },
    {
      "t": 41965,
      "e": 21277,
      "ty": 5,
      "x": 170,
      "y": 506,
      "ta": "#bigset.starttime+before+endtime+during > ul > li > label > input"
    },
    {
      "t": 41965,
      "e": 21277,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#bigset.starttime+before+endtime+during > ul > li > label > input",
      "v": "I"
    },
    {
      "t": 41999,
      "e": 21278,
      "ty": 41,
      "x": 55653,
      "y": 42290,
      "ta": "#bigset.starttime+before+endtime+during > ul > li > label > div"
    },
    {
      "t": 42098,
      "e": 21377,
      "ty": 2,
      "x": 178,
      "y": 509
    },
    {
      "t": 42117,
      "e": 21396,
      "ty": 7,
      "x": 196,
      "y": 519,
      "ta": "#bigset.starttime+before+endtime+during > ul > li"
    },
    {
      "t": 42132,
      "e": 21411,
      "ty": 6,
      "x": 210,
      "y": 526,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[5]"
    },
    {
      "t": 42184,
      "e": 21463,
      "ty": 7,
      "x": 276,
      "y": 554,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[5]"
    },
    {
      "t": 42184,
      "e": 21463,
      "ty": 6,
      "x": 276,
      "y": 554,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[6]"
    },
    {
      "t": 42198,
      "e": 21477,
      "ty": 2,
      "x": 276,
      "y": 554
    },
    {
      "t": 42201,
      "e": 21480,
      "ty": 7,
      "x": 313,
      "y": 571,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[6]"
    },
    {
      "t": 42201,
      "e": 21480,
      "ty": 6,
      "x": 313,
      "y": 571,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[10]"
    },
    {
      "t": 42233,
      "e": 21512,
      "ty": 7,
      "x": 365,
      "y": 594,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[10]"
    },
    {
      "t": 42249,
      "e": 21528,
      "ty": 41,
      "x": 24045,
      "y": 43365,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 42284,
      "e": 21563,
      "ty": 6,
      "x": 377,
      "y": 604,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[14]"
    },
    {
      "t": 42298,
      "e": 21577,
      "ty": 2,
      "x": 377,
      "y": 604
    },
    {
      "t": 42317,
      "e": 21596,
      "ty": 7,
      "x": 397,
      "y": 673,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[14]"
    },
    {
      "t": 42398,
      "e": 21677,
      "ty": 2,
      "x": 425,
      "y": 738
    },
    {
      "t": 42498,
      "e": 21777,
      "ty": 2,
      "x": 432,
      "y": 778
    },
    {
      "t": 42499,
      "e": 21778,
      "ty": 41,
      "x": 3510,
      "y": 59575,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 42598,
      "e": 21877,
      "ty": 2,
      "x": 495,
      "y": 763
    },
    {
      "t": 42601,
      "e": 21880,
      "ty": 6,
      "x": 520,
      "y": 751,
      "ta": "#testingButton"
    },
    {
      "t": 42699,
      "e": 21978,
      "ty": 2,
      "x": 540,
      "y": 742
    },
    {
      "t": 42748,
      "e": 22027,
      "ty": 41,
      "x": 52701,
      "y": 38369,
      "ta": "#testingButton"
    },
    {
      "t": 42799,
      "e": 22078,
      "ty": 2,
      "x": 541,
      "y": 740
    },
    {
      "t": 42898,
      "e": 22177,
      "ty": 2,
      "x": 541,
      "y": 739
    },
    {
      "t": 42998,
      "e": 22277,
      "ty": 2,
      "x": 541,
      "y": 738
    },
    {
      "t": 42998,
      "e": 22277,
      "ty": 41,
      "x": 52701,
      "y": 34514,
      "ta": "#testingButton"
    },
    {
      "t": 43099,
      "e": 22378,
      "ty": 2,
      "x": 539,
      "y": 738
    },
    {
      "t": 43248,
      "e": 22527,
      "ty": 41,
      "x": 51608,
      "y": 34514,
      "ta": "#testingButton"
    },
    {
      "t": 43275,
      "e": 22554,
      "ty": 3,
      "x": 539,
      "y": 738,
      "ta": "#testingButton"
    },
    {
      "t": 43276,
      "e": 22555,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#bigset.starttime+before+endtime+during > ul > li > label > input"
    },
    {
      "t": 43277,
      "e": 22556,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#testingButton"
    },
    {
      "t": 43369,
      "e": 22648,
      "ty": 4,
      "x": 51608,
      "y": 34514,
      "ta": "#testingButton"
    },
    {
      "t": 43378,
      "e": 22657,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#testingButton"
    },
    {
      "t": 43381,
      "e": 22660,
      "ty": 5,
      "x": 539,
      "y": 738,
      "ta": "#testingButton"
    },
    {
      "t": 43386,
      "e": 22665,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 43748,
      "e": 23027,
      "ty": 41,
      "x": 18251,
      "y": 40440,
      "ta": "html > body"
    },
    {
      "t": 43798,
      "e": 23077,
      "ty": 2,
      "x": 538,
      "y": 738
    },
    {
      "t": 44395,
      "e": 23674,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    }
  ],
  "useCssProxy": true,
  "loadTimes": "es: 250, dom: 291, initialDom: 291",
  "javascriptErrors": []
}