var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "1af13a0e274b0a19bded3efd948321c8",
  "created": "2018-06-01T11:25:06.8507554-07:00",
  "lastActivity": "2018-06-01T11:25:35.2816332-07:00",
  "pageViews": [
    {
      "id": "06010670812a49558b353e48c49196d951e661f8",
      "startTime": "2018-06-01T11:25:06.9766833-07:00",
      "endTime": "2018-06-01T11:25:35.2816332-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 28669,
      "engagementTime": 28669,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 28669,
  "engagementTime": 28669,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.43",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=FBPNS",
    "CONDITION=311",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "98ed197b7cf156bdf563a57378e0a25e",
  "gdpr": false
}