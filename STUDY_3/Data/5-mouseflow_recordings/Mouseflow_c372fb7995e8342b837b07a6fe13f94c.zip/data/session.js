var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "c372fb7995e8342b837b07a6fe13f94c",
  "created": "2018-05-29T12:13:58.9940953-07:00",
  "lastActivity": "2018-05-29T12:15:33.0915308-07:00",
  "pageViews": [
    {
      "id": "052959638a6a82ebfd531512e41a257dd68c261e",
      "startTime": "2018-05-29T12:13:58.9940953-07:00",
      "endTime": "2018-05-29T12:15:33.0915308-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 94361,
      "engagementTime": 88799,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 94361,
  "engagementTime": 88799,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=MD6NK",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "8deb150f71ecb6d6a30b8ee63f3d956a",
  "gdpr": false
}