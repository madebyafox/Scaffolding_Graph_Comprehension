var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "057882bb5c5ca96777bb6b3b9640791e",
  "created": "2018-05-22T13:16:07.2301937-07:00",
  "lastActivity": "2018-05-22T13:16:12.4957422-07:00",
  "pageViews": [
    {
      "id": "05220776e913c03b81b84d8edcf2ff0b87fb9b29",
      "startTime": "2018-05-22T13:16:07.4437422-07:00",
      "endTime": "2018-05-22T13:16:12.4957422-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/12",
      "visitTime": 5052,
      "engagementTime": 5052,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 5052,
  "engagementTime": 5052,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.24",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=DM4T0",
    "CONDITION=121",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "56c742d14785072a262954f751f7c3d3",
  "gdpr": false
}