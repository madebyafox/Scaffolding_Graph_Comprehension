var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "e1cf95c2f51fde57e4b2e5f9a98db41e",
  "created": "2018-05-14T14:09:47.914938-07:00",
  "lastActivity": "2018-05-14T14:11:42.370938-07:00",
  "pageViews": [
    {
      "id": "05144891c25f78053b780a2169e45f5e13e02150",
      "startTime": "2018-05-14T14:09:47.914938-07:00",
      "endTime": "2018-05-14T14:11:42.370938-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 114456,
      "engagementTime": 93508,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 114456,
  "engagementTime": 93508,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=L0W0F",
    "CONDITION=111",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d8ee35bfef24d0792c36432b2b7a190f",
  "gdpr": false
}