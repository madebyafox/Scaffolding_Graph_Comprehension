var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052920886aa06bcb307a512fb597e57aad7a031a"] = {
  "startTime": "2018-05-29T22:17:20.1549158Z",
  "websitePageUrl": "/16",
  "visitTime": 75082,
  "engagementTime": 67155,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "7ca8dd595c5df88365eff19d4fcf004f",
    "created": "2018-05-29T22:17:20.1255558+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=8TUB0",
      "CONDITION=114"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "6cd94ee41172fd008c468c90240cff09",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/7ca8dd595c5df88365eff19d4fcf004f/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 184,
      "e": 184,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 501,
      "e": 501,
      "ty": 2,
      "x": 474,
      "y": 743
    },
    {
      "t": 501,
      "e": 501,
      "ty": 41,
      "x": 42368,
      "y": 40717,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 658,
      "e": 658,
      "ty": 2,
      "x": 473,
      "y": 744
    },
    {
      "t": 751,
      "e": 751,
      "ty": 41,
      "x": 42255,
      "y": 40772,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1601,
      "e": 1601,
      "ty": 2,
      "x": 472,
      "y": 700
    },
    {
      "t": 1701,
      "e": 1701,
      "ty": 2,
      "x": 472,
      "y": 624
    },
    {
      "t": 1750,
      "e": 1750,
      "ty": 41,
      "x": 41918,
      "y": 63387,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 470,
      "y": 613
    },
    {
      "t": 1837,
      "e": 1837,
      "ty": 6,
      "x": 469,
      "y": 602,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1901,
      "e": 1901,
      "ty": 2,
      "x": 469,
      "y": 587
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 2,
      "x": 466,
      "y": 570
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 41468,
      "y": 38241,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2632,
      "e": 2632,
      "ty": 3,
      "x": 466,
      "y": 570,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2633,
      "e": 2633,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2783,
      "e": 2783,
      "ty": 4,
      "x": 41468,
      "y": 38241,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2783,
      "e": 2783,
      "ty": 5,
      "x": 466,
      "y": 570,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10000,
      "e": 7783,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10603,
      "e": 7783,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 10603,
      "e": 7783,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10706,
      "e": 7886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i"
    },
    {
      "t": 10866,
      "e": 8046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10867,
      "e": 8047,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11002,
      "e": 8182,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i "
    },
    {
      "t": 11034,
      "e": 8214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i "
    },
    {
      "t": 11171,
      "e": 8351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 11171,
      "e": 8351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11251,
      "e": 8431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i f"
    },
    {
      "t": 11436,
      "e": 8616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 11436,
      "e": 8616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11515,
      "e": 8695,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i fi"
    },
    {
      "t": 11708,
      "e": 8888,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 11708,
      "e": 8888,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11795,
      "e": 8975,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 12036,
      "e": 9216,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 12036,
      "e": 9216,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12130,
      "e": 9310,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 12291,
      "e": 9471,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12292,
      "e": 9472,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12395,
      "e": 9575,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12707,
      "e": 9887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 12708,
      "e": 9888,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12787,
      "e": 9967,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 13107,
      "e": 10287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 13108,
      "e": 10288,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13202,
      "e": 10382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 13571,
      "e": 10751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13572,
      "e": 10752,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13674,
      "e": 10854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14323,
      "e": 11503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14324,
      "e": 11504,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14394,
      "e": 11574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 14572,
      "e": 11752,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 14572,
      "e": 11752,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14651,
      "e": 11831,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 15667,
      "e": 12847,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15754,
      "e": 12934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i find 12 t"
    },
    {
      "t": 16011,
      "e": 13191,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 16011,
      "e": 13191,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16092,
      "e": 13272,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 16203,
      "e": 13383,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i find 12 th"
    },
    {
      "t": 16307,
      "e": 13487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 16308,
      "e": 13488,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16379,
      "e": 13559,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 16835,
      "e": 14015,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 16835,
      "e": 14015,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16932,
      "e": 14112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 17099,
      "e": 14279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17100,
      "e": 14280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17202,
      "e": 14382,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i find 12 then "
    },
    {
      "t": 17202,
      "e": 14382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17443,
      "e": 14623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 17444,
      "e": 14624,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17546,
      "e": 14726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 17715,
      "e": 14895,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 17716,
      "e": 14896,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17802,
      "e": 14982,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 17875,
      "e": 15055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 17875,
      "e": 15055,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17939,
      "e": 15119,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 18115,
      "e": 15295,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 18117,
      "e": 15297,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18187,
      "e": 15367,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 18395,
      "e": 15575,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18396,
      "e": 15576,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18538,
      "e": 15718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19091,
      "e": 16271,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 19092,
      "e": 16272,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19195,
      "e": 16375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 19307,
      "e": 16487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 19308,
      "e": 16488,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19435,
      "e": 16615,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 20001,
      "e": 17181,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 22324,
      "e": 19504,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22325,
      "e": 19505,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22435,
      "e": 19615,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22691,
      "e": 19871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22691,
      "e": 19871,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22763,
      "e": 19943,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 23588,
      "e": 20768,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 23588,
      "e": 20768,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23682,
      "e": 20862,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 23947,
      "e": 21127,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23947,
      "e": 21127,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24010,
      "e": 21190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 24422,
      "e": 21602,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24422,
      "e": 21602,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24557,
      "e": 21737,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24702,
      "e": 21882,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 24702,
      "e": 21882,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24772,
      "e": 21952,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 24942,
      "e": 22122,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24943,
      "e": 22123,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25070,
      "e": 22250,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25342,
      "e": 22522,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 25342,
      "e": 22522,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25429,
      "e": 22609,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 25581,
      "e": 22761,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 25582,
      "e": 22762,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25660,
      "e": 22840,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 25925,
      "e": 23105,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 25925,
      "e": 23105,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26045,
      "e": 23225,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 26253,
      "e": 23433,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 26254,
      "e": 23434,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26316,
      "e": 23496,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 27278,
      "e": 24458,
      "ty": 7,
      "x": 459,
      "y": 624,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27294,
      "e": 24474,
      "ty": 6,
      "x": 453,
      "y": 655,
      "ta": "#strategyButton"
    },
    {
      "t": 27303,
      "e": 24483,
      "ty": 2,
      "x": 453,
      "y": 655
    },
    {
      "t": 27327,
      "e": 24507,
      "ty": 7,
      "x": 431,
      "y": 693,
      "ta": "#strategyButton"
    },
    {
      "t": 27403,
      "e": 24583,
      "ty": 2,
      "x": 423,
      "y": 704
    },
    {
      "t": 27495,
      "e": 24675,
      "ty": 6,
      "x": 362,
      "y": 681,
      "ta": "#strategyButton"
    },
    {
      "t": 27503,
      "e": 24683,
      "ty": 2,
      "x": 362,
      "y": 681
    },
    {
      "t": 27503,
      "e": 24683,
      "ty": 41,
      "x": 12782,
      "y": 50626,
      "ta": "#strategyButton"
    },
    {
      "t": 27561,
      "e": 24741,
      "ty": 7,
      "x": 353,
      "y": 650,
      "ta": "#strategyButton"
    },
    {
      "t": 27603,
      "e": 24783,
      "ty": 2,
      "x": 353,
      "y": 650
    },
    {
      "t": 27754,
      "e": 24934,
      "ty": 41,
      "x": 16105,
      "y": 18523,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 27862,
      "e": 25042,
      "ty": 6,
      "x": 356,
      "y": 660,
      "ta": "#strategyButton"
    },
    {
      "t": 27903,
      "e": 25083,
      "ty": 2,
      "x": 361,
      "y": 665
    },
    {
      "t": 28003,
      "e": 25183,
      "ty": 2,
      "x": 367,
      "y": 668
    },
    {
      "t": 28003,
      "e": 25183,
      "ty": 41,
      "x": 15513,
      "y": 25569,
      "ta": "#strategyButton"
    },
    {
      "t": 28139,
      "e": 25319,
      "ty": 3,
      "x": 367,
      "y": 668,
      "ta": "#strategyButton"
    },
    {
      "t": 28140,
      "e": 25320,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i find 12 then look up the y axis"
    },
    {
      "t": 28141,
      "e": 25321,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28142,
      "e": 25322,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 28241,
      "e": 25421,
      "ty": 4,
      "x": 15513,
      "y": 25569,
      "ta": "#strategyButton"
    },
    {
      "t": 28254,
      "e": 25434,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 28255,
      "e": 25435,
      "ty": 5,
      "x": 367,
      "y": 668,
      "ta": "#strategyButton"
    },
    {
      "t": 28262,
      "e": 25442,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 28603,
      "e": 25783,
      "ty": 2,
      "x": 465,
      "y": 766
    },
    {
      "t": 28703,
      "e": 25883,
      "ty": 2,
      "x": 713,
      "y": 1034
    },
    {
      "t": 28753,
      "e": 25933,
      "ty": 41,
      "x": 26103,
      "y": 60770,
      "ta": "html > body"
    },
    {
      "t": 28802,
      "e": 25982,
      "ty": 2,
      "x": 770,
      "y": 1117
    },
    {
      "t": 28903,
      "e": 26083,
      "ty": 2,
      "x": 763,
      "y": 1122
    },
    {
      "t": 29003,
      "e": 26183,
      "ty": 2,
      "x": 761,
      "y": 1122
    },
    {
      "t": 29003,
      "e": 26183,
      "ty": 41,
      "x": 25931,
      "y": 61712,
      "ta": "html > body"
    },
    {
      "t": 29103,
      "e": 26283,
      "ty": 2,
      "x": 752,
      "y": 1123
    },
    {
      "t": 29203,
      "e": 26383,
      "ty": 2,
      "x": 761,
      "y": 1199
    },
    {
      "t": 29262,
      "e": 26442,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 29303,
      "e": 26483,
      "ty": 2,
      "x": 826,
      "y": 1199
    },
    {
      "t": 29402,
      "e": 26582,
      "ty": 2,
      "x": 897,
      "y": 1199
    },
    {
      "t": 29502,
      "e": 26682,
      "ty": 2,
      "x": 1034,
      "y": 1199
    },
    {
      "t": 29603,
      "e": 26783,
      "ty": 2,
      "x": 1074,
      "y": 1183
    },
    {
      "t": 29703,
      "e": 26883,
      "ty": 2,
      "x": 1289,
      "y": 827
    },
    {
      "t": 29753,
      "e": 26933,
      "ty": 41,
      "x": 46077,
      "y": 35731,
      "ta": "html > body"
    },
    {
      "t": 29803,
      "e": 26983,
      "ty": 2,
      "x": 1363,
      "y": 584
    },
    {
      "t": 29903,
      "e": 27083,
      "ty": 2,
      "x": 1308,
      "y": 462
    },
    {
      "t": 30003,
      "e": 27183,
      "ty": 2,
      "x": 1053,
      "y": 500
    },
    {
      "t": 30003,
      "e": 27183,
      "ty": 41,
      "x": 52990,
      "y": 7046,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 30003,
      "e": 27183,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30103,
      "e": 27283,
      "ty": 2,
      "x": 949,
      "y": 544
    },
    {
      "t": 30203,
      "e": 27383,
      "ty": 2,
      "x": 946,
      "y": 546
    },
    {
      "t": 30247,
      "e": 27427,
      "ty": 6,
      "x": 933,
      "y": 557,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 30253,
      "e": 27433,
      "ty": 41,
      "x": 27035,
      "y": 9362,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 30303,
      "e": 27483,
      "ty": 2,
      "x": 929,
      "y": 560
    },
    {
      "t": 30426,
      "e": 27606,
      "ty": 3,
      "x": 929,
      "y": 560,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 30428,
      "e": 27608,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 30503,
      "e": 27683,
      "ty": 41,
      "x": 26170,
      "y": 18724,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 30529,
      "e": 27709,
      "ty": 4,
      "x": 26170,
      "y": 18724,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 30529,
      "e": 27709,
      "ty": 5,
      "x": 929,
      "y": 560,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 31637,
      "e": 28817,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 31638,
      "e": 28818,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 31750,
      "e": 28930,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 31751,
      "e": 28931,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 31836,
      "e": 29016,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 31869,
      "e": 29049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 32732,
      "e": 29912,
      "ty": 7,
      "x": 929,
      "y": 580,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32753,
      "e": 29933,
      "ty": 41,
      "x": 26170,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 32781,
      "e": 29961,
      "ty": 6,
      "x": 918,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 32803,
      "e": 29983,
      "ty": 2,
      "x": 909,
      "y": 665
    },
    {
      "t": 32814,
      "e": 29994,
      "ty": 7,
      "x": 907,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 32903,
      "e": 30083,
      "ty": 2,
      "x": 901,
      "y": 674
    },
    {
      "t": 33003,
      "e": 30183,
      "ty": 41,
      "x": 20114,
      "y": 64125,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 33253,
      "e": 30433,
      "ty": 41,
      "x": 19682,
      "y": 62716,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 33266,
      "e": 30446,
      "ty": 6,
      "x": 897,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33303,
      "e": 30483,
      "ty": 2,
      "x": 895,
      "y": 662
    },
    {
      "t": 33395,
      "e": 30575,
      "ty": 3,
      "x": 894,
      "y": 661,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33395,
      "e": 30575,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 33396,
      "e": 30576,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 33396,
      "e": 30576,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33403,
      "e": 30583,
      "ty": 2,
      "x": 894,
      "y": 661
    },
    {
      "t": 33503,
      "e": 30683,
      "ty": 41,
      "x": 18600,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33513,
      "e": 30693,
      "ty": 4,
      "x": 18600,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33513,
      "e": 30693,
      "ty": 5,
      "x": 894,
      "y": 661,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 34366,
      "e": 31546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 34367,
      "e": 31547,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 34437,
      "e": 31617,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "u"
    },
    {
      "t": 34926,
      "e": 32106,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 34927,
      "e": 32107,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 34989,
      "e": 32169,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "us"
    },
    {
      "t": 35109,
      "e": 32289,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 35110,
      "e": 32290,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 35172,
      "e": 32352,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "usa"
    },
    {
      "t": 35951,
      "e": 33131,
      "ty": 7,
      "x": 939,
      "y": 672,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 35968,
      "e": 33148,
      "ty": 6,
      "x": 981,
      "y": 684,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 36003,
      "e": 33183,
      "ty": 2,
      "x": 1013,
      "y": 700
    },
    {
      "t": 36003,
      "e": 33183,
      "ty": 41,
      "x": 60340,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 36103,
      "e": 33283,
      "ty": 2,
      "x": 1013,
      "y": 707
    },
    {
      "t": 36117,
      "e": 33297,
      "ty": 7,
      "x": 1012,
      "y": 709,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 36204,
      "e": 33384,
      "ty": 2,
      "x": 1006,
      "y": 716
    },
    {
      "t": 36235,
      "e": 33415,
      "ty": 6,
      "x": 1001,
      "y": 704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 36254,
      "e": 33434,
      "ty": 41,
      "x": 53640,
      "y": 39718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 36304,
      "e": 33484,
      "ty": 2,
      "x": 995,
      "y": 687
    },
    {
      "t": 36403,
      "e": 33583,
      "ty": 2,
      "x": 989,
      "y": 686
    },
    {
      "t": 36442,
      "e": 33622,
      "ty": 3,
      "x": 988,
      "y": 686,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 36443,
      "e": 33623,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "usa"
    },
    {
      "t": 36443,
      "e": 33623,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36445,
      "e": 33625,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 36503,
      "e": 33683,
      "ty": 2,
      "x": 985,
      "y": 687
    },
    {
      "t": 36503,
      "e": 33683,
      "ty": 41,
      "x": 45909,
      "y": 21845,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 36529,
      "e": 33709,
      "ty": 4,
      "x": 43848,
      "y": 23830,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 36529,
      "e": 33709,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 36529,
      "e": 33709,
      "ty": 5,
      "x": 981,
      "y": 688,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 36530,
      "e": 33710,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 36603,
      "e": 33783,
      "ty": 2,
      "x": 981,
      "y": 688
    },
    {
      "t": 36753,
      "e": 33933,
      "ty": 41,
      "x": 33507,
      "y": 37670,
      "ta": "html > body"
    },
    {
      "t": 37552,
      "e": 34732,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 37703,
      "e": 34883,
      "ty": 2,
      "x": 982,
      "y": 688
    },
    {
      "t": 37754,
      "e": 34934,
      "ty": 41,
      "x": 38109,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 38203,
      "e": 35383,
      "ty": 2,
      "x": 983,
      "y": 687
    },
    {
      "t": 38253,
      "e": 35433,
      "ty": 41,
      "x": 38346,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 38303,
      "e": 35483,
      "ty": 2,
      "x": 983,
      "y": 537
    },
    {
      "t": 38404,
      "e": 35584,
      "ty": 2,
      "x": 952,
      "y": 313
    },
    {
      "t": 38503,
      "e": 35683,
      "ty": 2,
      "x": 929,
      "y": 246
    },
    {
      "t": 38503,
      "e": 35683,
      "ty": 41,
      "x": 25530,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 38603,
      "e": 35783,
      "ty": 2,
      "x": 904,
      "y": 213
    },
    {
      "t": 38703,
      "e": 35883,
      "ty": 2,
      "x": 899,
      "y": 213
    },
    {
      "t": 38753,
      "e": 35933,
      "ty": 41,
      "x": 17936,
      "y": 14102,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 38804,
      "e": 35984,
      "ty": 2,
      "x": 886,
      "y": 223
    },
    {
      "t": 38903,
      "e": 36083,
      "ty": 2,
      "x": 872,
      "y": 235
    },
    {
      "t": 39003,
      "e": 36183,
      "ty": 2,
      "x": 868,
      "y": 237
    },
    {
      "t": 39004,
      "e": 36184,
      "ty": 41,
      "x": 38141,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 39114,
      "e": 36294,
      "ty": 3,
      "x": 868,
      "y": 237,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 39203,
      "e": 36383,
      "ty": 2,
      "x": 867,
      "y": 238
    },
    {
      "t": 39225,
      "e": 36405,
      "ty": 4,
      "x": 37322,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 39225,
      "e": 36405,
      "ty": 5,
      "x": 867,
      "y": 238,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 39226,
      "e": 36406,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 39227,
      "e": 36407,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 39253,
      "e": 36433,
      "ty": 41,
      "x": 37322,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 39503,
      "e": 36683,
      "ty": 2,
      "x": 861,
      "y": 240
    },
    {
      "t": 39503,
      "e": 36683,
      "ty": 41,
      "x": 32409,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 39604,
      "e": 36784,
      "ty": 2,
      "x": 856,
      "y": 256
    },
    {
      "t": 39703,
      "e": 36883,
      "ty": 2,
      "x": 876,
      "y": 348
    },
    {
      "t": 39754,
      "e": 36934,
      "ty": 41,
      "x": 17936,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 39803,
      "e": 36983,
      "ty": 2,
      "x": 914,
      "y": 467
    },
    {
      "t": 39903,
      "e": 37083,
      "ty": 2,
      "x": 931,
      "y": 504
    },
    {
      "t": 40003,
      "e": 37183,
      "ty": 2,
      "x": 931,
      "y": 505
    },
    {
      "t": 40003,
      "e": 37183,
      "ty": 41,
      "x": 26005,
      "y": 46810,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 40104,
      "e": 37284,
      "ty": 2,
      "x": 919,
      "y": 507
    },
    {
      "t": 40204,
      "e": 37384,
      "ty": 2,
      "x": 901,
      "y": 502
    },
    {
      "t": 40254,
      "e": 37434,
      "ty": 41,
      "x": 18885,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 40304,
      "e": 37484,
      "ty": 2,
      "x": 899,
      "y": 503
    },
    {
      "t": 40403,
      "e": 37583,
      "ty": 2,
      "x": 886,
      "y": 547
    },
    {
      "t": 40503,
      "e": 37683,
      "ty": 2,
      "x": 881,
      "y": 572
    },
    {
      "t": 40503,
      "e": 37683,
      "ty": 41,
      "x": 14139,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 40604,
      "e": 37784,
      "ty": 2,
      "x": 880,
      "y": 573
    },
    {
      "t": 40754,
      "e": 37934,
      "ty": 41,
      "x": 58151,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-6 > label"
    },
    {
      "t": 40903,
      "e": 38083,
      "ty": 2,
      "x": 878,
      "y": 573
    },
    {
      "t": 41004,
      "e": 38184,
      "ty": 2,
      "x": 865,
      "y": 548
    },
    {
      "t": 41004,
      "e": 38184,
      "ty": 41,
      "x": 29734,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 41103,
      "e": 38283,
      "ty": 2,
      "x": 854,
      "y": 516
    },
    {
      "t": 41203,
      "e": 38383,
      "ty": 2,
      "x": 852,
      "y": 510
    },
    {
      "t": 41254,
      "e": 38434,
      "ty": 41,
      "x": 25650,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 41304,
      "e": 38484,
      "ty": 2,
      "x": 846,
      "y": 490
    },
    {
      "t": 41403,
      "e": 38583,
      "ty": 2,
      "x": 845,
      "y": 473
    },
    {
      "t": 41504,
      "e": 38684,
      "ty": 41,
      "x": 24922,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 41603,
      "e": 38783,
      "ty": 2,
      "x": 838,
      "y": 487
    },
    {
      "t": 41703,
      "e": 38883,
      "ty": 2,
      "x": 838,
      "y": 490
    },
    {
      "t": 41754,
      "e": 38934,
      "ty": 41,
      "x": 14879,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 42004,
      "e": 39184,
      "ty": 2,
      "x": 838,
      "y": 489
    },
    {
      "t": 42004,
      "e": 39184,
      "ty": 41,
      "x": 14879,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 42253,
      "e": 39433,
      "ty": 41,
      "x": 3934,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 42304,
      "e": 39484,
      "ty": 2,
      "x": 838,
      "y": 478
    },
    {
      "t": 42306,
      "e": 39486,
      "ty": 6,
      "x": 838,
      "y": 472,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 42403,
      "e": 39583,
      "ty": 2,
      "x": 839,
      "y": 469
    },
    {
      "t": 42503,
      "e": 39683,
      "ty": 2,
      "x": 839,
      "y": 468
    },
    {
      "t": 42504,
      "e": 39684,
      "ty": 41,
      "x": 63408,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 42506,
      "e": 39686,
      "ty": 7,
      "x": 841,
      "y": 468,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 42603,
      "e": 39783,
      "ty": 2,
      "x": 850,
      "y": 481
    },
    {
      "t": 42704,
      "e": 39884,
      "ty": 2,
      "x": 852,
      "y": 485
    },
    {
      "t": 42754,
      "e": 39934,
      "ty": 41,
      "x": 7256,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 43604,
      "e": 40784,
      "ty": 2,
      "x": 844,
      "y": 483
    },
    {
      "t": 43702,
      "e": 40882,
      "ty": 2,
      "x": 843,
      "y": 480
    },
    {
      "t": 43753,
      "e": 40933,
      "ty": 41,
      "x": 22808,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 43907,
      "e": 41087,
      "ty": 3,
      "x": 843,
      "y": 480,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 43908,
      "e": 41088,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 44032,
      "e": 41212,
      "ty": 4,
      "x": 22808,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 44033,
      "e": 41213,
      "ty": 5,
      "x": 843,
      "y": 480,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 44033,
      "e": 41213,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 44034,
      "e": 41214,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 44404,
      "e": 41584,
      "ty": 2,
      "x": 847,
      "y": 499
    },
    {
      "t": 44503,
      "e": 41683,
      "ty": 2,
      "x": 882,
      "y": 623
    },
    {
      "t": 44503,
      "e": 41683,
      "ty": 41,
      "x": 14376,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 44603,
      "e": 41783,
      "ty": 2,
      "x": 889,
      "y": 653
    },
    {
      "t": 44704,
      "e": 41884,
      "ty": 2,
      "x": 901,
      "y": 685
    },
    {
      "t": 44755,
      "e": 41885,
      "ty": 41,
      "x": 21971,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 44804,
      "e": 41934,
      "ty": 2,
      "x": 929,
      "y": 746
    },
    {
      "t": 44903,
      "e": 42033,
      "ty": 2,
      "x": 936,
      "y": 765
    },
    {
      "t": 45003,
      "e": 42133,
      "ty": 2,
      "x": 933,
      "y": 768
    },
    {
      "t": 45003,
      "e": 42133,
      "ty": 41,
      "x": 46556,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 45103,
      "e": 42233,
      "ty": 2,
      "x": 924,
      "y": 770
    },
    {
      "t": 45203,
      "e": 42333,
      "ty": 2,
      "x": 911,
      "y": 775
    },
    {
      "t": 45253,
      "e": 42383,
      "ty": 41,
      "x": 20309,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 45302,
      "e": 42432,
      "ty": 2,
      "x": 889,
      "y": 718
    },
    {
      "t": 45403,
      "e": 42533,
      "ty": 2,
      "x": 867,
      "y": 641
    },
    {
      "t": 45503,
      "e": 42633,
      "ty": 2,
      "x": 866,
      "y": 640
    },
    {
      "t": 45503,
      "e": 42633,
      "ty": 41,
      "x": 10579,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 45603,
      "e": 42733,
      "ty": 2,
      "x": 865,
      "y": 640
    },
    {
      "t": 45703,
      "e": 42833,
      "ty": 2,
      "x": 859,
      "y": 684
    },
    {
      "t": 45753,
      "e": 42883,
      "ty": 41,
      "x": 8443,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 45803,
      "e": 42933,
      "ty": 2,
      "x": 856,
      "y": 696
    },
    {
      "t": 45903,
      "e": 43033,
      "ty": 2,
      "x": 855,
      "y": 704
    },
    {
      "t": 46003,
      "e": 43133,
      "ty": 2,
      "x": 855,
      "y": 715
    },
    {
      "t": 46003,
      "e": 43133,
      "ty": 41,
      "x": 7968,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 46103,
      "e": 43233,
      "ty": 2,
      "x": 855,
      "y": 725
    },
    {
      "t": 46202,
      "e": 43332,
      "ty": 2,
      "x": 855,
      "y": 731
    },
    {
      "t": 46253,
      "e": 43383,
      "ty": 41,
      "x": 8427,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 46302,
      "e": 43432,
      "ty": 2,
      "x": 850,
      "y": 720
    },
    {
      "t": 46403,
      "e": 43533,
      "ty": 2,
      "x": 841,
      "y": 697
    },
    {
      "t": 46503,
      "e": 43633,
      "ty": 2,
      "x": 840,
      "y": 696
    },
    {
      "t": 46503,
      "e": 43633,
      "ty": 41,
      "x": 4681,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 47203,
      "e": 44333,
      "ty": 2,
      "x": 841,
      "y": 697
    },
    {
      "t": 47253,
      "e": 44383,
      "ty": 41,
      "x": 4933,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 47302,
      "e": 44432,
      "ty": 2,
      "x": 843,
      "y": 699
    },
    {
      "t": 47503,
      "e": 44633,
      "ty": 41,
      "x": 5437,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 47602,
      "e": 44732,
      "ty": 3,
      "x": 847,
      "y": 699,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 47603,
      "e": 44733,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 47605,
      "e": 44735,
      "ty": 2,
      "x": 847,
      "y": 699
    },
    {
      "t": 47753,
      "e": 44883,
      "ty": 41,
      "x": 6445,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 47769,
      "e": 44899,
      "ty": 4,
      "x": 6445,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 47770,
      "e": 44900,
      "ty": 5,
      "x": 847,
      "y": 699,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 47770,
      "e": 44900,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 47771,
      "e": 44901,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 50003,
      "e": 47133,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 51103,
      "e": 48233,
      "ty": 2,
      "x": 848,
      "y": 699
    },
    {
      "t": 51203,
      "e": 48333,
      "ty": 2,
      "x": 860,
      "y": 680
    },
    {
      "t": 51253,
      "e": 48383,
      "ty": 41,
      "x": 10626,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 51303,
      "e": 48433,
      "ty": 2,
      "x": 861,
      "y": 678
    },
    {
      "t": 53602,
      "e": 50732,
      "ty": 2,
      "x": 873,
      "y": 694
    },
    {
      "t": 53703,
      "e": 50833,
      "ty": 2,
      "x": 1070,
      "y": 975
    },
    {
      "t": 53753,
      "e": 50883,
      "ty": 41,
      "x": 37433,
      "y": 57668,
      "ta": "html > body"
    },
    {
      "t": 53802,
      "e": 50932,
      "ty": 2,
      "x": 1094,
      "y": 1078
    },
    {
      "t": 53904,
      "e": 51034,
      "ty": 2,
      "x": 1039,
      "y": 1102
    },
    {
      "t": 54003,
      "e": 51133,
      "ty": 2,
      "x": 933,
      "y": 1064
    },
    {
      "t": 54003,
      "e": 51133,
      "ty": 41,
      "x": 31854,
      "y": 58499,
      "ta": "html > body"
    },
    {
      "t": 54066,
      "e": 51196,
      "ty": 6,
      "x": 909,
      "y": 1032,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54103,
      "e": 51233,
      "ty": 2,
      "x": 906,
      "y": 1020
    },
    {
      "t": 54183,
      "e": 51313,
      "ty": 7,
      "x": 899,
      "y": 1002,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54203,
      "e": 51333,
      "ty": 2,
      "x": 898,
      "y": 997
    },
    {
      "t": 54253,
      "e": 51383,
      "ty": 41,
      "x": 17461,
      "y": 21064,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 54303,
      "e": 51433,
      "ty": 2,
      "x": 895,
      "y": 983
    },
    {
      "t": 54403,
      "e": 51533,
      "ty": 2,
      "x": 893,
      "y": 968
    },
    {
      "t": 54503,
      "e": 51633,
      "ty": 41,
      "x": 57900,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 54603,
      "e": 51733,
      "ty": 2,
      "x": 892,
      "y": 966
    },
    {
      "t": 54753,
      "e": 51883,
      "ty": 41,
      "x": 57091,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 54826,
      "e": 51956,
      "ty": 3,
      "x": 892,
      "y": 966,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 54828,
      "e": 51958,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 54953,
      "e": 52083,
      "ty": 4,
      "x": 57091,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 54953,
      "e": 52083,
      "ty": 5,
      "x": 892,
      "y": 966,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 54953,
      "e": 52083,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 54953,
      "e": 52083,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 55203,
      "e": 52333,
      "ty": 2,
      "x": 892,
      "y": 995
    },
    {
      "t": 55254,
      "e": 52384,
      "ty": 41,
      "x": 16749,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 55303,
      "e": 52433,
      "ty": 2,
      "x": 892,
      "y": 1003
    },
    {
      "t": 55339,
      "e": 52469,
      "ty": 6,
      "x": 892,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 55403,
      "e": 52533,
      "ty": 2,
      "x": 892,
      "y": 1005
    },
    {
      "t": 55503,
      "e": 52633,
      "ty": 41,
      "x": 32252,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 55706,
      "e": 52836,
      "ty": 3,
      "x": 892,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 55707,
      "e": 52837,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 55708,
      "e": 52838,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 55833,
      "e": 52963,
      "ty": 4,
      "x": 32252,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 55834,
      "e": 52964,
      "ty": 5,
      "x": 892,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 55836,
      "e": 52966,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 55837,
      "e": 52967,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 55838,
      "e": 52968,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 56932,
      "e": 54062,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 60003,
      "e": 57133,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 64404,
      "e": 57967,
      "ty": 2,
      "x": 902,
      "y": 1011
    },
    {
      "t": 64503,
      "e": 58066,
      "ty": 2,
      "x": 922,
      "y": 1025
    },
    {
      "t": 64504,
      "e": 58067,
      "ty": 41,
      "x": 30922,
      "y": 62232,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 64604,
      "e": 58167,
      "ty": 2,
      "x": 923,
      "y": 1026
    },
    {
      "t": 64704,
      "e": 58267,
      "ty": 2,
      "x": 923,
      "y": 1027
    },
    {
      "t": 64754,
      "e": 58317,
      "ty": 41,
      "x": 30971,
      "y": 62371,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 65303,
      "e": 58866,
      "ty": 2,
      "x": 930,
      "y": 1035
    },
    {
      "t": 65404,
      "e": 58967,
      "ty": 2,
      "x": 981,
      "y": 1071
    },
    {
      "t": 65409,
      "e": 58972,
      "ty": 6,
      "x": 985,
      "y": 1076,
      "ta": "#start"
    },
    {
      "t": 65504,
      "e": 59067,
      "ty": 2,
      "x": 994,
      "y": 1088
    },
    {
      "t": 65504,
      "e": 59067,
      "ty": 41,
      "x": 46147,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 65704,
      "e": 59267,
      "ty": 2,
      "x": 993,
      "y": 1090
    },
    {
      "t": 65754,
      "e": 59317,
      "ty": 41,
      "x": 43963,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 65803,
      "e": 59366,
      "ty": 2,
      "x": 987,
      "y": 1092
    },
    {
      "t": 65904,
      "e": 59467,
      "ty": 2,
      "x": 974,
      "y": 1088
    },
    {
      "t": 66003,
      "e": 59566,
      "ty": 2,
      "x": 969,
      "y": 1085
    },
    {
      "t": 66004,
      "e": 59567,
      "ty": 41,
      "x": 32494,
      "y": 23732,
      "ta": "#start"
    },
    {
      "t": 66104,
      "e": 59667,
      "ty": 2,
      "x": 968,
      "y": 1085
    },
    {
      "t": 66203,
      "e": 59766,
      "ty": 2,
      "x": 967,
      "y": 1085
    },
    {
      "t": 66254,
      "e": 59817,
      "ty": 41,
      "x": 31402,
      "y": 23732,
      "ta": "#start"
    },
    {
      "t": 66602,
      "e": 60165,
      "ty": 2,
      "x": 966,
      "y": 1085
    },
    {
      "t": 66753,
      "e": 60316,
      "ty": 41,
      "x": 30856,
      "y": 23732,
      "ta": "#start"
    },
    {
      "t": 70003,
      "e": 63566,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 73243,
      "e": 65316,
      "ty": 3,
      "x": 966,
      "y": 1085,
      "ta": "#start"
    },
    {
      "t": 73243,
      "e": 65316,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 73400,
      "e": 65473,
      "ty": 4,
      "x": 30856,
      "y": 23732,
      "ta": "#start"
    },
    {
      "t": 73402,
      "e": 65475,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 73402,
      "e": 65475,
      "ty": 5,
      "x": 966,
      "y": 1085,
      "ta": "#start"
    },
    {
      "t": 73403,
      "e": 65476,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 74431,
      "e": 66504,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 75082,
      "e": 67155,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 14074, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 14078, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"8TUB0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 8101, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 23280, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"8TUB0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 9354, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"sierra\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"114\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 33640, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"8TUB0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 10759, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 45488, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"8TUB0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 8456, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 54947, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"8TUB0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 13138, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 69569, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"8TUB0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-10 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1413,y:983,t:1527631903898};\\\", \\\"{x:1412,y:983,t:1527631903905};\\\", \\\"{x:1411,y:984,t:1527631904073};\\\", \\\"{x:1410,y:984,t:1527631904089};\\\", \\\"{x:1409,y:984,t:1527631904099};\\\", \\\"{x:1408,y:985,t:1527631904116};\\\", \\\"{x:1407,y:985,t:1527631904133};\\\", \\\"{x:1406,y:985,t:1527631904149};\\\", \\\"{x:1405,y:986,t:1527631904166};\\\", \\\"{x:1404,y:986,t:1527631904201};\\\", \\\"{x:1403,y:986,t:1527631904232};\\\", \\\"{x:1402,y:986,t:1527631904296};\\\", \\\"{x:1401,y:986,t:1527631904916};\\\", \\\"{x:1400,y:986,t:1527631904957};\\\", \\\"{x:1401,y:987,t:1527631905075};\\\", \\\"{x:1403,y:987,t:1527631905086};\\\", \\\"{x:1407,y:989,t:1527631905102};\\\", \\\"{x:1411,y:989,t:1527631905118};\\\", \\\"{x:1416,y:989,t:1527631905135};\\\", \\\"{x:1421,y:990,t:1527631905152};\\\", \\\"{x:1429,y:991,t:1527631905168};\\\", \\\"{x:1437,y:993,t:1527631905185};\\\", \\\"{x:1443,y:994,t:1527631905201};\\\", \\\"{x:1448,y:994,t:1527631905218};\\\", \\\"{x:1456,y:995,t:1527631905235};\\\", \\\"{x:1464,y:997,t:1527631905252};\\\", \\\"{x:1471,y:998,t:1527631905269};\\\", \\\"{x:1482,y:999,t:1527631905285};\\\", \\\"{x:1495,y:1002,t:1527631905302};\\\", \\\"{x:1512,y:1004,t:1527631905319};\\\", \\\"{x:1522,y:1005,t:1527631905335};\\\", \\\"{x:1531,y:1007,t:1527631905352};\\\", \\\"{x:1535,y:1008,t:1527631905369};\\\", \\\"{x:1536,y:1009,t:1527631905667};\\\", \\\"{x:1535,y:1011,t:1527631905683};\\\", \\\"{x:1534,y:1011,t:1527631905690};\\\", \\\"{x:1530,y:1012,t:1527631905707};\\\", \\\"{x:1529,y:1012,t:1527631905720};\\\", \\\"{x:1524,y:1014,t:1527631905736};\\\", \\\"{x:1519,y:1015,t:1527631905752};\\\", \\\"{x:1510,y:1018,t:1527631905770};\\\", \\\"{x:1497,y:1019,t:1527631905785};\\\", \\\"{x:1479,y:1019,t:1527631905802};\\\", \\\"{x:1448,y:1018,t:1527631905819};\\\", \\\"{x:1421,y:1013,t:1527631905836};\\\", \\\"{x:1399,y:1011,t:1527631905852};\\\", \\\"{x:1375,y:1006,t:1527631905870};\\\", \\\"{x:1350,y:1004,t:1527631905886};\\\", \\\"{x:1324,y:1001,t:1527631905902};\\\", \\\"{x:1299,y:996,t:1527631905920};\\\", \\\"{x:1276,y:993,t:1527631905935};\\\", \\\"{x:1254,y:989,t:1527631905952};\\\", \\\"{x:1237,y:988,t:1527631905970};\\\", \\\"{x:1223,y:985,t:1527631905986};\\\", \\\"{x:1213,y:984,t:1527631906003};\\\", \\\"{x:1203,y:983,t:1527631906019};\\\", \\\"{x:1201,y:983,t:1527631906036};\\\", \\\"{x:1200,y:983,t:1527631906053};\\\", \\\"{x:1198,y:983,t:1527631906260};\\\", \\\"{x:1191,y:983,t:1527631906271};\\\", \\\"{x:1170,y:986,t:1527631906286};\\\", \\\"{x:1145,y:988,t:1527631906302};\\\", \\\"{x:1114,y:992,t:1527631906319};\\\", \\\"{x:1078,y:992,t:1527631906336};\\\", \\\"{x:1022,y:992,t:1527631906353};\\\", \\\"{x:960,y:992,t:1527631906369};\\\", \\\"{x:888,y:992,t:1527631906386};\\\", \\\"{x:785,y:992,t:1527631906402};\\\", \\\"{x:708,y:986,t:1527631906419};\\\", \\\"{x:638,y:973,t:1527631906436};\\\", \\\"{x:573,y:963,t:1527631906452};\\\", \\\"{x:496,y:943,t:1527631906469};\\\", \\\"{x:424,y:925,t:1527631906486};\\\", \\\"{x:350,y:905,t:1527631906502};\\\", \\\"{x:283,y:884,t:1527631906519};\\\", \\\"{x:232,y:870,t:1527631906536};\\\", \\\"{x:195,y:857,t:1527631906553};\\\", \\\"{x:165,y:845,t:1527631906569};\\\", \\\"{x:140,y:830,t:1527631906586};\\\", \\\"{x:111,y:807,t:1527631906602};\\\", \\\"{x:99,y:789,t:1527631906619};\\\", \\\"{x:90,y:769,t:1527631906636};\\\", \\\"{x:81,y:746,t:1527631906652};\\\", \\\"{x:70,y:720,t:1527631906669};\\\", \\\"{x:64,y:700,t:1527631906686};\\\", \\\"{x:58,y:679,t:1527631906703};\\\", \\\"{x:53,y:655,t:1527631906720};\\\", \\\"{x:50,y:636,t:1527631906737};\\\", \\\"{x:48,y:623,t:1527631906753};\\\", \\\"{x:48,y:617,t:1527631906770};\\\", \\\"{x:48,y:613,t:1527631906786};\\\", \\\"{x:48,y:605,t:1527631906803};\\\", \\\"{x:48,y:602,t:1527631906820};\\\", \\\"{x:51,y:597,t:1527631906836};\\\", \\\"{x:53,y:593,t:1527631906853};\\\", \\\"{x:56,y:589,t:1527631906870};\\\", \\\"{x:59,y:586,t:1527631906886};\\\", \\\"{x:64,y:581,t:1527631906904};\\\", \\\"{x:71,y:574,t:1527631906921};\\\", \\\"{x:77,y:569,t:1527631906936};\\\", \\\"{x:82,y:566,t:1527631906953};\\\", \\\"{x:88,y:562,t:1527631906970};\\\", \\\"{x:92,y:560,t:1527631906987};\\\", \\\"{x:98,y:558,t:1527631907003};\\\", \\\"{x:107,y:555,t:1527631907020};\\\", \\\"{x:113,y:553,t:1527631907037};\\\", \\\"{x:121,y:552,t:1527631907053};\\\", \\\"{x:130,y:550,t:1527631907071};\\\", \\\"{x:136,y:550,t:1527631907086};\\\", \\\"{x:138,y:549,t:1527631907104};\\\", \\\"{x:141,y:549,t:1527631907120};\\\", \\\"{x:143,y:549,t:1527631907138};\\\", \\\"{x:149,y:549,t:1527631908132};\\\", \\\"{x:158,y:549,t:1527631908141};\\\", \\\"{x:173,y:549,t:1527631908154};\\\", \\\"{x:195,y:549,t:1527631908171};\\\", \\\"{x:218,y:549,t:1527631908187};\\\", \\\"{x:240,y:549,t:1527631908204};\\\", \\\"{x:266,y:549,t:1527631908221};\\\", \\\"{x:290,y:549,t:1527631908238};\\\", \\\"{x:309,y:549,t:1527631908254};\\\", \\\"{x:320,y:549,t:1527631908271};\\\", \\\"{x:326,y:549,t:1527631908288};\\\", \\\"{x:328,y:549,t:1527631908305};\\\", \\\"{x:329,y:549,t:1527631908321};\\\", \\\"{x:329,y:548,t:1527631908338};\\\", \\\"{x:330,y:548,t:1527631908484};\\\", \\\"{x:332,y:547,t:1527631908491};\\\", \\\"{x:334,y:545,t:1527631908506};\\\", \\\"{x:341,y:545,t:1527631908523};\\\", \\\"{x:343,y:543,t:1527631908540};\\\", \\\"{x:350,y:541,t:1527631908555};\\\", \\\"{x:355,y:539,t:1527631908571};\\\", \\\"{x:358,y:536,t:1527631908589};\\\", \\\"{x:363,y:533,t:1527631908604};\\\", \\\"{x:369,y:527,t:1527631908621};\\\", \\\"{x:373,y:523,t:1527631908639};\\\", \\\"{x:376,y:522,t:1527631908655};\\\", \\\"{x:377,y:520,t:1527631908671};\\\", \\\"{x:378,y:519,t:1527631908707};\\\", \\\"{x:380,y:519,t:1527631908738};\\\", \\\"{x:382,y:518,t:1527631908779};\\\", \\\"{x:382,y:517,t:1527631908788};\\\", \\\"{x:389,y:516,t:1527631908805};\\\", \\\"{x:400,y:512,t:1527631908822};\\\", \\\"{x:413,y:510,t:1527631908838};\\\", \\\"{x:419,y:510,t:1527631908856};\\\", \\\"{x:422,y:510,t:1527631908872};\\\", \\\"{x:424,y:510,t:1527631908889};\\\", \\\"{x:426,y:510,t:1527631908906};\\\", \\\"{x:427,y:510,t:1527631908921};\\\", \\\"{x:425,y:510,t:1527631909195};\\\", \\\"{x:424,y:510,t:1527631909206};\\\", \\\"{x:419,y:512,t:1527631909223};\\\", \\\"{x:416,y:513,t:1527631909239};\\\", \\\"{x:410,y:515,t:1527631909255};\\\", \\\"{x:407,y:516,t:1527631909272};\\\", \\\"{x:405,y:516,t:1527631909288};\\\", \\\"{x:404,y:516,t:1527631909306};\\\", \\\"{x:399,y:518,t:1527631909322};\\\", \\\"{x:396,y:519,t:1527631909338};\\\", \\\"{x:395,y:519,t:1527631909355};\\\", \\\"{x:393,y:520,t:1527631909372};\\\", \\\"{x:390,y:522,t:1527631909388};\\\", \\\"{x:389,y:522,t:1527631909405};\\\", \\\"{x:389,y:523,t:1527631909422};\\\", \\\"{x:388,y:523,t:1527631909443};\\\", \\\"{x:387,y:523,t:1527631909491};\\\", \\\"{x:386,y:523,t:1527631910051};\\\", \\\"{x:389,y:527,t:1527631910531};\\\", \\\"{x:398,y:535,t:1527631910540};\\\", \\\"{x:420,y:555,t:1527631910557};\\\", \\\"{x:459,y:589,t:1527631910575};\\\", \\\"{x:485,y:613,t:1527631910590};\\\", \\\"{x:519,y:646,t:1527631910607};\\\", \\\"{x:548,y:675,t:1527631910623};\\\", \\\"{x:569,y:693,t:1527631910639};\\\", \\\"{x:584,y:709,t:1527631910657};\\\", \\\"{x:593,y:719,t:1527631910674};\\\", \\\"{x:596,y:721,t:1527631910689};\\\", \\\"{x:596,y:722,t:1527631910882};\\\", \\\"{x:595,y:722,t:1527631910891};\\\", \\\"{x:589,y:724,t:1527631910906};\\\", \\\"{x:586,y:726,t:1527631910923};\\\", \\\"{x:581,y:727,t:1527631910940};\\\", \\\"{x:578,y:729,t:1527631910956};\\\", \\\"{x:575,y:729,t:1527631910974};\\\", \\\"{x:574,y:729,t:1527631910990};\\\", \\\"{x:573,y:730,t:1527631911006};\\\", \\\"{x:571,y:730,t:1527631911024};\\\", \\\"{x:570,y:731,t:1527631911039};\\\", \\\"{x:569,y:731,t:1527631911057};\\\", \\\"{x:568,y:731,t:1527631911073};\\\", \\\"{x:567,y:731,t:1527631911090};\\\", \\\"{x:567,y:732,t:1527631911123};\\\", \\\"{x:566,y:732,t:1527631913674};\\\", \\\"{x:565,y:732,t:1527631913698};\\\", \\\"{x:563,y:732,t:1527631913706};\\\", \\\"{x:560,y:733,t:1527631913724};\\\", \\\"{x:559,y:734,t:1527631913740};\\\", \\\"{x:555,y:735,t:1527631913757};\\\", \\\"{x:553,y:735,t:1527631913774};\\\", \\\"{x:552,y:735,t:1527631913790};\\\", \\\"{x:551,y:735,t:1527631913867};\\\", \\\"{x:550,y:735,t:1527631913874};\\\", \\\"{x:549,y:735,t:1527631913890};\\\", \\\"{x:545,y:735,t:1527631913906};\\\", \\\"{x:540,y:733,t:1527631913923};\\\", \\\"{x:536,y:729,t:1527631913940};\\\", \\\"{x:528,y:724,t:1527631913957};\\\", \\\"{x:521,y:718,t:1527631913974};\\\", \\\"{x:519,y:716,t:1527631913990};\\\", \\\"{x:516,y:712,t:1527631914007};\\\", \\\"{x:515,y:711,t:1527631914024};\\\", \\\"{x:515,y:710,t:1527631914040};\\\", \\\"{x:514,y:709,t:1527631914057};\\\", \\\"{x:513,y:709,t:1527631914580};\\\", \\\"{x:512,y:709,t:1527631914591};\\\", \\\"{x:510,y:709,t:1527631914607};\\\" ] }, { \\\"rt\\\": 17121, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 87979, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"8TUB0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:708,t:1527631917195};\\\", \\\"{x:507,y:699,t:1527631917203};\\\", \\\"{x:507,y:690,t:1527631917212};\\\", \\\"{x:506,y:673,t:1527631917228};\\\", \\\"{x:505,y:659,t:1527631917245};\\\", \\\"{x:502,y:648,t:1527631917262};\\\", \\\"{x:501,y:638,t:1527631917277};\\\", \\\"{x:501,y:627,t:1527631917294};\\\", \\\"{x:501,y:617,t:1527631917312};\\\", \\\"{x:501,y:607,t:1527631917329};\\\", \\\"{x:499,y:600,t:1527631917345};\\\", \\\"{x:497,y:595,t:1527631917362};\\\", \\\"{x:496,y:589,t:1527631917378};\\\", \\\"{x:495,y:587,t:1527631917395};\\\", \\\"{x:495,y:586,t:1527631917412};\\\", \\\"{x:494,y:585,t:1527631917428};\\\", \\\"{x:494,y:584,t:1527631917466};\\\", \\\"{x:494,y:582,t:1527631917482};\\\", \\\"{x:494,y:581,t:1527631917499};\\\", \\\"{x:494,y:580,t:1527631917512};\\\", \\\"{x:493,y:579,t:1527631917529};\\\", \\\"{x:492,y:577,t:1527631917545};\\\", \\\"{x:492,y:576,t:1527631917561};\\\", \\\"{x:491,y:573,t:1527631917579};\\\", \\\"{x:490,y:571,t:1527631917595};\\\", \\\"{x:490,y:569,t:1527631917611};\\\", \\\"{x:490,y:567,t:1527631917629};\\\", \\\"{x:490,y:566,t:1527631917645};\\\", \\\"{x:490,y:564,t:1527631917662};\\\", \\\"{x:490,y:563,t:1527631917678};\\\", \\\"{x:490,y:561,t:1527631917696};\\\", \\\"{x:490,y:560,t:1527631917715};\\\", \\\"{x:490,y:558,t:1527631917738};\\\", \\\"{x:487,y:558,t:1527631923474};\\\", \\\"{x:482,y:557,t:1527631923481};\\\", \\\"{x:479,y:556,t:1527631923499};\\\", \\\"{x:474,y:556,t:1527631923516};\\\", \\\"{x:468,y:555,t:1527631923532};\\\", \\\"{x:465,y:554,t:1527631923548};\\\", \\\"{x:464,y:554,t:1527631923565};\\\", \\\"{x:464,y:553,t:1527631923698};\\\", \\\"{x:464,y:550,t:1527631923706};\\\", \\\"{x:464,y:548,t:1527631923716};\\\", \\\"{x:469,y:542,t:1527631923734};\\\", \\\"{x:474,y:538,t:1527631923749};\\\", \\\"{x:479,y:534,t:1527631923766};\\\", \\\"{x:484,y:531,t:1527631923784};\\\", \\\"{x:486,y:530,t:1527631923800};\\\", \\\"{x:487,y:529,t:1527631923816};\\\", \\\"{x:500,y:526,t:1527631923835};\\\", \\\"{x:516,y:521,t:1527631923850};\\\", \\\"{x:526,y:519,t:1527631923867};\\\", \\\"{x:536,y:514,t:1527631923884};\\\", \\\"{x:555,y:505,t:1527631923900};\\\", \\\"{x:569,y:502,t:1527631923917};\\\", \\\"{x:577,y:500,t:1527631923934};\\\", \\\"{x:581,y:499,t:1527631923950};\\\", \\\"{x:582,y:499,t:1527631923967};\\\", \\\"{x:581,y:500,t:1527631924058};\\\", \\\"{x:578,y:501,t:1527631924067};\\\", \\\"{x:569,y:505,t:1527631924084};\\\", \\\"{x:556,y:510,t:1527631924102};\\\", \\\"{x:542,y:516,t:1527631924117};\\\", \\\"{x:524,y:521,t:1527631924133};\\\", \\\"{x:507,y:527,t:1527631924151};\\\", \\\"{x:495,y:533,t:1527631924167};\\\", \\\"{x:487,y:536,t:1527631924184};\\\", \\\"{x:478,y:540,t:1527631924201};\\\", \\\"{x:470,y:545,t:1527631924217};\\\", \\\"{x:461,y:550,t:1527631924234};\\\", \\\"{x:454,y:556,t:1527631924250};\\\", \\\"{x:448,y:560,t:1527631924267};\\\", \\\"{x:445,y:563,t:1527631924284};\\\", \\\"{x:441,y:566,t:1527631924301};\\\", \\\"{x:439,y:567,t:1527631924317};\\\", \\\"{x:437,y:569,t:1527631924334};\\\", \\\"{x:436,y:569,t:1527631924351};\\\", \\\"{x:435,y:570,t:1527631924367};\\\", \\\"{x:433,y:570,t:1527631924385};\\\", \\\"{x:432,y:570,t:1527631924410};\\\", \\\"{x:430,y:572,t:1527631924434};\\\", \\\"{x:428,y:572,t:1527631924451};\\\", \\\"{x:425,y:573,t:1527631924468};\\\", \\\"{x:420,y:574,t:1527631924484};\\\", \\\"{x:412,y:577,t:1527631924502};\\\", \\\"{x:407,y:578,t:1527631924518};\\\", \\\"{x:403,y:580,t:1527631924534};\\\", \\\"{x:399,y:581,t:1527631924550};\\\", \\\"{x:396,y:581,t:1527631924567};\\\", \\\"{x:395,y:581,t:1527631924583};\\\", \\\"{x:396,y:581,t:1527631924650};\\\", \\\"{x:424,y:575,t:1527631924666};\\\", \\\"{x:466,y:564,t:1527631924684};\\\", \\\"{x:512,y:549,t:1527631924700};\\\", \\\"{x:559,y:535,t:1527631924719};\\\", \\\"{x:616,y:525,t:1527631924734};\\\", \\\"{x:667,y:522,t:1527631924751};\\\", \\\"{x:709,y:522,t:1527631924768};\\\", \\\"{x:734,y:522,t:1527631924784};\\\", \\\"{x:753,y:525,t:1527631924801};\\\", \\\"{x:786,y:527,t:1527631924818};\\\", \\\"{x:812,y:530,t:1527631924834};\\\", \\\"{x:835,y:530,t:1527631924851};\\\", \\\"{x:857,y:532,t:1527631924868};\\\", \\\"{x:870,y:533,t:1527631924885};\\\", \\\"{x:876,y:535,t:1527631924901};\\\", \\\"{x:879,y:535,t:1527631924918};\\\", \\\"{x:880,y:535,t:1527631924938};\\\", \\\"{x:881,y:535,t:1527631924951};\\\", \\\"{x:880,y:535,t:1527631925051};\\\", \\\"{x:874,y:536,t:1527631925058};\\\", \\\"{x:868,y:540,t:1527631925068};\\\", \\\"{x:851,y:546,t:1527631925086};\\\", \\\"{x:831,y:552,t:1527631925101};\\\", \\\"{x:812,y:559,t:1527631925118};\\\", \\\"{x:793,y:564,t:1527631925134};\\\", \\\"{x:772,y:572,t:1527631925151};\\\", \\\"{x:755,y:575,t:1527631925168};\\\", \\\"{x:741,y:580,t:1527631925185};\\\", \\\"{x:725,y:586,t:1527631925202};\\\", \\\"{x:704,y:595,t:1527631925218};\\\", \\\"{x:689,y:600,t:1527631925234};\\\", \\\"{x:673,y:606,t:1527631925251};\\\", \\\"{x:661,y:610,t:1527631925268};\\\", \\\"{x:650,y:613,t:1527631925285};\\\", \\\"{x:636,y:616,t:1527631925302};\\\", \\\"{x:622,y:620,t:1527631925318};\\\", \\\"{x:602,y:625,t:1527631925336};\\\", \\\"{x:577,y:629,t:1527631925352};\\\", \\\"{x:549,y:629,t:1527631925368};\\\", \\\"{x:518,y:632,t:1527631925385};\\\", \\\"{x:475,y:632,t:1527631925403};\\\", \\\"{x:446,y:632,t:1527631925418};\\\", \\\"{x:419,y:632,t:1527631925435};\\\", \\\"{x:394,y:632,t:1527631925452};\\\", \\\"{x:372,y:632,t:1527631925469};\\\", \\\"{x:350,y:632,t:1527631925485};\\\", \\\"{x:324,y:632,t:1527631925502};\\\", \\\"{x:307,y:632,t:1527631925518};\\\", \\\"{x:286,y:632,t:1527631925535};\\\", \\\"{x:268,y:632,t:1527631925552};\\\", \\\"{x:251,y:632,t:1527631925568};\\\", \\\"{x:238,y:633,t:1527631925584};\\\", \\\"{x:221,y:637,t:1527631925602};\\\", \\\"{x:215,y:638,t:1527631925618};\\\", \\\"{x:209,y:638,t:1527631925635};\\\", \\\"{x:205,y:639,t:1527631925652};\\\", \\\"{x:202,y:640,t:1527631925668};\\\", \\\"{x:199,y:640,t:1527631925685};\\\", \\\"{x:196,y:641,t:1527631925702};\\\", \\\"{x:191,y:643,t:1527631925719};\\\", \\\"{x:186,y:644,t:1527631925735};\\\", \\\"{x:182,y:645,t:1527631925752};\\\", \\\"{x:177,y:647,t:1527631925769};\\\", \\\"{x:176,y:647,t:1527631925785};\\\", \\\"{x:175,y:647,t:1527631925802};\\\", \\\"{x:174,y:647,t:1527631925819};\\\", \\\"{x:173,y:647,t:1527631925835};\\\", \\\"{x:172,y:647,t:1527631925914};\\\", \\\"{x:171,y:647,t:1527631925922};\\\", \\\"{x:170,y:647,t:1527631925935};\\\", \\\"{x:170,y:646,t:1527631925952};\\\", \\\"{x:169,y:645,t:1527631925969};\\\", \\\"{x:166,y:643,t:1527631925985};\\\", \\\"{x:165,y:641,t:1527631926002};\\\", \\\"{x:163,y:639,t:1527631926019};\\\", \\\"{x:163,y:638,t:1527631926035};\\\", \\\"{x:161,y:637,t:1527631926052};\\\", \\\"{x:160,y:636,t:1527631926069};\\\", \\\"{x:160,y:635,t:1527631926085};\\\", \\\"{x:160,y:635,t:1527631926427};\\\", \\\"{x:165,y:635,t:1527631926779};\\\", \\\"{x:182,y:636,t:1527631926786};\\\", \\\"{x:229,y:643,t:1527631926803};\\\", \\\"{x:291,y:651,t:1527631926819};\\\", \\\"{x:377,y:662,t:1527631926837};\\\", \\\"{x:463,y:673,t:1527631926853};\\\", \\\"{x:552,y:689,t:1527631926869};\\\", \\\"{x:605,y:696,t:1527631926886};\\\", \\\"{x:639,y:701,t:1527631926903};\\\", \\\"{x:655,y:702,t:1527631926919};\\\", \\\"{x:659,y:703,t:1527631926936};\\\", \\\"{x:660,y:704,t:1527631926953};\\\", \\\"{x:659,y:704,t:1527631927059};\\\", \\\"{x:656,y:704,t:1527631927070};\\\", \\\"{x:649,y:705,t:1527631927086};\\\", \\\"{x:641,y:707,t:1527631927103};\\\", \\\"{x:634,y:709,t:1527631927120};\\\", \\\"{x:628,y:711,t:1527631927136};\\\", \\\"{x:623,y:713,t:1527631927153};\\\", \\\"{x:619,y:714,t:1527631927170};\\\", \\\"{x:616,y:715,t:1527631927186};\\\", \\\"{x:615,y:715,t:1527631927203};\\\", \\\"{x:613,y:715,t:1527631927220};\\\", \\\"{x:612,y:715,t:1527631927237};\\\", \\\"{x:610,y:717,t:1527631927253};\\\", \\\"{x:607,y:717,t:1527631927270};\\\", \\\"{x:604,y:718,t:1527631927287};\\\", \\\"{x:599,y:719,t:1527631927304};\\\", \\\"{x:592,y:721,t:1527631927320};\\\", \\\"{x:587,y:723,t:1527631927337};\\\", \\\"{x:583,y:724,t:1527631927353};\\\", \\\"{x:578,y:726,t:1527631927370};\\\", \\\"{x:573,y:726,t:1527631927387};\\\", \\\"{x:569,y:729,t:1527631927403};\\\", \\\"{x:562,y:730,t:1527631927420};\\\", \\\"{x:557,y:732,t:1527631927437};\\\", \\\"{x:550,y:733,t:1527631927453};\\\", \\\"{x:546,y:734,t:1527631927470};\\\", \\\"{x:543,y:736,t:1527631927487};\\\", \\\"{x:541,y:736,t:1527631927503};\\\", \\\"{x:538,y:737,t:1527631927520};\\\", \\\"{x:537,y:737,t:1527631927536};\\\", \\\"{x:536,y:737,t:1527631927553};\\\", \\\"{x:533,y:737,t:1527631927570};\\\", \\\"{x:532,y:737,t:1527631927586};\\\", \\\"{x:531,y:737,t:1527631927603};\\\", \\\"{x:530,y:737,t:1527631927634};\\\", \\\"{x:529,y:737,t:1527631927907};\\\", \\\"{x:529,y:734,t:1527631927920};\\\", \\\"{x:529,y:729,t:1527631927937};\\\", \\\"{x:529,y:722,t:1527631927954};\\\", \\\"{x:529,y:718,t:1527631927970};\\\", \\\"{x:530,y:715,t:1527631927987};\\\", \\\"{x:531,y:712,t:1527631928004};\\\", \\\"{x:531,y:710,t:1527631928020};\\\", \\\"{x:531,y:709,t:1527631928037};\\\", \\\"{x:531,y:708,t:1527631928055};\\\", \\\"{x:531,y:707,t:1527631928071};\\\", \\\"{x:532,y:707,t:1527631930250};\\\", \\\"{x:532,y:708,t:1527631930258};\\\", \\\"{x:532,y:710,t:1527631930282};\\\", \\\"{x:533,y:710,t:1527631930297};\\\", \\\"{x:533,y:711,t:1527631930306};\\\" ] }, { \\\"rt\\\": 24095, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 113306, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"8TUB0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:529,y:704,t:1527631943826};\\\", \\\"{x:526,y:700,t:1527631943834};\\\", \\\"{x:521,y:695,t:1527631943848};\\\", \\\"{x:513,y:690,t:1527631943865};\\\", \\\"{x:499,y:678,t:1527631943884};\\\", \\\"{x:489,y:670,t:1527631943899};\\\", \\\"{x:479,y:661,t:1527631943917};\\\", \\\"{x:470,y:654,t:1527631943934};\\\", \\\"{x:462,y:647,t:1527631943950};\\\", \\\"{x:454,y:639,t:1527631943967};\\\", \\\"{x:450,y:636,t:1527631943982};\\\", \\\"{x:443,y:630,t:1527631943999};\\\", \\\"{x:437,y:625,t:1527631944016};\\\", \\\"{x:431,y:621,t:1527631944034};\\\", \\\"{x:428,y:617,t:1527631944050};\\\", \\\"{x:424,y:611,t:1527631944068};\\\", \\\"{x:419,y:606,t:1527631944084};\\\", \\\"{x:416,y:602,t:1527631944100};\\\", \\\"{x:412,y:597,t:1527631944117};\\\", \\\"{x:408,y:593,t:1527631944133};\\\", \\\"{x:406,y:590,t:1527631944149};\\\", \\\"{x:401,y:584,t:1527631944167};\\\", \\\"{x:398,y:580,t:1527631944184};\\\", \\\"{x:394,y:575,t:1527631944200};\\\", \\\"{x:391,y:572,t:1527631944217};\\\", \\\"{x:387,y:567,t:1527631944233};\\\", \\\"{x:384,y:563,t:1527631944249};\\\", \\\"{x:383,y:562,t:1527631944267};\\\", \\\"{x:382,y:560,t:1527631944283};\\\", \\\"{x:381,y:560,t:1527631944300};\\\", \\\"{x:381,y:558,t:1527631944317};\\\", \\\"{x:379,y:556,t:1527631944334};\\\", \\\"{x:377,y:554,t:1527631944350};\\\", \\\"{x:377,y:553,t:1527631944366};\\\", \\\"{x:375,y:552,t:1527631944384};\\\", \\\"{x:374,y:550,t:1527631944399};\\\", \\\"{x:372,y:548,t:1527631944417};\\\", \\\"{x:369,y:546,t:1527631944433};\\\", \\\"{x:367,y:544,t:1527631944450};\\\", \\\"{x:364,y:542,t:1527631944468};\\\", \\\"{x:361,y:540,t:1527631944484};\\\", \\\"{x:358,y:537,t:1527631944501};\\\", \\\"{x:354,y:536,t:1527631944518};\\\", \\\"{x:350,y:534,t:1527631944534};\\\", \\\"{x:347,y:533,t:1527631944551};\\\", \\\"{x:346,y:533,t:1527631944570};\\\", \\\"{x:346,y:532,t:1527631944584};\\\", \\\"{x:345,y:532,t:1527631944601};\\\", \\\"{x:341,y:532,t:1527631945106};\\\", \\\"{x:340,y:532,t:1527631945117};\\\", \\\"{x:336,y:535,t:1527631945134};\\\", \\\"{x:327,y:539,t:1527631945151};\\\", \\\"{x:318,y:544,t:1527631945168};\\\", \\\"{x:312,y:548,t:1527631945184};\\\", \\\"{x:307,y:549,t:1527631945201};\\\", \\\"{x:299,y:553,t:1527631945218};\\\", \\\"{x:295,y:553,t:1527631945234};\\\", \\\"{x:291,y:555,t:1527631945250};\\\", \\\"{x:287,y:556,t:1527631945268};\\\", \\\"{x:283,y:556,t:1527631945284};\\\", \\\"{x:278,y:556,t:1527631945301};\\\", \\\"{x:274,y:556,t:1527631945318};\\\", \\\"{x:270,y:556,t:1527631945335};\\\", \\\"{x:268,y:556,t:1527631945351};\\\", \\\"{x:267,y:556,t:1527631945368};\\\", \\\"{x:268,y:554,t:1527631945434};\\\", \\\"{x:277,y:552,t:1527631945442};\\\", \\\"{x:289,y:548,t:1527631945451};\\\", \\\"{x:311,y:538,t:1527631945468};\\\", \\\"{x:334,y:527,t:1527631945485};\\\", \\\"{x:364,y:519,t:1527631945501};\\\", \\\"{x:385,y:513,t:1527631945518};\\\", \\\"{x:395,y:509,t:1527631945535};\\\", \\\"{x:400,y:509,t:1527631945551};\\\", \\\"{x:403,y:507,t:1527631945567};\\\", \\\"{x:404,y:507,t:1527631945585};\\\", \\\"{x:406,y:507,t:1527631945601};\\\", \\\"{x:407,y:511,t:1527631947514};\\\", \\\"{x:407,y:513,t:1527631947530};\\\", \\\"{x:408,y:514,t:1527631947538};\\\", \\\"{x:409,y:516,t:1527631947553};\\\", \\\"{x:409,y:518,t:1527631947568};\\\", \\\"{x:410,y:521,t:1527631947585};\\\", \\\"{x:411,y:525,t:1527631947603};\\\", \\\"{x:413,y:528,t:1527631947620};\\\", \\\"{x:417,y:535,t:1527631947636};\\\", \\\"{x:420,y:544,t:1527631947654};\\\", \\\"{x:427,y:558,t:1527631947670};\\\", \\\"{x:433,y:571,t:1527631947685};\\\", \\\"{x:440,y:586,t:1527631947703};\\\", \\\"{x:445,y:594,t:1527631947720};\\\", \\\"{x:452,y:606,t:1527631947736};\\\", \\\"{x:457,y:617,t:1527631947753};\\\", \\\"{x:458,y:619,t:1527631947770};\\\", \\\"{x:459,y:620,t:1527631947787};\\\", \\\"{x:460,y:621,t:1527631947803};\\\", \\\"{x:460,y:622,t:1527631947826};\\\", \\\"{x:461,y:623,t:1527631947841};\\\", \\\"{x:462,y:623,t:1527631947858};\\\", \\\"{x:462,y:625,t:1527631947870};\\\", \\\"{x:465,y:628,t:1527631947885};\\\", \\\"{x:469,y:633,t:1527631947903};\\\", \\\"{x:473,y:637,t:1527631947920};\\\", \\\"{x:477,y:642,t:1527631947937};\\\", \\\"{x:480,y:645,t:1527631947953};\\\", \\\"{x:485,y:652,t:1527631947969};\\\", \\\"{x:490,y:656,t:1527631947987};\\\", \\\"{x:492,y:660,t:1527631948003};\\\", \\\"{x:496,y:666,t:1527631948020};\\\", \\\"{x:499,y:670,t:1527631948037};\\\", \\\"{x:502,y:674,t:1527631948053};\\\", \\\"{x:503,y:676,t:1527631948070};\\\", \\\"{x:505,y:680,t:1527631948087};\\\", \\\"{x:506,y:681,t:1527631948102};\\\", \\\"{x:506,y:682,t:1527631948120};\\\", \\\"{x:505,y:677,t:1527631951602};\\\", \\\"{x:504,y:670,t:1527631951609};\\\", \\\"{x:500,y:663,t:1527631951622};\\\", \\\"{x:496,y:648,t:1527631951639};\\\", \\\"{x:493,y:637,t:1527631951657};\\\", \\\"{x:488,y:621,t:1527631951673};\\\", \\\"{x:480,y:602,t:1527631951690};\\\", \\\"{x:474,y:581,t:1527631951707};\\\", \\\"{x:470,y:569,t:1527631951723};\\\", \\\"{x:465,y:556,t:1527631951739};\\\", \\\"{x:459,y:543,t:1527631951756};\\\", \\\"{x:455,y:533,t:1527631951773};\\\", \\\"{x:453,y:527,t:1527631951789};\\\", \\\"{x:451,y:524,t:1527631951806};\\\", \\\"{x:449,y:522,t:1527631951823};\\\", \\\"{x:447,y:520,t:1527631951840};\\\", \\\"{x:445,y:519,t:1527631951856};\\\", \\\"{x:444,y:519,t:1527631951873};\\\", \\\"{x:441,y:519,t:1527631951890};\\\", \\\"{x:438,y:519,t:1527631951906};\\\", \\\"{x:435,y:519,t:1527631951923};\\\", \\\"{x:434,y:519,t:1527631951940};\\\", \\\"{x:432,y:519,t:1527631951956};\\\", \\\"{x:431,y:519,t:1527631951973};\\\", \\\"{x:429,y:519,t:1527631951990};\\\", \\\"{x:428,y:519,t:1527631952210};\\\", \\\"{x:427,y:519,t:1527631952242};\\\", \\\"{x:426,y:519,t:1527631952256};\\\", \\\"{x:425,y:519,t:1527631952305};\\\", \\\"{x:424,y:519,t:1527631952337};\\\", \\\"{x:423,y:520,t:1527631952362};\\\", \\\"{x:422,y:520,t:1527631953618};\\\", \\\"{x:422,y:523,t:1527631954922};\\\", \\\"{x:422,y:527,t:1527631954929};\\\", \\\"{x:422,y:530,t:1527631954942};\\\", \\\"{x:422,y:535,t:1527631954959};\\\", \\\"{x:422,y:542,t:1527631954976};\\\", \\\"{x:422,y:545,t:1527631954993};\\\", \\\"{x:422,y:551,t:1527631955009};\\\", \\\"{x:424,y:556,t:1527631955026};\\\", \\\"{x:426,y:563,t:1527631955042};\\\", \\\"{x:426,y:565,t:1527631955058};\\\", \\\"{x:427,y:567,t:1527631955075};\\\", \\\"{x:427,y:568,t:1527631955092};\\\", \\\"{x:428,y:569,t:1527631955108};\\\", \\\"{x:428,y:571,t:1527631955129};\\\", \\\"{x:428,y:572,t:1527631955194};\\\", \\\"{x:428,y:574,t:1527631955258};\\\", \\\"{x:428,y:575,t:1527631955274};\\\", \\\"{x:428,y:576,t:1527631955292};\\\", \\\"{x:429,y:578,t:1527631955310};\\\", \\\"{x:429,y:580,t:1527631955337};\\\", \\\"{x:429,y:581,t:1527631955354};\\\", \\\"{x:430,y:584,t:1527631955370};\\\", \\\"{x:430,y:585,t:1527631955378};\\\", \\\"{x:430,y:586,t:1527631955392};\\\", \\\"{x:431,y:590,t:1527631955409};\\\", \\\"{x:431,y:593,t:1527631955425};\\\", \\\"{x:431,y:594,t:1527631955442};\\\", \\\"{x:431,y:596,t:1527631955459};\\\", \\\"{x:431,y:598,t:1527631955554};\\\", \\\"{x:430,y:598,t:1527631955569};\\\", \\\"{x:427,y:600,t:1527631955578};\\\", \\\"{x:424,y:600,t:1527631955592};\\\", \\\"{x:419,y:602,t:1527631955609};\\\", \\\"{x:408,y:605,t:1527631955626};\\\", \\\"{x:401,y:608,t:1527631955643};\\\", \\\"{x:399,y:608,t:1527631955659};\\\", \\\"{x:398,y:608,t:1527631955770};\\\", \\\"{x:397,y:606,t:1527631955778};\\\", \\\"{x:395,y:604,t:1527631955793};\\\", \\\"{x:395,y:601,t:1527631955809};\\\", \\\"{x:395,y:597,t:1527631955827};\\\", \\\"{x:397,y:593,t:1527631955843};\\\", \\\"{x:409,y:587,t:1527631955859};\\\", \\\"{x:422,y:580,t:1527631955877};\\\", \\\"{x:436,y:575,t:1527631955893};\\\", \\\"{x:457,y:569,t:1527631955910};\\\", \\\"{x:476,y:563,t:1527631955927};\\\", \\\"{x:497,y:559,t:1527631955944};\\\", \\\"{x:518,y:554,t:1527631955960};\\\", \\\"{x:531,y:551,t:1527631955976};\\\", \\\"{x:541,y:551,t:1527631955993};\\\", \\\"{x:551,y:549,t:1527631956009};\\\", \\\"{x:566,y:549,t:1527631956026};\\\", \\\"{x:571,y:549,t:1527631956043};\\\", \\\"{x:576,y:549,t:1527631956060};\\\", \\\"{x:583,y:549,t:1527631956077};\\\", \\\"{x:593,y:548,t:1527631956094};\\\", \\\"{x:603,y:547,t:1527631956109};\\\", \\\"{x:614,y:547,t:1527631956126};\\\", \\\"{x:624,y:547,t:1527631956144};\\\", \\\"{x:635,y:547,t:1527631956159};\\\", \\\"{x:652,y:547,t:1527631956177};\\\", \\\"{x:665,y:547,t:1527631956194};\\\", \\\"{x:692,y:556,t:1527631956210};\\\", \\\"{x:708,y:562,t:1527631956226};\\\", \\\"{x:718,y:568,t:1527631956243};\\\", \\\"{x:722,y:572,t:1527631956261};\\\", \\\"{x:723,y:575,t:1527631956276};\\\", \\\"{x:723,y:579,t:1527631956293};\\\", \\\"{x:723,y:584,t:1527631956311};\\\", \\\"{x:719,y:589,t:1527631956326};\\\", \\\"{x:710,y:598,t:1527631956343};\\\", \\\"{x:695,y:607,t:1527631956360};\\\", \\\"{x:690,y:611,t:1527631956376};\\\", \\\"{x:684,y:616,t:1527631956393};\\\", \\\"{x:674,y:622,t:1527631956410};\\\", \\\"{x:668,y:624,t:1527631956427};\\\", \\\"{x:663,y:626,t:1527631956444};\\\", \\\"{x:655,y:629,t:1527631956460};\\\", \\\"{x:645,y:631,t:1527631956476};\\\", \\\"{x:632,y:635,t:1527631956494};\\\", \\\"{x:615,y:638,t:1527631956511};\\\", \\\"{x:596,y:639,t:1527631956526};\\\", \\\"{x:572,y:640,t:1527631956543};\\\", \\\"{x:545,y:640,t:1527631956560};\\\", \\\"{x:509,y:640,t:1527631956577};\\\", \\\"{x:470,y:640,t:1527631956593};\\\", \\\"{x:411,y:640,t:1527631956611};\\\", \\\"{x:376,y:640,t:1527631956627};\\\", \\\"{x:348,y:640,t:1527631956643};\\\", \\\"{x:323,y:640,t:1527631956661};\\\", \\\"{x:306,y:640,t:1527631956678};\\\", \\\"{x:299,y:640,t:1527631956693};\\\", \\\"{x:296,y:640,t:1527631956710};\\\", \\\"{x:294,y:640,t:1527631956727};\\\", \\\"{x:293,y:640,t:1527631956744};\\\", \\\"{x:290,y:640,t:1527631956760};\\\", \\\"{x:288,y:640,t:1527631956777};\\\", \\\"{x:286,y:640,t:1527631956794};\\\", \\\"{x:281,y:640,t:1527631956810};\\\", \\\"{x:278,y:641,t:1527631956827};\\\", \\\"{x:274,y:643,t:1527631956843};\\\", \\\"{x:267,y:645,t:1527631956860};\\\", \\\"{x:257,y:648,t:1527631956877};\\\", \\\"{x:243,y:652,t:1527631956894};\\\", \\\"{x:232,y:655,t:1527631956910};\\\", \\\"{x:220,y:657,t:1527631956927};\\\", \\\"{x:214,y:657,t:1527631956943};\\\", \\\"{x:209,y:657,t:1527631956961};\\\", \\\"{x:204,y:657,t:1527631956977};\\\", \\\"{x:196,y:651,t:1527631956994};\\\", \\\"{x:183,y:645,t:1527631957010};\\\", \\\"{x:178,y:641,t:1527631957028};\\\", \\\"{x:173,y:637,t:1527631957043};\\\", \\\"{x:166,y:628,t:1527631957061};\\\", \\\"{x:159,y:619,t:1527631957077};\\\", \\\"{x:154,y:610,t:1527631957094};\\\", \\\"{x:147,y:600,t:1527631957110};\\\", \\\"{x:144,y:594,t:1527631957127};\\\", \\\"{x:142,y:589,t:1527631957144};\\\", \\\"{x:138,y:585,t:1527631957160};\\\", \\\"{x:134,y:579,t:1527631957177};\\\", \\\"{x:131,y:574,t:1527631957194};\\\", \\\"{x:130,y:573,t:1527631957210};\\\", \\\"{x:130,y:571,t:1527631957227};\\\", \\\"{x:130,y:570,t:1527631957273};\\\", \\\"{x:132,y:570,t:1527631957345};\\\", \\\"{x:137,y:567,t:1527631957361};\\\", \\\"{x:139,y:566,t:1527631957377};\\\", \\\"{x:145,y:566,t:1527631957395};\\\", \\\"{x:152,y:563,t:1527631957410};\\\", \\\"{x:156,y:562,t:1527631957427};\\\", \\\"{x:157,y:562,t:1527631957770};\\\", \\\"{x:162,y:562,t:1527631957778};\\\", \\\"{x:184,y:562,t:1527631957794};\\\", \\\"{x:206,y:562,t:1527631957811};\\\", \\\"{x:236,y:572,t:1527631957827};\\\", \\\"{x:266,y:583,t:1527631957845};\\\", \\\"{x:295,y:595,t:1527631957861};\\\", \\\"{x:318,y:604,t:1527631957877};\\\", \\\"{x:340,y:615,t:1527631957895};\\\", \\\"{x:362,y:625,t:1527631957912};\\\", \\\"{x:383,y:634,t:1527631957929};\\\", \\\"{x:404,y:642,t:1527631957944};\\\", \\\"{x:424,y:652,t:1527631957961};\\\", \\\"{x:433,y:656,t:1527631957977};\\\", \\\"{x:434,y:657,t:1527631957995};\\\", \\\"{x:436,y:659,t:1527631958011};\\\", \\\"{x:436,y:660,t:1527631958049};\\\", \\\"{x:437,y:661,t:1527631958062};\\\", \\\"{x:440,y:667,t:1527631958079};\\\", \\\"{x:443,y:674,t:1527631958094};\\\", \\\"{x:445,y:678,t:1527631958111};\\\", \\\"{x:450,y:687,t:1527631958129};\\\", \\\"{x:455,y:693,t:1527631958145};\\\", \\\"{x:463,y:704,t:1527631958162};\\\", \\\"{x:473,y:718,t:1527631958178};\\\", \\\"{x:482,y:728,t:1527631958194};\\\", \\\"{x:491,y:737,t:1527631958212};\\\", \\\"{x:496,y:738,t:1527631958229};\\\", \\\"{x:497,y:738,t:1527631958244};\\\", \\\"{x:498,y:738,t:1527631958261};\\\", \\\"{x:498,y:739,t:1527631958369};\\\", \\\"{x:496,y:740,t:1527631958394};\\\", \\\"{x:494,y:740,t:1527631958418};\\\", \\\"{x:493,y:741,t:1527631958428};\\\", \\\"{x:492,y:741,t:1527631958445};\\\", \\\"{x:491,y:741,t:1527631958449};\\\", \\\"{x:491,y:741,t:1527631958461};\\\", \\\"{x:489,y:741,t:1527631958490};\\\", \\\"{x:488,y:740,t:1527631958497};\\\", \\\"{x:488,y:737,t:1527631958511};\\\", \\\"{x:488,y:730,t:1527631958528};\\\", \\\"{x:487,y:720,t:1527631958545};\\\", \\\"{x:486,y:713,t:1527631958562};\\\", \\\"{x:485,y:710,t:1527631958578};\\\", \\\"{x:484,y:708,t:1527631958595};\\\", \\\"{x:483,y:708,t:1527631958633};\\\", \\\"{x:482,y:708,t:1527631958673};\\\", \\\"{x:481,y:708,t:1527631958777};\\\", \\\"{x:479,y:708,t:1527631958786};\\\", \\\"{x:477,y:709,t:1527631959850};\\\", \\\"{x:476,y:709,t:1527631959874};\\\", \\\"{x:476,y:710,t:1527631959881};\\\", \\\"{x:474,y:710,t:1527631959970};\\\" ] }, { \\\"rt\\\": 49464, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 163991, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"8TUB0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -06 PM-03 PM-U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:475,y:710,t:1527631965221};\\\", \\\"{x:501,y:716,t:1527631965236};\\\", \\\"{x:668,y:753,t:1527631965253};\\\", \\\"{x:802,y:778,t:1527631965270};\\\", \\\"{x:942,y:809,t:1527631965286};\\\", \\\"{x:1088,y:843,t:1527631965304};\\\", \\\"{x:1214,y:871,t:1527631965321};\\\", \\\"{x:1325,y:891,t:1527631965337};\\\", \\\"{x:1401,y:904,t:1527631965354};\\\", \\\"{x:1440,y:915,t:1527631965371};\\\", \\\"{x:1470,y:921,t:1527631965387};\\\", \\\"{x:1486,y:923,t:1527631965404};\\\", \\\"{x:1506,y:926,t:1527631965421};\\\", \\\"{x:1516,y:927,t:1527631965437};\\\", \\\"{x:1530,y:929,t:1527631965454};\\\", \\\"{x:1540,y:929,t:1527631965471};\\\", \\\"{x:1555,y:929,t:1527631965487};\\\", \\\"{x:1577,y:933,t:1527631965504};\\\", \\\"{x:1602,y:934,t:1527631965521};\\\", \\\"{x:1625,y:939,t:1527631965537};\\\", \\\"{x:1650,y:943,t:1527631965554};\\\", \\\"{x:1668,y:944,t:1527631965571};\\\", \\\"{x:1681,y:948,t:1527631965587};\\\", \\\"{x:1685,y:950,t:1527631965604};\\\", \\\"{x:1687,y:951,t:1527631965621};\\\", \\\"{x:1687,y:952,t:1527631965701};\\\", \\\"{x:1687,y:954,t:1527631965724};\\\", \\\"{x:1687,y:956,t:1527631965741};\\\", \\\"{x:1686,y:957,t:1527631965756};\\\", \\\"{x:1685,y:957,t:1527631965771};\\\", \\\"{x:1680,y:959,t:1527631965788};\\\", \\\"{x:1676,y:961,t:1527631965804};\\\", \\\"{x:1673,y:963,t:1527631965821};\\\", \\\"{x:1670,y:965,t:1527631965838};\\\", \\\"{x:1668,y:965,t:1527631965854};\\\", \\\"{x:1664,y:966,t:1527631965871};\\\", \\\"{x:1657,y:969,t:1527631965888};\\\", \\\"{x:1654,y:969,t:1527631965904};\\\", \\\"{x:1650,y:970,t:1527631965921};\\\", \\\"{x:1647,y:971,t:1527631965938};\\\", \\\"{x:1643,y:972,t:1527631965953};\\\", \\\"{x:1640,y:973,t:1527631965971};\\\", \\\"{x:1638,y:974,t:1527631965988};\\\", \\\"{x:1637,y:973,t:1527631966125};\\\", \\\"{x:1636,y:970,t:1527631966138};\\\", \\\"{x:1633,y:963,t:1527631966155};\\\", \\\"{x:1630,y:954,t:1527631966171};\\\", \\\"{x:1625,y:944,t:1527631966188};\\\", \\\"{x:1618,y:927,t:1527631966204};\\\", \\\"{x:1614,y:918,t:1527631966221};\\\", \\\"{x:1613,y:912,t:1527631966238};\\\", \\\"{x:1610,y:905,t:1527631966255};\\\", \\\"{x:1607,y:892,t:1527631966271};\\\", \\\"{x:1605,y:880,t:1527631966288};\\\", \\\"{x:1603,y:867,t:1527631966305};\\\", \\\"{x:1602,y:857,t:1527631966320};\\\", \\\"{x:1601,y:850,t:1527631966338};\\\", \\\"{x:1600,y:845,t:1527631966354};\\\", \\\"{x:1600,y:841,t:1527631966371};\\\", \\\"{x:1600,y:838,t:1527631966388};\\\", \\\"{x:1598,y:831,t:1527631966404};\\\", \\\"{x:1598,y:826,t:1527631966421};\\\", \\\"{x:1598,y:818,t:1527631966438};\\\", \\\"{x:1596,y:811,t:1527631966454};\\\", \\\"{x:1596,y:806,t:1527631966471};\\\", \\\"{x:1596,y:803,t:1527631966488};\\\", \\\"{x:1596,y:797,t:1527631966505};\\\", \\\"{x:1596,y:792,t:1527631966521};\\\", \\\"{x:1596,y:785,t:1527631966539};\\\", \\\"{x:1596,y:777,t:1527631966555};\\\", \\\"{x:1596,y:770,t:1527631966571};\\\", \\\"{x:1596,y:764,t:1527631966588};\\\", \\\"{x:1596,y:753,t:1527631966605};\\\", \\\"{x:1597,y:746,t:1527631966621};\\\", \\\"{x:1598,y:739,t:1527631966638};\\\", \\\"{x:1600,y:730,t:1527631966654};\\\", \\\"{x:1601,y:721,t:1527631966672};\\\", \\\"{x:1602,y:715,t:1527631966688};\\\", \\\"{x:1602,y:712,t:1527631966705};\\\", \\\"{x:1602,y:710,t:1527631966722};\\\", \\\"{x:1602,y:707,t:1527631966738};\\\", \\\"{x:1602,y:705,t:1527631966755};\\\", \\\"{x:1602,y:702,t:1527631966772};\\\", \\\"{x:1602,y:698,t:1527631966788};\\\", \\\"{x:1602,y:694,t:1527631966804};\\\", \\\"{x:1602,y:691,t:1527631966822};\\\", \\\"{x:1602,y:687,t:1527631966838};\\\", \\\"{x:1602,y:683,t:1527631966854};\\\", \\\"{x:1602,y:680,t:1527631966872};\\\", \\\"{x:1602,y:676,t:1527631966888};\\\", \\\"{x:1602,y:672,t:1527631966905};\\\", \\\"{x:1605,y:667,t:1527631966922};\\\", \\\"{x:1605,y:663,t:1527631966938};\\\", \\\"{x:1606,y:658,t:1527631966955};\\\", \\\"{x:1606,y:651,t:1527631966972};\\\", \\\"{x:1606,y:647,t:1527631966988};\\\", \\\"{x:1608,y:638,t:1527631967004};\\\", \\\"{x:1608,y:635,t:1527631967022};\\\", \\\"{x:1608,y:631,t:1527631967038};\\\", \\\"{x:1608,y:628,t:1527631967055};\\\", \\\"{x:1608,y:623,t:1527631967072};\\\", \\\"{x:1608,y:619,t:1527631967089};\\\", \\\"{x:1608,y:617,t:1527631967105};\\\", \\\"{x:1608,y:614,t:1527631967122};\\\", \\\"{x:1608,y:612,t:1527631967141};\\\", \\\"{x:1608,y:611,t:1527631967156};\\\", \\\"{x:1608,y:610,t:1527631967171};\\\", \\\"{x:1607,y:607,t:1527631967188};\\\", \\\"{x:1607,y:606,t:1527631967205};\\\", \\\"{x:1606,y:605,t:1527631967222};\\\", \\\"{x:1606,y:604,t:1527631967239};\\\", \\\"{x:1606,y:602,t:1527631967255};\\\", \\\"{x:1605,y:601,t:1527631967272};\\\", \\\"{x:1605,y:599,t:1527631967289};\\\", \\\"{x:1604,y:599,t:1527631967305};\\\", \\\"{x:1604,y:598,t:1527631967322};\\\", \\\"{x:1604,y:596,t:1527631967339};\\\", \\\"{x:1604,y:595,t:1527631967355};\\\", \\\"{x:1603,y:593,t:1527631967372};\\\", \\\"{x:1603,y:592,t:1527631967389};\\\", \\\"{x:1603,y:591,t:1527631967405};\\\", \\\"{x:1602,y:590,t:1527631967422};\\\", \\\"{x:1602,y:589,t:1527631967444};\\\", \\\"{x:1602,y:588,t:1527631967461};\\\", \\\"{x:1602,y:587,t:1527631967472};\\\", \\\"{x:1601,y:587,t:1527631967489};\\\", \\\"{x:1601,y:586,t:1527631967508};\\\", \\\"{x:1601,y:585,t:1527631967524};\\\", \\\"{x:1601,y:584,t:1527631967557};\\\", \\\"{x:1600,y:583,t:1527631967572};\\\", \\\"{x:1600,y:582,t:1527631967589};\\\", \\\"{x:1599,y:581,t:1527631967606};\\\", \\\"{x:1599,y:580,t:1527631967622};\\\", \\\"{x:1599,y:579,t:1527631967639};\\\", \\\"{x:1599,y:577,t:1527631967656};\\\", \\\"{x:1598,y:576,t:1527631967672};\\\", \\\"{x:1598,y:574,t:1527631967689};\\\", \\\"{x:1598,y:573,t:1527631967706};\\\", \\\"{x:1598,y:572,t:1527631967733};\\\", \\\"{x:1598,y:571,t:1527631967749};\\\", \\\"{x:1597,y:571,t:1527631967757};\\\", \\\"{x:1596,y:571,t:1527631968437};\\\", \\\"{x:1595,y:572,t:1527631968453};\\\", \\\"{x:1595,y:573,t:1527631968477};\\\", \\\"{x:1594,y:574,t:1527631968532};\\\", \\\"{x:1594,y:576,t:1527631968629};\\\", \\\"{x:1593,y:578,t:1527631968640};\\\", \\\"{x:1592,y:579,t:1527631968656};\\\", \\\"{x:1592,y:583,t:1527631968673};\\\", \\\"{x:1592,y:584,t:1527631968690};\\\", \\\"{x:1592,y:585,t:1527631968706};\\\", \\\"{x:1591,y:586,t:1527631969061};\\\", \\\"{x:1590,y:586,t:1527631972165};\\\", \\\"{x:1589,y:587,t:1527631974117};\\\", \\\"{x:1588,y:588,t:1527631974141};\\\", \\\"{x:1587,y:588,t:1527631974156};\\\", \\\"{x:1586,y:588,t:1527631974188};\\\", \\\"{x:1585,y:588,t:1527631974204};\\\", \\\"{x:1583,y:589,t:1527631974212};\\\", \\\"{x:1581,y:589,t:1527631974228};\\\", \\\"{x:1573,y:589,t:1527631974244};\\\", \\\"{x:1554,y:590,t:1527631974261};\\\", \\\"{x:1537,y:590,t:1527631974277};\\\", \\\"{x:1526,y:591,t:1527631974294};\\\", \\\"{x:1512,y:592,t:1527631974311};\\\", \\\"{x:1503,y:594,t:1527631974327};\\\", \\\"{x:1496,y:595,t:1527631974345};\\\", \\\"{x:1490,y:596,t:1527631974361};\\\", \\\"{x:1484,y:596,t:1527631974378};\\\", \\\"{x:1480,y:596,t:1527631974395};\\\", \\\"{x:1476,y:596,t:1527631974412};\\\", \\\"{x:1474,y:596,t:1527631974428};\\\", \\\"{x:1471,y:596,t:1527631974444};\\\", \\\"{x:1469,y:596,t:1527631974461};\\\", \\\"{x:1468,y:596,t:1527631974477};\\\", \\\"{x:1466,y:596,t:1527631974494};\\\", \\\"{x:1464,y:596,t:1527631974512};\\\", \\\"{x:1463,y:596,t:1527631974527};\\\", \\\"{x:1461,y:596,t:1527631974545};\\\", \\\"{x:1458,y:596,t:1527631974562};\\\", \\\"{x:1454,y:596,t:1527631974578};\\\", \\\"{x:1448,y:596,t:1527631974595};\\\", \\\"{x:1443,y:596,t:1527631974612};\\\", \\\"{x:1435,y:596,t:1527631974628};\\\", \\\"{x:1431,y:596,t:1527631974645};\\\", \\\"{x:1425,y:596,t:1527631974661};\\\", \\\"{x:1423,y:595,t:1527631974679};\\\", \\\"{x:1421,y:595,t:1527631974694};\\\", \\\"{x:1420,y:595,t:1527631974741};\\\", \\\"{x:1418,y:595,t:1527631974997};\\\", \\\"{x:1417,y:595,t:1527631975374};\\\", \\\"{x:1415,y:595,t:1527631975389};\\\", \\\"{x:1414,y:595,t:1527631975397};\\\", \\\"{x:1412,y:595,t:1527631975412};\\\", \\\"{x:1409,y:595,t:1527631975428};\\\", \\\"{x:1404,y:595,t:1527631975445};\\\", \\\"{x:1398,y:595,t:1527631975462};\\\", \\\"{x:1393,y:595,t:1527631975479};\\\", \\\"{x:1390,y:595,t:1527631975495};\\\", \\\"{x:1389,y:595,t:1527631975512};\\\", \\\"{x:1387,y:595,t:1527631975529};\\\", \\\"{x:1386,y:595,t:1527631975546};\\\", \\\"{x:1385,y:595,t:1527631975563};\\\", \\\"{x:1384,y:595,t:1527631975579};\\\", \\\"{x:1383,y:595,t:1527631975596};\\\", \\\"{x:1382,y:595,t:1527631975612};\\\", \\\"{x:1381,y:595,t:1527631975629};\\\", \\\"{x:1380,y:594,t:1527631978261};\\\", \\\"{x:1380,y:588,t:1527631978269};\\\", \\\"{x:1380,y:583,t:1527631978281};\\\", \\\"{x:1380,y:577,t:1527631978297};\\\", \\\"{x:1378,y:572,t:1527631978314};\\\", \\\"{x:1378,y:566,t:1527631978330};\\\", \\\"{x:1377,y:563,t:1527631978348};\\\", \\\"{x:1376,y:560,t:1527631978365};\\\", \\\"{x:1376,y:558,t:1527631978381};\\\", \\\"{x:1376,y:557,t:1527631978398};\\\", \\\"{x:1376,y:556,t:1527631978429};\\\", \\\"{x:1376,y:553,t:1527631984358};\\\", \\\"{x:1375,y:550,t:1527631984369};\\\", \\\"{x:1374,y:548,t:1527631984386};\\\", \\\"{x:1374,y:546,t:1527631984403};\\\", \\\"{x:1374,y:545,t:1527631984419};\\\", \\\"{x:1374,y:543,t:1527631984436};\\\", \\\"{x:1374,y:541,t:1527631984453};\\\", \\\"{x:1373,y:540,t:1527631984469};\\\", \\\"{x:1372,y:538,t:1527631984486};\\\", \\\"{x:1372,y:537,t:1527631984503};\\\", \\\"{x:1372,y:535,t:1527631984525};\\\", \\\"{x:1384,y:539,t:1527631985493};\\\", \\\"{x:1410,y:551,t:1527631985503};\\\", \\\"{x:1471,y:568,t:1527631985521};\\\", \\\"{x:1537,y:592,t:1527631985537};\\\", \\\"{x:1603,y:623,t:1527631985553};\\\", \\\"{x:1669,y:661,t:1527631985570};\\\", \\\"{x:1738,y:704,t:1527631985587};\\\", \\\"{x:1798,y:753,t:1527631985603};\\\", \\\"{x:1852,y:797,t:1527631985620};\\\", \\\"{x:1897,y:850,t:1527631985636};\\\", \\\"{x:1911,y:872,t:1527631985653};\\\", \\\"{x:1918,y:889,t:1527631985670};\\\", \\\"{x:1919,y:899,t:1527631985687};\\\", \\\"{x:1919,y:906,t:1527631985704};\\\", \\\"{x:1915,y:910,t:1527631985720};\\\", \\\"{x:1911,y:912,t:1527631985736};\\\", \\\"{x:1902,y:915,t:1527631985754};\\\", \\\"{x:1890,y:918,t:1527631985770};\\\", \\\"{x:1881,y:920,t:1527631985787};\\\", \\\"{x:1872,y:923,t:1527631985805};\\\", \\\"{x:1856,y:928,t:1527631985821};\\\", \\\"{x:1849,y:929,t:1527631985837};\\\", \\\"{x:1839,y:933,t:1527631985854};\\\", \\\"{x:1826,y:937,t:1527631985871};\\\", \\\"{x:1819,y:939,t:1527631985887};\\\", \\\"{x:1804,y:944,t:1527631985904};\\\", \\\"{x:1790,y:950,t:1527631985921};\\\", \\\"{x:1773,y:959,t:1527631985937};\\\", \\\"{x:1756,y:971,t:1527631985954};\\\", \\\"{x:1741,y:982,t:1527631985971};\\\", \\\"{x:1726,y:994,t:1527631985987};\\\", \\\"{x:1713,y:1004,t:1527631986005};\\\", \\\"{x:1692,y:1026,t:1527631986021};\\\", \\\"{x:1682,y:1040,t:1527631986037};\\\", \\\"{x:1673,y:1050,t:1527631986054};\\\", \\\"{x:1665,y:1058,t:1527631986071};\\\", \\\"{x:1661,y:1061,t:1527631986088};\\\", \\\"{x:1658,y:1063,t:1527631986104};\\\", \\\"{x:1655,y:1063,t:1527631986121};\\\", \\\"{x:1654,y:1063,t:1527631986137};\\\", \\\"{x:1653,y:1063,t:1527631986154};\\\", \\\"{x:1651,y:1063,t:1527631986171};\\\", \\\"{x:1645,y:1063,t:1527631986187};\\\", \\\"{x:1638,y:1057,t:1527631986204};\\\", \\\"{x:1618,y:1040,t:1527631986221};\\\", \\\"{x:1600,y:1026,t:1527631986238};\\\", \\\"{x:1580,y:1011,t:1527631986254};\\\", \\\"{x:1561,y:998,t:1527631986271};\\\", \\\"{x:1544,y:983,t:1527631986288};\\\", \\\"{x:1522,y:967,t:1527631986305};\\\", \\\"{x:1500,y:952,t:1527631986321};\\\", \\\"{x:1481,y:936,t:1527631986337};\\\", \\\"{x:1466,y:924,t:1527631986354};\\\", \\\"{x:1453,y:914,t:1527631986371};\\\", \\\"{x:1445,y:903,t:1527631986388};\\\", \\\"{x:1441,y:895,t:1527631986404};\\\", \\\"{x:1435,y:882,t:1527631986421};\\\", \\\"{x:1430,y:873,t:1527631986438};\\\", \\\"{x:1426,y:866,t:1527631986455};\\\", \\\"{x:1422,y:856,t:1527631986471};\\\", \\\"{x:1418,y:848,t:1527631986488};\\\", \\\"{x:1410,y:837,t:1527631986505};\\\", \\\"{x:1405,y:828,t:1527631986521};\\\", \\\"{x:1401,y:819,t:1527631986538};\\\", \\\"{x:1396,y:814,t:1527631986554};\\\", \\\"{x:1390,y:805,t:1527631986572};\\\", \\\"{x:1385,y:797,t:1527631986588};\\\", \\\"{x:1379,y:786,t:1527631986604};\\\", \\\"{x:1371,y:772,t:1527631986621};\\\", \\\"{x:1366,y:763,t:1527631986638};\\\", \\\"{x:1362,y:754,t:1527631986655};\\\", \\\"{x:1356,y:737,t:1527631986671};\\\", \\\"{x:1351,y:724,t:1527631986688};\\\", \\\"{x:1347,y:716,t:1527631986705};\\\", \\\"{x:1346,y:711,t:1527631986721};\\\", \\\"{x:1342,y:699,t:1527631986739};\\\", \\\"{x:1339,y:686,t:1527631986756};\\\", \\\"{x:1338,y:678,t:1527631986771};\\\", \\\"{x:1336,y:670,t:1527631986788};\\\", \\\"{x:1334,y:661,t:1527631986804};\\\", \\\"{x:1333,y:658,t:1527631986821};\\\", \\\"{x:1332,y:653,t:1527631986838};\\\", \\\"{x:1331,y:649,t:1527631986855};\\\", \\\"{x:1331,y:648,t:1527631986871};\\\", \\\"{x:1330,y:647,t:1527631986888};\\\", \\\"{x:1330,y:646,t:1527631986905};\\\", \\\"{x:1330,y:644,t:1527631986921};\\\", \\\"{x:1329,y:642,t:1527631986938};\\\", \\\"{x:1329,y:641,t:1527631986957};\\\", \\\"{x:1328,y:640,t:1527631986981};\\\", \\\"{x:1328,y:639,t:1527631986989};\\\", \\\"{x:1328,y:638,t:1527631987013};\\\", \\\"{x:1327,y:638,t:1527631987028};\\\", \\\"{x:1326,y:640,t:1527631995453};\\\", \\\"{x:1322,y:647,t:1527631995462};\\\", \\\"{x:1318,y:659,t:1527631995478};\\\", \\\"{x:1313,y:674,t:1527631995494};\\\", \\\"{x:1310,y:691,t:1527631995511};\\\", \\\"{x:1305,y:714,t:1527631995528};\\\", \\\"{x:1301,y:741,t:1527631995546};\\\", \\\"{x:1300,y:769,t:1527631995561};\\\", \\\"{x:1300,y:795,t:1527631995579};\\\", \\\"{x:1301,y:817,t:1527631995595};\\\", \\\"{x:1304,y:840,t:1527631995611};\\\", \\\"{x:1314,y:873,t:1527631995629};\\\", \\\"{x:1316,y:888,t:1527631995644};\\\", \\\"{x:1319,y:896,t:1527631995662};\\\", \\\"{x:1320,y:901,t:1527631995679};\\\", \\\"{x:1320,y:900,t:1527631995869};\\\", \\\"{x:1320,y:892,t:1527631995879};\\\", \\\"{x:1311,y:869,t:1527631995896};\\\", \\\"{x:1303,y:845,t:1527631995912};\\\", \\\"{x:1299,y:832,t:1527631995929};\\\", \\\"{x:1294,y:821,t:1527631995945};\\\", \\\"{x:1292,y:816,t:1527631995962};\\\", \\\"{x:1291,y:815,t:1527631995978};\\\", \\\"{x:1291,y:814,t:1527631995996};\\\", \\\"{x:1293,y:814,t:1527631997453};\\\", \\\"{x:1294,y:814,t:1527631997464};\\\", \\\"{x:1298,y:815,t:1527631997480};\\\", \\\"{x:1300,y:817,t:1527631997497};\\\", \\\"{x:1302,y:819,t:1527631997514};\\\", \\\"{x:1306,y:821,t:1527631997530};\\\", \\\"{x:1311,y:823,t:1527631997547};\\\", \\\"{x:1321,y:826,t:1527631997564};\\\", \\\"{x:1331,y:827,t:1527631997580};\\\", \\\"{x:1337,y:827,t:1527631997597};\\\", \\\"{x:1340,y:827,t:1527631997614};\\\", \\\"{x:1346,y:827,t:1527631997630};\\\", \\\"{x:1359,y:827,t:1527631997647};\\\", \\\"{x:1374,y:827,t:1527631997664};\\\", \\\"{x:1387,y:827,t:1527631997680};\\\", \\\"{x:1399,y:827,t:1527631997696};\\\", \\\"{x:1410,y:829,t:1527631997714};\\\", \\\"{x:1424,y:831,t:1527631997730};\\\", \\\"{x:1439,y:832,t:1527631997747};\\\", \\\"{x:1459,y:838,t:1527631997763};\\\", \\\"{x:1476,y:841,t:1527631997780};\\\", \\\"{x:1504,y:848,t:1527631997796};\\\", \\\"{x:1524,y:854,t:1527631997814};\\\", \\\"{x:1541,y:862,t:1527631997830};\\\", \\\"{x:1554,y:867,t:1527631997846};\\\", \\\"{x:1567,y:874,t:1527631997864};\\\", \\\"{x:1582,y:883,t:1527631997881};\\\", \\\"{x:1594,y:893,t:1527631997897};\\\", \\\"{x:1606,y:903,t:1527631997914};\\\", \\\"{x:1620,y:914,t:1527631997931};\\\", \\\"{x:1634,y:926,t:1527631997947};\\\", \\\"{x:1644,y:936,t:1527631997964};\\\", \\\"{x:1653,y:942,t:1527631997981};\\\", \\\"{x:1654,y:943,t:1527631997996};\\\", \\\"{x:1654,y:945,t:1527631998140};\\\", \\\"{x:1653,y:945,t:1527631998157};\\\", \\\"{x:1650,y:945,t:1527631998164};\\\", \\\"{x:1645,y:945,t:1527631998180};\\\", \\\"{x:1638,y:945,t:1527631998198};\\\", \\\"{x:1630,y:943,t:1527631998213};\\\", \\\"{x:1621,y:940,t:1527631998231};\\\", \\\"{x:1615,y:938,t:1527631998247};\\\", \\\"{x:1607,y:933,t:1527631998263};\\\", \\\"{x:1598,y:929,t:1527631998280};\\\", \\\"{x:1587,y:924,t:1527631998298};\\\", \\\"{x:1576,y:917,t:1527631998313};\\\", \\\"{x:1567,y:912,t:1527631998330};\\\", \\\"{x:1555,y:908,t:1527631998348};\\\", \\\"{x:1544,y:903,t:1527631998363};\\\", \\\"{x:1535,y:899,t:1527631998381};\\\", \\\"{x:1531,y:897,t:1527631998397};\\\", \\\"{x:1527,y:896,t:1527631998414};\\\", \\\"{x:1521,y:893,t:1527631998431};\\\", \\\"{x:1517,y:892,t:1527631998447};\\\", \\\"{x:1509,y:889,t:1527631998464};\\\", \\\"{x:1501,y:888,t:1527631998481};\\\", \\\"{x:1493,y:884,t:1527631998497};\\\", \\\"{x:1487,y:882,t:1527631998513};\\\", \\\"{x:1482,y:881,t:1527631998530};\\\", \\\"{x:1475,y:879,t:1527631998548};\\\", \\\"{x:1471,y:878,t:1527631998563};\\\", \\\"{x:1467,y:876,t:1527631998580};\\\", \\\"{x:1465,y:876,t:1527631998598};\\\", \\\"{x:1464,y:875,t:1527631998614};\\\", \\\"{x:1463,y:875,t:1527631998669};\\\", \\\"{x:1463,y:874,t:1527631998680};\\\", \\\"{x:1462,y:873,t:1527631998698};\\\", \\\"{x:1462,y:871,t:1527631998715};\\\", \\\"{x:1462,y:870,t:1527631998731};\\\", \\\"{x:1462,y:868,t:1527631998748};\\\", \\\"{x:1462,y:865,t:1527631998764};\\\", \\\"{x:1462,y:864,t:1527631998780};\\\", \\\"{x:1462,y:863,t:1527631998797};\\\", \\\"{x:1462,y:862,t:1527631998814};\\\", \\\"{x:1462,y:861,t:1527631998830};\\\", \\\"{x:1462,y:859,t:1527631998848};\\\", \\\"{x:1462,y:858,t:1527631998893};\\\", \\\"{x:1463,y:858,t:1527631999181};\\\", \\\"{x:1464,y:856,t:1527631999204};\\\", \\\"{x:1464,y:855,t:1527631999214};\\\", \\\"{x:1465,y:855,t:1527631999231};\\\", \\\"{x:1466,y:853,t:1527631999248};\\\", \\\"{x:1467,y:852,t:1527631999264};\\\", \\\"{x:1468,y:851,t:1527631999282};\\\", \\\"{x:1470,y:851,t:1527631999333};\\\", \\\"{x:1472,y:850,t:1527631999357};\\\", \\\"{x:1473,y:850,t:1527631999365};\\\", \\\"{x:1473,y:849,t:1527631999396};\\\", \\\"{x:1474,y:849,t:1527631999421};\\\", \\\"{x:1475,y:849,t:1527631999453};\\\", \\\"{x:1476,y:849,t:1527631999477};\\\", \\\"{x:1476,y:848,t:1527631999485};\\\", \\\"{x:1477,y:848,t:1527631999525};\\\", \\\"{x:1478,y:847,t:1527631999565};\\\", \\\"{x:1478,y:846,t:1527631999837};\\\", \\\"{x:1478,y:845,t:1527631999852};\\\", \\\"{x:1478,y:844,t:1527632000677};\\\", \\\"{x:1478,y:843,t:1527632000693};\\\", \\\"{x:1478,y:842,t:1527632000708};\\\", \\\"{x:1478,y:841,t:1527632000724};\\\", \\\"{x:1478,y:840,t:1527632000749};\\\", \\\"{x:1478,y:839,t:1527632000805};\\\", \\\"{x:1478,y:838,t:1527632000821};\\\", \\\"{x:1477,y:837,t:1527632000837};\\\", \\\"{x:1477,y:836,t:1527632000861};\\\", \\\"{x:1477,y:835,t:1527632000868};\\\", \\\"{x:1477,y:834,t:1527632000884};\\\", \\\"{x:1477,y:832,t:1527632000915};\\\", \\\"{x:1477,y:831,t:1527632000940};\\\", \\\"{x:1477,y:829,t:1527632000980};\\\", \\\"{x:1477,y:828,t:1527632001013};\\\", \\\"{x:1476,y:828,t:1527632003445};\\\", \\\"{x:1475,y:828,t:1527632003461};\\\", \\\"{x:1474,y:828,t:1527632003469};\\\", \\\"{x:1473,y:828,t:1527632003484};\\\", \\\"{x:1472,y:828,t:1527632003509};\\\", \\\"{x:1471,y:828,t:1527632003525};\\\", \\\"{x:1469,y:828,t:1527632003581};\\\", \\\"{x:1468,y:828,t:1527632003596};\\\", \\\"{x:1467,y:829,t:1527632003604};\\\", \\\"{x:1466,y:829,t:1527632003621};\\\", \\\"{x:1465,y:829,t:1527632003635};\\\", \\\"{x:1462,y:830,t:1527632003652};\\\", \\\"{x:1461,y:831,t:1527632003668};\\\", \\\"{x:1460,y:832,t:1527632003684};\\\", \\\"{x:1459,y:832,t:1527632003708};\\\", \\\"{x:1458,y:832,t:1527632003797};\\\", \\\"{x:1456,y:832,t:1527632003941};\\\", \\\"{x:1455,y:832,t:1527632003988};\\\", \\\"{x:1454,y:833,t:1527632004013};\\\", \\\"{x:1453,y:833,t:1527632004037};\\\", \\\"{x:1451,y:833,t:1527632004060};\\\", \\\"{x:1448,y:833,t:1527632004069};\\\", \\\"{x:1445,y:833,t:1527632004085};\\\", \\\"{x:1441,y:833,t:1527632004102};\\\", \\\"{x:1435,y:833,t:1527632004119};\\\", \\\"{x:1427,y:832,t:1527632004136};\\\", \\\"{x:1420,y:830,t:1527632004152};\\\", \\\"{x:1408,y:829,t:1527632004169};\\\", \\\"{x:1392,y:827,t:1527632004185};\\\", \\\"{x:1380,y:823,t:1527632004203};\\\", \\\"{x:1375,y:823,t:1527632004218};\\\", \\\"{x:1369,y:821,t:1527632004235};\\\", \\\"{x:1367,y:820,t:1527632004252};\\\", \\\"{x:1364,y:819,t:1527632004269};\\\", \\\"{x:1362,y:817,t:1527632004285};\\\", \\\"{x:1360,y:816,t:1527632004302};\\\", \\\"{x:1360,y:815,t:1527632004319};\\\", \\\"{x:1358,y:814,t:1527632004335};\\\", \\\"{x:1356,y:812,t:1527632004352};\\\", \\\"{x:1354,y:810,t:1527632004370};\\\", \\\"{x:1353,y:807,t:1527632004385};\\\", \\\"{x:1352,y:805,t:1527632004402};\\\", \\\"{x:1350,y:804,t:1527632004419};\\\", \\\"{x:1350,y:802,t:1527632004435};\\\", \\\"{x:1350,y:801,t:1527632004452};\\\", \\\"{x:1350,y:800,t:1527632004469};\\\", \\\"{x:1350,y:796,t:1527632004486};\\\", \\\"{x:1350,y:794,t:1527632004502};\\\", \\\"{x:1351,y:793,t:1527632004519};\\\", \\\"{x:1353,y:790,t:1527632004536};\\\", \\\"{x:1354,y:790,t:1527632004552};\\\", \\\"{x:1356,y:788,t:1527632004569};\\\", \\\"{x:1358,y:787,t:1527632004586};\\\", \\\"{x:1361,y:786,t:1527632004601};\\\", \\\"{x:1364,y:785,t:1527632004618};\\\", \\\"{x:1366,y:784,t:1527632004636};\\\", \\\"{x:1367,y:783,t:1527632004651};\\\", \\\"{x:1372,y:781,t:1527632004669};\\\", \\\"{x:1374,y:780,t:1527632004686};\\\", \\\"{x:1375,y:780,t:1527632004702};\\\", \\\"{x:1376,y:780,t:1527632004719};\\\", \\\"{x:1377,y:779,t:1527632004736};\\\", \\\"{x:1374,y:777,t:1527632005101};\\\", \\\"{x:1371,y:777,t:1527632005109};\\\", \\\"{x:1369,y:777,t:1527632005119};\\\", \\\"{x:1355,y:776,t:1527632005136};\\\", \\\"{x:1338,y:772,t:1527632005153};\\\", \\\"{x:1317,y:771,t:1527632005168};\\\", \\\"{x:1292,y:769,t:1527632005186};\\\", \\\"{x:1266,y:769,t:1527632005202};\\\", \\\"{x:1233,y:769,t:1527632005219};\\\", \\\"{x:1188,y:769,t:1527632005236};\\\", \\\"{x:1088,y:769,t:1527632005252};\\\", \\\"{x:999,y:769,t:1527632005269};\\\", \\\"{x:902,y:769,t:1527632005286};\\\", \\\"{x:794,y:769,t:1527632005303};\\\", \\\"{x:683,y:769,t:1527632005320};\\\", \\\"{x:580,y:769,t:1527632005336};\\\", \\\"{x:500,y:769,t:1527632005353};\\\", \\\"{x:433,y:769,t:1527632005370};\\\", \\\"{x:385,y:769,t:1527632005386};\\\", \\\"{x:348,y:769,t:1527632005403};\\\", \\\"{x:321,y:769,t:1527632005420};\\\", \\\"{x:299,y:769,t:1527632005435};\\\", \\\"{x:272,y:769,t:1527632005453};\\\", \\\"{x:257,y:769,t:1527632005470};\\\", \\\"{x:244,y:769,t:1527632005486};\\\", \\\"{x:240,y:769,t:1527632005503};\\\", \\\"{x:237,y:769,t:1527632005520};\\\", \\\"{x:236,y:769,t:1527632005536};\\\", \\\"{x:236,y:767,t:1527632005628};\\\", \\\"{x:236,y:764,t:1527632005636};\\\", \\\"{x:242,y:750,t:1527632005653};\\\", \\\"{x:250,y:737,t:1527632005670};\\\", \\\"{x:264,y:722,t:1527632005686};\\\", \\\"{x:277,y:713,t:1527632005702};\\\", \\\"{x:290,y:705,t:1527632005720};\\\", \\\"{x:305,y:694,t:1527632005737};\\\", \\\"{x:319,y:684,t:1527632005753};\\\", \\\"{x:332,y:678,t:1527632005770};\\\", \\\"{x:342,y:674,t:1527632005786};\\\", \\\"{x:355,y:669,t:1527632005802};\\\", \\\"{x:368,y:665,t:1527632005820};\\\", \\\"{x:384,y:665,t:1527632005836};\\\", \\\"{x:393,y:665,t:1527632005853};\\\", \\\"{x:394,y:665,t:1527632005870};\\\", \\\"{x:397,y:663,t:1527632005886};\\\", \\\"{x:397,y:662,t:1527632005903};\\\", \\\"{x:398,y:653,t:1527632005919};\\\", \\\"{x:398,y:639,t:1527632005937};\\\", \\\"{x:398,y:624,t:1527632005953};\\\", \\\"{x:398,y:606,t:1527632005970};\\\", \\\"{x:398,y:587,t:1527632005986};\\\", \\\"{x:398,y:569,t:1527632006005};\\\", \\\"{x:398,y:554,t:1527632006020};\\\", \\\"{x:397,y:537,t:1527632006038};\\\", \\\"{x:396,y:530,t:1527632006055};\\\", \\\"{x:394,y:523,t:1527632006070};\\\", \\\"{x:394,y:513,t:1527632006087};\\\", \\\"{x:394,y:504,t:1527632006104};\\\", \\\"{x:394,y:498,t:1527632006120};\\\", \\\"{x:400,y:487,t:1527632006137};\\\", \\\"{x:410,y:479,t:1527632006154};\\\", \\\"{x:426,y:472,t:1527632006170};\\\", \\\"{x:449,y:468,t:1527632006187};\\\", \\\"{x:482,y:466,t:1527632006204};\\\", \\\"{x:537,y:466,t:1527632006220};\\\", \\\"{x:639,y:470,t:1527632006237};\\\", \\\"{x:716,y:479,t:1527632006254};\\\", \\\"{x:789,y:490,t:1527632006271};\\\", \\\"{x:850,y:505,t:1527632006287};\\\", \\\"{x:880,y:520,t:1527632006305};\\\", \\\"{x:896,y:528,t:1527632006321};\\\", \\\"{x:900,y:531,t:1527632006337};\\\", \\\"{x:901,y:533,t:1527632006356};\\\", \\\"{x:901,y:536,t:1527632006381};\\\", \\\"{x:901,y:540,t:1527632006389};\\\", \\\"{x:901,y:543,t:1527632006404};\\\", \\\"{x:901,y:549,t:1527632006422};\\\", \\\"{x:901,y:551,t:1527632006436};\\\", \\\"{x:901,y:552,t:1527632006454};\\\", \\\"{x:900,y:556,t:1527632006471};\\\", \\\"{x:891,y:560,t:1527632006487};\\\", \\\"{x:882,y:564,t:1527632006504};\\\", \\\"{x:873,y:565,t:1527632006521};\\\", \\\"{x:865,y:569,t:1527632006537};\\\", \\\"{x:858,y:572,t:1527632006554};\\\", \\\"{x:854,y:573,t:1527632006571};\\\", \\\"{x:852,y:574,t:1527632006588};\\\", \\\"{x:851,y:574,t:1527632006604};\\\", \\\"{x:848,y:574,t:1527632006620};\\\", \\\"{x:845,y:574,t:1527632006638};\\\", \\\"{x:842,y:574,t:1527632006654};\\\", \\\"{x:839,y:574,t:1527632006671};\\\", \\\"{x:837,y:573,t:1527632006688};\\\", \\\"{x:833,y:573,t:1527632006705};\\\", \\\"{x:826,y:573,t:1527632006721};\\\", \\\"{x:817,y:573,t:1527632006737};\\\", \\\"{x:808,y:573,t:1527632006755};\\\", \\\"{x:800,y:573,t:1527632006771};\\\", \\\"{x:789,y:573,t:1527632006788};\\\", \\\"{x:771,y:573,t:1527632006804};\\\", \\\"{x:759,y:571,t:1527632006821};\\\", \\\"{x:748,y:568,t:1527632006838};\\\", \\\"{x:736,y:566,t:1527632006855};\\\", \\\"{x:730,y:565,t:1527632006872};\\\", \\\"{x:725,y:565,t:1527632006888};\\\", \\\"{x:719,y:565,t:1527632006906};\\\", \\\"{x:709,y:565,t:1527632006922};\\\", \\\"{x:698,y:565,t:1527632006938};\\\", \\\"{x:685,y:565,t:1527632006954};\\\", \\\"{x:672,y:565,t:1527632006971};\\\", \\\"{x:657,y:565,t:1527632006988};\\\", \\\"{x:647,y:565,t:1527632007004};\\\", \\\"{x:638,y:565,t:1527632007021};\\\", \\\"{x:634,y:565,t:1527632007038};\\\", \\\"{x:628,y:565,t:1527632007054};\\\", \\\"{x:622,y:567,t:1527632007071};\\\", \\\"{x:614,y:571,t:1527632007088};\\\", \\\"{x:606,y:573,t:1527632007104};\\\", \\\"{x:597,y:578,t:1527632007121};\\\", \\\"{x:592,y:581,t:1527632007138};\\\", \\\"{x:589,y:583,t:1527632007156};\\\", \\\"{x:586,y:585,t:1527632007171};\\\", \\\"{x:585,y:586,t:1527632007189};\\\", \\\"{x:578,y:592,t:1527632007205};\\\", \\\"{x:575,y:595,t:1527632007221};\\\", \\\"{x:571,y:598,t:1527632007238};\\\", \\\"{x:569,y:600,t:1527632007255};\\\", \\\"{x:567,y:602,t:1527632007271};\\\", \\\"{x:566,y:602,t:1527632007288};\\\", \\\"{x:565,y:603,t:1527632007305};\\\", \\\"{x:565,y:604,t:1527632007325};\\\", \\\"{x:568,y:604,t:1527632007337};\\\", \\\"{x:579,y:600,t:1527632007355};\\\", \\\"{x:590,y:599,t:1527632007371};\\\", \\\"{x:600,y:595,t:1527632007388};\\\", \\\"{x:606,y:593,t:1527632007405};\\\", \\\"{x:612,y:592,t:1527632007421};\\\", \\\"{x:614,y:591,t:1527632007438};\\\", \\\"{x:620,y:590,t:1527632007456};\\\", \\\"{x:623,y:588,t:1527632007472};\\\", \\\"{x:626,y:587,t:1527632007488};\\\", \\\"{x:624,y:587,t:1527632008092};\\\", \\\"{x:623,y:587,t:1527632008106};\\\", \\\"{x:616,y:587,t:1527632008122};\\\", \\\"{x:610,y:589,t:1527632008140};\\\", \\\"{x:596,y:589,t:1527632008155};\\\", \\\"{x:580,y:589,t:1527632008172};\\\", \\\"{x:547,y:589,t:1527632008189};\\\", \\\"{x:521,y:589,t:1527632008205};\\\", \\\"{x:497,y:589,t:1527632008222};\\\", \\\"{x:473,y:589,t:1527632008240};\\\", \\\"{x:453,y:589,t:1527632008255};\\\", \\\"{x:436,y:589,t:1527632008273};\\\", \\\"{x:423,y:589,t:1527632008289};\\\", \\\"{x:418,y:589,t:1527632008305};\\\", \\\"{x:416,y:589,t:1527632008322};\\\", \\\"{x:414,y:589,t:1527632008477};\\\", \\\"{x:412,y:587,t:1527632008489};\\\", \\\"{x:408,y:581,t:1527632008507};\\\", \\\"{x:406,y:579,t:1527632008523};\\\", \\\"{x:405,y:578,t:1527632008539};\\\", \\\"{x:403,y:576,t:1527632008557};\\\", \\\"{x:402,y:576,t:1527632008572};\\\", \\\"{x:398,y:575,t:1527632008589};\\\", \\\"{x:395,y:573,t:1527632008607};\\\", \\\"{x:392,y:571,t:1527632008622};\\\", \\\"{x:389,y:569,t:1527632008640};\\\", \\\"{x:387,y:568,t:1527632008656};\\\", \\\"{x:385,y:567,t:1527632008672};\\\", \\\"{x:384,y:566,t:1527632008689};\\\", \\\"{x:383,y:565,t:1527632008706};\\\", \\\"{x:382,y:563,t:1527632008722};\\\", \\\"{x:381,y:562,t:1527632008739};\\\", \\\"{x:380,y:560,t:1527632008756};\\\", \\\"{x:380,y:559,t:1527632008772};\\\", \\\"{x:381,y:559,t:1527632009093};\\\", \\\"{x:383,y:559,t:1527632009106};\\\", \\\"{x:396,y:563,t:1527632009123};\\\", \\\"{x:408,y:572,t:1527632009140};\\\", \\\"{x:423,y:584,t:1527632009157};\\\", \\\"{x:444,y:605,t:1527632009172};\\\", \\\"{x:456,y:622,t:1527632009190};\\\", \\\"{x:468,y:637,t:1527632009207};\\\", \\\"{x:480,y:653,t:1527632009223};\\\", \\\"{x:493,y:670,t:1527632009240};\\\", \\\"{x:501,y:683,t:1527632009257};\\\", \\\"{x:509,y:693,t:1527632009274};\\\", \\\"{x:513,y:699,t:1527632009290};\\\", \\\"{x:516,y:704,t:1527632009306};\\\", \\\"{x:517,y:706,t:1527632009324};\\\", \\\"{x:518,y:706,t:1527632009340};\\\" ] }, { \\\"rt\\\": 51686, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 216904, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"8TUB0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-K -H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:707,t:1527632017573};\\\", \\\"{x:517,y:707,t:1527632017917};\\\", \\\"{x:516,y:708,t:1527632017956};\\\", \\\"{x:516,y:709,t:1527632017973};\\\", \\\"{x:515,y:709,t:1527632018013};\\\", \\\"{x:514,y:709,t:1527632018252};\\\", \\\"{x:513,y:710,t:1527632018340};\\\", \\\"{x:512,y:710,t:1527632018436};\\\", \\\"{x:511,y:710,t:1527632018517};\\\", \\\"{x:510,y:711,t:1527632018531};\\\", \\\"{x:508,y:712,t:1527632018677};\\\", \\\"{x:511,y:712,t:1527632036511};\\\", \\\"{x:518,y:712,t:1527632036519};\\\", \\\"{x:527,y:705,t:1527632036532};\\\", \\\"{x:549,y:689,t:1527632036547};\\\", \\\"{x:576,y:670,t:1527632036565};\\\", \\\"{x:615,y:645,t:1527632036582};\\\", \\\"{x:655,y:624,t:1527632036599};\\\", \\\"{x:693,y:602,t:1527632036614};\\\", \\\"{x:758,y:574,t:1527632036632};\\\", \\\"{x:784,y:562,t:1527632036647};\\\", \\\"{x:807,y:553,t:1527632036665};\\\", \\\"{x:825,y:548,t:1527632036683};\\\", \\\"{x:841,y:543,t:1527632036698};\\\", \\\"{x:864,y:537,t:1527632036716};\\\", \\\"{x:901,y:530,t:1527632036732};\\\", \\\"{x:940,y:526,t:1527632036749};\\\", \\\"{x:993,y:526,t:1527632036767};\\\", \\\"{x:1048,y:532,t:1527632036782};\\\", \\\"{x:1109,y:538,t:1527632036799};\\\", \\\"{x:1235,y:555,t:1527632036815};\\\", \\\"{x:1298,y:570,t:1527632036832};\\\", \\\"{x:1363,y:591,t:1527632036849};\\\", \\\"{x:1412,y:612,t:1527632036866};\\\", \\\"{x:1451,y:629,t:1527632036881};\\\", \\\"{x:1490,y:645,t:1527632036899};\\\", \\\"{x:1518,y:657,t:1527632036916};\\\", \\\"{x:1531,y:662,t:1527632036932};\\\", \\\"{x:1537,y:665,t:1527632036948};\\\", \\\"{x:1541,y:666,t:1527632036965};\\\", \\\"{x:1544,y:669,t:1527632036982};\\\", \\\"{x:1545,y:669,t:1527632036999};\\\", \\\"{x:1546,y:669,t:1527632037016};\\\", \\\"{x:1546,y:668,t:1527632037104};\\\", \\\"{x:1546,y:665,t:1527632037115};\\\", \\\"{x:1543,y:660,t:1527632037131};\\\", \\\"{x:1541,y:658,t:1527632037149};\\\", \\\"{x:1537,y:654,t:1527632037164};\\\", \\\"{x:1530,y:646,t:1527632037182};\\\", \\\"{x:1521,y:636,t:1527632037199};\\\", \\\"{x:1516,y:630,t:1527632037216};\\\", \\\"{x:1507,y:622,t:1527632037231};\\\", \\\"{x:1499,y:614,t:1527632037249};\\\", \\\"{x:1492,y:608,t:1527632037264};\\\", \\\"{x:1488,y:604,t:1527632037282};\\\", \\\"{x:1485,y:600,t:1527632037298};\\\", \\\"{x:1479,y:595,t:1527632037315};\\\", \\\"{x:1472,y:590,t:1527632037332};\\\", \\\"{x:1462,y:584,t:1527632037348};\\\", \\\"{x:1455,y:580,t:1527632037365};\\\", \\\"{x:1452,y:578,t:1527632037381};\\\", \\\"{x:1447,y:576,t:1527632037399};\\\", \\\"{x:1439,y:573,t:1527632037414};\\\", \\\"{x:1432,y:570,t:1527632037432};\\\", \\\"{x:1428,y:569,t:1527632037449};\\\", \\\"{x:1426,y:568,t:1527632037465};\\\", \\\"{x:1423,y:568,t:1527632037482};\\\", \\\"{x:1420,y:567,t:1527632037499};\\\", \\\"{x:1418,y:567,t:1527632037514};\\\", \\\"{x:1414,y:567,t:1527632037531};\\\", \\\"{x:1409,y:567,t:1527632037549};\\\", \\\"{x:1401,y:567,t:1527632037565};\\\", \\\"{x:1392,y:569,t:1527632037581};\\\", \\\"{x:1383,y:571,t:1527632037599};\\\", \\\"{x:1375,y:573,t:1527632037614};\\\", \\\"{x:1366,y:576,t:1527632037631};\\\", \\\"{x:1364,y:577,t:1527632037648};\\\", \\\"{x:1360,y:578,t:1527632037665};\\\", \\\"{x:1358,y:578,t:1527632037681};\\\", \\\"{x:1357,y:579,t:1527632037699};\\\", \\\"{x:1356,y:581,t:1527632037800};\\\", \\\"{x:1356,y:583,t:1527632037815};\\\", \\\"{x:1356,y:586,t:1527632037831};\\\", \\\"{x:1355,y:589,t:1527632037848};\\\", \\\"{x:1354,y:589,t:1527632037865};\\\", \\\"{x:1354,y:590,t:1527632037882};\\\", \\\"{x:1354,y:591,t:1527632037928};\\\", \\\"{x:1350,y:597,t:1527632045232};\\\", \\\"{x:1348,y:602,t:1527632045247};\\\", \\\"{x:1345,y:605,t:1527632045263};\\\", \\\"{x:1341,y:611,t:1527632045281};\\\", \\\"{x:1339,y:613,t:1527632045298};\\\", \\\"{x:1338,y:614,t:1527632045313};\\\", \\\"{x:1337,y:615,t:1527632045344};\\\", \\\"{x:1337,y:616,t:1527632045384};\\\", \\\"{x:1336,y:616,t:1527632045423};\\\", \\\"{x:1335,y:617,t:1527632045431};\\\", \\\"{x:1335,y:618,t:1527632045512};\\\", \\\"{x:1335,y:619,t:1527632045519};\\\", \\\"{x:1335,y:621,t:1527632045543};\\\", \\\"{x:1334,y:621,t:1527632045560};\\\", \\\"{x:1334,y:622,t:1527632045591};\\\", \\\"{x:1333,y:622,t:1527632045600};\\\", \\\"{x:1332,y:623,t:1527632045615};\\\", \\\"{x:1332,y:624,t:1527632045630};\\\", \\\"{x:1331,y:625,t:1527632045647};\\\", \\\"{x:1329,y:627,t:1527632045663};\\\", \\\"{x:1328,y:629,t:1527632045681};\\\", \\\"{x:1326,y:631,t:1527632045697};\\\", \\\"{x:1326,y:632,t:1527632045713};\\\", \\\"{x:1324,y:634,t:1527632045729};\\\", \\\"{x:1322,y:636,t:1527632045746};\\\", \\\"{x:1319,y:641,t:1527632045763};\\\", \\\"{x:1314,y:648,t:1527632045780};\\\", \\\"{x:1310,y:655,t:1527632045797};\\\", \\\"{x:1305,y:663,t:1527632045813};\\\", \\\"{x:1298,y:674,t:1527632045830};\\\", \\\"{x:1292,y:683,t:1527632045846};\\\", \\\"{x:1285,y:694,t:1527632045863};\\\", \\\"{x:1276,y:711,t:1527632045880};\\\", \\\"{x:1272,y:716,t:1527632045896};\\\", \\\"{x:1271,y:719,t:1527632045913};\\\", \\\"{x:1269,y:720,t:1527632045930};\\\", \\\"{x:1268,y:721,t:1527632049224};\\\", \\\"{x:1265,y:723,t:1527632049232};\\\", \\\"{x:1259,y:724,t:1527632049246};\\\", \\\"{x:1245,y:725,t:1527632049263};\\\", \\\"{x:1220,y:729,t:1527632049280};\\\", \\\"{x:1202,y:731,t:1527632049295};\\\", \\\"{x:1186,y:733,t:1527632049312};\\\", \\\"{x:1175,y:733,t:1527632049330};\\\", \\\"{x:1165,y:735,t:1527632049347};\\\", \\\"{x:1150,y:738,t:1527632049362};\\\", \\\"{x:1134,y:740,t:1527632049380};\\\", \\\"{x:1117,y:743,t:1527632049396};\\\", \\\"{x:1102,y:746,t:1527632049413};\\\", \\\"{x:1085,y:752,t:1527632049430};\\\", \\\"{x:1065,y:757,t:1527632049446};\\\", \\\"{x:1048,y:761,t:1527632049462};\\\", \\\"{x:1012,y:770,t:1527632049480};\\\", \\\"{x:992,y:774,t:1527632049495};\\\", \\\"{x:971,y:779,t:1527632049513};\\\", \\\"{x:954,y:785,t:1527632049529};\\\", \\\"{x:937,y:790,t:1527632049545};\\\", \\\"{x:915,y:795,t:1527632049562};\\\", \\\"{x:886,y:800,t:1527632049579};\\\", \\\"{x:856,y:807,t:1527632049595};\\\", \\\"{x:822,y:814,t:1527632049613};\\\", \\\"{x:788,y:819,t:1527632049630};\\\", \\\"{x:759,y:822,t:1527632049645};\\\", \\\"{x:736,y:825,t:1527632049662};\\\", \\\"{x:696,y:831,t:1527632049679};\\\", \\\"{x:669,y:835,t:1527632049695};\\\", \\\"{x:641,y:838,t:1527632049712};\\\", \\\"{x:618,y:840,t:1527632049730};\\\", \\\"{x:596,y:841,t:1527632049745};\\\", \\\"{x:576,y:842,t:1527632049762};\\\", \\\"{x:556,y:842,t:1527632049779};\\\", \\\"{x:542,y:845,t:1527632049795};\\\", \\\"{x:534,y:845,t:1527632049812};\\\", \\\"{x:527,y:845,t:1527632049830};\\\", \\\"{x:523,y:845,t:1527632049845};\\\", \\\"{x:519,y:845,t:1527632049862};\\\", \\\"{x:508,y:845,t:1527632049879};\\\", \\\"{x:501,y:845,t:1527632049895};\\\", \\\"{x:497,y:845,t:1527632049912};\\\", \\\"{x:494,y:845,t:1527632049929};\\\", \\\"{x:492,y:845,t:1527632049945};\\\", \\\"{x:491,y:845,t:1527632049962};\\\", \\\"{x:488,y:844,t:1527632060119};\\\", \\\"{x:486,y:842,t:1527632060127};\\\", \\\"{x:482,y:834,t:1527632060144};\\\", \\\"{x:474,y:825,t:1527632060160};\\\", \\\"{x:466,y:815,t:1527632060177};\\\", \\\"{x:458,y:807,t:1527632060194};\\\", \\\"{x:455,y:802,t:1527632060210};\\\", \\\"{x:451,y:798,t:1527632060227};\\\", \\\"{x:447,y:794,t:1527632060244};\\\", \\\"{x:441,y:789,t:1527632060260};\\\", \\\"{x:438,y:785,t:1527632060277};\\\", \\\"{x:434,y:780,t:1527632060294};\\\", \\\"{x:431,y:775,t:1527632060310};\\\", \\\"{x:426,y:768,t:1527632060327};\\\", \\\"{x:417,y:753,t:1527632060344};\\\", \\\"{x:411,y:743,t:1527632060360};\\\", \\\"{x:404,y:733,t:1527632060377};\\\", \\\"{x:396,y:722,t:1527632060393};\\\", \\\"{x:385,y:708,t:1527632060410};\\\", \\\"{x:373,y:692,t:1527632060426};\\\", \\\"{x:358,y:673,t:1527632060443};\\\", \\\"{x:344,y:647,t:1527632060460};\\\", \\\"{x:328,y:623,t:1527632060477};\\\", \\\"{x:311,y:596,t:1527632060494};\\\", \\\"{x:285,y:562,t:1527632060519};\\\", \\\"{x:264,y:541,t:1527632060535};\\\", \\\"{x:245,y:524,t:1527632060550};\\\", \\\"{x:221,y:503,t:1527632060568};\\\", \\\"{x:210,y:494,t:1527632060585};\\\", \\\"{x:205,y:491,t:1527632060602};\\\", \\\"{x:204,y:490,t:1527632060618};\\\", \\\"{x:203,y:489,t:1527632060679};\\\", \\\"{x:202,y:489,t:1527632060687};\\\", \\\"{x:200,y:492,t:1527632060702};\\\", \\\"{x:198,y:507,t:1527632060718};\\\", \\\"{x:201,y:526,t:1527632060735};\\\", \\\"{x:223,y:544,t:1527632060752};\\\", \\\"{x:246,y:550,t:1527632060767};\\\", \\\"{x:270,y:552,t:1527632060785};\\\", \\\"{x:291,y:552,t:1527632060800};\\\", \\\"{x:309,y:552,t:1527632060818};\\\", \\\"{x:327,y:549,t:1527632060835};\\\", \\\"{x:337,y:547,t:1527632060852};\\\", \\\"{x:342,y:544,t:1527632060868};\\\", \\\"{x:346,y:543,t:1527632060884};\\\", \\\"{x:353,y:540,t:1527632060902};\\\", \\\"{x:354,y:539,t:1527632060960};\\\", \\\"{x:355,y:536,t:1527632060984};\\\", \\\"{x:361,y:530,t:1527632060991};\\\", \\\"{x:368,y:522,t:1527632061002};\\\", \\\"{x:387,y:510,t:1527632061019};\\\", \\\"{x:402,y:502,t:1527632061035};\\\", \\\"{x:412,y:499,t:1527632061052};\\\", \\\"{x:416,y:496,t:1527632061068};\\\", \\\"{x:416,y:498,t:1527632061296};\\\", \\\"{x:416,y:500,t:1527632061303};\\\", \\\"{x:415,y:502,t:1527632061319};\\\", \\\"{x:413,y:507,t:1527632061335};\\\", \\\"{x:411,y:511,t:1527632061352};\\\", \\\"{x:410,y:511,t:1527632061369};\\\", \\\"{x:410,y:512,t:1527632061385};\\\", \\\"{x:408,y:512,t:1527632061402};\\\", \\\"{x:407,y:514,t:1527632061419};\\\", \\\"{x:402,y:517,t:1527632061436};\\\", \\\"{x:400,y:518,t:1527632061452};\\\", \\\"{x:398,y:519,t:1527632061469};\\\", \\\"{x:396,y:520,t:1527632061487};\\\", \\\"{x:395,y:521,t:1527632061502};\\\", \\\"{x:394,y:521,t:1527632061519};\\\", \\\"{x:393,y:522,t:1527632061536};\\\", \\\"{x:392,y:523,t:1527632061552};\\\", \\\"{x:391,y:524,t:1527632061568};\\\", \\\"{x:389,y:525,t:1527632061586};\\\", \\\"{x:385,y:528,t:1527632061602};\\\", \\\"{x:384,y:529,t:1527632061619};\\\", \\\"{x:382,y:530,t:1527632061636};\\\", \\\"{x:382,y:531,t:1527632061651};\\\", \\\"{x:381,y:533,t:1527632062007};\\\", \\\"{x:387,y:543,t:1527632062019};\\\", \\\"{x:406,y:558,t:1527632062037};\\\", \\\"{x:428,y:576,t:1527632062053};\\\", \\\"{x:455,y:599,t:1527632062069};\\\", \\\"{x:478,y:622,t:1527632062086};\\\", \\\"{x:499,y:647,t:1527632062104};\\\", \\\"{x:518,y:669,t:1527632062119};\\\", \\\"{x:534,y:693,t:1527632062136};\\\", \\\"{x:536,y:704,t:1527632062153};\\\", \\\"{x:542,y:717,t:1527632062170};\\\", \\\"{x:546,y:729,t:1527632062185};\\\", \\\"{x:550,y:735,t:1527632062202};\\\", \\\"{x:550,y:738,t:1527632062220};\\\", \\\"{x:550,y:739,t:1527632062335};\\\", \\\"{x:549,y:739,t:1527632062360};\\\", \\\"{x:548,y:739,t:1527632062383};\\\", \\\"{x:547,y:739,t:1527632062880};\\\" ] }, { \\\"rt\\\": 11383, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 229513, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"8TUB0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\", \\\"D\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:546,y:739,t:1527632064536};\\\", \\\"{x:545,y:740,t:1527632064576};\\\", \\\"{x:544,y:740,t:1527632064663};\\\", \\\"{x:542,y:741,t:1527632064887};\\\", \\\"{x:541,y:741,t:1527632065111};\\\", \\\"{x:540,y:742,t:1527632065151};\\\", \\\"{x:539,y:742,t:1527632065264};\\\", \\\"{x:538,y:742,t:1527632065279};\\\", \\\"{x:537,y:743,t:1527632067055};\\\", \\\"{x:536,y:744,t:1527632067231};\\\", \\\"{x:535,y:742,t:1527632069351};\\\", \\\"{x:532,y:729,t:1527632069359};\\\", \\\"{x:516,y:695,t:1527632069376};\\\", \\\"{x:498,y:663,t:1527632069392};\\\", \\\"{x:487,y:643,t:1527632069408};\\\", \\\"{x:476,y:625,t:1527632069426};\\\", \\\"{x:466,y:610,t:1527632069442};\\\", \\\"{x:457,y:599,t:1527632069459};\\\", \\\"{x:452,y:590,t:1527632069476};\\\", \\\"{x:449,y:586,t:1527632069492};\\\", \\\"{x:447,y:584,t:1527632069509};\\\", \\\"{x:447,y:583,t:1527632069525};\\\", \\\"{x:446,y:582,t:1527632069542};\\\", \\\"{x:445,y:581,t:1527632069559};\\\", \\\"{x:442,y:581,t:1527632069575};\\\", \\\"{x:440,y:581,t:1527632069592};\\\", \\\"{x:439,y:580,t:1527632069609};\\\", \\\"{x:436,y:580,t:1527632069626};\\\", \\\"{x:433,y:580,t:1527632069642};\\\", \\\"{x:430,y:580,t:1527632069659};\\\", \\\"{x:429,y:580,t:1527632069676};\\\", \\\"{x:426,y:580,t:1527632069692};\\\", \\\"{x:422,y:580,t:1527632069709};\\\", \\\"{x:420,y:580,t:1527632069726};\\\", \\\"{x:417,y:580,t:1527632069744};\\\", \\\"{x:416,y:580,t:1527632069759};\\\", \\\"{x:414,y:580,t:1527632069776};\\\", \\\"{x:411,y:580,t:1527632069792};\\\", \\\"{x:409,y:580,t:1527632069808};\\\", \\\"{x:408,y:580,t:1527632069825};\\\", \\\"{x:407,y:580,t:1527632069843};\\\", \\\"{x:405,y:582,t:1527632069863};\\\", \\\"{x:404,y:582,t:1527632069887};\\\", \\\"{x:403,y:582,t:1527632069895};\\\", \\\"{x:402,y:582,t:1527632069911};\\\", \\\"{x:401,y:582,t:1527632069935};\\\", \\\"{x:400,y:583,t:1527632069943};\\\", \\\"{x:399,y:583,t:1527632069959};\\\", \\\"{x:398,y:584,t:1527632069975};\\\", \\\"{x:397,y:584,t:1527632069999};\\\", \\\"{x:396,y:585,t:1527632070008};\\\", \\\"{x:395,y:585,t:1527632070025};\\\", \\\"{x:394,y:585,t:1527632070042};\\\", \\\"{x:393,y:586,t:1527632070058};\\\", \\\"{x:390,y:587,t:1527632070075};\\\", \\\"{x:388,y:588,t:1527632070093};\\\", \\\"{x:384,y:588,t:1527632070108};\\\", \\\"{x:377,y:589,t:1527632070125};\\\", \\\"{x:370,y:589,t:1527632070142};\\\", \\\"{x:362,y:589,t:1527632070158};\\\", \\\"{x:342,y:589,t:1527632070176};\\\", \\\"{x:327,y:589,t:1527632070193};\\\", \\\"{x:316,y:587,t:1527632070209};\\\", \\\"{x:307,y:583,t:1527632070226};\\\", \\\"{x:299,y:582,t:1527632070242};\\\", \\\"{x:296,y:579,t:1527632070259};\\\", \\\"{x:296,y:578,t:1527632070277};\\\", \\\"{x:295,y:576,t:1527632070292};\\\", \\\"{x:294,y:574,t:1527632070309};\\\", \\\"{x:294,y:573,t:1527632070326};\\\", \\\"{x:294,y:570,t:1527632070342};\\\", \\\"{x:294,y:566,t:1527632070359};\\\", \\\"{x:293,y:565,t:1527632070376};\\\", \\\"{x:292,y:563,t:1527632070392};\\\", \\\"{x:292,y:559,t:1527632070410};\\\", \\\"{x:292,y:554,t:1527632070427};\\\", \\\"{x:293,y:550,t:1527632070442};\\\", \\\"{x:298,y:546,t:1527632070459};\\\", \\\"{x:311,y:541,t:1527632070477};\\\", \\\"{x:331,y:535,t:1527632070492};\\\", \\\"{x:361,y:527,t:1527632070509};\\\", \\\"{x:390,y:520,t:1527632070526};\\\", \\\"{x:419,y:512,t:1527632070543};\\\", \\\"{x:461,y:511,t:1527632070559};\\\", \\\"{x:488,y:511,t:1527632070576};\\\", \\\"{x:502,y:516,t:1527632070593};\\\", \\\"{x:508,y:517,t:1527632070609};\\\", \\\"{x:509,y:518,t:1527632070687};\\\", \\\"{x:507,y:520,t:1527632070695};\\\", \\\"{x:501,y:521,t:1527632070710};\\\", \\\"{x:484,y:525,t:1527632070727};\\\", \\\"{x:460,y:532,t:1527632070743};\\\", \\\"{x:438,y:537,t:1527632070759};\\\", \\\"{x:418,y:540,t:1527632070777};\\\", \\\"{x:395,y:546,t:1527632070793};\\\", \\\"{x:373,y:549,t:1527632070809};\\\", \\\"{x:357,y:553,t:1527632070827};\\\", \\\"{x:350,y:556,t:1527632070844};\\\", \\\"{x:349,y:556,t:1527632070864};\\\", \\\"{x:346,y:559,t:1527632070951};\\\", \\\"{x:345,y:567,t:1527632070961};\\\", \\\"{x:345,y:589,t:1527632070977};\\\", \\\"{x:346,y:609,t:1527632070993};\\\", \\\"{x:353,y:625,t:1527632071010};\\\", \\\"{x:362,y:639,t:1527632071027};\\\", \\\"{x:374,y:651,t:1527632071044};\\\", \\\"{x:382,y:656,t:1527632071059};\\\", \\\"{x:391,y:661,t:1527632071076};\\\", \\\"{x:401,y:665,t:1527632071093};\\\", \\\"{x:405,y:667,t:1527632071110};\\\", \\\"{x:409,y:669,t:1527632071126};\\\", \\\"{x:408,y:669,t:1527632071345};\\\", \\\"{x:408,y:665,t:1527632071775};\\\", \\\"{x:409,y:653,t:1527632071783};\\\", \\\"{x:412,y:646,t:1527632071795};\\\", \\\"{x:423,y:628,t:1527632071811};\\\", \\\"{x:438,y:617,t:1527632071827};\\\", \\\"{x:453,y:606,t:1527632071843};\\\", \\\"{x:471,y:598,t:1527632071861};\\\", \\\"{x:487,y:592,t:1527632071877};\\\", \\\"{x:500,y:587,t:1527632071894};\\\", \\\"{x:517,y:583,t:1527632071911};\\\", \\\"{x:547,y:579,t:1527632071927};\\\", \\\"{x:562,y:579,t:1527632071944};\\\", \\\"{x:572,y:579,t:1527632071960};\\\", \\\"{x:577,y:579,t:1527632071977};\\\", \\\"{x:584,y:579,t:1527632071995};\\\", \\\"{x:589,y:579,t:1527632072010};\\\", \\\"{x:591,y:579,t:1527632072028};\\\", \\\"{x:588,y:581,t:1527632072072};\\\", \\\"{x:583,y:585,t:1527632072080};\\\", \\\"{x:577,y:588,t:1527632072095};\\\", \\\"{x:559,y:595,t:1527632072112};\\\", \\\"{x:543,y:604,t:1527632072129};\\\", \\\"{x:525,y:611,t:1527632072145};\\\", \\\"{x:506,y:618,t:1527632072160};\\\", \\\"{x:486,y:627,t:1527632072178};\\\", \\\"{x:472,y:632,t:1527632072195};\\\", \\\"{x:452,y:640,t:1527632072210};\\\", \\\"{x:437,y:644,t:1527632072228};\\\", \\\"{x:424,y:649,t:1527632072245};\\\", \\\"{x:417,y:650,t:1527632072260};\\\", \\\"{x:410,y:652,t:1527632072277};\\\", \\\"{x:405,y:653,t:1527632072294};\\\", \\\"{x:402,y:655,t:1527632072311};\\\", \\\"{x:401,y:655,t:1527632072328};\\\", \\\"{x:399,y:655,t:1527632072383};\\\", \\\"{x:398,y:656,t:1527632072394};\\\", \\\"{x:395,y:657,t:1527632072411};\\\", \\\"{x:393,y:657,t:1527632072791};\\\", \\\"{x:391,y:657,t:1527632072799};\\\", \\\"{x:393,y:657,t:1527632072811};\\\", \\\"{x:408,y:652,t:1527632072829};\\\", \\\"{x:420,y:647,t:1527632072844};\\\", \\\"{x:431,y:642,t:1527632072862};\\\", \\\"{x:450,y:634,t:1527632072879};\\\", \\\"{x:469,y:626,t:1527632072894};\\\", \\\"{x:509,y:609,t:1527632072912};\\\", \\\"{x:540,y:597,t:1527632072929};\\\", \\\"{x:559,y:588,t:1527632072945};\\\", \\\"{x:572,y:582,t:1527632072961};\\\", \\\"{x:584,y:577,t:1527632072978};\\\", \\\"{x:596,y:572,t:1527632072994};\\\", \\\"{x:605,y:567,t:1527632073012};\\\", \\\"{x:609,y:566,t:1527632073028};\\\", \\\"{x:612,y:563,t:1527632073045};\\\", \\\"{x:615,y:560,t:1527632073062};\\\", \\\"{x:616,y:559,t:1527632073079};\\\", \\\"{x:618,y:557,t:1527632073095};\\\", \\\"{x:622,y:554,t:1527632073112};\\\", \\\"{x:624,y:553,t:1527632073129};\\\", \\\"{x:628,y:550,t:1527632073145};\\\", \\\"{x:629,y:548,t:1527632073161};\\\", \\\"{x:630,y:548,t:1527632073178};\\\", \\\"{x:631,y:547,t:1527632073194};\\\", \\\"{x:633,y:545,t:1527632073211};\\\", \\\"{x:635,y:543,t:1527632073229};\\\", \\\"{x:637,y:539,t:1527632073244};\\\", \\\"{x:638,y:538,t:1527632073262};\\\", \\\"{x:639,y:536,t:1527632073278};\\\", \\\"{x:641,y:534,t:1527632073295};\\\", \\\"{x:644,y:532,t:1527632073311};\\\", \\\"{x:647,y:530,t:1527632073328};\\\", \\\"{x:651,y:529,t:1527632073344};\\\", \\\"{x:658,y:529,t:1527632073362};\\\", \\\"{x:667,y:527,t:1527632073378};\\\", \\\"{x:675,y:527,t:1527632073396};\\\", \\\"{x:685,y:528,t:1527632073411};\\\", \\\"{x:700,y:534,t:1527632073428};\\\", \\\"{x:718,y:540,t:1527632073445};\\\", \\\"{x:747,y:548,t:1527632073463};\\\", \\\"{x:770,y:552,t:1527632073478};\\\", \\\"{x:806,y:557,t:1527632073496};\\\", \\\"{x:824,y:560,t:1527632073511};\\\", \\\"{x:843,y:560,t:1527632073529};\\\", \\\"{x:861,y:560,t:1527632073546};\\\", \\\"{x:880,y:555,t:1527632073562};\\\", \\\"{x:886,y:553,t:1527632073578};\\\", \\\"{x:888,y:553,t:1527632073595};\\\", \\\"{x:889,y:552,t:1527632073679};\\\", \\\"{x:889,y:551,t:1527632073703};\\\", \\\"{x:889,y:550,t:1527632073736};\\\", \\\"{x:889,y:549,t:1527632073745};\\\", \\\"{x:889,y:548,t:1527632073762};\\\", \\\"{x:884,y:548,t:1527632073778};\\\", \\\"{x:878,y:547,t:1527632073795};\\\", \\\"{x:875,y:546,t:1527632073813};\\\", \\\"{x:871,y:546,t:1527632073828};\\\", \\\"{x:869,y:545,t:1527632073846};\\\", \\\"{x:866,y:544,t:1527632073862};\\\", \\\"{x:861,y:544,t:1527632073879};\\\", \\\"{x:852,y:544,t:1527632073895};\\\", \\\"{x:845,y:544,t:1527632073911};\\\", \\\"{x:841,y:543,t:1527632073928};\\\", \\\"{x:837,y:543,t:1527632073945};\\\", \\\"{x:832,y:543,t:1527632074256};\\\", \\\"{x:825,y:544,t:1527632074263};\\\", \\\"{x:806,y:552,t:1527632074279};\\\", \\\"{x:787,y:561,t:1527632074296};\\\", \\\"{x:761,y:571,t:1527632074313};\\\", \\\"{x:733,y:589,t:1527632074329};\\\", \\\"{x:696,y:613,t:1527632074345};\\\", \\\"{x:664,y:636,t:1527632074363};\\\", \\\"{x:628,y:661,t:1527632074379};\\\", \\\"{x:590,y:690,t:1527632074395};\\\", \\\"{x:562,y:715,t:1527632074413};\\\", \\\"{x:544,y:728,t:1527632074429};\\\", \\\"{x:529,y:739,t:1527632074446};\\\", \\\"{x:524,y:745,t:1527632074463};\\\", \\\"{x:521,y:749,t:1527632074479};\\\", \\\"{x:521,y:751,t:1527632074520};\\\", \\\"{x:520,y:752,t:1527632074560};\\\", \\\"{x:519,y:750,t:1527632074927};\\\", \\\"{x:519,y:748,t:1527632074935};\\\", \\\"{x:519,y:747,t:1527632074947};\\\", \\\"{x:518,y:745,t:1527632074962};\\\", \\\"{x:516,y:745,t:1527632075087};\\\", \\\"{x:515,y:745,t:1527632075104};\\\", \\\"{x:515,y:745,t:1527632075161};\\\" ] }, { \\\"rt\\\": 16887, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 247635, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"8TUB0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:514,y:743,t:1527632086314};\\\", \\\"{x:514,y:729,t:1527632086330};\\\", \\\"{x:514,y:722,t:1527632086346};\\\", \\\"{x:514,y:717,t:1527632086364};\\\", \\\"{x:514,y:714,t:1527632086380};\\\", \\\"{x:512,y:711,t:1527632086397};\\\", \\\"{x:512,y:710,t:1527632086409};\\\", \\\"{x:512,y:709,t:1527632086425};\\\", \\\"{x:512,y:708,t:1527632086442};\\\", \\\"{x:512,y:707,t:1527632086466};\\\", \\\"{x:512,y:701,t:1527632087866};\\\", \\\"{x:512,y:693,t:1527632087877};\\\", \\\"{x:513,y:676,t:1527632087893};\\\", \\\"{x:514,y:661,t:1527632087910};\\\", \\\"{x:517,y:646,t:1527632087927};\\\", \\\"{x:518,y:636,t:1527632087943};\\\", \\\"{x:518,y:628,t:1527632087961};\\\", \\\"{x:519,y:619,t:1527632087977};\\\", \\\"{x:520,y:613,t:1527632087993};\\\", \\\"{x:521,y:604,t:1527632088010};\\\", \\\"{x:523,y:595,t:1527632088027};\\\", \\\"{x:527,y:582,t:1527632088043};\\\", \\\"{x:533,y:563,t:1527632088060};\\\", \\\"{x:537,y:543,t:1527632088078};\\\", \\\"{x:539,y:526,t:1527632088093};\\\", \\\"{x:542,y:513,t:1527632088110};\\\", \\\"{x:543,y:503,t:1527632088126};\\\", \\\"{x:544,y:495,t:1527632088143};\\\", \\\"{x:544,y:490,t:1527632088160};\\\", \\\"{x:544,y:483,t:1527632088178};\\\", \\\"{x:537,y:476,t:1527632088193};\\\", \\\"{x:511,y:466,t:1527632088210};\\\", \\\"{x:481,y:461,t:1527632088227};\\\", \\\"{x:442,y:458,t:1527632088243};\\\", \\\"{x:404,y:456,t:1527632088260};\\\", \\\"{x:365,y:459,t:1527632088277};\\\", \\\"{x:331,y:464,t:1527632088293};\\\", \\\"{x:301,y:468,t:1527632088310};\\\", \\\"{x:277,y:475,t:1527632088327};\\\", \\\"{x:257,y:485,t:1527632088343};\\\", \\\"{x:246,y:491,t:1527632088360};\\\", \\\"{x:240,y:495,t:1527632088377};\\\", \\\"{x:237,y:498,t:1527632088393};\\\", \\\"{x:232,y:506,t:1527632088410};\\\", \\\"{x:228,y:513,t:1527632088427};\\\", \\\"{x:221,y:524,t:1527632088444};\\\", \\\"{x:214,y:535,t:1527632088461};\\\", \\\"{x:210,y:541,t:1527632088477};\\\", \\\"{x:206,y:547,t:1527632088493};\\\", \\\"{x:205,y:549,t:1527632088510};\\\", \\\"{x:203,y:552,t:1527632088527};\\\", \\\"{x:201,y:555,t:1527632088544};\\\", \\\"{x:198,y:558,t:1527632088560};\\\", \\\"{x:197,y:560,t:1527632088577};\\\", \\\"{x:194,y:563,t:1527632088594};\\\", \\\"{x:189,y:565,t:1527632088610};\\\", \\\"{x:188,y:566,t:1527632088627};\\\", \\\"{x:186,y:567,t:1527632088644};\\\", \\\"{x:184,y:567,t:1527632088674};\\\", \\\"{x:183,y:567,t:1527632088682};\\\", \\\"{x:182,y:567,t:1527632088694};\\\", \\\"{x:181,y:568,t:1527632088710};\\\", \\\"{x:179,y:568,t:1527632088727};\\\", \\\"{x:175,y:570,t:1527632088744};\\\", \\\"{x:172,y:570,t:1527632088761};\\\", \\\"{x:170,y:570,t:1527632088778};\\\", \\\"{x:169,y:571,t:1527632088794};\\\", \\\"{x:168,y:572,t:1527632088811};\\\", \\\"{x:166,y:574,t:1527632088930};\\\", \\\"{x:165,y:576,t:1527632088944};\\\", \\\"{x:163,y:579,t:1527632088961};\\\", \\\"{x:161,y:586,t:1527632088978};\\\", \\\"{x:161,y:591,t:1527632088994};\\\", \\\"{x:158,y:598,t:1527632089012};\\\", \\\"{x:158,y:602,t:1527632089028};\\\", \\\"{x:157,y:607,t:1527632089045};\\\", \\\"{x:157,y:609,t:1527632089061};\\\", \\\"{x:157,y:612,t:1527632089077};\\\", \\\"{x:157,y:613,t:1527632089094};\\\", \\\"{x:157,y:615,t:1527632089111};\\\", \\\"{x:157,y:616,t:1527632089127};\\\", \\\"{x:157,y:618,t:1527632089144};\\\", \\\"{x:157,y:619,t:1527632089161};\\\", \\\"{x:157,y:620,t:1527632089177};\\\", \\\"{x:157,y:618,t:1527632089290};\\\", \\\"{x:157,y:612,t:1527632089297};\\\", \\\"{x:157,y:604,t:1527632089311};\\\", \\\"{x:157,y:593,t:1527632089328};\\\", \\\"{x:157,y:582,t:1527632089344};\\\", \\\"{x:157,y:571,t:1527632089360};\\\", \\\"{x:157,y:561,t:1527632089377};\\\", \\\"{x:157,y:553,t:1527632089394};\\\", \\\"{x:158,y:549,t:1527632089412};\\\", \\\"{x:159,y:546,t:1527632089429};\\\", \\\"{x:159,y:544,t:1527632089444};\\\", \\\"{x:159,y:543,t:1527632089930};\\\", \\\"{x:164,y:540,t:1527632089945};\\\", \\\"{x:181,y:534,t:1527632089962};\\\", \\\"{x:203,y:523,t:1527632089978};\\\", \\\"{x:223,y:518,t:1527632089995};\\\", \\\"{x:243,y:513,t:1527632090012};\\\", \\\"{x:263,y:511,t:1527632090028};\\\", \\\"{x:287,y:510,t:1527632090045};\\\", \\\"{x:320,y:510,t:1527632090061};\\\", \\\"{x:365,y:510,t:1527632090078};\\\", \\\"{x:404,y:510,t:1527632090095};\\\", \\\"{x:434,y:510,t:1527632090111};\\\", \\\"{x:474,y:516,t:1527632090128};\\\", \\\"{x:519,y:522,t:1527632090145};\\\", \\\"{x:551,y:528,t:1527632090161};\\\", \\\"{x:587,y:538,t:1527632090179};\\\", \\\"{x:609,y:545,t:1527632090195};\\\", \\\"{x:624,y:549,t:1527632090212};\\\", \\\"{x:637,y:552,t:1527632090228};\\\", \\\"{x:650,y:556,t:1527632090245};\\\", \\\"{x:663,y:559,t:1527632090261};\\\", \\\"{x:673,y:559,t:1527632090278};\\\", \\\"{x:679,y:559,t:1527632090296};\\\", \\\"{x:683,y:559,t:1527632090312};\\\", \\\"{x:686,y:559,t:1527632090328};\\\", \\\"{x:691,y:558,t:1527632090345};\\\", \\\"{x:693,y:558,t:1527632090362};\\\", \\\"{x:695,y:556,t:1527632090378};\\\", \\\"{x:696,y:555,t:1527632090395};\\\", \\\"{x:696,y:553,t:1527632090412};\\\", \\\"{x:696,y:549,t:1527632090428};\\\", \\\"{x:695,y:542,t:1527632090445};\\\", \\\"{x:683,y:530,t:1527632090462};\\\", \\\"{x:677,y:525,t:1527632090478};\\\", \\\"{x:671,y:520,t:1527632090496};\\\", \\\"{x:668,y:517,t:1527632090513};\\\", \\\"{x:668,y:516,t:1527632090538};\\\", \\\"{x:668,y:515,t:1527632090562};\\\", \\\"{x:668,y:513,t:1527632090578};\\\", \\\"{x:674,y:509,t:1527632090595};\\\", \\\"{x:686,y:505,t:1527632090613};\\\", \\\"{x:698,y:502,t:1527632090629};\\\", \\\"{x:712,y:500,t:1527632090645};\\\", \\\"{x:731,y:499,t:1527632090663};\\\", \\\"{x:744,y:497,t:1527632090679};\\\", \\\"{x:758,y:497,t:1527632090695};\\\", \\\"{x:777,y:497,t:1527632090712};\\\", \\\"{x:788,y:497,t:1527632090729};\\\", \\\"{x:795,y:497,t:1527632090745};\\\", \\\"{x:798,y:497,t:1527632090762};\\\", \\\"{x:799,y:497,t:1527632090779};\\\", \\\"{x:802,y:497,t:1527632090818};\\\", \\\"{x:803,y:497,t:1527632090829};\\\", \\\"{x:806,y:497,t:1527632090845};\\\", \\\"{x:813,y:497,t:1527632090862};\\\", \\\"{x:817,y:495,t:1527632090879};\\\", \\\"{x:818,y:495,t:1527632090946};\\\", \\\"{x:817,y:497,t:1527632091251};\\\", \\\"{x:815,y:500,t:1527632091262};\\\", \\\"{x:808,y:510,t:1527632091279};\\\", \\\"{x:799,y:528,t:1527632091296};\\\", \\\"{x:783,y:559,t:1527632091313};\\\", \\\"{x:766,y:596,t:1527632091329};\\\", \\\"{x:741,y:650,t:1527632091346};\\\", \\\"{x:729,y:678,t:1527632091362};\\\", \\\"{x:707,y:713,t:1527632091380};\\\", \\\"{x:691,y:747,t:1527632091396};\\\", \\\"{x:677,y:768,t:1527632091412};\\\", \\\"{x:666,y:789,t:1527632091429};\\\", \\\"{x:658,y:800,t:1527632091446};\\\", \\\"{x:653,y:805,t:1527632091463};\\\", \\\"{x:652,y:805,t:1527632091480};\\\", \\\"{x:653,y:806,t:1527632091506};\\\", \\\"{x:663,y:801,t:1527632091514};\\\", \\\"{x:681,y:795,t:1527632091529};\\\", \\\"{x:754,y:752,t:1527632091546};\\\", \\\"{x:817,y:716,t:1527632091563};\\\", \\\"{x:877,y:681,t:1527632091580};\\\", \\\"{x:913,y:658,t:1527632091596};\\\", \\\"{x:936,y:639,t:1527632091613};\\\", \\\"{x:949,y:628,t:1527632091630};\\\", \\\"{x:954,y:621,t:1527632091647};\\\", \\\"{x:958,y:609,t:1527632091663};\\\", \\\"{x:958,y:598,t:1527632091679};\\\", \\\"{x:957,y:584,t:1527632091697};\\\", \\\"{x:952,y:565,t:1527632091713};\\\", \\\"{x:946,y:540,t:1527632091730};\\\", \\\"{x:939,y:524,t:1527632091747};\\\", \\\"{x:935,y:511,t:1527632091764};\\\", \\\"{x:927,y:498,t:1527632091780};\\\", \\\"{x:917,y:487,t:1527632091796};\\\", \\\"{x:905,y:481,t:1527632091813};\\\", \\\"{x:890,y:478,t:1527632091829};\\\", \\\"{x:880,y:476,t:1527632091846};\\\", \\\"{x:871,y:474,t:1527632091863};\\\", \\\"{x:860,y:473,t:1527632091879};\\\", \\\"{x:850,y:473,t:1527632091896};\\\", \\\"{x:842,y:473,t:1527632091913};\\\", \\\"{x:833,y:474,t:1527632091930};\\\", \\\"{x:826,y:476,t:1527632091946};\\\", \\\"{x:823,y:477,t:1527632091963};\\\", \\\"{x:822,y:478,t:1527632091980};\\\", \\\"{x:821,y:478,t:1527632092002};\\\", \\\"{x:820,y:479,t:1527632092013};\\\", \\\"{x:819,y:482,t:1527632092030};\\\", \\\"{x:817,y:484,t:1527632092046};\\\", \\\"{x:817,y:488,t:1527632092063};\\\", \\\"{x:817,y:492,t:1527632092080};\\\", \\\"{x:819,y:499,t:1527632092096};\\\", \\\"{x:821,y:503,t:1527632092113};\\\", \\\"{x:825,y:507,t:1527632092130};\\\", \\\"{x:829,y:508,t:1527632092146};\\\", \\\"{x:832,y:510,t:1527632092163};\\\", \\\"{x:833,y:510,t:1527632092181};\\\", \\\"{x:834,y:510,t:1527632092330};\\\", \\\"{x:834,y:510,t:1527632092430};\\\", \\\"{x:833,y:512,t:1527632092547};\\\", \\\"{x:817,y:529,t:1527632092564};\\\", \\\"{x:796,y:555,t:1527632092580};\\\", \\\"{x:764,y:597,t:1527632092598};\\\", \\\"{x:728,y:643,t:1527632092613};\\\", \\\"{x:695,y:684,t:1527632092630};\\\", \\\"{x:660,y:735,t:1527632092648};\\\", \\\"{x:625,y:783,t:1527632092663};\\\", \\\"{x:593,y:825,t:1527632092680};\\\", \\\"{x:568,y:856,t:1527632092697};\\\", \\\"{x:552,y:871,t:1527632092713};\\\", \\\"{x:542,y:880,t:1527632092730};\\\", \\\"{x:541,y:880,t:1527632092747};\\\", \\\"{x:541,y:878,t:1527632092826};\\\", \\\"{x:541,y:869,t:1527632092834};\\\", \\\"{x:541,y:861,t:1527632092847};\\\", \\\"{x:541,y:844,t:1527632092864};\\\", \\\"{x:541,y:824,t:1527632092881};\\\", \\\"{x:541,y:800,t:1527632092898};\\\", \\\"{x:539,y:772,t:1527632092914};\\\", \\\"{x:537,y:765,t:1527632092930};\\\", \\\"{x:535,y:761,t:1527632092947};\\\", \\\"{x:533,y:753,t:1527632092964};\\\", \\\"{x:529,y:744,t:1527632092980};\\\", \\\"{x:526,y:736,t:1527632092997};\\\", \\\"{x:526,y:734,t:1527632093013};\\\", \\\"{x:526,y:733,t:1527632093050};\\\" ] }, { \\\"rt\\\": 18870, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 267749, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"8TUB0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:526,y:727,t:1527632110210};\\\", \\\"{x:526,y:722,t:1527632110218};\\\", \\\"{x:526,y:717,t:1527632110227};\\\", \\\"{x:526,y:711,t:1527632110244};\\\", \\\"{x:526,y:708,t:1527632110261};\\\", \\\"{x:526,y:705,t:1527632110273};\\\", \\\"{x:526,y:700,t:1527632110289};\\\", \\\"{x:526,y:696,t:1527632110306};\\\", \\\"{x:526,y:692,t:1527632110323};\\\", \\\"{x:526,y:686,t:1527632110340};\\\", \\\"{x:527,y:680,t:1527632110356};\\\", \\\"{x:527,y:674,t:1527632110373};\\\", \\\"{x:527,y:667,t:1527632110390};\\\", \\\"{x:527,y:662,t:1527632110406};\\\", \\\"{x:527,y:655,t:1527632110423};\\\", \\\"{x:527,y:650,t:1527632110440};\\\", \\\"{x:527,y:647,t:1527632110457};\\\", \\\"{x:527,y:642,t:1527632110473};\\\", \\\"{x:527,y:638,t:1527632110490};\\\", \\\"{x:527,y:636,t:1527632110507};\\\", \\\"{x:527,y:632,t:1527632110523};\\\", \\\"{x:527,y:630,t:1527632110541};\\\", \\\"{x:526,y:626,t:1527632110557};\\\", \\\"{x:525,y:620,t:1527632110578};\\\", \\\"{x:525,y:616,t:1527632110595};\\\", \\\"{x:523,y:611,t:1527632110611};\\\", \\\"{x:522,y:607,t:1527632110628};\\\", \\\"{x:520,y:601,t:1527632110645};\\\", \\\"{x:520,y:599,t:1527632110661};\\\", \\\"{x:518,y:596,t:1527632110679};\\\", \\\"{x:518,y:593,t:1527632110696};\\\", \\\"{x:516,y:589,t:1527632110711};\\\", \\\"{x:514,y:585,t:1527632110728};\\\", \\\"{x:512,y:581,t:1527632110745};\\\", \\\"{x:510,y:576,t:1527632110762};\\\", \\\"{x:508,y:573,t:1527632110778};\\\", \\\"{x:507,y:571,t:1527632110795};\\\", \\\"{x:505,y:569,t:1527632110812};\\\", \\\"{x:504,y:567,t:1527632110828};\\\", \\\"{x:502,y:566,t:1527632110845};\\\", \\\"{x:500,y:564,t:1527632110862};\\\", \\\"{x:496,y:564,t:1527632110879};\\\", \\\"{x:490,y:562,t:1527632110896};\\\", \\\"{x:483,y:562,t:1527632110912};\\\", \\\"{x:473,y:562,t:1527632110928};\\\", \\\"{x:460,y:564,t:1527632110946};\\\", \\\"{x:441,y:571,t:1527632110962};\\\", \\\"{x:430,y:573,t:1527632110978};\\\", \\\"{x:420,y:577,t:1527632110995};\\\", \\\"{x:414,y:578,t:1527632111012};\\\", \\\"{x:408,y:580,t:1527632111029};\\\", \\\"{x:404,y:581,t:1527632111045};\\\", \\\"{x:403,y:581,t:1527632111062};\\\", \\\"{x:402,y:582,t:1527632111078};\\\", \\\"{x:401,y:583,t:1527632111097};\\\", \\\"{x:399,y:583,t:1527632111235};\\\", \\\"{x:397,y:583,t:1527632111246};\\\", \\\"{x:392,y:572,t:1527632111263};\\\", \\\"{x:385,y:555,t:1527632111280};\\\", \\\"{x:382,y:540,t:1527632111296};\\\", \\\"{x:378,y:526,t:1527632111313};\\\", \\\"{x:372,y:509,t:1527632111330};\\\", \\\"{x:368,y:495,t:1527632111346};\\\", \\\"{x:366,y:478,t:1527632111362};\\\", \\\"{x:364,y:472,t:1527632111380};\\\", \\\"{x:365,y:469,t:1527632111396};\\\", \\\"{x:372,y:464,t:1527632111412};\\\", \\\"{x:387,y:459,t:1527632111429};\\\", \\\"{x:415,y:450,t:1527632111446};\\\", \\\"{x:441,y:445,t:1527632111462};\\\", \\\"{x:473,y:442,t:1527632111478};\\\", \\\"{x:508,y:442,t:1527632111495};\\\", \\\"{x:535,y:442,t:1527632111512};\\\", \\\"{x:552,y:442,t:1527632111529};\\\", \\\"{x:570,y:442,t:1527632111546};\\\", \\\"{x:584,y:445,t:1527632111562};\\\", \\\"{x:587,y:448,t:1527632111579};\\\", \\\"{x:588,y:449,t:1527632111596};\\\", \\\"{x:591,y:451,t:1527632111611};\\\", \\\"{x:595,y:452,t:1527632111628};\\\", \\\"{x:604,y:456,t:1527632111645};\\\", \\\"{x:614,y:461,t:1527632111661};\\\", \\\"{x:622,y:467,t:1527632111678};\\\", \\\"{x:626,y:470,t:1527632111696};\\\", \\\"{x:631,y:474,t:1527632111711};\\\", \\\"{x:642,y:483,t:1527632111728};\\\", \\\"{x:654,y:493,t:1527632111746};\\\", \\\"{x:656,y:494,t:1527632111761};\\\", \\\"{x:656,y:495,t:1527632111826};\\\", \\\"{x:655,y:496,t:1527632111833};\\\", \\\"{x:653,y:497,t:1527632111846};\\\", \\\"{x:645,y:500,t:1527632111863};\\\", \\\"{x:641,y:500,t:1527632111879};\\\", \\\"{x:634,y:502,t:1527632111896};\\\", \\\"{x:628,y:505,t:1527632111912};\\\", \\\"{x:626,y:505,t:1527632111929};\\\", \\\"{x:625,y:505,t:1527632111946};\\\", \\\"{x:624,y:505,t:1527632111970};\\\", \\\"{x:622,y:505,t:1527632111986};\\\", \\\"{x:620,y:505,t:1527632111996};\\\", \\\"{x:617,y:506,t:1527632112330};\\\", \\\"{x:613,y:508,t:1527632112346};\\\", \\\"{x:608,y:516,t:1527632112364};\\\", \\\"{x:603,y:531,t:1527632112380};\\\", \\\"{x:596,y:544,t:1527632112396};\\\", \\\"{x:590,y:555,t:1527632112413};\\\", \\\"{x:586,y:563,t:1527632112430};\\\", \\\"{x:582,y:576,t:1527632112446};\\\", \\\"{x:573,y:600,t:1527632112463};\\\", \\\"{x:561,y:629,t:1527632112481};\\\", \\\"{x:547,y:659,t:1527632112497};\\\", \\\"{x:535,y:686,t:1527632112513};\\\", \\\"{x:523,y:719,t:1527632112529};\\\", \\\"{x:518,y:731,t:1527632112546};\\\", \\\"{x:516,y:735,t:1527632112564};\\\", \\\"{x:516,y:738,t:1527632112580};\\\", \\\"{x:516,y:740,t:1527632112596};\\\", \\\"{x:515,y:742,t:1527632112613};\\\", \\\"{x:513,y:745,t:1527632112630};\\\", \\\"{x:512,y:746,t:1527632112646};\\\", \\\"{x:512,y:747,t:1527632112682};\\\", \\\"{x:510,y:749,t:1527632112713};\\\", \\\"{x:507,y:753,t:1527632112730};\\\", \\\"{x:503,y:756,t:1527632112747};\\\", \\\"{x:502,y:757,t:1527632112763};\\\", \\\"{x:502,y:752,t:1527632113074};\\\", \\\"{x:502,y:745,t:1527632113082};\\\", \\\"{x:502,y:741,t:1527632113097};\\\", \\\"{x:502,y:735,t:1527632113113};\\\", \\\"{x:501,y:729,t:1527632113130};\\\", \\\"{x:500,y:727,t:1527632113147};\\\" ] }, { \\\"rt\\\": 12145, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 281131, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"8TUB0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:500,y:719,t:1527632122355};\\\", \\\"{x:503,y:691,t:1527632122371};\\\", \\\"{x:508,y:668,t:1527632122389};\\\", \\\"{x:514,y:645,t:1527632122405};\\\", \\\"{x:517,y:630,t:1527632122422};\\\", \\\"{x:520,y:621,t:1527632122438};\\\", \\\"{x:521,y:617,t:1527632122455};\\\", \\\"{x:521,y:616,t:1527632122506};\\\", \\\"{x:521,y:614,t:1527632122522};\\\", \\\"{x:517,y:610,t:1527632122538};\\\", \\\"{x:511,y:605,t:1527632122555};\\\", \\\"{x:497,y:596,t:1527632122572};\\\", \\\"{x:483,y:587,t:1527632122588};\\\", \\\"{x:463,y:572,t:1527632122605};\\\", \\\"{x:425,y:551,t:1527632122622};\\\", \\\"{x:392,y:538,t:1527632122638};\\\", \\\"{x:368,y:527,t:1527632122655};\\\", \\\"{x:346,y:521,t:1527632122672};\\\", \\\"{x:319,y:515,t:1527632122688};\\\", \\\"{x:293,y:510,t:1527632122704};\\\", \\\"{x:262,y:507,t:1527632122723};\\\", \\\"{x:245,y:504,t:1527632122739};\\\", \\\"{x:233,y:504,t:1527632122755};\\\", \\\"{x:228,y:504,t:1527632122772};\\\", \\\"{x:224,y:504,t:1527632122789};\\\", \\\"{x:221,y:504,t:1527632122804};\\\", \\\"{x:218,y:504,t:1527632122822};\\\", \\\"{x:215,y:506,t:1527632122839};\\\", \\\"{x:212,y:507,t:1527632122854};\\\", \\\"{x:210,y:508,t:1527632122871};\\\", \\\"{x:209,y:508,t:1527632122888};\\\", \\\"{x:207,y:509,t:1527632122905};\\\", \\\"{x:203,y:510,t:1527632122921};\\\", \\\"{x:202,y:511,t:1527632122970};\\\", \\\"{x:201,y:511,t:1527632123002};\\\", \\\"{x:199,y:511,t:1527632123010};\\\", \\\"{x:198,y:511,t:1527632123022};\\\", \\\"{x:197,y:511,t:1527632123042};\\\", \\\"{x:196,y:511,t:1527632123056};\\\", \\\"{x:200,y:517,t:1527632124762};\\\", \\\"{x:209,y:525,t:1527632124775};\\\", \\\"{x:234,y:544,t:1527632124792};\\\", \\\"{x:263,y:570,t:1527632124809};\\\", \\\"{x:299,y:595,t:1527632124823};\\\", \\\"{x:336,y:620,t:1527632124841};\\\", \\\"{x:368,y:645,t:1527632124858};\\\", \\\"{x:393,y:662,t:1527632124873};\\\", \\\"{x:412,y:680,t:1527632124890};\\\", \\\"{x:414,y:683,t:1527632124907};\\\", \\\"{x:414,y:684,t:1527632124924};\\\", \\\"{x:414,y:686,t:1527632124940};\\\", \\\"{x:415,y:687,t:1527632124957};\\\", \\\"{x:415,y:688,t:1527632124978};\\\", \\\"{x:415,y:689,t:1527632124991};\\\", \\\"{x:415,y:691,t:1527632125007};\\\", \\\"{x:415,y:694,t:1527632125024};\\\", \\\"{x:415,y:697,t:1527632125041};\\\", \\\"{x:415,y:699,t:1527632125056};\\\", \\\"{x:415,y:701,t:1527632125073};\\\", \\\"{x:414,y:703,t:1527632125091};\\\", \\\"{x:414,y:710,t:1527632125108};\\\", \\\"{x:415,y:718,t:1527632125123};\\\", \\\"{x:423,y:724,t:1527632125141};\\\", \\\"{x:434,y:728,t:1527632125158};\\\", \\\"{x:441,y:728,t:1527632125175};\\\", \\\"{x:449,y:726,t:1527632125191};\\\", \\\"{x:449,y:725,t:1527632125207};\\\", \\\"{x:446,y:715,t:1527632125223};\\\", \\\"{x:428,y:698,t:1527632125239};\\\", \\\"{x:401,y:681,t:1527632125257};\\\", \\\"{x:328,y:649,t:1527632125273};\\\", \\\"{x:278,y:629,t:1527632125290};\\\", \\\"{x:241,y:608,t:1527632125308};\\\", \\\"{x:204,y:590,t:1527632125325};\\\", \\\"{x:178,y:576,t:1527632125340};\\\", \\\"{x:154,y:565,t:1527632125357};\\\", \\\"{x:136,y:554,t:1527632125375};\\\", \\\"{x:123,y:547,t:1527632125390};\\\", \\\"{x:109,y:537,t:1527632125407};\\\", \\\"{x:106,y:534,t:1527632125424};\\\", \\\"{x:103,y:532,t:1527632125439};\\\", \\\"{x:103,y:531,t:1527632125456};\\\", \\\"{x:103,y:529,t:1527632125474};\\\", \\\"{x:103,y:528,t:1527632125490};\\\", \\\"{x:106,y:524,t:1527632125507};\\\", \\\"{x:119,y:519,t:1527632125524};\\\", \\\"{x:138,y:512,t:1527632125541};\\\", \\\"{x:152,y:507,t:1527632125557};\\\", \\\"{x:166,y:502,t:1527632125574};\\\", \\\"{x:173,y:499,t:1527632125591};\\\", \\\"{x:178,y:498,t:1527632125607};\\\", \\\"{x:179,y:497,t:1527632125624};\\\", \\\"{x:180,y:497,t:1527632125641};\\\", \\\"{x:183,y:497,t:1527632126082};\\\", \\\"{x:205,y:509,t:1527632126091};\\\", \\\"{x:250,y:541,t:1527632126109};\\\", \\\"{x:292,y:571,t:1527632126125};\\\", \\\"{x:335,y:594,t:1527632126141};\\\", \\\"{x:370,y:614,t:1527632126158};\\\", \\\"{x:392,y:626,t:1527632126175};\\\", \\\"{x:410,y:637,t:1527632126191};\\\", \\\"{x:427,y:651,t:1527632126208};\\\", \\\"{x:442,y:660,t:1527632126223};\\\", \\\"{x:447,y:663,t:1527632126241};\\\", \\\"{x:451,y:666,t:1527632126257};\\\", \\\"{x:453,y:667,t:1527632126274};\\\", \\\"{x:454,y:667,t:1527632126330};\\\", \\\"{x:456,y:667,t:1527632126341};\\\", \\\"{x:460,y:669,t:1527632126358};\\\", \\\"{x:463,y:671,t:1527632126374};\\\", \\\"{x:466,y:672,t:1527632126391};\\\", \\\"{x:470,y:676,t:1527632126408};\\\", \\\"{x:472,y:682,t:1527632126425};\\\", \\\"{x:478,y:692,t:1527632126441};\\\", \\\"{x:487,y:713,t:1527632126458};\\\", \\\"{x:494,y:725,t:1527632126475};\\\", \\\"{x:499,y:732,t:1527632126492};\\\", \\\"{x:499,y:733,t:1527632127178};\\\", \\\"{x:498,y:733,t:1527632127201};\\\", \\\"{x:497,y:734,t:1527632127210};\\\", \\\"{x:497,y:735,t:1527632127224};\\\", \\\"{x:496,y:735,t:1527632127249};\\\" ] }, { \\\"rt\\\": 14604, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 296963, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"8TUB0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:494,y:736,t:1527632129146};\\\", \\\"{x:493,y:736,t:1527632129178};\\\", \\\"{x:495,y:729,t:1527632129545};\\\", \\\"{x:503,y:711,t:1527632129560};\\\", \\\"{x:526,y:661,t:1527632129576};\\\", \\\"{x:547,y:618,t:1527632129594};\\\", \\\"{x:568,y:574,t:1527632129610};\\\", \\\"{x:582,y:552,t:1527632129627};\\\", \\\"{x:589,y:538,t:1527632129644};\\\", \\\"{x:594,y:526,t:1527632129660};\\\", \\\"{x:597,y:519,t:1527632129677};\\\", \\\"{x:599,y:513,t:1527632129694};\\\", \\\"{x:601,y:510,t:1527632129710};\\\", \\\"{x:601,y:508,t:1527632129727};\\\", \\\"{x:602,y:508,t:1527632129744};\\\", \\\"{x:602,y:507,t:1527632130810};\\\", \\\"{x:601,y:507,t:1527632130946};\\\", \\\"{x:599,y:508,t:1527632131634};\\\", \\\"{x:598,y:509,t:1527632132769};\\\", \\\"{x:595,y:510,t:1527632140226};\\\", \\\"{x:593,y:516,t:1527632140243};\\\", \\\"{x:589,y:521,t:1527632140260};\\\", \\\"{x:587,y:526,t:1527632140276};\\\", \\\"{x:586,y:527,t:1527632140290};\\\", \\\"{x:585,y:529,t:1527632140305};\\\", \\\"{x:585,y:530,t:1527632140318};\\\", \\\"{x:584,y:531,t:1527632140336};\\\", \\\"{x:583,y:534,t:1527632140352};\\\", \\\"{x:581,y:538,t:1527632140370};\\\", \\\"{x:579,y:540,t:1527632140386};\\\", \\\"{x:578,y:542,t:1527632140403};\\\", \\\"{x:576,y:544,t:1527632140419};\\\", \\\"{x:573,y:547,t:1527632140436};\\\", \\\"{x:573,y:550,t:1527632140452};\\\", \\\"{x:570,y:554,t:1527632140470};\\\", \\\"{x:567,y:559,t:1527632140486};\\\", \\\"{x:564,y:564,t:1527632140503};\\\", \\\"{x:561,y:570,t:1527632140519};\\\", \\\"{x:559,y:575,t:1527632140536};\\\", \\\"{x:558,y:579,t:1527632140551};\\\", \\\"{x:556,y:582,t:1527632140569};\\\", \\\"{x:554,y:586,t:1527632140586};\\\", \\\"{x:553,y:589,t:1527632140601};\\\", \\\"{x:553,y:591,t:1527632140618};\\\", \\\"{x:551,y:593,t:1527632140635};\\\", \\\"{x:550,y:594,t:1527632140652};\\\", \\\"{x:550,y:596,t:1527632140669};\\\", \\\"{x:549,y:597,t:1527632140685};\\\", \\\"{x:548,y:599,t:1527632140703};\\\", \\\"{x:547,y:600,t:1527632140719};\\\", \\\"{x:547,y:602,t:1527632140737};\\\", \\\"{x:546,y:603,t:1527632140752};\\\", \\\"{x:544,y:605,t:1527632140770};\\\", \\\"{x:544,y:608,t:1527632140786};\\\", \\\"{x:542,y:609,t:1527632140803};\\\", \\\"{x:540,y:612,t:1527632140819};\\\", \\\"{x:538,y:614,t:1527632140837};\\\", \\\"{x:536,y:616,t:1527632140852};\\\", \\\"{x:533,y:618,t:1527632140869};\\\", \\\"{x:531,y:619,t:1527632140887};\\\", \\\"{x:530,y:621,t:1527632140903};\\\", \\\"{x:528,y:624,t:1527632140919};\\\", \\\"{x:526,y:625,t:1527632140937};\\\", \\\"{x:522,y:626,t:1527632140953};\\\", \\\"{x:516,y:629,t:1527632140970};\\\", \\\"{x:513,y:631,t:1527632140986};\\\", \\\"{x:510,y:632,t:1527632141003};\\\", \\\"{x:506,y:633,t:1527632141020};\\\", \\\"{x:503,y:634,t:1527632141036};\\\", \\\"{x:499,y:635,t:1527632141053};\\\", \\\"{x:494,y:637,t:1527632141069};\\\", \\\"{x:490,y:638,t:1527632141087};\\\", \\\"{x:487,y:638,t:1527632141103};\\\", \\\"{x:483,y:638,t:1527632141119};\\\", \\\"{x:481,y:638,t:1527632141136};\\\", \\\"{x:477,y:637,t:1527632141153};\\\", \\\"{x:473,y:631,t:1527632141170};\\\", \\\"{x:469,y:623,t:1527632141187};\\\", \\\"{x:462,y:613,t:1527632141203};\\\", \\\"{x:456,y:603,t:1527632141219};\\\", \\\"{x:451,y:593,t:1527632141237};\\\", \\\"{x:448,y:585,t:1527632141253};\\\", \\\"{x:445,y:580,t:1527632141270};\\\", \\\"{x:442,y:576,t:1527632141286};\\\", \\\"{x:441,y:575,t:1527632141303};\\\", \\\"{x:439,y:574,t:1527632141322};\\\", \\\"{x:438,y:573,t:1527632141337};\\\", \\\"{x:433,y:573,t:1527632141354};\\\", \\\"{x:428,y:573,t:1527632141369};\\\", \\\"{x:423,y:573,t:1527632141386};\\\", \\\"{x:418,y:574,t:1527632141403};\\\", \\\"{x:414,y:575,t:1527632141420};\\\", \\\"{x:411,y:577,t:1527632141437};\\\", \\\"{x:410,y:577,t:1527632141453};\\\", \\\"{x:409,y:577,t:1527632141514};\\\", \\\"{x:408,y:576,t:1527632141521};\\\", \\\"{x:407,y:575,t:1527632141537};\\\", \\\"{x:404,y:571,t:1527632141554};\\\", \\\"{x:401,y:565,t:1527632141570};\\\", \\\"{x:397,y:560,t:1527632141587};\\\", \\\"{x:392,y:555,t:1527632141604};\\\", \\\"{x:391,y:553,t:1527632141621};\\\", \\\"{x:388,y:549,t:1527632141636};\\\", \\\"{x:386,y:546,t:1527632141654};\\\", \\\"{x:383,y:543,t:1527632141670};\\\", \\\"{x:382,y:542,t:1527632141686};\\\", \\\"{x:378,y:541,t:1527632141703};\\\", \\\"{x:377,y:539,t:1527632141721};\\\", \\\"{x:376,y:539,t:1527632141737};\\\", \\\"{x:377,y:542,t:1527632142082};\\\", \\\"{x:379,y:550,t:1527632142090};\\\", \\\"{x:384,y:558,t:1527632142104};\\\", \\\"{x:395,y:585,t:1527632142121};\\\", \\\"{x:427,y:635,t:1527632142138};\\\", \\\"{x:448,y:664,t:1527632142154};\\\", \\\"{x:473,y:693,t:1527632142171};\\\", \\\"{x:488,y:713,t:1527632142188};\\\", \\\"{x:496,y:724,t:1527632142204};\\\", \\\"{x:501,y:731,t:1527632142221};\\\", \\\"{x:505,y:737,t:1527632142238};\\\", \\\"{x:506,y:739,t:1527632142254};\\\", \\\"{x:504,y:739,t:1527632142378};\\\" ] }, { \\\"rt\\\": 12836, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 311003, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"8TUB0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:504,y:738,t:1527632151405};\\\", \\\"{x:504,y:737,t:1527632151838};\\\", \\\"{x:505,y:734,t:1527632151848};\\\", \\\"{x:505,y:729,t:1527632151863};\\\", \\\"{x:506,y:725,t:1527632151880};\\\", \\\"{x:506,y:721,t:1527632151897};\\\", \\\"{x:506,y:716,t:1527632151914};\\\", \\\"{x:508,y:714,t:1527632151930};\\\", \\\"{x:508,y:711,t:1527632151946};\\\", \\\"{x:509,y:709,t:1527632151964};\\\", \\\"{x:509,y:707,t:1527632151982};\\\", \\\"{x:509,y:706,t:1527632152004};\\\", \\\"{x:509,y:705,t:1527632152016};\\\", \\\"{x:509,y:704,t:1527632152033};\\\", \\\"{x:509,y:703,t:1527632152069};\\\", \\\"{x:509,y:702,t:1527632152101};\\\", \\\"{x:509,y:701,t:1527632152118};\\\", \\\"{x:510,y:700,t:1527632152141};\\\", \\\"{x:510,y:699,t:1527632152166};\\\", \\\"{x:510,y:698,t:1527632152182};\\\", \\\"{x:510,y:696,t:1527632152199};\\\", \\\"{x:510,y:694,t:1527632152216};\\\", \\\"{x:511,y:692,t:1527632152232};\\\", \\\"{x:512,y:689,t:1527632152249};\\\", \\\"{x:512,y:686,t:1527632152266};\\\", \\\"{x:512,y:683,t:1527632152283};\\\", \\\"{x:512,y:679,t:1527632152299};\\\", \\\"{x:513,y:675,t:1527632152316};\\\", \\\"{x:515,y:668,t:1527632152333};\\\", \\\"{x:516,y:663,t:1527632152349};\\\", \\\"{x:516,y:654,t:1527632152366};\\\", \\\"{x:517,y:648,t:1527632152383};\\\", \\\"{x:517,y:637,t:1527632152400};\\\", \\\"{x:517,y:624,t:1527632152417};\\\", \\\"{x:517,y:613,t:1527632152432};\\\", \\\"{x:519,y:603,t:1527632152448};\\\", \\\"{x:520,y:597,t:1527632152466};\\\", \\\"{x:524,y:588,t:1527632152483};\\\", \\\"{x:529,y:576,t:1527632152501};\\\", \\\"{x:557,y:545,t:1527632152544};\\\", \\\"{x:562,y:543,t:1527632152549};\\\", \\\"{x:567,y:539,t:1527632152565};\\\", \\\"{x:573,y:534,t:1527632152582};\\\", \\\"{x:578,y:531,t:1527632152600};\\\", \\\"{x:581,y:528,t:1527632152615};\\\", \\\"{x:582,y:526,t:1527632152633};\\\", \\\"{x:583,y:525,t:1527632152650};\\\", \\\"{x:584,y:524,t:1527632152666};\\\", \\\"{x:584,y:523,t:1527632152683};\\\", \\\"{x:584,y:522,t:1527632152700};\\\", \\\"{x:584,y:521,t:1527632152725};\\\", \\\"{x:586,y:519,t:1527632152733};\\\", \\\"{x:587,y:517,t:1527632152750};\\\", \\\"{x:589,y:514,t:1527632152767};\\\", \\\"{x:593,y:512,t:1527632152783};\\\", \\\"{x:598,y:509,t:1527632152800};\\\", \\\"{x:607,y:506,t:1527632152817};\\\", \\\"{x:615,y:502,t:1527632152833};\\\", \\\"{x:621,y:501,t:1527632152850};\\\", \\\"{x:627,y:498,t:1527632152866};\\\", \\\"{x:629,y:497,t:1527632152883};\\\", \\\"{x:632,y:496,t:1527632152899};\\\", \\\"{x:633,y:496,t:1527632152917};\\\", \\\"{x:634,y:496,t:1527632152933};\\\", \\\"{x:637,y:495,t:1527632152950};\\\", \\\"{x:632,y:495,t:1527632153062};\\\", \\\"{x:625,y:499,t:1527632153070};\\\", \\\"{x:618,y:501,t:1527632153083};\\\", \\\"{x:596,y:511,t:1527632153101};\\\", \\\"{x:562,y:523,t:1527632153118};\\\", \\\"{x:543,y:530,t:1527632153136};\\\", \\\"{x:490,y:548,t:1527632153185};\\\", \\\"{x:483,y:551,t:1527632153199};\\\", \\\"{x:478,y:552,t:1527632153216};\\\", \\\"{x:470,y:554,t:1527632153232};\\\", \\\"{x:465,y:556,t:1527632153250};\\\", \\\"{x:462,y:557,t:1527632153267};\\\", \\\"{x:459,y:558,t:1527632153283};\\\", \\\"{x:458,y:558,t:1527632153300};\\\", \\\"{x:457,y:558,t:1527632153341};\\\", \\\"{x:456,y:558,t:1527632153350};\\\", \\\"{x:453,y:558,t:1527632153367};\\\", \\\"{x:448,y:556,t:1527632153383};\\\", \\\"{x:443,y:554,t:1527632153400};\\\", \\\"{x:436,y:553,t:1527632153416};\\\", \\\"{x:428,y:553,t:1527632153434};\\\", \\\"{x:423,y:553,t:1527632153450};\\\", \\\"{x:424,y:552,t:1527632153502};\\\", \\\"{x:433,y:547,t:1527632153518};\\\", \\\"{x:463,y:533,t:1527632153533};\\\", \\\"{x:495,y:520,t:1527632153552};\\\", \\\"{x:553,y:504,t:1527632153568};\\\", \\\"{x:612,y:485,t:1527632153584};\\\", \\\"{x:653,y:475,t:1527632153600};\\\", \\\"{x:681,y:469,t:1527632153617};\\\", \\\"{x:699,y:464,t:1527632153634};\\\", \\\"{x:714,y:460,t:1527632153650};\\\", \\\"{x:727,y:455,t:1527632153666};\\\", \\\"{x:744,y:449,t:1527632153683};\\\", \\\"{x:757,y:445,t:1527632153701};\\\", \\\"{x:773,y:440,t:1527632153717};\\\", \\\"{x:809,y:434,t:1527632153733};\\\", \\\"{x:832,y:434,t:1527632153749};\\\", \\\"{x:842,y:434,t:1527632153767};\\\", \\\"{x:844,y:434,t:1527632153805};\\\", \\\"{x:844,y:435,t:1527632153817};\\\", \\\"{x:845,y:439,t:1527632153834};\\\", \\\"{x:846,y:442,t:1527632153851};\\\", \\\"{x:846,y:449,t:1527632153867};\\\", \\\"{x:848,y:452,t:1527632153883};\\\", \\\"{x:849,y:456,t:1527632153901};\\\", \\\"{x:849,y:461,t:1527632153917};\\\", \\\"{x:849,y:469,t:1527632153933};\\\", \\\"{x:849,y:473,t:1527632153951};\\\", \\\"{x:849,y:475,t:1527632153968};\\\", \\\"{x:849,y:478,t:1527632153984};\\\", \\\"{x:848,y:480,t:1527632154001};\\\", \\\"{x:848,y:481,t:1527632154017};\\\", \\\"{x:848,y:483,t:1527632154034};\\\", \\\"{x:848,y:484,t:1527632154053};\\\", \\\"{x:848,y:485,t:1527632154067};\\\", \\\"{x:846,y:489,t:1527632154084};\\\", \\\"{x:845,y:491,t:1527632154102};\\\", \\\"{x:844,y:492,t:1527632154117};\\\", \\\"{x:843,y:494,t:1527632154429};\\\", \\\"{x:840,y:495,t:1527632154437};\\\", \\\"{x:833,y:497,t:1527632154450};\\\", \\\"{x:815,y:502,t:1527632154468};\\\", \\\"{x:786,y:513,t:1527632154484};\\\", \\\"{x:741,y:528,t:1527632154501};\\\", \\\"{x:647,y:554,t:1527632154517};\\\", \\\"{x:562,y:571,t:1527632154535};\\\", \\\"{x:494,y:587,t:1527632154551};\\\", \\\"{x:419,y:607,t:1527632154569};\\\", \\\"{x:370,y:618,t:1527632154584};\\\", \\\"{x:331,y:623,t:1527632154601};\\\", \\\"{x:299,y:631,t:1527632154617};\\\", \\\"{x:276,y:637,t:1527632154635};\\\", \\\"{x:259,y:642,t:1527632154651};\\\", \\\"{x:247,y:646,t:1527632154668};\\\", \\\"{x:239,y:649,t:1527632154684};\\\", \\\"{x:230,y:651,t:1527632154700};\\\", \\\"{x:220,y:653,t:1527632154717};\\\", \\\"{x:219,y:653,t:1527632154735};\\\", \\\"{x:215,y:651,t:1527632154751};\\\", \\\"{x:211,y:644,t:1527632154768};\\\", \\\"{x:206,y:626,t:1527632154786};\\\", \\\"{x:197,y:607,t:1527632154801};\\\", \\\"{x:190,y:596,t:1527632154818};\\\", \\\"{x:181,y:581,t:1527632154836};\\\", \\\"{x:173,y:570,t:1527632154851};\\\", \\\"{x:167,y:563,t:1527632154868};\\\", \\\"{x:162,y:557,t:1527632154885};\\\", \\\"{x:161,y:554,t:1527632154902};\\\", \\\"{x:159,y:551,t:1527632154918};\\\", \\\"{x:158,y:550,t:1527632154934};\\\", \\\"{x:156,y:549,t:1527632154951};\\\", \\\"{x:155,y:548,t:1527632154968};\\\", \\\"{x:153,y:547,t:1527632154985};\\\", \\\"{x:152,y:547,t:1527632155005};\\\", \\\"{x:151,y:547,t:1527632155021};\\\", \\\"{x:150,y:547,t:1527632155037};\\\", \\\"{x:155,y:547,t:1527632155462};\\\", \\\"{x:164,y:549,t:1527632155469};\\\", \\\"{x:181,y:553,t:1527632155486};\\\", \\\"{x:203,y:560,t:1527632155502};\\\", \\\"{x:227,y:570,t:1527632155519};\\\", \\\"{x:252,y:582,t:1527632155535};\\\", \\\"{x:279,y:598,t:1527632155552};\\\", \\\"{x:309,y:620,t:1527632155569};\\\", \\\"{x:330,y:635,t:1527632155586};\\\", \\\"{x:352,y:652,t:1527632155603};\\\", \\\"{x:371,y:669,t:1527632155618};\\\", \\\"{x:389,y:685,t:1527632155635};\\\", \\\"{x:408,y:699,t:1527632155652};\\\", \\\"{x:420,y:709,t:1527632155669};\\\", \\\"{x:435,y:719,t:1527632155685};\\\", \\\"{x:441,y:722,t:1527632155702};\\\", \\\"{x:445,y:726,t:1527632155719};\\\", \\\"{x:449,y:728,t:1527632155736};\\\", \\\"{x:453,y:731,t:1527632155752};\\\", \\\"{x:459,y:734,t:1527632155769};\\\", \\\"{x:465,y:736,t:1527632155785};\\\", \\\"{x:469,y:738,t:1527632155802};\\\", \\\"{x:472,y:740,t:1527632155819};\\\", \\\"{x:474,y:740,t:1527632155835};\\\", \\\"{x:475,y:740,t:1527632155852};\\\", \\\"{x:476,y:741,t:1527632156654};\\\", \\\"{x:475,y:742,t:1527632156669};\\\", \\\"{x:473,y:743,t:1527632156686};\\\" ] }, { \\\"rt\\\": 5605, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 317841, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"8TUB0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:473,y:742,t:1527632160152};\\\", \\\"{x:473,y:738,t:1527632160162};\\\", \\\"{x:474,y:733,t:1527632160179};\\\", \\\"{x:476,y:728,t:1527632160196};\\\", \\\"{x:477,y:722,t:1527632160212};\\\", \\\"{x:477,y:716,t:1527632160229};\\\", \\\"{x:480,y:703,t:1527632160245};\\\", \\\"{x:481,y:693,t:1527632160261};\\\", \\\"{x:482,y:684,t:1527632160278};\\\", \\\"{x:483,y:680,t:1527632160289};\\\", \\\"{x:485,y:671,t:1527632160305};\\\", \\\"{x:485,y:664,t:1527632160322};\\\", \\\"{x:486,y:657,t:1527632160339};\\\", \\\"{x:486,y:649,t:1527632160356};\\\", \\\"{x:486,y:642,t:1527632160372};\\\", \\\"{x:486,y:634,t:1527632160389};\\\", \\\"{x:486,y:628,t:1527632160406};\\\", \\\"{x:486,y:624,t:1527632160421};\\\", \\\"{x:486,y:619,t:1527632160439};\\\", \\\"{x:486,y:613,t:1527632160456};\\\", \\\"{x:486,y:608,t:1527632160471};\\\", \\\"{x:486,y:604,t:1527632160489};\\\", \\\"{x:486,y:601,t:1527632160506};\\\", \\\"{x:483,y:596,t:1527632160522};\\\", \\\"{x:481,y:593,t:1527632160540};\\\", \\\"{x:478,y:590,t:1527632160555};\\\", \\\"{x:472,y:586,t:1527632160572};\\\", \\\"{x:465,y:581,t:1527632160589};\\\", \\\"{x:462,y:579,t:1527632160606};\\\", \\\"{x:460,y:578,t:1527632160623};\\\", \\\"{x:457,y:576,t:1527632160639};\\\", \\\"{x:453,y:573,t:1527632160656};\\\", \\\"{x:450,y:570,t:1527632160672};\\\", \\\"{x:444,y:568,t:1527632160689};\\\", \\\"{x:436,y:565,t:1527632160706};\\\", \\\"{x:431,y:563,t:1527632160723};\\\", \\\"{x:422,y:563,t:1527632160740};\\\", \\\"{x:410,y:563,t:1527632160756};\\\", \\\"{x:389,y:563,t:1527632160796};\\\", \\\"{x:363,y:568,t:1527632160806};\\\", \\\"{x:353,y:570,t:1527632160823};\\\", \\\"{x:347,y:571,t:1527632160838};\\\", \\\"{x:341,y:574,t:1527632160856};\\\", \\\"{x:338,y:574,t:1527632160873};\\\", \\\"{x:335,y:575,t:1527632160889};\\\", \\\"{x:333,y:576,t:1527632160906};\\\", \\\"{x:332,y:576,t:1527632160923};\\\", \\\"{x:331,y:577,t:1527632160939};\\\", \\\"{x:332,y:577,t:1527632161029};\\\", \\\"{x:341,y:577,t:1527632161040};\\\", \\\"{x:360,y:573,t:1527632161056};\\\", \\\"{x:389,y:565,t:1527632161073};\\\", \\\"{x:428,y:555,t:1527632161091};\\\", \\\"{x:460,y:547,t:1527632161106};\\\", \\\"{x:484,y:544,t:1527632161122};\\\", \\\"{x:512,y:538,t:1527632161140};\\\", \\\"{x:540,y:536,t:1527632161156};\\\", \\\"{x:573,y:530,t:1527632161173};\\\", \\\"{x:591,y:527,t:1527632161189};\\\", \\\"{x:602,y:526,t:1527632161206};\\\", \\\"{x:614,y:524,t:1527632161223};\\\", \\\"{x:623,y:522,t:1527632161239};\\\", \\\"{x:636,y:518,t:1527632161256};\\\", \\\"{x:649,y:515,t:1527632161274};\\\", \\\"{x:663,y:513,t:1527632161290};\\\", \\\"{x:676,y:513,t:1527632161306};\\\", \\\"{x:684,y:513,t:1527632161323};\\\", \\\"{x:688,y:513,t:1527632161340};\\\", \\\"{x:689,y:513,t:1527632161356};\\\", \\\"{x:692,y:513,t:1527632161373};\\\", \\\"{x:694,y:513,t:1527632161397};\\\", \\\"{x:695,y:513,t:1527632161437};\\\", \\\"{x:696,y:513,t:1527632161453};\\\", \\\"{x:696,y:514,t:1527632161533};\\\", \\\"{x:692,y:516,t:1527632161541};\\\", \\\"{x:688,y:518,t:1527632161556};\\\", \\\"{x:669,y:531,t:1527632161573};\\\", \\\"{x:659,y:538,t:1527632161590};\\\", \\\"{x:648,y:544,t:1527632161607};\\\", \\\"{x:637,y:549,t:1527632161623};\\\", \\\"{x:625,y:554,t:1527632161640};\\\", \\\"{x:614,y:558,t:1527632161656};\\\", \\\"{x:596,y:564,t:1527632161673};\\\", \\\"{x:574,y:570,t:1527632161690};\\\", \\\"{x:538,y:576,t:1527632161707};\\\", \\\"{x:498,y:582,t:1527632161725};\\\", \\\"{x:445,y:583,t:1527632161740};\\\", \\\"{x:380,y:583,t:1527632161758};\\\", \\\"{x:350,y:583,t:1527632161773};\\\", \\\"{x:323,y:583,t:1527632161790};\\\", \\\"{x:299,y:583,t:1527632161807};\\\", \\\"{x:277,y:583,t:1527632161823};\\\", \\\"{x:261,y:583,t:1527632161841};\\\", \\\"{x:252,y:583,t:1527632161857};\\\", \\\"{x:241,y:581,t:1527632161873};\\\", \\\"{x:228,y:578,t:1527632161890};\\\", \\\"{x:216,y:574,t:1527632161907};\\\", \\\"{x:201,y:570,t:1527632161923};\\\", \\\"{x:189,y:566,t:1527632161941};\\\", \\\"{x:178,y:561,t:1527632161957};\\\", \\\"{x:172,y:558,t:1527632161974};\\\", \\\"{x:165,y:553,t:1527632161990};\\\", \\\"{x:158,y:548,t:1527632162007};\\\", \\\"{x:153,y:545,t:1527632162024};\\\", \\\"{x:152,y:544,t:1527632162040};\\\", \\\"{x:150,y:542,t:1527632162057};\\\", \\\"{x:149,y:539,t:1527632162074};\\\", \\\"{x:148,y:536,t:1527632162091};\\\", \\\"{x:146,y:534,t:1527632162107};\\\", \\\"{x:146,y:532,t:1527632162124};\\\", \\\"{x:147,y:532,t:1527632162502};\\\", \\\"{x:148,y:532,t:1527632162542};\\\", \\\"{x:150,y:533,t:1527632162551};\\\", \\\"{x:150,y:536,t:1527632162893};\\\", \\\"{x:155,y:539,t:1527632162907};\\\", \\\"{x:171,y:547,t:1527632162924};\\\", \\\"{x:203,y:561,t:1527632162942};\\\", \\\"{x:224,y:573,t:1527632162959};\\\", \\\"{x:250,y:586,t:1527632162974};\\\", \\\"{x:290,y:608,t:1527632162992};\\\", \\\"{x:323,y:627,t:1527632163008};\\\", \\\"{x:360,y:647,t:1527632163025};\\\", \\\"{x:389,y:662,t:1527632163041};\\\", \\\"{x:416,y:679,t:1527632163059};\\\", \\\"{x:442,y:693,t:1527632163074};\\\", \\\"{x:462,y:705,t:1527632163091};\\\", \\\"{x:480,y:719,t:1527632163109};\\\", \\\"{x:491,y:726,t:1527632163125};\\\", \\\"{x:494,y:728,t:1527632163141};\\\" ] }, { \\\"rt\\\": 15716, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 335215, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"8TUB0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:495,y:728,t:1527632171319};\\\", \\\"{x:492,y:728,t:1527632173782};\\\", \\\"{x:477,y:733,t:1527632173799};\\\", \\\"{x:463,y:738,t:1527632173816};\\\", \\\"{x:457,y:740,t:1527632173832};\\\", \\\"{x:450,y:743,t:1527632173849};\\\", \\\"{x:447,y:744,t:1527632173866};\\\", \\\"{x:446,y:745,t:1527632173882};\\\", \\\"{x:445,y:745,t:1527632173950};\\\", \\\"{x:444,y:745,t:1527632173967};\\\", \\\"{x:443,y:745,t:1527632173982};\\\", \\\"{x:439,y:743,t:1527632173998};\\\", \\\"{x:436,y:741,t:1527632174016};\\\", \\\"{x:428,y:738,t:1527632174033};\\\", \\\"{x:423,y:735,t:1527632174049};\\\", \\\"{x:417,y:731,t:1527632174067};\\\", \\\"{x:412,y:728,t:1527632174083};\\\", \\\"{x:408,y:726,t:1527632174100};\\\", \\\"{x:400,y:722,t:1527632174117};\\\", \\\"{x:398,y:721,t:1527632174134};\\\", \\\"{x:397,y:719,t:1527632174157};\\\", \\\"{x:397,y:714,t:1527632174167};\\\", \\\"{x:397,y:702,t:1527632174183};\\\", \\\"{x:397,y:691,t:1527632174201};\\\", \\\"{x:397,y:680,t:1527632174216};\\\", \\\"{x:397,y:667,t:1527632174234};\\\", \\\"{x:398,y:653,t:1527632174251};\\\", \\\"{x:401,y:635,t:1527632174267};\\\", \\\"{x:404,y:618,t:1527632174284};\\\", \\\"{x:408,y:602,t:1527632174301};\\\", \\\"{x:411,y:597,t:1527632174317};\\\", \\\"{x:411,y:590,t:1527632174334};\\\", \\\"{x:411,y:588,t:1527632174351};\\\", \\\"{x:411,y:587,t:1527632174367};\\\", \\\"{x:411,y:586,t:1527632174477};\\\", \\\"{x:411,y:585,t:1527632174485};\\\", \\\"{x:411,y:583,t:1527632174500};\\\", \\\"{x:411,y:580,t:1527632174517};\\\", \\\"{x:412,y:578,t:1527632174533};\\\", \\\"{x:412,y:576,t:1527632174551};\\\", \\\"{x:412,y:573,t:1527632174567};\\\", \\\"{x:412,y:571,t:1527632174584};\\\", \\\"{x:412,y:569,t:1527632174599};\\\", \\\"{x:412,y:568,t:1527632174617};\\\", \\\"{x:413,y:565,t:1527632174634};\\\", \\\"{x:413,y:564,t:1527632174652};\\\", \\\"{x:413,y:563,t:1527632174667};\\\", \\\"{x:413,y:562,t:1527632174684};\\\", \\\"{x:414,y:559,t:1527632174701};\\\", \\\"{x:414,y:558,t:1527632174717};\\\", \\\"{x:414,y:555,t:1527632174872};\\\", \\\"{x:415,y:553,t:1527632174885};\\\", \\\"{x:415,y:548,t:1527632174901};\\\", \\\"{x:416,y:544,t:1527632174918};\\\", \\\"{x:416,y:543,t:1527632174933};\\\", \\\"{x:416,y:541,t:1527632174951};\\\", \\\"{x:416,y:540,t:1527632175334};\\\", \\\"{x:429,y:540,t:1527632175353};\\\", \\\"{x:451,y:538,t:1527632175368};\\\", \\\"{x:477,y:537,t:1527632175385};\\\", \\\"{x:507,y:535,t:1527632175402};\\\", \\\"{x:542,y:532,t:1527632175418};\\\", \\\"{x:570,y:531,t:1527632175434};\\\", \\\"{x:591,y:527,t:1527632175450};\\\", \\\"{x:611,y:525,t:1527632175467};\\\", \\\"{x:638,y:518,t:1527632175485};\\\", \\\"{x:652,y:515,t:1527632175502};\\\", \\\"{x:661,y:511,t:1527632175518};\\\", \\\"{x:670,y:509,t:1527632175534};\\\", \\\"{x:678,y:507,t:1527632175552};\\\", \\\"{x:684,y:506,t:1527632175568};\\\", \\\"{x:691,y:506,t:1527632175585};\\\", \\\"{x:699,y:506,t:1527632175602};\\\", \\\"{x:703,y:506,t:1527632175617};\\\", \\\"{x:708,y:506,t:1527632175634};\\\", \\\"{x:710,y:506,t:1527632175652};\\\", \\\"{x:714,y:506,t:1527632175668};\\\", \\\"{x:735,y:508,t:1527632175686};\\\", \\\"{x:749,y:510,t:1527632175702};\\\", \\\"{x:763,y:512,t:1527632175717};\\\", \\\"{x:781,y:517,t:1527632175735};\\\", \\\"{x:788,y:518,t:1527632175752};\\\", \\\"{x:791,y:518,t:1527632175768};\\\", \\\"{x:792,y:518,t:1527632175784};\\\", \\\"{x:794,y:518,t:1527632175802};\\\", \\\"{x:797,y:520,t:1527632175818};\\\", \\\"{x:799,y:520,t:1527632175835};\\\", \\\"{x:801,y:520,t:1527632175852};\\\", \\\"{x:802,y:520,t:1527632175868};\\\", \\\"{x:805,y:520,t:1527632175885};\\\", \\\"{x:807,y:520,t:1527632175902};\\\", \\\"{x:811,y:519,t:1527632175919};\\\", \\\"{x:816,y:517,t:1527632175936};\\\", \\\"{x:819,y:516,t:1527632175952};\\\", \\\"{x:821,y:515,t:1527632175968};\\\", \\\"{x:823,y:515,t:1527632175985};\\\", \\\"{x:827,y:515,t:1527632176002};\\\", \\\"{x:833,y:512,t:1527632176019};\\\", \\\"{x:839,y:507,t:1527632176034};\\\", \\\"{x:844,y:504,t:1527632176052};\\\", \\\"{x:848,y:502,t:1527632176069};\\\", \\\"{x:848,y:501,t:1527632176085};\\\", \\\"{x:849,y:501,t:1527632176468};\\\", \\\"{x:848,y:501,t:1527632176541};\\\", \\\"{x:847,y:501,t:1527632176605};\\\", \\\"{x:846,y:501,t:1527632176619};\\\", \\\"{x:845,y:501,t:1527632176636};\\\", \\\"{x:844,y:501,t:1527632176654};\\\", \\\"{x:843,y:502,t:1527632176670};\\\", \\\"{x:841,y:502,t:1527632176758};\\\", \\\"{x:840,y:502,t:1527632176769};\\\", \\\"{x:837,y:504,t:1527632176787};\\\", \\\"{x:834,y:504,t:1527632176803};\\\", \\\"{x:831,y:505,t:1527632176819};\\\", \\\"{x:827,y:506,t:1527632176837};\\\", \\\"{x:820,y:508,t:1527632176854};\\\", \\\"{x:813,y:511,t:1527632176869};\\\", \\\"{x:805,y:512,t:1527632176885};\\\", \\\"{x:796,y:515,t:1527632176902};\\\", \\\"{x:788,y:518,t:1527632176920};\\\", \\\"{x:782,y:518,t:1527632176935};\\\", \\\"{x:777,y:521,t:1527632176953};\\\", \\\"{x:772,y:521,t:1527632176969};\\\", \\\"{x:764,y:524,t:1527632176986};\\\", \\\"{x:757,y:526,t:1527632177003};\\\", \\\"{x:744,y:529,t:1527632177019};\\\", \\\"{x:725,y:534,t:1527632177035};\\\", \\\"{x:690,y:543,t:1527632177053};\\\", \\\"{x:668,y:551,t:1527632177069};\\\", \\\"{x:644,y:558,t:1527632177086};\\\", \\\"{x:618,y:562,t:1527632177103};\\\", \\\"{x:598,y:566,t:1527632177119};\\\", \\\"{x:578,y:570,t:1527632177136};\\\", \\\"{x:552,y:577,t:1527632177153};\\\", \\\"{x:528,y:585,t:1527632177169};\\\", \\\"{x:507,y:592,t:1527632177186};\\\", \\\"{x:482,y:599,t:1527632177203};\\\", \\\"{x:465,y:604,t:1527632177221};\\\", \\\"{x:452,y:608,t:1527632177236};\\\", \\\"{x:443,y:610,t:1527632177253};\\\", \\\"{x:439,y:612,t:1527632177269};\\\", \\\"{x:434,y:613,t:1527632177286};\\\", \\\"{x:432,y:615,t:1527632177303};\\\", \\\"{x:431,y:615,t:1527632177349};\\\", \\\"{x:430,y:615,t:1527632177365};\\\", \\\"{x:429,y:615,t:1527632177454};\\\", \\\"{x:425,y:606,t:1527632177469};\\\", \\\"{x:421,y:596,t:1527632177487};\\\", \\\"{x:418,y:589,t:1527632177503};\\\", \\\"{x:413,y:578,t:1527632177520};\\\", \\\"{x:410,y:567,t:1527632177536};\\\", \\\"{x:405,y:555,t:1527632177553};\\\", \\\"{x:401,y:549,t:1527632177570};\\\", \\\"{x:400,y:542,t:1527632177586};\\\", \\\"{x:396,y:536,t:1527632177603};\\\", \\\"{x:395,y:530,t:1527632177620};\\\", \\\"{x:394,y:526,t:1527632177637};\\\", \\\"{x:393,y:523,t:1527632177653};\\\", \\\"{x:392,y:521,t:1527632177669};\\\", \\\"{x:392,y:519,t:1527632177687};\\\", \\\"{x:392,y:516,t:1527632177703};\\\", \\\"{x:393,y:512,t:1527632177720};\\\", \\\"{x:399,y:507,t:1527632177736};\\\", \\\"{x:411,y:502,t:1527632177753};\\\", \\\"{x:428,y:494,t:1527632177770};\\\", \\\"{x:456,y:486,t:1527632177787};\\\", \\\"{x:485,y:476,t:1527632177803};\\\", \\\"{x:518,y:470,t:1527632177820};\\\", \\\"{x:553,y:466,t:1527632177837};\\\", \\\"{x:574,y:466,t:1527632177853};\\\", \\\"{x:595,y:469,t:1527632177870};\\\", \\\"{x:613,y:475,t:1527632177887};\\\", \\\"{x:629,y:484,t:1527632177904};\\\", \\\"{x:644,y:494,t:1527632177920};\\\", \\\"{x:659,y:504,t:1527632177937};\\\", \\\"{x:668,y:512,t:1527632177953};\\\", \\\"{x:673,y:517,t:1527632177970};\\\", \\\"{x:675,y:520,t:1527632177988};\\\", \\\"{x:678,y:524,t:1527632178003};\\\", \\\"{x:679,y:529,t:1527632178020};\\\", \\\"{x:679,y:537,t:1527632178037};\\\", \\\"{x:679,y:542,t:1527632178053};\\\", \\\"{x:679,y:547,t:1527632178070};\\\", \\\"{x:678,y:551,t:1527632178087};\\\", \\\"{x:672,y:557,t:1527632178104};\\\", \\\"{x:659,y:563,t:1527632178120};\\\", \\\"{x:643,y:570,t:1527632178137};\\\", \\\"{x:624,y:578,t:1527632178153};\\\", \\\"{x:599,y:585,t:1527632178170};\\\", \\\"{x:573,y:588,t:1527632178187};\\\", \\\"{x:530,y:590,t:1527632178203};\\\", \\\"{x:485,y:590,t:1527632178220};\\\", \\\"{x:410,y:587,t:1527632178236};\\\", \\\"{x:357,y:579,t:1527632178253};\\\", \\\"{x:312,y:573,t:1527632178270};\\\", \\\"{x:283,y:568,t:1527632178287};\\\", \\\"{x:257,y:567,t:1527632178306};\\\", \\\"{x:235,y:564,t:1527632178320};\\\", \\\"{x:223,y:564,t:1527632178337};\\\", \\\"{x:214,y:564,t:1527632178353};\\\", \\\"{x:208,y:564,t:1527632178370};\\\", \\\"{x:203,y:564,t:1527632178386};\\\", \\\"{x:200,y:564,t:1527632178404};\\\", \\\"{x:193,y:564,t:1527632178420};\\\", \\\"{x:183,y:565,t:1527632178437};\\\", \\\"{x:174,y:567,t:1527632178454};\\\", \\\"{x:166,y:568,t:1527632178470};\\\", \\\"{x:158,y:569,t:1527632178487};\\\", \\\"{x:154,y:569,t:1527632178504};\\\", \\\"{x:152,y:569,t:1527632178525};\\\", \\\"{x:152,y:570,t:1527632178573};\\\", \\\"{x:151,y:569,t:1527632178589};\\\", \\\"{x:151,y:563,t:1527632178604};\\\", \\\"{x:148,y:553,t:1527632178622};\\\", \\\"{x:146,y:547,t:1527632178636};\\\", \\\"{x:146,y:544,t:1527632178654};\\\", \\\"{x:144,y:540,t:1527632178671};\\\", \\\"{x:143,y:538,t:1527632178687};\\\", \\\"{x:143,y:537,t:1527632178704};\\\", \\\"{x:146,y:537,t:1527632179070};\\\", \\\"{x:153,y:538,t:1527632179079};\\\", \\\"{x:163,y:540,t:1527632179087};\\\", \\\"{x:179,y:548,t:1527632179104};\\\", \\\"{x:195,y:554,t:1527632179121};\\\", \\\"{x:206,y:560,t:1527632179139};\\\", \\\"{x:211,y:563,t:1527632179154};\\\", \\\"{x:212,y:563,t:1527632179237};\\\", \\\"{x:212,y:560,t:1527632179254};\\\", \\\"{x:210,y:556,t:1527632179271};\\\", \\\"{x:204,y:549,t:1527632179288};\\\", \\\"{x:198,y:542,t:1527632179304};\\\", \\\"{x:187,y:535,t:1527632179321};\\\", \\\"{x:177,y:527,t:1527632179338};\\\", \\\"{x:169,y:523,t:1527632179354};\\\", \\\"{x:165,y:521,t:1527632179371};\\\", \\\"{x:161,y:519,t:1527632179388};\\\", \\\"{x:156,y:518,t:1527632179404};\\\", \\\"{x:154,y:518,t:1527632179420};\\\", \\\"{x:153,y:518,t:1527632179438};\\\", \\\"{x:152,y:518,t:1527632179455};\\\", \\\"{x:151,y:518,t:1527632179471};\\\", \\\"{x:151,y:519,t:1527632179734};\\\", \\\"{x:151,y:522,t:1527632179742};\\\", \\\"{x:151,y:523,t:1527632179755};\\\", \\\"{x:151,y:525,t:1527632179772};\\\", \\\"{x:152,y:530,t:1527632179788};\\\", \\\"{x:156,y:533,t:1527632179805};\\\", \\\"{x:156,y:534,t:1527632179845};\\\", \\\"{x:159,y:537,t:1527632180172};\\\", \\\"{x:165,y:543,t:1527632180188};\\\", \\\"{x:195,y:571,t:1527632180206};\\\", \\\"{x:231,y:600,t:1527632180222};\\\", \\\"{x:277,y:636,t:1527632180239};\\\", \\\"{x:335,y:675,t:1527632180255};\\\", \\\"{x:388,y:713,t:1527632180272};\\\", \\\"{x:440,y:755,t:1527632180289};\\\", \\\"{x:477,y:788,t:1527632180305};\\\", \\\"{x:510,y:817,t:1527632180322};\\\", \\\"{x:535,y:837,t:1527632180339};\\\", \\\"{x:546,y:846,t:1527632180354};\\\", \\\"{x:549,y:849,t:1527632180372};\\\", \\\"{x:550,y:848,t:1527632180446};\\\", \\\"{x:550,y:845,t:1527632180456};\\\", \\\"{x:548,y:837,t:1527632180472};\\\", \\\"{x:546,y:821,t:1527632180489};\\\", \\\"{x:543,y:803,t:1527632180507};\\\", \\\"{x:540,y:782,t:1527632180523};\\\", \\\"{x:538,y:770,t:1527632180539};\\\", \\\"{x:537,y:760,t:1527632180556};\\\", \\\"{x:536,y:752,t:1527632180573};\\\", \\\"{x:534,y:744,t:1527632180588};\\\", \\\"{x:534,y:743,t:1527632180606};\\\" ] }, { \\\"rt\\\": 22203, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 358648, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"8TUB0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:533,y:743,t:1527632182390};\\\", \\\"{x:532,y:743,t:1527632182405};\\\", \\\"{x:531,y:743,t:1527632182454};\\\", \\\"{x:528,y:734,t:1527632190038};\\\", \\\"{x:525,y:724,t:1527632190046};\\\", \\\"{x:523,y:714,t:1527632190060};\\\", \\\"{x:516,y:692,t:1527632190076};\\\", \\\"{x:500,y:655,t:1527632190093};\\\", \\\"{x:487,y:629,t:1527632190111};\\\", \\\"{x:478,y:609,t:1527632190127};\\\", \\\"{x:471,y:593,t:1527632190147};\\\", \\\"{x:466,y:580,t:1527632190163};\\\", \\\"{x:462,y:571,t:1527632190180};\\\", \\\"{x:459,y:566,t:1527632190196};\\\", \\\"{x:457,y:561,t:1527632190213};\\\", \\\"{x:456,y:557,t:1527632190230};\\\", \\\"{x:455,y:554,t:1527632190247};\\\", \\\"{x:455,y:552,t:1527632190263};\\\", \\\"{x:454,y:551,t:1527632190285};\\\", \\\"{x:453,y:548,t:1527632190301};\\\", \\\"{x:452,y:548,t:1527632190313};\\\", \\\"{x:451,y:547,t:1527632190331};\\\", \\\"{x:448,y:544,t:1527632190347};\\\", \\\"{x:445,y:542,t:1527632190364};\\\", \\\"{x:438,y:540,t:1527632190380};\\\", \\\"{x:433,y:538,t:1527632190397};\\\", \\\"{x:426,y:536,t:1527632190413};\\\", \\\"{x:421,y:533,t:1527632190430};\\\", \\\"{x:414,y:530,t:1527632190447};\\\", \\\"{x:410,y:528,t:1527632190463};\\\", \\\"{x:405,y:526,t:1527632190480};\\\", \\\"{x:402,y:525,t:1527632190496};\\\", \\\"{x:396,y:523,t:1527632190514};\\\", \\\"{x:391,y:522,t:1527632190531};\\\", \\\"{x:385,y:522,t:1527632190547};\\\", \\\"{x:378,y:522,t:1527632190563};\\\", \\\"{x:360,y:522,t:1527632190580};\\\", \\\"{x:350,y:524,t:1527632190598};\\\", \\\"{x:342,y:527,t:1527632190613};\\\", \\\"{x:332,y:529,t:1527632190631};\\\", \\\"{x:319,y:533,t:1527632190646};\\\", \\\"{x:304,y:537,t:1527632190663};\\\", \\\"{x:292,y:540,t:1527632190680};\\\", \\\"{x:276,y:545,t:1527632190696};\\\", \\\"{x:267,y:548,t:1527632190714};\\\", \\\"{x:259,y:550,t:1527632190730};\\\", \\\"{x:251,y:552,t:1527632190747};\\\", \\\"{x:246,y:554,t:1527632190763};\\\", \\\"{x:243,y:555,t:1527632190780};\\\", \\\"{x:240,y:557,t:1527632190797};\\\", \\\"{x:238,y:557,t:1527632190844};\\\", \\\"{x:236,y:559,t:1527632190861};\\\", \\\"{x:234,y:560,t:1527632190868};\\\", \\\"{x:233,y:560,t:1527632190885};\\\", \\\"{x:232,y:560,t:1527632190897};\\\", \\\"{x:231,y:561,t:1527632190913};\\\", \\\"{x:229,y:562,t:1527632190930};\\\", \\\"{x:228,y:562,t:1527632190949};\\\", \\\"{x:227,y:563,t:1527632190964};\\\", \\\"{x:226,y:563,t:1527632190980};\\\", \\\"{x:225,y:563,t:1527632190997};\\\", \\\"{x:229,y:563,t:1527632191822};\\\", \\\"{x:240,y:563,t:1527632191832};\\\", \\\"{x:267,y:563,t:1527632191849};\\\", \\\"{x:300,y:563,t:1527632191868};\\\", \\\"{x:342,y:563,t:1527632191881};\\\", \\\"{x:385,y:563,t:1527632191897};\\\", \\\"{x:440,y:563,t:1527632191914};\\\", \\\"{x:499,y:563,t:1527632191932};\\\", \\\"{x:560,y:563,t:1527632191947};\\\", \\\"{x:647,y:573,t:1527632191964};\\\", \\\"{x:703,y:581,t:1527632191981};\\\", \\\"{x:751,y:588,t:1527632191998};\\\", \\\"{x:790,y:594,t:1527632192015};\\\", \\\"{x:816,y:595,t:1527632192032};\\\", \\\"{x:834,y:597,t:1527632192048};\\\", \\\"{x:848,y:598,t:1527632192065};\\\", \\\"{x:857,y:598,t:1527632192081};\\\", \\\"{x:860,y:598,t:1527632192099};\\\", \\\"{x:865,y:598,t:1527632192114};\\\", \\\"{x:867,y:598,t:1527632192132};\\\", \\\"{x:871,y:597,t:1527632192149};\\\", \\\"{x:873,y:596,t:1527632192164};\\\", \\\"{x:876,y:595,t:1527632192181};\\\", \\\"{x:877,y:590,t:1527632192199};\\\", \\\"{x:878,y:581,t:1527632192214};\\\", \\\"{x:879,y:571,t:1527632192232};\\\", \\\"{x:879,y:561,t:1527632192249};\\\", \\\"{x:879,y:555,t:1527632192266};\\\", \\\"{x:879,y:546,t:1527632192281};\\\", \\\"{x:876,y:540,t:1527632192298};\\\", \\\"{x:871,y:531,t:1527632192314};\\\", \\\"{x:867,y:524,t:1527632192332};\\\", \\\"{x:861,y:514,t:1527632192350};\\\", \\\"{x:860,y:509,t:1527632192365};\\\", \\\"{x:857,y:504,t:1527632192381};\\\", \\\"{x:857,y:503,t:1527632192399};\\\", \\\"{x:855,y:502,t:1527632192415};\\\", \\\"{x:854,y:501,t:1527632192781};\\\", \\\"{x:849,y:501,t:1527632192788};\\\", \\\"{x:845,y:501,t:1527632192798};\\\", \\\"{x:834,y:503,t:1527632192815};\\\", \\\"{x:821,y:506,t:1527632192831};\\\", \\\"{x:811,y:508,t:1527632192848};\\\", \\\"{x:803,y:510,t:1527632192865};\\\", \\\"{x:798,y:512,t:1527632192881};\\\", \\\"{x:794,y:512,t:1527632192899};\\\", \\\"{x:791,y:512,t:1527632192915};\\\", \\\"{x:789,y:512,t:1527632192931};\\\", \\\"{x:788,y:512,t:1527632192956};\\\", \\\"{x:788,y:513,t:1527632192973};\\\", \\\"{x:786,y:513,t:1527632192983};\\\", \\\"{x:784,y:513,t:1527632193005};\\\", \\\"{x:783,y:513,t:1527632193117};\\\", \\\"{x:783,y:514,t:1527632193693};\\\", \\\"{x:782,y:515,t:1527632193701};\\\", \\\"{x:781,y:516,t:1527632193717};\\\", \\\"{x:780,y:516,t:1527632193782};\\\", \\\"{x:781,y:516,t:1527632194390};\\\", \\\"{x:782,y:516,t:1527632194400};\\\", \\\"{x:784,y:516,t:1527632194417};\\\", \\\"{x:789,y:515,t:1527632194434};\\\", \\\"{x:793,y:512,t:1527632194450};\\\", \\\"{x:795,y:512,t:1527632194467};\\\", \\\"{x:796,y:511,t:1527632194484};\\\", \\\"{x:797,y:511,t:1527632194500};\\\", \\\"{x:798,y:510,t:1527632194517};\\\", \\\"{x:799,y:510,t:1527632194533};\\\", \\\"{x:800,y:509,t:1527632194550};\\\", \\\"{x:801,y:509,t:1527632194998};\\\", \\\"{x:802,y:509,t:1527632195006};\\\", \\\"{x:804,y:508,t:1527632195018};\\\", \\\"{x:806,y:508,t:1527632195034};\\\", \\\"{x:808,y:507,t:1527632195051};\\\", \\\"{x:811,y:506,t:1527632195068};\\\", \\\"{x:813,y:505,t:1527632195084};\\\", \\\"{x:818,y:505,t:1527632195101};\\\", \\\"{x:820,y:504,t:1527632195117};\\\", \\\"{x:822,y:502,t:1527632195134};\\\", \\\"{x:826,y:501,t:1527632195151};\\\", \\\"{x:828,y:501,t:1527632195166};\\\", \\\"{x:829,y:500,t:1527632195183};\\\", \\\"{x:830,y:500,t:1527632195201};\\\", \\\"{x:832,y:499,t:1527632195217};\\\", \\\"{x:833,y:498,t:1527632195244};\\\", \\\"{x:835,y:498,t:1527632195252};\\\", \\\"{x:837,y:498,t:1527632195268};\\\", \\\"{x:839,y:498,t:1527632195283};\\\", \\\"{x:834,y:499,t:1527632195589};\\\", \\\"{x:827,y:500,t:1527632195601};\\\", \\\"{x:806,y:507,t:1527632195618};\\\", \\\"{x:779,y:512,t:1527632195635};\\\", \\\"{x:747,y:517,t:1527632195651};\\\", \\\"{x:718,y:521,t:1527632195668};\\\", \\\"{x:692,y:522,t:1527632195685};\\\", \\\"{x:681,y:522,t:1527632195700};\\\", \\\"{x:676,y:523,t:1527632195717};\\\", \\\"{x:673,y:523,t:1527632195734};\\\", \\\"{x:671,y:523,t:1527632195751};\\\", \\\"{x:665,y:526,t:1527632195768};\\\", \\\"{x:659,y:529,t:1527632195785};\\\", \\\"{x:652,y:531,t:1527632195801};\\\", \\\"{x:639,y:537,t:1527632195818};\\\", \\\"{x:616,y:547,t:1527632195835};\\\", \\\"{x:589,y:556,t:1527632195852};\\\", \\\"{x:551,y:567,t:1527632195868};\\\", \\\"{x:482,y:585,t:1527632195885};\\\", \\\"{x:444,y:595,t:1527632195901};\\\", \\\"{x:410,y:600,t:1527632195917};\\\", \\\"{x:379,y:605,t:1527632195935};\\\", \\\"{x:356,y:607,t:1527632195951};\\\", \\\"{x:337,y:610,t:1527632195968};\\\", \\\"{x:331,y:611,t:1527632195985};\\\", \\\"{x:330,y:611,t:1527632196001};\\\", \\\"{x:335,y:607,t:1527632196109};\\\", \\\"{x:340,y:605,t:1527632196118};\\\", \\\"{x:357,y:597,t:1527632196136};\\\", \\\"{x:376,y:590,t:1527632196152};\\\", \\\"{x:389,y:584,t:1527632196168};\\\", \\\"{x:400,y:580,t:1527632196185};\\\", \\\"{x:406,y:578,t:1527632196202};\\\", \\\"{x:413,y:575,t:1527632196217};\\\", \\\"{x:415,y:575,t:1527632196234};\\\", \\\"{x:417,y:575,t:1527632196252};\\\", \\\"{x:417,y:574,t:1527632196268};\\\", \\\"{x:416,y:574,t:1527632196470};\\\", \\\"{x:410,y:576,t:1527632196486};\\\", \\\"{x:405,y:577,t:1527632196501};\\\", \\\"{x:401,y:579,t:1527632196519};\\\", \\\"{x:397,y:581,t:1527632196535};\\\", \\\"{x:394,y:582,t:1527632196553};\\\", \\\"{x:391,y:582,t:1527632196569};\\\", \\\"{x:389,y:584,t:1527632196585};\\\", \\\"{x:386,y:585,t:1527632196602};\\\", \\\"{x:383,y:586,t:1527632196618};\\\", \\\"{x:378,y:587,t:1527632196635};\\\", \\\"{x:374,y:588,t:1527632196652};\\\", \\\"{x:369,y:588,t:1527632196668};\\\", \\\"{x:364,y:588,t:1527632196685};\\\", \\\"{x:358,y:588,t:1527632196702};\\\", \\\"{x:352,y:588,t:1527632196718};\\\", \\\"{x:344,y:588,t:1527632196736};\\\", \\\"{x:332,y:588,t:1527632196751};\\\", \\\"{x:313,y:586,t:1527632196768};\\\", \\\"{x:298,y:583,t:1527632196785};\\\", \\\"{x:282,y:578,t:1527632196801};\\\", \\\"{x:263,y:570,t:1527632196819};\\\", \\\"{x:245,y:564,t:1527632196836};\\\", \\\"{x:228,y:559,t:1527632196852};\\\", \\\"{x:206,y:553,t:1527632196868};\\\", \\\"{x:199,y:551,t:1527632196885};\\\", \\\"{x:198,y:551,t:1527632196902};\\\", \\\"{x:195,y:551,t:1527632197070};\\\", \\\"{x:192,y:551,t:1527632197086};\\\", \\\"{x:189,y:551,t:1527632197102};\\\", \\\"{x:187,y:551,t:1527632197119};\\\", \\\"{x:184,y:551,t:1527632197136};\\\", \\\"{x:182,y:551,t:1527632197152};\\\", \\\"{x:179,y:551,t:1527632197169};\\\", \\\"{x:176,y:551,t:1527632197186};\\\", \\\"{x:173,y:549,t:1527632197203};\\\", \\\"{x:171,y:549,t:1527632197219};\\\", \\\"{x:169,y:548,t:1527632197236};\\\", \\\"{x:169,y:547,t:1527632198366};\\\", \\\"{x:173,y:546,t:1527632198374};\\\", \\\"{x:180,y:546,t:1527632198387};\\\", \\\"{x:193,y:547,t:1527632198404};\\\", \\\"{x:213,y:556,t:1527632198420};\\\", \\\"{x:242,y:571,t:1527632198436};\\\", \\\"{x:262,y:581,t:1527632198453};\\\", \\\"{x:275,y:591,t:1527632198470};\\\", \\\"{x:286,y:597,t:1527632198488};\\\", \\\"{x:294,y:601,t:1527632198503};\\\", \\\"{x:303,y:608,t:1527632198520};\\\", \\\"{x:309,y:613,t:1527632198537};\\\", \\\"{x:313,y:618,t:1527632198554};\\\", \\\"{x:316,y:621,t:1527632198570};\\\", \\\"{x:319,y:627,t:1527632198586};\\\", \\\"{x:323,y:631,t:1527632198603};\\\", \\\"{x:327,y:635,t:1527632198620};\\\", \\\"{x:342,y:646,t:1527632198638};\\\", \\\"{x:357,y:657,t:1527632198654};\\\", \\\"{x:375,y:669,t:1527632198669};\\\", \\\"{x:396,y:681,t:1527632198688};\\\", \\\"{x:414,y:691,t:1527632198704};\\\", \\\"{x:433,y:701,t:1527632198720};\\\", \\\"{x:446,y:706,t:1527632198736};\\\", \\\"{x:452,y:709,t:1527632198754};\\\", \\\"{x:456,y:711,t:1527632198771};\\\", \\\"{x:461,y:714,t:1527632198787};\\\", \\\"{x:463,y:715,t:1527632198804};\\\", \\\"{x:468,y:720,t:1527632198822};\\\", \\\"{x:477,y:726,t:1527632198837};\\\", \\\"{x:487,y:733,t:1527632198854};\\\", \\\"{x:503,y:744,t:1527632198870};\\\", \\\"{x:513,y:750,t:1527632198887};\\\", \\\"{x:518,y:754,t:1527632198904};\\\", \\\"{x:520,y:757,t:1527632198920};\\\", \\\"{x:521,y:757,t:1527632198937};\\\", \\\"{x:521,y:758,t:1527632199028};\\\", \\\"{x:521,y:759,t:1527632199052};\\\", \\\"{x:519,y:760,t:1527632199085};\\\", \\\"{x:518,y:760,t:1527632199109};\\\", \\\"{x:517,y:760,t:1527632199132};\\\", \\\"{x:516,y:760,t:1527632199181};\\\", \\\"{x:516,y:759,t:1527632199238};\\\", \\\"{x:515,y:759,t:1527632199317};\\\", \\\"{x:514,y:759,t:1527632199389};\\\", \\\"{x:513,y:760,t:1527632199429};\\\", \\\"{x:512,y:760,t:1527632199485};\\\", \\\"{x:511,y:760,t:1527632199581};\\\", \\\"{x:510,y:760,t:1527632199596};\\\", \\\"{x:509,y:760,t:1527632199629};\\\", \\\"{x:508,y:760,t:1527632199710};\\\", \\\"{x:507,y:760,t:1527632200302};\\\", \\\"{x:505,y:761,t:1527632200309};\\\", \\\"{x:504,y:761,t:1527632200333};\\\", \\\"{x:503,y:761,t:1527632200341};\\\", \\\"{x:502,y:761,t:1527632200356};\\\", \\\"{x:500,y:761,t:1527632200372};\\\", \\\"{x:499,y:761,t:1527632200389};\\\", \\\"{x:498,y:761,t:1527632200429};\\\", \\\"{x:496,y:761,t:1527632200453};\\\", \\\"{x:494,y:761,t:1527632200590};\\\", \\\"{x:492,y:760,t:1527632203846};\\\", \\\"{x:491,y:758,t:1527632203859};\\\", \\\"{x:489,y:757,t:1527632203875};\\\", \\\"{x:488,y:756,t:1527632203891};\\\", \\\"{x:487,y:755,t:1527632203907};\\\", \\\"{x:486,y:753,t:1527632203924};\\\", \\\"{x:486,y:750,t:1527632203940};\\\", \\\"{x:486,y:749,t:1527632203964};\\\", \\\"{x:486,y:748,t:1527632203974};\\\", \\\"{x:486,y:747,t:1527632203991};\\\", \\\"{x:486,y:746,t:1527632204008};\\\", \\\"{x:486,y:744,t:1527632204025};\\\" ] }, { \\\"rt\\\": 34352, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 394226, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"8TUB0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 AM-09 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:485,y:743,t:1527632206072};\\\", \\\"{x:484,y:743,t:1527632206132};\\\", \\\"{x:483,y:743,t:1527632206176};\\\", \\\"{x:482,y:742,t:1527632222450};\\\", \\\"{x:476,y:734,t:1527632222457};\\\", \\\"{x:470,y:726,t:1527632222473};\\\", \\\"{x:454,y:708,t:1527632222489};\\\", \\\"{x:449,y:703,t:1527632222504};\\\", \\\"{x:443,y:698,t:1527632222522};\\\", \\\"{x:439,y:694,t:1527632222538};\\\", \\\"{x:436,y:691,t:1527632222554};\\\", \\\"{x:435,y:691,t:1527632222571};\\\", \\\"{x:433,y:690,t:1527632222588};\\\", \\\"{x:433,y:689,t:1527632222604};\\\", \\\"{x:432,y:688,t:1527632222621};\\\", \\\"{x:431,y:688,t:1527632222638};\\\", \\\"{x:430,y:687,t:1527632222655};\\\", \\\"{x:430,y:686,t:1527632222680};\\\", \\\"{x:434,y:690,t:1527632228977};\\\", \\\"{x:453,y:703,t:1527632228992};\\\", \\\"{x:547,y:758,t:1527632229009};\\\", \\\"{x:613,y:786,t:1527632229025};\\\", \\\"{x:701,y:824,t:1527632229041};\\\", \\\"{x:851,y:884,t:1527632229065};\\\", \\\"{x:947,y:927,t:1527632229082};\\\", \\\"{x:1019,y:958,t:1527632229099};\\\", \\\"{x:1082,y:984,t:1527632229115};\\\", \\\"{x:1124,y:1004,t:1527632229132};\\\", \\\"{x:1141,y:1010,t:1527632229149};\\\", \\\"{x:1146,y:1013,t:1527632229164};\\\", \\\"{x:1147,y:1013,t:1527632229181};\\\", \\\"{x:1149,y:1013,t:1527632229225};\\\", \\\"{x:1150,y:1010,t:1527632229232};\\\", \\\"{x:1155,y:997,t:1527632229248};\\\", \\\"{x:1161,y:983,t:1527632229266};\\\", \\\"{x:1172,y:963,t:1527632229283};\\\", \\\"{x:1182,y:944,t:1527632229299};\\\", \\\"{x:1192,y:928,t:1527632229316};\\\", \\\"{x:1197,y:915,t:1527632229332};\\\", \\\"{x:1199,y:905,t:1527632229349};\\\", \\\"{x:1200,y:894,t:1527632229364};\\\", \\\"{x:1200,y:881,t:1527632229382};\\\", \\\"{x:1200,y:871,t:1527632229399};\\\", \\\"{x:1199,y:857,t:1527632229415};\\\", \\\"{x:1199,y:836,t:1527632229432};\\\", \\\"{x:1199,y:822,t:1527632229448};\\\", \\\"{x:1200,y:808,t:1527632229464};\\\", \\\"{x:1207,y:796,t:1527632229481};\\\", \\\"{x:1216,y:781,t:1527632229499};\\\", \\\"{x:1223,y:771,t:1527632229516};\\\", \\\"{x:1233,y:761,t:1527632229531};\\\", \\\"{x:1245,y:751,t:1527632229549};\\\", \\\"{x:1256,y:745,t:1527632229565};\\\", \\\"{x:1268,y:740,t:1527632229581};\\\", \\\"{x:1277,y:735,t:1527632229599};\\\", \\\"{x:1291,y:730,t:1527632229616};\\\", \\\"{x:1305,y:725,t:1527632229632};\\\", \\\"{x:1315,y:721,t:1527632229649};\\\", \\\"{x:1320,y:719,t:1527632229665};\\\", \\\"{x:1321,y:719,t:1527632229682};\\\", \\\"{x:1322,y:719,t:1527632230023};\\\", \\\"{x:1323,y:719,t:1527632230040};\\\", \\\"{x:1323,y:720,t:1527632230049};\\\", \\\"{x:1324,y:722,t:1527632230066};\\\", \\\"{x:1325,y:725,t:1527632230083};\\\", \\\"{x:1326,y:726,t:1527632230104};\\\", \\\"{x:1326,y:727,t:1527632230120};\\\", \\\"{x:1326,y:728,t:1527632230232};\\\", \\\"{x:1326,y:730,t:1527632232921};\\\", \\\"{x:1325,y:730,t:1527632232952};\\\", \\\"{x:1325,y:731,t:1527632232985};\\\", \\\"{x:1324,y:731,t:1527632233009};\\\", \\\"{x:1322,y:731,t:1527632233019};\\\", \\\"{x:1320,y:732,t:1527632233035};\\\", \\\"{x:1317,y:732,t:1527632233052};\\\", \\\"{x:1314,y:734,t:1527632233068};\\\", \\\"{x:1313,y:734,t:1527632233085};\\\", \\\"{x:1311,y:735,t:1527632233103};\\\", \\\"{x:1310,y:735,t:1527632233119};\\\", \\\"{x:1309,y:735,t:1527632233135};\\\", \\\"{x:1307,y:735,t:1527632233153};\\\", \\\"{x:1306,y:735,t:1527632233169};\\\", \\\"{x:1305,y:735,t:1527632233186};\\\", \\\"{x:1304,y:735,t:1527632233203};\\\", \\\"{x:1303,y:735,t:1527632233241};\\\", \\\"{x:1303,y:736,t:1527632234528};\\\", \\\"{x:1302,y:736,t:1527632234536};\\\", \\\"{x:1301,y:737,t:1527632234553};\\\", \\\"{x:1299,y:738,t:1527632234569};\\\", \\\"{x:1298,y:738,t:1527632234586};\\\", \\\"{x:1296,y:738,t:1527632234603};\\\", \\\"{x:1296,y:739,t:1527632234632};\\\", \\\"{x:1295,y:739,t:1527632234656};\\\", \\\"{x:1294,y:739,t:1527632234681};\\\", \\\"{x:1293,y:740,t:1527632234689};\\\", \\\"{x:1292,y:740,t:1527632234833};\\\", \\\"{x:1291,y:741,t:1527632234915};\\\", \\\"{x:1288,y:741,t:1527632235537};\\\", \\\"{x:1264,y:735,t:1527632235553};\\\", \\\"{x:1183,y:712,t:1527632235571};\\\", \\\"{x:1056,y:672,t:1527632235588};\\\", \\\"{x:904,y:628,t:1527632235604};\\\", \\\"{x:722,y:578,t:1527632235622};\\\", \\\"{x:542,y:523,t:1527632235637};\\\", \\\"{x:246,y:435,t:1527632235671};\\\", \\\"{x:160,y:414,t:1527632235687};\\\", \\\"{x:117,y:401,t:1527632235704};\\\", \\\"{x:115,y:401,t:1527632235719};\\\", \\\"{x:114,y:401,t:1527632235737};\\\", \\\"{x:113,y:403,t:1527632235808};\\\", \\\"{x:111,y:408,t:1527632235820};\\\", \\\"{x:108,y:421,t:1527632235837};\\\", \\\"{x:108,y:436,t:1527632235855};\\\", \\\"{x:113,y:454,t:1527632235870};\\\", \\\"{x:125,y:472,t:1527632235887};\\\", \\\"{x:141,y:488,t:1527632235904};\\\", \\\"{x:153,y:497,t:1527632235920};\\\", \\\"{x:167,y:506,t:1527632235938};\\\", \\\"{x:181,y:515,t:1527632235955};\\\", \\\"{x:198,y:524,t:1527632235971};\\\", \\\"{x:211,y:529,t:1527632235987};\\\", \\\"{x:223,y:534,t:1527632236005};\\\", \\\"{x:227,y:535,t:1527632236020};\\\", \\\"{x:231,y:536,t:1527632236037};\\\", \\\"{x:231,y:537,t:1527632236054};\\\", \\\"{x:233,y:537,t:1527632236071};\\\", \\\"{x:234,y:537,t:1527632236088};\\\", \\\"{x:236,y:537,t:1527632236104};\\\", \\\"{x:238,y:537,t:1527632236122};\\\", \\\"{x:241,y:538,t:1527632236137};\\\", \\\"{x:248,y:540,t:1527632236155};\\\", \\\"{x:257,y:541,t:1527632236171};\\\", \\\"{x:270,y:543,t:1527632236188};\\\", \\\"{x:286,y:546,t:1527632236205};\\\", \\\"{x:304,y:548,t:1527632236221};\\\", \\\"{x:324,y:551,t:1527632236237};\\\", \\\"{x:341,y:553,t:1527632236254};\\\", \\\"{x:359,y:556,t:1527632236272};\\\", \\\"{x:392,y:559,t:1527632236289};\\\", \\\"{x:416,y:563,t:1527632236304};\\\", \\\"{x:440,y:567,t:1527632236322};\\\", \\\"{x:469,y:571,t:1527632236338};\\\", \\\"{x:497,y:576,t:1527632236354};\\\", \\\"{x:520,y:582,t:1527632236371};\\\", \\\"{x:540,y:585,t:1527632236387};\\\", \\\"{x:557,y:585,t:1527632236404};\\\", \\\"{x:571,y:584,t:1527632236421};\\\", \\\"{x:583,y:579,t:1527632236438};\\\", \\\"{x:593,y:573,t:1527632236455};\\\", \\\"{x:605,y:563,t:1527632236471};\\\", \\\"{x:625,y:549,t:1527632236487};\\\", \\\"{x:634,y:541,t:1527632236505};\\\", \\\"{x:639,y:534,t:1527632236522};\\\", \\\"{x:641,y:529,t:1527632236538};\\\", \\\"{x:642,y:527,t:1527632236554};\\\", \\\"{x:643,y:525,t:1527632236571};\\\", \\\"{x:643,y:524,t:1527632236588};\\\", \\\"{x:643,y:521,t:1527632236604};\\\", \\\"{x:643,y:520,t:1527632236621};\\\", \\\"{x:641,y:518,t:1527632236638};\\\", \\\"{x:640,y:516,t:1527632236654};\\\", \\\"{x:640,y:514,t:1527632236671};\\\", \\\"{x:638,y:513,t:1527632236696};\\\", \\\"{x:637,y:513,t:1527632236792};\\\", \\\"{x:637,y:512,t:1527632237048};\\\", \\\"{x:635,y:512,t:1527632237055};\\\", \\\"{x:633,y:513,t:1527632237071};\\\", \\\"{x:624,y:515,t:1527632237088};\\\", \\\"{x:620,y:516,t:1527632237105};\\\", \\\"{x:618,y:516,t:1527632237121};\\\", \\\"{x:617,y:517,t:1527632237152};\\\", \\\"{x:616,y:517,t:1527632237168};\\\", \\\"{x:614,y:517,t:1527632237176};\\\", \\\"{x:613,y:518,t:1527632237188};\\\", \\\"{x:607,y:520,t:1527632237205};\\\", \\\"{x:599,y:523,t:1527632237222};\\\", \\\"{x:592,y:526,t:1527632237238};\\\", \\\"{x:583,y:532,t:1527632237255};\\\", \\\"{x:568,y:539,t:1527632237272};\\\", \\\"{x:547,y:549,t:1527632237288};\\\", \\\"{x:533,y:554,t:1527632237305};\\\", \\\"{x:522,y:559,t:1527632237322};\\\", \\\"{x:507,y:566,t:1527632237338};\\\", \\\"{x:498,y:569,t:1527632237356};\\\", \\\"{x:490,y:573,t:1527632237373};\\\", \\\"{x:479,y:578,t:1527632237388};\\\", \\\"{x:473,y:581,t:1527632237405};\\\", \\\"{x:468,y:583,t:1527632237422};\\\", \\\"{x:464,y:585,t:1527632237438};\\\", \\\"{x:459,y:587,t:1527632237455};\\\", \\\"{x:445,y:591,t:1527632237472};\\\", \\\"{x:430,y:596,t:1527632237488};\\\", \\\"{x:415,y:597,t:1527632237506};\\\", \\\"{x:401,y:598,t:1527632237522};\\\", \\\"{x:389,y:601,t:1527632237539};\\\", \\\"{x:375,y:602,t:1527632237555};\\\", \\\"{x:356,y:602,t:1527632237572};\\\", \\\"{x:339,y:602,t:1527632237589};\\\", \\\"{x:324,y:602,t:1527632237605};\\\", \\\"{x:311,y:602,t:1527632237622};\\\", \\\"{x:302,y:602,t:1527632237638};\\\", \\\"{x:298,y:602,t:1527632237655};\\\", \\\"{x:282,y:606,t:1527632237671};\\\", \\\"{x:270,y:609,t:1527632237689};\\\", \\\"{x:260,y:612,t:1527632237705};\\\", \\\"{x:253,y:612,t:1527632237722};\\\", \\\"{x:243,y:615,t:1527632237739};\\\", \\\"{x:233,y:616,t:1527632237755};\\\", \\\"{x:223,y:619,t:1527632237772};\\\", \\\"{x:208,y:621,t:1527632237789};\\\", \\\"{x:195,y:625,t:1527632237805};\\\", \\\"{x:182,y:629,t:1527632237823};\\\", \\\"{x:172,y:631,t:1527632237839};\\\", \\\"{x:163,y:634,t:1527632237855};\\\", \\\"{x:150,y:638,t:1527632237872};\\\", \\\"{x:142,y:639,t:1527632237890};\\\", \\\"{x:140,y:639,t:1527632237905};\\\", \\\"{x:139,y:639,t:1527632237922};\\\", \\\"{x:137,y:640,t:1527632237939};\\\", \\\"{x:141,y:640,t:1527632238089};\\\", \\\"{x:153,y:632,t:1527632238106};\\\", \\\"{x:162,y:623,t:1527632238122};\\\", \\\"{x:166,y:616,t:1527632238139};\\\", \\\"{x:168,y:612,t:1527632238156};\\\", \\\"{x:168,y:607,t:1527632238172};\\\", \\\"{x:168,y:605,t:1527632238188};\\\", \\\"{x:168,y:603,t:1527632238206};\\\", \\\"{x:168,y:601,t:1527632238222};\\\", \\\"{x:166,y:600,t:1527632238239};\\\", \\\"{x:166,y:599,t:1527632238256};\\\", \\\"{x:165,y:598,t:1527632238272};\\\", \\\"{x:164,y:597,t:1527632238296};\\\", \\\"{x:164,y:596,t:1527632238306};\\\", \\\"{x:163,y:595,t:1527632238322};\\\", \\\"{x:162,y:591,t:1527632238339};\\\", \\\"{x:161,y:589,t:1527632238356};\\\", \\\"{x:160,y:587,t:1527632238372};\\\", \\\"{x:159,y:585,t:1527632238389};\\\", \\\"{x:159,y:584,t:1527632238415};\\\", \\\"{x:159,y:582,t:1527632238433};\\\", \\\"{x:159,y:581,t:1527632238439};\\\", \\\"{x:159,y:579,t:1527632238456};\\\", \\\"{x:159,y:574,t:1527632238473};\\\", \\\"{x:159,y:572,t:1527632238489};\\\", \\\"{x:159,y:569,t:1527632238506};\\\", \\\"{x:159,y:566,t:1527632238523};\\\", \\\"{x:159,y:563,t:1527632238540};\\\", \\\"{x:159,y:562,t:1527632238556};\\\", \\\"{x:159,y:561,t:1527632238573};\\\", \\\"{x:166,y:563,t:1527632238984};\\\", \\\"{x:183,y:571,t:1527632238992};\\\", \\\"{x:201,y:578,t:1527632239007};\\\", \\\"{x:239,y:593,t:1527632239023};\\\", \\\"{x:316,y:622,t:1527632239041};\\\", \\\"{x:359,y:637,t:1527632239056};\\\", \\\"{x:389,y:650,t:1527632239074};\\\", \\\"{x:405,y:659,t:1527632239090};\\\", \\\"{x:411,y:662,t:1527632239106};\\\", \\\"{x:413,y:665,t:1527632239123};\\\", \\\"{x:415,y:669,t:1527632239140};\\\", \\\"{x:416,y:671,t:1527632239156};\\\", \\\"{x:417,y:674,t:1527632239173};\\\", \\\"{x:419,y:676,t:1527632239191};\\\", \\\"{x:420,y:677,t:1527632239248};\\\", \\\"{x:420,y:680,t:1527632239272};\\\", \\\"{x:423,y:683,t:1527632239280};\\\", \\\"{x:424,y:686,t:1527632239292};\\\", \\\"{x:429,y:693,t:1527632239306};\\\", \\\"{x:438,y:700,t:1527632239324};\\\", \\\"{x:451,y:710,t:1527632239340};\\\", \\\"{x:462,y:717,t:1527632239356};\\\", \\\"{x:472,y:724,t:1527632239373};\\\", \\\"{x:476,y:726,t:1527632239390};\\\", \\\"{x:477,y:727,t:1527632239406};\\\", \\\"{x:478,y:728,t:1527632239424};\\\", \\\"{x:478,y:730,t:1527632239617};\\\", \\\"{x:478,y:731,t:1527632239624};\\\", \\\"{x:478,y:735,t:1527632239642};\\\", \\\"{x:478,y:737,t:1527632239657};\\\", \\\"{x:478,y:738,t:1527632239673};\\\", \\\"{x:478,y:740,t:1527632239690};\\\", \\\"{x:478,y:741,t:1527632240352};\\\", \\\"{x:478,y:742,t:1527632240440};\\\", \\\"{x:477,y:742,t:1527632240641};\\\", \\\"{x:476,y:742,t:1527632240664};\\\", \\\"{x:475,y:743,t:1527632240697};\\\" ] }, { \\\"rt\\\": 28060, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 423503, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"8TUB0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"i find 12 then look up the y axis\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 7270, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"21\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"usa\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 431777, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"8TUB0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 18286, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 451084, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"8TUB0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 16478, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 468650, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"8TUB0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"8TUB0\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 168, dom: 748, initialDom: 860",
  "javascriptErrors": []
}