var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052947180fd4331d34c0dc26ca99e7830844a16c"] = {
  "startTime": "2018-05-29T17:06:47.3943819Z",
  "websitePageUrl": "/",
  "visitTime": 26176,
  "engagementTime": 26176,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1050,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "1b03714cdeb0f17c5ffe697409502bdd",
    "created": "2018-05-29T17:06:47.2887354+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "dc32be8bd3076e3a5cad5de9a9dd2e3a",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/1b03714cdeb0f17c5ffe697409502bdd/play"
  },
  "events": [
    {
      "t": 67,
      "e": 67,
      "ty": 14,
      "x": 0,
      "y": 1049
    },
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1050
    },
    {
      "t": 101,
      "e": 101,
      "ty": 2,
      "x": 461,
      "y": 27
    },
    {
      "t": 201,
      "e": 201,
      "ty": 2,
      "x": 470,
      "y": 56
    },
    {
      "t": 251,
      "e": 251,
      "ty": 41,
      "x": 16082,
      "y": 7232,
      "ta": "html > body"
    },
    {
      "t": 300,
      "e": 300,
      "ty": 2,
      "x": 496,
      "y": 177
    },
    {
      "t": 401,
      "e": 401,
      "ty": 2,
      "x": 645,
      "y": 341
    },
    {
      "t": 501,
      "e": 501,
      "ty": 2,
      "x": 1103,
      "y": 598
    },
    {
      "t": 502,
      "e": 502,
      "ty": 41,
      "x": 40604,
      "y": 38788,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 601,
      "e": 601,
      "ty": 2,
      "x": 1160,
      "y": 749
    },
    {
      "t": 701,
      "e": 701,
      "ty": 2,
      "x": 1161,
      "y": 750
    },
    {
      "t": 751,
      "e": 751,
      "ty": 41,
      "x": 43771,
      "y": 51240,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2082,
      "e": 2082,
      "ty": 3,
      "x": 1161,
      "y": 750,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2145,
      "e": 2145,
      "ty": 4,
      "x": 43771,
      "y": 51240,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2145,
      "e": 2145,
      "ty": 5,
      "x": 1161,
      "y": 750,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2701,
      "e": 2701,
      "ty": 2,
      "x": 1452,
      "y": 469
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 56409,
      "y": 22077,
      "ta": "html > body"
    },
    {
      "t": 2801,
      "e": 2801,
      "ty": 2,
      "x": 1666,
      "y": 345
    },
    {
      "t": 3002,
      "e": 3002,
      "ty": 41,
      "x": 57097,
      "y": 21379,
      "ta": "html > body"
    },
    {
      "t": 3185,
      "e": 3185,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 3201,
      "e": 3201,
      "ty": 2,
      "x": 1748,
      "y": 21
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 59921,
      "y": 824,
      "ta": "html > body"
    },
    {
      "t": 3901,
      "e": 3901,
      "ty": 2,
      "x": 1774,
      "y": 18
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 2,
      "x": 1739,
      "y": 120
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 41,
      "x": 59611,
      "y": 7105,
      "ta": "html > body"
    },
    {
      "t": 4101,
      "e": 4101,
      "ty": 2,
      "x": 1773,
      "y": 223
    },
    {
      "t": 4201,
      "e": 4201,
      "ty": 2,
      "x": 1776,
      "y": 230
    },
    {
      "t": 4252,
      "e": 4252,
      "ty": 41,
      "x": 60885,
      "y": 14147,
      "ta": "html > body"
    },
    {
      "t": 4301,
      "e": 4301,
      "ty": 2,
      "x": 1767,
      "y": 245
    },
    {
      "t": 4401,
      "e": 4401,
      "ty": 2,
      "x": 1725,
      "y": 284
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 0,
      "x": 1920,
      "y": 1156
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 2,
      "x": 1712,
      "y": 284
    },
    {
      "t": 4502,
      "e": 4502,
      "ty": 41,
      "x": 58681,
      "y": 15880,
      "ta": "html > body"
    },
    {
      "t": 4600,
      "e": 4600,
      "ty": 2,
      "x": 1415,
      "y": 331
    },
    {
      "t": 4701,
      "e": 4701,
      "ty": 2,
      "x": 1024,
      "y": 432
    },
    {
      "t": 4751,
      "e": 4751,
      "ty": 41,
      "x": 33067,
      "y": 25108,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 4800,
      "e": 4800,
      "ty": 2,
      "x": 943,
      "y": 517
    },
    {
      "t": 4901,
      "e": 4901,
      "ty": 2,
      "x": 931,
      "y": 531
    },
    {
      "t": 4961,
      "e": 4961,
      "ty": 3,
      "x": 931,
      "y": 531,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 41,
      "x": 31211,
      "y": 28958,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5024,
      "e": 5024,
      "ty": 4,
      "x": 31211,
      "y": 28958,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5024,
      "e": 5024,
      "ty": 5,
      "x": 931,
      "y": 531,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5505,
      "e": 5505,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 5601,
      "e": 5601,
      "ty": 1,
      "x": 0,
      "y": 11
    },
    {
      "t": 5701,
      "e": 5701,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 6595,
      "e": 6595,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 6616,
      "e": 6616,
      "ty": 2,
      "x": 928,
      "y": 525
    },
    {
      "t": 6701,
      "e": 6701,
      "ty": 2,
      "x": 943,
      "y": 466
    },
    {
      "t": 6751,
      "e": 6751,
      "ty": 41,
      "x": 32939,
      "y": 14303,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 6801,
      "e": 6801,
      "ty": 2,
      "x": 1003,
      "y": 380
    },
    {
      "t": 6901,
      "e": 6901,
      "ty": 2,
      "x": 1072,
      "y": 293
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 2,
      "x": 1072,
      "y": 292
    },
    {
      "t": 7002,
      "e": 7002,
      "ty": 41,
      "x": 38302,
      "y": 10142,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 7101,
      "e": 7101,
      "ty": 2,
      "x": 1019,
      "y": 431
    },
    {
      "t": 7200,
      "e": 7200,
      "ty": 2,
      "x": 820,
      "y": 1106
    },
    {
      "t": 7251,
      "e": 7251,
      "ty": 41,
      "x": 27343,
      "y": 64211,
      "ta": "> div.masterdiv"
    },
    {
      "t": 7301,
      "e": 7301,
      "ty": 2,
      "x": 785,
      "y": 1097
    },
    {
      "t": 7400,
      "e": 7400,
      "ty": 2,
      "x": 809,
      "y": 942
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 2,
      "x": 840,
      "y": 891
    },
    {
      "t": 7502,
      "e": 7502,
      "ty": 41,
      "x": 7677,
      "y": 14894,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 7601,
      "e": 7601,
      "ty": 2,
      "x": 843,
      "y": 884
    },
    {
      "t": 7701,
      "e": 7701,
      "ty": 2,
      "x": 839,
      "y": 885
    },
    {
      "t": 7751,
      "e": 7751,
      "ty": 41,
      "x": 6627,
      "y": 5957,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 7801,
      "e": 7801,
      "ty": 2,
      "x": 824,
      "y": 895
    },
    {
      "t": 7901,
      "e": 7901,
      "ty": 2,
      "x": 819,
      "y": 897
    },
    {
      "t": 7938,
      "e": 7938,
      "ty": 3,
      "x": 819,
      "y": 897,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 8000,
      "e": 8000,
      "ty": 4,
      "x": 50994,
      "y": 26214,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 8000,
      "e": 8000,
      "ty": 5,
      "x": 819,
      "y": 897,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 8001,
      "e": 8001,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 8005,
      "e": 8005,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 8006,
      "e": 8006,
      "ty": 41,
      "x": 50994,
      "y": 26214,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 8101,
      "e": 8101,
      "ty": 2,
      "x": 822,
      "y": 905
    },
    {
      "t": 8200,
      "e": 8200,
      "ty": 2,
      "x": 939,
      "y": 993
    },
    {
      "t": 8251,
      "e": 8251,
      "ty": 41,
      "x": 32349,
      "y": 64161,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 8301,
      "e": 8301,
      "ty": 2,
      "x": 953,
      "y": 1017
    },
    {
      "t": 8401,
      "e": 8401,
      "ty": 2,
      "x": 954,
      "y": 1017
    },
    {
      "t": 8501,
      "e": 8501,
      "ty": 2,
      "x": 956,
      "y": 1032
    },
    {
      "t": 8501,
      "e": 8501,
      "ty": 41,
      "x": 32595,
      "y": 65456,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 8515,
      "e": 8515,
      "ty": 6,
      "x": 957,
      "y": 1038,
      "ta": "#start"
    },
    {
      "t": 8601,
      "e": 8601,
      "ty": 2,
      "x": 958,
      "y": 1043
    },
    {
      "t": 8665,
      "e": 8665,
      "ty": 3,
      "x": 958,
      "y": 1043,
      "ta": "#start"
    },
    {
      "t": 8666,
      "e": 8666,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 8666,
      "e": 8666,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 8737,
      "e": 8737,
      "ty": 4,
      "x": 26487,
      "y": 19094,
      "ta": "#start"
    },
    {
      "t": 8739,
      "e": 8739,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 8740,
      "e": 8740,
      "ty": 5,
      "x": 958,
      "y": 1043,
      "ta": "#start"
    },
    {
      "t": 8741,
      "e": 8741,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 8751,
      "e": 8751,
      "ty": 41,
      "x": 32715,
      "y": 59551,
      "ta": "html > body"
    },
    {
      "t": 9001,
      "e": 9001,
      "ty": 2,
      "x": 862,
      "y": 925
    },
    {
      "t": 9001,
      "e": 9001,
      "ty": 41,
      "x": 29409,
      "y": 52761,
      "ta": "html > body"
    },
    {
      "t": 9101,
      "e": 9101,
      "ty": 2,
      "x": 817,
      "y": 871
    },
    {
      "t": 9201,
      "e": 9201,
      "ty": 2,
      "x": 766,
      "y": 786
    },
    {
      "t": 9251,
      "e": 9251,
      "ty": 41,
      "x": 24588,
      "y": 42405,
      "ta": "html > body"
    },
    {
      "t": 9301,
      "e": 9301,
      "ty": 2,
      "x": 719,
      "y": 740
    },
    {
      "t": 9401,
      "e": 9401,
      "ty": 2,
      "x": 719,
      "y": 737
    },
    {
      "t": 9501,
      "e": 9501,
      "ty": 2,
      "x": 693,
      "y": 743
    },
    {
      "t": 9501,
      "e": 9501,
      "ty": 41,
      "x": 23589,
      "y": 42289,
      "ta": "html > body"
    },
    {
      "t": 9601,
      "e": 9601,
      "ty": 2,
      "x": 669,
      "y": 750
    },
    {
      "t": 9701,
      "e": 9701,
      "ty": 2,
      "x": 666,
      "y": 751
    },
    {
      "t": 9742,
      "e": 9742,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 9751,
      "e": 9751,
      "ty": 41,
      "x": 22660,
      "y": 42750,
      "ta": "html > body"
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 2,
      "x": 641,
      "y": 767
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 41,
      "x": 21799,
      "y": 43670,
      "ta": "html > body"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10102,
      "e": 10102,
      "ty": 2,
      "x": 669,
      "y": 754
    },
    {
      "t": 10200,
      "e": 10200,
      "ty": 2,
      "x": 861,
      "y": 614
    },
    {
      "t": 10257,
      "e": 10257,
      "ty": 41,
      "x": 13193,
      "y": 2818,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 10301,
      "e": 10301,
      "ty": 2,
      "x": 870,
      "y": 592
    },
    {
      "t": 10331,
      "e": 10331,
      "ty": 6,
      "x": 875,
      "y": 584,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 10401,
      "e": 10401,
      "ty": 2,
      "x": 876,
      "y": 580
    },
    {
      "t": 10500,
      "e": 10500,
      "ty": 2,
      "x": 877,
      "y": 576
    },
    {
      "t": 10500,
      "e": 10500,
      "ty": 41,
      "x": 14923,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 10578,
      "e": 10578,
      "ty": 3,
      "x": 877,
      "y": 575,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 10578,
      "e": 10578,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 10600,
      "e": 10600,
      "ty": 2,
      "x": 877,
      "y": 575
    },
    {
      "t": 10632,
      "e": 10632,
      "ty": 4,
      "x": 14923,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 10632,
      "e": 10632,
      "ty": 5,
      "x": 877,
      "y": 575,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 10751,
      "e": 10751,
      "ty": 41,
      "x": 14923,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 11900,
      "e": 11900,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 11900,
      "e": 11900,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 11981,
      "e": 11981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "o"
    },
    {
      "t": 12085,
      "e": 12085,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "83"
    },
    {
      "t": 12086,
      "e": 12086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 12205,
      "e": 12205,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "os"
    },
    {
      "t": 12220,
      "e": 12220,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "os"
    },
    {
      "t": 12333,
      "e": 12333,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "67"
    },
    {
      "t": 12333,
      "e": 12333,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 12461,
      "e": 12461,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "osc"
    },
    {
      "t": 12533,
      "e": 12533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 12533,
      "e": 12533,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 12621,
      "e": 12621,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "osca"
    },
    {
      "t": 12677,
      "e": 12677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 12781,
      "e": 12781,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "osc"
    },
    {
      "t": 12884,
      "e": 12884,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 12932,
      "e": 12932,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "os"
    },
    {
      "t": 13044,
      "e": 13044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 13101,
      "e": 13101,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "o"
    },
    {
      "t": 13204,
      "e": 13204,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "o"
    },
    {
      "t": 13205,
      "e": 13205,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 13268,
      "e": 13268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": ""
    },
    {
      "t": 13389,
      "e": 13389,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 13485,
      "e": 13485,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": ""
    },
    {
      "t": 14237,
      "e": 14237,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 14238,
      "e": 14238,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 14292,
      "e": 14292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "O"
    },
    {
      "t": 14340,
      "e": 14340,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "83"
    },
    {
      "t": 14340,
      "e": 14340,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 14445,
      "e": 14445,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "67"
    },
    {
      "t": 14446,
      "e": 14446,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 14453,
      "e": 14453,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "OSC"
    },
    {
      "t": 14532,
      "e": 14532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "OSC"
    },
    {
      "t": 14589,
      "e": 14589,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 14589,
      "e": 14589,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 14717,
      "e": 14717,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 14718,
      "e": 14718,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 14725,
      "e": 14725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "OSCAR"
    },
    {
      "t": 14805,
      "e": 14805,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 14959,
      "e": 14959,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 15061,
      "e": 15061,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 15637,
      "e": 15637,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 15638,
      "e": 15638,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "OSCAR"
    },
    {
      "t": 15639,
      "e": 15639,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 15641,
      "e": 15641,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 15725,
      "e": 15725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 16965,
      "e": 16965,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 16965,
      "e": 16965,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 17013,
      "e": 17013,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 17126,
      "e": 17126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 17126,
      "e": 17126,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 17188,
      "e": 17188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 17292,
      "e": 17292,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "100"
    },
    {
      "t": 17293,
      "e": 17293,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 17357,
      "e": 17357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 17837,
      "e": 17837,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "191"
    },
    {
      "t": 17837,
      "e": 17837,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 17901,
      "e": 17901,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*\n"
    },
    {
      "t": 18004,
      "e": 18004,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*\n"
    },
    {
      "t": 19069,
      "e": 19069,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "191"
    },
    {
      "t": 19132,
      "e": 19132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 19730,
      "e": 19730,
      "ty": 7,
      "x": 877,
      "y": 591,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 19751,
      "e": 19751,
      "ty": 41,
      "x": 15356,
      "y": 7751,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 19792,
      "e": 19792,
      "ty": 6,
      "x": 898,
      "y": 664,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 19801,
      "e": 19801,
      "ty": 2,
      "x": 898,
      "y": 664
    },
    {
      "t": 19825,
      "e": 19825,
      "ty": 7,
      "x": 913,
      "y": 695,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 19825,
      "e": 19825,
      "ty": 6,
      "x": 913,
      "y": 695,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 19901,
      "e": 19901,
      "ty": 2,
      "x": 923,
      "y": 716
    },
    {
      "t": 20000,
      "e": 20000,
      "ty": 2,
      "x": 924,
      "y": 717
    },
    {
      "t": 20000,
      "e": 20000,
      "ty": 41,
      "x": 14471,
      "y": 61563,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 20000,
      "e": 20000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20128,
      "e": 20128,
      "ty": 3,
      "x": 924,
      "y": 717,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 20129,
      "e": 20129,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 20129,
      "e": 20129,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 20129,
      "e": 20129,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 20161,
      "e": 20161,
      "ty": 4,
      "x": 14471,
      "y": 61563,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 20161,
      "e": 20161,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 20162,
      "e": 20162,
      "ty": 5,
      "x": 924,
      "y": 717,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 20162,
      "e": 20162,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 20216,
      "e": 20216,
      "ty": 3,
      "x": 924,
      "y": 717,
      "ta": "html > body"
    },
    {
      "t": 20273,
      "e": 20273,
      "ty": 4,
      "x": 31544,
      "y": 40793,
      "ta": "html > body"
    },
    {
      "t": 20273,
      "e": 20273,
      "ty": 5,
      "x": 924,
      "y": 717,
      "ta": "html > body"
    },
    {
      "t": 20900,
      "e": 20900,
      "ty": 2,
      "x": 915,
      "y": 729
    },
    {
      "t": 21001,
      "e": 21001,
      "ty": 2,
      "x": 914,
      "y": 730
    },
    {
      "t": 21001,
      "e": 21001,
      "ty": 41,
      "x": 31200,
      "y": 41541,
      "ta": "html > body"
    },
    {
      "t": 21253,
      "e": 21253,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 21283,
      "e": 21283,
      "ty": 6,
      "x": 914,
      "y": 730,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 21301,
      "e": 21301,
      "ty": 2,
      "x": 912,
      "y": 730
    },
    {
      "t": 21401,
      "e": 21401,
      "ty": 2,
      "x": 911,
      "y": 729
    },
    {
      "t": 21501,
      "e": 21501,
      "ty": 2,
      "x": 913,
      "y": 719
    },
    {
      "t": 21501,
      "e": 21501,
      "ty": 41,
      "x": 29434,
      "y": 32767,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 21600,
      "e": 21600,
      "ty": 2,
      "x": 914,
      "y": 716
    },
    {
      "t": 21743,
      "e": 21743,
      "ty": 7,
      "x": 886,
      "y": 701,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 21743,
      "e": 21743,
      "ty": 6,
      "x": 886,
      "y": 701,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 21751,
      "e": 21751,
      "ty": 41,
      "x": 28066,
      "y": 56172,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 21776,
      "e": 21776,
      "ty": 7,
      "x": 672,
      "y": 656,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 21776,
      "e": 21776,
      "ty": 6,
      "x": 672,
      "y": 656,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 21792,
      "e": 21792,
      "ty": 7,
      "x": 455,
      "y": 626,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 21801,
      "e": 21801,
      "ty": 2,
      "x": 455,
      "y": 626
    },
    {
      "t": 21900,
      "e": 21900,
      "ty": 2,
      "x": 142,
      "y": 582
    },
    {
      "t": 22000,
      "e": 22000,
      "ty": 2,
      "x": 140,
      "y": 582
    },
    {
      "t": 22000,
      "e": 22000,
      "ty": 41,
      "x": 4545,
      "y": 33026,
      "ta": "> div.masterdiv"
    },
    {
      "t": 22076,
      "e": 22076,
      "ty": 6,
      "x": 298,
      "y": 652,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 22094,
      "e": 22094,
      "ty": 7,
      "x": 382,
      "y": 677,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 22094,
      "e": 22094,
      "ty": 6,
      "x": 382,
      "y": 677,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 22100,
      "e": 22100,
      "ty": 2,
      "x": 382,
      "y": 677
    },
    {
      "t": 22143,
      "e": 22143,
      "ty": 7,
      "x": 502,
      "y": 706,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 22143,
      "e": 22143,
      "ty": 6,
      "x": 502,
      "y": 706,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 22201,
      "e": 22201,
      "ty": 2,
      "x": 519,
      "y": 706
    },
    {
      "t": 22227,
      "e": 22227,
      "ty": 7,
      "x": 533,
      "y": 703,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 22228,
      "e": 22228,
      "ty": 6,
      "x": 533,
      "y": 703,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 22251,
      "e": 22251,
      "ty": 41,
      "x": 13019,
      "y": 60853,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 22261,
      "e": 22261,
      "ty": 7,
      "x": 663,
      "y": 711,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 22261,
      "e": 22261,
      "ty": 6,
      "x": 663,
      "y": 711,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 22294,
      "e": 22294,
      "ty": 7,
      "x": 784,
      "y": 761,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 22300,
      "e": 22300,
      "ty": 2,
      "x": 784,
      "y": 761
    },
    {
      "t": 22401,
      "e": 22401,
      "ty": 2,
      "x": 963,
      "y": 968
    },
    {
      "t": 22500,
      "e": 22500,
      "ty": 2,
      "x": 973,
      "y": 973
    },
    {
      "t": 22501,
      "e": 22501,
      "ty": 41,
      "x": 33431,
      "y": 61212,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 22600,
      "e": 22600,
      "ty": 2,
      "x": 974,
      "y": 1015
    },
    {
      "t": 22701,
      "e": 22701,
      "ty": 2,
      "x": 974,
      "y": 1023
    },
    {
      "t": 22751,
      "e": 22751,
      "ty": 41,
      "x": 33530,
      "y": 64952,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 22800,
      "e": 22800,
      "ty": 2,
      "x": 976,
      "y": 1029
    },
    {
      "t": 22845,
      "e": 22845,
      "ty": 6,
      "x": 976,
      "y": 1036,
      "ta": "#start"
    },
    {
      "t": 22901,
      "e": 22901,
      "ty": 2,
      "x": 976,
      "y": 1045
    },
    {
      "t": 22977,
      "e": 22977,
      "ty": 3,
      "x": 976,
      "y": 1045,
      "ta": "#start"
    },
    {
      "t": 22977,
      "e": 22977,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 23000,
      "e": 23000,
      "ty": 41,
      "x": 36317,
      "y": 22949,
      "ta": "#start"
    },
    {
      "t": 23056,
      "e": 23056,
      "ty": 4,
      "x": 36317,
      "y": 22949,
      "ta": "#start"
    },
    {
      "t": 23057,
      "e": 23057,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 23057,
      "e": 23057,
      "ty": 5,
      "x": 976,
      "y": 1045,
      "ta": "#start"
    },
    {
      "t": 23058,
      "e": 23058,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 23401,
      "e": 23401,
      "ty": 2,
      "x": 877,
      "y": 759
    },
    {
      "t": 23500,
      "e": 23500,
      "ty": 2,
      "x": 868,
      "y": 690
    },
    {
      "t": 23501,
      "e": 23501,
      "ty": 41,
      "x": 29616,
      "y": 39240,
      "ta": "html > body"
    },
    {
      "t": 23601,
      "e": 23601,
      "ty": 2,
      "x": 868,
      "y": 688
    },
    {
      "t": 23751,
      "e": 23751,
      "ty": 41,
      "x": 29616,
      "y": 39125,
      "ta": "html > body"
    },
    {
      "t": 24058,
      "e": 24058,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 25175,
      "e": 25175,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 26176,
      "e": 26176,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 93, dom: 667, initialDom: 671",
  "javascriptErrors": []
}