var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "434f875ed1728ddd1c5e6d5bc4de4dfb",
  "created": "2018-05-21T12:17:23.4846411-07:00",
  "lastActivity": "2018-05-21T12:17:54.2615915-07:00",
  "pageViews": [
    {
      "id": "05212394ed081ba832547078bc22a6398c93b839",
      "startTime": "2018-05-21T12:17:23.8113041-07:00",
      "endTime": "2018-05-21T12:17:54.2615915-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 30532,
      "engagementTime": 30482,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 30532,
  "engagementTime": 30482,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=EGP0T",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b27f5ec8c509348d93629bbd2c752f0a",
  "gdpr": false
}