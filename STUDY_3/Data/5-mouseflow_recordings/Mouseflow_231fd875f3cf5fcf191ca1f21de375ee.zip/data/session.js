var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "231fd875f3cf5fcf191ca1f21de375ee",
  "created": "2018-05-21T12:18:41.2109748-07:00",
  "lastActivity": "2018-05-21T12:18:53.6049748-07:00",
  "pageViews": [
    {
      "id": "05214119b6d7b69aa8e43b4bc914cb3daf1ac1fb",
      "startTime": "2018-05-21T12:18:41.2109748-07:00",
      "endTime": "2018-05-21T12:18:53.6049748-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 12394,
      "engagementTime": 12194,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 12394,
  "engagementTime": 12194,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.33",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=WKBNA",
    "CONDITION=111",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "98804b8ef265a96b1e3ad3d2e83e02b7",
  "gdpr": false
}