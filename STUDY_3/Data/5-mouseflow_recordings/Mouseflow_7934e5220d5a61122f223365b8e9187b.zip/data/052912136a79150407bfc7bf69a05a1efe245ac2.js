var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052912136a79150407bfc7bf69a05a1efe245ac2"] = {
  "startTime": "2018-05-29T23:17:12.3630288Z",
  "websitePageUrl": "/16",
  "visitTime": 89709,
  "engagementTime": 88589,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "7934e5220d5a61122f223365b8e9187b",
    "created": "2018-05-29T23:17:12.1136954+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=DK1EM",
      "CONDITION=113"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "7a3ab7bf59100f9c11f56dbb318cf402",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/7934e5220d5a61122f223365b8e9187b/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 179,
      "e": 179,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 179,
      "e": 179,
      "ty": 2,
      "x": 551,
      "y": 730
    },
    {
      "t": 251,
      "e": 251,
      "ty": 41,
      "x": 51023,
      "y": 39996,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 301,
      "e": 301,
      "ty": 2,
      "x": 552,
      "y": 717
    },
    {
      "t": 402,
      "e": 402,
      "ty": 2,
      "x": 545,
      "y": 686
    },
    {
      "t": 502,
      "e": 502,
      "ty": 2,
      "x": 545,
      "y": 684
    },
    {
      "t": 502,
      "e": 502,
      "ty": 41,
      "x": 50349,
      "y": 37448,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 659,
      "e": 659,
      "ty": 2,
      "x": 548,
      "y": 681
    },
    {
      "t": 701,
      "e": 701,
      "ty": 2,
      "x": 549,
      "y": 681
    },
    {
      "t": 752,
      "e": 752,
      "ty": 41,
      "x": 50798,
      "y": 37282,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 550,
      "y": 681
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 41,
      "x": 50911,
      "y": 37282,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 3801,
      "e": 3801,
      "ty": 2,
      "x": 559,
      "y": 679
    },
    {
      "t": 3901,
      "e": 3901,
      "ty": 2,
      "x": 560,
      "y": 679
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 41,
      "x": 52035,
      "y": 37171,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 2,
      "x": 563,
      "y": 674
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 41,
      "x": 52372,
      "y": 36894,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 5600,
      "e": 5600,
      "ty": 2,
      "x": 567,
      "y": 668
    },
    {
      "t": 5701,
      "e": 5701,
      "ty": 2,
      "x": 570,
      "y": 666
    },
    {
      "t": 5751,
      "e": 5751,
      "ty": 41,
      "x": 53159,
      "y": 36396,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 5801,
      "e": 5801,
      "ty": 2,
      "x": 570,
      "y": 664
    },
    {
      "t": 5900,
      "e": 5900,
      "ty": 2,
      "x": 571,
      "y": 660
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 2,
      "x": 573,
      "y": 656
    },
    {
      "t": 6002,
      "e": 6002,
      "ty": 41,
      "x": 53496,
      "y": 35897,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 6101,
      "e": 6101,
      "ty": 2,
      "x": 575,
      "y": 650
    },
    {
      "t": 6201,
      "e": 6201,
      "ty": 2,
      "x": 575,
      "y": 643
    },
    {
      "t": 6251,
      "e": 6251,
      "ty": 41,
      "x": 53721,
      "y": 34678,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 6300,
      "e": 6300,
      "ty": 2,
      "x": 575,
      "y": 626
    },
    {
      "t": 6367,
      "e": 6367,
      "ty": 6,
      "x": 575,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6400,
      "e": 6400,
      "ty": 2,
      "x": 575,
      "y": 596
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 2,
      "x": 576,
      "y": 585
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 41,
      "x": 53833,
      "y": 50377,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6601,
      "e": 6601,
      "ty": 2,
      "x": 576,
      "y": 584
    },
    {
      "t": 6700,
      "e": 6700,
      "ty": 2,
      "x": 576,
      "y": 583
    },
    {
      "t": 6751,
      "e": 6751,
      "ty": 41,
      "x": 53833,
      "y": 48759,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7700,
      "e": 7700,
      "ty": 2,
      "x": 577,
      "y": 582
    },
    {
      "t": 7751,
      "e": 7751,
      "ty": 41,
      "x": 53946,
      "y": 47950,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7801,
      "e": 7801,
      "ty": 2,
      "x": 578,
      "y": 582
    },
    {
      "t": 7901,
      "e": 7901,
      "ty": 2,
      "x": 581,
      "y": 581
    },
    {
      "t": 8001,
      "e": 8001,
      "ty": 41,
      "x": 54395,
      "y": 47141,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8101,
      "e": 8101,
      "ty": 2,
      "x": 582,
      "y": 580
    },
    {
      "t": 8251,
      "e": 8251,
      "ty": 41,
      "x": 54508,
      "y": 46332,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 14156,
      "e": 13251,
      "ty": 3,
      "x": 582,
      "y": 580,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14158,
      "e": 13253,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14266,
      "e": 13361,
      "ty": 4,
      "x": 54508,
      "y": 46332,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14266,
      "e": 13361,
      "ty": 5,
      "x": 582,
      "y": 580,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16168,
      "e": 15263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 16319,
      "e": 15414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 16319,
      "e": 15414,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16328,
      "e": 15423,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 16406,
      "e": 15501,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 16470,
      "e": 15565,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 16567,
      "e": 15662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 17095,
      "e": 16190,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17096,
      "e": 16191,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17202,
      "e": 16297,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F "
    },
    {
      "t": 17230,
      "e": 16325,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F "
    },
    {
      "t": 17238,
      "e": 16333,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 17239,
      "e": 16334,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17402,
      "e": 16497,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F a"
    },
    {
      "t": 17407,
      "e": 16502,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F a"
    },
    {
      "t": 17415,
      "e": 16510,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 17415,
      "e": 16510,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17479,
      "e": 16574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F ab"
    },
    {
      "t": 17605,
      "e": 16700,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F ab"
    },
    {
      "t": 18151,
      "e": 17246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18207,
      "e": 17302,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F a"
    },
    {
      "t": 18575,
      "e": 17670,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 18576,
      "e": 17671,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18638,
      "e": 17733,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F an"
    },
    {
      "t": 18670,
      "e": 17765,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 18670,
      "e": 17765,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18774,
      "e": 17869,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 18967,
      "e": 18062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18968,
      "e": 18063,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19094,
      "e": 18189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19142,
      "e": 18237,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 19296,
      "e": 18391,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19391,
      "e": 18486,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 19392,
      "e": 18487,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19395,
      "e": 18490,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 19395,
      "e": 18490,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19422,
      "e": 18517,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||BV"
    },
    {
      "t": 19470,
      "e": 18565,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19479,
      "e": 18574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 19591,
      "e": 18686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20001,
      "e": 19096,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20151,
      "e": 19246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 20191,
      "e": 19286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B"
    },
    {
      "t": 20295,
      "e": 19390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 20366,
      "e": 19461,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and "
    },
    {
      "t": 21135,
      "e": 20230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 21223,
      "e": 20318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21239,
      "e": 20334,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 21239,
      "e": 20334,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21326,
      "e": 20421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||B"
    },
    {
      "t": 21471,
      "e": 20566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 21592,
      "e": 20687,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21959,
      "e": 21054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 21959,
      "e": 21054,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22054,
      "e": 21149,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 22215,
      "e": 21310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22216,
      "e": 21311,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22334,
      "e": 21429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23742,
      "e": 22837,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 23742,
      "e": 22837,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23839,
      "e": 22934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 23846,
      "e": 22941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 23847,
      "e": 22942,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23943,
      "e": 23038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 23975,
      "e": 23070,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 23975,
      "e": 23070,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24070,
      "e": 23165,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 24102,
      "e": 23197,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 24103,
      "e": 23198,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24175,
      "e": 23270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 24311,
      "e": 23406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24312,
      "e": 23407,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24423,
      "e": 23518,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24527,
      "e": 23622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 24528,
      "e": 23623,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24646,
      "e": 23741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 25040,
      "e": 24135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25040,
      "e": 24135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25175,
      "e": 24270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25903,
      "e": 24998,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 25904,
      "e": 24999,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26030,
      "e": 25125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 26071,
      "e": 25166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26071,
      "e": 25166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26159,
      "e": 25254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 26191,
      "e": 25286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 26192,
      "e": 25287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26230,
      "e": 25325,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 26703,
      "e": 25798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26766,
      "e": 25861,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B, make a be"
    },
    {
      "t": 26854,
      "e": 25949,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26927,
      "e": 26022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B, make a b"
    },
    {
      "t": 27015,
      "e": 26110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27102,
      "e": 26197,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B, make a "
    },
    {
      "t": 27203,
      "e": 26298,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B, make a "
    },
    {
      "t": 27567,
      "e": 26662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 27567,
      "e": 26662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27646,
      "e": 26741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 27759,
      "e": 26854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 27759,
      "e": 26854,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27839,
      "e": 26934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 27927,
      "e": 27022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 27928,
      "e": 27023,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27990,
      "e": 27085,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 28151,
      "e": 27246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28151,
      "e": 27246,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28199,
      "e": 27294,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 28287,
      "e": 27382,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 28288,
      "e": 27383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28398,
      "e": 27493,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 28446,
      "e": 27541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 28446,
      "e": 27541,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28535,
      "e": 27630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 28536,
      "e": 27631,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28542,
      "e": 27637,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ca"
    },
    {
      "t": 28590,
      "e": 27685,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 28591,
      "e": 27686,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28630,
      "e": 27725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 28703,
      "e": 27798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28703,
      "e": 27798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28742,
      "e": 27837,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28807,
      "e": 27902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28895,
      "e": 27990,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 28896,
      "e": 27991,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29002,
      "e": 28097,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B, make a vertical l"
    },
    {
      "t": 29030,
      "e": 28125,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 29031,
      "e": 28126,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29047,
      "e": 28142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||li"
    },
    {
      "t": 29110,
      "e": 28205,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29183,
      "e": 28278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 29186,
      "e": 28281,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29286,
      "e": 28381,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 29334,
      "e": 28429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 29335,
      "e": 28430,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29358,
      "e": 28453,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 29694,
      "e": 28789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29694,
      "e": 28789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29804,
      "e": 28899,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B, make a vertical line "
    },
    {
      "t": 29807,
      "e": 28902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30002,
      "e": 29097,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30743,
      "e": 29838,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 30743,
      "e": 29838,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30846,
      "e": 29941,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 30983,
      "e": 30078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30984,
      "e": 30079,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31054,
      "e": 30149,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 31351,
      "e": 30446,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31351,
      "e": 30446,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31494,
      "e": 30589,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31607,
      "e": 30702,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 31609,
      "e": 30704,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31702,
      "e": 30797,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 31718,
      "e": 30813,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 31718,
      "e": 30813,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31798,
      "e": 30893,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 32023,
      "e": 31118,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 32024,
      "e": 31119,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32158,
      "e": 31253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 32422,
      "e": 31517,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 32422,
      "e": 31517,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32430,
      "e": 31525,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 32431,
      "e": 31526,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32486,
      "e": 31581,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m,"
    },
    {
      "t": 32518,
      "e": 31613,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33063,
      "e": 32158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33126,
      "e": 32221,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B, make a vertical line at 12pm"
    },
    {
      "t": 33214,
      "e": 32309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33311,
      "e": 32406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B, make a vertical line at 12p"
    },
    {
      "t": 34223,
      "e": 33318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 34224,
      "e": 33319,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34262,
      "e": 33357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 34402,
      "e": 33497,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B, make a vertical line at 12pm"
    },
    {
      "t": 34631,
      "e": 33726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34632,
      "e": 33727,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34766,
      "e": 33861,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34831,
      "e": 33926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 34831,
      "e": 33926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34934,
      "e": 34029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 34934,
      "e": 34029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34950,
      "e": 34045,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ab"
    },
    {
      "t": 35023,
      "e": 34118,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 35023,
      "e": 34118,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35054,
      "e": 34149,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 35088,
      "e": 34183,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35167,
      "e": 34262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35168,
      "e": 34263,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35286,
      "e": 34381,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36351,
      "e": 35446,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36431,
      "e": 35526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B, make a vertical line at 12pm abd"
    },
    {
      "t": 36527,
      "e": 35622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36590,
      "e": 35685,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B, make a vertical line at 12pm ab"
    },
    {
      "t": 36678,
      "e": 35773,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36767,
      "e": 35862,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B, make a vertical line at 12pm a"
    },
    {
      "t": 37631,
      "e": 36726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 37632,
      "e": 36727,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37726,
      "e": 36821,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 37726,
      "e": 36821,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37766,
      "e": 36861,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nd"
    },
    {
      "t": 37790,
      "e": 36885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37791,
      "e": 36886,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37806,
      "e": 36901,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37895,
      "e": 36990,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37975,
      "e": 37070,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 37976,
      "e": 37071,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38055,
      "e": 37150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 38191,
      "e": 37286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 38191,
      "e": 37286,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38229,
      "e": 37324,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 38334,
      "e": 37429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 38334,
      "e": 37429,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38414,
      "e": 37509,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 39095,
      "e": 38190,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 39095,
      "e": 38190,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39174,
      "e": 38269,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 39262,
      "e": 38357,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39263,
      "e": 38358,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39335,
      "e": 38430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39511,
      "e": 38606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 39512,
      "e": 38607,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39630,
      "e": 38725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 39654,
      "e": 38749,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 39655,
      "e": 38750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39711,
      "e": 38806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 39783,
      "e": 38878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 39784,
      "e": 38879,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39846,
      "e": 38941,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 39950,
      "e": 39045,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39951,
      "e": 39046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40001,
      "e": 39096,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40039,
      "e": 39134,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40087,
      "e": 39182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40088,
      "e": 39183,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40158,
      "e": 39253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 40198,
      "e": 39293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 40198,
      "e": 39293,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40246,
      "e": 39341,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40247,
      "e": 39342,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40286,
      "e": 39381,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 40350,
      "e": 39445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40375,
      "e": 39470,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40375,
      "e": 39470,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40478,
      "e": 39573,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40831,
      "e": 39926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 40832,
      "e": 39927,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40917,
      "e": 40012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 40918,
      "e": 40013,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40982,
      "e": 40077,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 41079,
      "e": 40174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41183,
      "e": 40278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 41183,
      "e": 40278,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41342,
      "e": 40437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 41342,
      "e": 40437,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41358,
      "e": 40453,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 41421,
      "e": 40516,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41454,
      "e": 40549,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41454,
      "e": 40549,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41519,
      "e": 40614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 41637,
      "e": 40732,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 41639,
      "e": 40734,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41726,
      "e": 40821,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 42023,
      "e": 41118,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42023,
      "e": 41118,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42167,
      "e": 41262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 42511,
      "e": 41606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 42512,
      "e": 41607,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42598,
      "e": 41693,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 42614,
      "e": 41709,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 42614,
      "e": 41709,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42702,
      "e": 41797,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 42803,
      "e": 41898,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B, make a vertical line at 12pm and look for the points in"
    },
    {
      "t": 42998,
      "e": 42093,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43002,
      "e": 42097,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43094,
      "e": 42189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 43150,
      "e": 42245,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 43150,
      "e": 42245,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43230,
      "e": 42325,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 43230,
      "e": 42325,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43238,
      "e": 42333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 43295,
      "e": 42390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 43295,
      "e": 42390,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43358,
      "e": 42453,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 43374,
      "e": 42469,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43383,
      "e": 42478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43383,
      "e": 42478,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43486,
      "e": 42581,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 43655,
      "e": 42750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 43655,
      "e": 42750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43718,
      "e": 42813,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 44079,
      "e": 43174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 44159,
      "e": 43254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B, make a vertical line at 12pm and look for the points in the "
    },
    {
      "t": 44334,
      "e": 43429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 44336,
      "e": 43431,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44447,
      "e": 43542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 44495,
      "e": 43590,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 44496,
      "e": 43591,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44602,
      "e": 43697,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B, make a vertical line at 12pm and look for the points in the li"
    },
    {
      "t": 44614,
      "e": 43709,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 44614,
      "e": 43709,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44622,
      "e": 43717,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 44694,
      "e": 43789,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44759,
      "e": 43854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 44760,
      "e": 43855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44822,
      "e": 43917,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 45911,
      "e": 45006,
      "ty": 2,
      "x": 550,
      "y": 580
    },
    {
      "t": 46010,
      "e": 45105,
      "ty": 2,
      "x": 505,
      "y": 588
    },
    {
      "t": 46010,
      "e": 45105,
      "ty": 41,
      "x": 45852,
      "y": 52804,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46059,
      "e": 45154,
      "ty": 7,
      "x": 474,
      "y": 605,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46110,
      "e": 45205,
      "ty": 2,
      "x": 448,
      "y": 623
    },
    {
      "t": 46135,
      "e": 45230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 46135,
      "e": 45230,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46207,
      "e": 45302,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 46210,
      "e": 45305,
      "ty": 2,
      "x": 386,
      "y": 650
    },
    {
      "t": 46259,
      "e": 45354,
      "ty": 6,
      "x": 377,
      "y": 654,
      "ta": "#strategyButton"
    },
    {
      "t": 46260,
      "e": 45355,
      "ty": 41,
      "x": 20974,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 46310,
      "e": 45405,
      "ty": 2,
      "x": 372,
      "y": 654
    },
    {
      "t": 46410,
      "e": 45505,
      "ty": 2,
      "x": 395,
      "y": 655
    },
    {
      "t": 46510,
      "e": 45605,
      "ty": 2,
      "x": 401,
      "y": 656
    },
    {
      "t": 46511,
      "e": 45606,
      "ty": 41,
      "x": 34081,
      "y": 2439,
      "ta": "#strategyButton"
    },
    {
      "t": 46610,
      "e": 45705,
      "ty": 2,
      "x": 402,
      "y": 656
    },
    {
      "t": 46636,
      "e": 45731,
      "ty": 3,
      "x": 402,
      "y": 656,
      "ta": "#strategyButton"
    },
    {
      "t": 46638,
      "e": 45733,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B, make a vertical line at 12pm and look for the points in the line."
    },
    {
      "t": 46639,
      "e": 45734,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46640,
      "e": 45735,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 46698,
      "e": 45793,
      "ty": 4,
      "x": 34627,
      "y": 2439,
      "ta": "#strategyButton"
    },
    {
      "t": 46707,
      "e": 45802,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 46709,
      "e": 45804,
      "ty": 5,
      "x": 402,
      "y": 656,
      "ta": "#strategyButton"
    },
    {
      "t": 46715,
      "e": 45810,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 46760,
      "e": 45804,
      "ty": 41,
      "x": 13568,
      "y": 35897,
      "ta": "html > body"
    },
    {
      "t": 47010,
      "e": 46054,
      "ty": 2,
      "x": 402,
      "y": 659
    },
    {
      "t": 47010,
      "e": 46054,
      "ty": 41,
      "x": 13568,
      "y": 36063,
      "ta": "html > body"
    },
    {
      "t": 47110,
      "e": 46154,
      "ty": 2,
      "x": 404,
      "y": 665
    },
    {
      "t": 47211,
      "e": 46255,
      "ty": 2,
      "x": 414,
      "y": 676
    },
    {
      "t": 47260,
      "e": 46304,
      "ty": 41,
      "x": 14326,
      "y": 37393,
      "ta": "html > body"
    },
    {
      "t": 47310,
      "e": 46354,
      "ty": 2,
      "x": 426,
      "y": 684
    },
    {
      "t": 47511,
      "e": 46555,
      "ty": 41,
      "x": 14394,
      "y": 37448,
      "ta": "html > body"
    },
    {
      "t": 47716,
      "e": 46760,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 48110,
      "e": 47154,
      "ty": 2,
      "x": 464,
      "y": 684
    },
    {
      "t": 48210,
      "e": 47254,
      "ty": 2,
      "x": 690,
      "y": 682
    },
    {
      "t": 48243,
      "e": 47287,
      "ty": 6,
      "x": 820,
      "y": 663,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48260,
      "e": 47304,
      "ty": 41,
      "x": 2595,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48276,
      "e": 47320,
      "ty": 7,
      "x": 893,
      "y": 643,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48309,
      "e": 47353,
      "ty": 2,
      "x": 941,
      "y": 625
    },
    {
      "t": 48410,
      "e": 47454,
      "ty": 2,
      "x": 957,
      "y": 603
    },
    {
      "t": 48510,
      "e": 47554,
      "ty": 2,
      "x": 959,
      "y": 578
    },
    {
      "t": 48510,
      "e": 47554,
      "ty": 41,
      "x": 32659,
      "y": 62011,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 48610,
      "e": 47654,
      "ty": 2,
      "x": 958,
      "y": 575
    },
    {
      "t": 48612,
      "e": 47656,
      "ty": 6,
      "x": 958,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48710,
      "e": 47754,
      "ty": 2,
      "x": 955,
      "y": 572
    },
    {
      "t": 48760,
      "e": 47804,
      "ty": 41,
      "x": 31577,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48810,
      "e": 47854,
      "ty": 2,
      "x": 953,
      "y": 572
    },
    {
      "t": 48851,
      "e": 47895,
      "ty": 3,
      "x": 953,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48851,
      "e": 47895,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48946,
      "e": 47990,
      "ty": 4,
      "x": 31361,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48946,
      "e": 47990,
      "ty": 5,
      "x": 953,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 49010,
      "e": 48054,
      "ty": 41,
      "x": 31361,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50031,
      "e": 49075,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 50031,
      "e": 49075,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50119,
      "e": 49163,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 50502,
      "e": 49546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 50503,
      "e": 49547,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50562,
      "e": 49606,
      "ty": 7,
      "x": 952,
      "y": 575,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50582,
      "e": 49626,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "29"
    },
    {
      "t": 50610,
      "e": 49654,
      "ty": 2,
      "x": 953,
      "y": 583
    },
    {
      "t": 50710,
      "e": 49754,
      "ty": 2,
      "x": 953,
      "y": 591
    },
    {
      "t": 50760,
      "e": 49804,
      "ty": 41,
      "x": 31361,
      "y": 8456,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 50810,
      "e": 49854,
      "ty": 2,
      "x": 952,
      "y": 600
    },
    {
      "t": 50910,
      "e": 49954,
      "ty": 2,
      "x": 944,
      "y": 627
    },
    {
      "t": 50979,
      "e": 50023,
      "ty": 6,
      "x": 939,
      "y": 648,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51010,
      "e": 50054,
      "ty": 2,
      "x": 938,
      "y": 650
    },
    {
      "t": 51010,
      "e": 50054,
      "ty": 41,
      "x": 28117,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51110,
      "e": 50154,
      "ty": 2,
      "x": 937,
      "y": 656
    },
    {
      "t": 51260,
      "e": 50304,
      "ty": 41,
      "x": 27901,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51291,
      "e": 50335,
      "ty": 3,
      "x": 937,
      "y": 656,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51291,
      "e": 50335,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "29"
    },
    {
      "t": 51291,
      "e": 50335,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51291,
      "e": 50335,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51363,
      "e": 50407,
      "ty": 4,
      "x": 27901,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51363,
      "e": 50407,
      "ty": 5,
      "x": 937,
      "y": 656,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52535,
      "e": 51579,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 52599,
      "e": 51643,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 52790,
      "e": 51834,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 52790,
      "e": 51834,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52935,
      "e": 51979,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "S"
    },
    {
      "t": 52936,
      "e": 51980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 53079,
      "e": 52123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "S"
    },
    {
      "t": 53103,
      "e": 52147,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "79"
    },
    {
      "t": 53104,
      "e": 52148,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53210,
      "e": 52254,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "So"
    },
    {
      "t": 53232,
      "e": 52276,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 53232,
      "e": 52276,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53278,
      "e": 52322,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Sou"
    },
    {
      "t": 53318,
      "e": 52362,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Sou"
    },
    {
      "t": 53592,
      "e": 52636,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 53592,
      "e": 52636,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53630,
      "e": 52674,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Sout"
    },
    {
      "t": 53926,
      "e": 52970,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 53927,
      "e": 52971,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54039,
      "e": 53083,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 54335,
      "e": 53379,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 54414,
      "e": 53458,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Sout"
    },
    {
      "t": 54439,
      "e": 53483,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 54486,
      "e": 53530,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Sou"
    },
    {
      "t": 54611,
      "e": 53655,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Sou"
    },
    {
      "t": 54703,
      "e": 53747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 54704,
      "e": 53748,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54734,
      "e": 53778,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Souh"
    },
    {
      "t": 55264,
      "e": 54308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 55344,
      "e": 54388,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Sou"
    },
    {
      "t": 55383,
      "e": 54427,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 55384,
      "e": 54428,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55473,
      "e": 54517,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Sout"
    },
    {
      "t": 55473,
      "e": 54517,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 55473,
      "e": 54517,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55607,
      "e": 54651,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 55607,
      "e": 54651,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55622,
      "e": 54666,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||h "
    },
    {
      "t": 55686,
      "e": 54730,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 55710,
      "e": 54754,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 55799,
      "e": 54843,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 55800,
      "e": 54844,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "75"
    },
    {
      "t": 55800,
      "e": 54844,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55887,
      "e": 54931,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||K"
    },
    {
      "t": 55894,
      "e": 54938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 55983,
      "e": 55027,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "79"
    },
    {
      "t": 55983,
      "e": 55027,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56022,
      "e": 55066,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||o"
    },
    {
      "t": 56047,
      "e": 55091,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "82"
    },
    {
      "t": 56048,
      "e": 55092,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56095,
      "e": 55139,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||r"
    },
    {
      "t": 56119,
      "e": 55163,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 56120,
      "e": 55164,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56144,
      "e": 55188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 56231,
      "e": 55275,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 56232,
      "e": 55276,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56254,
      "e": 55298,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 56302,
      "e": 55346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 56411,
      "e": 55455,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "South Korea"
    },
    {
      "t": 57259,
      "e": 56303,
      "ty": 41,
      "x": 27901,
      "y": 3120,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57268,
      "e": 56312,
      "ty": 7,
      "x": 938,
      "y": 642,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57310,
      "e": 56354,
      "ty": 2,
      "x": 938,
      "y": 642
    },
    {
      "t": 57510,
      "e": 56554,
      "ty": 41,
      "x": 28117,
      "y": 41575,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 57651,
      "e": 56695,
      "ty": 6,
      "x": 938,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57710,
      "e": 56754,
      "ty": 2,
      "x": 937,
      "y": 661
    },
    {
      "t": 57760,
      "e": 56804,
      "ty": 41,
      "x": 27901,
      "y": 56172,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57804,
      "e": 56848,
      "ty": 7,
      "x": 937,
      "y": 668,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57810,
      "e": 56854,
      "ty": 2,
      "x": 937,
      "y": 668
    },
    {
      "t": 57909,
      "e": 56953,
      "ty": 2,
      "x": 937,
      "y": 675
    },
    {
      "t": 57923,
      "e": 56953,
      "ty": 6,
      "x": 937,
      "y": 676,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 58009,
      "e": 57039,
      "ty": 2,
      "x": 937,
      "y": 680
    },
    {
      "t": 58009,
      "e": 57039,
      "ty": 41,
      "x": 21171,
      "y": 7943,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 58110,
      "e": 57140,
      "ty": 2,
      "x": 937,
      "y": 689
    },
    {
      "t": 58210,
      "e": 57240,
      "ty": 2,
      "x": 937,
      "y": 690
    },
    {
      "t": 58252,
      "e": 57282,
      "ty": 3,
      "x": 937,
      "y": 690,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 58253,
      "e": 57283,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "South Korea"
    },
    {
      "t": 58254,
      "e": 57284,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58254,
      "e": 57284,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 58259,
      "e": 57289,
      "ty": 41,
      "x": 21171,
      "y": 27802,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 58346,
      "e": 57376,
      "ty": 4,
      "x": 21171,
      "y": 27802,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 58347,
      "e": 57377,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 58348,
      "e": 57378,
      "ty": 5,
      "x": 937,
      "y": 690,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 58348,
      "e": 57378,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 58810,
      "e": 57840,
      "ty": 2,
      "x": 948,
      "y": 687
    },
    {
      "t": 58910,
      "e": 57940,
      "ty": 2,
      "x": 950,
      "y": 686
    },
    {
      "t": 59009,
      "e": 58039,
      "ty": 41,
      "x": 32440,
      "y": 37559,
      "ta": "html > body"
    },
    {
      "t": 59363,
      "e": 58393,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 60010,
      "e": 59040,
      "ty": 2,
      "x": 956,
      "y": 688
    },
    {
      "t": 60010,
      "e": 59040,
      "ty": 41,
      "x": 31938,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 60110,
      "e": 59140,
      "ty": 2,
      "x": 1017,
      "y": 707
    },
    {
      "t": 60209,
      "e": 59239,
      "ty": 2,
      "x": 1070,
      "y": 616
    },
    {
      "t": 60260,
      "e": 59290,
      "ty": 41,
      "x": 55671,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 60310,
      "e": 59340,
      "ty": 2,
      "x": 1007,
      "y": 434
    },
    {
      "t": 60410,
      "e": 59440,
      "ty": 2,
      "x": 916,
      "y": 328
    },
    {
      "t": 60510,
      "e": 59540,
      "ty": 2,
      "x": 890,
      "y": 310
    },
    {
      "t": 60510,
      "e": 59540,
      "ty": 41,
      "x": 16275,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 60609,
      "e": 59639,
      "ty": 2,
      "x": 876,
      "y": 298
    },
    {
      "t": 60710,
      "e": 59740,
      "ty": 2,
      "x": 869,
      "y": 274
    },
    {
      "t": 60760,
      "e": 59790,
      "ty": 41,
      "x": 31666,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 60810,
      "e": 59840,
      "ty": 2,
      "x": 860,
      "y": 257
    },
    {
      "t": 60909,
      "e": 59939,
      "ty": 2,
      "x": 845,
      "y": 255
    },
    {
      "t": 61009,
      "e": 60039,
      "ty": 2,
      "x": 827,
      "y": 258
    },
    {
      "t": 61009,
      "e": 60039,
      "ty": 41,
      "x": 4248,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 61020,
      "e": 60050,
      "ty": 6,
      "x": 826,
      "y": 261,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 61037,
      "e": 60067,
      "ty": 7,
      "x": 825,
      "y": 265,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 61110,
      "e": 60140,
      "ty": 2,
      "x": 820,
      "y": 290
    },
    {
      "t": 61210,
      "e": 60240,
      "ty": 2,
      "x": 823,
      "y": 316
    },
    {
      "t": 61260,
      "e": 60290,
      "ty": 41,
      "x": 1566,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 61471,
      "e": 60501,
      "ty": 6,
      "x": 829,
      "y": 322,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 61510,
      "e": 60540,
      "ty": 2,
      "x": 830,
      "y": 323
    },
    {
      "t": 61510,
      "e": 60540,
      "ty": 41,
      "x": 18037,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 61604,
      "e": 60634,
      "ty": 3,
      "x": 831,
      "y": 323,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 61605,
      "e": 60635,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 61609,
      "e": 60639,
      "ty": 2,
      "x": 831,
      "y": 323
    },
    {
      "t": 61690,
      "e": 60720,
      "ty": 4,
      "x": 23079,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 61691,
      "e": 60721,
      "ty": 5,
      "x": 831,
      "y": 323,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 61691,
      "e": 60721,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf",
      "v": "Other"
    },
    {
      "t": 61760,
      "e": 60790,
      "ty": 41,
      "x": 23079,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 61810,
      "e": 60840,
      "ty": 2,
      "x": 832,
      "y": 324
    },
    {
      "t": 61854,
      "e": 60884,
      "ty": 7,
      "x": 826,
      "y": 340,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 61909,
      "e": 60939,
      "ty": 2,
      "x": 823,
      "y": 418
    },
    {
      "t": 62010,
      "e": 61040,
      "ty": 2,
      "x": 853,
      "y": 556
    },
    {
      "t": 62011,
      "e": 61041,
      "ty": 41,
      "x": 21546,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 62110,
      "e": 61140,
      "ty": 2,
      "x": 855,
      "y": 564
    },
    {
      "t": 62260,
      "e": 61290,
      "ty": 41,
      "x": 7968,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-5"
    },
    {
      "t": 62310,
      "e": 61340,
      "ty": 2,
      "x": 855,
      "y": 565
    },
    {
      "t": 62410,
      "e": 61440,
      "ty": 2,
      "x": 855,
      "y": 566
    },
    {
      "t": 62510,
      "e": 61540,
      "ty": 41,
      "x": 7968,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-5"
    },
    {
      "t": 62760,
      "e": 61790,
      "ty": 41,
      "x": 23593,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 62809,
      "e": 61839,
      "ty": 2,
      "x": 857,
      "y": 551
    },
    {
      "t": 62910,
      "e": 61839,
      "ty": 2,
      "x": 859,
      "y": 533
    },
    {
      "t": 63010,
      "e": 61939,
      "ty": 2,
      "x": 856,
      "y": 494
    },
    {
      "t": 63010,
      "e": 61939,
      "ty": 41,
      "x": 31035,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 63110,
      "e": 62039,
      "ty": 2,
      "x": 855,
      "y": 477
    },
    {
      "t": 63209,
      "e": 62138,
      "ty": 2,
      "x": 848,
      "y": 467
    },
    {
      "t": 63260,
      "e": 62189,
      "ty": 41,
      "x": 24922,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 63309,
      "e": 62238,
      "ty": 2,
      "x": 845,
      "y": 463
    },
    {
      "t": 63509,
      "e": 62438,
      "ty": 41,
      "x": 24922,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 63610,
      "e": 62539,
      "ty": 2,
      "x": 841,
      "y": 462
    },
    {
      "t": 63710,
      "e": 62639,
      "ty": 2,
      "x": 837,
      "y": 462
    },
    {
      "t": 63755,
      "e": 62684,
      "ty": 6,
      "x": 833,
      "y": 464,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 63760,
      "e": 62689,
      "ty": 41,
      "x": 33161,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 63807,
      "e": 62736,
      "ty": 7,
      "x": 833,
      "y": 480,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 63810,
      "e": 62739,
      "ty": 2,
      "x": 833,
      "y": 480
    },
    {
      "t": 63839,
      "e": 62768,
      "ty": 6,
      "x": 833,
      "y": 492,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 63909,
      "e": 62838,
      "ty": 2,
      "x": 833,
      "y": 499
    },
    {
      "t": 64010,
      "e": 62939,
      "ty": 41,
      "x": 33161,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 64110,
      "e": 63039,
      "ty": 2,
      "x": 833,
      "y": 500
    },
    {
      "t": 64260,
      "e": 63189,
      "ty": 41,
      "x": 33161,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 64780,
      "e": 63709,
      "ty": 3,
      "x": 833,
      "y": 500,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 64781,
      "e": 63710,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 64782,
      "e": 63711,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 64907,
      "e": 63836,
      "ty": 4,
      "x": 33161,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 64907,
      "e": 63836,
      "ty": 5,
      "x": 833,
      "y": 500,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 64907,
      "e": 63836,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf",
      "v": "Fourth"
    },
    {
      "t": 65190,
      "e": 64119,
      "ty": 7,
      "x": 829,
      "y": 508,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 65210,
      "e": 64139,
      "ty": 2,
      "x": 822,
      "y": 522
    },
    {
      "t": 65260,
      "e": 64189,
      "ty": 41,
      "x": 27825,
      "y": 32462,
      "ta": "html > body"
    },
    {
      "t": 65310,
      "e": 64239,
      "ty": 2,
      "x": 824,
      "y": 669
    },
    {
      "t": 65340,
      "e": 64269,
      "ty": 6,
      "x": 832,
      "y": 704,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 65357,
      "e": 64286,
      "ty": 7,
      "x": 834,
      "y": 711,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 65409,
      "e": 64338,
      "ty": 2,
      "x": 836,
      "y": 720
    },
    {
      "t": 65510,
      "e": 64439,
      "ty": 2,
      "x": 836,
      "y": 721
    },
    {
      "t": 65510,
      "e": 64439,
      "ty": 41,
      "x": 3658,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 65609,
      "e": 64538,
      "ty": 2,
      "x": 837,
      "y": 719
    },
    {
      "t": 65760,
      "e": 64689,
      "ty": 41,
      "x": 3697,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 66510,
      "e": 65439,
      "ty": 2,
      "x": 841,
      "y": 725
    },
    {
      "t": 66511,
      "e": 65440,
      "ty": 41,
      "x": 4913,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 66610,
      "e": 65539,
      "ty": 2,
      "x": 841,
      "y": 729
    },
    {
      "t": 66710,
      "e": 65639,
      "ty": 2,
      "x": 841,
      "y": 730
    },
    {
      "t": 66761,
      "e": 65690,
      "ty": 41,
      "x": 4913,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 66810,
      "e": 65739,
      "ty": 2,
      "x": 840,
      "y": 734
    },
    {
      "t": 66910,
      "e": 65839,
      "ty": 2,
      "x": 840,
      "y": 744
    },
    {
      "t": 67010,
      "e": 65939,
      "ty": 2,
      "x": 838,
      "y": 747
    },
    {
      "t": 67010,
      "e": 65939,
      "ty": 41,
      "x": 3934,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 67100,
      "e": 66029,
      "ty": 6,
      "x": 838,
      "y": 753,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 67110,
      "e": 66039,
      "ty": 2,
      "x": 838,
      "y": 753
    },
    {
      "t": 67210,
      "e": 66139,
      "ty": 2,
      "x": 837,
      "y": 756
    },
    {
      "t": 67260,
      "e": 66189,
      "ty": 41,
      "x": 53325,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 67310,
      "e": 66239,
      "ty": 2,
      "x": 837,
      "y": 759
    },
    {
      "t": 67409,
      "e": 66338,
      "ty": 2,
      "x": 837,
      "y": 762
    },
    {
      "t": 67510,
      "e": 66439,
      "ty": 2,
      "x": 837,
      "y": 763
    },
    {
      "t": 67511,
      "e": 66440,
      "ty": 41,
      "x": 53325,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 68906,
      "e": 67835,
      "ty": 7,
      "x": 835,
      "y": 765,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 68910,
      "e": 67839,
      "ty": 2,
      "x": 835,
      "y": 765
    },
    {
      "t": 69010,
      "e": 67939,
      "ty": 41,
      "x": 5665,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 69110,
      "e": 68039,
      "ty": 2,
      "x": 832,
      "y": 765
    },
    {
      "t": 69210,
      "e": 68139,
      "ty": 2,
      "x": 829,
      "y": 766
    },
    {
      "t": 69261,
      "e": 68190,
      "ty": 41,
      "x": 2327,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 69310,
      "e": 68239,
      "ty": 2,
      "x": 827,
      "y": 766
    },
    {
      "t": 70580,
      "e": 69509,
      "ty": 6,
      "x": 829,
      "y": 764,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 70610,
      "e": 69539,
      "ty": 2,
      "x": 830,
      "y": 763
    },
    {
      "t": 70710,
      "e": 69639,
      "ty": 2,
      "x": 832,
      "y": 762
    },
    {
      "t": 70760,
      "e": 69689,
      "ty": 41,
      "x": 33161,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 70810,
      "e": 69739,
      "ty": 2,
      "x": 835,
      "y": 761
    },
    {
      "t": 70948,
      "e": 69877,
      "ty": 3,
      "x": 835,
      "y": 761,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 70950,
      "e": 69879,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 70950,
      "e": 69879,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 71010,
      "e": 69939,
      "ty": 41,
      "x": 43243,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 71050,
      "e": 69979,
      "ty": 4,
      "x": 43243,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 71051,
      "e": 69980,
      "ty": 5,
      "x": 835,
      "y": 761,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 71051,
      "e": 69980,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf",
      "v": "Natural Sciences"
    },
    {
      "t": 71210,
      "e": 70139,
      "ty": 2,
      "x": 835,
      "y": 760
    },
    {
      "t": 71260,
      "e": 70189,
      "ty": 41,
      "x": 38202,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 71310,
      "e": 70239,
      "ty": 2,
      "x": 834,
      "y": 760
    },
    {
      "t": 71395,
      "e": 70324,
      "ty": 7,
      "x": 833,
      "y": 765,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 71411,
      "e": 70340,
      "ty": 2,
      "x": 833,
      "y": 765
    },
    {
      "t": 71510,
      "e": 70439,
      "ty": 2,
      "x": 832,
      "y": 767
    },
    {
      "t": 71510,
      "e": 70439,
      "ty": 41,
      "x": 4413,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 71610,
      "e": 70539,
      "ty": 2,
      "x": 832,
      "y": 768
    },
    {
      "t": 71761,
      "e": 70690,
      "ty": 41,
      "x": 4413,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 71810,
      "e": 70739,
      "ty": 2,
      "x": 832,
      "y": 769
    },
    {
      "t": 71910,
      "e": 70839,
      "ty": 2,
      "x": 930,
      "y": 853
    },
    {
      "t": 72010,
      "e": 70939,
      "ty": 2,
      "x": 1096,
      "y": 943
    },
    {
      "t": 72011,
      "e": 70940,
      "ty": 41,
      "x": 65164,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 72110,
      "e": 71039,
      "ty": 2,
      "x": 1126,
      "y": 954
    },
    {
      "t": 72210,
      "e": 71139,
      "ty": 2,
      "x": 1126,
      "y": 955
    },
    {
      "t": 72260,
      "e": 71189,
      "ty": 41,
      "x": 38501,
      "y": 52461,
      "ta": "html > body"
    },
    {
      "t": 72510,
      "e": 71439,
      "ty": 2,
      "x": 1103,
      "y": 962
    },
    {
      "t": 72510,
      "e": 71439,
      "ty": 41,
      "x": 37709,
      "y": 52849,
      "ta": "html > body"
    },
    {
      "t": 72610,
      "e": 71539,
      "ty": 2,
      "x": 1100,
      "y": 962
    },
    {
      "t": 72761,
      "e": 71690,
      "ty": 41,
      "x": 37606,
      "y": 52849,
      "ta": "html > body"
    },
    {
      "t": 73010,
      "e": 71939,
      "ty": 2,
      "x": 1098,
      "y": 961
    },
    {
      "t": 73010,
      "e": 71939,
      "ty": 41,
      "x": 37537,
      "y": 52793,
      "ta": "html > body"
    },
    {
      "t": 73110,
      "e": 72039,
      "ty": 2,
      "x": 1081,
      "y": 966
    },
    {
      "t": 73210,
      "e": 72139,
      "ty": 2,
      "x": 1039,
      "y": 972
    },
    {
      "t": 73260,
      "e": 72189,
      "ty": 41,
      "x": 46652,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 73310,
      "e": 72239,
      "ty": 2,
      "x": 997,
      "y": 972
    },
    {
      "t": 73410,
      "e": 72339,
      "ty": 2,
      "x": 952,
      "y": 972
    },
    {
      "t": 73510,
      "e": 72439,
      "ty": 2,
      "x": 916,
      "y": 967
    },
    {
      "t": 73511,
      "e": 72440,
      "ty": 41,
      "x": 22445,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 73610,
      "e": 72539,
      "ty": 2,
      "x": 857,
      "y": 958
    },
    {
      "t": 73710,
      "e": 72639,
      "ty": 2,
      "x": 842,
      "y": 955
    },
    {
      "t": 73760,
      "e": 72689,
      "ty": 41,
      "x": 1798,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 73810,
      "e": 72739,
      "ty": 2,
      "x": 824,
      "y": 952
    },
    {
      "t": 73910,
      "e": 72839,
      "ty": 2,
      "x": 821,
      "y": 950
    },
    {
      "t": 74010,
      "e": 72939,
      "ty": 2,
      "x": 823,
      "y": 948
    },
    {
      "t": 74010,
      "e": 72939,
      "ty": 41,
      "x": 374,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 74110,
      "e": 73039,
      "ty": 2,
      "x": 827,
      "y": 943
    },
    {
      "t": 74130,
      "e": 73059,
      "ty": 6,
      "x": 828,
      "y": 940,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 74210,
      "e": 73139,
      "ty": 2,
      "x": 829,
      "y": 936
    },
    {
      "t": 74260,
      "e": 73189,
      "ty": 41,
      "x": 12996,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 74283,
      "e": 73212,
      "ty": 3,
      "x": 829,
      "y": 934,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 74284,
      "e": 73213,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 74284,
      "e": 73213,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 74310,
      "e": 73239,
      "ty": 2,
      "x": 829,
      "y": 934
    },
    {
      "t": 74363,
      "e": 73292,
      "ty": 4,
      "x": 12996,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 74364,
      "e": 73293,
      "ty": 5,
      "x": 829,
      "y": 934,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 74365,
      "e": 73294,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 74464,
      "e": 73393,
      "ty": 7,
      "x": 839,
      "y": 943,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 74510,
      "e": 73439,
      "ty": 2,
      "x": 859,
      "y": 965
    },
    {
      "t": 74510,
      "e": 73439,
      "ty": 41,
      "x": 30397,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 74564,
      "e": 73493,
      "ty": 6,
      "x": 907,
      "y": 1012,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 74610,
      "e": 73539,
      "ty": 2,
      "x": 915,
      "y": 1024
    },
    {
      "t": 74710,
      "e": 73639,
      "ty": 2,
      "x": 922,
      "y": 1035
    },
    {
      "t": 74761,
      "e": 73690,
      "ty": 41,
      "x": 47713,
      "y": 59577,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 74859,
      "e": 73788,
      "ty": 3,
      "x": 922,
      "y": 1035,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 74861,
      "e": 73790,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 74861,
      "e": 73790,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 74898,
      "e": 73827,
      "ty": 4,
      "x": 47713,
      "y": 59577,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 74899,
      "e": 73828,
      "ty": 5,
      "x": 922,
      "y": 1035,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 74900,
      "e": 73829,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 74900,
      "e": 73829,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 74901,
      "e": 73830,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 75310,
      "e": 74239,
      "ty": 2,
      "x": 919,
      "y": 1036
    },
    {
      "t": 75411,
      "e": 74340,
      "ty": 2,
      "x": 905,
      "y": 1032
    },
    {
      "t": 75510,
      "e": 74439,
      "ty": 2,
      "x": 902,
      "y": 1029
    },
    {
      "t": 75510,
      "e": 74439,
      "ty": 41,
      "x": 30787,
      "y": 56560,
      "ta": "html > body"
    },
    {
      "t": 75810,
      "e": 74739,
      "ty": 2,
      "x": 897,
      "y": 1025
    },
    {
      "t": 75910,
      "e": 74839,
      "ty": 2,
      "x": 872,
      "y": 1012
    },
    {
      "t": 76010,
      "e": 74939,
      "ty": 2,
      "x": 866,
      "y": 1010
    },
    {
      "t": 76010,
      "e": 74939,
      "ty": 41,
      "x": 29547,
      "y": 55508,
      "ta": "html > body"
    },
    {
      "t": 76261,
      "e": 75190,
      "ty": 41,
      "x": 29513,
      "y": 55286,
      "ta": "html > body"
    },
    {
      "t": 76312,
      "e": 75192,
      "ty": 2,
      "x": 863,
      "y": 994
    },
    {
      "t": 76410,
      "e": 75290,
      "ty": 2,
      "x": 855,
      "y": 983
    },
    {
      "t": 76510,
      "e": 75390,
      "ty": 2,
      "x": 849,
      "y": 979
    },
    {
      "t": 76511,
      "e": 75391,
      "ty": 41,
      "x": 28962,
      "y": 53790,
      "ta": "html > body"
    },
    {
      "t": 76610,
      "e": 75490,
      "ty": 2,
      "x": 843,
      "y": 975
    },
    {
      "t": 76710,
      "e": 75590,
      "ty": 2,
      "x": 841,
      "y": 975
    },
    {
      "t": 76760,
      "e": 75640,
      "ty": 41,
      "x": 28686,
      "y": 53458,
      "ta": "html > body"
    },
    {
      "t": 76811,
      "e": 75691,
      "ty": 2,
      "x": 841,
      "y": 972
    },
    {
      "t": 76911,
      "e": 75791,
      "ty": 2,
      "x": 844,
      "y": 971
    },
    {
      "t": 77010,
      "e": 75890,
      "ty": 2,
      "x": 846,
      "y": 971
    },
    {
      "t": 77011,
      "e": 75891,
      "ty": 41,
      "x": 28858,
      "y": 53347,
      "ta": "html > body"
    },
    {
      "t": 77111,
      "e": 75991,
      "ty": 2,
      "x": 847,
      "y": 969
    },
    {
      "t": 77260,
      "e": 76140,
      "ty": 41,
      "x": 28893,
      "y": 53236,
      "ta": "html > body"
    },
    {
      "t": 78210,
      "e": 77090,
      "ty": 2,
      "x": 847,
      "y": 968
    },
    {
      "t": 78261,
      "e": 77141,
      "ty": 41,
      "x": 28893,
      "y": 53181,
      "ta": "html > body"
    },
    {
      "t": 78610,
      "e": 77490,
      "ty": 2,
      "x": 847,
      "y": 967
    },
    {
      "t": 78710,
      "e": 77590,
      "ty": 2,
      "x": 845,
      "y": 966
    },
    {
      "t": 78761,
      "e": 77641,
      "ty": 41,
      "x": 28824,
      "y": 53070,
      "ta": "html > body"
    },
    {
      "t": 78811,
      "e": 77691,
      "ty": 2,
      "x": 844,
      "y": 966
    },
    {
      "t": 79010,
      "e": 77890,
      "ty": 2,
      "x": 842,
      "y": 964
    },
    {
      "t": 79011,
      "e": 77891,
      "ty": 41,
      "x": 28721,
      "y": 52959,
      "ta": "html > body"
    },
    {
      "t": 79610,
      "e": 78490,
      "ty": 2,
      "x": 842,
      "y": 962
    },
    {
      "t": 79711,
      "e": 78591,
      "ty": 2,
      "x": 842,
      "y": 960
    },
    {
      "t": 79761,
      "e": 78641,
      "ty": 41,
      "x": 28721,
      "y": 52738,
      "ta": "html > body"
    },
    {
      "t": 80210,
      "e": 79090,
      "ty": 2,
      "x": 842,
      "y": 959
    },
    {
      "t": 80261,
      "e": 79141,
      "ty": 41,
      "x": 28721,
      "y": 52627,
      "ta": "html > body"
    },
    {
      "t": 80311,
      "e": 79191,
      "ty": 2,
      "x": 842,
      "y": 957
    },
    {
      "t": 80511,
      "e": 79391,
      "ty": 41,
      "x": 28721,
      "y": 52572,
      "ta": "html > body"
    },
    {
      "t": 80611,
      "e": 79491,
      "ty": 2,
      "x": 845,
      "y": 954
    },
    {
      "t": 80710,
      "e": 79590,
      "ty": 2,
      "x": 850,
      "y": 950
    },
    {
      "t": 80761,
      "e": 79641,
      "ty": 41,
      "x": 29134,
      "y": 52073,
      "ta": "html > body"
    },
    {
      "t": 80810,
      "e": 79690,
      "ty": 2,
      "x": 859,
      "y": 946
    },
    {
      "t": 80910,
      "e": 79790,
      "ty": 2,
      "x": 868,
      "y": 940
    },
    {
      "t": 81010,
      "e": 79890,
      "ty": 2,
      "x": 873,
      "y": 937
    },
    {
      "t": 81010,
      "e": 79890,
      "ty": 41,
      "x": 29788,
      "y": 51464,
      "ta": "html > body"
    },
    {
      "t": 81310,
      "e": 80190,
      "ty": 2,
      "x": 874,
      "y": 937
    },
    {
      "t": 81510,
      "e": 80390,
      "ty": 41,
      "x": 29823,
      "y": 51464,
      "ta": "html > body"
    },
    {
      "t": 81611,
      "e": 80491,
      "ty": 2,
      "x": 875,
      "y": 937
    },
    {
      "t": 81710,
      "e": 80590,
      "ty": 2,
      "x": 878,
      "y": 936
    },
    {
      "t": 81760,
      "e": 80640,
      "ty": 41,
      "x": 30029,
      "y": 51408,
      "ta": "html > body"
    },
    {
      "t": 81811,
      "e": 80691,
      "ty": 2,
      "x": 882,
      "y": 936
    },
    {
      "t": 81911,
      "e": 80791,
      "ty": 2,
      "x": 942,
      "y": 1024
    },
    {
      "t": 82010,
      "e": 80890,
      "ty": 2,
      "x": 1017,
      "y": 1126
    },
    {
      "t": 82010,
      "e": 80890,
      "ty": 41,
      "x": 34747,
      "y": 61934,
      "ta": "html > body"
    },
    {
      "t": 82110,
      "e": 80990,
      "ty": 2,
      "x": 1106,
      "y": 1167
    },
    {
      "t": 82210,
      "e": 81090,
      "ty": 2,
      "x": 1218,
      "y": 1179
    },
    {
      "t": 82260,
      "e": 81140,
      "ty": 41,
      "x": 42943,
      "y": 65036,
      "ta": "html > body"
    },
    {
      "t": 82309,
      "e": 81189,
      "ty": 2,
      "x": 1268,
      "y": 1182
    },
    {
      "t": 82411,
      "e": 81291,
      "ty": 2,
      "x": 1273,
      "y": 1183
    },
    {
      "t": 82610,
      "e": 81490,
      "ty": 2,
      "x": 1270,
      "y": 1183
    },
    {
      "t": 82876,
      "e": 81756,
      "ty": 3,
      "x": 1270,
      "y": 1183,
      "ta": "html"
    },
    {
      "t": 83010,
      "e": 81890,
      "ty": 1,
      "x": 8,
      "y": 0
    },
    {
      "t": 83610,
      "e": 82490,
      "ty": 1,
      "x": 0,
      "y": 0
    },
    {
      "t": 83644,
      "e": 82524,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 83650,
      "e": 82530,
      "ty": 4,
      "x": 42255,
      "y": 65534,
      "ta": "html"
    },
    {
      "t": 83709,
      "e": 82589,
      "ty": 2,
      "x": 1227,
      "y": 1180
    },
    {
      "t": 83759,
      "e": 82639,
      "ty": 41,
      "x": 42289,
      "y": 61546,
      "ta": "> div.masterdiv"
    },
    {
      "t": 83810,
      "e": 82690,
      "ty": 2,
      "x": 1246,
      "y": 1035
    },
    {
      "t": 83910,
      "e": 82790,
      "ty": 2,
      "x": 1241,
      "y": 938
    },
    {
      "t": 84010,
      "e": 82890,
      "ty": 2,
      "x": 1239,
      "y": 935
    },
    {
      "t": 84010,
      "e": 82890,
      "ty": 41,
      "x": 46518,
      "y": 56000,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 84760,
      "e": 83640,
      "ty": 41,
      "x": 46419,
      "y": 56000,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 84810,
      "e": 83690,
      "ty": 2,
      "x": 1222,
      "y": 946
    },
    {
      "t": 84909,
      "e": 83789,
      "ty": 2,
      "x": 1217,
      "y": 950
    },
    {
      "t": 85009,
      "e": 83889,
      "ty": 2,
      "x": 1217,
      "y": 951
    },
    {
      "t": 85010,
      "e": 83890,
      "ty": 41,
      "x": 45435,
      "y": 57108,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 86110,
      "e": 84990,
      "ty": 2,
      "x": 1215,
      "y": 951
    },
    {
      "t": 86210,
      "e": 85090,
      "ty": 2,
      "x": 1210,
      "y": 953
    },
    {
      "t": 86260,
      "e": 85140,
      "ty": 41,
      "x": 44845,
      "y": 57246,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 86309,
      "e": 85189,
      "ty": 2,
      "x": 1202,
      "y": 954
    },
    {
      "t": 86410,
      "e": 85290,
      "ty": 2,
      "x": 1193,
      "y": 955
    },
    {
      "t": 86510,
      "e": 85390,
      "ty": 2,
      "x": 1183,
      "y": 957
    },
    {
      "t": 86510,
      "e": 85390,
      "ty": 41,
      "x": 43763,
      "y": 57523,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 86609,
      "e": 85489,
      "ty": 2,
      "x": 1162,
      "y": 961
    },
    {
      "t": 86710,
      "e": 85590,
      "ty": 2,
      "x": 1105,
      "y": 996
    },
    {
      "t": 86760,
      "e": 85640,
      "ty": 41,
      "x": 38843,
      "y": 61540,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 86809,
      "e": 85689,
      "ty": 2,
      "x": 1070,
      "y": 1031
    },
    {
      "t": 86910,
      "e": 85790,
      "ty": 2,
      "x": 1058,
      "y": 1047
    },
    {
      "t": 87010,
      "e": 85890,
      "ty": 2,
      "x": 1051,
      "y": 1055
    },
    {
      "t": 87010,
      "e": 85890,
      "ty": 41,
      "x": 37269,
      "y": 64310,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 87110,
      "e": 85990,
      "ty": 2,
      "x": 1045,
      "y": 1063
    },
    {
      "t": 87210,
      "e": 86090,
      "ty": 2,
      "x": 1028,
      "y": 1073
    },
    {
      "t": 87226,
      "e": 86106,
      "ty": 6,
      "x": 1026,
      "y": 1074,
      "ta": "#start"
    },
    {
      "t": 87260,
      "e": 86140,
      "ty": 41,
      "x": 59254,
      "y": 14094,
      "ta": "#start"
    },
    {
      "t": 87310,
      "e": 86190,
      "ty": 2,
      "x": 1009,
      "y": 1082
    },
    {
      "t": 87410,
      "e": 86290,
      "ty": 2,
      "x": 1000,
      "y": 1087
    },
    {
      "t": 87509,
      "e": 86389,
      "ty": 2,
      "x": 999,
      "y": 1088
    },
    {
      "t": 87510,
      "e": 86390,
      "ty": 41,
      "x": 48878,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 87627,
      "e": 86507,
      "ty": 3,
      "x": 999,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 87629,
      "e": 86509,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 87682,
      "e": 86562,
      "ty": 4,
      "x": 48878,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 87683,
      "e": 86563,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 87683,
      "e": 86563,
      "ty": 5,
      "x": 999,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 87683,
      "e": 86563,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 88610,
      "e": 87490,
      "ty": 2,
      "x": 1000,
      "y": 1088
    },
    {
      "t": 88720,
      "e": 87600,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 89228,
      "e": 88108,
      "ty": 2,
      "x": 1004,
      "y": 1085
    },
    {
      "t": 89228,
      "e": 88108,
      "ty": 41,
      "x": 35774,
      "y": 32925,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 89267,
      "e": 88147,
      "ty": 41,
      "x": 35910,
      "y": 32924,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 89309,
      "e": 88189,
      "ty": 2,
      "x": 1006,
      "y": 1083
    },
    {
      "t": 89709,
      "e": 88589,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"id\":2593},{\"id\":2594},{\"id\":2595},{\"id\":2596},{\"id\":2597},{\"id\":2598},{\"id\":2599},{\"id\":2600},{\"nodeType\":3,\"id\":2604,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2601},{\"id\":2602},{\"nodeType\":3,\"id\":2605,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2603}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2606,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2607,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2606},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2608,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2607},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2609,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2608},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2607}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2607}},{\"nodeType\":3,\"id\":2612,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2608}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2608}},{\"nodeType\":3,\"id\":2615,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2616,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2609}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2606},{\"id\":2607},{\"id\":2610},{\"id\":2612},{\"id\":2611},{\"id\":2608},{\"id\":2613},{\"id\":2615},{\"id\":2614},{\"id\":2609},{\"id\":2616}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2617,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2621,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2620},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2622},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2625,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2625},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2626},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2628,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2619}},{\"nodeType\":3,\"id\":2629,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2629},\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2631,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2625}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2631}},{\"nodeType\":3,\"id\":2633,\"textContent\":\"English\",\"previousSibling\":{\"id\":2632},\"parentNode\":{\"id\":2631}},{\"nodeType\":1,\"id\":2634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2635,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2634}},{\"nodeType\":3,\"id\":2636,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2635},\"parentNode\":{\"id\":2634}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2627}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":3,\"id\":2639,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2628}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":3,\"id\":2642,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2640}},{\"nodeType\":3,\"id\":2643,\"textContent\":\"*\",\"parentNode\":{\"id\":2630}},{\"nodeType\":1,\"id\":2644,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2645},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2646},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2648,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2648},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2649},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2651,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2620}},{\"nodeType\":3,\"id\":2652,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2652},\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2654,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2654}},{\"nodeType\":3,\"id\":2656,\"textContent\":\"First\",\"previousSibling\":{\"id\":2655},\"parentNode\":{\"id\":2654}},{\"nodeType\":1,\"id\":2657,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2657}},{\"nodeType\":3,\"id\":2659,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2658},\"parentNode\":{\"id\":2657}},{\"nodeType\":1,\"id\":2660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2647}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2660}},{\"nodeType\":3,\"id\":2662,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2661},\"parentNode\":{\"id\":2660}},{\"nodeType\":1,\"id\":2663,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2648}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2663}},{\"nodeType\":3,\"id\":2665,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2664},\"parentNode\":{\"id\":2663}},{\"nodeType\":1,\"id\":2666,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2667,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2666}},{\"nodeType\":3,\"id\":2668,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2667},\"parentNode\":{\"id\":2666}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2650}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":3,\"id\":2671,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2651}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":3,\"id\":2674,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2672}},{\"nodeType\":3,\"id\":2675,\"textContent\":\"*\",\"parentNode\":{\"id\":2653}},{\"nodeType\":1,\"id\":2676,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2677},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2678},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2680,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2680},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2681},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2683,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2621}},{\"nodeType\":3,\"id\":2684,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2684},\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2686,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2686}},{\"nodeType\":3,\"id\":2688,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2687},\"parentNode\":{\"id\":2686}},{\"nodeType\":1,\"id\":2689,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2689}},{\"nodeType\":3,\"id\":2691,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2690},\"parentNode\":{\"id\":2689}},{\"nodeType\":1,\"id\":2692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2679}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2692}},{\"nodeType\":3,\"id\":2694,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2693},\"parentNode\":{\"id\":2692}},{\"nodeType\":1,\"id\":2695,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2680}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2695}},{\"nodeType\":3,\"id\":2697,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2696},\"parentNode\":{\"id\":2695}},{\"nodeType\":1,\"id\":2698,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2699,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2698}},{\"nodeType\":3,\"id\":2700,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2699},\"parentNode\":{\"id\":2698}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2682}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":3,\"id\":2703,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2704,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2683}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2704}},{\"nodeType\":3,\"id\":2706,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2705},\"parentNode\":{\"id\":2704}},{\"nodeType\":3,\"id\":2707,\"textContent\":\"*\",\"parentNode\":{\"id\":2685}},{\"nodeType\":1,\"id\":2708,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2708},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2709},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2711,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2622}},{\"nodeType\":3,\"id\":2712,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2712},\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2714,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2715,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2714}},{\"nodeType\":3,\"id\":2716,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2715},\"parentNode\":{\"id\":2714}},{\"nodeType\":1,\"id\":2717,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2710}},{\"nodeType\":1,\"id\":2718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2717}},{\"nodeType\":3,\"id\":2719,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2717}},{\"nodeType\":1,\"id\":2720,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2711}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2722,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2723,\"textContent\":\"*\",\"parentNode\":{\"id\":2713}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2617},{\"id\":2618},{\"id\":2619},{\"id\":2624},{\"id\":2629},{\"id\":2630},{\"id\":2643},{\"id\":2625},{\"id\":2631},{\"id\":2632},{\"id\":2633},{\"id\":2626},{\"id\":2634},{\"id\":2635},{\"id\":2636},{\"id\":2627},{\"id\":2637},{\"id\":2638},{\"id\":2639},{\"id\":2628},{\"id\":2640},{\"id\":2641},{\"id\":2642},{\"id\":2620},{\"id\":2644},{\"id\":2652},{\"id\":2653},{\"id\":2675},{\"id\":2645},{\"id\":2654},{\"id\":2655},{\"id\":2656},{\"id\":2646},{\"id\":2657},{\"id\":2658},{\"id\":2659},{\"id\":2647},{\"id\":2660},{\"id\":2661},{\"id\":2662},{\"id\":2648},{\"id\":2663},{\"id\":2664},{\"id\":2665},{\"id\":2649},{\"id\":2666},{\"id\":2667},{\"id\":2668},{\"id\":2650},{\"id\":2669},{\"id\":2670},{\"id\":2671},{\"id\":2651},{\"id\":2672},{\"id\":2673},{\"id\":2674},{\"id\":2621},{\"id\":2676},{\"id\":2684},{\"id\":2685},{\"id\":2707},{\"id\":2677},{\"id\":2686},{\"id\":2687},{\"id\":2688},{\"id\":2678},{\"id\":2689},{\"id\":2690},{\"id\":2691},{\"id\":2679},{\"id\":2692},{\"id\":2693},{\"id\":2694},{\"id\":2680},{\"id\":2695},{\"id\":2696},{\"id\":2697},{\"id\":2681},{\"id\":2698},{\"id\":2699},{\"id\":2700},{\"id\":2682},{\"id\":2701},{\"id\":2702},{\"id\":2703},{\"id\":2683},{\"id\":2704},{\"id\":2705},{\"id\":2706},{\"id\":2622},{\"id\":2708},{\"id\":2712},{\"id\":2713},{\"id\":2723},{\"id\":2709},{\"id\":2714},{\"id\":2715},{\"id\":2716},{\"id\":2710},{\"id\":2717},{\"id\":2718},{\"id\":2719},{\"id\":2711},{\"id\":2720},{\"id\":2721},{\"id\":2722},{\"id\":2623}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2724,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"previousSibling\":{\"id\":2724},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2726,\"textContent\":\" \",\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"previousSibling\":{\"id\":2727},\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2731,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2730},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"previousSibling\":{\"id\":2731},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2733,\"textContent\":\" \",\"parentNode\":{\"id\":2727}},{\"nodeType\":1,\"id\":2734,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"previousSibling\":{\"id\":2734},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2736,\"textContent\":\" \",\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2739,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"parentNode\":{\"id\":2729}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2743,\"textContent\":\" \",\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2744,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2747,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2746},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"previousSibling\":{\"id\":2747},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" \",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2751,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2750},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"previousSibling\":{\"id\":2751},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2744}},{\"nodeType\":3,\"id\":2756,\"textContent\":\" \",\"parentNode\":{\"id\":2745}},{\"nodeType\":1,\"id\":2757,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2758,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2757},\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2757}},{\"nodeType\":3,\"id\":2760,\"textContent\":\" \",\"parentNode\":{\"id\":2747}},{\"nodeType\":1,\"id\":2761,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2760},\"parentNode\":{\"id\":2747}},{\"nodeType\":3,\"id\":2762,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2747}},{\"nodeType\":3,\"id\":2763,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2761}},{\"nodeType\":1,\"id\":2764,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2765,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2764},\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2764}},{\"nodeType\":3,\"id\":2767,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2751}},{\"nodeType\":3,\"id\":2768,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2753}},{\"nodeType\":3,\"id\":2769,\"textContent\":\" \",\"parentNode\":{\"id\":2731}},{\"nodeType\":1,\"id\":2770,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2769},\"parentNode\":{\"id\":2731}},{\"nodeType\":3,\"id\":2771,\"textContent\":\" \",\"previousSibling\":{\"id\":2770},\"parentNode\":{\"id\":2731}},{\"nodeType\":3,\"id\":2772,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2770}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2724},{\"id\":2726},{\"id\":2727},{\"id\":2733},{\"id\":2734},{\"id\":2736},{\"id\":2737},{\"id\":2739},{\"id\":2738},{\"id\":2735},{\"id\":2728},{\"id\":2729},{\"id\":2740},{\"id\":2741},{\"id\":2743},{\"id\":2744},{\"id\":2755},{\"id\":2745},{\"id\":2756},{\"id\":2757},{\"id\":2759},{\"id\":2758},{\"id\":2746},{\"id\":2747},{\"id\":2760},{\"id\":2761},{\"id\":2763},{\"id\":2762},{\"id\":2748},{\"id\":2749},{\"id\":2764},{\"id\":2766},{\"id\":2765},{\"id\":2750},{\"id\":2751},{\"id\":2767},{\"id\":2752},{\"id\":2753},{\"id\":2768},{\"id\":2754},{\"id\":2742},{\"id\":2730},{\"id\":2731},{\"id\":2769},{\"id\":2770},{\"id\":2772},{\"id\":2771},{\"id\":2732},{\"id\":2725}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2773,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2774,\"textContent\":\"[ { \\\"rt\\\": 17690, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 17698, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"DK1EM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 3750, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 22537, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"DK1EM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 7627, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"tango\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"113\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 31172, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"DK1EM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 31346, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 63608, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"DK1EM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 17553, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 82164, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"DK1EM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 22190, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 105579, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"DK1EM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-09 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1028,y:1054,t:1527635436053};\\\", \\\"{x:1026,y:1053,t:1527635436077};\\\", \\\"{x:1021,y:1053,t:1527635436085};\\\", \\\"{x:1014,y:1050,t:1527635436099};\\\", \\\"{x:1000,y:1045,t:1527635436116};\\\", \\\"{x:993,y:1044,t:1527635436133};\\\", \\\"{x:993,y:1043,t:1527635436166};\\\", \\\"{x:994,y:1043,t:1527635436887};\\\", \\\"{x:1000,y:1036,t:1527635436901};\\\", \\\"{x:1029,y:1024,t:1527635436917};\\\", \\\"{x:1073,y:999,t:1527635436934};\\\", \\\"{x:1094,y:988,t:1527635436951};\\\", \\\"{x:1113,y:978,t:1527635436967};\\\", \\\"{x:1133,y:969,t:1527635436984};\\\", \\\"{x:1150,y:960,t:1527635437001};\\\", \\\"{x:1173,y:951,t:1527635437018};\\\", \\\"{x:1197,y:943,t:1527635437033};\\\", \\\"{x:1221,y:932,t:1527635437050};\\\", \\\"{x:1239,y:927,t:1527635437067};\\\", \\\"{x:1259,y:921,t:1527635437084};\\\", \\\"{x:1277,y:920,t:1527635437100};\\\", \\\"{x:1294,y:916,t:1527635437117};\\\", \\\"{x:1311,y:915,t:1527635437134};\\\", \\\"{x:1313,y:914,t:1527635437149};\\\", \\\"{x:1314,y:914,t:1527635437168};\\\", \\\"{x:1311,y:915,t:1527635437335};\\\", \\\"{x:1310,y:916,t:1527635437351};\\\", \\\"{x:1308,y:919,t:1527635437367};\\\", \\\"{x:1306,y:920,t:1527635437383};\\\", \\\"{x:1305,y:921,t:1527635437401};\\\", \\\"{x:1305,y:922,t:1527635437418};\\\", \\\"{x:1305,y:923,t:1527635437438};\\\", \\\"{x:1305,y:924,t:1527635437452};\\\", \\\"{x:1304,y:924,t:1527635437467};\\\", \\\"{x:1303,y:924,t:1527635437550};\\\", \\\"{x:1303,y:925,t:1527635437791};\\\", \\\"{x:1303,y:927,t:1527635437822};\\\", \\\"{x:1303,y:928,t:1527635437839};\\\", \\\"{x:1302,y:929,t:1527635437851};\\\", \\\"{x:1302,y:930,t:1527635437910};\\\", \\\"{x:1301,y:930,t:1527635438214};\\\", \\\"{x:1300,y:930,t:1527635438431};\\\", \\\"{x:1299,y:930,t:1527635438855};\\\", \\\"{x:1298,y:930,t:1527635438878};\\\", \\\"{x:1296,y:929,t:1527635438895};\\\", \\\"{x:1297,y:930,t:1527635440918};\\\", \\\"{x:1297,y:932,t:1527635440958};\\\", \\\"{x:1297,y:933,t:1527635440990};\\\", \\\"{x:1297,y:934,t:1527635441023};\\\", \\\"{x:1299,y:935,t:1527635441046};\\\", \\\"{x:1299,y:936,t:1527635441094};\\\", \\\"{x:1299,y:937,t:1527635441143};\\\", \\\"{x:1299,y:938,t:1527635441183};\\\", \\\"{x:1299,y:939,t:1527635441198};\\\", \\\"{x:1299,y:940,t:1527635441230};\\\", \\\"{x:1299,y:941,t:1527635441543};\\\", \\\"{x:1299,y:942,t:1527635441573};\\\", \\\"{x:1299,y:943,t:1527635441646};\\\", \\\"{x:1299,y:944,t:1527635441678};\\\", \\\"{x:1296,y:944,t:1527635441702};\\\", \\\"{x:1292,y:944,t:1527635441721};\\\", \\\"{x:1285,y:944,t:1527635441737};\\\", \\\"{x:1268,y:941,t:1527635441753};\\\", \\\"{x:1240,y:934,t:1527635441770};\\\", \\\"{x:1198,y:921,t:1527635441787};\\\", \\\"{x:1139,y:904,t:1527635441803};\\\", \\\"{x:1062,y:884,t:1527635441820};\\\", \\\"{x:948,y:837,t:1527635441838};\\\", \\\"{x:889,y:810,t:1527635441853};\\\", \\\"{x:812,y:776,t:1527635441870};\\\", \\\"{x:747,y:741,t:1527635441887};\\\", \\\"{x:684,y:703,t:1527635441904};\\\", \\\"{x:616,y:667,t:1527635441921};\\\", \\\"{x:553,y:625,t:1527635441939};\\\", \\\"{x:509,y:590,t:1527635441954};\\\", \\\"{x:477,y:566,t:1527635441970};\\\", \\\"{x:449,y:547,t:1527635441988};\\\", \\\"{x:424,y:527,t:1527635442006};\\\", \\\"{x:418,y:521,t:1527635442021};\\\", \\\"{x:412,y:513,t:1527635442038};\\\", \\\"{x:409,y:506,t:1527635442055};\\\", \\\"{x:409,y:502,t:1527635442071};\\\", \\\"{x:408,y:495,t:1527635442088};\\\", \\\"{x:408,y:489,t:1527635442105};\\\", \\\"{x:408,y:487,t:1527635442120};\\\", \\\"{x:409,y:485,t:1527635442141};\\\", \\\"{x:410,y:485,t:1527635442205};\\\", \\\"{x:410,y:486,t:1527635442253};\\\", \\\"{x:410,y:487,t:1527635442261};\\\", \\\"{x:410,y:490,t:1527635442271};\\\", \\\"{x:410,y:493,t:1527635442288};\\\", \\\"{x:410,y:497,t:1527635442305};\\\", \\\"{x:410,y:502,t:1527635442321};\\\", \\\"{x:410,y:505,t:1527635442338};\\\", \\\"{x:410,y:509,t:1527635442356};\\\", \\\"{x:410,y:510,t:1527635442371};\\\", \\\"{x:410,y:512,t:1527635442388};\\\", \\\"{x:408,y:514,t:1527635442405};\\\", \\\"{x:408,y:515,t:1527635442422};\\\", \\\"{x:407,y:516,t:1527635442438};\\\", \\\"{x:406,y:517,t:1527635442455};\\\", \\\"{x:405,y:517,t:1527635442472};\\\", \\\"{x:403,y:517,t:1527635442489};\\\", \\\"{x:402,y:517,t:1527635442510};\\\", \\\"{x:401,y:517,t:1527635442523};\\\", \\\"{x:400,y:518,t:1527635442539};\\\", \\\"{x:399,y:518,t:1527635442555};\\\", \\\"{x:397,y:518,t:1527635442573};\\\", \\\"{x:394,y:518,t:1527635442590};\\\", \\\"{x:393,y:518,t:1527635442605};\\\", \\\"{x:392,y:521,t:1527635442837};\\\", \\\"{x:396,y:527,t:1527635442845};\\\", \\\"{x:396,y:529,t:1527635442855};\\\", \\\"{x:403,y:541,t:1527635442872};\\\", \\\"{x:409,y:557,t:1527635442890};\\\", \\\"{x:416,y:572,t:1527635442905};\\\", \\\"{x:423,y:588,t:1527635442924};\\\", \\\"{x:433,y:606,t:1527635442939};\\\", \\\"{x:439,y:621,t:1527635442957};\\\", \\\"{x:445,y:634,t:1527635442972};\\\", \\\"{x:449,y:653,t:1527635442989};\\\", \\\"{x:454,y:666,t:1527635443005};\\\", \\\"{x:456,y:675,t:1527635443022};\\\", \\\"{x:462,y:684,t:1527635443039};\\\", \\\"{x:468,y:695,t:1527635443056};\\\", \\\"{x:472,y:699,t:1527635443072};\\\", \\\"{x:474,y:701,t:1527635443090};\\\", \\\"{x:477,y:703,t:1527635443106};\\\", \\\"{x:478,y:703,t:1527635443122};\\\", \\\"{x:480,y:705,t:1527635443138};\\\", \\\"{x:481,y:705,t:1527635443173};\\\", \\\"{x:481,y:706,t:1527635443189};\\\", \\\"{x:484,y:707,t:1527635443221};\\\", \\\"{x:485,y:708,t:1527635443229};\\\", \\\"{x:486,y:709,t:1527635443239};\\\", \\\"{x:487,y:710,t:1527635443256};\\\", \\\"{x:488,y:711,t:1527635443272};\\\", \\\"{x:491,y:711,t:1527635444646};\\\", \\\"{x:492,y:711,t:1527635444669};\\\", \\\"{x:493,y:711,t:1527635444702};\\\", \\\"{x:494,y:710,t:1527635444845};\\\" ] }, { \\\"rt\\\": 18717, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 125542, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"DK1EM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:495,y:710,t:1527635445950};\\\", \\\"{x:497,y:709,t:1527635445958};\\\", \\\"{x:497,y:708,t:1527635445982};\\\", \\\"{x:497,y:706,t:1527635445998};\\\", \\\"{x:498,y:705,t:1527635446008};\\\", \\\"{x:498,y:704,t:1527635446025};\\\", \\\"{x:499,y:701,t:1527635446041};\\\", \\\"{x:500,y:700,t:1527635446059};\\\", \\\"{x:501,y:699,t:1527635446075};\\\", \\\"{x:501,y:697,t:1527635446091};\\\", \\\"{x:503,y:697,t:1527635446110};\\\", \\\"{x:503,y:696,t:1527635446558};\\\", \\\"{x:504,y:695,t:1527635446582};\\\", \\\"{x:504,y:694,t:1527635446621};\\\", \\\"{x:505,y:692,t:1527635450254};\\\", \\\"{x:506,y:692,t:1527635450822};\\\", \\\"{x:507,y:692,t:1527635451792};\\\", \\\"{x:508,y:692,t:1527635451845};\\\", \\\"{x:509,y:691,t:1527635451862};\\\", \\\"{x:509,y:690,t:1527635452838};\\\", \\\"{x:508,y:689,t:1527635452845};\\\", \\\"{x:503,y:687,t:1527635452862};\\\", \\\"{x:501,y:686,t:1527635452879};\\\", \\\"{x:501,y:685,t:1527635452896};\\\", \\\"{x:500,y:685,t:1527635452989};\\\", \\\"{x:501,y:685,t:1527635453660};\\\", \\\"{x:502,y:685,t:1527635453717};\\\", \\\"{x:504,y:685,t:1527635453805};\\\", \\\"{x:505,y:685,t:1527635453845};\\\", \\\"{x:506,y:685,t:1527635453861};\\\", \\\"{x:507,y:685,t:1527635453885};\\\", \\\"{x:507,y:684,t:1527635453896};\\\", \\\"{x:508,y:683,t:1527635453917};\\\", \\\"{x:509,y:682,t:1527635453950};\\\", \\\"{x:510,y:682,t:1527635454037};\\\", \\\"{x:511,y:682,t:1527635454053};\\\", \\\"{x:512,y:682,t:1527635454422};\\\", \\\"{x:515,y:676,t:1527635460347};\\\", \\\"{x:520,y:669,t:1527635460366};\\\", \\\"{x:525,y:656,t:1527635460383};\\\", \\\"{x:533,y:645,t:1527635460400};\\\", \\\"{x:539,y:636,t:1527635460415};\\\", \\\"{x:545,y:629,t:1527635460432};\\\", \\\"{x:550,y:625,t:1527635460448};\\\", \\\"{x:557,y:619,t:1527635460467};\\\", \\\"{x:564,y:615,t:1527635460483};\\\", \\\"{x:568,y:613,t:1527635460500};\\\", \\\"{x:570,y:613,t:1527635460516};\\\", \\\"{x:572,y:611,t:1527635460534};\\\", \\\"{x:573,y:610,t:1527635460550};\\\", \\\"{x:573,y:609,t:1527635460570};\\\", \\\"{x:572,y:607,t:1527635460586};\\\", \\\"{x:567,y:605,t:1527635460599};\\\", \\\"{x:553,y:603,t:1527635460616};\\\", \\\"{x:521,y:599,t:1527635460633};\\\", \\\"{x:493,y:597,t:1527635460651};\\\", \\\"{x:464,y:596,t:1527635460666};\\\", \\\"{x:441,y:592,t:1527635460683};\\\", \\\"{x:420,y:592,t:1527635460700};\\\", \\\"{x:408,y:592,t:1527635460717};\\\", \\\"{x:402,y:592,t:1527635460734};\\\", \\\"{x:400,y:592,t:1527635460749};\\\", \\\"{x:399,y:592,t:1527635460875};\\\", \\\"{x:399,y:590,t:1527635460891};\\\", \\\"{x:399,y:589,t:1527635460914};\\\", \\\"{x:397,y:589,t:1527635460987};\\\", \\\"{x:395,y:589,t:1527635461001};\\\", \\\"{x:383,y:589,t:1527635461018};\\\", \\\"{x:346,y:589,t:1527635461036};\\\", \\\"{x:320,y:589,t:1527635461050};\\\", \\\"{x:294,y:587,t:1527635461066};\\\", \\\"{x:275,y:584,t:1527635461083};\\\", \\\"{x:261,y:582,t:1527635461101};\\\", \\\"{x:257,y:580,t:1527635461118};\\\", \\\"{x:251,y:579,t:1527635461134};\\\", \\\"{x:249,y:578,t:1527635461151};\\\", \\\"{x:248,y:578,t:1527635461166};\\\", \\\"{x:247,y:578,t:1527635461202};\\\", \\\"{x:244,y:578,t:1527635461218};\\\", \\\"{x:243,y:578,t:1527635461234};\\\", \\\"{x:236,y:582,t:1527635461251};\\\", \\\"{x:226,y:591,t:1527635461268};\\\", \\\"{x:213,y:598,t:1527635461284};\\\", \\\"{x:204,y:602,t:1527635461301};\\\", \\\"{x:194,y:610,t:1527635461316};\\\", \\\"{x:179,y:616,t:1527635461334};\\\", \\\"{x:162,y:619,t:1527635461351};\\\", \\\"{x:149,y:622,t:1527635461369};\\\", \\\"{x:140,y:625,t:1527635461384};\\\", \\\"{x:136,y:627,t:1527635461401};\\\", \\\"{x:133,y:627,t:1527635461418};\\\", \\\"{x:134,y:629,t:1527635461699};\\\", \\\"{x:135,y:629,t:1527635461714};\\\", \\\"{x:136,y:629,t:1527635461722};\\\", \\\"{x:138,y:629,t:1527635461747};\\\", \\\"{x:140,y:630,t:1527635461755};\\\", \\\"{x:141,y:630,t:1527635461786};\\\", \\\"{x:142,y:630,t:1527635461801};\\\", \\\"{x:143,y:630,t:1527635461914};\\\", \\\"{x:143,y:630,t:1527635461923};\\\", \\\"{x:145,y:630,t:1527635462019};\\\", \\\"{x:177,y:640,t:1527635462035};\\\", \\\"{x:232,y:654,t:1527635462052};\\\", \\\"{x:299,y:672,t:1527635462068};\\\", \\\"{x:379,y:694,t:1527635462085};\\\", \\\"{x:449,y:714,t:1527635462103};\\\", \\\"{x:496,y:727,t:1527635462118};\\\", \\\"{x:526,y:735,t:1527635462134};\\\", \\\"{x:545,y:740,t:1527635462151};\\\", \\\"{x:551,y:743,t:1527635462167};\\\", \\\"{x:550,y:743,t:1527635462355};\\\", \\\"{x:546,y:743,t:1527635462368};\\\", \\\"{x:536,y:741,t:1527635462386};\\\", \\\"{x:520,y:737,t:1527635462402};\\\", \\\"{x:512,y:735,t:1527635462419};\\\", \\\"{x:507,y:732,t:1527635462435};\\\", \\\"{x:505,y:731,t:1527635462452};\\\", \\\"{x:504,y:729,t:1527635462467};\\\", \\\"{x:495,y:722,t:1527635462485};\\\", \\\"{x:483,y:716,t:1527635462502};\\\", \\\"{x:469,y:710,t:1527635462518};\\\", \\\"{x:449,y:702,t:1527635462535};\\\", \\\"{x:422,y:692,t:1527635462553};\\\", \\\"{x:388,y:674,t:1527635462568};\\\", \\\"{x:360,y:667,t:1527635462585};\\\", \\\"{x:322,y:654,t:1527635462601};\\\", \\\"{x:290,y:646,t:1527635462619};\\\", \\\"{x:267,y:638,t:1527635462635};\\\", \\\"{x:253,y:633,t:1527635462651};\\\", \\\"{x:241,y:628,t:1527635462668};\\\", \\\"{x:236,y:626,t:1527635462685};\\\", \\\"{x:232,y:625,t:1527635462701};\\\", \\\"{x:230,y:624,t:1527635462718};\\\", \\\"{x:229,y:624,t:1527635462745};\\\", \\\"{x:227,y:624,t:1527635462795};\\\", \\\"{x:224,y:624,t:1527635462802};\\\", \\\"{x:212,y:624,t:1527635462819};\\\", \\\"{x:197,y:624,t:1527635462834};\\\", \\\"{x:180,y:624,t:1527635462853};\\\", \\\"{x:168,y:624,t:1527635462869};\\\", \\\"{x:158,y:624,t:1527635462885};\\\", \\\"{x:154,y:624,t:1527635462902};\\\", \\\"{x:152,y:624,t:1527635462918};\\\", \\\"{x:153,y:624,t:1527635463185};\\\", \\\"{x:165,y:626,t:1527635463201};\\\", \\\"{x:186,y:634,t:1527635463219};\\\", \\\"{x:214,y:642,t:1527635463236};\\\", \\\"{x:267,y:658,t:1527635463252};\\\", \\\"{x:323,y:673,t:1527635463269};\\\", \\\"{x:370,y:687,t:1527635463286};\\\", \\\"{x:404,y:696,t:1527635463301};\\\", \\\"{x:426,y:699,t:1527635463319};\\\", \\\"{x:440,y:701,t:1527635463336};\\\", \\\"{x:454,y:703,t:1527635463353};\\\", \\\"{x:468,y:706,t:1527635463369};\\\", \\\"{x:485,y:708,t:1527635463385};\\\", \\\"{x:493,y:709,t:1527635463402};\\\", \\\"{x:500,y:709,t:1527635463419};\\\", \\\"{x:507,y:711,t:1527635463436};\\\", \\\"{x:515,y:711,t:1527635463452};\\\", \\\"{x:516,y:711,t:1527635463469};\\\", \\\"{x:518,y:711,t:1527635464066};\\\", \\\"{x:515,y:711,t:1527635464355};\\\", \\\"{x:515,y:712,t:1527635464370};\\\", \\\"{x:515,y:711,t:1527635464730};\\\", \\\"{x:516,y:711,t:1527635464746};\\\", \\\"{x:518,y:711,t:1527635464753};\\\" ] }, { \\\"rt\\\": 23225, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 150077, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"DK1EM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -A -Z -Z -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:533,y:704,t:1527635464993};\\\", \\\"{x:535,y:704,t:1527635465019};\\\", \\\"{x:536,y:703,t:1527635465042};\\\", \\\"{x:537,y:703,t:1527635465053};\\\", \\\"{x:539,y:701,t:1527635465071};\\\", \\\"{x:542,y:701,t:1527635465087};\\\", \\\"{x:546,y:698,t:1527635465104};\\\", \\\"{x:556,y:696,t:1527635465125};\\\", \\\"{x:560,y:694,t:1527635465136};\\\", \\\"{x:571,y:691,t:1527635465153};\\\", \\\"{x:582,y:688,t:1527635465171};\\\", \\\"{x:590,y:685,t:1527635465187};\\\", \\\"{x:599,y:683,t:1527635465204};\\\", \\\"{x:606,y:681,t:1527635465221};\\\", \\\"{x:614,y:679,t:1527635465236};\\\", \\\"{x:619,y:677,t:1527635465254};\\\", \\\"{x:622,y:676,t:1527635465271};\\\", \\\"{x:624,y:675,t:1527635465287};\\\", \\\"{x:625,y:675,t:1527635465378};\\\", \\\"{x:626,y:674,t:1527635467035};\\\", \\\"{x:627,y:674,t:1527635467083};\\\", \\\"{x:630,y:674,t:1527635467090};\\\", \\\"{x:631,y:674,t:1527635467105};\\\", \\\"{x:630,y:673,t:1527635467522};\\\", \\\"{x:629,y:673,t:1527635467547};\\\", \\\"{x:629,y:672,t:1527635467570};\\\", \\\"{x:627,y:672,t:1527635467923};\\\", \\\"{x:621,y:674,t:1527635467940};\\\", \\\"{x:617,y:677,t:1527635467956};\\\", \\\"{x:610,y:679,t:1527635467973};\\\", \\\"{x:606,y:682,t:1527635467989};\\\", \\\"{x:603,y:684,t:1527635468006};\\\", \\\"{x:603,y:685,t:1527635468023};\\\", \\\"{x:602,y:686,t:1527635468146};\\\", \\\"{x:600,y:686,t:1527635469451};\\\", \\\"{x:599,y:686,t:1527635469491};\\\", \\\"{x:597,y:686,t:1527635469507};\\\", \\\"{x:596,y:686,t:1527635469524};\\\", \\\"{x:595,y:686,t:1527635469633};\\\", \\\"{x:595,y:687,t:1527635470243};\\\", \\\"{x:596,y:687,t:1527635470322};\\\", \\\"{x:597,y:687,t:1527635470330};\\\", \\\"{x:601,y:687,t:1527635470341};\\\", \\\"{x:611,y:687,t:1527635470357};\\\", \\\"{x:632,y:682,t:1527635470375};\\\", \\\"{x:663,y:678,t:1527635470391};\\\", \\\"{x:713,y:670,t:1527635470407};\\\", \\\"{x:782,y:665,t:1527635470425};\\\", \\\"{x:852,y:653,t:1527635470441};\\\", \\\"{x:987,y:618,t:1527635470459};\\\", \\\"{x:1104,y:597,t:1527635470475};\\\", \\\"{x:1225,y:568,t:1527635470491};\\\", \\\"{x:1349,y:537,t:1527635470507};\\\", \\\"{x:1452,y:504,t:1527635470525};\\\", \\\"{x:1551,y:476,t:1527635470542};\\\", \\\"{x:1641,y:449,t:1527635470559};\\\", \\\"{x:1702,y:432,t:1527635470575};\\\", \\\"{x:1755,y:416,t:1527635470592};\\\", \\\"{x:1784,y:409,t:1527635470609};\\\", \\\"{x:1801,y:403,t:1527635470625};\\\", \\\"{x:1806,y:403,t:1527635470642};\\\", \\\"{x:1803,y:403,t:1527635470779};\\\", \\\"{x:1801,y:408,t:1527635470792};\\\", \\\"{x:1791,y:421,t:1527635470808};\\\", \\\"{x:1783,y:435,t:1527635470825};\\\", \\\"{x:1769,y:458,t:1527635470842};\\\", \\\"{x:1749,y:502,t:1527635470858};\\\", \\\"{x:1739,y:526,t:1527635470874};\\\", \\\"{x:1730,y:546,t:1527635470892};\\\", \\\"{x:1721,y:566,t:1527635470908};\\\", \\\"{x:1713,y:580,t:1527635470926};\\\", \\\"{x:1704,y:594,t:1527635470941};\\\", \\\"{x:1695,y:607,t:1527635470958};\\\", \\\"{x:1686,y:617,t:1527635470975};\\\", \\\"{x:1677,y:622,t:1527635470991};\\\", \\\"{x:1670,y:628,t:1527635471008};\\\", \\\"{x:1661,y:634,t:1527635471025};\\\", \\\"{x:1657,y:636,t:1527635471041};\\\", \\\"{x:1647,y:643,t:1527635471057};\\\", \\\"{x:1641,y:648,t:1527635471075};\\\", \\\"{x:1636,y:653,t:1527635471091};\\\", \\\"{x:1631,y:656,t:1527635471108};\\\", \\\"{x:1624,y:661,t:1527635471125};\\\", \\\"{x:1616,y:670,t:1527635471141};\\\", \\\"{x:1607,y:682,t:1527635471158};\\\", \\\"{x:1597,y:696,t:1527635471175};\\\", \\\"{x:1586,y:712,t:1527635471191};\\\", \\\"{x:1575,y:726,t:1527635471208};\\\", \\\"{x:1565,y:737,t:1527635471225};\\\", \\\"{x:1557,y:746,t:1527635471241};\\\", \\\"{x:1548,y:761,t:1527635471258};\\\", \\\"{x:1541,y:772,t:1527635471275};\\\", \\\"{x:1535,y:778,t:1527635471292};\\\", \\\"{x:1528,y:782,t:1527635471308};\\\", \\\"{x:1526,y:786,t:1527635471326};\\\", \\\"{x:1525,y:786,t:1527635471341};\\\", \\\"{x:1525,y:788,t:1527635471359};\\\", \\\"{x:1524,y:791,t:1527635471931};\\\", \\\"{x:1516,y:792,t:1527635471943};\\\", \\\"{x:1506,y:792,t:1527635471959};\\\", \\\"{x:1492,y:792,t:1527635471976};\\\", \\\"{x:1481,y:792,t:1527635471993};\\\", \\\"{x:1472,y:792,t:1527635472010};\\\", \\\"{x:1464,y:792,t:1527635472025};\\\", \\\"{x:1447,y:792,t:1527635472042};\\\", \\\"{x:1436,y:792,t:1527635472059};\\\", \\\"{x:1418,y:792,t:1527635472075};\\\", \\\"{x:1397,y:792,t:1527635472092};\\\", \\\"{x:1374,y:792,t:1527635472110};\\\", \\\"{x:1353,y:792,t:1527635472125};\\\", \\\"{x:1330,y:792,t:1527635472142};\\\", \\\"{x:1308,y:792,t:1527635472159};\\\", \\\"{x:1287,y:792,t:1527635472175};\\\", \\\"{x:1266,y:792,t:1527635472192};\\\", \\\"{x:1248,y:793,t:1527635472209};\\\", \\\"{x:1230,y:796,t:1527635472225};\\\", \\\"{x:1213,y:798,t:1527635472243};\\\", \\\"{x:1204,y:799,t:1527635472259};\\\", \\\"{x:1201,y:800,t:1527635472275};\\\", \\\"{x:1198,y:800,t:1527635472292};\\\", \\\"{x:1195,y:800,t:1527635472310};\\\", \\\"{x:1194,y:801,t:1527635472326};\\\", \\\"{x:1192,y:802,t:1527635472343};\\\", \\\"{x:1191,y:802,t:1527635472359};\\\", \\\"{x:1189,y:802,t:1527635472377};\\\", \\\"{x:1187,y:803,t:1527635472393};\\\", \\\"{x:1186,y:804,t:1527635472410};\\\", \\\"{x:1184,y:805,t:1527635472475};\\\", \\\"{x:1183,y:805,t:1527635472514};\\\", \\\"{x:1182,y:806,t:1527635472530};\\\", \\\"{x:1182,y:807,t:1527635472547};\\\", \\\"{x:1182,y:808,t:1527635472562};\\\", \\\"{x:1182,y:810,t:1527635472577};\\\", \\\"{x:1183,y:813,t:1527635472595};\\\", \\\"{x:1183,y:814,t:1527635472609};\\\", \\\"{x:1190,y:819,t:1527635472626};\\\", \\\"{x:1194,y:822,t:1527635472642};\\\", \\\"{x:1199,y:824,t:1527635472660};\\\", \\\"{x:1205,y:828,t:1527635472677};\\\", \\\"{x:1210,y:830,t:1527635472696};\\\", \\\"{x:1213,y:831,t:1527635472709};\\\", \\\"{x:1214,y:832,t:1527635472729};\\\", \\\"{x:1214,y:833,t:1527635472817};\\\", \\\"{x:1215,y:833,t:1527635475523};\\\", \\\"{x:1216,y:833,t:1527635476034};\\\", \\\"{x:1216,y:832,t:1527635476083};\\\", \\\"{x:1217,y:832,t:1527635478411};\\\", \\\"{x:1218,y:832,t:1527635478426};\\\", \\\"{x:1219,y:832,t:1527635478442};\\\", \\\"{x:1221,y:832,t:1527635478484};\\\", \\\"{x:1222,y:832,t:1527635478555};\\\", \\\"{x:1223,y:832,t:1527635478571};\\\", \\\"{x:1224,y:832,t:1527635478581};\\\", \\\"{x:1225,y:832,t:1527635478597};\\\", \\\"{x:1226,y:832,t:1527635478614};\\\", \\\"{x:1228,y:832,t:1527635478631};\\\", \\\"{x:1229,y:832,t:1527635478651};\\\", \\\"{x:1230,y:832,t:1527635478664};\\\", \\\"{x:1231,y:832,t:1527635478681};\\\", \\\"{x:1234,y:832,t:1527635478698};\\\", \\\"{x:1236,y:832,t:1527635478714};\\\", \\\"{x:1237,y:832,t:1527635478731};\\\", \\\"{x:1239,y:832,t:1527635478748};\\\", \\\"{x:1241,y:832,t:1527635478764};\\\", \\\"{x:1243,y:832,t:1527635478781};\\\", \\\"{x:1246,y:832,t:1527635478798};\\\", \\\"{x:1248,y:832,t:1527635478814};\\\", \\\"{x:1251,y:832,t:1527635478831};\\\", \\\"{x:1257,y:832,t:1527635478848};\\\", \\\"{x:1261,y:832,t:1527635478864};\\\", \\\"{x:1266,y:832,t:1527635478881};\\\", \\\"{x:1273,y:832,t:1527635478898};\\\", \\\"{x:1279,y:832,t:1527635478915};\\\", \\\"{x:1281,y:832,t:1527635478931};\\\", \\\"{x:1283,y:832,t:1527635478947};\\\", \\\"{x:1284,y:832,t:1527635478969};\\\", \\\"{x:1286,y:832,t:1527635479018};\\\", \\\"{x:1287,y:832,t:1527635481244};\\\", \\\"{x:1288,y:832,t:1527635481250};\\\", \\\"{x:1297,y:832,t:1527635481266};\\\", \\\"{x:1307,y:832,t:1527635481283};\\\", \\\"{x:1314,y:833,t:1527635481299};\\\", \\\"{x:1320,y:834,t:1527635481317};\\\", \\\"{x:1324,y:834,t:1527635481333};\\\", \\\"{x:1328,y:834,t:1527635481349};\\\", \\\"{x:1331,y:834,t:1527635481366};\\\", \\\"{x:1334,y:834,t:1527635481383};\\\", \\\"{x:1337,y:834,t:1527635481400};\\\", \\\"{x:1340,y:834,t:1527635481416};\\\", \\\"{x:1343,y:834,t:1527635481433};\\\", \\\"{x:1346,y:834,t:1527635481450};\\\", \\\"{x:1348,y:834,t:1527635481467};\\\", \\\"{x:1350,y:834,t:1527635481483};\\\", \\\"{x:1354,y:834,t:1527635481500};\\\", \\\"{x:1360,y:834,t:1527635481516};\\\", \\\"{x:1364,y:834,t:1527635481533};\\\", \\\"{x:1368,y:834,t:1527635481551};\\\", \\\"{x:1370,y:834,t:1527635481566};\\\", \\\"{x:1371,y:834,t:1527635481583};\\\", \\\"{x:1372,y:834,t:1527635481659};\\\", \\\"{x:1373,y:835,t:1527635482203};\\\", \\\"{x:1372,y:835,t:1527635482234};\\\", \\\"{x:1372,y:836,t:1527635482250};\\\", \\\"{x:1371,y:836,t:1527635482267};\\\", \\\"{x:1371,y:837,t:1527635482283};\\\", \\\"{x:1370,y:838,t:1527635482301};\\\", \\\"{x:1370,y:839,t:1527635482323};\\\", \\\"{x:1370,y:840,t:1527635482395};\\\", \\\"{x:1370,y:841,t:1527635482426};\\\", \\\"{x:1369,y:842,t:1527635482434};\\\", \\\"{x:1369,y:843,t:1527635482450};\\\", \\\"{x:1369,y:845,t:1527635482467};\\\", \\\"{x:1368,y:846,t:1527635482484};\\\", \\\"{x:1365,y:850,t:1527635482500};\\\", \\\"{x:1362,y:855,t:1527635482517};\\\", \\\"{x:1357,y:862,t:1527635482534};\\\", \\\"{x:1355,y:867,t:1527635482550};\\\", \\\"{x:1355,y:875,t:1527635482567};\\\", \\\"{x:1355,y:886,t:1527635482584};\\\", \\\"{x:1353,y:895,t:1527635482600};\\\", \\\"{x:1352,y:902,t:1527635482618};\\\", \\\"{x:1351,y:911,t:1527635482634};\\\", \\\"{x:1350,y:915,t:1527635482650};\\\", \\\"{x:1349,y:918,t:1527635482667};\\\", \\\"{x:1349,y:922,t:1527635482683};\\\", \\\"{x:1348,y:926,t:1527635482700};\\\", \\\"{x:1348,y:928,t:1527635482717};\\\", \\\"{x:1348,y:930,t:1527635482734};\\\", \\\"{x:1348,y:933,t:1527635482750};\\\", \\\"{x:1348,y:934,t:1527635482767};\\\", \\\"{x:1348,y:935,t:1527635482783};\\\", \\\"{x:1347,y:936,t:1527635482800};\\\", \\\"{x:1347,y:938,t:1527635482859};\\\", \\\"{x:1346,y:938,t:1527635482874};\\\", \\\"{x:1346,y:937,t:1527635483307};\\\", \\\"{x:1346,y:936,t:1527635483318};\\\", \\\"{x:1346,y:935,t:1527635483333};\\\", \\\"{x:1346,y:933,t:1527635483350};\\\", \\\"{x:1347,y:932,t:1527635483367};\\\", \\\"{x:1347,y:931,t:1527635483383};\\\", \\\"{x:1347,y:930,t:1527635483401};\\\", \\\"{x:1347,y:929,t:1527635483417};\\\", \\\"{x:1347,y:927,t:1527635483433};\\\", \\\"{x:1347,y:926,t:1527635483450};\\\", \\\"{x:1347,y:924,t:1527635483468};\\\", \\\"{x:1347,y:922,t:1527635483484};\\\", \\\"{x:1347,y:921,t:1527635483501};\\\", \\\"{x:1347,y:918,t:1527635483518};\\\", \\\"{x:1347,y:917,t:1527635483533};\\\", \\\"{x:1347,y:913,t:1527635483551};\\\", \\\"{x:1347,y:912,t:1527635483568};\\\", \\\"{x:1347,y:911,t:1527635483583};\\\", \\\"{x:1347,y:910,t:1527635483602};\\\", \\\"{x:1347,y:909,t:1527635483618};\\\", \\\"{x:1347,y:908,t:1527635483666};\\\", \\\"{x:1347,y:907,t:1527635483674};\\\", \\\"{x:1347,y:906,t:1527635483684};\\\", \\\"{x:1347,y:905,t:1527635483702};\\\", \\\"{x:1347,y:903,t:1527635483718};\\\", \\\"{x:1347,y:902,t:1527635483735};\\\", \\\"{x:1347,y:901,t:1527635483770};\\\", \\\"{x:1347,y:900,t:1527635483819};\\\", \\\"{x:1347,y:899,t:1527635483930};\\\", \\\"{x:1347,y:898,t:1527635483953};\\\", \\\"{x:1347,y:897,t:1527635483968};\\\", \\\"{x:1347,y:896,t:1527635483984};\\\", \\\"{x:1347,y:895,t:1527635484001};\\\", \\\"{x:1347,y:893,t:1527635484018};\\\", \\\"{x:1347,y:890,t:1527635484036};\\\", \\\"{x:1347,y:887,t:1527635484051};\\\", \\\"{x:1347,y:884,t:1527635484067};\\\", \\\"{x:1347,y:880,t:1527635484085};\\\", \\\"{x:1347,y:879,t:1527635484101};\\\", \\\"{x:1337,y:871,t:1527635484118};\\\", \\\"{x:1318,y:864,t:1527635484134};\\\", \\\"{x:1285,y:848,t:1527635484151};\\\", \\\"{x:1240,y:825,t:1527635484168};\\\", \\\"{x:1163,y:781,t:1527635484185};\\\", \\\"{x:1070,y:728,t:1527635484201};\\\", \\\"{x:938,y:640,t:1527635484217};\\\", \\\"{x:873,y:591,t:1527635484238};\\\", \\\"{x:821,y:552,t:1527635484253};\\\", \\\"{x:765,y:504,t:1527635484285};\\\", \\\"{x:751,y:494,t:1527635484302};\\\", \\\"{x:742,y:488,t:1527635484318};\\\", \\\"{x:739,y:487,t:1527635484335};\\\", \\\"{x:733,y:485,t:1527635484353};\\\", \\\"{x:726,y:485,t:1527635484369};\\\", \\\"{x:704,y:485,t:1527635484385};\\\", \\\"{x:686,y:486,t:1527635484402};\\\", \\\"{x:658,y:492,t:1527635484419};\\\", \\\"{x:621,y:506,t:1527635484436};\\\", \\\"{x:590,y:524,t:1527635484452};\\\", \\\"{x:561,y:547,t:1527635484471};\\\", \\\"{x:532,y:570,t:1527635484487};\\\", \\\"{x:511,y:583,t:1527635484503};\\\", \\\"{x:494,y:595,t:1527635484520};\\\", \\\"{x:481,y:605,t:1527635484536};\\\", \\\"{x:476,y:609,t:1527635484552};\\\", \\\"{x:470,y:613,t:1527635484570};\\\", \\\"{x:462,y:618,t:1527635484585};\\\", \\\"{x:452,y:622,t:1527635484603};\\\", \\\"{x:442,y:626,t:1527635484620};\\\", \\\"{x:430,y:630,t:1527635484636};\\\", \\\"{x:417,y:630,t:1527635484653};\\\", \\\"{x:402,y:630,t:1527635484670};\\\", \\\"{x:381,y:630,t:1527635484686};\\\", \\\"{x:356,y:630,t:1527635484702};\\\", \\\"{x:329,y:630,t:1527635484720};\\\", \\\"{x:303,y:628,t:1527635484736};\\\", \\\"{x:282,y:624,t:1527635484752};\\\", \\\"{x:258,y:621,t:1527635484770};\\\", \\\"{x:251,y:621,t:1527635484786};\\\", \\\"{x:247,y:620,t:1527635484802};\\\", \\\"{x:246,y:619,t:1527635484820};\\\", \\\"{x:247,y:619,t:1527635484898};\\\", \\\"{x:252,y:619,t:1527635484905};\\\", \\\"{x:262,y:618,t:1527635484920};\\\", \\\"{x:287,y:615,t:1527635484937};\\\", \\\"{x:335,y:615,t:1527635484952};\\\", \\\"{x:449,y:615,t:1527635484969};\\\", \\\"{x:544,y:615,t:1527635484987};\\\", \\\"{x:621,y:615,t:1527635485004};\\\", \\\"{x:688,y:615,t:1527635485020};\\\", \\\"{x:735,y:618,t:1527635485037};\\\", \\\"{x:765,y:618,t:1527635485054};\\\", \\\"{x:783,y:618,t:1527635485069};\\\", \\\"{x:793,y:618,t:1527635485087};\\\", \\\"{x:796,y:617,t:1527635485103};\\\", \\\"{x:798,y:616,t:1527635485119};\\\", \\\"{x:795,y:616,t:1527635485186};\\\", \\\"{x:787,y:616,t:1527635485203};\\\", \\\"{x:781,y:616,t:1527635485219};\\\", \\\"{x:779,y:616,t:1527635485237};\\\", \\\"{x:776,y:615,t:1527635485254};\\\", \\\"{x:775,y:614,t:1527635485347};\\\", \\\"{x:774,y:613,t:1527635485354};\\\", \\\"{x:763,y:613,t:1527635485371};\\\", \\\"{x:745,y:611,t:1527635485388};\\\", \\\"{x:719,y:606,t:1527635485405};\\\", \\\"{x:688,y:602,t:1527635485419};\\\", \\\"{x:659,y:597,t:1527635485436};\\\", \\\"{x:634,y:595,t:1527635485453};\\\", \\\"{x:611,y:591,t:1527635485470};\\\", \\\"{x:594,y:590,t:1527635485486};\\\", \\\"{x:578,y:590,t:1527635485504};\\\", \\\"{x:560,y:590,t:1527635485521};\\\", \\\"{x:542,y:590,t:1527635485537};\\\", \\\"{x:523,y:590,t:1527635485553};\\\", \\\"{x:513,y:590,t:1527635485571};\\\", \\\"{x:505,y:590,t:1527635485587};\\\", \\\"{x:499,y:590,t:1527635485603};\\\", \\\"{x:495,y:590,t:1527635485621};\\\", \\\"{x:489,y:591,t:1527635485637};\\\", \\\"{x:480,y:594,t:1527635485653};\\\", \\\"{x:467,y:596,t:1527635485670};\\\", \\\"{x:458,y:598,t:1527635485686};\\\", \\\"{x:455,y:599,t:1527635485704};\\\", \\\"{x:451,y:600,t:1527635485721};\\\", \\\"{x:449,y:601,t:1527635485737};\\\", \\\"{x:444,y:602,t:1527635485753};\\\", \\\"{x:439,y:603,t:1527635485770};\\\", \\\"{x:432,y:604,t:1527635485786};\\\", \\\"{x:427,y:605,t:1527635485803};\\\", \\\"{x:421,y:605,t:1527635485821};\\\", \\\"{x:416,y:605,t:1527635485838};\\\", \\\"{x:414,y:605,t:1527635485853};\\\", \\\"{x:412,y:605,t:1527635485871};\\\", \\\"{x:409,y:604,t:1527635485887};\\\", \\\"{x:408,y:604,t:1527635485954};\\\", \\\"{x:407,y:603,t:1527635485971};\\\", \\\"{x:406,y:601,t:1527635485988};\\\", \\\"{x:406,y:598,t:1527635486004};\\\", \\\"{x:404,y:595,t:1527635486021};\\\", \\\"{x:404,y:591,t:1527635486037};\\\", \\\"{x:404,y:589,t:1527635486054};\\\", \\\"{x:404,y:586,t:1527635486071};\\\", \\\"{x:403,y:584,t:1527635486088};\\\", \\\"{x:403,y:583,t:1527635486104};\\\", \\\"{x:403,y:580,t:1527635486122};\\\", \\\"{x:403,y:577,t:1527635486137};\\\", \\\"{x:403,y:576,t:1527635486154};\\\", \\\"{x:403,y:574,t:1527635486172};\\\", \\\"{x:403,y:573,t:1527635486193};\\\", \\\"{x:403,y:572,t:1527635486218};\\\", \\\"{x:402,y:571,t:1527635486338};\\\", \\\"{x:402,y:570,t:1527635486353};\\\", \\\"{x:397,y:569,t:1527635486371};\\\", \\\"{x:383,y:566,t:1527635486388};\\\", \\\"{x:366,y:565,t:1527635486404};\\\", \\\"{x:342,y:560,t:1527635486421};\\\", \\\"{x:316,y:557,t:1527635486437};\\\", \\\"{x:292,y:554,t:1527635486454};\\\", \\\"{x:270,y:550,t:1527635486472};\\\", \\\"{x:259,y:549,t:1527635486487};\\\", \\\"{x:253,y:549,t:1527635486505};\\\", \\\"{x:251,y:549,t:1527635486521};\\\", \\\"{x:249,y:547,t:1527635486538};\\\", \\\"{x:247,y:547,t:1527635486555};\\\", \\\"{x:246,y:547,t:1527635486570};\\\", \\\"{x:244,y:547,t:1527635486618};\\\", \\\"{x:243,y:547,t:1527635486626};\\\", \\\"{x:240,y:547,t:1527635486637};\\\", \\\"{x:233,y:547,t:1527635486655};\\\", \\\"{x:223,y:549,t:1527635486671};\\\", \\\"{x:214,y:551,t:1527635486688};\\\", \\\"{x:205,y:552,t:1527635486705};\\\", \\\"{x:200,y:553,t:1527635486721};\\\", \\\"{x:196,y:553,t:1527635486738};\\\", \\\"{x:195,y:553,t:1527635486755};\\\", \\\"{x:194,y:553,t:1527635486771};\\\", \\\"{x:192,y:553,t:1527635486788};\\\", \\\"{x:189,y:555,t:1527635486806};\\\", \\\"{x:185,y:555,t:1527635486821};\\\", \\\"{x:184,y:555,t:1527635486838};\\\", \\\"{x:182,y:555,t:1527635486854};\\\", \\\"{x:181,y:555,t:1527635486922};\\\", \\\"{x:180,y:555,t:1527635486938};\\\", \\\"{x:175,y:555,t:1527635486955};\\\", \\\"{x:173,y:555,t:1527635486971};\\\", \\\"{x:172,y:555,t:1527635486988};\\\", \\\"{x:171,y:555,t:1527635487004};\\\", \\\"{x:172,y:555,t:1527635487209};\\\", \\\"{x:174,y:556,t:1527635487222};\\\", \\\"{x:185,y:560,t:1527635487237};\\\", \\\"{x:206,y:566,t:1527635487255};\\\", \\\"{x:235,y:573,t:1527635487272};\\\", \\\"{x:260,y:580,t:1527635487289};\\\", \\\"{x:288,y:589,t:1527635487306};\\\", \\\"{x:322,y:599,t:1527635487321};\\\", \\\"{x:344,y:605,t:1527635487338};\\\", \\\"{x:368,y:613,t:1527635487356};\\\", \\\"{x:391,y:622,t:1527635487372};\\\", \\\"{x:412,y:631,t:1527635487390};\\\", \\\"{x:432,y:641,t:1527635487405};\\\", \\\"{x:449,y:650,t:1527635487421};\\\", \\\"{x:461,y:655,t:1527635487439};\\\", \\\"{x:468,y:657,t:1527635487455};\\\", \\\"{x:472,y:660,t:1527635487472};\\\", \\\"{x:475,y:662,t:1527635487488};\\\", \\\"{x:476,y:663,t:1527635487530};\\\", \\\"{x:477,y:663,t:1527635487586};\\\", \\\"{x:478,y:663,t:1527635487594};\\\", \\\"{x:480,y:664,t:1527635487626};\\\", \\\"{x:481,y:664,t:1527635487639};\\\", \\\"{x:484,y:667,t:1527635487655};\\\", \\\"{x:488,y:671,t:1527635487672};\\\", \\\"{x:489,y:673,t:1527635487688};\\\", \\\"{x:490,y:674,t:1527635487705};\\\", \\\"{x:491,y:676,t:1527635487722};\\\", \\\"{x:491,y:677,t:1527635487737};\\\", \\\"{x:491,y:678,t:1527635487761};\\\", \\\"{x:491,y:681,t:1527635487772};\\\", \\\"{x:491,y:684,t:1527635487788};\\\", \\\"{x:491,y:687,t:1527635487805};\\\", \\\"{x:491,y:692,t:1527635487822};\\\", \\\"{x:491,y:698,t:1527635487837};\\\", \\\"{x:491,y:699,t:1527635487855};\\\", \\\"{x:491,y:701,t:1527635487873};\\\", \\\"{x:491,y:702,t:1527635487888};\\\", \\\"{x:491,y:705,t:1527635487906};\\\", \\\"{x:491,y:706,t:1527635488802};\\\" ] }, { \\\"rt\\\": 13803, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 165108, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"DK1EM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-06 PM-05 PM-04 PM-04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:492,y:706,t:1527635489553};\\\", \\\"{x:493,y:706,t:1527635489625};\\\", \\\"{x:497,y:706,t:1527635490057};\\\", \\\"{x:501,y:704,t:1527635490073};\\\", \\\"{x:503,y:703,t:1527635490090};\\\", \\\"{x:504,y:703,t:1527635490108};\\\", \\\"{x:505,y:703,t:1527635490138};\\\", \\\"{x:506,y:703,t:1527635490578};\\\", \\\"{x:508,y:703,t:1527635490650};\\\", \\\"{x:509,y:703,t:1527635490666};\\\", \\\"{x:510,y:703,t:1527635490675};\\\", \\\"{x:511,y:703,t:1527635490745};\\\", \\\"{x:512,y:703,t:1527635490777};\\\", \\\"{x:513,y:702,t:1527635490825};\\\", \\\"{x:514,y:701,t:1527635490842};\\\", \\\"{x:515,y:701,t:1527635490914};\\\", \\\"{x:516,y:700,t:1527635490939};\\\", \\\"{x:517,y:700,t:1527635490991};\\\", \\\"{x:518,y:700,t:1527635491330};\\\", \\\"{x:519,y:699,t:1527635491346};\\\", \\\"{x:520,y:699,t:1527635491386};\\\", \\\"{x:520,y:698,t:1527635491499};\\\", \\\"{x:519,y:697,t:1527635491509};\\\", \\\"{x:518,y:697,t:1527635491586};\\\", \\\"{x:518,y:698,t:1527635491698};\\\", \\\"{x:517,y:700,t:1527635491709};\\\", \\\"{x:517,y:699,t:1527635491930};\\\", \\\"{x:517,y:698,t:1527635491954};\\\", \\\"{x:518,y:698,t:1527635491962};\\\", \\\"{x:519,y:698,t:1527635491986};\\\", \\\"{x:520,y:698,t:1527635492043};\\\", \\\"{x:521,y:698,t:1527635492066};\\\", \\\"{x:522,y:698,t:1527635492090};\\\", \\\"{x:522,y:697,t:1527635492098};\\\", \\\"{x:523,y:697,t:1527635492114};\\\", \\\"{x:524,y:697,t:1527635492130};\\\", \\\"{x:525,y:697,t:1527635492143};\\\", \\\"{x:527,y:697,t:1527635492160};\\\", \\\"{x:530,y:697,t:1527635492176};\\\", \\\"{x:531,y:697,t:1527635492194};\\\", \\\"{x:533,y:697,t:1527635492218};\\\", \\\"{x:534,y:697,t:1527635492234};\\\", \\\"{x:535,y:697,t:1527635492243};\\\", \\\"{x:538,y:697,t:1527635492259};\\\", \\\"{x:543,y:697,t:1527635492276};\\\", \\\"{x:548,y:698,t:1527635492294};\\\", \\\"{x:561,y:699,t:1527635492310};\\\", \\\"{x:578,y:701,t:1527635492327};\\\", \\\"{x:601,y:703,t:1527635492344};\\\", \\\"{x:631,y:707,t:1527635492360};\\\", \\\"{x:677,y:714,t:1527635492376};\\\", \\\"{x:728,y:721,t:1527635492393};\\\", \\\"{x:808,y:736,t:1527635492410};\\\", \\\"{x:859,y:744,t:1527635492427};\\\", \\\"{x:889,y:748,t:1527635492443};\\\", \\\"{x:914,y:753,t:1527635492460};\\\", \\\"{x:937,y:755,t:1527635492477};\\\", \\\"{x:953,y:758,t:1527635492494};\\\", \\\"{x:965,y:758,t:1527635492511};\\\", \\\"{x:986,y:762,t:1527635492526};\\\", \\\"{x:1009,y:765,t:1527635492543};\\\", \\\"{x:1029,y:767,t:1527635492560};\\\", \\\"{x:1047,y:770,t:1527635492576};\\\", \\\"{x:1067,y:773,t:1527635492594};\\\", \\\"{x:1105,y:783,t:1527635492609};\\\", \\\"{x:1134,y:791,t:1527635492627};\\\", \\\"{x:1174,y:804,t:1527635492643};\\\", \\\"{x:1224,y:818,t:1527635492660};\\\", \\\"{x:1264,y:829,t:1527635492677};\\\", \\\"{x:1328,y:848,t:1527635492694};\\\", \\\"{x:1392,y:867,t:1527635492710};\\\", \\\"{x:1450,y:884,t:1527635492727};\\\", \\\"{x:1509,y:901,t:1527635492743};\\\", \\\"{x:1570,y:918,t:1527635492760};\\\", \\\"{x:1628,y:935,t:1527635492777};\\\", \\\"{x:1671,y:948,t:1527635492794};\\\", \\\"{x:1714,y:960,t:1527635492810};\\\", \\\"{x:1733,y:965,t:1527635492827};\\\", \\\"{x:1739,y:967,t:1527635492843};\\\", \\\"{x:1742,y:968,t:1527635492861};\\\", \\\"{x:1742,y:969,t:1527635492954};\\\", \\\"{x:1741,y:970,t:1527635492978};\\\", \\\"{x:1739,y:970,t:1527635492994};\\\", \\\"{x:1735,y:973,t:1527635493010};\\\", \\\"{x:1729,y:974,t:1527635493027};\\\", \\\"{x:1718,y:976,t:1527635493045};\\\", \\\"{x:1701,y:976,t:1527635493061};\\\", \\\"{x:1680,y:976,t:1527635493077};\\\", \\\"{x:1660,y:976,t:1527635493094};\\\", \\\"{x:1645,y:976,t:1527635493110};\\\", \\\"{x:1634,y:976,t:1527635493127};\\\", \\\"{x:1625,y:976,t:1527635493144};\\\", \\\"{x:1614,y:976,t:1527635493160};\\\", \\\"{x:1607,y:976,t:1527635493176};\\\", \\\"{x:1597,y:976,t:1527635493193};\\\", \\\"{x:1593,y:976,t:1527635493210};\\\", \\\"{x:1589,y:976,t:1527635493227};\\\", \\\"{x:1586,y:976,t:1527635493244};\\\", \\\"{x:1584,y:976,t:1527635493260};\\\", \\\"{x:1583,y:976,t:1527635493282};\\\", \\\"{x:1581,y:976,t:1527635493297};\\\", \\\"{x:1579,y:976,t:1527635493312};\\\", \\\"{x:1576,y:977,t:1527635493327};\\\", \\\"{x:1580,y:977,t:1527635493531};\\\", \\\"{x:1585,y:976,t:1527635493545};\\\", \\\"{x:1590,y:976,t:1527635493561};\\\", \\\"{x:1599,y:975,t:1527635493578};\\\", \\\"{x:1604,y:975,t:1527635493594};\\\", \\\"{x:1605,y:973,t:1527635493611};\\\", \\\"{x:1607,y:973,t:1527635493682};\\\", \\\"{x:1608,y:972,t:1527635494035};\\\", \\\"{x:1609,y:971,t:1527635494498};\\\", \\\"{x:1610,y:970,t:1527635494514};\\\", \\\"{x:1610,y:969,t:1527635494530};\\\", \\\"{x:1610,y:968,t:1527635494580};\\\", \\\"{x:1610,y:966,t:1527635494595};\\\", \\\"{x:1610,y:965,t:1527635494634};\\\", \\\"{x:1610,y:964,t:1527635494651};\\\", \\\"{x:1610,y:963,t:1527635494662};\\\", \\\"{x:1610,y:962,t:1527635494679};\\\", \\\"{x:1610,y:961,t:1527635494695};\\\", \\\"{x:1610,y:960,t:1527635494712};\\\", \\\"{x:1610,y:959,t:1527635494729};\\\", \\\"{x:1610,y:957,t:1527635494745};\\\", \\\"{x:1610,y:955,t:1527635494762};\\\", \\\"{x:1611,y:954,t:1527635494779};\\\", \\\"{x:1611,y:952,t:1527635494794};\\\", \\\"{x:1611,y:951,t:1527635494811};\\\", \\\"{x:1611,y:949,t:1527635494841};\\\", \\\"{x:1611,y:948,t:1527635494873};\\\", \\\"{x:1611,y:946,t:1527635494930};\\\", \\\"{x:1611,y:945,t:1527635494995};\\\", \\\"{x:1611,y:943,t:1527635496571};\\\", \\\"{x:1611,y:942,t:1527635496611};\\\", \\\"{x:1612,y:941,t:1527635496634};\\\", \\\"{x:1612,y:940,t:1527635496658};\\\", \\\"{x:1613,y:939,t:1527635496730};\\\", \\\"{x:1613,y:937,t:1527635496899};\\\", \\\"{x:1613,y:936,t:1527635497019};\\\", \\\"{x:1612,y:936,t:1527635497754};\\\", \\\"{x:1611,y:936,t:1527635497766};\\\", \\\"{x:1610,y:936,t:1527635497794};\\\", \\\"{x:1609,y:936,t:1527635497802};\\\", \\\"{x:1608,y:935,t:1527635497818};\\\", \\\"{x:1607,y:935,t:1527635497850};\\\", \\\"{x:1605,y:934,t:1527635497866};\\\", \\\"{x:1604,y:934,t:1527635497882};\\\", \\\"{x:1601,y:934,t:1527635497899};\\\", \\\"{x:1598,y:934,t:1527635497915};\\\", \\\"{x:1597,y:933,t:1527635497932};\\\", \\\"{x:1595,y:933,t:1527635497949};\\\", \\\"{x:1591,y:933,t:1527635497965};\\\", \\\"{x:1588,y:933,t:1527635497982};\\\", \\\"{x:1579,y:932,t:1527635497999};\\\", \\\"{x:1570,y:930,t:1527635498015};\\\", \\\"{x:1554,y:927,t:1527635498032};\\\", \\\"{x:1527,y:922,t:1527635498049};\\\", \\\"{x:1509,y:917,t:1527635498065};\\\", \\\"{x:1495,y:911,t:1527635498082};\\\", \\\"{x:1483,y:904,t:1527635498099};\\\", \\\"{x:1477,y:900,t:1527635498116};\\\", \\\"{x:1475,y:898,t:1527635498133};\\\", \\\"{x:1473,y:895,t:1527635498150};\\\", \\\"{x:1473,y:892,t:1527635498166};\\\", \\\"{x:1470,y:886,t:1527635498182};\\\", \\\"{x:1467,y:880,t:1527635498199};\\\", \\\"{x:1465,y:874,t:1527635498216};\\\", \\\"{x:1465,y:870,t:1527635498233};\\\", \\\"{x:1463,y:866,t:1527635498249};\\\", \\\"{x:1463,y:862,t:1527635498266};\\\", \\\"{x:1463,y:859,t:1527635498282};\\\", \\\"{x:1463,y:855,t:1527635498299};\\\", \\\"{x:1463,y:851,t:1527635498316};\\\", \\\"{x:1463,y:849,t:1527635498333};\\\", \\\"{x:1463,y:847,t:1527635498349};\\\", \\\"{x:1464,y:845,t:1527635498366};\\\", \\\"{x:1464,y:844,t:1527635498385};\\\", \\\"{x:1464,y:842,t:1527635498410};\\\", \\\"{x:1466,y:841,t:1527635498426};\\\", \\\"{x:1466,y:840,t:1527635498433};\\\", \\\"{x:1467,y:840,t:1527635498458};\\\", \\\"{x:1467,y:839,t:1527635498466};\\\", \\\"{x:1468,y:837,t:1527635498505};\\\", \\\"{x:1469,y:837,t:1527635498530};\\\", \\\"{x:1470,y:836,t:1527635498563};\\\", \\\"{x:1471,y:835,t:1527635498610};\\\", \\\"{x:1472,y:834,t:1527635498626};\\\", \\\"{x:1473,y:833,t:1527635499635};\\\", \\\"{x:1472,y:831,t:1527635499652};\\\", \\\"{x:1471,y:831,t:1527635499835};\\\", \\\"{x:1470,y:831,t:1527635499852};\\\", \\\"{x:1469,y:831,t:1527635499868};\\\", \\\"{x:1468,y:832,t:1527635499898};\\\", \\\"{x:1468,y:833,t:1527635501035};\\\", \\\"{x:1465,y:835,t:1527635501042};\\\", \\\"{x:1465,y:836,t:1527635501053};\\\", \\\"{x:1458,y:836,t:1527635501070};\\\", \\\"{x:1447,y:836,t:1527635501086};\\\", \\\"{x:1428,y:836,t:1527635501103};\\\", \\\"{x:1407,y:836,t:1527635501120};\\\", \\\"{x:1383,y:836,t:1527635501136};\\\", \\\"{x:1349,y:836,t:1527635501153};\\\", \\\"{x:1271,y:836,t:1527635501169};\\\", \\\"{x:1199,y:836,t:1527635501186};\\\", \\\"{x:1132,y:828,t:1527635501202};\\\", \\\"{x:1066,y:820,t:1527635501219};\\\", \\\"{x:994,y:800,t:1527635501237};\\\", \\\"{x:939,y:777,t:1527635501253};\\\", \\\"{x:882,y:748,t:1527635501269};\\\", \\\"{x:813,y:717,t:1527635501286};\\\", \\\"{x:738,y:679,t:1527635501302};\\\", \\\"{x:668,y:646,t:1527635501319};\\\", \\\"{x:617,y:618,t:1527635501336};\\\", \\\"{x:573,y:601,t:1527635501353};\\\", \\\"{x:553,y:592,t:1527635501366};\\\", \\\"{x:544,y:591,t:1527635501383};\\\", \\\"{x:537,y:588,t:1527635501399};\\\", \\\"{x:536,y:588,t:1527635501417};\\\", \\\"{x:534,y:589,t:1527635501497};\\\", \\\"{x:530,y:590,t:1527635501505};\\\", \\\"{x:528,y:590,t:1527635501516};\\\", \\\"{x:522,y:591,t:1527635501533};\\\", \\\"{x:512,y:592,t:1527635501550};\\\", \\\"{x:490,y:594,t:1527635501567};\\\", \\\"{x:464,y:594,t:1527635501583};\\\", \\\"{x:434,y:594,t:1527635501600};\\\", \\\"{x:398,y:594,t:1527635501617};\\\", \\\"{x:348,y:594,t:1527635501633};\\\", \\\"{x:325,y:594,t:1527635501650};\\\", \\\"{x:310,y:594,t:1527635501666};\\\", \\\"{x:295,y:594,t:1527635501684};\\\", \\\"{x:281,y:594,t:1527635501700};\\\", \\\"{x:270,y:594,t:1527635501717};\\\", \\\"{x:257,y:597,t:1527635501733};\\\", \\\"{x:250,y:597,t:1527635501750};\\\", \\\"{x:245,y:597,t:1527635501766};\\\", \\\"{x:241,y:597,t:1527635501783};\\\", \\\"{x:239,y:597,t:1527635501817};\\\", \\\"{x:239,y:599,t:1527635501857};\\\", \\\"{x:243,y:601,t:1527635501866};\\\", \\\"{x:254,y:603,t:1527635501883};\\\", \\\"{x:295,y:608,t:1527635501901};\\\", \\\"{x:358,y:614,t:1527635501917};\\\", \\\"{x:430,y:619,t:1527635501933};\\\", \\\"{x:495,y:631,t:1527635501950};\\\", \\\"{x:537,y:631,t:1527635501966};\\\", \\\"{x:562,y:633,t:1527635501983};\\\", \\\"{x:572,y:633,t:1527635502000};\\\", \\\"{x:577,y:633,t:1527635502016};\\\", \\\"{x:578,y:633,t:1527635502033};\\\", \\\"{x:579,y:633,t:1527635502050};\\\", \\\"{x:581,y:632,t:1527635502068};\\\", \\\"{x:583,y:632,t:1527635502083};\\\", \\\"{x:585,y:631,t:1527635502100};\\\", \\\"{x:587,y:629,t:1527635502117};\\\", \\\"{x:590,y:628,t:1527635502134};\\\", \\\"{x:594,y:626,t:1527635502150};\\\", \\\"{x:597,y:625,t:1527635502168};\\\", \\\"{x:599,y:624,t:1527635502183};\\\", \\\"{x:600,y:623,t:1527635502201};\\\", \\\"{x:600,y:622,t:1527635502218};\\\", \\\"{x:601,y:620,t:1527635502234};\\\", \\\"{x:601,y:619,t:1527635502251};\\\", \\\"{x:601,y:617,t:1527635502267};\\\", \\\"{x:601,y:616,t:1527635502283};\\\", \\\"{x:603,y:614,t:1527635502300};\\\", \\\"{x:604,y:612,t:1527635502318};\\\", \\\"{x:605,y:610,t:1527635502334};\\\", \\\"{x:605,y:606,t:1527635502351};\\\", \\\"{x:606,y:605,t:1527635502367};\\\", \\\"{x:606,y:603,t:1527635502383};\\\", \\\"{x:606,y:602,t:1527635502400};\\\", \\\"{x:606,y:601,t:1527635502417};\\\", \\\"{x:606,y:599,t:1527635502609};\\\", \\\"{x:603,y:599,t:1527635502624};\\\", \\\"{x:599,y:599,t:1527635502634};\\\", \\\"{x:586,y:602,t:1527635502651};\\\", \\\"{x:572,y:611,t:1527635502667};\\\", \\\"{x:559,y:621,t:1527635502685};\\\", \\\"{x:551,y:631,t:1527635502700};\\\", \\\"{x:545,y:640,t:1527635502717};\\\", \\\"{x:539,y:649,t:1527635502735};\\\", \\\"{x:529,y:663,t:1527635502752};\\\", \\\"{x:524,y:672,t:1527635502767};\\\", \\\"{x:520,y:678,t:1527635502784};\\\", \\\"{x:517,y:682,t:1527635502800};\\\", \\\"{x:514,y:687,t:1527635502817};\\\", \\\"{x:514,y:689,t:1527635502834};\\\", \\\"{x:513,y:690,t:1527635502851};\\\", \\\"{x:512,y:690,t:1527635502867};\\\", \\\"{x:511,y:691,t:1527635502884};\\\", \\\"{x:510,y:693,t:1527635502900};\\\", \\\"{x:509,y:694,t:1527635502917};\\\", \\\"{x:509,y:695,t:1527635502935};\\\", \\\"{x:508,y:696,t:1527635502951};\\\", \\\"{x:507,y:697,t:1527635502977};\\\", \\\"{x:507,y:698,t:1527635502993};\\\", \\\"{x:507,y:699,t:1527635503009};\\\", \\\"{x:507,y:701,t:1527635503025};\\\", \\\"{x:507,y:702,t:1527635503040};\\\", \\\"{x:507,y:704,t:1527635503051};\\\", \\\"{x:507,y:706,t:1527635503067};\\\", \\\"{x:508,y:708,t:1527635503084};\\\", \\\"{x:508,y:710,t:1527635503101};\\\", \\\"{x:510,y:712,t:1527635503117};\\\", \\\"{x:512,y:712,t:1527635503714};\\\", \\\"{x:513,y:712,t:1527635503730};\\\", \\\"{x:515,y:712,t:1527635503746};\\\", \\\"{x:515,y:711,t:1527635503753};\\\", \\\"{x:515,y:710,t:1527635503786};\\\", \\\"{x:515,y:709,t:1527635503922};\\\", \\\"{x:516,y:708,t:1527635504106};\\\", \\\"{x:517,y:708,t:1527635504118};\\\", \\\"{x:517,y:707,t:1527635504146};\\\", \\\"{x:518,y:707,t:1527635504161};\\\", \\\"{x:519,y:706,t:1527635504177};\\\", \\\"{x:519,y:705,t:1527635504193};\\\", \\\"{x:520,y:705,t:1527635504218};\\\", \\\"{x:521,y:705,t:1527635504225};\\\", \\\"{x:522,y:705,t:1527635504284};\\\", \\\"{x:522,y:704,t:1527635504301};\\\" ] }, { \\\"rt\\\": 35878, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 202199, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"DK1EM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -I -O -12 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:522,y:702,t:1527635504585};\\\", \\\"{x:521,y:700,t:1527635504602};\\\", \\\"{x:520,y:700,t:1527635504619};\\\", \\\"{x:519,y:698,t:1527635504635};\\\", \\\"{x:518,y:698,t:1527635504958};\\\", \\\"{x:518,y:697,t:1527635504968};\\\", \\\"{x:515,y:696,t:1527635504986};\\\", \\\"{x:514,y:696,t:1527635505002};\\\", \\\"{x:513,y:696,t:1527635505259};\\\", \\\"{x:512,y:696,t:1527635505270};\\\", \\\"{x:513,y:695,t:1527635505690};\\\", \\\"{x:514,y:695,t:1527635505713};\\\", \\\"{x:514,y:694,t:1527635505769};\\\", \\\"{x:515,y:694,t:1527635505786};\\\", \\\"{x:515,y:693,t:1527635505817};\\\", \\\"{x:516,y:692,t:1527635506106};\\\", \\\"{x:517,y:692,t:1527635506425};\\\", \\\"{x:517,y:691,t:1527635506449};\\\", \\\"{x:518,y:690,t:1527635506770};\\\", \\\"{x:518,y:689,t:1527635506788};\\\", \\\"{x:519,y:689,t:1527635506826};\\\", \\\"{x:519,y:688,t:1527635508585};\\\", \\\"{x:520,y:687,t:1527635509010};\\\", \\\"{x:521,y:686,t:1527635511626};\\\", \\\"{x:520,y:685,t:1527635511649};\\\", \\\"{x:518,y:684,t:1527635511658};\\\", \\\"{x:517,y:683,t:1527635511674};\\\", \\\"{x:517,y:682,t:1527635511794};\\\", \\\"{x:517,y:681,t:1527635511843};\\\", \\\"{x:520,y:681,t:1527635512314};\\\", \\\"{x:522,y:681,t:1527635512325};\\\", \\\"{x:529,y:681,t:1527635512341};\\\", \\\"{x:536,y:681,t:1527635512358};\\\", \\\"{x:541,y:681,t:1527635512375};\\\", \\\"{x:547,y:681,t:1527635512391};\\\", \\\"{x:551,y:681,t:1527635512408};\\\", \\\"{x:556,y:680,t:1527635512425};\\\", \\\"{x:563,y:680,t:1527635512441};\\\", \\\"{x:572,y:680,t:1527635512459};\\\", \\\"{x:581,y:680,t:1527635512474};\\\", \\\"{x:595,y:680,t:1527635512492};\\\", \\\"{x:609,y:680,t:1527635512508};\\\", \\\"{x:624,y:680,t:1527635512525};\\\", \\\"{x:643,y:680,t:1527635512542};\\\", \\\"{x:664,y:680,t:1527635512557};\\\", \\\"{x:691,y:680,t:1527635512575};\\\", \\\"{x:721,y:680,t:1527635512591};\\\", \\\"{x:756,y:680,t:1527635512607};\\\", \\\"{x:843,y:680,t:1527635512625};\\\", \\\"{x:908,y:682,t:1527635512641};\\\", \\\"{x:976,y:685,t:1527635512658};\\\", \\\"{x:1059,y:695,t:1527635512675};\\\", \\\"{x:1128,y:703,t:1527635512692};\\\", \\\"{x:1197,y:710,t:1527635512707};\\\", \\\"{x:1258,y:717,t:1527635512725};\\\", \\\"{x:1327,y:725,t:1527635512742};\\\", \\\"{x:1376,y:729,t:1527635512758};\\\", \\\"{x:1421,y:730,t:1527635512775};\\\", \\\"{x:1468,y:736,t:1527635512792};\\\", \\\"{x:1497,y:740,t:1527635512808};\\\", \\\"{x:1535,y:742,t:1527635512825};\\\", \\\"{x:1557,y:745,t:1527635512842};\\\", \\\"{x:1570,y:746,t:1527635512859};\\\", \\\"{x:1578,y:748,t:1527635512875};\\\", \\\"{x:1579,y:748,t:1527635512892};\\\", \\\"{x:1581,y:748,t:1527635512908};\\\", \\\"{x:1582,y:749,t:1527635512930};\\\", \\\"{x:1583,y:749,t:1527635512945};\\\", \\\"{x:1584,y:749,t:1527635512959};\\\", \\\"{x:1585,y:750,t:1527635512978};\\\", \\\"{x:1586,y:750,t:1527635513001};\\\", \\\"{x:1587,y:751,t:1527635513010};\\\", \\\"{x:1586,y:751,t:1527635513571};\\\", \\\"{x:1586,y:752,t:1527635513657};\\\", \\\"{x:1585,y:752,t:1527635513681};\\\", \\\"{x:1583,y:752,t:1527635513721};\\\", \\\"{x:1582,y:752,t:1527635513729};\\\", \\\"{x:1581,y:752,t:1527635513742};\\\", \\\"{x:1580,y:752,t:1527635513759};\\\", \\\"{x:1579,y:752,t:1527635513777};\\\", \\\"{x:1578,y:752,t:1527635513818};\\\", \\\"{x:1577,y:752,t:1527635513866};\\\", \\\"{x:1576,y:751,t:1527635513876};\\\", \\\"{x:1575,y:751,t:1527635513894};\\\", \\\"{x:1573,y:751,t:1527635513909};\\\", \\\"{x:1571,y:751,t:1527635513926};\\\", \\\"{x:1569,y:751,t:1527635513943};\\\", \\\"{x:1568,y:751,t:1527635513960};\\\", \\\"{x:1566,y:752,t:1527635513977};\\\", \\\"{x:1565,y:752,t:1527635514099};\\\", \\\"{x:1563,y:752,t:1527635514130};\\\", \\\"{x:1562,y:752,t:1527635514154};\\\", \\\"{x:1558,y:752,t:1527635514619};\\\", \\\"{x:1556,y:752,t:1527635514674};\\\", \\\"{x:1555,y:752,t:1527635514747};\\\", \\\"{x:1553,y:753,t:1527635514770};\\\", \\\"{x:1552,y:753,t:1527635514785};\\\", \\\"{x:1550,y:753,t:1527635514802};\\\", \\\"{x:1550,y:754,t:1527635514810};\\\", \\\"{x:1549,y:755,t:1527635514828};\\\", \\\"{x:1548,y:756,t:1527635514858};\\\", \\\"{x:1546,y:756,t:1527635514866};\\\", \\\"{x:1545,y:757,t:1527635514877};\\\", \\\"{x:1539,y:760,t:1527635514893};\\\", \\\"{x:1533,y:764,t:1527635514910};\\\", \\\"{x:1529,y:769,t:1527635514927};\\\", \\\"{x:1526,y:774,t:1527635514943};\\\", \\\"{x:1524,y:776,t:1527635514960};\\\", \\\"{x:1521,y:782,t:1527635514978};\\\", \\\"{x:1518,y:786,t:1527635514994};\\\", \\\"{x:1514,y:794,t:1527635515010};\\\", \\\"{x:1507,y:805,t:1527635515027};\\\", \\\"{x:1500,y:815,t:1527635515044};\\\", \\\"{x:1493,y:828,t:1527635515061};\\\", \\\"{x:1485,y:838,t:1527635515077};\\\", \\\"{x:1480,y:844,t:1527635515093};\\\", \\\"{x:1476,y:849,t:1527635515111};\\\", \\\"{x:1473,y:851,t:1527635515127};\\\", \\\"{x:1472,y:855,t:1527635515144};\\\", \\\"{x:1468,y:859,t:1527635515160};\\\", \\\"{x:1468,y:862,t:1527635515178};\\\", \\\"{x:1466,y:862,t:1527635515194};\\\", \\\"{x:1465,y:862,t:1527635515546};\\\", \\\"{x:1464,y:862,t:1527635515595};\\\", \\\"{x:1463,y:862,t:1527635515658};\\\", \\\"{x:1463,y:859,t:1527635515674};\\\", \\\"{x:1462,y:856,t:1527635515682};\\\", \\\"{x:1462,y:853,t:1527635515693};\\\", \\\"{x:1459,y:847,t:1527635515710};\\\", \\\"{x:1459,y:842,t:1527635515727};\\\", \\\"{x:1458,y:837,t:1527635515744};\\\", \\\"{x:1458,y:834,t:1527635515761};\\\", \\\"{x:1458,y:828,t:1527635515776};\\\", \\\"{x:1455,y:816,t:1527635515794};\\\", \\\"{x:1450,y:807,t:1527635515811};\\\", \\\"{x:1449,y:801,t:1527635515827};\\\", \\\"{x:1448,y:791,t:1527635515844};\\\", \\\"{x:1447,y:783,t:1527635515861};\\\", \\\"{x:1446,y:778,t:1527635515877};\\\", \\\"{x:1443,y:764,t:1527635515894};\\\", \\\"{x:1439,y:755,t:1527635515911};\\\", \\\"{x:1438,y:746,t:1527635515927};\\\", \\\"{x:1434,y:733,t:1527635515944};\\\", \\\"{x:1425,y:715,t:1527635515961};\\\", \\\"{x:1422,y:710,t:1527635515977};\\\", \\\"{x:1421,y:706,t:1527635515994};\\\", \\\"{x:1417,y:699,t:1527635516010};\\\", \\\"{x:1417,y:696,t:1527635516027};\\\", \\\"{x:1413,y:688,t:1527635516044};\\\", \\\"{x:1407,y:676,t:1527635516061};\\\", \\\"{x:1400,y:663,t:1527635516077};\\\", \\\"{x:1390,y:649,t:1527635516094};\\\", \\\"{x:1379,y:631,t:1527635516111};\\\", \\\"{x:1373,y:624,t:1527635516127};\\\", \\\"{x:1370,y:618,t:1527635516144};\\\", \\\"{x:1363,y:602,t:1527635516161};\\\", \\\"{x:1358,y:590,t:1527635516177};\\\", \\\"{x:1353,y:581,t:1527635516194};\\\", \\\"{x:1350,y:574,t:1527635516211};\\\", \\\"{x:1346,y:569,t:1527635516228};\\\", \\\"{x:1344,y:566,t:1527635516244};\\\", \\\"{x:1344,y:564,t:1527635516262};\\\", \\\"{x:1344,y:561,t:1527635516278};\\\", \\\"{x:1344,y:553,t:1527635516294};\\\", \\\"{x:1344,y:548,t:1527635516311};\\\", \\\"{x:1341,y:540,t:1527635516328};\\\", \\\"{x:1340,y:538,t:1527635516344};\\\", \\\"{x:1340,y:537,t:1527635517242};\\\", \\\"{x:1339,y:536,t:1527635517258};\\\", \\\"{x:1338,y:534,t:1527635517273};\\\", \\\"{x:1337,y:533,t:1527635517281};\\\", \\\"{x:1337,y:532,t:1527635517297};\\\", \\\"{x:1337,y:531,t:1527635517320};\\\", \\\"{x:1336,y:531,t:1527635517329};\\\", \\\"{x:1336,y:530,t:1527635517345};\\\", \\\"{x:1335,y:529,t:1527635517361};\\\", \\\"{x:1335,y:528,t:1527635517378};\\\", \\\"{x:1334,y:527,t:1527635517393};\\\", \\\"{x:1333,y:525,t:1527635517410};\\\", \\\"{x:1333,y:524,t:1527635517426};\\\", \\\"{x:1332,y:522,t:1527635517442};\\\", \\\"{x:1331,y:522,t:1527635517459};\\\", \\\"{x:1331,y:521,t:1527635517476};\\\", \\\"{x:1330,y:520,t:1527635517493};\\\", \\\"{x:1330,y:519,t:1527635517510};\\\", \\\"{x:1329,y:517,t:1527635517526};\\\", \\\"{x:1327,y:513,t:1527635517542};\\\", \\\"{x:1325,y:511,t:1527635517560};\\\", \\\"{x:1325,y:509,t:1527635517576};\\\", \\\"{x:1324,y:508,t:1527635517593};\\\", \\\"{x:1323,y:507,t:1527635517610};\\\", \\\"{x:1322,y:505,t:1527635517626};\\\", \\\"{x:1322,y:504,t:1527635517643};\\\", \\\"{x:1322,y:503,t:1527635517660};\\\", \\\"{x:1322,y:502,t:1527635517688};\\\", \\\"{x:1321,y:502,t:1527635517703};\\\", \\\"{x:1321,y:501,t:1527635517768};\\\", \\\"{x:1320,y:501,t:1527635517840};\\\", \\\"{x:1320,y:499,t:1527635519200};\\\", \\\"{x:1321,y:499,t:1527635519215};\\\", \\\"{x:1322,y:499,t:1527635519272};\\\", \\\"{x:1323,y:498,t:1527635519295};\\\", \\\"{x:1322,y:498,t:1527635520343};\\\", \\\"{x:1321,y:498,t:1527635520368};\\\", \\\"{x:1320,y:498,t:1527635520450};\\\", \\\"{x:1319,y:498,t:1527635520462};\\\", \\\"{x:1318,y:498,t:1527635521167};\\\", \\\"{x:1319,y:498,t:1527635521271};\\\", \\\"{x:1320,y:498,t:1527635521287};\\\", \\\"{x:1321,y:498,t:1527635521337};\\\", \\\"{x:1322,y:498,t:1527635521368};\\\", \\\"{x:1323,y:498,t:1527635521384};\\\", \\\"{x:1324,y:498,t:1527635521396};\\\", \\\"{x:1325,y:498,t:1527635521413};\\\", \\\"{x:1327,y:497,t:1527635521429};\\\", \\\"{x:1328,y:497,t:1527635521446};\\\", \\\"{x:1329,y:497,t:1527635521480};\\\", \\\"{x:1330,y:497,t:1527635521496};\\\", \\\"{x:1331,y:497,t:1527635521513};\\\", \\\"{x:1332,y:496,t:1527635521530};\\\", \\\"{x:1335,y:496,t:1527635521546};\\\", \\\"{x:1336,y:496,t:1527635521574};\\\", \\\"{x:1337,y:496,t:1527635521598};\\\", \\\"{x:1336,y:496,t:1527635522376};\\\", \\\"{x:1335,y:496,t:1527635522392};\\\", \\\"{x:1334,y:496,t:1527635522415};\\\", \\\"{x:1333,y:496,t:1527635522479};\\\", \\\"{x:1332,y:496,t:1527635522784};\\\", \\\"{x:1331,y:496,t:1527635522798};\\\", \\\"{x:1330,y:496,t:1527635522813};\\\", \\\"{x:1330,y:497,t:1527635522840};\\\", \\\"{x:1328,y:498,t:1527635522911};\\\", \\\"{x:1328,y:499,t:1527635522936};\\\", \\\"{x:1327,y:499,t:1527635523096};\\\", \\\"{x:1326,y:500,t:1527635523160};\\\", \\\"{x:1325,y:501,t:1527635523183};\\\", \\\"{x:1323,y:501,t:1527635523200};\\\", \\\"{x:1322,y:501,t:1527635523216};\\\", \\\"{x:1320,y:501,t:1527635523231};\\\", \\\"{x:1316,y:502,t:1527635523248};\\\", \\\"{x:1314,y:502,t:1527635523264};\\\", \\\"{x:1312,y:503,t:1527635523281};\\\", \\\"{x:1311,y:503,t:1527635523303};\\\", \\\"{x:1310,y:503,t:1527635523472};\\\", \\\"{x:1310,y:504,t:1527635523482};\\\", \\\"{x:1310,y:507,t:1527635523497};\\\", \\\"{x:1310,y:511,t:1527635523514};\\\", \\\"{x:1310,y:514,t:1527635523531};\\\", \\\"{x:1310,y:515,t:1527635523547};\\\", \\\"{x:1310,y:516,t:1527635523564};\\\", \\\"{x:1310,y:517,t:1527635523583};\\\", \\\"{x:1310,y:518,t:1527635523776};\\\", \\\"{x:1310,y:516,t:1527635523792};\\\", \\\"{x:1310,y:515,t:1527635523799};\\\", \\\"{x:1310,y:512,t:1527635523815};\\\", \\\"{x:1310,y:508,t:1527635523831};\\\", \\\"{x:1310,y:506,t:1527635523848};\\\", \\\"{x:1310,y:505,t:1527635523864};\\\", \\\"{x:1310,y:503,t:1527635523881};\\\", \\\"{x:1310,y:501,t:1527635523898};\\\", \\\"{x:1311,y:499,t:1527635523915};\\\", \\\"{x:1311,y:498,t:1527635523931};\\\", \\\"{x:1311,y:497,t:1527635523948};\\\", \\\"{x:1312,y:495,t:1527635523964};\\\", \\\"{x:1313,y:495,t:1527635523982};\\\", \\\"{x:1312,y:496,t:1527635524231};\\\", \\\"{x:1311,y:497,t:1527635524263};\\\", \\\"{x:1311,y:498,t:1527635524287};\\\", \\\"{x:1311,y:499,t:1527635524298};\\\", \\\"{x:1310,y:500,t:1527635524315};\\\", \\\"{x:1310,y:501,t:1527635524343};\\\", \\\"{x:1310,y:502,t:1527635524351};\\\", \\\"{x:1310,y:503,t:1527635524374};\\\", \\\"{x:1310,y:504,t:1527635524383};\\\", \\\"{x:1310,y:505,t:1527635524398};\\\", \\\"{x:1310,y:506,t:1527635524414};\\\", \\\"{x:1310,y:507,t:1527635524431};\\\", \\\"{x:1310,y:508,t:1527635524448};\\\", \\\"{x:1310,y:509,t:1527635524479};\\\", \\\"{x:1310,y:510,t:1527635524503};\\\", \\\"{x:1310,y:511,t:1527635524534};\\\", \\\"{x:1309,y:511,t:1527635524791};\\\", \\\"{x:1309,y:512,t:1527635525023};\\\", \\\"{x:1309,y:513,t:1527635525032};\\\", \\\"{x:1309,y:514,t:1527635525048};\\\", \\\"{x:1309,y:516,t:1527635525065};\\\", \\\"{x:1309,y:517,t:1527635525082};\\\", \\\"{x:1308,y:520,t:1527635525098};\\\", \\\"{x:1308,y:523,t:1527635525115};\\\", \\\"{x:1307,y:528,t:1527635525132};\\\", \\\"{x:1306,y:533,t:1527635525148};\\\", \\\"{x:1305,y:538,t:1527635525165};\\\", \\\"{x:1305,y:542,t:1527635525182};\\\", \\\"{x:1305,y:546,t:1527635525198};\\\", \\\"{x:1305,y:551,t:1527635525215};\\\", \\\"{x:1305,y:554,t:1527635525232};\\\", \\\"{x:1305,y:556,t:1527635525249};\\\", \\\"{x:1305,y:560,t:1527635525266};\\\", \\\"{x:1305,y:563,t:1527635525283};\\\", \\\"{x:1305,y:566,t:1527635525299};\\\", \\\"{x:1305,y:569,t:1527635525316};\\\", \\\"{x:1305,y:574,t:1527635525333};\\\", \\\"{x:1305,y:576,t:1527635525349};\\\", \\\"{x:1305,y:582,t:1527635525366};\\\", \\\"{x:1305,y:586,t:1527635525383};\\\", \\\"{x:1305,y:592,t:1527635525399};\\\", \\\"{x:1305,y:594,t:1527635525416};\\\", \\\"{x:1305,y:598,t:1527635525433};\\\", \\\"{x:1305,y:601,t:1527635525450};\\\", \\\"{x:1306,y:605,t:1527635525465};\\\", \\\"{x:1306,y:609,t:1527635525483};\\\", \\\"{x:1307,y:612,t:1527635525499};\\\", \\\"{x:1307,y:615,t:1527635525516};\\\", \\\"{x:1308,y:618,t:1527635525533};\\\", \\\"{x:1308,y:622,t:1527635525549};\\\", \\\"{x:1308,y:624,t:1527635525565};\\\", \\\"{x:1309,y:627,t:1527635525582};\\\", \\\"{x:1309,y:631,t:1527635525599};\\\", \\\"{x:1309,y:632,t:1527635525639};\\\", \\\"{x:1309,y:634,t:1527635525712};\\\", \\\"{x:1309,y:635,t:1527635525759};\\\", \\\"{x:1309,y:637,t:1527635525799};\\\", \\\"{x:1309,y:638,t:1527635525816};\\\", \\\"{x:1309,y:639,t:1527635525832};\\\", \\\"{x:1309,y:640,t:1527635525850};\\\", \\\"{x:1309,y:641,t:1527635525866};\\\", \\\"{x:1309,y:643,t:1527635525882};\\\", \\\"{x:1309,y:644,t:1527635525900};\\\", \\\"{x:1309,y:646,t:1527635525916};\\\", \\\"{x:1309,y:649,t:1527635525933};\\\", \\\"{x:1309,y:651,t:1527635525949};\\\", \\\"{x:1309,y:653,t:1527635525967};\\\", \\\"{x:1309,y:658,t:1527635525983};\\\", \\\"{x:1309,y:663,t:1527635525999};\\\", \\\"{x:1309,y:668,t:1527635526016};\\\", \\\"{x:1309,y:671,t:1527635526033};\\\", \\\"{x:1310,y:676,t:1527635526050};\\\", \\\"{x:1310,y:677,t:1527635526067};\\\", \\\"{x:1310,y:679,t:1527635526083};\\\", \\\"{x:1311,y:682,t:1527635526100};\\\", \\\"{x:1311,y:684,t:1527635526117};\\\", \\\"{x:1311,y:687,t:1527635526133};\\\", \\\"{x:1312,y:691,t:1527635526150};\\\", \\\"{x:1313,y:696,t:1527635526167};\\\", \\\"{x:1313,y:702,t:1527635526183};\\\", \\\"{x:1313,y:705,t:1527635526200};\\\", \\\"{x:1313,y:709,t:1527635526217};\\\", \\\"{x:1313,y:713,t:1527635526234};\\\", \\\"{x:1314,y:719,t:1527635526250};\\\", \\\"{x:1314,y:724,t:1527635526267};\\\", \\\"{x:1314,y:729,t:1527635526285};\\\", \\\"{x:1314,y:734,t:1527635526299};\\\", \\\"{x:1314,y:736,t:1527635526317};\\\", \\\"{x:1314,y:738,t:1527635526334};\\\", \\\"{x:1315,y:741,t:1527635526350};\\\", \\\"{x:1315,y:744,t:1527635526367};\\\", \\\"{x:1315,y:752,t:1527635526383};\\\", \\\"{x:1315,y:755,t:1527635526400};\\\", \\\"{x:1315,y:759,t:1527635526416};\\\", \\\"{x:1315,y:762,t:1527635526434};\\\", \\\"{x:1315,y:767,t:1527635526450};\\\", \\\"{x:1315,y:770,t:1527635526467};\\\", \\\"{x:1315,y:773,t:1527635526484};\\\", \\\"{x:1315,y:777,t:1527635526499};\\\", \\\"{x:1315,y:781,t:1527635526517};\\\", \\\"{x:1315,y:784,t:1527635526533};\\\", \\\"{x:1315,y:788,t:1527635526550};\\\", \\\"{x:1315,y:792,t:1527635526567};\\\", \\\"{x:1316,y:799,t:1527635526583};\\\", \\\"{x:1316,y:806,t:1527635526599};\\\", \\\"{x:1316,y:814,t:1527635526617};\\\", \\\"{x:1316,y:817,t:1527635526634};\\\", \\\"{x:1316,y:821,t:1527635526650};\\\", \\\"{x:1317,y:826,t:1527635526667};\\\", \\\"{x:1318,y:832,t:1527635526685};\\\", \\\"{x:1318,y:836,t:1527635526701};\\\", \\\"{x:1318,y:841,t:1527635526716};\\\", \\\"{x:1318,y:846,t:1527635526734};\\\", \\\"{x:1318,y:849,t:1527635526751};\\\", \\\"{x:1318,y:855,t:1527635526767};\\\", \\\"{x:1318,y:859,t:1527635526784};\\\", \\\"{x:1320,y:866,t:1527635526801};\\\", \\\"{x:1321,y:872,t:1527635526817};\\\", \\\"{x:1322,y:879,t:1527635526834};\\\", \\\"{x:1322,y:885,t:1527635526850};\\\", \\\"{x:1322,y:891,t:1527635526867};\\\", \\\"{x:1322,y:893,t:1527635526884};\\\", \\\"{x:1322,y:897,t:1527635526901};\\\", \\\"{x:1322,y:900,t:1527635526916};\\\", \\\"{x:1322,y:901,t:1527635526934};\\\", \\\"{x:1322,y:903,t:1527635526950};\\\", \\\"{x:1322,y:906,t:1527635526966};\\\", \\\"{x:1322,y:908,t:1527635526984};\\\", \\\"{x:1322,y:909,t:1527635527001};\\\", \\\"{x:1322,y:911,t:1527635527017};\\\", \\\"{x:1322,y:912,t:1527635527033};\\\", \\\"{x:1322,y:913,t:1527635527056};\\\", \\\"{x:1322,y:914,t:1527635527071};\\\", \\\"{x:1322,y:915,t:1527635527087};\\\", \\\"{x:1322,y:916,t:1527635527111};\\\", \\\"{x:1322,y:917,t:1527635527119};\\\", \\\"{x:1322,y:918,t:1527635527134};\\\", \\\"{x:1322,y:919,t:1527635527151};\\\", \\\"{x:1322,y:922,t:1527635527168};\\\", \\\"{x:1321,y:922,t:1527635527184};\\\", \\\"{x:1321,y:924,t:1527635527201};\\\", \\\"{x:1321,y:926,t:1527635527218};\\\", \\\"{x:1319,y:929,t:1527635527234};\\\", \\\"{x:1318,y:929,t:1527635527250};\\\", \\\"{x:1318,y:931,t:1527635527271};\\\", \\\"{x:1318,y:934,t:1527635527287};\\\", \\\"{x:1317,y:935,t:1527635527300};\\\", \\\"{x:1316,y:939,t:1527635527317};\\\", \\\"{x:1314,y:942,t:1527635527333};\\\", \\\"{x:1311,y:945,t:1527635527350};\\\", \\\"{x:1309,y:949,t:1527635527366};\\\", \\\"{x:1307,y:952,t:1527635527384};\\\", \\\"{x:1306,y:954,t:1527635527400};\\\", \\\"{x:1305,y:956,t:1527635527417};\\\", \\\"{x:1304,y:957,t:1527635527433};\\\", \\\"{x:1303,y:958,t:1527635527450};\\\", \\\"{x:1303,y:959,t:1527635527467};\\\", \\\"{x:1303,y:960,t:1527635527503};\\\", \\\"{x:1303,y:962,t:1527635527566};\\\", \\\"{x:1305,y:964,t:1527635527583};\\\", \\\"{x:1309,y:964,t:1527635527600};\\\", \\\"{x:1313,y:967,t:1527635527617};\\\", \\\"{x:1318,y:968,t:1527635527634};\\\", \\\"{x:1324,y:970,t:1527635527650};\\\", \\\"{x:1330,y:971,t:1527635527667};\\\", \\\"{x:1335,y:972,t:1527635527684};\\\", \\\"{x:1340,y:975,t:1527635527701};\\\", \\\"{x:1343,y:975,t:1527635527717};\\\", \\\"{x:1344,y:975,t:1527635527734};\\\", \\\"{x:1345,y:975,t:1527635527750};\\\", \\\"{x:1347,y:975,t:1527635527767};\\\", \\\"{x:1348,y:975,t:1527635527848};\\\", \\\"{x:1349,y:974,t:1527635527976};\\\", \\\"{x:1350,y:974,t:1527635528000};\\\", \\\"{x:1350,y:972,t:1527635528063};\\\", \\\"{x:1350,y:971,t:1527635528176};\\\", \\\"{x:1351,y:970,t:1527635528288};\\\", \\\"{x:1352,y:969,t:1527635528303};\\\", \\\"{x:1353,y:969,t:1527635528359};\\\", \\\"{x:1354,y:968,t:1527635528368};\\\", \\\"{x:1355,y:967,t:1527635528415};\\\", \\\"{x:1356,y:967,t:1527635528447};\\\", \\\"{x:1357,y:967,t:1527635528455};\\\", \\\"{x:1358,y:966,t:1527635528468};\\\", \\\"{x:1360,y:965,t:1527635528484};\\\", \\\"{x:1362,y:964,t:1527635528501};\\\", \\\"{x:1363,y:963,t:1527635528519};\\\", \\\"{x:1364,y:963,t:1527635528534};\\\", \\\"{x:1368,y:961,t:1527635528551};\\\", \\\"{x:1371,y:961,t:1527635528568};\\\", \\\"{x:1374,y:961,t:1527635528584};\\\", \\\"{x:1379,y:961,t:1527635528601};\\\", \\\"{x:1384,y:961,t:1527635528619};\\\", \\\"{x:1386,y:961,t:1527635528634};\\\", \\\"{x:1388,y:961,t:1527635528651};\\\", \\\"{x:1391,y:961,t:1527635528668};\\\", \\\"{x:1393,y:961,t:1527635528684};\\\", \\\"{x:1397,y:961,t:1527635528701};\\\", \\\"{x:1399,y:960,t:1527635528718};\\\", \\\"{x:1401,y:960,t:1527635528734};\\\", \\\"{x:1402,y:960,t:1527635528751};\\\", \\\"{x:1404,y:960,t:1527635528768};\\\", \\\"{x:1405,y:960,t:1527635528799};\\\", \\\"{x:1406,y:960,t:1527635528823};\\\", \\\"{x:1407,y:960,t:1527635528847};\\\", \\\"{x:1409,y:960,t:1527635528863};\\\", \\\"{x:1410,y:960,t:1527635528879};\\\", \\\"{x:1411,y:960,t:1527635529072};\\\", \\\"{x:1413,y:960,t:1527635529086};\\\", \\\"{x:1416,y:960,t:1527635529102};\\\", \\\"{x:1421,y:960,t:1527635529119};\\\", \\\"{x:1427,y:960,t:1527635529135};\\\", \\\"{x:1430,y:960,t:1527635529151};\\\", \\\"{x:1431,y:960,t:1527635529175};\\\", \\\"{x:1433,y:960,t:1527635529186};\\\", \\\"{x:1434,y:960,t:1527635529202};\\\", \\\"{x:1437,y:960,t:1527635529219};\\\", \\\"{x:1439,y:960,t:1527635529235};\\\", \\\"{x:1443,y:960,t:1527635529251};\\\", \\\"{x:1445,y:960,t:1527635529269};\\\", \\\"{x:1447,y:960,t:1527635529285};\\\", \\\"{x:1450,y:960,t:1527635529301};\\\", \\\"{x:1452,y:960,t:1527635529318};\\\", \\\"{x:1455,y:960,t:1527635529335};\\\", \\\"{x:1459,y:960,t:1527635529352};\\\", \\\"{x:1463,y:960,t:1527635529369};\\\", \\\"{x:1466,y:960,t:1527635529386};\\\", \\\"{x:1468,y:960,t:1527635529402};\\\", \\\"{x:1471,y:961,t:1527635529419};\\\", \\\"{x:1474,y:961,t:1527635529436};\\\", \\\"{x:1475,y:961,t:1527635529452};\\\", \\\"{x:1477,y:961,t:1527635529469};\\\", \\\"{x:1480,y:961,t:1527635529486};\\\", \\\"{x:1481,y:961,t:1527635529502};\\\", \\\"{x:1483,y:961,t:1527635529519};\\\", \\\"{x:1485,y:961,t:1527635529719};\\\", \\\"{x:1486,y:961,t:1527635529736};\\\", \\\"{x:1489,y:961,t:1527635529753};\\\", \\\"{x:1495,y:961,t:1527635529769};\\\", \\\"{x:1501,y:961,t:1527635529786};\\\", \\\"{x:1504,y:961,t:1527635529802};\\\", \\\"{x:1508,y:962,t:1527635529819};\\\", \\\"{x:1509,y:962,t:1527635529836};\\\", \\\"{x:1510,y:962,t:1527635529852};\\\", \\\"{x:1511,y:962,t:1527635529869};\\\", \\\"{x:1512,y:962,t:1527635529887};\\\", \\\"{x:1513,y:962,t:1527635529902};\\\", \\\"{x:1515,y:962,t:1527635529919};\\\", \\\"{x:1518,y:962,t:1527635529936};\\\", \\\"{x:1521,y:962,t:1527635529953};\\\", \\\"{x:1523,y:962,t:1527635529969};\\\", \\\"{x:1524,y:962,t:1527635529985};\\\", \\\"{x:1527,y:962,t:1527635530003};\\\", \\\"{x:1530,y:962,t:1527635530019};\\\", \\\"{x:1533,y:962,t:1527635530036};\\\", \\\"{x:1534,y:962,t:1527635530053};\\\", \\\"{x:1536,y:963,t:1527635530069};\\\", \\\"{x:1537,y:963,t:1527635530085};\\\", \\\"{x:1538,y:963,t:1527635530168};\\\", \\\"{x:1539,y:963,t:1527635530183};\\\", \\\"{x:1540,y:963,t:1527635530199};\\\", \\\"{x:1541,y:963,t:1527635530288};\\\", \\\"{x:1542,y:963,t:1527635530302};\\\", \\\"{x:1543,y:963,t:1527635530319};\\\", \\\"{x:1544,y:963,t:1527635530390};\\\", \\\"{x:1545,y:963,t:1527635530406};\\\", \\\"{x:1546,y:963,t:1527635530647};\\\", \\\"{x:1547,y:963,t:1527635530671};\\\", \\\"{x:1548,y:962,t:1527635530728};\\\", \\\"{x:1549,y:962,t:1527635532520};\\\", \\\"{x:1549,y:963,t:1527635532551};\\\", \\\"{x:1548,y:963,t:1527635532576};\\\", \\\"{x:1548,y:965,t:1527635532592};\\\", \\\"{x:1548,y:966,t:1527635532671};\\\", \\\"{x:1549,y:965,t:1527635533135};\\\", \\\"{x:1550,y:964,t:1527635533159};\\\", \\\"{x:1551,y:964,t:1527635533183};\\\", \\\"{x:1552,y:963,t:1527635533223};\\\", \\\"{x:1551,y:963,t:1527635533376};\\\", \\\"{x:1552,y:963,t:1527635533487};\\\", \\\"{x:1553,y:963,t:1527635534606};\\\", \\\"{x:1553,y:961,t:1527635534695};\\\", \\\"{x:1553,y:959,t:1527635534706};\\\", \\\"{x:1553,y:958,t:1527635534722};\\\", \\\"{x:1553,y:956,t:1527635534739};\\\", \\\"{x:1553,y:955,t:1527635534755};\\\", \\\"{x:1553,y:954,t:1527635534773};\\\", \\\"{x:1553,y:953,t:1527635534790};\\\", \\\"{x:1553,y:952,t:1527635534806};\\\", \\\"{x:1553,y:950,t:1527635534823};\\\", \\\"{x:1553,y:947,t:1527635534839};\\\", \\\"{x:1553,y:946,t:1527635534856};\\\", \\\"{x:1553,y:944,t:1527635534872};\\\", \\\"{x:1553,y:943,t:1527635534889};\\\", \\\"{x:1553,y:941,t:1527635534906};\\\", \\\"{x:1553,y:940,t:1527635534923};\\\", \\\"{x:1553,y:939,t:1527635534940};\\\", \\\"{x:1553,y:937,t:1527635534956};\\\", \\\"{x:1553,y:935,t:1527635534973};\\\", \\\"{x:1553,y:934,t:1527635535007};\\\", \\\"{x:1553,y:932,t:1527635535031};\\\", \\\"{x:1553,y:931,t:1527635535063};\\\", \\\"{x:1553,y:930,t:1527635535104};\\\", \\\"{x:1553,y:929,t:1527635535111};\\\", \\\"{x:1553,y:928,t:1527635535144};\\\", \\\"{x:1553,y:926,t:1527635535175};\\\", \\\"{x:1553,y:925,t:1527635535223};\\\", \\\"{x:1553,y:924,t:1527635535255};\\\", \\\"{x:1553,y:923,t:1527635535263};\\\", \\\"{x:1553,y:922,t:1527635535279};\\\", \\\"{x:1553,y:921,t:1527635535318};\\\", \\\"{x:1553,y:920,t:1527635535343};\\\", \\\"{x:1553,y:919,t:1527635535358};\\\", \\\"{x:1553,y:918,t:1527635535382};\\\", \\\"{x:1553,y:917,t:1527635535399};\\\", \\\"{x:1553,y:916,t:1527635535431};\\\", \\\"{x:1553,y:915,t:1527635535487};\\\", \\\"{x:1553,y:914,t:1527635535520};\\\", \\\"{x:1553,y:913,t:1527635535527};\\\", \\\"{x:1553,y:912,t:1527635535712};\\\", \\\"{x:1553,y:911,t:1527635535723};\\\", \\\"{x:1553,y:910,t:1527635535740};\\\", \\\"{x:1553,y:909,t:1527635535758};\\\", \\\"{x:1553,y:908,t:1527635535783};\\\", \\\"{x:1553,y:907,t:1527635535790};\\\", \\\"{x:1553,y:904,t:1527635535806};\\\", \\\"{x:1553,y:902,t:1527635535823};\\\", \\\"{x:1553,y:900,t:1527635535839};\\\", \\\"{x:1553,y:899,t:1527635535857};\\\", \\\"{x:1553,y:895,t:1527635535874};\\\", \\\"{x:1553,y:891,t:1527635535890};\\\", \\\"{x:1553,y:882,t:1527635535907};\\\", \\\"{x:1553,y:878,t:1527635535923};\\\", \\\"{x:1551,y:872,t:1527635535939};\\\", \\\"{x:1550,y:866,t:1527635535957};\\\", \\\"{x:1550,y:862,t:1527635535974};\\\", \\\"{x:1550,y:857,t:1527635535990};\\\", \\\"{x:1550,y:850,t:1527635536007};\\\", \\\"{x:1549,y:846,t:1527635536023};\\\", \\\"{x:1549,y:845,t:1527635536040};\\\", \\\"{x:1548,y:841,t:1527635536057};\\\", \\\"{x:1547,y:838,t:1527635536074};\\\", \\\"{x:1547,y:835,t:1527635536089};\\\", \\\"{x:1547,y:834,t:1527635536106};\\\", \\\"{x:1547,y:833,t:1527635536123};\\\", \\\"{x:1547,y:832,t:1527635536143};\\\", \\\"{x:1547,y:831,t:1527635538327};\\\", \\\"{x:1544,y:831,t:1527635538575};\\\", \\\"{x:1531,y:827,t:1527635538592};\\\", \\\"{x:1506,y:822,t:1527635538609};\\\", \\\"{x:1465,y:812,t:1527635538626};\\\", \\\"{x:1414,y:796,t:1527635538642};\\\", \\\"{x:1361,y:780,t:1527635538659};\\\", \\\"{x:1298,y:756,t:1527635538676};\\\", \\\"{x:1228,y:721,t:1527635538692};\\\", \\\"{x:1140,y:684,t:1527635538708};\\\", \\\"{x:1066,y:642,t:1527635538726};\\\", \\\"{x:999,y:612,t:1527635538741};\\\", \\\"{x:940,y:585,t:1527635538758};\\\", \\\"{x:919,y:578,t:1527635538776};\\\", \\\"{x:909,y:574,t:1527635538792};\\\", \\\"{x:902,y:571,t:1527635538809};\\\", \\\"{x:897,y:570,t:1527635538826};\\\", \\\"{x:891,y:568,t:1527635538843};\\\", \\\"{x:885,y:568,t:1527635538860};\\\", \\\"{x:881,y:568,t:1527635538876};\\\", \\\"{x:877,y:568,t:1527635538894};\\\", \\\"{x:870,y:568,t:1527635538910};\\\", \\\"{x:850,y:574,t:1527635538926};\\\", \\\"{x:825,y:581,t:1527635538944};\\\", \\\"{x:800,y:585,t:1527635538960};\\\", \\\"{x:777,y:590,t:1527635538978};\\\", \\\"{x:740,y:591,t:1527635538994};\\\", \\\"{x:710,y:591,t:1527635539011};\\\", \\\"{x:683,y:591,t:1527635539028};\\\", \\\"{x:654,y:591,t:1527635539045};\\\", \\\"{x:633,y:591,t:1527635539062};\\\", \\\"{x:615,y:591,t:1527635539078};\\\", \\\"{x:599,y:591,t:1527635539093};\\\", \\\"{x:598,y:591,t:1527635539111};\\\", \\\"{x:598,y:592,t:1527635539278};\\\", \\\"{x:598,y:596,t:1527635539295};\\\", \\\"{x:599,y:601,t:1527635539311};\\\", \\\"{x:601,y:605,t:1527635539328};\\\", \\\"{x:602,y:605,t:1527635539345};\\\", \\\"{x:602,y:606,t:1527635539361};\\\", \\\"{x:602,y:608,t:1527635539630};\\\", \\\"{x:602,y:611,t:1527635539644};\\\", \\\"{x:597,y:617,t:1527635539662};\\\", \\\"{x:588,y:631,t:1527635539679};\\\", \\\"{x:576,y:653,t:1527635539695};\\\", \\\"{x:568,y:670,t:1527635539712};\\\", \\\"{x:561,y:682,t:1527635539728};\\\", \\\"{x:555,y:692,t:1527635539745};\\\", \\\"{x:553,y:697,t:1527635539761};\\\", \\\"{x:550,y:701,t:1527635539779};\\\", \\\"{x:550,y:704,t:1527635539794};\\\", \\\"{x:548,y:706,t:1527635539812};\\\", \\\"{x:548,y:707,t:1527635539828};\\\", \\\"{x:546,y:709,t:1527635539845};\\\", \\\"{x:544,y:711,t:1527635539862};\\\", \\\"{x:542,y:714,t:1527635539878};\\\", \\\"{x:541,y:714,t:1527635539999};\\\", \\\"{x:541,y:716,t:1527635540135};\\\", \\\"{x:540,y:717,t:1527635540146};\\\", \\\"{x:539,y:719,t:1527635540162};\\\", \\\"{x:539,y:720,t:1527635540179};\\\", \\\"{x:539,y:721,t:1527635540196};\\\", \\\"{x:539,y:722,t:1527635540212};\\\", \\\"{x:542,y:722,t:1527635540639};\\\", \\\"{x:550,y:722,t:1527635540647};\\\", \\\"{x:566,y:722,t:1527635540663};\\\", \\\"{x:583,y:722,t:1527635540679};\\\", \\\"{x:597,y:722,t:1527635540696};\\\", \\\"{x:607,y:718,t:1527635540713};\\\", \\\"{x:615,y:715,t:1527635540729};\\\", \\\"{x:620,y:713,t:1527635540745};\\\", \\\"{x:626,y:709,t:1527635540763};\\\", \\\"{x:633,y:708,t:1527635540779};\\\", \\\"{x:637,y:706,t:1527635540795};\\\", \\\"{x:639,y:705,t:1527635540813};\\\", \\\"{x:640,y:705,t:1527635540847};\\\", \\\"{x:641,y:704,t:1527635540863};\\\", \\\"{x:643,y:704,t:1527635540880};\\\", \\\"{x:643,y:703,t:1527635540959};\\\", \\\"{x:643,y:702,t:1527635541055};\\\", \\\"{x:644,y:701,t:1527635541062};\\\", \\\"{x:645,y:701,t:1527635541144};\\\" ] }, { \\\"rt\\\": 13297, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 216715, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"DK1EM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:646,y:701,t:1527635541559};\\\", \\\"{x:648,y:700,t:1527635541596};\\\", \\\"{x:649,y:699,t:1527635544839};\\\", \\\"{x:651,y:697,t:1527635544958};\\\", \\\"{x:652,y:696,t:1527635544966};\\\", \\\"{x:657,y:695,t:1527635544982};\\\", \\\"{x:668,y:690,t:1527635544999};\\\", \\\"{x:677,y:687,t:1527635545016};\\\", \\\"{x:687,y:683,t:1527635545032};\\\", \\\"{x:702,y:681,t:1527635545049};\\\", \\\"{x:724,y:678,t:1527635545066};\\\", \\\"{x:749,y:676,t:1527635545081};\\\", \\\"{x:776,y:671,t:1527635545098};\\\", \\\"{x:809,y:666,t:1527635545116};\\\", \\\"{x:849,y:666,t:1527635545132};\\\", \\\"{x:881,y:665,t:1527635545149};\\\", \\\"{x:914,y:665,t:1527635545165};\\\", \\\"{x:959,y:665,t:1527635545182};\\\", \\\"{x:986,y:665,t:1527635545199};\\\", \\\"{x:1012,y:665,t:1527635545216};\\\", \\\"{x:1037,y:665,t:1527635545233};\\\", \\\"{x:1067,y:665,t:1527635545249};\\\", \\\"{x:1092,y:665,t:1527635545266};\\\", \\\"{x:1112,y:665,t:1527635545283};\\\", \\\"{x:1124,y:664,t:1527635545299};\\\", \\\"{x:1133,y:664,t:1527635545316};\\\", \\\"{x:1134,y:663,t:1527635545333};\\\", \\\"{x:1136,y:663,t:1527635545350};\\\", \\\"{x:1137,y:663,t:1527635545376};\\\", \\\"{x:1137,y:662,t:1527635545398};\\\", \\\"{x:1139,y:662,t:1527635545430};\\\", \\\"{x:1139,y:661,t:1527635545647};\\\", \\\"{x:1139,y:659,t:1527635545663};\\\", \\\"{x:1144,y:657,t:1527635545935};\\\", \\\"{x:1148,y:656,t:1527635545950};\\\", \\\"{x:1160,y:653,t:1527635545966};\\\", \\\"{x:1191,y:652,t:1527635545983};\\\", \\\"{x:1213,y:652,t:1527635546001};\\\", \\\"{x:1234,y:652,t:1527635546017};\\\", \\\"{x:1247,y:651,t:1527635546033};\\\", \\\"{x:1258,y:649,t:1527635546050};\\\", \\\"{x:1268,y:648,t:1527635546066};\\\", \\\"{x:1283,y:647,t:1527635546083};\\\", \\\"{x:1297,y:643,t:1527635546100};\\\", \\\"{x:1309,y:643,t:1527635546116};\\\", \\\"{x:1316,y:642,t:1527635546134};\\\", \\\"{x:1321,y:640,t:1527635546150};\\\", \\\"{x:1322,y:639,t:1527635546198};\\\", \\\"{x:1323,y:639,t:1527635546214};\\\", \\\"{x:1324,y:639,t:1527635546222};\\\", \\\"{x:1325,y:639,t:1527635546232};\\\", \\\"{x:1326,y:638,t:1527635546249};\\\", \\\"{x:1328,y:637,t:1527635546267};\\\", \\\"{x:1329,y:637,t:1527635546286};\\\", \\\"{x:1330,y:636,t:1527635546310};\\\", \\\"{x:1332,y:635,t:1527635546335};\\\", \\\"{x:1333,y:635,t:1527635546351};\\\", \\\"{x:1335,y:634,t:1527635546375};\\\", \\\"{x:1335,y:633,t:1527635546456};\\\", \\\"{x:1336,y:632,t:1527635546503};\\\", \\\"{x:1336,y:631,t:1527635546519};\\\", \\\"{x:1336,y:630,t:1527635546535};\\\", \\\"{x:1336,y:629,t:1527635546551};\\\", \\\"{x:1333,y:624,t:1527635546567};\\\", \\\"{x:1331,y:622,t:1527635546584};\\\", \\\"{x:1328,y:618,t:1527635546600};\\\", \\\"{x:1324,y:615,t:1527635546616};\\\", \\\"{x:1320,y:613,t:1527635546634};\\\", \\\"{x:1315,y:609,t:1527635546649};\\\", \\\"{x:1309,y:606,t:1527635546667};\\\", \\\"{x:1301,y:600,t:1527635546683};\\\", \\\"{x:1296,y:599,t:1527635546700};\\\", \\\"{x:1286,y:594,t:1527635546717};\\\", \\\"{x:1270,y:586,t:1527635546735};\\\", \\\"{x:1263,y:584,t:1527635546750};\\\", \\\"{x:1259,y:582,t:1527635546767};\\\", \\\"{x:1257,y:581,t:1527635546784};\\\", \\\"{x:1256,y:580,t:1527635546800};\\\", \\\"{x:1255,y:579,t:1527635546817};\\\", \\\"{x:1254,y:579,t:1527635546847};\\\", \\\"{x:1252,y:579,t:1527635546952};\\\", \\\"{x:1251,y:579,t:1527635546983};\\\", \\\"{x:1250,y:579,t:1527635546991};\\\", \\\"{x:1248,y:579,t:1527635547000};\\\", \\\"{x:1245,y:579,t:1527635547017};\\\", \\\"{x:1239,y:579,t:1527635547033};\\\", \\\"{x:1225,y:579,t:1527635547050};\\\", \\\"{x:1209,y:579,t:1527635547067};\\\", \\\"{x:1184,y:579,t:1527635547084};\\\", \\\"{x:1154,y:579,t:1527635547101};\\\", \\\"{x:1112,y:579,t:1527635547117};\\\", \\\"{x:1059,y:579,t:1527635547134};\\\", \\\"{x:970,y:579,t:1527635547150};\\\", \\\"{x:906,y:579,t:1527635547168};\\\", \\\"{x:842,y:579,t:1527635547184};\\\", \\\"{x:788,y:578,t:1527635547201};\\\", \\\"{x:742,y:575,t:1527635547218};\\\", \\\"{x:709,y:569,t:1527635547234};\\\", \\\"{x:702,y:568,t:1527635547251};\\\", \\\"{x:704,y:568,t:1527635548487};\\\", \\\"{x:708,y:568,t:1527635548502};\\\", \\\"{x:716,y:568,t:1527635548518};\\\", \\\"{x:725,y:568,t:1527635548536};\\\", \\\"{x:738,y:568,t:1527635548552};\\\", \\\"{x:750,y:568,t:1527635548569};\\\", \\\"{x:765,y:568,t:1527635548585};\\\", \\\"{x:783,y:568,t:1527635548602};\\\", \\\"{x:794,y:568,t:1527635548619};\\\", \\\"{x:802,y:568,t:1527635548636};\\\", \\\"{x:806,y:568,t:1527635548652};\\\", \\\"{x:807,y:568,t:1527635548670};\\\", \\\"{x:809,y:566,t:1527635548686};\\\", \\\"{x:810,y:566,t:1527635549047};\\\", \\\"{x:811,y:566,t:1527635549071};\\\", \\\"{x:813,y:566,t:1527635549087};\\\", \\\"{x:816,y:566,t:1527635549103};\\\", \\\"{x:823,y:566,t:1527635549119};\\\", \\\"{x:830,y:567,t:1527635549138};\\\", \\\"{x:845,y:569,t:1527635549153};\\\", \\\"{x:865,y:572,t:1527635549169};\\\", \\\"{x:884,y:574,t:1527635549186};\\\", \\\"{x:909,y:574,t:1527635549203};\\\", \\\"{x:930,y:574,t:1527635549218};\\\", \\\"{x:956,y:574,t:1527635549236};\\\", \\\"{x:983,y:574,t:1527635549253};\\\", \\\"{x:1009,y:574,t:1527635549269};\\\", \\\"{x:1062,y:574,t:1527635549285};\\\", \\\"{x:1096,y:574,t:1527635549302};\\\", \\\"{x:1129,y:578,t:1527635549319};\\\", \\\"{x:1163,y:583,t:1527635549336};\\\", \\\"{x:1190,y:586,t:1527635549353};\\\", \\\"{x:1208,y:590,t:1527635549369};\\\", \\\"{x:1223,y:591,t:1527635549386};\\\", \\\"{x:1232,y:593,t:1527635549403};\\\", \\\"{x:1239,y:593,t:1527635549419};\\\", \\\"{x:1247,y:594,t:1527635549436};\\\", \\\"{x:1255,y:594,t:1527635549453};\\\", \\\"{x:1261,y:594,t:1527635549469};\\\", \\\"{x:1271,y:596,t:1527635549487};\\\", \\\"{x:1278,y:596,t:1527635549503};\\\", \\\"{x:1284,y:596,t:1527635549519};\\\", \\\"{x:1296,y:598,t:1527635549536};\\\", \\\"{x:1306,y:598,t:1527635549553};\\\", \\\"{x:1310,y:598,t:1527635549570};\\\", \\\"{x:1313,y:598,t:1527635549586};\\\", \\\"{x:1314,y:598,t:1527635549615};\\\", \\\"{x:1315,y:598,t:1527635550447};\\\", \\\"{x:1316,y:598,t:1527635550463};\\\", \\\"{x:1317,y:598,t:1527635550495};\\\", \\\"{x:1316,y:598,t:1527635551288};\\\", \\\"{x:1300,y:598,t:1527635551305};\\\", \\\"{x:1275,y:598,t:1527635551322};\\\", \\\"{x:1245,y:598,t:1527635551337};\\\", \\\"{x:1202,y:598,t:1527635551355};\\\", \\\"{x:1150,y:592,t:1527635551372};\\\", \\\"{x:1073,y:587,t:1527635551388};\\\", \\\"{x:1008,y:582,t:1527635551404};\\\", \\\"{x:935,y:571,t:1527635551422};\\\", \\\"{x:864,y:563,t:1527635551438};\\\", \\\"{x:837,y:558,t:1527635551454};\\\", \\\"{x:812,y:555,t:1527635551471};\\\", \\\"{x:791,y:555,t:1527635551488};\\\", \\\"{x:777,y:554,t:1527635551504};\\\", \\\"{x:755,y:554,t:1527635551521};\\\", \\\"{x:734,y:554,t:1527635551538};\\\", \\\"{x:714,y:552,t:1527635551555};\\\", \\\"{x:693,y:552,t:1527635551571};\\\", \\\"{x:673,y:552,t:1527635551588};\\\", \\\"{x:655,y:552,t:1527635551603};\\\", \\\"{x:637,y:549,t:1527635551621};\\\", \\\"{x:614,y:549,t:1527635551638};\\\", \\\"{x:597,y:549,t:1527635551654};\\\", \\\"{x:582,y:549,t:1527635551671};\\\", \\\"{x:569,y:549,t:1527635551688};\\\", \\\"{x:552,y:549,t:1527635551704};\\\", \\\"{x:542,y:550,t:1527635551721};\\\", \\\"{x:532,y:553,t:1527635551738};\\\", \\\"{x:520,y:554,t:1527635551754};\\\", \\\"{x:510,y:556,t:1527635551772};\\\", \\\"{x:501,y:558,t:1527635551788};\\\", \\\"{x:493,y:560,t:1527635551805};\\\", \\\"{x:487,y:564,t:1527635551821};\\\", \\\"{x:482,y:567,t:1527635551838};\\\", \\\"{x:481,y:567,t:1527635551855};\\\", \\\"{x:480,y:568,t:1527635551902};\\\", \\\"{x:481,y:570,t:1527635552007};\\\", \\\"{x:482,y:571,t:1527635552021};\\\", \\\"{x:494,y:579,t:1527635552039};\\\", \\\"{x:496,y:581,t:1527635552054};\\\", \\\"{x:499,y:583,t:1527635552073};\\\", \\\"{x:501,y:583,t:1527635552088};\\\", \\\"{x:501,y:584,t:1527635552104};\\\", \\\"{x:500,y:585,t:1527635552175};\\\", \\\"{x:496,y:585,t:1527635552189};\\\", \\\"{x:485,y:585,t:1527635552206};\\\", \\\"{x:471,y:585,t:1527635552222};\\\", \\\"{x:464,y:585,t:1527635552238};\\\", \\\"{x:462,y:584,t:1527635552255};\\\", \\\"{x:461,y:583,t:1527635552272};\\\", \\\"{x:461,y:581,t:1527635552288};\\\", \\\"{x:463,y:579,t:1527635552305};\\\", \\\"{x:472,y:574,t:1527635552322};\\\", \\\"{x:487,y:568,t:1527635552338};\\\", \\\"{x:509,y:562,t:1527635552356};\\\", \\\"{x:534,y:556,t:1527635552372};\\\", \\\"{x:570,y:547,t:1527635552388};\\\", \\\"{x:602,y:541,t:1527635552406};\\\", \\\"{x:631,y:533,t:1527635552422};\\\", \\\"{x:641,y:531,t:1527635552438};\\\", \\\"{x:646,y:530,t:1527635552455};\\\", \\\"{x:646,y:529,t:1527635552592};\\\", \\\"{x:646,y:528,t:1527635552615};\\\", \\\"{x:645,y:528,t:1527635552623};\\\", \\\"{x:642,y:526,t:1527635552639};\\\", \\\"{x:642,y:525,t:1527635552703};\\\", \\\"{x:641,y:523,t:1527635552848};\\\", \\\"{x:640,y:521,t:1527635552855};\\\", \\\"{x:636,y:520,t:1527635552872};\\\", \\\"{x:630,y:515,t:1527635552889};\\\", \\\"{x:627,y:512,t:1527635552906};\\\", \\\"{x:623,y:509,t:1527635552923};\\\", \\\"{x:619,y:507,t:1527635552939};\\\", \\\"{x:617,y:505,t:1527635552955};\\\", \\\"{x:616,y:503,t:1527635552972};\\\", \\\"{x:615,y:502,t:1527635552989};\\\", \\\"{x:615,y:501,t:1527635553006};\\\", \\\"{x:615,y:500,t:1527635553022};\\\", \\\"{x:614,y:499,t:1527635553039};\\\", \\\"{x:614,y:498,t:1527635553079};\\\", \\\"{x:614,y:497,t:1527635553422};\\\", \\\"{x:613,y:496,t:1527635553439};\\\", \\\"{x:612,y:496,t:1527635553456};\\\", \\\"{x:610,y:495,t:1527635553473};\\\", \\\"{x:609,y:496,t:1527635553494};\\\", \\\"{x:609,y:499,t:1527635553506};\\\", \\\"{x:613,y:507,t:1527635553523};\\\", \\\"{x:627,y:516,t:1527635553540};\\\", \\\"{x:644,y:529,t:1527635553557};\\\", \\\"{x:674,y:541,t:1527635553572};\\\", \\\"{x:705,y:549,t:1527635553589};\\\", \\\"{x:739,y:555,t:1527635553607};\\\", \\\"{x:757,y:557,t:1527635553623};\\\", \\\"{x:767,y:558,t:1527635553639};\\\", \\\"{x:773,y:559,t:1527635553656};\\\", \\\"{x:779,y:559,t:1527635553674};\\\", \\\"{x:786,y:559,t:1527635553690};\\\", \\\"{x:797,y:559,t:1527635553707};\\\", \\\"{x:806,y:559,t:1527635553723};\\\", \\\"{x:813,y:558,t:1527635553740};\\\", \\\"{x:817,y:558,t:1527635553757};\\\", \\\"{x:818,y:558,t:1527635553806};\\\", \\\"{x:818,y:557,t:1527635553824};\\\", \\\"{x:820,y:554,t:1527635553841};\\\", \\\"{x:822,y:552,t:1527635553857};\\\", \\\"{x:824,y:550,t:1527635553874};\\\", \\\"{x:827,y:548,t:1527635553891};\\\", \\\"{x:830,y:546,t:1527635553906};\\\", \\\"{x:833,y:544,t:1527635553923};\\\", \\\"{x:837,y:543,t:1527635553940};\\\", \\\"{x:841,y:541,t:1527635553956};\\\", \\\"{x:842,y:541,t:1527635553973};\\\", \\\"{x:842,y:540,t:1527635553990};\\\", \\\"{x:840,y:541,t:1527635554254};\\\", \\\"{x:832,y:544,t:1527635554262};\\\", \\\"{x:824,y:548,t:1527635554274};\\\", \\\"{x:800,y:559,t:1527635554291};\\\", \\\"{x:763,y:578,t:1527635554306};\\\", \\\"{x:716,y:605,t:1527635554324};\\\", \\\"{x:676,y:627,t:1527635554340};\\\", \\\"{x:642,y:645,t:1527635554357};\\\", \\\"{x:611,y:658,t:1527635554373};\\\", \\\"{x:574,y:682,t:1527635554390};\\\", \\\"{x:557,y:690,t:1527635554407};\\\", \\\"{x:538,y:696,t:1527635554423};\\\", \\\"{x:523,y:700,t:1527635554440};\\\", \\\"{x:509,y:704,t:1527635554457};\\\", \\\"{x:501,y:706,t:1527635554473};\\\", \\\"{x:492,y:709,t:1527635554491};\\\", \\\"{x:485,y:710,t:1527635554507};\\\", \\\"{x:481,y:712,t:1527635554523};\\\", \\\"{x:480,y:713,t:1527635554541};\\\", \\\"{x:480,y:715,t:1527635554590};\\\", \\\"{x:480,y:719,t:1527635554608};\\\", \\\"{x:480,y:721,t:1527635554625};\\\", \\\"{x:482,y:722,t:1527635554640};\\\", \\\"{x:483,y:724,t:1527635554657};\\\", \\\"{x:485,y:725,t:1527635554674};\\\", \\\"{x:486,y:726,t:1527635554695};\\\", \\\"{x:487,y:727,t:1527635554711};\\\", \\\"{x:488,y:727,t:1527635555583};\\\", \\\"{x:489,y:727,t:1527635555591};\\\", \\\"{x:491,y:727,t:1527635555607};\\\", \\\"{x:494,y:727,t:1527635555624};\\\", \\\"{x:497,y:727,t:1527635555642};\\\", \\\"{x:499,y:726,t:1527635555658};\\\", \\\"{x:501,y:725,t:1527635555674};\\\", \\\"{x:503,y:724,t:1527635555691};\\\", \\\"{x:506,y:722,t:1527635555707};\\\", \\\"{x:508,y:722,t:1527635555724};\\\", \\\"{x:509,y:722,t:1527635555741};\\\", \\\"{x:511,y:721,t:1527635555758};\\\", \\\"{x:513,y:720,t:1527635555774};\\\", \\\"{x:514,y:720,t:1527635555792};\\\", \\\"{x:514,y:719,t:1527635555809};\\\", \\\"{x:515,y:718,t:1527635555824};\\\", \\\"{x:516,y:717,t:1527635555846};\\\", \\\"{x:516,y:716,t:1527635555917};\\\", \\\"{x:517,y:715,t:1527635555950};\\\", \\\"{x:518,y:714,t:1527635555973};\\\" ] }, { \\\"rt\\\": 20129, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 238142, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"DK1EM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:713,t:1527635556153};\\\", \\\"{x:518,y:712,t:1527635556198};\\\", \\\"{x:519,y:711,t:1527635556286};\\\", \\\"{x:520,y:711,t:1527635556566};\\\", \\\"{x:521,y:711,t:1527635556662};\\\", \\\"{x:522,y:711,t:1527635556675};\\\", \\\"{x:522,y:710,t:1527635556692};\\\", \\\"{x:523,y:710,t:1527635556782};\\\", \\\"{x:524,y:709,t:1527635556822};\\\", \\\"{x:524,y:707,t:1527635556839};\\\", \\\"{x:525,y:706,t:1527635556846};\\\", \\\"{x:526,y:704,t:1527635556862};\\\", \\\"{x:526,y:703,t:1527635556875};\\\", \\\"{x:528,y:703,t:1527635556910};\\\", \\\"{x:528,y:702,t:1527635556926};\\\", \\\"{x:529,y:701,t:1527635556958};\\\", \\\"{x:529,y:700,t:1527635556975};\\\", \\\"{x:531,y:698,t:1527635556992};\\\", \\\"{x:531,y:697,t:1527635557009};\\\", \\\"{x:534,y:695,t:1527635557025};\\\", \\\"{x:536,y:695,t:1527635557043};\\\", \\\"{x:536,y:694,t:1527635557059};\\\", \\\"{x:537,y:693,t:1527635557076};\\\", \\\"{x:537,y:692,t:1527635557126};\\\", \\\"{x:537,y:691,t:1527635557143};\\\", \\\"{x:537,y:690,t:1527635557206};\\\", \\\"{x:539,y:688,t:1527635561551};\\\", \\\"{x:541,y:687,t:1527635561563};\\\", \\\"{x:545,y:686,t:1527635561579};\\\", \\\"{x:553,y:686,t:1527635561596};\\\", \\\"{x:559,y:685,t:1527635561612};\\\", \\\"{x:567,y:685,t:1527635561628};\\\", \\\"{x:580,y:684,t:1527635561645};\\\", \\\"{x:594,y:683,t:1527635561662};\\\", \\\"{x:612,y:681,t:1527635561678};\\\", \\\"{x:638,y:677,t:1527635561696};\\\", \\\"{x:678,y:676,t:1527635561713};\\\", \\\"{x:731,y:676,t:1527635561729};\\\", \\\"{x:786,y:676,t:1527635561745};\\\", \\\"{x:848,y:676,t:1527635561762};\\\", \\\"{x:903,y:676,t:1527635561779};\\\", \\\"{x:946,y:676,t:1527635561796};\\\", \\\"{x:986,y:676,t:1527635561813};\\\", \\\"{x:1007,y:676,t:1527635561829};\\\", \\\"{x:1026,y:676,t:1527635561846};\\\", \\\"{x:1047,y:676,t:1527635561862};\\\", \\\"{x:1056,y:676,t:1527635561880};\\\", \\\"{x:1065,y:676,t:1527635561896};\\\", \\\"{x:1076,y:676,t:1527635561913};\\\", \\\"{x:1086,y:676,t:1527635561929};\\\", \\\"{x:1093,y:676,t:1527635561946};\\\", \\\"{x:1102,y:676,t:1527635561963};\\\", \\\"{x:1107,y:677,t:1527635561980};\\\", \\\"{x:1110,y:677,t:1527635561996};\\\", \\\"{x:1111,y:677,t:1527635562013};\\\", \\\"{x:1112,y:677,t:1527635562038};\\\", \\\"{x:1113,y:676,t:1527635562471};\\\", \\\"{x:1114,y:676,t:1527635562495};\\\", \\\"{x:1116,y:676,t:1527635562511};\\\", \\\"{x:1118,y:676,t:1527635562527};\\\", \\\"{x:1119,y:676,t:1527635562559};\\\", \\\"{x:1120,y:676,t:1527635562616};\\\", \\\"{x:1121,y:676,t:1527635562631};\\\", \\\"{x:1122,y:676,t:1527635562647};\\\", \\\"{x:1123,y:676,t:1527635562687};\\\", \\\"{x:1124,y:676,t:1527635562702};\\\", \\\"{x:1125,y:676,t:1527635562719};\\\", \\\"{x:1127,y:676,t:1527635562759};\\\", \\\"{x:1127,y:677,t:1527635562767};\\\", \\\"{x:1128,y:677,t:1527635562783};\\\", \\\"{x:1129,y:677,t:1527635562799};\\\", \\\"{x:1130,y:677,t:1527635562815};\\\", \\\"{x:1131,y:677,t:1527635562830};\\\", \\\"{x:1132,y:677,t:1527635562854};\\\", \\\"{x:1133,y:677,t:1527635562864};\\\", \\\"{x:1134,y:677,t:1527635562880};\\\", \\\"{x:1135,y:677,t:1527635562910};\\\", \\\"{x:1136,y:677,t:1527635562960};\\\", \\\"{x:1137,y:677,t:1527635562966};\\\", \\\"{x:1137,y:678,t:1527635562980};\\\", \\\"{x:1138,y:678,t:1527635562998};\\\", \\\"{x:1140,y:678,t:1527635563014};\\\", \\\"{x:1141,y:678,t:1527635563030};\\\", \\\"{x:1144,y:678,t:1527635563046};\\\", \\\"{x:1146,y:678,t:1527635563064};\\\", \\\"{x:1149,y:680,t:1527635563080};\\\", \\\"{x:1151,y:680,t:1527635563098};\\\", \\\"{x:1155,y:681,t:1527635563114};\\\", \\\"{x:1157,y:681,t:1527635563130};\\\", \\\"{x:1163,y:681,t:1527635563147};\\\", \\\"{x:1168,y:682,t:1527635563164};\\\", \\\"{x:1172,y:682,t:1527635563180};\\\", \\\"{x:1176,y:684,t:1527635563197};\\\", \\\"{x:1180,y:684,t:1527635563214};\\\", \\\"{x:1187,y:684,t:1527635563231};\\\", \\\"{x:1190,y:685,t:1527635563247};\\\", \\\"{x:1193,y:686,t:1527635563264};\\\", \\\"{x:1196,y:687,t:1527635563280};\\\", \\\"{x:1197,y:687,t:1527635563298};\\\", \\\"{x:1198,y:687,t:1527635563314};\\\", \\\"{x:1199,y:688,t:1527635563332};\\\", \\\"{x:1201,y:689,t:1527635563348};\\\", \\\"{x:1202,y:689,t:1527635563364};\\\", \\\"{x:1203,y:689,t:1527635563381};\\\", \\\"{x:1204,y:689,t:1527635563397};\\\", \\\"{x:1205,y:689,t:1527635563414};\\\", \\\"{x:1206,y:689,t:1527635563430};\\\", \\\"{x:1207,y:689,t:1527635563462};\\\", \\\"{x:1208,y:689,t:1527635563470};\\\", \\\"{x:1209,y:689,t:1527635563480};\\\", \\\"{x:1211,y:690,t:1527635563497};\\\", \\\"{x:1212,y:690,t:1527635563518};\\\", \\\"{x:1213,y:690,t:1527635563574};\\\", \\\"{x:1214,y:690,t:1527635563582};\\\", \\\"{x:1215,y:690,t:1527635563598};\\\", \\\"{x:1215,y:691,t:1527635563614};\\\", \\\"{x:1217,y:691,t:1527635563630};\\\", \\\"{x:1218,y:692,t:1527635563647};\\\", \\\"{x:1219,y:692,t:1527635563679};\\\", \\\"{x:1221,y:692,t:1527635563735};\\\", \\\"{x:1222,y:692,t:1527635563751};\\\", \\\"{x:1223,y:692,t:1527635563765};\\\", \\\"{x:1224,y:692,t:1527635563782};\\\", \\\"{x:1225,y:693,t:1527635563798};\\\", \\\"{x:1226,y:693,t:1527635563814};\\\", \\\"{x:1227,y:693,t:1527635564007};\\\", \\\"{x:1228,y:693,t:1527635564063};\\\", \\\"{x:1229,y:693,t:1527635564081};\\\", \\\"{x:1230,y:693,t:1527635564098};\\\", \\\"{x:1232,y:693,t:1527635564127};\\\", \\\"{x:1233,y:693,t:1527635564135};\\\", \\\"{x:1234,y:693,t:1527635564159};\\\", \\\"{x:1235,y:693,t:1527635564175};\\\", \\\"{x:1236,y:693,t:1527635564183};\\\", \\\"{x:1237,y:693,t:1527635564232};\\\", \\\"{x:1238,y:693,t:1527635564328};\\\", \\\"{x:1238,y:692,t:1527635564342};\\\", \\\"{x:1238,y:691,t:1527635564359};\\\", \\\"{x:1239,y:690,t:1527635564367};\\\", \\\"{x:1240,y:689,t:1527635564391};\\\", \\\"{x:1241,y:688,t:1527635564399};\\\", \\\"{x:1242,y:687,t:1527635564415};\\\", \\\"{x:1243,y:686,t:1527635564432};\\\", \\\"{x:1244,y:685,t:1527635564448};\\\", \\\"{x:1246,y:683,t:1527635564466};\\\", \\\"{x:1246,y:682,t:1527635564482};\\\", \\\"{x:1248,y:679,t:1527635564499};\\\", \\\"{x:1250,y:676,t:1527635564515};\\\", \\\"{x:1252,y:673,t:1527635564531};\\\", \\\"{x:1253,y:671,t:1527635564548};\\\", \\\"{x:1254,y:668,t:1527635564565};\\\", \\\"{x:1255,y:665,t:1527635564581};\\\", \\\"{x:1256,y:663,t:1527635564598};\\\", \\\"{x:1257,y:660,t:1527635564615};\\\", \\\"{x:1259,y:658,t:1527635564631};\\\", \\\"{x:1259,y:656,t:1527635564648};\\\", \\\"{x:1261,y:653,t:1527635564666};\\\", \\\"{x:1262,y:652,t:1527635564681};\\\", \\\"{x:1263,y:650,t:1527635564699};\\\", \\\"{x:1263,y:649,t:1527635564716};\\\", \\\"{x:1264,y:648,t:1527635564732};\\\", \\\"{x:1266,y:646,t:1527635564748};\\\", \\\"{x:1266,y:645,t:1527635564766};\\\", \\\"{x:1266,y:644,t:1527635564799};\\\", \\\"{x:1265,y:644,t:1527635565712};\\\", \\\"{x:1264,y:644,t:1527635565743};\\\", \\\"{x:1264,y:645,t:1527635565823};\\\", \\\"{x:1263,y:646,t:1527635566143};\\\", \\\"{x:1261,y:647,t:1527635566271};\\\", \\\"{x:1260,y:648,t:1527635566431};\\\", \\\"{x:1260,y:649,t:1527635566447};\\\", \\\"{x:1259,y:649,t:1527635566575};\\\", \\\"{x:1258,y:650,t:1527635566663};\\\", \\\"{x:1258,y:651,t:1527635566719};\\\", \\\"{x:1258,y:650,t:1527635567182};\\\", \\\"{x:1258,y:649,t:1527635567200};\\\", \\\"{x:1258,y:648,t:1527635567230};\\\", \\\"{x:1258,y:647,t:1527635567296};\\\", \\\"{x:1258,y:646,t:1527635567319};\\\", \\\"{x:1258,y:645,t:1527635567343};\\\", \\\"{x:1257,y:644,t:1527635567374};\\\", \\\"{x:1256,y:643,t:1527635567383};\\\", \\\"{x:1255,y:642,t:1527635567406};\\\", \\\"{x:1255,y:641,t:1527635567423};\\\", \\\"{x:1254,y:639,t:1527635567455};\\\", \\\"{x:1253,y:639,t:1527635568143};\\\", \\\"{x:1252,y:639,t:1527635568151};\\\", \\\"{x:1250,y:639,t:1527635568167};\\\", \\\"{x:1249,y:640,t:1527635568183};\\\", \\\"{x:1247,y:641,t:1527635568200};\\\", \\\"{x:1246,y:642,t:1527635568217};\\\", \\\"{x:1245,y:643,t:1527635568234};\\\", \\\"{x:1243,y:646,t:1527635568251};\\\", \\\"{x:1243,y:648,t:1527635568266};\\\", \\\"{x:1242,y:649,t:1527635568284};\\\", \\\"{x:1240,y:652,t:1527635568301};\\\", \\\"{x:1239,y:655,t:1527635568317};\\\", \\\"{x:1239,y:656,t:1527635568334};\\\", \\\"{x:1238,y:658,t:1527635568351};\\\", \\\"{x:1238,y:659,t:1527635568367};\\\", \\\"{x:1237,y:660,t:1527635568384};\\\", \\\"{x:1236,y:663,t:1527635568401};\\\", \\\"{x:1236,y:666,t:1527635568417};\\\", \\\"{x:1233,y:670,t:1527635568434};\\\", \\\"{x:1233,y:675,t:1527635568451};\\\", \\\"{x:1232,y:679,t:1527635568467};\\\", \\\"{x:1231,y:682,t:1527635568484};\\\", \\\"{x:1230,y:687,t:1527635568501};\\\", \\\"{x:1228,y:690,t:1527635568517};\\\", \\\"{x:1226,y:694,t:1527635568534};\\\", \\\"{x:1225,y:696,t:1527635568551};\\\", \\\"{x:1224,y:697,t:1527635568568};\\\", \\\"{x:1223,y:698,t:1527635568584};\\\", \\\"{x:1223,y:699,t:1527635568606};\\\", \\\"{x:1223,y:700,t:1527635568630};\\\", \\\"{x:1223,y:701,t:1527635568655};\\\", \\\"{x:1224,y:701,t:1527635568982};\\\", \\\"{x:1226,y:701,t:1527635568990};\\\", \\\"{x:1228,y:701,t:1527635569000};\\\", \\\"{x:1231,y:701,t:1527635569017};\\\", \\\"{x:1236,y:701,t:1527635569034};\\\", \\\"{x:1241,y:701,t:1527635569051};\\\", \\\"{x:1247,y:701,t:1527635569068};\\\", \\\"{x:1252,y:701,t:1527635569085};\\\", \\\"{x:1259,y:701,t:1527635569101};\\\", \\\"{x:1269,y:701,t:1527635569118};\\\", \\\"{x:1277,y:701,t:1527635569135};\\\", \\\"{x:1287,y:701,t:1527635569151};\\\", \\\"{x:1295,y:701,t:1527635569168};\\\", \\\"{x:1302,y:701,t:1527635569184};\\\", \\\"{x:1311,y:701,t:1527635569201};\\\", \\\"{x:1315,y:701,t:1527635569218};\\\", \\\"{x:1319,y:701,t:1527635569235};\\\", \\\"{x:1322,y:701,t:1527635569251};\\\", \\\"{x:1326,y:701,t:1527635569267};\\\", \\\"{x:1330,y:701,t:1527635569285};\\\", \\\"{x:1337,y:701,t:1527635569301};\\\", \\\"{x:1346,y:702,t:1527635569319};\\\", \\\"{x:1352,y:703,t:1527635569336};\\\", \\\"{x:1354,y:703,t:1527635569351};\\\", \\\"{x:1355,y:703,t:1527635569368};\\\", \\\"{x:1357,y:703,t:1527635569398};\\\", \\\"{x:1357,y:704,t:1527635569422};\\\", \\\"{x:1358,y:704,t:1527635569435};\\\", \\\"{x:1358,y:706,t:1527635570215};\\\", \\\"{x:1358,y:707,t:1527635570231};\\\", \\\"{x:1357,y:707,t:1527635570280};\\\", \\\"{x:1356,y:707,t:1527635570359};\\\", \\\"{x:1355,y:708,t:1527635570391};\\\", \\\"{x:1352,y:708,t:1527635572840};\\\", \\\"{x:1335,y:708,t:1527635572855};\\\", \\\"{x:1298,y:703,t:1527635572871};\\\", \\\"{x:1246,y:696,t:1527635572888};\\\", \\\"{x:1181,y:684,t:1527635572905};\\\", \\\"{x:1115,y:670,t:1527635572922};\\\", \\\"{x:1054,y:653,t:1527635572938};\\\", \\\"{x:996,y:637,t:1527635572954};\\\", \\\"{x:937,y:620,t:1527635572973};\\\", \\\"{x:881,y:604,t:1527635572987};\\\", \\\"{x:834,y:582,t:1527635573004};\\\", \\\"{x:814,y:573,t:1527635573021};\\\", \\\"{x:797,y:565,t:1527635573034};\\\", \\\"{x:785,y:559,t:1527635573051};\\\", \\\"{x:783,y:558,t:1527635573067};\\\", \\\"{x:784,y:558,t:1527635573134};\\\", \\\"{x:785,y:558,t:1527635573141};\\\", \\\"{x:786,y:557,t:1527635573158};\\\", \\\"{x:788,y:556,t:1527635573172};\\\", \\\"{x:789,y:556,t:1527635573189};\\\", \\\"{x:792,y:556,t:1527635573205};\\\", \\\"{x:801,y:554,t:1527635573222};\\\", \\\"{x:803,y:552,t:1527635573239};\\\", \\\"{x:804,y:549,t:1527635573255};\\\", \\\"{x:804,y:546,t:1527635573272};\\\", \\\"{x:805,y:542,t:1527635573289};\\\", \\\"{x:805,y:540,t:1527635573305};\\\", \\\"{x:807,y:534,t:1527635573322};\\\", \\\"{x:814,y:522,t:1527635573340};\\\", \\\"{x:821,y:515,t:1527635573355};\\\", \\\"{x:827,y:509,t:1527635573372};\\\", \\\"{x:832,y:506,t:1527635573389};\\\", \\\"{x:834,y:504,t:1527635573405};\\\", \\\"{x:836,y:502,t:1527635573421};\\\", \\\"{x:837,y:502,t:1527635573461};\\\", \\\"{x:837,y:501,t:1527635573472};\\\", \\\"{x:838,y:500,t:1527635573489};\\\", \\\"{x:840,y:499,t:1527635573505};\\\", \\\"{x:840,y:498,t:1527635573526};\\\", \\\"{x:840,y:496,t:1527635573742};\\\", \\\"{x:839,y:496,t:1527635573758};\\\", \\\"{x:837,y:496,t:1527635573772};\\\", \\\"{x:832,y:494,t:1527635573788};\\\", \\\"{x:806,y:494,t:1527635573805};\\\", \\\"{x:777,y:497,t:1527635573822};\\\", \\\"{x:739,y:502,t:1527635573839};\\\", \\\"{x:686,y:509,t:1527635573857};\\\", \\\"{x:633,y:516,t:1527635573871};\\\", \\\"{x:593,y:523,t:1527635573889};\\\", \\\"{x:553,y:530,t:1527635573907};\\\", \\\"{x:518,y:532,t:1527635573923};\\\", \\\"{x:492,y:535,t:1527635573940};\\\", \\\"{x:467,y:540,t:1527635573956};\\\", \\\"{x:449,y:540,t:1527635573972};\\\", \\\"{x:435,y:540,t:1527635573989};\\\", \\\"{x:413,y:543,t:1527635574007};\\\", \\\"{x:397,y:546,t:1527635574023};\\\", \\\"{x:384,y:548,t:1527635574039};\\\", \\\"{x:375,y:551,t:1527635574056};\\\", \\\"{x:365,y:552,t:1527635574072};\\\", \\\"{x:356,y:555,t:1527635574089};\\\", \\\"{x:345,y:557,t:1527635574107};\\\", \\\"{x:332,y:561,t:1527635574122};\\\", \\\"{x:316,y:567,t:1527635574139};\\\", \\\"{x:305,y:570,t:1527635574155};\\\", \\\"{x:294,y:572,t:1527635574173};\\\", \\\"{x:283,y:575,t:1527635574189};\\\", \\\"{x:271,y:579,t:1527635574207};\\\", \\\"{x:267,y:580,t:1527635574223};\\\", \\\"{x:260,y:580,t:1527635574239};\\\", \\\"{x:253,y:580,t:1527635574255};\\\", \\\"{x:246,y:581,t:1527635574272};\\\", \\\"{x:239,y:581,t:1527635574289};\\\", \\\"{x:231,y:581,t:1527635574305};\\\", \\\"{x:226,y:581,t:1527635574323};\\\", \\\"{x:222,y:581,t:1527635574339};\\\", \\\"{x:216,y:583,t:1527635574356};\\\", \\\"{x:211,y:583,t:1527635574373};\\\", \\\"{x:205,y:584,t:1527635574389};\\\", \\\"{x:195,y:584,t:1527635574406};\\\", \\\"{x:189,y:587,t:1527635574423};\\\", \\\"{x:184,y:588,t:1527635574439};\\\", \\\"{x:181,y:592,t:1527635574456};\\\", \\\"{x:179,y:596,t:1527635574473};\\\", \\\"{x:177,y:600,t:1527635574490};\\\", \\\"{x:175,y:603,t:1527635574507};\\\", \\\"{x:173,y:607,t:1527635574523};\\\", \\\"{x:172,y:607,t:1527635574615};\\\", \\\"{x:171,y:607,t:1527635574623};\\\", \\\"{x:170,y:603,t:1527635574641};\\\", \\\"{x:169,y:593,t:1527635574657};\\\", \\\"{x:169,y:587,t:1527635574673};\\\", \\\"{x:165,y:580,t:1527635574690};\\\", \\\"{x:165,y:575,t:1527635574705};\\\", \\\"{x:164,y:570,t:1527635574722};\\\", \\\"{x:162,y:565,t:1527635574740};\\\", \\\"{x:161,y:563,t:1527635574756};\\\", \\\"{x:160,y:559,t:1527635574773};\\\", \\\"{x:158,y:556,t:1527635574789};\\\", \\\"{x:158,y:555,t:1527635574814};\\\", \\\"{x:158,y:553,t:1527635574830};\\\", \\\"{x:158,y:552,t:1527635574840};\\\", \\\"{x:158,y:550,t:1527635574857};\\\", \\\"{x:158,y:548,t:1527635574873};\\\", \\\"{x:158,y:546,t:1527635574889};\\\", \\\"{x:158,y:544,t:1527635574907};\\\", \\\"{x:158,y:543,t:1527635574923};\\\", \\\"{x:158,y:542,t:1527635574975};\\\", \\\"{x:158,y:540,t:1527635574999};\\\", \\\"{x:160,y:539,t:1527635575254};\\\", \\\"{x:167,y:540,t:1527635575261};\\\", \\\"{x:174,y:541,t:1527635575273};\\\", \\\"{x:204,y:550,t:1527635575290};\\\", \\\"{x:249,y:563,t:1527635575308};\\\", \\\"{x:295,y:581,t:1527635575325};\\\", \\\"{x:342,y:602,t:1527635575341};\\\", \\\"{x:391,y:621,t:1527635575358};\\\", \\\"{x:432,y:641,t:1527635575374};\\\", \\\"{x:455,y:652,t:1527635575390};\\\", \\\"{x:467,y:659,t:1527635575407};\\\", \\\"{x:480,y:669,t:1527635575424};\\\", \\\"{x:486,y:673,t:1527635575441};\\\", \\\"{x:492,y:676,t:1527635575457};\\\", \\\"{x:493,y:678,t:1527635575474};\\\", \\\"{x:496,y:681,t:1527635575490};\\\", \\\"{x:497,y:685,t:1527635575507};\\\", \\\"{x:501,y:691,t:1527635575524};\\\", \\\"{x:501,y:698,t:1527635575541};\\\", \\\"{x:504,y:703,t:1527635575558};\\\", \\\"{x:505,y:707,t:1527635575574};\\\", \\\"{x:507,y:711,t:1527635575591};\\\", \\\"{x:507,y:714,t:1527635575607};\\\", \\\"{x:508,y:717,t:1527635575625};\\\", \\\"{x:509,y:721,t:1527635575643};\\\", \\\"{x:509,y:724,t:1527635575658};\\\", \\\"{x:509,y:727,t:1527635575674};\\\", \\\"{x:511,y:728,t:1527635575789};\\\", \\\"{x:511,y:729,t:1527635575807};\\\", \\\"{x:511,y:730,t:1527635575824};\\\", \\\"{x:512,y:730,t:1527635575839};\\\", \\\"{x:514,y:733,t:1527635575856};\\\", \\\"{x:516,y:738,t:1527635575874};\\\", \\\"{x:516,y:739,t:1527635575893};\\\", \\\"{x:517,y:739,t:1527635575907};\\\", \\\"{x:518,y:740,t:1527635575924};\\\", \\\"{x:519,y:740,t:1527635576118};\\\", \\\"{x:520,y:740,t:1527635576158};\\\", \\\"{x:521,y:740,t:1527635576711};\\\", \\\"{x:523,y:740,t:1527635576724};\\\", \\\"{x:534,y:740,t:1527635576741};\\\", \\\"{x:545,y:740,t:1527635576758};\\\", \\\"{x:551,y:741,t:1527635576776};\\\", \\\"{x:553,y:741,t:1527635576792};\\\", \\\"{x:554,y:741,t:1527635576871};\\\" ] }, { \\\"rt\\\": 73822, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 313189, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"DK1EM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:554,y:739,t:1527635577628};\\\", \\\"{x:555,y:737,t:1527635578365};\\\", \\\"{x:556,y:737,t:1527635578395};\\\", \\\"{x:557,y:737,t:1527635578532};\\\", \\\"{x:557,y:736,t:1527635578555};\\\", \\\"{x:558,y:736,t:1527635578659};\\\", \\\"{x:559,y:735,t:1527635578708};\\\", \\\"{x:559,y:732,t:1527635578740};\\\", \\\"{x:560,y:729,t:1527635578758};\\\", \\\"{x:560,y:728,t:1527635578774};\\\", \\\"{x:561,y:728,t:1527635579349};\\\", \\\"{x:562,y:728,t:1527635579364};\\\", \\\"{x:562,y:727,t:1527635579375};\\\", \\\"{x:566,y:725,t:1527635579392};\\\", \\\"{x:567,y:725,t:1527635579407};\\\", \\\"{x:569,y:724,t:1527635579424};\\\", \\\"{x:571,y:723,t:1527635579441};\\\", \\\"{x:572,y:723,t:1527635579475};\\\", \\\"{x:573,y:722,t:1527635579491};\\\", \\\"{x:574,y:722,t:1527635579507};\\\", \\\"{x:576,y:721,t:1527635579525};\\\", \\\"{x:580,y:719,t:1527635579542};\\\", \\\"{x:583,y:718,t:1527635579558};\\\", \\\"{x:586,y:717,t:1527635579575};\\\", \\\"{x:593,y:717,t:1527635579592};\\\", \\\"{x:597,y:716,t:1527635579608};\\\", \\\"{x:601,y:715,t:1527635579625};\\\", \\\"{x:604,y:715,t:1527635579642};\\\", \\\"{x:607,y:715,t:1527635579658};\\\", \\\"{x:610,y:714,t:1527635579675};\\\", \\\"{x:614,y:714,t:1527635579691};\\\", \\\"{x:618,y:712,t:1527635579708};\\\", \\\"{x:619,y:712,t:1527635579732};\\\", \\\"{x:620,y:712,t:1527635579743};\\\", \\\"{x:621,y:712,t:1527635579869};\\\", \\\"{x:622,y:711,t:1527635579941};\\\", \\\"{x:623,y:711,t:1527635580052};\\\", \\\"{x:624,y:711,t:1527635580124};\\\", \\\"{x:625,y:710,t:1527635580165};\\\", \\\"{x:625,y:709,t:1527635580181};\\\", \\\"{x:626,y:709,t:1527635580901};\\\", \\\"{x:627,y:708,t:1527635580948};\\\", \\\"{x:628,y:707,t:1527635580972};\\\", \\\"{x:628,y:706,t:1527635580996};\\\", \\\"{x:627,y:706,t:1527635586989};\\\", \\\"{x:626,y:706,t:1527635586999};\\\", \\\"{x:622,y:705,t:1527635587015};\\\", \\\"{x:620,y:704,t:1527635587032};\\\", \\\"{x:618,y:704,t:1527635587612};\\\", \\\"{x:618,y:702,t:1527635587628};\\\", \\\"{x:620,y:701,t:1527635587636};\\\", \\\"{x:626,y:700,t:1527635587649};\\\", \\\"{x:634,y:699,t:1527635587666};\\\", \\\"{x:647,y:698,t:1527635587682};\\\", \\\"{x:664,y:696,t:1527635587699};\\\", \\\"{x:697,y:690,t:1527635587717};\\\", \\\"{x:719,y:687,t:1527635587732};\\\", \\\"{x:745,y:684,t:1527635587749};\\\", \\\"{x:770,y:680,t:1527635587766};\\\", \\\"{x:796,y:677,t:1527635587783};\\\", \\\"{x:816,y:674,t:1527635587798};\\\", \\\"{x:836,y:670,t:1527635587816};\\\", \\\"{x:855,y:668,t:1527635587833};\\\", \\\"{x:871,y:666,t:1527635587848};\\\", \\\"{x:889,y:663,t:1527635587865};\\\", \\\"{x:912,y:659,t:1527635587882};\\\", \\\"{x:937,y:657,t:1527635587899};\\\", \\\"{x:972,y:655,t:1527635587917};\\\", \\\"{x:994,y:654,t:1527635587933};\\\", \\\"{x:1010,y:653,t:1527635587949};\\\", \\\"{x:1021,y:653,t:1527635587966};\\\", \\\"{x:1023,y:652,t:1527635587983};\\\", \\\"{x:1016,y:650,t:1527635648937};\\\", \\\"{x:974,y:644,t:1527635648948};\\\", \\\"{x:830,y:625,t:1527635648967};\\\", \\\"{x:702,y:604,t:1527635648983};\\\", \\\"{x:591,y:585,t:1527635648998};\\\", \\\"{x:502,y:568,t:1527635649027};\\\", \\\"{x:494,y:565,t:1527635649045};\\\", \\\"{x:489,y:562,t:1527635649061};\\\", \\\"{x:487,y:562,t:1527635649079};\\\", \\\"{x:485,y:561,t:1527635649103};\\\", \\\"{x:483,y:560,t:1527635649119};\\\", \\\"{x:481,y:560,t:1527635649128};\\\", \\\"{x:480,y:559,t:1527635649145};\\\", \\\"{x:485,y:559,t:1527635649191};\\\", \\\"{x:497,y:555,t:1527635649200};\\\", \\\"{x:508,y:553,t:1527635649213};\\\", \\\"{x:530,y:546,t:1527635649227};\\\", \\\"{x:547,y:539,t:1527635649245};\\\", \\\"{x:561,y:530,t:1527635649262};\\\", \\\"{x:569,y:524,t:1527635649279};\\\", \\\"{x:572,y:519,t:1527635649295};\\\", \\\"{x:574,y:514,t:1527635649312};\\\", \\\"{x:578,y:509,t:1527635649328};\\\", \\\"{x:580,y:506,t:1527635649345};\\\", \\\"{x:583,y:505,t:1527635649362};\\\", \\\"{x:587,y:502,t:1527635649378};\\\", \\\"{x:591,y:500,t:1527635649395};\\\", \\\"{x:591,y:499,t:1527635649412};\\\", \\\"{x:592,y:499,t:1527635649552};\\\", \\\"{x:593,y:500,t:1527635649849};\\\", \\\"{x:592,y:510,t:1527635649862};\\\", \\\"{x:582,y:534,t:1527635649881};\\\", \\\"{x:571,y:569,t:1527635649896};\\\", \\\"{x:565,y:589,t:1527635649912};\\\", \\\"{x:564,y:601,t:1527635649928};\\\", \\\"{x:564,y:609,t:1527635649945};\\\", \\\"{x:564,y:613,t:1527635649962};\\\", \\\"{x:566,y:619,t:1527635649979};\\\", \\\"{x:567,y:623,t:1527635649995};\\\", \\\"{x:569,y:628,t:1527635650012};\\\", \\\"{x:569,y:634,t:1527635650030};\\\", \\\"{x:569,y:639,t:1527635650045};\\\", \\\"{x:569,y:641,t:1527635650062};\\\", \\\"{x:571,y:641,t:1527635650176};\\\", \\\"{x:573,y:640,t:1527635650183};\\\", \\\"{x:575,y:639,t:1527635650196};\\\", \\\"{x:580,y:633,t:1527635650212};\\\", \\\"{x:581,y:625,t:1527635650230};\\\", \\\"{x:583,y:609,t:1527635650246};\\\", \\\"{x:585,y:591,t:1527635650263};\\\", \\\"{x:587,y:575,t:1527635650279};\\\", \\\"{x:591,y:551,t:1527635650297};\\\", \\\"{x:593,y:540,t:1527635650312};\\\", \\\"{x:596,y:533,t:1527635650328};\\\", \\\"{x:598,y:529,t:1527635650345};\\\", \\\"{x:599,y:526,t:1527635650362};\\\", \\\"{x:600,y:525,t:1527635650378};\\\", \\\"{x:600,y:522,t:1527635650396};\\\", \\\"{x:601,y:521,t:1527635650412};\\\", \\\"{x:602,y:518,t:1527635650429};\\\", \\\"{x:604,y:515,t:1527635650446};\\\", \\\"{x:605,y:513,t:1527635650464};\\\", \\\"{x:606,y:511,t:1527635650479};\\\", \\\"{x:607,y:510,t:1527635650496};\\\", \\\"{x:608,y:507,t:1527635650512};\\\", \\\"{x:609,y:506,t:1527635650536};\\\", \\\"{x:609,y:505,t:1527635650551};\\\", \\\"{x:609,y:504,t:1527635650760};\\\", \\\"{x:604,y:504,t:1527635650767};\\\", \\\"{x:601,y:507,t:1527635650779};\\\", \\\"{x:589,y:519,t:1527635650797};\\\", \\\"{x:579,y:531,t:1527635650813};\\\", \\\"{x:570,y:549,t:1527635650829};\\\", \\\"{x:563,y:571,t:1527635650846};\\\", \\\"{x:555,y:601,t:1527635650863};\\\", \\\"{x:550,y:622,t:1527635650879};\\\", \\\"{x:545,y:649,t:1527635650896};\\\", \\\"{x:542,y:667,t:1527635650914};\\\", \\\"{x:541,y:682,t:1527635650929};\\\", \\\"{x:539,y:696,t:1527635650947};\\\", \\\"{x:536,y:717,t:1527635650963};\\\", \\\"{x:535,y:727,t:1527635650979};\\\", \\\"{x:534,y:733,t:1527635650996};\\\", \\\"{x:533,y:736,t:1527635651013};\\\", \\\"{x:533,y:737,t:1527635651495};\\\", \\\"{x:535,y:737,t:1527635651504};\\\", \\\"{x:542,y:737,t:1527635651513};\\\", \\\"{x:556,y:737,t:1527635651530};\\\", \\\"{x:570,y:737,t:1527635651547};\\\", \\\"{x:577,y:737,t:1527635651563};\\\", \\\"{x:578,y:737,t:1527635651580};\\\", \\\"{x:580,y:737,t:1527635651597};\\\", \\\"{x:581,y:737,t:1527635651613};\\\", \\\"{x:582,y:737,t:1527635651632};\\\", \\\"{x:584,y:737,t:1527635651647};\\\", \\\"{x:589,y:738,t:1527635651663};\\\", \\\"{x:603,y:738,t:1527635651680};\\\", \\\"{x:609,y:738,t:1527635651698};\\\", \\\"{x:612,y:738,t:1527635651713};\\\", \\\"{x:613,y:738,t:1527635651730};\\\", \\\"{x:612,y:738,t:1527635651848};\\\", \\\"{x:611,y:738,t:1527635651864};\\\", \\\"{x:598,y:738,t:1527635651880};\\\", \\\"{x:591,y:738,t:1527635651897};\\\", \\\"{x:585,y:738,t:1527635651914};\\\", \\\"{x:581,y:738,t:1527635651930};\\\", \\\"{x:578,y:738,t:1527635651948};\\\", \\\"{x:577,y:738,t:1527635651965};\\\", \\\"{x:576,y:738,t:1527635651992};\\\", \\\"{x:575,y:738,t:1527635652048};\\\", \\\"{x:574,y:738,t:1527635652720};\\\" ] }, { \\\"rt\\\": 31946, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 346762, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"DK1EM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:462,y:891,t:1527635653086};\\\", \\\"{x:460,y:891,t:1527635654489};\\\", \\\"{x:459,y:891,t:1527635654600};\\\", \\\"{x:462,y:886,t:1527635655601};\\\", \\\"{x:490,y:867,t:1527635655616};\\\", \\\"{x:525,y:853,t:1527635655633};\\\", \\\"{x:528,y:853,t:1527635655649};\\\", \\\"{x:529,y:850,t:1527635655666};\\\", \\\"{x:530,y:850,t:1527635657311};\\\", \\\"{x:531,y:848,t:1527635657319};\\\", \\\"{x:533,y:846,t:1527635657334};\\\", \\\"{x:533,y:845,t:1527635657351};\\\", \\\"{x:533,y:843,t:1527635657367};\\\", \\\"{x:535,y:840,t:1527635657384};\\\", \\\"{x:538,y:836,t:1527635657401};\\\", \\\"{x:541,y:834,t:1527635657417};\\\", \\\"{x:544,y:829,t:1527635657434};\\\", \\\"{x:547,y:823,t:1527635657451};\\\", \\\"{x:550,y:819,t:1527635657468};\\\", \\\"{x:551,y:817,t:1527635657485};\\\", \\\"{x:551,y:814,t:1527635657501};\\\", \\\"{x:555,y:807,t:1527635657517};\\\", \\\"{x:559,y:801,t:1527635657534};\\\", \\\"{x:564,y:787,t:1527635657551};\\\", \\\"{x:572,y:776,t:1527635657567};\\\", \\\"{x:576,y:770,t:1527635657584};\\\", \\\"{x:580,y:764,t:1527635657601};\\\", \\\"{x:585,y:755,t:1527635657617};\\\", \\\"{x:590,y:749,t:1527635657635};\\\", \\\"{x:595,y:744,t:1527635657651};\\\", \\\"{x:598,y:740,t:1527635657669};\\\", \\\"{x:601,y:736,t:1527635657685};\\\", \\\"{x:602,y:735,t:1527635657701};\\\", \\\"{x:604,y:735,t:1527635657744};\\\", \\\"{x:605,y:735,t:1527635657759};\\\", \\\"{x:606,y:735,t:1527635657768};\\\", \\\"{x:606,y:734,t:1527635658704};\\\", \\\"{x:606,y:733,t:1527635658728};\\\", \\\"{x:607,y:732,t:1527635658735};\\\", \\\"{x:609,y:731,t:1527635658752};\\\", \\\"{x:612,y:726,t:1527635658769};\\\", \\\"{x:616,y:723,t:1527635658786};\\\", \\\"{x:619,y:719,t:1527635658803};\\\", \\\"{x:621,y:717,t:1527635658819};\\\", \\\"{x:623,y:715,t:1527635658836};\\\", \\\"{x:624,y:715,t:1527635658852};\\\", \\\"{x:624,y:714,t:1527635658960};\\\", \\\"{x:625,y:713,t:1527635660225};\\\", \\\"{x:626,y:712,t:1527635660236};\\\", \\\"{x:626,y:711,t:1527635660264};\\\", \\\"{x:627,y:709,t:1527635660344};\\\", \\\"{x:627,y:708,t:1527635660354};\\\", \\\"{x:630,y:705,t:1527635660370};\\\", \\\"{x:632,y:700,t:1527635660387};\\\", \\\"{x:634,y:698,t:1527635660404};\\\", \\\"{x:637,y:695,t:1527635660419};\\\", \\\"{x:639,y:694,t:1527635660437};\\\", \\\"{x:641,y:693,t:1527635660453};\\\", \\\"{x:643,y:691,t:1527635660470};\\\", \\\"{x:646,y:690,t:1527635660487};\\\", \\\"{x:649,y:686,t:1527635660504};\\\", \\\"{x:650,y:685,t:1527635660520};\\\", \\\"{x:651,y:684,t:1527635660543};\\\", \\\"{x:652,y:684,t:1527635660553};\\\", \\\"{x:653,y:683,t:1527635660570};\\\", \\\"{x:656,y:680,t:1527635660586};\\\", \\\"{x:658,y:679,t:1527635660603};\\\", \\\"{x:660,y:677,t:1527635660620};\\\", \\\"{x:661,y:676,t:1527635660636};\\\", \\\"{x:663,y:675,t:1527635660653};\\\", \\\"{x:664,y:674,t:1527635660670};\\\", \\\"{x:666,y:673,t:1527635660686};\\\", \\\"{x:668,y:670,t:1527635660704};\\\", \\\"{x:670,y:668,t:1527635660720};\\\", \\\"{x:671,y:668,t:1527635660743};\\\", \\\"{x:673,y:667,t:1527635660767};\\\", \\\"{x:673,y:666,t:1527635660872};\\\", \\\"{x:675,y:665,t:1527635660919};\\\", \\\"{x:676,y:665,t:1527635661369};\\\", \\\"{x:676,y:667,t:1527635661384};\\\", \\\"{x:676,y:668,t:1527635661392};\\\", \\\"{x:675,y:668,t:1527635661407};\\\", \\\"{x:674,y:669,t:1527635661421};\\\", \\\"{x:674,y:670,t:1527635661437};\\\", \\\"{x:673,y:671,t:1527635661454};\\\", \\\"{x:673,y:673,t:1527635661544};\\\", \\\"{x:672,y:673,t:1527635661568};\\\", \\\"{x:671,y:674,t:1527635661664};\\\", \\\"{x:671,y:676,t:1527635661825};\\\", \\\"{x:671,y:677,t:1527635661896};\\\", \\\"{x:670,y:678,t:1527635661920};\\\", \\\"{x:670,y:679,t:1527635661968};\\\", \\\"{x:669,y:680,t:1527635662008};\\\", \\\"{x:669,y:681,t:1527635662040};\\\", \\\"{x:669,y:682,t:1527635662056};\\\", \\\"{x:669,y:683,t:1527635662071};\\\", \\\"{x:669,y:685,t:1527635662087};\\\", \\\"{x:670,y:691,t:1527635662105};\\\", \\\"{x:675,y:697,t:1527635662122};\\\", \\\"{x:683,y:705,t:1527635662138};\\\", \\\"{x:693,y:711,t:1527635662155};\\\", \\\"{x:702,y:716,t:1527635662171};\\\", \\\"{x:707,y:719,t:1527635662188};\\\", \\\"{x:713,y:725,t:1527635662205};\\\", \\\"{x:720,y:732,t:1527635662222};\\\", \\\"{x:730,y:739,t:1527635662237};\\\", \\\"{x:736,y:745,t:1527635662255};\\\", \\\"{x:742,y:751,t:1527635662272};\\\", \\\"{x:744,y:753,t:1527635662288};\\\", \\\"{x:746,y:756,t:1527635662305};\\\", \\\"{x:748,y:760,t:1527635662321};\\\", \\\"{x:750,y:762,t:1527635662338};\\\", \\\"{x:752,y:764,t:1527635662355};\\\", \\\"{x:753,y:765,t:1527635662372};\\\", \\\"{x:757,y:767,t:1527635662388};\\\", \\\"{x:765,y:771,t:1527635662404};\\\", \\\"{x:777,y:776,t:1527635662421};\\\", \\\"{x:787,y:780,t:1527635662439};\\\", \\\"{x:793,y:783,t:1527635662455};\\\", \\\"{x:798,y:784,t:1527635662471};\\\", \\\"{x:799,y:785,t:1527635662495};\\\", \\\"{x:802,y:785,t:1527635680824};\\\", \\\"{x:810,y:780,t:1527635680836};\\\", \\\"{x:825,y:774,t:1527635680852};\\\", \\\"{x:833,y:770,t:1527635680868};\\\", \\\"{x:839,y:767,t:1527635680885};\\\", \\\"{x:844,y:764,t:1527635680901};\\\", \\\"{x:847,y:762,t:1527635680918};\\\", \\\"{x:850,y:761,t:1527635680934};\\\", \\\"{x:852,y:761,t:1527635680951};\\\", \\\"{x:853,y:761,t:1527635680968};\\\", \\\"{x:855,y:761,t:1527635680985};\\\", \\\"{x:857,y:761,t:1527635681002};\\\", \\\"{x:858,y:761,t:1527635681018};\\\", \\\"{x:861,y:760,t:1527635681035};\\\", \\\"{x:866,y:758,t:1527635681052};\\\", \\\"{x:876,y:754,t:1527635681068};\\\", \\\"{x:888,y:747,t:1527635681085};\\\", \\\"{x:900,y:742,t:1527635681103};\\\", \\\"{x:912,y:737,t:1527635681118};\\\", \\\"{x:925,y:731,t:1527635681135};\\\", \\\"{x:928,y:731,t:1527635681152};\\\", \\\"{x:928,y:730,t:1527635681216};\\\", \\\"{x:928,y:729,t:1527635681232};\\\", \\\"{x:925,y:728,t:1527635681240};\\\", \\\"{x:917,y:728,t:1527635681253};\\\", \\\"{x:893,y:724,t:1527635681269};\\\", \\\"{x:856,y:716,t:1527635681285};\\\", \\\"{x:800,y:708,t:1527635681302};\\\", \\\"{x:735,y:694,t:1527635681318};\\\", \\\"{x:655,y:675,t:1527635681335};\\\", \\\"{x:620,y:664,t:1527635681352};\\\", \\\"{x:595,y:657,t:1527635681368};\\\", \\\"{x:578,y:652,t:1527635681385};\\\", \\\"{x:575,y:651,t:1527635681402};\\\", \\\"{x:573,y:651,t:1527635681419};\\\", \\\"{x:570,y:651,t:1527635681435};\\\", \\\"{x:562,y:648,t:1527635681452};\\\", \\\"{x:552,y:646,t:1527635681469};\\\", \\\"{x:542,y:644,t:1527635681485};\\\", \\\"{x:532,y:643,t:1527635681503};\\\", \\\"{x:517,y:638,t:1527635681519};\\\", \\\"{x:512,y:637,t:1527635681535};\\\", \\\"{x:506,y:635,t:1527635681552};\\\", \\\"{x:492,y:631,t:1527635681570};\\\", \\\"{x:473,y:628,t:1527635681585};\\\", \\\"{x:446,y:624,t:1527635681602};\\\", \\\"{x:419,y:623,t:1527635681621};\\\", \\\"{x:392,y:619,t:1527635681637};\\\", \\\"{x:374,y:617,t:1527635681654};\\\", \\\"{x:357,y:614,t:1527635681671};\\\", \\\"{x:354,y:613,t:1527635681687};\\\", \\\"{x:353,y:613,t:1527635681704};\\\", \\\"{x:352,y:613,t:1527635681721};\\\", \\\"{x:351,y:613,t:1527635681737};\\\", \\\"{x:346,y:612,t:1527635681754};\\\", \\\"{x:335,y:608,t:1527635681771};\\\", \\\"{x:321,y:604,t:1527635681787};\\\", \\\"{x:314,y:603,t:1527635681805};\\\", \\\"{x:310,y:602,t:1527635681821};\\\", \\\"{x:308,y:602,t:1527635681837};\\\", \\\"{x:305,y:600,t:1527635681855};\\\", \\\"{x:302,y:599,t:1527635681871};\\\", \\\"{x:295,y:596,t:1527635681887};\\\", \\\"{x:285,y:594,t:1527635681904};\\\", \\\"{x:268,y:591,t:1527635681922};\\\", \\\"{x:247,y:589,t:1527635681938};\\\", \\\"{x:231,y:586,t:1527635681954};\\\", \\\"{x:211,y:584,t:1527635681972};\\\", \\\"{x:197,y:582,t:1527635681988};\\\", \\\"{x:188,y:580,t:1527635682005};\\\", \\\"{x:185,y:579,t:1527635682022};\\\", \\\"{x:182,y:577,t:1527635682039};\\\", \\\"{x:181,y:576,t:1527635682054};\\\", \\\"{x:177,y:573,t:1527635682071};\\\", \\\"{x:176,y:570,t:1527635682088};\\\", \\\"{x:174,y:565,t:1527635682105};\\\", \\\"{x:172,y:562,t:1527635682122};\\\", \\\"{x:169,y:556,t:1527635682138};\\\", \\\"{x:169,y:555,t:1527635682156};\\\", \\\"{x:166,y:550,t:1527635682172};\\\", \\\"{x:166,y:545,t:1527635682188};\\\", \\\"{x:165,y:540,t:1527635682204};\\\", \\\"{x:164,y:536,t:1527635682221};\\\", \\\"{x:162,y:532,t:1527635682238};\\\", \\\"{x:160,y:525,t:1527635682255};\\\", \\\"{x:158,y:521,t:1527635682272};\\\", \\\"{x:156,y:518,t:1527635682288};\\\", \\\"{x:156,y:514,t:1527635682305};\\\", \\\"{x:154,y:511,t:1527635682321};\\\", \\\"{x:152,y:507,t:1527635682339};\\\", \\\"{x:151,y:506,t:1527635682354};\\\", \\\"{x:151,y:504,t:1527635682371};\\\", \\\"{x:150,y:504,t:1527635682391};\\\", \\\"{x:150,y:502,t:1527635682405};\\\", \\\"{x:149,y:501,t:1527635682423};\\\", \\\"{x:156,y:506,t:1527635682657};\\\", \\\"{x:189,y:526,t:1527635682673};\\\", \\\"{x:235,y:551,t:1527635682688};\\\", \\\"{x:287,y:583,t:1527635682705};\\\", \\\"{x:325,y:607,t:1527635682722};\\\", \\\"{x:358,y:626,t:1527635682738};\\\", \\\"{x:379,y:638,t:1527635682756};\\\", \\\"{x:394,y:649,t:1527635682772};\\\", \\\"{x:407,y:661,t:1527635682788};\\\", \\\"{x:418,y:671,t:1527635682806};\\\", \\\"{x:429,y:680,t:1527635682822};\\\", \\\"{x:437,y:685,t:1527635682839};\\\", \\\"{x:443,y:689,t:1527635682855};\\\", \\\"{x:446,y:691,t:1527635682871};\\\", \\\"{x:448,y:693,t:1527635682888};\\\", \\\"{x:449,y:693,t:1527635682905};\\\", \\\"{x:448,y:693,t:1527635682951};\\\", \\\"{x:443,y:687,t:1527635682959};\\\", \\\"{x:437,y:679,t:1527635682972};\\\", \\\"{x:412,y:660,t:1527635682989};\\\", \\\"{x:369,y:631,t:1527635683006};\\\", \\\"{x:314,y:597,t:1527635683023};\\\", \\\"{x:251,y:559,t:1527635683038};\\\", \\\"{x:169,y:510,t:1527635683056};\\\", \\\"{x:143,y:492,t:1527635683072};\\\", \\\"{x:131,y:480,t:1527635683089};\\\", \\\"{x:126,y:473,t:1527635683105};\\\", \\\"{x:125,y:472,t:1527635683122};\\\", \\\"{x:125,y:470,t:1527635683138};\\\", \\\"{x:124,y:469,t:1527635683156};\\\", \\\"{x:124,y:468,t:1527635683174};\\\", \\\"{x:124,y:467,t:1527635683189};\\\", \\\"{x:124,y:466,t:1527635683296};\\\", \\\"{x:128,y:467,t:1527635683311};\\\", \\\"{x:131,y:469,t:1527635683322};\\\", \\\"{x:143,y:477,t:1527635683339};\\\", \\\"{x:163,y:484,t:1527635683356};\\\", \\\"{x:179,y:492,t:1527635683373};\\\", \\\"{x:184,y:494,t:1527635683389};\\\", \\\"{x:188,y:497,t:1527635683406};\\\", \\\"{x:189,y:498,t:1527635683447};\\\", \\\"{x:189,y:500,t:1527635683463};\\\", \\\"{x:188,y:503,t:1527635683478};\\\", \\\"{x:186,y:504,t:1527635683495};\\\", \\\"{x:184,y:504,t:1527635683506};\\\", \\\"{x:182,y:506,t:1527635683522};\\\", \\\"{x:180,y:506,t:1527635683599};\\\", \\\"{x:178,y:506,t:1527635683615};\\\", \\\"{x:175,y:506,t:1527635683631};\\\", \\\"{x:174,y:506,t:1527635683638};\\\", \\\"{x:171,y:506,t:1527635683656};\\\", \\\"{x:170,y:505,t:1527635683672};\\\", \\\"{x:169,y:505,t:1527635683689};\\\", \\\"{x:168,y:505,t:1527635683706};\\\", \\\"{x:167,y:505,t:1527635683722};\\\", \\\"{x:172,y:509,t:1527635683919};\\\", \\\"{x:182,y:513,t:1527635683927};\\\", \\\"{x:197,y:521,t:1527635683940};\\\", \\\"{x:228,y:537,t:1527635683957};\\\", \\\"{x:253,y:551,t:1527635683972};\\\", \\\"{x:290,y:566,t:1527635683990};\\\", \\\"{x:317,y:578,t:1527635684006};\\\", \\\"{x:333,y:588,t:1527635684022};\\\", \\\"{x:355,y:599,t:1527635684040};\\\", \\\"{x:369,y:607,t:1527635684057};\\\", \\\"{x:377,y:611,t:1527635684073};\\\", \\\"{x:383,y:615,t:1527635684089};\\\", \\\"{x:388,y:620,t:1527635684107};\\\", \\\"{x:391,y:624,t:1527635684124};\\\", \\\"{x:397,y:630,t:1527635684140};\\\", \\\"{x:402,y:634,t:1527635684156};\\\", \\\"{x:406,y:637,t:1527635684174};\\\", \\\"{x:407,y:639,t:1527635684190};\\\", \\\"{x:407,y:640,t:1527635684207};\\\", \\\"{x:414,y:646,t:1527635684223};\\\", \\\"{x:415,y:647,t:1527635684240};\\\", \\\"{x:418,y:651,t:1527635684263};\\\", \\\"{x:423,y:655,t:1527635684273};\\\", \\\"{x:428,y:663,t:1527635684289};\\\", \\\"{x:435,y:671,t:1527635684307};\\\", \\\"{x:437,y:673,t:1527635684323};\\\", \\\"{x:439,y:673,t:1527635684375};\\\", \\\"{x:440,y:674,t:1527635684389};\\\", \\\"{x:441,y:676,t:1527635684406};\\\", \\\"{x:443,y:679,t:1527635684423};\\\", \\\"{x:446,y:682,t:1527635684439};\\\", \\\"{x:449,y:686,t:1527635684456};\\\", \\\"{x:453,y:691,t:1527635684474};\\\", \\\"{x:459,y:698,t:1527635684489};\\\", \\\"{x:466,y:707,t:1527635684506};\\\", \\\"{x:474,y:714,t:1527635684524};\\\", \\\"{x:480,y:718,t:1527635684540};\\\", \\\"{x:484,y:719,t:1527635684557};\\\", \\\"{x:485,y:720,t:1527635684575};\\\", \\\"{x:486,y:720,t:1527635684680};\\\", \\\"{x:487,y:720,t:1527635684695};\\\", \\\"{x:489,y:720,t:1527635684707};\\\", \\\"{x:494,y:724,t:1527635684724};\\\", \\\"{x:500,y:729,t:1527635684740};\\\", \\\"{x:506,y:735,t:1527635684756};\\\", \\\"{x:508,y:736,t:1527635684774};\\\", \\\"{x:509,y:737,t:1527635685190};\\\", \\\"{x:509,y:738,t:1527635685206};\\\", \\\"{x:510,y:738,t:1527635685223};\\\", \\\"{x:510,y:739,t:1527635685374};\\\", \\\"{x:510,y:740,t:1527635685390};\\\", \\\"{x:510,y:741,t:1527635685406};\\\", \\\"{x:510,y:742,t:1527635685438};\\\", \\\"{x:510,y:743,t:1527635685494};\\\", \\\"{x:510,y:744,t:1527635685527};\\\" ] }, { \\\"rt\\\": 41321, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 389295, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"DK1EM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:512,y:744,t:1527635686115};\\\", \\\"{x:513,y:744,t:1527635686125};\\\", \\\"{x:515,y:742,t:1527635686141};\\\", \\\"{x:516,y:742,t:1527635686157};\\\", \\\"{x:519,y:741,t:1527635686174};\\\", \\\"{x:524,y:737,t:1527635686191};\\\", \\\"{x:530,y:735,t:1527635686207};\\\", \\\"{x:534,y:734,t:1527635686224};\\\", \\\"{x:538,y:731,t:1527635686241};\\\", \\\"{x:542,y:730,t:1527635686257};\\\", \\\"{x:547,y:729,t:1527635686278};\\\", \\\"{x:552,y:727,t:1527635686292};\\\", \\\"{x:555,y:726,t:1527635686307};\\\", \\\"{x:558,y:725,t:1527635686324};\\\", \\\"{x:560,y:725,t:1527635686341};\\\", \\\"{x:561,y:724,t:1527635686357};\\\", \\\"{x:554,y:713,t:1527635699191};\\\", \\\"{x:533,y:694,t:1527635699198};\\\", \\\"{x:491,y:668,t:1527635699215};\\\", \\\"{x:464,y:656,t:1527635699231};\\\", \\\"{x:418,y:633,t:1527635699250};\\\", \\\"{x:365,y:608,t:1527635699265};\\\", \\\"{x:342,y:591,t:1527635699283};\\\", \\\"{x:327,y:579,t:1527635699299};\\\", \\\"{x:313,y:570,t:1527635699316};\\\", \\\"{x:301,y:560,t:1527635699333};\\\", \\\"{x:294,y:555,t:1527635699350};\\\", \\\"{x:290,y:554,t:1527635699366};\\\", \\\"{x:288,y:553,t:1527635699383};\\\", \\\"{x:287,y:553,t:1527635699477};\\\", \\\"{x:282,y:553,t:1527635699485};\\\", \\\"{x:275,y:556,t:1527635699500};\\\", \\\"{x:261,y:562,t:1527635699517};\\\", \\\"{x:249,y:567,t:1527635699534};\\\", \\\"{x:238,y:573,t:1527635699549};\\\", \\\"{x:228,y:578,t:1527635699566};\\\", \\\"{x:220,y:582,t:1527635699583};\\\", \\\"{x:215,y:586,t:1527635699599};\\\", \\\"{x:210,y:590,t:1527635699617};\\\", \\\"{x:208,y:594,t:1527635699633};\\\", \\\"{x:205,y:599,t:1527635699649};\\\", \\\"{x:204,y:604,t:1527635699667};\\\", \\\"{x:203,y:608,t:1527635699682};\\\", \\\"{x:203,y:612,t:1527635699700};\\\", \\\"{x:203,y:617,t:1527635699716};\\\", \\\"{x:203,y:619,t:1527635699734};\\\", \\\"{x:203,y:623,t:1527635699749};\\\", \\\"{x:205,y:625,t:1527635699767};\\\", \\\"{x:210,y:627,t:1527635699783};\\\", \\\"{x:219,y:629,t:1527635699799};\\\", \\\"{x:230,y:629,t:1527635699817};\\\", \\\"{x:240,y:629,t:1527635699834};\\\", \\\"{x:253,y:629,t:1527635699850};\\\", \\\"{x:271,y:627,t:1527635699867};\\\", \\\"{x:299,y:621,t:1527635699885};\\\", \\\"{x:330,y:616,t:1527635699900};\\\", \\\"{x:369,y:610,t:1527635699916};\\\", \\\"{x:391,y:607,t:1527635699933};\\\", \\\"{x:407,y:606,t:1527635699950};\\\", \\\"{x:425,y:605,t:1527635699967};\\\", \\\"{x:442,y:604,t:1527635699983};\\\", \\\"{x:460,y:602,t:1527635699999};\\\", \\\"{x:474,y:602,t:1527635700017};\\\", \\\"{x:482,y:601,t:1527635700034};\\\", \\\"{x:488,y:601,t:1527635700049};\\\", \\\"{x:496,y:601,t:1527635700067};\\\", \\\"{x:506,y:601,t:1527635700084};\\\", \\\"{x:520,y:601,t:1527635700100};\\\", \\\"{x:542,y:601,t:1527635700116};\\\", \\\"{x:551,y:601,t:1527635700134};\\\", \\\"{x:555,y:601,t:1527635700149};\\\", \\\"{x:559,y:600,t:1527635700167};\\\", \\\"{x:562,y:599,t:1527635700184};\\\", \\\"{x:565,y:599,t:1527635700200};\\\", \\\"{x:569,y:598,t:1527635700217};\\\", \\\"{x:576,y:596,t:1527635700234};\\\", \\\"{x:581,y:595,t:1527635700250};\\\", \\\"{x:587,y:594,t:1527635700267};\\\", \\\"{x:592,y:592,t:1527635700285};\\\", \\\"{x:596,y:591,t:1527635700300};\\\", \\\"{x:598,y:589,t:1527635700317};\\\", \\\"{x:599,y:588,t:1527635700340};\\\", \\\"{x:600,y:587,t:1527635700365};\\\", \\\"{x:602,y:586,t:1527635700384};\\\", \\\"{x:602,y:585,t:1527635700401};\\\", \\\"{x:606,y:583,t:1527635700417};\\\", \\\"{x:607,y:583,t:1527635700434};\\\", \\\"{x:608,y:582,t:1527635700451};\\\", \\\"{x:610,y:581,t:1527635700467};\\\", \\\"{x:608,y:581,t:1527635700829};\\\", \\\"{x:607,y:583,t:1527635700836};\\\", \\\"{x:606,y:585,t:1527635700850};\\\", \\\"{x:604,y:590,t:1527635700868};\\\", \\\"{x:601,y:597,t:1527635700884};\\\", \\\"{x:598,y:607,t:1527635700901};\\\", \\\"{x:596,y:615,t:1527635700917};\\\", \\\"{x:594,y:624,t:1527635700934};\\\", \\\"{x:594,y:631,t:1527635700950};\\\", \\\"{x:594,y:638,t:1527635700968};\\\", \\\"{x:593,y:645,t:1527635700984};\\\", \\\"{x:592,y:654,t:1527635701000};\\\", \\\"{x:591,y:663,t:1527635701018};\\\", \\\"{x:589,y:668,t:1527635701035};\\\", \\\"{x:586,y:677,t:1527635701051};\\\", \\\"{x:585,y:686,t:1527635701068};\\\", \\\"{x:581,y:697,t:1527635701085};\\\", \\\"{x:579,y:701,t:1527635701100};\\\", \\\"{x:578,y:701,t:1527635701118};\\\", \\\"{x:578,y:702,t:1527635727077};\\\", \\\"{x:577,y:710,t:1527635727090};\\\", \\\"{x:573,y:726,t:1527635727105};\\\", \\\"{x:568,y:737,t:1527635727123};\\\", \\\"{x:562,y:745,t:1527635727141};\\\", \\\"{x:560,y:747,t:1527635727157};\\\", \\\"{x:558,y:747,t:1527635727195};\\\", \\\"{x:556,y:747,t:1527635727203};\\\", \\\"{x:554,y:747,t:1527635727220};\\\", \\\"{x:550,y:747,t:1527635727236};\\\", \\\"{x:547,y:747,t:1527635727253};\\\", \\\"{x:546,y:747,t:1527635727292};\\\", \\\"{x:544,y:747,t:1527635727304};\\\", \\\"{x:543,y:747,t:1527635727321};\\\", \\\"{x:541,y:746,t:1527635727337};\\\", \\\"{x:540,y:746,t:1527635727620};\\\", \\\"{x:541,y:747,t:1527635727627};\\\", \\\"{x:542,y:747,t:1527635727639};\\\", \\\"{x:542,y:748,t:1527635727656};\\\", \\\"{x:544,y:749,t:1527635727672};\\\", \\\"{x:544,y:750,t:1527635727689};\\\", \\\"{x:546,y:751,t:1527635727706};\\\", \\\"{x:550,y:754,t:1527635727721};\\\", \\\"{x:553,y:754,t:1527635727739};\\\", \\\"{x:576,y:761,t:1527635727756};\\\", \\\"{x:598,y:771,t:1527635727772};\\\", \\\"{x:619,y:776,t:1527635727789};\\\", \\\"{x:637,y:779,t:1527635727805};\\\", \\\"{x:656,y:779,t:1527635727823};\\\", \\\"{x:670,y:779,t:1527635727839};\\\", \\\"{x:681,y:779,t:1527635727855};\\\", \\\"{x:695,y:781,t:1527635727873};\\\", \\\"{x:707,y:781,t:1527635727889};\\\", \\\"{x:719,y:781,t:1527635727906};\\\", \\\"{x:733,y:781,t:1527635727922};\\\", \\\"{x:745,y:781,t:1527635727939};\\\", \\\"{x:763,y:781,t:1527635727956};\\\", \\\"{x:770,y:781,t:1527635727972};\\\", \\\"{x:775,y:781,t:1527635727989};\\\", \\\"{x:777,y:781,t:1527635728006};\\\", \\\"{x:778,y:781,t:1527635728022};\\\", \\\"{x:780,y:782,t:1527635728039};\\\", \\\"{x:782,y:783,t:1527635728056};\\\", \\\"{x:784,y:784,t:1527635728072};\\\", \\\"{x:787,y:785,t:1527635728089};\\\", \\\"{x:790,y:785,t:1527635728105};\\\", \\\"{x:794,y:787,t:1527635728123};\\\", \\\"{x:795,y:787,t:1527635728317};\\\", \\\"{x:785,y:784,t:1527635728332};\\\", \\\"{x:775,y:780,t:1527635728340};\\\", \\\"{x:762,y:774,t:1527635728356};\\\", \\\"{x:757,y:771,t:1527635728373};\\\", \\\"{x:756,y:771,t:1527635728390};\\\", \\\"{x:757,y:770,t:1527635728572};\\\", \\\"{x:759,y:768,t:1527635728588};\\\", \\\"{x:760,y:767,t:1527635728604};\\\", \\\"{x:760,y:766,t:1527635728620};\\\" ] }, { \\\"rt\\\": 14739, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 405319, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"DK1EM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:760,y:765,t:1527635728723};\\\", \\\"{x:760,y:764,t:1527635728821};\\\", \\\"{x:760,y:762,t:1527635728840};\\\", \\\"{x:760,y:756,t:1527635728857};\\\", \\\"{x:760,y:751,t:1527635728873};\\\", \\\"{x:761,y:742,t:1527635728889};\\\", \\\"{x:764,y:736,t:1527635728907};\\\", \\\"{x:768,y:725,t:1527635728923};\\\", \\\"{x:775,y:705,t:1527635728939};\\\", \\\"{x:779,y:690,t:1527635728957};\\\", \\\"{x:783,y:680,t:1527635728972};\\\", \\\"{x:785,y:669,t:1527635728990};\\\", \\\"{x:787,y:662,t:1527635729007};\\\", \\\"{x:788,y:658,t:1527635729023};\\\", \\\"{x:788,y:657,t:1527635729051};\\\", \\\"{x:780,y:653,t:1527635729118};\\\", \\\"{x:779,y:652,t:1527635729128};\\\", \\\"{x:777,y:651,t:1527635729139};\\\", \\\"{x:774,y:651,t:1527635729157};\\\", \\\"{x:771,y:648,t:1527635729174};\\\", \\\"{x:767,y:648,t:1527635729190};\\\", \\\"{x:764,y:645,t:1527635729206};\\\", \\\"{x:763,y:645,t:1527635729223};\\\", \\\"{x:762,y:645,t:1527635729259};\\\", \\\"{x:759,y:643,t:1527635729324};\\\", \\\"{x:748,y:640,t:1527635729340};\\\", \\\"{x:730,y:636,t:1527635729356};\\\", \\\"{x:719,y:636,t:1527635729374};\\\", \\\"{x:708,y:635,t:1527635729389};\\\", \\\"{x:702,y:634,t:1527635729407};\\\", \\\"{x:699,y:634,t:1527635729423};\\\", \\\"{x:696,y:634,t:1527635729440};\\\", \\\"{x:694,y:634,t:1527635729457};\\\", \\\"{x:690,y:634,t:1527635729474};\\\", \\\"{x:689,y:634,t:1527635729492};\\\", \\\"{x:690,y:634,t:1527635729780};\\\", \\\"{x:692,y:634,t:1527635729791};\\\", \\\"{x:694,y:632,t:1527635729807};\\\", \\\"{x:696,y:631,t:1527635729825};\\\", \\\"{x:700,y:631,t:1527635729840};\\\", \\\"{x:706,y:631,t:1527635729858};\\\", \\\"{x:709,y:631,t:1527635729873};\\\", \\\"{x:713,y:631,t:1527635729890};\\\", \\\"{x:720,y:631,t:1527635729907};\\\", \\\"{x:721,y:631,t:1527635729924};\\\", \\\"{x:722,y:631,t:1527635730053};\\\", \\\"{x:723,y:632,t:1527635730094};\\\", \\\"{x:724,y:633,t:1527635730141};\\\", \\\"{x:727,y:635,t:1527635731581};\\\", \\\"{x:728,y:635,t:1527635731593};\\\", \\\"{x:730,y:635,t:1527635731885};\\\", \\\"{x:731,y:635,t:1527635731892};\\\", \\\"{x:732,y:635,t:1527635731909};\\\", \\\"{x:735,y:635,t:1527635731964};\\\", \\\"{x:739,y:635,t:1527635731976};\\\", \\\"{x:748,y:634,t:1527635731992};\\\", \\\"{x:755,y:633,t:1527635732009};\\\", \\\"{x:758,y:632,t:1527635732026};\\\", \\\"{x:759,y:631,t:1527635732044};\\\", \\\"{x:761,y:631,t:1527635732058};\\\", \\\"{x:762,y:631,t:1527635732083};\\\", \\\"{x:764,y:631,t:1527635732132};\\\", \\\"{x:765,y:631,t:1527635732155};\\\", \\\"{x:765,y:630,t:1527635732164};\\\", \\\"{x:767,y:630,t:1527635732176};\\\", \\\"{x:769,y:629,t:1527635732192};\\\", \\\"{x:772,y:629,t:1527635732209};\\\", \\\"{x:777,y:629,t:1527635732225};\\\", \\\"{x:787,y:628,t:1527635732242};\\\", \\\"{x:802,y:627,t:1527635732259};\\\", \\\"{x:842,y:627,t:1527635732277};\\\", \\\"{x:883,y:627,t:1527635732293};\\\", \\\"{x:925,y:627,t:1527635732308};\\\", \\\"{x:975,y:627,t:1527635732327};\\\", \\\"{x:1026,y:625,t:1527635732343};\\\", \\\"{x:1065,y:625,t:1527635732358};\\\", \\\"{x:1092,y:625,t:1527635732376};\\\", \\\"{x:1109,y:622,t:1527635732393};\\\", \\\"{x:1120,y:621,t:1527635732410};\\\", \\\"{x:1125,y:619,t:1527635732426};\\\", \\\"{x:1126,y:618,t:1527635732452};\\\", \\\"{x:1127,y:618,t:1527635732516};\\\", \\\"{x:1128,y:618,t:1527635732741};\\\", \\\"{x:1130,y:618,t:1527635733533};\\\", \\\"{x:1134,y:618,t:1527635733543};\\\", \\\"{x:1146,y:617,t:1527635733561};\\\", \\\"{x:1159,y:617,t:1527635733577};\\\", \\\"{x:1171,y:617,t:1527635733593};\\\", \\\"{x:1182,y:617,t:1527635733611};\\\", \\\"{x:1194,y:617,t:1527635733628};\\\", \\\"{x:1216,y:620,t:1527635733645};\\\", \\\"{x:1228,y:620,t:1527635733661};\\\", \\\"{x:1238,y:620,t:1527635733677};\\\", \\\"{x:1247,y:621,t:1527635733695};\\\", \\\"{x:1259,y:624,t:1527635733711};\\\", \\\"{x:1270,y:626,t:1527635733728};\\\", \\\"{x:1278,y:629,t:1527635733745};\\\", \\\"{x:1289,y:631,t:1527635733760};\\\", \\\"{x:1299,y:635,t:1527635733778};\\\", \\\"{x:1309,y:640,t:1527635733794};\\\", \\\"{x:1316,y:644,t:1527635733810};\\\", \\\"{x:1326,y:650,t:1527635733827};\\\", \\\"{x:1344,y:664,t:1527635733844};\\\", \\\"{x:1357,y:675,t:1527635733861};\\\", \\\"{x:1364,y:691,t:1527635733878};\\\", \\\"{x:1369,y:708,t:1527635733894};\\\", \\\"{x:1368,y:714,t:1527635733911};\\\", \\\"{x:1367,y:715,t:1527635733928};\\\", \\\"{x:1369,y:723,t:1527635733944};\\\", \\\"{x:1369,y:725,t:1527635733961};\\\", \\\"{x:1370,y:726,t:1527635733978};\\\", \\\"{x:1372,y:727,t:1527635734060};\\\", \\\"{x:1375,y:730,t:1527635734077};\\\", \\\"{x:1377,y:731,t:1527635734093};\\\", \\\"{x:1380,y:736,t:1527635734111};\\\", \\\"{x:1387,y:747,t:1527635734127};\\\", \\\"{x:1396,y:759,t:1527635734144};\\\", \\\"{x:1404,y:773,t:1527635734160};\\\", \\\"{x:1413,y:789,t:1527635734177};\\\", \\\"{x:1430,y:811,t:1527635734194};\\\", \\\"{x:1453,y:833,t:1527635734211};\\\", \\\"{x:1471,y:851,t:1527635734227};\\\", \\\"{x:1490,y:878,t:1527635734244};\\\", \\\"{x:1504,y:900,t:1527635734261};\\\", \\\"{x:1518,y:923,t:1527635734277};\\\", \\\"{x:1528,y:939,t:1527635734294};\\\", \\\"{x:1529,y:948,t:1527635734311};\\\", \\\"{x:1531,y:954,t:1527635734327};\\\", \\\"{x:1531,y:958,t:1527635734344};\\\", \\\"{x:1532,y:961,t:1527635734361};\\\", \\\"{x:1532,y:965,t:1527635734377};\\\", \\\"{x:1532,y:969,t:1527635734395};\\\", \\\"{x:1529,y:977,t:1527635734411};\\\", \\\"{x:1526,y:982,t:1527635734427};\\\", \\\"{x:1523,y:986,t:1527635734444};\\\", \\\"{x:1522,y:988,t:1527635734461};\\\", \\\"{x:1521,y:989,t:1527635734477};\\\", \\\"{x:1520,y:990,t:1527635734500};\\\", \\\"{x:1519,y:991,t:1527635734511};\\\", \\\"{x:1517,y:992,t:1527635734528};\\\", \\\"{x:1511,y:993,t:1527635734544};\\\", \\\"{x:1505,y:996,t:1527635734562};\\\", \\\"{x:1504,y:996,t:1527635734577};\\\", \\\"{x:1500,y:997,t:1527635734594};\\\", \\\"{x:1495,y:1000,t:1527635734611};\\\", \\\"{x:1487,y:1001,t:1527635734628};\\\", \\\"{x:1477,y:1003,t:1527635734644};\\\", \\\"{x:1466,y:1004,t:1527635734661};\\\", \\\"{x:1455,y:1004,t:1527635734679};\\\", \\\"{x:1444,y:1004,t:1527635734695};\\\", \\\"{x:1430,y:1004,t:1527635734712};\\\", \\\"{x:1416,y:1001,t:1527635734729};\\\", \\\"{x:1406,y:998,t:1527635734744};\\\", \\\"{x:1396,y:997,t:1527635734761};\\\", \\\"{x:1389,y:997,t:1527635734778};\\\", \\\"{x:1384,y:995,t:1527635734795};\\\", \\\"{x:1378,y:993,t:1527635734812};\\\", \\\"{x:1371,y:991,t:1527635734829};\\\", \\\"{x:1370,y:991,t:1527635734845};\\\", \\\"{x:1365,y:989,t:1527635734861};\\\", \\\"{x:1361,y:988,t:1527635734878};\\\", \\\"{x:1358,y:987,t:1527635734895};\\\", \\\"{x:1356,y:986,t:1527635734912};\\\", \\\"{x:1355,y:986,t:1527635734929};\\\", \\\"{x:1354,y:985,t:1527635734945};\\\", \\\"{x:1354,y:984,t:1527635734962};\\\", \\\"{x:1353,y:984,t:1527635734979};\\\", \\\"{x:1353,y:983,t:1527635735012};\\\", \\\"{x:1353,y:982,t:1527635735029};\\\", \\\"{x:1353,y:980,t:1527635735045};\\\", \\\"{x:1353,y:978,t:1527635735062};\\\", \\\"{x:1353,y:977,t:1527635735079};\\\", \\\"{x:1353,y:976,t:1527635735095};\\\", \\\"{x:1353,y:975,t:1527635735111};\\\", \\\"{x:1353,y:974,t:1527635735128};\\\", \\\"{x:1353,y:973,t:1527635735189};\\\", \\\"{x:1353,y:972,t:1527635735204};\\\", \\\"{x:1353,y:971,t:1527635735277};\\\", \\\"{x:1353,y:970,t:1527635735292};\\\", \\\"{x:1354,y:969,t:1527635735300};\\\", \\\"{x:1355,y:968,t:1527635735325};\\\", \\\"{x:1355,y:967,t:1527635735348};\\\", \\\"{x:1355,y:966,t:1527635735364};\\\", \\\"{x:1355,y:965,t:1527635735397};\\\", \\\"{x:1356,y:965,t:1527635735412};\\\", \\\"{x:1356,y:963,t:1527635735429};\\\", \\\"{x:1357,y:962,t:1527635735461};\\\", \\\"{x:1357,y:961,t:1527635735478};\\\", \\\"{x:1357,y:960,t:1527635735495};\\\", \\\"{x:1357,y:959,t:1527635735511};\\\", \\\"{x:1357,y:957,t:1527635735529};\\\", \\\"{x:1357,y:956,t:1527635735565};\\\", \\\"{x:1357,y:954,t:1527635735578};\\\", \\\"{x:1357,y:953,t:1527635735596};\\\", \\\"{x:1358,y:953,t:1527635735612};\\\", \\\"{x:1359,y:951,t:1527635735629};\\\", \\\"{x:1360,y:949,t:1527635735646};\\\", \\\"{x:1360,y:947,t:1527635735663};\\\", \\\"{x:1362,y:945,t:1527635735679};\\\", \\\"{x:1362,y:942,t:1527635735696};\\\", \\\"{x:1362,y:941,t:1527635735713};\\\", \\\"{x:1362,y:938,t:1527635735765};\\\", \\\"{x:1362,y:937,t:1527635735779};\\\", \\\"{x:1362,y:935,t:1527635735795};\\\", \\\"{x:1362,y:929,t:1527635735813};\\\", \\\"{x:1362,y:927,t:1527635735829};\\\", \\\"{x:1362,y:924,t:1527635735845};\\\", \\\"{x:1362,y:920,t:1527635735862};\\\", \\\"{x:1362,y:917,t:1527635735878};\\\", \\\"{x:1363,y:915,t:1527635735896};\\\", \\\"{x:1363,y:914,t:1527635735913};\\\", \\\"{x:1363,y:912,t:1527635735928};\\\", \\\"{x:1363,y:911,t:1527635735945};\\\", \\\"{x:1363,y:909,t:1527635735962};\\\", \\\"{x:1363,y:908,t:1527635735995};\\\", \\\"{x:1363,y:907,t:1527635736020};\\\", \\\"{x:1364,y:906,t:1527635736044};\\\", \\\"{x:1364,y:904,t:1527635736092};\\\", \\\"{x:1365,y:904,t:1527635736157};\\\", \\\"{x:1365,y:903,t:1527635736180};\\\", \\\"{x:1365,y:902,t:1527635736229};\\\", \\\"{x:1365,y:901,t:1527635736246};\\\", \\\"{x:1365,y:899,t:1527635736262};\\\", \\\"{x:1364,y:899,t:1527635736405};\\\", \\\"{x:1362,y:899,t:1527635736413};\\\", \\\"{x:1353,y:899,t:1527635736430};\\\", \\\"{x:1337,y:899,t:1527635736445};\\\", \\\"{x:1318,y:899,t:1527635736463};\\\", \\\"{x:1300,y:899,t:1527635736479};\\\", \\\"{x:1280,y:899,t:1527635736495};\\\", \\\"{x:1259,y:894,t:1527635736512};\\\", \\\"{x:1228,y:890,t:1527635736529};\\\", \\\"{x:1177,y:874,t:1527635736545};\\\", \\\"{x:1120,y:861,t:1527635736563};\\\", \\\"{x:1069,y:845,t:1527635736579};\\\", \\\"{x:1021,y:831,t:1527635736596};\\\", \\\"{x:944,y:802,t:1527635736612};\\\", \\\"{x:895,y:781,t:1527635736629};\\\", \\\"{x:842,y:758,t:1527635736646};\\\", \\\"{x:792,y:737,t:1527635736662};\\\", \\\"{x:748,y:709,t:1527635736679};\\\", \\\"{x:704,y:681,t:1527635736697};\\\", \\\"{x:679,y:660,t:1527635736713};\\\", \\\"{x:650,y:639,t:1527635736729};\\\", \\\"{x:633,y:624,t:1527635736746};\\\", \\\"{x:623,y:614,t:1527635736761};\\\", \\\"{x:617,y:608,t:1527635736776};\\\", \\\"{x:616,y:606,t:1527635736793};\\\", \\\"{x:615,y:606,t:1527635736809};\\\", \\\"{x:614,y:605,t:1527635736826};\\\", \\\"{x:613,y:603,t:1527635736843};\\\", \\\"{x:613,y:602,t:1527635736859};\\\", \\\"{x:613,y:599,t:1527635736880};\\\", \\\"{x:613,y:594,t:1527635736896};\\\", \\\"{x:613,y:591,t:1527635736914};\\\", \\\"{x:613,y:590,t:1527635736930};\\\", \\\"{x:613,y:589,t:1527635737094};\\\", \\\"{x:611,y:586,t:1527635737113};\\\", \\\"{x:609,y:584,t:1527635737130};\\\", \\\"{x:607,y:580,t:1527635737146};\\\", \\\"{x:605,y:577,t:1527635737163};\\\", \\\"{x:597,y:571,t:1527635737179};\\\", \\\"{x:581,y:562,t:1527635737198};\\\", \\\"{x:553,y:551,t:1527635737214};\\\", \\\"{x:520,y:542,t:1527635737230};\\\", \\\"{x:485,y:536,t:1527635737248};\\\", \\\"{x:440,y:524,t:1527635737263};\\\", \\\"{x:388,y:520,t:1527635737280};\\\", \\\"{x:335,y:512,t:1527635737297};\\\", \\\"{x:301,y:508,t:1527635737313};\\\", \\\"{x:267,y:506,t:1527635737330};\\\", \\\"{x:247,y:506,t:1527635737347};\\\", \\\"{x:235,y:507,t:1527635737363};\\\", \\\"{x:226,y:510,t:1527635737379};\\\", \\\"{x:223,y:512,t:1527635737396};\\\", \\\"{x:222,y:514,t:1527635737428};\\\", \\\"{x:222,y:515,t:1527635737436};\\\", \\\"{x:220,y:518,t:1527635737447};\\\", \\\"{x:220,y:527,t:1527635737463};\\\", \\\"{x:224,y:538,t:1527635737480};\\\", \\\"{x:231,y:553,t:1527635737497};\\\", \\\"{x:239,y:569,t:1527635737514};\\\", \\\"{x:249,y:580,t:1527635737530};\\\", \\\"{x:255,y:589,t:1527635737547};\\\", \\\"{x:260,y:594,t:1527635737564};\\\", \\\"{x:262,y:596,t:1527635737580};\\\", \\\"{x:263,y:598,t:1527635737597};\\\", \\\"{x:264,y:599,t:1527635737613};\\\", \\\"{x:264,y:600,t:1527635737693};\\\", \\\"{x:261,y:600,t:1527635737700};\\\", \\\"{x:259,y:600,t:1527635737714};\\\", \\\"{x:252,y:601,t:1527635737732};\\\", \\\"{x:243,y:602,t:1527635737747};\\\", \\\"{x:232,y:605,t:1527635737764};\\\", \\\"{x:229,y:605,t:1527635737780};\\\", \\\"{x:228,y:605,t:1527635737797};\\\", \\\"{x:224,y:606,t:1527635737814};\\\", \\\"{x:221,y:608,t:1527635737830};\\\", \\\"{x:217,y:609,t:1527635737847};\\\", \\\"{x:214,y:610,t:1527635737863};\\\", \\\"{x:213,y:610,t:1527635737880};\\\", \\\"{x:212,y:610,t:1527635737897};\\\", \\\"{x:214,y:610,t:1527635737956};\\\", \\\"{x:217,y:610,t:1527635737964};\\\", \\\"{x:223,y:610,t:1527635737981};\\\", \\\"{x:235,y:610,t:1527635737997};\\\", \\\"{x:246,y:608,t:1527635738014};\\\", \\\"{x:260,y:608,t:1527635738030};\\\", \\\"{x:276,y:608,t:1527635738048};\\\", \\\"{x:291,y:608,t:1527635738064};\\\", \\\"{x:313,y:608,t:1527635738080};\\\", \\\"{x:339,y:608,t:1527635738097};\\\", \\\"{x:366,y:609,t:1527635738114};\\\", \\\"{x:385,y:610,t:1527635738131};\\\", \\\"{x:399,y:612,t:1527635738147};\\\", \\\"{x:408,y:612,t:1527635738164};\\\", \\\"{x:411,y:612,t:1527635738181};\\\", \\\"{x:414,y:612,t:1527635738197};\\\", \\\"{x:418,y:612,t:1527635738215};\\\", \\\"{x:422,y:612,t:1527635738231};\\\", \\\"{x:424,y:612,t:1527635738247};\\\", \\\"{x:426,y:611,t:1527635738264};\\\", \\\"{x:426,y:610,t:1527635738300};\\\", \\\"{x:426,y:609,t:1527635738316};\\\", \\\"{x:426,y:608,t:1527635738330};\\\", \\\"{x:428,y:606,t:1527635738347};\\\", \\\"{x:428,y:600,t:1527635738365};\\\", \\\"{x:428,y:597,t:1527635738381};\\\", \\\"{x:428,y:594,t:1527635738397};\\\", \\\"{x:428,y:591,t:1527635738416};\\\", \\\"{x:428,y:587,t:1527635738431};\\\", \\\"{x:430,y:585,t:1527635738447};\\\", \\\"{x:434,y:582,t:1527635738465};\\\", \\\"{x:441,y:578,t:1527635738481};\\\", \\\"{x:457,y:574,t:1527635738497};\\\", \\\"{x:485,y:571,t:1527635738515};\\\", \\\"{x:526,y:571,t:1527635738532};\\\", \\\"{x:583,y:571,t:1527635738548};\\\", \\\"{x:611,y:571,t:1527635738564};\\\", \\\"{x:631,y:571,t:1527635738581};\\\", \\\"{x:652,y:571,t:1527635738597};\\\", \\\"{x:667,y:571,t:1527635738614};\\\", \\\"{x:674,y:571,t:1527635738630};\\\", \\\"{x:676,y:571,t:1527635738648};\\\", \\\"{x:679,y:571,t:1527635738821};\\\", \\\"{x:683,y:571,t:1527635738831};\\\", \\\"{x:704,y:574,t:1527635738849};\\\", \\\"{x:727,y:575,t:1527635738867};\\\", \\\"{x:750,y:575,t:1527635738881};\\\", \\\"{x:772,y:575,t:1527635738897};\\\", \\\"{x:792,y:575,t:1527635738915};\\\", \\\"{x:809,y:575,t:1527635738931};\\\", \\\"{x:822,y:575,t:1527635738948};\\\", \\\"{x:824,y:575,t:1527635738965};\\\", \\\"{x:825,y:575,t:1527635738981};\\\", \\\"{x:827,y:575,t:1527635739084};\\\", \\\"{x:828,y:575,t:1527635739108};\\\", \\\"{x:830,y:575,t:1527635739116};\\\", \\\"{x:831,y:577,t:1527635739132};\\\", \\\"{x:832,y:575,t:1527635739324};\\\", \\\"{x:834,y:571,t:1527635739331};\\\", \\\"{x:840,y:558,t:1527635739348};\\\", \\\"{x:846,y:542,t:1527635739366};\\\", \\\"{x:853,y:530,t:1527635739382};\\\", \\\"{x:859,y:518,t:1527635739399};\\\", \\\"{x:862,y:513,t:1527635739416};\\\", \\\"{x:862,y:508,t:1527635739432};\\\", \\\"{x:862,y:506,t:1527635739448};\\\", \\\"{x:862,y:505,t:1527635739465};\\\", \\\"{x:862,y:504,t:1527635739482};\\\", \\\"{x:862,y:503,t:1527635739498};\\\", \\\"{x:862,y:502,t:1527635739532};\\\", \\\"{x:862,y:500,t:1527635739548};\\\", \\\"{x:862,y:499,t:1527635739565};\\\", \\\"{x:862,y:497,t:1527635739582};\\\", \\\"{x:861,y:497,t:1527635739598};\\\", \\\"{x:859,y:495,t:1527635739616};\\\", \\\"{x:857,y:494,t:1527635739633};\\\", \\\"{x:855,y:494,t:1527635739649};\\\", \\\"{x:853,y:493,t:1527635739665};\\\", \\\"{x:851,y:493,t:1527635739682};\\\", \\\"{x:849,y:493,t:1527635739698};\\\", \\\"{x:846,y:493,t:1527635739716};\\\", \\\"{x:844,y:493,t:1527635739732};\\\", \\\"{x:843,y:493,t:1527635739748};\\\", \\\"{x:842,y:493,t:1527635739843};\\\", \\\"{x:842,y:493,t:1527635739912};\\\", \\\"{x:837,y:493,t:1527635739971};\\\", \\\"{x:829,y:494,t:1527635739982};\\\", \\\"{x:812,y:496,t:1527635739999};\\\", \\\"{x:787,y:500,t:1527635740015};\\\", \\\"{x:751,y:505,t:1527635740032};\\\", \\\"{x:700,y:508,t:1527635740050};\\\", \\\"{x:649,y:516,t:1527635740065};\\\", \\\"{x:593,y:524,t:1527635740082};\\\", \\\"{x:531,y:534,t:1527635740099};\\\", \\\"{x:485,y:543,t:1527635740117};\\\", \\\"{x:441,y:557,t:1527635740133};\\\", \\\"{x:415,y:565,t:1527635740150};\\\", \\\"{x:393,y:574,t:1527635740165};\\\", \\\"{x:367,y:585,t:1527635740182};\\\", \\\"{x:344,y:594,t:1527635740199};\\\", \\\"{x:324,y:599,t:1527635740215};\\\", \\\"{x:308,y:602,t:1527635740232};\\\", \\\"{x:294,y:603,t:1527635740249};\\\", \\\"{x:279,y:603,t:1527635740265};\\\", \\\"{x:264,y:603,t:1527635740282};\\\", \\\"{x:248,y:603,t:1527635740299};\\\", \\\"{x:229,y:600,t:1527635740316};\\\", \\\"{x:213,y:596,t:1527635740332};\\\", \\\"{x:202,y:595,t:1527635740350};\\\", \\\"{x:196,y:594,t:1527635740366};\\\", \\\"{x:195,y:593,t:1527635740383};\\\", \\\"{x:192,y:592,t:1527635740400};\\\", \\\"{x:190,y:592,t:1527635740416};\\\", \\\"{x:186,y:591,t:1527635740432};\\\", \\\"{x:184,y:589,t:1527635740449};\\\", \\\"{x:179,y:589,t:1527635740466};\\\", \\\"{x:176,y:589,t:1527635740482};\\\", \\\"{x:174,y:589,t:1527635740499};\\\", \\\"{x:172,y:589,t:1527635740516};\\\", \\\"{x:169,y:589,t:1527635740533};\\\", \\\"{x:168,y:588,t:1527635740549};\\\", \\\"{x:165,y:586,t:1527635740566};\\\", \\\"{x:160,y:581,t:1527635740582};\\\", \\\"{x:151,y:572,t:1527635740599};\\\", \\\"{x:145,y:566,t:1527635740616};\\\", \\\"{x:142,y:561,t:1527635740633};\\\", \\\"{x:139,y:558,t:1527635740649};\\\", \\\"{x:137,y:556,t:1527635740666};\\\", \\\"{x:136,y:555,t:1527635740684};\\\", \\\"{x:136,y:553,t:1527635740780};\\\", \\\"{x:136,y:552,t:1527635740821};\\\", \\\"{x:136,y:551,t:1527635740845};\\\", \\\"{x:137,y:550,t:1527635740852};\\\", \\\"{x:138,y:550,t:1527635740866};\\\", \\\"{x:142,y:547,t:1527635740884};\\\", \\\"{x:144,y:545,t:1527635740899};\\\", \\\"{x:146,y:545,t:1527635741260};\\\", \\\"{x:148,y:545,t:1527635741267};\\\", \\\"{x:163,y:546,t:1527635741284};\\\", \\\"{x:191,y:555,t:1527635741300};\\\", \\\"{x:231,y:569,t:1527635741316};\\\", \\\"{x:276,y:589,t:1527635741334};\\\", \\\"{x:326,y:612,t:1527635741351};\\\", \\\"{x:363,y:630,t:1527635741366};\\\", \\\"{x:384,y:646,t:1527635741383};\\\", \\\"{x:403,y:658,t:1527635741401};\\\", \\\"{x:420,y:667,t:1527635741416};\\\", \\\"{x:425,y:668,t:1527635741433};\\\", \\\"{x:430,y:671,t:1527635741451};\\\", \\\"{x:435,y:676,t:1527635741466};\\\", \\\"{x:442,y:680,t:1527635741483};\\\", \\\"{x:438,y:679,t:1527635741547};\\\", \\\"{x:428,y:676,t:1527635741555};\\\", \\\"{x:417,y:670,t:1527635741566};\\\", \\\"{x:382,y:650,t:1527635741583};\\\", \\\"{x:343,y:622,t:1527635741600};\\\", \\\"{x:307,y:599,t:1527635741616};\\\", \\\"{x:269,y:579,t:1527635741633};\\\", \\\"{x:243,y:566,t:1527635741650};\\\", \\\"{x:223,y:555,t:1527635741667};\\\", \\\"{x:209,y:546,t:1527635741683};\\\", \\\"{x:205,y:544,t:1527635741700};\\\", \\\"{x:203,y:542,t:1527635741717};\\\", \\\"{x:200,y:540,t:1527635741734};\\\", \\\"{x:195,y:538,t:1527635741749};\\\", \\\"{x:192,y:537,t:1527635741767};\\\", \\\"{x:188,y:535,t:1527635741784};\\\", \\\"{x:185,y:534,t:1527635741801};\\\", \\\"{x:183,y:533,t:1527635741816};\\\", \\\"{x:182,y:533,t:1527635741833};\\\", \\\"{x:180,y:532,t:1527635741850};\\\", \\\"{x:177,y:531,t:1527635741866};\\\", \\\"{x:171,y:531,t:1527635741883};\\\", \\\"{x:167,y:531,t:1527635741899};\\\", \\\"{x:162,y:531,t:1527635741916};\\\", \\\"{x:158,y:529,t:1527635741933};\\\", \\\"{x:152,y:528,t:1527635741950};\\\", \\\"{x:150,y:528,t:1527635741966};\\\", \\\"{x:149,y:528,t:1527635741983};\\\", \\\"{x:147,y:528,t:1527635742000};\\\", \\\"{x:148,y:529,t:1527635742548};\\\", \\\"{x:149,y:529,t:1527635742557};\\\", \\\"{x:152,y:530,t:1527635742567};\\\", \\\"{x:153,y:532,t:1527635742584};\\\", \\\"{x:154,y:532,t:1527635742600};\\\", \\\"{x:155,y:532,t:1527635742844};\\\", \\\"{x:159,y:538,t:1527635742851};\\\", \\\"{x:167,y:543,t:1527635742867};\\\", \\\"{x:192,y:557,t:1527635742884};\\\", \\\"{x:203,y:564,t:1527635742901};\\\", \\\"{x:209,y:567,t:1527635742917};\\\", \\\"{x:209,y:568,t:1527635743005};\\\", \\\"{x:210,y:568,t:1527635743018};\\\", \\\"{x:214,y:568,t:1527635743034};\\\", \\\"{x:243,y:583,t:1527635743052};\\\", \\\"{x:283,y:605,t:1527635743069};\\\", \\\"{x:337,y:638,t:1527635743085};\\\", \\\"{x:403,y:674,t:1527635743102};\\\", \\\"{x:451,y:700,t:1527635743118};\\\", \\\"{x:482,y:715,t:1527635743134};\\\", \\\"{x:504,y:726,t:1527635743152};\\\", \\\"{x:514,y:729,t:1527635743169};\\\", \\\"{x:516,y:730,t:1527635743184};\\\", \\\"{x:517,y:731,t:1527635743700};\\\", \\\"{x:518,y:731,t:1527635743716};\\\", \\\"{x:521,y:733,t:1527635743724};\\\", \\\"{x:522,y:734,t:1527635743736};\\\", \\\"{x:525,y:734,t:1527635743751};\\\", \\\"{x:527,y:734,t:1527635743769};\\\", \\\"{x:528,y:734,t:1527635743804};\\\", \\\"{x:529,y:736,t:1527635744061};\\\", \\\"{x:530,y:736,t:1527635744068};\\\", \\\"{x:533,y:736,t:1527635744086};\\\", \\\"{x:545,y:734,t:1527635744102};\\\", \\\"{x:561,y:730,t:1527635744118};\\\", \\\"{x:587,y:728,t:1527635744135};\\\", \\\"{x:618,y:722,t:1527635744153};\\\", \\\"{x:664,y:715,t:1527635744168};\\\", \\\"{x:716,y:709,t:1527635744185};\\\", \\\"{x:775,y:699,t:1527635744203};\\\", \\\"{x:855,y:690,t:1527635744219};\\\", \\\"{x:973,y:675,t:1527635744236};\\\", \\\"{x:1048,y:664,t:1527635744252};\\\", \\\"{x:1128,y:655,t:1527635744269};\\\", \\\"{x:1190,y:647,t:1527635744285};\\\", \\\"{x:1240,y:640,t:1527635744303};\\\", \\\"{x:1268,y:639,t:1527635744319};\\\", \\\"{x:1282,y:636,t:1527635744335};\\\", \\\"{x:1284,y:636,t:1527635744352};\\\" ] }, { \\\"rt\\\": 11125, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 417688, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"DK1EM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1281,y:632,t:1527635745909};\\\", \\\"{x:1277,y:632,t:1527635745921};\\\", \\\"{x:1258,y:632,t:1527635745942};\\\", \\\"{x:1248,y:632,t:1527635745954};\\\", \\\"{x:1235,y:632,t:1527635745970};\\\", \\\"{x:1226,y:632,t:1527635745986};\\\", \\\"{x:1211,y:631,t:1527635746004};\\\", \\\"{x:1192,y:627,t:1527635746020};\\\", \\\"{x:1167,y:627,t:1527635746036};\\\", \\\"{x:1134,y:624,t:1527635746053};\\\", \\\"{x:1105,y:619,t:1527635746070};\\\", \\\"{x:1081,y:610,t:1527635746086};\\\", \\\"{x:1057,y:603,t:1527635746103};\\\", \\\"{x:1031,y:599,t:1527635746121};\\\", \\\"{x:1009,y:596,t:1527635746136};\\\", \\\"{x:986,y:592,t:1527635746153};\\\", \\\"{x:964,y:590,t:1527635746170};\\\", \\\"{x:935,y:586,t:1527635746188};\\\", \\\"{x:917,y:586,t:1527635746203};\\\", \\\"{x:905,y:586,t:1527635746220};\\\", \\\"{x:897,y:586,t:1527635746238};\\\", \\\"{x:894,y:586,t:1527635746254};\\\", \\\"{x:893,y:586,t:1527635746340};\\\", \\\"{x:892,y:586,t:1527635746355};\\\", \\\"{x:891,y:586,t:1527635746380};\\\", \\\"{x:888,y:586,t:1527635746396};\\\", \\\"{x:887,y:586,t:1527635746404};\\\", \\\"{x:880,y:586,t:1527635746420};\\\", \\\"{x:879,y:585,t:1527635746438};\\\", \\\"{x:879,y:584,t:1527635746484};\\\", \\\"{x:879,y:583,t:1527635746500};\\\", \\\"{x:879,y:582,t:1527635746548};\\\", \\\"{x:879,y:581,t:1527635747485};\\\", \\\"{x:879,y:580,t:1527635747525};\\\", \\\"{x:879,y:579,t:1527635747548};\\\", \\\"{x:879,y:577,t:1527635748069};\\\", \\\"{x:881,y:576,t:1527635748076};\\\", \\\"{x:881,y:574,t:1527635748090};\\\", \\\"{x:882,y:574,t:1527635749244};\\\", \\\"{x:888,y:574,t:1527635751164};\\\", \\\"{x:910,y:577,t:1527635751177};\\\", \\\"{x:995,y:584,t:1527635751193};\\\", \\\"{x:1106,y:603,t:1527635751210};\\\", \\\"{x:1236,y:617,t:1527635751226};\\\", \\\"{x:1361,y:636,t:1527635751240};\\\", \\\"{x:1447,y:649,t:1527635751257};\\\", \\\"{x:1490,y:664,t:1527635751275};\\\", \\\"{x:1510,y:669,t:1527635751291};\\\", \\\"{x:1511,y:670,t:1527635751307};\\\", \\\"{x:1511,y:671,t:1527635751436};\\\", \\\"{x:1510,y:674,t:1527635751444};\\\", \\\"{x:1508,y:675,t:1527635751458};\\\", \\\"{x:1500,y:679,t:1527635751475};\\\", \\\"{x:1481,y:685,t:1527635751492};\\\", \\\"{x:1463,y:690,t:1527635751508};\\\", \\\"{x:1438,y:695,t:1527635751525};\\\", \\\"{x:1409,y:697,t:1527635751542};\\\", \\\"{x:1382,y:702,t:1527635751559};\\\", \\\"{x:1356,y:704,t:1527635751575};\\\", \\\"{x:1343,y:707,t:1527635751592};\\\", \\\"{x:1338,y:708,t:1527635751608};\\\", \\\"{x:1339,y:710,t:1527635751973};\\\", \\\"{x:1339,y:716,t:1527635751980};\\\", \\\"{x:1339,y:724,t:1527635751992};\\\", \\\"{x:1339,y:735,t:1527635752009};\\\", \\\"{x:1339,y:749,t:1527635752025};\\\", \\\"{x:1339,y:762,t:1527635752042};\\\", \\\"{x:1339,y:771,t:1527635752059};\\\", \\\"{x:1342,y:779,t:1527635752076};\\\", \\\"{x:1342,y:784,t:1527635752092};\\\", \\\"{x:1343,y:787,t:1527635752109};\\\", \\\"{x:1344,y:790,t:1527635752126};\\\", \\\"{x:1344,y:791,t:1527635752188};\\\", \\\"{x:1341,y:791,t:1527635752669};\\\", \\\"{x:1335,y:791,t:1527635752676};\\\", \\\"{x:1313,y:791,t:1527635752692};\\\", \\\"{x:1278,y:791,t:1527635752709};\\\", \\\"{x:1228,y:791,t:1527635752726};\\\", \\\"{x:1172,y:791,t:1527635752742};\\\", \\\"{x:1124,y:791,t:1527635752759};\\\", \\\"{x:1074,y:791,t:1527635752777};\\\", \\\"{x:1037,y:791,t:1527635752793};\\\", \\\"{x:1005,y:790,t:1527635752809};\\\", \\\"{x:974,y:786,t:1527635752826};\\\", \\\"{x:940,y:781,t:1527635752843};\\\", \\\"{x:911,y:776,t:1527635752859};\\\", \\\"{x:876,y:770,t:1527635752876};\\\", \\\"{x:859,y:764,t:1527635752893};\\\", \\\"{x:841,y:759,t:1527635752909};\\\", \\\"{x:824,y:753,t:1527635752926};\\\", \\\"{x:807,y:748,t:1527635752943};\\\", \\\"{x:792,y:742,t:1527635752959};\\\", \\\"{x:781,y:737,t:1527635752976};\\\", \\\"{x:777,y:731,t:1527635752993};\\\", \\\"{x:770,y:727,t:1527635753008};\\\", \\\"{x:769,y:727,t:1527635753026};\\\", \\\"{x:768,y:726,t:1527635753052};\\\", \\\"{x:766,y:724,t:1527635753060};\\\", \\\"{x:758,y:714,t:1527635753076};\\\", \\\"{x:752,y:708,t:1527635753093};\\\", \\\"{x:739,y:701,t:1527635753108};\\\", \\\"{x:726,y:692,t:1527635753125};\\\", \\\"{x:706,y:686,t:1527635753143};\\\", \\\"{x:683,y:674,t:1527635753158};\\\", \\\"{x:658,y:663,t:1527635753176};\\\", \\\"{x:636,y:654,t:1527635753193};\\\", \\\"{x:614,y:645,t:1527635753209};\\\", \\\"{x:590,y:639,t:1527635753225};\\\", \\\"{x:572,y:632,t:1527635753242};\\\", \\\"{x:555,y:627,t:1527635753260};\\\", \\\"{x:549,y:625,t:1527635753276};\\\", \\\"{x:509,y:606,t:1527635753323};\\\", \\\"{x:496,y:602,t:1527635753332};\\\", \\\"{x:486,y:600,t:1527635753343};\\\", \\\"{x:470,y:593,t:1527635753360};\\\", \\\"{x:457,y:589,t:1527635753376};\\\", \\\"{x:446,y:586,t:1527635753392};\\\", \\\"{x:442,y:586,t:1527635753409};\\\", \\\"{x:438,y:585,t:1527635753426};\\\", \\\"{x:430,y:582,t:1527635753443};\\\", \\\"{x:411,y:582,t:1527635753460};\\\", \\\"{x:399,y:581,t:1527635753477};\\\", \\\"{x:397,y:581,t:1527635753493};\\\", \\\"{x:397,y:579,t:1527635753715};\\\", \\\"{x:396,y:577,t:1527635753731};\\\", \\\"{x:393,y:574,t:1527635753743};\\\", \\\"{x:389,y:573,t:1527635753759};\\\", \\\"{x:375,y:572,t:1527635753776};\\\", \\\"{x:351,y:569,t:1527635753793};\\\", \\\"{x:316,y:568,t:1527635753810};\\\", \\\"{x:268,y:568,t:1527635753828};\\\", \\\"{x:206,y:568,t:1527635753843};\\\", \\\"{x:175,y:566,t:1527635753859};\\\", \\\"{x:155,y:566,t:1527635753877};\\\", \\\"{x:138,y:566,t:1527635753894};\\\", \\\"{x:131,y:566,t:1527635753913};\\\", \\\"{x:116,y:566,t:1527635753965};\\\", \\\"{x:116,y:565,t:1527635754019};\\\", \\\"{x:116,y:564,t:1527635754026};\\\", \\\"{x:115,y:563,t:1527635754043};\\\", \\\"{x:115,y:558,t:1527635754060};\\\", \\\"{x:116,y:554,t:1527635754077};\\\", \\\"{x:122,y:549,t:1527635754093};\\\", \\\"{x:126,y:548,t:1527635754110};\\\", \\\"{x:127,y:546,t:1527635754127};\\\", \\\"{x:129,y:545,t:1527635754144};\\\", \\\"{x:130,y:544,t:1527635754160};\\\", \\\"{x:131,y:543,t:1527635754180};\\\", \\\"{x:132,y:543,t:1527635754260};\\\", \\\"{x:134,y:543,t:1527635754277};\\\", \\\"{x:135,y:542,t:1527635754300};\\\", \\\"{x:137,y:542,t:1527635754444};\\\", \\\"{x:137,y:542,t:1527635754500};\\\", \\\"{x:140,y:542,t:1527635754676};\\\", \\\"{x:141,y:542,t:1527635754684};\\\", \\\"{x:143,y:542,t:1527635754694};\\\", \\\"{x:145,y:542,t:1527635754710};\\\", \\\"{x:147,y:542,t:1527635754788};\\\", \\\"{x:148,y:542,t:1527635754820};\\\", \\\"{x:150,y:542,t:1527635754836};\\\", \\\"{x:152,y:542,t:1527635754844};\\\", \\\"{x:153,y:542,t:1527635754860};\\\", \\\"{x:158,y:542,t:1527635755099};\\\", \\\"{x:164,y:542,t:1527635755111};\\\", \\\"{x:180,y:552,t:1527635755128};\\\", \\\"{x:218,y:573,t:1527635755146};\\\", \\\"{x:259,y:596,t:1527635755161};\\\", \\\"{x:296,y:616,t:1527635755178};\\\", \\\"{x:321,y:629,t:1527635755195};\\\", \\\"{x:342,y:638,t:1527635755211};\\\", \\\"{x:367,y:650,t:1527635755228};\\\", \\\"{x:380,y:657,t:1527635755245};\\\", \\\"{x:393,y:667,t:1527635755261};\\\", \\\"{x:404,y:677,t:1527635755279};\\\", \\\"{x:422,y:687,t:1527635755294};\\\", \\\"{x:432,y:692,t:1527635755311};\\\", \\\"{x:442,y:698,t:1527635755328};\\\", \\\"{x:448,y:703,t:1527635755345};\\\", \\\"{x:453,y:709,t:1527635755361};\\\", \\\"{x:455,y:712,t:1527635755377};\\\", \\\"{x:461,y:717,t:1527635755394};\\\", \\\"{x:465,y:718,t:1527635755411};\\\", \\\"{x:467,y:720,t:1527635755429};\\\", \\\"{x:468,y:721,t:1527635755444};\\\", \\\"{x:469,y:722,t:1527635755461};\\\", \\\"{x:470,y:722,t:1527635755491};\\\", \\\"{x:470,y:723,t:1527635755516};\\\", \\\"{x:469,y:723,t:1527635755532};\\\", \\\"{x:470,y:723,t:1527635756915};\\\", \\\"{x:471,y:723,t:1527635756929};\\\", \\\"{x:476,y:720,t:1527635756945};\\\", \\\"{x:477,y:719,t:1527635756971};\\\" ] }, { \\\"rt\\\": 20881, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 439829, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"DK1EM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -04 PM-04 PM-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:491,y:714,t:1527635757088};\\\", \\\"{x:492,y:714,t:1527635757213};\\\", \\\"{x:494,y:714,t:1527635757251};\\\", \\\"{x:495,y:713,t:1527635757267};\\\", \\\"{x:496,y:713,t:1527635757323};\\\", \\\"{x:496,y:712,t:1527635757411};\\\", \\\"{x:496,y:711,t:1527635757427};\\\", \\\"{x:497,y:711,t:1527635757434};\\\", \\\"{x:497,y:710,t:1527635757445};\\\", \\\"{x:498,y:710,t:1527635757462};\\\", \\\"{x:502,y:710,t:1527635757550};\\\", \\\"{x:503,y:710,t:1527635757561};\\\", \\\"{x:504,y:710,t:1527635757577};\\\", \\\"{x:505,y:710,t:1527635757729};\\\", \\\"{x:507,y:709,t:1527635757753};\\\", \\\"{x:507,y:707,t:1527635757769};\\\", \\\"{x:507,y:705,t:1527635757801};\\\", \\\"{x:507,y:704,t:1527635757825};\\\", \\\"{x:508,y:702,t:1527635758810};\\\", \\\"{x:510,y:702,t:1527635758834};\\\", \\\"{x:511,y:702,t:1527635758845};\\\", \\\"{x:517,y:700,t:1527635758862};\\\", \\\"{x:518,y:700,t:1527635758879};\\\", \\\"{x:521,y:699,t:1527635758897};\\\", \\\"{x:525,y:696,t:1527635758912};\\\", \\\"{x:526,y:696,t:1527635758929};\\\", \\\"{x:529,y:696,t:1527635758945};\\\", \\\"{x:538,y:696,t:1527635758962};\\\", \\\"{x:546,y:693,t:1527635758979};\\\", \\\"{x:553,y:691,t:1527635758995};\\\", \\\"{x:562,y:689,t:1527635759012};\\\", \\\"{x:568,y:689,t:1527635759029};\\\", \\\"{x:574,y:689,t:1527635759045};\\\", \\\"{x:582,y:688,t:1527635759062};\\\", \\\"{x:594,y:685,t:1527635759080};\\\", \\\"{x:604,y:684,t:1527635759096};\\\", \\\"{x:613,y:683,t:1527635759112};\\\", \\\"{x:633,y:682,t:1527635759129};\\\", \\\"{x:642,y:680,t:1527635759146};\\\", \\\"{x:650,y:680,t:1527635759162};\\\", \\\"{x:654,y:679,t:1527635759179};\\\", \\\"{x:660,y:678,t:1527635759195};\\\", \\\"{x:666,y:678,t:1527635759212};\\\", \\\"{x:670,y:678,t:1527635759229};\\\", \\\"{x:675,y:678,t:1527635759246};\\\", \\\"{x:678,y:677,t:1527635759261};\\\", \\\"{x:682,y:677,t:1527635759279};\\\", \\\"{x:684,y:676,t:1527635759296};\\\", \\\"{x:690,y:676,t:1527635759312};\\\", \\\"{x:695,y:676,t:1527635759329};\\\", \\\"{x:706,y:676,t:1527635759345};\\\", \\\"{x:711,y:676,t:1527635759362};\\\", \\\"{x:714,y:676,t:1527635759379};\\\", \\\"{x:717,y:676,t:1527635759396};\\\", \\\"{x:719,y:676,t:1527635759412};\\\", \\\"{x:722,y:676,t:1527635759429};\\\", \\\"{x:723,y:676,t:1527635759446};\\\", \\\"{x:724,y:676,t:1527635759482};\\\", \\\"{x:725,y:676,t:1527635759530};\\\", \\\"{x:726,y:676,t:1527635759554};\\\", \\\"{x:728,y:675,t:1527635759610};\\\", \\\"{x:729,y:675,t:1527635759682};\\\", \\\"{x:730,y:675,t:1527635759706};\\\", \\\"{x:731,y:675,t:1527635759721};\\\", \\\"{x:732,y:675,t:1527635759754};\\\", \\\"{x:733,y:675,t:1527635760546};\\\", \\\"{x:735,y:675,t:1527635760563};\\\", \\\"{x:736,y:677,t:1527635760580};\\\", \\\"{x:737,y:678,t:1527635760597};\\\", \\\"{x:738,y:680,t:1527635760613};\\\", \\\"{x:738,y:681,t:1527635760634};\\\", \\\"{x:738,y:682,t:1527635760646};\\\", \\\"{x:738,y:683,t:1527635760690};\\\", \\\"{x:739,y:683,t:1527635761315};\\\", \\\"{x:743,y:683,t:1527635761330};\\\", \\\"{x:746,y:682,t:1527635761346};\\\", \\\"{x:752,y:681,t:1527635761364};\\\", \\\"{x:757,y:681,t:1527635761380};\\\", \\\"{x:760,y:679,t:1527635761397};\\\", \\\"{x:764,y:678,t:1527635761413};\\\", \\\"{x:766,y:678,t:1527635761430};\\\", \\\"{x:769,y:678,t:1527635761447};\\\", \\\"{x:772,y:678,t:1527635761464};\\\", \\\"{x:779,y:677,t:1527635761480};\\\", \\\"{x:783,y:677,t:1527635761497};\\\", \\\"{x:786,y:675,t:1527635761514};\\\", \\\"{x:788,y:675,t:1527635761537};\\\", \\\"{x:789,y:674,t:1527635761561};\\\", \\\"{x:792,y:673,t:1527635761618};\\\", \\\"{x:793,y:671,t:1527635761630};\\\", \\\"{x:794,y:668,t:1527635761648};\\\", \\\"{x:794,y:667,t:1527635761664};\\\", \\\"{x:794,y:665,t:1527635761680};\\\", \\\"{x:795,y:665,t:1527635762161};\\\", \\\"{x:796,y:665,t:1527635762193};\\\", \\\"{x:798,y:665,t:1527635762209};\\\", \\\"{x:799,y:664,t:1527635762217};\\\", \\\"{x:800,y:664,t:1527635762234};\\\", \\\"{x:802,y:663,t:1527635762248};\\\", \\\"{x:807,y:662,t:1527635762264};\\\", \\\"{x:815,y:661,t:1527635762281};\\\", \\\"{x:835,y:660,t:1527635762297};\\\", \\\"{x:850,y:660,t:1527635762314};\\\", \\\"{x:869,y:660,t:1527635762331};\\\", \\\"{x:891,y:660,t:1527635762348};\\\", \\\"{x:914,y:660,t:1527635762364};\\\", \\\"{x:943,y:660,t:1527635762380};\\\", \\\"{x:972,y:660,t:1527635762398};\\\", \\\"{x:1011,y:660,t:1527635762415};\\\", \\\"{x:1055,y:660,t:1527635762431};\\\", \\\"{x:1108,y:660,t:1527635762448};\\\", \\\"{x:1156,y:660,t:1527635762464};\\\", \\\"{x:1212,y:660,t:1527635762481};\\\", \\\"{x:1249,y:660,t:1527635762498};\\\", \\\"{x:1279,y:660,t:1527635762514};\\\", \\\"{x:1306,y:660,t:1527635762532};\\\", \\\"{x:1333,y:660,t:1527635762548};\\\", \\\"{x:1351,y:660,t:1527635762564};\\\", \\\"{x:1373,y:660,t:1527635762582};\\\", \\\"{x:1392,y:660,t:1527635762599};\\\", \\\"{x:1408,y:660,t:1527635762615};\\\", \\\"{x:1421,y:660,t:1527635762631};\\\", \\\"{x:1434,y:662,t:1527635762648};\\\", \\\"{x:1453,y:662,t:1527635762666};\\\", \\\"{x:1461,y:663,t:1527635762682};\\\", \\\"{x:1464,y:663,t:1527635762699};\\\", \\\"{x:1465,y:663,t:1527635762715};\\\", \\\"{x:1467,y:663,t:1527635762732};\\\", \\\"{x:1467,y:664,t:1527635762770};\\\", \\\"{x:1467,y:665,t:1527635762786};\\\", \\\"{x:1468,y:666,t:1527635762798};\\\", \\\"{x:1469,y:669,t:1527635762815};\\\", \\\"{x:1469,y:671,t:1527635762831};\\\", \\\"{x:1471,y:676,t:1527635762848};\\\", \\\"{x:1472,y:682,t:1527635762866};\\\", \\\"{x:1472,y:686,t:1527635762882};\\\", \\\"{x:1473,y:690,t:1527635762898};\\\", \\\"{x:1475,y:696,t:1527635762915};\\\", \\\"{x:1475,y:702,t:1527635762930};\\\", \\\"{x:1479,y:711,t:1527635762948};\\\", \\\"{x:1482,y:721,t:1527635762965};\\\", \\\"{x:1485,y:730,t:1527635762981};\\\", \\\"{x:1489,y:742,t:1527635762998};\\\", \\\"{x:1490,y:751,t:1527635763014};\\\", \\\"{x:1491,y:757,t:1527635763031};\\\", \\\"{x:1492,y:762,t:1527635763048};\\\", \\\"{x:1495,y:769,t:1527635763065};\\\", \\\"{x:1500,y:776,t:1527635763081};\\\", \\\"{x:1502,y:779,t:1527635763098};\\\", \\\"{x:1502,y:781,t:1527635763114};\\\", \\\"{x:1503,y:783,t:1527635763132};\\\", \\\"{x:1503,y:785,t:1527635763148};\\\", \\\"{x:1503,y:786,t:1527635763177};\\\", \\\"{x:1504,y:787,t:1527635763218};\\\", \\\"{x:1505,y:787,t:1527635763233};\\\", \\\"{x:1507,y:786,t:1527635763537};\\\", \\\"{x:1511,y:785,t:1527635763548};\\\", \\\"{x:1521,y:782,t:1527635763565};\\\", \\\"{x:1530,y:780,t:1527635763582};\\\", \\\"{x:1541,y:775,t:1527635763598};\\\", \\\"{x:1550,y:771,t:1527635763615};\\\", \\\"{x:1559,y:765,t:1527635763632};\\\", \\\"{x:1572,y:755,t:1527635763649};\\\", \\\"{x:1583,y:747,t:1527635763665};\\\", \\\"{x:1593,y:742,t:1527635763682};\\\", \\\"{x:1603,y:737,t:1527635763699};\\\", \\\"{x:1608,y:733,t:1527635763715};\\\", \\\"{x:1612,y:730,t:1527635763732};\\\", \\\"{x:1612,y:727,t:1527635763749};\\\", \\\"{x:1612,y:726,t:1527635763766};\\\", \\\"{x:1613,y:724,t:1527635763786};\\\", \\\"{x:1613,y:723,t:1527635763799};\\\", \\\"{x:1613,y:720,t:1527635763815};\\\", \\\"{x:1614,y:716,t:1527635763832};\\\", \\\"{x:1614,y:714,t:1527635763849};\\\", \\\"{x:1615,y:713,t:1527635763865};\\\", \\\"{x:1615,y:711,t:1527635763882};\\\", \\\"{x:1615,y:710,t:1527635763954};\\\", \\\"{x:1615,y:708,t:1527635763994};\\\", \\\"{x:1615,y:707,t:1527635764010};\\\", \\\"{x:1615,y:706,t:1527635764026};\\\", \\\"{x:1615,y:705,t:1527635764034};\\\", \\\"{x:1615,y:704,t:1527635764114};\\\", \\\"{x:1615,y:703,t:1527635764122};\\\", \\\"{x:1615,y:702,t:1527635764149};\\\", \\\"{x:1615,y:701,t:1527635764182};\\\", \\\"{x:1615,y:700,t:1527635764209};\\\", \\\"{x:1615,y:699,t:1527635764226};\\\", \\\"{x:1615,y:702,t:1527635764938};\\\", \\\"{x:1615,y:704,t:1527635764951};\\\", \\\"{x:1614,y:708,t:1527635764967};\\\", \\\"{x:1614,y:711,t:1527635764983};\\\", \\\"{x:1614,y:713,t:1527635765000};\\\", \\\"{x:1613,y:716,t:1527635765016};\\\", \\\"{x:1612,y:720,t:1527635765034};\\\", \\\"{x:1612,y:722,t:1527635765050};\\\", \\\"{x:1612,y:726,t:1527635765067};\\\", \\\"{x:1612,y:729,t:1527635765083};\\\", \\\"{x:1612,y:732,t:1527635765100};\\\", \\\"{x:1612,y:735,t:1527635765117};\\\", \\\"{x:1612,y:740,t:1527635765133};\\\", \\\"{x:1612,y:742,t:1527635765151};\\\", \\\"{x:1612,y:745,t:1527635765166};\\\", \\\"{x:1612,y:747,t:1527635765184};\\\", \\\"{x:1612,y:749,t:1527635765201};\\\", \\\"{x:1612,y:751,t:1527635765216};\\\", \\\"{x:1612,y:754,t:1527635765233};\\\", \\\"{x:1612,y:756,t:1527635765251};\\\", \\\"{x:1612,y:759,t:1527635765266};\\\", \\\"{x:1612,y:762,t:1527635765283};\\\", \\\"{x:1612,y:764,t:1527635765300};\\\", \\\"{x:1612,y:766,t:1527635765317};\\\", \\\"{x:1612,y:768,t:1527635765334};\\\", \\\"{x:1613,y:770,t:1527635765350};\\\", \\\"{x:1613,y:771,t:1527635765366};\\\", \\\"{x:1613,y:774,t:1527635765384};\\\", \\\"{x:1613,y:776,t:1527635765400};\\\", \\\"{x:1613,y:778,t:1527635765416};\\\", \\\"{x:1614,y:780,t:1527635765434};\\\", \\\"{x:1614,y:781,t:1527635765451};\\\", \\\"{x:1614,y:783,t:1527635765466};\\\", \\\"{x:1614,y:786,t:1527635765484};\\\", \\\"{x:1614,y:788,t:1527635765501};\\\", \\\"{x:1614,y:790,t:1527635765518};\\\", \\\"{x:1614,y:792,t:1527635765534};\\\", \\\"{x:1614,y:794,t:1527635765551};\\\", \\\"{x:1614,y:795,t:1527635765567};\\\", \\\"{x:1614,y:799,t:1527635765584};\\\", \\\"{x:1614,y:801,t:1527635765600};\\\", \\\"{x:1614,y:806,t:1527635765618};\\\", \\\"{x:1614,y:810,t:1527635765634};\\\", \\\"{x:1614,y:813,t:1527635765651};\\\", \\\"{x:1614,y:818,t:1527635765668};\\\", \\\"{x:1614,y:825,t:1527635765684};\\\", \\\"{x:1614,y:829,t:1527635765701};\\\", \\\"{x:1614,y:833,t:1527635765718};\\\", \\\"{x:1614,y:837,t:1527635765734};\\\", \\\"{x:1614,y:842,t:1527635765750};\\\", \\\"{x:1614,y:848,t:1527635765768};\\\", \\\"{x:1610,y:860,t:1527635765784};\\\", \\\"{x:1610,y:870,t:1527635765800};\\\", \\\"{x:1606,y:887,t:1527635765818};\\\", \\\"{x:1604,y:894,t:1527635765834};\\\", \\\"{x:1602,y:900,t:1527635765851};\\\", \\\"{x:1601,y:907,t:1527635765868};\\\", \\\"{x:1600,y:913,t:1527635765884};\\\", \\\"{x:1598,y:919,t:1527635765900};\\\", \\\"{x:1597,y:925,t:1527635765917};\\\", \\\"{x:1595,y:932,t:1527635765934};\\\", \\\"{x:1594,y:937,t:1527635765950};\\\", \\\"{x:1592,y:941,t:1527635765967};\\\", \\\"{x:1592,y:944,t:1527635765984};\\\", \\\"{x:1592,y:948,t:1527635765999};\\\", \\\"{x:1591,y:955,t:1527635766016};\\\", \\\"{x:1591,y:958,t:1527635766034};\\\", \\\"{x:1591,y:962,t:1527635766050};\\\", \\\"{x:1591,y:964,t:1527635766067};\\\", \\\"{x:1591,y:966,t:1527635766084};\\\", \\\"{x:1592,y:969,t:1527635766100};\\\", \\\"{x:1593,y:970,t:1527635766117};\\\", \\\"{x:1593,y:972,t:1527635766134};\\\", \\\"{x:1594,y:975,t:1527635766150};\\\", \\\"{x:1596,y:978,t:1527635766168};\\\", \\\"{x:1596,y:979,t:1527635766184};\\\", \\\"{x:1598,y:982,t:1527635766200};\\\", \\\"{x:1600,y:985,t:1527635766218};\\\", \\\"{x:1600,y:986,t:1527635766234};\\\", \\\"{x:1600,y:987,t:1527635766250};\\\", \\\"{x:1600,y:988,t:1527635766267};\\\", \\\"{x:1601,y:989,t:1527635766306};\\\", \\\"{x:1602,y:989,t:1527635766642};\\\", \\\"{x:1604,y:989,t:1527635766682};\\\", \\\"{x:1604,y:988,t:1527635766714};\\\", \\\"{x:1605,y:987,t:1527635766730};\\\", \\\"{x:1605,y:986,t:1527635766738};\\\", \\\"{x:1606,y:985,t:1527635766751};\\\", \\\"{x:1608,y:984,t:1527635766826};\\\", \\\"{x:1608,y:983,t:1527635766866};\\\", \\\"{x:1609,y:983,t:1527635766881};\\\", \\\"{x:1609,y:982,t:1527635766890};\\\", \\\"{x:1609,y:981,t:1527635766906};\\\", \\\"{x:1609,y:980,t:1527635766918};\\\", \\\"{x:1609,y:979,t:1527635766976};\\\", \\\"{x:1609,y:978,t:1527635766993};\\\", \\\"{x:1609,y:977,t:1527635767064};\\\", \\\"{x:1610,y:977,t:1527635767073};\\\", \\\"{x:1610,y:976,t:1527635767137};\\\", \\\"{x:1610,y:975,t:1527635767151};\\\", \\\"{x:1610,y:973,t:1527635767169};\\\", \\\"{x:1611,y:971,t:1527635767185};\\\", \\\"{x:1611,y:970,t:1527635767201};\\\", \\\"{x:1611,y:968,t:1527635767218};\\\", \\\"{x:1611,y:967,t:1527635767235};\\\", \\\"{x:1612,y:967,t:1527635767251};\\\", \\\"{x:1613,y:966,t:1527635767269};\\\", \\\"{x:1613,y:965,t:1527635767298};\\\", \\\"{x:1613,y:964,t:1527635767306};\\\", \\\"{x:1614,y:963,t:1527635767319};\\\", \\\"{x:1615,y:962,t:1527635767335};\\\", \\\"{x:1615,y:960,t:1527635767352};\\\", \\\"{x:1616,y:958,t:1527635767394};\\\", \\\"{x:1616,y:957,t:1527635767442};\\\", \\\"{x:1616,y:955,t:1527635769642};\\\", \\\"{x:1616,y:953,t:1527635769654};\\\", \\\"{x:1609,y:946,t:1527635769670};\\\", \\\"{x:1602,y:936,t:1527635769687};\\\", \\\"{x:1594,y:926,t:1527635769703};\\\", \\\"{x:1588,y:917,t:1527635769719};\\\", \\\"{x:1580,y:906,t:1527635769736};\\\", \\\"{x:1567,y:887,t:1527635769752};\\\", \\\"{x:1558,y:876,t:1527635769770};\\\", \\\"{x:1549,y:866,t:1527635769786};\\\", \\\"{x:1541,y:854,t:1527635769803};\\\", \\\"{x:1527,y:845,t:1527635769820};\\\", \\\"{x:1516,y:836,t:1527635769836};\\\", \\\"{x:1501,y:825,t:1527635769853};\\\", \\\"{x:1486,y:816,t:1527635769871};\\\", \\\"{x:1472,y:808,t:1527635769886};\\\", \\\"{x:1462,y:802,t:1527635769903};\\\", \\\"{x:1452,y:797,t:1527635769921};\\\", \\\"{x:1444,y:792,t:1527635769936};\\\", \\\"{x:1438,y:789,t:1527635769954};\\\", \\\"{x:1435,y:789,t:1527635769971};\\\", \\\"{x:1429,y:786,t:1527635769987};\\\", \\\"{x:1423,y:785,t:1527635770004};\\\", \\\"{x:1416,y:782,t:1527635770020};\\\", \\\"{x:1412,y:781,t:1527635770036};\\\", \\\"{x:1409,y:780,t:1527635770054};\\\", \\\"{x:1408,y:780,t:1527635770071};\\\", \\\"{x:1405,y:779,t:1527635770086};\\\", \\\"{x:1404,y:779,t:1527635770103};\\\", \\\"{x:1403,y:778,t:1527635770120};\\\", \\\"{x:1402,y:777,t:1527635770136};\\\", \\\"{x:1398,y:774,t:1527635770153};\\\", \\\"{x:1395,y:770,t:1527635770171};\\\", \\\"{x:1387,y:765,t:1527635770186};\\\", \\\"{x:1379,y:760,t:1527635770203};\\\", \\\"{x:1372,y:755,t:1527635770221};\\\", \\\"{x:1368,y:751,t:1527635770237};\\\", \\\"{x:1367,y:750,t:1527635770253};\\\", \\\"{x:1366,y:748,t:1527635770271};\\\", \\\"{x:1365,y:747,t:1527635770287};\\\", \\\"{x:1357,y:741,t:1527635770303};\\\", \\\"{x:1352,y:737,t:1527635770320};\\\", \\\"{x:1347,y:734,t:1527635770337};\\\", \\\"{x:1346,y:731,t:1527635770353};\\\", \\\"{x:1344,y:729,t:1527635770370};\\\", \\\"{x:1344,y:728,t:1527635770387};\\\", \\\"{x:1343,y:728,t:1527635770417};\\\", \\\"{x:1342,y:728,t:1527635770424};\\\", \\\"{x:1339,y:725,t:1527635770438};\\\", \\\"{x:1337,y:724,t:1527635770453};\\\", \\\"{x:1335,y:723,t:1527635770470};\\\", \\\"{x:1335,y:721,t:1527635770770};\\\", \\\"{x:1335,y:720,t:1527635770788};\\\", \\\"{x:1337,y:718,t:1527635770805};\\\", \\\"{x:1339,y:716,t:1527635770821};\\\", \\\"{x:1341,y:715,t:1527635770849};\\\", \\\"{x:1341,y:714,t:1527635770857};\\\", \\\"{x:1342,y:714,t:1527635770871};\\\", \\\"{x:1343,y:714,t:1527635770888};\\\", \\\"{x:1345,y:711,t:1527635770904};\\\", \\\"{x:1345,y:710,t:1527635770921};\\\", \\\"{x:1345,y:709,t:1527635770945};\\\", \\\"{x:1346,y:708,t:1527635770955};\\\", \\\"{x:1347,y:707,t:1527635771010};\\\", \\\"{x:1348,y:706,t:1527635771058};\\\", \\\"{x:1349,y:704,t:1527635771073};\\\", \\\"{x:1349,y:702,t:1527635771090};\\\", \\\"{x:1349,y:701,t:1527635771130};\\\", \\\"{x:1350,y:701,t:1527635771145};\\\", \\\"{x:1350,y:699,t:1527635771162};\\\", \\\"{x:1350,y:698,t:1527635771226};\\\", \\\"{x:1351,y:697,t:1527635771298};\\\", \\\"{x:1343,y:697,t:1527635773210};\\\", \\\"{x:1333,y:697,t:1527635773223};\\\", \\\"{x:1297,y:701,t:1527635773240};\\\", \\\"{x:1243,y:704,t:1527635773256};\\\", \\\"{x:1163,y:704,t:1527635773273};\\\", \\\"{x:1088,y:704,t:1527635773289};\\\", \\\"{x:996,y:704,t:1527635773306};\\\", \\\"{x:945,y:704,t:1527635773323};\\\", \\\"{x:898,y:704,t:1527635773340};\\\", \\\"{x:856,y:701,t:1527635773355};\\\", \\\"{x:825,y:697,t:1527635773373};\\\", \\\"{x:796,y:692,t:1527635773390};\\\", \\\"{x:780,y:688,t:1527635773405};\\\", \\\"{x:769,y:684,t:1527635773423};\\\", \\\"{x:754,y:681,t:1527635773440};\\\", \\\"{x:744,y:677,t:1527635773456};\\\", \\\"{x:730,y:673,t:1527635773473};\\\", \\\"{x:703,y:667,t:1527635773489};\\\", \\\"{x:690,y:663,t:1527635773506};\\\", \\\"{x:683,y:660,t:1527635773523};\\\", \\\"{x:680,y:653,t:1527635773540};\\\", \\\"{x:673,y:642,t:1527635773556};\\\", \\\"{x:671,y:638,t:1527635773573};\\\", \\\"{x:670,y:636,t:1527635773809};\\\", \\\"{x:669,y:635,t:1527635773823};\\\", \\\"{x:664,y:632,t:1527635773840};\\\", \\\"{x:659,y:629,t:1527635773858};\\\", \\\"{x:655,y:626,t:1527635773872};\\\", \\\"{x:639,y:623,t:1527635773890};\\\", \\\"{x:619,y:620,t:1527635773907};\\\", \\\"{x:586,y:615,t:1527635773924};\\\", \\\"{x:547,y:611,t:1527635773939};\\\", \\\"{x:489,y:606,t:1527635773957};\\\", \\\"{x:428,y:598,t:1527635773974};\\\", \\\"{x:373,y:591,t:1527635773991};\\\", \\\"{x:313,y:588,t:1527635774007};\\\", \\\"{x:266,y:588,t:1527635774024};\\\", \\\"{x:212,y:588,t:1527635774040};\\\", \\\"{x:149,y:584,t:1527635774057};\\\", \\\"{x:124,y:584,t:1527635774073};\\\", \\\"{x:106,y:583,t:1527635774090};\\\", \\\"{x:92,y:582,t:1527635774107};\\\", \\\"{x:81,y:582,t:1527635774124};\\\", \\\"{x:75,y:582,t:1527635774140};\\\", \\\"{x:72,y:582,t:1527635774157};\\\", \\\"{x:67,y:582,t:1527635774174};\\\", \\\"{x:66,y:582,t:1527635774250};\\\", \\\"{x:66,y:583,t:1527635774257};\\\", \\\"{x:69,y:587,t:1527635774274};\\\", \\\"{x:82,y:593,t:1527635774290};\\\", \\\"{x:93,y:597,t:1527635774307};\\\", \\\"{x:101,y:598,t:1527635774324};\\\", \\\"{x:110,y:599,t:1527635774340};\\\", \\\"{x:117,y:599,t:1527635774358};\\\", \\\"{x:127,y:600,t:1527635774374};\\\", \\\"{x:135,y:601,t:1527635774391};\\\", \\\"{x:137,y:602,t:1527635774407};\\\", \\\"{x:138,y:603,t:1527635774465};\\\", \\\"{x:141,y:603,t:1527635774481};\\\", \\\"{x:142,y:604,t:1527635774490};\\\", \\\"{x:145,y:605,t:1527635774507};\\\", \\\"{x:149,y:609,t:1527635774525};\\\", \\\"{x:152,y:612,t:1527635774541};\\\", \\\"{x:153,y:614,t:1527635774557};\\\", \\\"{x:154,y:615,t:1527635774593};\\\", \\\"{x:155,y:615,t:1527635774609};\\\", \\\"{x:156,y:615,t:1527635774666};\\\", \\\"{x:158,y:615,t:1527635774682};\\\", \\\"{x:160,y:615,t:1527635774692};\\\", \\\"{x:168,y:615,t:1527635774708};\\\", \\\"{x:181,y:612,t:1527635774725};\\\", \\\"{x:196,y:607,t:1527635774742};\\\", \\\"{x:215,y:600,t:1527635774758};\\\", \\\"{x:237,y:594,t:1527635774774};\\\", \\\"{x:258,y:589,t:1527635774791};\\\", \\\"{x:284,y:586,t:1527635774808};\\\", \\\"{x:309,y:586,t:1527635774824};\\\", \\\"{x:343,y:586,t:1527635774841};\\\", \\\"{x:363,y:586,t:1527635774858};\\\", \\\"{x:382,y:586,t:1527635774874};\\\", \\\"{x:393,y:586,t:1527635774891};\\\", \\\"{x:398,y:586,t:1527635774908};\\\", \\\"{x:401,y:586,t:1527635774925};\\\", \\\"{x:408,y:587,t:1527635774941};\\\", \\\"{x:412,y:588,t:1527635774957};\\\", \\\"{x:415,y:589,t:1527635774975};\\\", \\\"{x:416,y:589,t:1527635774991};\\\", \\\"{x:418,y:589,t:1527635775033};\\\", \\\"{x:419,y:589,t:1527635775049};\\\", \\\"{x:421,y:589,t:1527635775073};\\\", \\\"{x:422,y:589,t:1527635775089};\\\", \\\"{x:424,y:589,t:1527635775097};\\\", \\\"{x:425,y:589,t:1527635775108};\\\", \\\"{x:429,y:589,t:1527635775125};\\\", \\\"{x:437,y:589,t:1527635775141};\\\", \\\"{x:449,y:589,t:1527635775158};\\\", \\\"{x:460,y:589,t:1527635775175};\\\", \\\"{x:469,y:589,t:1527635775191};\\\", \\\"{x:475,y:590,t:1527635775208};\\\", \\\"{x:480,y:590,t:1527635775225};\\\", \\\"{x:486,y:591,t:1527635775241};\\\", \\\"{x:488,y:593,t:1527635775258};\\\", \\\"{x:493,y:593,t:1527635775275};\\\", \\\"{x:499,y:593,t:1527635775293};\\\", \\\"{x:512,y:594,t:1527635775309};\\\", \\\"{x:527,y:595,t:1527635775325};\\\", \\\"{x:542,y:599,t:1527635775341};\\\", \\\"{x:552,y:599,t:1527635775358};\\\", \\\"{x:563,y:602,t:1527635775376};\\\", \\\"{x:571,y:602,t:1527635775391};\\\", \\\"{x:580,y:603,t:1527635775409};\\\", \\\"{x:593,y:605,t:1527635775424};\\\", \\\"{x:606,y:607,t:1527635775443};\\\", \\\"{x:616,y:608,t:1527635775458};\\\", \\\"{x:624,y:608,t:1527635775476};\\\", \\\"{x:632,y:608,t:1527635775491};\\\", \\\"{x:634,y:608,t:1527635775508};\\\", \\\"{x:635,y:608,t:1527635775525};\\\", \\\"{x:636,y:608,t:1527635775544};\\\", \\\"{x:637,y:608,t:1527635775558};\\\", \\\"{x:638,y:608,t:1527635775575};\\\", \\\"{x:639,y:608,t:1527635775592};\\\", \\\"{x:640,y:608,t:1527635775608};\\\", \\\"{x:641,y:608,t:1527635775625};\\\", \\\"{x:642,y:608,t:1527635775649};\\\", \\\"{x:643,y:607,t:1527635775665};\\\", \\\"{x:643,y:606,t:1527635775682};\\\", \\\"{x:643,y:605,t:1527635775692};\\\", \\\"{x:643,y:603,t:1527635775709};\\\", \\\"{x:643,y:602,t:1527635775725};\\\", \\\"{x:641,y:599,t:1527635775743};\\\", \\\"{x:636,y:596,t:1527635775758};\\\", \\\"{x:633,y:593,t:1527635775776};\\\", \\\"{x:630,y:590,t:1527635775792};\\\", \\\"{x:627,y:588,t:1527635775809};\\\", \\\"{x:626,y:587,t:1527635775826};\\\", \\\"{x:625,y:586,t:1527635775842};\\\", \\\"{x:624,y:585,t:1527635775873};\\\", \\\"{x:623,y:584,t:1527635775881};\\\", \\\"{x:622,y:584,t:1527635775898};\\\", \\\"{x:620,y:583,t:1527635775912};\\\", \\\"{x:619,y:583,t:1527635775976};\\\", \\\"{x:618,y:583,t:1527635776001};\\\", \\\"{x:617,y:583,t:1527635776017};\\\", \\\"{x:616,y:583,t:1527635776040};\\\", \\\"{x:615,y:583,t:1527635776072};\\\", \\\"{x:616,y:579,t:1527635776281};\\\", \\\"{x:624,y:576,t:1527635776292};\\\", \\\"{x:649,y:566,t:1527635776309};\\\", \\\"{x:687,y:551,t:1527635776326};\\\", \\\"{x:723,y:537,t:1527635776342};\\\", \\\"{x:739,y:531,t:1527635776360};\\\", \\\"{x:747,y:526,t:1527635776376};\\\", \\\"{x:750,y:523,t:1527635776393};\\\", \\\"{x:753,y:521,t:1527635776410};\\\", \\\"{x:759,y:518,t:1527635776426};\\\", \\\"{x:765,y:513,t:1527635776443};\\\", \\\"{x:768,y:510,t:1527635776460};\\\", \\\"{x:771,y:508,t:1527635776475};\\\", \\\"{x:772,y:506,t:1527635776493};\\\", \\\"{x:774,y:506,t:1527635776509};\\\", \\\"{x:776,y:505,t:1527635776526};\\\", \\\"{x:780,y:502,t:1527635776543};\\\", \\\"{x:785,y:499,t:1527635776560};\\\", \\\"{x:789,y:496,t:1527635776576};\\\", \\\"{x:791,y:496,t:1527635776592};\\\", \\\"{x:792,y:495,t:1527635776609};\\\", \\\"{x:793,y:495,t:1527635776633};\\\", \\\"{x:794,y:495,t:1527635776649};\\\", \\\"{x:795,y:495,t:1527635776659};\\\", \\\"{x:798,y:495,t:1527635776676};\\\", \\\"{x:801,y:495,t:1527635776692};\\\", \\\"{x:807,y:495,t:1527635776709};\\\", \\\"{x:812,y:495,t:1527635776726};\\\", \\\"{x:818,y:495,t:1527635776742};\\\", \\\"{x:820,y:495,t:1527635776760};\\\", \\\"{x:821,y:495,t:1527635776833};\\\", \\\"{x:822,y:495,t:1527635776844};\\\", \\\"{x:823,y:495,t:1527635776866};\\\", \\\"{x:824,y:495,t:1527635776881};\\\", \\\"{x:825,y:495,t:1527635776894};\\\", \\\"{x:828,y:494,t:1527635776910};\\\", \\\"{x:830,y:493,t:1527635776927};\\\", \\\"{x:831,y:493,t:1527635776944};\\\", \\\"{x:832,y:493,t:1527635777024};\\\", \\\"{x:825,y:498,t:1527635777225};\\\", \\\"{x:807,y:515,t:1527635777244};\\\", \\\"{x:790,y:532,t:1527635777260};\\\", \\\"{x:763,y:556,t:1527635777276};\\\", \\\"{x:746,y:579,t:1527635777294};\\\", \\\"{x:724,y:605,t:1527635777311};\\\", \\\"{x:708,y:624,t:1527635777327};\\\", \\\"{x:692,y:638,t:1527635777344};\\\", \\\"{x:669,y:660,t:1527635777360};\\\", \\\"{x:656,y:673,t:1527635777376};\\\", \\\"{x:646,y:684,t:1527635777393};\\\", \\\"{x:639,y:693,t:1527635777411};\\\", \\\"{x:636,y:696,t:1527635777427};\\\", \\\"{x:633,y:697,t:1527635777444};\\\", \\\"{x:631,y:698,t:1527635777460};\\\", \\\"{x:631,y:700,t:1527635777476};\\\", \\\"{x:630,y:700,t:1527635777493};\\\", \\\"{x:629,y:700,t:1527635777510};\\\", \\\"{x:627,y:700,t:1527635777526};\\\", \\\"{x:623,y:700,t:1527635777543};\\\", \\\"{x:607,y:706,t:1527635777560};\\\", \\\"{x:596,y:711,t:1527635777576};\\\", \\\"{x:585,y:715,t:1527635777593};\\\", \\\"{x:573,y:719,t:1527635777609};\\\", \\\"{x:567,y:719,t:1527635777626};\\\", \\\"{x:560,y:719,t:1527635777643};\\\", \\\"{x:551,y:720,t:1527635777661};\\\", \\\"{x:542,y:721,t:1527635777676};\\\", \\\"{x:534,y:723,t:1527635777693};\\\", \\\"{x:525,y:724,t:1527635777710};\\\", \\\"{x:515,y:725,t:1527635777728};\\\", \\\"{x:511,y:725,t:1527635777743};\\\", \\\"{x:510,y:726,t:1527635777760};\\\", \\\"{x:510,y:727,t:1527635777785};\\\" ] }, { \\\"rt\\\": 16061, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 457254, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"DK1EM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-03 PM-M -B -3\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:510,y:728,t:1527635780282};\\\", \\\"{x:511,y:730,t:1527635780295};\\\", \\\"{x:512,y:730,t:1527635780313};\\\", \\\"{x:514,y:731,t:1527635780330};\\\", \\\"{x:515,y:731,t:1527635780346};\\\", \\\"{x:516,y:731,t:1527635780650};\\\", \\\"{x:517,y:731,t:1527635780674};\\\", \\\"{x:518,y:731,t:1527635780689};\\\", \\\"{x:519,y:731,t:1527635780745};\\\", \\\"{x:520,y:731,t:1527635780881};\\\", \\\"{x:522,y:731,t:1527635780896};\\\", \\\"{x:524,y:731,t:1527635780913};\\\", \\\"{x:527,y:731,t:1527635780929};\\\", \\\"{x:529,y:731,t:1527635780946};\\\", \\\"{x:530,y:731,t:1527635780963};\\\", \\\"{x:532,y:731,t:1527635780984};\\\", \\\"{x:533,y:731,t:1527635781009};\\\", \\\"{x:535,y:731,t:1527635781049};\\\", \\\"{x:536,y:731,t:1527635781073};\\\", \\\"{x:537,y:730,t:1527635781097};\\\", \\\"{x:538,y:729,t:1527635781145};\\\", \\\"{x:539,y:729,t:1527635781186};\\\", \\\"{x:540,y:729,t:1527635781257};\\\", \\\"{x:541,y:729,t:1527635781282};\\\", \\\"{x:543,y:729,t:1527635781297};\\\", \\\"{x:544,y:729,t:1527635781321};\\\", \\\"{x:545,y:729,t:1527635781331};\\\", \\\"{x:546,y:729,t:1527635781347};\\\", \\\"{x:548,y:729,t:1527635781364};\\\", \\\"{x:549,y:727,t:1527635781380};\\\", \\\"{x:555,y:727,t:1527635781396};\\\", \\\"{x:559,y:727,t:1527635781414};\\\", \\\"{x:563,y:727,t:1527635781431};\\\", \\\"{x:569,y:729,t:1527635781448};\\\", \\\"{x:576,y:730,t:1527635781464};\\\", \\\"{x:584,y:730,t:1527635781480};\\\", \\\"{x:588,y:731,t:1527635781496};\\\", \\\"{x:587,y:732,t:1527635781841};\\\", \\\"{x:587,y:733,t:1527635781890};\\\", \\\"{x:587,y:734,t:1527635781969};\\\", \\\"{x:589,y:733,t:1527635781986};\\\", \\\"{x:590,y:733,t:1527635781996};\\\", \\\"{x:593,y:733,t:1527635782013};\\\", \\\"{x:596,y:733,t:1527635782031};\\\", \\\"{x:598,y:733,t:1527635782046};\\\", \\\"{x:601,y:731,t:1527635782064};\\\", \\\"{x:608,y:731,t:1527635782081};\\\", \\\"{x:615,y:731,t:1527635782097};\\\", \\\"{x:623,y:731,t:1527635782114};\\\", \\\"{x:633,y:731,t:1527635782131};\\\", \\\"{x:648,y:731,t:1527635782147};\\\", \\\"{x:667,y:731,t:1527635782164};\\\", \\\"{x:689,y:731,t:1527635782181};\\\", \\\"{x:716,y:731,t:1527635782197};\\\", \\\"{x:748,y:731,t:1527635782214};\\\", \\\"{x:784,y:731,t:1527635782230};\\\", \\\"{x:817,y:731,t:1527635782247};\\\", \\\"{x:849,y:731,t:1527635782263};\\\", \\\"{x:893,y:731,t:1527635782281};\\\", \\\"{x:931,y:731,t:1527635782297};\\\", \\\"{x:967,y:731,t:1527635782314};\\\", \\\"{x:1007,y:737,t:1527635782331};\\\", \\\"{x:1039,y:743,t:1527635782347};\\\", \\\"{x:1063,y:749,t:1527635782363};\\\", \\\"{x:1084,y:756,t:1527635782381};\\\", \\\"{x:1097,y:762,t:1527635782399};\\\", \\\"{x:1107,y:770,t:1527635782414};\\\", \\\"{x:1115,y:779,t:1527635782431};\\\", \\\"{x:1126,y:792,t:1527635782448};\\\", \\\"{x:1138,y:809,t:1527635782464};\\\", \\\"{x:1156,y:834,t:1527635782482};\\\", \\\"{x:1170,y:849,t:1527635782498};\\\", \\\"{x:1193,y:874,t:1527635782514};\\\", \\\"{x:1230,y:903,t:1527635782531};\\\", \\\"{x:1270,y:930,t:1527635782548};\\\", \\\"{x:1301,y:946,t:1527635782564};\\\", \\\"{x:1341,y:961,t:1527635782581};\\\", \\\"{x:1373,y:971,t:1527635782598};\\\", \\\"{x:1401,y:975,t:1527635782615};\\\", \\\"{x:1427,y:981,t:1527635782631};\\\", \\\"{x:1454,y:984,t:1527635782649};\\\", \\\"{x:1476,y:988,t:1527635782664};\\\", \\\"{x:1497,y:990,t:1527635782680};\\\", \\\"{x:1500,y:990,t:1527635782697};\\\", \\\"{x:1501,y:990,t:1527635782714};\\\", \\\"{x:1504,y:990,t:1527635782731};\\\", \\\"{x:1507,y:989,t:1527635782748};\\\", \\\"{x:1508,y:988,t:1527635782764};\\\", \\\"{x:1513,y:987,t:1527635782781};\\\", \\\"{x:1517,y:984,t:1527635782798};\\\", \\\"{x:1521,y:980,t:1527635782814};\\\", \\\"{x:1523,y:978,t:1527635782831};\\\", \\\"{x:1526,y:974,t:1527635782848};\\\", \\\"{x:1529,y:971,t:1527635782865};\\\", \\\"{x:1533,y:968,t:1527635782882};\\\", \\\"{x:1533,y:967,t:1527635782898};\\\", \\\"{x:1534,y:967,t:1527635782915};\\\", \\\"{x:1536,y:967,t:1527635782930};\\\", \\\"{x:1538,y:965,t:1527635782948};\\\", \\\"{x:1541,y:964,t:1527635782965};\\\", \\\"{x:1542,y:963,t:1527635783049};\\\", \\\"{x:1543,y:963,t:1527635783216};\\\", \\\"{x:1545,y:963,t:1527635783231};\\\", \\\"{x:1546,y:962,t:1527635783587};\\\", \\\"{x:1547,y:961,t:1527635783601};\\\", \\\"{x:1548,y:960,t:1527635783615};\\\", \\\"{x:1548,y:958,t:1527635783631};\\\", \\\"{x:1548,y:957,t:1527635783648};\\\", \\\"{x:1548,y:956,t:1527635783689};\\\", \\\"{x:1548,y:955,t:1527635783721};\\\", \\\"{x:1548,y:954,t:1527635783802};\\\", \\\"{x:1549,y:954,t:1527635784905};\\\", \\\"{x:1550,y:954,t:1527635784944};\\\", \\\"{x:1551,y:954,t:1527635784985};\\\", \\\"{x:1552,y:954,t:1527635785034};\\\", \\\"{x:1553,y:955,t:1527635785731};\\\", \\\"{x:1551,y:955,t:1527635788802};\\\", \\\"{x:1537,y:954,t:1527635788820};\\\", \\\"{x:1514,y:947,t:1527635788836};\\\", \\\"{x:1479,y:938,t:1527635788852};\\\", \\\"{x:1441,y:925,t:1527635788869};\\\", \\\"{x:1416,y:919,t:1527635788885};\\\", \\\"{x:1398,y:911,t:1527635788903};\\\", \\\"{x:1385,y:904,t:1527635788920};\\\", \\\"{x:1376,y:896,t:1527635788937};\\\", \\\"{x:1366,y:889,t:1527635788952};\\\", \\\"{x:1346,y:874,t:1527635788968};\\\", \\\"{x:1339,y:871,t:1527635788985};\\\", \\\"{x:1337,y:869,t:1527635789002};\\\", \\\"{x:1336,y:869,t:1527635789019};\\\", \\\"{x:1336,y:866,t:1527635789035};\\\", \\\"{x:1336,y:863,t:1527635789052};\\\", \\\"{x:1336,y:860,t:1527635789069};\\\", \\\"{x:1336,y:858,t:1527635789086};\\\", \\\"{x:1336,y:857,t:1527635789102};\\\", \\\"{x:1336,y:854,t:1527635789119};\\\", \\\"{x:1336,y:852,t:1527635789136};\\\", \\\"{x:1338,y:850,t:1527635789152};\\\", \\\"{x:1339,y:848,t:1527635789169};\\\", \\\"{x:1340,y:846,t:1527635789186};\\\", \\\"{x:1341,y:845,t:1527635789218};\\\", \\\"{x:1342,y:844,t:1527635789249};\\\", \\\"{x:1342,y:843,t:1527635789265};\\\", \\\"{x:1344,y:841,t:1527635789281};\\\", \\\"{x:1346,y:841,t:1527635789313};\\\", \\\"{x:1346,y:840,t:1527635789321};\\\", \\\"{x:1346,y:838,t:1527635789336};\\\", \\\"{x:1347,y:837,t:1527635789352};\\\", \\\"{x:1348,y:835,t:1527635789369};\\\", \\\"{x:1348,y:832,t:1527635789387};\\\", \\\"{x:1349,y:832,t:1527635789402};\\\", \\\"{x:1349,y:831,t:1527635789420};\\\", \\\"{x:1349,y:827,t:1527635790066};\\\", \\\"{x:1349,y:822,t:1527635790073};\\\", \\\"{x:1349,y:821,t:1527635790087};\\\", \\\"{x:1349,y:817,t:1527635790103};\\\", \\\"{x:1348,y:814,t:1527635790120};\\\", \\\"{x:1347,y:810,t:1527635790136};\\\", \\\"{x:1345,y:806,t:1527635790153};\\\", \\\"{x:1345,y:805,t:1527635790170};\\\", \\\"{x:1345,y:802,t:1527635790186};\\\", \\\"{x:1343,y:799,t:1527635790203};\\\", \\\"{x:1343,y:796,t:1527635790220};\\\", \\\"{x:1343,y:794,t:1527635790236};\\\", \\\"{x:1343,y:792,t:1527635790253};\\\", \\\"{x:1343,y:791,t:1527635790270};\\\", \\\"{x:1343,y:789,t:1527635790286};\\\", \\\"{x:1343,y:788,t:1527635790304};\\\", \\\"{x:1343,y:786,t:1527635790320};\\\", \\\"{x:1343,y:784,t:1527635790337};\\\", \\\"{x:1344,y:782,t:1527635790353};\\\", \\\"{x:1346,y:782,t:1527635790370};\\\", \\\"{x:1347,y:781,t:1527635790386};\\\", \\\"{x:1348,y:779,t:1527635790409};\\\", \\\"{x:1349,y:778,t:1527635790425};\\\", \\\"{x:1350,y:777,t:1527635790441};\\\", \\\"{x:1351,y:777,t:1527635790537};\\\", \\\"{x:1351,y:776,t:1527635790569};\\\", \\\"{x:1351,y:775,t:1527635790600};\\\", \\\"{x:1351,y:774,t:1527635790609};\\\", \\\"{x:1352,y:774,t:1527635790649};\\\", \\\"{x:1352,y:773,t:1527635790713};\\\", \\\"{x:1352,y:772,t:1527635790729};\\\", \\\"{x:1352,y:771,t:1527635790737};\\\", \\\"{x:1352,y:770,t:1527635790785};\\\", \\\"{x:1352,y:769,t:1527635790801};\\\", \\\"{x:1352,y:768,t:1527635790826};\\\", \\\"{x:1352,y:767,t:1527635790850};\\\", \\\"{x:1352,y:766,t:1527635790870};\\\", \\\"{x:1352,y:765,t:1527635790897};\\\", \\\"{x:1353,y:765,t:1527635790920};\\\", \\\"{x:1353,y:764,t:1527635790968};\\\", \\\"{x:1353,y:763,t:1527635791016};\\\", \\\"{x:1353,y:762,t:1527635793186};\\\", \\\"{x:1352,y:762,t:1527635793234};\\\", \\\"{x:1346,y:762,t:1527635793241};\\\", \\\"{x:1339,y:762,t:1527635793256};\\\", \\\"{x:1316,y:762,t:1527635793272};\\\", \\\"{x:1234,y:762,t:1527635793289};\\\", \\\"{x:1148,y:762,t:1527635793305};\\\", \\\"{x:1037,y:762,t:1527635793322};\\\", \\\"{x:918,y:762,t:1527635793339};\\\", \\\"{x:796,y:760,t:1527635793355};\\\", \\\"{x:685,y:760,t:1527635793371};\\\", \\\"{x:593,y:760,t:1527635793389};\\\", \\\"{x:539,y:759,t:1527635793405};\\\", \\\"{x:511,y:756,t:1527635793422};\\\", \\\"{x:496,y:753,t:1527635793439};\\\", \\\"{x:494,y:752,t:1527635793455};\\\", \\\"{x:493,y:752,t:1527635793472};\\\", \\\"{x:493,y:751,t:1527635793528};\\\", \\\"{x:493,y:748,t:1527635793539};\\\", \\\"{x:493,y:737,t:1527635793556};\\\", \\\"{x:493,y:723,t:1527635793573};\\\", \\\"{x:493,y:704,t:1527635793590};\\\", \\\"{x:491,y:682,t:1527635793606};\\\", \\\"{x:481,y:656,t:1527635793624};\\\", \\\"{x:473,y:628,t:1527635793640};\\\", \\\"{x:456,y:592,t:1527635793657};\\\", \\\"{x:441,y:575,t:1527635793673};\\\", \\\"{x:423,y:555,t:1527635793691};\\\", \\\"{x:406,y:541,t:1527635793706};\\\", \\\"{x:384,y:526,t:1527635793723};\\\", \\\"{x:367,y:516,t:1527635793740};\\\", \\\"{x:355,y:511,t:1527635793756};\\\", \\\"{x:339,y:509,t:1527635793772};\\\", \\\"{x:329,y:508,t:1527635793790};\\\", \\\"{x:319,y:508,t:1527635793805};\\\", \\\"{x:306,y:508,t:1527635793823};\\\", \\\"{x:289,y:511,t:1527635793840};\\\", \\\"{x:260,y:522,t:1527635793857};\\\", \\\"{x:244,y:526,t:1527635793873};\\\", \\\"{x:230,y:529,t:1527635793889};\\\", \\\"{x:220,y:534,t:1527635793907};\\\", \\\"{x:211,y:539,t:1527635793923};\\\", \\\"{x:205,y:542,t:1527635793940};\\\", \\\"{x:199,y:545,t:1527635793957};\\\", \\\"{x:192,y:547,t:1527635793973};\\\", \\\"{x:187,y:549,t:1527635793990};\\\", \\\"{x:183,y:549,t:1527635794007};\\\", \\\"{x:179,y:549,t:1527635794023};\\\", \\\"{x:178,y:550,t:1527635794040};\\\", \\\"{x:177,y:550,t:1527635794060};\\\", \\\"{x:176,y:550,t:1527635794080};\\\", \\\"{x:175,y:550,t:1527635794104};\\\", \\\"{x:173,y:550,t:1527635794120};\\\", \\\"{x:171,y:550,t:1527635794136};\\\", \\\"{x:170,y:550,t:1527635794144};\\\", \\\"{x:168,y:550,t:1527635794157};\\\", \\\"{x:166,y:550,t:1527635794172};\\\", \\\"{x:165,y:550,t:1527635794190};\\\", \\\"{x:164,y:550,t:1527635794207};\\\", \\\"{x:162,y:550,t:1527635794223};\\\", \\\"{x:161,y:549,t:1527635794240};\\\", \\\"{x:160,y:549,t:1527635794257};\\\", \\\"{x:159,y:549,t:1527635794280};\\\", \\\"{x:162,y:549,t:1527635794504};\\\", \\\"{x:165,y:552,t:1527635794512};\\\", \\\"{x:173,y:556,t:1527635794525};\\\", \\\"{x:187,y:562,t:1527635794540};\\\", \\\"{x:205,y:572,t:1527635794557};\\\", \\\"{x:226,y:583,t:1527635794574};\\\", \\\"{x:248,y:595,t:1527635794590};\\\", \\\"{x:270,y:604,t:1527635794608};\\\", \\\"{x:302,y:613,t:1527635794624};\\\", \\\"{x:318,y:620,t:1527635794639};\\\", \\\"{x:332,y:625,t:1527635794657};\\\", \\\"{x:346,y:631,t:1527635794674};\\\", \\\"{x:361,y:638,t:1527635794690};\\\", \\\"{x:377,y:646,t:1527635794708};\\\", \\\"{x:392,y:654,t:1527635794724};\\\", \\\"{x:404,y:660,t:1527635794742};\\\", \\\"{x:414,y:668,t:1527635794758};\\\", \\\"{x:419,y:676,t:1527635794775};\\\", \\\"{x:423,y:681,t:1527635794791};\\\", \\\"{x:428,y:689,t:1527635794808};\\\", \\\"{x:432,y:694,t:1527635794824};\\\", \\\"{x:440,y:702,t:1527635794841};\\\", \\\"{x:447,y:707,t:1527635794857};\\\", \\\"{x:450,y:710,t:1527635794874};\\\", \\\"{x:455,y:713,t:1527635794891};\\\", \\\"{x:459,y:717,t:1527635794907};\\\", \\\"{x:462,y:718,t:1527635794924};\\\", \\\"{x:466,y:720,t:1527635794942};\\\", \\\"{x:468,y:722,t:1527635794957};\\\", \\\"{x:471,y:724,t:1527635794974};\\\", \\\"{x:475,y:726,t:1527635794991};\\\", \\\"{x:479,y:728,t:1527635795008};\\\", \\\"{x:481,y:728,t:1527635795025};\\\", \\\"{x:484,y:729,t:1527635795041};\\\", \\\"{x:485,y:729,t:1527635795059};\\\", \\\"{x:486,y:729,t:1527635795074};\\\", \\\"{x:488,y:729,t:1527635795092};\\\", \\\"{x:492,y:729,t:1527635795108};\\\", \\\"{x:493,y:729,t:1527635795124};\\\", \\\"{x:495,y:729,t:1527635795141};\\\", \\\"{x:499,y:731,t:1527635795600};\\\", \\\"{x:502,y:733,t:1527635795608};\\\", \\\"{x:508,y:734,t:1527635795624};\\\", \\\"{x:536,y:741,t:1527635795641};\\\", \\\"{x:566,y:747,t:1527635795658};\\\", \\\"{x:616,y:755,t:1527635795674};\\\", \\\"{x:671,y:758,t:1527635795691};\\\", \\\"{x:723,y:763,t:1527635795708};\\\", \\\"{x:757,y:764,t:1527635795724};\\\", \\\"{x:782,y:764,t:1527635795741};\\\", \\\"{x:801,y:764,t:1527635795758};\\\", \\\"{x:811,y:764,t:1527635795775};\\\", \\\"{x:818,y:764,t:1527635795791};\\\", \\\"{x:823,y:764,t:1527635795809};\\\", \\\"{x:825,y:764,t:1527635795824};\\\", \\\"{x:825,y:765,t:1527635795841};\\\", \\\"{x:827,y:767,t:1527635795858};\\\", \\\"{x:828,y:768,t:1527635795875};\\\", \\\"{x:829,y:769,t:1527635795891};\\\", \\\"{x:830,y:771,t:1527635795908};\\\", \\\"{x:832,y:774,t:1527635795925};\\\", \\\"{x:832,y:776,t:1527635795942};\\\", \\\"{x:833,y:777,t:1527635795958};\\\", \\\"{x:835,y:779,t:1527635795975};\\\", \\\"{x:836,y:780,t:1527635795992};\\\", \\\"{x:836,y:781,t:1527635796016};\\\", \\\"{x:836,y:782,t:1527635796049};\\\", \\\"{x:836,y:783,t:1527635796065};\\\" ] }, { \\\"rt\\\": 34626, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 493147, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"DK1EM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-X -02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:835,y:782,t:1527635797152};\\\", \\\"{x:834,y:782,t:1527635797160};\\\", \\\"{x:831,y:779,t:1527635797176};\\\", \\\"{x:828,y:777,t:1527635797192};\\\", \\\"{x:826,y:776,t:1527635797209};\\\", \\\"{x:821,y:775,t:1527635797226};\\\", \\\"{x:817,y:775,t:1527635797241};\\\", \\\"{x:813,y:775,t:1527635797259};\\\", \\\"{x:809,y:774,t:1527635797276};\\\", \\\"{x:806,y:774,t:1527635797292};\\\", \\\"{x:803,y:774,t:1527635797309};\\\", \\\"{x:802,y:773,t:1527635797327};\\\", \\\"{x:801,y:773,t:1527635797473};\\\", \\\"{x:801,y:772,t:1527635797504};\\\", \\\"{x:800,y:772,t:1527635797536};\\\", \\\"{x:799,y:772,t:1527635797544};\\\", \\\"{x:798,y:772,t:1527635797562};\\\", \\\"{x:797,y:772,t:1527635797641};\\\", \\\"{x:795,y:772,t:1527635797649};\\\", \\\"{x:794,y:772,t:1527635797659};\\\", \\\"{x:790,y:772,t:1527635797676};\\\", \\\"{x:786,y:772,t:1527635797693};\\\", \\\"{x:781,y:772,t:1527635797709};\\\", \\\"{x:776,y:772,t:1527635797726};\\\", \\\"{x:774,y:772,t:1527635797743};\\\", \\\"{x:772,y:772,t:1527635797759};\\\", \\\"{x:770,y:772,t:1527635797801};\\\", \\\"{x:768,y:772,t:1527635797817};\\\", \\\"{x:767,y:772,t:1527635797826};\\\", \\\"{x:765,y:772,t:1527635797843};\\\", \\\"{x:759,y:772,t:1527635797860};\\\", \\\"{x:756,y:772,t:1527635797876};\\\", \\\"{x:753,y:772,t:1527635797894};\\\", \\\"{x:749,y:772,t:1527635797909};\\\", \\\"{x:748,y:772,t:1527635797926};\\\", \\\"{x:745,y:771,t:1527635797944};\\\", \\\"{x:744,y:771,t:1527635798001};\\\", \\\"{x:743,y:771,t:1527635798025};\\\", \\\"{x:742,y:771,t:1527635798033};\\\", \\\"{x:741,y:771,t:1527635798048};\\\", \\\"{x:740,y:771,t:1527635798061};\\\", \\\"{x:738,y:769,t:1527635798076};\\\", \\\"{x:737,y:769,t:1527635798146};\\\", \\\"{x:736,y:769,t:1527635798161};\\\", \\\"{x:735,y:769,t:1527635798177};\\\", \\\"{x:734,y:769,t:1527635798193};\\\", \\\"{x:732,y:769,t:1527635798211};\\\", \\\"{x:731,y:769,t:1527635798227};\\\", \\\"{x:730,y:769,t:1527635798243};\\\", \\\"{x:729,y:769,t:1527635798260};\\\", \\\"{x:728,y:769,t:1527635798569};\\\", \\\"{x:727,y:769,t:1527635798585};\\\", \\\"{x:726,y:769,t:1527635798618};\\\", \\\"{x:725,y:769,t:1527635798627};\\\", \\\"{x:724,y:769,t:1527635798874};\\\", \\\"{x:723,y:770,t:1527635798889};\\\", \\\"{x:721,y:770,t:1527635799208};\\\", \\\"{x:720,y:770,t:1527635799240};\\\", \\\"{x:720,y:771,t:1527635800880};\\\", \\\"{x:721,y:771,t:1527635800962};\\\", \\\"{x:722,y:771,t:1527635800976};\\\", \\\"{x:723,y:771,t:1527635801025};\\\", \\\"{x:724,y:771,t:1527635801064};\\\", \\\"{x:725,y:771,t:1527635801145};\\\", \\\"{x:726,y:771,t:1527635803408};\\\", \\\"{x:726,y:772,t:1527635803448};\\\", \\\"{x:726,y:773,t:1527635803496};\\\", \\\"{x:726,y:774,t:1527635803504};\\\", \\\"{x:726,y:775,t:1527635803576};\\\", \\\"{x:726,y:776,t:1527635803591};\\\", \\\"{x:726,y:777,t:1527635803608};\\\", \\\"{x:727,y:777,t:1527635803776};\\\", \\\"{x:728,y:777,t:1527635803808};\\\", \\\"{x:729,y:777,t:1527635803815};\\\", \\\"{x:730,y:777,t:1527635803831};\\\", \\\"{x:732,y:777,t:1527635803848};\\\", \\\"{x:733,y:777,t:1527635803864};\\\", \\\"{x:736,y:775,t:1527635803881};\\\", \\\"{x:739,y:774,t:1527635803897};\\\", \\\"{x:742,y:774,t:1527635804224};\\\", \\\"{x:746,y:774,t:1527635804231};\\\", \\\"{x:748,y:773,t:1527635804248};\\\", \\\"{x:766,y:771,t:1527635804263};\\\", \\\"{x:780,y:771,t:1527635804281};\\\", \\\"{x:795,y:771,t:1527635804298};\\\", \\\"{x:815,y:771,t:1527635804314};\\\", \\\"{x:840,y:771,t:1527635804331};\\\", \\\"{x:868,y:771,t:1527635804347};\\\", \\\"{x:898,y:771,t:1527635804364};\\\", \\\"{x:934,y:771,t:1527635804381};\\\", \\\"{x:971,y:771,t:1527635804397};\\\", \\\"{x:1013,y:771,t:1527635804414};\\\", \\\"{x:1055,y:771,t:1527635804431};\\\", \\\"{x:1103,y:771,t:1527635804447};\\\", \\\"{x:1159,y:771,t:1527635804464};\\\", \\\"{x:1195,y:774,t:1527635804481};\\\", \\\"{x:1232,y:774,t:1527635804497};\\\", \\\"{x:1276,y:780,t:1527635804514};\\\", \\\"{x:1309,y:785,t:1527635804532};\\\", \\\"{x:1334,y:790,t:1527635804548};\\\", \\\"{x:1358,y:793,t:1527635804565};\\\", \\\"{x:1371,y:795,t:1527635804582};\\\", \\\"{x:1380,y:797,t:1527635804597};\\\", \\\"{x:1389,y:801,t:1527635804615};\\\", \\\"{x:1399,y:806,t:1527635804632};\\\", \\\"{x:1403,y:809,t:1527635804648};\\\", \\\"{x:1410,y:815,t:1527635804665};\\\", \\\"{x:1413,y:821,t:1527635804681};\\\", \\\"{x:1414,y:825,t:1527635804699};\\\", \\\"{x:1415,y:831,t:1527635804715};\\\", \\\"{x:1416,y:839,t:1527635804731};\\\", \\\"{x:1419,y:848,t:1527635804749};\\\", \\\"{x:1422,y:858,t:1527635804764};\\\", \\\"{x:1427,y:870,t:1527635804781};\\\", \\\"{x:1429,y:878,t:1527635804798};\\\", \\\"{x:1433,y:886,t:1527635804814};\\\", \\\"{x:1433,y:891,t:1527635804831};\\\", \\\"{x:1436,y:901,t:1527635804847};\\\", \\\"{x:1438,y:907,t:1527635804864};\\\", \\\"{x:1441,y:913,t:1527635804881};\\\", \\\"{x:1444,y:919,t:1527635804898};\\\", \\\"{x:1446,y:922,t:1527635804914};\\\", \\\"{x:1449,y:925,t:1527635804932};\\\", \\\"{x:1452,y:928,t:1527635804948};\\\", \\\"{x:1452,y:929,t:1527635804964};\\\", \\\"{x:1455,y:932,t:1527635804981};\\\", \\\"{x:1456,y:934,t:1527635804998};\\\", \\\"{x:1459,y:937,t:1527635805014};\\\", \\\"{x:1464,y:941,t:1527635805031};\\\", \\\"{x:1472,y:946,t:1527635805048};\\\", \\\"{x:1475,y:948,t:1527635805064};\\\", \\\"{x:1480,y:951,t:1527635805081};\\\", \\\"{x:1481,y:952,t:1527635805099};\\\", \\\"{x:1481,y:953,t:1527635805115};\\\", \\\"{x:1482,y:954,t:1527635805131};\\\", \\\"{x:1482,y:955,t:1527635805148};\\\", \\\"{x:1482,y:957,t:1527635805165};\\\", \\\"{x:1482,y:959,t:1527635805181};\\\", \\\"{x:1482,y:960,t:1527635805199};\\\", \\\"{x:1482,y:961,t:1527635805216};\\\", \\\"{x:1482,y:962,t:1527635805273};\\\", \\\"{x:1482,y:963,t:1527635805282};\\\", \\\"{x:1482,y:964,t:1527635805304};\\\", \\\"{x:1481,y:964,t:1527635805316};\\\", \\\"{x:1481,y:966,t:1527635805336};\\\", \\\"{x:1481,y:967,t:1527635805353};\\\", \\\"{x:1480,y:968,t:1527635805377};\\\", \\\"{x:1480,y:969,t:1527635805393};\\\", \\\"{x:1480,y:970,t:1527635805424};\\\", \\\"{x:1480,y:971,t:1527635805449};\\\", \\\"{x:1480,y:972,t:1527635805465};\\\", \\\"{x:1480,y:973,t:1527635805522};\\\", \\\"{x:1480,y:972,t:1527635805673};\\\", \\\"{x:1480,y:971,t:1527635805683};\\\", \\\"{x:1480,y:970,t:1527635805700};\\\", \\\"{x:1481,y:968,t:1527635805722};\\\", \\\"{x:1481,y:967,t:1527635805769};\\\", \\\"{x:1482,y:965,t:1527635805793};\\\", \\\"{x:1482,y:964,t:1527635805890};\\\", \\\"{x:1482,y:963,t:1527635805992};\\\", \\\"{x:1481,y:963,t:1527635806170};\\\", \\\"{x:1481,y:962,t:1527635806216};\\\", \\\"{x:1480,y:961,t:1527635806248};\\\", \\\"{x:1479,y:960,t:1527635806272};\\\", \\\"{x:1479,y:959,t:1527635806353};\\\", \\\"{x:1478,y:958,t:1527635806369};\\\", \\\"{x:1478,y:957,t:1527635806440};\\\", \\\"{x:1478,y:956,t:1527635806463};\\\", \\\"{x:1478,y:955,t:1527635806488};\\\", \\\"{x:1478,y:954,t:1527635806576};\\\", \\\"{x:1478,y:953,t:1527635806593};\\\", \\\"{x:1478,y:952,t:1527635806616};\\\", \\\"{x:1478,y:951,t:1527635806664};\\\", \\\"{x:1478,y:950,t:1527635806680};\\\", \\\"{x:1478,y:949,t:1527635806704};\\\", \\\"{x:1478,y:948,t:1527635806760};\\\", \\\"{x:1478,y:947,t:1527635806777};\\\", \\\"{x:1478,y:946,t:1527635806784};\\\", \\\"{x:1478,y:945,t:1527635806832};\\\", \\\"{x:1478,y:944,t:1527635806897};\\\", \\\"{x:1478,y:943,t:1527635806905};\\\", \\\"{x:1477,y:943,t:1527635806921};\\\", \\\"{x:1476,y:943,t:1527635806937};\\\", \\\"{x:1475,y:943,t:1527635806986};\\\", \\\"{x:1474,y:943,t:1527635807001};\\\", \\\"{x:1473,y:943,t:1527635807017};\\\", \\\"{x:1472,y:943,t:1527635807057};\\\", \\\"{x:1472,y:944,t:1527635807433};\\\", \\\"{x:1472,y:943,t:1527635807625};\\\", \\\"{x:1470,y:941,t:1527635807634};\\\", \\\"{x:1469,y:938,t:1527635807651};\\\", \\\"{x:1469,y:932,t:1527635807668};\\\", \\\"{x:1468,y:929,t:1527635807684};\\\", \\\"{x:1467,y:924,t:1527635807701};\\\", \\\"{x:1466,y:923,t:1527635807717};\\\", \\\"{x:1467,y:920,t:1527635807735};\\\", \\\"{x:1467,y:919,t:1527635807751};\\\", \\\"{x:1468,y:918,t:1527635807768};\\\", \\\"{x:1468,y:915,t:1527635807784};\\\", \\\"{x:1469,y:914,t:1527635807801};\\\", \\\"{x:1471,y:911,t:1527635807817};\\\", \\\"{x:1472,y:910,t:1527635807835};\\\", \\\"{x:1473,y:908,t:1527635807850};\\\", \\\"{x:1474,y:906,t:1527635807867};\\\", \\\"{x:1475,y:904,t:1527635807884};\\\", \\\"{x:1476,y:901,t:1527635807900};\\\", \\\"{x:1477,y:893,t:1527635807916};\\\", \\\"{x:1477,y:887,t:1527635807934};\\\", \\\"{x:1477,y:879,t:1527635807951};\\\", \\\"{x:1476,y:870,t:1527635807966};\\\", \\\"{x:1475,y:863,t:1527635807984};\\\", \\\"{x:1474,y:853,t:1527635808001};\\\", \\\"{x:1474,y:848,t:1527635808017};\\\", \\\"{x:1474,y:842,t:1527635808034};\\\", \\\"{x:1474,y:839,t:1527635808051};\\\", \\\"{x:1474,y:837,t:1527635808068};\\\", \\\"{x:1474,y:832,t:1527635808084};\\\", \\\"{x:1474,y:830,t:1527635808102};\\\", \\\"{x:1474,y:828,t:1527635808118};\\\", \\\"{x:1474,y:827,t:1527635808134};\\\", \\\"{x:1474,y:826,t:1527635808151};\\\", \\\"{x:1474,y:825,t:1527635808168};\\\", \\\"{x:1474,y:824,t:1527635808506};\\\", \\\"{x:1473,y:823,t:1527635808586};\\\", \\\"{x:1473,y:822,t:1527635808929};\\\", \\\"{x:1473,y:823,t:1527635810945};\\\", \\\"{x:1473,y:824,t:1527635811193};\\\", \\\"{x:1473,y:825,t:1527635811257};\\\", \\\"{x:1475,y:826,t:1527635812602};\\\", \\\"{x:1476,y:827,t:1527635812635};\\\", \\\"{x:1476,y:830,t:1527635812670};\\\", \\\"{x:1477,y:832,t:1527635812687};\\\", \\\"{x:1479,y:844,t:1527635812704};\\\", \\\"{x:1481,y:853,t:1527635812721};\\\", \\\"{x:1483,y:863,t:1527635812737};\\\", \\\"{x:1484,y:870,t:1527635812753};\\\", \\\"{x:1485,y:879,t:1527635812771};\\\", \\\"{x:1486,y:886,t:1527635812787};\\\", \\\"{x:1487,y:892,t:1527635812804};\\\", \\\"{x:1488,y:897,t:1527635812821};\\\", \\\"{x:1488,y:898,t:1527635812836};\\\", \\\"{x:1488,y:902,t:1527635812854};\\\", \\\"{x:1488,y:906,t:1527635812871};\\\", \\\"{x:1488,y:912,t:1527635812888};\\\", \\\"{x:1488,y:913,t:1527635812904};\\\", \\\"{x:1488,y:918,t:1527635812921};\\\", \\\"{x:1488,y:921,t:1527635812938};\\\", \\\"{x:1488,y:923,t:1527635812954};\\\", \\\"{x:1488,y:925,t:1527635812972};\\\", \\\"{x:1489,y:928,t:1527635812988};\\\", \\\"{x:1489,y:931,t:1527635813004};\\\", \\\"{x:1489,y:934,t:1527635813021};\\\", \\\"{x:1491,y:936,t:1527635813037};\\\", \\\"{x:1492,y:940,t:1527635813054};\\\", \\\"{x:1492,y:941,t:1527635813089};\\\", \\\"{x:1492,y:942,t:1527635813104};\\\", \\\"{x:1492,y:943,t:1527635813298};\\\", \\\"{x:1492,y:944,t:1527635813305};\\\", \\\"{x:1492,y:946,t:1527635813321};\\\", \\\"{x:1492,y:947,t:1527635813353};\\\", \\\"{x:1492,y:948,t:1527635813361};\\\", \\\"{x:1492,y:949,t:1527635813377};\\\", \\\"{x:1492,y:950,t:1527635813393};\\\", \\\"{x:1492,y:951,t:1527635813405};\\\", \\\"{x:1492,y:952,t:1527635813422};\\\", \\\"{x:1492,y:953,t:1527635813440};\\\", \\\"{x:1492,y:954,t:1527635813455};\\\", \\\"{x:1493,y:955,t:1527635813472};\\\", \\\"{x:1493,y:956,t:1527635813497};\\\", \\\"{x:1493,y:957,t:1527635813513};\\\", \\\"{x:1493,y:958,t:1527635813529};\\\", \\\"{x:1493,y:959,t:1527635813561};\\\", \\\"{x:1493,y:960,t:1527635813576};\\\", \\\"{x:1493,y:961,t:1527635813588};\\\", \\\"{x:1493,y:963,t:1527635813606};\\\", \\\"{x:1493,y:964,t:1527635813625};\\\", \\\"{x:1493,y:966,t:1527635813648};\\\", \\\"{x:1493,y:967,t:1527635813664};\\\", \\\"{x:1493,y:969,t:1527635813672};\\\", \\\"{x:1492,y:970,t:1527635813696};\\\", \\\"{x:1492,y:971,t:1527635813711};\\\", \\\"{x:1491,y:971,t:1527635813897};\\\", \\\"{x:1490,y:971,t:1527635813961};\\\", \\\"{x:1490,y:970,t:1527635814073};\\\", \\\"{x:1490,y:969,t:1527635814089};\\\", \\\"{x:1490,y:968,t:1527635814154};\\\", \\\"{x:1491,y:967,t:1527635814217};\\\", \\\"{x:1491,y:966,t:1527635814249};\\\", \\\"{x:1492,y:966,t:1527635814273};\\\", \\\"{x:1492,y:965,t:1527635814290};\\\", \\\"{x:1493,y:964,t:1527635814306};\\\", \\\"{x:1493,y:963,t:1527635814322};\\\", \\\"{x:1494,y:962,t:1527635814339};\\\", \\\"{x:1495,y:959,t:1527635814356};\\\", \\\"{x:1495,y:958,t:1527635814372};\\\", \\\"{x:1495,y:955,t:1527635814390};\\\", \\\"{x:1495,y:951,t:1527635814405};\\\", \\\"{x:1495,y:949,t:1527635814422};\\\", \\\"{x:1496,y:947,t:1527635814439};\\\", \\\"{x:1496,y:944,t:1527635814455};\\\", \\\"{x:1496,y:940,t:1527635814472};\\\", \\\"{x:1497,y:939,t:1527635814489};\\\", \\\"{x:1497,y:937,t:1527635814505};\\\", \\\"{x:1497,y:935,t:1527635814521};\\\", \\\"{x:1497,y:933,t:1527635814539};\\\", \\\"{x:1497,y:931,t:1527635814554};\\\", \\\"{x:1497,y:928,t:1527635814572};\\\", \\\"{x:1497,y:926,t:1527635814589};\\\", \\\"{x:1497,y:925,t:1527635814604};\\\", \\\"{x:1497,y:922,t:1527635814622};\\\", \\\"{x:1497,y:919,t:1527635814639};\\\", \\\"{x:1497,y:918,t:1527635814655};\\\", \\\"{x:1497,y:915,t:1527635814672};\\\", \\\"{x:1497,y:913,t:1527635814689};\\\", \\\"{x:1496,y:911,t:1527635814705};\\\", \\\"{x:1496,y:910,t:1527635814722};\\\", \\\"{x:1496,y:909,t:1527635814739};\\\", \\\"{x:1495,y:908,t:1527635814756};\\\", \\\"{x:1495,y:907,t:1527635814772};\\\", \\\"{x:1494,y:906,t:1527635814800};\\\", \\\"{x:1494,y:905,t:1527635814817};\\\", \\\"{x:1494,y:904,t:1527635814865};\\\", \\\"{x:1494,y:903,t:1527635815465};\\\", \\\"{x:1492,y:902,t:1527635816929};\\\", \\\"{x:1491,y:900,t:1527635816940};\\\", \\\"{x:1482,y:899,t:1527635816958};\\\", \\\"{x:1455,y:895,t:1527635816974};\\\", \\\"{x:1423,y:890,t:1527635816990};\\\", \\\"{x:1357,y:881,t:1527635817007};\\\", \\\"{x:1211,y:862,t:1527635817024};\\\", \\\"{x:1111,y:848,t:1527635817041};\\\", \\\"{x:1011,y:832,t:1527635817057};\\\", \\\"{x:920,y:821,t:1527635817075};\\\", \\\"{x:862,y:806,t:1527635817090};\\\", \\\"{x:816,y:797,t:1527635817107};\\\", \\\"{x:780,y:782,t:1527635817123};\\\", \\\"{x:760,y:771,t:1527635817141};\\\", \\\"{x:747,y:763,t:1527635817157};\\\", \\\"{x:739,y:757,t:1527635817174};\\\", \\\"{x:736,y:754,t:1527635817191};\\\", \\\"{x:731,y:746,t:1527635817207};\\\", \\\"{x:715,y:720,t:1527635817224};\\\", \\\"{x:703,y:702,t:1527635817240};\\\", \\\"{x:694,y:693,t:1527635817257};\\\", \\\"{x:689,y:690,t:1527635817274};\\\", \\\"{x:686,y:689,t:1527635817291};\\\", \\\"{x:685,y:688,t:1527635817307};\\\", \\\"{x:683,y:687,t:1527635817324};\\\", \\\"{x:674,y:684,t:1527635817341};\\\", \\\"{x:658,y:681,t:1527635817357};\\\", \\\"{x:620,y:675,t:1527635817374};\\\", \\\"{x:542,y:666,t:1527635817391};\\\", \\\"{x:493,y:662,t:1527635817408};\\\", \\\"{x:422,y:655,t:1527635817424};\\\", \\\"{x:396,y:652,t:1527635817441};\\\", \\\"{x:388,y:651,t:1527635817459};\\\", \\\"{x:393,y:646,t:1527635817511};\\\", \\\"{x:403,y:639,t:1527635817527};\\\", \\\"{x:428,y:627,t:1527635817547};\\\", \\\"{x:474,y:603,t:1527635817565};\\\", \\\"{x:522,y:578,t:1527635817581};\\\", \\\"{x:574,y:547,t:1527635817598};\\\", \\\"{x:595,y:533,t:1527635817614};\\\", \\\"{x:617,y:518,t:1527635817632};\\\", \\\"{x:637,y:507,t:1527635817647};\\\", \\\"{x:650,y:499,t:1527635817665};\\\", \\\"{x:667,y:489,t:1527635817681};\\\", \\\"{x:681,y:482,t:1527635817697};\\\", \\\"{x:702,y:471,t:1527635817715};\\\", \\\"{x:725,y:462,t:1527635817731};\\\", \\\"{x:749,y:458,t:1527635817747};\\\", \\\"{x:772,y:458,t:1527635817764};\\\", \\\"{x:791,y:458,t:1527635817781};\\\", \\\"{x:803,y:466,t:1527635817797};\\\", \\\"{x:813,y:473,t:1527635817814};\\\", \\\"{x:821,y:481,t:1527635817832};\\\", \\\"{x:831,y:486,t:1527635817848};\\\", \\\"{x:838,y:491,t:1527635817864};\\\", \\\"{x:844,y:495,t:1527635817881};\\\", \\\"{x:847,y:497,t:1527635817898};\\\", \\\"{x:849,y:499,t:1527635817914};\\\", \\\"{x:849,y:500,t:1527635817931};\\\", \\\"{x:849,y:501,t:1527635818056};\\\", \\\"{x:849,y:503,t:1527635818069};\\\", \\\"{x:849,y:504,t:1527635818081};\\\", \\\"{x:846,y:506,t:1527635818098};\\\", \\\"{x:844,y:507,t:1527635818114};\\\", \\\"{x:842,y:509,t:1527635818131};\\\", \\\"{x:840,y:511,t:1527635818148};\\\", \\\"{x:839,y:511,t:1527635818173};\\\", \\\"{x:839,y:512,t:1527635818180};\\\", \\\"{x:838,y:513,t:1527635818205};\\\", \\\"{x:837,y:513,t:1527635818221};\\\", \\\"{x:837,y:514,t:1527635818231};\\\", \\\"{x:836,y:514,t:1527635818253};\\\", \\\"{x:834,y:516,t:1527635818678};\\\", \\\"{x:832,y:518,t:1527635818685};\\\", \\\"{x:826,y:521,t:1527635818699};\\\", \\\"{x:815,y:527,t:1527635818717};\\\", \\\"{x:807,y:534,t:1527635818732};\\\", \\\"{x:799,y:541,t:1527635818749};\\\", \\\"{x:788,y:548,t:1527635818765};\\\", \\\"{x:786,y:550,t:1527635818782};\\\", \\\"{x:786,y:553,t:1527635818799};\\\", \\\"{x:783,y:557,t:1527635818815};\\\", \\\"{x:779,y:561,t:1527635818832};\\\", \\\"{x:778,y:562,t:1527635818848};\\\", \\\"{x:778,y:563,t:1527635818865};\\\", \\\"{x:777,y:563,t:1527635818882};\\\", \\\"{x:776,y:564,t:1527635818898};\\\", \\\"{x:775,y:564,t:1527635818915};\\\", \\\"{x:773,y:567,t:1527635818933};\\\", \\\"{x:772,y:567,t:1527635818948};\\\", \\\"{x:770,y:569,t:1527635818965};\\\", \\\"{x:769,y:570,t:1527635818983};\\\", \\\"{x:769,y:572,t:1527635818998};\\\", \\\"{x:767,y:574,t:1527635819015};\\\", \\\"{x:766,y:575,t:1527635819031};\\\", \\\"{x:762,y:580,t:1527635819048};\\\", \\\"{x:761,y:583,t:1527635819065};\\\", \\\"{x:759,y:586,t:1527635819082};\\\", \\\"{x:757,y:589,t:1527635819098};\\\", \\\"{x:756,y:591,t:1527635819115};\\\", \\\"{x:755,y:593,t:1527635819132};\\\", \\\"{x:755,y:595,t:1527635819148};\\\", \\\"{x:754,y:598,t:1527635819165};\\\", \\\"{x:752,y:600,t:1527635819182};\\\", \\\"{x:751,y:601,t:1527635819200};\\\", \\\"{x:751,y:603,t:1527635819215};\\\", \\\"{x:748,y:607,t:1527635819232};\\\", \\\"{x:748,y:610,t:1527635819251};\\\", \\\"{x:745,y:614,t:1527635819265};\\\", \\\"{x:743,y:616,t:1527635819283};\\\", \\\"{x:742,y:619,t:1527635819299};\\\", \\\"{x:741,y:622,t:1527635819315};\\\", \\\"{x:740,y:625,t:1527635819333};\\\", \\\"{x:736,y:634,t:1527635819349};\\\", \\\"{x:734,y:636,t:1527635819365};\\\", \\\"{x:732,y:640,t:1527635819382};\\\", \\\"{x:732,y:641,t:1527635819399};\\\", \\\"{x:732,y:644,t:1527635819415};\\\", \\\"{x:732,y:646,t:1527635819433};\\\", \\\"{x:732,y:647,t:1527635819461};\\\", \\\"{x:732,y:649,t:1527635819493};\\\", \\\"{x:732,y:650,t:1527635819501};\\\", \\\"{x:732,y:652,t:1527635819525};\\\", \\\"{x:731,y:653,t:1527635819533};\\\", \\\"{x:731,y:654,t:1527635819549};\\\", \\\"{x:730,y:656,t:1527635819566};\\\", \\\"{x:730,y:657,t:1527635819582};\\\", \\\"{x:730,y:659,t:1527635819600};\\\", \\\"{x:730,y:660,t:1527635819615};\\\", \\\"{x:729,y:662,t:1527635819632};\\\", \\\"{x:729,y:663,t:1527635819649};\\\", \\\"{x:728,y:665,t:1527635819666};\\\", \\\"{x:728,y:666,t:1527635819682};\\\", \\\"{x:728,y:667,t:1527635819717};\\\", \\\"{x:727,y:669,t:1527635819732};\\\", \\\"{x:726,y:671,t:1527635819766};\\\", \\\"{x:726,y:672,t:1527635819789};\\\", \\\"{x:725,y:673,t:1527635819800};\\\", \\\"{x:724,y:674,t:1527635819816};\\\", \\\"{x:723,y:675,t:1527635819833};\\\", \\\"{x:722,y:676,t:1527635819850};\\\", \\\"{x:721,y:677,t:1527635819866};\\\", \\\"{x:720,y:678,t:1527635819882};\\\", \\\"{x:718,y:681,t:1527635819900};\\\", \\\"{x:715,y:685,t:1527635819916};\\\", \\\"{x:709,y:690,t:1527635819933};\\\", \\\"{x:706,y:692,t:1527635819949};\\\", \\\"{x:702,y:695,t:1527635819967};\\\", \\\"{x:701,y:697,t:1527635819983};\\\", \\\"{x:698,y:699,t:1527635820000};\\\", \\\"{x:693,y:703,t:1527635820016};\\\", \\\"{x:690,y:706,t:1527635820033};\\\", \\\"{x:683,y:711,t:1527635820049};\\\", \\\"{x:680,y:712,t:1527635820066};\\\", \\\"{x:675,y:715,t:1527635820084};\\\", \\\"{x:671,y:718,t:1527635820100};\\\", \\\"{x:668,y:721,t:1527635820117};\\\", \\\"{x:666,y:724,t:1527635820133};\\\", \\\"{x:666,y:725,t:1527635820149};\\\", \\\"{x:665,y:728,t:1527635820167};\\\", \\\"{x:664,y:730,t:1527635820189};\\\", \\\"{x:663,y:730,t:1527635820200};\\\", \\\"{x:663,y:731,t:1527635820217};\\\", \\\"{x:663,y:732,t:1527635820246};\\\", \\\"{x:662,y:733,t:1527635820278};\\\", \\\"{x:662,y:734,t:1527635820293};\\\", \\\"{x:661,y:734,t:1527635820310};\\\", \\\"{x:661,y:735,t:1527635820318};\\\", \\\"{x:660,y:738,t:1527635820334};\\\", \\\"{x:659,y:739,t:1527635820398};\\\", \\\"{x:659,y:740,t:1527635820438};\\\", \\\"{x:659,y:741,t:1527635820451};\\\", \\\"{x:659,y:742,t:1527635820477};\\\", \\\"{x:659,y:743,t:1527635820493};\\\", \\\"{x:659,y:744,t:1527635820509};\\\", \\\"{x:659,y:745,t:1527635820532};\\\", \\\"{x:659,y:746,t:1527635820565};\\\", \\\"{x:659,y:747,t:1527635820573};\\\", \\\"{x:659,y:748,t:1527635820597};\\\", \\\"{x:658,y:749,t:1527635820605};\\\", \\\"{x:658,y:750,t:1527635820616};\\\", \\\"{x:657,y:751,t:1527635820634};\\\", \\\"{x:657,y:752,t:1527635820651};\\\", \\\"{x:656,y:753,t:1527635820666};\\\", \\\"{x:656,y:755,t:1527635820774};\\\", \\\"{x:656,y:756,t:1527635820806};\\\", \\\"{x:656,y:758,t:1527635821286};\\\", \\\"{x:655,y:758,t:1527635821966};\\\", \\\"{x:654,y:758,t:1527635822062};\\\", \\\"{x:655,y:758,t:1527635823726};\\\", \\\"{x:656,y:758,t:1527635823736};\\\", \\\"{x:657,y:759,t:1527635823774};\\\", \\\"{x:658,y:759,t:1527635824047};\\\", \\\"{x:659,y:759,t:1527635824142};\\\", \\\"{x:660,y:759,t:1527635824158};\\\", \\\"{x:662,y:759,t:1527635824308};\\\", \\\"{x:663,y:759,t:1527635824413};\\\", \\\"{x:665,y:760,t:1527635824437};\\\", \\\"{x:666,y:760,t:1527635824526};\\\", \\\"{x:668,y:760,t:1527635825734};\\\", \\\"{x:669,y:760,t:1527635825806};\\\", \\\"{x:669,y:759,t:1527635825822};\\\", \\\"{x:669,y:758,t:1527635827142};\\\", \\\"{x:669,y:757,t:1527635827156};\\\", \\\"{x:667,y:756,t:1527635827173};\\\", \\\"{x:666,y:751,t:1527635827189};\\\", \\\"{x:660,y:743,t:1527635827206};\\\", \\\"{x:652,y:730,t:1527635827223};\\\", \\\"{x:646,y:719,t:1527635827239};\\\", \\\"{x:634,y:701,t:1527635827256};\\\", \\\"{x:621,y:685,t:1527635827273};\\\", \\\"{x:613,y:676,t:1527635827290};\\\", \\\"{x:608,y:666,t:1527635827306};\\\", \\\"{x:604,y:650,t:1527635827323};\\\", \\\"{x:604,y:636,t:1527635827341};\\\", \\\"{x:604,y:621,t:1527635827355};\\\", \\\"{x:604,y:603,t:1527635827373};\\\", \\\"{x:604,y:599,t:1527635827387};\\\", \\\"{x:604,y:587,t:1527635827405};\\\", \\\"{x:603,y:581,t:1527635827420};\\\", \\\"{x:603,y:577,t:1527635827438};\\\", \\\"{x:603,y:571,t:1527635827455};\\\", \\\"{x:602,y:568,t:1527635827472};\\\", \\\"{x:600,y:561,t:1527635827489};\\\", \\\"{x:600,y:556,t:1527635827506};\\\", \\\"{x:599,y:552,t:1527635827522};\\\", \\\"{x:599,y:545,t:1527635827538};\\\", \\\"{x:599,y:540,t:1527635827555};\\\", \\\"{x:599,y:531,t:1527635827573};\\\", \\\"{x:599,y:525,t:1527635827588};\\\", \\\"{x:599,y:518,t:1527635827605};\\\", \\\"{x:598,y:514,t:1527635827622};\\\", \\\"{x:597,y:510,t:1527635827638};\\\", \\\"{x:597,y:509,t:1527635827656};\\\", \\\"{x:596,y:508,t:1527635827677};\\\", \\\"{x:596,y:507,t:1527635827766};\\\", \\\"{x:597,y:507,t:1527635827782};\\\", \\\"{x:598,y:507,t:1527635827910};\\\", \\\"{x:599,y:507,t:1527635827939};\\\", \\\"{x:599,y:507,t:1527635828005};\\\", \\\"{x:597,y:512,t:1527635828093};\\\", \\\"{x:594,y:516,t:1527635828106};\\\", \\\"{x:593,y:525,t:1527635828121};\\\", \\\"{x:589,y:536,t:1527635828139};\\\", \\\"{x:586,y:552,t:1527635828156};\\\", \\\"{x:586,y:570,t:1527635828173};\\\", \\\"{x:586,y:594,t:1527635828189};\\\", \\\"{x:586,y:603,t:1527635828206};\\\", \\\"{x:586,y:612,t:1527635828223};\\\", \\\"{x:587,y:623,t:1527635828240};\\\", \\\"{x:590,y:635,t:1527635828256};\\\", \\\"{x:591,y:646,t:1527635828274};\\\", \\\"{x:592,y:653,t:1527635828290};\\\", \\\"{x:592,y:661,t:1527635828306};\\\", \\\"{x:594,y:667,t:1527635828322};\\\", \\\"{x:595,y:672,t:1527635828340};\\\", \\\"{x:595,y:674,t:1527635828357};\\\", \\\"{x:596,y:673,t:1527635828446};\\\", \\\"{x:599,y:668,t:1527635828457};\\\", \\\"{x:605,y:652,t:1527635828472};\\\", \\\"{x:609,y:636,t:1527635828491};\\\", \\\"{x:611,y:617,t:1527635828507};\\\", \\\"{x:617,y:599,t:1527635828524};\\\", \\\"{x:620,y:586,t:1527635828540};\\\", \\\"{x:624,y:574,t:1527635828557};\\\", \\\"{x:627,y:561,t:1527635828573};\\\", \\\"{x:630,y:545,t:1527635828589};\\\", \\\"{x:631,y:541,t:1527635828607};\\\", \\\"{x:631,y:539,t:1527635828623};\\\", \\\"{x:631,y:538,t:1527635828832};\\\", \\\"{x:631,y:537,t:1527635828841};\\\", \\\"{x:630,y:537,t:1527635828894};\\\", \\\"{x:629,y:537,t:1527635828910};\\\", \\\"{x:627,y:537,t:1527635828924};\\\", \\\"{x:626,y:537,t:1527635828950};\\\", \\\"{x:626,y:536,t:1527635828998};\\\", \\\"{x:625,y:536,t:1527635829021};\\\", \\\"{x:624,y:536,t:1527635829030};\\\", \\\"{x:624,y:535,t:1527635829206};\\\", \\\"{x:624,y:534,t:1527635829262};\\\", \\\"{x:624,y:533,t:1527635829274};\\\", \\\"{x:625,y:532,t:1527635829310};\\\", \\\"{x:625,y:530,t:1527635829343};\\\", \\\"{x:625,y:529,t:1527635829373};\\\", \\\"{x:625,y:528,t:1527635829405};\\\", \\\"{x:625,y:527,t:1527635829420};\\\", \\\"{x:625,y:526,t:1527635829436};\\\", \\\"{x:624,y:526,t:1527635829485};\\\", \\\"{x:623,y:526,t:1527635829533};\\\", \\\"{x:623,y:525,t:1527635829541};\\\", \\\"{x:622,y:524,t:1527635829557};\\\", \\\"{x:620,y:524,t:1527635829614};\\\", \\\"{x:619,y:524,t:1527635829662};\\\", \\\"{x:618,y:524,t:1527635829678};\\\", \\\"{x:617,y:523,t:1527635829710};\\\", \\\"{x:616,y:523,t:1527635829734};\\\", \\\"{x:615,y:523,t:1527635829741};\\\", \\\"{x:614,y:522,t:1527635829766};\\\", \\\"{x:613,y:522,t:1527635829814};\\\", \\\"{x:611,y:522,t:1527635829837};\\\", \\\"{x:611,y:521,t:1527635829862};\\\", \\\"{x:609,y:521,t:1527635829877};\\\", \\\"{x:608,y:521,t:1527635829934};\\\", \\\"{x:606,y:522,t:1527635830526};\\\", \\\"{x:601,y:528,t:1527635830542};\\\", \\\"{x:597,y:537,t:1527635830558};\\\", \\\"{x:594,y:545,t:1527635830575};\\\", \\\"{x:591,y:556,t:1527635830591};\\\", \\\"{x:590,y:567,t:1527635830608};\\\", \\\"{x:588,y:577,t:1527635830625};\\\", \\\"{x:586,y:587,t:1527635830642};\\\", \\\"{x:585,y:598,t:1527635830657};\\\", \\\"{x:583,y:608,t:1527635830675};\\\", \\\"{x:580,y:621,t:1527635830692};\\\", \\\"{x:576,y:636,t:1527635830708};\\\", \\\"{x:568,y:655,t:1527635830726};\\\", \\\"{x:565,y:665,t:1527635830741};\\\", \\\"{x:563,y:675,t:1527635830758};\\\", \\\"{x:562,y:685,t:1527635830774};\\\", \\\"{x:560,y:696,t:1527635830791};\\\", \\\"{x:558,y:705,t:1527635830808};\\\", \\\"{x:553,y:714,t:1527635830824};\\\", \\\"{x:551,y:718,t:1527635830842};\\\", \\\"{x:548,y:721,t:1527635830859};\\\", \\\"{x:548,y:725,t:1527635830874};\\\", \\\"{x:545,y:728,t:1527635830891};\\\", \\\"{x:543,y:730,t:1527635830909};\\\", \\\"{x:542,y:731,t:1527635830925};\\\", \\\"{x:541,y:732,t:1527635830942};\\\", \\\"{x:540,y:733,t:1527635830959};\\\", \\\"{x:539,y:734,t:1527635830976};\\\", \\\"{x:537,y:735,t:1527635831005};\\\", \\\"{x:537,y:736,t:1527635831013};\\\", \\\"{x:536,y:737,t:1527635831025};\\\", \\\"{x:535,y:738,t:1527635831042};\\\", \\\"{x:533,y:739,t:1527635831058};\\\", \\\"{x:533,y:740,t:1527635831075};\\\", \\\"{x:532,y:740,t:1527635831092};\\\", \\\"{x:531,y:742,t:1527635831109};\\\", \\\"{x:531,y:743,t:1527635831766};\\\", \\\"{x:532,y:743,t:1527635831776};\\\", \\\"{x:534,y:743,t:1527635831792};\\\", \\\"{x:536,y:743,t:1527635831809};\\\", \\\"{x:537,y:743,t:1527635831854};\\\", \\\"{x:538,y:743,t:1527635831885};\\\", \\\"{x:539,y:743,t:1527635831893};\\\", \\\"{x:540,y:743,t:1527635831917};\\\", \\\"{x:541,y:743,t:1527635832006};\\\", \\\"{x:542,y:743,t:1527635832029};\\\", \\\"{x:543,y:743,t:1527635832093};\\\", \\\"{x:544,y:742,t:1527635832118};\\\", \\\"{x:545,y:742,t:1527635832126};\\\", \\\"{x:545,y:741,t:1527635832143};\\\", \\\"{x:545,y:740,t:1527635832159};\\\", \\\"{x:546,y:738,t:1527635832176};\\\", \\\"{x:548,y:736,t:1527635832193};\\\", \\\"{x:549,y:735,t:1527635832209};\\\", \\\"{x:549,y:734,t:1527635832226};\\\", \\\"{x:549,y:733,t:1527635832243};\\\", \\\"{x:550,y:733,t:1527635832259};\\\", \\\"{x:550,y:731,t:1527635832285};\\\", \\\"{x:551,y:730,t:1527635832325};\\\" ] }, { \\\"rt\\\": 46523, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 540871, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"DK1EM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"F and B, make a vertical line at 12pm and look for the points in the line.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 10633, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"29\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"South Korea\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 552510, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"DK1EM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 15539, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Other\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fourth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Natural Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 569063, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"DK1EM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 4049, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 581846, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"DK1EM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\" } ]\",\"parentNode\":{\"id\":2773}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"DK1EM\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"line\",\"attributes\":{\"x1\":\"400\",\"x2\":\"0\",\"y1\":\"0\",\"y2\":\"800\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-65) translate(-200,280)\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2412,\"textContent\":\"DURATION (in hours)\"}]}]},{\"nodeType\":1,\"id\":2413,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2414,\"tagName\":\"text\",\"attributes\":{\"x\":\"-1.6666666666666714\",\"y\":\"738.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2415,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2416,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2417,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"33.33333333333333\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"text\",\"attributes\":{\"x\":\"31.666666666666657\",\"y\":\"671.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2420,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2421,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2422,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"66.66666666666666\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"x\":\"65\",\"y\":\"605\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"100\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2429,\"tagName\":\"text\",\"attributes\":{\"x\":\"98.33333333333331\",\"y\":\"538.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2430,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2432,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"133.33333333333331\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2434,\"tagName\":\"text\",\"attributes\":{\"x\":\"131.66666666666669\",\"y\":\"471.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2435,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2436,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2437,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"166.66666666666669\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"text\",\"attributes\":{\"x\":\"165\",\"y\":\"405\"},\"childNodes\":[{\"nodeType\":3,\"id\":2440,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2441,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2442,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"200\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2443,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"x\":\"198.33333333333334\",\"y\":\"338.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"233.33333333333334\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2448,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2449,\"tagName\":\"text\",\"attributes\":{\"x\":\"231.66666666666663\",\"y\":\"271.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2450,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2451,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2452,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"266.66666666666663\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2453,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2454,\"tagName\":\"text\",\"attributes\":{\"x\":\"265\",\"y\":\"205\"},\"childNodes\":[{\"nodeType\":3,\"id\":2455,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2456,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2457,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"300\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"text\",\"attributes\":{\"x\":\"298.33333333333337\",\"y\":\"138.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2460,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2461,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2462,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"333.33333333333337\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2463,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2464,\"tagName\":\"text\",\"attributes\":{\"x\":\"331.66666666666663\",\"y\":\"71.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2465,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"366.66666666666663\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"text\",\"attributes\":{\"x\":\"365\",\"y\":\"5\"},\"childNodes\":[{\"nodeType\":3,\"id\":2470,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2471,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2472,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2473,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2492,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2494,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2496,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2498,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2523,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2588,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2589,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2590,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2591,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2592,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2593,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2594,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2595,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2596,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2597,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2598},{\"nodeType\":3,\"id\":2599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2600,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2601,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2602,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2603,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 162, dom: 579, initialDom: 631",
  "javascriptErrors": []
}