var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["060426282f20035e30412c865ca7882dc8f524ee"] = {
  "startTime": "2018-06-04T20:16:27.262885Z",
  "websitePageUrl": "/",
  "visitTime": 62030,
  "engagementTime": 47363,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1105,
  "tags": [],
  "session": {
    "id": "4c525c17be43440a3eb8fd787c1e6202",
    "created": "2018-06-04T20:16:27.1809958+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 2,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko",
    "browser": "IE",
    "browserVersion": "11.0",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "f8bc890ce6a0356802a8765487c1bc07",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/4c525c17be43440a3eb8fd787c1e6202/play"
  },
  "events": [
    {
      "t": 10,
      "e": 10,
      "ty": 14,
      "x": 0,
      "y": 1105
    },
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 1920,
      "y": 1105
    },
    {
      "t": 100,
      "e": 100,
      "ty": 2,
      "x": 872,
      "y": 83
    },
    {
      "t": 281,
      "e": 281,
      "ty": 41,
      "x": 29763,
      "y": 4922,
      "ta": "html"
    },
    {
      "t": 2703,
      "e": 2703,
      "ty": 2,
      "x": 871,
      "y": 83
    },
    {
      "t": 2753,
      "e": 2753,
      "ty": 41,
      "x": 29729,
      "y": 4922,
      "ta": "html"
    },
    {
      "t": 2802,
      "e": 2802,
      "ty": 2,
      "x": 838,
      "y": 75
    },
    {
      "t": 2902,
      "e": 2902,
      "ty": 2,
      "x": 699,
      "y": 53
    },
    {
      "t": 3012,
      "e": 3012,
      "ty": 41,
      "x": 23858,
      "y": 3143,
      "ta": "html"
    },
    {
      "t": 3203,
      "e": 3203,
      "ty": 2,
      "x": 698,
      "y": 53
    },
    {
      "t": 3253,
      "e": 3253,
      "ty": 41,
      "x": 23824,
      "y": 3143,
      "ta": "html"
    },
    {
      "t": 3503,
      "e": 3503,
      "ty": 41,
      "x": 23790,
      "y": 3143,
      "ta": "html"
    },
    {
      "t": 3503,
      "e": 3503,
      "ty": 2,
      "x": 697,
      "y": 53
    },
    {
      "t": 4003,
      "e": 4003,
      "ty": 2,
      "x": 696,
      "y": 53
    },
    {
      "t": 4003,
      "e": 4003,
      "ty": 41,
      "x": 23756,
      "y": 3143,
      "ta": "html"
    },
    {
      "t": 4204,
      "e": 4204,
      "ty": 2,
      "x": 599,
      "y": 53
    },
    {
      "t": 4253,
      "e": 4253,
      "ty": 41,
      "x": 19831,
      "y": 3261,
      "ta": "html"
    },
    {
      "t": 4303,
      "e": 4303,
      "ty": 2,
      "x": 581,
      "y": 55
    },
    {
      "t": 4604,
      "e": 4604,
      "ty": 2,
      "x": 580,
      "y": 55
    },
    {
      "t": 4771,
      "e": 4771,
      "ty": 41,
      "x": 19797,
      "y": 3261,
      "ta": "html"
    },
    {
      "t": 10010,
      "e": 9771,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 14612,
      "e": 9771,
      "ty": 2,
      "x": 577,
      "y": 36
    },
    {
      "t": 14712,
      "e": 9871,
      "ty": 2,
      "x": 430,
      "y": 4
    },
    {
      "t": 14755,
      "e": 9914,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 14763,
      "e": 9922,
      "ty": 41,
      "x": 14677,
      "y": 237,
      "ta": "html"
    },
    {
      "t": 15763,
      "e": 10922,
      "ty": 41,
      "x": 29866,
      "y": 652,
      "ta": "html"
    },
    {
      "t": 15813,
      "e": 10972,
      "ty": 2,
      "x": 946,
      "y": 11
    },
    {
      "t": 16013,
      "e": 11172,
      "ty": 2,
      "x": 827,
      "y": 10
    },
    {
      "t": 16014,
      "e": 11173,
      "ty": 41,
      "x": 28227,
      "y": 593,
      "ta": "html"
    },
    {
      "t": 16130,
      "e": 11289,
      "ty": 2,
      "x": 821,
      "y": 7
    },
    {
      "t": 16214,
      "e": 11373,
      "ty": 2,
      "x": 825,
      "y": 0
    },
    {
      "t": 16264,
      "e": 11423,
      "ty": 41,
      "x": 28159,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 16314,
      "e": 11473,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 17631,
      "e": 12790,
      "ty": 2,
      "x": 846,
      "y": 4
    },
    {
      "t": 17710,
      "e": 12869,
      "ty": 2,
      "x": 846,
      "y": 7
    },
    {
      "t": 17756,
      "e": 12915,
      "ty": 41,
      "x": 28876,
      "y": 415,
      "ta": "html"
    },
    {
      "t": 17905,
      "e": 13064,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 20006,
      "e": 15165,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 41811,
      "e": 18064,
      "ty": 0,
      "x": 1920,
      "y": 1083
    },
    {
      "t": 43738,
      "e": 19991,
      "ty": 0,
      "x": 1920,
      "y": 1105
    },
    {
      "t": 50004,
      "e": 24991,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 52026,
      "e": 38677,
      "ty": 2,
      "x": 261,
      "y": 1
    },
    {
      "t": 52026,
      "e": 38677,
      "ty": 41,
      "x": 8908,
      "y": 59,
      "ta": "html"
    },
    {
      "t": 52259,
      "e": 38910,
      "ty": 41,
      "x": 8908,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 52309,
      "e": 38960,
      "ty": 2,
      "x": 261,
      "y": 0
    },
    {
      "t": 52318,
      "e": 38969,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 53897,
      "e": 40548,
      "ty": 0,
      "x": 1920,
      "y": 1083
    },
    {
      "t": 55712,
      "e": 42363,
      "ty": 0,
      "x": 1920,
      "y": 1105
    },
    {
      "t": 62030,
      "e": 47363,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"rel\":\"stylesheet\",\"media\":\"all\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 133, dom: 133, initialDom: 197",
  "javascriptErrors": []
}