var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["060429888753bb01c93bcf8ae9ab5f654558b2a8"] = {
  "startTime": "2018-06-04T20:17:29.6176793Z",
  "websitePageUrl": "/",
  "visitTime": 20003,
  "engagementTime": 18322,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1105,
  "tags": [],
  "session": {
    "id": "4c525c17be43440a3eb8fd787c1e6202",
    "created": "2018-06-04T20:16:27.1809958+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 2,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko",
    "browser": "IE",
    "browserVersion": "11.0",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "f8bc890ce6a0356802a8765487c1bc07",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/4c525c17be43440a3eb8fd787c1e6202/play"
  },
  "events": [
    {
      "t": 19,
      "e": 19,
      "ty": 14,
      "x": 0,
      "y": 1105
    },
    {
      "t": 106,
      "e": 106,
      "ty": 0,
      "x": 1920,
      "y": 1105
    },
    {
      "t": 106,
      "e": 106,
      "ty": 2,
      "x": 490,
      "y": 464
    },
    {
      "t": 261,
      "e": 261,
      "ty": 41,
      "x": 16725,
      "y": 27518,
      "ta": "html"
    },
    {
      "t": 601,
      "e": 601,
      "ty": 2,
      "x": 491,
      "y": 457
    },
    {
      "t": 756,
      "e": 756,
      "ty": 41,
      "x": 16759,
      "y": 27103,
      "ta": "html"
    },
    {
      "t": 801,
      "e": 801,
      "ty": 2,
      "x": 493,
      "y": 455
    },
    {
      "t": 904,
      "e": 904,
      "ty": 2,
      "x": 494,
      "y": 455
    },
    {
      "t": 1008,
      "e": 1008,
      "ty": 2,
      "x": 496,
      "y": 451
    },
    {
      "t": 1009,
      "e": 1009,
      "ty": 41,
      "x": 16929,
      "y": 26747,
      "ta": "html"
    },
    {
      "t": 3400,
      "e": 3400,
      "ty": 2,
      "x": 494,
      "y": 449
    },
    {
      "t": 3504,
      "e": 3504,
      "ty": 2,
      "x": 1001,
      "y": 307
    },
    {
      "t": 3504,
      "e": 3504,
      "ty": 41,
      "x": 34166,
      "y": 18207,
      "ta": "html"
    },
    {
      "t": 3601,
      "e": 3601,
      "ty": 2,
      "x": 1105,
      "y": 339
    },
    {
      "t": 3704,
      "e": 3704,
      "ty": 2,
      "x": 1116,
      "y": 341
    },
    {
      "t": 3751,
      "e": 3751,
      "ty": 41,
      "x": 38092,
      "y": 20223,
      "ta": "html"
    },
    {
      "t": 6898,
      "e": 6898,
      "ty": 2,
      "x": 1120,
      "y": 341
    },
    {
      "t": 7007,
      "e": 7007,
      "ty": 2,
      "x": 1078,
      "y": 358
    },
    {
      "t": 7008,
      "e": 7008,
      "ty": 41,
      "x": 36795,
      "y": 21232,
      "ta": "html"
    },
    {
      "t": 7104,
      "e": 7104,
      "ty": 2,
      "x": 1064,
      "y": 384
    },
    {
      "t": 7260,
      "e": 7260,
      "ty": 41,
      "x": 36317,
      "y": 22774,
      "ta": "html"
    },
    {
      "t": 7510,
      "e": 7510,
      "ty": 2,
      "x": 1064,
      "y": 385
    },
    {
      "t": 7511,
      "e": 7511,
      "ty": 41,
      "x": 36317,
      "y": 22833,
      "ta": "html"
    },
    {
      "t": 7697,
      "e": 7697,
      "ty": 2,
      "x": 1064,
      "y": 386
    },
    {
      "t": 7760,
      "e": 7760,
      "ty": 41,
      "x": 36317,
      "y": 22892,
      "ta": "html"
    },
    {
      "t": 8113,
      "e": 8113,
      "ty": 2,
      "x": 1057,
      "y": 376
    },
    {
      "t": 8207,
      "e": 8207,
      "ty": 2,
      "x": 1027,
      "y": 338
    },
    {
      "t": 8255,
      "e": 8255,
      "ty": 41,
      "x": 33996,
      "y": 14174,
      "ta": "html"
    },
    {
      "t": 8303,
      "e": 8303,
      "ty": 2,
      "x": 991,
      "y": 208
    },
    {
      "t": 8399,
      "e": 8399,
      "ty": 2,
      "x": 964,
      "y": 112
    },
    {
      "t": 8496,
      "e": 8496,
      "ty": 2,
      "x": 927,
      "y": 30
    },
    {
      "t": 8511,
      "e": 8511,
      "ty": 41,
      "x": 31504,
      "y": 1423,
      "ta": "html"
    },
    {
      "t": 8607,
      "e": 8607,
      "ty": 2,
      "x": 923,
      "y": 22
    },
    {
      "t": 8763,
      "e": 8763,
      "ty": 41,
      "x": 31504,
      "y": 1304,
      "ta": "html"
    },
    {
      "t": 8808,
      "e": 8808,
      "ty": 2,
      "x": 956,
      "y": 7
    },
    {
      "t": 8903,
      "e": 8903,
      "ty": 2,
      "x": 963,
      "y": 3
    },
    {
      "t": 9007,
      "e": 9007,
      "ty": 2,
      "x": 964,
      "y": 0
    },
    {
      "t": 9008,
      "e": 9008,
      "ty": 41,
      "x": 32904,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 9040,
      "e": 9040,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 12407,
      "e": 12439,
      "ty": 2,
      "x": 0,
      "y": 159
    },
    {
      "t": 12503,
      "e": 12535,
      "ty": 2,
      "x": 10,
      "y": 129
    },
    {
      "t": 12503,
      "e": 12535,
      "ty": 41,
      "x": 341,
      "y": 7650,
      "ta": "html"
    },
    {
      "t": 12599,
      "e": 12631,
      "ty": 2,
      "x": 109,
      "y": 60
    },
    {
      "t": 12696,
      "e": 12728,
      "ty": 2,
      "x": 299,
      "y": 59
    },
    {
      "t": 12759,
      "e": 12791,
      "ty": 41,
      "x": 10478,
      "y": 3143,
      "ta": "html"
    },
    {
      "t": 12807,
      "e": 12839,
      "ty": 2,
      "x": 309,
      "y": 47
    },
    {
      "t": 12903,
      "e": 12935,
      "ty": 2,
      "x": 310,
      "y": 24
    },
    {
      "t": 13000,
      "e": 13032,
      "ty": 2,
      "x": 314,
      "y": 16
    },
    {
      "t": 13001,
      "e": 13033,
      "ty": 41,
      "x": 10717,
      "y": 948,
      "ta": "html"
    },
    {
      "t": 13113,
      "e": 13145,
      "ty": 2,
      "x": 318,
      "y": 11
    },
    {
      "t": 13207,
      "e": 13239,
      "ty": 2,
      "x": 325,
      "y": 2
    },
    {
      "t": 13237,
      "e": 13269,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 13253,
      "e": 13285,
      "ty": 41,
      "x": 11093,
      "y": 118,
      "ta": "html"
    },
    {
      "t": 13807,
      "e": 13839,
      "ty": 2,
      "x": 610,
      "y": 4
    },
    {
      "t": 13903,
      "e": 13935,
      "ty": 2,
      "x": 817,
      "y": 8
    },
    {
      "t": 13999,
      "e": 14031,
      "ty": 41,
      "x": 29729,
      "y": 1364,
      "ta": "html"
    },
    {
      "t": 14000,
      "e": 14032,
      "ty": 2,
      "x": 871,
      "y": 23
    },
    {
      "t": 14103,
      "e": 14135,
      "ty": 2,
      "x": 875,
      "y": 45
    },
    {
      "t": 14199,
      "e": 14231,
      "ty": 2,
      "x": 865,
      "y": 100
    },
    {
      "t": 14249,
      "e": 14281,
      "ty": 41,
      "x": 29320,
      "y": 7176,
      "ta": "html"
    },
    {
      "t": 14296,
      "e": 14328,
      "ty": 2,
      "x": 858,
      "y": 127
    },
    {
      "t": 14497,
      "e": 14529,
      "ty": 41,
      "x": 29047,
      "y": 8896,
      "ta": "html"
    },
    {
      "t": 14497,
      "e": 14529,
      "ty": 2,
      "x": 851,
      "y": 150
    },
    {
      "t": 14601,
      "e": 14633,
      "ty": 2,
      "x": 833,
      "y": 185
    },
    {
      "t": 14756,
      "e": 14788,
      "ty": 41,
      "x": 28432,
      "y": 10971,
      "ta": "html"
    },
    {
      "t": 14913,
      "e": 14945,
      "ty": 2,
      "x": 830,
      "y": 174
    },
    {
      "t": 15008,
      "e": 15040,
      "ty": 41,
      "x": 28159,
      "y": 9311,
      "ta": "html"
    },
    {
      "t": 15008,
      "e": 15040,
      "ty": 2,
      "x": 825,
      "y": 157
    },
    {
      "t": 15209,
      "e": 15241,
      "ty": 2,
      "x": 823,
      "y": 157
    },
    {
      "t": 15256,
      "e": 15288,
      "ty": 41,
      "x": 27988,
      "y": 9785,
      "ta": "html"
    },
    {
      "t": 15304,
      "e": 15336,
      "ty": 2,
      "x": 820,
      "y": 166
    },
    {
      "t": 15506,
      "e": 15538,
      "ty": 41,
      "x": 27988,
      "y": 9845,
      "ta": "html"
    },
    {
      "t": 16407,
      "e": 16439,
      "ty": 2,
      "x": 549,
      "y": 214
    },
    {
      "t": 16504,
      "e": 16536,
      "ty": 41,
      "x": 4471,
      "y": 22062,
      "ta": "html"
    },
    {
      "t": 16504,
      "e": 16536,
      "ty": 2,
      "x": 131,
      "y": 372
    },
    {
      "t": 16599,
      "e": 16631,
      "ty": 2,
      "x": 0,
      "y": 541
    },
    {
      "t": 16697,
      "e": 16729,
      "ty": 2,
      "x": 11,
      "y": 655
    },
    {
      "t": 16760,
      "e": 16792,
      "ty": 41,
      "x": 8840,
      "y": 56401,
      "ta": "html"
    },
    {
      "t": 16808,
      "e": 16840,
      "ty": 2,
      "x": 380,
      "y": 1090
    },
    {
      "t": 16871,
      "e": 16903,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 17002,
      "e": 17034,
      "ty": 2,
      "x": 124,
      "y": 1071
    },
    {
      "t": 17002,
      "e": 17034,
      "ty": 41,
      "x": 4232,
      "y": 63518,
      "ta": "html"
    },
    {
      "t": 17105,
      "e": 17137,
      "ty": 2,
      "x": 110,
      "y": 1055
    },
    {
      "t": 17200,
      "e": 17232,
      "ty": 2,
      "x": 228,
      "y": 1083
    },
    {
      "t": 17249,
      "e": 17281,
      "ty": 41,
      "x": 8533,
      "y": 65119,
      "ta": "html"
    },
    {
      "t": 17294,
      "e": 17326,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 17312,
      "e": 17344,
      "ty": 2,
      "x": 250,
      "y": 1098
    },
    {
      "t": 18001,
      "e": 18033,
      "ty": 41,
      "x": 10581,
      "y": 65357,
      "ta": "html"
    },
    {
      "t": 18002,
      "e": 18034,
      "ty": 2,
      "x": 310,
      "y": 1102
    },
    {
      "t": 18290,
      "e": 18322,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 20003,
      "e": 20035,
      "ty": 19,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"rel\":\"stylesheet\",\"media\":\"all\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 252, dom: 252, initialDom: 256",
  "javascriptErrors": []
}