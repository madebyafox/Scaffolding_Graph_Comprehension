var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "4f5fd2c4e45f6018df6e010ef8b543c1",
  "created": "2018-05-29T14:06:38.8241774-07:00",
  "lastActivity": "2018-05-29T14:06:51.4171774-07:00",
  "pageViews": [
    {
      "id": "052938097f72309b38e1fa5d1ebd146e0a144c81",
      "startTime": "2018-05-29T14:06:38.8241774-07:00",
      "endTime": "2018-05-29T14:06:51.4171774-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 12593,
      "engagementTime": 12593,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 12593,
  "engagementTime": 12593,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.41",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=7H6QC",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "0a4e522891ae9ec765731f710e5f72d4",
  "gdpr": false
}