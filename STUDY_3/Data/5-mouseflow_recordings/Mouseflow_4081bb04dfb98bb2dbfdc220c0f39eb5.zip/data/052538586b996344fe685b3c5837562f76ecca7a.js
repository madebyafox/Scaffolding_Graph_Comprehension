var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052538586b996344fe685b3c5837562f76ecca7a"] = {
  "startTime": "2018-05-25T18:19:38.4832097Z",
  "websitePageUrl": "/16",
  "visitTime": 132247,
  "engagementTime": 118208,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "4081bb04dfb98bb2dbfdc220c0f39eb5",
    "created": "2018-05-25T18:19:38.4832097+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=2WQ0M",
      "CONDITION=114"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "ff6cef8d411d637400bf5b0d52a849a7",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/4081bb04dfb98bb2dbfdc220c0f39eb5/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 253,
      "e": 253,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 253,
      "e": 253,
      "ty": 2,
      "x": 771,
      "y": 685
    },
    {
      "t": 253,
      "e": 253,
      "ty": 41,
      "x": 5217,
      "y": 38838,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 300,
      "e": 300,
      "ty": 2,
      "x": 889,
      "y": 648
    },
    {
      "t": 413,
      "e": 413,
      "ty": 2,
      "x": 955,
      "y": 621
    },
    {
      "t": 500,
      "e": 500,
      "ty": 2,
      "x": 964,
      "y": 614
    },
    {
      "t": 500,
      "e": 500,
      "ty": 41,
      "x": 12544,
      "y": 34092,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 663,
      "e": 663,
      "ty": 2,
      "x": 968,
      "y": 612
    },
    {
      "t": 752,
      "e": 752,
      "ty": 41,
      "x": 12826,
      "y": 33949,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 800,
      "e": 800,
      "ty": 2,
      "x": 950,
      "y": 612
    },
    {
      "t": 890,
      "e": 890,
      "ty": 6,
      "x": 652,
      "y": 572,
      "ta": "#strategyAnswer"
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 652,
      "y": 572
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 2,
      "x": 508,
      "y": 550
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 46189,
      "y": 22059,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1700,
      "e": 1700,
      "ty": 2,
      "x": 507,
      "y": 551
    },
    {
      "t": 1750,
      "e": 1750,
      "ty": 41,
      "x": 46077,
      "y": 22868,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2108,
      "e": 2108,
      "ty": 3,
      "x": 507,
      "y": 551,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2109,
      "e": 2109,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2187,
      "e": 2187,
      "ty": 4,
      "x": 46077,
      "y": 22868,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2188,
      "e": 2188,
      "ty": 5,
      "x": 507,
      "y": 551,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3100,
      "e": 3100,
      "ty": 2,
      "x": 507,
      "y": 552
    },
    {
      "t": 3200,
      "e": 3200,
      "ty": 2,
      "x": 654,
      "y": 592
    },
    {
      "t": 3208,
      "e": 3208,
      "ty": 7,
      "x": 687,
      "y": 602,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3250,
      "e": 3250,
      "ty": 41,
      "x": 3954,
      "y": 34365,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 3300,
      "e": 3300,
      "ty": 2,
      "x": 862,
      "y": 666
    },
    {
      "t": 3400,
      "e": 3400,
      "ty": 2,
      "x": 1015,
      "y": 755
    },
    {
      "t": 3500,
      "e": 3500,
      "ty": 2,
      "x": 1078,
      "y": 820
    },
    {
      "t": 3500,
      "e": 3500,
      "ty": 41,
      "x": 20577,
      "y": 48846,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3600,
      "e": 3600,
      "ty": 2,
      "x": 1083,
      "y": 851
    },
    {
      "t": 3701,
      "e": 3701,
      "ty": 2,
      "x": 1107,
      "y": 923
    },
    {
      "t": 3750,
      "e": 3750,
      "ty": 41,
      "x": 23748,
      "y": 57369,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3800,
      "e": 3800,
      "ty": 2,
      "x": 1153,
      "y": 944
    },
    {
      "t": 3901,
      "e": 3901,
      "ty": 2,
      "x": 1225,
      "y": 944
    },
    {
      "t": 4000,
      "e": 4000,
      "ty": 41,
      "x": 30936,
      "y": 57728,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4100,
      "e": 4100,
      "ty": 2,
      "x": 1220,
      "y": 942
    },
    {
      "t": 4200,
      "e": 4200,
      "ty": 2,
      "x": 1203,
      "y": 947
    },
    {
      "t": 4251,
      "e": 4251,
      "ty": 41,
      "x": 26708,
      "y": 58086,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4300,
      "e": 4300,
      "ty": 2,
      "x": 1149,
      "y": 949
    },
    {
      "t": 4400,
      "e": 4400,
      "ty": 2,
      "x": 1144,
      "y": 950
    },
    {
      "t": 4500,
      "e": 4500,
      "ty": 2,
      "x": 1143,
      "y": 953
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 41,
      "x": 25158,
      "y": 58372,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4601,
      "e": 4601,
      "ty": 2,
      "x": 1143,
      "y": 954
    },
    {
      "t": 4700,
      "e": 4700,
      "ty": 2,
      "x": 1143,
      "y": 953
    },
    {
      "t": 4751,
      "e": 4751,
      "ty": 41,
      "x": 26144,
      "y": 56725,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4800,
      "e": 4800,
      "ty": 2,
      "x": 1168,
      "y": 913
    },
    {
      "t": 4900,
      "e": 4900,
      "ty": 2,
      "x": 1174,
      "y": 904
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 2,
      "x": 1174,
      "y": 903
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 41,
      "x": 27342,
      "y": 54791,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5100,
      "e": 5100,
      "ty": 2,
      "x": 1180,
      "y": 900
    },
    {
      "t": 5200,
      "e": 5200,
      "ty": 2,
      "x": 1185,
      "y": 896
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 49236,
      "y": 14563,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[13] > circle"
    },
    {
      "t": 5300,
      "e": 5300,
      "ty": 2,
      "x": 1200,
      "y": 883
    },
    {
      "t": 5400,
      "e": 5400,
      "ty": 2,
      "x": 1217,
      "y": 862
    },
    {
      "t": 5500,
      "e": 5500,
      "ty": 2,
      "x": 1238,
      "y": 827
    },
    {
      "t": 5500,
      "e": 5500,
      "ty": 41,
      "x": 31852,
      "y": 49348,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5601,
      "e": 5601,
      "ty": 2,
      "x": 1244,
      "y": 822
    },
    {
      "t": 5700,
      "e": 5700,
      "ty": 2,
      "x": 1244,
      "y": 818
    },
    {
      "t": 5751,
      "e": 5751,
      "ty": 41,
      "x": 32275,
      "y": 48703,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7335,
      "e": 7335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 7503,
      "e": 7503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 7503,
      "e": 7503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7574,
      "e": 7574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 7582,
      "e": 7582,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 7655,
      "e": 7655,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 7655,
      "e": 7655,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7783,
      "e": 7783,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 7784,
      "e": 7784,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7791,
      "e": 7791,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Tra"
    },
    {
      "t": 7951,
      "e": 7951,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 7951,
      "e": 7951,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7967,
      "e": 7967,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Trac"
    },
    {
      "t": 8127,
      "e": 8127,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 8159,
      "e": 8159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 8160,
      "e": 8160,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8222,
      "e": 8222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8222,
      "e": 8222,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8255,
      "e": 8255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k "
    },
    {
      "t": 8334,
      "e": 8334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 8367,
      "e": 8367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 8367,
      "e": 8367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8430,
      "e": 8430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 8478,
      "e": 8478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 8478,
      "e": 8478,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8567,
      "e": 8567,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 8567,
      "e": 8567,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8607,
      "e": 8607,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 8647,
      "e": 8647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 8656,
      "e": 8656,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8658,
      "e": 8658,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8759,
      "e": 8759,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 9272,
      "e": 9272,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 9273,
      "e": 9273,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9303,
      "e": 9303,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 9303,
      "e": 9303,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9318,
      "e": 9318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||le"
    },
    {
      "t": 9505,
      "e": 9505,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 9505,
      "e": 9505,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9507,
      "e": 9507,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 9574,
      "e": 9574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 9694,
      "e": 9694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 9696,
      "e": 9696,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9803,
      "e": 9803,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Track the left"
    },
    {
      "t": 9831,
      "e": 9831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 9832,
      "e": 9832,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9871,
      "e": 9871,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||tw"
    },
    {
      "t": 9975,
      "e": 9975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 9975,
      "e": 9975,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10047,
      "e": 10047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 10142,
      "e": 10142,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 10142,
      "e": 10142,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10199,
      "e": 10199,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 10287,
      "e": 10287,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10447,
      "e": 10447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 10603,
      "e": 10603,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Track the leftwa"
    },
    {
      "t": 10947,
      "e": 10947,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 10980,
      "e": 10980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11012,
      "e": 11012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11045,
      "e": 11045,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11078,
      "e": 11078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11111,
      "e": 11111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11144,
      "e": 11144,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11177,
      "e": 11177,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11210,
      "e": 11210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11242,
      "e": 11242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11276,
      "e": 11276,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11309,
      "e": 11309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11342,
      "e": 11342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11375,
      "e": 11375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11408,
      "e": 11408,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11441,
      "e": 11441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11474,
      "e": 11474,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11507,
      "e": 11507,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11540,
      "e": 11540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11573,
      "e": 11573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11606,
      "e": 11606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11639,
      "e": 11639,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 11678,
      "e": 11678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 11679,
      "e": 11679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 11680,
      "e": 11680,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11775,
      "e": 11775,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 11831,
      "e": 11831,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 11863,
      "e": 11863,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 11864,
      "e": 11864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11951,
      "e": 11951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fo"
    },
    {
      "t": 12095,
      "e": 12095,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 12096,
      "e": 12096,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12159,
      "e": 12159,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fol"
    },
    {
      "t": 12223,
      "e": 12223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 12223,
      "e": 12223,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12279,
      "e": 12279,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Foll"
    },
    {
      "t": 12384,
      "e": 12384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 12384,
      "e": 12384,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12447,
      "e": 12447,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 12455,
      "e": 12455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 12455,
      "e": 12455,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12542,
      "e": 12542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 12575,
      "e": 12575,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12575,
      "e": 12575,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12663,
      "e": 12663,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12664,
      "e": 12664,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12671,
      "e": 12671,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 12703,
      "e": 12703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12743,
      "e": 12743,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 12743,
      "e": 12743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12823,
      "e": 12823,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 12823,
      "e": 12823,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12886,
      "e": 12886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 12895,
      "e": 12895,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12903,
      "e": 12903,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12903,
      "e": 12903,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12984,
      "e": 12984,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13127,
      "e": 13127,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 13128,
      "e": 13128,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13198,
      "e": 13198,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 13199,
      "e": 13199,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13206,
      "e": 13206,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||le"
    },
    {
      "t": 13287,
      "e": 13287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 13287,
      "e": 13287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13311,
      "e": 13311,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 13375,
      "e": 13375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13472,
      "e": 13472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13472,
      "e": 13472,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13550,
      "e": 13550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 13551,
      "e": 13551,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13647,
      "e": 13647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||tw"
    },
    {
      "t": 13735,
      "e": 13735,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 13736,
      "e": 13736,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13775,
      "e": 13775,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 13904,
      "e": 13904,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 13904,
      "e": 13904,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13943,
      "e": 13943,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 14038,
      "e": 14038,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 14038,
      "e": 14038,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14054,
      "e": 14054,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 14142,
      "e": 14142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14727,
      "e": 14727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14782,
      "e": 14782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the leftwar"
    },
    {
      "t": 14886,
      "e": 14886,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14950,
      "e": 14950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the leftwa"
    },
    {
      "t": 15054,
      "e": 15054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15118,
      "e": 15118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the leftw"
    },
    {
      "t": 15232,
      "e": 15232,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15310,
      "e": 15310,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the left"
    },
    {
      "t": 15414,
      "e": 15414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15479,
      "e": 15479,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the lef"
    },
    {
      "t": 15592,
      "e": 15592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15646,
      "e": 15646,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the le"
    },
    {
      "t": 15750,
      "e": 15750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15815,
      "e": 15815,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the l"
    },
    {
      "t": 15911,
      "e": 15911,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15974,
      "e": 15974,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the "
    },
    {
      "t": 16199,
      "e": 16199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 16201,
      "e": 16201,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16302,
      "e": 16302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 16303,
      "e": 16303,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16351,
      "e": 16351,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||li"
    },
    {
      "t": 16383,
      "e": 16383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16447,
      "e": 16447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 16447,
      "e": 16447,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16568,
      "e": 16568,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 16568,
      "e": 16568,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16583,
      "e": 16583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ne"
    },
    {
      "t": 16624,
      "e": 16584,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16663,
      "e": 16623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16664,
      "e": 16624,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16750,
      "e": 16710,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16822,
      "e": 16782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 16823,
      "e": 16783,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16879,
      "e": 16839,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 17002,
      "e": 16962,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the line g"
    },
    {
      "t": 17071,
      "e": 17031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 17072,
      "e": 17032,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17166,
      "e": 17126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 17167,
      "e": 17127,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17222,
      "e": 17182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||oi"
    },
    {
      "t": 17254,
      "e": 17214,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 17255,
      "e": 17215,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17295,
      "e": 17255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 17352,
      "e": 17312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 17352,
      "e": 17312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17374,
      "e": 17334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 17414,
      "e": 17374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17487,
      "e": 17447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17487,
      "e": 17447,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17583,
      "e": 17543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17631,
      "e": 17591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 17632,
      "e": 17592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17719,
      "e": 17679,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 17751,
      "e": 17711,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 17752,
      "e": 17712,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17815,
      "e": 17775,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 17815,
      "e": 17775,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17862,
      "e": 17822,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ia"
    },
    {
      "t": 17926,
      "e": 17886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17934,
      "e": 17894,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 17935,
      "e": 17895,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18047,
      "e": 18007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 18087,
      "e": 18047,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 18088,
      "e": 18048,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18158,
      "e": 18118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 18223,
      "e": 18183,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 18223,
      "e": 18183,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18302,
      "e": 18262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 18302,
      "e": 18262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18303,
      "e": 18263,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18414,
      "e": 18374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 18416,
      "e": 18376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 18416,
      "e": 18376,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18471,
      "e": 18431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 18535,
      "e": 18495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 18536,
      "e": 18496,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18599,
      "e": 18559,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 18679,
      "e": 18639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 18680,
      "e": 18640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18774,
      "e": 18734,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18774,
      "e": 18734,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18798,
      "e": 18758,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y "
    },
    {
      "t": 18855,
      "e": 18815,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19070,
      "e": 19030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 19071,
      "e": 19031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19118,
      "e": 19078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 19352,
      "e": 19312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 19353,
      "e": 19313,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19439,
      "e": 19399,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 19439,
      "e": 19399,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19463,
      "e": 19423,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ef"
    },
    {
      "t": 19510,
      "e": 19470,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19631,
      "e": 19591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19632,
      "e": 19592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19686,
      "e": 19646,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 19802,
      "e": 19762,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the line going diagonally left"
    },
    {
      "t": 20047,
      "e": 20007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 20119,
      "e": 20079,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the line going diagonally lef"
    },
    {
      "t": 20190,
      "e": 20150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 20270,
      "e": 20230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the line going diagonally le"
    },
    {
      "t": 20350,
      "e": 20310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 20423,
      "e": 20383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the line going diagonally l"
    },
    {
      "t": 20503,
      "e": 20463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 20574,
      "e": 20534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the line going diagonally "
    },
    {
      "t": 20735,
      "e": 20695,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 20736,
      "e": 20696,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20846,
      "e": 20806,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 20848,
      "e": 20808,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20886,
      "e": 20846,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||up"
    },
    {
      "t": 20966,
      "e": 20926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21222,
      "e": 21182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21402,
      "e": 21362,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the line going diagonally u"
    },
    {
      "t": 21503,
      "e": 21463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the line going diagonally u"
    },
    {
      "t": 22063,
      "e": 22023,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 22064,
      "e": 22024,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22190,
      "e": 22150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 22190,
      "e": 22150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22239,
      "e": 22199,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||up"
    },
    {
      "t": 22271,
      "e": 22231,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22447,
      "e": 22407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22486,
      "e": 22446,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the line going diagonally uu"
    },
    {
      "t": 22576,
      "e": 22446,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22631,
      "e": 22501,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the line going diagonally u"
    },
    {
      "t": 22799,
      "e": 22669,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 22799,
      "e": 22669,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22886,
      "e": 22756,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 23271,
      "e": 23141,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "191"
    },
    {
      "t": 23272,
      "e": 23142,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23359,
      "e": 23229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||/"
    },
    {
      "t": 23495,
      "e": 23365,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 23495,
      "e": 23365,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23575,
      "e": 23445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 23590,
      "e": 23460,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23591,
      "e": 23461,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23679,
      "e": 23549,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 23680,
      "e": 23550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23703,
      "e": 23573,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ef"
    },
    {
      "t": 23767,
      "e": 23637,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23895,
      "e": 23765,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23896,
      "e": 23766,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23942,
      "e": 23812,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 24455,
      "e": 24325,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24503,
      "e": 24373,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the line going diagonally up/lef"
    },
    {
      "t": 24591,
      "e": 24461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24662,
      "e": 24532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the line going diagonally up/le"
    },
    {
      "t": 24758,
      "e": 24628,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24823,
      "e": 24693,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the line going diagonally up/l"
    },
    {
      "t": 24911,
      "e": 24781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24982,
      "e": 24852,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the line going diagonally up/"
    },
    {
      "t": 25022,
      "e": 24892,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 25022,
      "e": 24892,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25127,
      "e": 24997,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 25159,
      "e": 25029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 25159,
      "e": 25029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25230,
      "e": 25100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 25246,
      "e": 25116,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 25246,
      "e": 25116,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25318,
      "e": 25188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 25383,
      "e": 25253,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 25384,
      "e": 25254,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25471,
      "e": 25341,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 25486,
      "e": 25356,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25486,
      "e": 25356,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25567,
      "e": 25437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 26031,
      "e": 25901,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26032,
      "e": 25902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26134,
      "e": 26004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 26134,
      "e": 26004,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26142,
      "e": 26012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| f"
    },
    {
      "t": 26198,
      "e": 26068,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26319,
      "e": 26189,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 26320,
      "e": 26190,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26383,
      "e": 26253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 26390,
      "e": 26260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 26392,
      "e": 26262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26447,
      "e": 26317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 26518,
      "e": 26388,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 26518,
      "e": 26388,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26623,
      "e": 26493,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 26631,
      "e": 26501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26632,
      "e": 26502,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26719,
      "e": 26589,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27487,
      "e": 27357,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27488,
      "e": 27358,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27550,
      "e": 27420,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 27599,
      "e": 27469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 27599,
      "e": 27469,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27671,
      "e": 27541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 27671,
      "e": 27541,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27678,
      "e": 27548,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 27735,
      "e": 27605,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27791,
      "e": 27661,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27791,
      "e": 27661,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27895,
      "e": 27765,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27919,
      "e": 27789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 27920,
      "e": 27790,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28006,
      "e": 27876,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 28007,
      "e": 27877,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28054,
      "e": 27924,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 28102,
      "e": 27972,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28203,
      "e": 28073,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the line going diagonally up/right from the 12"
    },
    {
      "t": 28279,
      "e": 28149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 28279,
      "e": 28149,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28382,
      "e": 28252,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 28471,
      "e": 28341,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 28471,
      "e": 28341,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28558,
      "e": 28428,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 30000,
      "e": 29870,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 34911,
      "e": 33428,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 34912,
      "e": 33429,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34974,
      "e": 33491,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 34989,
      "e": 33506,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34990,
      "e": 33507,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35062,
      "e": 33579,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35351,
      "e": 33868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 35850,
      "e": 34367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 35855,
      "e": 34372,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35983,
      "e": 34500,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 36119,
      "e": 34636,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 36119,
      "e": 34636,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36182,
      "e": 34699,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 36214,
      "e": 34731,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36246,
      "e": 34763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 36247,
      "e": 34764,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36351,
      "e": 34868,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 36486,
      "e": 35003,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 36487,
      "e": 35004,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36603,
      "e": 35120,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the line going diagonally up/right from the 12pm. Any"
    },
    {
      "t": 36607,
      "e": 35124,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 36647,
      "e": 35164,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36647,
      "e": 35164,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36734,
      "e": 35251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37534,
      "e": 36051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 37536,
      "e": 36053,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37630,
      "e": 36147,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 37630,
      "e": 36147,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37646,
      "e": 36163,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 37647,
      "e": 36164,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37662,
      "e": 36179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||poi"
    },
    {
      "t": 37734,
      "e": 36251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37767,
      "e": 36284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37767,
      "e": 36284,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 37768,
      "e": 36285,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37894,
      "e": 36411,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37896,
      "e": 36413,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37902,
      "e": 36419,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nt"
    },
    {
      "t": 37958,
      "e": 36475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38071,
      "e": 36588,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38071,
      "e": 36588,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38166,
      "e": 36683,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38207,
      "e": 36724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 38207,
      "e": 36724,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38278,
      "e": 36795,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 38278,
      "e": 36795,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38286,
      "e": 36803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 38342,
      "e": 36859,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 38342,
      "e": 36859,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38406,
      "e": 36923,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 38438,
      "e": 36955,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 38439,
      "e": 36956,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38478,
      "e": 36995,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 38527,
      "e": 37044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38527,
      "e": 37044,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38534,
      "e": 37051,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38599,
      "e": 37116,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38694,
      "e": 37211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 38695,
      "e": 37212,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38775,
      "e": 37292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 38799,
      "e": 37316,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 38799,
      "e": 37316,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38966,
      "e": 37483,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 38975,
      "e": 37492,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 38975,
      "e": 37492,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39069,
      "e": 37586,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 39102,
      "e": 37619,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 39102,
      "e": 37619,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39203,
      "e": 37720,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the line going diagonally up/right from the 12pm. Any point that pass"
    },
    {
      "t": 39270,
      "e": 37787,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 39582,
      "e": 38099,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 39583,
      "e": 38100,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39670,
      "e": 38187,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 39670,
      "e": 38187,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39710,
      "e": 38227,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||es"
    },
    {
      "t": 39790,
      "e": 38307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39886,
      "e": 38403,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39887,
      "e": 38404,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39958,
      "e": 38475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39999,
      "e": 38516,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40000,
      "e": 38517,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40003,
      "e": 38520,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40046,
      "e": 38563,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 40094,
      "e": 38611,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 40095,
      "e": 38612,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40166,
      "e": 38683,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 40174,
      "e": 38691,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 40174,
      "e": 38691,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40255,
      "e": 38772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 40255,
      "e": 38772,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40262,
      "e": 38779,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ro"
    },
    {
      "t": 40343,
      "e": 38860,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 40343,
      "e": 38860,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40382,
      "e": 38899,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 40438,
      "e": 38955,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 40439,
      "e": 38956,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40455,
      "e": 38972,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 40519,
      "e": 39036,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40583,
      "e": 39100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 40583,
      "e": 39100,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40695,
      "e": 39212,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40695,
      "e": 39212,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40710,
      "e": 39227,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h "
    },
    {
      "t": 40758,
      "e": 39275,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40758,
      "e": 39275,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40782,
      "e": 39299,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 40830,
      "e": 39347,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40886,
      "e": 39403,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 40887,
      "e": 39404,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40966,
      "e": 39483,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 40966,
      "e": 39483,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41022,
      "e": 39539,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 41070,
      "e": 39587,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 41071,
      "e": 39588,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41110,
      "e": 39627,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 41143,
      "e": 39660,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41143,
      "e": 39660,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41150,
      "e": 39667,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41230,
      "e": 39747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41310,
      "e": 39827,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 41310,
      "e": 39827,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41398,
      "e": 39915,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 41398,
      "e": 39915,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41430,
      "e": 39947,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||li"
    },
    {
      "t": 41478,
      "e": 39995,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41519,
      "e": 40036,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 41521,
      "e": 40038,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41630,
      "e": 40147,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 41638,
      "e": 40155,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 41639,
      "e": 40156,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41718,
      "e": 40235,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 41775,
      "e": 40292,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41775,
      "e": 40292,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41862,
      "e": 40379,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46478,
      "e": 44995,
      "ty": 6,
      "x": 373,
      "y": 666,
      "ta": "#strategyButton"
    },
    {
      "t": 46495,
      "e": 45012,
      "ty": 7,
      "x": 167,
      "y": 608,
      "ta": "#strategyButton"
    },
    {
      "t": 46501,
      "e": 45018,
      "ty": 2,
      "x": 167,
      "y": 608
    },
    {
      "t": 46501,
      "e": 45018,
      "ty": 41,
      "x": 7858,
      "y": 63443,
      "ta": "#.strategy"
    },
    {
      "t": 46601,
      "e": 45118,
      "ty": 2,
      "x": 0,
      "y": 527
    },
    {
      "t": 46700,
      "e": 45217,
      "ty": 2,
      "x": 0,
      "y": 534
    },
    {
      "t": 46751,
      "e": 45268,
      "ty": 41,
      "x": 2755,
      "y": 28695,
      "ta": "> div.stimulus"
    },
    {
      "t": 46762,
      "e": 45279,
      "ty": 6,
      "x": 169,
      "y": 526,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46801,
      "e": 45318,
      "ty": 2,
      "x": 393,
      "y": 588
    },
    {
      "t": 46811,
      "e": 45328,
      "ty": 7,
      "x": 475,
      "y": 639,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46900,
      "e": 45417,
      "ty": 2,
      "x": 1053,
      "y": 891
    },
    {
      "t": 47000,
      "e": 45517,
      "ty": 2,
      "x": 1334,
      "y": 939
    },
    {
      "t": 47000,
      "e": 45517,
      "ty": 41,
      "x": 38617,
      "y": 57369,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 47101,
      "e": 45618,
      "ty": 2,
      "x": 1369,
      "y": 936
    },
    {
      "t": 47200,
      "e": 45717,
      "ty": 2,
      "x": 1265,
      "y": 927
    },
    {
      "t": 47251,
      "e": 45768,
      "ty": 41,
      "x": 26990,
      "y": 56367,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 47301,
      "e": 45818,
      "ty": 2,
      "x": 1130,
      "y": 925
    },
    {
      "t": 47401,
      "e": 45918,
      "ty": 2,
      "x": 1127,
      "y": 932
    },
    {
      "t": 47501,
      "e": 46018,
      "ty": 2,
      "x": 1131,
      "y": 965
    },
    {
      "t": 47502,
      "e": 46019,
      "ty": 41,
      "x": 24312,
      "y": 59232,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 47600,
      "e": 46117,
      "ty": 2,
      "x": 1135,
      "y": 967
    },
    {
      "t": 47700,
      "e": 46217,
      "ty": 2,
      "x": 1136,
      "y": 960
    },
    {
      "t": 47751,
      "e": 46268,
      "ty": 41,
      "x": 24664,
      "y": 58730,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 47800,
      "e": 46317,
      "ty": 2,
      "x": 1136,
      "y": 958
    },
    {
      "t": 48000,
      "e": 46517,
      "ty": 2,
      "x": 810,
      "y": 862
    },
    {
      "t": 48001,
      "e": 46518,
      "ty": 41,
      "x": 1692,
      "y": 51855,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 48100,
      "e": 46617,
      "ty": 2,
      "x": 676,
      "y": 777
    },
    {
      "t": 48200,
      "e": 46717,
      "ty": 2,
      "x": 476,
      "y": 692
    },
    {
      "t": 48213,
      "e": 46730,
      "ty": 6,
      "x": 442,
      "y": 681,
      "ta": "#strategyButton"
    },
    {
      "t": 48251,
      "e": 46768,
      "ty": 41,
      "x": 22612,
      "y": 14004,
      "ta": "#strategyButton"
    },
    {
      "t": 48262,
      "e": 46779,
      "ty": 7,
      "x": 346,
      "y": 654,
      "ta": "#strategyButton"
    },
    {
      "t": 48300,
      "e": 46817,
      "ty": 2,
      "x": 295,
      "y": 638
    },
    {
      "t": 48362,
      "e": 46879,
      "ty": 6,
      "x": 195,
      "y": 599,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48400,
      "e": 46917,
      "ty": 2,
      "x": 152,
      "y": 585
    },
    {
      "t": 48500,
      "e": 47017,
      "ty": 2,
      "x": 145,
      "y": 579
    },
    {
      "t": 48500,
      "e": 47017,
      "ty": 41,
      "x": 5385,
      "y": 45523,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48600,
      "e": 47117,
      "ty": 2,
      "x": 162,
      "y": 568
    },
    {
      "t": 48700,
      "e": 47217,
      "ty": 2,
      "x": 207,
      "y": 564
    },
    {
      "t": 48749,
      "e": 47266,
      "ty": 41,
      "x": 19099,
      "y": 35005,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48799,
      "e": 47316,
      "ty": 2,
      "x": 306,
      "y": 567
    },
    {
      "t": 48900,
      "e": 47417,
      "ty": 2,
      "x": 349,
      "y": 574
    },
    {
      "t": 49001,
      "e": 47518,
      "ty": 41,
      "x": 28316,
      "y": 41477,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50000,
      "e": 48517,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 51824,
      "e": 50341,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 51825,
      "e": 50342,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51887,
      "e": 50404,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 51887,
      "e": 50404,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51903,
      "e": 50420,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||is"
    },
    {
      "t": 52006,
      "e": 50523,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52079,
      "e": 50596,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52079,
      "e": 50596,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52158,
      "e": 50675,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 52174,
      "e": 50691,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 52174,
      "e": 50691,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52262,
      "e": 50779,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 52278,
      "e": 50795,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 52278,
      "e": 50795,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52366,
      "e": 50883,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52366,
      "e": 50883,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52398,
      "e": 50915,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 52471,
      "e": 50988,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52502,
      "e": 51019,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 52503,
      "e": 51020,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52606,
      "e": 51123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 52638,
      "e": 51155,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 52639,
      "e": 51156,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52734,
      "e": 51251,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 52734,
      "e": 51251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52750,
      "e": 51267,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ve"
    },
    {
      "t": 52822,
      "e": 51339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52831,
      "e": 51348,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 52831,
      "e": 51348,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52943,
      "e": 51460,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 52959,
      "e": 51476,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 52959,
      "e": 51476,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53022,
      "e": 51539,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53023,
      "e": 51540,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53054,
      "e": 51571,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 53110,
      "e": 51627,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53211,
      "e": 51728,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the line going diagonally up/right from the 12pm. Any point that passes through this line is an event "
    },
    {
      "t": 53215,
      "e": 51732,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 53216,
      "e": 51733,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53270,
      "e": 51787,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 53270,
      "e": 51787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 53270,
      "e": 51787,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53358,
      "e": 51875,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 53358,
      "e": 51875,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53374,
      "e": 51891,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 53487,
      "e": 52004,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53655,
      "e": 52172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 53656,
      "e": 52173,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53767,
      "e": 52284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 53862,
      "e": 52379,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53863,
      "e": 52380,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53910,
      "e": 52427,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 53910,
      "e": 52427,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53966,
      "e": 52483,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| b"
    },
    {
      "t": 54046,
      "e": 52563,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 54046,
      "e": 52563,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54063,
      "e": 52580,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 54134,
      "e": 52651,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54191,
      "e": 52708,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 54192,
      "e": 52709,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54278,
      "e": 52795,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 54278,
      "e": 52795,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54286,
      "e": 52803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||gi"
    },
    {
      "t": 54343,
      "e": 52860,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54463,
      "e": 52980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 54463,
      "e": 52980,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54518,
      "e": 53035,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 54590,
      "e": 53107,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 54590,
      "e": 53107,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54695,
      "e": 53212,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 54703,
      "e": 53220,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 54704,
      "e": 53221,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54774,
      "e": 53291,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 54830,
      "e": 53347,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54831,
      "e": 53348,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54886,
      "e": 53403,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 54886,
      "e": 53403,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54934,
      "e": 53451,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 54966,
      "e": 53483,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 54967,
      "e": 53484,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55007,
      "e": 53524,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 55055,
      "e": 53572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 55086,
      "e": 53603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55087,
      "e": 53604,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55174,
      "e": 53691,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55214,
      "e": 53731,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 55215,
      "e": 53732,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55319,
      "e": 53836,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 55320,
      "e": 53837,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55350,
      "e": 53867,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 55414,
      "e": 53931,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 55527,
      "e": 54044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 55528,
      "e": 54045,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55646,
      "e": 54163,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 55871,
      "e": 54388,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 56010,
      "e": 54527,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the line going diagonally up/right from the 12pm. Any point that passes through this line is an event that beginns at 12"
    },
    {
      "t": 56370,
      "e": 54887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 56403,
      "e": 54920,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 56436,
      "e": 54953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 56469,
      "e": 54986,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 56502,
      "e": 55019,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 56535,
      "e": 55052,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 56543,
      "e": 55053,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the line going diagonally up/right from the 12pm. Any point that passes through this line is an event that beginns"
    },
    {
      "t": 56662,
      "e": 55172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 56734,
      "e": 55244,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the line going diagonally up/right from the 12pm. Any point that passes through this line is an event that beginn"
    },
    {
      "t": 57030,
      "e": 55540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 57119,
      "e": 55629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the line going diagonally up/right from the 12pm. Any point that passes through this line is an event that begin"
    },
    {
      "t": 57158,
      "e": 55668,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 57158,
      "e": 55668,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57230,
      "e": 55740,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 57311,
      "e": 55821,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57311,
      "e": 55821,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57407,
      "e": 55917,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57471,
      "e": 55981,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 57472,
      "e": 55982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57582,
      "e": 56092,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 57582,
      "e": 56092,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57623,
      "e": 56133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 57662,
      "e": 56172,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57703,
      "e": 56213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57703,
      "e": 56213,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57774,
      "e": 56284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57855,
      "e": 56365,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 57855,
      "e": 56365,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57959,
      "e": 56469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 57960,
      "e": 56470,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57974,
      "e": 56484,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 58046,
      "e": 56556,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58102,
      "e": 56612,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 58103,
      "e": 56613,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58207,
      "e": 56717,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 58279,
      "e": 56789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 58279,
      "e": 56789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58366,
      "e": 56876,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 58479,
      "e": 56989,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 58480,
      "e": 56990,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58550,
      "e": 57060,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 59259,
      "e": 57769,
      "ty": 41,
      "x": 28766,
      "y": 41477,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59296,
      "e": 57806,
      "ty": 7,
      "x": 398,
      "y": 604,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59309,
      "e": 57819,
      "ty": 2,
      "x": 398,
      "y": 604
    },
    {
      "t": 59409,
      "e": 57919,
      "ty": 2,
      "x": 578,
      "y": 699
    },
    {
      "t": 59509,
      "e": 58019,
      "ty": 2,
      "x": 557,
      "y": 714
    },
    {
      "t": 59509,
      "e": 58019,
      "ty": 41,
      "x": 51698,
      "y": 39110,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 59563,
      "e": 58073,
      "ty": 6,
      "x": 439,
      "y": 685,
      "ta": "#strategyButton"
    },
    {
      "t": 59608,
      "e": 58118,
      "ty": 2,
      "x": 388,
      "y": 675
    },
    {
      "t": 59709,
      "e": 58219,
      "ty": 2,
      "x": 374,
      "y": 674
    },
    {
      "t": 59759,
      "e": 58269,
      "ty": 41,
      "x": 19336,
      "y": 37134,
      "ta": "#strategyButton"
    },
    {
      "t": 59809,
      "e": 58319,
      "ty": 2,
      "x": 365,
      "y": 665
    },
    {
      "t": 59814,
      "e": 58324,
      "ty": 7,
      "x": 335,
      "y": 645,
      "ta": "#strategyButton"
    },
    {
      "t": 59847,
      "e": 58357,
      "ty": 6,
      "x": 219,
      "y": 585,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59900,
      "e": 58410,
      "ty": 7,
      "x": 65,
      "y": 511,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59909,
      "e": 58419,
      "ty": 2,
      "x": 65,
      "y": 511
    },
    {
      "t": 60009,
      "e": 58519,
      "ty": 2,
      "x": 28,
      "y": 496
    },
    {
      "t": 60009,
      "e": 58519,
      "ty": 41,
      "x": 688,
      "y": 27033,
      "ta": "> div.stimulus"
    },
    {
      "t": 60109,
      "e": 58619,
      "ty": 2,
      "x": 27,
      "y": 496
    },
    {
      "t": 60260,
      "e": 58770,
      "ty": 41,
      "x": 654,
      "y": 27033,
      "ta": "> div.stimulus"
    },
    {
      "t": 60509,
      "e": 59019,
      "ty": 2,
      "x": 56,
      "y": 515
    },
    {
      "t": 60510,
      "e": 59020,
      "ty": 41,
      "x": 1653,
      "y": 28086,
      "ta": "> div.stimulus"
    },
    {
      "t": 60609,
      "e": 59119,
      "ty": 2,
      "x": 85,
      "y": 526
    },
    {
      "t": 60708,
      "e": 59218,
      "ty": 2,
      "x": 94,
      "y": 525
    },
    {
      "t": 60747,
      "e": 59257,
      "ty": 6,
      "x": 97,
      "y": 524,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60758,
      "e": 59268,
      "ty": 41,
      "x": 0,
      "y": 1023,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60809,
      "e": 59319,
      "ty": 2,
      "x": 101,
      "y": 524
    },
    {
      "t": 60908,
      "e": 59418,
      "ty": 2,
      "x": 171,
      "y": 558
    },
    {
      "t": 61009,
      "e": 59519,
      "ty": 2,
      "x": 230,
      "y": 586
    },
    {
      "t": 61009,
      "e": 59519,
      "ty": 41,
      "x": 14939,
      "y": 51186,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61109,
      "e": 59619,
      "ty": 2,
      "x": 283,
      "y": 597
    },
    {
      "t": 61132,
      "e": 59642,
      "ty": 7,
      "x": 326,
      "y": 610,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61209,
      "e": 59719,
      "ty": 2,
      "x": 385,
      "y": 623
    },
    {
      "t": 61259,
      "e": 59769,
      "ty": 41,
      "x": 54490,
      "y": 829,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 61309,
      "e": 59819,
      "ty": 2,
      "x": 525,
      "y": 623
    },
    {
      "t": 61408,
      "e": 59918,
      "ty": 2,
      "x": 630,
      "y": 623
    },
    {
      "t": 61509,
      "e": 60019,
      "ty": 2,
      "x": 641,
      "y": 624
    },
    {
      "t": 61510,
      "e": 60020,
      "ty": 41,
      "x": 61140,
      "y": 34124,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 61609,
      "e": 60119,
      "ty": 2,
      "x": 499,
      "y": 647
    },
    {
      "t": 61709,
      "e": 60219,
      "ty": 2,
      "x": 460,
      "y": 650
    },
    {
      "t": 61748,
      "e": 60258,
      "ty": 6,
      "x": 444,
      "y": 656,
      "ta": "#strategyButton"
    },
    {
      "t": 61758,
      "e": 60268,
      "ty": 41,
      "x": 57564,
      "y": 2439,
      "ta": "#strategyButton"
    },
    {
      "t": 61808,
      "e": 60318,
      "ty": 2,
      "x": 429,
      "y": 661
    },
    {
      "t": 61909,
      "e": 60419,
      "ty": 2,
      "x": 425,
      "y": 661
    },
    {
      "t": 62009,
      "e": 60519,
      "ty": 2,
      "x": 413,
      "y": 670
    },
    {
      "t": 62009,
      "e": 60519,
      "ty": 41,
      "x": 40635,
      "y": 29424,
      "ta": "#strategyButton"
    },
    {
      "t": 62109,
      "e": 60619,
      "ty": 2,
      "x": 412,
      "y": 671
    },
    {
      "t": 62258,
      "e": 60768,
      "ty": 41,
      "x": 40088,
      "y": 31351,
      "ta": "#strategyButton"
    },
    {
      "t": 62653,
      "e": 61163,
      "ty": 3,
      "x": 412,
      "y": 671,
      "ta": "#strategyButton"
    },
    {
      "t": 62655,
      "e": 61165,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the line going diagonally up/right from the 12pm. Any point that passes through this line is an event that begins at 12pm."
    },
    {
      "t": 62656,
      "e": 61166,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62658,
      "e": 61168,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 62714,
      "e": 61224,
      "ty": 4,
      "x": 40088,
      "y": 31351,
      "ta": "#strategyButton"
    },
    {
      "t": 62723,
      "e": 61233,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 62724,
      "e": 61234,
      "ty": 5,
      "x": 412,
      "y": 671,
      "ta": "#strategyButton"
    },
    {
      "t": 62731,
      "e": 61241,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 63208,
      "e": 61718,
      "ty": 2,
      "x": 412,
      "y": 648
    },
    {
      "t": 63259,
      "e": 61769,
      "ty": 41,
      "x": 13878,
      "y": 34678,
      "ta": "html > body"
    },
    {
      "t": 63309,
      "e": 61819,
      "ty": 2,
      "x": 415,
      "y": 602
    },
    {
      "t": 63409,
      "e": 61919,
      "ty": 2,
      "x": 426,
      "y": 554
    },
    {
      "t": 63509,
      "e": 62019,
      "ty": 2,
      "x": 430,
      "y": 529
    },
    {
      "t": 63510,
      "e": 62020,
      "ty": 41,
      "x": 14532,
      "y": 28861,
      "ta": "html > body"
    },
    {
      "t": 63609,
      "e": 62119,
      "ty": 2,
      "x": 430,
      "y": 524
    },
    {
      "t": 63709,
      "e": 62219,
      "ty": 2,
      "x": 430,
      "y": 495
    },
    {
      "t": 63730,
      "e": 62240,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 63759,
      "e": 62269,
      "ty": 41,
      "x": 14188,
      "y": 26369,
      "ta": "html > body"
    },
    {
      "t": 63809,
      "e": 62319,
      "ty": 2,
      "x": 420,
      "y": 484
    },
    {
      "t": 64209,
      "e": 62719,
      "ty": 2,
      "x": 610,
      "y": 510
    },
    {
      "t": 64285,
      "e": 62795,
      "ty": 41,
      "x": 38604,
      "y": 31299,
      "ta": "html > body"
    },
    {
      "t": 64309,
      "e": 62819,
      "ty": 2,
      "x": 1131,
      "y": 573
    },
    {
      "t": 64409,
      "e": 62919,
      "ty": 2,
      "x": 1124,
      "y": 572
    },
    {
      "t": 64432,
      "e": 62942,
      "ty": 6,
      "x": 1091,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64509,
      "e": 63019,
      "ty": 2,
      "x": 1005,
      "y": 559
    },
    {
      "t": 64510,
      "e": 63020,
      "ty": 41,
      "x": 42608,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64603,
      "e": 63113,
      "ty": 3,
      "x": 998,
      "y": 558,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64604,
      "e": 63114,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64609,
      "e": 63119,
      "ty": 2,
      "x": 998,
      "y": 558
    },
    {
      "t": 64698,
      "e": 63208,
      "ty": 4,
      "x": 41094,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64698,
      "e": 63208,
      "ty": 5,
      "x": 998,
      "y": 558,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64759,
      "e": 63269,
      "ty": 41,
      "x": 41094,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 65647,
      "e": 64157,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 65647,
      "e": 64157,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 65734,
      "e": 64244,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "96"
    },
    {
      "t": 65734,
      "e": 64244,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 65782,
      "e": 64292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 65830,
      "e": 64340,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 66169,
      "e": 64679,
      "ty": 7,
      "x": 998,
      "y": 549,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 66209,
      "e": 64719,
      "ty": 2,
      "x": 998,
      "y": 540
    },
    {
      "t": 66259,
      "e": 64769,
      "ty": 41,
      "x": 52990,
      "y": 35938,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 66309,
      "e": 64819,
      "ty": 2,
      "x": 1065,
      "y": 577
    },
    {
      "t": 66410,
      "e": 64920,
      "ty": 2,
      "x": 1084,
      "y": 621
    },
    {
      "t": 66436,
      "e": 64946,
      "ty": 6,
      "x": 1082,
      "y": 648,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66469,
      "e": 64979,
      "ty": 7,
      "x": 1077,
      "y": 672,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66509,
      "e": 65019,
      "ty": 2,
      "x": 1077,
      "y": 672
    },
    {
      "t": 66510,
      "e": 65020,
      "ty": 41,
      "x": 58181,
      "y": 62716,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 66723,
      "e": 65233,
      "ty": 6,
      "x": 1078,
      "y": 666,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66759,
      "e": 65269,
      "ty": 41,
      "x": 59478,
      "y": 24965,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66809,
      "e": 65319,
      "ty": 2,
      "x": 1083,
      "y": 655
    },
    {
      "t": 66834,
      "e": 65344,
      "ty": 3,
      "x": 1083,
      "y": 655,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66834,
      "e": 65344,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 66835,
      "e": 65345,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 66835,
      "e": 65345,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66930,
      "e": 65440,
      "ty": 4,
      "x": 59478,
      "y": 24965,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66931,
      "e": 65441,
      "ty": 5,
      "x": 1083,
      "y": 655,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67295,
      "e": 65805,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 67519,
      "e": 66029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 67520,
      "e": 66030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67622,
      "e": 66132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 67662,
      "e": 66172,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 67791,
      "e": 66301,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 67792,
      "e": 66302,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67901,
      "e": 66411,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un"
    },
    {
      "t": 67910,
      "e": 66420,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 67910,
      "e": 66420,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68006,
      "e": 66516,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 68054,
      "e": 66564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 68055,
      "e": 66565,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68183,
      "e": 66693,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 68183,
      "e": 66693,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68221,
      "e": 66731,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unite"
    },
    {
      "t": 68261,
      "e": 66771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 68342,
      "e": 66852,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 68342,
      "e": 66852,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68439,
      "e": 66949,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 68439,
      "e": 66949,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68446,
      "e": 66956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d "
    },
    {
      "t": 68517,
      "e": 67027,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 68526,
      "e": 67036,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 68622,
      "e": 67132,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 68623,
      "e": 67133,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68678,
      "e": 67188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 68679,
      "e": 67189,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 68680,
      "e": 67190,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68726,
      "e": 67236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 68814,
      "e": 67324,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 68822,
      "e": 67332,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 68822,
      "e": 67332,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68926,
      "e": 67436,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 68928,
      "e": 67438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68951,
      "e": 67461,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||at"
    },
    {
      "t": 69031,
      "e": 67541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 69031,
      "e": 67541,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69110,
      "e": 67620,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 69110,
      "e": 67620,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69118,
      "e": 67628,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||es"
    },
    {
      "t": 69206,
      "e": 67716,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 69286,
      "e": 67796,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 69455,
      "e": 67965,
      "ty": 7,
      "x": 1064,
      "y": 632,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69472,
      "e": 67982,
      "ty": 6,
      "x": 997,
      "y": 564,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 69488,
      "e": 67998,
      "ty": 7,
      "x": 937,
      "y": 532,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 69509,
      "e": 68019,
      "ty": 2,
      "x": 911,
      "y": 526
    },
    {
      "t": 69509,
      "e": 68019,
      "ty": 41,
      "x": 22277,
      "y": 42129,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 69609,
      "e": 68119,
      "ty": 2,
      "x": 905,
      "y": 527
    },
    {
      "t": 69672,
      "e": 68182,
      "ty": 6,
      "x": 891,
      "y": 555,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 69689,
      "e": 68199,
      "ty": 7,
      "x": 888,
      "y": 576,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 69709,
      "e": 68219,
      "ty": 2,
      "x": 888,
      "y": 599
    },
    {
      "t": 69755,
      "e": 68219,
      "ty": 6,
      "x": 902,
      "y": 654,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69759,
      "e": 68223,
      "ty": 41,
      "x": 20330,
      "y": 21845,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69772,
      "e": 68236,
      "ty": 7,
      "x": 912,
      "y": 673,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69789,
      "e": 68253,
      "ty": 6,
      "x": 927,
      "y": 698,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 69805,
      "e": 68269,
      "ty": 7,
      "x": 944,
      "y": 723,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 69809,
      "e": 68273,
      "ty": 2,
      "x": 944,
      "y": 723
    },
    {
      "t": 69909,
      "e": 68373,
      "ty": 2,
      "x": 969,
      "y": 752
    },
    {
      "t": 70010,
      "e": 68474,
      "ty": 2,
      "x": 990,
      "y": 723
    },
    {
      "t": 70010,
      "e": 68474,
      "ty": 41,
      "x": 33817,
      "y": 39609,
      "ta": "html > body"
    },
    {
      "t": 70109,
      "e": 68573,
      "ty": 2,
      "x": 993,
      "y": 711
    },
    {
      "t": 70209,
      "e": 68673,
      "ty": 2,
      "x": 993,
      "y": 710
    },
    {
      "t": 70259,
      "e": 68723,
      "ty": 41,
      "x": 33921,
      "y": 38888,
      "ta": "html > body"
    },
    {
      "t": 70289,
      "e": 68753,
      "ty": 6,
      "x": 993,
      "y": 708,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 70309,
      "e": 68773,
      "ty": 2,
      "x": 992,
      "y": 705
    },
    {
      "t": 70409,
      "e": 68873,
      "ty": 2,
      "x": 989,
      "y": 694
    },
    {
      "t": 70509,
      "e": 68973,
      "ty": 41,
      "x": 47971,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 71387,
      "e": 69851,
      "ty": 3,
      "x": 989,
      "y": 694,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 71388,
      "e": 69852,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 71388,
      "e": 69852,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 71389,
      "e": 69853,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 71467,
      "e": 69931,
      "ty": 4,
      "x": 47971,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 71469,
      "e": 69933,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 71470,
      "e": 69934,
      "ty": 5,
      "x": 989,
      "y": 694,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 71470,
      "e": 69934,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 72491,
      "e": 70955,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 73109,
      "e": 71573,
      "ty": 2,
      "x": 988,
      "y": 691
    },
    {
      "t": 73209,
      "e": 71673,
      "ty": 2,
      "x": 790,
      "y": 227
    },
    {
      "t": 73260,
      "e": 71724,
      "ty": 41,
      "x": 26826,
      "y": 10470,
      "ta": "html > body"
    },
    {
      "t": 73309,
      "e": 71773,
      "ty": 2,
      "x": 787,
      "y": 196
    },
    {
      "t": 73408,
      "e": 71872,
      "ty": 2,
      "x": 808,
      "y": 195
    },
    {
      "t": 73509,
      "e": 71973,
      "ty": 2,
      "x": 886,
      "y": 226
    },
    {
      "t": 73510,
      "e": 71974,
      "ty": 41,
      "x": 15325,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 73609,
      "e": 72073,
      "ty": 2,
      "x": 886,
      "y": 227
    },
    {
      "t": 73709,
      "e": 72173,
      "ty": 2,
      "x": 871,
      "y": 232
    },
    {
      "t": 73758,
      "e": 72222,
      "ty": 41,
      "x": 38960,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 73808,
      "e": 72272,
      "ty": 2,
      "x": 869,
      "y": 234
    },
    {
      "t": 73962,
      "e": 72426,
      "ty": 3,
      "x": 869,
      "y": 234,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 74025,
      "e": 72489,
      "ty": 4,
      "x": 38960,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 74026,
      "e": 72490,
      "ty": 5,
      "x": 869,
      "y": 234,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 74026,
      "e": 72490,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 74027,
      "e": 72491,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 74208,
      "e": 72672,
      "ty": 2,
      "x": 865,
      "y": 240
    },
    {
      "t": 74259,
      "e": 72723,
      "ty": 41,
      "x": 12717,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 74309,
      "e": 72773,
      "ty": 2,
      "x": 862,
      "y": 354
    },
    {
      "t": 74408,
      "e": 72872,
      "ty": 2,
      "x": 862,
      "y": 389
    },
    {
      "t": 74509,
      "e": 72973,
      "ty": 2,
      "x": 869,
      "y": 414
    },
    {
      "t": 74509,
      "e": 72973,
      "ty": 41,
      "x": 55694,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 74608,
      "e": 73072,
      "ty": 2,
      "x": 869,
      "y": 416
    },
    {
      "t": 74708,
      "e": 73172,
      "ty": 2,
      "x": 868,
      "y": 418
    },
    {
      "t": 74758,
      "e": 73222,
      "ty": 41,
      "x": 53353,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 74808,
      "e": 73272,
      "ty": 2,
      "x": 867,
      "y": 419
    },
    {
      "t": 75609,
      "e": 74073,
      "ty": 2,
      "x": 867,
      "y": 467
    },
    {
      "t": 75708,
      "e": 74172,
      "ty": 2,
      "x": 866,
      "y": 551
    },
    {
      "t": 75759,
      "e": 74223,
      "ty": 41,
      "x": 30416,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 75809,
      "e": 74273,
      "ty": 2,
      "x": 866,
      "y": 559
    },
    {
      "t": 75909,
      "e": 74373,
      "ty": 2,
      "x": 866,
      "y": 546
    },
    {
      "t": 76009,
      "e": 74473,
      "ty": 2,
      "x": 863,
      "y": 512
    },
    {
      "t": 76009,
      "e": 74473,
      "ty": 41,
      "x": 9867,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 76108,
      "e": 74572,
      "ty": 2,
      "x": 863,
      "y": 511
    },
    {
      "t": 76209,
      "e": 74673,
      "ty": 2,
      "x": 863,
      "y": 487
    },
    {
      "t": 76259,
      "e": 74674,
      "ty": 41,
      "x": 43948,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 76308,
      "e": 74723,
      "ty": 2,
      "x": 863,
      "y": 458
    },
    {
      "t": 76408,
      "e": 74823,
      "ty": 2,
      "x": 863,
      "y": 453
    },
    {
      "t": 76509,
      "e": 74924,
      "ty": 41,
      "x": 9867,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 76808,
      "e": 75223,
      "ty": 2,
      "x": 863,
      "y": 450
    },
    {
      "t": 76908,
      "e": 75323,
      "ty": 2,
      "x": 864,
      "y": 448
    },
    {
      "t": 77009,
      "e": 75424,
      "ty": 41,
      "x": 34009,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 77178,
      "e": 75593,
      "ty": 3,
      "x": 864,
      "y": 448,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 77179,
      "e": 75594,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 77282,
      "e": 75697,
      "ty": 4,
      "x": 34009,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 77282,
      "e": 75697,
      "ty": 5,
      "x": 864,
      "y": 448,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 77282,
      "e": 75697,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 77282,
      "e": 75697,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 77995,
      "e": 76410,
      "ty": 6,
      "x": 837,
      "y": 524,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 78008,
      "e": 76423,
      "ty": 2,
      "x": 837,
      "y": 524
    },
    {
      "t": 78008,
      "e": 76423,
      "ty": 41,
      "x": 53325,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 78012,
      "e": 76427,
      "ty": 7,
      "x": 836,
      "y": 554,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 78012,
      "e": 76427,
      "ty": 6,
      "x": 836,
      "y": 554,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 78028,
      "e": 76443,
      "ty": 7,
      "x": 836,
      "y": 584,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 78029,
      "e": 76444,
      "ty": 6,
      "x": 836,
      "y": 584,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 78045,
      "e": 76460,
      "ty": 7,
      "x": 839,
      "y": 611,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 78108,
      "e": 76523,
      "ty": 2,
      "x": 860,
      "y": 669
    },
    {
      "t": 78208,
      "e": 76623,
      "ty": 2,
      "x": 869,
      "y": 685
    },
    {
      "t": 78259,
      "e": 76674,
      "ty": 41,
      "x": 11766,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 78309,
      "e": 76724,
      "ty": 2,
      "x": 873,
      "y": 688
    },
    {
      "t": 78408,
      "e": 76823,
      "ty": 2,
      "x": 874,
      "y": 688
    },
    {
      "t": 78509,
      "e": 76924,
      "ty": 2,
      "x": 875,
      "y": 688
    },
    {
      "t": 78509,
      "e": 76924,
      "ty": 41,
      "x": 12715,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 78708,
      "e": 77123,
      "ty": 2,
      "x": 889,
      "y": 684
    },
    {
      "t": 78758,
      "e": 77173,
      "ty": 41,
      "x": 19487,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 78808,
      "e": 77223,
      "ty": 2,
      "x": 902,
      "y": 673
    },
    {
      "t": 78909,
      "e": 77324,
      "ty": 2,
      "x": 906,
      "y": 670
    },
    {
      "t": 79009,
      "e": 77424,
      "ty": 2,
      "x": 913,
      "y": 672
    },
    {
      "t": 79009,
      "e": 77424,
      "ty": 41,
      "x": 24588,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 79209,
      "e": 77624,
      "ty": 2,
      "x": 913,
      "y": 674
    },
    {
      "t": 79259,
      "e": 77674,
      "ty": 41,
      "x": 24588,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 79308,
      "e": 77723,
      "ty": 2,
      "x": 911,
      "y": 689
    },
    {
      "t": 79408,
      "e": 77823,
      "ty": 2,
      "x": 908,
      "y": 699
    },
    {
      "t": 79509,
      "e": 77924,
      "ty": 2,
      "x": 908,
      "y": 700
    },
    {
      "t": 79509,
      "e": 77924,
      "ty": 41,
      "x": 21816,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 79708,
      "e": 78123,
      "ty": 2,
      "x": 907,
      "y": 700
    },
    {
      "t": 79758,
      "e": 78173,
      "ty": 41,
      "x": 20808,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 79809,
      "e": 78224,
      "ty": 2,
      "x": 904,
      "y": 703
    },
    {
      "t": 82315,
      "e": 80730,
      "ty": 3,
      "x": 904,
      "y": 703,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 82316,
      "e": 80731,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 82418,
      "e": 80833,
      "ty": 4,
      "x": 20808,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 82418,
      "e": 80833,
      "ty": 5,
      "x": 904,
      "y": 703,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 82418,
      "e": 80833,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 82419,
      "e": 80834,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 82508,
      "e": 80923,
      "ty": 2,
      "x": 900,
      "y": 703
    },
    {
      "t": 82508,
      "e": 80923,
      "ty": 41,
      "x": 19800,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 82608,
      "e": 81023,
      "ty": 2,
      "x": 899,
      "y": 703
    },
    {
      "t": 82708,
      "e": 81123,
      "ty": 2,
      "x": 895,
      "y": 775
    },
    {
      "t": 82759,
      "e": 81174,
      "ty": 41,
      "x": 51840,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 82808,
      "e": 81223,
      "ty": 2,
      "x": 890,
      "y": 901
    },
    {
      "t": 82908,
      "e": 81323,
      "ty": 2,
      "x": 871,
      "y": 939
    },
    {
      "t": 83009,
      "e": 81424,
      "ty": 2,
      "x": 861,
      "y": 950
    },
    {
      "t": 83009,
      "e": 81424,
      "ty": 41,
      "x": 9392,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 83109,
      "e": 81524,
      "ty": 2,
      "x": 861,
      "y": 945
    },
    {
      "t": 83208,
      "e": 81623,
      "ty": 2,
      "x": 861,
      "y": 939
    },
    {
      "t": 83259,
      "e": 81674,
      "ty": 41,
      "x": 43229,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 83299,
      "e": 81714,
      "ty": 3,
      "x": 861,
      "y": 939,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 83299,
      "e": 81714,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 83387,
      "e": 81802,
      "ty": 4,
      "x": 43229,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 83387,
      "e": 81802,
      "ty": 5,
      "x": 861,
      "y": 939,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 83388,
      "e": 81803,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 83389,
      "e": 81804,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 84259,
      "e": 82674,
      "ty": 41,
      "x": 19597,
      "y": 14115,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 84309,
      "e": 82724,
      "ty": 2,
      "x": 967,
      "y": 841
    },
    {
      "t": 84408,
      "e": 82823,
      "ty": 2,
      "x": 1026,
      "y": 737
    },
    {
      "t": 84508,
      "e": 82923,
      "ty": 2,
      "x": 1030,
      "y": 720
    },
    {
      "t": 84509,
      "e": 82924,
      "ty": 41,
      "x": 49500,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 84609,
      "e": 83024,
      "ty": 2,
      "x": 1027,
      "y": 708
    },
    {
      "t": 84709,
      "e": 83124,
      "ty": 2,
      "x": 1025,
      "y": 707
    },
    {
      "t": 84759,
      "e": 83174,
      "ty": 41,
      "x": 49786,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 84809,
      "e": 83224,
      "ty": 2,
      "x": 1007,
      "y": 710
    },
    {
      "t": 85009,
      "e": 83424,
      "ty": 41,
      "x": 46762,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 85408,
      "e": 83823,
      "ty": 2,
      "x": 997,
      "y": 706
    },
    {
      "t": 85508,
      "e": 83923,
      "ty": 2,
      "x": 988,
      "y": 692
    },
    {
      "t": 85509,
      "e": 83924,
      "ty": 41,
      "x": 39533,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 85609,
      "e": 84024,
      "ty": 2,
      "x": 987,
      "y": 686
    },
    {
      "t": 85709,
      "e": 84124,
      "ty": 2,
      "x": 987,
      "y": 685
    },
    {
      "t": 85759,
      "e": 84174,
      "ty": 41,
      "x": 39295,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 85908,
      "e": 84323,
      "ty": 2,
      "x": 981,
      "y": 690
    },
    {
      "t": 86009,
      "e": 84424,
      "ty": 2,
      "x": 974,
      "y": 705
    },
    {
      "t": 86009,
      "e": 84424,
      "ty": 41,
      "x": 38446,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 86109,
      "e": 84524,
      "ty": 2,
      "x": 972,
      "y": 709
    },
    {
      "t": 86259,
      "e": 84674,
      "ty": 41,
      "x": 37942,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 86509,
      "e": 84924,
      "ty": 2,
      "x": 966,
      "y": 714
    },
    {
      "t": 86509,
      "e": 84924,
      "ty": 41,
      "x": 34311,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 86609,
      "e": 85024,
      "ty": 2,
      "x": 959,
      "y": 721
    },
    {
      "t": 86709,
      "e": 85124,
      "ty": 2,
      "x": 955,
      "y": 731
    },
    {
      "t": 86760,
      "e": 85125,
      "ty": 41,
      "x": 33526,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 86808,
      "e": 85173,
      "ty": 2,
      "x": 954,
      "y": 743
    },
    {
      "t": 86908,
      "e": 85273,
      "ty": 2,
      "x": 954,
      "y": 760
    },
    {
      "t": 87009,
      "e": 85374,
      "ty": 2,
      "x": 951,
      "y": 782
    },
    {
      "t": 87009,
      "e": 85374,
      "ty": 41,
      "x": 30752,
      "y": 21064,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 87109,
      "e": 85474,
      "ty": 2,
      "x": 940,
      "y": 802
    },
    {
      "t": 87209,
      "e": 85574,
      "ty": 2,
      "x": 939,
      "y": 805
    },
    {
      "t": 87259,
      "e": 85624,
      "ty": 41,
      "x": 27904,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 87309,
      "e": 85674,
      "ty": 2,
      "x": 937,
      "y": 809
    },
    {
      "t": 87409,
      "e": 85774,
      "ty": 2,
      "x": 933,
      "y": 814
    },
    {
      "t": 87509,
      "e": 85874,
      "ty": 2,
      "x": 924,
      "y": 827
    },
    {
      "t": 87509,
      "e": 85874,
      "ty": 41,
      "x": 24344,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 87609,
      "e": 85974,
      "ty": 2,
      "x": 916,
      "y": 840
    },
    {
      "t": 87709,
      "e": 86074,
      "ty": 2,
      "x": 912,
      "y": 843
    },
    {
      "t": 87760,
      "e": 86125,
      "ty": 41,
      "x": 63817,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 87909,
      "e": 86274,
      "ty": 2,
      "x": 910,
      "y": 843
    },
    {
      "t": 88009,
      "e": 86374,
      "ty": 41,
      "x": 62408,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 89258,
      "e": 87623,
      "ty": 41,
      "x": 19360,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 89309,
      "e": 87674,
      "ty": 2,
      "x": 888,
      "y": 892
    },
    {
      "t": 89372,
      "e": 87737,
      "ty": 6,
      "x": 874,
      "y": 1006,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 89387,
      "e": 87752,
      "ty": 7,
      "x": 874,
      "y": 1045,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 89409,
      "e": 87774,
      "ty": 2,
      "x": 874,
      "y": 1077
    },
    {
      "t": 89509,
      "e": 87874,
      "ty": 2,
      "x": 865,
      "y": 1123
    },
    {
      "t": 89509,
      "e": 87874,
      "ty": 41,
      "x": 29513,
      "y": 61767,
      "ta": "html > body"
    },
    {
      "t": 89609,
      "e": 87974,
      "ty": 2,
      "x": 862,
      "y": 1127
    },
    {
      "t": 89759,
      "e": 88124,
      "ty": 41,
      "x": 29409,
      "y": 61989,
      "ta": "html > body"
    },
    {
      "t": 90009,
      "e": 88374,
      "ty": 2,
      "x": 868,
      "y": 1118
    },
    {
      "t": 90009,
      "e": 88374,
      "ty": 41,
      "x": 29616,
      "y": 61490,
      "ta": "html > body"
    },
    {
      "t": 90109,
      "e": 88474,
      "ty": 2,
      "x": 881,
      "y": 1070
    },
    {
      "t": 90170,
      "e": 88535,
      "ty": 6,
      "x": 887,
      "y": 1030,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 90209,
      "e": 88574,
      "ty": 2,
      "x": 887,
      "y": 1018
    },
    {
      "t": 90258,
      "e": 88623,
      "ty": 41,
      "x": 29675,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 90272,
      "e": 88637,
      "ty": 7,
      "x": 887,
      "y": 1004,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 90309,
      "e": 88674,
      "ty": 2,
      "x": 887,
      "y": 1002
    },
    {
      "t": 90409,
      "e": 88774,
      "ty": 2,
      "x": 888,
      "y": 999
    },
    {
      "t": 90506,
      "e": 88871,
      "ty": 6,
      "x": 878,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 90509,
      "e": 88874,
      "ty": 2,
      "x": 878,
      "y": 1005
    },
    {
      "t": 90509,
      "e": 88874,
      "ty": 41,
      "x": 25036,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 90609,
      "e": 88974,
      "ty": 2,
      "x": 877,
      "y": 1021
    },
    {
      "t": 90759,
      "e": 89124,
      "ty": 41,
      "x": 24521,
      "y": 31774,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 93009,
      "e": 91374,
      "ty": 2,
      "x": 877,
      "y": 1022
    },
    {
      "t": 93009,
      "e": 91374,
      "ty": 41,
      "x": 24521,
      "y": 33760,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 94284,
      "e": 92649,
      "ty": 3,
      "x": 877,
      "y": 1022,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 94285,
      "e": 92650,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 94286,
      "e": 92651,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 94362,
      "e": 92727,
      "ty": 4,
      "x": 24521,
      "y": 33760,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 94362,
      "e": 92727,
      "ty": 5,
      "x": 877,
      "y": 1022,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 94363,
      "e": 92728,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 94364,
      "e": 92729,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 94365,
      "e": 92730,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 95698,
      "e": 94063,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 96409,
      "e": 94774,
      "ty": 2,
      "x": 704,
      "y": 834
    },
    {
      "t": 96510,
      "e": 94875,
      "ty": 2,
      "x": 596,
      "y": 727
    },
    {
      "t": 96510,
      "e": 94875,
      "ty": 41,
      "x": 14884,
      "y": 34239,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 96709,
      "e": 95074,
      "ty": 2,
      "x": 596,
      "y": 721
    },
    {
      "t": 96759,
      "e": 95124,
      "ty": 41,
      "x": 14786,
      "y": 30143,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 96809,
      "e": 95174,
      "ty": 2,
      "x": 594,
      "y": 720
    },
    {
      "t": 97209,
      "e": 95574,
      "ty": 2,
      "x": 594,
      "y": 719
    },
    {
      "t": 97260,
      "e": 95625,
      "ty": 41,
      "x": 14786,
      "y": 29558,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 97760,
      "e": 96125,
      "ty": 41,
      "x": 15425,
      "y": 33654,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 97810,
      "e": 96175,
      "ty": 2,
      "x": 805,
      "y": 848
    },
    {
      "t": 97909,
      "e": 96274,
      "ty": 2,
      "x": 973,
      "y": 986
    },
    {
      "t": 98009,
      "e": 96374,
      "ty": 2,
      "x": 974,
      "y": 1015
    },
    {
      "t": 98010,
      "e": 96375,
      "ty": 41,
      "x": 33480,
      "y": 61540,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 98110,
      "e": 96475,
      "ty": 2,
      "x": 977,
      "y": 1046
    },
    {
      "t": 98209,
      "e": 96574,
      "ty": 2,
      "x": 976,
      "y": 1067
    },
    {
      "t": 98259,
      "e": 96624,
      "ty": 41,
      "x": 33579,
      "y": 65141,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 98309,
      "e": 96674,
      "ty": 2,
      "x": 974,
      "y": 1069
    },
    {
      "t": 98346,
      "e": 96711,
      "ty": 6,
      "x": 970,
      "y": 1074,
      "ta": "#start"
    },
    {
      "t": 98409,
      "e": 96774,
      "ty": 2,
      "x": 967,
      "y": 1086
    },
    {
      "t": 98510,
      "e": 96875,
      "ty": 2,
      "x": 965,
      "y": 1092
    },
    {
      "t": 98510,
      "e": 96875,
      "ty": 41,
      "x": 30309,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 100009,
      "e": 98374,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 101808,
      "e": 100173,
      "ty": 2,
      "x": 965,
      "y": 1091
    },
    {
      "t": 102009,
      "e": 100374,
      "ty": 41,
      "x": 30309,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 110009,
      "e": 105374,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 119413,
      "e": 105374,
      "ty": 2,
      "x": 969,
      "y": 1080
    },
    {
      "t": 119510,
      "e": 105471,
      "ty": 7,
      "x": 983,
      "y": 1070,
      "ta": "#start"
    },
    {
      "t": 119513,
      "e": 105474,
      "ty": 2,
      "x": 983,
      "y": 1070
    },
    {
      "t": 119513,
      "e": 105474,
      "ty": 41,
      "x": 33923,
      "y": 65348,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 119612,
      "e": 105573,
      "ty": 2,
      "x": 942,
      "y": 1051
    },
    {
      "t": 119713,
      "e": 105674,
      "ty": 2,
      "x": 918,
      "y": 1043
    },
    {
      "t": 119763,
      "e": 105724,
      "ty": 41,
      "x": 28561,
      "y": 62994,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 119813,
      "e": 105774,
      "ty": 2,
      "x": 821,
      "y": 1028
    },
    {
      "t": 119913,
      "e": 105874,
      "ty": 2,
      "x": 756,
      "y": 972
    },
    {
      "t": 120013,
      "e": 105974,
      "ty": 2,
      "x": 736,
      "y": 878
    },
    {
      "t": 120013,
      "e": 105974,
      "ty": 41,
      "x": 21771,
      "y": 12909,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 120113,
      "e": 106074,
      "ty": 2,
      "x": 785,
      "y": 831
    },
    {
      "t": 120213,
      "e": 106174,
      "ty": 2,
      "x": 848,
      "y": 825
    },
    {
      "t": 120264,
      "e": 106225,
      "ty": 41,
      "x": 27282,
      "y": 31030,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 120513,
      "e": 106474,
      "ty": 2,
      "x": 858,
      "y": 835
    },
    {
      "t": 120513,
      "e": 106474,
      "ty": 41,
      "x": 27774,
      "y": 42733,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 120913,
      "e": 106874,
      "ty": 2,
      "x": 859,
      "y": 835
    },
    {
      "t": 121014,
      "e": 106975,
      "ty": 41,
      "x": 27823,
      "y": 42733,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 121113,
      "e": 107074,
      "ty": 2,
      "x": 860,
      "y": 835
    },
    {
      "t": 121213,
      "e": 107174,
      "ty": 2,
      "x": 922,
      "y": 739
    },
    {
      "t": 121264,
      "e": 107225,
      "ty": 41,
      "x": 37023,
      "y": 40380,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 121313,
      "e": 107274,
      "ty": 2,
      "x": 1078,
      "y": 527
    },
    {
      "t": 121413,
      "e": 107374,
      "ty": 2,
      "x": 1059,
      "y": 506
    },
    {
      "t": 121513,
      "e": 107474,
      "ty": 2,
      "x": 703,
      "y": 404
    },
    {
      "t": 121513,
      "e": 107474,
      "ty": 41,
      "x": 20148,
      "y": 18346,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 121613,
      "e": 107574,
      "ty": 2,
      "x": 497,
      "y": 401
    },
    {
      "t": 121713,
      "e": 107674,
      "ty": 2,
      "x": 482,
      "y": 421
    },
    {
      "t": 121764,
      "e": 107725,
      "ty": 41,
      "x": 9226,
      "y": 32389,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 121813,
      "e": 107774,
      "ty": 2,
      "x": 481,
      "y": 429
    },
    {
      "t": 121913,
      "e": 107874,
      "ty": 2,
      "x": 514,
      "y": 523
    },
    {
      "t": 122013,
      "e": 107974,
      "ty": 2,
      "x": 622,
      "y": 606
    },
    {
      "t": 122013,
      "e": 107974,
      "ty": 41,
      "x": 16163,
      "y": 48182,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 122113,
      "e": 108074,
      "ty": 2,
      "x": 903,
      "y": 611
    },
    {
      "t": 122213,
      "e": 108174,
      "ty": 2,
      "x": 1063,
      "y": 586
    },
    {
      "t": 122264,
      "e": 108225,
      "ty": 41,
      "x": 40220,
      "y": 39600,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 122313,
      "e": 108274,
      "ty": 2,
      "x": 1158,
      "y": 586
    },
    {
      "t": 122413,
      "e": 108374,
      "ty": 2,
      "x": 1141,
      "y": 625
    },
    {
      "t": 122514,
      "e": 108475,
      "ty": 2,
      "x": 813,
      "y": 665
    },
    {
      "t": 122514,
      "e": 108475,
      "ty": 41,
      "x": 25560,
      "y": 38269,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 122613,
      "e": 108574,
      "ty": 2,
      "x": 718,
      "y": 664
    },
    {
      "t": 122713,
      "e": 108674,
      "ty": 2,
      "x": 696,
      "y": 669
    },
    {
      "t": 122763,
      "e": 108724,
      "ty": 41,
      "x": 18377,
      "y": 13759,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 122813,
      "e": 108774,
      "ty": 2,
      "x": 638,
      "y": 726
    },
    {
      "t": 122913,
      "e": 108874,
      "ty": 2,
      "x": 603,
      "y": 758
    },
    {
      "t": 123013,
      "e": 108974,
      "ty": 2,
      "x": 602,
      "y": 758
    },
    {
      "t": 123014,
      "e": 108975,
      "ty": 41,
      "x": 15179,
      "y": 52378,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 123314,
      "e": 109275,
      "ty": 2,
      "x": 602,
      "y": 761
    },
    {
      "t": 123413,
      "e": 109374,
      "ty": 2,
      "x": 699,
      "y": 769
    },
    {
      "t": 123513,
      "e": 109474,
      "ty": 2,
      "x": 901,
      "y": 799
    },
    {
      "t": 123513,
      "e": 109474,
      "ty": 41,
      "x": 29889,
      "y": 603,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 123735,
      "e": 109696,
      "ty": 3,
      "x": 901,
      "y": 799,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 123758,
      "e": 109719,
      "ty": 3,
      "x": 901,
      "y": 799,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 124317,
      "e": 110278,
      "ty": 4,
      "x": 29889,
      "y": 603,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 124318,
      "e": 110279,
      "ty": 5,
      "x": 901,
      "y": 799,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 124519,
      "e": 110480,
      "ty": 3,
      "x": 815,
      "y": 786,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 124597,
      "e": 110558,
      "ty": 4,
      "x": 25658,
      "y": 52279,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 124598,
      "e": 110559,
      "ty": 5,
      "x": 815,
      "y": 786,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 124613,
      "e": 110574,
      "ty": 2,
      "x": 815,
      "y": 786
    },
    {
      "t": 124713,
      "e": 110674,
      "ty": 2,
      "x": 817,
      "y": 785
    },
    {
      "t": 124763,
      "e": 110724,
      "ty": 41,
      "x": 26052,
      "y": 51931,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 124812,
      "e": 110773,
      "ty": 2,
      "x": 834,
      "y": 783
    },
    {
      "t": 124913,
      "e": 110874,
      "ty": 2,
      "x": 898,
      "y": 808
    },
    {
      "t": 125014,
      "e": 110975,
      "ty": 2,
      "x": 898,
      "y": 809
    },
    {
      "t": 125014,
      "e": 110975,
      "ty": 41,
      "x": 29741,
      "y": 12306,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 125213,
      "e": 111174,
      "ty": 2,
      "x": 899,
      "y": 809
    },
    {
      "t": 125263,
      "e": 111224,
      "ty": 41,
      "x": 29692,
      "y": 14646,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 125313,
      "e": 111274,
      "ty": 2,
      "x": 879,
      "y": 811
    },
    {
      "t": 125412,
      "e": 111373,
      "ty": 2,
      "x": 833,
      "y": 778
    },
    {
      "t": 125512,
      "e": 111473,
      "ty": 2,
      "x": 827,
      "y": 752
    },
    {
      "t": 125513,
      "e": 111474,
      "ty": 41,
      "x": 26248,
      "y": 48867,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 125614,
      "e": 111575,
      "ty": 2,
      "x": 846,
      "y": 738
    },
    {
      "t": 125713,
      "e": 111674,
      "ty": 2,
      "x": 859,
      "y": 742
    },
    {
      "t": 125764,
      "e": 111725,
      "ty": 41,
      "x": 28019,
      "y": 44771,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 125813,
      "e": 111774,
      "ty": 2,
      "x": 866,
      "y": 748
    },
    {
      "t": 125912,
      "e": 111873,
      "ty": 2,
      "x": 885,
      "y": 777
    },
    {
      "t": 126013,
      "e": 111974,
      "ty": 2,
      "x": 902,
      "y": 795
    },
    {
      "t": 126013,
      "e": 111974,
      "ty": 41,
      "x": 29938,
      "y": 53321,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 126112,
      "e": 112073,
      "ty": 2,
      "x": 941,
      "y": 869
    },
    {
      "t": 126213,
      "e": 112174,
      "ty": 2,
      "x": 975,
      "y": 967
    },
    {
      "t": 126262,
      "e": 112223,
      "ty": 41,
      "x": 33776,
      "y": 59670,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 126313,
      "e": 112274,
      "ty": 2,
      "x": 981,
      "y": 999
    },
    {
      "t": 126412,
      "e": 112373,
      "ty": 2,
      "x": 982,
      "y": 1015
    },
    {
      "t": 126512,
      "e": 112473,
      "ty": 2,
      "x": 967,
      "y": 1046
    },
    {
      "t": 126513,
      "e": 112474,
      "ty": 41,
      "x": 33136,
      "y": 63686,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 126588,
      "e": 112549,
      "ty": 6,
      "x": 956,
      "y": 1076,
      "ta": "#start"
    },
    {
      "t": 126612,
      "e": 112573,
      "ty": 2,
      "x": 954,
      "y": 1093
    },
    {
      "t": 126639,
      "e": 112600,
      "ty": 7,
      "x": 962,
      "y": 1110,
      "ta": "#start"
    },
    {
      "t": 126712,
      "e": 112673,
      "ty": 2,
      "x": 963,
      "y": 1110
    },
    {
      "t": 126762,
      "e": 112723,
      "ty": 41,
      "x": 34405,
      "y": 20670,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 127112,
      "e": 113073,
      "ty": 2,
      "x": 962,
      "y": 1109
    },
    {
      "t": 127208,
      "e": 113169,
      "ty": 6,
      "x": 962,
      "y": 1105,
      "ta": "#start"
    },
    {
      "t": 127212,
      "e": 113173,
      "ty": 2,
      "x": 962,
      "y": 1105
    },
    {
      "t": 127263,
      "e": 113224,
      "ty": 41,
      "x": 31948,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 127312,
      "e": 113273,
      "ty": 2,
      "x": 969,
      "y": 1088
    },
    {
      "t": 127513,
      "e": 113474,
      "ty": 41,
      "x": 32494,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 129662,
      "e": 115623,
      "ty": 3,
      "x": 969,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 129663,
      "e": 115624,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 129732,
      "e": 115693,
      "ty": 4,
      "x": 32494,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 129733,
      "e": 115694,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 129733,
      "e": 115694,
      "ty": 5,
      "x": 969,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 129734,
      "e": 115695,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 130013,
      "e": 115974,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 130776,
      "e": 116737,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 132247,
      "e": 118208,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 13374, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 13380, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"2WQ0M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 51261, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 65732, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"2WQ0M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 20117, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"November\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"114\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 86855, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"2WQ0M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 34256, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 122444, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"2WQ0M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 13177, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 136625, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"2WQ0M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 75068, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 213057, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"2WQ0M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -A -12 PM-12 PM-11 AM-A -F -H -H -H -04 PM-04 PM-02 PM-04 PM-04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:979,y:1054,t:1527271857955};\\\", \\\"{x:1022,y:996,t:1527271857971};\\\", \\\"{x:1047,y:957,t:1527271857988};\\\", \\\"{x:1071,y:919,t:1527271858004};\\\", \\\"{x:1107,y:863,t:1527271858022};\\\", \\\"{x:1151,y:811,t:1527271858038};\\\", \\\"{x:1201,y:765,t:1527271858054};\\\", \\\"{x:1248,y:724,t:1527271858072};\\\", \\\"{x:1297,y:693,t:1527271858088};\\\", \\\"{x:1329,y:676,t:1527271858105};\\\", \\\"{x:1344,y:666,t:1527271858121};\\\", \\\"{x:1360,y:659,t:1527271858137};\\\", \\\"{x:1376,y:655,t:1527271858154};\\\", \\\"{x:1378,y:655,t:1527271858173};\\\", \\\"{x:1379,y:655,t:1527271858370};\\\", \\\"{x:1381,y:655,t:1527271858378};\\\", \\\"{x:1383,y:655,t:1527271858402};\\\", \\\"{x:1384,y:655,t:1527271858418};\\\", \\\"{x:1386,y:655,t:1527271858426};\\\", \\\"{x:1387,y:654,t:1527271858438};\\\", \\\"{x:1389,y:653,t:1527271858454};\\\", \\\"{x:1391,y:652,t:1527271858472};\\\", \\\"{x:1395,y:650,t:1527271858488};\\\", \\\"{x:1397,y:649,t:1527271858505};\\\", \\\"{x:1397,y:650,t:1527271858699};\\\", \\\"{x:1397,y:653,t:1527271858706};\\\", \\\"{x:1397,y:657,t:1527271858721};\\\", \\\"{x:1395,y:676,t:1527271858738};\\\", \\\"{x:1392,y:686,t:1527271858755};\\\", \\\"{x:1391,y:700,t:1527271858771};\\\", \\\"{x:1391,y:714,t:1527271858789};\\\", \\\"{x:1391,y:720,t:1527271858805};\\\", \\\"{x:1391,y:725,t:1527271858822};\\\", \\\"{x:1391,y:729,t:1527271858838};\\\", \\\"{x:1391,y:732,t:1527271858856};\\\", \\\"{x:1390,y:736,t:1527271858872};\\\", \\\"{x:1390,y:741,t:1527271858888};\\\", \\\"{x:1388,y:752,t:1527271858905};\\\", \\\"{x:1384,y:776,t:1527271858922};\\\", \\\"{x:1381,y:794,t:1527271858938};\\\", \\\"{x:1378,y:809,t:1527271858955};\\\", \\\"{x:1376,y:826,t:1527271858971};\\\", \\\"{x:1373,y:843,t:1527271858988};\\\", \\\"{x:1371,y:855,t:1527271859005};\\\", \\\"{x:1370,y:868,t:1527271859022};\\\", \\\"{x:1367,y:880,t:1527271859038};\\\", \\\"{x:1367,y:885,t:1527271859055};\\\", \\\"{x:1366,y:889,t:1527271859071};\\\", \\\"{x:1366,y:890,t:1527271859088};\\\", \\\"{x:1366,y:893,t:1527271859105};\\\", \\\"{x:1365,y:895,t:1527271859121};\\\", \\\"{x:1363,y:899,t:1527271859138};\\\", \\\"{x:1363,y:900,t:1527271859155};\\\", \\\"{x:1362,y:903,t:1527271859172};\\\", \\\"{x:1361,y:904,t:1527271859188};\\\", \\\"{x:1361,y:905,t:1527271859205};\\\", \\\"{x:1360,y:907,t:1527271859223};\\\", \\\"{x:1360,y:909,t:1527271859238};\\\", \\\"{x:1358,y:911,t:1527271859255};\\\", \\\"{x:1357,y:912,t:1527271859271};\\\", \\\"{x:1357,y:913,t:1527271859287};\\\", \\\"{x:1356,y:916,t:1527271859305};\\\", \\\"{x:1355,y:918,t:1527271859321};\\\", \\\"{x:1354,y:919,t:1527271859337};\\\", \\\"{x:1354,y:920,t:1527271859355};\\\", \\\"{x:1354,y:921,t:1527271859371};\\\", \\\"{x:1353,y:921,t:1527271859388};\\\", \\\"{x:1352,y:922,t:1527271860002};\\\", \\\"{x:1351,y:923,t:1527271860067};\\\", \\\"{x:1350,y:923,t:1527271860115};\\\", \\\"{x:1350,y:924,t:1527271860179};\\\", \\\"{x:1349,y:925,t:1527271860307};\\\", \\\"{x:1348,y:926,t:1527271860435};\\\", \\\"{x:1348,y:927,t:1527271860555};\\\", \\\"{x:1347,y:928,t:1527271860913};\\\", \\\"{x:1346,y:928,t:1527271860923};\\\", \\\"{x:1345,y:928,t:1527271861011};\\\", \\\"{x:1344,y:929,t:1527271861034};\\\", \\\"{x:1343,y:929,t:1527271861050};\\\", \\\"{x:1342,y:929,t:1527271861066};\\\", \\\"{x:1341,y:930,t:1527271861074};\\\", \\\"{x:1340,y:930,t:1527271861090};\\\", \\\"{x:1338,y:932,t:1527271861106};\\\", \\\"{x:1335,y:932,t:1527271861124};\\\", \\\"{x:1332,y:934,t:1527271861139};\\\", \\\"{x:1330,y:935,t:1527271861157};\\\", \\\"{x:1327,y:936,t:1527271861173};\\\", \\\"{x:1323,y:938,t:1527271861189};\\\", \\\"{x:1315,y:940,t:1527271861206};\\\", \\\"{x:1303,y:943,t:1527271861225};\\\", \\\"{x:1293,y:943,t:1527271861241};\\\", \\\"{x:1289,y:944,t:1527271861257};\\\", \\\"{x:1284,y:946,t:1527271861274};\\\", \\\"{x:1283,y:946,t:1527271861290};\\\", \\\"{x:1281,y:946,t:1527271861330};\\\", \\\"{x:1280,y:947,t:1527271861363};\\\", \\\"{x:1280,y:948,t:1527271861426};\\\", \\\"{x:1283,y:948,t:1527271861523};\\\", \\\"{x:1289,y:943,t:1527271861540};\\\", \\\"{x:1294,y:931,t:1527271861556};\\\", \\\"{x:1300,y:914,t:1527271861573};\\\", \\\"{x:1307,y:886,t:1527271861591};\\\", \\\"{x:1307,y:856,t:1527271861607};\\\", \\\"{x:1306,y:828,t:1527271861626};\\\", \\\"{x:1297,y:806,t:1527271861641};\\\", \\\"{x:1292,y:792,t:1527271861658};\\\", \\\"{x:1286,y:780,t:1527271861674};\\\", \\\"{x:1280,y:769,t:1527271861690};\\\", \\\"{x:1278,y:768,t:1527271861708};\\\", \\\"{x:1277,y:767,t:1527271861723};\\\", \\\"{x:1276,y:767,t:1527271861762};\\\", \\\"{x:1275,y:767,t:1527271861778};\\\", \\\"{x:1273,y:767,t:1527271861790};\\\", \\\"{x:1270,y:767,t:1527271861807};\\\", \\\"{x:1269,y:767,t:1527271861823};\\\", \\\"{x:1268,y:766,t:1527271861840};\\\", \\\"{x:1266,y:766,t:1527271861856};\\\", \\\"{x:1264,y:766,t:1527271861872};\\\", \\\"{x:1261,y:772,t:1527271861889};\\\", \\\"{x:1261,y:775,t:1527271861907};\\\", \\\"{x:1259,y:780,t:1527271861923};\\\", \\\"{x:1259,y:785,t:1527271861941};\\\", \\\"{x:1259,y:790,t:1527271861957};\\\", \\\"{x:1259,y:793,t:1527271861974};\\\", \\\"{x:1259,y:796,t:1527271861990};\\\", \\\"{x:1259,y:797,t:1527271862007};\\\", \\\"{x:1259,y:798,t:1527271862025};\\\", \\\"{x:1259,y:799,t:1527271862040};\\\", \\\"{x:1260,y:799,t:1527271862082};\\\", \\\"{x:1261,y:799,t:1527271862107};\\\", \\\"{x:1262,y:799,t:1527271862125};\\\", \\\"{x:1262,y:800,t:1527271862141};\\\", \\\"{x:1263,y:800,t:1527271862162};\\\", \\\"{x:1264,y:800,t:1527271862174};\\\", \\\"{x:1265,y:800,t:1527271862190};\\\", \\\"{x:1267,y:801,t:1527271862218};\\\", \\\"{x:1268,y:801,t:1527271862234};\\\", \\\"{x:1270,y:802,t:1527271862258};\\\", \\\"{x:1274,y:804,t:1527271862274};\\\", \\\"{x:1280,y:806,t:1527271862291};\\\", \\\"{x:1282,y:807,t:1527271862307};\\\", \\\"{x:1283,y:807,t:1527271862331};\\\", \\\"{x:1283,y:808,t:1527271862347};\\\", \\\"{x:1283,y:809,t:1527271862362};\\\", \\\"{x:1283,y:810,t:1527271862379};\\\", \\\"{x:1283,y:812,t:1527271862395};\\\", \\\"{x:1283,y:813,t:1527271862411};\\\", \\\"{x:1283,y:815,t:1527271862435};\\\", \\\"{x:1283,y:816,t:1527271862475};\\\", \\\"{x:1282,y:817,t:1527271862690};\\\", \\\"{x:1282,y:818,t:1527271862708};\\\", \\\"{x:1282,y:819,t:1527271862779};\\\", \\\"{x:1281,y:822,t:1527271863482};\\\", \\\"{x:1281,y:823,t:1527271863506};\\\", \\\"{x:1281,y:824,t:1527271863514};\\\", \\\"{x:1281,y:825,t:1527271863534};\\\", \\\"{x:1281,y:826,t:1527271863558};\\\", \\\"{x:1281,y:828,t:1527271863575};\\\", \\\"{x:1281,y:829,t:1527271863591};\\\", \\\"{x:1281,y:832,t:1527271863608};\\\", \\\"{x:1281,y:833,t:1527271863625};\\\", \\\"{x:1281,y:837,t:1527271863641};\\\", \\\"{x:1281,y:839,t:1527271863658};\\\", \\\"{x:1281,y:841,t:1527271863675};\\\", \\\"{x:1282,y:844,t:1527271863691};\\\", \\\"{x:1283,y:847,t:1527271863708};\\\", \\\"{x:1286,y:850,t:1527271863726};\\\", \\\"{x:1287,y:854,t:1527271863741};\\\", \\\"{x:1290,y:858,t:1527271863758};\\\", \\\"{x:1294,y:862,t:1527271863775};\\\", \\\"{x:1296,y:864,t:1527271863791};\\\", \\\"{x:1301,y:869,t:1527271863808};\\\", \\\"{x:1302,y:873,t:1527271863826};\\\", \\\"{x:1307,y:877,t:1527271863841};\\\", \\\"{x:1312,y:882,t:1527271863858};\\\", \\\"{x:1315,y:884,t:1527271863876};\\\", \\\"{x:1319,y:889,t:1527271863892};\\\", \\\"{x:1323,y:894,t:1527271863908};\\\", \\\"{x:1327,y:900,t:1527271863925};\\\", \\\"{x:1329,y:903,t:1527271863942};\\\", \\\"{x:1330,y:905,t:1527271863958};\\\", \\\"{x:1331,y:907,t:1527271863976};\\\", \\\"{x:1332,y:912,t:1527271863991};\\\", \\\"{x:1335,y:915,t:1527271864009};\\\", \\\"{x:1335,y:918,t:1527271864026};\\\", \\\"{x:1336,y:922,t:1527271864042};\\\", \\\"{x:1336,y:928,t:1527271864059};\\\", \\\"{x:1337,y:933,t:1527271864075};\\\", \\\"{x:1338,y:937,t:1527271864092};\\\", \\\"{x:1340,y:941,t:1527271864108};\\\", \\\"{x:1340,y:949,t:1527271864126};\\\", \\\"{x:1341,y:952,t:1527271864142};\\\", \\\"{x:1341,y:956,t:1527271864158};\\\", \\\"{x:1342,y:959,t:1527271864176};\\\", \\\"{x:1343,y:962,t:1527271864192};\\\", \\\"{x:1343,y:965,t:1527271864208};\\\", \\\"{x:1343,y:967,t:1527271864226};\\\", \\\"{x:1345,y:969,t:1527271864243};\\\", \\\"{x:1345,y:972,t:1527271864259};\\\", \\\"{x:1345,y:974,t:1527271864276};\\\", \\\"{x:1346,y:978,t:1527271864292};\\\", \\\"{x:1346,y:979,t:1527271864308};\\\", \\\"{x:1347,y:980,t:1527271864326};\\\", \\\"{x:1347,y:981,t:1527271864343};\\\", \\\"{x:1347,y:982,t:1527271864363};\\\", \\\"{x:1348,y:983,t:1527271864379};\\\", \\\"{x:1348,y:984,t:1527271864394};\\\", \\\"{x:1349,y:984,t:1527271864410};\\\", \\\"{x:1349,y:985,t:1527271864427};\\\", \\\"{x:1349,y:986,t:1527271864658};\\\", \\\"{x:1348,y:986,t:1527271864690};\\\", \\\"{x:1346,y:986,t:1527271864707};\\\", \\\"{x:1344,y:986,t:1527271864714};\\\", \\\"{x:1343,y:986,t:1527271864726};\\\", \\\"{x:1341,y:985,t:1527271864743};\\\", \\\"{x:1339,y:985,t:1527271864759};\\\", \\\"{x:1335,y:985,t:1527271864776};\\\", \\\"{x:1329,y:983,t:1527271864792};\\\", \\\"{x:1319,y:980,t:1527271864810};\\\", \\\"{x:1307,y:978,t:1527271864825};\\\", \\\"{x:1286,y:974,t:1527271864842};\\\", \\\"{x:1271,y:972,t:1527271864860};\\\", \\\"{x:1259,y:969,t:1527271864876};\\\", \\\"{x:1254,y:968,t:1527271864892};\\\", \\\"{x:1251,y:966,t:1527271864910};\\\", \\\"{x:1249,y:966,t:1527271864925};\\\", \\\"{x:1248,y:966,t:1527271864943};\\\", \\\"{x:1246,y:966,t:1527271864960};\\\", \\\"{x:1244,y:965,t:1527271864976};\\\", \\\"{x:1243,y:965,t:1527271864992};\\\", \\\"{x:1242,y:965,t:1527271865010};\\\", \\\"{x:1240,y:965,t:1527271865027};\\\", \\\"{x:1239,y:965,t:1527271865042};\\\", \\\"{x:1238,y:965,t:1527271865060};\\\", \\\"{x:1236,y:965,t:1527271865076};\\\", \\\"{x:1235,y:965,t:1527271865093};\\\", \\\"{x:1234,y:963,t:1527271865110};\\\", \\\"{x:1233,y:963,t:1527271865162};\\\", \\\"{x:1232,y:963,t:1527271865955};\\\", \\\"{x:1232,y:962,t:1527271865962};\\\", \\\"{x:1233,y:961,t:1527271865979};\\\", \\\"{x:1235,y:960,t:1527271865994};\\\", \\\"{x:1237,y:960,t:1527271866027};\\\", \\\"{x:1237,y:959,t:1527271866043};\\\", \\\"{x:1238,y:959,t:1527271866061};\\\", \\\"{x:1238,y:958,t:1527271866077};\\\", \\\"{x:1239,y:958,t:1527271866106};\\\", \\\"{x:1240,y:957,t:1527271867210};\\\", \\\"{x:1241,y:957,t:1527271867258};\\\", \\\"{x:1242,y:956,t:1527271867283};\\\", \\\"{x:1243,y:955,t:1527271867323};\\\", \\\"{x:1244,y:955,t:1527271867354};\\\", \\\"{x:1245,y:954,t:1527271867601};\\\", \\\"{x:1246,y:954,t:1527271871491};\\\", \\\"{x:1247,y:952,t:1527271871514};\\\", \\\"{x:1252,y:946,t:1527271871531};\\\", \\\"{x:1259,y:935,t:1527271871548};\\\", \\\"{x:1265,y:925,t:1527271871564};\\\", \\\"{x:1269,y:915,t:1527271871581};\\\", \\\"{x:1274,y:902,t:1527271871597};\\\", \\\"{x:1279,y:892,t:1527271871613};\\\", \\\"{x:1282,y:884,t:1527271871631};\\\", \\\"{x:1285,y:877,t:1527271871648};\\\", \\\"{x:1286,y:872,t:1527271871665};\\\", \\\"{x:1287,y:871,t:1527271871681};\\\", \\\"{x:1288,y:869,t:1527271871698};\\\", \\\"{x:1288,y:868,t:1527271871714};\\\", \\\"{x:1288,y:867,t:1527271871883};\\\", \\\"{x:1289,y:865,t:1527271871898};\\\", \\\"{x:1289,y:863,t:1527271871915};\\\", \\\"{x:1289,y:861,t:1527271871931};\\\", \\\"{x:1289,y:860,t:1527271871948};\\\", \\\"{x:1289,y:859,t:1527271871965};\\\", \\\"{x:1289,y:857,t:1527271871981};\\\", \\\"{x:1289,y:856,t:1527271871998};\\\", \\\"{x:1289,y:852,t:1527271872015};\\\", \\\"{x:1289,y:849,t:1527271872030};\\\", \\\"{x:1289,y:845,t:1527271872048};\\\", \\\"{x:1289,y:842,t:1527271872065};\\\", \\\"{x:1289,y:839,t:1527271872081};\\\", \\\"{x:1289,y:836,t:1527271872098};\\\", \\\"{x:1289,y:835,t:1527271872115};\\\", \\\"{x:1289,y:834,t:1527271872146};\\\", \\\"{x:1290,y:832,t:1527271872170};\\\", \\\"{x:1291,y:832,t:1527271872234};\\\", \\\"{x:1290,y:832,t:1527271872370};\\\", \\\"{x:1289,y:832,t:1527271872386};\\\", \\\"{x:1289,y:831,t:1527271872397};\\\", \\\"{x:1288,y:831,t:1527271872415};\\\", \\\"{x:1287,y:831,t:1527271872432};\\\", \\\"{x:1286,y:831,t:1527271872451};\\\", \\\"{x:1285,y:831,t:1527271872594};\\\", \\\"{x:1284,y:831,t:1527271872706};\\\", \\\"{x:1283,y:831,t:1527271872754};\\\", \\\"{x:1282,y:831,t:1527271872826};\\\", \\\"{x:1281,y:831,t:1527271877043};\\\", \\\"{x:1281,y:832,t:1527271877066};\\\", \\\"{x:1280,y:832,t:1527271877092};\\\", \\\"{x:1280,y:833,t:1527271877101};\\\", \\\"{x:1279,y:834,t:1527271877346};\\\", \\\"{x:1279,y:835,t:1527271877378};\\\", \\\"{x:1278,y:836,t:1527271877395};\\\", \\\"{x:1276,y:837,t:1527271877633};\\\", \\\"{x:1275,y:837,t:1527271877641};\\\", \\\"{x:1269,y:837,t:1527271877652};\\\", \\\"{x:1251,y:837,t:1527271877669};\\\", \\\"{x:1210,y:837,t:1527271877685};\\\", \\\"{x:1139,y:832,t:1527271877702};\\\", \\\"{x:1033,y:812,t:1527271877719};\\\", \\\"{x:889,y:773,t:1527271877734};\\\", \\\"{x:724,y:728,t:1527271877751};\\\", \\\"{x:552,y:676,t:1527271877769};\\\", \\\"{x:386,y:627,t:1527271877786};\\\", \\\"{x:206,y:570,t:1527271877802};\\\", \\\"{x:146,y:550,t:1527271877818};\\\", \\\"{x:121,y:539,t:1527271877838};\\\", \\\"{x:108,y:535,t:1527271877854};\\\", \\\"{x:107,y:534,t:1527271877871};\\\", \\\"{x:106,y:534,t:1527271877905};\\\", \\\"{x:106,y:533,t:1527271877921};\\\", \\\"{x:106,y:528,t:1527271877937};\\\", \\\"{x:113,y:516,t:1527271877955};\\\", \\\"{x:121,y:506,t:1527271877971};\\\", \\\"{x:131,y:497,t:1527271877988};\\\", \\\"{x:146,y:485,t:1527271878005};\\\", \\\"{x:159,y:477,t:1527271878021};\\\", \\\"{x:170,y:470,t:1527271878039};\\\", \\\"{x:186,y:463,t:1527271878054};\\\", \\\"{x:199,y:456,t:1527271878072};\\\", \\\"{x:210,y:454,t:1527271878089};\\\", \\\"{x:216,y:454,t:1527271878105};\\\", \\\"{x:229,y:451,t:1527271878122};\\\", \\\"{x:243,y:450,t:1527271878138};\\\", \\\"{x:262,y:450,t:1527271878155};\\\", \\\"{x:285,y:450,t:1527271878172};\\\", \\\"{x:318,y:450,t:1527271878189};\\\", \\\"{x:347,y:454,t:1527271878205};\\\", \\\"{x:375,y:460,t:1527271878222};\\\", \\\"{x:399,y:464,t:1527271878239};\\\", \\\"{x:414,y:466,t:1527271878255};\\\", \\\"{x:427,y:469,t:1527271878272};\\\", \\\"{x:436,y:470,t:1527271878289};\\\", \\\"{x:445,y:471,t:1527271878306};\\\", \\\"{x:449,y:474,t:1527271878322};\\\", \\\"{x:453,y:474,t:1527271878339};\\\", \\\"{x:455,y:474,t:1527271878356};\\\", \\\"{x:460,y:474,t:1527271878372};\\\", \\\"{x:468,y:474,t:1527271878389};\\\", \\\"{x:480,y:474,t:1527271878406};\\\", \\\"{x:490,y:474,t:1527271878423};\\\", \\\"{x:499,y:474,t:1527271878438};\\\", \\\"{x:501,y:474,t:1527271878456};\\\", \\\"{x:504,y:474,t:1527271878472};\\\", \\\"{x:504,y:475,t:1527271878787};\\\", \\\"{x:503,y:477,t:1527271878818};\\\", \\\"{x:502,y:477,t:1527271878834};\\\", \\\"{x:502,y:478,t:1527271878858};\\\", \\\"{x:502,y:479,t:1527271878898};\\\", \\\"{x:501,y:479,t:1527271878922};\\\", \\\"{x:501,y:481,t:1527271879010};\\\", \\\"{x:500,y:482,t:1527271879066};\\\", \\\"{x:499,y:483,t:1527271879082};\\\", \\\"{x:499,y:484,t:1527271879147};\\\", \\\"{x:498,y:485,t:1527271879157};\\\", \\\"{x:498,y:486,t:1527271879194};\\\", \\\"{x:497,y:487,t:1527271879207};\\\", \\\"{x:496,y:488,t:1527271879226};\\\", \\\"{x:495,y:489,t:1527271879251};\\\", \\\"{x:495,y:490,t:1527271879266};\\\", \\\"{x:493,y:492,t:1527271879282};\\\", \\\"{x:492,y:493,t:1527271879354};\\\", \\\"{x:492,y:494,t:1527271879386};\\\", \\\"{x:491,y:494,t:1527271879402};\\\", \\\"{x:490,y:496,t:1527271879451};\\\", \\\"{x:489,y:498,t:1527271879498};\\\", \\\"{x:488,y:498,t:1527271879513};\\\", \\\"{x:487,y:498,t:1527271879525};\\\", \\\"{x:486,y:499,t:1527271879541};\\\", \\\"{x:485,y:500,t:1527271879558};\\\", \\\"{x:483,y:501,t:1527271879575};\\\", \\\"{x:481,y:503,t:1527271879592};\\\", \\\"{x:478,y:504,t:1527271879608};\\\", \\\"{x:476,y:505,t:1527271879626};\\\", \\\"{x:471,y:505,t:1527271879642};\\\", \\\"{x:470,y:506,t:1527271879659};\\\", \\\"{x:468,y:506,t:1527271879674};\\\", \\\"{x:466,y:506,t:1527271879688};\\\", \\\"{x:465,y:507,t:1527271879706};\\\", \\\"{x:463,y:507,t:1527271879722};\\\", \\\"{x:461,y:508,t:1527271879739};\\\", \\\"{x:459,y:508,t:1527271879755};\\\", \\\"{x:458,y:508,t:1527271879772};\\\", \\\"{x:454,y:509,t:1527271879789};\\\", \\\"{x:453,y:509,t:1527271879806};\\\", \\\"{x:450,y:509,t:1527271879821};\\\", \\\"{x:446,y:509,t:1527271879838};\\\", \\\"{x:442,y:511,t:1527271879855};\\\", \\\"{x:436,y:513,t:1527271879871};\\\", \\\"{x:427,y:516,t:1527271879888};\\\", \\\"{x:416,y:519,t:1527271879906};\\\", \\\"{x:411,y:521,t:1527271879922};\\\", \\\"{x:406,y:523,t:1527271879940};\\\", \\\"{x:404,y:523,t:1527271879956};\\\", \\\"{x:404,y:524,t:1527271879972};\\\", \\\"{x:402,y:525,t:1527271879990};\\\", \\\"{x:400,y:525,t:1527271880006};\\\", \\\"{x:399,y:526,t:1527271880023};\\\", \\\"{x:398,y:527,t:1527271880040};\\\", \\\"{x:397,y:527,t:1527271880057};\\\", \\\"{x:396,y:527,t:1527271880073};\\\", \\\"{x:395,y:527,t:1527271880106};\\\", \\\"{x:398,y:527,t:1527271889007};\\\", \\\"{x:406,y:526,t:1527271889015};\\\", \\\"{x:415,y:525,t:1527271889027};\\\", \\\"{x:428,y:523,t:1527271889045};\\\", \\\"{x:455,y:523,t:1527271889060};\\\", \\\"{x:490,y:525,t:1527271889077};\\\", \\\"{x:581,y:547,t:1527271889094};\\\", \\\"{x:670,y:574,t:1527271889110};\\\", \\\"{x:766,y:595,t:1527271889128};\\\", \\\"{x:845,y:614,t:1527271889144};\\\", \\\"{x:904,y:630,t:1527271889160};\\\", \\\"{x:949,y:638,t:1527271889177};\\\", \\\"{x:982,y:645,t:1527271889194};\\\", \\\"{x:1010,y:650,t:1527271889211};\\\", \\\"{x:1036,y:655,t:1527271889227};\\\", \\\"{x:1056,y:657,t:1527271889244};\\\", \\\"{x:1077,y:664,t:1527271889261};\\\", \\\"{x:1105,y:672,t:1527271889278};\\\", \\\"{x:1124,y:683,t:1527271889294};\\\", \\\"{x:1147,y:693,t:1527271889311};\\\", \\\"{x:1170,y:705,t:1527271889327};\\\", \\\"{x:1190,y:713,t:1527271889344};\\\", \\\"{x:1206,y:722,t:1527271889361};\\\", \\\"{x:1219,y:729,t:1527271889377};\\\", \\\"{x:1231,y:737,t:1527271889394};\\\", \\\"{x:1239,y:744,t:1527271889411};\\\", \\\"{x:1249,y:749,t:1527271889428};\\\", \\\"{x:1256,y:756,t:1527271889444};\\\", \\\"{x:1258,y:757,t:1527271889461};\\\", \\\"{x:1259,y:761,t:1527271889478};\\\", \\\"{x:1260,y:765,t:1527271889494};\\\", \\\"{x:1271,y:783,t:1527271889511};\\\", \\\"{x:1287,y:798,t:1527271889528};\\\", \\\"{x:1311,y:812,t:1527271889545};\\\", \\\"{x:1337,y:822,t:1527271889561};\\\", \\\"{x:1359,y:830,t:1527271889578};\\\", \\\"{x:1380,y:836,t:1527271889594};\\\", \\\"{x:1390,y:837,t:1527271889612};\\\", \\\"{x:1391,y:837,t:1527271889629};\\\", \\\"{x:1392,y:839,t:1527271889823};\\\", \\\"{x:1393,y:839,t:1527271889831};\\\", \\\"{x:1395,y:839,t:1527271889846};\\\", \\\"{x:1397,y:839,t:1527271889862};\\\", \\\"{x:1404,y:839,t:1527271889879};\\\", \\\"{x:1407,y:839,t:1527271889895};\\\", \\\"{x:1409,y:839,t:1527271889911};\\\", \\\"{x:1410,y:839,t:1527271889927};\\\", \\\"{x:1411,y:838,t:1527271890039};\\\", \\\"{x:1412,y:838,t:1527271890070};\\\", \\\"{x:1413,y:838,t:1527271890078};\\\", \\\"{x:1414,y:838,t:1527271890094};\\\", \\\"{x:1418,y:838,t:1527271890112};\\\", \\\"{x:1419,y:838,t:1527271890128};\\\", \\\"{x:1420,y:838,t:1527271890145};\\\", \\\"{x:1419,y:838,t:1527271890631};\\\", \\\"{x:1418,y:838,t:1527271890645};\\\", \\\"{x:1413,y:838,t:1527271890662};\\\", \\\"{x:1410,y:838,t:1527271890679};\\\", \\\"{x:1409,y:836,t:1527271890696};\\\", \\\"{x:1407,y:836,t:1527271890713};\\\", \\\"{x:1405,y:836,t:1527271890730};\\\", \\\"{x:1402,y:836,t:1527271890746};\\\", \\\"{x:1399,y:835,t:1527271890762};\\\", \\\"{x:1392,y:834,t:1527271890780};\\\", \\\"{x:1381,y:830,t:1527271890795};\\\", \\\"{x:1374,y:829,t:1527271890813};\\\", \\\"{x:1369,y:826,t:1527271890830};\\\", \\\"{x:1367,y:826,t:1527271890846};\\\", \\\"{x:1362,y:824,t:1527271890863};\\\", \\\"{x:1361,y:824,t:1527271890959};\\\", \\\"{x:1363,y:824,t:1527271891143};\\\", \\\"{x:1366,y:824,t:1527271891151};\\\", \\\"{x:1368,y:824,t:1527271891163};\\\", \\\"{x:1372,y:825,t:1527271891179};\\\", \\\"{x:1374,y:825,t:1527271891197};\\\", \\\"{x:1377,y:825,t:1527271891213};\\\", \\\"{x:1380,y:825,t:1527271891229};\\\", \\\"{x:1388,y:827,t:1527271891247};\\\", \\\"{x:1391,y:827,t:1527271891263};\\\", \\\"{x:1393,y:827,t:1527271891279};\\\", \\\"{x:1395,y:828,t:1527271891297};\\\", \\\"{x:1396,y:828,t:1527271891312};\\\", \\\"{x:1398,y:828,t:1527271891359};\\\", \\\"{x:1399,y:828,t:1527271891391};\\\", \\\"{x:1401,y:828,t:1527271891407};\\\", \\\"{x:1402,y:828,t:1527271891422};\\\", \\\"{x:1402,y:829,t:1527271891430};\\\", \\\"{x:1404,y:829,t:1527271891447};\\\", \\\"{x:1408,y:830,t:1527271891462};\\\", \\\"{x:1409,y:830,t:1527271891480};\\\", \\\"{x:1412,y:832,t:1527271891497};\\\", \\\"{x:1415,y:832,t:1527271891513};\\\", \\\"{x:1417,y:832,t:1527271891529};\\\", \\\"{x:1418,y:832,t:1527271891547};\\\", \\\"{x:1418,y:833,t:1527271891591};\\\", \\\"{x:1419,y:833,t:1527271892023};\\\", \\\"{x:1420,y:835,t:1527271892031};\\\", \\\"{x:1424,y:841,t:1527271892046};\\\", \\\"{x:1429,y:846,t:1527271892063};\\\", \\\"{x:1433,y:852,t:1527271892080};\\\", \\\"{x:1437,y:858,t:1527271892096};\\\", \\\"{x:1440,y:861,t:1527271892113};\\\", \\\"{x:1441,y:863,t:1527271892130};\\\", \\\"{x:1443,y:865,t:1527271892146};\\\", \\\"{x:1443,y:866,t:1527271892163};\\\", \\\"{x:1443,y:869,t:1527271892180};\\\", \\\"{x:1445,y:871,t:1527271892196};\\\", \\\"{x:1446,y:874,t:1527271892213};\\\", \\\"{x:1447,y:876,t:1527271892230};\\\", \\\"{x:1447,y:878,t:1527271892246};\\\", \\\"{x:1448,y:879,t:1527271892264};\\\", \\\"{x:1449,y:879,t:1527271892303};\\\", \\\"{x:1449,y:881,t:1527271892559};\\\", \\\"{x:1450,y:882,t:1527271892575};\\\", \\\"{x:1450,y:884,t:1527271892607};\\\", \\\"{x:1451,y:885,t:1527271892623};\\\", \\\"{x:1451,y:887,t:1527271892655};\\\", \\\"{x:1451,y:888,t:1527271892711};\\\", \\\"{x:1452,y:889,t:1527271892846};\\\", \\\"{x:1452,y:890,t:1527271893407};\\\", \\\"{x:1452,y:891,t:1527271893415};\\\", \\\"{x:1452,y:894,t:1527271893431};\\\", \\\"{x:1455,y:901,t:1527271893447};\\\", \\\"{x:1456,y:907,t:1527271893465};\\\", \\\"{x:1460,y:915,t:1527271893482};\\\", \\\"{x:1463,y:921,t:1527271893498};\\\", \\\"{x:1466,y:930,t:1527271893515};\\\", \\\"{x:1469,y:935,t:1527271893532};\\\", \\\"{x:1469,y:936,t:1527271893548};\\\", \\\"{x:1469,y:937,t:1527271893565};\\\", \\\"{x:1470,y:938,t:1527271893582};\\\", \\\"{x:1470,y:939,t:1527271893632};\\\", \\\"{x:1470,y:940,t:1527271893679};\\\", \\\"{x:1471,y:941,t:1527271893687};\\\", \\\"{x:1471,y:942,t:1527271893703};\\\", \\\"{x:1472,y:943,t:1527271893715};\\\", \\\"{x:1472,y:944,t:1527271893731};\\\", \\\"{x:1472,y:946,t:1527271893748};\\\", \\\"{x:1472,y:947,t:1527271893783};\\\", \\\"{x:1473,y:948,t:1527271893798};\\\", \\\"{x:1473,y:949,t:1527271893815};\\\", \\\"{x:1474,y:951,t:1527271893832};\\\", \\\"{x:1475,y:952,t:1527271893951};\\\", \\\"{x:1476,y:953,t:1527271894039};\\\", \\\"{x:1477,y:954,t:1527271894135};\\\", \\\"{x:1477,y:955,t:1527271894175};\\\", \\\"{x:1478,y:955,t:1527271894311};\\\", \\\"{x:1478,y:956,t:1527271894351};\\\", \\\"{x:1479,y:956,t:1527271894391};\\\", \\\"{x:1479,y:957,t:1527271894791};\\\", \\\"{x:1479,y:958,t:1527271894807};\\\", \\\"{x:1480,y:958,t:1527271894823};\\\", \\\"{x:1475,y:957,t:1527271895135};\\\", \\\"{x:1474,y:957,t:1527271895150};\\\", \\\"{x:1471,y:955,t:1527271895166};\\\", \\\"{x:1469,y:953,t:1527271895182};\\\", \\\"{x:1466,y:946,t:1527271895200};\\\", \\\"{x:1462,y:932,t:1527271895215};\\\", \\\"{x:1453,y:909,t:1527271895233};\\\", \\\"{x:1441,y:880,t:1527271895250};\\\", \\\"{x:1421,y:845,t:1527271895266};\\\", \\\"{x:1407,y:823,t:1527271895283};\\\", \\\"{x:1398,y:808,t:1527271895300};\\\", \\\"{x:1393,y:798,t:1527271895316};\\\", \\\"{x:1392,y:796,t:1527271895332};\\\", \\\"{x:1391,y:794,t:1527271895349};\\\", \\\"{x:1392,y:796,t:1527271895735};\\\", \\\"{x:1392,y:799,t:1527271895749};\\\", \\\"{x:1399,y:809,t:1527271895767};\\\", \\\"{x:1404,y:816,t:1527271895783};\\\", \\\"{x:1409,y:822,t:1527271895800};\\\", \\\"{x:1415,y:830,t:1527271895817};\\\", \\\"{x:1419,y:835,t:1527271895840};\\\", \\\"{x:1421,y:838,t:1527271895849};\\\", \\\"{x:1422,y:840,t:1527271895866};\\\", \\\"{x:1423,y:842,t:1527271895883};\\\", \\\"{x:1424,y:844,t:1527271895901};\\\", \\\"{x:1424,y:845,t:1527271895934};\\\", \\\"{x:1424,y:846,t:1527271895949};\\\", \\\"{x:1425,y:847,t:1527271895966};\\\", \\\"{x:1426,y:847,t:1527271896359};\\\", \\\"{x:1427,y:847,t:1527271896768};\\\", \\\"{x:1430,y:847,t:1527271896784};\\\", \\\"{x:1431,y:847,t:1527271896801};\\\", \\\"{x:1431,y:848,t:1527271896818};\\\", \\\"{x:1430,y:846,t:1527271897614};\\\", \\\"{x:1429,y:846,t:1527271897630};\\\", \\\"{x:1427,y:845,t:1527271897654};\\\", \\\"{x:1425,y:843,t:1527271897668};\\\", \\\"{x:1422,y:840,t:1527271897684};\\\", \\\"{x:1418,y:834,t:1527271897701};\\\", \\\"{x:1417,y:830,t:1527271897717};\\\", \\\"{x:1409,y:816,t:1527271897734};\\\", \\\"{x:1403,y:804,t:1527271897751};\\\", \\\"{x:1394,y:788,t:1527271897767};\\\", \\\"{x:1382,y:765,t:1527271897785};\\\", \\\"{x:1365,y:738,t:1527271897801};\\\", \\\"{x:1353,y:717,t:1527271897818};\\\", \\\"{x:1341,y:697,t:1527271897834};\\\", \\\"{x:1336,y:687,t:1527271897851};\\\", \\\"{x:1335,y:680,t:1527271897868};\\\", \\\"{x:1332,y:667,t:1527271897885};\\\", \\\"{x:1332,y:654,t:1527271897901};\\\", \\\"{x:1330,y:645,t:1527271897917};\\\", \\\"{x:1328,y:640,t:1527271897934};\\\", \\\"{x:1327,y:639,t:1527271897951};\\\", \\\"{x:1326,y:638,t:1527271897975};\\\", \\\"{x:1326,y:637,t:1527271898791};\\\", \\\"{x:1327,y:637,t:1527271898822};\\\", \\\"{x:1328,y:637,t:1527271898951};\\\", \\\"{x:1328,y:638,t:1527271898991};\\\", \\\"{x:1328,y:640,t:1527271899014};\\\", \\\"{x:1328,y:641,t:1527271899030};\\\", \\\"{x:1328,y:643,t:1527271899039};\\\", \\\"{x:1328,y:645,t:1527271899053};\\\", \\\"{x:1327,y:652,t:1527271899069};\\\", \\\"{x:1325,y:664,t:1527271899086};\\\", \\\"{x:1319,y:690,t:1527271899102};\\\", \\\"{x:1311,y:714,t:1527271899119};\\\", \\\"{x:1305,y:734,t:1527271899136};\\\", \\\"{x:1299,y:755,t:1527271899153};\\\", \\\"{x:1290,y:774,t:1527271899170};\\\", \\\"{x:1284,y:788,t:1527271899185};\\\", \\\"{x:1279,y:800,t:1527271899203};\\\", \\\"{x:1275,y:812,t:1527271899219};\\\", \\\"{x:1273,y:819,t:1527271899236};\\\", \\\"{x:1272,y:824,t:1527271899253};\\\", \\\"{x:1270,y:831,t:1527271899269};\\\", \\\"{x:1269,y:835,t:1527271899286};\\\", \\\"{x:1267,y:842,t:1527271899303};\\\", \\\"{x:1265,y:845,t:1527271899320};\\\", \\\"{x:1265,y:849,t:1527271899336};\\\", \\\"{x:1265,y:851,t:1527271899353};\\\", \\\"{x:1265,y:853,t:1527271899370};\\\", \\\"{x:1263,y:855,t:1527271899386};\\\", \\\"{x:1263,y:857,t:1527271899402};\\\", \\\"{x:1263,y:858,t:1527271899420};\\\", \\\"{x:1262,y:860,t:1527271899436};\\\", \\\"{x:1262,y:861,t:1527271899455};\\\", \\\"{x:1262,y:862,t:1527271899471};\\\", \\\"{x:1261,y:863,t:1527271899485};\\\", \\\"{x:1260,y:864,t:1527271899503};\\\", \\\"{x:1259,y:866,t:1527271899520};\\\", \\\"{x:1257,y:869,t:1527271899536};\\\", \\\"{x:1256,y:871,t:1527271899553};\\\", \\\"{x:1255,y:872,t:1527271899570};\\\", \\\"{x:1255,y:871,t:1527271899687};\\\", \\\"{x:1255,y:866,t:1527271899702};\\\", \\\"{x:1259,y:856,t:1527271899720};\\\", \\\"{x:1265,y:840,t:1527271899736};\\\", \\\"{x:1273,y:821,t:1527271899753};\\\", \\\"{x:1282,y:800,t:1527271899770};\\\", \\\"{x:1293,y:782,t:1527271899786};\\\", \\\"{x:1304,y:762,t:1527271899803};\\\", \\\"{x:1314,y:738,t:1527271899820};\\\", \\\"{x:1324,y:717,t:1527271899837};\\\", \\\"{x:1331,y:701,t:1527271899853};\\\", \\\"{x:1339,y:682,t:1527271899870};\\\", \\\"{x:1350,y:656,t:1527271899886};\\\", \\\"{x:1356,y:645,t:1527271899902};\\\", \\\"{x:1362,y:633,t:1527271899920};\\\", \\\"{x:1367,y:625,t:1527271899937};\\\", \\\"{x:1371,y:618,t:1527271899953};\\\", \\\"{x:1373,y:616,t:1527271899970};\\\", \\\"{x:1373,y:615,t:1527271899987};\\\", \\\"{x:1373,y:616,t:1527271900272};\\\", \\\"{x:1373,y:619,t:1527271900287};\\\", \\\"{x:1372,y:621,t:1527271900304};\\\", \\\"{x:1371,y:623,t:1527271900320};\\\", \\\"{x:1371,y:624,t:1527271900337};\\\", \\\"{x:1371,y:625,t:1527271900359};\\\", \\\"{x:1371,y:626,t:1527271900375};\\\", \\\"{x:1371,y:627,t:1527271900390};\\\", \\\"{x:1371,y:629,t:1527271900404};\\\", \\\"{x:1371,y:631,t:1527271900420};\\\", \\\"{x:1371,y:638,t:1527271900437};\\\", \\\"{x:1379,y:652,t:1527271900454};\\\", \\\"{x:1385,y:658,t:1527271900470};\\\", \\\"{x:1403,y:682,t:1527271900486};\\\", \\\"{x:1427,y:707,t:1527271900504};\\\", \\\"{x:1454,y:733,t:1527271900520};\\\", \\\"{x:1490,y:763,t:1527271900537};\\\", \\\"{x:1533,y:797,t:1527271900554};\\\", \\\"{x:1580,y:839,t:1527271900571};\\\", \\\"{x:1610,y:871,t:1527271900587};\\\", \\\"{x:1628,y:891,t:1527271900604};\\\", \\\"{x:1640,y:905,t:1527271900620};\\\", \\\"{x:1649,y:915,t:1527271900637};\\\", \\\"{x:1652,y:919,t:1527271900653};\\\", \\\"{x:1653,y:921,t:1527271900671};\\\", \\\"{x:1653,y:920,t:1527271900775};\\\", \\\"{x:1651,y:919,t:1527271900787};\\\", \\\"{x:1638,y:910,t:1527271900804};\\\", \\\"{x:1615,y:897,t:1527271900823};\\\", \\\"{x:1605,y:891,t:1527271900837};\\\", \\\"{x:1569,y:867,t:1527271900855};\\\", \\\"{x:1546,y:847,t:1527271900871};\\\", \\\"{x:1529,y:828,t:1527271900887};\\\", \\\"{x:1517,y:812,t:1527271900904};\\\", \\\"{x:1508,y:795,t:1527271900921};\\\", \\\"{x:1502,y:779,t:1527271900937};\\\", \\\"{x:1498,y:753,t:1527271900954};\\\", \\\"{x:1493,y:728,t:1527271900971};\\\", \\\"{x:1489,y:702,t:1527271900988};\\\", \\\"{x:1488,y:684,t:1527271901003};\\\", \\\"{x:1488,y:669,t:1527271901021};\\\", \\\"{x:1488,y:658,t:1527271901036};\\\", \\\"{x:1488,y:650,t:1527271901053};\\\", \\\"{x:1488,y:634,t:1527271901070};\\\", \\\"{x:1488,y:628,t:1527271901086};\\\", \\\"{x:1487,y:624,t:1527271901103};\\\", \\\"{x:1486,y:621,t:1527271901120};\\\", \\\"{x:1486,y:620,t:1527271901138};\\\", \\\"{x:1485,y:620,t:1527271901447};\\\", \\\"{x:1484,y:620,t:1527271901463};\\\", \\\"{x:1483,y:620,t:1527271901471};\\\", \\\"{x:1474,y:624,t:1527271901488};\\\", \\\"{x:1462,y:633,t:1527271901504};\\\", \\\"{x:1447,y:646,t:1527271901521};\\\", \\\"{x:1431,y:663,t:1527271901538};\\\", \\\"{x:1419,y:680,t:1527271901555};\\\", \\\"{x:1407,y:697,t:1527271901571};\\\", \\\"{x:1397,y:711,t:1527271901588};\\\", \\\"{x:1393,y:720,t:1527271901605};\\\", \\\"{x:1389,y:727,t:1527271901622};\\\", \\\"{x:1388,y:728,t:1527271901638};\\\", \\\"{x:1387,y:729,t:1527271901654};\\\", \\\"{x:1386,y:728,t:1527271901743};\\\", \\\"{x:1386,y:723,t:1527271901755};\\\", \\\"{x:1386,y:709,t:1527271901771};\\\", \\\"{x:1386,y:694,t:1527271901788};\\\", \\\"{x:1386,y:678,t:1527271901805};\\\", \\\"{x:1389,y:651,t:1527271901823};\\\", \\\"{x:1391,y:640,t:1527271901838};\\\", \\\"{x:1393,y:616,t:1527271901855};\\\", \\\"{x:1397,y:607,t:1527271901871};\\\", \\\"{x:1401,y:594,t:1527271901888};\\\", \\\"{x:1404,y:581,t:1527271901905};\\\", \\\"{x:1405,y:575,t:1527271901921};\\\", \\\"{x:1407,y:571,t:1527271901938};\\\", \\\"{x:1407,y:568,t:1527271901955};\\\", \\\"{x:1408,y:565,t:1527271901972};\\\", \\\"{x:1410,y:562,t:1527271901988};\\\", \\\"{x:1410,y:561,t:1527271902005};\\\", \\\"{x:1410,y:559,t:1527271902023};\\\", \\\"{x:1410,y:558,t:1527271902039};\\\", \\\"{x:1410,y:556,t:1527271902055};\\\", \\\"{x:1411,y:554,t:1527271902072};\\\", \\\"{x:1412,y:550,t:1527271902088};\\\", \\\"{x:1412,y:548,t:1527271902110};\\\", \\\"{x:1412,y:547,t:1527271902127};\\\", \\\"{x:1411,y:547,t:1527271902223};\\\", \\\"{x:1409,y:550,t:1527271902239};\\\", \\\"{x:1408,y:554,t:1527271902255};\\\", \\\"{x:1405,y:561,t:1527271902272};\\\", \\\"{x:1405,y:565,t:1527271902288};\\\", \\\"{x:1405,y:567,t:1527271902306};\\\", \\\"{x:1405,y:569,t:1527271902322};\\\", \\\"{x:1405,y:570,t:1527271902342};\\\", \\\"{x:1406,y:570,t:1527271902567};\\\", \\\"{x:1408,y:570,t:1527271902575};\\\", \\\"{x:1409,y:570,t:1527271902589};\\\", \\\"{x:1412,y:568,t:1527271902605};\\\", \\\"{x:1413,y:567,t:1527271902622};\\\", \\\"{x:1414,y:567,t:1527271902639};\\\", \\\"{x:1415,y:567,t:1527271905311};\\\", \\\"{x:1415,y:568,t:1527271905324};\\\", \\\"{x:1416,y:570,t:1527271905342};\\\", \\\"{x:1418,y:575,t:1527271905358};\\\", \\\"{x:1421,y:580,t:1527271905374};\\\", \\\"{x:1425,y:589,t:1527271905391};\\\", \\\"{x:1428,y:596,t:1527271905407};\\\", \\\"{x:1432,y:604,t:1527271905425};\\\", \\\"{x:1435,y:613,t:1527271905441};\\\", \\\"{x:1437,y:623,t:1527271905457};\\\", \\\"{x:1442,y:634,t:1527271905474};\\\", \\\"{x:1447,y:647,t:1527271905491};\\\", \\\"{x:1452,y:658,t:1527271905508};\\\", \\\"{x:1456,y:667,t:1527271905525};\\\", \\\"{x:1458,y:676,t:1527271905542};\\\", \\\"{x:1461,y:684,t:1527271905559};\\\", \\\"{x:1462,y:689,t:1527271905574};\\\", \\\"{x:1467,y:707,t:1527271905591};\\\", \\\"{x:1471,y:719,t:1527271905608};\\\", \\\"{x:1473,y:728,t:1527271905624};\\\", \\\"{x:1476,y:735,t:1527271905641};\\\", \\\"{x:1478,y:740,t:1527271905659};\\\", \\\"{x:1479,y:744,t:1527271905674};\\\", \\\"{x:1482,y:752,t:1527271905692};\\\", \\\"{x:1487,y:760,t:1527271905708};\\\", \\\"{x:1490,y:765,t:1527271905723};\\\", \\\"{x:1492,y:770,t:1527271905741};\\\", \\\"{x:1496,y:776,t:1527271905757};\\\", \\\"{x:1497,y:780,t:1527271905773};\\\", \\\"{x:1498,y:782,t:1527271905791};\\\", \\\"{x:1499,y:785,t:1527271905807};\\\", \\\"{x:1503,y:790,t:1527271905823};\\\", \\\"{x:1506,y:795,t:1527271905840};\\\", \\\"{x:1508,y:798,t:1527271905858};\\\", \\\"{x:1510,y:802,t:1527271905874};\\\", \\\"{x:1513,y:806,t:1527271905890};\\\", \\\"{x:1515,y:811,t:1527271905908};\\\", \\\"{x:1517,y:815,t:1527271905925};\\\", \\\"{x:1520,y:820,t:1527271905941};\\\", \\\"{x:1523,y:829,t:1527271905958};\\\", \\\"{x:1525,y:832,t:1527271905974};\\\", \\\"{x:1528,y:840,t:1527271905991};\\\", \\\"{x:1531,y:849,t:1527271906008};\\\", \\\"{x:1538,y:861,t:1527271906025};\\\", \\\"{x:1545,y:869,t:1527271906041};\\\", \\\"{x:1549,y:877,t:1527271906058};\\\", \\\"{x:1551,y:887,t:1527271906075};\\\", \\\"{x:1555,y:897,t:1527271906091};\\\", \\\"{x:1560,y:908,t:1527271906108};\\\", \\\"{x:1564,y:917,t:1527271906125};\\\", \\\"{x:1567,y:925,t:1527271906141};\\\", \\\"{x:1569,y:932,t:1527271906158};\\\", \\\"{x:1573,y:942,t:1527271906175};\\\", \\\"{x:1577,y:947,t:1527271906191};\\\", \\\"{x:1582,y:955,t:1527271906208};\\\", \\\"{x:1585,y:960,t:1527271906225};\\\", \\\"{x:1589,y:966,t:1527271906241};\\\", \\\"{x:1591,y:968,t:1527271906259};\\\", \\\"{x:1592,y:969,t:1527271906278};\\\", \\\"{x:1594,y:969,t:1527271906327};\\\", \\\"{x:1595,y:969,t:1527271906343};\\\", \\\"{x:1597,y:969,t:1527271906359};\\\", \\\"{x:1599,y:969,t:1527271906375};\\\", \\\"{x:1601,y:969,t:1527271906392};\\\", \\\"{x:1603,y:969,t:1527271906408};\\\", \\\"{x:1605,y:968,t:1527271906426};\\\", \\\"{x:1606,y:967,t:1527271906441};\\\", \\\"{x:1607,y:967,t:1527271906457};\\\", \\\"{x:1608,y:967,t:1527271906478};\\\", \\\"{x:1609,y:967,t:1527271906509};\\\", \\\"{x:1610,y:967,t:1527271906533};\\\", \\\"{x:1611,y:968,t:1527271906558};\\\", \\\"{x:1614,y:971,t:1527271906574};\\\", \\\"{x:1615,y:973,t:1527271906591};\\\", \\\"{x:1617,y:974,t:1527271906608};\\\", \\\"{x:1619,y:977,t:1527271906625};\\\", \\\"{x:1620,y:977,t:1527271906679};\\\", \\\"{x:1621,y:977,t:1527271906710};\\\", \\\"{x:1623,y:977,t:1527271906759};\\\", \\\"{x:1623,y:976,t:1527271908631};\\\", \\\"{x:1623,y:975,t:1527271908643};\\\", \\\"{x:1623,y:974,t:1527271908662};\\\", \\\"{x:1623,y:973,t:1527271908677};\\\", \\\"{x:1623,y:972,t:1527271908831};\\\", \\\"{x:1622,y:971,t:1527271909111};\\\", \\\"{x:1621,y:971,t:1527271909126};\\\", \\\"{x:1620,y:971,t:1527271909144};\\\", \\\"{x:1618,y:971,t:1527271909160};\\\", \\\"{x:1611,y:971,t:1527271909177};\\\", \\\"{x:1599,y:969,t:1527271909194};\\\", \\\"{x:1560,y:964,t:1527271909210};\\\", \\\"{x:1505,y:956,t:1527271909227};\\\", \\\"{x:1431,y:940,t:1527271909244};\\\", \\\"{x:1365,y:926,t:1527271909259};\\\", \\\"{x:1320,y:913,t:1527271909277};\\\", \\\"{x:1280,y:905,t:1527271909293};\\\", \\\"{x:1269,y:902,t:1527271909309};\\\", \\\"{x:1264,y:902,t:1527271909327};\\\", \\\"{x:1263,y:902,t:1527271909343};\\\", \\\"{x:1262,y:902,t:1527271909359};\\\", \\\"{x:1261,y:903,t:1527271909446};\\\", \\\"{x:1261,y:905,t:1527271909469};\\\", \\\"{x:1261,y:906,t:1527271909477};\\\", \\\"{x:1261,y:909,t:1527271909493};\\\", \\\"{x:1259,y:915,t:1527271909511};\\\", \\\"{x:1259,y:919,t:1527271909527};\\\", \\\"{x:1259,y:923,t:1527271909543};\\\", \\\"{x:1259,y:927,t:1527271909561};\\\", \\\"{x:1259,y:930,t:1527271909577};\\\", \\\"{x:1259,y:931,t:1527271909594};\\\", \\\"{x:1259,y:933,t:1527271909614};\\\", \\\"{x:1259,y:934,t:1527271909630};\\\", \\\"{x:1259,y:935,t:1527271909647};\\\", \\\"{x:1260,y:935,t:1527271909661};\\\", \\\"{x:1262,y:937,t:1527271909678};\\\", \\\"{x:1264,y:938,t:1527271909694};\\\", \\\"{x:1267,y:940,t:1527271909710};\\\", \\\"{x:1269,y:942,t:1527271909727};\\\", \\\"{x:1272,y:943,t:1527271909744};\\\", \\\"{x:1272,y:944,t:1527271909761};\\\", \\\"{x:1274,y:944,t:1527271909778};\\\", \\\"{x:1275,y:944,t:1527271909815};\\\", \\\"{x:1275,y:945,t:1527271909827};\\\", \\\"{x:1277,y:947,t:1527271909844};\\\", \\\"{x:1278,y:948,t:1527271909862};\\\", \\\"{x:1280,y:950,t:1527271909878};\\\", \\\"{x:1280,y:952,t:1527271909934};\\\", \\\"{x:1280,y:953,t:1527271909975};\\\", \\\"{x:1281,y:953,t:1527271910159};\\\", \\\"{x:1283,y:953,t:1527271910166};\\\", \\\"{x:1284,y:953,t:1527271910178};\\\", \\\"{x:1298,y:954,t:1527271910195};\\\", \\\"{x:1314,y:958,t:1527271910211};\\\", \\\"{x:1335,y:960,t:1527271910228};\\\", \\\"{x:1352,y:964,t:1527271910244};\\\", \\\"{x:1367,y:968,t:1527271910261};\\\", \\\"{x:1380,y:970,t:1527271910278};\\\", \\\"{x:1383,y:970,t:1527271910295};\\\", \\\"{x:1381,y:970,t:1527271910431};\\\", \\\"{x:1378,y:970,t:1527271910445};\\\", \\\"{x:1374,y:971,t:1527271910462};\\\", \\\"{x:1373,y:971,t:1527271910479};\\\", \\\"{x:1372,y:971,t:1527271910599};\\\", \\\"{x:1372,y:970,t:1527271910622};\\\", \\\"{x:1372,y:969,t:1527271910630};\\\", \\\"{x:1374,y:968,t:1527271910646};\\\", \\\"{x:1379,y:966,t:1527271910662};\\\", \\\"{x:1384,y:964,t:1527271910679};\\\", \\\"{x:1387,y:963,t:1527271910696};\\\", \\\"{x:1391,y:961,t:1527271910711};\\\", \\\"{x:1394,y:961,t:1527271910728};\\\", \\\"{x:1399,y:961,t:1527271910746};\\\", \\\"{x:1403,y:961,t:1527271910763};\\\", \\\"{x:1405,y:961,t:1527271910779};\\\", \\\"{x:1406,y:961,t:1527271910796};\\\", \\\"{x:1408,y:961,t:1527271910871};\\\", \\\"{x:1409,y:962,t:1527271910982};\\\", \\\"{x:1411,y:962,t:1527271910998};\\\", \\\"{x:1415,y:962,t:1527271911012};\\\", \\\"{x:1429,y:967,t:1527271911029};\\\", \\\"{x:1446,y:971,t:1527271911045};\\\", \\\"{x:1469,y:976,t:1527271911062};\\\", \\\"{x:1479,y:979,t:1527271911078};\\\", \\\"{x:1486,y:981,t:1527271911095};\\\", \\\"{x:1489,y:981,t:1527271911112};\\\", \\\"{x:1490,y:981,t:1527271911128};\\\", \\\"{x:1492,y:981,t:1527271911145};\\\", \\\"{x:1493,y:981,t:1527271911359};\\\", \\\"{x:1494,y:981,t:1527271911374};\\\", \\\"{x:1495,y:979,t:1527271911399};\\\", \\\"{x:1496,y:977,t:1527271911412};\\\", \\\"{x:1501,y:973,t:1527271911430};\\\", \\\"{x:1512,y:970,t:1527271911446};\\\", \\\"{x:1523,y:968,t:1527271911462};\\\", \\\"{x:1529,y:968,t:1527271911479};\\\", \\\"{x:1535,y:968,t:1527271911495};\\\", \\\"{x:1538,y:968,t:1527271911512};\\\", \\\"{x:1541,y:968,t:1527271911529};\\\", \\\"{x:1543,y:968,t:1527271911545};\\\", \\\"{x:1544,y:968,t:1527271911563};\\\", \\\"{x:1546,y:968,t:1527271911743};\\\", \\\"{x:1548,y:968,t:1527271911751};\\\", \\\"{x:1551,y:968,t:1527271911762};\\\", \\\"{x:1560,y:968,t:1527271911780};\\\", \\\"{x:1568,y:968,t:1527271911797};\\\", \\\"{x:1575,y:968,t:1527271911812};\\\", \\\"{x:1581,y:968,t:1527271911830};\\\", \\\"{x:1584,y:968,t:1527271911847};\\\", \\\"{x:1585,y:968,t:1527271911903};\\\", \\\"{x:1586,y:968,t:1527271912086};\\\", \\\"{x:1588,y:968,t:1527271912095};\\\", \\\"{x:1595,y:968,t:1527271912112};\\\", \\\"{x:1610,y:968,t:1527271912129};\\\", \\\"{x:1623,y:968,t:1527271912146};\\\", \\\"{x:1633,y:970,t:1527271912162};\\\", \\\"{x:1640,y:971,t:1527271912179};\\\", \\\"{x:1643,y:972,t:1527271912196};\\\", \\\"{x:1642,y:972,t:1527271912655};\\\", \\\"{x:1641,y:972,t:1527271912686};\\\", \\\"{x:1638,y:972,t:1527271912696};\\\", \\\"{x:1636,y:971,t:1527271912713};\\\", \\\"{x:1634,y:970,t:1527271912730};\\\", \\\"{x:1630,y:970,t:1527271912746};\\\", \\\"{x:1629,y:970,t:1527271912763};\\\", \\\"{x:1627,y:969,t:1527271912781};\\\", \\\"{x:1626,y:968,t:1527271912864};\\\", \\\"{x:1625,y:968,t:1527271912935};\\\", \\\"{x:1624,y:968,t:1527271913047};\\\", \\\"{x:1623,y:968,t:1527271913103};\\\", \\\"{x:1621,y:967,t:1527271913114};\\\", \\\"{x:1612,y:964,t:1527271913131};\\\", \\\"{x:1581,y:954,t:1527271913148};\\\", \\\"{x:1484,y:927,t:1527271913164};\\\", \\\"{x:1334,y:874,t:1527271913180};\\\", \\\"{x:1126,y:804,t:1527271913197};\\\", \\\"{x:939,y:720,t:1527271913213};\\\", \\\"{x:730,y:629,t:1527271913230};\\\", \\\"{x:670,y:596,t:1527271913248};\\\", \\\"{x:643,y:577,t:1527271913264};\\\", \\\"{x:638,y:572,t:1527271913279};\\\", \\\"{x:637,y:571,t:1527271913298};\\\", \\\"{x:636,y:571,t:1527271913334};\\\", \\\"{x:635,y:571,t:1527271913346};\\\", \\\"{x:626,y:564,t:1527271913364};\\\", \\\"{x:609,y:557,t:1527271913381};\\\", \\\"{x:582,y:546,t:1527271913397};\\\", \\\"{x:536,y:532,t:1527271913415};\\\", \\\"{x:516,y:527,t:1527271913431};\\\", \\\"{x:507,y:523,t:1527271913447};\\\", \\\"{x:506,y:523,t:1527271913464};\\\", \\\"{x:505,y:523,t:1527271913550};\\\", \\\"{x:503,y:523,t:1527271913564};\\\", \\\"{x:501,y:523,t:1527271913581};\\\", \\\"{x:497,y:523,t:1527271913599};\\\", \\\"{x:491,y:525,t:1527271913614};\\\", \\\"{x:488,y:526,t:1527271913631};\\\", \\\"{x:485,y:528,t:1527271913647};\\\", \\\"{x:482,y:528,t:1527271913664};\\\", \\\"{x:481,y:528,t:1527271913685};\\\", \\\"{x:479,y:529,t:1527271913697};\\\", \\\"{x:479,y:530,t:1527271914406};\\\", \\\"{x:479,y:531,t:1527271914414};\\\", \\\"{x:479,y:533,t:1527271914429};\\\", \\\"{x:482,y:538,t:1527271914446};\\\", \\\"{x:490,y:542,t:1527271914463};\\\", \\\"{x:519,y:551,t:1527271914482};\\\", \\\"{x:597,y:575,t:1527271914498};\\\", \\\"{x:697,y:606,t:1527271914515};\\\", \\\"{x:833,y:649,t:1527271914532};\\\", \\\"{x:974,y:690,t:1527271914547};\\\", \\\"{x:1100,y:737,t:1527271914565};\\\", \\\"{x:1218,y:792,t:1527271914581};\\\", \\\"{x:1249,y:811,t:1527271914598};\\\", \\\"{x:1257,y:816,t:1527271914615};\\\", \\\"{x:1258,y:817,t:1527271914631};\\\", \\\"{x:1259,y:817,t:1527271914653};\\\", \\\"{x:1259,y:819,t:1527271914665};\\\", \\\"{x:1257,y:822,t:1527271914682};\\\", \\\"{x:1256,y:829,t:1527271914698};\\\", \\\"{x:1253,y:838,t:1527271914715};\\\", \\\"{x:1252,y:843,t:1527271914732};\\\", \\\"{x:1252,y:846,t:1527271914749};\\\", \\\"{x:1252,y:847,t:1527271914765};\\\", \\\"{x:1252,y:850,t:1527271914782};\\\", \\\"{x:1251,y:858,t:1527271914799};\\\", \\\"{x:1249,y:873,t:1527271914815};\\\", \\\"{x:1249,y:891,t:1527271914832};\\\", \\\"{x:1251,y:905,t:1527271914850};\\\", \\\"{x:1255,y:913,t:1527271914865};\\\", \\\"{x:1259,y:919,t:1527271914883};\\\", \\\"{x:1259,y:922,t:1527271914900};\\\", \\\"{x:1259,y:929,t:1527271914916};\\\", \\\"{x:1259,y:944,t:1527271914932};\\\", \\\"{x:1256,y:957,t:1527271914949};\\\", \\\"{x:1255,y:964,t:1527271914965};\\\", \\\"{x:1253,y:969,t:1527271914982};\\\", \\\"{x:1253,y:970,t:1527271915047};\\\", \\\"{x:1253,y:971,t:1527271915119};\\\", \\\"{x:1257,y:971,t:1527271915132};\\\", \\\"{x:1267,y:968,t:1527271915150};\\\", \\\"{x:1277,y:964,t:1527271915166};\\\", \\\"{x:1282,y:961,t:1527271915183};\\\", \\\"{x:1290,y:960,t:1527271915200};\\\", \\\"{x:1297,y:959,t:1527271915217};\\\", \\\"{x:1303,y:958,t:1527271915232};\\\", \\\"{x:1305,y:957,t:1527271915249};\\\", \\\"{x:1306,y:957,t:1527271915267};\\\", \\\"{x:1307,y:956,t:1527271915282};\\\", \\\"{x:1308,y:954,t:1527271915326};\\\", \\\"{x:1310,y:952,t:1527271915334};\\\", \\\"{x:1314,y:944,t:1527271915350};\\\", \\\"{x:1330,y:917,t:1527271915367};\\\", \\\"{x:1339,y:893,t:1527271915383};\\\", \\\"{x:1349,y:868,t:1527271915399};\\\", \\\"{x:1355,y:849,t:1527271915416};\\\", \\\"{x:1357,y:841,t:1527271915432};\\\", \\\"{x:1358,y:839,t:1527271915449};\\\", \\\"{x:1359,y:835,t:1527271915465};\\\", \\\"{x:1359,y:833,t:1527271915482};\\\", \\\"{x:1359,y:831,t:1527271915499};\\\", \\\"{x:1361,y:829,t:1527271915516};\\\", \\\"{x:1362,y:827,t:1527271915541};\\\", \\\"{x:1363,y:826,t:1527271915582};\\\", \\\"{x:1364,y:824,t:1527271915599};\\\", \\\"{x:1365,y:820,t:1527271915616};\\\", \\\"{x:1367,y:809,t:1527271915633};\\\", \\\"{x:1368,y:805,t:1527271915649};\\\", \\\"{x:1369,y:800,t:1527271915666};\\\", \\\"{x:1370,y:793,t:1527271915683};\\\", \\\"{x:1370,y:788,t:1527271915700};\\\", \\\"{x:1370,y:784,t:1527271915717};\\\", \\\"{x:1372,y:779,t:1527271915733};\\\", \\\"{x:1373,y:776,t:1527271915750};\\\", \\\"{x:1373,y:775,t:1527271916054};\\\", \\\"{x:1372,y:774,t:1527271916334};\\\", \\\"{x:1349,y:774,t:1527271916350};\\\", \\\"{x:1297,y:771,t:1527271916367};\\\", \\\"{x:1214,y:758,t:1527271916383};\\\", \\\"{x:1105,y:740,t:1527271916400};\\\", \\\"{x:979,y:715,t:1527271916417};\\\", \\\"{x:844,y:678,t:1527271916433};\\\", \\\"{x:728,y:645,t:1527271916450};\\\", \\\"{x:625,y:615,t:1527271916466};\\\", \\\"{x:526,y:587,t:1527271916484};\\\", \\\"{x:477,y:570,t:1527271916501};\\\", \\\"{x:447,y:560,t:1527271916516};\\\", \\\"{x:433,y:556,t:1527271916533};\\\", \\\"{x:425,y:556,t:1527271916549};\\\", \\\"{x:421,y:556,t:1527271916567};\\\", \\\"{x:418,y:556,t:1527271916582};\\\", \\\"{x:412,y:556,t:1527271916600};\\\", \\\"{x:404,y:556,t:1527271916617};\\\", \\\"{x:398,y:556,t:1527271916633};\\\", \\\"{x:395,y:556,t:1527271916650};\\\", \\\"{x:394,y:556,t:1527271916667};\\\", \\\"{x:393,y:556,t:1527271916685};\\\", \\\"{x:394,y:556,t:1527271916766};\\\", \\\"{x:395,y:556,t:1527271916798};\\\", \\\"{x:396,y:556,t:1527271918736};\\\", \\\"{x:398,y:556,t:1527271918751};\\\", \\\"{x:401,y:556,t:1527271918767};\\\", \\\"{x:407,y:558,t:1527271918784};\\\", \\\"{x:420,y:563,t:1527271918801};\\\", \\\"{x:432,y:572,t:1527271918818};\\\", \\\"{x:451,y:583,t:1527271918835};\\\", \\\"{x:470,y:594,t:1527271918852};\\\", \\\"{x:485,y:603,t:1527271918869};\\\", \\\"{x:493,y:609,t:1527271918885};\\\", \\\"{x:498,y:614,t:1527271918902};\\\", \\\"{x:502,y:618,t:1527271918919};\\\", \\\"{x:505,y:621,t:1527271918935};\\\", \\\"{x:506,y:621,t:1527271920246};\\\", \\\"{x:506,y:622,t:1527271920254};\\\", \\\"{x:504,y:624,t:1527271920270};\\\", \\\"{x:504,y:625,t:1527271920287};\\\", \\\"{x:503,y:627,t:1527271920304};\\\", \\\"{x:503,y:628,t:1527271920326};\\\", \\\"{x:502,y:628,t:1527271920337};\\\", \\\"{x:502,y:629,t:1527271920353};\\\", \\\"{x:502,y:630,t:1527271920371};\\\", \\\"{x:502,y:631,t:1527271920390};\\\", \\\"{x:502,y:632,t:1527271920422};\\\", \\\"{x:502,y:633,t:1527271920437};\\\", \\\"{x:502,y:634,t:1527271921158};\\\", \\\"{x:502,y:635,t:1527271921198};\\\", \\\"{x:502,y:636,t:1527271921230};\\\", \\\"{x:502,y:637,t:1527271921246};\\\", \\\"{x:502,y:638,t:1527271921262};\\\", \\\"{x:502,y:639,t:1527271921319};\\\", \\\"{x:502,y:640,t:1527271921358};\\\", \\\"{x:502,y:641,t:1527271921382};\\\", \\\"{x:502,y:642,t:1527271921414};\\\", \\\"{x:502,y:643,t:1527271921422};\\\", \\\"{x:501,y:644,t:1527271921438};\\\", \\\"{x:501,y:645,t:1527271921453};\\\", \\\"{x:500,y:647,t:1527271921471};\\\", \\\"{x:500,y:648,t:1527271921488};\\\", \\\"{x:499,y:650,t:1527271921504};\\\", \\\"{x:499,y:651,t:1527271921525};\\\", \\\"{x:498,y:651,t:1527271921574};\\\", \\\"{x:498,y:652,t:1527271921878};\\\", \\\"{x:498,y:653,t:1527271921886};\\\", \\\"{x:498,y:654,t:1527271921904};\\\", \\\"{x:498,y:655,t:1527271921926};\\\", \\\"{x:498,y:656,t:1527271921936};\\\", \\\"{x:498,y:658,t:1527271921953};\\\", \\\"{x:498,y:660,t:1527271921971};\\\", \\\"{x:497,y:665,t:1527271921986};\\\", \\\"{x:497,y:669,t:1527271922004};\\\", \\\"{x:496,y:677,t:1527271922022};\\\", \\\"{x:496,y:679,t:1527271922037};\\\", \\\"{x:495,y:682,t:1527271922054};\\\", \\\"{x:494,y:687,t:1527271922070};\\\", \\\"{x:493,y:691,t:1527271922086};\\\", \\\"{x:493,y:693,t:1527271922103};\\\", \\\"{x:493,y:695,t:1527271922120};\\\", \\\"{x:493,y:696,t:1527271922136};\\\", \\\"{x:493,y:697,t:1527271922153};\\\", \\\"{x:492,y:698,t:1527271922170};\\\", \\\"{x:492,y:699,t:1527271922238};\\\", \\\"{x:492,y:701,t:1527271922255};\\\", \\\"{x:492,y:703,t:1527271922270};\\\", \\\"{x:492,y:707,t:1527271922286};\\\", \\\"{x:492,y:710,t:1527271922305};\\\", \\\"{x:492,y:714,t:1527271922321};\\\", \\\"{x:492,y:716,t:1527271922338};\\\", \\\"{x:492,y:719,t:1527271922355};\\\", \\\"{x:492,y:720,t:1527271922371};\\\", \\\"{x:492,y:721,t:1527271923294};\\\", \\\"{x:494,y:721,t:1527271923334};\\\", \\\"{x:495,y:721,t:1527271923366};\\\", \\\"{x:496,y:720,t:1527271923373};\\\", \\\"{x:494,y:721,t:1527271923670};\\\", \\\"{x:493,y:722,t:1527271923678};\\\", \\\"{x:492,y:722,t:1527271923689};\\\", \\\"{x:487,y:725,t:1527271923706};\\\", \\\"{x:482,y:727,t:1527271923723};\\\", \\\"{x:480,y:728,t:1527271923740};\\\" ] }, { \\\"rt\\\": 15623, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 230232, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"2WQ0M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-5-H -K -12 PM-D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:479,y:728,t:1527271924383};\\\", \\\"{x:479,y:730,t:1527271924390};\\\", \\\"{x:479,y:731,t:1527271924453};\\\", \\\"{x:477,y:731,t:1527271924572};\\\", \\\"{x:477,y:729,t:1527271924717};\\\", \\\"{x:478,y:725,t:1527271924725};\\\", \\\"{x:481,y:722,t:1527271924740};\\\", \\\"{x:483,y:714,t:1527271924756};\\\", \\\"{x:490,y:694,t:1527271924774};\\\", \\\"{x:495,y:677,t:1527271924791};\\\", \\\"{x:501,y:660,t:1527271924807};\\\", \\\"{x:509,y:640,t:1527271924824};\\\", \\\"{x:515,y:629,t:1527271924840};\\\", \\\"{x:521,y:619,t:1527271924857};\\\", \\\"{x:527,y:613,t:1527271924873};\\\", \\\"{x:530,y:607,t:1527271924891};\\\", \\\"{x:532,y:604,t:1527271924907};\\\", \\\"{x:536,y:597,t:1527271924923};\\\", \\\"{x:540,y:591,t:1527271924940};\\\", \\\"{x:543,y:586,t:1527271924957};\\\", \\\"{x:546,y:582,t:1527271924973};\\\", \\\"{x:550,y:577,t:1527271924991};\\\", \\\"{x:556,y:570,t:1527271925008};\\\", \\\"{x:559,y:566,t:1527271925023};\\\", \\\"{x:562,y:561,t:1527271925040};\\\", \\\"{x:563,y:559,t:1527271925057};\\\", \\\"{x:565,y:556,t:1527271925073};\\\", \\\"{x:566,y:555,t:1527271925090};\\\", \\\"{x:566,y:554,t:1527271925117};\\\", \\\"{x:566,y:553,t:1527271925133};\\\", \\\"{x:566,y:552,t:1527271925310};\\\", \\\"{x:565,y:552,t:1527271925324};\\\", \\\"{x:559,y:552,t:1527271925340};\\\", \\\"{x:552,y:554,t:1527271925357};\\\", \\\"{x:549,y:556,t:1527271925373};\\\", \\\"{x:547,y:557,t:1527271925390};\\\", \\\"{x:546,y:557,t:1527271925407};\\\", \\\"{x:545,y:557,t:1527271925430};\\\", \\\"{x:548,y:557,t:1527271925670};\\\", \\\"{x:550,y:557,t:1527271925678};\\\", \\\"{x:552,y:557,t:1527271925690};\\\", \\\"{x:558,y:557,t:1527271925707};\\\", \\\"{x:568,y:558,t:1527271925724};\\\", \\\"{x:588,y:561,t:1527271925742};\\\", \\\"{x:594,y:562,t:1527271925758};\\\", \\\"{x:609,y:565,t:1527271925775};\\\", \\\"{x:620,y:566,t:1527271925792};\\\", \\\"{x:637,y:568,t:1527271925807};\\\", \\\"{x:661,y:570,t:1527271925826};\\\", \\\"{x:688,y:574,t:1527271925841};\\\", \\\"{x:724,y:580,t:1527271925857};\\\", \\\"{x:758,y:585,t:1527271925874};\\\", \\\"{x:786,y:591,t:1527271925891};\\\", \\\"{x:828,y:600,t:1527271925907};\\\", \\\"{x:884,y:608,t:1527271925925};\\\", \\\"{x:969,y:621,t:1527271925941};\\\", \\\"{x:1003,y:626,t:1527271925958};\\\", \\\"{x:1025,y:629,t:1527271925974};\\\", \\\"{x:1040,y:633,t:1527271925991};\\\", \\\"{x:1048,y:634,t:1527271926008};\\\", \\\"{x:1054,y:635,t:1527271926024};\\\", \\\"{x:1060,y:636,t:1527271926042};\\\", \\\"{x:1065,y:637,t:1527271926059};\\\", \\\"{x:1068,y:638,t:1527271926074};\\\", \\\"{x:1073,y:638,t:1527271926091};\\\", \\\"{x:1082,y:641,t:1527271926108};\\\", \\\"{x:1101,y:647,t:1527271926125};\\\", \\\"{x:1123,y:654,t:1527271926142};\\\", \\\"{x:1137,y:658,t:1527271926158};\\\", \\\"{x:1153,y:663,t:1527271926175};\\\", \\\"{x:1166,y:668,t:1527271926192};\\\", \\\"{x:1179,y:672,t:1527271926209};\\\", \\\"{x:1197,y:681,t:1527271926225};\\\", \\\"{x:1218,y:695,t:1527271926242};\\\", \\\"{x:1250,y:715,t:1527271926258};\\\", \\\"{x:1281,y:736,t:1527271926275};\\\", \\\"{x:1310,y:756,t:1527271926291};\\\", \\\"{x:1329,y:768,t:1527271926309};\\\", \\\"{x:1338,y:776,t:1527271926324};\\\", \\\"{x:1348,y:784,t:1527271926342};\\\", \\\"{x:1351,y:787,t:1527271926359};\\\", \\\"{x:1351,y:790,t:1527271926375};\\\", \\\"{x:1352,y:794,t:1527271926392};\\\", \\\"{x:1352,y:801,t:1527271926409};\\\", \\\"{x:1356,y:808,t:1527271926425};\\\", \\\"{x:1359,y:820,t:1527271926442};\\\", \\\"{x:1362,y:831,t:1527271926459};\\\", \\\"{x:1365,y:835,t:1527271926474};\\\", \\\"{x:1367,y:839,t:1527271926492};\\\", \\\"{x:1367,y:841,t:1527271926509};\\\", \\\"{x:1367,y:843,t:1527271926526};\\\", \\\"{x:1367,y:844,t:1527271926542};\\\", \\\"{x:1367,y:847,t:1527271926559};\\\", \\\"{x:1366,y:848,t:1527271926575};\\\", \\\"{x:1363,y:850,t:1527271926592};\\\", \\\"{x:1361,y:852,t:1527271926609};\\\", \\\"{x:1359,y:854,t:1527271926626};\\\", \\\"{x:1358,y:854,t:1527271926646};\\\", \\\"{x:1357,y:854,t:1527271926659};\\\", \\\"{x:1361,y:854,t:1527271927022};\\\", \\\"{x:1367,y:857,t:1527271927030};\\\", \\\"{x:1374,y:860,t:1527271927043};\\\", \\\"{x:1389,y:865,t:1527271927059};\\\", \\\"{x:1407,y:866,t:1527271927076};\\\", \\\"{x:1422,y:866,t:1527271927093};\\\", \\\"{x:1440,y:866,t:1527271927109};\\\", \\\"{x:1474,y:865,t:1527271927125};\\\", \\\"{x:1499,y:859,t:1527271927142};\\\", \\\"{x:1527,y:854,t:1527271927158};\\\", \\\"{x:1551,y:847,t:1527271927175};\\\", \\\"{x:1569,y:841,t:1527271927192};\\\", \\\"{x:1582,y:836,t:1527271927208};\\\", \\\"{x:1589,y:832,t:1527271927225};\\\", \\\"{x:1589,y:831,t:1527271927242};\\\", \\\"{x:1589,y:830,t:1527271927294};\\\", \\\"{x:1591,y:828,t:1527271927309};\\\", \\\"{x:1592,y:825,t:1527271927326};\\\", \\\"{x:1592,y:822,t:1527271927342};\\\", \\\"{x:1597,y:815,t:1527271927359};\\\", \\\"{x:1604,y:803,t:1527271927375};\\\", \\\"{x:1605,y:800,t:1527271927392};\\\", \\\"{x:1606,y:799,t:1527271927410};\\\", \\\"{x:1608,y:795,t:1527271927425};\\\", \\\"{x:1610,y:790,t:1527271927443};\\\", \\\"{x:1612,y:785,t:1527271927459};\\\", \\\"{x:1613,y:780,t:1527271927476};\\\", \\\"{x:1614,y:777,t:1527271927493};\\\", \\\"{x:1614,y:776,t:1527271927702};\\\", \\\"{x:1607,y:774,t:1527271927710};\\\", \\\"{x:1587,y:774,t:1527271927726};\\\", \\\"{x:1570,y:772,t:1527271927743};\\\", \\\"{x:1566,y:770,t:1527271927760};\\\", \\\"{x:1566,y:769,t:1527271927775};\\\", \\\"{x:1565,y:769,t:1527271927798};\\\", \\\"{x:1565,y:768,t:1527271927813};\\\", \\\"{x:1563,y:767,t:1527271927830};\\\", \\\"{x:1563,y:766,t:1527271927843};\\\", \\\"{x:1556,y:762,t:1527271927859};\\\", \\\"{x:1543,y:754,t:1527271927877};\\\", \\\"{x:1521,y:734,t:1527271927893};\\\", \\\"{x:1480,y:700,t:1527271927910};\\\", \\\"{x:1457,y:679,t:1527271927926};\\\", \\\"{x:1439,y:661,t:1527271927943};\\\", \\\"{x:1427,y:645,t:1527271927960};\\\", \\\"{x:1425,y:640,t:1527271927977};\\\", \\\"{x:1422,y:634,t:1527271927993};\\\", \\\"{x:1421,y:626,t:1527271928010};\\\", \\\"{x:1421,y:621,t:1527271928026};\\\", \\\"{x:1420,y:616,t:1527271928043};\\\", \\\"{x:1420,y:612,t:1527271928060};\\\", \\\"{x:1418,y:608,t:1527271928077};\\\", \\\"{x:1418,y:605,t:1527271928093};\\\", \\\"{x:1418,y:600,t:1527271928110};\\\", \\\"{x:1418,y:597,t:1527271928126};\\\", \\\"{x:1418,y:593,t:1527271928143};\\\", \\\"{x:1417,y:590,t:1527271928159};\\\", \\\"{x:1416,y:583,t:1527271928176};\\\", \\\"{x:1414,y:575,t:1527271928193};\\\", \\\"{x:1413,y:569,t:1527271928209};\\\", \\\"{x:1409,y:561,t:1527271928229};\\\", \\\"{x:1406,y:553,t:1527271928243};\\\", \\\"{x:1404,y:548,t:1527271928259};\\\", \\\"{x:1403,y:543,t:1527271928276};\\\", \\\"{x:1401,y:535,t:1527271928293};\\\", \\\"{x:1400,y:530,t:1527271928309};\\\", \\\"{x:1399,y:522,t:1527271928326};\\\", \\\"{x:1397,y:517,t:1527271928343};\\\", \\\"{x:1397,y:513,t:1527271928359};\\\", \\\"{x:1396,y:507,t:1527271928376};\\\", \\\"{x:1396,y:504,t:1527271928394};\\\", \\\"{x:1394,y:497,t:1527271928409};\\\", \\\"{x:1393,y:494,t:1527271928427};\\\", \\\"{x:1393,y:491,t:1527271928443};\\\", \\\"{x:1393,y:489,t:1527271928459};\\\", \\\"{x:1393,y:487,t:1527271928477};\\\", \\\"{x:1393,y:483,t:1527271928494};\\\", \\\"{x:1393,y:481,t:1527271928509};\\\", \\\"{x:1393,y:480,t:1527271928527};\\\", \\\"{x:1392,y:480,t:1527271928646};\\\", \\\"{x:1391,y:481,t:1527271928660};\\\", \\\"{x:1387,y:487,t:1527271928676};\\\", \\\"{x:1377,y:500,t:1527271928694};\\\", \\\"{x:1373,y:507,t:1527271928709};\\\", \\\"{x:1368,y:514,t:1527271928727};\\\", \\\"{x:1362,y:525,t:1527271928744};\\\", \\\"{x:1357,y:531,t:1527271928761};\\\", \\\"{x:1352,y:537,t:1527271928777};\\\", \\\"{x:1348,y:544,t:1527271928793};\\\", \\\"{x:1345,y:550,t:1527271928811};\\\", \\\"{x:1341,y:559,t:1527271928827};\\\", \\\"{x:1339,y:565,t:1527271928844};\\\", \\\"{x:1337,y:570,t:1527271928861};\\\", \\\"{x:1336,y:575,t:1527271928877};\\\", \\\"{x:1334,y:580,t:1527271928894};\\\", \\\"{x:1334,y:583,t:1527271928910};\\\", \\\"{x:1333,y:586,t:1527271928926};\\\", \\\"{x:1330,y:590,t:1527271928943};\\\", \\\"{x:1329,y:592,t:1527271928960};\\\", \\\"{x:1329,y:595,t:1527271928976};\\\", \\\"{x:1329,y:597,t:1527271928993};\\\", \\\"{x:1327,y:598,t:1527271929010};\\\", \\\"{x:1327,y:599,t:1527271929026};\\\", \\\"{x:1327,y:600,t:1527271929044};\\\", \\\"{x:1326,y:602,t:1527271929060};\\\", \\\"{x:1326,y:605,t:1527271929077};\\\", \\\"{x:1326,y:608,t:1527271929094};\\\", \\\"{x:1326,y:610,t:1527271929117};\\\", \\\"{x:1326,y:611,t:1527271929127};\\\", \\\"{x:1324,y:612,t:1527271929144};\\\", \\\"{x:1324,y:613,t:1527271929166};\\\", \\\"{x:1324,y:614,t:1527271929181};\\\", \\\"{x:1324,y:615,t:1527271929194};\\\", \\\"{x:1324,y:617,t:1527271929210};\\\", \\\"{x:1325,y:621,t:1527271929228};\\\", \\\"{x:1325,y:626,t:1527271929244};\\\", \\\"{x:1327,y:634,t:1527271929260};\\\", \\\"{x:1334,y:645,t:1527271929278};\\\", \\\"{x:1341,y:656,t:1527271929294};\\\", \\\"{x:1350,y:672,t:1527271929311};\\\", \\\"{x:1364,y:688,t:1527271929328};\\\", \\\"{x:1378,y:704,t:1527271929344};\\\", \\\"{x:1392,y:720,t:1527271929361};\\\", \\\"{x:1400,y:729,t:1527271929377};\\\", \\\"{x:1407,y:738,t:1527271929394};\\\", \\\"{x:1409,y:743,t:1527271929411};\\\", \\\"{x:1411,y:747,t:1527271929428};\\\", \\\"{x:1411,y:748,t:1527271929443};\\\", \\\"{x:1411,y:749,t:1527271929502};\\\", \\\"{x:1413,y:749,t:1527271929511};\\\", \\\"{x:1429,y:744,t:1527271929528};\\\", \\\"{x:1440,y:737,t:1527271929543};\\\", \\\"{x:1440,y:734,t:1527271930655};\\\", \\\"{x:1440,y:733,t:1527271930678};\\\", \\\"{x:1440,y:731,t:1527271930695};\\\", \\\"{x:1443,y:728,t:1527271930712};\\\", \\\"{x:1447,y:724,t:1527271930729};\\\", \\\"{x:1449,y:722,t:1527271930745};\\\", \\\"{x:1454,y:718,t:1527271930761};\\\", \\\"{x:1456,y:715,t:1527271930779};\\\", \\\"{x:1457,y:714,t:1527271930795};\\\", \\\"{x:1458,y:712,t:1527271930812};\\\", \\\"{x:1460,y:710,t:1527271930828};\\\", \\\"{x:1462,y:706,t:1527271930845};\\\", \\\"{x:1467,y:697,t:1527271930862};\\\", \\\"{x:1473,y:688,t:1527271930879};\\\", \\\"{x:1485,y:666,t:1527271930895};\\\", \\\"{x:1499,y:642,t:1527271930912};\\\", \\\"{x:1510,y:609,t:1527271930928};\\\", \\\"{x:1525,y:566,t:1527271930946};\\\", \\\"{x:1533,y:528,t:1527271930962};\\\", \\\"{x:1536,y:504,t:1527271930979};\\\", \\\"{x:1537,y:483,t:1527271930996};\\\", \\\"{x:1538,y:468,t:1527271931012};\\\", \\\"{x:1538,y:457,t:1527271931029};\\\", \\\"{x:1538,y:454,t:1527271931045};\\\", \\\"{x:1539,y:453,t:1527271931078};\\\", \\\"{x:1540,y:452,t:1527271931096};\\\", \\\"{x:1540,y:450,t:1527271931198};\\\", \\\"{x:1540,y:447,t:1527271931212};\\\", \\\"{x:1544,y:442,t:1527271931228};\\\", \\\"{x:1553,y:433,t:1527271931246};\\\", \\\"{x:1562,y:427,t:1527271931262};\\\", \\\"{x:1568,y:423,t:1527271931279};\\\", \\\"{x:1571,y:421,t:1527271931296};\\\", \\\"{x:1576,y:419,t:1527271931312};\\\", \\\"{x:1577,y:419,t:1527271931334};\\\", \\\"{x:1578,y:419,t:1527271931366};\\\", \\\"{x:1579,y:419,t:1527271931382};\\\", \\\"{x:1580,y:419,t:1527271931397};\\\", \\\"{x:1581,y:419,t:1527271931429};\\\", \\\"{x:1582,y:419,t:1527271931445};\\\", \\\"{x:1584,y:419,t:1527271931462};\\\", \\\"{x:1587,y:419,t:1527271931479};\\\", \\\"{x:1590,y:420,t:1527271931496};\\\", \\\"{x:1594,y:422,t:1527271931513};\\\", \\\"{x:1596,y:422,t:1527271931529};\\\", \\\"{x:1597,y:423,t:1527271931546};\\\", \\\"{x:1598,y:423,t:1527271931654};\\\", \\\"{x:1600,y:424,t:1527271931741};\\\", \\\"{x:1600,y:425,t:1527271931765};\\\", \\\"{x:1601,y:425,t:1527271931805};\\\", \\\"{x:1602,y:425,t:1527271931861};\\\", \\\"{x:1603,y:426,t:1527271931869};\\\", \\\"{x:1604,y:426,t:1527271931885};\\\", \\\"{x:1605,y:428,t:1527271931896};\\\", \\\"{x:1606,y:428,t:1527271931974};\\\", \\\"{x:1605,y:430,t:1527271931982};\\\", \\\"{x:1605,y:431,t:1527271931997};\\\", \\\"{x:1601,y:438,t:1527271932013};\\\", \\\"{x:1594,y:451,t:1527271932029};\\\", \\\"{x:1588,y:462,t:1527271932046};\\\", \\\"{x:1587,y:467,t:1527271932062};\\\", \\\"{x:1583,y:473,t:1527271932080};\\\", \\\"{x:1581,y:479,t:1527271932097};\\\", \\\"{x:1579,y:486,t:1527271932113};\\\", \\\"{x:1575,y:495,t:1527271932130};\\\", \\\"{x:1572,y:508,t:1527271932146};\\\", \\\"{x:1570,y:516,t:1527271932163};\\\", \\\"{x:1567,y:524,t:1527271932181};\\\", \\\"{x:1565,y:529,t:1527271932197};\\\", \\\"{x:1565,y:532,t:1527271932213};\\\", \\\"{x:1563,y:537,t:1527271932230};\\\", \\\"{x:1562,y:542,t:1527271932246};\\\", \\\"{x:1559,y:550,t:1527271932263};\\\", \\\"{x:1557,y:557,t:1527271932280};\\\", \\\"{x:1555,y:564,t:1527271932297};\\\", \\\"{x:1552,y:572,t:1527271932313};\\\", \\\"{x:1549,y:579,t:1527271932331};\\\", \\\"{x:1544,y:590,t:1527271932347};\\\", \\\"{x:1540,y:597,t:1527271932363};\\\", \\\"{x:1536,y:605,t:1527271932379};\\\", \\\"{x:1533,y:611,t:1527271932397};\\\", \\\"{x:1529,y:615,t:1527271932413};\\\", \\\"{x:1525,y:621,t:1527271932429};\\\", \\\"{x:1523,y:624,t:1527271932447};\\\", \\\"{x:1522,y:625,t:1527271932463};\\\", \\\"{x:1520,y:627,t:1527271932480};\\\", \\\"{x:1519,y:628,t:1527271932498};\\\", \\\"{x:1518,y:629,t:1527271932513};\\\", \\\"{x:1517,y:629,t:1527271932550};\\\", \\\"{x:1517,y:630,t:1527271932646};\\\", \\\"{x:1516,y:630,t:1527271932664};\\\", \\\"{x:1515,y:631,t:1527271932710};\\\", \\\"{x:1512,y:632,t:1527271932862};\\\", \\\"{x:1505,y:638,t:1527271932871};\\\", \\\"{x:1498,y:645,t:1527271932880};\\\", \\\"{x:1481,y:659,t:1527271932897};\\\", \\\"{x:1474,y:666,t:1527271932913};\\\", \\\"{x:1471,y:669,t:1527271932929};\\\", \\\"{x:1470,y:670,t:1527271932946};\\\", \\\"{x:1470,y:672,t:1527271932963};\\\", \\\"{x:1467,y:677,t:1527271932979};\\\", \\\"{x:1463,y:687,t:1527271932997};\\\", \\\"{x:1444,y:721,t:1527271933013};\\\", \\\"{x:1432,y:750,t:1527271933030};\\\", \\\"{x:1410,y:788,t:1527271933047};\\\", \\\"{x:1387,y:833,t:1527271933064};\\\", \\\"{x:1364,y:874,t:1527271933079};\\\", \\\"{x:1348,y:907,t:1527271933097};\\\", \\\"{x:1337,y:933,t:1527271933114};\\\", \\\"{x:1332,y:955,t:1527271933131};\\\", \\\"{x:1327,y:968,t:1527271933146};\\\", \\\"{x:1321,y:979,t:1527271933164};\\\", \\\"{x:1318,y:985,t:1527271933180};\\\", \\\"{x:1315,y:987,t:1527271933197};\\\", \\\"{x:1314,y:989,t:1527271933214};\\\", \\\"{x:1313,y:989,t:1527271933231};\\\", \\\"{x:1312,y:989,t:1527271933247};\\\", \\\"{x:1309,y:989,t:1527271933264};\\\", \\\"{x:1307,y:989,t:1527271933281};\\\", \\\"{x:1306,y:989,t:1527271933297};\\\", \\\"{x:1309,y:987,t:1527271933774};\\\", \\\"{x:1318,y:985,t:1527271933782};\\\", \\\"{x:1339,y:978,t:1527271933798};\\\", \\\"{x:1373,y:964,t:1527271933815};\\\", \\\"{x:1419,y:949,t:1527271933832};\\\", \\\"{x:1469,y:935,t:1527271933848};\\\", \\\"{x:1508,y:916,t:1527271933864};\\\", \\\"{x:1548,y:887,t:1527271933881};\\\", \\\"{x:1581,y:858,t:1527271933898};\\\", \\\"{x:1605,y:832,t:1527271933914};\\\", \\\"{x:1621,y:808,t:1527271933930};\\\", \\\"{x:1631,y:781,t:1527271933948};\\\", \\\"{x:1641,y:756,t:1527271933964};\\\", \\\"{x:1647,y:740,t:1527271933980};\\\", \\\"{x:1656,y:709,t:1527271933997};\\\", \\\"{x:1661,y:688,t:1527271934014};\\\", \\\"{x:1668,y:670,t:1527271934031};\\\", \\\"{x:1671,y:647,t:1527271934048};\\\", \\\"{x:1676,y:629,t:1527271934064};\\\", \\\"{x:1680,y:606,t:1527271934081};\\\", \\\"{x:1687,y:574,t:1527271934098};\\\", \\\"{x:1690,y:544,t:1527271934114};\\\", \\\"{x:1691,y:506,t:1527271934131};\\\", \\\"{x:1691,y:475,t:1527271934148};\\\", \\\"{x:1691,y:453,t:1527271934165};\\\", \\\"{x:1691,y:437,t:1527271934181};\\\", \\\"{x:1691,y:420,t:1527271934197};\\\", \\\"{x:1691,y:416,t:1527271934215};\\\", \\\"{x:1691,y:412,t:1527271934231};\\\", \\\"{x:1688,y:408,t:1527271934248};\\\", \\\"{x:1686,y:406,t:1527271934265};\\\", \\\"{x:1681,y:403,t:1527271934281};\\\", \\\"{x:1676,y:400,t:1527271934297};\\\", \\\"{x:1670,y:398,t:1527271934315};\\\", \\\"{x:1666,y:397,t:1527271934331};\\\", \\\"{x:1660,y:397,t:1527271934348};\\\", \\\"{x:1654,y:396,t:1527271934365};\\\", \\\"{x:1646,y:396,t:1527271934381};\\\", \\\"{x:1633,y:399,t:1527271934397};\\\", \\\"{x:1624,y:402,t:1527271934415};\\\", \\\"{x:1618,y:405,t:1527271934432};\\\", \\\"{x:1615,y:409,t:1527271934448};\\\", \\\"{x:1611,y:411,t:1527271934465};\\\", \\\"{x:1609,y:414,t:1527271934482};\\\", \\\"{x:1607,y:418,t:1527271934497};\\\", \\\"{x:1605,y:424,t:1527271934515};\\\", \\\"{x:1605,y:429,t:1527271934532};\\\", \\\"{x:1605,y:432,t:1527271934548};\\\", \\\"{x:1604,y:435,t:1527271934565};\\\", \\\"{x:1604,y:439,t:1527271934582};\\\", \\\"{x:1604,y:443,t:1527271934598};\\\", \\\"{x:1604,y:450,t:1527271934615};\\\", \\\"{x:1604,y:463,t:1527271934632};\\\", \\\"{x:1603,y:481,t:1527271934649};\\\", \\\"{x:1603,y:498,t:1527271934665};\\\", \\\"{x:1603,y:513,t:1527271934682};\\\", \\\"{x:1603,y:526,t:1527271934699};\\\", \\\"{x:1603,y:536,t:1527271934715};\\\", \\\"{x:1603,y:547,t:1527271934732};\\\", \\\"{x:1603,y:563,t:1527271934748};\\\", \\\"{x:1603,y:577,t:1527271934766};\\\", \\\"{x:1603,y:596,t:1527271934782};\\\", \\\"{x:1603,y:609,t:1527271934799};\\\", \\\"{x:1603,y:616,t:1527271934815};\\\", \\\"{x:1603,y:619,t:1527271934832};\\\", \\\"{x:1603,y:624,t:1527271934849};\\\", \\\"{x:1603,y:627,t:1527271934865};\\\", \\\"{x:1604,y:631,t:1527271934882};\\\", \\\"{x:1605,y:634,t:1527271934900};\\\", \\\"{x:1606,y:636,t:1527271934915};\\\", \\\"{x:1606,y:639,t:1527271934932};\\\", \\\"{x:1606,y:640,t:1527271934949};\\\", \\\"{x:1606,y:642,t:1527271934965};\\\", \\\"{x:1608,y:644,t:1527271934982};\\\", \\\"{x:1608,y:647,t:1527271934999};\\\", \\\"{x:1608,y:650,t:1527271935015};\\\", \\\"{x:1608,y:653,t:1527271935032};\\\", \\\"{x:1608,y:656,t:1527271935049};\\\", \\\"{x:1608,y:660,t:1527271935066};\\\", \\\"{x:1608,y:664,t:1527271935082};\\\", \\\"{x:1608,y:670,t:1527271935099};\\\", \\\"{x:1607,y:679,t:1527271935115};\\\", \\\"{x:1603,y:686,t:1527271935132};\\\", \\\"{x:1575,y:703,t:1527271935150};\\\", \\\"{x:1548,y:716,t:1527271935165};\\\", \\\"{x:1416,y:733,t:1527271935181};\\\", \\\"{x:1297,y:730,t:1527271935199};\\\", \\\"{x:1154,y:699,t:1527271935215};\\\", \\\"{x:989,y:657,t:1527271935232};\\\", \\\"{x:828,y:608,t:1527271935250};\\\", \\\"{x:685,y:567,t:1527271935266};\\\", \\\"{x:578,y:525,t:1527271935282};\\\", \\\"{x:540,y:509,t:1527271935290};\\\", \\\"{x:507,y:488,t:1527271935308};\\\", \\\"{x:495,y:480,t:1527271935325};\\\", \\\"{x:492,y:477,t:1527271935348};\\\", \\\"{x:491,y:477,t:1527271935429};\\\", \\\"{x:488,y:479,t:1527271935437};\\\", \\\"{x:482,y:482,t:1527271935448};\\\", \\\"{x:469,y:489,t:1527271935466};\\\", \\\"{x:462,y:494,t:1527271935483};\\\", \\\"{x:452,y:502,t:1527271935498};\\\", \\\"{x:445,y:509,t:1527271935517};\\\", \\\"{x:439,y:515,t:1527271935533};\\\", \\\"{x:436,y:519,t:1527271935549};\\\", \\\"{x:432,y:526,t:1527271935565};\\\", \\\"{x:431,y:530,t:1527271935582};\\\", \\\"{x:430,y:534,t:1527271935599};\\\", \\\"{x:428,y:540,t:1527271935617};\\\", \\\"{x:427,y:547,t:1527271935633};\\\", \\\"{x:423,y:554,t:1527271935649};\\\", \\\"{x:419,y:560,t:1527271935666};\\\", \\\"{x:414,y:566,t:1527271935683};\\\", \\\"{x:407,y:571,t:1527271935699};\\\", \\\"{x:400,y:575,t:1527271935716};\\\", \\\"{x:394,y:580,t:1527271935733};\\\", \\\"{x:392,y:581,t:1527271935749};\\\", \\\"{x:392,y:582,t:1527271935775};\\\", \\\"{x:392,y:583,t:1527271935788};\\\", \\\"{x:390,y:583,t:1527271935804};\\\", \\\"{x:387,y:584,t:1527271935829};\\\", \\\"{x:386,y:585,t:1527271935861};\\\", \\\"{x:386,y:586,t:1527271935957};\\\", \\\"{x:386,y:587,t:1527271935989};\\\", \\\"{x:386,y:588,t:1527271936063};\\\", \\\"{x:387,y:589,t:1527271938829};\\\", \\\"{x:391,y:589,t:1527271938838};\\\", \\\"{x:397,y:593,t:1527271938853};\\\", \\\"{x:405,y:600,t:1527271938869};\\\", \\\"{x:415,y:609,t:1527271938885};\\\", \\\"{x:439,y:626,t:1527271938902};\\\", \\\"{x:451,y:636,t:1527271938919};\\\", \\\"{x:454,y:640,t:1527271938935};\\\", \\\"{x:457,y:642,t:1527271938951};\\\", \\\"{x:457,y:643,t:1527271938969};\\\", \\\"{x:457,y:644,t:1527271938986};\\\", \\\"{x:457,y:646,t:1527271939001};\\\", \\\"{x:458,y:648,t:1527271939019};\\\", \\\"{x:460,y:652,t:1527271939036};\\\", \\\"{x:462,y:655,t:1527271939052};\\\", \\\"{x:465,y:661,t:1527271939069};\\\", \\\"{x:472,y:673,t:1527271939085};\\\", \\\"{x:478,y:682,t:1527271939102};\\\", \\\"{x:483,y:689,t:1527271939119};\\\", \\\"{x:491,y:699,t:1527271939136};\\\", \\\"{x:492,y:701,t:1527271939154};\\\", \\\"{x:492,y:702,t:1527271939277};\\\", \\\"{x:492,y:704,t:1527271939285};\\\", \\\"{x:492,y:705,t:1527271939301};\\\", \\\"{x:492,y:707,t:1527271939318};\\\", \\\"{x:492,y:710,t:1527271939336};\\\", \\\"{x:492,y:711,t:1527271939352};\\\", \\\"{x:493,y:711,t:1527271939934};\\\", \\\"{x:495,y:709,t:1527271940309};\\\", \\\"{x:496,y:707,t:1527271940319};\\\", \\\"{x:496,y:703,t:1527271940335};\\\" ] }, { \\\"rt\\\": 38666, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 270125, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"2WQ0M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -C -11 AM-F -11 AM-C -C -A -A -C -10 AM-11 AM-12 PM-Z -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:497,y:703,t:1527271941590};\\\", \\\"{x:497,y:702,t:1527271941604};\\\", \\\"{x:506,y:668,t:1527271941712};\\\", \\\"{x:506,y:664,t:1527271941723};\\\", \\\"{x:506,y:660,t:1527271941737};\\\", \\\"{x:506,y:658,t:1527271941753};\\\", \\\"{x:506,y:657,t:1527271941771};\\\", \\\"{x:506,y:656,t:1527271941797};\\\", \\\"{x:506,y:655,t:1527271941813};\\\", \\\"{x:506,y:654,t:1527271941821};\\\", \\\"{x:506,y:650,t:1527271941837};\\\", \\\"{x:506,y:643,t:1527271941854};\\\", \\\"{x:506,y:638,t:1527271941870};\\\", \\\"{x:506,y:635,t:1527271941888};\\\", \\\"{x:507,y:633,t:1527271941903};\\\", \\\"{x:507,y:632,t:1527271941921};\\\", \\\"{x:507,y:631,t:1527271941938};\\\", \\\"{x:507,y:630,t:1527271941954};\\\", \\\"{x:507,y:629,t:1527271942166};\\\", \\\"{x:506,y:629,t:1527271942182};\\\", \\\"{x:505,y:628,t:1527271942198};\\\", \\\"{x:504,y:628,t:1527271942206};\\\", \\\"{x:503,y:628,t:1527271942221};\\\", \\\"{x:499,y:626,t:1527271942238};\\\", \\\"{x:498,y:626,t:1527271942288};\\\", \\\"{x:497,y:625,t:1527271942305};\\\", \\\"{x:494,y:621,t:1527271942321};\\\", \\\"{x:493,y:614,t:1527271942338};\\\", \\\"{x:491,y:610,t:1527271942355};\\\", \\\"{x:491,y:609,t:1527271942371};\\\", \\\"{x:493,y:609,t:1527271948678};\\\", \\\"{x:496,y:609,t:1527271948694};\\\", \\\"{x:497,y:609,t:1527271948710};\\\", \\\"{x:499,y:609,t:1527271948728};\\\", \\\"{x:502,y:609,t:1527271948925};\\\", \\\"{x:507,y:609,t:1527271948933};\\\", \\\"{x:512,y:609,t:1527271948943};\\\", \\\"{x:548,y:609,t:1527271948960};\\\", \\\"{x:615,y:609,t:1527271948977};\\\", \\\"{x:704,y:609,t:1527271948993};\\\", \\\"{x:807,y:609,t:1527271949011};\\\", \\\"{x:920,y:609,t:1527271949024};\\\", \\\"{x:1053,y:609,t:1527271949041};\\\", \\\"{x:1186,y:610,t:1527271949058};\\\", \\\"{x:1366,y:610,t:1527271949075};\\\", \\\"{x:1463,y:601,t:1527271949091};\\\", \\\"{x:1535,y:581,t:1527271949108};\\\", \\\"{x:1574,y:562,t:1527271949125};\\\", \\\"{x:1595,y:554,t:1527271949141};\\\", \\\"{x:1602,y:547,t:1527271949158};\\\", \\\"{x:1606,y:543,t:1527271949175};\\\", \\\"{x:1608,y:539,t:1527271949191};\\\", \\\"{x:1609,y:539,t:1527271949208};\\\", \\\"{x:1609,y:537,t:1527271949227};\\\", \\\"{x:1609,y:536,t:1527271949292};\\\", \\\"{x:1609,y:534,t:1527271949308};\\\", \\\"{x:1609,y:531,t:1527271949325};\\\", \\\"{x:1608,y:529,t:1527271949341};\\\", \\\"{x:1606,y:525,t:1527271949358};\\\", \\\"{x:1602,y:519,t:1527271949376};\\\", \\\"{x:1600,y:515,t:1527271949392};\\\", \\\"{x:1598,y:512,t:1527271949408};\\\", \\\"{x:1594,y:509,t:1527271949425};\\\", \\\"{x:1591,y:507,t:1527271949443};\\\", \\\"{x:1589,y:506,t:1527271949458};\\\", \\\"{x:1586,y:504,t:1527271949475};\\\", \\\"{x:1585,y:503,t:1527271949492};\\\", \\\"{x:1582,y:503,t:1527271949508};\\\", \\\"{x:1580,y:503,t:1527271949526};\\\", \\\"{x:1576,y:503,t:1527271949543};\\\", \\\"{x:1567,y:501,t:1527271949559};\\\", \\\"{x:1552,y:501,t:1527271949575};\\\", \\\"{x:1529,y:507,t:1527271949593};\\\", \\\"{x:1509,y:511,t:1527271949608};\\\", \\\"{x:1487,y:513,t:1527271949626};\\\", \\\"{x:1462,y:519,t:1527271949642};\\\", \\\"{x:1441,y:526,t:1527271949659};\\\", \\\"{x:1406,y:530,t:1527271949676};\\\", \\\"{x:1383,y:533,t:1527271949692};\\\", \\\"{x:1359,y:537,t:1527271949708};\\\", \\\"{x:1341,y:540,t:1527271949726};\\\", \\\"{x:1331,y:541,t:1527271949743};\\\", \\\"{x:1325,y:542,t:1527271949759};\\\", \\\"{x:1320,y:543,t:1527271949775};\\\", \\\"{x:1317,y:544,t:1527271949792};\\\", \\\"{x:1315,y:545,t:1527271949808};\\\", \\\"{x:1312,y:548,t:1527271949825};\\\", \\\"{x:1309,y:551,t:1527271949844};\\\", \\\"{x:1308,y:552,t:1527271949859};\\\", \\\"{x:1307,y:556,t:1527271949876};\\\", \\\"{x:1306,y:558,t:1527271949893};\\\", \\\"{x:1305,y:561,t:1527271949909};\\\", \\\"{x:1305,y:566,t:1527271949925};\\\", \\\"{x:1305,y:572,t:1527271949942};\\\", \\\"{x:1305,y:576,t:1527271949959};\\\", \\\"{x:1305,y:581,t:1527271949975};\\\", \\\"{x:1305,y:587,t:1527271949992};\\\", \\\"{x:1305,y:593,t:1527271950009};\\\", \\\"{x:1305,y:598,t:1527271950025};\\\", \\\"{x:1305,y:605,t:1527271950042};\\\", \\\"{x:1307,y:618,t:1527271950059};\\\", \\\"{x:1310,y:629,t:1527271950076};\\\", \\\"{x:1314,y:643,t:1527271950093};\\\", \\\"{x:1319,y:656,t:1527271950109};\\\", \\\"{x:1325,y:671,t:1527271950125};\\\", \\\"{x:1330,y:680,t:1527271950143};\\\", \\\"{x:1337,y:691,t:1527271950160};\\\", \\\"{x:1339,y:699,t:1527271950175};\\\", \\\"{x:1342,y:703,t:1527271950193};\\\", \\\"{x:1342,y:706,t:1527271950209};\\\", \\\"{x:1345,y:713,t:1527271950225};\\\", \\\"{x:1347,y:718,t:1527271950242};\\\", \\\"{x:1349,y:725,t:1527271950259};\\\", \\\"{x:1351,y:730,t:1527271950275};\\\", \\\"{x:1353,y:737,t:1527271950293};\\\", \\\"{x:1355,y:746,t:1527271950309};\\\", \\\"{x:1358,y:755,t:1527271950326};\\\", \\\"{x:1360,y:764,t:1527271950342};\\\", \\\"{x:1360,y:771,t:1527271950360};\\\", \\\"{x:1360,y:779,t:1527271950376};\\\", \\\"{x:1360,y:788,t:1527271950393};\\\", \\\"{x:1363,y:799,t:1527271950410};\\\", \\\"{x:1364,y:811,t:1527271950426};\\\", \\\"{x:1364,y:816,t:1527271950443};\\\", \\\"{x:1366,y:829,t:1527271950460};\\\", \\\"{x:1367,y:836,t:1527271950476};\\\", \\\"{x:1367,y:838,t:1527271950493};\\\", \\\"{x:1365,y:840,t:1527271950510};\\\", \\\"{x:1365,y:843,t:1527271950527};\\\", \\\"{x:1365,y:844,t:1527271950543};\\\", \\\"{x:1361,y:845,t:1527271950560};\\\", \\\"{x:1360,y:846,t:1527271950576};\\\", \\\"{x:1359,y:846,t:1527271950596};\\\", \\\"{x:1357,y:846,t:1527271950610};\\\", \\\"{x:1353,y:847,t:1527271950627};\\\", \\\"{x:1348,y:847,t:1527271950642};\\\", \\\"{x:1339,y:847,t:1527271950660};\\\", \\\"{x:1330,y:847,t:1527271950677};\\\", \\\"{x:1316,y:847,t:1527271950693};\\\", \\\"{x:1299,y:845,t:1527271950710};\\\", \\\"{x:1280,y:841,t:1527271950727};\\\", \\\"{x:1260,y:837,t:1527271950743};\\\", \\\"{x:1240,y:832,t:1527271950760};\\\", \\\"{x:1227,y:829,t:1527271950776};\\\", \\\"{x:1217,y:828,t:1527271950794};\\\", \\\"{x:1214,y:827,t:1527271950810};\\\", \\\"{x:1213,y:827,t:1527271950826};\\\", \\\"{x:1213,y:826,t:1527271951162};\\\", \\\"{x:1213,y:825,t:1527271951708};\\\", \\\"{x:1217,y:831,t:1527271951716};\\\", \\\"{x:1221,y:838,t:1527271951727};\\\", \\\"{x:1227,y:854,t:1527271951744};\\\", \\\"{x:1234,y:870,t:1527271951761};\\\", \\\"{x:1239,y:882,t:1527271951777};\\\", \\\"{x:1242,y:891,t:1527271951794};\\\", \\\"{x:1243,y:894,t:1527271951810};\\\", \\\"{x:1243,y:895,t:1527271951827};\\\", \\\"{x:1243,y:898,t:1527271951843};\\\", \\\"{x:1243,y:900,t:1527271951861};\\\", \\\"{x:1243,y:902,t:1527271951876};\\\", \\\"{x:1243,y:904,t:1527271951893};\\\", \\\"{x:1243,y:905,t:1527271951910};\\\", \\\"{x:1243,y:907,t:1527271951927};\\\", \\\"{x:1243,y:908,t:1527271951944};\\\", \\\"{x:1244,y:910,t:1527271951961};\\\", \\\"{x:1246,y:913,t:1527271951977};\\\", \\\"{x:1248,y:916,t:1527271951993};\\\", \\\"{x:1250,y:918,t:1527271952010};\\\", \\\"{x:1252,y:921,t:1527271952027};\\\", \\\"{x:1254,y:925,t:1527271952043};\\\", \\\"{x:1256,y:928,t:1527271952061};\\\", \\\"{x:1260,y:935,t:1527271952078};\\\", \\\"{x:1270,y:949,t:1527271952093};\\\", \\\"{x:1281,y:958,t:1527271952111};\\\", \\\"{x:1290,y:962,t:1527271952128};\\\", \\\"{x:1292,y:962,t:1527271952143};\\\", \\\"{x:1293,y:962,t:1527271952161};\\\", \\\"{x:1293,y:963,t:1527271952349};\\\", \\\"{x:1293,y:964,t:1527271952361};\\\", \\\"{x:1293,y:966,t:1527271952378};\\\", \\\"{x:1293,y:967,t:1527271952395};\\\", \\\"{x:1293,y:968,t:1527271952411};\\\", \\\"{x:1292,y:969,t:1527271952444};\\\", \\\"{x:1291,y:970,t:1527271952556};\\\", \\\"{x:1290,y:971,t:1527271952571};\\\", \\\"{x:1289,y:971,t:1527271952595};\\\", \\\"{x:1288,y:971,t:1527271952612};\\\", \\\"{x:1287,y:971,t:1527271952628};\\\", \\\"{x:1286,y:971,t:1527271952659};\\\", \\\"{x:1285,y:971,t:1527271952691};\\\", \\\"{x:1284,y:971,t:1527271952707};\\\", \\\"{x:1283,y:971,t:1527271952723};\\\", \\\"{x:1282,y:971,t:1527271952732};\\\", \\\"{x:1281,y:971,t:1527271952763};\\\", \\\"{x:1281,y:969,t:1527271952980};\\\", \\\"{x:1281,y:968,t:1527271953013};\\\", \\\"{x:1281,y:966,t:1527271953035};\\\", \\\"{x:1281,y:965,t:1527271953059};\\\", \\\"{x:1281,y:963,t:1527271953076};\\\", \\\"{x:1281,y:961,t:1527271953084};\\\", \\\"{x:1282,y:958,t:1527271953095};\\\", \\\"{x:1288,y:948,t:1527271953112};\\\", \\\"{x:1293,y:939,t:1527271953128};\\\", \\\"{x:1299,y:927,t:1527271953145};\\\", \\\"{x:1308,y:913,t:1527271953162};\\\", \\\"{x:1317,y:898,t:1527271953178};\\\", \\\"{x:1323,y:883,t:1527271953195};\\\", \\\"{x:1335,y:842,t:1527271953211};\\\", \\\"{x:1342,y:821,t:1527271953228};\\\", \\\"{x:1345,y:809,t:1527271953245};\\\", \\\"{x:1350,y:799,t:1527271953262};\\\", \\\"{x:1354,y:793,t:1527271953278};\\\", \\\"{x:1355,y:788,t:1527271953295};\\\", \\\"{x:1357,y:785,t:1527271953311};\\\", \\\"{x:1359,y:782,t:1527271953328};\\\", \\\"{x:1359,y:781,t:1527271953345};\\\", \\\"{x:1361,y:778,t:1527271953362};\\\", \\\"{x:1361,y:777,t:1527271953378};\\\", \\\"{x:1362,y:777,t:1527271953394};\\\", \\\"{x:1363,y:775,t:1527271953412};\\\", \\\"{x:1364,y:774,t:1527271953484};\\\", \\\"{x:1365,y:774,t:1527271953508};\\\", \\\"{x:1368,y:774,t:1527271953516};\\\", \\\"{x:1368,y:773,t:1527271953528};\\\", \\\"{x:1372,y:772,t:1527271953545};\\\", \\\"{x:1374,y:771,t:1527271953562};\\\", \\\"{x:1375,y:770,t:1527271953579};\\\", \\\"{x:1376,y:770,t:1527271955068};\\\", \\\"{x:1377,y:770,t:1527271955079};\\\", \\\"{x:1378,y:770,t:1527271955096};\\\", \\\"{x:1379,y:768,t:1527271955113};\\\", \\\"{x:1379,y:767,t:1527271955148};\\\", \\\"{x:1380,y:767,t:1527271955171};\\\", \\\"{x:1381,y:765,t:1527271955203};\\\", \\\"{x:1382,y:764,t:1527271955323};\\\", \\\"{x:1383,y:762,t:1527271955412};\\\", \\\"{x:1384,y:762,t:1527271955436};\\\", \\\"{x:1384,y:764,t:1527271962636};\\\", \\\"{x:1386,y:774,t:1527271962652};\\\", \\\"{x:1388,y:780,t:1527271962668};\\\", \\\"{x:1389,y:783,t:1527271962684};\\\", \\\"{x:1389,y:786,t:1527271962701};\\\", \\\"{x:1389,y:787,t:1527271962719};\\\", \\\"{x:1389,y:788,t:1527271962734};\\\", \\\"{x:1389,y:789,t:1527271962779};\\\", \\\"{x:1389,y:792,t:1527271962787};\\\", \\\"{x:1385,y:795,t:1527271962801};\\\", \\\"{x:1369,y:802,t:1527271962819};\\\", \\\"{x:1335,y:810,t:1527271962834};\\\", \\\"{x:1221,y:811,t:1527271962851};\\\", \\\"{x:1104,y:811,t:1527271962868};\\\", \\\"{x:963,y:808,t:1527271962885};\\\", \\\"{x:824,y:786,t:1527271962901};\\\", \\\"{x:721,y:773,t:1527271962918};\\\", \\\"{x:638,y:748,t:1527271962935};\\\", \\\"{x:592,y:731,t:1527271962951};\\\", \\\"{x:569,y:720,t:1527271962967};\\\", \\\"{x:556,y:710,t:1527271962986};\\\", \\\"{x:541,y:699,t:1527271963002};\\\", \\\"{x:520,y:686,t:1527271963018};\\\", \\\"{x:484,y:663,t:1527271963031};\\\", \\\"{x:441,y:640,t:1527271963047};\\\", \\\"{x:393,y:618,t:1527271963064};\\\", \\\"{x:343,y:592,t:1527271963087};\\\", \\\"{x:320,y:581,t:1527271963103};\\\", \\\"{x:315,y:577,t:1527271963120};\\\", \\\"{x:313,y:575,t:1527271963137};\\\", \\\"{x:313,y:571,t:1527271963154};\\\", \\\"{x:313,y:569,t:1527271963170};\\\", \\\"{x:315,y:562,t:1527271963186};\\\", \\\"{x:318,y:557,t:1527271963203};\\\", \\\"{x:319,y:554,t:1527271963220};\\\", \\\"{x:321,y:554,t:1527271963237};\\\", \\\"{x:321,y:553,t:1527271963254};\\\", \\\"{x:322,y:552,t:1527271963269};\\\", \\\"{x:323,y:552,t:1527271963287};\\\", \\\"{x:325,y:551,t:1527271963304};\\\", \\\"{x:330,y:551,t:1527271963319};\\\", \\\"{x:333,y:551,t:1527271963336};\\\", \\\"{x:338,y:551,t:1527271963354};\\\", \\\"{x:340,y:551,t:1527271963369};\\\", \\\"{x:343,y:551,t:1527271963387};\\\", \\\"{x:345,y:551,t:1527271963411};\\\", \\\"{x:345,y:552,t:1527271963427};\\\", \\\"{x:346,y:552,t:1527271963459};\\\", \\\"{x:348,y:552,t:1527271963491};\\\", \\\"{x:349,y:552,t:1527271963504};\\\", \\\"{x:352,y:553,t:1527271963520};\\\", \\\"{x:358,y:554,t:1527271963537};\\\", \\\"{x:363,y:556,t:1527271963554};\\\", \\\"{x:369,y:557,t:1527271963570};\\\", \\\"{x:376,y:557,t:1527271963588};\\\", \\\"{x:379,y:557,t:1527271963604};\\\", \\\"{x:381,y:557,t:1527271963619};\\\", \\\"{x:382,y:557,t:1527271963637};\\\", \\\"{x:382,y:558,t:1527271963654};\\\", \\\"{x:383,y:558,t:1527271963670};\\\", \\\"{x:384,y:559,t:1527271964292};\\\", \\\"{x:390,y:559,t:1527271964304};\\\", \\\"{x:414,y:564,t:1527271964321};\\\", \\\"{x:465,y:572,t:1527271964339};\\\", \\\"{x:548,y:583,t:1527271964355};\\\", \\\"{x:736,y:616,t:1527271964371};\\\", \\\"{x:912,y:659,t:1527271964387};\\\", \\\"{x:1086,y:707,t:1527271964404};\\\", \\\"{x:1254,y:749,t:1527271964421};\\\", \\\"{x:1378,y:785,t:1527271964438};\\\", \\\"{x:1462,y:807,t:1527271964454};\\\", \\\"{x:1499,y:819,t:1527271964471};\\\", \\\"{x:1514,y:823,t:1527271964488};\\\", \\\"{x:1517,y:824,t:1527271964504};\\\", \\\"{x:1514,y:823,t:1527271964683};\\\", \\\"{x:1506,y:819,t:1527271964692};\\\", \\\"{x:1498,y:816,t:1527271964705};\\\", \\\"{x:1475,y:809,t:1527271964721};\\\", \\\"{x:1446,y:799,t:1527271964738};\\\", \\\"{x:1411,y:790,t:1527271964755};\\\", \\\"{x:1394,y:785,t:1527271964771};\\\", \\\"{x:1384,y:782,t:1527271964788};\\\", \\\"{x:1381,y:781,t:1527271964805};\\\", \\\"{x:1380,y:780,t:1527271964876};\\\", \\\"{x:1379,y:779,t:1527271965027};\\\", \\\"{x:1377,y:781,t:1527271965235};\\\", \\\"{x:1375,y:785,t:1527271965243};\\\", \\\"{x:1370,y:792,t:1527271965255};\\\", \\\"{x:1361,y:803,t:1527271965272};\\\", \\\"{x:1353,y:814,t:1527271965288};\\\", \\\"{x:1345,y:825,t:1527271965306};\\\", \\\"{x:1334,y:842,t:1527271965322};\\\", \\\"{x:1323,y:858,t:1527271965338};\\\", \\\"{x:1307,y:883,t:1527271965356};\\\", \\\"{x:1296,y:898,t:1527271965372};\\\", \\\"{x:1283,y:915,t:1527271965388};\\\", \\\"{x:1274,y:927,t:1527271965406};\\\", \\\"{x:1266,y:937,t:1527271965422};\\\", \\\"{x:1256,y:952,t:1527271965438};\\\", \\\"{x:1252,y:961,t:1527271965455};\\\", \\\"{x:1251,y:965,t:1527271965472};\\\", \\\"{x:1250,y:966,t:1527271965488};\\\", \\\"{x:1250,y:967,t:1527271965505};\\\", \\\"{x:1250,y:968,t:1527271965531};\\\", \\\"{x:1251,y:969,t:1527271965604};\\\", \\\"{x:1253,y:969,t:1527271965611};\\\", \\\"{x:1254,y:969,t:1527271965622};\\\", \\\"{x:1257,y:969,t:1527271965638};\\\", \\\"{x:1264,y:970,t:1527271965656};\\\", \\\"{x:1271,y:970,t:1527271965673};\\\", \\\"{x:1280,y:970,t:1527271965688};\\\", \\\"{x:1287,y:970,t:1527271965705};\\\", \\\"{x:1290,y:970,t:1527271965723};\\\", \\\"{x:1291,y:970,t:1527271965738};\\\", \\\"{x:1292,y:970,t:1527271965756};\\\", \\\"{x:1292,y:969,t:1527271966036};\\\", \\\"{x:1291,y:969,t:1527271966043};\\\", \\\"{x:1290,y:969,t:1527271966067};\\\", \\\"{x:1289,y:969,t:1527271966075};\\\", \\\"{x:1288,y:969,t:1527271966089};\\\", \\\"{x:1287,y:968,t:1527271966105};\\\", \\\"{x:1286,y:968,t:1527271966122};\\\", \\\"{x:1285,y:968,t:1527271966139};\\\", \\\"{x:1284,y:968,t:1527271966162};\\\", \\\"{x:1283,y:968,t:1527271966172};\\\", \\\"{x:1282,y:967,t:1527271966189};\\\", \\\"{x:1281,y:967,t:1527271966244};\\\", \\\"{x:1280,y:965,t:1527271966256};\\\", \\\"{x:1278,y:961,t:1527271966272};\\\", \\\"{x:1273,y:948,t:1527271966289};\\\", \\\"{x:1265,y:927,t:1527271966305};\\\", \\\"{x:1255,y:907,t:1527271966322};\\\", \\\"{x:1241,y:877,t:1527271966339};\\\", \\\"{x:1233,y:861,t:1527271966355};\\\", \\\"{x:1229,y:850,t:1527271966372};\\\", \\\"{x:1225,y:841,t:1527271966390};\\\", \\\"{x:1219,y:824,t:1527271966406};\\\", \\\"{x:1214,y:811,t:1527271966423};\\\", \\\"{x:1209,y:802,t:1527271966440};\\\", \\\"{x:1205,y:798,t:1527271966456};\\\", \\\"{x:1205,y:797,t:1527271966472};\\\", \\\"{x:1205,y:801,t:1527271966596};\\\", \\\"{x:1205,y:804,t:1527271966606};\\\", \\\"{x:1206,y:812,t:1527271966622};\\\", \\\"{x:1211,y:822,t:1527271966640};\\\", \\\"{x:1222,y:840,t:1527271966656};\\\", \\\"{x:1241,y:863,t:1527271966673};\\\", \\\"{x:1257,y:884,t:1527271966690};\\\", \\\"{x:1271,y:902,t:1527271966706};\\\", \\\"{x:1278,y:911,t:1527271966722};\\\", \\\"{x:1281,y:918,t:1527271966740};\\\", \\\"{x:1281,y:921,t:1527271966757};\\\", \\\"{x:1281,y:923,t:1527271966773};\\\", \\\"{x:1281,y:925,t:1527271966790};\\\", \\\"{x:1281,y:922,t:1527271966907};\\\", \\\"{x:1281,y:919,t:1527271966922};\\\", \\\"{x:1281,y:913,t:1527271966939};\\\", \\\"{x:1281,y:910,t:1527271966956};\\\", \\\"{x:1281,y:906,t:1527271966974};\\\", \\\"{x:1281,y:901,t:1527271966990};\\\", \\\"{x:1281,y:891,t:1527271967007};\\\", \\\"{x:1281,y:882,t:1527271967023};\\\", \\\"{x:1281,y:867,t:1527271967039};\\\", \\\"{x:1281,y:857,t:1527271967057};\\\", \\\"{x:1282,y:844,t:1527271967073};\\\", \\\"{x:1283,y:839,t:1527271967089};\\\", \\\"{x:1284,y:835,t:1527271967106};\\\", \\\"{x:1286,y:831,t:1527271967123};\\\", \\\"{x:1286,y:829,t:1527271967138};\\\", \\\"{x:1286,y:828,t:1527271967219};\\\", \\\"{x:1287,y:827,t:1527271967227};\\\", \\\"{x:1288,y:826,t:1527271967243};\\\", \\\"{x:1288,y:825,t:1527271967652};\\\", \\\"{x:1287,y:825,t:1527271967659};\\\", \\\"{x:1284,y:825,t:1527271967674};\\\", \\\"{x:1278,y:825,t:1527271967690};\\\", \\\"{x:1270,y:825,t:1527271967707};\\\", \\\"{x:1248,y:825,t:1527271967723};\\\", \\\"{x:1229,y:825,t:1527271967740};\\\", \\\"{x:1206,y:824,t:1527271967757};\\\", \\\"{x:1181,y:819,t:1527271967774};\\\", \\\"{x:1164,y:815,t:1527271967791};\\\", \\\"{x:1155,y:811,t:1527271967806};\\\", \\\"{x:1154,y:811,t:1527271967823};\\\", \\\"{x:1155,y:811,t:1527271967851};\\\", \\\"{x:1157,y:811,t:1527271967859};\\\", \\\"{x:1158,y:811,t:1527271967873};\\\", \\\"{x:1160,y:811,t:1527271967890};\\\", \\\"{x:1161,y:811,t:1527271967906};\\\", \\\"{x:1165,y:811,t:1527271967923};\\\", \\\"{x:1171,y:811,t:1527271967941};\\\", \\\"{x:1183,y:813,t:1527271967956};\\\", \\\"{x:1196,y:818,t:1527271967974};\\\", \\\"{x:1207,y:824,t:1527271967991};\\\", \\\"{x:1218,y:831,t:1527271968007};\\\", \\\"{x:1228,y:839,t:1527271968024};\\\", \\\"{x:1235,y:846,t:1527271968041};\\\", \\\"{x:1241,y:854,t:1527271968057};\\\", \\\"{x:1244,y:860,t:1527271968074};\\\", \\\"{x:1246,y:865,t:1527271968091};\\\", \\\"{x:1247,y:870,t:1527271968106};\\\", \\\"{x:1249,y:875,t:1527271968123};\\\", \\\"{x:1250,y:880,t:1527271968140};\\\", \\\"{x:1250,y:884,t:1527271968158};\\\", \\\"{x:1250,y:889,t:1527271968173};\\\", \\\"{x:1249,y:897,t:1527271968190};\\\", \\\"{x:1249,y:905,t:1527271968208};\\\", \\\"{x:1248,y:915,t:1527271968224};\\\", \\\"{x:1247,y:923,t:1527271968241};\\\", \\\"{x:1246,y:931,t:1527271968258};\\\", \\\"{x:1244,y:940,t:1527271968274};\\\", \\\"{x:1240,y:950,t:1527271968291};\\\", \\\"{x:1235,y:956,t:1527271968307};\\\", \\\"{x:1234,y:960,t:1527271968323};\\\", \\\"{x:1232,y:964,t:1527271968341};\\\", \\\"{x:1231,y:964,t:1527271968357};\\\", \\\"{x:1230,y:967,t:1527271968374};\\\", \\\"{x:1229,y:968,t:1527271968390};\\\", \\\"{x:1228,y:968,t:1527271968411};\\\", \\\"{x:1228,y:969,t:1527271968444};\\\", \\\"{x:1226,y:969,t:1527271968475};\\\", \\\"{x:1225,y:970,t:1527271968491};\\\", \\\"{x:1225,y:971,t:1527271968508};\\\", \\\"{x:1224,y:971,t:1527271968603};\\\", \\\"{x:1224,y:968,t:1527271968612};\\\", \\\"{x:1224,y:962,t:1527271968623};\\\", \\\"{x:1224,y:943,t:1527271968641};\\\", \\\"{x:1224,y:924,t:1527271968658};\\\", \\\"{x:1224,y:905,t:1527271968674};\\\", \\\"{x:1229,y:881,t:1527271968691};\\\", \\\"{x:1235,y:861,t:1527271968708};\\\", \\\"{x:1238,y:854,t:1527271968724};\\\", \\\"{x:1241,y:848,t:1527271968741};\\\", \\\"{x:1242,y:845,t:1527271968758};\\\", \\\"{x:1242,y:844,t:1527271968774};\\\", \\\"{x:1242,y:843,t:1527271968791};\\\", \\\"{x:1242,y:842,t:1527271968807};\\\", \\\"{x:1241,y:841,t:1527271969020};\\\", \\\"{x:1241,y:840,t:1527271969028};\\\", \\\"{x:1238,y:839,t:1527271969042};\\\", \\\"{x:1233,y:837,t:1527271969058};\\\", \\\"{x:1230,y:835,t:1527271969074};\\\", \\\"{x:1228,y:834,t:1527271969091};\\\", \\\"{x:1227,y:833,t:1527271969108};\\\", \\\"{x:1226,y:837,t:1527271970108};\\\", \\\"{x:1224,y:846,t:1527271970125};\\\", \\\"{x:1224,y:853,t:1527271970142};\\\", \\\"{x:1224,y:860,t:1527271970159};\\\", \\\"{x:1224,y:870,t:1527271970175};\\\", \\\"{x:1224,y:882,t:1527271970192};\\\", \\\"{x:1225,y:894,t:1527271970208};\\\", \\\"{x:1229,y:908,t:1527271970225};\\\", \\\"{x:1239,y:931,t:1527271970243};\\\", \\\"{x:1242,y:939,t:1527271970258};\\\", \\\"{x:1247,y:949,t:1527271970274};\\\", \\\"{x:1251,y:958,t:1527271970291};\\\", \\\"{x:1253,y:961,t:1527271970309};\\\", \\\"{x:1253,y:962,t:1527271970347};\\\", \\\"{x:1253,y:964,t:1527271970359};\\\", \\\"{x:1254,y:964,t:1527271970374};\\\", \\\"{x:1255,y:966,t:1527271970392};\\\", \\\"{x:1256,y:966,t:1527271970409};\\\", \\\"{x:1257,y:967,t:1527271970425};\\\", \\\"{x:1258,y:967,t:1527271970442};\\\", \\\"{x:1259,y:967,t:1527271970458};\\\", \\\"{x:1264,y:967,t:1527271970475};\\\", \\\"{x:1270,y:967,t:1527271970491};\\\", \\\"{x:1284,y:967,t:1527271970508};\\\", \\\"{x:1296,y:969,t:1527271970526};\\\", \\\"{x:1308,y:971,t:1527271970542};\\\", \\\"{x:1314,y:972,t:1527271970558};\\\", \\\"{x:1316,y:973,t:1527271970575};\\\", \\\"{x:1317,y:973,t:1527271970611};\\\", \\\"{x:1318,y:973,t:1527271970626};\\\", \\\"{x:1320,y:973,t:1527271970642};\\\", \\\"{x:1326,y:973,t:1527271970659};\\\", \\\"{x:1336,y:973,t:1527271970675};\\\", \\\"{x:1342,y:973,t:1527271970692};\\\", \\\"{x:1349,y:973,t:1527271970709};\\\", \\\"{x:1355,y:973,t:1527271970726};\\\", \\\"{x:1359,y:973,t:1527271970741};\\\", \\\"{x:1360,y:973,t:1527271970758};\\\", \\\"{x:1361,y:973,t:1527271970883};\\\", \\\"{x:1361,y:972,t:1527271970940};\\\", \\\"{x:1361,y:970,t:1527271970955};\\\", \\\"{x:1361,y:969,t:1527271970971};\\\", \\\"{x:1360,y:967,t:1527271970980};\\\", \\\"{x:1358,y:965,t:1527271970995};\\\", \\\"{x:1357,y:965,t:1527271971008};\\\", \\\"{x:1357,y:964,t:1527271971026};\\\", \\\"{x:1356,y:963,t:1527271971046};\\\", \\\"{x:1356,y:962,t:1527271971059};\\\", \\\"{x:1355,y:961,t:1527271971091};\\\", \\\"{x:1355,y:960,t:1527271971356};\\\", \\\"{x:1354,y:959,t:1527271971396};\\\", \\\"{x:1353,y:959,t:1527271971408};\\\", \\\"{x:1352,y:959,t:1527271971667};\\\", \\\"{x:1351,y:959,t:1527271971683};\\\", \\\"{x:1350,y:959,t:1527271971699};\\\", \\\"{x:1349,y:959,t:1527271971731};\\\", \\\"{x:1348,y:959,t:1527271971771};\\\", \\\"{x:1347,y:959,t:1527271971795};\\\", \\\"{x:1346,y:960,t:1527271971852};\\\", \\\"{x:1345,y:960,t:1527271971867};\\\", \\\"{x:1344,y:961,t:1527271971907};\\\", \\\"{x:1344,y:958,t:1527271972572};\\\", \\\"{x:1344,y:955,t:1527271972580};\\\", \\\"{x:1344,y:952,t:1527271972595};\\\", \\\"{x:1344,y:946,t:1527271972609};\\\", \\\"{x:1344,y:939,t:1527271972626};\\\", \\\"{x:1343,y:921,t:1527271972642};\\\", \\\"{x:1339,y:912,t:1527271972659};\\\", \\\"{x:1336,y:902,t:1527271972676};\\\", \\\"{x:1335,y:896,t:1527271972693};\\\", \\\"{x:1332,y:892,t:1527271972709};\\\", \\\"{x:1332,y:890,t:1527271972726};\\\", \\\"{x:1332,y:889,t:1527271972743};\\\", \\\"{x:1332,y:888,t:1527271972811};\\\", \\\"{x:1332,y:887,t:1527271972851};\\\", \\\"{x:1333,y:886,t:1527271972883};\\\", \\\"{x:1334,y:886,t:1527271972894};\\\", \\\"{x:1335,y:886,t:1527271972916};\\\", \\\"{x:1336,y:886,t:1527271972939};\\\", \\\"{x:1337,y:885,t:1527271972947};\\\", \\\"{x:1338,y:885,t:1527271972971};\\\", \\\"{x:1339,y:885,t:1527271972995};\\\", \\\"{x:1340,y:885,t:1527271973011};\\\", \\\"{x:1341,y:884,t:1527271973027};\\\", \\\"{x:1342,y:884,t:1527271973075};\\\", \\\"{x:1343,y:884,t:1527271973283};\\\", \\\"{x:1343,y:885,t:1527271973299};\\\", \\\"{x:1343,y:887,t:1527271973315};\\\", \\\"{x:1343,y:888,t:1527271973347};\\\", \\\"{x:1344,y:890,t:1527271974620};\\\", \\\"{x:1345,y:891,t:1527271974651};\\\", \\\"{x:1346,y:892,t:1527271974764};\\\", \\\"{x:1344,y:892,t:1527271977043};\\\", \\\"{x:1341,y:892,t:1527271977052};\\\", \\\"{x:1337,y:892,t:1527271977063};\\\", \\\"{x:1326,y:889,t:1527271977078};\\\", \\\"{x:1311,y:883,t:1527271977096};\\\", \\\"{x:1293,y:874,t:1527271977112};\\\", \\\"{x:1270,y:862,t:1527271977128};\\\", \\\"{x:1247,y:851,t:1527271977145};\\\", \\\"{x:1186,y:815,t:1527271977162};\\\", \\\"{x:1117,y:786,t:1527271977178};\\\", \\\"{x:1062,y:752,t:1527271977196};\\\", \\\"{x:1002,y:718,t:1527271977212};\\\", \\\"{x:941,y:691,t:1527271977229};\\\", \\\"{x:895,y:667,t:1527271977245};\\\", \\\"{x:865,y:658,t:1527271977262};\\\", \\\"{x:846,y:651,t:1527271977279};\\\", \\\"{x:829,y:645,t:1527271977295};\\\", \\\"{x:819,y:643,t:1527271977312};\\\", \\\"{x:809,y:643,t:1527271977329};\\\", \\\"{x:799,y:641,t:1527271977345};\\\", \\\"{x:779,y:639,t:1527271977363};\\\", \\\"{x:765,y:636,t:1527271977379};\\\", \\\"{x:749,y:632,t:1527271977396};\\\", \\\"{x:731,y:628,t:1527271977412};\\\", \\\"{x:710,y:624,t:1527271977430};\\\", \\\"{x:684,y:616,t:1527271977446};\\\", \\\"{x:657,y:608,t:1527271977462};\\\", \\\"{x:629,y:598,t:1527271977477};\\\", \\\"{x:606,y:590,t:1527271977494};\\\", \\\"{x:574,y:581,t:1527271977515};\\\", \\\"{x:553,y:576,t:1527271977531};\\\", \\\"{x:537,y:573,t:1527271977548};\\\", \\\"{x:531,y:571,t:1527271977565};\\\", \\\"{x:526,y:569,t:1527271977581};\\\", \\\"{x:523,y:569,t:1527271977598};\\\", \\\"{x:521,y:570,t:1527271977615};\\\", \\\"{x:517,y:572,t:1527271977631};\\\", \\\"{x:515,y:573,t:1527271977648};\\\", \\\"{x:512,y:576,t:1527271977665};\\\", \\\"{x:506,y:583,t:1527271977683};\\\", \\\"{x:500,y:589,t:1527271977698};\\\", \\\"{x:496,y:595,t:1527271977716};\\\", \\\"{x:491,y:602,t:1527271977732};\\\", \\\"{x:486,y:610,t:1527271977748};\\\", \\\"{x:482,y:617,t:1527271977766};\\\", \\\"{x:479,y:622,t:1527271977783};\\\", \\\"{x:477,y:627,t:1527271977798};\\\", \\\"{x:476,y:631,t:1527271977815};\\\", \\\"{x:476,y:634,t:1527271977832};\\\", \\\"{x:476,y:642,t:1527271977848};\\\", \\\"{x:476,y:646,t:1527271977865};\\\", \\\"{x:480,y:659,t:1527271977883};\\\", \\\"{x:483,y:667,t:1527271977898};\\\", \\\"{x:486,y:672,t:1527271977916};\\\", \\\"{x:488,y:674,t:1527271977933};\\\", \\\"{x:490,y:676,t:1527271977948};\\\", \\\"{x:495,y:679,t:1527271977966};\\\", \\\"{x:509,y:687,t:1527271977982};\\\", \\\"{x:537,y:699,t:1527271977999};\\\", \\\"{x:602,y:722,t:1527271978016};\\\", \\\"{x:729,y:754,t:1527271978032};\\\", \\\"{x:881,y:795,t:1527271978049};\\\", \\\"{x:1060,y:843,t:1527271978066};\\\", \\\"{x:1313,y:906,t:1527271978083};\\\", \\\"{x:1453,y:936,t:1527271978099};\\\", \\\"{x:1534,y:949,t:1527271978115};\\\", \\\"{x:1570,y:954,t:1527271978132};\\\", \\\"{x:1577,y:954,t:1527271978149};\\\", \\\"{x:1578,y:954,t:1527271978178};\\\", \\\"{x:1576,y:952,t:1527271978211};\\\", \\\"{x:1573,y:952,t:1527271978219};\\\", \\\"{x:1571,y:949,t:1527271978232};\\\", \\\"{x:1562,y:946,t:1527271978249};\\\", \\\"{x:1548,y:939,t:1527271978266};\\\", \\\"{x:1525,y:929,t:1527271978283};\\\", \\\"{x:1504,y:919,t:1527271978300};\\\", \\\"{x:1477,y:906,t:1527271978317};\\\", \\\"{x:1457,y:897,t:1527271978333};\\\", \\\"{x:1440,y:891,t:1527271978350};\\\", \\\"{x:1430,y:889,t:1527271978367};\\\", \\\"{x:1421,y:889,t:1527271978382};\\\", \\\"{x:1411,y:889,t:1527271978400};\\\", \\\"{x:1396,y:889,t:1527271978417};\\\", \\\"{x:1376,y:891,t:1527271978433};\\\", \\\"{x:1354,y:893,t:1527271978450};\\\", \\\"{x:1331,y:897,t:1527271978467};\\\", \\\"{x:1326,y:899,t:1527271978483};\\\", \\\"{x:1317,y:905,t:1527271978500};\\\", \\\"{x:1312,y:907,t:1527271978517};\\\", \\\"{x:1305,y:911,t:1527271978533};\\\", \\\"{x:1295,y:918,t:1527271978549};\\\", \\\"{x:1292,y:920,t:1527271978567};\\\", \\\"{x:1285,y:925,t:1527271978583};\\\", \\\"{x:1279,y:928,t:1527271978600};\\\", \\\"{x:1276,y:930,t:1527271978617};\\\", \\\"{x:1276,y:931,t:1527271979012};\\\", \\\"{x:1275,y:932,t:1527271979020};\\\", \\\"{x:1273,y:933,t:1527271979034};\\\", \\\"{x:1262,y:933,t:1527271979051};\\\", \\\"{x:1248,y:933,t:1527271979067};\\\", \\\"{x:1227,y:928,t:1527271979083};\\\", \\\"{x:1203,y:922,t:1527271979100};\\\", \\\"{x:1178,y:914,t:1527271979116};\\\", \\\"{x:1139,y:900,t:1527271979134};\\\", \\\"{x:1089,y:885,t:1527271979150};\\\", \\\"{x:1031,y:870,t:1527271979167};\\\", \\\"{x:972,y:853,t:1527271979184};\\\", \\\"{x:940,y:841,t:1527271979201};\\\", \\\"{x:921,y:836,t:1527271979216};\\\", \\\"{x:914,y:834,t:1527271979233};\\\", \\\"{x:904,y:830,t:1527271979250};\\\", \\\"{x:896,y:826,t:1527271979267};\\\", \\\"{x:875,y:819,t:1527271979284};\\\", \\\"{x:847,y:805,t:1527271979300};\\\", \\\"{x:806,y:788,t:1527271979317};\\\", \\\"{x:770,y:772,t:1527271979333};\\\", \\\"{x:720,y:750,t:1527271979350};\\\", \\\"{x:678,y:732,t:1527271979367};\\\", \\\"{x:636,y:713,t:1527271979384};\\\", \\\"{x:613,y:702,t:1527271979400};\\\", \\\"{x:593,y:696,t:1527271979417};\\\", \\\"{x:577,y:689,t:1527271979433};\\\", \\\"{x:558,y:684,t:1527271979450};\\\", \\\"{x:543,y:680,t:1527271979467};\\\", \\\"{x:530,y:677,t:1527271979483};\\\", \\\"{x:521,y:677,t:1527271979500};\\\", \\\"{x:513,y:677,t:1527271979517};\\\", \\\"{x:503,y:677,t:1527271979533};\\\", \\\"{x:496,y:679,t:1527271979551};\\\", \\\"{x:486,y:684,t:1527271979568};\\\", \\\"{x:480,y:687,t:1527271979583};\\\", \\\"{x:473,y:691,t:1527271979600};\\\", \\\"{x:470,y:694,t:1527271979617};\\\", \\\"{x:464,y:699,t:1527271979634};\\\", \\\"{x:460,y:704,t:1527271979652};\\\", \\\"{x:459,y:706,t:1527271979667};\\\", \\\"{x:459,y:707,t:1527271979714};\\\", \\\"{x:460,y:708,t:1527271980291};\\\", \\\"{x:461,y:708,t:1527271980301};\\\", \\\"{x:467,y:708,t:1527271980317};\\\", \\\"{x:471,y:708,t:1527271980335};\\\", \\\"{x:475,y:708,t:1527271980350};\\\", \\\"{x:479,y:708,t:1527271980367};\\\", \\\"{x:482,y:708,t:1527271980384};\\\", \\\"{x:483,y:708,t:1527271980402};\\\" ] }, { \\\"rt\\\": 19304, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 290644, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"2WQ0M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-04 PM-B -B -09 AM-08 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:484,y:709,t:1527271981250};\\\", \\\"{x:484,y:711,t:1527271981258};\\\", \\\"{x:485,y:710,t:1527271981363};\\\", \\\"{x:486,y:709,t:1527271981386};\\\", \\\"{x:486,y:708,t:1527271981491};\\\", \\\"{x:486,y:705,t:1527271981501};\\\", \\\"{x:496,y:636,t:1527271981602};\\\", \\\"{x:502,y:613,t:1527271981618};\\\", \\\"{x:508,y:596,t:1527271981634};\\\", \\\"{x:516,y:584,t:1527271981651};\\\", \\\"{x:525,y:574,t:1527271981669};\\\", \\\"{x:548,y:553,t:1527271981685};\\\", \\\"{x:606,y:516,t:1527271981702};\\\", \\\"{x:695,y:493,t:1527271981719};\\\", \\\"{x:802,y:481,t:1527271981735};\\\", \\\"{x:910,y:481,t:1527271981753};\\\", \\\"{x:1021,y:481,t:1527271981769};\\\", \\\"{x:1116,y:481,t:1527271981786};\\\", \\\"{x:1237,y:497,t:1527271981802};\\\", \\\"{x:1276,y:504,t:1527271981818};\\\", \\\"{x:1297,y:506,t:1527271981835};\\\", \\\"{x:1301,y:508,t:1527271981852};\\\", \\\"{x:1301,y:509,t:1527271981869};\\\", \\\"{x:1301,y:511,t:1527271981941};\\\", \\\"{x:1301,y:515,t:1527271981953};\\\", \\\"{x:1297,y:527,t:1527271981969};\\\", \\\"{x:1294,y:536,t:1527271981986};\\\", \\\"{x:1289,y:554,t:1527271982003};\\\", \\\"{x:1285,y:564,t:1527271982019};\\\", \\\"{x:1284,y:572,t:1527271982036};\\\", \\\"{x:1284,y:577,t:1527271982053};\\\", \\\"{x:1284,y:584,t:1527271982069};\\\", \\\"{x:1288,y:594,t:1527271982086};\\\", \\\"{x:1294,y:606,t:1527271982102};\\\", \\\"{x:1306,y:625,t:1527271982119};\\\", \\\"{x:1326,y:652,t:1527271982136};\\\", \\\"{x:1358,y:690,t:1527271982153};\\\", \\\"{x:1378,y:713,t:1527271982169};\\\", \\\"{x:1386,y:724,t:1527271982185};\\\", \\\"{x:1388,y:733,t:1527271982203};\\\", \\\"{x:1388,y:742,t:1527271982219};\\\", \\\"{x:1388,y:758,t:1527271982236};\\\", \\\"{x:1383,y:782,t:1527271982252};\\\", \\\"{x:1383,y:800,t:1527271982270};\\\", \\\"{x:1385,y:804,t:1527271982287};\\\", \\\"{x:1386,y:804,t:1527271982692};\\\", \\\"{x:1385,y:804,t:1527271982763};\\\", \\\"{x:1384,y:804,t:1527271982779};\\\", \\\"{x:1383,y:804,t:1527271982803};\\\", \\\"{x:1382,y:804,t:1527271982821};\\\", \\\"{x:1381,y:804,t:1527271982838};\\\", \\\"{x:1379,y:804,t:1527271982854};\\\", \\\"{x:1378,y:804,t:1527271982871};\\\", \\\"{x:1375,y:804,t:1527271983075};\\\", \\\"{x:1373,y:804,t:1527271983088};\\\", \\\"{x:1368,y:804,t:1527271983105};\\\", \\\"{x:1366,y:804,t:1527271983121};\\\", \\\"{x:1365,y:804,t:1527271983300};\\\", \\\"{x:1365,y:799,t:1527271983307};\\\", \\\"{x:1365,y:792,t:1527271983322};\\\", \\\"{x:1365,y:787,t:1527271983338};\\\", \\\"{x:1363,y:772,t:1527271983355};\\\", \\\"{x:1363,y:757,t:1527271983372};\\\", \\\"{x:1363,y:738,t:1527271983389};\\\", \\\"{x:1363,y:718,t:1527271983405};\\\", \\\"{x:1360,y:697,t:1527271983422};\\\", \\\"{x:1352,y:672,t:1527271983440};\\\", \\\"{x:1347,y:654,t:1527271983455};\\\", \\\"{x:1343,y:642,t:1527271983472};\\\", \\\"{x:1341,y:633,t:1527271983490};\\\", \\\"{x:1338,y:628,t:1527271983505};\\\", \\\"{x:1337,y:627,t:1527271983522};\\\", \\\"{x:1336,y:624,t:1527271983539};\\\", \\\"{x:1334,y:623,t:1527271983555};\\\", \\\"{x:1333,y:622,t:1527271983572};\\\", \\\"{x:1332,y:621,t:1527271983589};\\\", \\\"{x:1331,y:620,t:1527271983627};\\\", \\\"{x:1331,y:619,t:1527271983963};\\\", \\\"{x:1331,y:618,t:1527271984171};\\\", \\\"{x:1332,y:616,t:1527271984203};\\\", \\\"{x:1331,y:616,t:1527271984555};\\\", \\\"{x:1326,y:617,t:1527271984563};\\\", \\\"{x:1321,y:624,t:1527271984574};\\\", \\\"{x:1308,y:633,t:1527271984590};\\\", \\\"{x:1297,y:641,t:1527271984607};\\\", \\\"{x:1287,y:648,t:1527271984624};\\\", \\\"{x:1280,y:652,t:1527271984641};\\\", \\\"{x:1278,y:654,t:1527271984657};\\\", \\\"{x:1277,y:655,t:1527271984674};\\\", \\\"{x:1276,y:656,t:1527271984778};\\\", \\\"{x:1276,y:657,t:1527271984794};\\\", \\\"{x:1275,y:657,t:1527271984807};\\\", \\\"{x:1275,y:659,t:1527271984824};\\\", \\\"{x:1275,y:660,t:1527271984840};\\\", \\\"{x:1275,y:662,t:1527271984857};\\\", \\\"{x:1273,y:666,t:1527271984874};\\\", \\\"{x:1272,y:669,t:1527271984891};\\\", \\\"{x:1270,y:672,t:1527271984908};\\\", \\\"{x:1270,y:673,t:1527271984931};\\\", \\\"{x:1270,y:674,t:1527271984941};\\\", \\\"{x:1270,y:676,t:1527271984958};\\\", \\\"{x:1270,y:677,t:1527271984974};\\\", \\\"{x:1270,y:679,t:1527271984991};\\\", \\\"{x:1270,y:680,t:1527271985011};\\\", \\\"{x:1270,y:682,t:1527271985025};\\\", \\\"{x:1271,y:684,t:1527271985041};\\\", \\\"{x:1273,y:686,t:1527271985058};\\\", \\\"{x:1275,y:686,t:1527271985075};\\\", \\\"{x:1276,y:687,t:1527271985091};\\\", \\\"{x:1278,y:688,t:1527271985109};\\\", \\\"{x:1280,y:688,t:1527271985125};\\\", \\\"{x:1284,y:690,t:1527271985141};\\\", \\\"{x:1291,y:692,t:1527271985158};\\\", \\\"{x:1298,y:694,t:1527271985175};\\\", \\\"{x:1300,y:695,t:1527271985191};\\\", \\\"{x:1301,y:695,t:1527271985484};\\\", \\\"{x:1303,y:696,t:1527271985492};\\\", \\\"{x:1305,y:697,t:1527271985509};\\\", \\\"{x:1310,y:698,t:1527271985525};\\\", \\\"{x:1318,y:699,t:1527271985543};\\\", \\\"{x:1333,y:702,t:1527271985558};\\\", \\\"{x:1355,y:707,t:1527271985574};\\\", \\\"{x:1387,y:714,t:1527271985591};\\\", \\\"{x:1424,y:719,t:1527271985609};\\\", \\\"{x:1464,y:726,t:1527271985625};\\\", \\\"{x:1492,y:728,t:1527271985642};\\\", \\\"{x:1528,y:731,t:1527271985659};\\\", \\\"{x:1539,y:731,t:1527271985675};\\\", \\\"{x:1545,y:731,t:1527271985691};\\\", \\\"{x:1548,y:731,t:1527271985709};\\\", \\\"{x:1549,y:731,t:1527271985726};\\\", \\\"{x:1547,y:731,t:1527271985963};\\\", \\\"{x:1541,y:731,t:1527271985976};\\\", \\\"{x:1529,y:731,t:1527271985993};\\\", \\\"{x:1515,y:727,t:1527271986010};\\\", \\\"{x:1500,y:726,t:1527271986027};\\\", \\\"{x:1480,y:723,t:1527271986043};\\\", \\\"{x:1470,y:722,t:1527271986060};\\\", \\\"{x:1461,y:721,t:1527271986076};\\\", \\\"{x:1454,y:721,t:1527271986093};\\\", \\\"{x:1450,y:721,t:1527271986110};\\\", \\\"{x:1443,y:721,t:1527271986126};\\\", \\\"{x:1436,y:721,t:1527271986143};\\\", \\\"{x:1433,y:723,t:1527271986161};\\\", \\\"{x:1430,y:726,t:1527271986176};\\\", \\\"{x:1426,y:732,t:1527271986193};\\\", \\\"{x:1424,y:745,t:1527271986210};\\\", \\\"{x:1424,y:771,t:1527271986227};\\\", \\\"{x:1422,y:792,t:1527271986242};\\\", \\\"{x:1423,y:820,t:1527271986260};\\\", \\\"{x:1425,y:848,t:1527271986277};\\\", \\\"{x:1427,y:872,t:1527271986293};\\\", \\\"{x:1427,y:890,t:1527271986310};\\\", \\\"{x:1428,y:903,t:1527271986327};\\\", \\\"{x:1429,y:913,t:1527271986343};\\\", \\\"{x:1432,y:919,t:1527271986360};\\\", \\\"{x:1433,y:921,t:1527271986379};\\\", \\\"{x:1433,y:922,t:1527271986531};\\\", \\\"{x:1435,y:923,t:1527271986544};\\\", \\\"{x:1446,y:928,t:1527271986560};\\\", \\\"{x:1466,y:934,t:1527271986578};\\\", \\\"{x:1498,y:941,t:1527271986595};\\\", \\\"{x:1537,y:952,t:1527271986610};\\\", \\\"{x:1592,y:966,t:1527271986627};\\\", \\\"{x:1621,y:973,t:1527271986644};\\\", \\\"{x:1637,y:974,t:1527271986662};\\\", \\\"{x:1643,y:976,t:1527271986677};\\\", \\\"{x:1645,y:976,t:1527271986694};\\\", \\\"{x:1646,y:976,t:1527271986711};\\\", \\\"{x:1648,y:976,t:1527271986727};\\\", \\\"{x:1649,y:976,t:1527271986745};\\\", \\\"{x:1650,y:976,t:1527271986761};\\\", \\\"{x:1651,y:976,t:1527271986777};\\\", \\\"{x:1652,y:976,t:1527271986794};\\\", \\\"{x:1655,y:976,t:1527271986811};\\\", \\\"{x:1656,y:976,t:1527271986828};\\\", \\\"{x:1657,y:976,t:1527271986844};\\\", \\\"{x:1654,y:976,t:1527271986923};\\\", \\\"{x:1651,y:976,t:1527271986931};\\\", \\\"{x:1647,y:975,t:1527271986944};\\\", \\\"{x:1641,y:973,t:1527271986961};\\\", \\\"{x:1636,y:973,t:1527271986978};\\\", \\\"{x:1631,y:972,t:1527271986995};\\\", \\\"{x:1627,y:971,t:1527271987010};\\\", \\\"{x:1625,y:971,t:1527271987028};\\\", \\\"{x:1624,y:971,t:1527271987045};\\\", \\\"{x:1623,y:970,t:1527271987091};\\\", \\\"{x:1622,y:969,t:1527271987141};\\\", \\\"{x:1621,y:969,t:1527271987147};\\\", \\\"{x:1621,y:968,t:1527271987164};\\\", \\\"{x:1620,y:967,t:1527271987178};\\\", \\\"{x:1618,y:965,t:1527271987195};\\\", \\\"{x:1617,y:964,t:1527271987211};\\\", \\\"{x:1614,y:962,t:1527271987228};\\\", \\\"{x:1614,y:961,t:1527271987246};\\\", \\\"{x:1611,y:959,t:1527271987262};\\\", \\\"{x:1608,y:958,t:1527271987278};\\\", \\\"{x:1606,y:956,t:1527271987295};\\\", \\\"{x:1604,y:955,t:1527271987312};\\\", \\\"{x:1602,y:953,t:1527271987328};\\\", \\\"{x:1598,y:947,t:1527271987345};\\\", \\\"{x:1595,y:944,t:1527271987362};\\\", \\\"{x:1592,y:939,t:1527271987378};\\\", \\\"{x:1589,y:935,t:1527271987395};\\\", \\\"{x:1588,y:931,t:1527271987412};\\\", \\\"{x:1587,y:929,t:1527271987429};\\\", \\\"{x:1585,y:927,t:1527271987445};\\\", \\\"{x:1585,y:925,t:1527271987462};\\\", \\\"{x:1585,y:924,t:1527271987479};\\\", \\\"{x:1584,y:923,t:1527271987499};\\\", \\\"{x:1584,y:922,t:1527271987707};\\\", \\\"{x:1583,y:921,t:1527271987715};\\\", \\\"{x:1582,y:919,t:1527271987731};\\\", \\\"{x:1580,y:915,t:1527271987746};\\\", \\\"{x:1576,y:909,t:1527271987762};\\\", \\\"{x:1564,y:888,t:1527271987778};\\\", \\\"{x:1555,y:867,t:1527271987796};\\\", \\\"{x:1545,y:845,t:1527271987814};\\\", \\\"{x:1535,y:819,t:1527271987829};\\\", \\\"{x:1522,y:789,t:1527271987846};\\\", \\\"{x:1509,y:744,t:1527271987863};\\\", \\\"{x:1494,y:708,t:1527271987879};\\\", \\\"{x:1486,y:688,t:1527271987896};\\\", \\\"{x:1480,y:674,t:1527271987913};\\\", \\\"{x:1473,y:660,t:1527271987930};\\\", \\\"{x:1472,y:654,t:1527271987946};\\\", \\\"{x:1470,y:649,t:1527271987963};\\\", \\\"{x:1470,y:646,t:1527271987979};\\\", \\\"{x:1469,y:642,t:1527271987997};\\\", \\\"{x:1468,y:638,t:1527271988013};\\\", \\\"{x:1466,y:634,t:1527271988030};\\\", \\\"{x:1465,y:633,t:1527271988046};\\\", \\\"{x:1465,y:630,t:1527271988063};\\\", \\\"{x:1462,y:627,t:1527271988080};\\\", \\\"{x:1460,y:625,t:1527271988096};\\\", \\\"{x:1459,y:624,t:1527271988114};\\\", \\\"{x:1455,y:621,t:1527271988130};\\\", \\\"{x:1452,y:619,t:1527271988146};\\\", \\\"{x:1449,y:617,t:1527271988163};\\\", \\\"{x:1448,y:615,t:1527271988180};\\\", \\\"{x:1445,y:612,t:1527271988197};\\\", \\\"{x:1443,y:610,t:1527271988214};\\\", \\\"{x:1441,y:606,t:1527271988230};\\\", \\\"{x:1439,y:604,t:1527271988247};\\\", \\\"{x:1436,y:601,t:1527271988263};\\\", \\\"{x:1434,y:599,t:1527271988280};\\\", \\\"{x:1432,y:596,t:1527271988297};\\\", \\\"{x:1430,y:593,t:1527271988314};\\\", \\\"{x:1428,y:591,t:1527271988330};\\\", \\\"{x:1426,y:587,t:1527271988347};\\\", \\\"{x:1425,y:586,t:1527271988363};\\\", \\\"{x:1425,y:585,t:1527271988387};\\\", \\\"{x:1424,y:584,t:1527271988403};\\\", \\\"{x:1424,y:583,t:1527271988460};\\\", \\\"{x:1424,y:582,t:1527271988467};\\\", \\\"{x:1423,y:582,t:1527271989963};\\\", \\\"{x:1420,y:582,t:1527271989970};\\\", \\\"{x:1414,y:582,t:1527271989983};\\\", \\\"{x:1378,y:584,t:1527271989999};\\\", \\\"{x:1274,y:590,t:1527271990017};\\\", \\\"{x:1119,y:590,t:1527271990034};\\\", \\\"{x:860,y:573,t:1527271990052};\\\", \\\"{x:691,y:544,t:1527271990067};\\\", \\\"{x:539,y:522,t:1527271990083};\\\", \\\"{x:428,y:504,t:1527271990103};\\\", \\\"{x:363,y:494,t:1527271990120};\\\", \\\"{x:332,y:489,t:1527271990142};\\\", \\\"{x:331,y:488,t:1527271990159};\\\", \\\"{x:330,y:488,t:1527271990186};\\\", \\\"{x:329,y:488,t:1527271990194};\\\", \\\"{x:328,y:489,t:1527271990210};\\\", \\\"{x:327,y:489,t:1527271990225};\\\", \\\"{x:322,y:492,t:1527271990241};\\\", \\\"{x:320,y:494,t:1527271990258};\\\", \\\"{x:318,y:495,t:1527271990275};\\\", \\\"{x:317,y:497,t:1527271990292};\\\", \\\"{x:316,y:498,t:1527271990309};\\\", \\\"{x:315,y:502,t:1527271990326};\\\", \\\"{x:315,y:504,t:1527271990342};\\\", \\\"{x:315,y:506,t:1527271990360};\\\", \\\"{x:318,y:509,t:1527271990376};\\\", \\\"{x:323,y:513,t:1527271990392};\\\", \\\"{x:329,y:516,t:1527271990409};\\\", \\\"{x:335,y:521,t:1527271990426};\\\", \\\"{x:338,y:522,t:1527271990442};\\\", \\\"{x:341,y:524,t:1527271990458};\\\", \\\"{x:345,y:525,t:1527271990475};\\\", \\\"{x:354,y:529,t:1527271990493};\\\", \\\"{x:372,y:530,t:1527271990508};\\\", \\\"{x:409,y:537,t:1527271990526};\\\", \\\"{x:454,y:542,t:1527271990542};\\\", \\\"{x:502,y:550,t:1527271990560};\\\", \\\"{x:552,y:558,t:1527271990576};\\\", \\\"{x:583,y:562,t:1527271990592};\\\", \\\"{x:613,y:564,t:1527271990610};\\\", \\\"{x:628,y:567,t:1527271990626};\\\", \\\"{x:637,y:568,t:1527271990643};\\\", \\\"{x:636,y:568,t:1527271990803};\\\", \\\"{x:634,y:568,t:1527271990811};\\\", \\\"{x:632,y:568,t:1527271990826};\\\", \\\"{x:627,y:568,t:1527271990843};\\\", \\\"{x:626,y:568,t:1527271990860};\\\", \\\"{x:624,y:568,t:1527271990876};\\\", \\\"{x:626,y:568,t:1527271991219};\\\", \\\"{x:636,y:568,t:1527271991226};\\\", \\\"{x:691,y:568,t:1527271991243};\\\", \\\"{x:792,y:576,t:1527271991261};\\\", \\\"{x:939,y:602,t:1527271991276};\\\", \\\"{x:1121,y:648,t:1527271991293};\\\", \\\"{x:1322,y:699,t:1527271991310};\\\", \\\"{x:1500,y:735,t:1527271991327};\\\", \\\"{x:1639,y:756,t:1527271991343};\\\", \\\"{x:1723,y:760,t:1527271991360};\\\", \\\"{x:1741,y:760,t:1527271991376};\\\", \\\"{x:1739,y:760,t:1527271991442};\\\", \\\"{x:1737,y:760,t:1527271991460};\\\", \\\"{x:1735,y:760,t:1527271991477};\\\", \\\"{x:1729,y:763,t:1527271991493};\\\", \\\"{x:1718,y:779,t:1527271991510};\\\", \\\"{x:1703,y:798,t:1527271991527};\\\", \\\"{x:1692,y:813,t:1527271991543};\\\", \\\"{x:1680,y:830,t:1527271991561};\\\", \\\"{x:1671,y:841,t:1527271991577};\\\", \\\"{x:1660,y:852,t:1527271991593};\\\", \\\"{x:1650,y:866,t:1527271991609};\\\", \\\"{x:1639,y:884,t:1527271991626};\\\", \\\"{x:1631,y:897,t:1527271991644};\\\", \\\"{x:1626,y:904,t:1527271991660};\\\", \\\"{x:1622,y:909,t:1527271991677};\\\", \\\"{x:1619,y:912,t:1527271991694};\\\", \\\"{x:1618,y:914,t:1527271991710};\\\", \\\"{x:1615,y:915,t:1527271991727};\\\", \\\"{x:1614,y:915,t:1527271991744};\\\", \\\"{x:1614,y:917,t:1527271991760};\\\", \\\"{x:1612,y:919,t:1527271991776};\\\", \\\"{x:1612,y:922,t:1527271991794};\\\", \\\"{x:1612,y:927,t:1527271991810};\\\", \\\"{x:1611,y:935,t:1527271991827};\\\", \\\"{x:1611,y:940,t:1527271991843};\\\", \\\"{x:1611,y:944,t:1527271991859};\\\", \\\"{x:1610,y:948,t:1527271991877};\\\", \\\"{x:1610,y:951,t:1527271991894};\\\", \\\"{x:1610,y:952,t:1527271991910};\\\", \\\"{x:1610,y:953,t:1527271991927};\\\", \\\"{x:1610,y:954,t:1527271992131};\\\", \\\"{x:1610,y:955,t:1527271992323};\\\", \\\"{x:1610,y:956,t:1527271992419};\\\", \\\"{x:1611,y:956,t:1527271992436};\\\", \\\"{x:1611,y:957,t:1527271992451};\\\", \\\"{x:1612,y:958,t:1527271992475};\\\", \\\"{x:1612,y:959,t:1527271992507};\\\", \\\"{x:1612,y:960,t:1527271992588};\\\", \\\"{x:1613,y:961,t:1527271992603};\\\", \\\"{x:1613,y:963,t:1527271992635};\\\", \\\"{x:1613,y:964,t:1527271992651};\\\", \\\"{x:1614,y:964,t:1527271992683};\\\", \\\"{x:1615,y:965,t:1527271992755};\\\", \\\"{x:1615,y:966,t:1527271993379};\\\", \\\"{x:1615,y:965,t:1527271995651};\\\", \\\"{x:1615,y:964,t:1527271995663};\\\", \\\"{x:1614,y:962,t:1527271995680};\\\", \\\"{x:1614,y:961,t:1527271995699};\\\", \\\"{x:1614,y:960,t:1527271995714};\\\", \\\"{x:1614,y:958,t:1527271996251};\\\", \\\"{x:1614,y:950,t:1527271996263};\\\", \\\"{x:1614,y:929,t:1527271996281};\\\", \\\"{x:1616,y:910,t:1527271996298};\\\", \\\"{x:1621,y:894,t:1527271996313};\\\", \\\"{x:1635,y:858,t:1527271996330};\\\", \\\"{x:1653,y:830,t:1527271996348};\\\", \\\"{x:1663,y:816,t:1527271996364};\\\", \\\"{x:1672,y:804,t:1527271996381};\\\", \\\"{x:1683,y:790,t:1527271996398};\\\", \\\"{x:1692,y:780,t:1527271996414};\\\", \\\"{x:1694,y:777,t:1527271996431};\\\", \\\"{x:1695,y:776,t:1527271996447};\\\", \\\"{x:1696,y:775,t:1527271996465};\\\", \\\"{x:1696,y:774,t:1527271996651};\\\", \\\"{x:1695,y:775,t:1527271996665};\\\", \\\"{x:1687,y:793,t:1527271996680};\\\", \\\"{x:1678,y:811,t:1527271996698};\\\", \\\"{x:1656,y:845,t:1527271996716};\\\", \\\"{x:1643,y:865,t:1527271996731};\\\", \\\"{x:1634,y:880,t:1527271996748};\\\", \\\"{x:1628,y:894,t:1527271996765};\\\", \\\"{x:1623,y:904,t:1527271996781};\\\", \\\"{x:1621,y:910,t:1527271996798};\\\", \\\"{x:1619,y:914,t:1527271996815};\\\", \\\"{x:1617,y:916,t:1527271996831};\\\", \\\"{x:1616,y:917,t:1527271996848};\\\", \\\"{x:1614,y:919,t:1527271996864};\\\", \\\"{x:1612,y:920,t:1527271996882};\\\", \\\"{x:1610,y:920,t:1527271996899};\\\", \\\"{x:1608,y:920,t:1527271996915};\\\", \\\"{x:1606,y:921,t:1527271996930};\\\", \\\"{x:1603,y:921,t:1527271996947};\\\", \\\"{x:1597,y:921,t:1527271996964};\\\", \\\"{x:1590,y:921,t:1527271996981};\\\", \\\"{x:1580,y:917,t:1527271996997};\\\", \\\"{x:1566,y:906,t:1527271997015};\\\", \\\"{x:1549,y:891,t:1527271997031};\\\", \\\"{x:1532,y:870,t:1527271997047};\\\", \\\"{x:1517,y:850,t:1527271997065};\\\", \\\"{x:1504,y:831,t:1527271997082};\\\", \\\"{x:1495,y:817,t:1527271997098};\\\", \\\"{x:1491,y:800,t:1527271997115};\\\", \\\"{x:1489,y:785,t:1527271997130};\\\", \\\"{x:1486,y:769,t:1527271997147};\\\", \\\"{x:1481,y:748,t:1527271997164};\\\", \\\"{x:1474,y:727,t:1527271997181};\\\", \\\"{x:1464,y:708,t:1527271997197};\\\", \\\"{x:1455,y:690,t:1527271997214};\\\", \\\"{x:1446,y:668,t:1527271997230};\\\", \\\"{x:1440,y:651,t:1527271997247};\\\", \\\"{x:1434,y:637,t:1527271997264};\\\", \\\"{x:1429,y:627,t:1527271997281};\\\", \\\"{x:1425,y:619,t:1527271997297};\\\", \\\"{x:1420,y:611,t:1527271997314};\\\", \\\"{x:1419,y:609,t:1527271997331};\\\", \\\"{x:1418,y:610,t:1527271997436};\\\", \\\"{x:1417,y:612,t:1527271997448};\\\", \\\"{x:1414,y:620,t:1527271997465};\\\", \\\"{x:1408,y:634,t:1527271997482};\\\", \\\"{x:1397,y:668,t:1527271997499};\\\", \\\"{x:1387,y:691,t:1527271997515};\\\", \\\"{x:1378,y:712,t:1527271997531};\\\", \\\"{x:1366,y:733,t:1527271997549};\\\", \\\"{x:1354,y:755,t:1527271997565};\\\", \\\"{x:1342,y:776,t:1527271997582};\\\", \\\"{x:1329,y:797,t:1527271997599};\\\", \\\"{x:1320,y:814,t:1527271997614};\\\", \\\"{x:1312,y:831,t:1527271997631};\\\", \\\"{x:1300,y:852,t:1527271997649};\\\", \\\"{x:1291,y:868,t:1527271997665};\\\", \\\"{x:1281,y:882,t:1527271997681};\\\", \\\"{x:1269,y:898,t:1527271997699};\\\", \\\"{x:1264,y:905,t:1527271997715};\\\", \\\"{x:1258,y:911,t:1527271997732};\\\", \\\"{x:1255,y:918,t:1527271997749};\\\", \\\"{x:1252,y:925,t:1527271997764};\\\", \\\"{x:1249,y:932,t:1527271997782};\\\", \\\"{x:1248,y:936,t:1527271997799};\\\", \\\"{x:1247,y:938,t:1527271997815};\\\", \\\"{x:1246,y:940,t:1527271997832};\\\", \\\"{x:1245,y:941,t:1527271997849};\\\", \\\"{x:1244,y:943,t:1527271997865};\\\", \\\"{x:1243,y:945,t:1527271997891};\\\", \\\"{x:1243,y:946,t:1527271997979};\\\", \\\"{x:1242,y:947,t:1527271998115};\\\", \\\"{x:1242,y:948,t:1527271998132};\\\", \\\"{x:1241,y:949,t:1527271998149};\\\", \\\"{x:1237,y:951,t:1527271998165};\\\", \\\"{x:1229,y:956,t:1527271998181};\\\", \\\"{x:1209,y:965,t:1527271998199};\\\", \\\"{x:1181,y:971,t:1527271998215};\\\", \\\"{x:1146,y:977,t:1527271998232};\\\", \\\"{x:1093,y:977,t:1527271998249};\\\", \\\"{x:1034,y:979,t:1527271998266};\\\", \\\"{x:970,y:971,t:1527271998282};\\\", \\\"{x:876,y:943,t:1527271998299};\\\", \\\"{x:845,y:917,t:1527271998315};\\\", \\\"{x:842,y:914,t:1527271998333};\\\", \\\"{x:839,y:913,t:1527271998651};\\\", \\\"{x:815,y:910,t:1527271998665};\\\", \\\"{x:715,y:882,t:1527271998682};\\\", \\\"{x:657,y:864,t:1527271998698};\\\", \\\"{x:599,y:842,t:1527271998715};\\\", \\\"{x:563,y:826,t:1527271998732};\\\", \\\"{x:544,y:815,t:1527271998748};\\\", \\\"{x:529,y:804,t:1527271998766};\\\", \\\"{x:512,y:794,t:1527271998782};\\\", \\\"{x:496,y:784,t:1527271998800};\\\", \\\"{x:477,y:776,t:1527271998815};\\\", \\\"{x:457,y:763,t:1527271998832};\\\", \\\"{x:441,y:750,t:1527271998849};\\\", \\\"{x:430,y:741,t:1527271998865};\\\", \\\"{x:424,y:734,t:1527271998883};\\\", \\\"{x:424,y:732,t:1527271998898};\\\", \\\"{x:425,y:728,t:1527271998916};\\\", \\\"{x:428,y:724,t:1527271998932};\\\", \\\"{x:431,y:722,t:1527271998949};\\\", \\\"{x:434,y:721,t:1527271998965};\\\", \\\"{x:436,y:720,t:1527271998981};\\\", \\\"{x:438,y:720,t:1527271998999};\\\", \\\"{x:439,y:719,t:1527271999015};\\\", \\\"{x:440,y:718,t:1527271999066};\\\", \\\"{x:443,y:718,t:1527271999082};\\\", \\\"{x:447,y:718,t:1527271999100};\\\", \\\"{x:453,y:718,t:1527271999114};\\\", \\\"{x:458,y:718,t:1527271999132};\\\", \\\"{x:465,y:718,t:1527271999149};\\\", \\\"{x:470,y:718,t:1527271999165};\\\", \\\"{x:472,y:718,t:1527271999182};\\\", \\\"{x:473,y:718,t:1527271999198};\\\" ] }, { \\\"rt\\\": 21470, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 313412, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"2WQ0M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -O -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:475,y:718,t:1527272002611};\\\", \\\"{x:479,y:717,t:1527272002619};\\\", \\\"{x:486,y:716,t:1527272002637};\\\", \\\"{x:493,y:713,t:1527272002652};\\\", \\\"{x:502,y:710,t:1527272002669};\\\", \\\"{x:510,y:705,t:1527272002686};\\\", \\\"{x:516,y:702,t:1527272002702};\\\", \\\"{x:522,y:698,t:1527272002718};\\\", \\\"{x:529,y:694,t:1527272002736};\\\", \\\"{x:548,y:684,t:1527272002752};\\\", \\\"{x:576,y:676,t:1527272002770};\\\", \\\"{x:658,y:672,t:1527272002786};\\\", \\\"{x:742,y:672,t:1527272002802};\\\", \\\"{x:861,y:672,t:1527272002819};\\\", \\\"{x:1016,y:672,t:1527272002837};\\\", \\\"{x:1179,y:672,t:1527272002852};\\\", \\\"{x:1327,y:686,t:1527272002869};\\\", \\\"{x:1438,y:686,t:1527272002886};\\\", \\\"{x:1519,y:686,t:1527272002902};\\\", \\\"{x:1555,y:686,t:1527272002919};\\\", \\\"{x:1577,y:686,t:1527272002936};\\\", \\\"{x:1590,y:686,t:1527272002952};\\\", \\\"{x:1593,y:687,t:1527272002969};\\\", \\\"{x:1592,y:687,t:1527272003011};\\\", \\\"{x:1591,y:686,t:1527272003020};\\\", \\\"{x:1588,y:688,t:1527272011400};\\\", \\\"{x:1581,y:691,t:1527272011408};\\\", \\\"{x:1576,y:696,t:1527272011424};\\\", \\\"{x:1570,y:698,t:1527272011441};\\\", \\\"{x:1567,y:700,t:1527272011458};\\\", \\\"{x:1566,y:700,t:1527272011474};\\\", \\\"{x:1565,y:700,t:1527272011736};\\\", \\\"{x:1565,y:699,t:1527272011752};\\\", \\\"{x:1563,y:698,t:1527272011760};\\\", \\\"{x:1561,y:695,t:1527272011774};\\\", \\\"{x:1559,y:691,t:1527272011792};\\\", \\\"{x:1557,y:688,t:1527272011808};\\\", \\\"{x:1554,y:683,t:1527272011825};\\\", \\\"{x:1552,y:679,t:1527272011842};\\\", \\\"{x:1552,y:678,t:1527272011858};\\\", \\\"{x:1550,y:674,t:1527272011875};\\\", \\\"{x:1550,y:671,t:1527272011892};\\\", \\\"{x:1545,y:666,t:1527272011908};\\\", \\\"{x:1539,y:659,t:1527272011925};\\\", \\\"{x:1530,y:652,t:1527272011941};\\\", \\\"{x:1517,y:641,t:1527272011958};\\\", \\\"{x:1497,y:630,t:1527272011975};\\\", \\\"{x:1466,y:611,t:1527272011993};\\\", \\\"{x:1439,y:599,t:1527272012008};\\\", \\\"{x:1411,y:583,t:1527272012024};\\\", \\\"{x:1381,y:566,t:1527272012042};\\\", \\\"{x:1352,y:551,t:1527272012058};\\\", \\\"{x:1327,y:540,t:1527272012074};\\\", \\\"{x:1304,y:526,t:1527272012092};\\\", \\\"{x:1289,y:520,t:1527272012108};\\\", \\\"{x:1279,y:516,t:1527272012124};\\\", \\\"{x:1272,y:512,t:1527272012141};\\\", \\\"{x:1267,y:509,t:1527272012157};\\\", \\\"{x:1265,y:507,t:1527272012174};\\\", \\\"{x:1262,y:504,t:1527272012191};\\\", \\\"{x:1261,y:503,t:1527272012207};\\\", \\\"{x:1261,y:502,t:1527272012232};\\\", \\\"{x:1261,y:501,t:1527272012247};\\\", \\\"{x:1261,y:500,t:1527272012258};\\\", \\\"{x:1263,y:498,t:1527272012274};\\\", \\\"{x:1266,y:495,t:1527272012291};\\\", \\\"{x:1269,y:493,t:1527272012308};\\\", \\\"{x:1274,y:492,t:1527272012324};\\\", \\\"{x:1278,y:491,t:1527272012341};\\\", \\\"{x:1281,y:490,t:1527272012359};\\\", \\\"{x:1282,y:490,t:1527272012375};\\\", \\\"{x:1285,y:490,t:1527272012392};\\\", \\\"{x:1289,y:491,t:1527272012408};\\\", \\\"{x:1290,y:492,t:1527272012424};\\\", \\\"{x:1292,y:494,t:1527272012442};\\\", \\\"{x:1295,y:495,t:1527272012459};\\\", \\\"{x:1295,y:496,t:1527272012475};\\\", \\\"{x:1296,y:496,t:1527272012492};\\\", \\\"{x:1297,y:497,t:1527272012508};\\\", \\\"{x:1298,y:497,t:1527272012544};\\\", \\\"{x:1300,y:497,t:1527272012560};\\\", \\\"{x:1301,y:497,t:1527272012575};\\\", \\\"{x:1303,y:497,t:1527272012592};\\\", \\\"{x:1307,y:497,t:1527272012608};\\\", \\\"{x:1309,y:497,t:1527272012627};\\\", \\\"{x:1311,y:497,t:1527272012641};\\\", \\\"{x:1314,y:497,t:1527272012658};\\\", \\\"{x:1315,y:497,t:1527272012687};\\\", \\\"{x:1316,y:497,t:1527272012704};\\\", \\\"{x:1317,y:497,t:1527272012735};\\\", \\\"{x:1318,y:496,t:1527272012775};\\\", \\\"{x:1318,y:497,t:1527272013153};\\\", \\\"{x:1318,y:498,t:1527272013176};\\\", \\\"{x:1318,y:500,t:1527272013192};\\\", \\\"{x:1318,y:501,t:1527272013208};\\\", \\\"{x:1317,y:503,t:1527272013227};\\\", \\\"{x:1317,y:504,t:1527272013242};\\\", \\\"{x:1316,y:507,t:1527272013259};\\\", \\\"{x:1316,y:509,t:1527272013276};\\\", \\\"{x:1315,y:514,t:1527272013292};\\\", \\\"{x:1313,y:517,t:1527272013308};\\\", \\\"{x:1313,y:523,t:1527272013325};\\\", \\\"{x:1313,y:530,t:1527272013343};\\\", \\\"{x:1313,y:539,t:1527272013359};\\\", \\\"{x:1313,y:546,t:1527272013375};\\\", \\\"{x:1313,y:549,t:1527272013392};\\\", \\\"{x:1313,y:552,t:1527272013408};\\\", \\\"{x:1313,y:557,t:1527272013425};\\\", \\\"{x:1313,y:562,t:1527272013443};\\\", \\\"{x:1313,y:567,t:1527272013459};\\\", \\\"{x:1313,y:572,t:1527272013475};\\\", \\\"{x:1313,y:577,t:1527272013492};\\\", \\\"{x:1313,y:582,t:1527272013509};\\\", \\\"{x:1313,y:588,t:1527272013526};\\\", \\\"{x:1313,y:594,t:1527272013543};\\\", \\\"{x:1313,y:599,t:1527272013559};\\\", \\\"{x:1313,y:606,t:1527272013576};\\\", \\\"{x:1313,y:609,t:1527272013592};\\\", \\\"{x:1313,y:612,t:1527272013609};\\\", \\\"{x:1313,y:615,t:1527272013626};\\\", \\\"{x:1314,y:618,t:1527272013642};\\\", \\\"{x:1314,y:621,t:1527272013659};\\\", \\\"{x:1314,y:624,t:1527272013676};\\\", \\\"{x:1314,y:625,t:1527272013697};\\\", \\\"{x:1314,y:626,t:1527272013760};\\\", \\\"{x:1313,y:626,t:1527272016552};\\\", \\\"{x:1307,y:626,t:1527272016563};\\\", \\\"{x:1288,y:626,t:1527272016577};\\\", \\\"{x:1243,y:619,t:1527272016595};\\\", \\\"{x:1167,y:607,t:1527272016612};\\\", \\\"{x:1071,y:595,t:1527272016629};\\\", \\\"{x:968,y:581,t:1527272016645};\\\", \\\"{x:865,y:563,t:1527272016664};\\\", \\\"{x:765,y:552,t:1527272016679};\\\", \\\"{x:671,y:552,t:1527272016694};\\\", \\\"{x:568,y:552,t:1527272016711};\\\", \\\"{x:538,y:552,t:1527272016728};\\\", \\\"{x:520,y:552,t:1527272016745};\\\", \\\"{x:511,y:552,t:1527272016761};\\\", \\\"{x:510,y:552,t:1527272016778};\\\", \\\"{x:509,y:552,t:1527272016831};\\\", \\\"{x:508,y:552,t:1527272016845};\\\", \\\"{x:507,y:552,t:1527272016861};\\\", \\\"{x:504,y:552,t:1527272016879};\\\", \\\"{x:501,y:553,t:1527272016895};\\\", \\\"{x:500,y:555,t:1527272016911};\\\", \\\"{x:499,y:556,t:1527272016928};\\\", \\\"{x:497,y:560,t:1527272016947};\\\", \\\"{x:495,y:562,t:1527272016962};\\\", \\\"{x:495,y:566,t:1527272016978};\\\", \\\"{x:495,y:567,t:1527272016995};\\\", \\\"{x:495,y:569,t:1527272017012};\\\", \\\"{x:496,y:569,t:1527272017047};\\\", \\\"{x:502,y:569,t:1527272017063};\\\", \\\"{x:532,y:563,t:1527272017079};\\\", \\\"{x:567,y:563,t:1527272017095};\\\", \\\"{x:614,y:563,t:1527272017113};\\\", \\\"{x:662,y:563,t:1527272017128};\\\", \\\"{x:698,y:563,t:1527272017145};\\\", \\\"{x:724,y:563,t:1527272017163};\\\", \\\"{x:738,y:563,t:1527272017179};\\\", \\\"{x:742,y:563,t:1527272017195};\\\", \\\"{x:745,y:563,t:1527272017288};\\\", \\\"{x:749,y:563,t:1527272017295};\\\", \\\"{x:764,y:563,t:1527272017312};\\\", \\\"{x:782,y:563,t:1527272017329};\\\", \\\"{x:797,y:563,t:1527272017345};\\\", \\\"{x:804,y:562,t:1527272017362};\\\", \\\"{x:805,y:561,t:1527272017379};\\\", \\\"{x:806,y:560,t:1527272017395};\\\", \\\"{x:807,y:558,t:1527272017413};\\\", \\\"{x:810,y:557,t:1527272017430};\\\", \\\"{x:814,y:555,t:1527272017445};\\\", \\\"{x:818,y:553,t:1527272017462};\\\", \\\"{x:819,y:552,t:1527272017479};\\\", \\\"{x:821,y:552,t:1527272017495};\\\", \\\"{x:823,y:551,t:1527272017519};\\\", \\\"{x:823,y:550,t:1527272017536};\\\", \\\"{x:824,y:550,t:1527272017545};\\\", \\\"{x:824,y:549,t:1527272017791};\\\", \\\"{x:823,y:547,t:1527272017807};\\\", \\\"{x:822,y:544,t:1527272017815};\\\", \\\"{x:822,y:543,t:1527272017831};\\\", \\\"{x:824,y:543,t:1527272018201};\\\", \\\"{x:825,y:543,t:1527272018213};\\\", \\\"{x:831,y:543,t:1527272018229};\\\", \\\"{x:835,y:543,t:1527272018246};\\\", \\\"{x:853,y:541,t:1527272018263};\\\", \\\"{x:867,y:538,t:1527272018279};\\\", \\\"{x:879,y:535,t:1527272018296};\\\", \\\"{x:883,y:533,t:1527272018313};\\\", \\\"{x:884,y:532,t:1527272018329};\\\", \\\"{x:886,y:530,t:1527272018347};\\\", \\\"{x:887,y:530,t:1527272018363};\\\", \\\"{x:889,y:527,t:1527272018379};\\\", \\\"{x:891,y:525,t:1527272018396};\\\", \\\"{x:895,y:521,t:1527272018414};\\\", \\\"{x:898,y:517,t:1527272018430};\\\", \\\"{x:900,y:514,t:1527272018446};\\\", \\\"{x:902,y:509,t:1527272018464};\\\", \\\"{x:903,y:508,t:1527272018479};\\\", \\\"{x:903,y:507,t:1527272018497};\\\", \\\"{x:903,y:506,t:1527272018514};\\\", \\\"{x:902,y:503,t:1527272018530};\\\", \\\"{x:898,y:503,t:1527272018547};\\\", \\\"{x:894,y:503,t:1527272018564};\\\", \\\"{x:893,y:503,t:1527272018579};\\\", \\\"{x:890,y:503,t:1527272018597};\\\", \\\"{x:886,y:503,t:1527272018613};\\\", \\\"{x:880,y:503,t:1527272018631};\\\", \\\"{x:875,y:505,t:1527272018647};\\\", \\\"{x:864,y:513,t:1527272018663};\\\", \\\"{x:860,y:516,t:1527272018680};\\\", \\\"{x:855,y:520,t:1527272018696};\\\", \\\"{x:850,y:524,t:1527272018713};\\\", \\\"{x:846,y:527,t:1527272018730};\\\", \\\"{x:845,y:528,t:1527272018746};\\\", \\\"{x:843,y:530,t:1527272018763};\\\", \\\"{x:842,y:531,t:1527272018780};\\\", \\\"{x:841,y:532,t:1527272018796};\\\", \\\"{x:840,y:532,t:1527272018813};\\\", \\\"{x:835,y:537,t:1527272019264};\\\", \\\"{x:823,y:548,t:1527272019281};\\\", \\\"{x:797,y:569,t:1527272019299};\\\", \\\"{x:748,y:607,t:1527272019315};\\\", \\\"{x:693,y:653,t:1527272019332};\\\", \\\"{x:638,y:702,t:1527272019348};\\\", \\\"{x:590,y:739,t:1527272019363};\\\", \\\"{x:557,y:757,t:1527272019380};\\\", \\\"{x:537,y:769,t:1527272019398};\\\", \\\"{x:529,y:773,t:1527272019413};\\\", \\\"{x:527,y:774,t:1527272019431};\\\", \\\"{x:526,y:775,t:1527272019447};\\\", \\\"{x:525,y:773,t:1527272019552};\\\", \\\"{x:524,y:769,t:1527272019564};\\\", \\\"{x:521,y:761,t:1527272019580};\\\", \\\"{x:520,y:751,t:1527272019598};\\\", \\\"{x:518,y:739,t:1527272019615};\\\", \\\"{x:518,y:734,t:1527272019631};\\\", \\\"{x:518,y:730,t:1527272019647};\\\", \\\"{x:518,y:728,t:1527272019664};\\\" ] }, { \\\"rt\\\": 25212, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 339850, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"2WQ0M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -G -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:726,t:1527272024912};\\\", \\\"{x:586,y:622,t:1527272025004};\\\", \\\"{x:595,y:607,t:1527272025019};\\\", \\\"{x:605,y:587,t:1527272025035};\\\", \\\"{x:613,y:572,t:1527272025051};\\\", \\\"{x:618,y:561,t:1527272025069};\\\", \\\"{x:621,y:556,t:1527272025085};\\\", \\\"{x:622,y:551,t:1527272025102};\\\", \\\"{x:622,y:550,t:1527272025119};\\\", \\\"{x:622,y:549,t:1527272025136};\\\", \\\"{x:624,y:548,t:1527272025151};\\\", \\\"{x:624,y:547,t:1527272025536};\\\", \\\"{x:629,y:547,t:1527272025551};\\\", \\\"{x:636,y:547,t:1527272025569};\\\", \\\"{x:650,y:547,t:1527272025586};\\\", \\\"{x:665,y:547,t:1527272025602};\\\", \\\"{x:689,y:547,t:1527272025618};\\\", \\\"{x:734,y:549,t:1527272025637};\\\", \\\"{x:782,y:557,t:1527272025653};\\\", \\\"{x:837,y:561,t:1527272025669};\\\", \\\"{x:920,y:569,t:1527272025686};\\\", \\\"{x:989,y:577,t:1527272025703};\\\", \\\"{x:1061,y:584,t:1527272025718};\\\", \\\"{x:1160,y:600,t:1527272025735};\\\", \\\"{x:1227,y:610,t:1527272025753};\\\", \\\"{x:1275,y:617,t:1527272025770};\\\", \\\"{x:1315,y:624,t:1527272025786};\\\", \\\"{x:1353,y:627,t:1527272025803};\\\", \\\"{x:1388,y:633,t:1527272025819};\\\", \\\"{x:1413,y:638,t:1527272025836};\\\", \\\"{x:1432,y:642,t:1527272025853};\\\", \\\"{x:1437,y:642,t:1527272025870};\\\", \\\"{x:1438,y:642,t:1527272025886};\\\", \\\"{x:1439,y:642,t:1527272026088};\\\", \\\"{x:1439,y:643,t:1527272026384};\\\", \\\"{x:1439,y:646,t:1527272026393};\\\", \\\"{x:1439,y:650,t:1527272026404};\\\", \\\"{x:1439,y:658,t:1527272026421};\\\", \\\"{x:1439,y:665,t:1527272026437};\\\", \\\"{x:1437,y:677,t:1527272026454};\\\", \\\"{x:1434,y:690,t:1527272026471};\\\", \\\"{x:1433,y:700,t:1527272026487};\\\", \\\"{x:1432,y:707,t:1527272026503};\\\", \\\"{x:1430,y:719,t:1527272026520};\\\", \\\"{x:1428,y:728,t:1527272026537};\\\", \\\"{x:1427,y:739,t:1527272026554};\\\", \\\"{x:1425,y:748,t:1527272026570};\\\", \\\"{x:1424,y:757,t:1527272026587};\\\", \\\"{x:1423,y:765,t:1527272026604};\\\", \\\"{x:1420,y:774,t:1527272026621};\\\", \\\"{x:1420,y:782,t:1527272026637};\\\", \\\"{x:1420,y:788,t:1527272026654};\\\", \\\"{x:1420,y:794,t:1527272026670};\\\", \\\"{x:1420,y:805,t:1527272026688};\\\", \\\"{x:1420,y:811,t:1527272026704};\\\", \\\"{x:1420,y:816,t:1527272026720};\\\", \\\"{x:1420,y:819,t:1527272026737};\\\", \\\"{x:1420,y:823,t:1527272026754};\\\", \\\"{x:1420,y:827,t:1527272026770};\\\", \\\"{x:1420,y:834,t:1527272026787};\\\", \\\"{x:1417,y:839,t:1527272026804};\\\", \\\"{x:1416,y:844,t:1527272026820};\\\", \\\"{x:1411,y:850,t:1527272026837};\\\", \\\"{x:1405,y:856,t:1527272026854};\\\", \\\"{x:1399,y:862,t:1527272026870};\\\", \\\"{x:1390,y:867,t:1527272026887};\\\", \\\"{x:1373,y:877,t:1527272026904};\\\", \\\"{x:1361,y:882,t:1527272026921};\\\", \\\"{x:1347,y:886,t:1527272026937};\\\", \\\"{x:1335,y:890,t:1527272026954};\\\", \\\"{x:1325,y:894,t:1527272026971};\\\", \\\"{x:1312,y:896,t:1527272026987};\\\", \\\"{x:1303,y:900,t:1527272027005};\\\", \\\"{x:1295,y:900,t:1527272027021};\\\", \\\"{x:1288,y:901,t:1527272027037};\\\", \\\"{x:1281,y:901,t:1527272027054};\\\", \\\"{x:1270,y:901,t:1527272027071};\\\", \\\"{x:1261,y:901,t:1527272027087};\\\", \\\"{x:1251,y:901,t:1527272027104};\\\", \\\"{x:1245,y:901,t:1527272027122};\\\", \\\"{x:1240,y:901,t:1527272027138};\\\", \\\"{x:1237,y:901,t:1527272027154};\\\", \\\"{x:1235,y:900,t:1527272027171};\\\", \\\"{x:1233,y:900,t:1527272027187};\\\", \\\"{x:1232,y:900,t:1527272027328};\\\", \\\"{x:1231,y:900,t:1527272027384};\\\", \\\"{x:1230,y:899,t:1527272027392};\\\", \\\"{x:1230,y:898,t:1527272027416};\\\", \\\"{x:1230,y:895,t:1527272027425};\\\", \\\"{x:1229,y:892,t:1527272027438};\\\", \\\"{x:1229,y:886,t:1527272027454};\\\", \\\"{x:1229,y:881,t:1527272027472};\\\", \\\"{x:1229,y:863,t:1527272027487};\\\", \\\"{x:1229,y:849,t:1527272027504};\\\", \\\"{x:1229,y:832,t:1527272027521};\\\", \\\"{x:1234,y:814,t:1527272027538};\\\", \\\"{x:1239,y:798,t:1527272027554};\\\", \\\"{x:1244,y:786,t:1527272027571};\\\", \\\"{x:1246,y:777,t:1527272027589};\\\", \\\"{x:1248,y:768,t:1527272027604};\\\", \\\"{x:1251,y:761,t:1527272027621};\\\", \\\"{x:1252,y:756,t:1527272027639};\\\", \\\"{x:1253,y:752,t:1527272027656};\\\", \\\"{x:1253,y:746,t:1527272027672};\\\", \\\"{x:1253,y:740,t:1527272027687};\\\", \\\"{x:1253,y:736,t:1527272027705};\\\", \\\"{x:1253,y:733,t:1527272027722};\\\", \\\"{x:1253,y:731,t:1527272027738};\\\", \\\"{x:1253,y:729,t:1527272027756};\\\", \\\"{x:1253,y:727,t:1527272027771};\\\", \\\"{x:1253,y:723,t:1527272027788};\\\", \\\"{x:1253,y:715,t:1527272027805};\\\", \\\"{x:1255,y:708,t:1527272027821};\\\", \\\"{x:1255,y:702,t:1527272027838};\\\", \\\"{x:1255,y:695,t:1527272027855};\\\", \\\"{x:1255,y:691,t:1527272027871};\\\", \\\"{x:1255,y:688,t:1527272027888};\\\", \\\"{x:1255,y:686,t:1527272027905};\\\", \\\"{x:1255,y:685,t:1527272027922};\\\", \\\"{x:1255,y:684,t:1527272027938};\\\", \\\"{x:1255,y:683,t:1527272027955};\\\", \\\"{x:1256,y:682,t:1527272027972};\\\", \\\"{x:1257,y:680,t:1527272028025};\\\", \\\"{x:1254,y:679,t:1527272028328};\\\", \\\"{x:1249,y:679,t:1527272028338};\\\", \\\"{x:1241,y:677,t:1527272028355};\\\", \\\"{x:1236,y:677,t:1527272028372};\\\", \\\"{x:1234,y:677,t:1527272028388};\\\", \\\"{x:1231,y:677,t:1527272028406};\\\", \\\"{x:1230,y:676,t:1527272028425};\\\", \\\"{x:1229,y:675,t:1527272028448};\\\", \\\"{x:1228,y:674,t:1527272028455};\\\", \\\"{x:1226,y:666,t:1527272028472};\\\", \\\"{x:1222,y:657,t:1527272028489};\\\", \\\"{x:1218,y:640,t:1527272028505};\\\", \\\"{x:1213,y:619,t:1527272028523};\\\", \\\"{x:1211,y:599,t:1527272028540};\\\", \\\"{x:1209,y:577,t:1527272028555};\\\", \\\"{x:1210,y:566,t:1527272028572};\\\", \\\"{x:1212,y:559,t:1527272028589};\\\", \\\"{x:1214,y:557,t:1527272028606};\\\", \\\"{x:1214,y:555,t:1527272028623};\\\", \\\"{x:1216,y:553,t:1527272028640};\\\", \\\"{x:1217,y:552,t:1527272028688};\\\", \\\"{x:1218,y:552,t:1527272028706};\\\", \\\"{x:1219,y:552,t:1527272028722};\\\", \\\"{x:1222,y:552,t:1527272028740};\\\", \\\"{x:1227,y:552,t:1527272028755};\\\", \\\"{x:1233,y:552,t:1527272028773};\\\", \\\"{x:1238,y:552,t:1527272028790};\\\", \\\"{x:1246,y:552,t:1527272028805};\\\", \\\"{x:1251,y:552,t:1527272028823};\\\", \\\"{x:1256,y:552,t:1527272028840};\\\", \\\"{x:1261,y:552,t:1527272028855};\\\", \\\"{x:1268,y:554,t:1527272028872};\\\", \\\"{x:1276,y:556,t:1527272028890};\\\", \\\"{x:1282,y:557,t:1527272028906};\\\", \\\"{x:1291,y:558,t:1527272028924};\\\", \\\"{x:1298,y:560,t:1527272028939};\\\", \\\"{x:1304,y:561,t:1527272028956};\\\", \\\"{x:1310,y:564,t:1527272028972};\\\", \\\"{x:1314,y:565,t:1527272028989};\\\", \\\"{x:1317,y:566,t:1527272029007};\\\", \\\"{x:1320,y:566,t:1527272029022};\\\", \\\"{x:1321,y:567,t:1527272029040};\\\", \\\"{x:1323,y:567,t:1527272029057};\\\", \\\"{x:1324,y:567,t:1527272029073};\\\", \\\"{x:1326,y:567,t:1527272029090};\\\", \\\"{x:1327,y:567,t:1527272029106};\\\", \\\"{x:1329,y:567,t:1527272029504};\\\", \\\"{x:1331,y:567,t:1527272029512};\\\", \\\"{x:1334,y:567,t:1527272029524};\\\", \\\"{x:1347,y:567,t:1527272029539};\\\", \\\"{x:1368,y:569,t:1527272029556};\\\", \\\"{x:1394,y:573,t:1527272029573};\\\", \\\"{x:1422,y:576,t:1527272029590};\\\", \\\"{x:1453,y:581,t:1527272029607};\\\", \\\"{x:1486,y:584,t:1527272029625};\\\", \\\"{x:1500,y:585,t:1527272029640};\\\", \\\"{x:1510,y:586,t:1527272029656};\\\", \\\"{x:1513,y:586,t:1527272029673};\\\", \\\"{x:1515,y:586,t:1527272029690};\\\", \\\"{x:1514,y:586,t:1527272030064};\\\", \\\"{x:1511,y:586,t:1527272030074};\\\", \\\"{x:1505,y:586,t:1527272030091};\\\", \\\"{x:1495,y:583,t:1527272030107};\\\", \\\"{x:1480,y:580,t:1527272030123};\\\", \\\"{x:1464,y:578,t:1527272030140};\\\", \\\"{x:1447,y:575,t:1527272030158};\\\", \\\"{x:1434,y:574,t:1527272030174};\\\", \\\"{x:1424,y:573,t:1527272030191};\\\", \\\"{x:1414,y:571,t:1527272030208};\\\", \\\"{x:1413,y:571,t:1527272030226};\\\", \\\"{x:1413,y:570,t:1527272030809};\\\", \\\"{x:1413,y:569,t:1527272030848};\\\", \\\"{x:1413,y:568,t:1527272030867};\\\", \\\"{x:1413,y:567,t:1527272030959};\\\", \\\"{x:1413,y:566,t:1527272031608};\\\", \\\"{x:1395,y:566,t:1527272031626};\\\", \\\"{x:1361,y:566,t:1527272031642};\\\", \\\"{x:1303,y:566,t:1527272031658};\\\", \\\"{x:1203,y:566,t:1527272031676};\\\", \\\"{x:1087,y:566,t:1527272031691};\\\", \\\"{x:973,y:566,t:1527272031709};\\\", \\\"{x:849,y:566,t:1527272031725};\\\", \\\"{x:749,y:566,t:1527272031741};\\\", \\\"{x:658,y:556,t:1527272031758};\\\", \\\"{x:587,y:544,t:1527272031774};\\\", \\\"{x:508,y:533,t:1527272031790};\\\", \\\"{x:474,y:530,t:1527272031808};\\\", \\\"{x:452,y:529,t:1527272031824};\\\", \\\"{x:435,y:529,t:1527272031841};\\\", \\\"{x:424,y:529,t:1527272031857};\\\", \\\"{x:409,y:529,t:1527272031874};\\\", \\\"{x:390,y:526,t:1527272031891};\\\", \\\"{x:373,y:523,t:1527272031908};\\\", \\\"{x:360,y:521,t:1527272031924};\\\", \\\"{x:359,y:521,t:1527272031940};\\\", \\\"{x:358,y:521,t:1527272032008};\\\", \\\"{x:357,y:521,t:1527272032024};\\\", \\\"{x:356,y:522,t:1527272032041};\\\", \\\"{x:356,y:523,t:1527272032104};\\\", \\\"{x:356,y:524,t:1527272032112};\\\", \\\"{x:357,y:525,t:1527272032126};\\\", \\\"{x:360,y:527,t:1527272032140};\\\", \\\"{x:364,y:527,t:1527272032158};\\\", \\\"{x:371,y:529,t:1527272032175};\\\", \\\"{x:379,y:529,t:1527272032191};\\\", \\\"{x:404,y:529,t:1527272032208};\\\", \\\"{x:435,y:529,t:1527272032225};\\\", \\\"{x:474,y:529,t:1527272032241};\\\", \\\"{x:511,y:529,t:1527272032259};\\\", \\\"{x:543,y:529,t:1527272032275};\\\", \\\"{x:572,y:529,t:1527272032291};\\\", \\\"{x:587,y:529,t:1527272032308};\\\", \\\"{x:592,y:529,t:1527272032325};\\\", \\\"{x:593,y:529,t:1527272032341};\\\", \\\"{x:593,y:528,t:1527272032472};\\\", \\\"{x:593,y:527,t:1527272032503};\\\", \\\"{x:593,y:526,t:1527272032512};\\\", \\\"{x:593,y:525,t:1527272032525};\\\", \\\"{x:593,y:522,t:1527272032544};\\\", \\\"{x:593,y:519,t:1527272032558};\\\", \\\"{x:596,y:513,t:1527272032575};\\\", \\\"{x:599,y:510,t:1527272032592};\\\", \\\"{x:601,y:508,t:1527272032608};\\\", \\\"{x:603,y:507,t:1527272032624};\\\", \\\"{x:607,y:507,t:1527272032935};\\\", \\\"{x:616,y:507,t:1527272032943};\\\", \\\"{x:628,y:507,t:1527272032958};\\\", \\\"{x:683,y:507,t:1527272032976};\\\", \\\"{x:731,y:507,t:1527272032993};\\\", \\\"{x:767,y:507,t:1527272033009};\\\", \\\"{x:793,y:507,t:1527272033024};\\\", \\\"{x:803,y:510,t:1527272033042};\\\", \\\"{x:805,y:511,t:1527272033059};\\\", \\\"{x:807,y:511,t:1527272033128};\\\", \\\"{x:817,y:517,t:1527272033152};\\\", \\\"{x:819,y:519,t:1527272033159};\\\", \\\"{x:828,y:523,t:1527272033174};\\\", \\\"{x:835,y:528,t:1527272033192};\\\", \\\"{x:841,y:531,t:1527272033208};\\\", \\\"{x:844,y:533,t:1527272033225};\\\", \\\"{x:846,y:535,t:1527272033242};\\\", \\\"{x:847,y:536,t:1527272033262};\\\", \\\"{x:850,y:536,t:1527272033631};\\\", \\\"{x:859,y:538,t:1527272033642};\\\", \\\"{x:883,y:540,t:1527272033660};\\\", \\\"{x:943,y:548,t:1527272033676};\\\", \\\"{x:1040,y:564,t:1527272033692};\\\", \\\"{x:1140,y:575,t:1527272033709};\\\", \\\"{x:1241,y:583,t:1527272033727};\\\", \\\"{x:1330,y:583,t:1527272033742};\\\", \\\"{x:1405,y:583,t:1527272033775};\\\", \\\"{x:1406,y:583,t:1527272033792};\\\", \\\"{x:1407,y:583,t:1527272033911};\\\", \\\"{x:1409,y:582,t:1527272033935};\\\", \\\"{x:1410,y:581,t:1527272033943};\\\", \\\"{x:1410,y:580,t:1527272033959};\\\", \\\"{x:1411,y:580,t:1527272033976};\\\", \\\"{x:1412,y:580,t:1527272033992};\\\", \\\"{x:1416,y:578,t:1527272034009};\\\", \\\"{x:1422,y:574,t:1527272034026};\\\", \\\"{x:1428,y:572,t:1527272034042};\\\", \\\"{x:1432,y:570,t:1527272034059};\\\", \\\"{x:1431,y:570,t:1527272034264};\\\", \\\"{x:1430,y:570,t:1527272034280};\\\", \\\"{x:1429,y:570,t:1527272034294};\\\", \\\"{x:1428,y:569,t:1527272034310};\\\", \\\"{x:1427,y:569,t:1527272034367};\\\", \\\"{x:1426,y:569,t:1527272034399};\\\", \\\"{x:1426,y:568,t:1527272034423};\\\", \\\"{x:1425,y:568,t:1527272034439};\\\", \\\"{x:1425,y:567,t:1527272034446};\\\", \\\"{x:1424,y:567,t:1527272034462};\\\", \\\"{x:1423,y:566,t:1527272034476};\\\", \\\"{x:1422,y:566,t:1527272034493};\\\", \\\"{x:1420,y:566,t:1527272034509};\\\", \\\"{x:1417,y:565,t:1527272034526};\\\", \\\"{x:1414,y:565,t:1527272034543};\\\", \\\"{x:1413,y:564,t:1527272034560};\\\", \\\"{x:1407,y:563,t:1527272036385};\\\", \\\"{x:1400,y:563,t:1527272036394};\\\", \\\"{x:1378,y:564,t:1527272036412};\\\", \\\"{x:1349,y:567,t:1527272036428};\\\", \\\"{x:1309,y:573,t:1527272036444};\\\", \\\"{x:1256,y:581,t:1527272036461};\\\", \\\"{x:1204,y:594,t:1527272036478};\\\", \\\"{x:1143,y:609,t:1527272036495};\\\", \\\"{x:1065,y:630,t:1527272036511};\\\", \\\"{x:1016,y:642,t:1527272036528};\\\", \\\"{x:973,y:655,t:1527272036544};\\\", \\\"{x:937,y:659,t:1527272036560};\\\", \\\"{x:912,y:667,t:1527272036577};\\\", \\\"{x:886,y:669,t:1527272036594};\\\", \\\"{x:868,y:672,t:1527272036611};\\\", \\\"{x:854,y:674,t:1527272036627};\\\", \\\"{x:841,y:675,t:1527272036644};\\\", \\\"{x:831,y:678,t:1527272036661};\\\", \\\"{x:817,y:679,t:1527272036677};\\\", \\\"{x:804,y:683,t:1527272036694};\\\", \\\"{x:780,y:686,t:1527272036710};\\\", \\\"{x:762,y:689,t:1527272036727};\\\", \\\"{x:741,y:693,t:1527272036743};\\\", \\\"{x:724,y:697,t:1527272036761};\\\", \\\"{x:707,y:703,t:1527272036778};\\\", \\\"{x:692,y:710,t:1527272036794};\\\", \\\"{x:676,y:718,t:1527272036811};\\\", \\\"{x:658,y:725,t:1527272036828};\\\", \\\"{x:642,y:732,t:1527272036844};\\\", \\\"{x:632,y:736,t:1527272036860};\\\", \\\"{x:623,y:740,t:1527272036877};\\\", \\\"{x:615,y:744,t:1527272036894};\\\", \\\"{x:599,y:750,t:1527272036910};\\\", \\\"{x:588,y:755,t:1527272036927};\\\", \\\"{x:580,y:757,t:1527272036944};\\\", \\\"{x:571,y:760,t:1527272036961};\\\", \\\"{x:564,y:761,t:1527272036978};\\\", \\\"{x:556,y:763,t:1527272036994};\\\", \\\"{x:550,y:765,t:1527272037011};\\\", \\\"{x:543,y:766,t:1527272037028};\\\", \\\"{x:536,y:766,t:1527272037044};\\\", \\\"{x:529,y:766,t:1527272037061};\\\", \\\"{x:523,y:766,t:1527272037078};\\\", \\\"{x:517,y:766,t:1527272037094};\\\", \\\"{x:505,y:764,t:1527272037111};\\\", \\\"{x:499,y:763,t:1527272037128};\\\", \\\"{x:495,y:762,t:1527272037144};\\\", \\\"{x:491,y:760,t:1527272037160};\\\", \\\"{x:490,y:759,t:1527272037178};\\\", \\\"{x:487,y:758,t:1527272037194};\\\", \\\"{x:486,y:757,t:1527272037279};\\\", \\\"{x:486,y:755,t:1527272037295};\\\", \\\"{x:486,y:753,t:1527272037311};\\\", \\\"{x:486,y:750,t:1527272037328};\\\", \\\"{x:486,y:746,t:1527272037345};\\\", \\\"{x:486,y:743,t:1527272037362};\\\", \\\"{x:486,y:741,t:1527272037378};\\\", \\\"{x:487,y:737,t:1527272037394};\\\", \\\"{x:488,y:734,t:1527272037412};\\\", \\\"{x:490,y:731,t:1527272037428};\\\", \\\"{x:491,y:729,t:1527272037445};\\\", \\\"{x:492,y:728,t:1527272037839};\\\", \\\"{x:493,y:728,t:1527272037871};\\\", \\\"{x:494,y:728,t:1527272047608};\\\", \\\"{x:496,y:728,t:1527272047624};\\\", \\\"{x:497,y:728,t:1527272047688};\\\", \\\"{x:499,y:728,t:1527272050152};\\\", \\\"{x:500,y:728,t:1527272050159};\\\", \\\"{x:503,y:727,t:1527272050173};\\\", \\\"{x:505,y:726,t:1527272050190};\\\", \\\"{x:507,y:725,t:1527272050206};\\\", \\\"{x:509,y:725,t:1527272050223};\\\" ] }, { \\\"rt\\\": 29291, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 370529, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"2WQ0M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -B -C -C -X -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:511,y:725,t:1527272051102};\\\", \\\"{x:515,y:722,t:1527272051106};\\\", \\\"{x:519,y:720,t:1527272051124};\\\", \\\"{x:523,y:717,t:1527272051141};\\\", \\\"{x:525,y:715,t:1527272051157};\\\", \\\"{x:525,y:714,t:1527272051175};\\\", \\\"{x:525,y:713,t:1527272051198};\\\", \\\"{x:525,y:712,t:1527272051215};\\\", \\\"{x:525,y:711,t:1527272051223};\\\", \\\"{x:525,y:710,t:1527272051240};\\\", \\\"{x:525,y:709,t:1527272051257};\\\", \\\"{x:525,y:708,t:1527272051343};\\\", \\\"{x:525,y:707,t:1527272051367};\\\", \\\"{x:525,y:706,t:1527272051382};\\\", \\\"{x:525,y:704,t:1527272051414};\\\", \\\"{x:527,y:702,t:1527272051424};\\\", \\\"{x:529,y:699,t:1527272051441};\\\", \\\"{x:533,y:695,t:1527272051457};\\\", \\\"{x:539,y:691,t:1527272051473};\\\", \\\"{x:547,y:687,t:1527272051489};\\\", \\\"{x:554,y:686,t:1527272051507};\\\", \\\"{x:558,y:685,t:1527272051523};\\\", \\\"{x:564,y:685,t:1527272051540};\\\", \\\"{x:573,y:683,t:1527272051558};\\\", \\\"{x:581,y:682,t:1527272051574};\\\", \\\"{x:593,y:680,t:1527272051591};\\\", \\\"{x:598,y:679,t:1527272051607};\\\", \\\"{x:601,y:678,t:1527272051624};\\\", \\\"{x:603,y:677,t:1527272051641};\\\", \\\"{x:604,y:677,t:1527272051658};\\\", \\\"{x:607,y:677,t:1527272051674};\\\", \\\"{x:608,y:675,t:1527272051692};\\\", \\\"{x:609,y:675,t:1527272051708};\\\", \\\"{x:610,y:675,t:1527272051724};\\\", \\\"{x:611,y:675,t:1527272051799};\\\", \\\"{x:611,y:674,t:1527272051911};\\\", \\\"{x:612,y:674,t:1527272051923};\\\", \\\"{x:613,y:672,t:1527272052000};\\\", \\\"{x:615,y:672,t:1527272052519};\\\", \\\"{x:620,y:672,t:1527272052527};\\\", \\\"{x:628,y:672,t:1527272052542};\\\", \\\"{x:652,y:672,t:1527272052558};\\\", \\\"{x:704,y:675,t:1527272052575};\\\", \\\"{x:755,y:683,t:1527272052591};\\\", \\\"{x:827,y:693,t:1527272052608};\\\", \\\"{x:897,y:704,t:1527272052625};\\\", \\\"{x:967,y:714,t:1527272052642};\\\", \\\"{x:1050,y:721,t:1527272052658};\\\", \\\"{x:1124,y:730,t:1527272052675};\\\", \\\"{x:1197,y:741,t:1527272052692};\\\", \\\"{x:1259,y:744,t:1527272052708};\\\", \\\"{x:1319,y:748,t:1527272052725};\\\", \\\"{x:1353,y:749,t:1527272052743};\\\", \\\"{x:1395,y:749,t:1527272052758};\\\", \\\"{x:1460,y:749,t:1527272052775};\\\", \\\"{x:1499,y:749,t:1527272052792};\\\", \\\"{x:1528,y:749,t:1527272052809};\\\", \\\"{x:1535,y:750,t:1527272052826};\\\", \\\"{x:1534,y:749,t:1527272053168};\\\", \\\"{x:1533,y:748,t:1527272053176};\\\", \\\"{x:1528,y:746,t:1527272053193};\\\", \\\"{x:1525,y:744,t:1527272053210};\\\", \\\"{x:1520,y:740,t:1527272053226};\\\", \\\"{x:1517,y:738,t:1527272053243};\\\", \\\"{x:1514,y:737,t:1527272053259};\\\", \\\"{x:1511,y:736,t:1527272053276};\\\", \\\"{x:1510,y:736,t:1527272053292};\\\", \\\"{x:1510,y:735,t:1527272054462};\\\", \\\"{x:1510,y:734,t:1527272054476};\\\", \\\"{x:1507,y:729,t:1527272054493};\\\", \\\"{x:1504,y:726,t:1527272054510};\\\", \\\"{x:1499,y:720,t:1527272054526};\\\", \\\"{x:1495,y:716,t:1527272054543};\\\", \\\"{x:1492,y:711,t:1527272054560};\\\", \\\"{x:1489,y:708,t:1527272054577};\\\", \\\"{x:1485,y:704,t:1527272054593};\\\", \\\"{x:1483,y:702,t:1527272054610};\\\", \\\"{x:1482,y:698,t:1527272054627};\\\", \\\"{x:1479,y:695,t:1527272054644};\\\", \\\"{x:1477,y:692,t:1527272054660};\\\", \\\"{x:1475,y:688,t:1527272054678};\\\", \\\"{x:1471,y:683,t:1527272054693};\\\", \\\"{x:1464,y:675,t:1527272054710};\\\", \\\"{x:1453,y:663,t:1527272054727};\\\", \\\"{x:1448,y:653,t:1527272054743};\\\", \\\"{x:1436,y:632,t:1527272054760};\\\", \\\"{x:1416,y:613,t:1527272054777};\\\", \\\"{x:1401,y:601,t:1527272054794};\\\", \\\"{x:1388,y:591,t:1527272054810};\\\", \\\"{x:1376,y:583,t:1527272054827};\\\", \\\"{x:1369,y:579,t:1527272054843};\\\", \\\"{x:1365,y:577,t:1527272054860};\\\", \\\"{x:1363,y:576,t:1527272054876};\\\", \\\"{x:1362,y:576,t:1527272054894};\\\", \\\"{x:1362,y:577,t:1527272055912};\\\", \\\"{x:1362,y:583,t:1527272055928};\\\", \\\"{x:1362,y:587,t:1527272055945};\\\", \\\"{x:1361,y:592,t:1527272055961};\\\", \\\"{x:1359,y:597,t:1527272055979};\\\", \\\"{x:1359,y:602,t:1527272055995};\\\", \\\"{x:1358,y:609,t:1527272056011};\\\", \\\"{x:1357,y:617,t:1527272056028};\\\", \\\"{x:1355,y:626,t:1527272056044};\\\", \\\"{x:1352,y:636,t:1527272056061};\\\", \\\"{x:1352,y:646,t:1527272056078};\\\", \\\"{x:1349,y:663,t:1527272056095};\\\", \\\"{x:1349,y:678,t:1527272056111};\\\", \\\"{x:1349,y:689,t:1527272056129};\\\", \\\"{x:1349,y:701,t:1527272056148};\\\", \\\"{x:1349,y:711,t:1527272056161};\\\", \\\"{x:1349,y:718,t:1527272056178};\\\", \\\"{x:1349,y:724,t:1527272056195};\\\", \\\"{x:1349,y:731,t:1527272056211};\\\", \\\"{x:1349,y:737,t:1527272056228};\\\", \\\"{x:1348,y:743,t:1527272056244};\\\", \\\"{x:1347,y:751,t:1527272056260};\\\", \\\"{x:1344,y:758,t:1527272056278};\\\", \\\"{x:1342,y:765,t:1527272056295};\\\", \\\"{x:1341,y:767,t:1527272056311};\\\", \\\"{x:1341,y:770,t:1527272056328};\\\", \\\"{x:1340,y:773,t:1527272056345};\\\", \\\"{x:1338,y:777,t:1527272056361};\\\", \\\"{x:1338,y:778,t:1527272056378};\\\", \\\"{x:1337,y:781,t:1527272056395};\\\", \\\"{x:1336,y:783,t:1527272056411};\\\", \\\"{x:1335,y:785,t:1527272056428};\\\", \\\"{x:1334,y:788,t:1527272056445};\\\", \\\"{x:1332,y:792,t:1527272056461};\\\", \\\"{x:1330,y:795,t:1527272056478};\\\", \\\"{x:1330,y:798,t:1527272056495};\\\", \\\"{x:1329,y:800,t:1527272056512};\\\", \\\"{x:1328,y:800,t:1527272056528};\\\", \\\"{x:1328,y:801,t:1527272056808};\\\", \\\"{x:1329,y:802,t:1527272056864};\\\", \\\"{x:1329,y:803,t:1527272056879};\\\", \\\"{x:1329,y:805,t:1527272056896};\\\", \\\"{x:1326,y:810,t:1527272056912};\\\", \\\"{x:1325,y:814,t:1527272056929};\\\", \\\"{x:1323,y:817,t:1527272056945};\\\", \\\"{x:1320,y:821,t:1527272056961};\\\", \\\"{x:1319,y:823,t:1527272056979};\\\", \\\"{x:1317,y:825,t:1527272056995};\\\", \\\"{x:1316,y:827,t:1527272057012};\\\", \\\"{x:1313,y:830,t:1527272057029};\\\", \\\"{x:1311,y:833,t:1527272057045};\\\", \\\"{x:1309,y:836,t:1527272057062};\\\", \\\"{x:1306,y:839,t:1527272057079};\\\", \\\"{x:1305,y:841,t:1527272057095};\\\", \\\"{x:1304,y:842,t:1527272057112};\\\", \\\"{x:1303,y:844,t:1527272057129};\\\", \\\"{x:1303,y:845,t:1527272057146};\\\", \\\"{x:1302,y:845,t:1527272057162};\\\", \\\"{x:1301,y:847,t:1527272057179};\\\", \\\"{x:1301,y:848,t:1527272057195};\\\", \\\"{x:1300,y:849,t:1527272057212};\\\", \\\"{x:1300,y:850,t:1527272057230};\\\", \\\"{x:1300,y:852,t:1527272057245};\\\", \\\"{x:1299,y:852,t:1527272057262};\\\", \\\"{x:1299,y:855,t:1527272057279};\\\", \\\"{x:1299,y:857,t:1527272057296};\\\", \\\"{x:1299,y:860,t:1527272057312};\\\", \\\"{x:1298,y:862,t:1527272057330};\\\", \\\"{x:1298,y:864,t:1527272057346};\\\", \\\"{x:1298,y:865,t:1527272057456};\\\", \\\"{x:1297,y:865,t:1527272057472};\\\", \\\"{x:1296,y:865,t:1527272057527};\\\", \\\"{x:1296,y:863,t:1527272057543};\\\", \\\"{x:1296,y:862,t:1527272057551};\\\", \\\"{x:1296,y:861,t:1527272057562};\\\", \\\"{x:1296,y:857,t:1527272057579};\\\", \\\"{x:1296,y:852,t:1527272057597};\\\", \\\"{x:1298,y:846,t:1527272057612};\\\", \\\"{x:1301,y:842,t:1527272057630};\\\", \\\"{x:1305,y:836,t:1527272057646};\\\", \\\"{x:1309,y:832,t:1527272057663};\\\", \\\"{x:1311,y:830,t:1527272057680};\\\", \\\"{x:1313,y:828,t:1527272057697};\\\", \\\"{x:1317,y:823,t:1527272057714};\\\", \\\"{x:1320,y:819,t:1527272057729};\\\", \\\"{x:1323,y:815,t:1527272057746};\\\", \\\"{x:1323,y:810,t:1527272057763};\\\", \\\"{x:1325,y:803,t:1527272057779};\\\", \\\"{x:1326,y:799,t:1527272057796};\\\", \\\"{x:1328,y:792,t:1527272057813};\\\", \\\"{x:1329,y:783,t:1527272057829};\\\", \\\"{x:1331,y:773,t:1527272057846};\\\", \\\"{x:1333,y:755,t:1527272057864};\\\", \\\"{x:1333,y:742,t:1527272057879};\\\", \\\"{x:1334,y:731,t:1527272057896};\\\", \\\"{x:1334,y:724,t:1527272057914};\\\", \\\"{x:1334,y:715,t:1527272057930};\\\", \\\"{x:1334,y:706,t:1527272057946};\\\", \\\"{x:1336,y:698,t:1527272057963};\\\", \\\"{x:1336,y:693,t:1527272057980};\\\", \\\"{x:1337,y:688,t:1527272057996};\\\", \\\"{x:1337,y:686,t:1527272058014};\\\", \\\"{x:1338,y:684,t:1527272058029};\\\", \\\"{x:1338,y:683,t:1527272058047};\\\", \\\"{x:1340,y:680,t:1527272058063};\\\", \\\"{x:1340,y:678,t:1527272058080};\\\", \\\"{x:1340,y:675,t:1527272058097};\\\", \\\"{x:1341,y:673,t:1527272058114};\\\", \\\"{x:1343,y:666,t:1527272058131};\\\", \\\"{x:1345,y:663,t:1527272058146};\\\", \\\"{x:1348,y:656,t:1527272058163};\\\", \\\"{x:1351,y:651,t:1527272058180};\\\", \\\"{x:1352,y:646,t:1527272058197};\\\", \\\"{x:1353,y:644,t:1527272058213};\\\", \\\"{x:1353,y:643,t:1527272058230};\\\", \\\"{x:1353,y:642,t:1527272058247};\\\", \\\"{x:1354,y:641,t:1527272058271};\\\", \\\"{x:1357,y:640,t:1527272058704};\\\", \\\"{x:1363,y:640,t:1527272058713};\\\", \\\"{x:1378,y:639,t:1527272058730};\\\", \\\"{x:1394,y:635,t:1527272058747};\\\", \\\"{x:1412,y:633,t:1527272058763};\\\", \\\"{x:1433,y:628,t:1527272058779};\\\", \\\"{x:1451,y:626,t:1527272058797};\\\", \\\"{x:1461,y:624,t:1527272058813};\\\", \\\"{x:1466,y:623,t:1527272058830};\\\", \\\"{x:1468,y:622,t:1527272058847};\\\", \\\"{x:1469,y:621,t:1527272058863};\\\", \\\"{x:1470,y:621,t:1527272058880};\\\", \\\"{x:1473,y:620,t:1527272058897};\\\", \\\"{x:1475,y:620,t:1527272058919};\\\", \\\"{x:1474,y:620,t:1527272059056};\\\", \\\"{x:1472,y:620,t:1527272059064};\\\", \\\"{x:1470,y:620,t:1527272059080};\\\", \\\"{x:1468,y:621,t:1527272059097};\\\", \\\"{x:1466,y:622,t:1527272059115};\\\", \\\"{x:1462,y:623,t:1527272059131};\\\", \\\"{x:1459,y:624,t:1527272059148};\\\", \\\"{x:1459,y:625,t:1527272059164};\\\", \\\"{x:1457,y:625,t:1527272059180};\\\", \\\"{x:1455,y:626,t:1527272059198};\\\", \\\"{x:1454,y:627,t:1527272059215};\\\", \\\"{x:1453,y:627,t:1527272059240};\\\", \\\"{x:1452,y:628,t:1527272059358};\\\", \\\"{x:1452,y:629,t:1527272059374};\\\", \\\"{x:1452,y:630,t:1527272059423};\\\", \\\"{x:1453,y:630,t:1527272059437};\\\", \\\"{x:1454,y:630,t:1527272059448};\\\", \\\"{x:1455,y:631,t:1527272059464};\\\", \\\"{x:1456,y:631,t:1527272059480};\\\", \\\"{x:1457,y:631,t:1527272059497};\\\", \\\"{x:1458,y:631,t:1527272059513};\\\", \\\"{x:1460,y:632,t:1527272059531};\\\", \\\"{x:1461,y:632,t:1527272059550};\\\", \\\"{x:1462,y:632,t:1527272059606};\\\", \\\"{x:1463,y:633,t:1527272060295};\\\", \\\"{x:1465,y:634,t:1527272060303};\\\", \\\"{x:1468,y:636,t:1527272060315};\\\", \\\"{x:1475,y:639,t:1527272060331};\\\", \\\"{x:1483,y:645,t:1527272060348};\\\", \\\"{x:1487,y:647,t:1527272060365};\\\", \\\"{x:1491,y:650,t:1527272060381};\\\", \\\"{x:1493,y:652,t:1527272060398};\\\", \\\"{x:1495,y:655,t:1527272060415};\\\", \\\"{x:1495,y:658,t:1527272060431};\\\", \\\"{x:1495,y:665,t:1527272060448};\\\", \\\"{x:1497,y:674,t:1527272060465};\\\", \\\"{x:1499,y:686,t:1527272060481};\\\", \\\"{x:1500,y:694,t:1527272060499};\\\", \\\"{x:1500,y:699,t:1527272060516};\\\", \\\"{x:1500,y:706,t:1527272060532};\\\", \\\"{x:1500,y:716,t:1527272060548};\\\", \\\"{x:1500,y:725,t:1527272060565};\\\", \\\"{x:1500,y:739,t:1527272060583};\\\", \\\"{x:1500,y:749,t:1527272060599};\\\", \\\"{x:1500,y:754,t:1527272060616};\\\", \\\"{x:1500,y:759,t:1527272060633};\\\", \\\"{x:1500,y:762,t:1527272060648};\\\", \\\"{x:1499,y:765,t:1527272060666};\\\", \\\"{x:1498,y:768,t:1527272060683};\\\", \\\"{x:1498,y:769,t:1527272060698};\\\", \\\"{x:1498,y:771,t:1527272060715};\\\", \\\"{x:1497,y:774,t:1527272060732};\\\", \\\"{x:1497,y:775,t:1527272060748};\\\", \\\"{x:1497,y:776,t:1527272060764};\\\", \\\"{x:1497,y:778,t:1527272060782};\\\", \\\"{x:1497,y:781,t:1527272060798};\\\", \\\"{x:1497,y:786,t:1527272060815};\\\", \\\"{x:1497,y:790,t:1527272060833};\\\", \\\"{x:1497,y:792,t:1527272060848};\\\", \\\"{x:1495,y:796,t:1527272060865};\\\", \\\"{x:1495,y:798,t:1527272060882};\\\", \\\"{x:1495,y:801,t:1527272060898};\\\", \\\"{x:1495,y:803,t:1527272060915};\\\", \\\"{x:1494,y:805,t:1527272060932};\\\", \\\"{x:1493,y:809,t:1527272060949};\\\", \\\"{x:1493,y:811,t:1527272060965};\\\", \\\"{x:1492,y:814,t:1527272060982};\\\", \\\"{x:1491,y:815,t:1527272060999};\\\", \\\"{x:1490,y:817,t:1527272061016};\\\", \\\"{x:1490,y:819,t:1527272061032};\\\", \\\"{x:1490,y:820,t:1527272061056};\\\", \\\"{x:1489,y:821,t:1527272061066};\\\", \\\"{x:1488,y:823,t:1527272061083};\\\", \\\"{x:1487,y:824,t:1527272061100};\\\", \\\"{x:1487,y:826,t:1527272061116};\\\", \\\"{x:1486,y:827,t:1527272061133};\\\", \\\"{x:1485,y:828,t:1527272061150};\\\", \\\"{x:1485,y:829,t:1527272061166};\\\", \\\"{x:1484,y:830,t:1527272061182};\\\", \\\"{x:1484,y:832,t:1527272061199};\\\", \\\"{x:1483,y:833,t:1527272061216};\\\", \\\"{x:1482,y:834,t:1527272061233};\\\", \\\"{x:1481,y:835,t:1527272061249};\\\", \\\"{x:1481,y:836,t:1527272061267};\\\", \\\"{x:1481,y:837,t:1527272061287};\\\", \\\"{x:1479,y:838,t:1527272061300};\\\", \\\"{x:1479,y:839,t:1527272061316};\\\", \\\"{x:1478,y:840,t:1527272061332};\\\", \\\"{x:1478,y:842,t:1527272061350};\\\", \\\"{x:1476,y:844,t:1527272061368};\\\", \\\"{x:1476,y:845,t:1527272061383};\\\", \\\"{x:1475,y:847,t:1527272061400};\\\", \\\"{x:1474,y:847,t:1527272061417};\\\", \\\"{x:1474,y:849,t:1527272061433};\\\", \\\"{x:1473,y:849,t:1527272061449};\\\", \\\"{x:1473,y:850,t:1527272061467};\\\", \\\"{x:1472,y:850,t:1527272061483};\\\", \\\"{x:1471,y:850,t:1527272061728};\\\", \\\"{x:1471,y:849,t:1527272061735};\\\", \\\"{x:1471,y:845,t:1527272061750};\\\", \\\"{x:1472,y:837,t:1527272061767};\\\", \\\"{x:1478,y:825,t:1527272061784};\\\", \\\"{x:1481,y:819,t:1527272061800};\\\", \\\"{x:1482,y:815,t:1527272061816};\\\", \\\"{x:1486,y:810,t:1527272061834};\\\", \\\"{x:1487,y:807,t:1527272061849};\\\", \\\"{x:1489,y:804,t:1527272061867};\\\", \\\"{x:1490,y:802,t:1527272061884};\\\", \\\"{x:1490,y:801,t:1527272061899};\\\", \\\"{x:1492,y:798,t:1527272061916};\\\", \\\"{x:1492,y:797,t:1527272061933};\\\", \\\"{x:1493,y:797,t:1527272061949};\\\", \\\"{x:1493,y:796,t:1527272061967};\\\", \\\"{x:1493,y:795,t:1527272061983};\\\", \\\"{x:1494,y:795,t:1527272061999};\\\", \\\"{x:1495,y:793,t:1527272062016};\\\", \\\"{x:1495,y:792,t:1527272062039};\\\", \\\"{x:1496,y:792,t:1527272062071};\\\", \\\"{x:1496,y:791,t:1527272062094};\\\", \\\"{x:1496,y:790,t:1527272062103};\\\", \\\"{x:1496,y:789,t:1527272062116};\\\", \\\"{x:1496,y:788,t:1527272062133};\\\", \\\"{x:1498,y:785,t:1527272062149};\\\", \\\"{x:1498,y:783,t:1527272062175};\\\", \\\"{x:1499,y:782,t:1527272062191};\\\", \\\"{x:1499,y:781,t:1527272062231};\\\", \\\"{x:1500,y:780,t:1527272062247};\\\", \\\"{x:1500,y:779,t:1527272062256};\\\", \\\"{x:1501,y:778,t:1527272062271};\\\", \\\"{x:1502,y:777,t:1527272062287};\\\", \\\"{x:1502,y:776,t:1527272062303};\\\", \\\"{x:1503,y:775,t:1527272062343};\\\", \\\"{x:1503,y:774,t:1527272062415};\\\", \\\"{x:1503,y:773,t:1527272072549};\\\", \\\"{x:1503,y:774,t:1527272073940};\\\", \\\"{x:1500,y:779,t:1527272073958};\\\", \\\"{x:1496,y:782,t:1527272073975};\\\", \\\"{x:1493,y:785,t:1527272073992};\\\", \\\"{x:1492,y:786,t:1527272074013};\\\", \\\"{x:1490,y:787,t:1527272074029};\\\", \\\"{x:1489,y:787,t:1527272074042};\\\", \\\"{x:1485,y:788,t:1527272074058};\\\", \\\"{x:1481,y:791,t:1527272074075};\\\", \\\"{x:1473,y:793,t:1527272074091};\\\", \\\"{x:1460,y:796,t:1527272074108};\\\", \\\"{x:1437,y:798,t:1527272074124};\\\", \\\"{x:1411,y:798,t:1527272074142};\\\", \\\"{x:1378,y:798,t:1527272074157};\\\", \\\"{x:1333,y:798,t:1527272074174};\\\", \\\"{x:1285,y:798,t:1527272074192};\\\", \\\"{x:1230,y:793,t:1527272074207};\\\", \\\"{x:1160,y:782,t:1527272074224};\\\", \\\"{x:1088,y:772,t:1527272074241};\\\", \\\"{x:1007,y:759,t:1527272074258};\\\", \\\"{x:929,y:737,t:1527272074275};\\\", \\\"{x:842,y:710,t:1527272074292};\\\", \\\"{x:763,y:689,t:1527272074307};\\\", \\\"{x:676,y:671,t:1527272074325};\\\", \\\"{x:625,y:661,t:1527272074341};\\\", \\\"{x:595,y:658,t:1527272074358};\\\", \\\"{x:572,y:653,t:1527272074374};\\\", \\\"{x:550,y:651,t:1527272074391};\\\", \\\"{x:534,y:647,t:1527272074408};\\\", \\\"{x:527,y:644,t:1527272074424};\\\", \\\"{x:526,y:644,t:1527272074441};\\\", \\\"{x:521,y:644,t:1527272074458};\\\", \\\"{x:517,y:643,t:1527272074474};\\\", \\\"{x:509,y:643,t:1527272074491};\\\", \\\"{x:490,y:634,t:1527272074508};\\\", \\\"{x:477,y:627,t:1527272074525};\\\", \\\"{x:464,y:620,t:1527272074541};\\\", \\\"{x:457,y:613,t:1527272074558};\\\", \\\"{x:454,y:607,t:1527272074572};\\\", \\\"{x:454,y:602,t:1527272074588};\\\", \\\"{x:455,y:596,t:1527272074605};\\\", \\\"{x:463,y:590,t:1527272074622};\\\", \\\"{x:480,y:581,t:1527272074640};\\\", \\\"{x:508,y:573,t:1527272074658};\\\", \\\"{x:553,y:566,t:1527272074674};\\\", \\\"{x:587,y:565,t:1527272074690};\\\", \\\"{x:612,y:565,t:1527272074707};\\\", \\\"{x:640,y:565,t:1527272074723};\\\", \\\"{x:649,y:565,t:1527272074740};\\\", \\\"{x:650,y:565,t:1527272074772};\\\", \\\"{x:650,y:566,t:1527272074780};\\\", \\\"{x:649,y:569,t:1527272074790};\\\", \\\"{x:644,y:573,t:1527272074807};\\\", \\\"{x:638,y:576,t:1527272074825};\\\", \\\"{x:632,y:580,t:1527272074840};\\\", \\\"{x:624,y:583,t:1527272074858};\\\", \\\"{x:620,y:587,t:1527272074874};\\\", \\\"{x:616,y:590,t:1527272074892};\\\", \\\"{x:614,y:591,t:1527272074907};\\\", \\\"{x:617,y:592,t:1527272074949};\\\", \\\"{x:621,y:592,t:1527272074957};\\\", \\\"{x:638,y:590,t:1527272074975};\\\", \\\"{x:677,y:585,t:1527272074990};\\\", \\\"{x:736,y:576,t:1527272075009};\\\", \\\"{x:791,y:570,t:1527272075024};\\\", \\\"{x:830,y:565,t:1527272075040};\\\", \\\"{x:847,y:563,t:1527272075057};\\\", \\\"{x:853,y:563,t:1527272075074};\\\", \\\"{x:853,y:561,t:1527272075165};\\\", \\\"{x:853,y:560,t:1527272075180};\\\", \\\"{x:852,y:560,t:1527272075317};\\\", \\\"{x:852,y:563,t:1527272075325};\\\", \\\"{x:852,y:566,t:1527272075342};\\\", \\\"{x:852,y:568,t:1527272075358};\\\", \\\"{x:852,y:569,t:1527272075374};\\\", \\\"{x:849,y:570,t:1527272075628};\\\", \\\"{x:841,y:570,t:1527272075641};\\\", \\\"{x:819,y:570,t:1527272075658};\\\", \\\"{x:772,y:570,t:1527272075674};\\\", \\\"{x:725,y:570,t:1527272075691};\\\", \\\"{x:671,y:570,t:1527272075708};\\\", \\\"{x:639,y:570,t:1527272075724};\\\", \\\"{x:617,y:570,t:1527272075741};\\\", \\\"{x:606,y:570,t:1527272075758};\\\", \\\"{x:604,y:570,t:1527272075775};\\\", \\\"{x:603,y:570,t:1527272075791};\\\", \\\"{x:602,y:570,t:1527272075808};\\\", \\\"{x:601,y:570,t:1527272075828};\\\", \\\"{x:599,y:571,t:1527272075853};\\\", \\\"{x:599,y:572,t:1527272075876};\\\", \\\"{x:598,y:572,t:1527272075892};\\\", \\\"{x:598,y:573,t:1527272075917};\\\", \\\"{x:598,y:577,t:1527272076228};\\\", \\\"{x:598,y:583,t:1527272076242};\\\", \\\"{x:598,y:594,t:1527272076260};\\\", \\\"{x:598,y:606,t:1527272076276};\\\", \\\"{x:598,y:629,t:1527272076292};\\\", \\\"{x:597,y:638,t:1527272076309};\\\", \\\"{x:597,y:642,t:1527272076325};\\\", \\\"{x:597,y:649,t:1527272076343};\\\", \\\"{x:597,y:652,t:1527272076358};\\\", \\\"{x:597,y:654,t:1527272076375};\\\", \\\"{x:597,y:657,t:1527272076392};\\\", \\\"{x:597,y:658,t:1527272076408};\\\", \\\"{x:597,y:659,t:1527272076426};\\\", \\\"{x:595,y:662,t:1527272076442};\\\", \\\"{x:590,y:663,t:1527272076458};\\\", \\\"{x:587,y:665,t:1527272076476};\\\", \\\"{x:583,y:666,t:1527272076491};\\\", \\\"{x:581,y:667,t:1527272076509};\\\", \\\"{x:580,y:661,t:1527272076556};\\\", \\\"{x:580,y:650,t:1527272076565};\\\", \\\"{x:580,y:641,t:1527272076575};\\\", \\\"{x:590,y:626,t:1527272076593};\\\", \\\"{x:603,y:613,t:1527272076609};\\\", \\\"{x:615,y:604,t:1527272076625};\\\", \\\"{x:623,y:597,t:1527272076643};\\\", \\\"{x:626,y:593,t:1527272076660};\\\", \\\"{x:629,y:590,t:1527272076675};\\\", \\\"{x:632,y:586,t:1527272076692};\\\", \\\"{x:632,y:585,t:1527272076788};\\\", \\\"{x:632,y:584,t:1527272076804};\\\", \\\"{x:632,y:583,t:1527272076812};\\\", \\\"{x:631,y:583,t:1527272076825};\\\", \\\"{x:629,y:582,t:1527272076842};\\\", \\\"{x:627,y:581,t:1527272076858};\\\", \\\"{x:623,y:580,t:1527272076875};\\\", \\\"{x:620,y:580,t:1527272076892};\\\", \\\"{x:617,y:578,t:1527272076909};\\\", \\\"{x:617,y:580,t:1527272077453};\\\", \\\"{x:616,y:584,t:1527272077460};\\\", \\\"{x:613,y:593,t:1527272077478};\\\", \\\"{x:612,y:603,t:1527272077493};\\\", \\\"{x:611,y:618,t:1527272077509};\\\", \\\"{x:606,y:635,t:1527272077527};\\\", \\\"{x:605,y:649,t:1527272077543};\\\", \\\"{x:603,y:661,t:1527272077559};\\\", \\\"{x:601,y:675,t:1527272077576};\\\", \\\"{x:600,y:687,t:1527272077593};\\\", \\\"{x:598,y:696,t:1527272077609};\\\", \\\"{x:598,y:702,t:1527272077626};\\\", \\\"{x:597,y:705,t:1527272077643};\\\", \\\"{x:597,y:706,t:1527272077659};\\\", \\\"{x:597,y:707,t:1527272077684};\\\", \\\"{x:597,y:708,t:1527272077732};\\\", \\\"{x:597,y:709,t:1527272077744};\\\", \\\"{x:595,y:712,t:1527272077759};\\\", \\\"{x:589,y:715,t:1527272077777};\\\", \\\"{x:575,y:717,t:1527272077793};\\\", \\\"{x:556,y:717,t:1527272077810};\\\", \\\"{x:540,y:717,t:1527272077826};\\\", \\\"{x:530,y:717,t:1527272077844};\\\", \\\"{x:526,y:717,t:1527272077859};\\\", \\\"{x:524,y:717,t:1527272077877};\\\", \\\"{x:522,y:718,t:1527272078037};\\\", \\\"{x:522,y:719,t:1527272078044};\\\", \\\"{x:521,y:721,t:1527272078062};\\\", \\\"{x:520,y:722,t:1527272078076};\\\", \\\"{x:519,y:723,t:1527272078093};\\\", \\\"{x:519,y:725,t:1527272078172};\\\", \\\"{x:519,y:726,t:1527272078203};\\\", \\\"{x:518,y:727,t:1527272079877};\\\", \\\"{x:516,y:727,t:1527272079884};\\\", \\\"{x:514,y:727,t:1527272079901};\\\", \\\"{x:513,y:727,t:1527272079915};\\\", \\\"{x:511,y:727,t:1527272079934};\\\", \\\"{x:510,y:727,t:1527272079948};\\\", \\\"{x:508,y:727,t:1527272079981};\\\", \\\"{x:507,y:727,t:1527272080077};\\\", \\\"{x:505,y:727,t:1527272080092};\\\", \\\"{x:504,y:727,t:1527272080101};\\\", \\\"{x:503,y:727,t:1527272080117};\\\", \\\"{x:502,y:727,t:1527272080356};\\\", \\\"{x:501,y:727,t:1527272080765};\\\", \\\"{x:500,y:727,t:1527272081052};\\\", \\\"{x:500,y:726,t:1527272081063};\\\", \\\"{x:500,y:723,t:1527272081084};\\\", \\\"{x:500,y:722,t:1527272081100};\\\" ] }, { \\\"rt\\\": 64549, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 436400, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"2WQ0M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-03 PM-04 PM-N -F -F -B -B -F -04 PM-B -X -04 PM-B -B -11 AM-11 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:498,y:720,t:1527272081624};\\\", \\\"{x:498,y:719,t:1527272081650};\\\", \\\"{x:498,y:717,t:1527272081663};\\\", \\\"{x:498,y:716,t:1527272081679};\\\", \\\"{x:497,y:713,t:1527272081696};\\\", \\\"{x:497,y:710,t:1527272081713};\\\", \\\"{x:494,y:706,t:1527272081730};\\\", \\\"{x:493,y:701,t:1527272081746};\\\", \\\"{x:486,y:684,t:1527272081764};\\\", \\\"{x:475,y:666,t:1527272081779};\\\", \\\"{x:463,y:651,t:1527272081797};\\\", \\\"{x:447,y:627,t:1527272081830};\\\", \\\"{x:437,y:612,t:1527272081845};\\\", \\\"{x:431,y:602,t:1527272081863};\\\", \\\"{x:427,y:592,t:1527272081879};\\\", \\\"{x:418,y:580,t:1527272081896};\\\", \\\"{x:411,y:568,t:1527272081913};\\\", \\\"{x:406,y:554,t:1527272081930};\\\", \\\"{x:404,y:548,t:1527272081946};\\\", \\\"{x:403,y:538,t:1527272081963};\\\", \\\"{x:402,y:530,t:1527272081979};\\\", \\\"{x:401,y:524,t:1527272081997};\\\", \\\"{x:400,y:518,t:1527272082013};\\\", \\\"{x:399,y:514,t:1527272082029};\\\", \\\"{x:397,y:510,t:1527272082046};\\\", \\\"{x:395,y:507,t:1527272082064};\\\", \\\"{x:394,y:505,t:1527272082080};\\\", \\\"{x:394,y:503,t:1527272082096};\\\", \\\"{x:392,y:501,t:1527272082113};\\\", \\\"{x:392,y:500,t:1527272082189};\\\", \\\"{x:390,y:498,t:1527272082217};\\\", \\\"{x:388,y:497,t:1527272082231};\\\", \\\"{x:388,y:496,t:1527272083061};\\\", \\\"{x:389,y:495,t:1527272083068};\\\", \\\"{x:391,y:495,t:1527272083084};\\\", \\\"{x:392,y:494,t:1527272083099};\\\", \\\"{x:394,y:493,t:1527272083115};\\\", \\\"{x:395,y:492,t:1527272083140};\\\", \\\"{x:396,y:491,t:1527272083172};\\\", \\\"{x:397,y:491,t:1527272083188};\\\", \\\"{x:398,y:490,t:1527272083203};\\\", \\\"{x:399,y:490,t:1527272083220};\\\", \\\"{x:401,y:489,t:1527272083233};\\\", \\\"{x:402,y:488,t:1527272083250};\\\", \\\"{x:404,y:486,t:1527272083266};\\\", \\\"{x:407,y:484,t:1527272083280};\\\", \\\"{x:409,y:482,t:1527272083297};\\\", \\\"{x:413,y:480,t:1527272083313};\\\", \\\"{x:423,y:476,t:1527272083329};\\\", \\\"{x:441,y:469,t:1527272083347};\\\", \\\"{x:478,y:459,t:1527272083364};\\\", \\\"{x:522,y:453,t:1527272083379};\\\", \\\"{x:589,y:444,t:1527272083396};\\\", \\\"{x:669,y:444,t:1527272083414};\\\", \\\"{x:764,y:444,t:1527272083430};\\\", \\\"{x:869,y:444,t:1527272083447};\\\", \\\"{x:985,y:455,t:1527272083463};\\\", \\\"{x:1124,y:486,t:1527272083479};\\\", \\\"{x:1261,y:514,t:1527272083496};\\\", \\\"{x:1358,y:541,t:1527272083514};\\\", \\\"{x:1446,y:578,t:1527272083530};\\\", \\\"{x:1456,y:588,t:1527272083547};\\\", \\\"{x:1463,y:595,t:1527272083564};\\\", \\\"{x:1463,y:596,t:1527272083580};\\\", \\\"{x:1455,y:604,t:1527272083661};\\\", \\\"{x:1444,y:609,t:1527272083669};\\\", \\\"{x:1437,y:610,t:1527272083680};\\\", \\\"{x:1425,y:615,t:1527272083697};\\\", \\\"{x:1409,y:623,t:1527272083713};\\\", \\\"{x:1398,y:628,t:1527272083730};\\\", \\\"{x:1391,y:630,t:1527272083748};\\\", \\\"{x:1387,y:632,t:1527272083764};\\\", \\\"{x:1383,y:634,t:1527272083780};\\\", \\\"{x:1382,y:635,t:1527272083797};\\\", \\\"{x:1380,y:637,t:1527272083813};\\\", \\\"{x:1377,y:639,t:1527272083830};\\\", \\\"{x:1375,y:640,t:1527272083848};\\\", \\\"{x:1372,y:642,t:1527272083863};\\\", \\\"{x:1370,y:644,t:1527272083880};\\\", \\\"{x:1367,y:646,t:1527272083897};\\\", \\\"{x:1365,y:646,t:1527272083912};\\\", \\\"{x:1363,y:648,t:1527272083930};\\\", \\\"{x:1361,y:649,t:1527272083947};\\\", \\\"{x:1360,y:649,t:1527272083972};\\\", \\\"{x:1359,y:649,t:1527272083979};\\\", \\\"{x:1358,y:649,t:1527272084245};\\\", \\\"{x:1357,y:648,t:1527272084509};\\\", \\\"{x:1356,y:648,t:1527272086052};\\\", \\\"{x:1355,y:648,t:1527272086100};\\\", \\\"{x:1354,y:648,t:1527272086245};\\\", \\\"{x:1353,y:646,t:1527272088693};\\\", \\\"{x:1357,y:637,t:1527272088700};\\\", \\\"{x:1365,y:628,t:1527272088712};\\\", \\\"{x:1383,y:610,t:1527272088729};\\\", \\\"{x:1400,y:594,t:1527272088746};\\\", \\\"{x:1412,y:583,t:1527272088763};\\\", \\\"{x:1416,y:578,t:1527272088779};\\\", \\\"{x:1417,y:574,t:1527272088795};\\\", \\\"{x:1418,y:573,t:1527272088812};\\\", \\\"{x:1419,y:572,t:1527272088836};\\\", \\\"{x:1420,y:571,t:1527272088846};\\\", \\\"{x:1421,y:570,t:1527272088863};\\\", \\\"{x:1423,y:568,t:1527272088880};\\\", \\\"{x:1427,y:564,t:1527272088895};\\\", \\\"{x:1432,y:559,t:1527272088912};\\\", \\\"{x:1436,y:555,t:1527272088930};\\\", \\\"{x:1441,y:551,t:1527272088945};\\\", \\\"{x:1444,y:547,t:1527272088962};\\\", \\\"{x:1450,y:543,t:1527272088979};\\\", \\\"{x:1457,y:537,t:1527272088996};\\\", \\\"{x:1464,y:529,t:1527272089013};\\\", \\\"{x:1467,y:522,t:1527272089029};\\\", \\\"{x:1473,y:496,t:1527272089046};\\\", \\\"{x:1505,y:401,t:1527272089063};\\\", \\\"{x:1512,y:378,t:1527272089080};\\\", \\\"{x:1513,y:373,t:1527272089095};\\\", \\\"{x:1513,y:371,t:1527272089112};\\\", \\\"{x:1513,y:370,t:1527272089130};\\\", \\\"{x:1513,y:369,t:1527272089145};\\\", \\\"{x:1512,y:368,t:1527272089163};\\\", \\\"{x:1508,y:365,t:1527272089180};\\\", \\\"{x:1502,y:362,t:1527272089195};\\\", \\\"{x:1496,y:359,t:1527272089212};\\\", \\\"{x:1491,y:358,t:1527272089229};\\\", \\\"{x:1480,y:353,t:1527272089245};\\\", \\\"{x:1466,y:341,t:1527272089262};\\\", \\\"{x:1453,y:330,t:1527272089279};\\\", \\\"{x:1453,y:329,t:1527272089295};\\\", \\\"{x:1452,y:328,t:1527272089645};\\\", \\\"{x:1453,y:328,t:1527272089663};\\\", \\\"{x:1454,y:328,t:1527272089680};\\\", \\\"{x:1458,y:328,t:1527272089696};\\\", \\\"{x:1462,y:328,t:1527272089713};\\\", \\\"{x:1469,y:328,t:1527272089729};\\\", \\\"{x:1476,y:328,t:1527272089745};\\\", \\\"{x:1485,y:328,t:1527272089762};\\\", \\\"{x:1498,y:332,t:1527272089780};\\\", \\\"{x:1512,y:336,t:1527272089795};\\\", \\\"{x:1531,y:342,t:1527272089812};\\\", \\\"{x:1541,y:344,t:1527272089828};\\\", \\\"{x:1546,y:346,t:1527272089846};\\\", \\\"{x:1548,y:347,t:1527272089862};\\\", \\\"{x:1549,y:349,t:1527272089908};\\\", \\\"{x:1551,y:352,t:1527272089924};\\\", \\\"{x:1555,y:355,t:1527272089932};\\\", \\\"{x:1555,y:358,t:1527272089946};\\\", \\\"{x:1561,y:365,t:1527272089963};\\\", \\\"{x:1570,y:370,t:1527272089980};\\\", \\\"{x:1571,y:371,t:1527272089995};\\\", \\\"{x:1573,y:371,t:1527272090013};\\\", \\\"{x:1575,y:371,t:1527272090028};\\\", \\\"{x:1576,y:371,t:1527272090046};\\\", \\\"{x:1578,y:371,t:1527272090062};\\\", \\\"{x:1580,y:371,t:1527272090078};\\\", \\\"{x:1583,y:371,t:1527272090095};\\\", \\\"{x:1584,y:371,t:1527272090112};\\\", \\\"{x:1585,y:372,t:1527272090228};\\\", \\\"{x:1585,y:374,t:1527272090245};\\\", \\\"{x:1585,y:377,t:1527272090262};\\\", \\\"{x:1585,y:378,t:1527272090278};\\\", \\\"{x:1585,y:379,t:1527272090295};\\\", \\\"{x:1585,y:380,t:1527272090312};\\\", \\\"{x:1582,y:380,t:1527272091092};\\\", \\\"{x:1575,y:380,t:1527272091100};\\\", \\\"{x:1568,y:380,t:1527272091113};\\\", \\\"{x:1545,y:380,t:1527272091129};\\\", \\\"{x:1518,y:380,t:1527272091145};\\\", \\\"{x:1485,y:380,t:1527272091163};\\\", \\\"{x:1458,y:380,t:1527272091179};\\\", \\\"{x:1436,y:380,t:1527272091196};\\\", \\\"{x:1416,y:383,t:1527272091212};\\\", \\\"{x:1413,y:383,t:1527272091228};\\\", \\\"{x:1408,y:385,t:1527272091245};\\\", \\\"{x:1403,y:388,t:1527272091263};\\\", \\\"{x:1390,y:395,t:1527272091278};\\\", \\\"{x:1373,y:409,t:1527272091296};\\\", \\\"{x:1348,y:430,t:1527272091312};\\\", \\\"{x:1329,y:454,t:1527272091329};\\\", \\\"{x:1299,y:494,t:1527272091345};\\\", \\\"{x:1277,y:532,t:1527272091361};\\\", \\\"{x:1257,y:570,t:1527272091378};\\\", \\\"{x:1245,y:611,t:1527272091395};\\\", \\\"{x:1238,y:651,t:1527272091410};\\\", \\\"{x:1238,y:719,t:1527272091428};\\\", \\\"{x:1250,y:771,t:1527272091445};\\\", \\\"{x:1271,y:818,t:1527272091461};\\\", \\\"{x:1289,y:852,t:1527272091478};\\\", \\\"{x:1305,y:871,t:1527272091495};\\\", \\\"{x:1329,y:898,t:1527272091511};\\\", \\\"{x:1351,y:922,t:1527272091528};\\\", \\\"{x:1380,y:943,t:1527272091545};\\\", \\\"{x:1409,y:958,t:1527272091561};\\\", \\\"{x:1433,y:965,t:1527272091578};\\\", \\\"{x:1462,y:969,t:1527272091595};\\\", \\\"{x:1490,y:970,t:1527272091611};\\\", \\\"{x:1531,y:970,t:1527272091628};\\\", \\\"{x:1557,y:970,t:1527272091644};\\\", \\\"{x:1581,y:970,t:1527272091661};\\\", \\\"{x:1610,y:970,t:1527272091679};\\\", \\\"{x:1640,y:968,t:1527272091696};\\\", \\\"{x:1667,y:961,t:1527272091711};\\\", \\\"{x:1689,y:953,t:1527272091728};\\\", \\\"{x:1702,y:947,t:1527272091745};\\\", \\\"{x:1710,y:941,t:1527272091761};\\\", \\\"{x:1713,y:937,t:1527272091778};\\\", \\\"{x:1714,y:930,t:1527272091795};\\\", \\\"{x:1714,y:926,t:1527272091812};\\\", \\\"{x:1714,y:920,t:1527272091828};\\\", \\\"{x:1714,y:918,t:1527272091845};\\\", \\\"{x:1713,y:915,t:1527272091861};\\\", \\\"{x:1709,y:910,t:1527272091878};\\\", \\\"{x:1707,y:906,t:1527272091895};\\\", \\\"{x:1704,y:900,t:1527272091911};\\\", \\\"{x:1700,y:891,t:1527272091927};\\\", \\\"{x:1698,y:878,t:1527272091945};\\\", \\\"{x:1695,y:871,t:1527272091960};\\\", \\\"{x:1695,y:868,t:1527272091978};\\\", \\\"{x:1695,y:864,t:1527272091995};\\\", \\\"{x:1695,y:859,t:1527272092010};\\\", \\\"{x:1695,y:853,t:1527272092028};\\\", \\\"{x:1695,y:848,t:1527272092045};\\\", \\\"{x:1694,y:846,t:1527272092061};\\\", \\\"{x:1694,y:844,t:1527272092078};\\\", \\\"{x:1694,y:842,t:1527272092095};\\\", \\\"{x:1694,y:841,t:1527272092111};\\\", \\\"{x:1694,y:839,t:1527272092128};\\\", \\\"{x:1692,y:837,t:1527272092145};\\\", \\\"{x:1687,y:833,t:1527272092161};\\\", \\\"{x:1680,y:828,t:1527272092180};\\\", \\\"{x:1673,y:822,t:1527272092196};\\\", \\\"{x:1664,y:814,t:1527272092211};\\\", \\\"{x:1648,y:785,t:1527272092228};\\\", \\\"{x:1641,y:757,t:1527272092245};\\\", \\\"{x:1628,y:720,t:1527272092261};\\\", \\\"{x:1621,y:695,t:1527272092278};\\\", \\\"{x:1611,y:668,t:1527272092295};\\\", \\\"{x:1600,y:644,t:1527272092311};\\\", \\\"{x:1590,y:625,t:1527272092328};\\\", \\\"{x:1586,y:615,t:1527272092346};\\\", \\\"{x:1583,y:605,t:1527272092361};\\\", \\\"{x:1580,y:594,t:1527272092378};\\\", \\\"{x:1578,y:586,t:1527272092396};\\\", \\\"{x:1575,y:577,t:1527272092412};\\\", \\\"{x:1567,y:559,t:1527272092428};\\\", \\\"{x:1555,y:544,t:1527272092445};\\\", \\\"{x:1539,y:528,t:1527272092461};\\\", \\\"{x:1523,y:513,t:1527272092478};\\\", \\\"{x:1509,y:501,t:1527272092496};\\\", \\\"{x:1490,y:488,t:1527272092512};\\\", \\\"{x:1475,y:478,t:1527272092528};\\\", \\\"{x:1462,y:470,t:1527272092545};\\\", \\\"{x:1455,y:464,t:1527272092561};\\\", \\\"{x:1450,y:461,t:1527272092578};\\\", \\\"{x:1447,y:460,t:1527272092594};\\\", \\\"{x:1446,y:459,t:1527272092611};\\\", \\\"{x:1445,y:458,t:1527272092676};\\\", \\\"{x:1444,y:457,t:1527272092691};\\\", \\\"{x:1443,y:456,t:1527272092699};\\\", \\\"{x:1442,y:455,t:1527272092716};\\\", \\\"{x:1441,y:454,t:1527272092728};\\\", \\\"{x:1438,y:453,t:1527272092744};\\\", \\\"{x:1434,y:450,t:1527272092761};\\\", \\\"{x:1432,y:449,t:1527272092778};\\\", \\\"{x:1429,y:448,t:1527272092793};\\\", \\\"{x:1426,y:447,t:1527272092811};\\\", \\\"{x:1422,y:446,t:1527272092828};\\\", \\\"{x:1420,y:444,t:1527272092845};\\\", \\\"{x:1419,y:444,t:1527272092892};\\\", \\\"{x:1417,y:444,t:1527272092908};\\\", \\\"{x:1415,y:444,t:1527272092917};\\\", \\\"{x:1413,y:447,t:1527272092928};\\\", \\\"{x:1411,y:452,t:1527272092944};\\\", \\\"{x:1410,y:456,t:1527272092962};\\\", \\\"{x:1409,y:462,t:1527272092979};\\\", \\\"{x:1408,y:468,t:1527272092995};\\\", \\\"{x:1407,y:479,t:1527272093011};\\\", \\\"{x:1399,y:499,t:1527272093028};\\\", \\\"{x:1396,y:511,t:1527272093045};\\\", \\\"{x:1391,y:524,t:1527272093062};\\\", \\\"{x:1387,y:536,t:1527272093078};\\\", \\\"{x:1382,y:552,t:1527272093095};\\\", \\\"{x:1380,y:563,t:1527272093111};\\\", \\\"{x:1377,y:575,t:1527272093129};\\\", \\\"{x:1373,y:589,t:1527272093144};\\\", \\\"{x:1367,y:605,t:1527272093162};\\\", \\\"{x:1365,y:620,t:1527272093178};\\\", \\\"{x:1360,y:636,t:1527272093195};\\\", \\\"{x:1357,y:647,t:1527272093211};\\\", \\\"{x:1353,y:661,t:1527272093228};\\\", \\\"{x:1352,y:668,t:1527272093244};\\\", \\\"{x:1352,y:671,t:1527272093262};\\\", \\\"{x:1350,y:677,t:1527272093278};\\\", \\\"{x:1348,y:681,t:1527272093295};\\\", \\\"{x:1348,y:688,t:1527272093312};\\\", \\\"{x:1345,y:692,t:1527272093329};\\\", \\\"{x:1345,y:698,t:1527272093344};\\\", \\\"{x:1345,y:704,t:1527272093362};\\\", \\\"{x:1344,y:707,t:1527272093378};\\\", \\\"{x:1344,y:711,t:1527272093394};\\\", \\\"{x:1344,y:715,t:1527272093411};\\\", \\\"{x:1344,y:734,t:1527272093427};\\\", \\\"{x:1344,y:749,t:1527272093444};\\\", \\\"{x:1344,y:762,t:1527272093461};\\\", \\\"{x:1344,y:767,t:1527272093478};\\\", \\\"{x:1344,y:769,t:1527272093494};\\\", \\\"{x:1344,y:772,t:1527272096044};\\\", \\\"{x:1344,y:781,t:1527272096061};\\\", \\\"{x:1338,y:792,t:1527272096077};\\\", \\\"{x:1331,y:805,t:1527272096095};\\\", \\\"{x:1325,y:819,t:1527272096111};\\\", \\\"{x:1320,y:829,t:1527272096127};\\\", \\\"{x:1316,y:835,t:1527272096144};\\\", \\\"{x:1311,y:844,t:1527272096161};\\\", \\\"{x:1306,y:850,t:1527272096177};\\\", \\\"{x:1299,y:861,t:1527272096195};\\\", \\\"{x:1290,y:876,t:1527272096210};\\\", \\\"{x:1282,y:889,t:1527272096227};\\\", \\\"{x:1271,y:908,t:1527272096244};\\\", \\\"{x:1267,y:917,t:1527272096261};\\\", \\\"{x:1262,y:928,t:1527272096277};\\\", \\\"{x:1260,y:935,t:1527272096295};\\\", \\\"{x:1258,y:939,t:1527272096310};\\\", \\\"{x:1257,y:941,t:1527272096327};\\\", \\\"{x:1257,y:943,t:1527272096345};\\\", \\\"{x:1257,y:944,t:1527272096361};\\\", \\\"{x:1257,y:945,t:1527272096378};\\\", \\\"{x:1256,y:947,t:1527272096394};\\\", \\\"{x:1256,y:948,t:1527272096477};\\\", \\\"{x:1256,y:949,t:1527272096500};\\\", \\\"{x:1256,y:950,t:1527272096517};\\\", \\\"{x:1256,y:951,t:1527272096528};\\\", \\\"{x:1255,y:953,t:1527272096548};\\\", \\\"{x:1254,y:953,t:1527272096573};\\\", \\\"{x:1254,y:954,t:1527272096613};\\\", \\\"{x:1253,y:954,t:1527272096636};\\\", \\\"{x:1253,y:955,t:1527272096652};\\\", \\\"{x:1252,y:955,t:1527272096772};\\\", \\\"{x:1252,y:956,t:1527272096805};\\\", \\\"{x:1250,y:957,t:1527272096821};\\\", \\\"{x:1249,y:957,t:1527272096844};\\\", \\\"{x:1249,y:958,t:1527272096861};\\\", \\\"{x:1248,y:958,t:1527272096877};\\\", \\\"{x:1247,y:960,t:1527272096916};\\\", \\\"{x:1248,y:960,t:1527272103445};\\\", \\\"{x:1258,y:960,t:1527272103459};\\\", \\\"{x:1310,y:960,t:1527272103476};\\\", \\\"{x:1363,y:960,t:1527272103493};\\\", \\\"{x:1408,y:960,t:1527272103509};\\\", \\\"{x:1453,y:960,t:1527272103526};\\\", \\\"{x:1477,y:960,t:1527272103543};\\\", \\\"{x:1499,y:964,t:1527272103559};\\\", \\\"{x:1512,y:965,t:1527272103577};\\\", \\\"{x:1517,y:965,t:1527272103593};\\\", \\\"{x:1521,y:965,t:1527272103608};\\\", \\\"{x:1526,y:967,t:1527272103626};\\\", \\\"{x:1528,y:967,t:1527272103643};\\\", \\\"{x:1534,y:968,t:1527272103659};\\\", \\\"{x:1545,y:968,t:1527272103676};\\\", \\\"{x:1558,y:968,t:1527272103692};\\\", \\\"{x:1573,y:968,t:1527272103709};\\\", \\\"{x:1589,y:968,t:1527272103726};\\\", \\\"{x:1607,y:968,t:1527272103743};\\\", \\\"{x:1618,y:967,t:1527272103759};\\\", \\\"{x:1625,y:966,t:1527272103776};\\\", \\\"{x:1630,y:965,t:1527272103793};\\\", \\\"{x:1634,y:965,t:1527272103809};\\\", \\\"{x:1639,y:965,t:1527272103826};\\\", \\\"{x:1640,y:965,t:1527272103843};\\\", \\\"{x:1641,y:965,t:1527272103859};\\\", \\\"{x:1641,y:964,t:1527272103979};\\\", \\\"{x:1641,y:963,t:1527272103995};\\\", \\\"{x:1640,y:963,t:1527272104009};\\\", \\\"{x:1639,y:963,t:1527272104026};\\\", \\\"{x:1638,y:963,t:1527272104043};\\\", \\\"{x:1637,y:963,t:1527272104058};\\\", \\\"{x:1637,y:962,t:1527272104092};\\\", \\\"{x:1636,y:962,t:1527272104524};\\\", \\\"{x:1636,y:961,t:1527272104548};\\\", \\\"{x:1636,y:960,t:1527272104580};\\\", \\\"{x:1634,y:959,t:1527272104893};\\\", \\\"{x:1632,y:959,t:1527272104909};\\\", \\\"{x:1628,y:959,t:1527272104926};\\\", \\\"{x:1626,y:959,t:1527272104942};\\\", \\\"{x:1621,y:959,t:1527272104959};\\\", \\\"{x:1619,y:959,t:1527272104976};\\\", \\\"{x:1617,y:959,t:1527272104992};\\\", \\\"{x:1616,y:959,t:1527272105009};\\\", \\\"{x:1615,y:959,t:1527272105045};\\\", \\\"{x:1614,y:959,t:1527272112404};\\\", \\\"{x:1614,y:960,t:1527272112411};\\\", \\\"{x:1613,y:961,t:1527272112424};\\\", \\\"{x:1612,y:961,t:1527272114501};\\\", \\\"{x:1609,y:959,t:1527272114508};\\\", \\\"{x:1603,y:955,t:1527272114523};\\\", \\\"{x:1583,y:940,t:1527272114540};\\\", \\\"{x:1569,y:929,t:1527272114557};\\\", \\\"{x:1553,y:917,t:1527272114574};\\\", \\\"{x:1540,y:907,t:1527272114590};\\\", \\\"{x:1536,y:903,t:1527272114606};\\\", \\\"{x:1533,y:900,t:1527272114623};\\\", \\\"{x:1531,y:898,t:1527272114641};\\\", \\\"{x:1528,y:894,t:1527272114656};\\\", \\\"{x:1526,y:890,t:1527272114673};\\\", \\\"{x:1524,y:885,t:1527272114691};\\\", \\\"{x:1520,y:881,t:1527272114706};\\\", \\\"{x:1513,y:876,t:1527272114724};\\\", \\\"{x:1494,y:865,t:1527272114740};\\\", \\\"{x:1474,y:856,t:1527272114756};\\\", \\\"{x:1457,y:849,t:1527272114773};\\\", \\\"{x:1442,y:844,t:1527272114791};\\\", \\\"{x:1429,y:838,t:1527272114806};\\\", \\\"{x:1421,y:831,t:1527272114824};\\\", \\\"{x:1415,y:824,t:1527272114841};\\\", \\\"{x:1410,y:811,t:1527272114856};\\\", \\\"{x:1393,y:774,t:1527272114874};\\\", \\\"{x:1380,y:752,t:1527272114890};\\\", \\\"{x:1375,y:739,t:1527272114907};\\\", \\\"{x:1370,y:731,t:1527272114923};\\\", \\\"{x:1367,y:720,t:1527272114940};\\\", \\\"{x:1366,y:718,t:1527272114956};\\\", \\\"{x:1366,y:717,t:1527272114973};\\\", \\\"{x:1366,y:715,t:1527272114996};\\\", \\\"{x:1366,y:714,t:1527272115212};\\\", \\\"{x:1365,y:714,t:1527272115228};\\\", \\\"{x:1364,y:712,t:1527272115244};\\\", \\\"{x:1363,y:710,t:1527272115260};\\\", \\\"{x:1362,y:710,t:1527272115273};\\\", \\\"{x:1359,y:707,t:1527272115291};\\\", \\\"{x:1358,y:706,t:1527272115306};\\\", \\\"{x:1357,y:705,t:1527272115324};\\\", \\\"{x:1356,y:705,t:1527272115340};\\\", \\\"{x:1355,y:704,t:1527272115357};\\\", \\\"{x:1354,y:703,t:1527272115374};\\\", \\\"{x:1353,y:703,t:1527272115461};\\\", \\\"{x:1353,y:704,t:1527272115540};\\\", \\\"{x:1353,y:712,t:1527272115556};\\\", \\\"{x:1353,y:717,t:1527272115573};\\\", \\\"{x:1353,y:724,t:1527272115590};\\\", \\\"{x:1355,y:733,t:1527272115606};\\\", \\\"{x:1360,y:749,t:1527272115623};\\\", \\\"{x:1367,y:772,t:1527272115639};\\\", \\\"{x:1376,y:795,t:1527272115655};\\\", \\\"{x:1383,y:812,t:1527272115673};\\\", \\\"{x:1393,y:830,t:1527272115690};\\\", \\\"{x:1401,y:845,t:1527272115706};\\\", \\\"{x:1407,y:856,t:1527272115723};\\\", \\\"{x:1415,y:867,t:1527272115740};\\\", \\\"{x:1421,y:876,t:1527272115756};\\\", \\\"{x:1424,y:880,t:1527272115773};\\\", \\\"{x:1426,y:884,t:1527272115789};\\\", \\\"{x:1428,y:888,t:1527272115806};\\\", \\\"{x:1429,y:889,t:1527272115823};\\\", \\\"{x:1430,y:891,t:1527272115840};\\\", \\\"{x:1430,y:892,t:1527272115868};\\\", \\\"{x:1431,y:893,t:1527272116004};\\\", \\\"{x:1432,y:894,t:1527272116012};\\\", \\\"{x:1433,y:895,t:1527272116024};\\\", \\\"{x:1438,y:898,t:1527272116040};\\\", \\\"{x:1449,y:902,t:1527272116057};\\\", \\\"{x:1458,y:906,t:1527272116074};\\\", \\\"{x:1467,y:909,t:1527272116089};\\\", \\\"{x:1470,y:911,t:1527272116106};\\\", \\\"{x:1478,y:915,t:1527272116123};\\\", \\\"{x:1483,y:919,t:1527272116140};\\\", \\\"{x:1491,y:923,t:1527272116156};\\\", \\\"{x:1497,y:927,t:1527272116174};\\\", \\\"{x:1501,y:928,t:1527272116189};\\\", \\\"{x:1504,y:930,t:1527272116206};\\\", \\\"{x:1506,y:930,t:1527272116223};\\\", \\\"{x:1510,y:932,t:1527272116239};\\\", \\\"{x:1517,y:934,t:1527272116256};\\\", \\\"{x:1527,y:935,t:1527272116273};\\\", \\\"{x:1537,y:938,t:1527272116289};\\\", \\\"{x:1546,y:939,t:1527272116306};\\\", \\\"{x:1552,y:940,t:1527272116323};\\\", \\\"{x:1556,y:940,t:1527272116339};\\\", \\\"{x:1557,y:940,t:1527272116420};\\\", \\\"{x:1557,y:938,t:1527272116428};\\\", \\\"{x:1552,y:936,t:1527272116439};\\\", \\\"{x:1537,y:927,t:1527272116456};\\\", \\\"{x:1513,y:917,t:1527272116473};\\\", \\\"{x:1481,y:909,t:1527272116489};\\\", \\\"{x:1442,y:899,t:1527272116506};\\\", \\\"{x:1392,y:891,t:1527272116524};\\\", \\\"{x:1330,y:881,t:1527272116539};\\\", \\\"{x:1212,y:866,t:1527272116556};\\\", \\\"{x:1139,y:864,t:1527272116573};\\\", \\\"{x:1072,y:854,t:1527272116589};\\\", \\\"{x:1000,y:845,t:1527272116606};\\\", \\\"{x:936,y:835,t:1527272116623};\\\", \\\"{x:877,y:818,t:1527272116639};\\\", \\\"{x:818,y:800,t:1527272116656};\\\", \\\"{x:771,y:778,t:1527272116673};\\\", \\\"{x:714,y:749,t:1527272116689};\\\", \\\"{x:688,y:714,t:1527272116705};\\\", \\\"{x:672,y:693,t:1527272116723};\\\", \\\"{x:657,y:669,t:1527272116739};\\\", \\\"{x:637,y:630,t:1527272116756};\\\", \\\"{x:628,y:607,t:1527272116773};\\\", \\\"{x:612,y:581,t:1527272116789};\\\", \\\"{x:599,y:555,t:1527272116810};\\\", \\\"{x:593,y:543,t:1527272116825};\\\", \\\"{x:591,y:539,t:1527272116842};\\\", \\\"{x:590,y:538,t:1527272116899};\\\", \\\"{x:589,y:538,t:1527272116908};\\\", \\\"{x:587,y:538,t:1527272116925};\\\", \\\"{x:585,y:538,t:1527272116942};\\\", \\\"{x:583,y:538,t:1527272116963};\\\", \\\"{x:583,y:539,t:1527272116987};\\\", \\\"{x:583,y:540,t:1527272117011};\\\", \\\"{x:583,y:541,t:1527272117027};\\\", \\\"{x:584,y:543,t:1527272117042};\\\", \\\"{x:586,y:543,t:1527272117058};\\\", \\\"{x:589,y:543,t:1527272117075};\\\", \\\"{x:592,y:543,t:1527272117091};\\\", \\\"{x:601,y:542,t:1527272117112};\\\", \\\"{x:615,y:541,t:1527272117124};\\\", \\\"{x:643,y:536,t:1527272117142};\\\", \\\"{x:670,y:535,t:1527272117158};\\\", \\\"{x:699,y:534,t:1527272117176};\\\", \\\"{x:727,y:534,t:1527272117193};\\\", \\\"{x:753,y:534,t:1527272117209};\\\", \\\"{x:778,y:538,t:1527272117225};\\\", \\\"{x:804,y:542,t:1527272117242};\\\", \\\"{x:820,y:547,t:1527272117259};\\\", \\\"{x:832,y:550,t:1527272117276};\\\", \\\"{x:838,y:552,t:1527272117292};\\\", \\\"{x:840,y:553,t:1527272117308};\\\", \\\"{x:841,y:553,t:1527272117339};\\\", \\\"{x:841,y:554,t:1527272117355};\\\", \\\"{x:843,y:553,t:1527272117524};\\\", \\\"{x:843,y:552,t:1527272117532};\\\", \\\"{x:849,y:551,t:1527272117772};\\\", \\\"{x:857,y:551,t:1527272117780};\\\", \\\"{x:870,y:551,t:1527272117793};\\\", \\\"{x:908,y:551,t:1527272117810};\\\", \\\"{x:983,y:551,t:1527272117827};\\\", \\\"{x:1137,y:570,t:1527272117843};\\\", \\\"{x:1252,y:578,t:1527272117859};\\\", \\\"{x:1349,y:589,t:1527272117876};\\\", \\\"{x:1426,y:589,t:1527272117893};\\\", \\\"{x:1468,y:589,t:1527272117910};\\\", \\\"{x:1496,y:589,t:1527272117926};\\\", \\\"{x:1507,y:589,t:1527272117943};\\\", \\\"{x:1509,y:589,t:1527272117960};\\\", \\\"{x:1510,y:589,t:1527272118012};\\\", \\\"{x:1511,y:589,t:1527272118027};\\\", \\\"{x:1514,y:588,t:1527272118043};\\\", \\\"{x:1516,y:587,t:1527272118060};\\\", \\\"{x:1517,y:586,t:1527272118092};\\\", \\\"{x:1516,y:586,t:1527272118140};\\\", \\\"{x:1509,y:586,t:1527272118148};\\\", \\\"{x:1502,y:584,t:1527272118161};\\\", \\\"{x:1488,y:582,t:1527272118177};\\\", \\\"{x:1478,y:581,t:1527272118193};\\\", \\\"{x:1470,y:579,t:1527272118210};\\\", \\\"{x:1468,y:579,t:1527272118228};\\\", \\\"{x:1467,y:579,t:1527272118243};\\\", \\\"{x:1466,y:579,t:1527272118309};\\\", \\\"{x:1464,y:579,t:1527272118316};\\\", \\\"{x:1462,y:579,t:1527272118332};\\\", \\\"{x:1461,y:579,t:1527272118343};\\\", \\\"{x:1457,y:578,t:1527272118360};\\\", \\\"{x:1456,y:578,t:1527272118378};\\\", \\\"{x:1454,y:578,t:1527272118393};\\\", \\\"{x:1453,y:578,t:1527272118410};\\\", \\\"{x:1449,y:577,t:1527272118428};\\\", \\\"{x:1446,y:577,t:1527272118443};\\\", \\\"{x:1441,y:575,t:1527272118461};\\\", \\\"{x:1436,y:575,t:1527272118477};\\\", \\\"{x:1433,y:574,t:1527272118494};\\\", \\\"{x:1430,y:574,t:1527272118511};\\\", \\\"{x:1428,y:574,t:1527272118528};\\\", \\\"{x:1426,y:574,t:1527272118543};\\\", \\\"{x:1421,y:574,t:1527272118561};\\\", \\\"{x:1414,y:574,t:1527272118578};\\\", \\\"{x:1405,y:578,t:1527272118594};\\\", \\\"{x:1388,y:590,t:1527272118610};\\\", \\\"{x:1368,y:609,t:1527272118628};\\\", \\\"{x:1356,y:623,t:1527272118643};\\\", \\\"{x:1344,y:638,t:1527272118660};\\\", \\\"{x:1336,y:649,t:1527272118677};\\\", \\\"{x:1329,y:660,t:1527272118694};\\\", \\\"{x:1325,y:669,t:1527272118711};\\\", \\\"{x:1321,y:676,t:1527272118727};\\\", \\\"{x:1316,y:688,t:1527272118744};\\\", \\\"{x:1313,y:694,t:1527272118760};\\\", \\\"{x:1312,y:700,t:1527272118777};\\\", \\\"{x:1311,y:704,t:1527272118795};\\\", \\\"{x:1311,y:707,t:1527272118810};\\\", \\\"{x:1312,y:708,t:1527272118827};\\\", \\\"{x:1314,y:710,t:1527272118844};\\\", \\\"{x:1315,y:711,t:1527272118861};\\\", \\\"{x:1317,y:711,t:1527272118877};\\\", \\\"{x:1321,y:712,t:1527272118894};\\\", \\\"{x:1324,y:712,t:1527272118910};\\\", \\\"{x:1327,y:713,t:1527272118928};\\\", \\\"{x:1328,y:713,t:1527272118945};\\\", \\\"{x:1332,y:716,t:1527272118960};\\\", \\\"{x:1335,y:718,t:1527272118977};\\\", \\\"{x:1337,y:718,t:1527272118994};\\\", \\\"{x:1339,y:719,t:1527272119011};\\\", \\\"{x:1340,y:719,t:1527272119044};\\\", \\\"{x:1342,y:718,t:1527272119061};\\\", \\\"{x:1342,y:714,t:1527272119078};\\\", \\\"{x:1343,y:709,t:1527272119095};\\\", \\\"{x:1346,y:703,t:1527272119110};\\\", \\\"{x:1347,y:702,t:1527272119128};\\\", \\\"{x:1347,y:701,t:1527272119161};\\\", \\\"{x:1347,y:703,t:1527272119485};\\\", \\\"{x:1344,y:706,t:1527272119495};\\\", \\\"{x:1339,y:715,t:1527272119511};\\\", \\\"{x:1329,y:725,t:1527272119528};\\\", \\\"{x:1315,y:736,t:1527272119545};\\\", \\\"{x:1297,y:749,t:1527272119562};\\\", \\\"{x:1278,y:761,t:1527272119578};\\\", \\\"{x:1264,y:771,t:1527272119594};\\\", \\\"{x:1240,y:785,t:1527272119612};\\\", \\\"{x:1226,y:795,t:1527272119628};\\\", \\\"{x:1216,y:801,t:1527272119644};\\\", \\\"{x:1206,y:809,t:1527272119662};\\\", \\\"{x:1199,y:817,t:1527272119677};\\\", \\\"{x:1193,y:826,t:1527272119695};\\\", \\\"{x:1190,y:831,t:1527272119712};\\\", \\\"{x:1187,y:837,t:1527272119728};\\\", \\\"{x:1186,y:839,t:1527272119745};\\\", \\\"{x:1185,y:841,t:1527272119762};\\\", \\\"{x:1185,y:842,t:1527272119779};\\\", \\\"{x:1185,y:843,t:1527272119795};\\\", \\\"{x:1186,y:843,t:1527272119892};\\\", \\\"{x:1187,y:843,t:1527272119900};\\\", \\\"{x:1189,y:843,t:1527272119912};\\\", \\\"{x:1196,y:843,t:1527272119928};\\\", \\\"{x:1203,y:843,t:1527272119944};\\\", \\\"{x:1211,y:843,t:1527272119962};\\\", \\\"{x:1217,y:843,t:1527272119979};\\\", \\\"{x:1222,y:843,t:1527272119995};\\\", \\\"{x:1226,y:843,t:1527272120012};\\\", \\\"{x:1229,y:843,t:1527272120029};\\\", \\\"{x:1230,y:843,t:1527272120124};\\\", \\\"{x:1230,y:844,t:1527272120221};\\\", \\\"{x:1231,y:845,t:1527272120229};\\\", \\\"{x:1231,y:846,t:1527272120244};\\\", \\\"{x:1231,y:847,t:1527272120262};\\\", \\\"{x:1231,y:848,t:1527272120279};\\\", \\\"{x:1231,y:849,t:1527272120295};\\\", \\\"{x:1231,y:850,t:1527272120311};\\\", \\\"{x:1231,y:851,t:1527272120328};\\\", \\\"{x:1231,y:852,t:1527272120346};\\\", \\\"{x:1231,y:853,t:1527272120371};\\\", \\\"{x:1230,y:853,t:1527272120380};\\\", \\\"{x:1229,y:853,t:1527272120412};\\\", \\\"{x:1227,y:853,t:1527272120428};\\\", \\\"{x:1225,y:853,t:1527272120476};\\\", \\\"{x:1225,y:852,t:1527272120556};\\\", \\\"{x:1225,y:850,t:1527272120724};\\\", \\\"{x:1225,y:848,t:1527272120756};\\\", \\\"{x:1225,y:846,t:1527272120764};\\\", \\\"{x:1226,y:845,t:1527272120779};\\\", \\\"{x:1229,y:841,t:1527272120795};\\\", \\\"{x:1246,y:830,t:1527272120812};\\\", \\\"{x:1265,y:815,t:1527272120829};\\\", \\\"{x:1296,y:791,t:1527272120845};\\\", \\\"{x:1335,y:757,t:1527272120863};\\\", \\\"{x:1373,y:725,t:1527272120879};\\\", \\\"{x:1398,y:706,t:1527272120895};\\\", \\\"{x:1411,y:700,t:1527272120913};\\\", \\\"{x:1416,y:697,t:1527272120929};\\\", \\\"{x:1417,y:696,t:1527272120945};\\\", \\\"{x:1413,y:695,t:1527272121053};\\\", \\\"{x:1408,y:695,t:1527272121063};\\\", \\\"{x:1394,y:694,t:1527272121079};\\\", \\\"{x:1384,y:693,t:1527272121096};\\\", \\\"{x:1375,y:693,t:1527272121113};\\\", \\\"{x:1369,y:694,t:1527272121129};\\\", \\\"{x:1367,y:695,t:1527272121146};\\\", \\\"{x:1365,y:695,t:1527272121163};\\\", \\\"{x:1364,y:695,t:1527272121491};\\\", \\\"{x:1363,y:697,t:1527272121499};\\\", \\\"{x:1362,y:699,t:1527272121512};\\\", \\\"{x:1360,y:706,t:1527272121529};\\\", \\\"{x:1358,y:718,t:1527272121545};\\\", \\\"{x:1358,y:731,t:1527272121562};\\\", \\\"{x:1358,y:744,t:1527272121579};\\\", \\\"{x:1358,y:749,t:1527272121595};\\\", \\\"{x:1358,y:751,t:1527272121613};\\\", \\\"{x:1358,y:752,t:1527272121629};\\\", \\\"{x:1358,y:753,t:1527272121645};\\\", \\\"{x:1358,y:754,t:1527272121663};\\\", \\\"{x:1358,y:755,t:1527272121716};\\\", \\\"{x:1358,y:756,t:1527272121844};\\\", \\\"{x:1357,y:757,t:1527272121860};\\\", \\\"{x:1356,y:758,t:1527272121875};\\\", \\\"{x:1356,y:759,t:1527272121884};\\\", \\\"{x:1356,y:760,t:1527272121916};\\\", \\\"{x:1356,y:761,t:1527272121930};\\\", \\\"{x:1355,y:763,t:1527272121947};\\\", \\\"{x:1357,y:764,t:1527272122412};\\\", \\\"{x:1358,y:764,t:1527272122420};\\\", \\\"{x:1363,y:766,t:1527272122429};\\\", \\\"{x:1370,y:766,t:1527272122446};\\\", \\\"{x:1385,y:768,t:1527272122463};\\\", \\\"{x:1410,y:775,t:1527272122480};\\\", \\\"{x:1443,y:785,t:1527272122496};\\\", \\\"{x:1491,y:800,t:1527272122514};\\\", \\\"{x:1527,y:816,t:1527272122530};\\\", \\\"{x:1550,y:826,t:1527272122546};\\\", \\\"{x:1563,y:835,t:1527272122564};\\\", \\\"{x:1565,y:838,t:1527272122579};\\\", \\\"{x:1566,y:839,t:1527272122597};\\\", \\\"{x:1566,y:841,t:1527272122620};\\\", \\\"{x:1566,y:842,t:1527272122630};\\\", \\\"{x:1566,y:843,t:1527272122652};\\\", \\\"{x:1566,y:844,t:1527272122663};\\\", \\\"{x:1566,y:845,t:1527272122684};\\\", \\\"{x:1566,y:846,t:1527272122700};\\\", \\\"{x:1566,y:847,t:1527272122715};\\\", \\\"{x:1566,y:848,t:1527272122748};\\\", \\\"{x:1566,y:849,t:1527272122764};\\\", \\\"{x:1566,y:850,t:1527272122779};\\\", \\\"{x:1567,y:850,t:1527272123228};\\\", \\\"{x:1567,y:849,t:1527272123548};\\\", \\\"{x:1566,y:848,t:1527272123572};\\\", \\\"{x:1566,y:847,t:1527272123588};\\\", \\\"{x:1566,y:845,t:1527272123597};\\\", \\\"{x:1563,y:843,t:1527272123614};\\\", \\\"{x:1558,y:838,t:1527272123631};\\\", \\\"{x:1552,y:828,t:1527272123648};\\\", \\\"{x:1545,y:817,t:1527272123664};\\\", \\\"{x:1535,y:803,t:1527272123681};\\\", \\\"{x:1520,y:785,t:1527272123697};\\\", \\\"{x:1503,y:763,t:1527272123715};\\\", \\\"{x:1487,y:744,t:1527272123731};\\\", \\\"{x:1466,y:718,t:1527272123747};\\\", \\\"{x:1459,y:708,t:1527272123764};\\\", \\\"{x:1451,y:694,t:1527272123781};\\\", \\\"{x:1448,y:686,t:1527272123798};\\\", \\\"{x:1448,y:680,t:1527272123814};\\\", \\\"{x:1447,y:675,t:1527272123830};\\\", \\\"{x:1446,y:674,t:1527272124389};\\\", \\\"{x:1445,y:673,t:1527272124427};\\\", \\\"{x:1445,y:672,t:1527272124444};\\\", \\\"{x:1445,y:671,t:1527272124452};\\\", \\\"{x:1445,y:670,t:1527272124468};\\\", \\\"{x:1445,y:669,t:1527272124482};\\\", \\\"{x:1445,y:667,t:1527272124498};\\\", \\\"{x:1446,y:664,t:1527272124514};\\\", \\\"{x:1447,y:659,t:1527272124532};\\\", \\\"{x:1447,y:658,t:1527272124548};\\\", \\\"{x:1447,y:656,t:1527272124565};\\\", \\\"{x:1446,y:655,t:1527272124660};\\\", \\\"{x:1444,y:655,t:1527272124788};\\\", \\\"{x:1442,y:654,t:1527272124798};\\\", \\\"{x:1439,y:654,t:1527272124815};\\\", \\\"{x:1437,y:654,t:1527272124832};\\\", \\\"{x:1434,y:652,t:1527272124848};\\\", \\\"{x:1432,y:651,t:1527272124865};\\\", \\\"{x:1429,y:646,t:1527272124882};\\\", \\\"{x:1424,y:636,t:1527272124898};\\\", \\\"{x:1421,y:624,t:1527272124915};\\\", \\\"{x:1418,y:607,t:1527272124932};\\\", \\\"{x:1418,y:595,t:1527272124947};\\\", \\\"{x:1418,y:588,t:1527272124965};\\\", \\\"{x:1418,y:585,t:1527272124982};\\\", \\\"{x:1418,y:584,t:1527272124999};\\\", \\\"{x:1416,y:582,t:1527272125196};\\\", \\\"{x:1416,y:581,t:1527272125204};\\\", \\\"{x:1415,y:576,t:1527272125215};\\\", \\\"{x:1411,y:570,t:1527272125232};\\\", \\\"{x:1407,y:564,t:1527272125249};\\\", \\\"{x:1405,y:557,t:1527272125264};\\\", \\\"{x:1404,y:556,t:1527272125282};\\\", \\\"{x:1405,y:557,t:1527272125403};\\\", \\\"{x:1411,y:568,t:1527272125414};\\\", \\\"{x:1427,y:594,t:1527272125431};\\\", \\\"{x:1454,y:638,t:1527272125448};\\\", \\\"{x:1484,y:690,t:1527272125465};\\\", \\\"{x:1524,y:763,t:1527272125482};\\\", \\\"{x:1566,y:830,t:1527272125499};\\\", \\\"{x:1619,y:910,t:1527272125516};\\\", \\\"{x:1634,y:938,t:1527272125532};\\\", \\\"{x:1644,y:954,t:1527272125549};\\\", \\\"{x:1646,y:962,t:1527272125565};\\\", \\\"{x:1646,y:965,t:1527272125582};\\\", \\\"{x:1646,y:967,t:1527272125599};\\\", \\\"{x:1646,y:969,t:1527272125615};\\\", \\\"{x:1646,y:970,t:1527272125635};\\\", \\\"{x:1646,y:971,t:1527272125652};\\\", \\\"{x:1646,y:972,t:1527272125700};\\\", \\\"{x:1646,y:973,t:1527272125715};\\\", \\\"{x:1644,y:973,t:1527272125844};\\\", \\\"{x:1640,y:973,t:1527272125852};\\\", \\\"{x:1637,y:972,t:1527272125866};\\\", \\\"{x:1630,y:969,t:1527272125882};\\\", \\\"{x:1623,y:966,t:1527272125899};\\\", \\\"{x:1616,y:963,t:1527272125916};\\\", \\\"{x:1613,y:962,t:1527272125932};\\\", \\\"{x:1612,y:962,t:1527272125948};\\\", \\\"{x:1612,y:961,t:1527272126436};\\\", \\\"{x:1608,y:960,t:1527272127964};\\\", \\\"{x:1602,y:959,t:1527272127971};\\\", \\\"{x:1592,y:956,t:1527272127984};\\\", \\\"{x:1564,y:944,t:1527272127999};\\\", \\\"{x:1530,y:926,t:1527272128017};\\\", \\\"{x:1492,y:904,t:1527272128033};\\\", \\\"{x:1467,y:886,t:1527272128049};\\\", \\\"{x:1446,y:867,t:1527272128066};\\\", \\\"{x:1428,y:845,t:1527272128082};\\\", \\\"{x:1422,y:837,t:1527272128100};\\\", \\\"{x:1419,y:832,t:1527272128116};\\\", \\\"{x:1417,y:827,t:1527272128134};\\\", \\\"{x:1414,y:825,t:1527272128151};\\\", \\\"{x:1411,y:822,t:1527272128166};\\\", \\\"{x:1408,y:820,t:1527272128184};\\\", \\\"{x:1403,y:817,t:1527272128201};\\\", \\\"{x:1395,y:814,t:1527272128217};\\\", \\\"{x:1383,y:809,t:1527272128233};\\\", \\\"{x:1375,y:805,t:1527272128251};\\\", \\\"{x:1367,y:801,t:1527272128266};\\\", \\\"{x:1360,y:796,t:1527272128283};\\\", \\\"{x:1353,y:789,t:1527272128301};\\\", \\\"{x:1349,y:784,t:1527272128317};\\\", \\\"{x:1343,y:776,t:1527272128334};\\\", \\\"{x:1340,y:772,t:1527272128351};\\\", \\\"{x:1338,y:769,t:1527272128367};\\\", \\\"{x:1338,y:768,t:1527272128388};\\\", \\\"{x:1337,y:767,t:1527272128401};\\\", \\\"{x:1337,y:766,t:1527272128692};\\\", \\\"{x:1336,y:766,t:1527272128701};\\\", \\\"{x:1335,y:766,t:1527272128718};\\\", \\\"{x:1332,y:766,t:1527272128733};\\\", \\\"{x:1331,y:766,t:1527272128755};\\\", \\\"{x:1329,y:766,t:1527272128768};\\\", \\\"{x:1331,y:766,t:1527272129324};\\\", \\\"{x:1334,y:766,t:1527272129335};\\\", \\\"{x:1339,y:766,t:1527272129351};\\\", \\\"{x:1344,y:766,t:1527272129368};\\\", \\\"{x:1352,y:766,t:1527272129384};\\\", \\\"{x:1359,y:766,t:1527272129401};\\\", \\\"{x:1363,y:766,t:1527272129418};\\\", \\\"{x:1362,y:766,t:1527272129595};\\\", \\\"{x:1361,y:766,t:1527272129611};\\\", \\\"{x:1360,y:766,t:1527272129619};\\\", \\\"{x:1359,y:766,t:1527272129635};\\\", \\\"{x:1358,y:766,t:1527272129835};\\\", \\\"{x:1357,y:766,t:1527272129851};\\\", \\\"{x:1362,y:765,t:1527272130637};\\\", \\\"{x:1376,y:765,t:1527272130653};\\\", \\\"{x:1389,y:768,t:1527272130670};\\\", \\\"{x:1402,y:776,t:1527272130687};\\\", \\\"{x:1417,y:787,t:1527272130703};\\\", \\\"{x:1433,y:799,t:1527272130719};\\\", \\\"{x:1441,y:808,t:1527272130737};\\\", \\\"{x:1450,y:814,t:1527272130753};\\\", \\\"{x:1456,y:819,t:1527272130769};\\\", \\\"{x:1458,y:821,t:1527272130787};\\\", \\\"{x:1460,y:823,t:1527272130803};\\\", \\\"{x:1463,y:825,t:1527272130820};\\\", \\\"{x:1469,y:829,t:1527272130836};\\\", \\\"{x:1474,y:833,t:1527272130853};\\\", \\\"{x:1479,y:835,t:1527272130870};\\\", \\\"{x:1481,y:836,t:1527272130887};\\\", \\\"{x:1483,y:837,t:1527272130902};\\\", \\\"{x:1485,y:838,t:1527272130920};\\\", \\\"{x:1486,y:838,t:1527272130949};\\\", \\\"{x:1487,y:838,t:1527272130965};\\\", \\\"{x:1488,y:838,t:1527272131037};\\\", \\\"{x:1489,y:838,t:1527272131100};\\\", \\\"{x:1489,y:837,t:1527272131156};\\\", \\\"{x:1488,y:836,t:1527272131172};\\\", \\\"{x:1487,y:836,t:1527272132053};\\\", \\\"{x:1488,y:842,t:1527272132071};\\\", \\\"{x:1494,y:853,t:1527272132086};\\\", \\\"{x:1498,y:862,t:1527272132103};\\\", \\\"{x:1502,y:873,t:1527272132121};\\\", \\\"{x:1507,y:880,t:1527272132137};\\\", \\\"{x:1510,y:886,t:1527272132154};\\\", \\\"{x:1512,y:889,t:1527272132170};\\\", \\\"{x:1516,y:894,t:1527272132187};\\\", \\\"{x:1521,y:902,t:1527272132204};\\\", \\\"{x:1530,y:916,t:1527272132220};\\\", \\\"{x:1533,y:923,t:1527272132237};\\\", \\\"{x:1536,y:928,t:1527272132253};\\\", \\\"{x:1537,y:930,t:1527272132271};\\\", \\\"{x:1538,y:932,t:1527272132287};\\\", \\\"{x:1540,y:936,t:1527272132304};\\\", \\\"{x:1541,y:938,t:1527272132321};\\\", \\\"{x:1543,y:941,t:1527272132338};\\\", \\\"{x:1543,y:942,t:1527272132354};\\\", \\\"{x:1544,y:942,t:1527272132371};\\\", \\\"{x:1544,y:944,t:1527272132421};\\\", \\\"{x:1544,y:945,t:1527272132445};\\\", \\\"{x:1545,y:946,t:1527272132468};\\\", \\\"{x:1546,y:947,t:1527272132493};\\\", \\\"{x:1546,y:948,t:1527272132508};\\\", \\\"{x:1546,y:949,t:1527272132524};\\\", \\\"{x:1546,y:950,t:1527272132537};\\\", \\\"{x:1547,y:951,t:1527272132553};\\\", \\\"{x:1547,y:953,t:1527272132571};\\\", \\\"{x:1547,y:954,t:1527272132588};\\\", \\\"{x:1547,y:955,t:1527272132604};\\\", \\\"{x:1547,y:956,t:1527272132621};\\\", \\\"{x:1549,y:957,t:1527272132638};\\\", \\\"{x:1549,y:959,t:1527272133868};\\\", \\\"{x:1549,y:960,t:1527272134220};\\\", \\\"{x:1562,y:961,t:1527272134239};\\\", \\\"{x:1587,y:964,t:1527272134255};\\\", \\\"{x:1606,y:970,t:1527272134272};\\\", \\\"{x:1627,y:972,t:1527272134288};\\\", \\\"{x:1637,y:973,t:1527272134306};\\\", \\\"{x:1638,y:973,t:1527272134321};\\\", \\\"{x:1639,y:973,t:1527272134404};\\\", \\\"{x:1639,y:972,t:1527272134411};\\\", \\\"{x:1639,y:971,t:1527272134421};\\\", \\\"{x:1639,y:970,t:1527272134438};\\\", \\\"{x:1639,y:968,t:1527272134455};\\\", \\\"{x:1638,y:967,t:1527272134472};\\\", \\\"{x:1636,y:965,t:1527272134489};\\\", \\\"{x:1635,y:965,t:1527272134505};\\\", \\\"{x:1633,y:964,t:1527272134522};\\\", \\\"{x:1630,y:962,t:1527272134539};\\\", \\\"{x:1628,y:962,t:1527272134555};\\\", \\\"{x:1625,y:961,t:1527272134571};\\\", \\\"{x:1622,y:960,t:1527272134588};\\\", \\\"{x:1619,y:958,t:1527272134605};\\\", \\\"{x:1614,y:954,t:1527272134621};\\\", \\\"{x:1612,y:954,t:1527272134639};\\\", \\\"{x:1610,y:952,t:1527272134655};\\\", \\\"{x:1606,y:950,t:1527272134672};\\\", \\\"{x:1605,y:949,t:1527272134689};\\\", \\\"{x:1604,y:947,t:1527272134706};\\\", \\\"{x:1603,y:944,t:1527272134721};\\\", \\\"{x:1601,y:940,t:1527272134738};\\\", \\\"{x:1599,y:936,t:1527272134756};\\\", \\\"{x:1593,y:916,t:1527272134772};\\\", \\\"{x:1586,y:890,t:1527272134789};\\\", \\\"{x:1577,y:831,t:1527272134806};\\\", \\\"{x:1559,y:736,t:1527272134821};\\\", \\\"{x:1540,y:653,t:1527272134838};\\\", \\\"{x:1511,y:592,t:1527272134856};\\\", \\\"{x:1480,y:523,t:1527272134872};\\\", \\\"{x:1452,y:467,t:1527272134889};\\\", \\\"{x:1432,y:417,t:1527272134906};\\\", \\\"{x:1417,y:391,t:1527272134923};\\\", \\\"{x:1408,y:374,t:1527272134939};\\\", \\\"{x:1398,y:363,t:1527272134956};\\\", \\\"{x:1396,y:360,t:1527272134973};\\\", \\\"{x:1395,y:358,t:1527272134996};\\\", \\\"{x:1394,y:358,t:1527272135036};\\\", \\\"{x:1393,y:358,t:1527272135045};\\\", \\\"{x:1389,y:366,t:1527272135056};\\\", \\\"{x:1379,y:383,t:1527272135073};\\\", \\\"{x:1374,y:403,t:1527272135088};\\\", \\\"{x:1370,y:421,t:1527272135105};\\\", \\\"{x:1369,y:442,t:1527272135123};\\\", \\\"{x:1369,y:461,t:1527272135138};\\\", \\\"{x:1369,y:479,t:1527272135155};\\\", \\\"{x:1372,y:497,t:1527272135172};\\\", \\\"{x:1373,y:504,t:1527272135189};\\\", \\\"{x:1374,y:507,t:1527272135206};\\\", \\\"{x:1375,y:508,t:1527272135223};\\\", \\\"{x:1376,y:510,t:1527272135239};\\\", \\\"{x:1377,y:511,t:1527272135268};\\\", \\\"{x:1378,y:512,t:1527272135285};\\\", \\\"{x:1378,y:514,t:1527272135292};\\\", \\\"{x:1380,y:514,t:1527272135308};\\\", \\\"{x:1380,y:516,t:1527272135323};\\\", \\\"{x:1383,y:518,t:1527272135340};\\\", \\\"{x:1386,y:520,t:1527272135356};\\\", \\\"{x:1391,y:522,t:1527272135372};\\\", \\\"{x:1394,y:524,t:1527272135389};\\\", \\\"{x:1399,y:527,t:1527272135405};\\\", \\\"{x:1402,y:528,t:1527272135423};\\\", \\\"{x:1406,y:530,t:1527272135440};\\\", \\\"{x:1409,y:531,t:1527272135456};\\\", \\\"{x:1413,y:534,t:1527272135473};\\\", \\\"{x:1416,y:534,t:1527272135490};\\\", \\\"{x:1416,y:535,t:1527272135506};\\\", \\\"{x:1417,y:536,t:1527272135757};\\\", \\\"{x:1419,y:538,t:1527272135772};\\\", \\\"{x:1419,y:540,t:1527272135790};\\\", \\\"{x:1421,y:541,t:1527272135805};\\\", \\\"{x:1422,y:544,t:1527272135823};\\\", \\\"{x:1423,y:545,t:1527272135840};\\\", \\\"{x:1423,y:547,t:1527272135856};\\\", \\\"{x:1424,y:547,t:1527272135872};\\\", \\\"{x:1424,y:548,t:1527272135893};\\\", \\\"{x:1425,y:548,t:1527272135916};\\\", \\\"{x:1426,y:550,t:1527272135940};\\\", \\\"{x:1427,y:550,t:1527272135956};\\\", \\\"{x:1427,y:551,t:1527272135988};\\\", \\\"{x:1429,y:553,t:1527272136004};\\\", \\\"{x:1430,y:554,t:1527272136036};\\\", \\\"{x:1430,y:555,t:1527272136044};\\\", \\\"{x:1431,y:556,t:1527272136060};\\\", \\\"{x:1432,y:557,t:1527272136092};\\\", \\\"{x:1432,y:558,t:1527272136117};\\\", \\\"{x:1432,y:559,t:1527272136124};\\\", \\\"{x:1432,y:561,t:1527272136140};\\\", \\\"{x:1431,y:564,t:1527272136156};\\\", \\\"{x:1422,y:568,t:1527272136172};\\\", \\\"{x:1405,y:573,t:1527272136189};\\\", \\\"{x:1371,y:574,t:1527272136207};\\\", \\\"{x:1315,y:574,t:1527272136223};\\\", \\\"{x:1243,y:574,t:1527272136239};\\\", \\\"{x:1155,y:565,t:1527272136256};\\\", \\\"{x:1088,y:555,t:1527272136273};\\\", \\\"{x:1053,y:550,t:1527272136290};\\\", \\\"{x:1036,y:548,t:1527272136306};\\\", \\\"{x:1031,y:547,t:1527272136323};\\\", \\\"{x:1030,y:546,t:1527272136339};\\\", \\\"{x:1029,y:546,t:1527272136397};\\\", \\\"{x:1025,y:546,t:1527272136407};\\\", \\\"{x:1014,y:546,t:1527272136423};\\\", \\\"{x:1009,y:546,t:1527272136440};\\\", \\\"{x:997,y:546,t:1527272136457};\\\", \\\"{x:986,y:546,t:1527272136474};\\\", \\\"{x:972,y:546,t:1527272136489};\\\", \\\"{x:961,y:546,t:1527272136506};\\\", \\\"{x:936,y:544,t:1527272136525};\\\", \\\"{x:917,y:539,t:1527272136539};\\\", \\\"{x:900,y:535,t:1527272136556};\\\", \\\"{x:895,y:534,t:1527272136575};\\\", \\\"{x:888,y:532,t:1527272136591};\\\", \\\"{x:882,y:531,t:1527272136608};\\\", \\\"{x:880,y:531,t:1527272136625};\\\", \\\"{x:878,y:531,t:1527272136641};\\\", \\\"{x:877,y:531,t:1527272136658};\\\", \\\"{x:876,y:531,t:1527272136675};\\\", \\\"{x:871,y:531,t:1527272136691};\\\", \\\"{x:865,y:531,t:1527272136709};\\\", \\\"{x:860,y:531,t:1527272136725};\\\", \\\"{x:858,y:531,t:1527272136742};\\\", \\\"{x:855,y:531,t:1527272136759};\\\", \\\"{x:859,y:531,t:1527272137140};\\\", \\\"{x:872,y:532,t:1527272137148};\\\", \\\"{x:887,y:534,t:1527272137159};\\\", \\\"{x:935,y:542,t:1527272137176};\\\", \\\"{x:991,y:552,t:1527272137194};\\\", \\\"{x:1047,y:560,t:1527272137209};\\\", \\\"{x:1092,y:565,t:1527272137227};\\\", \\\"{x:1140,y:572,t:1527272137244};\\\", \\\"{x:1160,y:576,t:1527272137260};\\\", \\\"{x:1183,y:583,t:1527272137277};\\\", \\\"{x:1206,y:589,t:1527272137293};\\\", \\\"{x:1233,y:593,t:1527272137309};\\\", \\\"{x:1262,y:598,t:1527272137326};\\\", \\\"{x:1290,y:599,t:1527272137344};\\\", \\\"{x:1313,y:599,t:1527272137359};\\\", \\\"{x:1336,y:599,t:1527272137376};\\\", \\\"{x:1362,y:599,t:1527272137394};\\\", \\\"{x:1383,y:599,t:1527272137409};\\\", \\\"{x:1399,y:599,t:1527272137427};\\\", \\\"{x:1420,y:599,t:1527272137444};\\\", \\\"{x:1429,y:597,t:1527272137460};\\\", \\\"{x:1433,y:595,t:1527272137477};\\\", \\\"{x:1434,y:594,t:1527272137533};\\\", \\\"{x:1435,y:594,t:1527272137547};\\\", \\\"{x:1436,y:594,t:1527272137559};\\\", \\\"{x:1437,y:594,t:1527272137576};\\\", \\\"{x:1438,y:594,t:1527272137593};\\\", \\\"{x:1439,y:593,t:1527272137645};\\\", \\\"{x:1439,y:592,t:1527272137700};\\\", \\\"{x:1438,y:591,t:1527272137716};\\\", \\\"{x:1436,y:590,t:1527272137727};\\\", \\\"{x:1433,y:587,t:1527272137743};\\\", \\\"{x:1431,y:584,t:1527272137761};\\\", \\\"{x:1427,y:579,t:1527272137776};\\\", \\\"{x:1423,y:573,t:1527272137794};\\\", \\\"{x:1423,y:572,t:1527272137810};\\\", \\\"{x:1422,y:572,t:1527272137826};\\\", \\\"{x:1421,y:571,t:1527272137876};\\\", \\\"{x:1420,y:571,t:1527272138021};\\\", \\\"{x:1418,y:574,t:1527272138028};\\\", \\\"{x:1417,y:580,t:1527272138044};\\\", \\\"{x:1414,y:592,t:1527272138061};\\\", \\\"{x:1414,y:610,t:1527272138078};\\\", \\\"{x:1414,y:630,t:1527272138094};\\\", \\\"{x:1420,y:656,t:1527272138111};\\\", \\\"{x:1430,y:679,t:1527272138128};\\\", \\\"{x:1442,y:702,t:1527272138144};\\\", \\\"{x:1456,y:723,t:1527272138161};\\\", \\\"{x:1471,y:742,t:1527272138178};\\\", \\\"{x:1485,y:759,t:1527272138194};\\\", \\\"{x:1497,y:773,t:1527272138211};\\\", \\\"{x:1510,y:790,t:1527272138229};\\\", \\\"{x:1518,y:801,t:1527272138244};\\\", \\\"{x:1527,y:814,t:1527272138260};\\\", \\\"{x:1538,y:829,t:1527272138277};\\\", \\\"{x:1543,y:839,t:1527272138294};\\\", \\\"{x:1548,y:845,t:1527272138311};\\\", \\\"{x:1550,y:848,t:1527272138327};\\\", \\\"{x:1551,y:853,t:1527272138343};\\\", \\\"{x:1554,y:858,t:1527272138360};\\\", \\\"{x:1554,y:860,t:1527272138378};\\\", \\\"{x:1558,y:868,t:1527272138393};\\\", \\\"{x:1559,y:875,t:1527272138410};\\\", \\\"{x:1564,y:885,t:1527272138427};\\\", \\\"{x:1566,y:891,t:1527272138444};\\\", \\\"{x:1567,y:896,t:1527272138461};\\\", \\\"{x:1567,y:898,t:1527272138478};\\\", \\\"{x:1568,y:900,t:1527272138494};\\\", \\\"{x:1569,y:902,t:1527272138510};\\\", \\\"{x:1569,y:903,t:1527272138527};\\\", \\\"{x:1570,y:903,t:1527272138545};\\\", \\\"{x:1570,y:905,t:1527272138561};\\\", \\\"{x:1571,y:905,t:1527272138578};\\\", \\\"{x:1570,y:905,t:1527272138645};\\\", \\\"{x:1565,y:897,t:1527272138661};\\\", \\\"{x:1554,y:876,t:1527272138677};\\\", \\\"{x:1528,y:834,t:1527272138695};\\\", \\\"{x:1498,y:786,t:1527272138710};\\\", \\\"{x:1463,y:745,t:1527272138728};\\\", \\\"{x:1435,y:710,t:1527272138744};\\\", \\\"{x:1415,y:681,t:1527272138761};\\\", \\\"{x:1403,y:667,t:1527272138778};\\\", \\\"{x:1397,y:660,t:1527272138795};\\\", \\\"{x:1396,y:659,t:1527272138811};\\\", \\\"{x:1396,y:658,t:1527272138828};\\\", \\\"{x:1396,y:657,t:1527272138861};\\\", \\\"{x:1394,y:654,t:1527272138878};\\\", \\\"{x:1392,y:650,t:1527272138895};\\\", \\\"{x:1388,y:645,t:1527272138911};\\\", \\\"{x:1385,y:641,t:1527272138927};\\\", \\\"{x:1380,y:636,t:1527272138945};\\\", \\\"{x:1378,y:632,t:1527272138962};\\\", \\\"{x:1377,y:629,t:1527272138978};\\\", \\\"{x:1375,y:626,t:1527272138995};\\\", \\\"{x:1374,y:614,t:1527272139012};\\\", \\\"{x:1373,y:603,t:1527272139028};\\\", \\\"{x:1373,y:595,t:1527272139044};\\\", \\\"{x:1372,y:592,t:1527272139061};\\\", \\\"{x:1371,y:592,t:1527272139078};\\\", \\\"{x:1371,y:593,t:1527272139173};\\\", \\\"{x:1369,y:598,t:1527272139180};\\\", \\\"{x:1366,y:606,t:1527272139195};\\\", \\\"{x:1356,y:634,t:1527272139212};\\\", \\\"{x:1348,y:655,t:1527272139228};\\\", \\\"{x:1338,y:677,t:1527272139245};\\\", \\\"{x:1330,y:695,t:1527272139262};\\\", \\\"{x:1323,y:712,t:1527272139278};\\\", \\\"{x:1317,y:727,t:1527272139295};\\\", \\\"{x:1310,y:743,t:1527272139312};\\\", \\\"{x:1306,y:756,t:1527272139328};\\\", \\\"{x:1302,y:767,t:1527272139345};\\\", \\\"{x:1300,y:774,t:1527272139362};\\\", \\\"{x:1297,y:779,t:1527272139378};\\\", \\\"{x:1297,y:783,t:1527272139395};\\\", \\\"{x:1296,y:789,t:1527272139412};\\\", \\\"{x:1294,y:793,t:1527272139428};\\\", \\\"{x:1294,y:795,t:1527272139445};\\\", \\\"{x:1294,y:798,t:1527272139462};\\\", \\\"{x:1294,y:801,t:1527272139478};\\\", \\\"{x:1294,y:800,t:1527272139540};\\\", \\\"{x:1294,y:797,t:1527272139549};\\\", \\\"{x:1296,y:793,t:1527272139562};\\\", \\\"{x:1300,y:781,t:1527272139579};\\\", \\\"{x:1314,y:763,t:1527272139595};\\\", \\\"{x:1331,y:745,t:1527272139613};\\\", \\\"{x:1338,y:743,t:1527272139628};\\\", \\\"{x:1340,y:741,t:1527272139645};\\\", \\\"{x:1341,y:741,t:1527272139662};\\\", \\\"{x:1342,y:741,t:1527272139684};\\\", \\\"{x:1344,y:741,t:1527272139716};\\\", \\\"{x:1345,y:742,t:1527272139729};\\\", \\\"{x:1346,y:745,t:1527272139745};\\\", \\\"{x:1349,y:749,t:1527272139762};\\\", \\\"{x:1349,y:751,t:1527272139779};\\\", \\\"{x:1350,y:754,t:1527272139795};\\\", \\\"{x:1350,y:756,t:1527272139812};\\\", \\\"{x:1350,y:757,t:1527272139837};\\\", \\\"{x:1350,y:759,t:1527272141646};\\\", \\\"{x:1350,y:762,t:1527272141663};\\\", \\\"{x:1349,y:766,t:1527272141680};\\\", \\\"{x:1349,y:767,t:1527272141696};\\\", \\\"{x:1349,y:768,t:1527272141712};\\\", \\\"{x:1349,y:769,t:1527272141730};\\\", \\\"{x:1348,y:771,t:1527272141747};\\\", \\\"{x:1348,y:776,t:1527272141763};\\\", \\\"{x:1347,y:780,t:1527272141780};\\\", \\\"{x:1346,y:784,t:1527272141797};\\\", \\\"{x:1345,y:787,t:1527272141814};\\\", \\\"{x:1344,y:789,t:1527272141830};\\\", \\\"{x:1343,y:791,t:1527272141847};\\\", \\\"{x:1341,y:794,t:1527272141864};\\\", \\\"{x:1341,y:795,t:1527272141880};\\\", \\\"{x:1341,y:797,t:1527272141897};\\\", \\\"{x:1340,y:799,t:1527272141914};\\\", \\\"{x:1339,y:801,t:1527272141930};\\\", \\\"{x:1338,y:802,t:1527272141947};\\\", \\\"{x:1337,y:805,t:1527272141964};\\\", \\\"{x:1337,y:807,t:1527272141979};\\\", \\\"{x:1336,y:808,t:1527272141997};\\\", \\\"{x:1336,y:809,t:1527272142014};\\\", \\\"{x:1335,y:809,t:1527272142156};\\\", \\\"{x:1335,y:808,t:1527272142164};\\\", \\\"{x:1335,y:804,t:1527272142180};\\\", \\\"{x:1335,y:801,t:1527272142197};\\\", \\\"{x:1335,y:800,t:1527272142214};\\\", \\\"{x:1335,y:796,t:1527272142230};\\\", \\\"{x:1336,y:794,t:1527272142247};\\\", \\\"{x:1337,y:792,t:1527272142264};\\\", \\\"{x:1338,y:789,t:1527272142280};\\\", \\\"{x:1340,y:787,t:1527272142296};\\\", \\\"{x:1340,y:785,t:1527272142314};\\\", \\\"{x:1342,y:783,t:1527272142330};\\\", \\\"{x:1343,y:783,t:1527272142347};\\\", \\\"{x:1345,y:781,t:1527272142364};\\\", \\\"{x:1346,y:781,t:1527272142573};\\\", \\\"{x:1346,y:782,t:1527272142581};\\\", \\\"{x:1341,y:796,t:1527272142597};\\\", \\\"{x:1323,y:831,t:1527272142614};\\\", \\\"{x:1315,y:858,t:1527272142631};\\\", \\\"{x:1307,y:881,t:1527272142647};\\\", \\\"{x:1301,y:907,t:1527272142664};\\\", \\\"{x:1294,y:932,t:1527272142681};\\\", \\\"{x:1290,y:948,t:1527272142698};\\\", \\\"{x:1289,y:956,t:1527272142714};\\\", \\\"{x:1289,y:963,t:1527272142732};\\\", \\\"{x:1288,y:968,t:1527272142748};\\\", \\\"{x:1286,y:973,t:1527272142764};\\\", \\\"{x:1284,y:977,t:1527272142781};\\\", \\\"{x:1283,y:980,t:1527272142798};\\\", \\\"{x:1282,y:982,t:1527272142814};\\\", \\\"{x:1281,y:983,t:1527272142831};\\\", \\\"{x:1281,y:985,t:1527272142849};\\\", \\\"{x:1281,y:987,t:1527272142956};\\\", \\\"{x:1280,y:987,t:1527272142972};\\\", \\\"{x:1279,y:987,t:1527272142988};\\\", \\\"{x:1278,y:987,t:1527272143012};\\\", \\\"{x:1276,y:987,t:1527272143020};\\\", \\\"{x:1275,y:987,t:1527272143031};\\\", \\\"{x:1271,y:984,t:1527272143049};\\\", \\\"{x:1268,y:981,t:1527272143064};\\\", \\\"{x:1264,y:977,t:1527272143081};\\\", \\\"{x:1262,y:974,t:1527272143098};\\\", \\\"{x:1261,y:972,t:1527272143115};\\\", \\\"{x:1261,y:971,t:1527272143131};\\\", \\\"{x:1260,y:970,t:1527272143148};\\\", \\\"{x:1260,y:969,t:1527272143172};\\\", \\\"{x:1260,y:967,t:1527272143252};\\\", \\\"{x:1259,y:967,t:1527272143268};\\\", \\\"{x:1258,y:967,t:1527272143284};\\\", \\\"{x:1257,y:967,t:1527272143298};\\\", \\\"{x:1256,y:967,t:1527272143315};\\\", \\\"{x:1255,y:967,t:1527272143357};\\\", \\\"{x:1254,y:967,t:1527272143372};\\\", \\\"{x:1253,y:967,t:1527272143388};\\\", \\\"{x:1251,y:965,t:1527272144965};\\\", \\\"{x:1247,y:964,t:1527272144972};\\\", \\\"{x:1243,y:961,t:1527272144982};\\\", \\\"{x:1226,y:953,t:1527272145000};\\\", \\\"{x:1194,y:941,t:1527272145016};\\\", \\\"{x:1132,y:918,t:1527272145032};\\\", \\\"{x:1053,y:890,t:1527272145049};\\\", \\\"{x:975,y:868,t:1527272145066};\\\", \\\"{x:909,y:848,t:1527272145082};\\\", \\\"{x:848,y:832,t:1527272145099};\\\", \\\"{x:789,y:816,t:1527272145116};\\\", \\\"{x:764,y:808,t:1527272145132};\\\", \\\"{x:743,y:802,t:1527272145149};\\\", \\\"{x:730,y:799,t:1527272145166};\\\", \\\"{x:726,y:797,t:1527272145183};\\\", \\\"{x:724,y:797,t:1527272145199};\\\", \\\"{x:721,y:796,t:1527272145216};\\\", \\\"{x:718,y:796,t:1527272145233};\\\", \\\"{x:714,y:795,t:1527272145249};\\\", \\\"{x:711,y:794,t:1527272145266};\\\", \\\"{x:707,y:790,t:1527272145283};\\\", \\\"{x:698,y:785,t:1527272145299};\\\", \\\"{x:689,y:777,t:1527272145315};\\\", \\\"{x:683,y:773,t:1527272145333};\\\", \\\"{x:679,y:771,t:1527272145349};\\\", \\\"{x:673,y:768,t:1527272145366};\\\", \\\"{x:666,y:765,t:1527272145382};\\\", \\\"{x:656,y:758,t:1527272145399};\\\", \\\"{x:644,y:749,t:1527272145416};\\\", \\\"{x:637,y:744,t:1527272145432};\\\", \\\"{x:629,y:740,t:1527272145449};\\\", \\\"{x:620,y:735,t:1527272145466};\\\", \\\"{x:612,y:731,t:1527272145483};\\\", \\\"{x:608,y:731,t:1527272145499};\\\", \\\"{x:603,y:730,t:1527272145515};\\\", \\\"{x:597,y:728,t:1527272145533};\\\", \\\"{x:588,y:726,t:1527272145550};\\\", \\\"{x:572,y:720,t:1527272145566};\\\", \\\"{x:560,y:716,t:1527272145582};\\\", \\\"{x:554,y:716,t:1527272145599};\\\", \\\"{x:547,y:714,t:1527272145615};\\\", \\\"{x:541,y:712,t:1527272145633};\\\", \\\"{x:538,y:712,t:1527272145649};\\\", \\\"{x:533,y:712,t:1527272145665};\\\", \\\"{x:530,y:712,t:1527272145683};\\\", \\\"{x:521,y:712,t:1527272145700};\\\", \\\"{x:515,y:712,t:1527272145715};\\\", \\\"{x:512,y:712,t:1527272145733};\\\", \\\"{x:507,y:714,t:1527272145750};\\\", \\\"{x:504,y:716,t:1527272145766};\\\", \\\"{x:502,y:718,t:1527272145782};\\\", \\\"{x:501,y:720,t:1527272145800};\\\", \\\"{x:500,y:720,t:1527272145815};\\\", \\\"{x:500,y:721,t:1527272145833};\\\", \\\"{x:499,y:722,t:1527272145850};\\\", \\\"{x:498,y:722,t:1527272145866};\\\", \\\"{x:497,y:722,t:1527272145915};\\\", \\\"{x:496,y:722,t:1527272145923};\\\", \\\"{x:494,y:722,t:1527272145939};\\\", \\\"{x:494,y:723,t:1527272145955};\\\", \\\"{x:493,y:723,t:1527272145966};\\\", \\\"{x:493,y:724,t:1527272145987};\\\", \\\"{x:493,y:725,t:1527272146347};\\\", \\\"{x:494,y:725,t:1527272146372};\\\", \\\"{x:495,y:725,t:1527272146384};\\\", \\\"{x:501,y:725,t:1527272146401};\\\", \\\"{x:501,y:726,t:1527272146417};\\\", \\\"{x:502,y:726,t:1527272147267};\\\", \\\"{x:502,y:724,t:1527272147291};\\\", \\\"{x:502,y:723,t:1527272147307};\\\", \\\"{x:502,y:721,t:1527272147318};\\\", \\\"{x:502,y:718,t:1527272147335};\\\", \\\"{x:501,y:712,t:1527272147351};\\\", \\\"{x:500,y:705,t:1527272147367};\\\", \\\"{x:500,y:699,t:1527272147384};\\\", \\\"{x:500,y:693,t:1527272147401};\\\", \\\"{x:502,y:684,t:1527272147418};\\\", \\\"{x:505,y:669,t:1527272147435};\\\", \\\"{x:512,y:648,t:1527272147451};\\\", \\\"{x:515,y:637,t:1527272147468};\\\", \\\"{x:519,y:622,t:1527272147485};\\\", \\\"{x:525,y:601,t:1527272147502};\\\", \\\"{x:529,y:583,t:1527272147518};\\\" ] }, { \\\"rt\\\": 77942, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 515891, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"2WQ0M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -J -B -B -B -B -E -J -E -E -I -I -J -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:589,y:215,t:1527272147713};\\\", \\\"{x:589,y:209,t:1527272147720};\\\", \\\"{x:589,y:202,t:1527272147737};\\\", \\\"{x:589,y:198,t:1527272147752};\\\", \\\"{x:588,y:198,t:1527272147768};\\\", \\\"{x:588,y:197,t:1527272147829};\\\", \\\"{x:587,y:197,t:1527272147898};\\\", \\\"{x:586,y:198,t:1527272147906};\\\", \\\"{x:586,y:199,t:1527272147918};\\\", \\\"{x:585,y:202,t:1527272147935};\\\", \\\"{x:583,y:206,t:1527272147951};\\\", \\\"{x:581,y:209,t:1527272147969};\\\", \\\"{x:579,y:214,t:1527272147984};\\\", \\\"{x:577,y:223,t:1527272148001};\\\", \\\"{x:574,y:232,t:1527272148018};\\\", \\\"{x:571,y:245,t:1527272148034};\\\", \\\"{x:568,y:255,t:1527272148052};\\\", \\\"{x:565,y:268,t:1527272148069};\\\", \\\"{x:563,y:282,t:1527272148085};\\\", \\\"{x:560,y:293,t:1527272148102};\\\", \\\"{x:559,y:306,t:1527272148118};\\\", \\\"{x:556,y:319,t:1527272148136};\\\", \\\"{x:555,y:333,t:1527272148151};\\\", \\\"{x:553,y:342,t:1527272148169};\\\", \\\"{x:553,y:348,t:1527272148186};\\\", \\\"{x:552,y:351,t:1527272148201};\\\", \\\"{x:552,y:353,t:1527272148219};\\\", \\\"{x:550,y:355,t:1527272148236};\\\", \\\"{x:550,y:356,t:1527272148267};\\\", \\\"{x:548,y:358,t:1527272148300};\\\", \\\"{x:548,y:359,t:1527272148308};\\\", \\\"{x:547,y:359,t:1527272148319};\\\", \\\"{x:546,y:363,t:1527272148336};\\\", \\\"{x:545,y:363,t:1527272148352};\\\", \\\"{x:545,y:364,t:1527272149507};\\\", \\\"{x:546,y:365,t:1527272149519};\\\", \\\"{x:565,y:371,t:1527272149537};\\\", \\\"{x:595,y:377,t:1527272149552};\\\", \\\"{x:663,y:393,t:1527272149569};\\\", \\\"{x:760,y:417,t:1527272149586};\\\", \\\"{x:864,y:443,t:1527272149603};\\\", \\\"{x:999,y:475,t:1527272149620};\\\", \\\"{x:1058,y:483,t:1527272149637};\\\", \\\"{x:1098,y:492,t:1527272149653};\\\", \\\"{x:1121,y:500,t:1527272149670};\\\", \\\"{x:1128,y:501,t:1527272149687};\\\", \\\"{x:1132,y:502,t:1527272149703};\\\", \\\"{x:1135,y:502,t:1527272149720};\\\", \\\"{x:1139,y:504,t:1527272149737};\\\", \\\"{x:1144,y:504,t:1527272149753};\\\", \\\"{x:1157,y:505,t:1527272149770};\\\", \\\"{x:1180,y:510,t:1527272149787};\\\", \\\"{x:1222,y:517,t:1527272149803};\\\", \\\"{x:1321,y:538,t:1527272149820};\\\", \\\"{x:1407,y:551,t:1527272149837};\\\", \\\"{x:1504,y:566,t:1527272149854};\\\", \\\"{x:1611,y:586,t:1527272149870};\\\", \\\"{x:1712,y:606,t:1527272149887};\\\", \\\"{x:1747,y:613,t:1527272149904};\\\", \\\"{x:1748,y:615,t:1527272149920};\\\", \\\"{x:1749,y:615,t:1527272150188};\\\", \\\"{x:1749,y:616,t:1527272150788};\\\", \\\"{x:1749,y:618,t:1527272151980};\\\", \\\"{x:1749,y:623,t:1527272151989};\\\", \\\"{x:1745,y:639,t:1527272152005};\\\", \\\"{x:1734,y:655,t:1527272152022};\\\", \\\"{x:1723,y:672,t:1527272152040};\\\", \\\"{x:1710,y:691,t:1527272152055};\\\", \\\"{x:1700,y:706,t:1527272152073};\\\", \\\"{x:1693,y:714,t:1527272152089};\\\", \\\"{x:1679,y:726,t:1527272152105};\\\", \\\"{x:1660,y:735,t:1527272152123};\\\", \\\"{x:1644,y:743,t:1527272152140};\\\", \\\"{x:1628,y:748,t:1527272152155};\\\", \\\"{x:1616,y:751,t:1527272152172};\\\", \\\"{x:1611,y:752,t:1527272152189};\\\", \\\"{x:1603,y:753,t:1527272152205};\\\", \\\"{x:1595,y:754,t:1527272152223};\\\", \\\"{x:1582,y:756,t:1527272152239};\\\", \\\"{x:1570,y:758,t:1527272152255};\\\", \\\"{x:1555,y:763,t:1527272152272};\\\", \\\"{x:1539,y:767,t:1527272152289};\\\", \\\"{x:1516,y:778,t:1527272152305};\\\", \\\"{x:1485,y:791,t:1527272152321};\\\", \\\"{x:1437,y:807,t:1527272152338};\\\", \\\"{x:1360,y:826,t:1527272152354};\\\", \\\"{x:1325,y:838,t:1527272152371};\\\", \\\"{x:1306,y:843,t:1527272152389};\\\", \\\"{x:1291,y:846,t:1527272152405};\\\", \\\"{x:1279,y:848,t:1527272152422};\\\", \\\"{x:1275,y:849,t:1527272152439};\\\", \\\"{x:1268,y:851,t:1527272152456};\\\", \\\"{x:1265,y:851,t:1527272152472};\\\", \\\"{x:1264,y:851,t:1527272152488};\\\", \\\"{x:1265,y:850,t:1527272152868};\\\", \\\"{x:1267,y:850,t:1527272152876};\\\", \\\"{x:1270,y:848,t:1527272152889};\\\", \\\"{x:1276,y:843,t:1527272152906};\\\", \\\"{x:1277,y:837,t:1527272152924};\\\", \\\"{x:1281,y:825,t:1527272152939};\\\", \\\"{x:1296,y:804,t:1527272152956};\\\", \\\"{x:1303,y:788,t:1527272152973};\\\", \\\"{x:1307,y:775,t:1527272152990};\\\", \\\"{x:1308,y:768,t:1527272153006};\\\", \\\"{x:1308,y:766,t:1527272153022};\\\", \\\"{x:1309,y:764,t:1527272153123};\\\", \\\"{x:1312,y:763,t:1527272153139};\\\", \\\"{x:1318,y:761,t:1527272153156};\\\", \\\"{x:1322,y:761,t:1527272153172};\\\", \\\"{x:1327,y:759,t:1527272153189};\\\", \\\"{x:1329,y:758,t:1527272153206};\\\", \\\"{x:1330,y:758,t:1527272153223};\\\", \\\"{x:1332,y:758,t:1527272153244};\\\", \\\"{x:1333,y:757,t:1527272153283};\\\", \\\"{x:1334,y:756,t:1527272153308};\\\", \\\"{x:1336,y:756,t:1527272153756};\\\", \\\"{x:1337,y:756,t:1527272153774};\\\", \\\"{x:1337,y:760,t:1527272153790};\\\", \\\"{x:1337,y:772,t:1527272153808};\\\", \\\"{x:1326,y:784,t:1527272153823};\\\", \\\"{x:1314,y:797,t:1527272153840};\\\", \\\"{x:1306,y:808,t:1527272153857};\\\", \\\"{x:1294,y:822,t:1527272153874};\\\", \\\"{x:1280,y:835,t:1527272153890};\\\", \\\"{x:1253,y:851,t:1527272153908};\\\", \\\"{x:1237,y:859,t:1527272153924};\\\", \\\"{x:1227,y:862,t:1527272153940};\\\", \\\"{x:1220,y:864,t:1527272153957};\\\", \\\"{x:1216,y:864,t:1527272153974};\\\", \\\"{x:1213,y:864,t:1527272153991};\\\", \\\"{x:1212,y:864,t:1527272154008};\\\", \\\"{x:1211,y:864,t:1527272154023};\\\", \\\"{x:1210,y:864,t:1527272154041};\\\", \\\"{x:1207,y:864,t:1527272154057};\\\", \\\"{x:1204,y:864,t:1527272154074};\\\", \\\"{x:1200,y:864,t:1527272154090};\\\", \\\"{x:1191,y:857,t:1527272154108};\\\", \\\"{x:1187,y:852,t:1527272154124};\\\", \\\"{x:1182,y:846,t:1527272154140};\\\", \\\"{x:1180,y:842,t:1527272154157};\\\", \\\"{x:1179,y:839,t:1527272154173};\\\", \\\"{x:1179,y:836,t:1527272154190};\\\", \\\"{x:1179,y:835,t:1527272154207};\\\", \\\"{x:1179,y:833,t:1527272154236};\\\", \\\"{x:1179,y:832,t:1527272154276};\\\", \\\"{x:1181,y:832,t:1527272154308};\\\", \\\"{x:1183,y:832,t:1527272154324};\\\", \\\"{x:1186,y:832,t:1527272154341};\\\", \\\"{x:1192,y:832,t:1527272154357};\\\", \\\"{x:1195,y:831,t:1527272154375};\\\", \\\"{x:1196,y:831,t:1527272154390};\\\", \\\"{x:1197,y:831,t:1527272154407};\\\", \\\"{x:1198,y:831,t:1527272154427};\\\", \\\"{x:1199,y:831,t:1527272155060};\\\", \\\"{x:1199,y:834,t:1527272155075};\\\", \\\"{x:1199,y:844,t:1527272155091};\\\", \\\"{x:1198,y:860,t:1527272155108};\\\", \\\"{x:1191,y:884,t:1527272155125};\\\", \\\"{x:1186,y:909,t:1527272155141};\\\", \\\"{x:1183,y:935,t:1527272155158};\\\", \\\"{x:1180,y:956,t:1527272155174};\\\", \\\"{x:1177,y:971,t:1527272155192};\\\", \\\"{x:1175,y:984,t:1527272155208};\\\", \\\"{x:1173,y:989,t:1527272155224};\\\", \\\"{x:1173,y:991,t:1527272155241};\\\", \\\"{x:1173,y:992,t:1527272155257};\\\", \\\"{x:1172,y:993,t:1527272155356};\\\", \\\"{x:1171,y:993,t:1527272155420};\\\", \\\"{x:1170,y:992,t:1527272155428};\\\", \\\"{x:1170,y:991,t:1527272155441};\\\", \\\"{x:1170,y:987,t:1527272155458};\\\", \\\"{x:1170,y:983,t:1527272155474};\\\", \\\"{x:1170,y:979,t:1527272155492};\\\", \\\"{x:1170,y:973,t:1527272155508};\\\", \\\"{x:1170,y:968,t:1527272155525};\\\", \\\"{x:1170,y:964,t:1527272155541};\\\", \\\"{x:1170,y:959,t:1527272155558};\\\", \\\"{x:1169,y:956,t:1527272155576};\\\", \\\"{x:1169,y:954,t:1527272155591};\\\", \\\"{x:1168,y:953,t:1527272155628};\\\", \\\"{x:1166,y:953,t:1527272155676};\\\", \\\"{x:1166,y:954,t:1527272155692};\\\", \\\"{x:1165,y:955,t:1527272155708};\\\", \\\"{x:1162,y:957,t:1527272155725};\\\", \\\"{x:1161,y:961,t:1527272155742};\\\", \\\"{x:1160,y:963,t:1527272155759};\\\", \\\"{x:1158,y:966,t:1527272155776};\\\", \\\"{x:1158,y:967,t:1527272155792};\\\", \\\"{x:1157,y:968,t:1527272155853};\\\", \\\"{x:1156,y:968,t:1527272157044};\\\", \\\"{x:1157,y:967,t:1527272157059};\\\", \\\"{x:1159,y:962,t:1527272157075};\\\", \\\"{x:1160,y:960,t:1527272157093};\\\", \\\"{x:1163,y:956,t:1527272157109};\\\", \\\"{x:1165,y:953,t:1527272157126};\\\", \\\"{x:1168,y:948,t:1527272157143};\\\", \\\"{x:1171,y:942,t:1527272157160};\\\", \\\"{x:1176,y:934,t:1527272157177};\\\", \\\"{x:1182,y:920,t:1527272157193};\\\", \\\"{x:1185,y:912,t:1527272157209};\\\", \\\"{x:1195,y:897,t:1527272157226};\\\", \\\"{x:1201,y:883,t:1527272157242};\\\", \\\"{x:1206,y:855,t:1527272157259};\\\", \\\"{x:1210,y:832,t:1527272157277};\\\", \\\"{x:1214,y:816,t:1527272157294};\\\", \\\"{x:1219,y:802,t:1527272157309};\\\", \\\"{x:1223,y:793,t:1527272157326};\\\", \\\"{x:1223,y:787,t:1527272157343};\\\", \\\"{x:1227,y:781,t:1527272157359};\\\", \\\"{x:1229,y:777,t:1527272157376};\\\", \\\"{x:1230,y:774,t:1527272157393};\\\", \\\"{x:1230,y:772,t:1527272157409};\\\", \\\"{x:1232,y:770,t:1527272157427};\\\", \\\"{x:1233,y:769,t:1527272157443};\\\", \\\"{x:1234,y:768,t:1527272158420};\\\", \\\"{x:1236,y:768,t:1527272158427};\\\", \\\"{x:1240,y:768,t:1527272158444};\\\", \\\"{x:1242,y:768,t:1527272158460};\\\", \\\"{x:1243,y:768,t:1527272158477};\\\", \\\"{x:1244,y:768,t:1527272158596};\\\", \\\"{x:1244,y:771,t:1527272158611};\\\", \\\"{x:1244,y:780,t:1527272158627};\\\", \\\"{x:1244,y:784,t:1527272158644};\\\", \\\"{x:1244,y:790,t:1527272158660};\\\", \\\"{x:1244,y:793,t:1527272158677};\\\", \\\"{x:1243,y:797,t:1527272158694};\\\", \\\"{x:1243,y:799,t:1527272158710};\\\", \\\"{x:1242,y:800,t:1527272158727};\\\", \\\"{x:1241,y:802,t:1527272158744};\\\", \\\"{x:1240,y:805,t:1527272158761};\\\", \\\"{x:1238,y:808,t:1527272158777};\\\", \\\"{x:1238,y:810,t:1527272158794};\\\", \\\"{x:1238,y:811,t:1527272158810};\\\", \\\"{x:1238,y:812,t:1527272158827};\\\", \\\"{x:1239,y:812,t:1527272158884};\\\", \\\"{x:1242,y:810,t:1527272158895};\\\", \\\"{x:1254,y:802,t:1527272158911};\\\", \\\"{x:1270,y:796,t:1527272158927};\\\", \\\"{x:1289,y:786,t:1527272158945};\\\", \\\"{x:1302,y:781,t:1527272158961};\\\", \\\"{x:1313,y:775,t:1527272158977};\\\", \\\"{x:1319,y:772,t:1527272158994};\\\", \\\"{x:1324,y:770,t:1527272159012};\\\", \\\"{x:1324,y:769,t:1527272159028};\\\", \\\"{x:1325,y:768,t:1527272159059};\\\", \\\"{x:1327,y:768,t:1527272159084};\\\", \\\"{x:1329,y:768,t:1527272159116};\\\", \\\"{x:1330,y:767,t:1527272159132};\\\", \\\"{x:1331,y:766,t:1527272159144};\\\", \\\"{x:1332,y:765,t:1527272159161};\\\", \\\"{x:1335,y:765,t:1527272159177};\\\", \\\"{x:1337,y:764,t:1527272159213};\\\", \\\"{x:1338,y:764,t:1527272159252};\\\", \\\"{x:1339,y:764,t:1527272159267};\\\", \\\"{x:1340,y:764,t:1527272159278};\\\", \\\"{x:1342,y:763,t:1527272159295};\\\", \\\"{x:1343,y:763,t:1527272159340};\\\", \\\"{x:1344,y:762,t:1527272167419};\\\", \\\"{x:1346,y:761,t:1527272167434};\\\", \\\"{x:1349,y:761,t:1527272167451};\\\", \\\"{x:1348,y:761,t:1527272167812};\\\", \\\"{x:1348,y:763,t:1527272167819};\\\", \\\"{x:1346,y:766,t:1527272167835};\\\", \\\"{x:1345,y:770,t:1527272167852};\\\", \\\"{x:1342,y:776,t:1527272167868};\\\", \\\"{x:1342,y:779,t:1527272167885};\\\", \\\"{x:1339,y:786,t:1527272167901};\\\", \\\"{x:1337,y:792,t:1527272167918};\\\", \\\"{x:1334,y:801,t:1527272167934};\\\", \\\"{x:1331,y:810,t:1527272167951};\\\", \\\"{x:1329,y:816,t:1527272167968};\\\", \\\"{x:1327,y:820,t:1527272167985};\\\", \\\"{x:1325,y:825,t:1527272168002};\\\", \\\"{x:1325,y:828,t:1527272168018};\\\", \\\"{x:1322,y:833,t:1527272168035};\\\", \\\"{x:1319,y:839,t:1527272168051};\\\", \\\"{x:1317,y:844,t:1527272168067};\\\", \\\"{x:1313,y:850,t:1527272168085};\\\", \\\"{x:1310,y:855,t:1527272168102};\\\", \\\"{x:1308,y:859,t:1527272168119};\\\", \\\"{x:1306,y:863,t:1527272168135};\\\", \\\"{x:1303,y:868,t:1527272168152};\\\", \\\"{x:1301,y:871,t:1527272168168};\\\", \\\"{x:1298,y:876,t:1527272168185};\\\", \\\"{x:1294,y:883,t:1527272168203};\\\", \\\"{x:1294,y:884,t:1527272168219};\\\", \\\"{x:1291,y:888,t:1527272168235};\\\", \\\"{x:1287,y:893,t:1527272168251};\\\", \\\"{x:1284,y:897,t:1527272168269};\\\", \\\"{x:1282,y:900,t:1527272168285};\\\", \\\"{x:1279,y:904,t:1527272168302};\\\", \\\"{x:1276,y:908,t:1527272168319};\\\", \\\"{x:1274,y:911,t:1527272168335};\\\", \\\"{x:1272,y:913,t:1527272168352};\\\", \\\"{x:1271,y:917,t:1527272168369};\\\", \\\"{x:1267,y:923,t:1527272168385};\\\", \\\"{x:1265,y:926,t:1527272168403};\\\", \\\"{x:1262,y:932,t:1527272168420};\\\", \\\"{x:1261,y:934,t:1527272168434};\\\", \\\"{x:1260,y:939,t:1527272168452};\\\", \\\"{x:1260,y:943,t:1527272168469};\\\", \\\"{x:1258,y:946,t:1527272168484};\\\", \\\"{x:1258,y:949,t:1527272168503};\\\", \\\"{x:1258,y:952,t:1527272168519};\\\", \\\"{x:1258,y:953,t:1527272168535};\\\", \\\"{x:1258,y:954,t:1527272168552};\\\", \\\"{x:1259,y:955,t:1527272168828};\\\", \\\"{x:1259,y:952,t:1527272171684};\\\", \\\"{x:1259,y:949,t:1527272171692};\\\", \\\"{x:1261,y:946,t:1527272171704};\\\", \\\"{x:1263,y:939,t:1527272171722};\\\", \\\"{x:1267,y:930,t:1527272171738};\\\", \\\"{x:1271,y:921,t:1527272171755};\\\", \\\"{x:1275,y:904,t:1527272171771};\\\", \\\"{x:1278,y:893,t:1527272171787};\\\", \\\"{x:1282,y:881,t:1527272171805};\\\", \\\"{x:1286,y:869,t:1527272171821};\\\", \\\"{x:1291,y:852,t:1527272171838};\\\", \\\"{x:1296,y:830,t:1527272171856};\\\", \\\"{x:1302,y:810,t:1527272171871};\\\", \\\"{x:1307,y:796,t:1527272171889};\\\", \\\"{x:1309,y:783,t:1527272171905};\\\", \\\"{x:1313,y:774,t:1527272171921};\\\", \\\"{x:1313,y:765,t:1527272171938};\\\", \\\"{x:1315,y:756,t:1527272171956};\\\", \\\"{x:1316,y:746,t:1527272171971};\\\", \\\"{x:1317,y:741,t:1527272171988};\\\", \\\"{x:1319,y:738,t:1527272172006};\\\", \\\"{x:1321,y:732,t:1527272172021};\\\", \\\"{x:1321,y:730,t:1527272172038};\\\", \\\"{x:1322,y:728,t:1527272172055};\\\", \\\"{x:1323,y:727,t:1527272172075};\\\", \\\"{x:1324,y:727,t:1527272172099};\\\", \\\"{x:1325,y:727,t:1527272172123};\\\", \\\"{x:1328,y:727,t:1527272172139};\\\", \\\"{x:1335,y:727,t:1527272172155};\\\", \\\"{x:1349,y:731,t:1527272172171};\\\", \\\"{x:1357,y:734,t:1527272172188};\\\", \\\"{x:1360,y:736,t:1527272172205};\\\", \\\"{x:1362,y:739,t:1527272172222};\\\", \\\"{x:1362,y:740,t:1527272172238};\\\", \\\"{x:1362,y:742,t:1527272172255};\\\", \\\"{x:1362,y:744,t:1527272172272};\\\", \\\"{x:1362,y:745,t:1527272172287};\\\", \\\"{x:1362,y:746,t:1527272172355};\\\", \\\"{x:1361,y:747,t:1527272172386};\\\", \\\"{x:1360,y:747,t:1527272172403};\\\", \\\"{x:1359,y:749,t:1527272172411};\\\", \\\"{x:1358,y:749,t:1527272172422};\\\", \\\"{x:1355,y:749,t:1527272172438};\\\", \\\"{x:1354,y:749,t:1527272172459};\\\", \\\"{x:1353,y:750,t:1527272172472};\\\", \\\"{x:1352,y:750,t:1527272172488};\\\", \\\"{x:1351,y:750,t:1527272172515};\\\", \\\"{x:1351,y:751,t:1527272172531};\\\", \\\"{x:1349,y:751,t:1527272172588};\\\", \\\"{x:1348,y:752,t:1527272172676};\\\", \\\"{x:1347,y:753,t:1527272172732};\\\", \\\"{x:1347,y:754,t:1527272172747};\\\", \\\"{x:1346,y:754,t:1527272172755};\\\", \\\"{x:1345,y:755,t:1527272172779};\\\", \\\"{x:1345,y:756,t:1527272173123};\\\", \\\"{x:1345,y:758,t:1527272173139};\\\", \\\"{x:1344,y:758,t:1527272173156};\\\", \\\"{x:1344,y:760,t:1527272173179};\\\", \\\"{x:1343,y:760,t:1527272173189};\\\", \\\"{x:1342,y:762,t:1527272173206};\\\", \\\"{x:1339,y:767,t:1527272173222};\\\", \\\"{x:1335,y:771,t:1527272173238};\\\", \\\"{x:1331,y:777,t:1527272173256};\\\", \\\"{x:1323,y:788,t:1527272173272};\\\", \\\"{x:1314,y:800,t:1527272173289};\\\", \\\"{x:1305,y:810,t:1527272173306};\\\", \\\"{x:1296,y:819,t:1527272173321};\\\", \\\"{x:1282,y:830,t:1527272173339};\\\", \\\"{x:1276,y:834,t:1527272173356};\\\", \\\"{x:1272,y:836,t:1527272173379};\\\", \\\"{x:1268,y:838,t:1527272173389};\\\", \\\"{x:1261,y:842,t:1527272173406};\\\", \\\"{x:1254,y:845,t:1527272173422};\\\", \\\"{x:1247,y:848,t:1527272173439};\\\", \\\"{x:1242,y:849,t:1527272173456};\\\", \\\"{x:1233,y:852,t:1527272173472};\\\", \\\"{x:1225,y:853,t:1527272173490};\\\", \\\"{x:1211,y:854,t:1527272173506};\\\", \\\"{x:1200,y:857,t:1527272173523};\\\", \\\"{x:1187,y:859,t:1527272173540};\\\", \\\"{x:1183,y:862,t:1527272173556};\\\", \\\"{x:1180,y:865,t:1527272173573};\\\", \\\"{x:1180,y:869,t:1527272173590};\\\", \\\"{x:1179,y:873,t:1527272173606};\\\", \\\"{x:1178,y:884,t:1527272173623};\\\", \\\"{x:1176,y:894,t:1527272173639};\\\", \\\"{x:1174,y:903,t:1527272173656};\\\", \\\"{x:1171,y:914,t:1527272173673};\\\", \\\"{x:1170,y:922,t:1527272173689};\\\", \\\"{x:1169,y:930,t:1527272173706};\\\", \\\"{x:1167,y:935,t:1527272173723};\\\", \\\"{x:1167,y:940,t:1527272173739};\\\", \\\"{x:1167,y:941,t:1527272173756};\\\", \\\"{x:1167,y:943,t:1527272173773};\\\", \\\"{x:1166,y:945,t:1527272173796};\\\", \\\"{x:1166,y:946,t:1527272173819};\\\", \\\"{x:1166,y:947,t:1527272173828};\\\", \\\"{x:1166,y:948,t:1527272173839};\\\", \\\"{x:1166,y:949,t:1527272173857};\\\", \\\"{x:1166,y:951,t:1527272173873};\\\", \\\"{x:1165,y:952,t:1527272173892};\\\", \\\"{x:1165,y:953,t:1527272173906};\\\", \\\"{x:1163,y:955,t:1527272173924};\\\", \\\"{x:1162,y:956,t:1527272173948};\\\", \\\"{x:1162,y:957,t:1527272173963};\\\", \\\"{x:1161,y:957,t:1527272173973};\\\", \\\"{x:1160,y:958,t:1527272173990};\\\", \\\"{x:1159,y:958,t:1527272174019};\\\", \\\"{x:1158,y:958,t:1527272174028};\\\", \\\"{x:1157,y:958,t:1527272174040};\\\", \\\"{x:1156,y:960,t:1527272174057};\\\", \\\"{x:1154,y:960,t:1527272174073};\\\", \\\"{x:1151,y:961,t:1527272174090};\\\", \\\"{x:1149,y:963,t:1527272174106};\\\", \\\"{x:1146,y:964,t:1527272174123};\\\", \\\"{x:1145,y:964,t:1527272174139};\\\", \\\"{x:1145,y:965,t:1527272174156};\\\", \\\"{x:1144,y:965,t:1527272174173};\\\", \\\"{x:1143,y:965,t:1527272174190};\\\", \\\"{x:1143,y:966,t:1527272174206};\\\", \\\"{x:1142,y:966,t:1527272174227};\\\", \\\"{x:1141,y:966,t:1527272175148};\\\", \\\"{x:1139,y:966,t:1527272175157};\\\", \\\"{x:1138,y:966,t:1527272175175};\\\", \\\"{x:1135,y:966,t:1527272175190};\\\", \\\"{x:1133,y:966,t:1527272175207};\\\", \\\"{x:1132,y:966,t:1527272175284};\\\", \\\"{x:1131,y:966,t:1527272175308};\\\", \\\"{x:1130,y:963,t:1527272175324};\\\", \\\"{x:1130,y:959,t:1527272175341};\\\", \\\"{x:1129,y:956,t:1527272175357};\\\", \\\"{x:1129,y:954,t:1527272175374};\\\", \\\"{x:1129,y:950,t:1527272175391};\\\", \\\"{x:1129,y:947,t:1527272175407};\\\", \\\"{x:1129,y:945,t:1527272175424};\\\", \\\"{x:1129,y:941,t:1527272175441};\\\", \\\"{x:1132,y:934,t:1527272175458};\\\", \\\"{x:1133,y:927,t:1527272175475};\\\", \\\"{x:1134,y:917,t:1527272175491};\\\", \\\"{x:1138,y:905,t:1527272175507};\\\", \\\"{x:1144,y:890,t:1527272175524};\\\", \\\"{x:1149,y:871,t:1527272175541};\\\", \\\"{x:1156,y:849,t:1527272175557};\\\", \\\"{x:1163,y:824,t:1527272175575};\\\", \\\"{x:1170,y:797,t:1527272175591};\\\", \\\"{x:1177,y:772,t:1527272175607};\\\", \\\"{x:1184,y:751,t:1527272175624};\\\", \\\"{x:1192,y:732,t:1527272175641};\\\", \\\"{x:1197,y:715,t:1527272175658};\\\", \\\"{x:1204,y:702,t:1527272175674};\\\", \\\"{x:1210,y:685,t:1527272175691};\\\", \\\"{x:1214,y:679,t:1527272175707};\\\", \\\"{x:1215,y:673,t:1527272175724};\\\", \\\"{x:1218,y:668,t:1527272175741};\\\", \\\"{x:1223,y:660,t:1527272175758};\\\", \\\"{x:1228,y:652,t:1527272175774};\\\", \\\"{x:1232,y:641,t:1527272175791};\\\", \\\"{x:1238,y:630,t:1527272175808};\\\", \\\"{x:1242,y:620,t:1527272175825};\\\", \\\"{x:1250,y:608,t:1527272175841};\\\", \\\"{x:1254,y:598,t:1527272175858};\\\", \\\"{x:1260,y:589,t:1527272175874};\\\", \\\"{x:1264,y:580,t:1527272175891};\\\", \\\"{x:1268,y:571,t:1527272175908};\\\", \\\"{x:1271,y:565,t:1527272175924};\\\", \\\"{x:1273,y:562,t:1527272175941};\\\", \\\"{x:1274,y:560,t:1527272175958};\\\", \\\"{x:1275,y:559,t:1527272175974};\\\", \\\"{x:1275,y:558,t:1527272176012};\\\", \\\"{x:1277,y:559,t:1527272176764};\\\", \\\"{x:1278,y:562,t:1527272176775};\\\", \\\"{x:1281,y:568,t:1527272176792};\\\", \\\"{x:1286,y:581,t:1527272176809};\\\", \\\"{x:1293,y:594,t:1527272176826};\\\", \\\"{x:1298,y:604,t:1527272176843};\\\", \\\"{x:1303,y:615,t:1527272176858};\\\", \\\"{x:1309,y:630,t:1527272176876};\\\", \\\"{x:1313,y:640,t:1527272176892};\\\", \\\"{x:1319,y:650,t:1527272176908};\\\", \\\"{x:1323,y:661,t:1527272176925};\\\", \\\"{x:1328,y:672,t:1527272176943};\\\", \\\"{x:1331,y:680,t:1527272176958};\\\", \\\"{x:1335,y:688,t:1527272176976};\\\", \\\"{x:1338,y:695,t:1527272176992};\\\", \\\"{x:1341,y:699,t:1527272177009};\\\", \\\"{x:1343,y:708,t:1527272177025};\\\", \\\"{x:1346,y:712,t:1527272177042};\\\", \\\"{x:1349,y:719,t:1527272177059};\\\", \\\"{x:1349,y:724,t:1527272177075};\\\", \\\"{x:1352,y:729,t:1527272177092};\\\", \\\"{x:1353,y:734,t:1527272177109};\\\", \\\"{x:1357,y:740,t:1527272177125};\\\", \\\"{x:1357,y:743,t:1527272177142};\\\", \\\"{x:1358,y:746,t:1527272177159};\\\", \\\"{x:1359,y:748,t:1527272177175};\\\", \\\"{x:1359,y:750,t:1527272177192};\\\", \\\"{x:1360,y:752,t:1527272177209};\\\", \\\"{x:1360,y:753,t:1527272177225};\\\", \\\"{x:1361,y:755,t:1527272177241};\\\", \\\"{x:1361,y:758,t:1527272177258};\\\", \\\"{x:1363,y:761,t:1527272177274};\\\", \\\"{x:1363,y:763,t:1527272177291};\\\", \\\"{x:1363,y:764,t:1527272177338};\\\", \\\"{x:1363,y:765,t:1527272177363};\\\", \\\"{x:1363,y:766,t:1527272177394};\\\", \\\"{x:1364,y:767,t:1527272177475};\\\", \\\"{x:1364,y:768,t:1527272177524};\\\", \\\"{x:1364,y:769,t:1527272177564};\\\", \\\"{x:1363,y:769,t:1527272180124};\\\", \\\"{x:1353,y:769,t:1527272180132};\\\", \\\"{x:1335,y:769,t:1527272180145};\\\", \\\"{x:1271,y:769,t:1527272180162};\\\", \\\"{x:1185,y:769,t:1527272180179};\\\", \\\"{x:1077,y:769,t:1527272180194};\\\", \\\"{x:872,y:769,t:1527272180211};\\\", \\\"{x:747,y:769,t:1527272180228};\\\", \\\"{x:636,y:769,t:1527272180244};\\\", \\\"{x:553,y:769,t:1527272180262};\\\", \\\"{x:505,y:769,t:1527272180278};\\\", \\\"{x:485,y:769,t:1527272180295};\\\", \\\"{x:477,y:770,t:1527272180312};\\\", \\\"{x:473,y:770,t:1527272180328};\\\", \\\"{x:467,y:773,t:1527272180344};\\\", \\\"{x:464,y:774,t:1527272180362};\\\", \\\"{x:462,y:776,t:1527272180379};\\\", \\\"{x:461,y:776,t:1527272180451};\\\", \\\"{x:461,y:773,t:1527272180461};\\\", \\\"{x:467,y:766,t:1527272180478};\\\", \\\"{x:477,y:757,t:1527272180494};\\\", \\\"{x:491,y:751,t:1527272180513};\\\", \\\"{x:499,y:747,t:1527272180528};\\\", \\\"{x:503,y:745,t:1527272180545};\\\", \\\"{x:504,y:744,t:1527272180555};\\\", \\\"{x:506,y:744,t:1527272181067};\\\", \\\"{x:507,y:744,t:1527272181083};\\\", \\\"{x:509,y:744,t:1527272181091};\\\", \\\"{x:511,y:744,t:1527272181107};\\\", \\\"{x:517,y:744,t:1527272181123};\\\", \\\"{x:526,y:744,t:1527272181139};\\\", \\\"{x:539,y:744,t:1527272181157};\\\", \\\"{x:557,y:744,t:1527272181172};\\\", \\\"{x:585,y:744,t:1527272181191};\\\", \\\"{x:625,y:744,t:1527272181206};\\\", \\\"{x:695,y:744,t:1527272181228};\\\", \\\"{x:753,y:744,t:1527272181246};\\\", \\\"{x:800,y:748,t:1527272181263};\\\", \\\"{x:853,y:748,t:1527272181279};\\\", \\\"{x:903,y:748,t:1527272181295};\\\", \\\"{x:948,y:748,t:1527272181313};\\\", \\\"{x:993,y:748,t:1527272181329};\\\", \\\"{x:1038,y:748,t:1527272181346};\\\", \\\"{x:1086,y:748,t:1527272181362};\\\", \\\"{x:1113,y:748,t:1527272181378};\\\", \\\"{x:1137,y:748,t:1527272181396};\\\", \\\"{x:1158,y:748,t:1527272181413};\\\", \\\"{x:1175,y:748,t:1527272181430};\\\", \\\"{x:1189,y:748,t:1527272181446};\\\", \\\"{x:1204,y:748,t:1527272181463};\\\", \\\"{x:1214,y:748,t:1527272181479};\\\", \\\"{x:1222,y:747,t:1527272181496};\\\", \\\"{x:1228,y:745,t:1527272181513};\\\", \\\"{x:1232,y:744,t:1527272181529};\\\", \\\"{x:1235,y:744,t:1527272181547};\\\", \\\"{x:1237,y:742,t:1527272181564};\\\", \\\"{x:1239,y:742,t:1527272181620};\\\", \\\"{x:1241,y:742,t:1527272181635};\\\", \\\"{x:1243,y:742,t:1527272181646};\\\", \\\"{x:1245,y:742,t:1527272181664};\\\", \\\"{x:1249,y:742,t:1527272181680};\\\", \\\"{x:1251,y:742,t:1527272181697};\\\", \\\"{x:1254,y:742,t:1527272181714};\\\", \\\"{x:1260,y:743,t:1527272181730};\\\", \\\"{x:1270,y:744,t:1527272181746};\\\", \\\"{x:1288,y:748,t:1527272181763};\\\", \\\"{x:1296,y:749,t:1527272181780};\\\", \\\"{x:1302,y:749,t:1527272181796};\\\", \\\"{x:1305,y:749,t:1527272181813};\\\", \\\"{x:1306,y:749,t:1527272181830};\\\", \\\"{x:1308,y:750,t:1527272181995};\\\", \\\"{x:1309,y:751,t:1527272182012};\\\", \\\"{x:1310,y:752,t:1527272182028};\\\", \\\"{x:1312,y:754,t:1527272182035};\\\", \\\"{x:1315,y:756,t:1527272182051};\\\", \\\"{x:1318,y:757,t:1527272182063};\\\", \\\"{x:1323,y:759,t:1527272182081};\\\", \\\"{x:1328,y:762,t:1527272182097};\\\", \\\"{x:1330,y:763,t:1527272182113};\\\", \\\"{x:1332,y:764,t:1527272182130};\\\", \\\"{x:1334,y:764,t:1527272182147};\\\", \\\"{x:1334,y:765,t:1527272182212};\\\", \\\"{x:1335,y:766,t:1527272182219};\\\", \\\"{x:1336,y:768,t:1527272182231};\\\", \\\"{x:1338,y:769,t:1527272182247};\\\", \\\"{x:1338,y:770,t:1527272182264};\\\", \\\"{x:1339,y:770,t:1527272183027};\\\", \\\"{x:1340,y:770,t:1527272183036};\\\", \\\"{x:1341,y:770,t:1527272183067};\\\", \\\"{x:1342,y:770,t:1527272183108};\\\", \\\"{x:1343,y:770,t:1527272183444};\\\", \\\"{x:1344,y:770,t:1527272183459};\\\", \\\"{x:1346,y:770,t:1527272183467};\\\", \\\"{x:1348,y:772,t:1527272183483};\\\", \\\"{x:1349,y:772,t:1527272183499};\\\", \\\"{x:1353,y:772,t:1527272183514};\\\", \\\"{x:1357,y:772,t:1527272183531};\\\", \\\"{x:1359,y:774,t:1527272183548};\\\", \\\"{x:1361,y:776,t:1527272183564};\\\", \\\"{x:1365,y:780,t:1527272183581};\\\", \\\"{x:1368,y:784,t:1527272183599};\\\", \\\"{x:1374,y:791,t:1527272183615};\\\", \\\"{x:1377,y:798,t:1527272183631};\\\", \\\"{x:1382,y:810,t:1527272183649};\\\", \\\"{x:1386,y:820,t:1527272183665};\\\", \\\"{x:1389,y:827,t:1527272183682};\\\", \\\"{x:1391,y:831,t:1527272183698};\\\", \\\"{x:1394,y:837,t:1527272183715};\\\", \\\"{x:1397,y:841,t:1527272183731};\\\", \\\"{x:1398,y:844,t:1527272183748};\\\", \\\"{x:1398,y:846,t:1527272183765};\\\", \\\"{x:1401,y:849,t:1527272183781};\\\", \\\"{x:1402,y:851,t:1527272183799};\\\", \\\"{x:1403,y:853,t:1527272183816};\\\", \\\"{x:1405,y:857,t:1527272183831};\\\", \\\"{x:1407,y:860,t:1527272183848};\\\", \\\"{x:1408,y:864,t:1527272183865};\\\", \\\"{x:1410,y:870,t:1527272183882};\\\", \\\"{x:1411,y:872,t:1527272183899};\\\", \\\"{x:1413,y:878,t:1527272183916};\\\", \\\"{x:1413,y:881,t:1527272183931};\\\", \\\"{x:1415,y:883,t:1527272183948};\\\", \\\"{x:1415,y:885,t:1527272183966};\\\", \\\"{x:1416,y:889,t:1527272183982};\\\", \\\"{x:1418,y:890,t:1527272183998};\\\", \\\"{x:1419,y:892,t:1527272184015};\\\", \\\"{x:1419,y:894,t:1527272184031};\\\", \\\"{x:1421,y:896,t:1527272184049};\\\", \\\"{x:1423,y:900,t:1527272184066};\\\", \\\"{x:1425,y:903,t:1527272184082};\\\", \\\"{x:1426,y:904,t:1527272184099};\\\", \\\"{x:1429,y:908,t:1527272184116};\\\", \\\"{x:1433,y:911,t:1527272184132};\\\", \\\"{x:1437,y:915,t:1527272184149};\\\", \\\"{x:1444,y:922,t:1527272184166};\\\", \\\"{x:1451,y:927,t:1527272184183};\\\", \\\"{x:1456,y:930,t:1527272184199};\\\", \\\"{x:1459,y:933,t:1527272184216};\\\", \\\"{x:1461,y:935,t:1527272184233};\\\", \\\"{x:1462,y:936,t:1527272184252};\\\", \\\"{x:1463,y:937,t:1527272184275};\\\", \\\"{x:1463,y:938,t:1527272184307};\\\", \\\"{x:1463,y:939,t:1527272184323};\\\", \\\"{x:1463,y:941,t:1527272184339};\\\", \\\"{x:1463,y:942,t:1527272184348};\\\", \\\"{x:1463,y:943,t:1527272184365};\\\", \\\"{x:1463,y:945,t:1527272184383};\\\", \\\"{x:1463,y:946,t:1527272184399};\\\", \\\"{x:1463,y:947,t:1527272184415};\\\", \\\"{x:1463,y:948,t:1527272184432};\\\", \\\"{x:1463,y:949,t:1527272184451};\\\", \\\"{x:1463,y:950,t:1527272184475};\\\", \\\"{x:1463,y:951,t:1527272184499};\\\", \\\"{x:1463,y:952,t:1527272184571};\\\", \\\"{x:1463,y:953,t:1527272184603};\\\", \\\"{x:1463,y:954,t:1527272184627};\\\", \\\"{x:1463,y:955,t:1527272184667};\\\", \\\"{x:1463,y:957,t:1527272184723};\\\", \\\"{x:1462,y:957,t:1527272184739};\\\", \\\"{x:1461,y:959,t:1527272184764};\\\", \\\"{x:1460,y:959,t:1527272184795};\\\", \\\"{x:1459,y:959,t:1527272184900};\\\", \\\"{x:1458,y:959,t:1527272184916};\\\", \\\"{x:1457,y:959,t:1527272184933};\\\", \\\"{x:1456,y:959,t:1527272185012};\\\", \\\"{x:1455,y:959,t:1527272185027};\\\", \\\"{x:1454,y:959,t:1527272185043};\\\", \\\"{x:1453,y:959,t:1527272185084};\\\", \\\"{x:1452,y:959,t:1527272185100};\\\", \\\"{x:1451,y:958,t:1527272185123};\\\", \\\"{x:1449,y:958,t:1527272185155};\\\", \\\"{x:1448,y:958,t:1527272185196};\\\", \\\"{x:1446,y:958,t:1527272191853};\\\", \\\"{x:1445,y:958,t:1527272191958};\\\", \\\"{x:1443,y:958,t:1527272192772};\\\", \\\"{x:1439,y:957,t:1527272192781};\\\", \\\"{x:1427,y:952,t:1527272192798};\\\", \\\"{x:1417,y:947,t:1527272192815};\\\", \\\"{x:1406,y:942,t:1527272192831};\\\", \\\"{x:1397,y:938,t:1527272192847};\\\", \\\"{x:1388,y:934,t:1527272192865};\\\", \\\"{x:1381,y:929,t:1527272192881};\\\", \\\"{x:1376,y:922,t:1527272192898};\\\", \\\"{x:1370,y:911,t:1527272192915};\\\", \\\"{x:1355,y:885,t:1527272192932};\\\", \\\"{x:1344,y:867,t:1527272192948};\\\", \\\"{x:1339,y:858,t:1527272192965};\\\", \\\"{x:1335,y:850,t:1527272192982};\\\", \\\"{x:1333,y:843,t:1527272192998};\\\", \\\"{x:1330,y:836,t:1527272193015};\\\", \\\"{x:1329,y:826,t:1527272193032};\\\", \\\"{x:1328,y:812,t:1527272193049};\\\", \\\"{x:1326,y:799,t:1527272193065};\\\", \\\"{x:1324,y:785,t:1527272193082};\\\", \\\"{x:1324,y:777,t:1527272193099};\\\", \\\"{x:1324,y:774,t:1527272193115};\\\", \\\"{x:1324,y:771,t:1527272193133};\\\", \\\"{x:1324,y:770,t:1527272193172};\\\", \\\"{x:1324,y:769,t:1527272193182};\\\", \\\"{x:1324,y:765,t:1527272193198};\\\", \\\"{x:1326,y:758,t:1527272193216};\\\", \\\"{x:1327,y:752,t:1527272193233};\\\", \\\"{x:1330,y:746,t:1527272193248};\\\", \\\"{x:1333,y:741,t:1527272193266};\\\", \\\"{x:1334,y:738,t:1527272193283};\\\", \\\"{x:1335,y:733,t:1527272193299};\\\", \\\"{x:1337,y:727,t:1527272193315};\\\", \\\"{x:1339,y:720,t:1527272193333};\\\", \\\"{x:1339,y:716,t:1527272193349};\\\", \\\"{x:1339,y:713,t:1527272193366};\\\", \\\"{x:1339,y:711,t:1527272193383};\\\", \\\"{x:1339,y:710,t:1527272193400};\\\", \\\"{x:1339,y:711,t:1527272196973};\\\", \\\"{x:1339,y:715,t:1527272196986};\\\", \\\"{x:1339,y:719,t:1527272197002};\\\", \\\"{x:1339,y:724,t:1527272197019};\\\", \\\"{x:1339,y:728,t:1527272197036};\\\", \\\"{x:1339,y:732,t:1527272197052};\\\", \\\"{x:1338,y:733,t:1527272197069};\\\", \\\"{x:1338,y:735,t:1527272197085};\\\", \\\"{x:1338,y:737,t:1527272197102};\\\", \\\"{x:1338,y:739,t:1527272197119};\\\", \\\"{x:1338,y:742,t:1527272197135};\\\", \\\"{x:1337,y:745,t:1527272197152};\\\", \\\"{x:1335,y:750,t:1527272197169};\\\", \\\"{x:1334,y:752,t:1527272197185};\\\", \\\"{x:1333,y:755,t:1527272197202};\\\", \\\"{x:1332,y:757,t:1527272197217};\\\", \\\"{x:1330,y:761,t:1527272197235};\\\", \\\"{x:1322,y:769,t:1527272197252};\\\", \\\"{x:1316,y:774,t:1527272197268};\\\", \\\"{x:1302,y:782,t:1527272197285};\\\", \\\"{x:1282,y:787,t:1527272197302};\\\", \\\"{x:1258,y:794,t:1527272197318};\\\", \\\"{x:1237,y:799,t:1527272197335};\\\", \\\"{x:1220,y:804,t:1527272197352};\\\", \\\"{x:1206,y:806,t:1527272197368};\\\", \\\"{x:1197,y:808,t:1527272197385};\\\", \\\"{x:1193,y:810,t:1527272197402};\\\", \\\"{x:1189,y:813,t:1527272197418};\\\", \\\"{x:1185,y:814,t:1527272197435};\\\", \\\"{x:1183,y:817,t:1527272197452};\\\", \\\"{x:1182,y:818,t:1527272197469};\\\", \\\"{x:1182,y:819,t:1527272197485};\\\", \\\"{x:1181,y:820,t:1527272197502};\\\", \\\"{x:1181,y:821,t:1527272197519};\\\", \\\"{x:1180,y:822,t:1527272197535};\\\", \\\"{x:1180,y:823,t:1527272197553};\\\", \\\"{x:1180,y:824,t:1527272197573};\\\", \\\"{x:1180,y:825,t:1527272197597};\\\", \\\"{x:1181,y:826,t:1527272197621};\\\", \\\"{x:1182,y:827,t:1527272197636};\\\", \\\"{x:1183,y:827,t:1527272197653};\\\", \\\"{x:1186,y:827,t:1527272197669};\\\", \\\"{x:1194,y:827,t:1527272197686};\\\", \\\"{x:1201,y:828,t:1527272197703};\\\", \\\"{x:1207,y:828,t:1527272197720};\\\", \\\"{x:1212,y:828,t:1527272197737};\\\", \\\"{x:1214,y:828,t:1527272197753};\\\", \\\"{x:1215,y:828,t:1527272197837};\\\", \\\"{x:1215,y:829,t:1527272199548};\\\", \\\"{x:1213,y:830,t:1527272199685};\\\", \\\"{x:1213,y:831,t:1527272199700};\\\", \\\"{x:1213,y:832,t:1527272199716};\\\", \\\"{x:1213,y:834,t:1527272199733};\\\", \\\"{x:1212,y:835,t:1527272199740};\\\", \\\"{x:1210,y:838,t:1527272199755};\\\", \\\"{x:1208,y:844,t:1527272199771};\\\", \\\"{x:1204,y:856,t:1527272199788};\\\", \\\"{x:1202,y:871,t:1527272199804};\\\", \\\"{x:1200,y:892,t:1527272199820};\\\", \\\"{x:1198,y:902,t:1527272199838};\\\", \\\"{x:1198,y:910,t:1527272199854};\\\", \\\"{x:1197,y:914,t:1527272199871};\\\", \\\"{x:1197,y:916,t:1527272199888};\\\", \\\"{x:1196,y:920,t:1527272199905};\\\", \\\"{x:1196,y:921,t:1527272199921};\\\", \\\"{x:1196,y:923,t:1527272199941};\\\", \\\"{x:1195,y:924,t:1527272199957};\\\", \\\"{x:1195,y:926,t:1527272199981};\\\", \\\"{x:1194,y:927,t:1527272199997};\\\", \\\"{x:1192,y:929,t:1527272200020};\\\", \\\"{x:1190,y:931,t:1527272200038};\\\", \\\"{x:1182,y:935,t:1527272200055};\\\", \\\"{x:1173,y:939,t:1527272200071};\\\", \\\"{x:1166,y:942,t:1527272200088};\\\", \\\"{x:1158,y:944,t:1527272200105};\\\", \\\"{x:1153,y:947,t:1527272200121};\\\", \\\"{x:1151,y:948,t:1527272200138};\\\", \\\"{x:1148,y:951,t:1527272200155};\\\", \\\"{x:1147,y:953,t:1527272200171};\\\", \\\"{x:1147,y:954,t:1527272200188};\\\", \\\"{x:1145,y:956,t:1527272200205};\\\", \\\"{x:1145,y:957,t:1527272200221};\\\", \\\"{x:1145,y:959,t:1527272200238};\\\", \\\"{x:1145,y:960,t:1527272200261};\\\", \\\"{x:1145,y:961,t:1527272200276};\\\", \\\"{x:1145,y:962,t:1527272200301};\\\", \\\"{x:1145,y:964,t:1527272200341};\\\", \\\"{x:1145,y:965,t:1527272200429};\\\", \\\"{x:1145,y:966,t:1527272200460};\\\", \\\"{x:1145,y:967,t:1527272200472};\\\", \\\"{x:1139,y:967,t:1527272200488};\\\", \\\"{x:1135,y:967,t:1527272200505};\\\", \\\"{x:1127,y:967,t:1527272200521};\\\", \\\"{x:1119,y:967,t:1527272200538};\\\", \\\"{x:1111,y:967,t:1527272200555};\\\", \\\"{x:1101,y:967,t:1527272200572};\\\", \\\"{x:1092,y:964,t:1527272200588};\\\", \\\"{x:1086,y:963,t:1527272200605};\\\", \\\"{x:1084,y:963,t:1527272200621};\\\", \\\"{x:1082,y:963,t:1527272200660};\\\", \\\"{x:1082,y:962,t:1527272200780};\\\", \\\"{x:1082,y:961,t:1527272200788};\\\", \\\"{x:1082,y:959,t:1527272200805};\\\", \\\"{x:1082,y:958,t:1527272200821};\\\", \\\"{x:1082,y:955,t:1527272200838};\\\", \\\"{x:1085,y:950,t:1527272200855};\\\", \\\"{x:1090,y:940,t:1527272200871};\\\", \\\"{x:1095,y:926,t:1527272200888};\\\", \\\"{x:1104,y:909,t:1527272200905};\\\", \\\"{x:1111,y:900,t:1527272200922};\\\", \\\"{x:1116,y:892,t:1527272200939};\\\", \\\"{x:1123,y:881,t:1527272200954};\\\", \\\"{x:1131,y:871,t:1527272200972};\\\", \\\"{x:1145,y:849,t:1527272200988};\\\", \\\"{x:1154,y:835,t:1527272201005};\\\", \\\"{x:1164,y:815,t:1527272201021};\\\", \\\"{x:1175,y:795,t:1527272201039};\\\", \\\"{x:1185,y:779,t:1527272201055};\\\", \\\"{x:1191,y:767,t:1527272201072};\\\", \\\"{x:1196,y:757,t:1527272201088};\\\", \\\"{x:1202,y:746,t:1527272201104};\\\", \\\"{x:1206,y:735,t:1527272201122};\\\", \\\"{x:1210,y:724,t:1527272201138};\\\", \\\"{x:1214,y:713,t:1527272201155};\\\", \\\"{x:1216,y:706,t:1527272201172};\\\", \\\"{x:1220,y:697,t:1527272201189};\\\", \\\"{x:1221,y:694,t:1527272201206};\\\", \\\"{x:1222,y:693,t:1527272201229};\\\", \\\"{x:1222,y:692,t:1527272201239};\\\", \\\"{x:1222,y:691,t:1527272201255};\\\", \\\"{x:1223,y:689,t:1527272201272};\\\", \\\"{x:1224,y:687,t:1527272201289};\\\", \\\"{x:1226,y:683,t:1527272201305};\\\", \\\"{x:1226,y:680,t:1527272201322};\\\", \\\"{x:1228,y:676,t:1527272201339};\\\", \\\"{x:1229,y:674,t:1527272201356};\\\", \\\"{x:1229,y:668,t:1527272201372};\\\", \\\"{x:1232,y:659,t:1527272201389};\\\", \\\"{x:1233,y:654,t:1527272201405};\\\", \\\"{x:1236,y:645,t:1527272201422};\\\", \\\"{x:1238,y:638,t:1527272201439};\\\", \\\"{x:1240,y:630,t:1527272201456};\\\", \\\"{x:1242,y:625,t:1527272201472};\\\", \\\"{x:1244,y:619,t:1527272201489};\\\", \\\"{x:1249,y:609,t:1527272201506};\\\", \\\"{x:1255,y:601,t:1527272201522};\\\", \\\"{x:1259,y:593,t:1527272201539};\\\", \\\"{x:1261,y:588,t:1527272201556};\\\", \\\"{x:1265,y:583,t:1527272201572};\\\", \\\"{x:1267,y:578,t:1527272201588};\\\", \\\"{x:1268,y:576,t:1527272201605};\\\", \\\"{x:1269,y:575,t:1527272201622};\\\", \\\"{x:1270,y:573,t:1527272201638};\\\", \\\"{x:1271,y:572,t:1527272201656};\\\", \\\"{x:1271,y:571,t:1527272201672};\\\", \\\"{x:1271,y:569,t:1527272201693};\\\", \\\"{x:1272,y:569,t:1527272201706};\\\", \\\"{x:1272,y:568,t:1527272202797};\\\", \\\"{x:1274,y:568,t:1527272202807};\\\", \\\"{x:1279,y:565,t:1527272202823};\\\", \\\"{x:1281,y:564,t:1527272202840};\\\", \\\"{x:1283,y:563,t:1527272202857};\\\", \\\"{x:1286,y:561,t:1527272202872};\\\", \\\"{x:1287,y:560,t:1527272202891};\\\", \\\"{x:1286,y:561,t:1527272205086};\\\", \\\"{x:1282,y:568,t:1527272205108};\\\", \\\"{x:1275,y:576,t:1527272205125};\\\", \\\"{x:1273,y:582,t:1527272205142};\\\", \\\"{x:1271,y:585,t:1527272205159};\\\", \\\"{x:1268,y:590,t:1527272205175};\\\", \\\"{x:1263,y:600,t:1527272205192};\\\", \\\"{x:1258,y:608,t:1527272205209};\\\", \\\"{x:1253,y:616,t:1527272205225};\\\", \\\"{x:1246,y:627,t:1527272205242};\\\", \\\"{x:1241,y:636,t:1527272205259};\\\", \\\"{x:1233,y:650,t:1527272205275};\\\", \\\"{x:1223,y:662,t:1527272205292};\\\", \\\"{x:1216,y:677,t:1527272205308};\\\", \\\"{x:1211,y:685,t:1527272205325};\\\", \\\"{x:1206,y:693,t:1527272205342};\\\", \\\"{x:1202,y:702,t:1527272205359};\\\", \\\"{x:1197,y:713,t:1527272205375};\\\", \\\"{x:1192,y:724,t:1527272205392};\\\", \\\"{x:1189,y:732,t:1527272205409};\\\", \\\"{x:1185,y:738,t:1527272205425};\\\", \\\"{x:1183,y:743,t:1527272205442};\\\", \\\"{x:1181,y:747,t:1527272205459};\\\", \\\"{x:1180,y:748,t:1527272205476};\\\", \\\"{x:1178,y:751,t:1527272205493};\\\", \\\"{x:1177,y:753,t:1527272205509};\\\", \\\"{x:1172,y:757,t:1527272205526};\\\", \\\"{x:1168,y:759,t:1527272205542};\\\", \\\"{x:1166,y:760,t:1527272205559};\\\", \\\"{x:1164,y:761,t:1527272205575};\\\", \\\"{x:1163,y:761,t:1527272205592};\\\", \\\"{x:1163,y:762,t:1527272205805};\\\", \\\"{x:1164,y:762,t:1527272205813};\\\", \\\"{x:1165,y:762,t:1527272205826};\\\", \\\"{x:1168,y:762,t:1527272205842};\\\", \\\"{x:1170,y:762,t:1527272205859};\\\", \\\"{x:1173,y:762,t:1527272205876};\\\", \\\"{x:1174,y:762,t:1527272205892};\\\", \\\"{x:1176,y:762,t:1527272205909};\\\", \\\"{x:1177,y:762,t:1527272205942};\\\", \\\"{x:1178,y:762,t:1527272205964};\\\", \\\"{x:1179,y:762,t:1527272207005};\\\", \\\"{x:1180,y:762,t:1527272209180};\\\", \\\"{x:1181,y:762,t:1527272209195};\\\", \\\"{x:1184,y:764,t:1527272209213};\\\", \\\"{x:1186,y:765,t:1527272209228};\\\", \\\"{x:1188,y:766,t:1527272209246};\\\", \\\"{x:1191,y:769,t:1527272209262};\\\", \\\"{x:1192,y:769,t:1527272209278};\\\", \\\"{x:1193,y:770,t:1527272209295};\\\", \\\"{x:1196,y:771,t:1527272209312};\\\", \\\"{x:1197,y:772,t:1527272209328};\\\", \\\"{x:1199,y:773,t:1527272209345};\\\", \\\"{x:1200,y:773,t:1527272209362};\\\", \\\"{x:1201,y:774,t:1527272209378};\\\", \\\"{x:1202,y:775,t:1527272209395};\\\", \\\"{x:1204,y:776,t:1527272209413};\\\", \\\"{x:1205,y:778,t:1527272209428};\\\", \\\"{x:1206,y:779,t:1527272209460};\\\", \\\"{x:1207,y:780,t:1527272209485};\\\", \\\"{x:1208,y:781,t:1527272209495};\\\", \\\"{x:1209,y:782,t:1527272209511};\\\", \\\"{x:1209,y:784,t:1527272209528};\\\", \\\"{x:1209,y:786,t:1527272209545};\\\", \\\"{x:1211,y:788,t:1527272209561};\\\", \\\"{x:1211,y:790,t:1527272209579};\\\", \\\"{x:1213,y:792,t:1527272209594};\\\", \\\"{x:1215,y:796,t:1527272209611};\\\", \\\"{x:1215,y:799,t:1527272209629};\\\", \\\"{x:1216,y:801,t:1527272209644};\\\", \\\"{x:1217,y:804,t:1527272209661};\\\", \\\"{x:1218,y:806,t:1527272209679};\\\", \\\"{x:1219,y:808,t:1527272209695};\\\", \\\"{x:1220,y:811,t:1527272209712};\\\", \\\"{x:1221,y:814,t:1527272209729};\\\", \\\"{x:1222,y:816,t:1527272209745};\\\", \\\"{x:1222,y:817,t:1527272209761};\\\", \\\"{x:1222,y:819,t:1527272209779};\\\", \\\"{x:1223,y:821,t:1527272209795};\\\", \\\"{x:1224,y:824,t:1527272209812};\\\", \\\"{x:1225,y:828,t:1527272209828};\\\", \\\"{x:1226,y:830,t:1527272209845};\\\", \\\"{x:1226,y:833,t:1527272209862};\\\", \\\"{x:1226,y:836,t:1527272209879};\\\", \\\"{x:1228,y:838,t:1527272209895};\\\", \\\"{x:1228,y:840,t:1527272209912};\\\", \\\"{x:1230,y:843,t:1527272209929};\\\", \\\"{x:1231,y:846,t:1527272209945};\\\", \\\"{x:1232,y:848,t:1527272209962};\\\", \\\"{x:1233,y:851,t:1527272209980};\\\", \\\"{x:1234,y:858,t:1527272209996};\\\", \\\"{x:1235,y:860,t:1527272210012};\\\", \\\"{x:1235,y:864,t:1527272210028};\\\", \\\"{x:1236,y:865,t:1527272210046};\\\", \\\"{x:1237,y:867,t:1527272210062};\\\", \\\"{x:1239,y:871,t:1527272210079};\\\", \\\"{x:1240,y:876,t:1527272210096};\\\", \\\"{x:1243,y:881,t:1527272210112};\\\", \\\"{x:1244,y:886,t:1527272210129};\\\", \\\"{x:1248,y:891,t:1527272210146};\\\", \\\"{x:1250,y:897,t:1527272210162};\\\", \\\"{x:1252,y:903,t:1527272210179};\\\", \\\"{x:1256,y:912,t:1527272210196};\\\", \\\"{x:1259,y:919,t:1527272210212};\\\", \\\"{x:1261,y:925,t:1527272210230};\\\", \\\"{x:1262,y:930,t:1527272210246};\\\", \\\"{x:1264,y:934,t:1527272210262};\\\", \\\"{x:1265,y:938,t:1527272210279};\\\", \\\"{x:1267,y:940,t:1527272210297};\\\", \\\"{x:1267,y:941,t:1527272210312};\\\", \\\"{x:1267,y:943,t:1527272210330};\\\", \\\"{x:1268,y:944,t:1527272210346};\\\", \\\"{x:1268,y:945,t:1527272210362};\\\", \\\"{x:1268,y:947,t:1527272210380};\\\", \\\"{x:1269,y:948,t:1527272210397};\\\", \\\"{x:1269,y:949,t:1527272210413};\\\", \\\"{x:1269,y:950,t:1527272210429};\\\", \\\"{x:1270,y:950,t:1527272210446};\\\", \\\"{x:1270,y:951,t:1527272210469};\\\", \\\"{x:1270,y:952,t:1527272210485};\\\", \\\"{x:1270,y:953,t:1527272210497};\\\", \\\"{x:1271,y:953,t:1527272210513};\\\", \\\"{x:1272,y:954,t:1527272210529};\\\", \\\"{x:1272,y:955,t:1527272210547};\\\", \\\"{x:1273,y:957,t:1527272210563};\\\", \\\"{x:1273,y:958,t:1527272210580};\\\", \\\"{x:1273,y:959,t:1527272210597};\\\", \\\"{x:1273,y:960,t:1527272210653};\\\", \\\"{x:1274,y:961,t:1527272210664};\\\", \\\"{x:1274,y:962,t:1527272210829};\\\", \\\"{x:1275,y:963,t:1527272210893};\\\", \\\"{x:1276,y:964,t:1527272210940};\\\", \\\"{x:1276,y:965,t:1527272211029};\\\", \\\"{x:1270,y:965,t:1527272211541};\\\", \\\"{x:1251,y:958,t:1527272211549};\\\", \\\"{x:1222,y:946,t:1527272211563};\\\", \\\"{x:1112,y:890,t:1527272211581};\\\", \\\"{x:1089,y:875,t:1527272211597};\\\", \\\"{x:979,y:826,t:1527272211613};\\\", \\\"{x:978,y:826,t:1527272211630};\\\", \\\"{x:977,y:826,t:1527272211647};\\\", \\\"{x:985,y:823,t:1527272211701};\\\", \\\"{x:1005,y:823,t:1527272211714};\\\", \\\"{x:1040,y:823,t:1527272211730};\\\", \\\"{x:1045,y:823,t:1527272211746};\\\", \\\"{x:1046,y:822,t:1527272211779};\\\", \\\"{x:1046,y:820,t:1527272211796};\\\", \\\"{x:1048,y:813,t:1527272211814};\\\", \\\"{x:1056,y:802,t:1527272211829};\\\", \\\"{x:1062,y:789,t:1527272211847};\\\", \\\"{x:1064,y:785,t:1527272211863};\\\", \\\"{x:1065,y:781,t:1527272211880};\\\", \\\"{x:1064,y:776,t:1527272211897};\\\", \\\"{x:1045,y:769,t:1527272211913};\\\", \\\"{x:1016,y:755,t:1527272211929};\\\", \\\"{x:963,y:732,t:1527272211947};\\\", \\\"{x:849,y:699,t:1527272211964};\\\", \\\"{x:758,y:674,t:1527272211980};\\\", \\\"{x:665,y:654,t:1527272211997};\\\", \\\"{x:593,y:646,t:1527272212014};\\\", \\\"{x:548,y:638,t:1527272212030};\\\", \\\"{x:520,y:637,t:1527272212047};\\\", \\\"{x:498,y:634,t:1527272212064};\\\", \\\"{x:481,y:631,t:1527272212081};\\\", \\\"{x:468,y:625,t:1527272212097};\\\", \\\"{x:464,y:622,t:1527272212114};\\\", \\\"{x:453,y:615,t:1527272212131};\\\", \\\"{x:427,y:603,t:1527272212147};\\\", \\\"{x:411,y:597,t:1527272212164};\\\", \\\"{x:399,y:591,t:1527272212182};\\\", \\\"{x:396,y:589,t:1527272212197};\\\", \\\"{x:396,y:584,t:1527272212215};\\\", \\\"{x:396,y:576,t:1527272212231};\\\", \\\"{x:398,y:567,t:1527272212248};\\\", \\\"{x:399,y:559,t:1527272212265};\\\", \\\"{x:399,y:555,t:1527272212281};\\\", \\\"{x:399,y:551,t:1527272212298};\\\", \\\"{x:399,y:545,t:1527272212315};\\\", \\\"{x:399,y:541,t:1527272212331};\\\", \\\"{x:399,y:535,t:1527272212347};\\\", \\\"{x:399,y:534,t:1527272212365};\\\", \\\"{x:401,y:532,t:1527272212382};\\\", \\\"{x:402,y:531,t:1527272212398};\\\", \\\"{x:406,y:531,t:1527272212415};\\\", \\\"{x:411,y:531,t:1527272212432};\\\", \\\"{x:420,y:531,t:1527272212449};\\\", \\\"{x:434,y:529,t:1527272212465};\\\", \\\"{x:460,y:525,t:1527272212482};\\\", \\\"{x:490,y:524,t:1527272212499};\\\", \\\"{x:516,y:520,t:1527272212515};\\\", \\\"{x:537,y:519,t:1527272212532};\\\", \\\"{x:540,y:518,t:1527272212548};\\\", \\\"{x:537,y:518,t:1527272212596};\\\", \\\"{x:525,y:518,t:1527272212604};\\\", \\\"{x:511,y:516,t:1527272212616};\\\", \\\"{x:476,y:513,t:1527272212633};\\\", \\\"{x:417,y:513,t:1527272212648};\\\", \\\"{x:349,y:506,t:1527272212665};\\\", \\\"{x:281,y:496,t:1527272212681};\\\", \\\"{x:241,y:489,t:1527272212699};\\\", \\\"{x:213,y:484,t:1527272212715};\\\", \\\"{x:203,y:483,t:1527272212732};\\\", \\\"{x:202,y:483,t:1527272212788};\\\", \\\"{x:199,y:483,t:1527272212799};\\\", \\\"{x:193,y:481,t:1527272212814};\\\", \\\"{x:188,y:481,t:1527272212832};\\\", \\\"{x:180,y:481,t:1527272212849};\\\", \\\"{x:170,y:481,t:1527272212865};\\\", \\\"{x:161,y:481,t:1527272212882};\\\", \\\"{x:157,y:482,t:1527272212899};\\\", \\\"{x:156,y:482,t:1527272212915};\\\", \\\"{x:155,y:484,t:1527272212932};\\\", \\\"{x:155,y:485,t:1527272212972};\\\", \\\"{x:155,y:486,t:1527272213021};\\\", \\\"{x:155,y:487,t:1527272213045};\\\", \\\"{x:155,y:489,t:1527272213065};\\\", \\\"{x:155,y:493,t:1527272213082};\\\", \\\"{x:155,y:494,t:1527272213131};\\\", \\\"{x:158,y:494,t:1527272213444};\\\", \\\"{x:162,y:494,t:1527272213451};\\\", \\\"{x:167,y:494,t:1527272213465};\\\", \\\"{x:183,y:494,t:1527272213483};\\\", \\\"{x:212,y:499,t:1527272213499};\\\", \\\"{x:331,y:528,t:1527272213516};\\\", \\\"{x:452,y:559,t:1527272213532};\\\", \\\"{x:593,y:603,t:1527272213549};\\\", \\\"{x:740,y:647,t:1527272213567};\\\", \\\"{x:882,y:699,t:1527272213582};\\\", \\\"{x:1018,y:740,t:1527272213599};\\\", \\\"{x:1133,y:784,t:1527272213616};\\\", \\\"{x:1210,y:816,t:1527272213633};\\\", \\\"{x:1257,y:837,t:1527272213649};\\\", \\\"{x:1274,y:843,t:1527272213666};\\\", \\\"{x:1278,y:844,t:1527272213683};\\\", \\\"{x:1279,y:845,t:1527272213741};\\\", \\\"{x:1279,y:846,t:1527272213757};\\\", \\\"{x:1278,y:847,t:1527272213767};\\\", \\\"{x:1271,y:849,t:1527272213784};\\\", \\\"{x:1260,y:850,t:1527272213799};\\\", \\\"{x:1236,y:850,t:1527272213816};\\\", \\\"{x:1217,y:850,t:1527272213833};\\\", \\\"{x:1198,y:850,t:1527272213849};\\\", \\\"{x:1182,y:850,t:1527272213866};\\\", \\\"{x:1173,y:851,t:1527272213883};\\\", \\\"{x:1170,y:853,t:1527272213899};\\\", \\\"{x:1170,y:854,t:1527272213917};\\\", \\\"{x:1170,y:857,t:1527272213933};\\\", \\\"{x:1170,y:862,t:1527272213950};\\\", \\\"{x:1170,y:866,t:1527272213966};\\\", \\\"{x:1169,y:868,t:1527272213983};\\\", \\\"{x:1168,y:871,t:1527272214000};\\\", \\\"{x:1168,y:866,t:1527272214101};\\\", \\\"{x:1168,y:847,t:1527272214117};\\\", \\\"{x:1168,y:824,t:1527272214134};\\\", \\\"{x:1171,y:803,t:1527272214151};\\\", \\\"{x:1174,y:791,t:1527272214166};\\\", \\\"{x:1175,y:788,t:1527272214184};\\\", \\\"{x:1176,y:785,t:1527272214201};\\\", \\\"{x:1177,y:785,t:1527272214217};\\\", \\\"{x:1177,y:784,t:1527272214234};\\\", \\\"{x:1178,y:784,t:1527272214250};\\\", \\\"{x:1178,y:783,t:1527272214267};\\\", \\\"{x:1180,y:785,t:1527272214421};\\\", \\\"{x:1183,y:791,t:1527272214433};\\\", \\\"{x:1190,y:807,t:1527272214450};\\\", \\\"{x:1199,y:823,t:1527272214468};\\\", \\\"{x:1209,y:842,t:1527272214483};\\\", \\\"{x:1217,y:858,t:1527272214500};\\\", \\\"{x:1217,y:860,t:1527272214518};\\\", \\\"{x:1217,y:861,t:1527272214533};\\\", \\\"{x:1219,y:862,t:1527272214614};\\\", \\\"{x:1220,y:862,t:1527272214620};\\\", \\\"{x:1221,y:861,t:1527272214634};\\\", \\\"{x:1223,y:860,t:1527272214650};\\\", \\\"{x:1223,y:859,t:1527272214667};\\\", \\\"{x:1225,y:857,t:1527272214683};\\\", \\\"{x:1226,y:852,t:1527272214700};\\\", \\\"{x:1226,y:847,t:1527272214718};\\\", \\\"{x:1226,y:844,t:1527272214734};\\\", \\\"{x:1226,y:843,t:1527272214756};\\\", \\\"{x:1226,y:842,t:1527272214829};\\\", \\\"{x:1226,y:841,t:1527272214869};\\\", \\\"{x:1225,y:840,t:1527272214965};\\\", \\\"{x:1224,y:838,t:1527272214997};\\\", \\\"{x:1224,y:837,t:1527272215020};\\\", \\\"{x:1224,y:836,t:1527272215034};\\\", \\\"{x:1224,y:835,t:1527272215050};\\\", \\\"{x:1224,y:834,t:1527272215132};\\\", \\\"{x:1225,y:837,t:1527272215253};\\\", \\\"{x:1225,y:838,t:1527272215267};\\\", \\\"{x:1226,y:845,t:1527272215285};\\\", \\\"{x:1230,y:849,t:1527272215301};\\\", \\\"{x:1230,y:854,t:1527272215317};\\\", \\\"{x:1232,y:857,t:1527272215335};\\\", \\\"{x:1234,y:860,t:1527272215351};\\\", \\\"{x:1235,y:864,t:1527272215367};\\\", \\\"{x:1236,y:867,t:1527272215384};\\\", \\\"{x:1237,y:871,t:1527272215402};\\\", \\\"{x:1238,y:874,t:1527272215417};\\\", \\\"{x:1238,y:877,t:1527272215434};\\\", \\\"{x:1239,y:878,t:1527272215451};\\\", \\\"{x:1240,y:879,t:1527272215469};\\\", \\\"{x:1240,y:881,t:1527272215485};\\\", \\\"{x:1243,y:880,t:1527272215550};\\\", \\\"{x:1244,y:872,t:1527272215556};\\\", \\\"{x:1249,y:866,t:1527272215568};\\\", \\\"{x:1257,y:846,t:1527272215585};\\\", \\\"{x:1274,y:816,t:1527272215602};\\\", \\\"{x:1290,y:792,t:1527272215619};\\\", \\\"{x:1302,y:773,t:1527272215635};\\\", \\\"{x:1312,y:752,t:1527272215652};\\\", \\\"{x:1324,y:723,t:1527272215668};\\\", \\\"{x:1328,y:716,t:1527272215685};\\\", \\\"{x:1328,y:713,t:1527272215702};\\\", \\\"{x:1330,y:710,t:1527272215718};\\\", \\\"{x:1331,y:709,t:1527272215741};\\\", \\\"{x:1333,y:708,t:1527272215813};\\\", \\\"{x:1334,y:708,t:1527272215820};\\\", \\\"{x:1335,y:708,t:1527272215836};\\\", \\\"{x:1338,y:707,t:1527272215852};\\\", \\\"{x:1340,y:706,t:1527272215868};\\\", \\\"{x:1342,y:706,t:1527272215885};\\\", \\\"{x:1343,y:704,t:1527272215902};\\\", \\\"{x:1345,y:705,t:1527272215973};\\\", \\\"{x:1345,y:707,t:1527272215985};\\\", \\\"{x:1346,y:713,t:1527272216001};\\\", \\\"{x:1348,y:723,t:1527272216018};\\\", \\\"{x:1349,y:733,t:1527272216036};\\\", \\\"{x:1349,y:742,t:1527272216052};\\\", \\\"{x:1349,y:750,t:1527272216069};\\\", \\\"{x:1349,y:754,t:1527272216085};\\\", \\\"{x:1349,y:757,t:1527272216101};\\\", \\\"{x:1349,y:758,t:1527272216119};\\\", \\\"{x:1350,y:758,t:1527272216172};\\\", \\\"{x:1350,y:759,t:1527272216244};\\\", \\\"{x:1350,y:760,t:1527272216252};\\\", \\\"{x:1349,y:762,t:1527272216276};\\\", \\\"{x:1349,y:763,t:1527272216285};\\\", \\\"{x:1345,y:768,t:1527272216302};\\\", \\\"{x:1343,y:772,t:1527272216319};\\\", \\\"{x:1340,y:776,t:1527272216336};\\\", \\\"{x:1337,y:780,t:1527272216352};\\\", \\\"{x:1336,y:782,t:1527272216368};\\\", \\\"{x:1333,y:787,t:1527272216385};\\\", \\\"{x:1330,y:791,t:1527272216402};\\\", \\\"{x:1325,y:798,t:1527272216417};\\\", \\\"{x:1322,y:802,t:1527272216434};\\\", \\\"{x:1313,y:814,t:1527272216451};\\\", \\\"{x:1308,y:821,t:1527272216468};\\\", \\\"{x:1304,y:829,t:1527272216485};\\\", \\\"{x:1299,y:839,t:1527272216501};\\\", \\\"{x:1295,y:847,t:1527272216518};\\\", \\\"{x:1290,y:857,t:1527272216535};\\\", \\\"{x:1288,y:865,t:1527272216552};\\\", \\\"{x:1288,y:869,t:1527272216568};\\\", \\\"{x:1285,y:874,t:1527272216585};\\\", \\\"{x:1285,y:877,t:1527272216602};\\\", \\\"{x:1285,y:881,t:1527272216619};\\\", \\\"{x:1284,y:885,t:1527272216635};\\\", \\\"{x:1280,y:894,t:1527272216651};\\\", \\\"{x:1277,y:900,t:1527272216668};\\\", \\\"{x:1273,y:908,t:1527272216686};\\\", \\\"{x:1270,y:912,t:1527272216702};\\\", \\\"{x:1268,y:917,t:1527272216719};\\\", \\\"{x:1265,y:920,t:1527272216736};\\\", \\\"{x:1263,y:923,t:1527272216752};\\\", \\\"{x:1261,y:925,t:1527272216769};\\\", \\\"{x:1260,y:927,t:1527272216785};\\\", \\\"{x:1258,y:930,t:1527272216803};\\\", \\\"{x:1255,y:933,t:1527272216819};\\\", \\\"{x:1252,y:937,t:1527272216836};\\\", \\\"{x:1248,y:942,t:1527272216852};\\\", \\\"{x:1247,y:944,t:1527272216869};\\\", \\\"{x:1245,y:945,t:1527272216886};\\\", \\\"{x:1244,y:947,t:1527272216903};\\\", \\\"{x:1244,y:948,t:1527272216919};\\\", \\\"{x:1244,y:950,t:1527272216935};\\\", \\\"{x:1244,y:951,t:1527272216952};\\\", \\\"{x:1243,y:954,t:1527272216970};\\\", \\\"{x:1243,y:955,t:1527272216996};\\\", \\\"{x:1243,y:956,t:1527272217004};\\\", \\\"{x:1243,y:957,t:1527272217028};\\\", \\\"{x:1243,y:958,t:1527272217076};\\\", \\\"{x:1243,y:959,t:1527272218940};\\\", \\\"{x:1243,y:960,t:1527272221229};\\\", \\\"{x:1244,y:960,t:1527272221240};\\\", \\\"{x:1244,y:961,t:1527272221256};\\\", \\\"{x:1244,y:963,t:1527272221274};\\\", \\\"{x:1244,y:964,t:1527272221290};\\\", \\\"{x:1244,y:966,t:1527272221307};\\\", \\\"{x:1244,y:967,t:1527272221340};\\\", \\\"{x:1244,y:968,t:1527272221397};\\\", \\\"{x:1244,y:969,t:1527272221412};\\\", \\\"{x:1244,y:970,t:1527272221949};\\\", \\\"{x:1245,y:971,t:1527272221958};\\\", \\\"{x:1246,y:971,t:1527272224948};\\\", \\\"{x:1246,y:968,t:1527272224959};\\\", \\\"{x:1199,y:960,t:1527272224977};\\\", \\\"{x:1121,y:933,t:1527272224994};\\\", \\\"{x:1032,y:906,t:1527272225010};\\\", \\\"{x:910,y:871,t:1527272225026};\\\", \\\"{x:733,y:821,t:1527272225044};\\\", \\\"{x:632,y:789,t:1527272225060};\\\", \\\"{x:560,y:755,t:1527272225076};\\\", \\\"{x:513,y:733,t:1527272225095};\\\", \\\"{x:492,y:722,t:1527272225109};\\\", \\\"{x:485,y:718,t:1527272225126};\\\", \\\"{x:484,y:717,t:1527272225143};\\\", \\\"{x:483,y:717,t:1527272225158};\\\", \\\"{x:479,y:717,t:1527272225175};\\\", \\\"{x:471,y:716,t:1527272225192};\\\", \\\"{x:448,y:716,t:1527272225208};\\\", \\\"{x:426,y:713,t:1527272225225};\\\", \\\"{x:409,y:711,t:1527272225242};\\\", \\\"{x:399,y:707,t:1527272225258};\\\", \\\"{x:399,y:706,t:1527272225275};\\\", \\\"{x:404,y:706,t:1527272225307};\\\", \\\"{x:428,y:711,t:1527272225325};\\\", \\\"{x:457,y:723,t:1527272225343};\\\", \\\"{x:478,y:733,t:1527272225359};\\\", \\\"{x:490,y:738,t:1527272225375};\\\", \\\"{x:494,y:740,t:1527272225392};\\\", \\\"{x:496,y:740,t:1527272226332};\\\", \\\"{x:500,y:740,t:1527272226342};\\\", \\\"{x:502,y:740,t:1527272226359};\\\", \\\"{x:503,y:740,t:1527272226780};\\\" ] }, { \\\"rt\\\": 9948, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 527390, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"2WQ0M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:503,y:738,t:1527272227516};\\\", \\\"{x:503,y:737,t:1527272227527};\\\", \\\"{x:506,y:727,t:1527272227543};\\\", \\\"{x:513,y:710,t:1527272227560};\\\", \\\"{x:522,y:689,t:1527272227577};\\\", \\\"{x:524,y:668,t:1527272227593};\\\", \\\"{x:527,y:649,t:1527272227610};\\\", \\\"{x:527,y:632,t:1527272227627};\\\", \\\"{x:527,y:620,t:1527272227644};\\\", \\\"{x:527,y:606,t:1527272227660};\\\", \\\"{x:527,y:596,t:1527272227678};\\\", \\\"{x:525,y:582,t:1527272227694};\\\", \\\"{x:519,y:565,t:1527272227710};\\\", \\\"{x:513,y:549,t:1527272227728};\\\", \\\"{x:506,y:532,t:1527272227744};\\\", \\\"{x:502,y:526,t:1527272227760};\\\", \\\"{x:496,y:519,t:1527272227778};\\\", \\\"{x:495,y:508,t:1527272227795};\\\", \\\"{x:487,y:494,t:1527272227810};\\\", \\\"{x:486,y:492,t:1527272227827};\\\", \\\"{x:491,y:491,t:1527272228116};\\\", \\\"{x:500,y:491,t:1527272228129};\\\", \\\"{x:526,y:493,t:1527272228144};\\\", \\\"{x:579,y:500,t:1527272228161};\\\", \\\"{x:670,y:511,t:1527272228177};\\\", \\\"{x:788,y:517,t:1527272228196};\\\", \\\"{x:984,y:536,t:1527272228212};\\\", \\\"{x:1102,y:540,t:1527272228227};\\\", \\\"{x:1224,y:560,t:1527272228245};\\\", \\\"{x:1331,y:570,t:1527272228261};\\\", \\\"{x:1411,y:579,t:1527272228277};\\\", \\\"{x:1476,y:590,t:1527272228295};\\\", \\\"{x:1507,y:598,t:1527272228311};\\\", \\\"{x:1526,y:606,t:1527272228328};\\\", \\\"{x:1536,y:613,t:1527272228345};\\\", \\\"{x:1540,y:620,t:1527272228362};\\\", \\\"{x:1541,y:625,t:1527272228378};\\\", \\\"{x:1541,y:633,t:1527272228395};\\\", \\\"{x:1541,y:657,t:1527272228412};\\\", \\\"{x:1538,y:674,t:1527272228428};\\\", \\\"{x:1532,y:693,t:1527272228445};\\\", \\\"{x:1523,y:717,t:1527272228462};\\\", \\\"{x:1510,y:741,t:1527272228478};\\\", \\\"{x:1500,y:760,t:1527272228495};\\\", \\\"{x:1487,y:782,t:1527272228512};\\\", \\\"{x:1471,y:800,t:1527272228529};\\\", \\\"{x:1456,y:814,t:1527272228545};\\\", \\\"{x:1441,y:823,t:1527272228562};\\\", \\\"{x:1435,y:828,t:1527272228579};\\\", \\\"{x:1424,y:835,t:1527272228595};\\\", \\\"{x:1401,y:844,t:1527272228612};\\\", \\\"{x:1384,y:848,t:1527272228628};\\\", \\\"{x:1374,y:849,t:1527272228644};\\\", \\\"{x:1362,y:853,t:1527272228662};\\\", \\\"{x:1349,y:857,t:1527272228679};\\\", \\\"{x:1340,y:859,t:1527272228695};\\\", \\\"{x:1329,y:862,t:1527272228712};\\\", \\\"{x:1322,y:863,t:1527272228730};\\\", \\\"{x:1316,y:865,t:1527272228745};\\\", \\\"{x:1313,y:865,t:1527272228762};\\\", \\\"{x:1315,y:865,t:1527272229077};\\\", \\\"{x:1328,y:865,t:1527272229084};\\\", \\\"{x:1343,y:865,t:1527272229096};\\\", \\\"{x:1384,y:865,t:1527272229111};\\\", \\\"{x:1426,y:865,t:1527272229129};\\\", \\\"{x:1473,y:865,t:1527272229146};\\\", \\\"{x:1510,y:865,t:1527272229162};\\\", \\\"{x:1546,y:865,t:1527272229179};\\\", \\\"{x:1585,y:865,t:1527272229196};\\\", \\\"{x:1602,y:865,t:1527272229212};\\\", \\\"{x:1610,y:863,t:1527272229229};\\\", \\\"{x:1613,y:862,t:1527272229246};\\\", \\\"{x:1613,y:861,t:1527272229262};\\\", \\\"{x:1614,y:860,t:1527272229300};\\\", \\\"{x:1614,y:858,t:1527272229312};\\\", \\\"{x:1618,y:841,t:1527272229328};\\\", \\\"{x:1618,y:811,t:1527272229345};\\\", \\\"{x:1621,y:763,t:1527272229362};\\\", \\\"{x:1617,y:697,t:1527272229380};\\\", \\\"{x:1590,y:615,t:1527272229396};\\\", \\\"{x:1571,y:566,t:1527272229411};\\\", \\\"{x:1553,y:520,t:1527272229428};\\\", \\\"{x:1537,y:479,t:1527272229445};\\\", \\\"{x:1531,y:460,t:1527272229461};\\\", \\\"{x:1529,y:449,t:1527272229478};\\\", \\\"{x:1529,y:448,t:1527272229495};\\\", \\\"{x:1529,y:447,t:1527272229512};\\\", \\\"{x:1528,y:447,t:1527272229789};\\\", \\\"{x:1527,y:446,t:1527272229796};\\\", \\\"{x:1527,y:445,t:1527272229828};\\\", \\\"{x:1525,y:444,t:1527272229846};\\\", \\\"{x:1519,y:440,t:1527272229863};\\\", \\\"{x:1506,y:430,t:1527272229880};\\\", \\\"{x:1496,y:421,t:1527272229896};\\\", \\\"{x:1483,y:409,t:1527272229912};\\\", \\\"{x:1472,y:392,t:1527272229929};\\\", \\\"{x:1463,y:380,t:1527272229946};\\\", \\\"{x:1458,y:369,t:1527272229963};\\\", \\\"{x:1454,y:359,t:1527272229980};\\\", \\\"{x:1452,y:345,t:1527272229996};\\\", \\\"{x:1452,y:340,t:1527272230012};\\\", \\\"{x:1452,y:337,t:1527272230029};\\\", \\\"{x:1452,y:335,t:1527272230046};\\\", \\\"{x:1452,y:333,t:1527272230063};\\\", \\\"{x:1452,y:332,t:1527272230100};\\\", \\\"{x:1452,y:330,t:1527272230113};\\\", \\\"{x:1453,y:328,t:1527272230131};\\\", \\\"{x:1454,y:325,t:1527272230146};\\\", \\\"{x:1456,y:321,t:1527272230162};\\\", \\\"{x:1458,y:318,t:1527272230179};\\\", \\\"{x:1458,y:317,t:1527272230307};\\\", \\\"{x:1460,y:314,t:1527272230395};\\\", \\\"{x:1461,y:313,t:1527272230413};\\\", \\\"{x:1465,y:310,t:1527272230430};\\\", \\\"{x:1476,y:308,t:1527272230445};\\\", \\\"{x:1486,y:307,t:1527272230462};\\\", \\\"{x:1497,y:305,t:1527272230480};\\\", \\\"{x:1503,y:305,t:1527272230495};\\\", \\\"{x:1506,y:303,t:1527272230513};\\\", \\\"{x:1508,y:303,t:1527272230530};\\\", \\\"{x:1509,y:303,t:1527272230546};\\\", \\\"{x:1510,y:303,t:1527272230563};\\\", \\\"{x:1512,y:307,t:1527272230580};\\\", \\\"{x:1514,y:312,t:1527272230596};\\\", \\\"{x:1514,y:317,t:1527272230613};\\\", \\\"{x:1515,y:321,t:1527272230630};\\\", \\\"{x:1515,y:326,t:1527272230647};\\\", \\\"{x:1513,y:337,t:1527272230663};\\\", \\\"{x:1508,y:350,t:1527272230680};\\\", \\\"{x:1501,y:362,t:1527272230697};\\\", \\\"{x:1493,y:372,t:1527272230713};\\\", \\\"{x:1486,y:378,t:1527272230730};\\\", \\\"{x:1479,y:382,t:1527272230747};\\\", \\\"{x:1474,y:382,t:1527272230763};\\\", \\\"{x:1466,y:383,t:1527272230780};\\\", \\\"{x:1457,y:383,t:1527272230796};\\\", \\\"{x:1447,y:386,t:1527272230813};\\\", \\\"{x:1440,y:387,t:1527272230829};\\\", \\\"{x:1436,y:387,t:1527272230847};\\\", \\\"{x:1433,y:388,t:1527272230862};\\\", \\\"{x:1428,y:391,t:1527272230879};\\\", \\\"{x:1423,y:394,t:1527272230896};\\\", \\\"{x:1416,y:405,t:1527272230912};\\\", \\\"{x:1407,y:421,t:1527272230930};\\\", \\\"{x:1398,y:442,t:1527272230946};\\\", \\\"{x:1392,y:466,t:1527272230963};\\\", \\\"{x:1386,y:502,t:1527272230979};\\\", \\\"{x:1385,y:524,t:1527272230997};\\\", \\\"{x:1385,y:540,t:1527272231013};\\\", \\\"{x:1385,y:547,t:1527272231030};\\\", \\\"{x:1385,y:548,t:1527272231047};\\\", \\\"{x:1383,y:548,t:1527272231068};\\\", \\\"{x:1382,y:548,t:1527272231080};\\\", \\\"{x:1375,y:548,t:1527272231097};\\\", \\\"{x:1365,y:548,t:1527272231112};\\\", \\\"{x:1358,y:547,t:1527272231131};\\\", \\\"{x:1349,y:546,t:1527272231147};\\\", \\\"{x:1339,y:545,t:1527272231164};\\\", \\\"{x:1338,y:545,t:1527272231180};\\\", \\\"{x:1340,y:542,t:1527272231268};\\\", \\\"{x:1351,y:538,t:1527272231280};\\\", \\\"{x:1377,y:527,t:1527272231297};\\\", \\\"{x:1422,y:513,t:1527272231314};\\\", \\\"{x:1479,y:502,t:1527272231331};\\\", \\\"{x:1523,y:491,t:1527272231347};\\\", \\\"{x:1564,y:490,t:1527272231364};\\\", \\\"{x:1571,y:490,t:1527272231380};\\\", \\\"{x:1572,y:490,t:1527272231445};\\\", \\\"{x:1572,y:491,t:1527272231452};\\\", \\\"{x:1572,y:493,t:1527272231464};\\\", \\\"{x:1571,y:498,t:1527272231480};\\\", \\\"{x:1569,y:500,t:1527272231497};\\\", \\\"{x:1566,y:503,t:1527272231514};\\\", \\\"{x:1563,y:506,t:1527272231531};\\\", \\\"{x:1559,y:511,t:1527272231547};\\\", \\\"{x:1553,y:522,t:1527272231564};\\\", \\\"{x:1545,y:536,t:1527272231580};\\\", \\\"{x:1538,y:551,t:1527272231597};\\\", \\\"{x:1529,y:566,t:1527272231613};\\\", \\\"{x:1518,y:584,t:1527272231630};\\\", \\\"{x:1506,y:597,t:1527272231647};\\\", \\\"{x:1491,y:610,t:1527272231664};\\\", \\\"{x:1475,y:625,t:1527272231681};\\\", \\\"{x:1460,y:633,t:1527272231697};\\\", \\\"{x:1448,y:640,t:1527272231714};\\\", \\\"{x:1433,y:649,t:1527272231731};\\\", \\\"{x:1423,y:654,t:1527272231747};\\\", \\\"{x:1411,y:664,t:1527272231764};\\\", \\\"{x:1405,y:670,t:1527272231780};\\\", \\\"{x:1399,y:678,t:1527272231797};\\\", \\\"{x:1389,y:690,t:1527272231814};\\\", \\\"{x:1380,y:700,t:1527272231831};\\\", \\\"{x:1376,y:706,t:1527272231847};\\\", \\\"{x:1370,y:717,t:1527272231864};\\\", \\\"{x:1367,y:722,t:1527272231881};\\\", \\\"{x:1366,y:727,t:1527272231897};\\\", \\\"{x:1365,y:730,t:1527272231914};\\\", \\\"{x:1365,y:734,t:1527272231932};\\\", \\\"{x:1365,y:735,t:1527272231948};\\\", \\\"{x:1363,y:732,t:1527272232020};\\\", \\\"{x:1361,y:726,t:1527272232031};\\\", \\\"{x:1357,y:718,t:1527272232047};\\\", \\\"{x:1354,y:715,t:1527272232064};\\\", \\\"{x:1351,y:711,t:1527272232081};\\\", \\\"{x:1348,y:710,t:1527272232098};\\\", \\\"{x:1347,y:709,t:1527272232114};\\\", \\\"{x:1346,y:709,t:1527272232140};\\\", \\\"{x:1345,y:708,t:1527272232309};\\\", \\\"{x:1345,y:707,t:1527272232325};\\\", \\\"{x:1345,y:706,t:1527272232331};\\\", \\\"{x:1345,y:705,t:1527272232347};\\\", \\\"{x:1345,y:704,t:1527272232363};\\\", \\\"{x:1346,y:703,t:1527272232381};\\\", \\\"{x:1346,y:702,t:1527272232398};\\\", \\\"{x:1347,y:700,t:1527272232414};\\\", \\\"{x:1347,y:699,t:1527272232431};\\\", \\\"{x:1348,y:699,t:1527272232500};\\\", \\\"{x:1349,y:699,t:1527272233644};\\\", \\\"{x:1354,y:704,t:1527272233653};\\\", \\\"{x:1356,y:706,t:1527272233665};\\\", \\\"{x:1366,y:713,t:1527272233682};\\\", \\\"{x:1372,y:717,t:1527272233700};\\\", \\\"{x:1375,y:720,t:1527272233715};\\\", \\\"{x:1378,y:723,t:1527272233732};\\\", \\\"{x:1379,y:724,t:1527272233749};\\\", \\\"{x:1380,y:725,t:1527272233766};\\\", \\\"{x:1380,y:726,t:1527272233782};\\\", \\\"{x:1381,y:728,t:1527272233799};\\\", \\\"{x:1382,y:728,t:1527272233815};\\\", \\\"{x:1382,y:730,t:1527272233832};\\\", \\\"{x:1384,y:733,t:1527272233849};\\\", \\\"{x:1384,y:735,t:1527272233865};\\\", \\\"{x:1385,y:737,t:1527272233882};\\\", \\\"{x:1386,y:740,t:1527272233899};\\\", \\\"{x:1387,y:741,t:1527272233915};\\\", \\\"{x:1388,y:746,t:1527272233932};\\\", \\\"{x:1390,y:749,t:1527272233950};\\\", \\\"{x:1391,y:752,t:1527272233965};\\\", \\\"{x:1391,y:757,t:1527272233982};\\\", \\\"{x:1394,y:763,t:1527272234000};\\\", \\\"{x:1397,y:773,t:1527272234016};\\\", \\\"{x:1400,y:784,t:1527272234032};\\\", \\\"{x:1401,y:790,t:1527272234049};\\\", \\\"{x:1405,y:797,t:1527272234065};\\\", \\\"{x:1408,y:803,t:1527272234082};\\\", \\\"{x:1412,y:812,t:1527272234100};\\\", \\\"{x:1416,y:823,t:1527272234115};\\\", \\\"{x:1423,y:839,t:1527272234131};\\\", \\\"{x:1429,y:849,t:1527272234149};\\\", \\\"{x:1434,y:862,t:1527272234165};\\\", \\\"{x:1439,y:870,t:1527272234182};\\\", \\\"{x:1443,y:878,t:1527272234200};\\\", \\\"{x:1448,y:886,t:1527272234215};\\\", \\\"{x:1451,y:892,t:1527272234232};\\\", \\\"{x:1453,y:898,t:1527272234249};\\\", \\\"{x:1456,y:902,t:1527272234266};\\\", \\\"{x:1457,y:906,t:1527272234282};\\\", \\\"{x:1459,y:909,t:1527272234299};\\\", \\\"{x:1462,y:915,t:1527272234316};\\\", \\\"{x:1462,y:918,t:1527272234332};\\\", \\\"{x:1464,y:921,t:1527272234349};\\\", \\\"{x:1465,y:922,t:1527272234366};\\\", \\\"{x:1465,y:923,t:1527272234383};\\\", \\\"{x:1465,y:924,t:1527272234399};\\\", \\\"{x:1466,y:925,t:1527272234416};\\\", \\\"{x:1467,y:926,t:1527272234433};\\\", \\\"{x:1467,y:927,t:1527272234449};\\\", \\\"{x:1468,y:928,t:1527272234467};\\\", \\\"{x:1469,y:929,t:1527272234492};\\\", \\\"{x:1469,y:930,t:1527272234524};\\\", \\\"{x:1470,y:931,t:1527272234540};\\\", \\\"{x:1470,y:932,t:1527272234549};\\\", \\\"{x:1472,y:934,t:1527272234566};\\\", \\\"{x:1474,y:937,t:1527272234582};\\\", \\\"{x:1475,y:938,t:1527272234604};\\\", \\\"{x:1476,y:939,t:1527272234616};\\\", \\\"{x:1477,y:940,t:1527272234632};\\\", \\\"{x:1478,y:941,t:1527272234649};\\\", \\\"{x:1479,y:941,t:1527272234668};\\\", \\\"{x:1479,y:942,t:1527272234684};\\\", \\\"{x:1479,y:943,t:1527272234708};\\\", \\\"{x:1480,y:943,t:1527272234892};\\\", \\\"{x:1480,y:944,t:1527272234989};\\\", \\\"{x:1478,y:944,t:1527272235000};\\\", \\\"{x:1460,y:940,t:1527272235016};\\\", \\\"{x:1422,y:931,t:1527272235034};\\\", \\\"{x:1358,y:914,t:1527272235050};\\\", \\\"{x:1251,y:888,t:1527272235066};\\\", \\\"{x:1115,y:847,t:1527272235083};\\\", \\\"{x:966,y:801,t:1527272235100};\\\", \\\"{x:747,y:710,t:1527272235115};\\\", \\\"{x:640,y:645,t:1527272235134};\\\", \\\"{x:630,y:616,t:1527272235150};\\\", \\\"{x:629,y:612,t:1527272235166};\\\", \\\"{x:628,y:610,t:1527272235183};\\\", \\\"{x:627,y:606,t:1527272235195};\\\", \\\"{x:625,y:604,t:1527272235213};\\\", \\\"{x:624,y:598,t:1527272235229};\\\", \\\"{x:619,y:586,t:1527272235247};\\\", \\\"{x:612,y:571,t:1527272235266};\\\", \\\"{x:605,y:563,t:1527272235283};\\\", \\\"{x:596,y:554,t:1527272235301};\\\", \\\"{x:595,y:549,t:1527272235316};\\\", \\\"{x:592,y:542,t:1527272235334};\\\", \\\"{x:587,y:525,t:1527272235351};\\\", \\\"{x:576,y:507,t:1527272235367};\\\", \\\"{x:567,y:491,t:1527272235384};\\\", \\\"{x:566,y:489,t:1527272235401};\\\", \\\"{x:566,y:488,t:1527272235416};\\\", \\\"{x:566,y:487,t:1527272235459};\\\", \\\"{x:567,y:486,t:1527272235475};\\\", \\\"{x:568,y:486,t:1527272235484};\\\", \\\"{x:572,y:486,t:1527272235500};\\\", \\\"{x:580,y:486,t:1527272235516};\\\", \\\"{x:586,y:487,t:1527272235533};\\\", \\\"{x:594,y:490,t:1527272235551};\\\", \\\"{x:598,y:491,t:1527272235566};\\\", \\\"{x:599,y:492,t:1527272235584};\\\", \\\"{x:600,y:492,t:1527272235601};\\\", \\\"{x:600,y:497,t:1527272235908};\\\", \\\"{x:597,y:506,t:1527272235918};\\\", \\\"{x:587,y:542,t:1527272235934};\\\", \\\"{x:580,y:597,t:1527272235951};\\\", \\\"{x:570,y:664,t:1527272235967};\\\", \\\"{x:564,y:717,t:1527272235984};\\\", \\\"{x:555,y:760,t:1527272236000};\\\", \\\"{x:550,y:784,t:1527272236018};\\\", \\\"{x:546,y:794,t:1527272236035};\\\", \\\"{x:544,y:800,t:1527272236051};\\\", \\\"{x:541,y:805,t:1527272236067};\\\", \\\"{x:541,y:807,t:1527272236084};\\\", \\\"{x:541,y:806,t:1527272236172};\\\", \\\"{x:541,y:805,t:1527272236184};\\\", \\\"{x:541,y:799,t:1527272236201};\\\", \\\"{x:542,y:792,t:1527272236218};\\\", \\\"{x:544,y:777,t:1527272236236};\\\", \\\"{x:544,y:766,t:1527272236250};\\\", \\\"{x:544,y:763,t:1527272236267};\\\", \\\"{x:544,y:762,t:1527272236285};\\\", \\\"{x:544,y:761,t:1527272236307};\\\", \\\"{x:543,y:761,t:1527272236324};\\\", \\\"{x:543,y:760,t:1527272236335};\\\", \\\"{x:538,y:759,t:1527272236351};\\\", \\\"{x:536,y:759,t:1527272236368};\\\", \\\"{x:532,y:757,t:1527272236385};\\\", \\\"{x:528,y:757,t:1527272236401};\\\", \\\"{x:523,y:754,t:1527272236419};\\\", \\\"{x:519,y:751,t:1527272236435};\\\", \\\"{x:516,y:748,t:1527272236451};\\\", \\\"{x:514,y:746,t:1527272236468};\\\", \\\"{x:513,y:745,t:1527272236485};\\\", \\\"{x:513,y:743,t:1527272236501};\\\", \\\"{x:513,y:742,t:1527272236532};\\\", \\\"{x:513,y:741,t:1527272236548};\\\", \\\"{x:511,y:740,t:1527272236563};\\\", \\\"{x:511,y:738,t:1527272237307};\\\", \\\"{x:511,y:735,t:1527272237319};\\\", \\\"{x:510,y:730,t:1527272237336};\\\", \\\"{x:510,y:729,t:1527272237748};\\\", \\\"{x:513,y:729,t:1527272237756};\\\", \\\"{x:518,y:729,t:1527272237769};\\\", \\\"{x:523,y:726,t:1527272237786};\\\", \\\"{x:530,y:722,t:1527272237802};\\\", \\\"{x:549,y:710,t:1527272237819};\\\", \\\"{x:560,y:699,t:1527272237836};\\\", \\\"{x:578,y:682,t:1527272237853};\\\", \\\"{x:594,y:663,t:1527272237869};\\\", \\\"{x:607,y:644,t:1527272237885};\\\", \\\"{x:623,y:616,t:1527272237903};\\\", \\\"{x:639,y:584,t:1527272237919};\\\", \\\"{x:645,y:567,t:1527272237936};\\\", \\\"{x:652,y:554,t:1527272237953};\\\", \\\"{x:655,y:546,t:1527272237968};\\\", \\\"{x:656,y:542,t:1527272237986};\\\", \\\"{x:656,y:534,t:1527272238003};\\\", \\\"{x:656,y:528,t:1527272238019};\\\", \\\"{x:656,y:518,t:1527272238035};\\\", \\\"{x:655,y:510,t:1527272238053};\\\", \\\"{x:653,y:507,t:1527272238068};\\\", \\\"{x:649,y:503,t:1527272238086};\\\", \\\"{x:640,y:497,t:1527272238103};\\\", \\\"{x:626,y:492,t:1527272238119};\\\", \\\"{x:611,y:485,t:1527272238136};\\\", \\\"{x:592,y:479,t:1527272238153};\\\", \\\"{x:570,y:471,t:1527272238170};\\\", \\\"{x:489,y:453,t:1527272238198};\\\", \\\"{x:475,y:449,t:1527272238203};\\\", \\\"{x:444,y:445,t:1527272238218};\\\", \\\"{x:419,y:444,t:1527272238236};\\\", \\\"{x:410,y:443,t:1527272238252};\\\", \\\"{x:414,y:443,t:1527272238323};\\\", \\\"{x:418,y:444,t:1527272238335};\\\" ] }, { \\\"rt\\\": 20938, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 549622, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"2WQ0M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:443,y:446,t:1527272238460};\\\", \\\"{x:445,y:446,t:1527272238571};\\\", \\\"{x:444,y:446,t:1527272238819};\\\", \\\"{x:437,y:446,t:1527272238898};\\\", \\\"{x:436,y:445,t:1527272238903};\\\", \\\"{x:435,y:445,t:1527272238931};\\\", \\\"{x:436,y:445,t:1527272239059};\\\", \\\"{x:438,y:445,t:1527272239070};\\\", \\\"{x:441,y:445,t:1527272239087};\\\", \\\"{x:448,y:445,t:1527272239104};\\\", \\\"{x:468,y:444,t:1527272239119};\\\", \\\"{x:495,y:444,t:1527272239137};\\\", \\\"{x:522,y:444,t:1527272239154};\\\", \\\"{x:555,y:442,t:1527272239170};\\\", \\\"{x:621,y:438,t:1527272239188};\\\", \\\"{x:701,y:433,t:1527272239203};\\\", \\\"{x:833,y:418,t:1527272239220};\\\", \\\"{x:985,y:396,t:1527272239238};\\\", \\\"{x:1126,y:381,t:1527272239254};\\\", \\\"{x:1252,y:376,t:1527272239270};\\\", \\\"{x:1350,y:394,t:1527272239287};\\\", \\\"{x:1412,y:407,t:1527272239304};\\\", \\\"{x:1438,y:413,t:1527272239320};\\\", \\\"{x:1452,y:420,t:1527272239337};\\\", \\\"{x:1456,y:423,t:1527272239354};\\\", \\\"{x:1458,y:432,t:1527272239370};\\\", \\\"{x:1466,y:451,t:1527272239387};\\\", \\\"{x:1473,y:490,t:1527272239403};\\\", \\\"{x:1473,y:513,t:1527272239420};\\\", \\\"{x:1473,y:539,t:1527272239437};\\\", \\\"{x:1472,y:563,t:1527272239454};\\\", \\\"{x:1467,y:586,t:1527272239471};\\\", \\\"{x:1458,y:613,t:1527272239487};\\\", \\\"{x:1449,y:635,t:1527272239505};\\\", \\\"{x:1440,y:656,t:1527272239522};\\\", \\\"{x:1430,y:678,t:1527272239537};\\\", \\\"{x:1419,y:700,t:1527272239554};\\\", \\\"{x:1413,y:723,t:1527272239571};\\\", \\\"{x:1408,y:745,t:1527272239587};\\\", \\\"{x:1407,y:770,t:1527272239604};\\\", \\\"{x:1407,y:785,t:1527272239621};\\\", \\\"{x:1407,y:797,t:1527272239637};\\\", \\\"{x:1407,y:806,t:1527272239654};\\\", \\\"{x:1407,y:811,t:1527272239671};\\\", \\\"{x:1407,y:818,t:1527272239688};\\\", \\\"{x:1409,y:826,t:1527272239704};\\\", \\\"{x:1411,y:835,t:1527272239721};\\\", \\\"{x:1414,y:841,t:1527272239738};\\\", \\\"{x:1415,y:847,t:1527272239754};\\\", \\\"{x:1418,y:857,t:1527272239772};\\\", \\\"{x:1419,y:861,t:1527272239787};\\\", \\\"{x:1423,y:872,t:1527272239805};\\\", \\\"{x:1426,y:875,t:1527272239821};\\\", \\\"{x:1427,y:878,t:1527272239837};\\\", \\\"{x:1430,y:881,t:1527272239855};\\\", \\\"{x:1432,y:881,t:1527272239872};\\\", \\\"{x:1434,y:884,t:1527272239889};\\\", \\\"{x:1436,y:887,t:1527272239904};\\\", \\\"{x:1436,y:891,t:1527272239922};\\\", \\\"{x:1436,y:897,t:1527272239937};\\\", \\\"{x:1436,y:905,t:1527272239954};\\\", \\\"{x:1436,y:912,t:1527272239971};\\\", \\\"{x:1436,y:921,t:1527272239988};\\\", \\\"{x:1436,y:926,t:1527272240005};\\\", \\\"{x:1436,y:928,t:1527272240021};\\\", \\\"{x:1436,y:930,t:1527272240038};\\\", \\\"{x:1437,y:932,t:1527272240054};\\\", \\\"{x:1437,y:933,t:1527272240072};\\\", \\\"{x:1437,y:934,t:1527272240088};\\\", \\\"{x:1437,y:936,t:1527272240104};\\\", \\\"{x:1436,y:942,t:1527272240121};\\\", \\\"{x:1432,y:946,t:1527272240139};\\\", \\\"{x:1424,y:952,t:1527272240155};\\\", \\\"{x:1413,y:954,t:1527272240171};\\\", \\\"{x:1390,y:954,t:1527272240187};\\\", \\\"{x:1367,y:954,t:1527272240204};\\\", \\\"{x:1342,y:954,t:1527272240222};\\\", \\\"{x:1316,y:952,t:1527272240239};\\\", \\\"{x:1300,y:950,t:1527272240254};\\\", \\\"{x:1291,y:948,t:1527272240272};\\\", \\\"{x:1290,y:947,t:1527272240288};\\\", \\\"{x:1290,y:949,t:1527272240412};\\\", \\\"{x:1290,y:950,t:1527272240421};\\\", \\\"{x:1291,y:952,t:1527272240439};\\\", \\\"{x:1293,y:955,t:1527272240455};\\\", \\\"{x:1300,y:958,t:1527272240472};\\\", \\\"{x:1306,y:961,t:1527272240488};\\\", \\\"{x:1311,y:963,t:1527272240505};\\\", \\\"{x:1319,y:966,t:1527272240522};\\\", \\\"{x:1323,y:966,t:1527272240538};\\\", \\\"{x:1326,y:967,t:1527272240556};\\\", \\\"{x:1327,y:967,t:1527272240572};\\\", \\\"{x:1328,y:967,t:1527272240619};\\\", \\\"{x:1329,y:967,t:1527272240628};\\\", \\\"{x:1330,y:967,t:1527272240638};\\\", \\\"{x:1335,y:967,t:1527272240655};\\\", \\\"{x:1340,y:967,t:1527272240671};\\\", \\\"{x:1346,y:967,t:1527272240688};\\\", \\\"{x:1351,y:967,t:1527272240705};\\\", \\\"{x:1352,y:967,t:1527272240721};\\\", \\\"{x:1354,y:967,t:1527272241180};\\\", \\\"{x:1357,y:965,t:1527272241190};\\\", \\\"{x:1363,y:960,t:1527272241205};\\\", \\\"{x:1373,y:952,t:1527272241223};\\\", \\\"{x:1383,y:943,t:1527272241240};\\\", \\\"{x:1393,y:935,t:1527272241255};\\\", \\\"{x:1401,y:927,t:1527272241272};\\\", \\\"{x:1406,y:922,t:1527272241290};\\\", \\\"{x:1408,y:921,t:1527272241306};\\\", \\\"{x:1408,y:919,t:1527272241461};\\\", \\\"{x:1407,y:919,t:1527272241472};\\\", \\\"{x:1406,y:919,t:1527272241489};\\\", \\\"{x:1401,y:919,t:1527272241505};\\\", \\\"{x:1396,y:919,t:1527272241522};\\\", \\\"{x:1394,y:919,t:1527272241539};\\\", \\\"{x:1393,y:919,t:1527272241556};\\\", \\\"{x:1392,y:919,t:1527272241620};\\\", \\\"{x:1390,y:918,t:1527272241652};\\\", \\\"{x:1389,y:918,t:1527272241693};\\\", \\\"{x:1389,y:917,t:1527272241706};\\\", \\\"{x:1386,y:914,t:1527272241722};\\\", \\\"{x:1384,y:911,t:1527272241740};\\\", \\\"{x:1383,y:910,t:1527272241804};\\\", \\\"{x:1381,y:906,t:1527272242476};\\\", \\\"{x:1381,y:905,t:1527272242489};\\\", \\\"{x:1381,y:904,t:1527272242507};\\\", \\\"{x:1381,y:902,t:1527272242524};\\\", \\\"{x:1381,y:901,t:1527272242541};\\\", \\\"{x:1381,y:900,t:1527272242556};\\\", \\\"{x:1379,y:899,t:1527272245669};\\\", \\\"{x:1366,y:898,t:1527272245677};\\\", \\\"{x:1322,y:893,t:1527272245692};\\\", \\\"{x:1250,y:882,t:1527272245709};\\\", \\\"{x:1149,y:866,t:1527272245725};\\\", \\\"{x:1037,y:842,t:1527272245742};\\\", \\\"{x:942,y:810,t:1527272245759};\\\", \\\"{x:864,y:786,t:1527272245775};\\\", \\\"{x:813,y:762,t:1527272245792};\\\", \\\"{x:773,y:741,t:1527272245809};\\\", \\\"{x:750,y:727,t:1527272245825};\\\", \\\"{x:732,y:716,t:1527272245842};\\\", \\\"{x:714,y:699,t:1527272245859};\\\", \\\"{x:705,y:689,t:1527272245875};\\\", \\\"{x:701,y:682,t:1527272245892};\\\", \\\"{x:693,y:671,t:1527272245909};\\\", \\\"{x:691,y:667,t:1527272245925};\\\", \\\"{x:691,y:664,t:1527272245942};\\\", \\\"{x:688,y:657,t:1527272245960};\\\", \\\"{x:687,y:645,t:1527272245976};\\\", \\\"{x:683,y:623,t:1527272245994};\\\", \\\"{x:675,y:591,t:1527272246010};\\\", \\\"{x:666,y:568,t:1527272246026};\\\", \\\"{x:658,y:552,t:1527272246041};\\\", \\\"{x:650,y:544,t:1527272246055};\\\", \\\"{x:638,y:534,t:1527272246076};\\\", \\\"{x:631,y:531,t:1527272246091};\\\", \\\"{x:626,y:528,t:1527272246109};\\\", \\\"{x:617,y:527,t:1527272246126};\\\", \\\"{x:596,y:520,t:1527272246143};\\\", \\\"{x:572,y:512,t:1527272246160};\\\", \\\"{x:550,y:505,t:1527272246175};\\\", \\\"{x:533,y:501,t:1527272246192};\\\", \\\"{x:524,y:499,t:1527272246209};\\\", \\\"{x:518,y:499,t:1527272246225};\\\", \\\"{x:497,y:499,t:1527272246244};\\\", \\\"{x:474,y:499,t:1527272246259};\\\", \\\"{x:446,y:499,t:1527272246276};\\\", \\\"{x:417,y:499,t:1527272246292};\\\", \\\"{x:389,y:499,t:1527272246309};\\\", \\\"{x:367,y:500,t:1527272246327};\\\", \\\"{x:353,y:502,t:1527272246343};\\\", \\\"{x:347,y:506,t:1527272246359};\\\", \\\"{x:343,y:509,t:1527272246376};\\\", \\\"{x:342,y:511,t:1527272246395};\\\", \\\"{x:342,y:513,t:1527272246410};\\\", \\\"{x:341,y:515,t:1527272246426};\\\", \\\"{x:341,y:522,t:1527272246444};\\\", \\\"{x:341,y:524,t:1527272246459};\\\", \\\"{x:343,y:530,t:1527272246478};\\\", \\\"{x:349,y:535,t:1527272246493};\\\", \\\"{x:357,y:537,t:1527272246510};\\\", \\\"{x:362,y:539,t:1527272246527};\\\", \\\"{x:366,y:539,t:1527272246543};\\\", \\\"{x:367,y:539,t:1527272246559};\\\", \\\"{x:368,y:539,t:1527272246587};\\\", \\\"{x:369,y:539,t:1527272246603};\\\", \\\"{x:370,y:539,t:1527272246620};\\\", \\\"{x:371,y:539,t:1527272246628};\\\", \\\"{x:373,y:539,t:1527272246644};\\\", \\\"{x:374,y:539,t:1527272246660};\\\", \\\"{x:376,y:541,t:1527272246971};\\\", \\\"{x:376,y:544,t:1527272246979};\\\", \\\"{x:376,y:550,t:1527272246992};\\\", \\\"{x:376,y:560,t:1527272247010};\\\", \\\"{x:376,y:580,t:1527272247028};\\\", \\\"{x:379,y:591,t:1527272247043};\\\", \\\"{x:379,y:596,t:1527272247061};\\\", \\\"{x:380,y:600,t:1527272247077};\\\", \\\"{x:382,y:602,t:1527272247094};\\\", \\\"{x:383,y:604,t:1527272247110};\\\", \\\"{x:385,y:606,t:1527272247127};\\\", \\\"{x:386,y:608,t:1527272247143};\\\", \\\"{x:387,y:608,t:1527272247160};\\\", \\\"{x:387,y:609,t:1527272247177};\\\", \\\"{x:388,y:609,t:1527272247195};\\\", \\\"{x:389,y:610,t:1527272247211};\\\", \\\"{x:390,y:611,t:1527272247227};\\\", \\\"{x:390,y:613,t:1527272247268};\\\", \\\"{x:391,y:614,t:1527272247652};\\\", \\\"{x:392,y:618,t:1527272247660};\\\", \\\"{x:399,y:632,t:1527272247678};\\\", \\\"{x:409,y:644,t:1527272247695};\\\", \\\"{x:421,y:662,t:1527272247711};\\\", \\\"{x:434,y:678,t:1527272247727};\\\", \\\"{x:451,y:698,t:1527272247744};\\\", \\\"{x:463,y:713,t:1527272247759};\\\", \\\"{x:475,y:724,t:1527272247778};\\\", \\\"{x:484,y:731,t:1527272247794};\\\", \\\"{x:488,y:734,t:1527272247810};\\\", \\\"{x:494,y:739,t:1527272247826};\\\", \\\"{x:498,y:740,t:1527272247844};\\\", \\\"{x:502,y:743,t:1527272247861};\\\", \\\"{x:505,y:743,t:1527272247877};\\\", \\\"{x:506,y:743,t:1527272247915};\\\", \\\"{x:506,y:744,t:1527272247927};\\\", \\\"{x:507,y:744,t:1527272247944};\\\", \\\"{x:509,y:744,t:1527272247962};\\\", \\\"{x:510,y:744,t:1527272247977};\\\", \\\"{x:512,y:744,t:1527272247994};\\\", \\\"{x:513,y:744,t:1527272248027};\\\", \\\"{x:514,y:744,t:1527272248100};\\\", \\\"{x:515,y:744,t:1527272248235};\\\", \\\"{x:515,y:743,t:1527272248298};\\\", \\\"{x:516,y:742,t:1527272248547};\\\", \\\"{x:516,y:741,t:1527272248564};\\\", \\\"{x:516,y:740,t:1527272248579};\\\", \\\"{x:516,y:739,t:1527272248612};\\\", \\\"{x:516,y:738,t:1527272248643};\\\", \\\"{x:516,y:737,t:1527272248668};\\\", \\\"{x:516,y:736,t:1527272248756};\\\", \\\"{x:516,y:735,t:1527272248948};\\\" ] }, { \\\"rt\\\": 12626, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 563471, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"2WQ0M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:734,t:1527272260788};\\\", \\\"{x:528,y:734,t:1527272260797};\\\", \\\"{x:538,y:731,t:1527272260814};\\\", \\\"{x:552,y:717,t:1527272260832};\\\", \\\"{x:569,y:697,t:1527272260848};\\\", \\\"{x:586,y:670,t:1527272260864};\\\", \\\"{x:597,y:646,t:1527272260881};\\\", \\\"{x:604,y:630,t:1527272260898};\\\", \\\"{x:612,y:611,t:1527272260914};\\\", \\\"{x:621,y:591,t:1527272260932};\\\", \\\"{x:623,y:580,t:1527272260947};\\\", \\\"{x:625,y:575,t:1527272260964};\\\", \\\"{x:625,y:574,t:1527272260988};\\\", \\\"{x:625,y:573,t:1527272261005};\\\", \\\"{x:625,y:572,t:1527272261015};\\\", \\\"{x:624,y:568,t:1527272261031};\\\", \\\"{x:624,y:565,t:1527272261048};\\\", \\\"{x:624,y:560,t:1527272261065};\\\", \\\"{x:620,y:553,t:1527272261082};\\\", \\\"{x:615,y:546,t:1527272261099};\\\", \\\"{x:608,y:541,t:1527272261114};\\\", \\\"{x:543,y:509,t:1527272261204};\\\", \\\"{x:520,y:502,t:1527272261214};\\\", \\\"{x:499,y:492,t:1527272261231};\\\", \\\"{x:478,y:482,t:1527272261247};\\\", \\\"{x:460,y:477,t:1527272261264};\\\", \\\"{x:451,y:474,t:1527272261281};\\\", \\\"{x:448,y:472,t:1527272261298};\\\", \\\"{x:448,y:471,t:1527272261315};\\\", \\\"{x:450,y:471,t:1527272261661};\\\", \\\"{x:455,y:471,t:1527272261669};\\\", \\\"{x:462,y:471,t:1527272261682};\\\", \\\"{x:488,y:476,t:1527272261699};\\\", \\\"{x:536,y:491,t:1527272261717};\\\", \\\"{x:709,y:528,t:1527272261733};\\\", \\\"{x:860,y:569,t:1527272261749};\\\", \\\"{x:1009,y:609,t:1527272261766};\\\", \\\"{x:1151,y:652,t:1527272261782};\\\", \\\"{x:1279,y:699,t:1527272261799};\\\", \\\"{x:1375,y:735,t:1527272261815};\\\", \\\"{x:1440,y:771,t:1527272261832};\\\", \\\"{x:1475,y:797,t:1527272261848};\\\", \\\"{x:1487,y:818,t:1527272261865};\\\", \\\"{x:1491,y:843,t:1527272261882};\\\", \\\"{x:1490,y:866,t:1527272261898};\\\", \\\"{x:1481,y:887,t:1527272261916};\\\", \\\"{x:1473,y:897,t:1527272261931};\\\", \\\"{x:1470,y:901,t:1527272261949};\\\", \\\"{x:1467,y:905,t:1527272261965};\\\", \\\"{x:1463,y:910,t:1527272261982};\\\", \\\"{x:1460,y:912,t:1527272261999};\\\", \\\"{x:1456,y:915,t:1527272262015};\\\", \\\"{x:1452,y:916,t:1527272262032};\\\", \\\"{x:1448,y:917,t:1527272262049};\\\", \\\"{x:1442,y:917,t:1527272262065};\\\", \\\"{x:1432,y:917,t:1527272262082};\\\", \\\"{x:1418,y:915,t:1527272262099};\\\", \\\"{x:1397,y:909,t:1527272262115};\\\", \\\"{x:1366,y:903,t:1527272262132};\\\", \\\"{x:1312,y:887,t:1527272262149};\\\", \\\"{x:1279,y:878,t:1527272262165};\\\", \\\"{x:1259,y:870,t:1527272262182};\\\", \\\"{x:1251,y:867,t:1527272262198};\\\", \\\"{x:1249,y:866,t:1527272262215};\\\", \\\"{x:1248,y:864,t:1527272262237};\\\", \\\"{x:1248,y:862,t:1527272262248};\\\", \\\"{x:1248,y:857,t:1527272262265};\\\", \\\"{x:1248,y:853,t:1527272262282};\\\", \\\"{x:1247,y:847,t:1527272262299};\\\", \\\"{x:1244,y:839,t:1527272262315};\\\", \\\"{x:1244,y:832,t:1527272262332};\\\", \\\"{x:1244,y:823,t:1527272262350};\\\", \\\"{x:1246,y:810,t:1527272262366};\\\", \\\"{x:1253,y:796,t:1527272262381};\\\", \\\"{x:1259,y:784,t:1527272262398};\\\", \\\"{x:1265,y:775,t:1527272262415};\\\", \\\"{x:1272,y:765,t:1527272262432};\\\", \\\"{x:1278,y:758,t:1527272262448};\\\", \\\"{x:1280,y:755,t:1527272262465};\\\", \\\"{x:1283,y:751,t:1527272262482};\\\", \\\"{x:1286,y:746,t:1527272262498};\\\", \\\"{x:1288,y:740,t:1527272262515};\\\", \\\"{x:1292,y:734,t:1527272262532};\\\", \\\"{x:1296,y:727,t:1527272262548};\\\", \\\"{x:1301,y:718,t:1527272262566};\\\", \\\"{x:1303,y:713,t:1527272262582};\\\", \\\"{x:1305,y:708,t:1527272262598};\\\", \\\"{x:1306,y:706,t:1527272262615};\\\", \\\"{x:1308,y:702,t:1527272262632};\\\", \\\"{x:1308,y:698,t:1527272262648};\\\", \\\"{x:1310,y:695,t:1527272262665};\\\", \\\"{x:1311,y:690,t:1527272262682};\\\", \\\"{x:1311,y:685,t:1527272262698};\\\", \\\"{x:1314,y:680,t:1527272262715};\\\", \\\"{x:1315,y:674,t:1527272262732};\\\", \\\"{x:1316,y:669,t:1527272262748};\\\", \\\"{x:1317,y:667,t:1527272262765};\\\", \\\"{x:1318,y:666,t:1527272262805};\\\", \\\"{x:1319,y:665,t:1527272262821};\\\", \\\"{x:1321,y:664,t:1527272262831};\\\", \\\"{x:1327,y:662,t:1527272262847};\\\", \\\"{x:1337,y:659,t:1527272262864};\\\", \\\"{x:1347,y:659,t:1527272262880};\\\", \\\"{x:1358,y:659,t:1527272262898};\\\", \\\"{x:1376,y:659,t:1527272262915};\\\", \\\"{x:1401,y:663,t:1527272262931};\\\", \\\"{x:1432,y:673,t:1527272262948};\\\", \\\"{x:1475,y:685,t:1527272262965};\\\", \\\"{x:1496,y:692,t:1527272262981};\\\", \\\"{x:1507,y:699,t:1527272262997};\\\", \\\"{x:1510,y:702,t:1527272263014};\\\", \\\"{x:1511,y:702,t:1527272263031};\\\", \\\"{x:1511,y:703,t:1527272263047};\\\", \\\"{x:1511,y:705,t:1527272263064};\\\", \\\"{x:1511,y:714,t:1527272263081};\\\", \\\"{x:1511,y:725,t:1527272263098};\\\", \\\"{x:1509,y:742,t:1527272263114};\\\", \\\"{x:1509,y:750,t:1527272263131};\\\", \\\"{x:1508,y:763,t:1527272263148};\\\", \\\"{x:1507,y:770,t:1527272263165};\\\", \\\"{x:1504,y:779,t:1527272263181};\\\", \\\"{x:1503,y:782,t:1527272263198};\\\", \\\"{x:1499,y:787,t:1527272263214};\\\", \\\"{x:1494,y:791,t:1527272263231};\\\", \\\"{x:1486,y:796,t:1527272263248};\\\", \\\"{x:1478,y:801,t:1527272263264};\\\", \\\"{x:1471,y:805,t:1527272263281};\\\", \\\"{x:1463,y:810,t:1527272263298};\\\", \\\"{x:1456,y:813,t:1527272263314};\\\", \\\"{x:1451,y:814,t:1527272263331};\\\", \\\"{x:1445,y:815,t:1527272263349};\\\", \\\"{x:1439,y:815,t:1527272263364};\\\", \\\"{x:1426,y:815,t:1527272263381};\\\", \\\"{x:1412,y:809,t:1527272263397};\\\", \\\"{x:1392,y:799,t:1527272263414};\\\", \\\"{x:1373,y:788,t:1527272263431};\\\", \\\"{x:1360,y:777,t:1527272263447};\\\", \\\"{x:1349,y:760,t:1527272263466};\\\", \\\"{x:1343,y:747,t:1527272263481};\\\", \\\"{x:1342,y:736,t:1527272263497};\\\", \\\"{x:1342,y:719,t:1527272263513};\\\", \\\"{x:1344,y:710,t:1527272263530};\\\", \\\"{x:1351,y:698,t:1527272263547};\\\", \\\"{x:1360,y:688,t:1527272263564};\\\", \\\"{x:1369,y:679,t:1527272263581};\\\", \\\"{x:1376,y:670,t:1527272263596};\\\", \\\"{x:1378,y:666,t:1527272263614};\\\", \\\"{x:1378,y:662,t:1527272263630};\\\", \\\"{x:1380,y:659,t:1527272263647};\\\", \\\"{x:1380,y:656,t:1527272263663};\\\", \\\"{x:1380,y:650,t:1527272263681};\\\", \\\"{x:1380,y:643,t:1527272263697};\\\", \\\"{x:1375,y:633,t:1527272263714};\\\", \\\"{x:1369,y:626,t:1527272263730};\\\", \\\"{x:1354,y:614,t:1527272263747};\\\", \\\"{x:1339,y:603,t:1527272263764};\\\", \\\"{x:1329,y:597,t:1527272263780};\\\", \\\"{x:1320,y:590,t:1527272263797};\\\", \\\"{x:1319,y:587,t:1527272263814};\\\", \\\"{x:1317,y:585,t:1527272263830};\\\", \\\"{x:1316,y:584,t:1527272263847};\\\", \\\"{x:1316,y:582,t:1527272263864};\\\", \\\"{x:1314,y:579,t:1527272263879};\\\", \\\"{x:1314,y:577,t:1527272263909};\\\", \\\"{x:1314,y:576,t:1527272263917};\\\", \\\"{x:1314,y:574,t:1527272263930};\\\", \\\"{x:1314,y:569,t:1527272263947};\\\", \\\"{x:1320,y:561,t:1527272263964};\\\", \\\"{x:1325,y:550,t:1527272263980};\\\", \\\"{x:1335,y:525,t:1527272263997};\\\", \\\"{x:1340,y:512,t:1527272264013};\\\", \\\"{x:1344,y:499,t:1527272264030};\\\", \\\"{x:1346,y:483,t:1527272264047};\\\", \\\"{x:1346,y:461,t:1527272264063};\\\", \\\"{x:1346,y:444,t:1527272264080};\\\", \\\"{x:1344,y:426,t:1527272264097};\\\", \\\"{x:1342,y:417,t:1527272264113};\\\", \\\"{x:1339,y:405,t:1527272264130};\\\", \\\"{x:1338,y:401,t:1527272264147};\\\", \\\"{x:1335,y:393,t:1527272264163};\\\", \\\"{x:1335,y:388,t:1527272264180};\\\", \\\"{x:1333,y:382,t:1527272264197};\\\", \\\"{x:1333,y:379,t:1527272264213};\\\", \\\"{x:1332,y:377,t:1527272264230};\\\", \\\"{x:1331,y:380,t:1527272264438};\\\", \\\"{x:1331,y:395,t:1527272264445};\\\", \\\"{x:1331,y:420,t:1527272264462};\\\", \\\"{x:1336,y:442,t:1527272264480};\\\", \\\"{x:1345,y:459,t:1527272264495};\\\", \\\"{x:1352,y:474,t:1527272264512};\\\", \\\"{x:1360,y:490,t:1527272264529};\\\", \\\"{x:1365,y:505,t:1527272264545};\\\", \\\"{x:1369,y:520,t:1527272264563};\\\", \\\"{x:1371,y:536,t:1527272264580};\\\", \\\"{x:1374,y:549,t:1527272264595};\\\", \\\"{x:1375,y:563,t:1527272264613};\\\", \\\"{x:1378,y:572,t:1527272264629};\\\", \\\"{x:1379,y:579,t:1527272264646};\\\", \\\"{x:1379,y:588,t:1527272264663};\\\", \\\"{x:1379,y:599,t:1527272264680};\\\", \\\"{x:1379,y:610,t:1527272264695};\\\", \\\"{x:1379,y:620,t:1527272264713};\\\", \\\"{x:1379,y:628,t:1527272264729};\\\", \\\"{x:1379,y:634,t:1527272264747};\\\", \\\"{x:1379,y:640,t:1527272264763};\\\", \\\"{x:1379,y:644,t:1527272264779};\\\", \\\"{x:1379,y:648,t:1527272264796};\\\", \\\"{x:1376,y:656,t:1527272264813};\\\", \\\"{x:1374,y:660,t:1527272264829};\\\", \\\"{x:1373,y:664,t:1527272264846};\\\", \\\"{x:1373,y:667,t:1527272264863};\\\", \\\"{x:1371,y:670,t:1527272264879};\\\", \\\"{x:1370,y:671,t:1527272264896};\\\", \\\"{x:1368,y:674,t:1527272264913};\\\", \\\"{x:1365,y:677,t:1527272264929};\\\", \\\"{x:1360,y:681,t:1527272264946};\\\", \\\"{x:1356,y:686,t:1527272264963};\\\", \\\"{x:1354,y:689,t:1527272264979};\\\", \\\"{x:1353,y:689,t:1527272264996};\\\", \\\"{x:1352,y:690,t:1527272265013};\\\", \\\"{x:1351,y:691,t:1527272265029};\\\", \\\"{x:1350,y:691,t:1527272265046};\\\", \\\"{x:1349,y:692,t:1527272265079};\\\", \\\"{x:1348,y:692,t:1527272266860};\\\", \\\"{x:1342,y:697,t:1527272266877};\\\", \\\"{x:1331,y:705,t:1527272266894};\\\", \\\"{x:1317,y:713,t:1527272266911};\\\", \\\"{x:1300,y:719,t:1527272266926};\\\", \\\"{x:1279,y:723,t:1527272266944};\\\", \\\"{x:1244,y:723,t:1527272266961};\\\", \\\"{x:1177,y:723,t:1527272266977};\\\", \\\"{x:1074,y:709,t:1527272266994};\\\", \\\"{x:954,y:684,t:1527272267012};\\\", \\\"{x:832,y:646,t:1527272267027};\\\", \\\"{x:718,y:615,t:1527272267048};\\\", \\\"{x:626,y:583,t:1527272267061};\\\", \\\"{x:621,y:579,t:1527272267077};\\\", \\\"{x:619,y:579,t:1527272267098};\\\", \\\"{x:612,y:578,t:1527272267114};\\\", \\\"{x:600,y:571,t:1527272267131};\\\", \\\"{x:585,y:555,t:1527272267148};\\\", \\\"{x:557,y:521,t:1527272267164};\\\", \\\"{x:545,y:510,t:1527272267187};\\\", \\\"{x:540,y:503,t:1527272267202};\\\", \\\"{x:540,y:502,t:1527272267220};\\\", \\\"{x:541,y:502,t:1527272267341};\\\", \\\"{x:544,y:504,t:1527272267354};\\\", \\\"{x:550,y:507,t:1527272267371};\\\", \\\"{x:561,y:514,t:1527272267386};\\\", \\\"{x:572,y:519,t:1527272267405};\\\", \\\"{x:587,y:525,t:1527272267421};\\\", \\\"{x:596,y:528,t:1527272267437};\\\", \\\"{x:602,y:531,t:1527272267453};\\\", \\\"{x:604,y:531,t:1527272267470};\\\", \\\"{x:607,y:532,t:1527272267487};\\\", \\\"{x:609,y:534,t:1527272267504};\\\", \\\"{x:609,y:533,t:1527272267597};\\\", \\\"{x:606,y:532,t:1527272267605};\\\", \\\"{x:600,y:530,t:1527272267621};\\\", \\\"{x:560,y:529,t:1527272267638};\\\", \\\"{x:520,y:529,t:1527272267654};\\\", \\\"{x:483,y:528,t:1527272267671};\\\", \\\"{x:473,y:528,t:1527272267687};\\\", \\\"{x:471,y:530,t:1527272267704};\\\", \\\"{x:470,y:530,t:1527272267720};\\\", \\\"{x:470,y:531,t:1527272267981};\\\", \\\"{x:468,y:534,t:1527272267989};\\\", \\\"{x:463,y:536,t:1527272268004};\\\", \\\"{x:455,y:538,t:1527272268021};\\\", \\\"{x:451,y:540,t:1527272268037};\\\", \\\"{x:447,y:543,t:1527272268054};\\\", \\\"{x:440,y:546,t:1527272268071};\\\", \\\"{x:433,y:548,t:1527272268087};\\\", \\\"{x:420,y:550,t:1527272268103};\\\", \\\"{x:403,y:554,t:1527272268121};\\\", \\\"{x:384,y:554,t:1527272268137};\\\", \\\"{x:361,y:554,t:1527272268154};\\\", \\\"{x:334,y:554,t:1527272268171};\\\", \\\"{x:306,y:554,t:1527272268187};\\\", \\\"{x:281,y:554,t:1527272268204};\\\", \\\"{x:246,y:552,t:1527272268223};\\\", \\\"{x:218,y:548,t:1527272268237};\\\", \\\"{x:192,y:545,t:1527272268253};\\\", \\\"{x:173,y:545,t:1527272268271};\\\", \\\"{x:155,y:544,t:1527272268288};\\\", \\\"{x:147,y:544,t:1527272268304};\\\", \\\"{x:146,y:544,t:1527272268321};\\\", \\\"{x:145,y:544,t:1527272268340};\\\", \\\"{x:144,y:545,t:1527272268364};\\\", \\\"{x:144,y:546,t:1527272268380};\\\", \\\"{x:143,y:547,t:1527272268388};\\\", \\\"{x:143,y:548,t:1527272268403};\\\", \\\"{x:143,y:549,t:1527272268420};\\\", \\\"{x:143,y:552,t:1527272268438};\\\", \\\"{x:147,y:555,t:1527272268454};\\\", \\\"{x:162,y:557,t:1527272268471};\\\", \\\"{x:203,y:557,t:1527272268487};\\\", \\\"{x:295,y:557,t:1527272268504};\\\", \\\"{x:403,y:557,t:1527272268521};\\\", \\\"{x:525,y:559,t:1527272268537};\\\", \\\"{x:647,y:559,t:1527272268554};\\\", \\\"{x:763,y:559,t:1527272268571};\\\", \\\"{x:866,y:559,t:1527272268587};\\\", \\\"{x:924,y:559,t:1527272268604};\\\", \\\"{x:959,y:559,t:1527272268621};\\\", \\\"{x:962,y:559,t:1527272268638};\\\", \\\"{x:961,y:559,t:1527272268725};\\\", \\\"{x:959,y:561,t:1527272268738};\\\", \\\"{x:953,y:561,t:1527272268755};\\\", \\\"{x:937,y:561,t:1527272268770};\\\", \\\"{x:913,y:558,t:1527272268788};\\\", \\\"{x:890,y:554,t:1527272268806};\\\", \\\"{x:852,y:549,t:1527272268820};\\\", \\\"{x:836,y:547,t:1527272268838};\\\", \\\"{x:827,y:547,t:1527272268854};\\\", \\\"{x:824,y:547,t:1527272268870};\\\", \\\"{x:823,y:547,t:1527272268888};\\\", \\\"{x:816,y:547,t:1527272269278};\\\", \\\"{x:801,y:563,t:1527272269289};\\\", \\\"{x:764,y:597,t:1527272269304};\\\", \\\"{x:700,y:643,t:1527272269322};\\\", \\\"{x:643,y:685,t:1527272269338};\\\", \\\"{x:593,y:719,t:1527272269354};\\\", \\\"{x:570,y:736,t:1527272269372};\\\", \\\"{x:553,y:750,t:1527272269388};\\\", \\\"{x:539,y:760,t:1527272269405};\\\", \\\"{x:532,y:764,t:1527272269421};\\\", \\\"{x:523,y:768,t:1527272269439};\\\", \\\"{x:514,y:770,t:1527272269455};\\\", \\\"{x:513,y:770,t:1527272269471};\\\", \\\"{x:512,y:770,t:1527272269517};\\\", \\\"{x:516,y:760,t:1527272269525};\\\", \\\"{x:526,y:745,t:1527272269539};\\\", \\\"{x:568,y:706,t:1527272269555};\\\", \\\"{x:641,y:652,t:1527272269572};\\\", \\\"{x:719,y:614,t:1527272269588};\\\", \\\"{x:822,y:584,t:1527272269605};\\\", \\\"{x:869,y:572,t:1527272269622};\\\", \\\"{x:887,y:570,t:1527272269638};\\\", \\\"{x:892,y:568,t:1527272269654};\\\", \\\"{x:890,y:565,t:1527272269765};\\\", \\\"{x:886,y:561,t:1527272269773};\\\", \\\"{x:881,y:557,t:1527272269787};\\\", \\\"{x:866,y:548,t:1527272269806};\\\", \\\"{x:853,y:543,t:1527272269821};\\\", \\\"{x:846,y:539,t:1527272269838};\\\", \\\"{x:842,y:537,t:1527272269855};\\\", \\\"{x:839,y:536,t:1527272269872};\\\", \\\"{x:838,y:535,t:1527272269888};\\\", \\\"{x:836,y:535,t:1527272269905};\\\", \\\"{x:835,y:535,t:1527272269922};\\\", \\\"{x:831,y:535,t:1527272270196};\\\", \\\"{x:821,y:543,t:1527272270206};\\\", \\\"{x:786,y:572,t:1527272270223};\\\", \\\"{x:747,y:606,t:1527272270239};\\\", \\\"{x:708,y:642,t:1527272270256};\\\", \\\"{x:667,y:673,t:1527272270272};\\\", \\\"{x:646,y:692,t:1527272270289};\\\", \\\"{x:631,y:705,t:1527272270306};\\\", \\\"{x:618,y:715,t:1527272270323};\\\", \\\"{x:609,y:719,t:1527272270338};\\\", \\\"{x:603,y:722,t:1527272270356};\\\", \\\"{x:585,y:726,t:1527272270372};\\\", \\\"{x:573,y:727,t:1527272270389};\\\", \\\"{x:562,y:729,t:1527272270406};\\\", \\\"{x:557,y:729,t:1527272270422};\\\", \\\"{x:555,y:729,t:1527272270438};\\\", \\\"{x:553,y:729,t:1527272270455};\\\", \\\"{x:553,y:727,t:1527272270473};\\\", \\\"{x:551,y:722,t:1527272270489};\\\", \\\"{x:550,y:719,t:1527272270506};\\\", \\\"{x:549,y:716,t:1527272270522};\\\", \\\"{x:548,y:715,t:1527272270538};\\\", \\\"{x:547,y:714,t:1527272270556};\\\", \\\"{x:540,y:714,t:1527272270573};\\\", \\\"{x:530,y:721,t:1527272270590};\\\", \\\"{x:520,y:730,t:1527272270606};\\\", \\\"{x:514,y:736,t:1527272270622};\\\", \\\"{x:513,y:739,t:1527272270640};\\\", \\\"{x:512,y:740,t:1527272270656};\\\", \\\"{x:513,y:740,t:1527272270861};\\\", \\\"{x:513,y:739,t:1527272270893};\\\", \\\"{x:516,y:739,t:1527272274181};\\\", \\\"{x:517,y:739,t:1527272274192};\\\", \\\"{x:519,y:737,t:1527272274209};\\\", \\\"{x:519,y:736,t:1527272274227};\\\", \\\"{x:521,y:733,t:1527272274243};\\\", \\\"{x:521,y:732,t:1527272274269};\\\" ] }, { \\\"rt\\\": 29064, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 593800, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"2WQ0M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -F -M -Z -Z -02 PM-Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:522,y:732,t:1527272275693};\\\", \\\"{x:523,y:730,t:1527272275700};\\\", \\\"{x:524,y:730,t:1527272275749};\\\", \\\"{x:525,y:728,t:1527272275981};\\\", \\\"{x:526,y:726,t:1527272275996};\\\", \\\"{x:529,y:723,t:1527272276013};\\\", \\\"{x:538,y:714,t:1527272276030};\\\", \\\"{x:544,y:700,t:1527272276046};\\\", \\\"{x:547,y:691,t:1527272276060};\\\", \\\"{x:554,y:659,t:1527272276077};\\\", \\\"{x:555,y:639,t:1527272276093};\\\", \\\"{x:555,y:610,t:1527272276112};\\\", \\\"{x:545,y:573,t:1527272276127};\\\", \\\"{x:540,y:552,t:1527272276144};\\\", \\\"{x:536,y:538,t:1527272276160};\\\", \\\"{x:529,y:524,t:1527272276178};\\\", \\\"{x:526,y:518,t:1527272276194};\\\", \\\"{x:525,y:516,t:1527272276211};\\\", \\\"{x:525,y:515,t:1527272276227};\\\", \\\"{x:525,y:511,t:1527272276789};\\\", \\\"{x:525,y:508,t:1527272276797};\\\", \\\"{x:527,y:506,t:1527272276811};\\\", \\\"{x:529,y:504,t:1527272276827};\\\", \\\"{x:531,y:500,t:1527272276844};\\\", \\\"{x:533,y:494,t:1527272276861};\\\", \\\"{x:534,y:493,t:1527272276877};\\\", \\\"{x:534,y:491,t:1527272276894};\\\", \\\"{x:535,y:490,t:1527272276911};\\\", \\\"{x:535,y:487,t:1527272277598};\\\", \\\"{x:535,y:485,t:1527272277613};\\\", \\\"{x:535,y:481,t:1527272277628};\\\", \\\"{x:536,y:479,t:1527272277645};\\\", \\\"{x:537,y:477,t:1527272277662};\\\", \\\"{x:537,y:476,t:1527272277756};\\\", \\\"{x:537,y:474,t:1527272277788};\\\", \\\"{x:537,y:472,t:1527272277804};\\\", \\\"{x:537,y:469,t:1527272277812};\\\", \\\"{x:535,y:466,t:1527272277829};\\\", \\\"{x:534,y:463,t:1527272277846};\\\", \\\"{x:533,y:461,t:1527272277862};\\\", \\\"{x:532,y:459,t:1527272277884};\\\", \\\"{x:535,y:459,t:1527272278462};\\\", \\\"{x:541,y:459,t:1527272278470};\\\", \\\"{x:548,y:459,t:1527272278479};\\\", \\\"{x:570,y:459,t:1527272278496};\\\", \\\"{x:598,y:459,t:1527272278513};\\\", \\\"{x:636,y:459,t:1527272278530};\\\", \\\"{x:704,y:461,t:1527272278546};\\\", \\\"{x:794,y:465,t:1527272278563};\\\", \\\"{x:940,y:486,t:1527272278580};\\\", \\\"{x:1029,y:500,t:1527272278596};\\\", \\\"{x:1112,y:511,t:1527272278613};\\\", \\\"{x:1184,y:521,t:1527272278630};\\\", \\\"{x:1248,y:530,t:1527272278646};\\\", \\\"{x:1310,y:540,t:1527272278663};\\\", \\\"{x:1361,y:548,t:1527272278680};\\\", \\\"{x:1392,y:556,t:1527272278696};\\\", \\\"{x:1416,y:563,t:1527272278714};\\\", \\\"{x:1430,y:568,t:1527272278731};\\\", \\\"{x:1436,y:572,t:1527272278746};\\\", \\\"{x:1439,y:575,t:1527272278764};\\\", \\\"{x:1442,y:580,t:1527272278781};\\\", \\\"{x:1442,y:581,t:1527272278796};\\\", \\\"{x:1442,y:583,t:1527272278814};\\\", \\\"{x:1442,y:584,t:1527272278836};\\\", \\\"{x:1442,y:586,t:1527272278853};\\\", \\\"{x:1442,y:587,t:1527272278871};\\\", \\\"{x:1440,y:589,t:1527272278881};\\\", \\\"{x:1438,y:593,t:1527272278897};\\\", \\\"{x:1434,y:597,t:1527272278913};\\\", \\\"{x:1431,y:602,t:1527272278930};\\\", \\\"{x:1424,y:608,t:1527272278947};\\\", \\\"{x:1414,y:617,t:1527272278963};\\\", \\\"{x:1398,y:632,t:1527272278980};\\\", \\\"{x:1388,y:642,t:1527272278997};\\\", \\\"{x:1380,y:651,t:1527272279013};\\\", \\\"{x:1370,y:662,t:1527272279030};\\\", \\\"{x:1359,y:671,t:1527272279047};\\\", \\\"{x:1349,y:678,t:1527272279065};\\\", \\\"{x:1342,y:681,t:1527272279081};\\\", \\\"{x:1337,y:685,t:1527272279097};\\\", \\\"{x:1333,y:687,t:1527272279114};\\\", \\\"{x:1331,y:688,t:1527272279130};\\\", \\\"{x:1330,y:688,t:1527272279165};\\\", \\\"{x:1328,y:689,t:1527272279180};\\\", \\\"{x:1327,y:689,t:1527272279197};\\\", \\\"{x:1326,y:690,t:1527272279215};\\\", \\\"{x:1324,y:690,t:1527272279231};\\\", \\\"{x:1317,y:690,t:1527272279247};\\\", \\\"{x:1312,y:690,t:1527272279264};\\\", \\\"{x:1305,y:690,t:1527272279280};\\\", \\\"{x:1302,y:690,t:1527272279297};\\\", \\\"{x:1300,y:690,t:1527272279314};\\\", \\\"{x:1299,y:689,t:1527272279331};\\\", \\\"{x:1298,y:689,t:1527272279347};\\\", \\\"{x:1297,y:689,t:1527272279364};\\\", \\\"{x:1296,y:689,t:1527272279412};\\\", \\\"{x:1296,y:688,t:1527272279500};\\\", \\\"{x:1295,y:688,t:1527272279515};\\\", \\\"{x:1292,y:688,t:1527272279531};\\\", \\\"{x:1289,y:688,t:1527272279548};\\\", \\\"{x:1286,y:689,t:1527272279565};\\\", \\\"{x:1284,y:690,t:1527272279582};\\\", \\\"{x:1284,y:691,t:1527272279597};\\\", \\\"{x:1283,y:692,t:1527272279709};\\\", \\\"{x:1284,y:692,t:1527272279717};\\\", \\\"{x:1285,y:692,t:1527272279731};\\\", \\\"{x:1291,y:694,t:1527272279748};\\\", \\\"{x:1294,y:694,t:1527272279765};\\\", \\\"{x:1300,y:694,t:1527272279782};\\\", \\\"{x:1303,y:694,t:1527272279798};\\\", \\\"{x:1307,y:694,t:1527272279815};\\\", \\\"{x:1310,y:695,t:1527272279831};\\\", \\\"{x:1312,y:696,t:1527272279849};\\\", \\\"{x:1314,y:696,t:1527272279865};\\\", \\\"{x:1315,y:697,t:1527272279882};\\\", \\\"{x:1316,y:697,t:1527272279899};\\\", \\\"{x:1317,y:697,t:1527272279915};\\\", \\\"{x:1318,y:697,t:1527272279931};\\\", \\\"{x:1318,y:700,t:1527272280278};\\\", \\\"{x:1318,y:704,t:1527272280285};\\\", \\\"{x:1316,y:712,t:1527272280299};\\\", \\\"{x:1314,y:723,t:1527272280316};\\\", \\\"{x:1311,y:744,t:1527272280333};\\\", \\\"{x:1309,y:760,t:1527272280349};\\\", \\\"{x:1309,y:774,t:1527272280366};\\\", \\\"{x:1309,y:783,t:1527272280383};\\\", \\\"{x:1309,y:790,t:1527272280399};\\\", \\\"{x:1306,y:797,t:1527272280416};\\\", \\\"{x:1306,y:803,t:1527272280432};\\\", \\\"{x:1306,y:806,t:1527272280449};\\\", \\\"{x:1306,y:810,t:1527272280465};\\\", \\\"{x:1306,y:816,t:1527272280482};\\\", \\\"{x:1306,y:822,t:1527272280500};\\\", \\\"{x:1308,y:828,t:1527272280516};\\\", \\\"{x:1312,y:839,t:1527272280533};\\\", \\\"{x:1318,y:850,t:1527272280549};\\\", \\\"{x:1323,y:856,t:1527272280566};\\\", \\\"{x:1326,y:860,t:1527272280583};\\\", \\\"{x:1332,y:863,t:1527272280599};\\\", \\\"{x:1334,y:865,t:1527272280616};\\\", \\\"{x:1335,y:865,t:1527272280633};\\\", \\\"{x:1336,y:865,t:1527272280661};\\\", \\\"{x:1337,y:866,t:1527272280693};\\\", \\\"{x:1338,y:866,t:1527272280709};\\\", \\\"{x:1339,y:867,t:1527272280741};\\\", \\\"{x:1340,y:868,t:1527272280765};\\\", \\\"{x:1342,y:869,t:1527272280781};\\\", \\\"{x:1342,y:870,t:1527272280789};\\\", \\\"{x:1345,y:872,t:1527272280800};\\\", \\\"{x:1349,y:876,t:1527272280817};\\\", \\\"{x:1359,y:881,t:1527272280832};\\\", \\\"{x:1370,y:886,t:1527272280850};\\\", \\\"{x:1384,y:888,t:1527272280866};\\\", \\\"{x:1401,y:890,t:1527272280884};\\\", \\\"{x:1416,y:890,t:1527272280900};\\\", \\\"{x:1448,y:882,t:1527272280917};\\\", \\\"{x:1482,y:872,t:1527272280933};\\\", \\\"{x:1508,y:867,t:1527272280949};\\\", \\\"{x:1530,y:867,t:1527272280967};\\\", \\\"{x:1543,y:867,t:1527272280983};\\\", \\\"{x:1552,y:867,t:1527272281000};\\\", \\\"{x:1558,y:867,t:1527272281016};\\\", \\\"{x:1563,y:867,t:1527272281033};\\\", \\\"{x:1569,y:867,t:1527272281050};\\\", \\\"{x:1572,y:867,t:1527272281067};\\\", \\\"{x:1577,y:866,t:1527272281084};\\\", \\\"{x:1579,y:866,t:1527272281099};\\\", \\\"{x:1581,y:865,t:1527272281116};\\\", \\\"{x:1581,y:863,t:1527272281190};\\\", \\\"{x:1581,y:860,t:1527272281200};\\\", \\\"{x:1581,y:846,t:1527272281217};\\\", \\\"{x:1578,y:821,t:1527272281233};\\\", \\\"{x:1565,y:783,t:1527272281250};\\\", \\\"{x:1539,y:744,t:1527272281267};\\\", \\\"{x:1515,y:710,t:1527272281283};\\\", \\\"{x:1501,y:690,t:1527272281300};\\\", \\\"{x:1493,y:676,t:1527272281317};\\\", \\\"{x:1486,y:661,t:1527272281334};\\\", \\\"{x:1486,y:655,t:1527272281351};\\\", \\\"{x:1482,y:649,t:1527272281367};\\\", \\\"{x:1481,y:645,t:1527272281383};\\\", \\\"{x:1479,y:639,t:1527272281401};\\\", \\\"{x:1478,y:631,t:1527272281417};\\\", \\\"{x:1474,y:620,t:1527272281434};\\\", \\\"{x:1472,y:613,t:1527272281451};\\\", \\\"{x:1468,y:603,t:1527272281467};\\\", \\\"{x:1465,y:594,t:1527272281484};\\\", \\\"{x:1460,y:574,t:1527272281502};\\\", \\\"{x:1454,y:561,t:1527272281517};\\\", \\\"{x:1452,y:552,t:1527272281534};\\\", \\\"{x:1449,y:544,t:1527272281551};\\\", \\\"{x:1446,y:536,t:1527272281567};\\\", \\\"{x:1445,y:531,t:1527272281584};\\\", \\\"{x:1444,y:525,t:1527272281601};\\\", \\\"{x:1442,y:520,t:1527272281617};\\\", \\\"{x:1441,y:514,t:1527272281634};\\\", \\\"{x:1440,y:508,t:1527272281651};\\\", \\\"{x:1438,y:502,t:1527272281668};\\\", \\\"{x:1438,y:496,t:1527272281685};\\\", \\\"{x:1437,y:488,t:1527272281701};\\\", \\\"{x:1436,y:484,t:1527272281717};\\\", \\\"{x:1436,y:482,t:1527272281733};\\\", \\\"{x:1436,y:480,t:1527272281751};\\\", \\\"{x:1435,y:478,t:1527272281767};\\\", \\\"{x:1435,y:476,t:1527272281784};\\\", \\\"{x:1435,y:475,t:1527272281801};\\\", \\\"{x:1435,y:474,t:1527272281818};\\\", \\\"{x:1435,y:473,t:1527272281834};\\\", \\\"{x:1435,y:472,t:1527272283390};\\\", \\\"{x:1439,y:473,t:1527272283404};\\\", \\\"{x:1450,y:486,t:1527272283420};\\\", \\\"{x:1467,y:506,t:1527272283436};\\\", \\\"{x:1490,y:528,t:1527272283452};\\\", \\\"{x:1503,y:545,t:1527272283470};\\\", \\\"{x:1515,y:558,t:1527272283486};\\\", \\\"{x:1523,y:566,t:1527272283503};\\\", \\\"{x:1525,y:567,t:1527272283520};\\\", \\\"{x:1526,y:570,t:1527272283536};\\\", \\\"{x:1528,y:573,t:1527272283553};\\\", \\\"{x:1533,y:578,t:1527272283570};\\\", \\\"{x:1540,y:583,t:1527272283585};\\\", \\\"{x:1550,y:588,t:1527272283603};\\\", \\\"{x:1566,y:597,t:1527272283620};\\\", \\\"{x:1599,y:613,t:1527272283636};\\\", \\\"{x:1621,y:626,t:1527272283653};\\\", \\\"{x:1636,y:636,t:1527272283670};\\\", \\\"{x:1643,y:641,t:1527272283686};\\\", \\\"{x:1648,y:645,t:1527272283703};\\\", \\\"{x:1651,y:649,t:1527272283720};\\\", \\\"{x:1652,y:654,t:1527272283736};\\\", \\\"{x:1654,y:659,t:1527272283753};\\\", \\\"{x:1655,y:664,t:1527272283770};\\\", \\\"{x:1655,y:666,t:1527272283787};\\\", \\\"{x:1655,y:667,t:1527272283803};\\\", \\\"{x:1655,y:668,t:1527272283820};\\\", \\\"{x:1655,y:669,t:1527272283861};\\\", \\\"{x:1654,y:670,t:1527272283871};\\\", \\\"{x:1643,y:673,t:1527272283887};\\\", \\\"{x:1633,y:675,t:1527272283904};\\\", \\\"{x:1628,y:678,t:1527272283919};\\\", \\\"{x:1623,y:681,t:1527272283936};\\\", \\\"{x:1615,y:684,t:1527272283953};\\\", \\\"{x:1609,y:685,t:1527272283970};\\\", \\\"{x:1605,y:685,t:1527272283986};\\\", \\\"{x:1603,y:686,t:1527272284003};\\\", \\\"{x:1603,y:688,t:1527272284181};\\\", \\\"{x:1603,y:689,t:1527272284204};\\\", \\\"{x:1603,y:690,t:1527272284221};\\\", \\\"{x:1603,y:691,t:1527272284237};\\\", \\\"{x:1603,y:692,t:1527272284284};\\\", \\\"{x:1604,y:693,t:1527272284292};\\\", \\\"{x:1605,y:693,t:1527272284308};\\\", \\\"{x:1606,y:694,t:1527272284324};\\\", \\\"{x:1606,y:695,t:1527272285228};\\\", \\\"{x:1607,y:696,t:1527272285244};\\\", \\\"{x:1608,y:698,t:1527272285254};\\\", \\\"{x:1609,y:699,t:1527272285271};\\\", \\\"{x:1610,y:701,t:1527272285288};\\\", \\\"{x:1611,y:702,t:1527272285304};\\\", \\\"{x:1611,y:703,t:1527272285428};\\\", \\\"{x:1611,y:704,t:1527272286004};\\\", \\\"{x:1611,y:705,t:1527272286117};\\\", \\\"{x:1611,y:708,t:1527272286125};\\\", \\\"{x:1611,y:711,t:1527272286140};\\\", \\\"{x:1611,y:716,t:1527272286155};\\\", \\\"{x:1611,y:727,t:1527272286172};\\\", \\\"{x:1610,y:737,t:1527272286189};\\\", \\\"{x:1609,y:751,t:1527272286205};\\\", \\\"{x:1608,y:764,t:1527272286223};\\\", \\\"{x:1605,y:777,t:1527272286239};\\\", \\\"{x:1603,y:787,t:1527272286256};\\\", \\\"{x:1600,y:798,t:1527272286273};\\\", \\\"{x:1595,y:807,t:1527272286289};\\\", \\\"{x:1590,y:819,t:1527272286305};\\\", \\\"{x:1576,y:837,t:1527272286326};\\\", \\\"{x:1572,y:844,t:1527272286339};\\\", \\\"{x:1565,y:852,t:1527272286355};\\\", \\\"{x:1557,y:862,t:1527272286372};\\\", \\\"{x:1553,y:868,t:1527272286389};\\\", \\\"{x:1547,y:877,t:1527272286406};\\\", \\\"{x:1541,y:885,t:1527272286423};\\\", \\\"{x:1537,y:891,t:1527272286440};\\\", \\\"{x:1532,y:896,t:1527272286456};\\\", \\\"{x:1530,y:901,t:1527272286473};\\\", \\\"{x:1526,y:906,t:1527272286489};\\\", \\\"{x:1522,y:914,t:1527272286506};\\\", \\\"{x:1517,y:923,t:1527272286522};\\\", \\\"{x:1511,y:931,t:1527272286539};\\\", \\\"{x:1502,y:946,t:1527272286556};\\\", \\\"{x:1497,y:953,t:1527272286572};\\\", \\\"{x:1495,y:955,t:1527272286590};\\\", \\\"{x:1494,y:959,t:1527272286607};\\\", \\\"{x:1493,y:960,t:1527272286623};\\\", \\\"{x:1492,y:963,t:1527272286640};\\\", \\\"{x:1490,y:965,t:1527272286657};\\\", \\\"{x:1488,y:968,t:1527272286673};\\\", \\\"{x:1486,y:969,t:1527272286689};\\\", \\\"{x:1484,y:972,t:1527272286707};\\\", \\\"{x:1484,y:974,t:1527272286723};\\\", \\\"{x:1482,y:974,t:1527272286789};\\\", \\\"{x:1481,y:974,t:1527272286870};\\\", \\\"{x:1480,y:974,t:1527272286877};\\\", \\\"{x:1480,y:973,t:1527272286889};\\\", \\\"{x:1479,y:971,t:1527272286906};\\\", \\\"{x:1478,y:971,t:1527272286924};\\\", \\\"{x:1478,y:970,t:1527272287021};\\\", \\\"{x:1478,y:969,t:1527272287076};\\\", \\\"{x:1477,y:968,t:1527272287101};\\\", \\\"{x:1477,y:967,t:1527272287117};\\\", \\\"{x:1477,y:966,t:1527272287124};\\\", \\\"{x:1476,y:965,t:1527272287157};\\\", \\\"{x:1475,y:965,t:1527272287174};\\\", \\\"{x:1475,y:963,t:1527272287197};\\\", \\\"{x:1474,y:963,t:1527272287236};\\\", \\\"{x:1474,y:961,t:1527272288095};\\\", \\\"{x:1472,y:961,t:1527272288229};\\\", \\\"{x:1468,y:961,t:1527272288242};\\\", \\\"{x:1442,y:954,t:1527272288259};\\\", \\\"{x:1367,y:932,t:1527272288275};\\\", \\\"{x:1233,y:902,t:1527272288292};\\\", \\\"{x:972,y:820,t:1527272288309};\\\", \\\"{x:805,y:754,t:1527272288325};\\\", \\\"{x:667,y:691,t:1527272288341};\\\", \\\"{x:582,y:644,t:1527272288359};\\\", \\\"{x:539,y:619,t:1527272288375};\\\", \\\"{x:527,y:610,t:1527272288392};\\\", \\\"{x:527,y:605,t:1527272288408};\\\", \\\"{x:527,y:597,t:1527272288420};\\\", \\\"{x:527,y:587,t:1527272288438};\\\", \\\"{x:528,y:578,t:1527272288454};\\\", \\\"{x:528,y:570,t:1527272288470};\\\", \\\"{x:528,y:561,t:1527272288488};\\\", \\\"{x:528,y:555,t:1527272288505};\\\", \\\"{x:530,y:549,t:1527272288520};\\\", \\\"{x:536,y:544,t:1527272288537};\\\", \\\"{x:541,y:541,t:1527272288554};\\\", \\\"{x:555,y:534,t:1527272288571};\\\", \\\"{x:564,y:529,t:1527272288587};\\\", \\\"{x:578,y:521,t:1527272288605};\\\", \\\"{x:581,y:517,t:1527272288621};\\\", \\\"{x:581,y:516,t:1527272288733};\\\", \\\"{x:582,y:516,t:1527272288765};\\\", \\\"{x:584,y:514,t:1527272288773};\\\", \\\"{x:589,y:512,t:1527272288787};\\\", \\\"{x:605,y:503,t:1527272288806};\\\", \\\"{x:609,y:501,t:1527272288820};\\\", \\\"{x:610,y:499,t:1527272288837};\\\", \\\"{x:611,y:499,t:1527272289068};\\\", \\\"{x:615,y:498,t:1527272289076};\\\", \\\"{x:622,y:497,t:1527272289088};\\\", \\\"{x:642,y:494,t:1527272289104};\\\", \\\"{x:665,y:493,t:1527272289121};\\\", \\\"{x:701,y:493,t:1527272289137};\\\", \\\"{x:743,y:493,t:1527272289155};\\\", \\\"{x:775,y:493,t:1527272289171};\\\", \\\"{x:793,y:493,t:1527272289187};\\\", \\\"{x:797,y:493,t:1527272289205};\\\", \\\"{x:798,y:493,t:1527272289293};\\\", \\\"{x:798,y:492,t:1527272289305};\\\", \\\"{x:801,y:493,t:1527272289365};\\\", \\\"{x:806,y:495,t:1527272289372};\\\", \\\"{x:816,y:499,t:1527272289388};\\\", \\\"{x:828,y:499,t:1527272289405};\\\", \\\"{x:830,y:499,t:1527272289422};\\\", \\\"{x:831,y:499,t:1527272289438};\\\", \\\"{x:832,y:499,t:1527272289455};\\\", \\\"{x:834,y:499,t:1527272289477};\\\", \\\"{x:835,y:499,t:1527272289489};\\\", \\\"{x:836,y:499,t:1527272289540};\\\", \\\"{x:838,y:499,t:1527272289700};\\\", \\\"{x:843,y:499,t:1527272289716};\\\", \\\"{x:847,y:500,t:1527272289724};\\\", \\\"{x:859,y:506,t:1527272289738};\\\", \\\"{x:896,y:524,t:1527272289756};\\\", \\\"{x:964,y:561,t:1527272289771};\\\", \\\"{x:1108,y:636,t:1527272289788};\\\", \\\"{x:1212,y:694,t:1527272289805};\\\", \\\"{x:1313,y:754,t:1527272289822};\\\", \\\"{x:1399,y:795,t:1527272289838};\\\", \\\"{x:1461,y:823,t:1527272289855};\\\", \\\"{x:1496,y:837,t:1527272289872};\\\", \\\"{x:1507,y:840,t:1527272289888};\\\", \\\"{x:1507,y:839,t:1527272289942};\\\", \\\"{x:1509,y:835,t:1527272289956};\\\", \\\"{x:1523,y:809,t:1527272289972};\\\", \\\"{x:1535,y:780,t:1527272289989};\\\", \\\"{x:1549,y:744,t:1527272290006};\\\", \\\"{x:1559,y:719,t:1527272290022};\\\", \\\"{x:1561,y:705,t:1527272290039};\\\", \\\"{x:1563,y:696,t:1527272290056};\\\", \\\"{x:1563,y:693,t:1527272290072};\\\", \\\"{x:1563,y:690,t:1527272290089};\\\", \\\"{x:1564,y:689,t:1527272290106};\\\", \\\"{x:1564,y:687,t:1527272290122};\\\", \\\"{x:1566,y:686,t:1527272290140};\\\", \\\"{x:1566,y:685,t:1527272290156};\\\", \\\"{x:1568,y:684,t:1527272290172};\\\", \\\"{x:1574,y:682,t:1527272290189};\\\", \\\"{x:1583,y:679,t:1527272290205};\\\", \\\"{x:1591,y:677,t:1527272290224};\\\", \\\"{x:1595,y:675,t:1527272290239};\\\", \\\"{x:1599,y:675,t:1527272290256};\\\", \\\"{x:1602,y:675,t:1527272290273};\\\", \\\"{x:1603,y:675,t:1527272290288};\\\", \\\"{x:1605,y:675,t:1527272290305};\\\", \\\"{x:1606,y:675,t:1527272290323};\\\", \\\"{x:1606,y:676,t:1527272290338};\\\", \\\"{x:1607,y:678,t:1527272290355};\\\", \\\"{x:1609,y:685,t:1527272290371};\\\", \\\"{x:1609,y:689,t:1527272290389};\\\", \\\"{x:1609,y:694,t:1527272290405};\\\", \\\"{x:1609,y:699,t:1527272290422};\\\", \\\"{x:1609,y:703,t:1527272290439};\\\", \\\"{x:1608,y:708,t:1527272290455};\\\", \\\"{x:1608,y:714,t:1527272290472};\\\", \\\"{x:1607,y:719,t:1527272290488};\\\", \\\"{x:1605,y:728,t:1527272290505};\\\", \\\"{x:1604,y:736,t:1527272290522};\\\", \\\"{x:1602,y:744,t:1527272290538};\\\", \\\"{x:1596,y:755,t:1527272290556};\\\", \\\"{x:1589,y:769,t:1527272290572};\\\", \\\"{x:1583,y:781,t:1527272290589};\\\", \\\"{x:1578,y:793,t:1527272290605};\\\", \\\"{x:1571,y:807,t:1527272290623};\\\", \\\"{x:1565,y:818,t:1527272290640};\\\", \\\"{x:1555,y:831,t:1527272290655};\\\", \\\"{x:1544,y:843,t:1527272290673};\\\", \\\"{x:1535,y:854,t:1527272290690};\\\", \\\"{x:1526,y:866,t:1527272290706};\\\", \\\"{x:1517,y:879,t:1527272290723};\\\", \\\"{x:1507,y:891,t:1527272290741};\\\", \\\"{x:1503,y:895,t:1527272290756};\\\", \\\"{x:1491,y:907,t:1527272290773};\\\", \\\"{x:1484,y:913,t:1527272290790};\\\", \\\"{x:1481,y:919,t:1527272290805};\\\", \\\"{x:1479,y:925,t:1527272290823};\\\", \\\"{x:1478,y:930,t:1527272290840};\\\", \\\"{x:1477,y:936,t:1527272290856};\\\", \\\"{x:1477,y:940,t:1527272290873};\\\", \\\"{x:1476,y:944,t:1527272290890};\\\", \\\"{x:1476,y:948,t:1527272290906};\\\", \\\"{x:1476,y:952,t:1527272290923};\\\", \\\"{x:1476,y:955,t:1527272290940};\\\", \\\"{x:1476,y:956,t:1527272290956};\\\", \\\"{x:1476,y:957,t:1527272290973};\\\", \\\"{x:1476,y:958,t:1527272291166};\\\", \\\"{x:1476,y:959,t:1527272291173};\\\", \\\"{x:1476,y:960,t:1527272291190};\\\", \\\"{x:1476,y:961,t:1527272291207};\\\", \\\"{x:1476,y:962,t:1527272291621};\\\", \\\"{x:1476,y:964,t:1527272291637};\\\", \\\"{x:1473,y:964,t:1527272291645};\\\", \\\"{x:1466,y:965,t:1527272291657};\\\", \\\"{x:1446,y:965,t:1527272291674};\\\", \\\"{x:1403,y:961,t:1527272291690};\\\", \\\"{x:1325,y:948,t:1527272291707};\\\", \\\"{x:1177,y:912,t:1527272291724};\\\", \\\"{x:1116,y:896,t:1527272291740};\\\", \\\"{x:940,y:852,t:1527272291757};\\\", \\\"{x:824,y:821,t:1527272291774};\\\", \\\"{x:740,y:794,t:1527272291790};\\\", \\\"{x:695,y:779,t:1527272291807};\\\", \\\"{x:669,y:772,t:1527272291824};\\\", \\\"{x:657,y:768,t:1527272291840};\\\", \\\"{x:651,y:766,t:1527272291857};\\\", \\\"{x:644,y:764,t:1527272291874};\\\", \\\"{x:636,y:763,t:1527272291890};\\\", \\\"{x:626,y:762,t:1527272291907};\\\", \\\"{x:617,y:759,t:1527272291924};\\\", \\\"{x:602,y:755,t:1527272291940};\\\", \\\"{x:595,y:755,t:1527272291957};\\\", \\\"{x:582,y:752,t:1527272291974};\\\", \\\"{x:570,y:749,t:1527272291991};\\\", \\\"{x:561,y:749,t:1527272292008};\\\", \\\"{x:555,y:748,t:1527272292024};\\\", \\\"{x:553,y:746,t:1527272292040};\\\", \\\"{x:552,y:746,t:1527272292205};\\\", \\\"{x:551,y:746,t:1527272292213};\\\", \\\"{x:550,y:746,t:1527272292229};\\\", \\\"{x:549,y:746,t:1527272292240};\\\", \\\"{x:548,y:746,t:1527272292257};\\\", \\\"{x:547,y:746,t:1527272292276};\\\", \\\"{x:546,y:746,t:1527272292389};\\\", \\\"{x:545,y:746,t:1527272292412};\\\", \\\"{x:544,y:746,t:1527272292460};\\\", \\\"{x:544,y:745,t:1527272299941};\\\", \\\"{x:558,y:743,t:1527272299949};\\\", \\\"{x:589,y:741,t:1527272299961};\\\", \\\"{x:692,y:737,t:1527272299977};\\\", \\\"{x:806,y:700,t:1527272299994};\\\", \\\"{x:972,y:638,t:1527272300014};\\\", \\\"{x:1076,y:593,t:1527272300030};\\\", \\\"{x:1170,y:555,t:1527272300047};\\\", \\\"{x:1255,y:522,t:1527272300064};\\\", \\\"{x:1288,y:506,t:1527272300079};\\\", \\\"{x:1324,y:498,t:1527272300097};\\\", \\\"{x:1335,y:496,t:1527272300114};\\\", \\\"{x:1339,y:496,t:1527272300130};\\\", \\\"{x:1341,y:495,t:1527272300147};\\\", \\\"{x:1356,y:499,t:1527272300164};\\\", \\\"{x:1372,y:507,t:1527272300180};\\\", \\\"{x:1393,y:521,t:1527272300198};\\\", \\\"{x:1417,y:536,t:1527272300214};\\\", \\\"{x:1446,y:558,t:1527272300232};\\\", \\\"{x:1471,y:578,t:1527272300248};\\\", \\\"{x:1503,y:608,t:1527272300265};\\\", \\\"{x:1542,y:646,t:1527272300282};\\\", \\\"{x:1578,y:677,t:1527272300298};\\\", \\\"{x:1606,y:697,t:1527272300314};\\\", \\\"{x:1620,y:706,t:1527272300331};\\\", \\\"{x:1626,y:709,t:1527272300347};\\\", \\\"{x:1628,y:711,t:1527272300365};\\\", \\\"{x:1628,y:713,t:1527272300565};\\\", \\\"{x:1624,y:720,t:1527272300581};\\\", \\\"{x:1615,y:734,t:1527272300597};\\\", \\\"{x:1607,y:748,t:1527272300614};\\\", \\\"{x:1597,y:760,t:1527272300631};\\\", \\\"{x:1588,y:774,t:1527272300648};\\\", \\\"{x:1574,y:793,t:1527272300665};\\\", \\\"{x:1564,y:807,t:1527272300681};\\\", \\\"{x:1553,y:822,t:1527272300697};\\\", \\\"{x:1544,y:833,t:1527272300714};\\\", \\\"{x:1535,y:843,t:1527272300731};\\\", \\\"{x:1527,y:852,t:1527272300748};\\\", \\\"{x:1523,y:858,t:1527272300764};\\\", \\\"{x:1520,y:864,t:1527272300781};\\\", \\\"{x:1517,y:869,t:1527272300798};\\\", \\\"{x:1513,y:876,t:1527272300814};\\\", \\\"{x:1511,y:881,t:1527272300832};\\\", \\\"{x:1509,y:886,t:1527272300848};\\\", \\\"{x:1507,y:890,t:1527272300865};\\\", \\\"{x:1505,y:893,t:1527272300881};\\\", \\\"{x:1503,y:897,t:1527272300898};\\\", \\\"{x:1501,y:901,t:1527272300914};\\\", \\\"{x:1500,y:904,t:1527272300931};\\\", \\\"{x:1496,y:911,t:1527272300947};\\\", \\\"{x:1494,y:916,t:1527272300963};\\\", \\\"{x:1491,y:921,t:1527272300981};\\\", \\\"{x:1490,y:923,t:1527272300998};\\\", \\\"{x:1488,y:927,t:1527272301014};\\\", \\\"{x:1487,y:929,t:1527272301031};\\\", \\\"{x:1484,y:933,t:1527272301048};\\\", \\\"{x:1484,y:937,t:1527272301065};\\\", \\\"{x:1481,y:943,t:1527272301081};\\\", \\\"{x:1480,y:945,t:1527272301098};\\\", \\\"{x:1479,y:948,t:1527272301114};\\\", \\\"{x:1478,y:949,t:1527272301131};\\\", \\\"{x:1478,y:950,t:1527272301148};\\\", \\\"{x:1477,y:951,t:1527272301173};\\\", \\\"{x:1477,y:952,t:1527272301188};\\\", \\\"{x:1477,y:953,t:1527272301205};\\\", \\\"{x:1472,y:953,t:1527272302781};\\\", \\\"{x:1450,y:947,t:1527272302788};\\\", \\\"{x:1416,y:937,t:1527272302800};\\\", \\\"{x:1289,y:903,t:1527272302816};\\\", \\\"{x:1113,y:853,t:1527272302833};\\\", \\\"{x:903,y:795,t:1527272302849};\\\", \\\"{x:689,y:748,t:1527272302866};\\\", \\\"{x:515,y:701,t:1527272302883};\\\", \\\"{x:393,y:665,t:1527272302901};\\\", \\\"{x:318,y:646,t:1527272302916};\\\", \\\"{x:312,y:645,t:1527272302932};\\\", \\\"{x:313,y:645,t:1527272303044};\\\", \\\"{x:318,y:645,t:1527272303051};\\\", \\\"{x:327,y:645,t:1527272303066};\\\", \\\"{x:352,y:645,t:1527272303083};\\\", \\\"{x:391,y:650,t:1527272303099};\\\", \\\"{x:455,y:677,t:1527272303117};\\\", \\\"{x:486,y:689,t:1527272303133};\\\", \\\"{x:506,y:698,t:1527272303148};\\\", \\\"{x:516,y:704,t:1527272303166};\\\", \\\"{x:524,y:710,t:1527272303183};\\\", \\\"{x:532,y:720,t:1527272303200};\\\", \\\"{x:536,y:726,t:1527272303216};\\\", \\\"{x:541,y:730,t:1527272303233};\\\", \\\"{x:543,y:732,t:1527272303250};\\\", \\\"{x:544,y:732,t:1527272303266};\\\", \\\"{x:544,y:733,t:1527272303340};\\\", \\\"{x:543,y:733,t:1527272303381};\\\", \\\"{x:542,y:735,t:1527272303397};\\\", \\\"{x:538,y:736,t:1527272303405};\\\", \\\"{x:537,y:737,t:1527272303418};\\\", \\\"{x:533,y:739,t:1527272303434};\\\", \\\"{x:532,y:739,t:1527272304109};\\\", \\\"{x:531,y:739,t:1527272304117};\\\", \\\"{x:531,y:737,t:1527272304197};\\\", \\\"{x:531,y:736,t:1527272304204};\\\", \\\"{x:531,y:735,t:1527272304220};\\\", \\\"{x:531,y:734,t:1527272304307};\\\", \\\"{x:532,y:734,t:1527272304484};\\\", \\\"{x:534,y:733,t:1527272304500};\\\", \\\"{x:534,y:732,t:1527272304517};\\\", \\\"{x:535,y:732,t:1527272304540};\\\", \\\"{x:535,y:731,t:1527272304572};\\\", \\\"{x:536,y:731,t:1527272304597};\\\", \\\"{x:537,y:729,t:1527272304617};\\\", \\\"{x:537,y:728,t:1527272304659};\\\", \\\"{x:538,y:727,t:1527272304675};\\\" ] }, { \\\"rt\\\": 48506, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 643568, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"2WQ0M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -X -03 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:539,y:726,t:1527272304836};\\\", \\\"{x:539,y:725,t:1527272305140};\\\", \\\"{x:539,y:724,t:1527272305256};\\\", \\\"{x:540,y:723,t:1527272305565};\\\", \\\"{x:540,y:720,t:1527272305572};\\\", \\\"{x:542,y:716,t:1527272305586};\\\", \\\"{x:546,y:703,t:1527272305601};\\\", \\\"{x:550,y:693,t:1527272305619};\\\", \\\"{x:556,y:678,t:1527272305636};\\\", \\\"{x:562,y:645,t:1527272305652};\\\", \\\"{x:582,y:608,t:1527272305670};\\\", \\\"{x:613,y:574,t:1527272305686};\\\", \\\"{x:661,y:542,t:1527272305703};\\\", \\\"{x:725,y:509,t:1527272305720};\\\", \\\"{x:826,y:471,t:1527272305735};\\\", \\\"{x:940,y:440,t:1527272305751};\\\", \\\"{x:1052,y:418,t:1527272305768};\\\", \\\"{x:1173,y:403,t:1527272305785};\\\", \\\"{x:1274,y:397,t:1527272305801};\\\", \\\"{x:1363,y:395,t:1527272305818};\\\", \\\"{x:1416,y:395,t:1527272305835};\\\", \\\"{x:1442,y:395,t:1527272305851};\\\", \\\"{x:1471,y:395,t:1527272305868};\\\", \\\"{x:1479,y:395,t:1527272305885};\\\", \\\"{x:1484,y:395,t:1527272305902};\\\", \\\"{x:1486,y:395,t:1527272305918};\\\", \\\"{x:1490,y:395,t:1527272305936};\\\", \\\"{x:1497,y:395,t:1527272305951};\\\", \\\"{x:1508,y:395,t:1527272305968};\\\", \\\"{x:1523,y:396,t:1527272305986};\\\", \\\"{x:1536,y:399,t:1527272306002};\\\", \\\"{x:1541,y:401,t:1527272306018};\\\", \\\"{x:1545,y:403,t:1527272306036};\\\", \\\"{x:1550,y:410,t:1527272306053};\\\", \\\"{x:1552,y:419,t:1527272306069};\\\", \\\"{x:1554,y:434,t:1527272306086};\\\", \\\"{x:1555,y:455,t:1527272306103};\\\", \\\"{x:1558,y:473,t:1527272306118};\\\", \\\"{x:1558,y:492,t:1527272306136};\\\", \\\"{x:1558,y:511,t:1527272306153};\\\", \\\"{x:1558,y:528,t:1527272306169};\\\", \\\"{x:1553,y:547,t:1527272306185};\\\", \\\"{x:1545,y:572,t:1527272306203};\\\", \\\"{x:1536,y:591,t:1527272306219};\\\", \\\"{x:1530,y:606,t:1527272306235};\\\", \\\"{x:1525,y:618,t:1527272306253};\\\", \\\"{x:1524,y:622,t:1527272306269};\\\", \\\"{x:1521,y:626,t:1527272306286};\\\", \\\"{x:1521,y:627,t:1527272306357};\\\", \\\"{x:1521,y:628,t:1527272306368};\\\", \\\"{x:1520,y:629,t:1527272306386};\\\", \\\"{x:1520,y:631,t:1527272306403};\\\", \\\"{x:1518,y:633,t:1527272306419};\\\", \\\"{x:1517,y:635,t:1527272306436};\\\", \\\"{x:1516,y:637,t:1527272306452};\\\", \\\"{x:1515,y:638,t:1527272306468};\\\", \\\"{x:1514,y:640,t:1527272306492};\\\", \\\"{x:1513,y:640,t:1527272306508};\\\", \\\"{x:1513,y:642,t:1527272306525};\\\", \\\"{x:1511,y:642,t:1527272306536};\\\", \\\"{x:1511,y:643,t:1527272306553};\\\", \\\"{x:1510,y:643,t:1527272306569};\\\", \\\"{x:1509,y:645,t:1527272306589};\\\", \\\"{x:1508,y:645,t:1527272306612};\\\", \\\"{x:1508,y:646,t:1527272306636};\\\", \\\"{x:1506,y:646,t:1527272306653};\\\", \\\"{x:1505,y:646,t:1527272306685};\\\", \\\"{x:1503,y:646,t:1527272306717};\\\", \\\"{x:1502,y:647,t:1527272306732};\\\", \\\"{x:1501,y:648,t:1527272306741};\\\", \\\"{x:1500,y:648,t:1527272306756};\\\", \\\"{x:1499,y:649,t:1527272306773};\\\", \\\"{x:1497,y:650,t:1527272306785};\\\", \\\"{x:1495,y:651,t:1527272306802};\\\", \\\"{x:1491,y:652,t:1527272306820};\\\", \\\"{x:1486,y:653,t:1527272306835};\\\", \\\"{x:1478,y:656,t:1527272306853};\\\", \\\"{x:1473,y:658,t:1527272306870};\\\", \\\"{x:1466,y:660,t:1527272306886};\\\", \\\"{x:1462,y:663,t:1527272306903};\\\", \\\"{x:1454,y:667,t:1527272306919};\\\", \\\"{x:1448,y:669,t:1527272306935};\\\", \\\"{x:1445,y:671,t:1527272306952};\\\", \\\"{x:1442,y:673,t:1527272306969};\\\", \\\"{x:1438,y:676,t:1527272306985};\\\", \\\"{x:1434,y:679,t:1527272307002};\\\", \\\"{x:1433,y:680,t:1527272307019};\\\", \\\"{x:1428,y:683,t:1527272307035};\\\", \\\"{x:1421,y:690,t:1527272307052};\\\", \\\"{x:1407,y:700,t:1527272307069};\\\", \\\"{x:1383,y:718,t:1527272307085};\\\", \\\"{x:1365,y:737,t:1527272307103};\\\", \\\"{x:1349,y:756,t:1527272307119};\\\", \\\"{x:1341,y:764,t:1527272307135};\\\", \\\"{x:1341,y:765,t:1527272307333};\\\", \\\"{x:1341,y:767,t:1527272307340};\\\", \\\"{x:1342,y:769,t:1527272307353};\\\", \\\"{x:1343,y:775,t:1527272307369};\\\", \\\"{x:1347,y:783,t:1527272307386};\\\", \\\"{x:1353,y:792,t:1527272307403};\\\", \\\"{x:1363,y:805,t:1527272307419};\\\", \\\"{x:1379,y:818,t:1527272307435};\\\", \\\"{x:1409,y:836,t:1527272307452};\\\", \\\"{x:1438,y:851,t:1527272307469};\\\", \\\"{x:1475,y:865,t:1527272307485};\\\", \\\"{x:1513,y:879,t:1527272307502};\\\", \\\"{x:1549,y:894,t:1527272307520};\\\", \\\"{x:1573,y:906,t:1527272307536};\\\", \\\"{x:1595,y:915,t:1527272307552};\\\", \\\"{x:1608,y:921,t:1527272307570};\\\", \\\"{x:1617,y:927,t:1527272307587};\\\", \\\"{x:1627,y:932,t:1527272307603};\\\", \\\"{x:1644,y:937,t:1527272307619};\\\", \\\"{x:1673,y:940,t:1527272307636};\\\", \\\"{x:1674,y:940,t:1527272307652};\\\", \\\"{x:1676,y:940,t:1527272307670};\\\", \\\"{x:1671,y:940,t:1527272307989};\\\", \\\"{x:1663,y:941,t:1527272308003};\\\", \\\"{x:1651,y:943,t:1527272308020};\\\", \\\"{x:1632,y:946,t:1527272308036};\\\", \\\"{x:1627,y:947,t:1527272308053};\\\", \\\"{x:1622,y:948,t:1527272308070};\\\", \\\"{x:1621,y:948,t:1527272308087};\\\", \\\"{x:1620,y:949,t:1527272308165};\\\", \\\"{x:1619,y:949,t:1527272308173};\\\", \\\"{x:1618,y:949,t:1527272308187};\\\", \\\"{x:1612,y:949,t:1527272308203};\\\", \\\"{x:1602,y:951,t:1527272308219};\\\", \\\"{x:1586,y:955,t:1527272308235};\\\", \\\"{x:1574,y:956,t:1527272308252};\\\", \\\"{x:1566,y:956,t:1527272308269};\\\", \\\"{x:1561,y:956,t:1527272308286};\\\", \\\"{x:1557,y:956,t:1527272308302};\\\", \\\"{x:1555,y:956,t:1527272308319};\\\", \\\"{x:1554,y:956,t:1527272308339};\\\", \\\"{x:1552,y:956,t:1527272308353};\\\", \\\"{x:1549,y:956,t:1527272308369};\\\", \\\"{x:1543,y:956,t:1527272308387};\\\", \\\"{x:1536,y:956,t:1527272308403};\\\", \\\"{x:1533,y:956,t:1527272308419};\\\", \\\"{x:1531,y:956,t:1527272308437};\\\", \\\"{x:1532,y:956,t:1527272308637};\\\", \\\"{x:1533,y:956,t:1527272308660};\\\", \\\"{x:1534,y:956,t:1527272308733};\\\", \\\"{x:1535,y:956,t:1527272308764};\\\", \\\"{x:1536,y:956,t:1527272309405};\\\", \\\"{x:1537,y:958,t:1527272309438};\\\", \\\"{x:1538,y:958,t:1527272309454};\\\", \\\"{x:1539,y:959,t:1527272309470};\\\", \\\"{x:1540,y:959,t:1527272309502};\\\", \\\"{x:1541,y:959,t:1527272309518};\\\", \\\"{x:1542,y:959,t:1527272309590};\\\", \\\"{x:1543,y:959,t:1527272309655};\\\", \\\"{x:1544,y:959,t:1527272309678};\\\", \\\"{x:1544,y:958,t:1527272312414};\\\", \\\"{x:1544,y:955,t:1527272312431};\\\", \\\"{x:1544,y:951,t:1527272312447};\\\", \\\"{x:1543,y:947,t:1527272312463};\\\", \\\"{x:1542,y:940,t:1527272312481};\\\", \\\"{x:1541,y:933,t:1527272312497};\\\", \\\"{x:1539,y:924,t:1527272312514};\\\", \\\"{x:1534,y:913,t:1527272312531};\\\", \\\"{x:1529,y:904,t:1527272312547};\\\", \\\"{x:1527,y:899,t:1527272312564};\\\", \\\"{x:1525,y:895,t:1527272312581};\\\", \\\"{x:1524,y:893,t:1527272312598};\\\", \\\"{x:1522,y:889,t:1527272312614};\\\", \\\"{x:1522,y:887,t:1527272312631};\\\", \\\"{x:1522,y:886,t:1527272312648};\\\", \\\"{x:1522,y:885,t:1527272312678};\\\", \\\"{x:1521,y:885,t:1527272312686};\\\", \\\"{x:1521,y:884,t:1527272312698};\\\", \\\"{x:1520,y:884,t:1527272312715};\\\", \\\"{x:1519,y:882,t:1527272312732};\\\", \\\"{x:1518,y:879,t:1527272312749};\\\", \\\"{x:1515,y:876,t:1527272312765};\\\", \\\"{x:1512,y:870,t:1527272312781};\\\", \\\"{x:1506,y:857,t:1527272312798};\\\", \\\"{x:1502,y:850,t:1527272312815};\\\", \\\"{x:1498,y:843,t:1527272312832};\\\", \\\"{x:1495,y:839,t:1527272312849};\\\", \\\"{x:1492,y:834,t:1527272312865};\\\", \\\"{x:1490,y:831,t:1527272312882};\\\", \\\"{x:1490,y:830,t:1527272312910};\\\", \\\"{x:1490,y:829,t:1527272312942};\\\", \\\"{x:1489,y:829,t:1527272313239};\\\", \\\"{x:1486,y:828,t:1527272313251};\\\", \\\"{x:1485,y:828,t:1527272313264};\\\", \\\"{x:1484,y:827,t:1527272313280};\\\", \\\"{x:1483,y:827,t:1527272313694};\\\", \\\"{x:1482,y:827,t:1527272313702};\\\", \\\"{x:1482,y:834,t:1527272317335};\\\", \\\"{x:1485,y:852,t:1527272317351};\\\", \\\"{x:1490,y:869,t:1527272317367};\\\", \\\"{x:1494,y:885,t:1527272317383};\\\", \\\"{x:1498,y:901,t:1527272317400};\\\", \\\"{x:1504,y:915,t:1527272317417};\\\", \\\"{x:1506,y:931,t:1527272317433};\\\", \\\"{x:1508,y:943,t:1527272317449};\\\", \\\"{x:1509,y:955,t:1527272317466};\\\", \\\"{x:1510,y:962,t:1527272317483};\\\", \\\"{x:1510,y:968,t:1527272317499};\\\", \\\"{x:1512,y:974,t:1527272317516};\\\", \\\"{x:1513,y:977,t:1527272317533};\\\", \\\"{x:1513,y:978,t:1527272317630};\\\", \\\"{x:1514,y:978,t:1527272317654};\\\", \\\"{x:1516,y:978,t:1527272317670};\\\", \\\"{x:1516,y:977,t:1527272317684};\\\", \\\"{x:1520,y:975,t:1527272317700};\\\", \\\"{x:1524,y:972,t:1527272317717};\\\", \\\"{x:1530,y:968,t:1527272317734};\\\", \\\"{x:1533,y:966,t:1527272317750};\\\", \\\"{x:1536,y:964,t:1527272317767};\\\", \\\"{x:1538,y:964,t:1527272317784};\\\", \\\"{x:1540,y:964,t:1527272317801};\\\", \\\"{x:1540,y:963,t:1527272317817};\\\", \\\"{x:1541,y:963,t:1527272317833};\\\", \\\"{x:1543,y:962,t:1527272317851};\\\", \\\"{x:1545,y:961,t:1527272317866};\\\", \\\"{x:1546,y:961,t:1527272317883};\\\", \\\"{x:1547,y:960,t:1527272317901};\\\", \\\"{x:1548,y:960,t:1527272317916};\\\", \\\"{x:1550,y:959,t:1527272317934};\\\", \\\"{x:1551,y:959,t:1527272317950};\\\", \\\"{x:1551,y:958,t:1527272317982};\\\", \\\"{x:1551,y:957,t:1527272318038};\\\", \\\"{x:1551,y:956,t:1527272320734};\\\", \\\"{x:1551,y:955,t:1527272320958};\\\", \\\"{x:1551,y:952,t:1527272320969};\\\", \\\"{x:1551,y:947,t:1527272320985};\\\", \\\"{x:1552,y:944,t:1527272321001};\\\", \\\"{x:1552,y:939,t:1527272321019};\\\", \\\"{x:1553,y:933,t:1527272321035};\\\", \\\"{x:1557,y:925,t:1527272321051};\\\", \\\"{x:1561,y:917,t:1527272321069};\\\", \\\"{x:1566,y:909,t:1527272321085};\\\", \\\"{x:1573,y:897,t:1527272321101};\\\", \\\"{x:1576,y:888,t:1527272321118};\\\", \\\"{x:1576,y:880,t:1527272321135};\\\", \\\"{x:1576,y:872,t:1527272321152};\\\", \\\"{x:1577,y:866,t:1527272321169};\\\", \\\"{x:1577,y:859,t:1527272321185};\\\", \\\"{x:1580,y:851,t:1527272321202};\\\", \\\"{x:1580,y:846,t:1527272321218};\\\", \\\"{x:1586,y:829,t:1527272321235};\\\", \\\"{x:1590,y:819,t:1527272321251};\\\", \\\"{x:1593,y:810,t:1527272321269};\\\", \\\"{x:1598,y:801,t:1527272321285};\\\", \\\"{x:1601,y:793,t:1527272321302};\\\", \\\"{x:1603,y:790,t:1527272321319};\\\", \\\"{x:1603,y:787,t:1527272321335};\\\", \\\"{x:1604,y:782,t:1527272321352};\\\", \\\"{x:1606,y:777,t:1527272321369};\\\", \\\"{x:1608,y:776,t:1527272321385};\\\", \\\"{x:1608,y:774,t:1527272321402};\\\", \\\"{x:1609,y:773,t:1527272321419};\\\", \\\"{x:1609,y:780,t:1527272322942};\\\", \\\"{x:1603,y:793,t:1527272322952};\\\", \\\"{x:1589,y:828,t:1527272322969};\\\", \\\"{x:1575,y:878,t:1527272322986};\\\", \\\"{x:1564,y:933,t:1527272323003};\\\", \\\"{x:1553,y:969,t:1527272323019};\\\", \\\"{x:1550,y:986,t:1527272323036};\\\", \\\"{x:1548,y:993,t:1527272323053};\\\", \\\"{x:1547,y:996,t:1527272323069};\\\", \\\"{x:1547,y:995,t:1527272323238};\\\", \\\"{x:1547,y:994,t:1527272323253};\\\", \\\"{x:1547,y:990,t:1527272323269};\\\", \\\"{x:1547,y:982,t:1527272323285};\\\", \\\"{x:1548,y:977,t:1527272323303};\\\", \\\"{x:1548,y:975,t:1527272323319};\\\", \\\"{x:1548,y:974,t:1527272323336};\\\", \\\"{x:1548,y:973,t:1527272323353};\\\", \\\"{x:1548,y:972,t:1527272323373};\\\", \\\"{x:1548,y:971,t:1527272323406};\\\", \\\"{x:1548,y:969,t:1527272323420};\\\", \\\"{x:1548,y:968,t:1527272323436};\\\", \\\"{x:1548,y:965,t:1527272323453};\\\", \\\"{x:1548,y:964,t:1527272323470};\\\", \\\"{x:1548,y:963,t:1527272323487};\\\", \\\"{x:1548,y:962,t:1527272323503};\\\", \\\"{x:1548,y:961,t:1527272323542};\\\", \\\"{x:1547,y:961,t:1527272323630};\\\", \\\"{x:1547,y:960,t:1527272330086};\\\", \\\"{x:1548,y:960,t:1527272336518};\\\", \\\"{x:1548,y:962,t:1527272336526};\\\", \\\"{x:1548,y:963,t:1527272336549};\\\", \\\"{x:1548,y:965,t:1527272336574};\\\", \\\"{x:1548,y:963,t:1527272338670};\\\", \\\"{x:1536,y:962,t:1527272349647};\\\", \\\"{x:1500,y:958,t:1527272349654};\\\", \\\"{x:1435,y:947,t:1527272349664};\\\", \\\"{x:1299,y:926,t:1527272349681};\\\", \\\"{x:1121,y:895,t:1527272349698};\\\", \\\"{x:947,y:865,t:1527272349714};\\\", \\\"{x:782,y:828,t:1527272349731};\\\", \\\"{x:651,y:787,t:1527272349747};\\\", \\\"{x:559,y:754,t:1527272349764};\\\", \\\"{x:499,y:720,t:1527272349781};\\\", \\\"{x:487,y:710,t:1527272349798};\\\", \\\"{x:486,y:702,t:1527272349813};\\\", \\\"{x:486,y:699,t:1527272349822};\\\", \\\"{x:486,y:696,t:1527272349839};\\\", \\\"{x:486,y:692,t:1527272349857};\\\", \\\"{x:486,y:688,t:1527272349872};\\\", \\\"{x:486,y:686,t:1527272349889};\\\", \\\"{x:486,y:685,t:1527272349906};\\\", \\\"{x:487,y:681,t:1527272349922};\\\", \\\"{x:488,y:680,t:1527272349939};\\\", \\\"{x:489,y:676,t:1527272349957};\\\", \\\"{x:490,y:672,t:1527272349973};\\\", \\\"{x:491,y:668,t:1527272349991};\\\", \\\"{x:491,y:662,t:1527272350007};\\\", \\\"{x:491,y:656,t:1527272350015};\\\", \\\"{x:486,y:640,t:1527272350031};\\\", \\\"{x:484,y:628,t:1527272350049};\\\", \\\"{x:481,y:618,t:1527272350064};\\\", \\\"{x:481,y:607,t:1527272350081};\\\", \\\"{x:489,y:593,t:1527272350098};\\\", \\\"{x:499,y:583,t:1527272350115};\\\", \\\"{x:513,y:575,t:1527272350131};\\\", \\\"{x:538,y:566,t:1527272350147};\\\", \\\"{x:574,y:560,t:1527272350167};\\\", \\\"{x:595,y:560,t:1527272350181};\\\", \\\"{x:605,y:560,t:1527272350198};\\\", \\\"{x:610,y:562,t:1527272350214};\\\", \\\"{x:613,y:565,t:1527272350232};\\\", \\\"{x:617,y:571,t:1527272350248};\\\", \\\"{x:617,y:574,t:1527272350264};\\\", \\\"{x:618,y:578,t:1527272350281};\\\", \\\"{x:618,y:580,t:1527272350298};\\\", \\\"{x:618,y:581,t:1527272350314};\\\", \\\"{x:617,y:582,t:1527272350628};\\\", \\\"{x:613,y:588,t:1527272350636};\\\", \\\"{x:604,y:596,t:1527272350648};\\\", \\\"{x:592,y:612,t:1527272350665};\\\", \\\"{x:580,y:624,t:1527272350681};\\\", \\\"{x:566,y:645,t:1527272350698};\\\", \\\"{x:552,y:667,t:1527272350715};\\\", \\\"{x:544,y:678,t:1527272350731};\\\", \\\"{x:535,y:696,t:1527272350749};\\\", \\\"{x:533,y:703,t:1527272350765};\\\", \\\"{x:530,y:711,t:1527272350781};\\\", \\\"{x:529,y:717,t:1527272350798};\\\", \\\"{x:528,y:722,t:1527272350816};\\\", \\\"{x:526,y:727,t:1527272350831};\\\", \\\"{x:526,y:730,t:1527272350848};\\\", \\\"{x:525,y:731,t:1527272350866};\\\", \\\"{x:524,y:733,t:1527272350881};\\\", \\\"{x:523,y:735,t:1527272350898};\\\", \\\"{x:523,y:736,t:1527272350915};\\\", \\\"{x:522,y:737,t:1527272350933};\\\", \\\"{x:521,y:737,t:1527272350948};\\\", \\\"{x:520,y:738,t:1527272350965};\\\" ] }, { \\\"rt\\\": 22754, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 667657, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"2WQ0M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -12 PM-01 PM-02 PM-X -X -D -07 PM-02 PM-X -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:468,y:694,t:1527272354672};\\\", \\\"{x:467,y:693,t:1527272355013};\\\", \\\"{x:475,y:679,t:1527272355266};\\\", \\\"{x:483,y:672,t:1527272355270};\\\", \\\"{x:504,y:657,t:1527272355286};\\\", \\\"{x:526,y:648,t:1527272355302};\\\", \\\"{x:548,y:640,t:1527272355319};\\\", \\\"{x:572,y:637,t:1527272355335};\\\", \\\"{x:601,y:632,t:1527272355353};\\\", \\\"{x:641,y:627,t:1527272355369};\\\", \\\"{x:679,y:624,t:1527272355385};\\\", \\\"{x:720,y:620,t:1527272355402};\\\", \\\"{x:754,y:620,t:1527272355419};\\\", \\\"{x:796,y:620,t:1527272355436};\\\", \\\"{x:838,y:620,t:1527272355452};\\\", \\\"{x:859,y:622,t:1527272355468};\\\", \\\"{x:880,y:624,t:1527272355486};\\\", \\\"{x:896,y:627,t:1527272355502};\\\", \\\"{x:919,y:632,t:1527272355519};\\\", \\\"{x:943,y:636,t:1527272355536};\\\", \\\"{x:968,y:639,t:1527272355553};\\\", \\\"{x:994,y:643,t:1527272355569};\\\", \\\"{x:1016,y:645,t:1527272355585};\\\", \\\"{x:1030,y:648,t:1527272355603};\\\", \\\"{x:1039,y:648,t:1527272355619};\\\", \\\"{x:1041,y:649,t:1527272355635};\\\", \\\"{x:1042,y:650,t:1527272355652};\\\", \\\"{x:1046,y:651,t:1527272355668};\\\", \\\"{x:1059,y:657,t:1527272355685};\\\", \\\"{x:1067,y:659,t:1527272355702};\\\", \\\"{x:1068,y:662,t:1527272355720};\\\", \\\"{x:1068,y:663,t:1527272355736};\\\", \\\"{x:1068,y:664,t:1527272355753};\\\", \\\"{x:1069,y:664,t:1527272355948};\\\", \\\"{x:1070,y:664,t:1527272355964};\\\", \\\"{x:1072,y:664,t:1527272355973};\\\", \\\"{x:1073,y:667,t:1527272355986};\\\", \\\"{x:1079,y:670,t:1527272356003};\\\", \\\"{x:1090,y:676,t:1527272356020};\\\", \\\"{x:1099,y:683,t:1527272356036};\\\", \\\"{x:1121,y:689,t:1527272356053};\\\", \\\"{x:1146,y:695,t:1527272356070};\\\", \\\"{x:1171,y:702,t:1527272356086};\\\", \\\"{x:1202,y:706,t:1527272356103};\\\", \\\"{x:1225,y:712,t:1527272356120};\\\", \\\"{x:1251,y:715,t:1527272356136};\\\", \\\"{x:1274,y:722,t:1527272356154};\\\", \\\"{x:1299,y:726,t:1527272356170};\\\", \\\"{x:1320,y:729,t:1527272356187};\\\", \\\"{x:1345,y:735,t:1527272356203};\\\", \\\"{x:1361,y:736,t:1527272356220};\\\", \\\"{x:1369,y:737,t:1527272356237};\\\", \\\"{x:1370,y:738,t:1527272356261};\\\", \\\"{x:1372,y:738,t:1527272356708};\\\", \\\"{x:1373,y:738,t:1527272356720};\\\", \\\"{x:1381,y:738,t:1527272356737};\\\", \\\"{x:1395,y:738,t:1527272356754};\\\", \\\"{x:1409,y:738,t:1527272356770};\\\", \\\"{x:1425,y:738,t:1527272356787};\\\", \\\"{x:1442,y:738,t:1527272356804};\\\", \\\"{x:1456,y:738,t:1527272356820};\\\", \\\"{x:1463,y:738,t:1527272356837};\\\", \\\"{x:1464,y:738,t:1527272356854};\\\", \\\"{x:1463,y:742,t:1527272358582};\\\", \\\"{x:1457,y:754,t:1527272358589};\\\", \\\"{x:1448,y:775,t:1527272358605};\\\", \\\"{x:1441,y:786,t:1527272358623};\\\", \\\"{x:1436,y:795,t:1527272358639};\\\", \\\"{x:1430,y:806,t:1527272358656};\\\", \\\"{x:1423,y:821,t:1527272358672};\\\", \\\"{x:1414,y:836,t:1527272358688};\\\", \\\"{x:1406,y:853,t:1527272358706};\\\", \\\"{x:1395,y:872,t:1527272358722};\\\", \\\"{x:1384,y:888,t:1527272358739};\\\", \\\"{x:1372,y:906,t:1527272358756};\\\", \\\"{x:1363,y:921,t:1527272358773};\\\", \\\"{x:1354,y:943,t:1527272358789};\\\", \\\"{x:1350,y:951,t:1527272358805};\\\", \\\"{x:1349,y:956,t:1527272358822};\\\", \\\"{x:1348,y:964,t:1527272358840};\\\", \\\"{x:1348,y:967,t:1527272358855};\\\", \\\"{x:1347,y:970,t:1527272358872};\\\", \\\"{x:1347,y:971,t:1527272358889};\\\", \\\"{x:1347,y:972,t:1527272358905};\\\", \\\"{x:1347,y:974,t:1527272358950};\\\", \\\"{x:1349,y:974,t:1527272358965};\\\", \\\"{x:1352,y:974,t:1527272358973};\\\", \\\"{x:1358,y:975,t:1527272358989};\\\", \\\"{x:1365,y:976,t:1527272359005};\\\", \\\"{x:1378,y:976,t:1527272359023};\\\", \\\"{x:1391,y:976,t:1527272359039};\\\", \\\"{x:1405,y:976,t:1527272359055};\\\", \\\"{x:1414,y:976,t:1527272359072};\\\", \\\"{x:1422,y:976,t:1527272359089};\\\", \\\"{x:1429,y:976,t:1527272359106};\\\", \\\"{x:1439,y:976,t:1527272359123};\\\", \\\"{x:1447,y:976,t:1527272359139};\\\", \\\"{x:1452,y:976,t:1527272359156};\\\", \\\"{x:1454,y:976,t:1527272359172};\\\", \\\"{x:1455,y:976,t:1527272359189};\\\", \\\"{x:1459,y:976,t:1527272359205};\\\", \\\"{x:1465,y:976,t:1527272359223};\\\", \\\"{x:1473,y:976,t:1527272359239};\\\", \\\"{x:1479,y:976,t:1527272359256};\\\", \\\"{x:1483,y:976,t:1527272359272};\\\", \\\"{x:1485,y:976,t:1527272359289};\\\", \\\"{x:1485,y:975,t:1527272359358};\\\", \\\"{x:1486,y:974,t:1527272359373};\\\", \\\"{x:1486,y:973,t:1527272359389};\\\", \\\"{x:1488,y:971,t:1527272359406};\\\", \\\"{x:1489,y:970,t:1527272359421};\\\", \\\"{x:1489,y:969,t:1527272359500};\\\", \\\"{x:1489,y:968,t:1527272359532};\\\", \\\"{x:1489,y:967,t:1527272359540};\\\", \\\"{x:1489,y:966,t:1527272359556};\\\", \\\"{x:1489,y:965,t:1527272359571};\\\", \\\"{x:1488,y:964,t:1527272359589};\\\", \\\"{x:1487,y:963,t:1527272359605};\\\", \\\"{x:1486,y:962,t:1527272359621};\\\", \\\"{x:1485,y:961,t:1527272359638};\\\", \\\"{x:1484,y:961,t:1527272359655};\\\", \\\"{x:1483,y:960,t:1527272359700};\\\", \\\"{x:1482,y:960,t:1527272359724};\\\", \\\"{x:1482,y:958,t:1527272359749};\\\", \\\"{x:1482,y:957,t:1527272359814};\\\", \\\"{x:1482,y:956,t:1527272359878};\\\", \\\"{x:1482,y:955,t:1527272359974};\\\", \\\"{x:1481,y:953,t:1527272359989};\\\", \\\"{x:1480,y:951,t:1527272360006};\\\", \\\"{x:1480,y:950,t:1527272360023};\\\", \\\"{x:1480,y:947,t:1527272360039};\\\", \\\"{x:1480,y:944,t:1527272360056};\\\", \\\"{x:1480,y:940,t:1527272360073};\\\", \\\"{x:1480,y:929,t:1527272360089};\\\", \\\"{x:1480,y:917,t:1527272360107};\\\", \\\"{x:1480,y:900,t:1527272360123};\\\", \\\"{x:1480,y:884,t:1527272360140};\\\", \\\"{x:1480,y:872,t:1527272360156};\\\", \\\"{x:1479,y:857,t:1527272360172};\\\", \\\"{x:1478,y:849,t:1527272360190};\\\", \\\"{x:1475,y:838,t:1527272360206};\\\", \\\"{x:1475,y:835,t:1527272360224};\\\", \\\"{x:1475,y:832,t:1527272360240};\\\", \\\"{x:1474,y:829,t:1527272360256};\\\", \\\"{x:1473,y:827,t:1527272360274};\\\", \\\"{x:1473,y:825,t:1527272360291};\\\", \\\"{x:1473,y:823,t:1527272360306};\\\", \\\"{x:1472,y:822,t:1527272360324};\\\", \\\"{x:1472,y:820,t:1527272360341};\\\", \\\"{x:1471,y:819,t:1527272360357};\\\", \\\"{x:1471,y:818,t:1527272360398};\\\", \\\"{x:1471,y:819,t:1527272360605};\\\", \\\"{x:1472,y:819,t:1527272360733};\\\", \\\"{x:1473,y:820,t:1527272360741};\\\", \\\"{x:1474,y:820,t:1527272360789};\\\", \\\"{x:1475,y:820,t:1527272360813};\\\", \\\"{x:1476,y:821,t:1527272360823};\\\", \\\"{x:1477,y:822,t:1527272360840};\\\", \\\"{x:1478,y:823,t:1527272360861};\\\", \\\"{x:1479,y:823,t:1527272360874};\\\", \\\"{x:1481,y:825,t:1527272360896};\\\", \\\"{x:1481,y:826,t:1527272360973};\\\", \\\"{x:1482,y:828,t:1527272360991};\\\", \\\"{x:1482,y:829,t:1527272361037};\\\", \\\"{x:1482,y:830,t:1527272361277};\\\", \\\"{x:1482,y:831,t:1527272363534};\\\", \\\"{x:1471,y:831,t:1527272363543};\\\", \\\"{x:1405,y:827,t:1527272363559};\\\", \\\"{x:1313,y:812,t:1527272363576};\\\", \\\"{x:1214,y:804,t:1527272363592};\\\", \\\"{x:1090,y:787,t:1527272363610};\\\", \\\"{x:965,y:768,t:1527272363627};\\\", \\\"{x:845,y:750,t:1527272363642};\\\", \\\"{x:734,y:732,t:1527272363659};\\\", \\\"{x:635,y:710,t:1527272363676};\\\", \\\"{x:555,y:690,t:1527272363692};\\\", \\\"{x:492,y:674,t:1527272363710};\\\", \\\"{x:471,y:667,t:1527272363726};\\\", \\\"{x:460,y:660,t:1527272363742};\\\", \\\"{x:456,y:656,t:1527272363755};\\\", \\\"{x:451,y:648,t:1527272363772};\\\", \\\"{x:447,y:642,t:1527272363788};\\\", \\\"{x:444,y:633,t:1527272363809};\\\", \\\"{x:438,y:622,t:1527272363826};\\\", \\\"{x:434,y:612,t:1527272363844};\\\", \\\"{x:433,y:607,t:1527272363860};\\\", \\\"{x:433,y:603,t:1527272363876};\\\", \\\"{x:433,y:600,t:1527272363892};\\\", \\\"{x:432,y:600,t:1527272364013};\\\", \\\"{x:431,y:600,t:1527272364036};\\\", \\\"{x:430,y:600,t:1527272364045};\\\", \\\"{x:428,y:599,t:1527272364060};\\\", \\\"{x:426,y:599,t:1527272364076};\\\", \\\"{x:411,y:596,t:1527272364093};\\\", \\\"{x:402,y:595,t:1527272364110};\\\", \\\"{x:397,y:594,t:1527272364126};\\\", \\\"{x:393,y:593,t:1527272364144};\\\", \\\"{x:392,y:592,t:1527272364159};\\\", \\\"{x:393,y:592,t:1527272364293};\\\", \\\"{x:406,y:592,t:1527272364309};\\\", \\\"{x:424,y:591,t:1527272364327};\\\", \\\"{x:447,y:591,t:1527272364343};\\\", \\\"{x:474,y:591,t:1527272364360};\\\", \\\"{x:501,y:591,t:1527272364377};\\\", \\\"{x:528,y:591,t:1527272364393};\\\", \\\"{x:553,y:591,t:1527272364410};\\\", \\\"{x:574,y:591,t:1527272364426};\\\", \\\"{x:595,y:591,t:1527272364443};\\\", \\\"{x:609,y:591,t:1527272364460};\\\", \\\"{x:613,y:591,t:1527272364476};\\\", \\\"{x:614,y:591,t:1527272364492};\\\", \\\"{x:616,y:591,t:1527272364740};\\\", \\\"{x:611,y:591,t:1527272364748};\\\", \\\"{x:582,y:591,t:1527272364760};\\\", \\\"{x:504,y:589,t:1527272364776};\\\", \\\"{x:453,y:589,t:1527272364793};\\\", \\\"{x:424,y:583,t:1527272364809};\\\", \\\"{x:406,y:581,t:1527272364827};\\\", \\\"{x:399,y:581,t:1527272364842};\\\", \\\"{x:394,y:580,t:1527272364860};\\\", \\\"{x:391,y:580,t:1527272364876};\\\", \\\"{x:387,y:580,t:1527272364892};\\\", \\\"{x:385,y:580,t:1527272364910};\\\", \\\"{x:384,y:580,t:1527272364926};\\\", \\\"{x:383,y:580,t:1527272364943};\\\", \\\"{x:382,y:580,t:1527272364960};\\\", \\\"{x:386,y:580,t:1527272365276};\\\", \\\"{x:391,y:580,t:1527272365284};\\\", \\\"{x:400,y:581,t:1527272365294};\\\", \\\"{x:414,y:582,t:1527272365310};\\\", \\\"{x:439,y:582,t:1527272365327};\\\", \\\"{x:494,y:582,t:1527272365343};\\\", \\\"{x:569,y:582,t:1527272365360};\\\", \\\"{x:656,y:584,t:1527272365377};\\\", \\\"{x:758,y:584,t:1527272365396};\\\", \\\"{x:859,y:581,t:1527272365410};\\\", \\\"{x:945,y:558,t:1527272365427};\\\", \\\"{x:1068,y:500,t:1527272365444};\\\", \\\"{x:1138,y:463,t:1527272365460};\\\", \\\"{x:1182,y:438,t:1527272365476};\\\", \\\"{x:1217,y:410,t:1527272365494};\\\", \\\"{x:1250,y:382,t:1527272365510};\\\", \\\"{x:1272,y:366,t:1527272365527};\\\", \\\"{x:1291,y:353,t:1527272365544};\\\", \\\"{x:1307,y:345,t:1527272365561};\\\", \\\"{x:1319,y:339,t:1527272365577};\\\", \\\"{x:1324,y:338,t:1527272365594};\\\", \\\"{x:1328,y:337,t:1527272365611};\\\", \\\"{x:1331,y:337,t:1527272365627};\\\", \\\"{x:1332,y:337,t:1527272365644};\\\", \\\"{x:1334,y:337,t:1527272365741};\\\", \\\"{x:1335,y:337,t:1527272365748};\\\", \\\"{x:1337,y:337,t:1527272365761};\\\", \\\"{x:1344,y:335,t:1527272365777};\\\", \\\"{x:1351,y:335,t:1527272365794};\\\", \\\"{x:1364,y:333,t:1527272365811};\\\", \\\"{x:1377,y:331,t:1527272365827};\\\", \\\"{x:1401,y:328,t:1527272365844};\\\", \\\"{x:1421,y:325,t:1527272365861};\\\", \\\"{x:1439,y:324,t:1527272365877};\\\", \\\"{x:1452,y:324,t:1527272365894};\\\", \\\"{x:1460,y:324,t:1527272365911};\\\", \\\"{x:1464,y:324,t:1527272365927};\\\", \\\"{x:1465,y:324,t:1527272365997};\\\", \\\"{x:1467,y:322,t:1527272366158};\\\", \\\"{x:1468,y:320,t:1527272366166};\\\", \\\"{x:1469,y:320,t:1527272366178};\\\", \\\"{x:1471,y:317,t:1527272366194};\\\", \\\"{x:1474,y:313,t:1527272366212};\\\", \\\"{x:1477,y:311,t:1527272366228};\\\", \\\"{x:1480,y:308,t:1527272366245};\\\", \\\"{x:1482,y:307,t:1527272366261};\\\", \\\"{x:1484,y:308,t:1527272368637};\\\", \\\"{x:1486,y:310,t:1527272368653};\\\", \\\"{x:1487,y:312,t:1527272368663};\\\", \\\"{x:1489,y:314,t:1527272368679};\\\", \\\"{x:1489,y:315,t:1527272368696};\\\", \\\"{x:1490,y:316,t:1527272368846};\\\", \\\"{x:1491,y:316,t:1527272368869};\\\", \\\"{x:1492,y:316,t:1527272368885};\\\", \\\"{x:1493,y:317,t:1527272368896};\\\", \\\"{x:1494,y:319,t:1527272368913};\\\", \\\"{x:1495,y:320,t:1527272368929};\\\", \\\"{x:1496,y:322,t:1527272368946};\\\", \\\"{x:1498,y:324,t:1527272368963};\\\", \\\"{x:1499,y:327,t:1527272368979};\\\", \\\"{x:1502,y:331,t:1527272368995};\\\", \\\"{x:1506,y:337,t:1527272369012};\\\", \\\"{x:1508,y:341,t:1527272369028};\\\", \\\"{x:1512,y:348,t:1527272369045};\\\", \\\"{x:1514,y:350,t:1527272369062};\\\", \\\"{x:1516,y:355,t:1527272369078};\\\", \\\"{x:1518,y:359,t:1527272369095};\\\", \\\"{x:1521,y:366,t:1527272369112};\\\", \\\"{x:1524,y:370,t:1527272369128};\\\", \\\"{x:1529,y:378,t:1527272369145};\\\", \\\"{x:1532,y:386,t:1527272369162};\\\", \\\"{x:1535,y:393,t:1527272369179};\\\", \\\"{x:1538,y:401,t:1527272369196};\\\", \\\"{x:1544,y:414,t:1527272369213};\\\", \\\"{x:1547,y:424,t:1527272369228};\\\", \\\"{x:1551,y:434,t:1527272369245};\\\", \\\"{x:1553,y:448,t:1527272369262};\\\", \\\"{x:1558,y:465,t:1527272369278};\\\", \\\"{x:1562,y:485,t:1527272369296};\\\", \\\"{x:1569,y:503,t:1527272369313};\\\", \\\"{x:1577,y:523,t:1527272369330};\\\", \\\"{x:1584,y:542,t:1527272369345};\\\", \\\"{x:1596,y:563,t:1527272369362};\\\", \\\"{x:1608,y:586,t:1527272369380};\\\", \\\"{x:1621,y:610,t:1527272369395};\\\", \\\"{x:1642,y:642,t:1527272369412};\\\", \\\"{x:1657,y:669,t:1527272369428};\\\", \\\"{x:1679,y:714,t:1527272369455};\\\", \\\"{x:1708,y:756,t:1527272369473};\\\", \\\"{x:1731,y:797,t:1527272369490};\\\", \\\"{x:1749,y:827,t:1527272369505};\\\", \\\"{x:1762,y:849,t:1527272369523};\\\", \\\"{x:1770,y:867,t:1527272369539};\\\", \\\"{x:1778,y:882,t:1527272369555};\\\", \\\"{x:1787,y:899,t:1527272369572};\\\", \\\"{x:1794,y:916,t:1527272369589};\\\", \\\"{x:1799,y:927,t:1527272369605};\\\", \\\"{x:1805,y:942,t:1527272369623};\\\", \\\"{x:1807,y:950,t:1527272369638};\\\", \\\"{x:1809,y:957,t:1527272369656};\\\", \\\"{x:1813,y:966,t:1527272369673};\\\", \\\"{x:1816,y:971,t:1527272369690};\\\", \\\"{x:1816,y:976,t:1527272369705};\\\", \\\"{x:1817,y:978,t:1527272369723};\\\", \\\"{x:1817,y:979,t:1527272369739};\\\", \\\"{x:1817,y:981,t:1527272369756};\\\", \\\"{x:1819,y:982,t:1527272369773};\\\", \\\"{x:1818,y:981,t:1527272369999};\\\", \\\"{x:1816,y:981,t:1527272370007};\\\", \\\"{x:1807,y:976,t:1527272370022};\\\", \\\"{x:1792,y:972,t:1527272370039};\\\", \\\"{x:1767,y:968,t:1527272370055};\\\", \\\"{x:1731,y:965,t:1527272370072};\\\", \\\"{x:1678,y:964,t:1527272370089};\\\", \\\"{x:1605,y:964,t:1527272370105};\\\", \\\"{x:1519,y:964,t:1527272370122};\\\", \\\"{x:1458,y:964,t:1527272370139};\\\", \\\"{x:1422,y:964,t:1527272370155};\\\", \\\"{x:1399,y:961,t:1527272370173};\\\", \\\"{x:1381,y:961,t:1527272370189};\\\", \\\"{x:1366,y:961,t:1527272370205};\\\", \\\"{x:1339,y:961,t:1527272370223};\\\", \\\"{x:1321,y:961,t:1527272370239};\\\", \\\"{x:1300,y:961,t:1527272370256};\\\", \\\"{x:1277,y:961,t:1527272370273};\\\", \\\"{x:1247,y:961,t:1527272370289};\\\", \\\"{x:1218,y:961,t:1527272370306};\\\", \\\"{x:1193,y:961,t:1527272370322};\\\", \\\"{x:1177,y:961,t:1527272370339};\\\", \\\"{x:1166,y:961,t:1527272370356};\\\", \\\"{x:1160,y:961,t:1527272370373};\\\", \\\"{x:1154,y:961,t:1527272370389};\\\", \\\"{x:1147,y:961,t:1527272370406};\\\", \\\"{x:1146,y:961,t:1527272370422};\\\", \\\"{x:1145,y:961,t:1527272370439};\\\", \\\"{x:1147,y:961,t:1527272371496};\\\", \\\"{x:1153,y:961,t:1527272371507};\\\", \\\"{x:1175,y:961,t:1527272371524};\\\", \\\"{x:1201,y:961,t:1527272371540};\\\", \\\"{x:1228,y:961,t:1527272371557};\\\", \\\"{x:1258,y:961,t:1527272371574};\\\", \\\"{x:1290,y:961,t:1527272371589};\\\", \\\"{x:1335,y:961,t:1527272371606};\\\", \\\"{x:1363,y:961,t:1527272371623};\\\", \\\"{x:1384,y:961,t:1527272371639};\\\", \\\"{x:1398,y:961,t:1527272371657};\\\", \\\"{x:1407,y:961,t:1527272371673};\\\", \\\"{x:1410,y:961,t:1527272371690};\\\", \\\"{x:1413,y:961,t:1527272371707};\\\", \\\"{x:1415,y:962,t:1527272371724};\\\", \\\"{x:1416,y:962,t:1527272371740};\\\", \\\"{x:1418,y:962,t:1527272371756};\\\", \\\"{x:1420,y:962,t:1527272371774};\\\", \\\"{x:1427,y:964,t:1527272371790};\\\", \\\"{x:1440,y:966,t:1527272371807};\\\", \\\"{x:1450,y:967,t:1527272371823};\\\", \\\"{x:1461,y:969,t:1527272371839};\\\", \\\"{x:1468,y:969,t:1527272371857};\\\", \\\"{x:1474,y:969,t:1527272371874};\\\", \\\"{x:1477,y:969,t:1527272371889};\\\", \\\"{x:1481,y:968,t:1527272371908};\\\", \\\"{x:1489,y:967,t:1527272371924};\\\", \\\"{x:1495,y:966,t:1527272371940};\\\", \\\"{x:1501,y:965,t:1527272371957};\\\", \\\"{x:1503,y:965,t:1527272371974};\\\", \\\"{x:1505,y:965,t:1527272371991};\\\", \\\"{x:1505,y:963,t:1527272372104};\\\", \\\"{x:1503,y:961,t:1527272372123};\\\", \\\"{x:1501,y:960,t:1527272372139};\\\", \\\"{x:1499,y:959,t:1527272372156};\\\", \\\"{x:1498,y:959,t:1527272372198};\\\", \\\"{x:1498,y:958,t:1527272372206};\\\", \\\"{x:1498,y:957,t:1527272372238};\\\", \\\"{x:1497,y:953,t:1527272372247};\\\", \\\"{x:1495,y:949,t:1527272372256};\\\", \\\"{x:1494,y:943,t:1527272372273};\\\", \\\"{x:1493,y:930,t:1527272372289};\\\", \\\"{x:1492,y:913,t:1527272372307};\\\", \\\"{x:1490,y:888,t:1527272372324};\\\", \\\"{x:1490,y:846,t:1527272372339};\\\", \\\"{x:1489,y:806,t:1527272372356};\\\", \\\"{x:1487,y:787,t:1527272372373};\\\", \\\"{x:1484,y:769,t:1527272372390};\\\", \\\"{x:1483,y:766,t:1527272372406};\\\", \\\"{x:1482,y:766,t:1527272372558};\\\", \\\"{x:1482,y:770,t:1527272372573};\\\", \\\"{x:1480,y:783,t:1527272372590};\\\", \\\"{x:1479,y:793,t:1527272372606};\\\", \\\"{x:1477,y:802,t:1527272372624};\\\", \\\"{x:1476,y:805,t:1527272372640};\\\", \\\"{x:1476,y:807,t:1527272372657};\\\", \\\"{x:1476,y:810,t:1527272372674};\\\", \\\"{x:1476,y:811,t:1527272372691};\\\", \\\"{x:1476,y:812,t:1527272372706};\\\", \\\"{x:1476,y:813,t:1527272372724};\\\", \\\"{x:1476,y:815,t:1527272372759};\\\", \\\"{x:1476,y:816,t:1527272372847};\\\", \\\"{x:1476,y:817,t:1527272372871};\\\", \\\"{x:1476,y:818,t:1527272372878};\\\", \\\"{x:1477,y:820,t:1527272372895};\\\", \\\"{x:1477,y:821,t:1527272372911};\\\", \\\"{x:1477,y:822,t:1527272372927};\\\", \\\"{x:1478,y:823,t:1527272372940};\\\", \\\"{x:1478,y:824,t:1527272372958};\\\", \\\"{x:1479,y:825,t:1527272372974};\\\", \\\"{x:1479,y:824,t:1527272373528};\\\", \\\"{x:1479,y:823,t:1527272373541};\\\", \\\"{x:1479,y:819,t:1527272373557};\\\", \\\"{x:1479,y:810,t:1527272373575};\\\", \\\"{x:1479,y:799,t:1527272373590};\\\", \\\"{x:1479,y:793,t:1527272373607};\\\", \\\"{x:1479,y:786,t:1527272373624};\\\", \\\"{x:1479,y:779,t:1527272373641};\\\", \\\"{x:1479,y:771,t:1527272373658};\\\", \\\"{x:1479,y:761,t:1527272373673};\\\", \\\"{x:1478,y:748,t:1527272373690};\\\", \\\"{x:1478,y:738,t:1527272373707};\\\", \\\"{x:1478,y:731,t:1527272373723};\\\", \\\"{x:1477,y:723,t:1527272373740};\\\", \\\"{x:1477,y:718,t:1527272373757};\\\", \\\"{x:1476,y:714,t:1527272373773};\\\", \\\"{x:1476,y:709,t:1527272373790};\\\", \\\"{x:1476,y:707,t:1527272373807};\\\", \\\"{x:1476,y:705,t:1527272373824};\\\", \\\"{x:1476,y:703,t:1527272373840};\\\", \\\"{x:1476,y:701,t:1527272373857};\\\", \\\"{x:1476,y:699,t:1527272373873};\\\", \\\"{x:1476,y:698,t:1527272373891};\\\", \\\"{x:1476,y:696,t:1527272373911};\\\", \\\"{x:1476,y:695,t:1527272373927};\\\", \\\"{x:1476,y:693,t:1527272373943};\\\", \\\"{x:1476,y:691,t:1527272373958};\\\", \\\"{x:1476,y:688,t:1527272373974};\\\", \\\"{x:1478,y:682,t:1527272373991};\\\", \\\"{x:1481,y:677,t:1527272374008};\\\", \\\"{x:1482,y:674,t:1527272374024};\\\", \\\"{x:1483,y:670,t:1527272374041};\\\", \\\"{x:1483,y:666,t:1527272374058};\\\", \\\"{x:1485,y:660,t:1527272374074};\\\", \\\"{x:1486,y:654,t:1527272374091};\\\", \\\"{x:1486,y:649,t:1527272374108};\\\", \\\"{x:1487,y:645,t:1527272374124};\\\", \\\"{x:1488,y:643,t:1527272374141};\\\", \\\"{x:1488,y:640,t:1527272374158};\\\", \\\"{x:1488,y:637,t:1527272374175};\\\", \\\"{x:1490,y:625,t:1527272374191};\\\", \\\"{x:1490,y:618,t:1527272374208};\\\", \\\"{x:1491,y:609,t:1527272374224};\\\", \\\"{x:1491,y:603,t:1527272374241};\\\", \\\"{x:1491,y:596,t:1527272374258};\\\", \\\"{x:1491,y:587,t:1527272374273};\\\", \\\"{x:1491,y:580,t:1527272374291};\\\", \\\"{x:1491,y:570,t:1527272374308};\\\", \\\"{x:1491,y:562,t:1527272374324};\\\", \\\"{x:1491,y:554,t:1527272374341};\\\", \\\"{x:1490,y:546,t:1527272374358};\\\", \\\"{x:1490,y:538,t:1527272374375};\\\", \\\"{x:1488,y:532,t:1527272374391};\\\", \\\"{x:1486,y:526,t:1527272374407};\\\", \\\"{x:1486,y:523,t:1527272374425};\\\", \\\"{x:1486,y:519,t:1527272374441};\\\", \\\"{x:1485,y:515,t:1527272374458};\\\", \\\"{x:1485,y:510,t:1527272374474};\\\", \\\"{x:1485,y:503,t:1527272374491};\\\", \\\"{x:1485,y:498,t:1527272374508};\\\", \\\"{x:1485,y:492,t:1527272374524};\\\", \\\"{x:1485,y:486,t:1527272374541};\\\", \\\"{x:1485,y:480,t:1527272374558};\\\", \\\"{x:1485,y:474,t:1527272374574};\\\", \\\"{x:1485,y:468,t:1527272374591};\\\", \\\"{x:1485,y:462,t:1527272374608};\\\", \\\"{x:1485,y:457,t:1527272374625};\\\", \\\"{x:1485,y:452,t:1527272374641};\\\", \\\"{x:1485,y:449,t:1527272374658};\\\", \\\"{x:1485,y:446,t:1527272374675};\\\", \\\"{x:1485,y:444,t:1527272374691};\\\", \\\"{x:1485,y:441,t:1527272374708};\\\", \\\"{x:1485,y:438,t:1527272374725};\\\", \\\"{x:1485,y:437,t:1527272374741};\\\", \\\"{x:1485,y:434,t:1527272374758};\\\", \\\"{x:1485,y:429,t:1527272374775};\\\", \\\"{x:1485,y:427,t:1527272374791};\\\", \\\"{x:1485,y:422,t:1527272374808};\\\", \\\"{x:1485,y:417,t:1527272374825};\\\", \\\"{x:1485,y:412,t:1527272374841};\\\", \\\"{x:1485,y:407,t:1527272374858};\\\", \\\"{x:1485,y:405,t:1527272374874};\\\", \\\"{x:1485,y:402,t:1527272374891};\\\", \\\"{x:1485,y:401,t:1527272374908};\\\", \\\"{x:1485,y:400,t:1527272374943};\\\", \\\"{x:1484,y:400,t:1527272375272};\\\", \\\"{x:1484,y:402,t:1527272375279};\\\", \\\"{x:1483,y:408,t:1527272375292};\\\", \\\"{x:1483,y:415,t:1527272375308};\\\", \\\"{x:1480,y:432,t:1527272375326};\\\", \\\"{x:1477,y:453,t:1527272375342};\\\", \\\"{x:1475,y:480,t:1527272375357};\\\", \\\"{x:1469,y:523,t:1527272375375};\\\", \\\"{x:1469,y:552,t:1527272375392};\\\", \\\"{x:1466,y:578,t:1527272375408};\\\", \\\"{x:1463,y:602,t:1527272375425};\\\", \\\"{x:1463,y:624,t:1527272375442};\\\", \\\"{x:1462,y:646,t:1527272375458};\\\", \\\"{x:1462,y:665,t:1527272375475};\\\", \\\"{x:1459,y:683,t:1527272375492};\\\", \\\"{x:1457,y:697,t:1527272375508};\\\", \\\"{x:1455,y:707,t:1527272375525};\\\", \\\"{x:1454,y:714,t:1527272375542};\\\", \\\"{x:1451,y:719,t:1527272375558};\\\", \\\"{x:1446,y:727,t:1527272375575};\\\", \\\"{x:1438,y:733,t:1527272375592};\\\", \\\"{x:1421,y:737,t:1527272375608};\\\", \\\"{x:1399,y:741,t:1527272375625};\\\", \\\"{x:1364,y:745,t:1527272375642};\\\", \\\"{x:1305,y:745,t:1527272375658};\\\", \\\"{x:1213,y:744,t:1527272375675};\\\", \\\"{x:1105,y:728,t:1527272375691};\\\", \\\"{x:985,y:710,t:1527272375708};\\\", \\\"{x:861,y:693,t:1527272375725};\\\", \\\"{x:744,y:677,t:1527272375742};\\\", \\\"{x:642,y:663,t:1527272375758};\\\", \\\"{x:507,y:644,t:1527272375776};\\\", \\\"{x:443,y:634,t:1527272375792};\\\", \\\"{x:399,y:631,t:1527272375807};\\\", \\\"{x:371,y:631,t:1527272375829};\\\", \\\"{x:348,y:631,t:1527272375846};\\\", \\\"{x:339,y:632,t:1527272375862};\\\", \\\"{x:331,y:636,t:1527272375880};\\\", \\\"{x:319,y:644,t:1527272375895};\\\", \\\"{x:306,y:655,t:1527272375912};\\\", \\\"{x:297,y:664,t:1527272375930};\\\", \\\"{x:286,y:675,t:1527272375946};\\\", \\\"{x:275,y:684,t:1527272375963};\\\", \\\"{x:269,y:690,t:1527272375979};\\\", \\\"{x:266,y:696,t:1527272375997};\\\", \\\"{x:264,y:698,t:1527272376013};\\\", \\\"{x:264,y:699,t:1527272376054};\\\", \\\"{x:264,y:702,t:1527272376062};\\\", \\\"{x:265,y:707,t:1527272376079};\\\", \\\"{x:270,y:715,t:1527272376096};\\\", \\\"{x:279,y:725,t:1527272376113};\\\", \\\"{x:290,y:736,t:1527272376130};\\\", \\\"{x:310,y:749,t:1527272376146};\\\", \\\"{x:330,y:760,t:1527272376163};\\\", \\\"{x:353,y:772,t:1527272376179};\\\", \\\"{x:378,y:781,t:1527272376197};\\\", \\\"{x:399,y:788,t:1527272376213};\\\", \\\"{x:418,y:794,t:1527272376230};\\\", \\\"{x:446,y:805,t:1527272376247};\\\", \\\"{x:456,y:810,t:1527272376262};\\\", \\\"{x:464,y:810,t:1527272376280};\\\", \\\"{x:468,y:810,t:1527272376297};\\\", \\\"{x:473,y:810,t:1527272376313};\\\", \\\"{x:474,y:809,t:1527272376330};\\\", \\\"{x:475,y:805,t:1527272376347};\\\", \\\"{x:478,y:801,t:1527272376364};\\\", \\\"{x:481,y:798,t:1527272376379};\\\", \\\"{x:483,y:796,t:1527272376397};\\\", \\\"{x:484,y:793,t:1527272376414};\\\", \\\"{x:485,y:792,t:1527272376430};\\\", \\\"{x:486,y:791,t:1527272376446};\\\", \\\"{x:488,y:787,t:1527272376464};\\\", \\\"{x:489,y:786,t:1527272376480};\\\", \\\"{x:491,y:784,t:1527272376497};\\\", \\\"{x:492,y:783,t:1527272376514};\\\", \\\"{x:492,y:781,t:1527272376530};\\\", \\\"{x:493,y:781,t:1527272376547};\\\", \\\"{x:493,y:779,t:1527272376564};\\\", \\\"{x:494,y:778,t:1527272376599};\\\", \\\"{x:495,y:776,t:1527272376622};\\\", \\\"{x:495,y:775,t:1527272376639};\\\", \\\"{x:495,y:773,t:1527272376703};\\\", \\\"{x:495,y:772,t:1527272376719};\\\", \\\"{x:495,y:770,t:1527272376735};\\\", \\\"{x:495,y:769,t:1527272376747};\\\", \\\"{x:497,y:767,t:1527272376765};\\\", \\\"{x:499,y:764,t:1527272376781};\\\", \\\"{x:502,y:762,t:1527272376796};\\\", \\\"{x:503,y:761,t:1527272376821};\\\", \\\"{x:504,y:761,t:1527272376837};\\\", \\\"{x:505,y:760,t:1527272376845};\\\", \\\"{x:507,y:759,t:1527272376863};\\\", \\\"{x:508,y:758,t:1527272376879};\\\", \\\"{x:511,y:758,t:1527272376897};\\\", \\\"{x:512,y:757,t:1527272376913};\\\", \\\"{x:513,y:756,t:1527272376930};\\\", \\\"{x:514,y:756,t:1527272377015};\\\" ] }, { \\\"rt\\\": 62464, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 731399, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"2WQ0M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Follow the line going diagonally up/right from the 12pm. Any point that passes through this line is an event that begins at 12pm.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 7739, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 740145, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"2WQ0M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 21875, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 763040, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"2WQ0M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 34044, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 798409, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"2WQ0M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"2WQ0M\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 345, dom: 890, initialDom: 966",
  "javascriptErrors": []
}