var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05220270e3e6dd3803b80613a31af9f2db6b0e97"] = {
  "startTime": "2018-05-22T22:21:02.4505905Z",
  "websitePageUrl": "/16",
  "visitTime": 61642,
  "engagementTime": 58248,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "3f38c7b3013410cbbf3b0aec0ae3e328",
    "created": "2018-05-22T22:21:02.4505905+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=C30CF",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "51738380260706dd61d1369185bd997e",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/3f38c7b3013410cbbf3b0aec0ae3e328/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 224,
      "e": 224,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 301,
      "e": 301,
      "ty": 2,
      "x": 494,
      "y": 756
    },
    {
      "t": 401,
      "e": 401,
      "ty": 2,
      "x": 496,
      "y": 757
    },
    {
      "t": 501,
      "e": 501,
      "ty": 2,
      "x": 496,
      "y": 758
    },
    {
      "t": 502,
      "e": 502,
      "ty": 41,
      "x": 44841,
      "y": 41547,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 902,
      "e": 902,
      "ty": 2,
      "x": 496,
      "y": 757
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 507,
      "y": 649
    },
    {
      "t": 1002,
      "e": 1002,
      "ty": 41,
      "x": 46077,
      "y": 35509,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1102,
      "e": 1102,
      "ty": 2,
      "x": 512,
      "y": 614
    },
    {
      "t": 1122,
      "e": 1122,
      "ty": 6,
      "x": 514,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 517,
      "y": 592
    },
    {
      "t": 1252,
      "e": 1252,
      "ty": 41,
      "x": 47201,
      "y": 53613,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1302,
      "e": 1302,
      "ty": 2,
      "x": 521,
      "y": 573
    },
    {
      "t": 1394,
      "e": 1394,
      "ty": 3,
      "x": 530,
      "y": 557,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1395,
      "e": 1395,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 530,
      "y": 557
    },
    {
      "t": 1448,
      "e": 1448,
      "ty": 4,
      "x": 48662,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1448,
      "e": 1448,
      "ty": 5,
      "x": 530,
      "y": 557,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 41,
      "x": 48662,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 528,
      "y": 567
    },
    {
      "t": 1889,
      "e": 1889,
      "ty": 7,
      "x": 523,
      "y": 604,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1901,
      "e": 1901,
      "ty": 2,
      "x": 523,
      "y": 604
    },
    {
      "t": 2002,
      "e": 2002,
      "ty": 2,
      "x": 556,
      "y": 695
    },
    {
      "t": 2002,
      "e": 2002,
      "ty": 41,
      "x": 51585,
      "y": 38057,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2102,
      "e": 2102,
      "ty": 2,
      "x": 581,
      "y": 733
    },
    {
      "t": 2202,
      "e": 2202,
      "ty": 2,
      "x": 585,
      "y": 739
    },
    {
      "t": 2252,
      "e": 2252,
      "ty": 41,
      "x": 54845,
      "y": 40550,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2302,
      "e": 2302,
      "ty": 2,
      "x": 585,
      "y": 741
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 54845,
      "y": 40606,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 3701,
      "e": 3701,
      "ty": 2,
      "x": 610,
      "y": 785
    },
    {
      "t": 3752,
      "e": 3752,
      "ty": 41,
      "x": 855,
      "y": 49701,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 3802,
      "e": 3802,
      "ty": 2,
      "x": 800,
      "y": 883
    },
    {
      "t": 3901,
      "e": 3901,
      "ty": 2,
      "x": 901,
      "y": 936
    },
    {
      "t": 4002,
      "e": 4002,
      "ty": 2,
      "x": 1010,
      "y": 973
    },
    {
      "t": 4002,
      "e": 4002,
      "ty": 41,
      "x": 16849,
      "y": 16639,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[5] > text"
    },
    {
      "t": 4101,
      "e": 4101,
      "ty": 2,
      "x": 1095,
      "y": 984
    },
    {
      "t": 4202,
      "e": 4202,
      "ty": 2,
      "x": 1149,
      "y": 984
    },
    {
      "t": 4252,
      "e": 4252,
      "ty": 41,
      "x": 58430,
      "y": 53503,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 4302,
      "e": 4302,
      "ty": 2,
      "x": 1176,
      "y": 978
    },
    {
      "t": 4502,
      "e": 4502,
      "ty": 2,
      "x": 1175,
      "y": 976
    },
    {
      "t": 4503,
      "e": 4503,
      "ty": 41,
      "x": 27413,
      "y": 60020,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4602,
      "e": 4602,
      "ty": 2,
      "x": 1166,
      "y": 973
    },
    {
      "t": 4701,
      "e": 4701,
      "ty": 2,
      "x": 1159,
      "y": 968
    },
    {
      "t": 4752,
      "e": 4752,
      "ty": 41,
      "x": 26074,
      "y": 58730,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4802,
      "e": 4802,
      "ty": 2,
      "x": 1146,
      "y": 924
    },
    {
      "t": 4901,
      "e": 4901,
      "ty": 2,
      "x": 1118,
      "y": 835
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 2,
      "x": 1118,
      "y": 745
    },
    {
      "t": 5002,
      "e": 5002,
      "ty": 41,
      "x": 23396,
      "y": 43475,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5102,
      "e": 5102,
      "ty": 2,
      "x": 1138,
      "y": 699
    },
    {
      "t": 5202,
      "e": 5202,
      "ty": 2,
      "x": 1142,
      "y": 696
    },
    {
      "t": 5252,
      "e": 5252,
      "ty": 41,
      "x": 26215,
      "y": 40252,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5302,
      "e": 5302,
      "ty": 2,
      "x": 1191,
      "y": 711
    },
    {
      "t": 5402,
      "e": 5402,
      "ty": 2,
      "x": 1215,
      "y": 722
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 2,
      "x": 1226,
      "y": 724
    },
    {
      "t": 5502,
      "e": 5502,
      "ty": 41,
      "x": 31006,
      "y": 41971,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5602,
      "e": 5602,
      "ty": 2,
      "x": 1227,
      "y": 725
    },
    {
      "t": 5702,
      "e": 5702,
      "ty": 2,
      "x": 1228,
      "y": 725
    },
    {
      "t": 5752,
      "e": 5752,
      "ty": 41,
      "x": 31429,
      "y": 42185,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5802,
      "e": 5802,
      "ty": 2,
      "x": 1266,
      "y": 746
    },
    {
      "t": 5902,
      "e": 5902,
      "ty": 2,
      "x": 1278,
      "y": 751
    },
    {
      "t": 6002,
      "e": 6002,
      "ty": 41,
      "x": 34671,
      "y": 43904,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7054,
      "e": 7054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 7213,
      "e": 7213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 7214,
      "e": 7214,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7285,
      "e": 7285,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 7372,
      "e": 7372,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 7742,
      "e": 7742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 7742,
      "e": 7742,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7851,
      "e": 7851,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F "
    },
    {
      "t": 7868,
      "e": 7868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 7868,
      "e": 7868,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7980,
      "e": 7980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 7980,
      "e": 7980,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8020,
      "e": 8020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F an"
    },
    {
      "t": 8044,
      "e": 8044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 8044,
      "e": 8044,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8077,
      "e": 8077,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 8165,
      "e": 8165,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8166,
      "e": 8166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8196,
      "e": 8196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 8252,
      "e": 8252,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8260,
      "e": 8260,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 8357,
      "e": 8357,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 8357,
      "e": 8357,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8461,
      "e": 8461,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||B"
    },
    {
      "t": 8477,
      "e": 8477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 9197,
      "e": 9197,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 9198,
      "e": 9198,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9300,
      "e": 9300,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 9349,
      "e": 9349,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 9349,
      "e": 9349,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9485,
      "e": 9485,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 9486,
      "e": 9486,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9524,
      "e": 9524,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 9605,
      "e": 9605,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 9606,
      "e": 9606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 9606,
      "e": 9606,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9724,
      "e": 9724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 9724,
      "e": 9724,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9748,
      "e": 9748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 9820,
      "e": 9820,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 9901,
      "e": 9901,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 9902,
      "e": 9902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10002,
      "e": 10002,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10003,
      "e": 10003,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B start"
    },
    {
      "t": 10004,
      "e": 10004,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 10012,
      "e": 10012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 10012,
      "e": 10012,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10124,
      "e": 10124,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 10172,
      "e": 10172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10173,
      "e": 10173,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10260,
      "e": 10260,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11413,
      "e": 11413,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 11415,
      "e": 11415,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11492,
      "e": 11492,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 11533,
      "e": 11533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 11533,
      "e": 11533,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11676,
      "e": 11676,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 11900,
      "e": 11900,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 11900,
      "e": 11900,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12003,
      "e": 12003,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B starts the"
    },
    {
      "t": 12037,
      "e": 12037,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 12045,
      "e": 12045,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 12046,
      "e": 12046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12133,
      "e": 12133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 12173,
      "e": 12173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 12174,
      "e": 12174,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12252,
      "e": 12252,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 12260,
      "e": 12260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12260,
      "e": 12260,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12364,
      "e": 12364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12380,
      "e": 12380,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 12381,
      "e": 12381,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12484,
      "e": 12484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 12485,
      "e": 12485,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12500,
      "e": 12500,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sh"
    },
    {
      "t": 12556,
      "e": 12556,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 12557,
      "e": 12557,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12589,
      "e": 12589,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 12661,
      "e": 12661,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12677,
      "e": 12677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 12678,
      "e": 12678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12741,
      "e": 12741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 12876,
      "e": 12876,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12876,
      "e": 12876,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12949,
      "e": 12949,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 12973,
      "e": 12973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 12973,
      "e": 12973,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13076,
      "e": 13076,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 13788,
      "e": 13788,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 13789,
      "e": 13789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13869,
      "e": 13869,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 19293,
      "e": 18869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "13"
    },
    {
      "t": 19294,
      "e": 18870,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19403,
      "e": 18979,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B starts their shifts,\n"
    },
    {
      "t": 19404,
      "e": 18980,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||\n"
    },
    {
      "t": 20001,
      "e": 19577,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20212,
      "e": 19788,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20349,
      "e": 19925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "74"
    },
    {
      "t": 20350,
      "e": 19926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20380,
      "e": 19956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||J"
    },
    {
      "t": 20428,
      "e": 20004,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20573,
      "e": 20149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20574,
      "e": 20150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20676,
      "e": 20252,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20861,
      "e": 20437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20862,
      "e": 20438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20972,
      "e": 20548,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 20988,
      "e": 20564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 20989,
      "e": 20565,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21085,
      "e": 20661,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 21133,
      "e": 20709,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 21134,
      "e": 20710,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21220,
      "e": 20796,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 21221,
      "e": 20797,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21268,
      "e": 20844,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ds"
    },
    {
      "t": 21381,
      "e": 20957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21406,
      "e": 20982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21406,
      "e": 20982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21525,
      "e": 21101,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21741,
      "e": 21317,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 21742,
      "e": 21318,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21837,
      "e": 21413,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 21861,
      "e": 21437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 21861,
      "e": 21437,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21957,
      "e": 21533,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 21981,
      "e": 21557,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 21982,
      "e": 21558,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22109,
      "e": 21685,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 22157,
      "e": 21733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22157,
      "e": 21733,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22236,
      "e": 21812,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22348,
      "e": 21924,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 22349,
      "e": 21925,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22476,
      "e": 22052,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 22477,
      "e": 22053,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22492,
      "e": 22068,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sh"
    },
    {
      "t": 22565,
      "e": 22141,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 22565,
      "e": 22141,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22580,
      "e": 22156,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 22652,
      "e": 22228,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 22653,
      "e": 22229,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22661,
      "e": 22237,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 22740,
      "e": 22316,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22885,
      "e": 22461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22885,
      "e": 22461,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22965,
      "e": 22541,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 23012,
      "e": 22588,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23012,
      "e": 22588,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23116,
      "e": 22692,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23237,
      "e": 22813,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 23237,
      "e": 22813,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23340,
      "e": 22916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23340,
      "e": 22916,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23388,
      "e": 22964,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 23444,
      "e": 23020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23605,
      "e": 23181,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23606,
      "e": 23182,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23692,
      "e": 23268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23804,
      "e": 23380,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B starts their shifts,\nJ ends its shift at "
    },
    {
      "t": 23893,
      "e": 23469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 23894,
      "e": 23470,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23980,
      "e": 23556,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 23980,
      "e": 23556,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24036,
      "e": 23612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 24140,
      "e": 23716,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24373,
      "e": 23949,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "13"
    },
    {
      "t": 24374,
      "e": 23950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24484,
      "e": 24060,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||\n"
    },
    {
      "t": 30002,
      "e": 29060,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 32403,
      "e": 29060,
      "ty": 2,
      "x": 1280,
      "y": 751
    },
    {
      "t": 32502,
      "e": 29159,
      "ty": 2,
      "x": 1246,
      "y": 690
    },
    {
      "t": 32503,
      "e": 29160,
      "ty": 41,
      "x": 32416,
      "y": 39535,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 32602,
      "e": 29259,
      "ty": 2,
      "x": 1186,
      "y": 977
    },
    {
      "t": 32702,
      "e": 29359,
      "ty": 2,
      "x": 866,
      "y": 915
    },
    {
      "t": 32752,
      "e": 29409,
      "ty": 41,
      "x": 41019,
      "y": 44871,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 32802,
      "e": 29459,
      "ty": 2,
      "x": 374,
      "y": 783
    },
    {
      "t": 32898,
      "e": 29555,
      "ty": 6,
      "x": 347,
      "y": 682,
      "ta": "#strategyButton"
    },
    {
      "t": 32902,
      "e": 29559,
      "ty": 2,
      "x": 347,
      "y": 682
    },
    {
      "t": 33002,
      "e": 29659,
      "ty": 2,
      "x": 387,
      "y": 661
    },
    {
      "t": 33002,
      "e": 29659,
      "ty": 41,
      "x": 26435,
      "y": 12076,
      "ta": "#strategyButton"
    },
    {
      "t": 33102,
      "e": 29759,
      "ty": 2,
      "x": 397,
      "y": 666
    },
    {
      "t": 33170,
      "e": 29827,
      "ty": 3,
      "x": 398,
      "y": 669,
      "ta": "#strategyButton"
    },
    {
      "t": 33171,
      "e": 29828,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B starts their shifts,\nJ ends its shift at 12\n"
    },
    {
      "t": 33172,
      "e": 29829,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33172,
      "e": 29829,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 33202,
      "e": 29859,
      "ty": 2,
      "x": 398,
      "y": 669
    },
    {
      "t": 33233,
      "e": 29890,
      "ty": 4,
      "x": 32443,
      "y": 27496,
      "ta": "#strategyButton"
    },
    {
      "t": 33250,
      "e": 29907,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 33251,
      "e": 29908,
      "ty": 5,
      "x": 398,
      "y": 669,
      "ta": "#strategyButton"
    },
    {
      "t": 33256,
      "e": 29913,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 33258,
      "e": 29915,
      "ty": 41,
      "x": 13430,
      "y": 36617,
      "ta": "html > body"
    },
    {
      "t": 33702,
      "e": 30359,
      "ty": 2,
      "x": 398,
      "y": 672
    },
    {
      "t": 33753,
      "e": 30410,
      "ty": 41,
      "x": 13396,
      "y": 36949,
      "ta": "html > body"
    },
    {
      "t": 33802,
      "e": 30459,
      "ty": 2,
      "x": 397,
      "y": 675
    },
    {
      "t": 34102,
      "e": 30759,
      "ty": 2,
      "x": 396,
      "y": 678
    },
    {
      "t": 34202,
      "e": 30859,
      "ty": 2,
      "x": 396,
      "y": 680
    },
    {
      "t": 34252,
      "e": 30909,
      "ty": 41,
      "x": 13361,
      "y": 37226,
      "ta": "html > body"
    },
    {
      "t": 34259,
      "e": 30916,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 34401,
      "e": 31058,
      "ty": 2,
      "x": 394,
      "y": 687
    },
    {
      "t": 34501,
      "e": 31158,
      "ty": 2,
      "x": 392,
      "y": 693
    },
    {
      "t": 34501,
      "e": 31158,
      "ty": 41,
      "x": 13224,
      "y": 37947,
      "ta": "html > body"
    },
    {
      "t": 34702,
      "e": 31359,
      "ty": 2,
      "x": 398,
      "y": 694
    },
    {
      "t": 34752,
      "e": 31409,
      "ty": 41,
      "x": 16116,
      "y": 36894,
      "ta": "html > body"
    },
    {
      "t": 34802,
      "e": 31459,
      "ty": 2,
      "x": 630,
      "y": 634
    },
    {
      "t": 34901,
      "e": 31558,
      "ty": 2,
      "x": 734,
      "y": 595
    },
    {
      "t": 35001,
      "e": 31658,
      "ty": 2,
      "x": 759,
      "y": 588
    },
    {
      "t": 35001,
      "e": 31658,
      "ty": 41,
      "x": 25862,
      "y": 32130,
      "ta": "html > body"
    },
    {
      "t": 35064,
      "e": 31721,
      "ty": 6,
      "x": 819,
      "y": 564,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35100,
      "e": 31757,
      "ty": 7,
      "x": 845,
      "y": 552,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35102,
      "e": 31759,
      "ty": 2,
      "x": 845,
      "y": 552
    },
    {
      "t": 35202,
      "e": 31859,
      "ty": 2,
      "x": 852,
      "y": 549
    },
    {
      "t": 35252,
      "e": 31909,
      "ty": 41,
      "x": 9516,
      "y": 41575,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 35304,
      "e": 31961,
      "ty": 3,
      "x": 852,
      "y": 549,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 35360,
      "e": 32017,
      "ty": 4,
      "x": 9516,
      "y": 41575,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 35360,
      "e": 32017,
      "ty": 5,
      "x": 852,
      "y": 549,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 35466,
      "e": 32123,
      "ty": 6,
      "x": 852,
      "y": 556,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35502,
      "e": 32159,
      "ty": 2,
      "x": 854,
      "y": 559
    },
    {
      "t": 35502,
      "e": 32159,
      "ty": 41,
      "x": 9949,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35575,
      "e": 32232,
      "ty": 3,
      "x": 854,
      "y": 562,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35576,
      "e": 32233,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35602,
      "e": 32259,
      "ty": 2,
      "x": 854,
      "y": 562
    },
    {
      "t": 35640,
      "e": 32297,
      "ty": 4,
      "x": 9949,
      "y": 24965,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35640,
      "e": 32297,
      "ty": 5,
      "x": 854,
      "y": 562,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35752,
      "e": 32409,
      "ty": 41,
      "x": 9949,
      "y": 24965,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35984,
      "e": 32641,
      "ty": 7,
      "x": 858,
      "y": 575,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36002,
      "e": 32659,
      "ty": 2,
      "x": 858,
      "y": 576
    },
    {
      "t": 36002,
      "e": 32659,
      "ty": 41,
      "x": 10814,
      "y": 60602,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 36804,
      "e": 33461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 36804,
      "e": 33461,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36860,
      "e": 33517,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "96"
    },
    {
      "t": 36861,
      "e": 33518,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36908,
      "e": 33565,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 36956,
      "e": 33613,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 37301,
      "e": 33958,
      "ty": 2,
      "x": 974,
      "y": 577
    },
    {
      "t": 37401,
      "e": 34058,
      "ty": 2,
      "x": 1141,
      "y": 594
    },
    {
      "t": 37501,
      "e": 34158,
      "ty": 2,
      "x": 1092,
      "y": 630
    },
    {
      "t": 37501,
      "e": 34158,
      "ty": 41,
      "x": 61425,
      "y": 33119,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 37535,
      "e": 34192,
      "ty": 6,
      "x": 1080,
      "y": 653,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37601,
      "e": 34258,
      "ty": 2,
      "x": 1070,
      "y": 665
    },
    {
      "t": 37701,
      "e": 34358,
      "ty": 2,
      "x": 1069,
      "y": 665
    },
    {
      "t": 37751,
      "e": 34408,
      "ty": 41,
      "x": 56018,
      "y": 56172,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37801,
      "e": 34458,
      "ty": 2,
      "x": 1064,
      "y": 653
    },
    {
      "t": 37856,
      "e": 34513,
      "ty": 3,
      "x": 1064,
      "y": 653,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37856,
      "e": 34513,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 37856,
      "e": 34513,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 37856,
      "e": 34513,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37928,
      "e": 34585,
      "ty": 4,
      "x": 55369,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37928,
      "e": 34585,
      "ty": 5,
      "x": 1064,
      "y": 653,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38002,
      "e": 34659,
      "ty": 41,
      "x": 55369,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38765,
      "e": 35422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 38877,
      "e": 35534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 38877,
      "e": 35534,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38934,
      "e": 35591,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 38950,
      "e": 35607,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 39055,
      "e": 35712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 39055,
      "e": 35712,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39205,
      "e": 35862,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un"
    },
    {
      "t": 39215,
      "e": 35872,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 39216,
      "e": 35873,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39222,
      "e": 35879,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 39334,
      "e": 35991,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 39455,
      "e": 36112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 39456,
      "e": 36113,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39583,
      "e": 36240,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 39583,
      "e": 36240,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39614,
      "e": 36271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unite"
    },
    {
      "t": 39702,
      "e": 36359,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 39792,
      "e": 36449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 39792,
      "e": 36449,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39910,
      "e": 36567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 39950,
      "e": 36607,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 39951,
      "e": 36608,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40004,
      "e": 36661,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40047,
      "e": 36704,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 40055,
      "e": 36712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 40158,
      "e": 36815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 40158,
      "e": 36815,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40230,
      "e": 36887,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 40327,
      "e": 36984,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 40327,
      "e": 36984,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40407,
      "e": 37064,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 40415,
      "e": 37072,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 40423,
      "e": 37080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 40424,
      "e": 37081,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40511,
      "e": 37168,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 40511,
      "e": 37168,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40527,
      "e": 37184,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||at"
    },
    {
      "t": 40590,
      "e": 37247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 40591,
      "e": 37248,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40623,
      "e": 37280,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 40671,
      "e": 37328,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 40672,
      "e": 37329,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40734,
      "e": 37391,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 40783,
      "e": 37440,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 41254,
      "e": 37911,
      "ty": 41,
      "x": 55802,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41304,
      "e": 37961,
      "ty": 2,
      "x": 1068,
      "y": 653
    },
    {
      "t": 41458,
      "e": 38115,
      "ty": 7,
      "x": 1028,
      "y": 637,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41504,
      "e": 38161,
      "ty": 2,
      "x": 907,
      "y": 620
    },
    {
      "t": 41504,
      "e": 38161,
      "ty": 41,
      "x": 21412,
      "y": 44470,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 41540,
      "e": 38197,
      "ty": 6,
      "x": 895,
      "y": 648,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41603,
      "e": 38260,
      "ty": 2,
      "x": 880,
      "y": 661
    },
    {
      "t": 41623,
      "e": 38280,
      "ty": 7,
      "x": 867,
      "y": 672,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41704,
      "e": 38361,
      "ty": 2,
      "x": 864,
      "y": 677
    },
    {
      "t": 41755,
      "e": 38412,
      "ty": 41,
      "x": 29478,
      "y": 37226,
      "ta": "html > body"
    },
    {
      "t": 41804,
      "e": 38461,
      "ty": 2,
      "x": 879,
      "y": 683
    },
    {
      "t": 41841,
      "e": 38498,
      "ty": 6,
      "x": 898,
      "y": 683,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41904,
      "e": 38561,
      "ty": 2,
      "x": 914,
      "y": 684
    },
    {
      "t": 41932,
      "e": 38589,
      "ty": 3,
      "x": 914,
      "y": 684,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41932,
      "e": 38589,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 41933,
      "e": 38590,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41934,
      "e": 38591,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 42002,
      "e": 38659,
      "ty": 4,
      "x": 9317,
      "y": 15887,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 42003,
      "e": 38660,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 42003,
      "e": 38660,
      "ty": 5,
      "x": 914,
      "y": 684,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 42003,
      "e": 38660,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 42005,
      "e": 38662,
      "ty": 41,
      "x": 31200,
      "y": 37448,
      "ta": "html > body"
    },
    {
      "t": 42204,
      "e": 38861,
      "ty": 2,
      "x": 937,
      "y": 685
    },
    {
      "t": 42254,
      "e": 38911,
      "ty": 41,
      "x": 32509,
      "y": 37614,
      "ta": "html > body"
    },
    {
      "t": 42304,
      "e": 38961,
      "ty": 2,
      "x": 952,
      "y": 687
    },
    {
      "t": 43022,
      "e": 39679,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 43704,
      "e": 40361,
      "ty": 2,
      "x": 957,
      "y": 653
    },
    {
      "t": 43754,
      "e": 40411,
      "ty": 41,
      "x": 32413,
      "y": 37448,
      "ta": "#jspsych-survey-multi-choice-option-1-5"
    },
    {
      "t": 43804,
      "e": 40461,
      "ty": 2,
      "x": 935,
      "y": 474
    },
    {
      "t": 43904,
      "e": 40561,
      "ty": 2,
      "x": 900,
      "y": 370
    },
    {
      "t": 44003,
      "e": 40660,
      "ty": 2,
      "x": 890,
      "y": 288
    },
    {
      "t": 44004,
      "e": 40661,
      "ty": 41,
      "x": 21492,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 44104,
      "e": 40761,
      "ty": 2,
      "x": 877,
      "y": 235
    },
    {
      "t": 44204,
      "e": 40861,
      "ty": 2,
      "x": 873,
      "y": 226
    },
    {
      "t": 44254,
      "e": 40911,
      "ty": 41,
      "x": 12240,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 44304,
      "e": 40961,
      "ty": 2,
      "x": 870,
      "y": 228
    },
    {
      "t": 44404,
      "e": 41061,
      "ty": 2,
      "x": 870,
      "y": 247
    },
    {
      "t": 44504,
      "e": 41161,
      "ty": 2,
      "x": 871,
      "y": 281
    },
    {
      "t": 44504,
      "e": 41161,
      "ty": 41,
      "x": 11766,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 44604,
      "e": 41261,
      "ty": 2,
      "x": 873,
      "y": 293
    },
    {
      "t": 44704,
      "e": 41361,
      "ty": 2,
      "x": 875,
      "y": 297
    },
    {
      "t": 44755,
      "e": 41412,
      "ty": 41,
      "x": 16791,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 44904,
      "e": 41561,
      "ty": 2,
      "x": 875,
      "y": 296
    },
    {
      "t": 45004,
      "e": 41661,
      "ty": 41,
      "x": 16791,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 45116,
      "e": 41773,
      "ty": 3,
      "x": 875,
      "y": 296,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 45195,
      "e": 41852,
      "ty": 4,
      "x": 16791,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 45196,
      "e": 41853,
      "ty": 5,
      "x": 875,
      "y": 296,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 45196,
      "e": 41853,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 45199,
      "e": 41856,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf",
      "v": "Mandarin or Cantonese"
    },
    {
      "t": 45505,
      "e": 42162,
      "ty": 2,
      "x": 876,
      "y": 295
    },
    {
      "t": 45505,
      "e": 42162,
      "ty": 41,
      "x": 17104,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 45604,
      "e": 42261,
      "ty": 2,
      "x": 878,
      "y": 316
    },
    {
      "t": 45704,
      "e": 42361,
      "ty": 2,
      "x": 879,
      "y": 385
    },
    {
      "t": 45754,
      "e": 42411,
      "ty": 41,
      "x": 13664,
      "y": 14043,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 45804,
      "e": 42461,
      "ty": 2,
      "x": 876,
      "y": 422
    },
    {
      "t": 45904,
      "e": 42561,
      "ty": 2,
      "x": 875,
      "y": 430
    },
    {
      "t": 46004,
      "e": 42661,
      "ty": 41,
      "x": 12715,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 46104,
      "e": 42761,
      "ty": 2,
      "x": 873,
      "y": 441
    },
    {
      "t": 46204,
      "e": 42861,
      "ty": 2,
      "x": 870,
      "y": 455
    },
    {
      "t": 46255,
      "e": 42862,
      "ty": 41,
      "x": 47119,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 46304,
      "e": 42911,
      "ty": 2,
      "x": 861,
      "y": 480
    },
    {
      "t": 46404,
      "e": 43011,
      "ty": 2,
      "x": 860,
      "y": 482
    },
    {
      "t": 46504,
      "e": 43111,
      "ty": 2,
      "x": 859,
      "y": 483
    },
    {
      "t": 46504,
      "e": 43111,
      "ty": 41,
      "x": 8918,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 46604,
      "e": 43211,
      "ty": 2,
      "x": 859,
      "y": 476
    },
    {
      "t": 46684,
      "e": 43291,
      "ty": 3,
      "x": 859,
      "y": 476,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 46684,
      "e": 43291,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 46746,
      "e": 43353,
      "ty": 4,
      "x": 39720,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 46746,
      "e": 43353,
      "ty": 5,
      "x": 859,
      "y": 476,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 46746,
      "e": 43353,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 46747,
      "e": 43354,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 46754,
      "e": 43361,
      "ty": 41,
      "x": 39720,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 47004,
      "e": 43611,
      "ty": 2,
      "x": 889,
      "y": 532
    },
    {
      "t": 47004,
      "e": 43611,
      "ty": 41,
      "x": 16037,
      "y": 44470,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 47104,
      "e": 43711,
      "ty": 2,
      "x": 913,
      "y": 606
    },
    {
      "t": 47204,
      "e": 43811,
      "ty": 2,
      "x": 916,
      "y": 630
    },
    {
      "t": 47254,
      "e": 43861,
      "ty": 41,
      "x": 22445,
      "y": 7853,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 47304,
      "e": 43911,
      "ty": 2,
      "x": 916,
      "y": 658
    },
    {
      "t": 47405,
      "e": 44012,
      "ty": 2,
      "x": 911,
      "y": 680
    },
    {
      "t": 47504,
      "e": 44111,
      "ty": 2,
      "x": 908,
      "y": 687
    },
    {
      "t": 47504,
      "e": 44111,
      "ty": 41,
      "x": 20547,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 47604,
      "e": 44211,
      "ty": 2,
      "x": 906,
      "y": 692
    },
    {
      "t": 47704,
      "e": 44311,
      "ty": 2,
      "x": 903,
      "y": 708
    },
    {
      "t": 47754,
      "e": 44361,
      "ty": 41,
      "x": 19123,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 47804,
      "e": 44411,
      "ty": 2,
      "x": 900,
      "y": 721
    },
    {
      "t": 47905,
      "e": 44512,
      "ty": 2,
      "x": 900,
      "y": 733
    },
    {
      "t": 48004,
      "e": 44611,
      "ty": 2,
      "x": 898,
      "y": 741
    },
    {
      "t": 48005,
      "e": 44612,
      "ty": 41,
      "x": 18173,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 48104,
      "e": 44711,
      "ty": 2,
      "x": 895,
      "y": 753
    },
    {
      "t": 48204,
      "e": 44811,
      "ty": 2,
      "x": 892,
      "y": 761
    },
    {
      "t": 48254,
      "e": 44861,
      "ty": 41,
      "x": 29031,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 48305,
      "e": 44912,
      "ty": 2,
      "x": 890,
      "y": 768
    },
    {
      "t": 48404,
      "e": 45011,
      "ty": 2,
      "x": 884,
      "y": 790
    },
    {
      "t": 48504,
      "e": 45111,
      "ty": 2,
      "x": 884,
      "y": 805
    },
    {
      "t": 48504,
      "e": 45111,
      "ty": 41,
      "x": 36936,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 48604,
      "e": 45211,
      "ty": 2,
      "x": 886,
      "y": 814
    },
    {
      "t": 48704,
      "e": 45311,
      "ty": 2,
      "x": 887,
      "y": 824
    },
    {
      "t": 48755,
      "e": 45362,
      "ty": 41,
      "x": 16275,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 48804,
      "e": 45411,
      "ty": 2,
      "x": 891,
      "y": 835
    },
    {
      "t": 48904,
      "e": 45511,
      "ty": 2,
      "x": 892,
      "y": 843
    },
    {
      "t": 49004,
      "e": 45611,
      "ty": 2,
      "x": 893,
      "y": 848
    },
    {
      "t": 49005,
      "e": 45612,
      "ty": 41,
      "x": 50431,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 49104,
      "e": 45711,
      "ty": 2,
      "x": 893,
      "y": 850
    },
    {
      "t": 49254,
      "e": 45861,
      "ty": 41,
      "x": 50431,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 49404,
      "e": 46011,
      "ty": 2,
      "x": 893,
      "y": 833
    },
    {
      "t": 49504,
      "e": 46111,
      "ty": 2,
      "x": 893,
      "y": 797
    },
    {
      "t": 49507,
      "e": 46113,
      "ty": 41,
      "x": 16987,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 49604,
      "e": 46210,
      "ty": 2,
      "x": 892,
      "y": 775
    },
    {
      "t": 49704,
      "e": 46310,
      "ty": 2,
      "x": 896,
      "y": 755
    },
    {
      "t": 49754,
      "e": 46360,
      "ty": 41,
      "x": 18648,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 49804,
      "e": 46410,
      "ty": 2,
      "x": 904,
      "y": 737
    },
    {
      "t": 49904,
      "e": 46510,
      "ty": 2,
      "x": 910,
      "y": 719
    },
    {
      "t": 50003,
      "e": 46609,
      "ty": 2,
      "x": 913,
      "y": 713
    },
    {
      "t": 50004,
      "e": 46610,
      "ty": 41,
      "x": 21733,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 50105,
      "e": 46711,
      "ty": 2,
      "x": 917,
      "y": 707
    },
    {
      "t": 50204,
      "e": 46810,
      "ty": 2,
      "x": 919,
      "y": 701
    },
    {
      "t": 50254,
      "e": 46860,
      "ty": 41,
      "x": 24587,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 50705,
      "e": 47311,
      "ty": 2,
      "x": 919,
      "y": 699
    },
    {
      "t": 50755,
      "e": 47361,
      "ty": 41,
      "x": 26736,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 50804,
      "e": 47410,
      "ty": 2,
      "x": 923,
      "y": 673
    },
    {
      "t": 50904,
      "e": 47510,
      "ty": 2,
      "x": 924,
      "y": 669
    },
    {
      "t": 51005,
      "e": 47611,
      "ty": 41,
      "x": 27542,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 51505,
      "e": 48111,
      "ty": 2,
      "x": 923,
      "y": 678
    },
    {
      "t": 51505,
      "e": 48111,
      "ty": 41,
      "x": 27273,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 51604,
      "e": 48210,
      "ty": 2,
      "x": 919,
      "y": 696
    },
    {
      "t": 51755,
      "e": 48361,
      "ty": 41,
      "x": 24587,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 52170,
      "e": 48776,
      "ty": 3,
      "x": 919,
      "y": 696,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 52171,
      "e": 48777,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 52242,
      "e": 48848,
      "ty": 4,
      "x": 24587,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 52242,
      "e": 48848,
      "ty": 5,
      "x": 919,
      "y": 696,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 52242,
      "e": 48848,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 52243,
      "e": 48849,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 52505,
      "e": 49111,
      "ty": 2,
      "x": 919,
      "y": 705
    },
    {
      "t": 52505,
      "e": 49111,
      "ty": 41,
      "x": 24587,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 52604,
      "e": 49210,
      "ty": 2,
      "x": 932,
      "y": 813
    },
    {
      "t": 52704,
      "e": 49310,
      "ty": 2,
      "x": 937,
      "y": 843
    },
    {
      "t": 52754,
      "e": 49360,
      "ty": 41,
      "x": 27429,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 52904,
      "e": 49510,
      "ty": 2,
      "x": 937,
      "y": 844
    },
    {
      "t": 53004,
      "e": 49610,
      "ty": 2,
      "x": 914,
      "y": 870
    },
    {
      "t": 53005,
      "e": 49611,
      "ty": 41,
      "x": 21971,
      "y": 52980,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 53105,
      "e": 49711,
      "ty": 2,
      "x": 893,
      "y": 939
    },
    {
      "t": 53204,
      "e": 49810,
      "ty": 2,
      "x": 881,
      "y": 952
    },
    {
      "t": 53254,
      "e": 49860,
      "ty": 41,
      "x": 43340,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 53304,
      "e": 49910,
      "ty": 2,
      "x": 871,
      "y": 953
    },
    {
      "t": 53404,
      "e": 50010,
      "ty": 2,
      "x": 868,
      "y": 940
    },
    {
      "t": 53504,
      "e": 50110,
      "ty": 2,
      "x": 868,
      "y": 936
    },
    {
      "t": 53505,
      "e": 50111,
      "ty": 41,
      "x": 50874,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 53704,
      "e": 50310,
      "ty": 2,
      "x": 871,
      "y": 951
    },
    {
      "t": 53754,
      "e": 50360,
      "ty": 41,
      "x": 41722,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 53804,
      "e": 50410,
      "ty": 2,
      "x": 873,
      "y": 960
    },
    {
      "t": 53836,
      "e": 50442,
      "ty": 3,
      "x": 873,
      "y": 960,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 53837,
      "e": 50443,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 53915,
      "e": 50521,
      "ty": 4,
      "x": 41722,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 53915,
      "e": 50521,
      "ty": 5,
      "x": 873,
      "y": 961,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 53915,
      "e": 50521,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 53917,
      "e": 50523,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 54005,
      "e": 50611,
      "ty": 2,
      "x": 874,
      "y": 980
    },
    {
      "t": 54005,
      "e": 50611,
      "ty": 41,
      "x": 12478,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 54084,
      "e": 50690,
      "ty": 6,
      "x": 881,
      "y": 1006,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54104,
      "e": 50710,
      "ty": 2,
      "x": 883,
      "y": 1008
    },
    {
      "t": 54204,
      "e": 50810,
      "ty": 2,
      "x": 883,
      "y": 1016
    },
    {
      "t": 54254,
      "e": 50860,
      "ty": 41,
      "x": 28128,
      "y": 25816,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54275,
      "e": 50881,
      "ty": 3,
      "x": 885,
      "y": 1019,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54275,
      "e": 50881,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 54275,
      "e": 50881,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54304,
      "e": 50910,
      "ty": 2,
      "x": 885,
      "y": 1019
    },
    {
      "t": 54338,
      "e": 50944,
      "ty": 4,
      "x": 28644,
      "y": 27802,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54339,
      "e": 50945,
      "ty": 5,
      "x": 885,
      "y": 1019,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54342,
      "e": 50948,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54343,
      "e": 50949,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 54344,
      "e": 50950,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 54504,
      "e": 51110,
      "ty": 2,
      "x": 886,
      "y": 1018
    },
    {
      "t": 54505,
      "e": 51111,
      "ty": 41,
      "x": 30236,
      "y": 55951,
      "ta": "html > body"
    },
    {
      "t": 54605,
      "e": 51211,
      "ty": 2,
      "x": 979,
      "y": 981
    },
    {
      "t": 54705,
      "e": 51311,
      "ty": 2,
      "x": 1091,
      "y": 913
    },
    {
      "t": 54755,
      "e": 51361,
      "ty": 41,
      "x": 37571,
      "y": 49857,
      "ta": "html > body"
    },
    {
      "t": 54805,
      "e": 51411,
      "ty": 2,
      "x": 1099,
      "y": 908
    },
    {
      "t": 55436,
      "e": 52042,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 56404,
      "e": 53010,
      "ty": 2,
      "x": 1099,
      "y": 909
    },
    {
      "t": 56504,
      "e": 53110,
      "ty": 41,
      "x": 39630,
      "y": 54200,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 56704,
      "e": 53310,
      "ty": 2,
      "x": 1099,
      "y": 913
    },
    {
      "t": 56754,
      "e": 53360,
      "ty": 41,
      "x": 39433,
      "y": 55031,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 56804,
      "e": 53410,
      "ty": 2,
      "x": 1093,
      "y": 925
    },
    {
      "t": 56904,
      "e": 53510,
      "ty": 2,
      "x": 1082,
      "y": 940
    },
    {
      "t": 57004,
      "e": 53610,
      "ty": 2,
      "x": 1071,
      "y": 954
    },
    {
      "t": 57004,
      "e": 53610,
      "ty": 41,
      "x": 38252,
      "y": 57316,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 57104,
      "e": 53710,
      "ty": 2,
      "x": 1065,
      "y": 975
    },
    {
      "t": 57204,
      "e": 53810,
      "ty": 2,
      "x": 1049,
      "y": 1005
    },
    {
      "t": 57254,
      "e": 53860,
      "ty": 41,
      "x": 36580,
      "y": 61540,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 57303,
      "e": 53909,
      "ty": 2,
      "x": 1026,
      "y": 1025
    },
    {
      "t": 57404,
      "e": 54010,
      "ty": 2,
      "x": 1002,
      "y": 1042
    },
    {
      "t": 57504,
      "e": 54110,
      "ty": 2,
      "x": 993,
      "y": 1049
    },
    {
      "t": 57504,
      "e": 54110,
      "ty": 41,
      "x": 34415,
      "y": 63894,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 57604,
      "e": 54210,
      "ty": 2,
      "x": 985,
      "y": 1055
    },
    {
      "t": 57704,
      "e": 54310,
      "ty": 2,
      "x": 978,
      "y": 1061
    },
    {
      "t": 57754,
      "e": 54360,
      "ty": 41,
      "x": 33677,
      "y": 64794,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 57804,
      "e": 54410,
      "ty": 2,
      "x": 977,
      "y": 1065
    },
    {
      "t": 57891,
      "e": 54497,
      "ty": 6,
      "x": 975,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 57904,
      "e": 54510,
      "ty": 2,
      "x": 975,
      "y": 1072
    },
    {
      "t": 58004,
      "e": 54610,
      "ty": 2,
      "x": 975,
      "y": 1074
    },
    {
      "t": 58004,
      "e": 54610,
      "ty": 41,
      "x": 35771,
      "y": 2529,
      "ta": "#start"
    },
    {
      "t": 58104,
      "e": 54710,
      "ty": 2,
      "x": 975,
      "y": 1075
    },
    {
      "t": 58253,
      "e": 54859,
      "ty": 41,
      "x": 35771,
      "y": 4457,
      "ta": "#start"
    },
    {
      "t": 58504,
      "e": 55110,
      "ty": 2,
      "x": 975,
      "y": 1076
    },
    {
      "t": 58504,
      "e": 55110,
      "ty": 41,
      "x": 35771,
      "y": 6384,
      "ta": "#start"
    },
    {
      "t": 58908,
      "e": 55514,
      "ty": 3,
      "x": 975,
      "y": 1076,
      "ta": "#start"
    },
    {
      "t": 58909,
      "e": 55515,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 59010,
      "e": 55616,
      "ty": 4,
      "x": 35771,
      "y": 6384,
      "ta": "#start"
    },
    {
      "t": 59010,
      "e": 55616,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 59011,
      "e": 55617,
      "ty": 5,
      "x": 975,
      "y": 1076,
      "ta": "#start"
    },
    {
      "t": 59011,
      "e": 55617,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 59504,
      "e": 56110,
      "ty": 2,
      "x": 975,
      "y": 1069
    },
    {
      "t": 59504,
      "e": 56110,
      "ty": 41,
      "x": 33301,
      "y": 58776,
      "ta": "html > body"
    },
    {
      "t": 59604,
      "e": 56210,
      "ty": 2,
      "x": 975,
      "y": 959
    },
    {
      "t": 59703,
      "e": 56309,
      "ty": 2,
      "x": 975,
      "y": 864
    },
    {
      "t": 59754,
      "e": 56360,
      "ty": 41,
      "x": 33301,
      "y": 46422,
      "ta": "html > body"
    },
    {
      "t": 59804,
      "e": 56410,
      "ty": 2,
      "x": 975,
      "y": 844
    },
    {
      "t": 60003,
      "e": 56609,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60004,
      "e": 56610,
      "ty": 41,
      "x": 33301,
      "y": 46312,
      "ta": "html > body"
    },
    {
      "t": 60040,
      "e": 56646,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 61642,
      "e": 58248,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 9351, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 9354, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"C30CF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 33681, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 44182, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"C30CF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 8173, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"india\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 53357, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"C30CF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 8098, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 62561, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"C30CF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 10435, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 73998, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"C30CF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 16760, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 91978, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"C30CF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:965,y:836,t:1527027240124};\\\", \\\"{x:965,y:833,t:1527027240137};\\\", \\\"{x:965,y:832,t:1527027240154};\\\", \\\"{x:965,y:831,t:1527027240170};\\\", \\\"{x:970,y:831,t:1527027241499};\\\", \\\"{x:981,y:831,t:1527027241507};\\\", \\\"{x:1000,y:841,t:1527027241521};\\\", \\\"{x:1026,y:850,t:1527027241538};\\\", \\\"{x:1051,y:859,t:1527027241553};\\\", \\\"{x:1079,y:864,t:1527027241571};\\\", \\\"{x:1124,y:865,t:1527027241587};\\\", \\\"{x:1151,y:865,t:1527027241604};\\\", \\\"{x:1179,y:870,t:1527027241620};\\\", \\\"{x:1206,y:873,t:1527027241638};\\\", \\\"{x:1229,y:876,t:1527027241655};\\\", \\\"{x:1253,y:877,t:1527027241670};\\\", \\\"{x:1272,y:879,t:1527027241687};\\\", \\\"{x:1283,y:879,t:1527027241704};\\\", \\\"{x:1287,y:879,t:1527027241720};\\\", \\\"{x:1288,y:879,t:1527027241737};\\\", \\\"{x:1289,y:878,t:1527027241754};\\\", \\\"{x:1290,y:876,t:1527027241770};\\\", \\\"{x:1295,y:865,t:1527027241786};\\\", \\\"{x:1300,y:859,t:1527027241803};\\\", \\\"{x:1302,y:857,t:1527027241820};\\\", \\\"{x:1303,y:854,t:1527027241837};\\\", \\\"{x:1303,y:853,t:1527027241853};\\\", \\\"{x:1303,y:850,t:1527027241870};\\\", \\\"{x:1304,y:849,t:1527027241887};\\\", \\\"{x:1304,y:847,t:1527027241904};\\\", \\\"{x:1304,y:845,t:1527027241920};\\\", \\\"{x:1304,y:843,t:1527027241937};\\\", \\\"{x:1303,y:840,t:1527027241954};\\\", \\\"{x:1300,y:838,t:1527027241970};\\\", \\\"{x:1293,y:835,t:1527027241987};\\\", \\\"{x:1290,y:834,t:1527027242004};\\\", \\\"{x:1287,y:833,t:1527027242020};\\\", \\\"{x:1283,y:833,t:1527027242037};\\\", \\\"{x:1281,y:832,t:1527027242054};\\\", \\\"{x:1278,y:832,t:1527027242070};\\\", \\\"{x:1277,y:832,t:1527027242087};\\\", \\\"{x:1276,y:832,t:1527027242104};\\\", \\\"{x:1276,y:831,t:1527027242667};\\\", \\\"{x:1273,y:830,t:1527027244261};\\\", \\\"{x:1255,y:828,t:1527027244272};\\\", \\\"{x:1195,y:814,t:1527027244290};\\\", \\\"{x:1104,y:803,t:1527027244305};\\\", \\\"{x:997,y:780,t:1527027244323};\\\", \\\"{x:824,y:735,t:1527027244339};\\\", \\\"{x:716,y:704,t:1527027244356};\\\", \\\"{x:613,y:672,t:1527027244372};\\\", \\\"{x:503,y:648,t:1527027244390};\\\", \\\"{x:387,y:612,t:1527027244405};\\\", \\\"{x:285,y:586,t:1527027244422};\\\", \\\"{x:199,y:562,t:1527027244440};\\\", \\\"{x:113,y:541,t:1527027244456};\\\", \\\"{x:38,y:517,t:1527027244473};\\\", \\\"{x:0,y:497,t:1527027244488};\\\", \\\"{x:0,y:464,t:1527027244506};\\\", \\\"{x:0,y:451,t:1527027244522};\\\", \\\"{x:0,y:439,t:1527027244539};\\\", \\\"{x:0,y:434,t:1527027244556};\\\", \\\"{x:0,y:431,t:1527027244573};\\\", \\\"{x:0,y:430,t:1527027244590};\\\", \\\"{x:0,y:429,t:1527027244626};\\\", \\\"{x:0,y:428,t:1527027244639};\\\", \\\"{x:0,y:427,t:1527027244656};\\\", \\\"{x:2,y:427,t:1527027244674};\\\", \\\"{x:10,y:427,t:1527027244690};\\\", \\\"{x:33,y:438,t:1527027244707};\\\", \\\"{x:58,y:452,t:1527027244723};\\\", \\\"{x:88,y:470,t:1527027244740};\\\", \\\"{x:118,y:483,t:1527027244756};\\\", \\\"{x:161,y:499,t:1527027244773};\\\", \\\"{x:222,y:516,t:1527027244791};\\\", \\\"{x:287,y:527,t:1527027244807};\\\", \\\"{x:342,y:539,t:1527027244822};\\\", \\\"{x:387,y:547,t:1527027244840};\\\", \\\"{x:412,y:551,t:1527027244857};\\\", \\\"{x:422,y:551,t:1527027244873};\\\", \\\"{x:427,y:551,t:1527027244890};\\\", \\\"{x:428,y:550,t:1527027244906};\\\", \\\"{x:428,y:547,t:1527027244924};\\\", \\\"{x:428,y:542,t:1527027244940};\\\", \\\"{x:428,y:537,t:1527027244957};\\\", \\\"{x:428,y:535,t:1527027244987};\\\", \\\"{x:428,y:534,t:1527027244993};\\\", \\\"{x:428,y:533,t:1527027245010};\\\", \\\"{x:427,y:532,t:1527027245026};\\\", \\\"{x:426,y:531,t:1527027245040};\\\", \\\"{x:421,y:529,t:1527027245056};\\\", \\\"{x:413,y:526,t:1527027245073};\\\", \\\"{x:400,y:525,t:1527027245090};\\\", \\\"{x:393,y:523,t:1527027245106};\\\", \\\"{x:384,y:522,t:1527027245123};\\\", \\\"{x:377,y:521,t:1527027245140};\\\", \\\"{x:369,y:519,t:1527027245158};\\\", \\\"{x:366,y:518,t:1527027245173};\\\", \\\"{x:365,y:518,t:1527027245190};\\\", \\\"{x:369,y:518,t:1527027245322};\\\", \\\"{x:371,y:518,t:1527027245330};\\\", \\\"{x:376,y:519,t:1527027245340};\\\", \\\"{x:382,y:520,t:1527027245356};\\\", \\\"{x:385,y:522,t:1527027245374};\\\", \\\"{x:387,y:522,t:1527027245389};\\\", \\\"{x:388,y:523,t:1527027245707};\\\", \\\"{x:389,y:532,t:1527027245724};\\\", \\\"{x:400,y:551,t:1527027245742};\\\", \\\"{x:416,y:570,t:1527027245757};\\\", \\\"{x:434,y:593,t:1527027245774};\\\", \\\"{x:453,y:616,t:1527027245792};\\\", \\\"{x:471,y:640,t:1527027245808};\\\", \\\"{x:487,y:667,t:1527027245824};\\\", \\\"{x:500,y:695,t:1527027245841};\\\", \\\"{x:508,y:716,t:1527027245857};\\\", \\\"{x:516,y:735,t:1527027245874};\\\", \\\"{x:518,y:743,t:1527027245890};\\\", \\\"{x:521,y:748,t:1527027245907};\\\", \\\"{x:521,y:750,t:1527027245924};\\\", \\\"{x:521,y:747,t:1527027246066};\\\", \\\"{x:523,y:744,t:1527027246074};\\\", \\\"{x:524,y:738,t:1527027246090};\\\", \\\"{x:525,y:733,t:1527027246108};\\\", \\\"{x:525,y:730,t:1527027246123};\\\", \\\"{x:526,y:725,t:1527027246141};\\\", \\\"{x:526,y:723,t:1527027246157};\\\", \\\"{x:526,y:721,t:1527027246174};\\\", \\\"{x:526,y:720,t:1527027246194};\\\", \\\"{x:526,y:719,t:1527027246207};\\\" ] }, { \\\"rt\\\": 8895, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 102133, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"C30CF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-K -D -D -E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:527,y:719,t:1527027257291};\\\", \\\"{x:528,y:721,t:1527027257307};\\\", \\\"{x:528,y:722,t:1527027257317};\\\", \\\"{x:528,y:724,t:1527027257334};\\\", \\\"{x:531,y:729,t:1527027257350};\\\", \\\"{x:534,y:733,t:1527027257366};\\\", \\\"{x:541,y:740,t:1527027257385};\\\", \\\"{x:550,y:745,t:1527027257401};\\\", \\\"{x:568,y:755,t:1527027257416};\\\", \\\"{x:585,y:762,t:1527027257433};\\\", \\\"{x:619,y:776,t:1527027257450};\\\", \\\"{x:651,y:785,t:1527027257466};\\\", \\\"{x:688,y:796,t:1527027257483};\\\", \\\"{x:731,y:805,t:1527027257501};\\\", \\\"{x:775,y:815,t:1527027257516};\\\", \\\"{x:825,y:827,t:1527027257533};\\\", \\\"{x:883,y:844,t:1527027257551};\\\", \\\"{x:934,y:853,t:1527027257566};\\\", \\\"{x:1001,y:871,t:1527027257584};\\\", \\\"{x:1051,y:885,t:1527027257601};\\\", \\\"{x:1110,y:895,t:1527027257616};\\\", \\\"{x:1179,y:903,t:1527027257634};\\\", \\\"{x:1271,y:918,t:1527027257651};\\\", \\\"{x:1319,y:926,t:1527027257667};\\\", \\\"{x:1368,y:929,t:1527027257684};\\\", \\\"{x:1407,y:934,t:1527027257701};\\\", \\\"{x:1454,y:939,t:1527027257717};\\\", \\\"{x:1490,y:939,t:1527027257733};\\\", \\\"{x:1522,y:939,t:1527027257750};\\\", \\\"{x:1546,y:939,t:1527027257766};\\\", \\\"{x:1569,y:939,t:1527027257784};\\\", \\\"{x:1588,y:939,t:1527027257801};\\\", \\\"{x:1608,y:939,t:1527027257817};\\\", \\\"{x:1618,y:939,t:1527027257834};\\\", \\\"{x:1624,y:935,t:1527027257851};\\\", \\\"{x:1625,y:933,t:1527027257867};\\\", \\\"{x:1626,y:931,t:1527027257884};\\\", \\\"{x:1626,y:929,t:1527027257901};\\\", \\\"{x:1626,y:927,t:1527027257916};\\\", \\\"{x:1626,y:925,t:1527027257934};\\\", \\\"{x:1626,y:922,t:1527027257950};\\\", \\\"{x:1626,y:919,t:1527027257968};\\\", \\\"{x:1626,y:916,t:1527027257984};\\\", \\\"{x:1626,y:911,t:1527027258001};\\\", \\\"{x:1626,y:907,t:1527027258018};\\\", \\\"{x:1626,y:901,t:1527027258033};\\\", \\\"{x:1629,y:892,t:1527027258050};\\\", \\\"{x:1630,y:890,t:1527027258068};\\\", \\\"{x:1633,y:890,t:1527027258123};\\\", \\\"{x:1636,y:890,t:1527027258134};\\\", \\\"{x:1640,y:890,t:1527027258151};\\\", \\\"{x:1644,y:890,t:1527027258168};\\\", \\\"{x:1648,y:890,t:1527027258184};\\\", \\\"{x:1649,y:890,t:1527027258307};\\\", \\\"{x:1649,y:889,t:1527027258331};\\\", \\\"{x:1649,y:888,t:1527027258346};\\\", \\\"{x:1649,y:886,t:1527027258355};\\\", \\\"{x:1649,y:884,t:1527027258368};\\\", \\\"{x:1649,y:879,t:1527027258384};\\\", \\\"{x:1651,y:873,t:1527027258401};\\\", \\\"{x:1654,y:871,t:1527027258418};\\\", \\\"{x:1658,y:867,t:1527027258435};\\\", \\\"{x:1662,y:865,t:1527027258451};\\\", \\\"{x:1666,y:863,t:1527027258468};\\\", \\\"{x:1671,y:859,t:1527027258485};\\\", \\\"{x:1674,y:855,t:1527027258501};\\\", \\\"{x:1677,y:851,t:1527027258518};\\\", \\\"{x:1679,y:849,t:1527027258535};\\\", \\\"{x:1681,y:846,t:1527027258551};\\\", \\\"{x:1684,y:843,t:1527027258568};\\\", \\\"{x:1687,y:837,t:1527027258585};\\\", \\\"{x:1690,y:831,t:1527027258601};\\\", \\\"{x:1692,y:826,t:1527027258618};\\\", \\\"{x:1693,y:819,t:1527027258635};\\\", \\\"{x:1693,y:813,t:1527027258651};\\\", \\\"{x:1693,y:805,t:1527027258668};\\\", \\\"{x:1692,y:801,t:1527027258685};\\\", \\\"{x:1687,y:788,t:1527027258701};\\\", \\\"{x:1682,y:776,t:1527027258718};\\\", \\\"{x:1679,y:767,t:1527027258735};\\\", \\\"{x:1672,y:755,t:1527027258751};\\\", \\\"{x:1665,y:744,t:1527027258767};\\\", \\\"{x:1657,y:733,t:1527027258784};\\\", \\\"{x:1649,y:723,t:1527027258800};\\\", \\\"{x:1627,y:706,t:1527027258817};\\\", \\\"{x:1589,y:677,t:1527027258834};\\\", \\\"{x:1558,y:656,t:1527027258850};\\\", \\\"{x:1535,y:640,t:1527027258867};\\\", \\\"{x:1513,y:625,t:1527027258886};\\\", \\\"{x:1495,y:611,t:1527027258902};\\\", \\\"{x:1478,y:598,t:1527027258917};\\\", \\\"{x:1459,y:583,t:1527027258934};\\\", \\\"{x:1440,y:570,t:1527027258951};\\\", \\\"{x:1419,y:555,t:1527027258968};\\\", \\\"{x:1404,y:545,t:1527027258984};\\\", \\\"{x:1394,y:536,t:1527027259002};\\\", \\\"{x:1387,y:530,t:1527027259018};\\\", \\\"{x:1382,y:525,t:1527027259034};\\\", \\\"{x:1382,y:523,t:1527027259052};\\\", \\\"{x:1382,y:520,t:1527027259068};\\\", \\\"{x:1382,y:517,t:1527027259085};\\\", \\\"{x:1382,y:514,t:1527027259102};\\\", \\\"{x:1382,y:513,t:1527027259117};\\\", \\\"{x:1382,y:510,t:1527027259135};\\\", \\\"{x:1385,y:505,t:1527027259152};\\\", \\\"{x:1399,y:493,t:1527027259168};\\\", \\\"{x:1414,y:482,t:1527027259185};\\\", \\\"{x:1429,y:473,t:1527027259202};\\\", \\\"{x:1445,y:462,t:1527027259218};\\\", \\\"{x:1464,y:449,t:1527027259234};\\\", \\\"{x:1469,y:446,t:1527027259252};\\\", \\\"{x:1475,y:443,t:1527027259268};\\\", \\\"{x:1482,y:440,t:1527027259285};\\\", \\\"{x:1489,y:435,t:1527027259302};\\\", \\\"{x:1499,y:430,t:1527027259318};\\\", \\\"{x:1512,y:426,t:1527027259335};\\\", \\\"{x:1527,y:423,t:1527027259352};\\\", \\\"{x:1533,y:421,t:1527027259368};\\\", \\\"{x:1539,y:421,t:1527027259385};\\\", \\\"{x:1544,y:420,t:1527027259402};\\\", \\\"{x:1555,y:420,t:1527027259419};\\\", \\\"{x:1564,y:420,t:1527027259434};\\\", \\\"{x:1575,y:420,t:1527027259452};\\\", \\\"{x:1585,y:420,t:1527027259469};\\\", \\\"{x:1590,y:420,t:1527027259484};\\\", \\\"{x:1596,y:420,t:1527027259502};\\\", \\\"{x:1600,y:420,t:1527027259519};\\\", \\\"{x:1603,y:420,t:1527027259534};\\\", \\\"{x:1604,y:420,t:1527027259551};\\\", \\\"{x:1607,y:420,t:1527027259568};\\\", \\\"{x:1608,y:420,t:1527027259585};\\\", \\\"{x:1611,y:420,t:1527027259602};\\\", \\\"{x:1614,y:420,t:1527027259619};\\\", \\\"{x:1615,y:421,t:1527027259650};\\\", \\\"{x:1616,y:422,t:1527027259674};\\\", \\\"{x:1618,y:424,t:1527027259686};\\\", \\\"{x:1619,y:425,t:1527027259715};\\\", \\\"{x:1620,y:426,t:1527027259740};\\\", \\\"{x:1621,y:428,t:1527027259819};\\\", \\\"{x:1621,y:427,t:1527027260019};\\\", \\\"{x:1620,y:427,t:1527027260307};\\\", \\\"{x:1620,y:428,t:1527027260320};\\\", \\\"{x:1619,y:434,t:1527027260337};\\\", \\\"{x:1616,y:440,t:1527027260353};\\\", \\\"{x:1615,y:448,t:1527027260369};\\\", \\\"{x:1613,y:460,t:1527027260386};\\\", \\\"{x:1610,y:476,t:1527027260403};\\\", \\\"{x:1608,y:490,t:1527027260419};\\\", \\\"{x:1608,y:506,t:1527027260436};\\\", \\\"{x:1608,y:520,t:1527027260454};\\\", \\\"{x:1608,y:532,t:1527027260469};\\\", \\\"{x:1608,y:541,t:1527027260486};\\\", \\\"{x:1608,y:549,t:1527027260503};\\\", \\\"{x:1609,y:556,t:1527027260519};\\\", \\\"{x:1611,y:562,t:1527027260536};\\\", \\\"{x:1611,y:567,t:1527027260553};\\\", \\\"{x:1612,y:569,t:1527027260570};\\\", \\\"{x:1612,y:571,t:1527027260586};\\\", \\\"{x:1613,y:576,t:1527027260602};\\\", \\\"{x:1613,y:577,t:1527027260635};\\\", \\\"{x:1613,y:576,t:1527027260809};\\\", \\\"{x:1613,y:574,t:1527027260826};\\\", \\\"{x:1613,y:573,t:1527027260836};\\\", \\\"{x:1613,y:572,t:1527027260853};\\\", \\\"{x:1613,y:571,t:1527027260890};\\\", \\\"{x:1611,y:571,t:1527027261146};\\\", \\\"{x:1603,y:573,t:1527027261154};\\\", \\\"{x:1586,y:579,t:1527027261170};\\\", \\\"{x:1529,y:590,t:1527027261185};\\\", \\\"{x:1397,y:609,t:1527027261202};\\\", \\\"{x:1306,y:620,t:1527027261220};\\\", \\\"{x:1206,y:634,t:1527027261236};\\\", \\\"{x:1123,y:634,t:1527027261252};\\\", \\\"{x:1045,y:634,t:1527027261269};\\\", \\\"{x:962,y:626,t:1527027261286};\\\", \\\"{x:889,y:612,t:1527027261303};\\\", \\\"{x:836,y:607,t:1527027261320};\\\", \\\"{x:797,y:601,t:1527027261337};\\\", \\\"{x:776,y:597,t:1527027261353};\\\", \\\"{x:758,y:593,t:1527027261369};\\\", \\\"{x:739,y:587,t:1527027261386};\\\", \\\"{x:734,y:585,t:1527027261403};\\\", \\\"{x:729,y:582,t:1527027261420};\\\", \\\"{x:726,y:579,t:1527027261437};\\\", \\\"{x:723,y:575,t:1527027261454};\\\", \\\"{x:719,y:568,t:1527027261470};\\\", \\\"{x:710,y:559,t:1527027261486};\\\", \\\"{x:699,y:553,t:1527027261503};\\\", \\\"{x:681,y:545,t:1527027261519};\\\", \\\"{x:660,y:540,t:1527027261537};\\\", \\\"{x:639,y:536,t:1527027261554};\\\", \\\"{x:617,y:534,t:1527027261570};\\\", \\\"{x:583,y:531,t:1527027261586};\\\", \\\"{x:566,y:529,t:1527027261603};\\\", \\\"{x:555,y:529,t:1527027261619};\\\", \\\"{x:543,y:525,t:1527027261636};\\\", \\\"{x:527,y:523,t:1527027261654};\\\", \\\"{x:511,y:523,t:1527027261670};\\\", \\\"{x:497,y:523,t:1527027261688};\\\", \\\"{x:486,y:523,t:1527027261703};\\\", \\\"{x:477,y:525,t:1527027261719};\\\", \\\"{x:473,y:526,t:1527027261736};\\\", \\\"{x:471,y:526,t:1527027261753};\\\", \\\"{x:469,y:528,t:1527027261770};\\\", \\\"{x:464,y:530,t:1527027261786};\\\", \\\"{x:456,y:534,t:1527027261804};\\\", \\\"{x:445,y:537,t:1527027261820};\\\", \\\"{x:437,y:538,t:1527027261836};\\\", \\\"{x:429,y:539,t:1527027261853};\\\", \\\"{x:420,y:541,t:1527027261870};\\\", \\\"{x:411,y:544,t:1527027261888};\\\", \\\"{x:404,y:547,t:1527027261904};\\\", \\\"{x:398,y:551,t:1527027261920};\\\", \\\"{x:391,y:556,t:1527027261937};\\\", \\\"{x:388,y:560,t:1527027261954};\\\", \\\"{x:386,y:564,t:1527027261970};\\\", \\\"{x:385,y:566,t:1527027261986};\\\", \\\"{x:384,y:570,t:1527027262003};\\\", \\\"{x:382,y:574,t:1527027262021};\\\", \\\"{x:381,y:579,t:1527027262037};\\\", \\\"{x:378,y:585,t:1527027262055};\\\", \\\"{x:377,y:588,t:1527027262071};\\\", \\\"{x:377,y:591,t:1527027262087};\\\", \\\"{x:375,y:594,t:1527027262104};\\\", \\\"{x:374,y:597,t:1527027262121};\\\", \\\"{x:371,y:600,t:1527027262137};\\\", \\\"{x:364,y:604,t:1527027262153};\\\", \\\"{x:346,y:606,t:1527027262170};\\\", \\\"{x:327,y:606,t:1527027262188};\\\", \\\"{x:304,y:606,t:1527027262203};\\\", \\\"{x:282,y:603,t:1527027262221};\\\", \\\"{x:259,y:600,t:1527027262239};\\\", \\\"{x:233,y:596,t:1527027262253};\\\", \\\"{x:209,y:593,t:1527027262270};\\\", \\\"{x:192,y:590,t:1527027262287};\\\", \\\"{x:180,y:589,t:1527027262304};\\\", \\\"{x:174,y:587,t:1527027262321};\\\", \\\"{x:170,y:586,t:1527027262337};\\\", \\\"{x:165,y:586,t:1527027262354};\\\", \\\"{x:158,y:586,t:1527027262370};\\\", \\\"{x:156,y:586,t:1527027262387};\\\", \\\"{x:154,y:586,t:1527027262403};\\\", \\\"{x:153,y:586,t:1527027262420};\\\", \\\"{x:151,y:587,t:1527027262438};\\\", \\\"{x:149,y:589,t:1527027262467};\\\", \\\"{x:149,y:590,t:1527027262523};\\\", \\\"{x:150,y:591,t:1527027262537};\\\", \\\"{x:150,y:594,t:1527027262555};\\\", \\\"{x:150,y:598,t:1527027262570};\\\", \\\"{x:150,y:603,t:1527027262587};\\\", \\\"{x:151,y:609,t:1527027262605};\\\", \\\"{x:152,y:614,t:1527027262622};\\\", \\\"{x:153,y:617,t:1527027262638};\\\", \\\"{x:154,y:618,t:1527027262654};\\\", \\\"{x:154,y:620,t:1527027262674};\\\", \\\"{x:154,y:621,t:1527027262690};\\\", \\\"{x:155,y:622,t:1527027262706};\\\", \\\"{x:155,y:623,t:1527027262778};\\\", \\\"{x:156,y:623,t:1527027262787};\\\", \\\"{x:156,y:624,t:1527027262803};\\\", \\\"{x:158,y:625,t:1527027262821};\\\", \\\"{x:158,y:626,t:1527027262842};\\\", \\\"{x:159,y:627,t:1527027262855};\\\", \\\"{x:159,y:628,t:1527027262871};\\\", \\\"{x:160,y:628,t:1527027262888};\\\", \\\"{x:160,y:629,t:1527027263067};\\\", \\\"{x:160,y:631,t:1527027263073};\\\", \\\"{x:160,y:633,t:1527027263088};\\\", \\\"{x:168,y:639,t:1527027263104};\\\", \\\"{x:183,y:646,t:1527027263122};\\\", \\\"{x:215,y:659,t:1527027263138};\\\", \\\"{x:247,y:668,t:1527027263154};\\\", \\\"{x:286,y:683,t:1527027263172};\\\", \\\"{x:310,y:695,t:1527027263187};\\\", \\\"{x:339,y:707,t:1527027263205};\\\", \\\"{x:359,y:716,t:1527027263222};\\\", \\\"{x:371,y:722,t:1527027263237};\\\", \\\"{x:380,y:724,t:1527027263254};\\\", \\\"{x:383,y:725,t:1527027263272};\\\", \\\"{x:384,y:725,t:1527027263287};\\\", \\\"{x:385,y:725,t:1527027263305};\\\", \\\"{x:386,y:725,t:1527027263321};\\\", \\\"{x:389,y:725,t:1527027263338};\\\", \\\"{x:395,y:726,t:1527027263354};\\\", \\\"{x:401,y:728,t:1527027263372};\\\", \\\"{x:411,y:729,t:1527027263388};\\\", \\\"{x:424,y:731,t:1527027263405};\\\", \\\"{x:433,y:734,t:1527027263422};\\\", \\\"{x:448,y:738,t:1527027263438};\\\", \\\"{x:461,y:741,t:1527027263454};\\\", \\\"{x:475,y:744,t:1527027263472};\\\", \\\"{x:484,y:745,t:1527027263488};\\\", \\\"{x:490,y:745,t:1527027263504};\\\", \\\"{x:494,y:745,t:1527027263522};\\\", \\\"{x:498,y:743,t:1527027263539};\\\", \\\"{x:502,y:741,t:1527027263555};\\\", \\\"{x:503,y:740,t:1527027263572};\\\", \\\"{x:504,y:739,t:1527027263588};\\\", \\\"{x:504,y:738,t:1527027263626};\\\", \\\"{x:505,y:738,t:1527027263666};\\\", \\\"{x:506,y:736,t:1527027263762};\\\", \\\"{x:507,y:734,t:1527027263773};\\\", \\\"{x:513,y:731,t:1527027263788};\\\", \\\"{x:516,y:729,t:1527027263805};\\\", \\\"{x:519,y:726,t:1527027263822};\\\", \\\"{x:521,y:724,t:1527027263838};\\\", \\\"{x:522,y:723,t:1527027263855};\\\", \\\"{x:526,y:725,t:1527027264323};\\\", \\\"{x:541,y:733,t:1527027264339};\\\", \\\"{x:562,y:742,t:1527027264355};\\\", \\\"{x:590,y:752,t:1527027264372};\\\", \\\"{x:627,y:761,t:1527027264389};\\\", \\\"{x:655,y:770,t:1527027264406};\\\", \\\"{x:683,y:778,t:1527027264422};\\\", \\\"{x:714,y:787,t:1527027264438};\\\", \\\"{x:734,y:793,t:1527027264456};\\\", \\\"{x:749,y:796,t:1527027264472};\\\", \\\"{x:759,y:800,t:1527027264489};\\\", \\\"{x:765,y:800,t:1527027264507};\\\", \\\"{x:766,y:800,t:1527027264521};\\\", \\\"{x:766,y:801,t:1527027264579};\\\", \\\"{x:767,y:802,t:1527027264675};\\\" ] }, { \\\"rt\\\": 24377, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 127761, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"C30CF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -A -A -C -C -C -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:768,y:802,t:1527027265306};\\\", \\\"{x:769,y:802,t:1527027266218};\\\", \\\"{x:770,y:802,t:1527027268043};\\\", \\\"{x:772,y:802,t:1527027268146};\\\", \\\"{x:780,y:804,t:1527027268159};\\\", \\\"{x:814,y:815,t:1527027268176};\\\", \\\"{x:861,y:822,t:1527027268192};\\\", \\\"{x:924,y:834,t:1527027268209};\\\", \\\"{x:982,y:849,t:1527027268226};\\\", \\\"{x:1040,y:864,t:1527027268243};\\\", \\\"{x:1066,y:872,t:1527027268260};\\\", \\\"{x:1088,y:879,t:1527027268276};\\\", \\\"{x:1114,y:886,t:1527027268292};\\\", \\\"{x:1137,y:892,t:1527027268309};\\\", \\\"{x:1160,y:897,t:1527027268326};\\\", \\\"{x:1190,y:904,t:1527027268342};\\\", \\\"{x:1229,y:916,t:1527027268359};\\\", \\\"{x:1261,y:921,t:1527027268377};\\\", \\\"{x:1283,y:923,t:1527027268392};\\\", \\\"{x:1299,y:923,t:1527027268410};\\\", \\\"{x:1303,y:923,t:1527027268425};\\\", \\\"{x:1304,y:923,t:1527027268443};\\\", \\\"{x:1304,y:918,t:1527027268459};\\\", \\\"{x:1304,y:910,t:1527027268477};\\\", \\\"{x:1304,y:904,t:1527027268492};\\\", \\\"{x:1304,y:898,t:1527027268509};\\\", \\\"{x:1300,y:885,t:1527027268526};\\\", \\\"{x:1294,y:873,t:1527027268542};\\\", \\\"{x:1285,y:859,t:1527027268559};\\\", \\\"{x:1267,y:846,t:1527027268576};\\\", \\\"{x:1251,y:837,t:1527027268593};\\\", \\\"{x:1233,y:830,t:1527027268610};\\\", \\\"{x:1207,y:818,t:1527027268626};\\\", \\\"{x:1193,y:812,t:1527027268642};\\\", \\\"{x:1181,y:808,t:1527027268660};\\\", \\\"{x:1177,y:807,t:1527027268676};\\\", \\\"{x:1176,y:806,t:1527027268692};\\\", \\\"{x:1176,y:807,t:1527027268836};\\\", \\\"{x:1178,y:809,t:1527027268843};\\\", \\\"{x:1180,y:813,t:1527027268860};\\\", \\\"{x:1182,y:816,t:1527027268877};\\\", \\\"{x:1184,y:818,t:1527027268894};\\\", \\\"{x:1186,y:819,t:1527027268910};\\\", \\\"{x:1187,y:820,t:1527027268927};\\\", \\\"{x:1188,y:820,t:1527027268947};\\\", \\\"{x:1189,y:820,t:1527027268960};\\\", \\\"{x:1190,y:820,t:1527027268976};\\\", \\\"{x:1192,y:821,t:1527027268993};\\\", \\\"{x:1193,y:821,t:1527027269010};\\\", \\\"{x:1195,y:822,t:1527027269027};\\\", \\\"{x:1196,y:822,t:1527027269075};\\\", \\\"{x:1197,y:822,t:1527027269094};\\\", \\\"{x:1198,y:822,t:1527027269109};\\\", \\\"{x:1199,y:822,t:1527027269127};\\\", \\\"{x:1200,y:822,t:1527027269143};\\\", \\\"{x:1201,y:822,t:1527027269160};\\\", \\\"{x:1203,y:823,t:1527027269579};\\\", \\\"{x:1206,y:824,t:1527027269594};\\\", \\\"{x:1220,y:830,t:1527027269613};\\\", \\\"{x:1223,y:830,t:1527027269626};\\\", \\\"{x:1221,y:830,t:1527027270098};\\\", \\\"{x:1218,y:830,t:1527027270110};\\\", \\\"{x:1217,y:831,t:1527027270127};\\\", \\\"{x:1216,y:831,t:1527027270178};\\\", \\\"{x:1214,y:831,t:1527027270803};\\\", \\\"{x:1215,y:832,t:1527027272331};\\\", \\\"{x:1222,y:832,t:1527027272346};\\\", \\\"{x:1248,y:832,t:1527027272363};\\\", \\\"{x:1264,y:834,t:1527027272380};\\\", \\\"{x:1276,y:835,t:1527027272395};\\\", \\\"{x:1282,y:835,t:1527027272413};\\\", \\\"{x:1284,y:835,t:1527027272431};\\\", \\\"{x:1285,y:835,t:1527027272446};\\\", \\\"{x:1286,y:835,t:1527027272467};\\\", \\\"{x:1287,y:835,t:1527027272480};\\\", \\\"{x:1288,y:835,t:1527027272496};\\\", \\\"{x:1289,y:835,t:1527027272515};\\\", \\\"{x:1290,y:835,t:1527027272529};\\\", \\\"{x:1290,y:834,t:1527027272715};\\\", \\\"{x:1290,y:833,t:1527027272730};\\\", \\\"{x:1289,y:831,t:1527027272746};\\\", \\\"{x:1288,y:831,t:1527027272762};\\\", \\\"{x:1287,y:831,t:1527027272780};\\\", \\\"{x:1285,y:830,t:1527027272797};\\\", \\\"{x:1284,y:830,t:1527027272915};\\\", \\\"{x:1283,y:829,t:1527027272931};\\\", \\\"{x:1282,y:829,t:1527027272947};\\\", \\\"{x:1281,y:829,t:1527027272962};\\\", \\\"{x:1279,y:829,t:1527027272986};\\\", \\\"{x:1279,y:828,t:1527027272996};\\\", \\\"{x:1278,y:828,t:1527027273026};\\\", \\\"{x:1276,y:828,t:1527027273073};\\\", \\\"{x:1275,y:828,t:1527027276492};\\\", \\\"{x:1272,y:829,t:1527027276499};\\\", \\\"{x:1270,y:829,t:1527027276516};\\\", \\\"{x:1269,y:829,t:1527027276533};\\\", \\\"{x:1266,y:829,t:1527027276549};\\\", \\\"{x:1265,y:829,t:1527027276571};\\\", \\\"{x:1263,y:829,t:1527027276583};\\\", \\\"{x:1260,y:829,t:1527027276598};\\\", \\\"{x:1257,y:829,t:1527027276616};\\\", \\\"{x:1252,y:829,t:1527027276633};\\\", \\\"{x:1246,y:829,t:1527027276649};\\\", \\\"{x:1241,y:829,t:1527027276666};\\\", \\\"{x:1235,y:829,t:1527027276682};\\\", \\\"{x:1229,y:829,t:1527027276699};\\\", \\\"{x:1226,y:829,t:1527027276715};\\\", \\\"{x:1222,y:828,t:1527027276733};\\\", \\\"{x:1219,y:828,t:1527027276750};\\\", \\\"{x:1217,y:828,t:1527027276765};\\\", \\\"{x:1216,y:828,t:1527027276782};\\\", \\\"{x:1215,y:828,t:1527027276827};\\\", \\\"{x:1213,y:828,t:1527027276842};\\\", \\\"{x:1212,y:828,t:1527027276858};\\\", \\\"{x:1211,y:828,t:1527027277339};\\\", \\\"{x:1209,y:828,t:1527027277351};\\\", \\\"{x:1209,y:827,t:1527027277386};\\\", \\\"{x:1208,y:827,t:1527027277540};\\\", \\\"{x:1207,y:827,t:1527027277549};\\\", \\\"{x:1206,y:826,t:1527027277567};\\\", \\\"{x:1205,y:824,t:1527027277595};\\\", \\\"{x:1203,y:822,t:1527027277603};\\\", \\\"{x:1203,y:820,t:1527027277617};\\\", \\\"{x:1201,y:816,t:1527027277633};\\\", \\\"{x:1201,y:813,t:1527027277650};\\\", \\\"{x:1199,y:809,t:1527027277667};\\\", \\\"{x:1199,y:804,t:1527027277684};\\\", \\\"{x:1198,y:800,t:1527027277700};\\\", \\\"{x:1196,y:795,t:1527027277717};\\\", \\\"{x:1196,y:788,t:1527027277734};\\\", \\\"{x:1194,y:781,t:1527027277750};\\\", \\\"{x:1194,y:776,t:1527027277767};\\\", \\\"{x:1194,y:768,t:1527027277784};\\\", \\\"{x:1192,y:759,t:1527027277799};\\\", \\\"{x:1192,y:756,t:1527027277817};\\\", \\\"{x:1192,y:749,t:1527027277834};\\\", \\\"{x:1192,y:742,t:1527027277851};\\\", \\\"{x:1192,y:736,t:1527027277866};\\\", \\\"{x:1192,y:728,t:1527027277884};\\\", \\\"{x:1193,y:720,t:1527027277900};\\\", \\\"{x:1194,y:717,t:1527027277917};\\\", \\\"{x:1195,y:710,t:1527027277934};\\\", \\\"{x:1195,y:706,t:1527027277949};\\\", \\\"{x:1196,y:703,t:1527027277967};\\\", \\\"{x:1196,y:702,t:1527027277984};\\\", \\\"{x:1197,y:701,t:1527027278000};\\\", \\\"{x:1197,y:700,t:1527027278019};\\\", \\\"{x:1197,y:699,t:1527027278035};\\\", \\\"{x:1198,y:698,t:1527027278051};\\\", \\\"{x:1198,y:697,t:1527027278074};\\\", \\\"{x:1200,y:697,t:1527027278539};\\\", \\\"{x:1204,y:697,t:1527027278551};\\\", \\\"{x:1216,y:697,t:1527027278568};\\\", \\\"{x:1228,y:697,t:1527027278584};\\\", \\\"{x:1235,y:697,t:1527027278601};\\\", \\\"{x:1242,y:697,t:1527027278618};\\\", \\\"{x:1248,y:697,t:1527027278634};\\\", \\\"{x:1255,y:697,t:1527027278651};\\\", \\\"{x:1258,y:697,t:1527027278668};\\\", \\\"{x:1260,y:697,t:1527027278684};\\\", \\\"{x:1266,y:697,t:1527027278702};\\\", \\\"{x:1273,y:697,t:1527027278718};\\\", \\\"{x:1280,y:697,t:1527027278734};\\\", \\\"{x:1284,y:697,t:1527027278751};\\\", \\\"{x:1291,y:697,t:1527027278768};\\\", \\\"{x:1295,y:697,t:1527027278784};\\\", \\\"{x:1299,y:698,t:1527027278801};\\\", \\\"{x:1306,y:700,t:1527027278818};\\\", \\\"{x:1311,y:700,t:1527027278834};\\\", \\\"{x:1324,y:701,t:1527027278851};\\\", \\\"{x:1327,y:702,t:1527027278868};\\\", \\\"{x:1329,y:702,t:1527027278884};\\\", \\\"{x:1331,y:703,t:1527027278903};\\\", \\\"{x:1333,y:703,t:1527027278918};\\\", \\\"{x:1334,y:703,t:1527027278934};\\\", \\\"{x:1337,y:703,t:1527027278951};\\\", \\\"{x:1340,y:703,t:1527027278968};\\\", \\\"{x:1343,y:703,t:1527027278984};\\\", \\\"{x:1346,y:703,t:1527027279001};\\\", \\\"{x:1348,y:703,t:1527027279018};\\\", \\\"{x:1353,y:703,t:1527027279035};\\\", \\\"{x:1356,y:703,t:1527027279051};\\\", \\\"{x:1358,y:703,t:1527027279068};\\\", \\\"{x:1360,y:703,t:1527027279085};\\\", \\\"{x:1363,y:702,t:1527027279107};\\\", \\\"{x:1366,y:702,t:1527027279122};\\\", \\\"{x:1369,y:702,t:1527027279135};\\\", \\\"{x:1374,y:702,t:1527027279151};\\\", \\\"{x:1377,y:702,t:1527027279168};\\\", \\\"{x:1381,y:702,t:1527027279185};\\\", \\\"{x:1387,y:702,t:1527027279201};\\\", \\\"{x:1391,y:702,t:1527027279218};\\\", \\\"{x:1397,y:702,t:1527027279235};\\\", \\\"{x:1405,y:700,t:1527027279251};\\\", \\\"{x:1412,y:700,t:1527027279268};\\\", \\\"{x:1421,y:699,t:1527027279286};\\\", \\\"{x:1430,y:699,t:1527027279303};\\\", \\\"{x:1437,y:699,t:1527027279318};\\\", \\\"{x:1440,y:699,t:1527027279335};\\\", \\\"{x:1445,y:699,t:1527027279351};\\\", \\\"{x:1447,y:699,t:1527027279368};\\\", \\\"{x:1448,y:699,t:1527027279385};\\\", \\\"{x:1449,y:699,t:1527027279459};\\\", \\\"{x:1449,y:701,t:1527027279468};\\\", \\\"{x:1446,y:706,t:1527027279485};\\\", \\\"{x:1441,y:713,t:1527027279502};\\\", \\\"{x:1430,y:720,t:1527027279518};\\\", \\\"{x:1418,y:726,t:1527027279535};\\\", \\\"{x:1401,y:733,t:1527027279552};\\\", \\\"{x:1379,y:740,t:1527027279568};\\\", \\\"{x:1356,y:749,t:1527027279586};\\\", \\\"{x:1335,y:755,t:1527027279602};\\\", \\\"{x:1312,y:762,t:1527027279618};\\\", \\\"{x:1288,y:767,t:1527027279635};\\\", \\\"{x:1281,y:770,t:1527027279652};\\\", \\\"{x:1278,y:771,t:1527027279668};\\\", \\\"{x:1271,y:774,t:1527027279685};\\\", \\\"{x:1265,y:778,t:1527027279702};\\\", \\\"{x:1259,y:782,t:1527027279718};\\\", \\\"{x:1253,y:785,t:1527027279735};\\\", \\\"{x:1246,y:788,t:1527027279752};\\\", \\\"{x:1239,y:795,t:1527027279768};\\\", \\\"{x:1233,y:799,t:1527027279786};\\\", \\\"{x:1229,y:802,t:1527027279802};\\\", \\\"{x:1225,y:807,t:1527027279818};\\\", \\\"{x:1220,y:815,t:1527027279835};\\\", \\\"{x:1218,y:817,t:1527027279852};\\\", \\\"{x:1216,y:819,t:1527027279869};\\\", \\\"{x:1214,y:822,t:1527027279885};\\\", \\\"{x:1213,y:823,t:1527027279903};\\\", \\\"{x:1212,y:825,t:1527027279919};\\\", \\\"{x:1211,y:826,t:1527027279934};\\\", \\\"{x:1210,y:827,t:1527027279951};\\\", \\\"{x:1210,y:828,t:1527027279969};\\\", \\\"{x:1209,y:828,t:1527027279985};\\\", \\\"{x:1209,y:829,t:1527027280002};\\\", \\\"{x:1210,y:829,t:1527027280331};\\\", \\\"{x:1212,y:829,t:1527027280339};\\\", \\\"{x:1213,y:829,t:1527027280362};\\\", \\\"{x:1213,y:828,t:1527027280371};\\\", \\\"{x:1214,y:828,t:1527027281480};\\\", \\\"{x:1215,y:828,t:1527027281487};\\\", \\\"{x:1219,y:828,t:1527027282943};\\\", \\\"{x:1226,y:828,t:1527027282952};\\\", \\\"{x:1238,y:828,t:1527027282968};\\\", \\\"{x:1249,y:828,t:1527027282984};\\\", \\\"{x:1258,y:828,t:1527027283001};\\\", \\\"{x:1263,y:828,t:1527027283018};\\\", \\\"{x:1269,y:828,t:1527027283035};\\\", \\\"{x:1272,y:828,t:1527027283051};\\\", \\\"{x:1276,y:828,t:1527027283068};\\\", \\\"{x:1278,y:828,t:1527027283084};\\\", \\\"{x:1280,y:828,t:1527027283101};\\\", \\\"{x:1281,y:828,t:1527027283135};\\\", \\\"{x:1283,y:827,t:1527027283151};\\\", \\\"{x:1284,y:826,t:1527027283248};\\\", \\\"{x:1285,y:826,t:1527027283271};\\\", \\\"{x:1286,y:826,t:1527027283288};\\\", \\\"{x:1287,y:826,t:1527027283392};\\\", \\\"{x:1288,y:826,t:1527027283402};\\\", \\\"{x:1289,y:826,t:1527027283418};\\\", \\\"{x:1291,y:826,t:1527027283435};\\\", \\\"{x:1292,y:826,t:1527027283452};\\\", \\\"{x:1294,y:826,t:1527027283468};\\\", \\\"{x:1296,y:826,t:1527027283485};\\\", \\\"{x:1299,y:826,t:1527027283502};\\\", \\\"{x:1302,y:826,t:1527027283517};\\\", \\\"{x:1315,y:829,t:1527027283534};\\\", \\\"{x:1319,y:829,t:1527027283550};\\\", \\\"{x:1325,y:830,t:1527027283568};\\\", \\\"{x:1330,y:830,t:1527027283584};\\\", \\\"{x:1335,y:830,t:1527027283601};\\\", \\\"{x:1338,y:830,t:1527027283617};\\\", \\\"{x:1340,y:830,t:1527027283635};\\\", \\\"{x:1341,y:830,t:1527027283652};\\\", \\\"{x:1343,y:830,t:1527027283944};\\\", \\\"{x:1344,y:832,t:1527027283952};\\\", \\\"{x:1345,y:832,t:1527027283969};\\\", \\\"{x:1346,y:832,t:1527027283985};\\\", \\\"{x:1348,y:832,t:1527027284001};\\\", \\\"{x:1350,y:832,t:1527027284018};\\\", \\\"{x:1353,y:832,t:1527027284034};\\\", \\\"{x:1353,y:833,t:1527027284052};\\\", \\\"{x:1348,y:832,t:1527027285944};\\\", \\\"{x:1332,y:827,t:1527027285953};\\\", \\\"{x:1267,y:813,t:1527027285970};\\\", \\\"{x:1174,y:798,t:1527027285987};\\\", \\\"{x:1065,y:775,t:1527027286004};\\\", \\\"{x:973,y:758,t:1527027286020};\\\", \\\"{x:889,y:745,t:1527027286037};\\\", \\\"{x:828,y:737,t:1527027286053};\\\", \\\"{x:794,y:732,t:1527027286070};\\\", \\\"{x:751,y:727,t:1527027286087};\\\", \\\"{x:733,y:726,t:1527027286103};\\\", \\\"{x:716,y:726,t:1527027286119};\\\", \\\"{x:703,y:726,t:1527027286136};\\\", \\\"{x:691,y:723,t:1527027286154};\\\", \\\"{x:676,y:721,t:1527027286169};\\\", \\\"{x:655,y:716,t:1527027286186};\\\", \\\"{x:634,y:714,t:1527027286203};\\\", \\\"{x:616,y:711,t:1527027286219};\\\", \\\"{x:600,y:707,t:1527027286237};\\\", \\\"{x:597,y:705,t:1527027286253};\\\", \\\"{x:596,y:703,t:1527027286270};\\\", \\\"{x:593,y:696,t:1527027286287};\\\", \\\"{x:592,y:691,t:1527027286303};\\\", \\\"{x:592,y:685,t:1527027286320};\\\", \\\"{x:592,y:680,t:1527027286336};\\\", \\\"{x:592,y:671,t:1527027286353};\\\", \\\"{x:596,y:663,t:1527027286370};\\\", \\\"{x:600,y:659,t:1527027286387};\\\", \\\"{x:607,y:652,t:1527027286404};\\\", \\\"{x:619,y:647,t:1527027286422};\\\", \\\"{x:627,y:644,t:1527027286436};\\\", \\\"{x:634,y:638,t:1527027286469};\\\", \\\"{x:634,y:637,t:1527027286480};\\\", \\\"{x:634,y:635,t:1527027286498};\\\", \\\"{x:634,y:634,t:1527027286518};\\\", \\\"{x:630,y:634,t:1527027286530};\\\", \\\"{x:612,y:633,t:1527027286548};\\\", \\\"{x:586,y:633,t:1527027286565};\\\", \\\"{x:547,y:633,t:1527027286580};\\\", \\\"{x:477,y:632,t:1527027286604};\\\", \\\"{x:429,y:624,t:1527027286621};\\\", \\\"{x:402,y:618,t:1527027286638};\\\", \\\"{x:381,y:615,t:1527027286653};\\\", \\\"{x:370,y:614,t:1527027286671};\\\", \\\"{x:365,y:614,t:1527027286687};\\\", \\\"{x:357,y:614,t:1527027286704};\\\", \\\"{x:350,y:615,t:1527027286720};\\\", \\\"{x:337,y:615,t:1527027286737};\\\", \\\"{x:320,y:618,t:1527027286753};\\\", \\\"{x:306,y:621,t:1527027286771};\\\", \\\"{x:290,y:622,t:1527027286788};\\\", \\\"{x:269,y:623,t:1527027286804};\\\", \\\"{x:253,y:625,t:1527027286820};\\\", \\\"{x:242,y:625,t:1527027286838};\\\", \\\"{x:232,y:625,t:1527027286854};\\\", \\\"{x:216,y:625,t:1527027286871};\\\", \\\"{x:201,y:625,t:1527027286887};\\\", \\\"{x:187,y:625,t:1527027286904};\\\", \\\"{x:175,y:623,t:1527027286920};\\\", \\\"{x:168,y:621,t:1527027286937};\\\", \\\"{x:165,y:620,t:1527027286953};\\\", \\\"{x:160,y:618,t:1527027286971};\\\", \\\"{x:157,y:614,t:1527027286987};\\\", \\\"{x:148,y:606,t:1527027287003};\\\", \\\"{x:142,y:602,t:1527027287021};\\\", \\\"{x:139,y:600,t:1527027287037};\\\", \\\"{x:139,y:599,t:1527027287053};\\\", \\\"{x:137,y:593,t:1527027287070};\\\", \\\"{x:137,y:587,t:1527027287087};\\\", \\\"{x:137,y:582,t:1527027287105};\\\", \\\"{x:137,y:579,t:1527027287121};\\\", \\\"{x:138,y:575,t:1527027287137};\\\", \\\"{x:139,y:574,t:1527027287157};\\\", \\\"{x:140,y:574,t:1527027287170};\\\", \\\"{x:143,y:571,t:1527027287188};\\\", \\\"{x:150,y:568,t:1527027287205};\\\", \\\"{x:155,y:566,t:1527027287220};\\\", \\\"{x:161,y:564,t:1527027287237};\\\", \\\"{x:164,y:563,t:1527027287255};\\\", \\\"{x:164,y:562,t:1527027287294};\\\", \\\"{x:165,y:561,t:1527027287310};\\\", \\\"{x:166,y:560,t:1527027287321};\\\", \\\"{x:167,y:560,t:1527027287338};\\\", \\\"{x:167,y:559,t:1527027287354};\\\", \\\"{x:168,y:559,t:1527027287539};\\\", \\\"{x:169,y:558,t:1527027287555};\\\", \\\"{x:170,y:558,t:1527027287575};\\\", \\\"{x:170,y:558,t:1527027287607};\\\", \\\"{x:173,y:558,t:1527027287695};\\\", \\\"{x:179,y:562,t:1527027287704};\\\", \\\"{x:194,y:570,t:1527027287722};\\\", \\\"{x:217,y:584,t:1527027287738};\\\", \\\"{x:242,y:598,t:1527027287754};\\\", \\\"{x:277,y:617,t:1527027287772};\\\", \\\"{x:304,y:633,t:1527027287788};\\\", \\\"{x:329,y:648,t:1527027287805};\\\", \\\"{x:353,y:661,t:1527027287822};\\\", \\\"{x:385,y:676,t:1527027287839};\\\", \\\"{x:405,y:686,t:1527027287854};\\\", \\\"{x:419,y:693,t:1527027287871};\\\", \\\"{x:434,y:700,t:1527027287888};\\\", \\\"{x:449,y:705,t:1527027287905};\\\", \\\"{x:458,y:709,t:1527027287922};\\\", \\\"{x:462,y:709,t:1527027287937};\\\", \\\"{x:463,y:710,t:1527027287954};\\\", \\\"{x:465,y:710,t:1527027287972};\\\", \\\"{x:466,y:710,t:1527027287988};\\\", \\\"{x:468,y:710,t:1527027288005};\\\", \\\"{x:470,y:710,t:1527027288022};\\\", \\\"{x:473,y:709,t:1527027288038};\\\", \\\"{x:476,y:707,t:1527027288055};\\\", \\\"{x:479,y:706,t:1527027288071};\\\", \\\"{x:481,y:704,t:1527027288088};\\\", \\\"{x:483,y:703,t:1527027288105};\\\", \\\"{x:483,y:702,t:1527027288121};\\\", \\\"{x:482,y:698,t:1527027288139};\\\", \\\"{x:466,y:691,t:1527027288155};\\\", \\\"{x:441,y:683,t:1527027288171};\\\", \\\"{x:397,y:670,t:1527027288188};\\\", \\\"{x:347,y:656,t:1527027288205};\\\", \\\"{x:286,y:637,t:1527027288222};\\\", \\\"{x:224,y:612,t:1527027288239};\\\", \\\"{x:207,y:603,t:1527027288255};\\\", \\\"{x:193,y:595,t:1527027288271};\\\", \\\"{x:186,y:590,t:1527027288288};\\\", \\\"{x:183,y:588,t:1527027288304};\\\", \\\"{x:183,y:587,t:1527027288326};\\\", \\\"{x:183,y:586,t:1527027288338};\\\", \\\"{x:183,y:585,t:1527027288355};\\\", \\\"{x:183,y:583,t:1527027288372};\\\", \\\"{x:181,y:581,t:1527027288390};\\\", \\\"{x:181,y:578,t:1527027288406};\\\", \\\"{x:179,y:577,t:1527027288422};\\\", \\\"{x:179,y:575,t:1527027288480};\\\", \\\"{x:179,y:574,t:1527027288496};\\\", \\\"{x:179,y:572,t:1527027288526};\\\", \\\"{x:179,y:571,t:1527027288538};\\\", \\\"{x:179,y:570,t:1527027288555};\\\", \\\"{x:178,y:569,t:1527027288573};\\\", \\\"{x:177,y:568,t:1527027288589};\\\", \\\"{x:175,y:567,t:1527027288606};\\\", \\\"{x:172,y:567,t:1527027288621};\\\", \\\"{x:168,y:564,t:1527027288639};\\\", \\\"{x:166,y:564,t:1527027288656};\\\", \\\"{x:165,y:563,t:1527027288711};\\\", \\\"{x:164,y:562,t:1527027288722};\\\", \\\"{x:163,y:562,t:1527027288739};\\\", \\\"{x:162,y:562,t:1527027288756};\\\", \\\"{x:162,y:561,t:1527027288775};\\\", \\\"{x:163,y:561,t:1527027288998};\\\", \\\"{x:166,y:561,t:1527027289006};\\\", \\\"{x:177,y:564,t:1527027289023};\\\", \\\"{x:193,y:571,t:1527027289039};\\\", \\\"{x:215,y:580,t:1527027289056};\\\", \\\"{x:245,y:597,t:1527027289073};\\\", \\\"{x:272,y:612,t:1527027289089};\\\", \\\"{x:306,y:630,t:1527027289106};\\\", \\\"{x:338,y:645,t:1527027289123};\\\", \\\"{x:362,y:657,t:1527027289139};\\\", \\\"{x:387,y:671,t:1527027289156};\\\", \\\"{x:408,y:683,t:1527027289172};\\\", \\\"{x:424,y:690,t:1527027289189};\\\", \\\"{x:436,y:695,t:1527027289206};\\\", \\\"{x:445,y:699,t:1527027289223};\\\", \\\"{x:448,y:701,t:1527027289239};\\\", \\\"{x:450,y:701,t:1527027289256};\\\", \\\"{x:451,y:702,t:1527027289273};\\\", \\\"{x:452,y:702,t:1527027289290};\\\", \\\"{x:454,y:703,t:1527027289306};\\\", \\\"{x:455,y:703,t:1527027289323};\\\", \\\"{x:458,y:704,t:1527027289340};\\\", \\\"{x:459,y:704,t:1527027289355};\\\", \\\"{x:459,y:705,t:1527027289373};\\\", \\\"{x:460,y:705,t:1527027289407};\\\", \\\"{x:463,y:707,t:1527027289423};\\\", \\\"{x:469,y:712,t:1527027289439};\\\", \\\"{x:477,y:718,t:1527027289455};\\\", \\\"{x:486,y:725,t:1527027289473};\\\", \\\"{x:494,y:731,t:1527027289489};\\\", \\\"{x:498,y:734,t:1527027289506};\\\", \\\"{x:499,y:734,t:1527027289523};\\\" ] }, { \\\"rt\\\": 44343, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 173333, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"C30CF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-2-12 PM-01 PM-03 PM-04 PM-04 PM-U -03 PM-K -K -F -F -A -O -O -K -K -I -I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:501,y:734,t:1527027291848};\\\", \\\"{x:503,y:736,t:1527027291864};\\\", \\\"{x:509,y:738,t:1527027291878};\\\", \\\"{x:516,y:743,t:1527027291891};\\\", \\\"{x:536,y:750,t:1527027291907};\\\", \\\"{x:558,y:756,t:1527027291925};\\\", \\\"{x:584,y:763,t:1527027291942};\\\", \\\"{x:613,y:769,t:1527027291958};\\\", \\\"{x:649,y:779,t:1527027291974};\\\", \\\"{x:676,y:785,t:1527027291992};\\\", \\\"{x:702,y:790,t:1527027292008};\\\", \\\"{x:732,y:798,t:1527027292025};\\\", \\\"{x:762,y:803,t:1527027292042};\\\", \\\"{x:804,y:809,t:1527027292057};\\\", \\\"{x:844,y:816,t:1527027292075};\\\", \\\"{x:889,y:822,t:1527027292092};\\\", \\\"{x:928,y:827,t:1527027292108};\\\", \\\"{x:954,y:831,t:1527027292125};\\\", \\\"{x:976,y:834,t:1527027292142};\\\", \\\"{x:989,y:835,t:1527027292158};\\\", \\\"{x:1001,y:835,t:1527027292175};\\\", \\\"{x:1005,y:835,t:1527027292192};\\\", \\\"{x:1007,y:835,t:1527027292209};\\\", \\\"{x:1008,y:835,t:1527027292226};\\\", \\\"{x:1006,y:826,t:1527027292243};\\\", \\\"{x:1007,y:824,t:1527027292703};\\\", \\\"{x:1012,y:824,t:1527027292711};\\\", \\\"{x:1017,y:824,t:1527027292727};\\\", \\\"{x:1031,y:824,t:1527027292743};\\\", \\\"{x:1058,y:829,t:1527027292759};\\\", \\\"{x:1082,y:838,t:1527027292777};\\\", \\\"{x:1116,y:847,t:1527027292793};\\\", \\\"{x:1144,y:855,t:1527027292809};\\\", \\\"{x:1176,y:863,t:1527027292826};\\\", \\\"{x:1201,y:869,t:1527027292843};\\\", \\\"{x:1225,y:876,t:1527027292859};\\\", \\\"{x:1247,y:882,t:1527027292876};\\\", \\\"{x:1264,y:889,t:1527027292892};\\\", \\\"{x:1283,y:897,t:1527027292909};\\\", \\\"{x:1295,y:902,t:1527027292926};\\\", \\\"{x:1302,y:906,t:1527027292943};\\\", \\\"{x:1308,y:911,t:1527027292960};\\\", \\\"{x:1313,y:916,t:1527027292976};\\\", \\\"{x:1317,y:923,t:1527027292992};\\\", \\\"{x:1324,y:933,t:1527027293009};\\\", \\\"{x:1333,y:942,t:1527027293027};\\\", \\\"{x:1339,y:949,t:1527027293043};\\\", \\\"{x:1346,y:959,t:1527027293059};\\\", \\\"{x:1349,y:963,t:1527027293077};\\\", \\\"{x:1352,y:967,t:1527027293094};\\\", \\\"{x:1352,y:968,t:1527027293109};\\\", \\\"{x:1353,y:969,t:1527027293127};\\\", \\\"{x:1354,y:972,t:1527027293143};\\\", \\\"{x:1355,y:973,t:1527027293159};\\\", \\\"{x:1356,y:974,t:1527027293183};\\\", \\\"{x:1356,y:975,t:1527027293194};\\\", \\\"{x:1356,y:976,t:1527027293209};\\\", \\\"{x:1357,y:976,t:1527027293227};\\\", \\\"{x:1358,y:977,t:1527027293248};\\\", \\\"{x:1360,y:977,t:1527027293295};\\\", \\\"{x:1361,y:977,t:1527027293311};\\\", \\\"{x:1363,y:977,t:1527027293327};\\\", \\\"{x:1373,y:980,t:1527027293343};\\\", \\\"{x:1385,y:981,t:1527027293359};\\\", \\\"{x:1402,y:982,t:1527027293377};\\\", \\\"{x:1417,y:982,t:1527027293393};\\\", \\\"{x:1433,y:982,t:1527027293410};\\\", \\\"{x:1449,y:985,t:1527027293426};\\\", \\\"{x:1460,y:986,t:1527027293444};\\\", \\\"{x:1466,y:986,t:1527027293460};\\\", \\\"{x:1471,y:986,t:1527027293476};\\\", \\\"{x:1473,y:986,t:1527027293492};\\\", \\\"{x:1475,y:986,t:1527027293510};\\\", \\\"{x:1480,y:986,t:1527027293526};\\\", \\\"{x:1500,y:986,t:1527027293543};\\\", \\\"{x:1514,y:986,t:1527027293560};\\\", \\\"{x:1527,y:986,t:1527027293575};\\\", \\\"{x:1536,y:986,t:1527027293593};\\\", \\\"{x:1539,y:986,t:1527027293610};\\\", \\\"{x:1541,y:986,t:1527027293626};\\\", \\\"{x:1542,y:986,t:1527027293662};\\\", \\\"{x:1543,y:985,t:1527027293695};\\\", \\\"{x:1544,y:985,t:1527027293710};\\\", \\\"{x:1546,y:984,t:1527027293752};\\\", \\\"{x:1547,y:984,t:1527027293775};\\\", \\\"{x:1549,y:984,t:1527027293794};\\\", \\\"{x:1550,y:984,t:1527027293811};\\\", \\\"{x:1552,y:983,t:1527027293827};\\\", \\\"{x:1553,y:983,t:1527027293844};\\\", \\\"{x:1556,y:981,t:1527027293860};\\\", \\\"{x:1558,y:981,t:1527027293876};\\\", \\\"{x:1560,y:981,t:1527027293893};\\\", \\\"{x:1563,y:981,t:1527027293909};\\\", \\\"{x:1565,y:981,t:1527027293926};\\\", \\\"{x:1568,y:981,t:1527027293943};\\\", \\\"{x:1572,y:981,t:1527027293960};\\\", \\\"{x:1575,y:981,t:1527027293977};\\\", \\\"{x:1580,y:981,t:1527027293993};\\\", \\\"{x:1584,y:981,t:1527027294010};\\\", \\\"{x:1589,y:981,t:1527027294027};\\\", \\\"{x:1595,y:981,t:1527027294043};\\\", \\\"{x:1601,y:981,t:1527027294060};\\\", \\\"{x:1605,y:981,t:1527027294077};\\\", \\\"{x:1609,y:981,t:1527027294093};\\\", \\\"{x:1609,y:980,t:1527027294111};\\\", \\\"{x:1610,y:980,t:1527027294126};\\\", \\\"{x:1610,y:979,t:1527027294143};\\\", \\\"{x:1611,y:978,t:1527027294160};\\\", \\\"{x:1613,y:976,t:1527027294177};\\\", \\\"{x:1615,y:975,t:1527027294193};\\\", \\\"{x:1615,y:974,t:1527027294211};\\\", \\\"{x:1616,y:973,t:1527027294227};\\\", \\\"{x:1616,y:972,t:1527027294303};\\\", \\\"{x:1616,y:970,t:1527027294712};\\\", \\\"{x:1616,y:969,t:1527027294727};\\\", \\\"{x:1616,y:968,t:1527027294745};\\\", \\\"{x:1615,y:967,t:1527027294762};\\\", \\\"{x:1615,y:964,t:1527027294777};\\\", \\\"{x:1614,y:960,t:1527027294795};\\\", \\\"{x:1613,y:957,t:1527027294812};\\\", \\\"{x:1612,y:955,t:1527027294827};\\\", \\\"{x:1611,y:952,t:1527027294844};\\\", \\\"{x:1611,y:950,t:1527027294860};\\\", \\\"{x:1610,y:949,t:1527027294877};\\\", \\\"{x:1609,y:947,t:1527027294894};\\\", \\\"{x:1609,y:946,t:1527027294910};\\\", \\\"{x:1609,y:945,t:1527027294926};\\\", \\\"{x:1609,y:944,t:1527027294944};\\\", \\\"{x:1608,y:942,t:1527027294961};\\\", \\\"{x:1608,y:941,t:1527027294977};\\\", \\\"{x:1608,y:940,t:1527027294994};\\\", \\\"{x:1608,y:939,t:1527027295023};\\\", \\\"{x:1608,y:938,t:1527027295046};\\\", \\\"{x:1608,y:939,t:1527027296175};\\\", \\\"{x:1608,y:940,t:1527027296214};\\\", \\\"{x:1608,y:941,t:1527027296239};\\\", \\\"{x:1608,y:942,t:1527027296263};\\\", \\\"{x:1608,y:943,t:1527027296279};\\\", \\\"{x:1609,y:946,t:1527027296295};\\\", \\\"{x:1610,y:948,t:1527027296313};\\\", \\\"{x:1610,y:951,t:1527027296329};\\\", \\\"{x:1612,y:953,t:1527027296345};\\\", \\\"{x:1612,y:954,t:1527027296363};\\\", \\\"{x:1612,y:955,t:1527027296380};\\\", \\\"{x:1612,y:956,t:1527027296395};\\\", \\\"{x:1612,y:957,t:1527027296413};\\\", \\\"{x:1612,y:959,t:1527027296430};\\\", \\\"{x:1612,y:960,t:1527027296446};\\\", \\\"{x:1613,y:962,t:1527027296463};\\\", \\\"{x:1613,y:963,t:1527027296479};\\\", \\\"{x:1613,y:965,t:1527027296552};\\\", \\\"{x:1613,y:966,t:1527027296631};\\\", \\\"{x:1613,y:968,t:1527027296671};\\\", \\\"{x:1613,y:969,t:1527027296695};\\\", \\\"{x:1612,y:969,t:1527027296712};\\\", \\\"{x:1612,y:971,t:1527027296729};\\\", \\\"{x:1612,y:972,t:1527027297080};\\\", \\\"{x:1608,y:972,t:1527027297097};\\\", \\\"{x:1596,y:972,t:1527027297113};\\\", \\\"{x:1580,y:970,t:1527027297130};\\\", \\\"{x:1565,y:967,t:1527027297146};\\\", \\\"{x:1554,y:966,t:1527027297164};\\\", \\\"{x:1547,y:965,t:1527027297179};\\\", \\\"{x:1545,y:964,t:1527027297198};\\\", \\\"{x:1544,y:964,t:1527027297214};\\\", \\\"{x:1543,y:964,t:1527027297255};\\\", \\\"{x:1542,y:964,t:1527027297263};\\\", \\\"{x:1540,y:964,t:1527027297279};\\\", \\\"{x:1539,y:964,t:1527027297303};\\\", \\\"{x:1538,y:964,t:1527027297808};\\\", \\\"{x:1536,y:964,t:1527027297815};\\\", \\\"{x:1534,y:964,t:1527027297831};\\\", \\\"{x:1530,y:964,t:1527027297847};\\\", \\\"{x:1525,y:964,t:1527027297863};\\\", \\\"{x:1522,y:964,t:1527027297880};\\\", \\\"{x:1519,y:964,t:1527027297897};\\\", \\\"{x:1515,y:964,t:1527027297914};\\\", \\\"{x:1507,y:964,t:1527027297931};\\\", \\\"{x:1499,y:964,t:1527027297947};\\\", \\\"{x:1491,y:964,t:1527027297964};\\\", \\\"{x:1487,y:964,t:1527027297980};\\\", \\\"{x:1484,y:964,t:1527027297996};\\\", \\\"{x:1483,y:964,t:1527027298014};\\\", \\\"{x:1482,y:964,t:1527027298031};\\\", \\\"{x:1480,y:964,t:1527027298048};\\\", \\\"{x:1480,y:965,t:1527027298095};\\\", \\\"{x:1479,y:966,t:1527027298136};\\\", \\\"{x:1479,y:967,t:1527027298175};\\\", \\\"{x:1478,y:966,t:1527027298256};\\\", \\\"{x:1477,y:962,t:1527027298263};\\\", \\\"{x:1477,y:955,t:1527027298281};\\\", \\\"{x:1475,y:945,t:1527027298297};\\\", \\\"{x:1473,y:937,t:1527027298314};\\\", \\\"{x:1473,y:928,t:1527027298331};\\\", \\\"{x:1473,y:920,t:1527027298347};\\\", \\\"{x:1473,y:911,t:1527027298363};\\\", \\\"{x:1474,y:902,t:1527027298381};\\\", \\\"{x:1477,y:897,t:1527027298398};\\\", \\\"{x:1478,y:891,t:1527027298415};\\\", \\\"{x:1479,y:885,t:1527027298430};\\\", \\\"{x:1481,y:878,t:1527027298448};\\\", \\\"{x:1483,y:873,t:1527027298465};\\\", \\\"{x:1485,y:869,t:1527027298481};\\\", \\\"{x:1487,y:865,t:1527027298499};\\\", \\\"{x:1487,y:862,t:1527027298515};\\\", \\\"{x:1489,y:855,t:1527027298530};\\\", \\\"{x:1489,y:850,t:1527027298547};\\\", \\\"{x:1489,y:848,t:1527027298564};\\\", \\\"{x:1489,y:847,t:1527027298607};\\\", \\\"{x:1489,y:845,t:1527027298639};\\\", \\\"{x:1489,y:844,t:1527027298663};\\\", \\\"{x:1488,y:844,t:1527027298680};\\\", \\\"{x:1488,y:842,t:1527027298758};\\\", \\\"{x:1486,y:841,t:1527027298766};\\\", \\\"{x:1486,y:840,t:1527027298781};\\\", \\\"{x:1484,y:839,t:1527027298797};\\\", \\\"{x:1484,y:838,t:1527027298814};\\\", \\\"{x:1483,y:837,t:1527027298831};\\\", \\\"{x:1483,y:835,t:1527027298896};\\\", \\\"{x:1482,y:835,t:1527027298914};\\\", \\\"{x:1481,y:834,t:1527027298931};\\\", \\\"{x:1480,y:832,t:1527027298946};\\\", \\\"{x:1479,y:831,t:1527027298966};\\\", \\\"{x:1479,y:829,t:1527027299007};\\\", \\\"{x:1477,y:829,t:1527027299143};\\\", \\\"{x:1477,y:828,t:1527027299159};\\\", \\\"{x:1476,y:828,t:1527027299392};\\\", \\\"{x:1473,y:828,t:1527027301729};\\\", \\\"{x:1458,y:828,t:1527027301735};\\\", \\\"{x:1376,y:811,t:1527027301751};\\\", \\\"{x:1264,y:791,t:1527027301767};\\\", \\\"{x:1138,y:764,t:1527027301783};\\\", \\\"{x:993,y:731,t:1527027301801};\\\", \\\"{x:850,y:694,t:1527027301817};\\\", \\\"{x:712,y:660,t:1527027301833};\\\", \\\"{x:590,y:626,t:1527027301852};\\\", \\\"{x:491,y:598,t:1527027301866};\\\", \\\"{x:395,y:571,t:1527027301900};\\\", \\\"{x:369,y:563,t:1527027301916};\\\", \\\"{x:349,y:554,t:1527027301932};\\\", \\\"{x:331,y:550,t:1527027301949};\\\", \\\"{x:309,y:542,t:1527027301966};\\\", \\\"{x:304,y:541,t:1527027301983};\\\", \\\"{x:302,y:540,t:1527027301999};\\\", \\\"{x:301,y:540,t:1527027302017};\\\", \\\"{x:301,y:539,t:1527027302047};\\\", \\\"{x:301,y:538,t:1527027302055};\\\", \\\"{x:301,y:537,t:1527027302066};\\\", \\\"{x:301,y:535,t:1527027302083};\\\", \\\"{x:305,y:532,t:1527027302099};\\\", \\\"{x:315,y:531,t:1527027302117};\\\", \\\"{x:331,y:531,t:1527027302134};\\\", \\\"{x:356,y:534,t:1527027302149};\\\", \\\"{x:404,y:548,t:1527027302167};\\\", \\\"{x:444,y:561,t:1527027302184};\\\", \\\"{x:472,y:568,t:1527027302199};\\\", \\\"{x:499,y:577,t:1527027302217};\\\", \\\"{x:520,y:585,t:1527027302234};\\\", \\\"{x:535,y:591,t:1527027302249};\\\", \\\"{x:540,y:594,t:1527027302267};\\\", \\\"{x:542,y:594,t:1527027302283};\\\", \\\"{x:547,y:596,t:1527027302299};\\\", \\\"{x:550,y:596,t:1527027302317};\\\", \\\"{x:553,y:596,t:1527027302333};\\\", \\\"{x:559,y:596,t:1527027302350};\\\", \\\"{x:570,y:597,t:1527027302367};\\\", \\\"{x:577,y:598,t:1527027302383};\\\", \\\"{x:578,y:598,t:1527027302399};\\\", \\\"{x:579,y:598,t:1527027302416};\\\", \\\"{x:580,y:598,t:1527027302463};\\\", \\\"{x:583,y:598,t:1527027302479};\\\", \\\"{x:584,y:598,t:1527027302487};\\\", \\\"{x:586,y:598,t:1527027302500};\\\", \\\"{x:589,y:598,t:1527027302516};\\\", \\\"{x:593,y:598,t:1527027302534};\\\", \\\"{x:596,y:598,t:1527027302551};\\\", \\\"{x:597,y:598,t:1527027302567};\\\", \\\"{x:605,y:601,t:1527027302584};\\\", \\\"{x:614,y:603,t:1527027302600};\\\", \\\"{x:624,y:605,t:1527027302616};\\\", \\\"{x:628,y:605,t:1527027302633};\\\", \\\"{x:629,y:605,t:1527027302650};\\\", \\\"{x:627,y:605,t:1527027302895};\\\", \\\"{x:624,y:605,t:1527027302902};\\\", \\\"{x:622,y:605,t:1527027302918};\\\", \\\"{x:619,y:604,t:1527027302934};\\\", \\\"{x:617,y:603,t:1527027302951};\\\", \\\"{x:617,y:602,t:1527027303703};\\\", \\\"{x:619,y:603,t:1527027303718};\\\", \\\"{x:640,y:612,t:1527027303734};\\\", \\\"{x:661,y:620,t:1527027303752};\\\", \\\"{x:684,y:631,t:1527027303767};\\\", \\\"{x:709,y:641,t:1527027303784};\\\", \\\"{x:738,y:654,t:1527027303802};\\\", \\\"{x:779,y:671,t:1527027303817};\\\", \\\"{x:818,y:689,t:1527027303834};\\\", \\\"{x:860,y:707,t:1527027303852};\\\", \\\"{x:901,y:724,t:1527027303867};\\\", \\\"{x:947,y:748,t:1527027303885};\\\", \\\"{x:994,y:768,t:1527027303901};\\\", \\\"{x:1031,y:782,t:1527027303917};\\\", \\\"{x:1079,y:801,t:1527027303934};\\\", \\\"{x:1109,y:817,t:1527027303952};\\\", \\\"{x:1138,y:829,t:1527027303967};\\\", \\\"{x:1162,y:838,t:1527027303984};\\\", \\\"{x:1187,y:847,t:1527027304002};\\\", \\\"{x:1210,y:857,t:1527027304017};\\\", \\\"{x:1234,y:866,t:1527027304035};\\\", \\\"{x:1257,y:877,t:1527027304052};\\\", \\\"{x:1286,y:884,t:1527027304068};\\\", \\\"{x:1317,y:895,t:1527027304085};\\\", \\\"{x:1342,y:901,t:1527027304102};\\\", \\\"{x:1360,y:906,t:1527027304118};\\\", \\\"{x:1385,y:912,t:1527027304135};\\\", \\\"{x:1400,y:915,t:1527027304152};\\\", \\\"{x:1414,y:920,t:1527027304169};\\\", \\\"{x:1427,y:923,t:1527027304184};\\\", \\\"{x:1433,y:925,t:1527027304202};\\\", \\\"{x:1437,y:926,t:1527027304219};\\\", \\\"{x:1439,y:926,t:1527027304235};\\\", \\\"{x:1440,y:926,t:1527027304256};\\\", \\\"{x:1442,y:928,t:1527027304269};\\\", \\\"{x:1446,y:928,t:1527027304285};\\\", \\\"{x:1453,y:930,t:1527027304303};\\\", \\\"{x:1461,y:933,t:1527027304319};\\\", \\\"{x:1467,y:933,t:1527027304336};\\\", \\\"{x:1470,y:934,t:1527027304352};\\\", \\\"{x:1477,y:937,t:1527027304369};\\\", \\\"{x:1487,y:941,t:1527027304385};\\\", \\\"{x:1499,y:946,t:1527027304402};\\\", \\\"{x:1506,y:948,t:1527027304419};\\\", \\\"{x:1510,y:948,t:1527027304435};\\\", \\\"{x:1512,y:948,t:1527027304480};\\\", \\\"{x:1514,y:949,t:1527027304495};\\\", \\\"{x:1516,y:949,t:1527027304503};\\\", \\\"{x:1525,y:951,t:1527027304518};\\\", \\\"{x:1533,y:951,t:1527027304535};\\\", \\\"{x:1542,y:954,t:1527027304551};\\\", \\\"{x:1551,y:955,t:1527027304569};\\\", \\\"{x:1554,y:955,t:1527027304585};\\\", \\\"{x:1555,y:956,t:1527027304602};\\\", \\\"{x:1556,y:956,t:1527027304618};\\\", \\\"{x:1557,y:956,t:1527027304646};\\\", \\\"{x:1558,y:956,t:1527027304743};\\\", \\\"{x:1558,y:957,t:1527027304792};\\\", \\\"{x:1558,y:958,t:1527027304815};\\\", \\\"{x:1558,y:959,t:1527027304823};\\\", \\\"{x:1558,y:960,t:1527027304836};\\\", \\\"{x:1558,y:961,t:1527027304851};\\\", \\\"{x:1558,y:962,t:1527027304869};\\\", \\\"{x:1558,y:964,t:1527027304887};\\\", \\\"{x:1557,y:967,t:1527027304903};\\\", \\\"{x:1556,y:968,t:1527027304919};\\\", \\\"{x:1556,y:969,t:1527027304936};\\\", \\\"{x:1555,y:970,t:1527027304952};\\\", \\\"{x:1555,y:971,t:1527027304969};\\\", \\\"{x:1554,y:971,t:1527027304986};\\\", \\\"{x:1555,y:971,t:1527027305223};\\\", \\\"{x:1556,y:969,t:1527027305236};\\\", \\\"{x:1558,y:968,t:1527027305254};\\\", \\\"{x:1561,y:966,t:1527027305269};\\\", \\\"{x:1564,y:965,t:1527027305286};\\\", \\\"{x:1571,y:963,t:1527027305303};\\\", \\\"{x:1576,y:963,t:1527027305319};\\\", \\\"{x:1580,y:962,t:1527027305337};\\\", \\\"{x:1584,y:962,t:1527027305353};\\\", \\\"{x:1590,y:962,t:1527027305369};\\\", \\\"{x:1593,y:962,t:1527027305386};\\\", \\\"{x:1597,y:962,t:1527027305403};\\\", \\\"{x:1601,y:962,t:1527027305419};\\\", \\\"{x:1605,y:962,t:1527027305436};\\\", \\\"{x:1607,y:961,t:1527027305453};\\\", \\\"{x:1612,y:960,t:1527027305469};\\\", \\\"{x:1613,y:959,t:1527027305486};\\\", \\\"{x:1614,y:959,t:1527027305503};\\\", \\\"{x:1615,y:959,t:1527027305535};\\\", \\\"{x:1615,y:958,t:1527027306110};\\\", \\\"{x:1615,y:956,t:1527027306119};\\\", \\\"{x:1615,y:952,t:1527027306137};\\\", \\\"{x:1615,y:949,t:1527027306152};\\\", \\\"{x:1611,y:942,t:1527027306169};\\\", \\\"{x:1610,y:936,t:1527027306186};\\\", \\\"{x:1607,y:931,t:1527027306203};\\\", \\\"{x:1607,y:928,t:1527027306219};\\\", \\\"{x:1606,y:924,t:1527027306236};\\\", \\\"{x:1605,y:921,t:1527027306252};\\\", \\\"{x:1605,y:917,t:1527027306270};\\\", \\\"{x:1603,y:909,t:1527027306287};\\\", \\\"{x:1602,y:904,t:1527027306303};\\\", \\\"{x:1602,y:903,t:1527027306320};\\\", \\\"{x:1602,y:901,t:1527027306342};\\\", \\\"{x:1602,y:899,t:1527027306354};\\\", \\\"{x:1600,y:893,t:1527027306370};\\\", \\\"{x:1599,y:889,t:1527027306386};\\\", \\\"{x:1599,y:884,t:1527027306404};\\\", \\\"{x:1599,y:877,t:1527027306420};\\\", \\\"{x:1599,y:873,t:1527027306437};\\\", \\\"{x:1599,y:867,t:1527027306454};\\\", \\\"{x:1599,y:865,t:1527027306470};\\\", \\\"{x:1599,y:859,t:1527027306487};\\\", \\\"{x:1599,y:857,t:1527027306503};\\\", \\\"{x:1599,y:855,t:1527027306520};\\\", \\\"{x:1599,y:852,t:1527027306537};\\\", \\\"{x:1599,y:850,t:1527027306553};\\\", \\\"{x:1599,y:848,t:1527027306570};\\\", \\\"{x:1599,y:846,t:1527027306586};\\\", \\\"{x:1599,y:843,t:1527027306604};\\\", \\\"{x:1599,y:840,t:1527027306620};\\\", \\\"{x:1598,y:836,t:1527027306637};\\\", \\\"{x:1598,y:834,t:1527027306654};\\\", \\\"{x:1598,y:830,t:1527027306670};\\\", \\\"{x:1598,y:826,t:1527027306687};\\\", \\\"{x:1598,y:822,t:1527027306704};\\\", \\\"{x:1598,y:817,t:1527027306719};\\\", \\\"{x:1596,y:813,t:1527027306737};\\\", \\\"{x:1596,y:809,t:1527027306754};\\\", \\\"{x:1595,y:804,t:1527027306770};\\\", \\\"{x:1595,y:801,t:1527027306787};\\\", \\\"{x:1595,y:796,t:1527027306804};\\\", \\\"{x:1594,y:794,t:1527027306821};\\\", \\\"{x:1594,y:791,t:1527027306837};\\\", \\\"{x:1594,y:790,t:1527027306854};\\\", \\\"{x:1593,y:784,t:1527027306871};\\\", \\\"{x:1593,y:781,t:1527027306887};\\\", \\\"{x:1593,y:778,t:1527027306904};\\\", \\\"{x:1593,y:776,t:1527027306921};\\\", \\\"{x:1593,y:774,t:1527027306943};\\\", \\\"{x:1593,y:773,t:1527027306966};\\\", \\\"{x:1592,y:772,t:1527027307304};\\\", \\\"{x:1591,y:772,t:1527027307327};\\\", \\\"{x:1588,y:773,t:1527027307338};\\\", \\\"{x:1579,y:784,t:1527027307354};\\\", \\\"{x:1569,y:796,t:1527027307371};\\\", \\\"{x:1568,y:797,t:1527027307388};\\\", \\\"{x:1568,y:798,t:1527027307431};\\\", \\\"{x:1569,y:798,t:1527027307447};\\\", \\\"{x:1573,y:798,t:1527027307455};\\\", \\\"{x:1581,y:787,t:1527027307471};\\\", \\\"{x:1587,y:777,t:1527027307487};\\\", \\\"{x:1594,y:764,t:1527027307504};\\\", \\\"{x:1613,y:725,t:1527027307521};\\\", \\\"{x:1638,y:662,t:1527027307537};\\\", \\\"{x:1649,y:622,t:1527027307553};\\\", \\\"{x:1649,y:629,t:1527027308152};\\\", \\\"{x:1648,y:634,t:1527027308159};\\\", \\\"{x:1647,y:636,t:1527027308172};\\\", \\\"{x:1644,y:640,t:1527027308188};\\\", \\\"{x:1638,y:649,t:1527027308205};\\\", \\\"{x:1628,y:660,t:1527027308223};\\\", \\\"{x:1612,y:673,t:1527027308238};\\\", \\\"{x:1584,y:692,t:1527027308255};\\\", \\\"{x:1568,y:700,t:1527027308272};\\\", \\\"{x:1549,y:709,t:1527027308288};\\\", \\\"{x:1532,y:722,t:1527027308306};\\\", \\\"{x:1516,y:734,t:1527027308322};\\\", \\\"{x:1508,y:743,t:1527027308338};\\\", \\\"{x:1499,y:750,t:1527027308355};\\\", \\\"{x:1497,y:751,t:1527027308373};\\\", \\\"{x:1496,y:751,t:1527027308415};\\\", \\\"{x:1495,y:750,t:1527027308439};\\\", \\\"{x:1495,y:741,t:1527027308455};\\\", \\\"{x:1495,y:726,t:1527027308472};\\\", \\\"{x:1495,y:708,t:1527027308488};\\\", \\\"{x:1495,y:697,t:1527027308505};\\\", \\\"{x:1500,y:685,t:1527027308522};\\\", \\\"{x:1508,y:675,t:1527027308539};\\\", \\\"{x:1518,y:664,t:1527027308555};\\\", \\\"{x:1526,y:655,t:1527027308572};\\\", \\\"{x:1532,y:649,t:1527027308589};\\\", \\\"{x:1534,y:648,t:1527027308605};\\\", \\\"{x:1536,y:645,t:1527027308622};\\\", \\\"{x:1538,y:644,t:1527027308639};\\\", \\\"{x:1539,y:643,t:1527027308655};\\\", \\\"{x:1539,y:641,t:1527027308672};\\\", \\\"{x:1539,y:640,t:1527027308689};\\\", \\\"{x:1539,y:636,t:1527027308705};\\\", \\\"{x:1539,y:632,t:1527027308721};\\\", \\\"{x:1539,y:630,t:1527027308739};\\\", \\\"{x:1539,y:628,t:1527027308755};\\\", \\\"{x:1537,y:628,t:1527027308772};\\\", \\\"{x:1533,y:625,t:1527027308789};\\\", \\\"{x:1531,y:625,t:1527027308805};\\\", \\\"{x:1528,y:625,t:1527027308821};\\\", \\\"{x:1523,y:624,t:1527027308838};\\\", \\\"{x:1521,y:624,t:1527027308854};\\\", \\\"{x:1520,y:624,t:1527027309007};\\\", \\\"{x:1519,y:624,t:1527027309055};\\\", \\\"{x:1518,y:624,t:1527027309072};\\\", \\\"{x:1517,y:623,t:1527027309090};\\\", \\\"{x:1516,y:622,t:1527027309110};\\\", \\\"{x:1517,y:622,t:1527027309831};\\\", \\\"{x:1517,y:624,t:1527027310679};\\\", \\\"{x:1517,y:625,t:1527027310691};\\\", \\\"{x:1517,y:626,t:1527027310706};\\\", \\\"{x:1517,y:629,t:1527027310722};\\\", \\\"{x:1517,y:633,t:1527027310740};\\\", \\\"{x:1514,y:639,t:1527027310757};\\\", \\\"{x:1507,y:645,t:1527027310773};\\\", \\\"{x:1495,y:651,t:1527027310790};\\\", \\\"{x:1477,y:661,t:1527027310806};\\\", \\\"{x:1462,y:672,t:1527027310823};\\\", \\\"{x:1448,y:682,t:1527027310840};\\\", \\\"{x:1442,y:690,t:1527027310856};\\\", \\\"{x:1438,y:695,t:1527027310874};\\\", \\\"{x:1434,y:703,t:1527027310890};\\\", \\\"{x:1431,y:714,t:1527027310907};\\\", \\\"{x:1428,y:728,t:1527027310923};\\\", \\\"{x:1425,y:749,t:1527027310940};\\\", \\\"{x:1423,y:765,t:1527027310957};\\\", \\\"{x:1422,y:779,t:1527027310974};\\\", \\\"{x:1422,y:788,t:1527027310989};\\\", \\\"{x:1422,y:796,t:1527027311007};\\\", \\\"{x:1422,y:800,t:1527027311024};\\\", \\\"{x:1422,y:804,t:1527027311040};\\\", \\\"{x:1422,y:808,t:1527027311057};\\\", \\\"{x:1419,y:812,t:1527027311074};\\\", \\\"{x:1417,y:812,t:1527027311090};\\\", \\\"{x:1416,y:813,t:1527027311106};\\\", \\\"{x:1412,y:813,t:1527027311124};\\\", \\\"{x:1409,y:813,t:1527027311139};\\\", \\\"{x:1405,y:813,t:1527027311157};\\\", \\\"{x:1401,y:812,t:1527027311174};\\\", \\\"{x:1397,y:808,t:1527027311190};\\\", \\\"{x:1393,y:799,t:1527027311207};\\\", \\\"{x:1392,y:794,t:1527027311224};\\\", \\\"{x:1390,y:788,t:1527027311240};\\\", \\\"{x:1388,y:784,t:1527027311256};\\\", \\\"{x:1386,y:781,t:1527027311274};\\\", \\\"{x:1385,y:780,t:1527027311291};\\\", \\\"{x:1384,y:779,t:1527027311307};\\\", \\\"{x:1383,y:778,t:1527027311324};\\\", \\\"{x:1383,y:777,t:1527027311341};\\\", \\\"{x:1383,y:776,t:1527027311357};\\\", \\\"{x:1383,y:775,t:1527027311424};\\\", \\\"{x:1383,y:774,t:1527027311447};\\\", \\\"{x:1383,y:771,t:1527027311457};\\\", \\\"{x:1384,y:768,t:1527027311475};\\\", \\\"{x:1384,y:765,t:1527027311491};\\\", \\\"{x:1385,y:764,t:1527027311507};\\\", \\\"{x:1385,y:761,t:1527027311524};\\\", \\\"{x:1385,y:760,t:1527027312463};\\\", \\\"{x:1384,y:760,t:1527027312479};\\\", \\\"{x:1383,y:760,t:1527027312528};\\\", \\\"{x:1382,y:760,t:1527027312550};\\\", \\\"{x:1384,y:760,t:1527027314855};\\\", \\\"{x:1388,y:760,t:1527027314864};\\\", \\\"{x:1391,y:760,t:1527027314877};\\\", \\\"{x:1397,y:761,t:1527027314893};\\\", \\\"{x:1401,y:761,t:1527027314910};\\\", \\\"{x:1403,y:762,t:1527027314927};\\\", \\\"{x:1404,y:762,t:1527027314966};\\\", \\\"{x:1405,y:762,t:1527027314982};\\\", \\\"{x:1406,y:762,t:1527027314999};\\\", \\\"{x:1407,y:762,t:1527027315014};\\\", \\\"{x:1409,y:762,t:1527027315030};\\\", \\\"{x:1410,y:762,t:1527027315046};\\\", \\\"{x:1411,y:762,t:1527027315063};\\\", \\\"{x:1412,y:762,t:1527027315077};\\\", \\\"{x:1416,y:762,t:1527027315093};\\\", \\\"{x:1418,y:762,t:1527027315110};\\\", \\\"{x:1420,y:762,t:1527027315127};\\\", \\\"{x:1422,y:762,t:1527027315143};\\\", \\\"{x:1423,y:762,t:1527027315160};\\\", \\\"{x:1426,y:762,t:1527027315177};\\\", \\\"{x:1429,y:762,t:1527027315193};\\\", \\\"{x:1433,y:762,t:1527027315210};\\\", \\\"{x:1437,y:762,t:1527027315227};\\\", \\\"{x:1439,y:762,t:1527027315244};\\\", \\\"{x:1444,y:762,t:1527027315260};\\\", \\\"{x:1446,y:762,t:1527027315278};\\\", \\\"{x:1447,y:762,t:1527027315294};\\\", \\\"{x:1448,y:762,t:1527027315311};\\\", \\\"{x:1450,y:762,t:1527027315328};\\\", \\\"{x:1452,y:762,t:1527027315351};\\\", \\\"{x:1453,y:762,t:1527027315367};\\\", \\\"{x:1455,y:762,t:1527027315407};\\\", \\\"{x:1456,y:762,t:1527027315414};\\\", \\\"{x:1456,y:761,t:1527027315428};\\\", \\\"{x:1458,y:761,t:1527027315444};\\\", \\\"{x:1461,y:761,t:1527027315460};\\\", \\\"{x:1462,y:761,t:1527027315477};\\\", \\\"{x:1464,y:761,t:1527027315494};\\\", \\\"{x:1465,y:761,t:1527027315600};\\\", \\\"{x:1464,y:761,t:1527027315735};\\\", \\\"{x:1461,y:761,t:1527027315745};\\\", \\\"{x:1457,y:761,t:1527027315761};\\\", \\\"{x:1448,y:761,t:1527027315777};\\\", \\\"{x:1440,y:761,t:1527027315795};\\\", \\\"{x:1433,y:761,t:1527027315812};\\\", \\\"{x:1423,y:759,t:1527027315827};\\\", \\\"{x:1417,y:759,t:1527027315844};\\\", \\\"{x:1411,y:759,t:1527027315861};\\\", \\\"{x:1406,y:759,t:1527027315877};\\\", \\\"{x:1404,y:759,t:1527027315894};\\\", \\\"{x:1401,y:759,t:1527027315911};\\\", \\\"{x:1399,y:759,t:1527027315927};\\\", \\\"{x:1397,y:759,t:1527027315944};\\\", \\\"{x:1394,y:761,t:1527027315961};\\\", \\\"{x:1391,y:761,t:1527027315978};\\\", \\\"{x:1388,y:761,t:1527027315994};\\\", \\\"{x:1385,y:761,t:1527027316012};\\\", \\\"{x:1382,y:761,t:1527027316027};\\\", \\\"{x:1381,y:761,t:1527027316044};\\\", \\\"{x:1380,y:761,t:1527027316061};\\\", \\\"{x:1379,y:762,t:1527027316077};\\\", \\\"{x:1381,y:762,t:1527027316287};\\\", \\\"{x:1382,y:762,t:1527027316294};\\\", \\\"{x:1385,y:762,t:1527027316311};\\\", \\\"{x:1387,y:762,t:1527027316329};\\\", \\\"{x:1388,y:762,t:1527027316344};\\\", \\\"{x:1389,y:762,t:1527027316376};\\\", \\\"{x:1391,y:762,t:1527027316391};\\\", \\\"{x:1392,y:762,t:1527027316399};\\\", \\\"{x:1394,y:762,t:1527027316415};\\\", \\\"{x:1396,y:762,t:1527027316429};\\\", \\\"{x:1397,y:762,t:1527027316444};\\\", \\\"{x:1399,y:762,t:1527027316462};\\\", \\\"{x:1401,y:762,t:1527027316478};\\\", \\\"{x:1407,y:762,t:1527027316495};\\\", \\\"{x:1411,y:762,t:1527027316512};\\\", \\\"{x:1415,y:762,t:1527027316528};\\\", \\\"{x:1417,y:762,t:1527027316545};\\\", \\\"{x:1419,y:762,t:1527027316562};\\\", \\\"{x:1423,y:762,t:1527027316578};\\\", \\\"{x:1426,y:762,t:1527027316595};\\\", \\\"{x:1430,y:762,t:1527027316612};\\\", \\\"{x:1435,y:762,t:1527027316629};\\\", \\\"{x:1439,y:762,t:1527027316645};\\\", \\\"{x:1442,y:762,t:1527027316661};\\\", \\\"{x:1443,y:762,t:1527027316679};\\\", \\\"{x:1444,y:762,t:1527027316695};\\\", \\\"{x:1445,y:762,t:1527027316718};\\\", \\\"{x:1446,y:762,t:1527027316750};\\\", \\\"{x:1447,y:762,t:1527027316761};\\\", \\\"{x:1448,y:762,t:1527027316778};\\\", \\\"{x:1449,y:762,t:1527027316799};\\\", \\\"{x:1450,y:762,t:1527027316822};\\\", \\\"{x:1451,y:761,t:1527027316830};\\\", \\\"{x:1452,y:761,t:1527027318568};\\\", \\\"{x:1454,y:761,t:1527027318580};\\\", \\\"{x:1463,y:761,t:1527027318597};\\\", \\\"{x:1469,y:761,t:1527027318614};\\\", \\\"{x:1472,y:761,t:1527027318629};\\\", \\\"{x:1476,y:761,t:1527027318647};\\\", \\\"{x:1477,y:761,t:1527027318664};\\\", \\\"{x:1479,y:761,t:1527027318679};\\\", \\\"{x:1481,y:761,t:1527027318698};\\\", \\\"{x:1482,y:761,t:1527027318720};\\\", \\\"{x:1483,y:761,t:1527027318730};\\\", \\\"{x:1485,y:761,t:1527027318747};\\\", \\\"{x:1487,y:761,t:1527027318763};\\\", \\\"{x:1490,y:761,t:1527027318780};\\\", \\\"{x:1491,y:761,t:1527027318797};\\\", \\\"{x:1493,y:761,t:1527027318814};\\\", \\\"{x:1495,y:761,t:1527027318830};\\\", \\\"{x:1497,y:761,t:1527027318846};\\\", \\\"{x:1501,y:761,t:1527027318863};\\\", \\\"{x:1503,y:761,t:1527027318881};\\\", \\\"{x:1504,y:761,t:1527027318896};\\\", \\\"{x:1506,y:760,t:1527027318914};\\\", \\\"{x:1507,y:760,t:1527027318931};\\\", \\\"{x:1508,y:760,t:1527027318951};\\\", \\\"{x:1509,y:760,t:1527027318967};\\\", \\\"{x:1510,y:760,t:1527027318981};\\\", \\\"{x:1511,y:760,t:1527027318996};\\\", \\\"{x:1515,y:760,t:1527027319014};\\\", \\\"{x:1517,y:760,t:1527027319031};\\\", \\\"{x:1518,y:760,t:1527027319055};\\\", \\\"{x:1519,y:760,t:1527027319071};\\\", \\\"{x:1520,y:760,t:1527027319255};\\\", \\\"{x:1521,y:761,t:1527027319263};\\\", \\\"{x:1526,y:761,t:1527027319281};\\\", \\\"{x:1530,y:761,t:1527027319298};\\\", \\\"{x:1540,y:762,t:1527027319313};\\\", \\\"{x:1549,y:764,t:1527027319330};\\\", \\\"{x:1554,y:765,t:1527027319348};\\\", \\\"{x:1556,y:765,t:1527027319364};\\\", \\\"{x:1558,y:766,t:1527027319381};\\\", \\\"{x:1556,y:766,t:1527027319879};\\\", \\\"{x:1550,y:766,t:1527027319898};\\\", \\\"{x:1543,y:766,t:1527027319915};\\\", \\\"{x:1534,y:766,t:1527027319930};\\\", \\\"{x:1528,y:766,t:1527027319947};\\\", \\\"{x:1524,y:766,t:1527027319965};\\\", \\\"{x:1523,y:766,t:1527027319981};\\\", \\\"{x:1521,y:766,t:1527027319998};\\\", \\\"{x:1516,y:766,t:1527027320015};\\\", \\\"{x:1509,y:766,t:1527027320031};\\\", \\\"{x:1505,y:766,t:1527027320048};\\\", \\\"{x:1502,y:766,t:1527027320065};\\\", \\\"{x:1501,y:766,t:1527027320081};\\\", \\\"{x:1499,y:766,t:1527027320098};\\\", \\\"{x:1496,y:766,t:1527027320115};\\\", \\\"{x:1493,y:766,t:1527027320132};\\\", \\\"{x:1484,y:766,t:1527027320148};\\\", \\\"{x:1474,y:766,t:1527027320165};\\\", \\\"{x:1461,y:766,t:1527027320182};\\\", \\\"{x:1451,y:766,t:1527027320197};\\\", \\\"{x:1441,y:766,t:1527027320215};\\\", \\\"{x:1434,y:766,t:1527027320231};\\\", \\\"{x:1431,y:766,t:1527027320247};\\\", \\\"{x:1428,y:766,t:1527027320265};\\\", \\\"{x:1426,y:766,t:1527027320282};\\\", \\\"{x:1424,y:766,t:1527027320360};\\\", \\\"{x:1423,y:766,t:1527027320367};\\\", \\\"{x:1422,y:766,t:1527027320399};\\\", \\\"{x:1421,y:766,t:1527027320448};\\\", \\\"{x:1423,y:766,t:1527027320487};\\\", \\\"{x:1428,y:766,t:1527027320498};\\\", \\\"{x:1441,y:766,t:1527027320515};\\\", \\\"{x:1454,y:766,t:1527027320532};\\\", \\\"{x:1461,y:766,t:1527027320549};\\\", \\\"{x:1465,y:766,t:1527027320565};\\\", \\\"{x:1466,y:766,t:1527027320582};\\\", \\\"{x:1467,y:766,t:1527027320607};\\\", \\\"{x:1468,y:766,t:1527027320615};\\\", \\\"{x:1471,y:766,t:1527027320631};\\\", \\\"{x:1476,y:766,t:1527027320648};\\\", \\\"{x:1485,y:766,t:1527027320665};\\\", \\\"{x:1490,y:766,t:1527027320682};\\\", \\\"{x:1495,y:765,t:1527027320702};\\\", \\\"{x:1498,y:765,t:1527027320714};\\\", \\\"{x:1500,y:765,t:1527027320731};\\\", \\\"{x:1502,y:764,t:1527027320748};\\\", \\\"{x:1505,y:764,t:1527027320764};\\\", \\\"{x:1508,y:763,t:1527027320781};\\\", \\\"{x:1513,y:761,t:1527027320798};\\\", \\\"{x:1517,y:761,t:1527027320814};\\\", \\\"{x:1520,y:761,t:1527027320831};\\\", \\\"{x:1527,y:761,t:1527027320848};\\\", \\\"{x:1534,y:761,t:1527027320865};\\\", \\\"{x:1541,y:760,t:1527027320881};\\\", \\\"{x:1544,y:760,t:1527027320898};\\\", \\\"{x:1546,y:760,t:1527027320914};\\\", \\\"{x:1547,y:760,t:1527027320931};\\\", \\\"{x:1548,y:760,t:1527027320950};\\\", \\\"{x:1550,y:760,t:1527027320966};\\\", \\\"{x:1552,y:760,t:1527027320982};\\\", \\\"{x:1556,y:760,t:1527027320998};\\\", \\\"{x:1557,y:760,t:1527027321056};\\\", \\\"{x:1558,y:760,t:1527027321065};\\\", \\\"{x:1563,y:760,t:1527027321081};\\\", \\\"{x:1569,y:760,t:1527027321098};\\\", \\\"{x:1574,y:760,t:1527027321115};\\\", \\\"{x:1578,y:760,t:1527027321132};\\\", \\\"{x:1580,y:760,t:1527027321148};\\\", \\\"{x:1581,y:760,t:1527027321896};\\\", \\\"{x:1580,y:761,t:1527027323424};\\\", \\\"{x:1578,y:761,t:1527027323434};\\\", \\\"{x:1576,y:764,t:1527027323451};\\\", \\\"{x:1571,y:766,t:1527027323467};\\\", \\\"{x:1565,y:769,t:1527027323484};\\\", \\\"{x:1550,y:773,t:1527027323501};\\\", \\\"{x:1529,y:780,t:1527027323517};\\\", \\\"{x:1506,y:785,t:1527027323533};\\\", \\\"{x:1465,y:797,t:1527027323550};\\\", \\\"{x:1441,y:807,t:1527027323567};\\\", \\\"{x:1420,y:812,t:1527027323584};\\\", \\\"{x:1404,y:817,t:1527027323600};\\\", \\\"{x:1388,y:823,t:1527027323617};\\\", \\\"{x:1378,y:828,t:1527027323633};\\\", \\\"{x:1363,y:834,t:1527027323650};\\\", \\\"{x:1350,y:838,t:1527027323667};\\\", \\\"{x:1341,y:840,t:1527027323683};\\\", \\\"{x:1336,y:840,t:1527027323700};\\\", \\\"{x:1326,y:842,t:1527027323717};\\\", \\\"{x:1317,y:843,t:1527027323734};\\\", \\\"{x:1311,y:844,t:1527027323750};\\\", \\\"{x:1309,y:844,t:1527027323767};\\\", \\\"{x:1308,y:844,t:1527027323791};\\\", \\\"{x:1306,y:844,t:1527027323831};\\\", \\\"{x:1305,y:843,t:1527027323847};\\\", \\\"{x:1304,y:842,t:1527027323863};\\\", \\\"{x:1303,y:841,t:1527027323879};\\\", \\\"{x:1302,y:840,t:1527027323911};\\\", \\\"{x:1301,y:840,t:1527027323959};\\\", \\\"{x:1300,y:839,t:1527027323974};\\\", \\\"{x:1299,y:838,t:1527027323991};\\\", \\\"{x:1298,y:837,t:1527027324000};\\\", \\\"{x:1297,y:836,t:1527027324023};\\\", \\\"{x:1296,y:836,t:1527027324034};\\\", \\\"{x:1296,y:835,t:1527027324050};\\\", \\\"{x:1294,y:834,t:1527027324068};\\\", \\\"{x:1293,y:834,t:1527027324085};\\\", \\\"{x:1293,y:833,t:1527027324160};\\\", \\\"{x:1291,y:832,t:1527027324255};\\\", \\\"{x:1290,y:832,t:1527027324271};\\\", \\\"{x:1290,y:831,t:1527027324285};\\\", \\\"{x:1289,y:831,t:1527027324301};\\\", \\\"{x:1287,y:831,t:1527027324318};\\\", \\\"{x:1286,y:830,t:1527027324336};\\\", \\\"{x:1285,y:830,t:1527027324543};\\\", \\\"{x:1285,y:829,t:1527027324551};\\\", \\\"{x:1285,y:827,t:1527027324568};\\\", \\\"{x:1285,y:824,t:1527027324586};\\\", \\\"{x:1288,y:819,t:1527027324601};\\\", \\\"{x:1292,y:808,t:1527027324618};\\\", \\\"{x:1297,y:793,t:1527027324635};\\\", \\\"{x:1301,y:778,t:1527027324652};\\\", \\\"{x:1304,y:765,t:1527027324668};\\\", \\\"{x:1308,y:752,t:1527027324685};\\\", \\\"{x:1311,y:737,t:1527027324702};\\\", \\\"{x:1311,y:719,t:1527027324718};\\\", \\\"{x:1313,y:702,t:1527027324734};\\\", \\\"{x:1313,y:693,t:1527027324751};\\\", \\\"{x:1313,y:685,t:1527027324768};\\\", \\\"{x:1313,y:678,t:1527027324784};\\\", \\\"{x:1313,y:673,t:1527027324802};\\\", \\\"{x:1312,y:664,t:1527027324817};\\\", \\\"{x:1312,y:660,t:1527027324834};\\\", \\\"{x:1312,y:656,t:1527027324851};\\\", \\\"{x:1312,y:650,t:1527027324868};\\\", \\\"{x:1311,y:646,t:1527027324884};\\\", \\\"{x:1310,y:644,t:1527027324902};\\\", \\\"{x:1310,y:643,t:1527027324918};\\\", \\\"{x:1310,y:640,t:1527027324934};\\\", \\\"{x:1310,y:638,t:1527027324959};\\\", \\\"{x:1310,y:637,t:1527027324968};\\\", \\\"{x:1310,y:634,t:1527027324985};\\\", \\\"{x:1310,y:633,t:1527027325001};\\\", \\\"{x:1310,y:630,t:1527027325019};\\\", \\\"{x:1310,y:628,t:1527027325034};\\\", \\\"{x:1310,y:627,t:1527027325052};\\\", \\\"{x:1310,y:626,t:1527027325068};\\\", \\\"{x:1310,y:625,t:1527027325085};\\\", \\\"{x:1310,y:624,t:1527027325159};\\\", \\\"{x:1311,y:623,t:1527027325208};\\\", \\\"{x:1312,y:623,t:1527027325288};\\\", \\\"{x:1315,y:623,t:1527027325303};\\\", \\\"{x:1316,y:623,t:1527027325318};\\\", \\\"{x:1318,y:624,t:1527027325334};\\\", \\\"{x:1320,y:624,t:1527027325352};\\\", \\\"{x:1321,y:624,t:1527027325368};\\\", \\\"{x:1323,y:625,t:1527027325385};\\\", \\\"{x:1324,y:625,t:1527027325401};\\\", \\\"{x:1324,y:626,t:1527027325648};\\\", \\\"{x:1324,y:627,t:1527027325655};\\\", \\\"{x:1324,y:628,t:1527027325704};\\\", \\\"{x:1324,y:629,t:1527027325719};\\\", \\\"{x:1324,y:630,t:1527027325736};\\\", \\\"{x:1324,y:631,t:1527027325753};\\\", \\\"{x:1322,y:632,t:1527027325808};\\\", \\\"{x:1322,y:633,t:1527027325983};\\\", \\\"{x:1323,y:633,t:1527027325991};\\\", \\\"{x:1327,y:633,t:1527027326003};\\\", \\\"{x:1336,y:633,t:1527027326019};\\\", \\\"{x:1344,y:633,t:1527027326036};\\\", \\\"{x:1350,y:633,t:1527027326053};\\\", \\\"{x:1355,y:633,t:1527027326069};\\\", \\\"{x:1357,y:633,t:1527027326086};\\\", \\\"{x:1362,y:632,t:1527027326103};\\\", \\\"{x:1364,y:632,t:1527027326118};\\\", \\\"{x:1370,y:630,t:1527027326135};\\\", \\\"{x:1375,y:629,t:1527027326153};\\\", \\\"{x:1379,y:629,t:1527027326169};\\\", \\\"{x:1382,y:629,t:1527027326185};\\\", \\\"{x:1383,y:629,t:1527027326202};\\\", \\\"{x:1384,y:629,t:1527027326219};\\\", \\\"{x:1385,y:629,t:1527027326235};\\\", \\\"{x:1386,y:628,t:1527027326252};\\\", \\\"{x:1384,y:628,t:1527027326456};\\\", \\\"{x:1382,y:628,t:1527027326471};\\\", \\\"{x:1383,y:628,t:1527027326711};\\\", \\\"{x:1386,y:628,t:1527027326720};\\\", \\\"{x:1388,y:628,t:1527027326737};\\\", \\\"{x:1389,y:628,t:1527027326753};\\\", \\\"{x:1390,y:628,t:1527027326770};\\\", \\\"{x:1392,y:627,t:1527027326807};\\\", \\\"{x:1394,y:627,t:1527027326823};\\\", \\\"{x:1395,y:627,t:1527027326837};\\\", \\\"{x:1398,y:626,t:1527027326853};\\\", \\\"{x:1399,y:626,t:1527027326870};\\\", \\\"{x:1402,y:626,t:1527027326887};\\\", \\\"{x:1405,y:626,t:1527027326903};\\\", \\\"{x:1408,y:626,t:1527027326920};\\\", \\\"{x:1413,y:626,t:1527027326937};\\\", \\\"{x:1418,y:626,t:1527027326954};\\\", \\\"{x:1420,y:626,t:1527027326970};\\\", \\\"{x:1422,y:626,t:1527027326987};\\\", \\\"{x:1423,y:626,t:1527027327039};\\\", \\\"{x:1425,y:626,t:1527027327055};\\\", \\\"{x:1428,y:626,t:1527027327070};\\\", \\\"{x:1433,y:627,t:1527027327087};\\\", \\\"{x:1435,y:628,t:1527027327103};\\\", \\\"{x:1436,y:628,t:1527027327120};\\\", \\\"{x:1439,y:628,t:1527027327471};\\\", \\\"{x:1446,y:628,t:1527027327487};\\\", \\\"{x:1452,y:628,t:1527027327504};\\\", \\\"{x:1455,y:629,t:1527027327521};\\\", \\\"{x:1458,y:629,t:1527027327537};\\\", \\\"{x:1459,y:629,t:1527027327584};\\\", \\\"{x:1461,y:629,t:1527027327607};\\\", \\\"{x:1462,y:629,t:1527027327622};\\\", \\\"{x:1463,y:629,t:1527027327637};\\\", \\\"{x:1465,y:629,t:1527027327654};\\\", \\\"{x:1466,y:629,t:1527027327671};\\\", \\\"{x:1468,y:629,t:1527027327687};\\\", \\\"{x:1470,y:629,t:1527027327704};\\\", \\\"{x:1475,y:629,t:1527027327720};\\\", \\\"{x:1478,y:629,t:1527027327736};\\\", \\\"{x:1482,y:629,t:1527027327753};\\\", \\\"{x:1488,y:629,t:1527027327770};\\\", \\\"{x:1492,y:629,t:1527027327787};\\\", \\\"{x:1495,y:629,t:1527027327803};\\\", \\\"{x:1496,y:629,t:1527027327820};\\\", \\\"{x:1497,y:629,t:1527027327836};\\\", \\\"{x:1498,y:629,t:1527027327854};\\\", \\\"{x:1500,y:629,t:1527027327870};\\\", \\\"{x:1502,y:629,t:1527027327886};\\\", \\\"{x:1505,y:629,t:1527027327903};\\\", \\\"{x:1506,y:629,t:1527027327921};\\\", \\\"{x:1507,y:629,t:1527027327937};\\\", \\\"{x:1508,y:629,t:1527027327953};\\\", \\\"{x:1509,y:629,t:1527027328056};\\\", \\\"{x:1510,y:629,t:1527027328191};\\\", \\\"{x:1511,y:629,t:1527027328204};\\\", \\\"{x:1514,y:629,t:1527027328221};\\\", \\\"{x:1523,y:629,t:1527027328239};\\\", \\\"{x:1534,y:629,t:1527027328255};\\\", \\\"{x:1552,y:629,t:1527027328271};\\\", \\\"{x:1558,y:629,t:1527027328288};\\\", \\\"{x:1559,y:629,t:1527027328303};\\\", \\\"{x:1560,y:629,t:1527027328366};\\\", \\\"{x:1561,y:629,t:1527027328374};\\\", \\\"{x:1563,y:629,t:1527027328390};\\\", \\\"{x:1564,y:629,t:1527027328406};\\\", \\\"{x:1565,y:629,t:1527027328421};\\\", \\\"{x:1566,y:629,t:1527027328437};\\\", \\\"{x:1568,y:629,t:1527027328454};\\\", \\\"{x:1575,y:629,t:1527027328471};\\\", \\\"{x:1578,y:629,t:1527027328488};\\\", \\\"{x:1579,y:629,t:1527027328504};\\\", \\\"{x:1581,y:629,t:1527027328688};\\\", \\\"{x:1583,y:629,t:1527027328704};\\\", \\\"{x:1587,y:629,t:1527027328721};\\\", \\\"{x:1594,y:629,t:1527027328737};\\\", \\\"{x:1602,y:629,t:1527027328754};\\\", \\\"{x:1611,y:629,t:1527027328770};\\\", \\\"{x:1614,y:629,t:1527027328787};\\\", \\\"{x:1616,y:628,t:1527027328805};\\\", \\\"{x:1618,y:628,t:1527027328821};\\\", \\\"{x:1619,y:627,t:1527027328838};\\\", \\\"{x:1620,y:627,t:1527027328870};\\\", \\\"{x:1621,y:627,t:1527027328911};\\\", \\\"{x:1623,y:627,t:1527027328926};\\\", \\\"{x:1624,y:627,t:1527027328938};\\\", \\\"{x:1627,y:627,t:1527027328955};\\\", \\\"{x:1630,y:627,t:1527027328972};\\\", \\\"{x:1632,y:627,t:1527027328987};\\\", \\\"{x:1633,y:627,t:1527027329039};\\\", \\\"{x:1636,y:627,t:1527027329055};\\\", \\\"{x:1639,y:627,t:1527027329072};\\\", \\\"{x:1642,y:627,t:1527027329088};\\\", \\\"{x:1643,y:627,t:1527027330552};\\\", \\\"{x:1643,y:626,t:1527027330567};\\\", \\\"{x:1640,y:626,t:1527027330583};\\\", \\\"{x:1638,y:626,t:1527027330591};\\\", \\\"{x:1635,y:626,t:1527027330607};\\\", \\\"{x:1624,y:626,t:1527027330623};\\\", \\\"{x:1619,y:626,t:1527027330640};\\\", \\\"{x:1612,y:626,t:1527027330656};\\\", \\\"{x:1604,y:627,t:1527027330674};\\\", \\\"{x:1600,y:627,t:1527027330689};\\\", \\\"{x:1596,y:627,t:1527027330706};\\\", \\\"{x:1590,y:627,t:1527027330722};\\\", \\\"{x:1581,y:627,t:1527027330740};\\\", \\\"{x:1571,y:627,t:1527027330756};\\\", \\\"{x:1558,y:628,t:1527027330773};\\\", \\\"{x:1545,y:628,t:1527027330790};\\\", \\\"{x:1534,y:628,t:1527027330805};\\\", \\\"{x:1521,y:628,t:1527027330822};\\\", \\\"{x:1518,y:628,t:1527027330840};\\\", \\\"{x:1515,y:628,t:1527027330856};\\\", \\\"{x:1513,y:628,t:1527027330873};\\\", \\\"{x:1511,y:628,t:1527027330889};\\\", \\\"{x:1508,y:628,t:1527027330907};\\\", \\\"{x:1506,y:628,t:1527027330923};\\\", \\\"{x:1504,y:628,t:1527027330940};\\\", \\\"{x:1505,y:628,t:1527027331624};\\\", \\\"{x:1505,y:627,t:1527027331655};\\\", \\\"{x:1504,y:626,t:1527027331663};\\\", \\\"{x:1503,y:624,t:1527027331679};\\\", \\\"{x:1501,y:622,t:1527027331695};\\\", \\\"{x:1499,y:620,t:1527027331707};\\\", \\\"{x:1495,y:615,t:1527027331724};\\\", \\\"{x:1489,y:610,t:1527027331741};\\\", \\\"{x:1483,y:605,t:1527027331757};\\\", \\\"{x:1476,y:599,t:1527027331775};\\\", \\\"{x:1471,y:596,t:1527027331790};\\\", \\\"{x:1465,y:591,t:1527027331807};\\\", \\\"{x:1460,y:588,t:1527027331825};\\\", \\\"{x:1456,y:587,t:1527027331841};\\\", \\\"{x:1452,y:585,t:1527027331857};\\\", \\\"{x:1449,y:584,t:1527027331874};\\\", \\\"{x:1447,y:583,t:1527027331890};\\\", \\\"{x:1446,y:583,t:1527027331907};\\\", \\\"{x:1442,y:581,t:1527027331924};\\\", \\\"{x:1438,y:580,t:1527027331940};\\\", \\\"{x:1430,y:577,t:1527027331958};\\\", \\\"{x:1421,y:576,t:1527027331974};\\\", \\\"{x:1407,y:575,t:1527027331991};\\\", \\\"{x:1389,y:572,t:1527027332007};\\\", \\\"{x:1379,y:572,t:1527027332024};\\\", \\\"{x:1375,y:572,t:1527027332040};\\\", \\\"{x:1374,y:572,t:1527027332058};\\\", \\\"{x:1373,y:571,t:1527027332183};\\\", \\\"{x:1373,y:570,t:1527027332199};\\\", \\\"{x:1373,y:569,t:1527027332207};\\\", \\\"{x:1373,y:565,t:1527027332224};\\\", \\\"{x:1372,y:560,t:1527027332242};\\\", \\\"{x:1371,y:555,t:1527027332258};\\\", \\\"{x:1367,y:547,t:1527027332274};\\\", \\\"{x:1361,y:538,t:1527027332291};\\\", \\\"{x:1353,y:528,t:1527027332307};\\\", \\\"{x:1343,y:516,t:1527027332324};\\\", \\\"{x:1332,y:504,t:1527027332341};\\\", \\\"{x:1325,y:495,t:1527027332358};\\\", \\\"{x:1317,y:488,t:1527027332374};\\\", \\\"{x:1310,y:484,t:1527027332391};\\\", \\\"{x:1306,y:481,t:1527027332408};\\\", \\\"{x:1305,y:481,t:1527027332424};\\\", \\\"{x:1306,y:481,t:1527027332607};\\\", \\\"{x:1309,y:481,t:1527027332625};\\\", \\\"{x:1310,y:482,t:1527027332647};\\\", \\\"{x:1312,y:483,t:1527027332696};\\\", \\\"{x:1314,y:484,t:1527027332726};\\\", \\\"{x:1315,y:484,t:1527027332742};\\\", \\\"{x:1315,y:485,t:1527027332757};\\\", \\\"{x:1318,y:485,t:1527027332774};\\\", \\\"{x:1325,y:486,t:1527027332791};\\\", \\\"{x:1329,y:488,t:1527027332808};\\\", \\\"{x:1333,y:489,t:1527027332823};\\\", \\\"{x:1336,y:489,t:1527027332841};\\\", \\\"{x:1339,y:489,t:1527027332858};\\\", \\\"{x:1340,y:489,t:1527027332874};\\\", \\\"{x:1343,y:489,t:1527027332891};\\\", \\\"{x:1345,y:489,t:1527027332908};\\\", \\\"{x:1349,y:489,t:1527027332924};\\\", \\\"{x:1355,y:489,t:1527027332941};\\\", \\\"{x:1369,y:489,t:1527027332958};\\\", \\\"{x:1391,y:493,t:1527027332974};\\\", \\\"{x:1410,y:494,t:1527027332991};\\\", \\\"{x:1426,y:497,t:1527027333008};\\\", \\\"{x:1440,y:497,t:1527027333025};\\\", \\\"{x:1451,y:497,t:1527027333041};\\\", \\\"{x:1463,y:497,t:1527027333058};\\\", \\\"{x:1473,y:498,t:1527027333075};\\\", \\\"{x:1490,y:498,t:1527027333092};\\\", \\\"{x:1508,y:498,t:1527027333108};\\\", \\\"{x:1525,y:498,t:1527027333125};\\\", \\\"{x:1543,y:498,t:1527027333141};\\\", \\\"{x:1558,y:498,t:1527027333158};\\\", \\\"{x:1579,y:498,t:1527027333175};\\\", \\\"{x:1589,y:498,t:1527027333191};\\\", \\\"{x:1594,y:498,t:1527027333208};\\\", \\\"{x:1601,y:498,t:1527027333225};\\\", \\\"{x:1606,y:498,t:1527027333241};\\\", \\\"{x:1612,y:497,t:1527027333259};\\\", \\\"{x:1616,y:496,t:1527027333276};\\\", \\\"{x:1619,y:496,t:1527027333292};\\\", \\\"{x:1621,y:495,t:1527027333308};\\\", \\\"{x:1623,y:494,t:1527027333325};\\\", \\\"{x:1624,y:494,t:1527027333343};\\\", \\\"{x:1625,y:494,t:1527027333359};\\\", \\\"{x:1626,y:494,t:1527027333376};\\\", \\\"{x:1627,y:494,t:1527027333391};\\\", \\\"{x:1630,y:494,t:1527027333409};\\\", \\\"{x:1633,y:494,t:1527027333425};\\\", \\\"{x:1635,y:494,t:1527027333443};\\\", \\\"{x:1638,y:494,t:1527027333458};\\\", \\\"{x:1641,y:494,t:1527027333475};\\\", \\\"{x:1643,y:494,t:1527027333492};\\\", \\\"{x:1647,y:494,t:1527027333509};\\\", \\\"{x:1652,y:494,t:1527027333526};\\\", \\\"{x:1656,y:494,t:1527027333543};\\\", \\\"{x:1660,y:494,t:1527027333559};\\\", \\\"{x:1660,y:496,t:1527027333951};\\\", \\\"{x:1660,y:497,t:1527027333967};\\\", \\\"{x:1659,y:498,t:1527027333976};\\\", \\\"{x:1658,y:501,t:1527027333992};\\\", \\\"{x:1656,y:504,t:1527027334009};\\\", \\\"{x:1655,y:506,t:1527027334026};\\\", \\\"{x:1653,y:509,t:1527027334042};\\\", \\\"{x:1651,y:514,t:1527027334059};\\\", \\\"{x:1649,y:519,t:1527027334076};\\\", \\\"{x:1645,y:526,t:1527027334093};\\\", \\\"{x:1642,y:534,t:1527027334110};\\\", \\\"{x:1639,y:540,t:1527027334126};\\\", \\\"{x:1634,y:547,t:1527027334142};\\\", \\\"{x:1628,y:557,t:1527027334159};\\\", \\\"{x:1623,y:564,t:1527027334175};\\\", \\\"{x:1612,y:574,t:1527027334192};\\\", \\\"{x:1599,y:584,t:1527027334209};\\\", \\\"{x:1580,y:594,t:1527027334225};\\\", \\\"{x:1557,y:604,t:1527027334242};\\\", \\\"{x:1525,y:613,t:1527027334259};\\\", \\\"{x:1481,y:623,t:1527027334276};\\\", \\\"{x:1440,y:634,t:1527027334292};\\\", \\\"{x:1381,y:642,t:1527027334309};\\\", \\\"{x:1324,y:656,t:1527027334326};\\\", \\\"{x:1260,y:673,t:1527027334343};\\\", \\\"{x:1168,y:690,t:1527027334359};\\\", \\\"{x:1115,y:698,t:1527027334377};\\\", \\\"{x:1082,y:701,t:1527027334392};\\\", \\\"{x:1054,y:704,t:1527027334410};\\\", \\\"{x:1029,y:704,t:1527027334427};\\\", \\\"{x:1003,y:704,t:1527027334442};\\\", \\\"{x:974,y:704,t:1527027334460};\\\", \\\"{x:944,y:704,t:1527027334476};\\\", \\\"{x:914,y:704,t:1527027334493};\\\", \\\"{x:887,y:707,t:1527027334509};\\\", \\\"{x:861,y:716,t:1527027334526};\\\", \\\"{x:853,y:714,t:1527027334783};\\\", \\\"{x:842,y:711,t:1527027334794};\\\", \\\"{x:802,y:711,t:1527027334809};\\\", \\\"{x:771,y:711,t:1527027334826};\\\", \\\"{x:731,y:708,t:1527027334843};\\\", \\\"{x:681,y:708,t:1527027334859};\\\", \\\"{x:630,y:708,t:1527027334876};\\\", \\\"{x:588,y:708,t:1527027334893};\\\", \\\"{x:555,y:708,t:1527027334911};\\\", \\\"{x:531,y:708,t:1527027334926};\\\", \\\"{x:510,y:708,t:1527027334942};\\\", \\\"{x:505,y:709,t:1527027334959};\\\", \\\"{x:498,y:713,t:1527027334977};\\\", \\\"{x:494,y:714,t:1527027334992};\\\", \\\"{x:486,y:717,t:1527027335009};\\\", \\\"{x:477,y:719,t:1527027335027};\\\", \\\"{x:473,y:719,t:1527027335043};\\\", \\\"{x:476,y:720,t:1527027335487};\\\", \\\"{x:481,y:722,t:1527027335494};\\\", \\\"{x:492,y:724,t:1527027335510};\\\", \\\"{x:508,y:727,t:1527027335526};\\\", \\\"{x:518,y:728,t:1527027335543};\\\", \\\"{x:524,y:728,t:1527027335560};\\\", \\\"{x:528,y:729,t:1527027335577};\\\", \\\"{x:530,y:729,t:1527027335593};\\\", \\\"{x:531,y:731,t:1527027335610};\\\", \\\"{x:533,y:731,t:1527027335631};\\\", \\\"{x:534,y:731,t:1527027335644};\\\", \\\"{x:538,y:733,t:1527027335660};\\\", \\\"{x:545,y:735,t:1527027335677};\\\", \\\"{x:556,y:737,t:1527027335695};\\\", \\\"{x:559,y:738,t:1527027335710};\\\", \\\"{x:566,y:740,t:1527027335727};\\\", \\\"{x:569,y:741,t:1527027335744};\\\", \\\"{x:575,y:742,t:1527027335760};\\\", \\\"{x:581,y:744,t:1527027335777};\\\", \\\"{x:587,y:745,t:1527027335794};\\\", \\\"{x:594,y:748,t:1527027335810};\\\", \\\"{x:597,y:749,t:1527027335827};\\\", \\\"{x:598,y:749,t:1527027335844};\\\", \\\"{x:600,y:749,t:1527027335860};\\\", \\\"{x:600,y:750,t:1527027335877};\\\", \\\"{x:602,y:750,t:1527027335895};\\\", \\\"{x:603,y:750,t:1527027335910};\\\", \\\"{x:604,y:750,t:1527027335927};\\\", \\\"{x:606,y:751,t:1527027335944};\\\", \\\"{x:607,y:751,t:1527027335959};\\\", \\\"{x:609,y:752,t:1527027335983};\\\", \\\"{x:610,y:752,t:1527027336031};\\\" ] }, { \\\"rt\\\": 64277, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 238878, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"C30CF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\", \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -I -6-7-I -I -H -E -E -K -O -O -K -K -K -F -U -U -Z -A -H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:617,y:753,t:1527027341430};\\\", \\\"{x:640,y:756,t:1527027341448};\\\", \\\"{x:676,y:761,t:1527027341464};\\\", \\\"{x:716,y:768,t:1527027341480};\\\", \\\"{x:768,y:774,t:1527027341498};\\\", \\\"{x:804,y:778,t:1527027341515};\\\", \\\"{x:836,y:784,t:1527027341530};\\\", \\\"{x:859,y:787,t:1527027341547};\\\", \\\"{x:881,y:789,t:1527027341564};\\\", \\\"{x:902,y:793,t:1527027341580};\\\", \\\"{x:935,y:797,t:1527027341597};\\\", \\\"{x:956,y:800,t:1527027341614};\\\", \\\"{x:979,y:804,t:1527027341631};\\\", \\\"{x:1001,y:808,t:1527027341648};\\\", \\\"{x:1025,y:810,t:1527027341664};\\\", \\\"{x:1043,y:813,t:1527027341681};\\\", \\\"{x:1057,y:815,t:1527027341697};\\\", \\\"{x:1068,y:816,t:1527027341714};\\\", \\\"{x:1080,y:819,t:1527027341730};\\\", \\\"{x:1086,y:819,t:1527027341747};\\\", \\\"{x:1091,y:819,t:1527027341766};\\\", \\\"{x:1092,y:819,t:1527027341781};\\\", \\\"{x:1092,y:820,t:1527027341797};\\\", \\\"{x:1093,y:820,t:1527027343446};\\\", \\\"{x:1092,y:820,t:1527027343477};\\\", \\\"{x:1090,y:818,t:1527027343485};\\\", \\\"{x:1089,y:818,t:1527027343878};\\\", \\\"{x:1090,y:818,t:1527027343957};\\\", \\\"{x:1094,y:818,t:1527027343965};\\\", \\\"{x:1101,y:818,t:1527027343983};\\\", \\\"{x:1114,y:820,t:1527027344000};\\\", \\\"{x:1132,y:822,t:1527027344017};\\\", \\\"{x:1148,y:825,t:1527027344032};\\\", \\\"{x:1174,y:827,t:1527027344050};\\\", \\\"{x:1197,y:832,t:1527027344067};\\\", \\\"{x:1219,y:836,t:1527027344082};\\\", \\\"{x:1243,y:839,t:1527027344099};\\\", \\\"{x:1262,y:844,t:1527027344117};\\\", \\\"{x:1288,y:850,t:1527027344133};\\\", \\\"{x:1317,y:854,t:1527027344150};\\\", \\\"{x:1338,y:857,t:1527027344166};\\\", \\\"{x:1359,y:860,t:1527027344182};\\\", \\\"{x:1382,y:863,t:1527027344199};\\\", \\\"{x:1405,y:866,t:1527027344217};\\\", \\\"{x:1432,y:871,t:1527027344232};\\\", \\\"{x:1460,y:871,t:1527027344250};\\\", \\\"{x:1490,y:871,t:1527027344268};\\\", \\\"{x:1521,y:871,t:1527027344282};\\\", \\\"{x:1548,y:871,t:1527027344299};\\\", \\\"{x:1573,y:872,t:1527027344316};\\\", \\\"{x:1591,y:874,t:1527027344333};\\\", \\\"{x:1613,y:874,t:1527027344349};\\\", \\\"{x:1625,y:874,t:1527027344367};\\\", \\\"{x:1636,y:874,t:1527027344383};\\\", \\\"{x:1644,y:874,t:1527027344400};\\\", \\\"{x:1652,y:873,t:1527027344417};\\\", \\\"{x:1661,y:870,t:1527027344434};\\\", \\\"{x:1670,y:868,t:1527027344450};\\\", \\\"{x:1676,y:865,t:1527027344467};\\\", \\\"{x:1683,y:861,t:1527027344484};\\\", \\\"{x:1694,y:852,t:1527027344499};\\\", \\\"{x:1697,y:847,t:1527027344516};\\\", \\\"{x:1702,y:834,t:1527027344533};\\\", \\\"{x:1706,y:819,t:1527027344550};\\\", \\\"{x:1707,y:805,t:1527027344567};\\\", \\\"{x:1707,y:793,t:1527027344583};\\\", \\\"{x:1707,y:780,t:1527027344600};\\\", \\\"{x:1700,y:764,t:1527027344617};\\\", \\\"{x:1689,y:747,t:1527027344633};\\\", \\\"{x:1679,y:731,t:1527027344650};\\\", \\\"{x:1669,y:718,t:1527027344667};\\\", \\\"{x:1657,y:705,t:1527027344684};\\\", \\\"{x:1650,y:698,t:1527027344700};\\\", \\\"{x:1645,y:694,t:1527027344717};\\\", \\\"{x:1637,y:688,t:1527027344733};\\\", \\\"{x:1632,y:686,t:1527027344750};\\\", \\\"{x:1625,y:684,t:1527027344766};\\\", \\\"{x:1621,y:684,t:1527027344783};\\\", \\\"{x:1613,y:683,t:1527027344801};\\\", \\\"{x:1606,y:682,t:1527027344817};\\\", \\\"{x:1600,y:680,t:1527027344833};\\\", \\\"{x:1590,y:677,t:1527027344850};\\\", \\\"{x:1577,y:673,t:1527027344867};\\\", \\\"{x:1558,y:667,t:1527027344884};\\\", \\\"{x:1541,y:658,t:1527027344901};\\\", \\\"{x:1521,y:651,t:1527027344916};\\\", \\\"{x:1488,y:636,t:1527027344934};\\\", \\\"{x:1470,y:626,t:1527027344950};\\\", \\\"{x:1455,y:620,t:1527027344967};\\\", \\\"{x:1448,y:615,t:1527027344983};\\\", \\\"{x:1435,y:604,t:1527027345001};\\\", \\\"{x:1430,y:589,t:1527027345017};\\\", \\\"{x:1426,y:576,t:1527027345034};\\\", \\\"{x:1421,y:558,t:1527027345051};\\\", \\\"{x:1419,y:542,t:1527027345067};\\\", \\\"{x:1418,y:525,t:1527027345084};\\\", \\\"{x:1415,y:515,t:1527027345101};\\\", \\\"{x:1415,y:511,t:1527027345116};\\\", \\\"{x:1414,y:505,t:1527027345134};\\\", \\\"{x:1413,y:501,t:1527027345151};\\\", \\\"{x:1411,y:497,t:1527027345166};\\\", \\\"{x:1409,y:494,t:1527027345183};\\\", \\\"{x:1407,y:492,t:1527027345201};\\\", \\\"{x:1406,y:491,t:1527027345217};\\\", \\\"{x:1401,y:489,t:1527027345233};\\\", \\\"{x:1397,y:488,t:1527027345251};\\\", \\\"{x:1387,y:487,t:1527027345266};\\\", \\\"{x:1371,y:486,t:1527027345283};\\\", \\\"{x:1351,y:484,t:1527027345301};\\\", \\\"{x:1329,y:484,t:1527027345317};\\\", \\\"{x:1319,y:484,t:1527027345334};\\\", \\\"{x:1316,y:484,t:1527027345351};\\\", \\\"{x:1315,y:484,t:1527027345390};\\\", \\\"{x:1314,y:484,t:1527027345406};\\\", \\\"{x:1312,y:484,t:1527027345418};\\\", \\\"{x:1307,y:486,t:1527027345434};\\\", \\\"{x:1304,y:488,t:1527027345451};\\\", \\\"{x:1302,y:488,t:1527027345467};\\\", \\\"{x:1301,y:489,t:1527027345550};\\\", \\\"{x:1301,y:490,t:1527027345590};\\\", \\\"{x:1302,y:491,t:1527027345600};\\\", \\\"{x:1302,y:493,t:1527027345618};\\\", \\\"{x:1304,y:493,t:1527027345633};\\\", \\\"{x:1304,y:494,t:1527027345651};\\\", \\\"{x:1305,y:494,t:1527027345686};\\\", \\\"{x:1306,y:494,t:1527027345701};\\\", \\\"{x:1307,y:494,t:1527027345718};\\\", \\\"{x:1309,y:494,t:1527027345736};\\\", \\\"{x:1313,y:494,t:1527027345750};\\\", \\\"{x:1314,y:494,t:1527027345767};\\\", \\\"{x:1316,y:494,t:1527027345784};\\\", \\\"{x:1317,y:494,t:1527027345820};\\\", \\\"{x:1319,y:494,t:1527027347958};\\\", \\\"{x:1320,y:494,t:1527027347970};\\\", \\\"{x:1322,y:494,t:1527027347990};\\\", \\\"{x:1323,y:494,t:1527027348003};\\\", \\\"{x:1328,y:494,t:1527027348020};\\\", \\\"{x:1331,y:494,t:1527027348036};\\\", \\\"{x:1335,y:494,t:1527027348053};\\\", \\\"{x:1338,y:495,t:1527027348070};\\\", \\\"{x:1339,y:495,t:1527027348085};\\\", \\\"{x:1340,y:495,t:1527027348103};\\\", \\\"{x:1341,y:495,t:1527027348120};\\\", \\\"{x:1341,y:496,t:1527027348136};\\\", \\\"{x:1342,y:496,t:1527027348152};\\\", \\\"{x:1344,y:496,t:1527027348170};\\\", \\\"{x:1347,y:496,t:1527027348186};\\\", \\\"{x:1350,y:496,t:1527027348203};\\\", \\\"{x:1354,y:496,t:1527027348220};\\\", \\\"{x:1358,y:496,t:1527027348236};\\\", \\\"{x:1363,y:496,t:1527027348253};\\\", \\\"{x:1369,y:496,t:1527027348269};\\\", \\\"{x:1371,y:496,t:1527027348285};\\\", \\\"{x:1372,y:496,t:1527027348303};\\\", \\\"{x:1373,y:496,t:1527027348320};\\\", \\\"{x:1374,y:496,t:1527027348398};\\\", \\\"{x:1375,y:496,t:1527027348406};\\\", \\\"{x:1376,y:496,t:1527027348478};\\\", \\\"{x:1378,y:496,t:1527027348493};\\\", \\\"{x:1380,y:496,t:1527027348502};\\\", \\\"{x:1383,y:496,t:1527027348520};\\\", \\\"{x:1384,y:496,t:1527027348536};\\\", \\\"{x:1386,y:496,t:1527027348774};\\\", \\\"{x:1387,y:496,t:1527027348787};\\\", \\\"{x:1390,y:496,t:1527027348803};\\\", \\\"{x:1398,y:496,t:1527027348820};\\\", \\\"{x:1405,y:496,t:1527027348837};\\\", \\\"{x:1412,y:496,t:1527027348853};\\\", \\\"{x:1418,y:496,t:1527027348870};\\\", \\\"{x:1419,y:496,t:1527027348887};\\\", \\\"{x:1421,y:496,t:1527027348925};\\\", \\\"{x:1422,y:496,t:1527027348937};\\\", \\\"{x:1424,y:496,t:1527027348954};\\\", \\\"{x:1425,y:496,t:1527027348970};\\\", \\\"{x:1428,y:496,t:1527027348987};\\\", \\\"{x:1430,y:496,t:1527027349004};\\\", \\\"{x:1433,y:496,t:1527027349019};\\\", \\\"{x:1435,y:496,t:1527027349037};\\\", \\\"{x:1436,y:496,t:1527027349069};\\\", \\\"{x:1437,y:496,t:1527027349087};\\\", \\\"{x:1440,y:496,t:1527027349103};\\\", \\\"{x:1446,y:496,t:1527027349120};\\\", \\\"{x:1447,y:496,t:1527027349137};\\\", \\\"{x:1449,y:497,t:1527027349422};\\\", \\\"{x:1450,y:497,t:1527027349437};\\\", \\\"{x:1451,y:497,t:1527027349454};\\\", \\\"{x:1455,y:497,t:1527027349471};\\\", \\\"{x:1461,y:497,t:1527027349487};\\\", \\\"{x:1467,y:497,t:1527027349504};\\\", \\\"{x:1472,y:497,t:1527027349521};\\\", \\\"{x:1477,y:497,t:1527027349536};\\\", \\\"{x:1484,y:497,t:1527027349553};\\\", \\\"{x:1489,y:497,t:1527027349571};\\\", \\\"{x:1495,y:497,t:1527027349587};\\\", \\\"{x:1496,y:497,t:1527027349604};\\\", \\\"{x:1497,y:497,t:1527027349621};\\\", \\\"{x:1499,y:497,t:1527027349669};\\\", \\\"{x:1504,y:497,t:1527027349687};\\\", \\\"{x:1506,y:497,t:1527027349703};\\\", \\\"{x:1507,y:497,t:1527027349721};\\\", \\\"{x:1508,y:497,t:1527027350030};\\\", \\\"{x:1510,y:497,t:1527027350038};\\\", \\\"{x:1516,y:497,t:1527027350054};\\\", \\\"{x:1519,y:497,t:1527027350071};\\\", \\\"{x:1520,y:497,t:1527027350088};\\\", \\\"{x:1521,y:497,t:1527027350270};\\\", \\\"{x:1523,y:497,t:1527027350287};\\\", \\\"{x:1525,y:497,t:1527027350304};\\\", \\\"{x:1530,y:497,t:1527027350320};\\\", \\\"{x:1532,y:497,t:1527027350338};\\\", \\\"{x:1536,y:497,t:1527027350354};\\\", \\\"{x:1539,y:497,t:1527027350370};\\\", \\\"{x:1545,y:497,t:1527027350387};\\\", \\\"{x:1549,y:497,t:1527027350404};\\\", \\\"{x:1556,y:497,t:1527027350421};\\\", \\\"{x:1561,y:497,t:1527027350438};\\\", \\\"{x:1562,y:497,t:1527027350455};\\\", \\\"{x:1563,y:497,t:1527027350493};\\\", \\\"{x:1565,y:497,t:1527027350505};\\\", \\\"{x:1567,y:497,t:1527027350520};\\\", \\\"{x:1569,y:496,t:1527027350538};\\\", \\\"{x:1570,y:496,t:1527027350646};\\\", \\\"{x:1571,y:496,t:1527027350654};\\\", \\\"{x:1573,y:495,t:1527027350671};\\\", \\\"{x:1575,y:495,t:1527027350687};\\\", \\\"{x:1576,y:495,t:1527027350878};\\\", \\\"{x:1578,y:495,t:1527027350888};\\\", \\\"{x:1583,y:495,t:1527027350905};\\\", \\\"{x:1590,y:493,t:1527027350922};\\\", \\\"{x:1596,y:492,t:1527027350938};\\\", \\\"{x:1601,y:492,t:1527027350955};\\\", \\\"{x:1605,y:492,t:1527027350972};\\\", \\\"{x:1609,y:492,t:1527027350988};\\\", \\\"{x:1615,y:492,t:1527027351005};\\\", \\\"{x:1622,y:492,t:1527027351022};\\\", \\\"{x:1627,y:492,t:1527027351038};\\\", \\\"{x:1629,y:492,t:1527027351055};\\\", \\\"{x:1632,y:492,t:1527027351072};\\\", \\\"{x:1634,y:492,t:1527027351093};\\\", \\\"{x:1635,y:492,t:1527027351110};\\\", \\\"{x:1637,y:492,t:1527027351125};\\\", \\\"{x:1638,y:492,t:1527027351141};\\\", \\\"{x:1639,y:492,t:1527027351154};\\\", \\\"{x:1641,y:492,t:1527027351171};\\\", \\\"{x:1643,y:492,t:1527027351188};\\\", \\\"{x:1644,y:492,t:1527027351205};\\\", \\\"{x:1645,y:492,t:1527027351285};\\\", \\\"{x:1647,y:492,t:1527027351559};\\\", \\\"{x:1651,y:492,t:1527027351573};\\\", \\\"{x:1653,y:492,t:1527027351588};\\\", \\\"{x:1661,y:493,t:1527027351605};\\\", \\\"{x:1665,y:494,t:1527027351621};\\\", \\\"{x:1669,y:494,t:1527027351639};\\\", \\\"{x:1672,y:494,t:1527027351656};\\\", \\\"{x:1676,y:494,t:1527027351671};\\\", \\\"{x:1677,y:495,t:1527027351689};\\\", \\\"{x:1678,y:495,t:1527027351706};\\\", \\\"{x:1679,y:495,t:1527027351725};\\\", \\\"{x:1680,y:495,t:1527027351741};\\\", \\\"{x:1681,y:495,t:1527027351756};\\\", \\\"{x:1683,y:496,t:1527027351782};\\\", \\\"{x:1684,y:496,t:1527027351789};\\\", \\\"{x:1688,y:497,t:1527027351806};\\\", \\\"{x:1695,y:497,t:1527027351822};\\\", \\\"{x:1702,y:498,t:1527027351839};\\\", \\\"{x:1711,y:500,t:1527027351855};\\\", \\\"{x:1718,y:500,t:1527027351871};\\\", \\\"{x:1725,y:500,t:1527027351889};\\\", \\\"{x:1729,y:500,t:1527027351906};\\\", \\\"{x:1727,y:500,t:1527027352126};\\\", \\\"{x:1726,y:500,t:1527027352182};\\\", \\\"{x:1726,y:499,t:1527027352190};\\\", \\\"{x:1727,y:499,t:1527027352334};\\\", \\\"{x:1729,y:499,t:1527027352341};\\\", \\\"{x:1733,y:499,t:1527027352356};\\\", \\\"{x:1738,y:499,t:1527027352372};\\\", \\\"{x:1746,y:499,t:1527027352389};\\\", \\\"{x:1751,y:499,t:1527027352406};\\\", \\\"{x:1753,y:499,t:1527027352422};\\\", \\\"{x:1754,y:499,t:1527027352439};\\\", \\\"{x:1755,y:499,t:1527027352461};\\\", \\\"{x:1756,y:499,t:1527027352477};\\\", \\\"{x:1758,y:499,t:1527027352494};\\\", \\\"{x:1759,y:499,t:1527027352506};\\\", \\\"{x:1763,y:499,t:1527027352523};\\\", \\\"{x:1768,y:499,t:1527027352540};\\\", \\\"{x:1769,y:499,t:1527027352556};\\\", \\\"{x:1770,y:499,t:1527027352614};\\\", \\\"{x:1773,y:497,t:1527027352623};\\\", \\\"{x:1776,y:497,t:1527027352640};\\\", \\\"{x:1779,y:497,t:1527027352656};\\\", \\\"{x:1780,y:496,t:1527027352674};\\\", \\\"{x:1780,y:495,t:1527027352750};\\\", \\\"{x:1779,y:495,t:1527027352765};\\\", \\\"{x:1777,y:495,t:1527027352774};\\\", \\\"{x:1770,y:495,t:1527027352789};\\\", \\\"{x:1756,y:496,t:1527027352806};\\\", \\\"{x:1731,y:501,t:1527027352823};\\\", \\\"{x:1681,y:513,t:1527027352840};\\\", \\\"{x:1622,y:521,t:1527027352856};\\\", \\\"{x:1561,y:523,t:1527027352873};\\\", \\\"{x:1505,y:523,t:1527027352890};\\\", \\\"{x:1463,y:523,t:1527027352906};\\\", \\\"{x:1438,y:523,t:1527027352923};\\\", \\\"{x:1427,y:523,t:1527027352941};\\\", \\\"{x:1416,y:523,t:1527027352957};\\\", \\\"{x:1413,y:523,t:1527027352973};\\\", \\\"{x:1409,y:523,t:1527027352990};\\\", \\\"{x:1401,y:523,t:1527027353007};\\\", \\\"{x:1391,y:523,t:1527027353024};\\\", \\\"{x:1384,y:523,t:1527027353040};\\\", \\\"{x:1383,y:523,t:1527027353057};\\\", \\\"{x:1380,y:523,t:1527027353073};\\\", \\\"{x:1373,y:521,t:1527027353090};\\\", \\\"{x:1364,y:517,t:1527027353107};\\\", \\\"{x:1349,y:516,t:1527027353123};\\\", \\\"{x:1334,y:513,t:1527027353140};\\\", \\\"{x:1317,y:510,t:1527027353158};\\\", \\\"{x:1310,y:508,t:1527027353173};\\\", \\\"{x:1310,y:507,t:1527027353190};\\\", \\\"{x:1311,y:506,t:1527027353213};\\\", \\\"{x:1313,y:504,t:1527027353230};\\\", \\\"{x:1314,y:504,t:1527027353240};\\\", \\\"{x:1316,y:503,t:1527027353257};\\\", \\\"{x:1316,y:502,t:1527027353278};\\\", \\\"{x:1316,y:501,t:1527027353307};\\\", \\\"{x:1317,y:501,t:1527027353324};\\\", \\\"{x:1318,y:500,t:1527027353340};\\\", \\\"{x:1321,y:499,t:1527027353358};\\\", \\\"{x:1322,y:498,t:1527027353374};\\\", \\\"{x:1322,y:496,t:1527027353422};\\\", \\\"{x:1323,y:496,t:1527027353518};\\\", \\\"{x:1327,y:496,t:1527027353526};\\\", \\\"{x:1331,y:496,t:1527027353540};\\\", \\\"{x:1341,y:496,t:1527027353557};\\\", \\\"{x:1359,y:496,t:1527027353574};\\\", \\\"{x:1368,y:496,t:1527027353590};\\\", \\\"{x:1377,y:496,t:1527027353607};\\\", \\\"{x:1380,y:496,t:1527027353624};\\\", \\\"{x:1383,y:495,t:1527027353641};\\\", \\\"{x:1384,y:495,t:1527027353686};\\\", \\\"{x:1385,y:495,t:1527027353701};\\\", \\\"{x:1384,y:495,t:1527027353877};\\\", \\\"{x:1383,y:495,t:1527027353950};\\\", \\\"{x:1382,y:495,t:1527027354055};\\\", \\\"{x:1382,y:496,t:1527027354110};\\\", \\\"{x:1384,y:496,t:1527027354124};\\\", \\\"{x:1395,y:497,t:1527027354142};\\\", \\\"{x:1400,y:497,t:1527027354157};\\\", \\\"{x:1411,y:499,t:1527027354174};\\\", \\\"{x:1420,y:499,t:1527027354191};\\\", \\\"{x:1428,y:500,t:1527027354208};\\\", \\\"{x:1429,y:500,t:1527027354224};\\\", \\\"{x:1430,y:500,t:1527027354241};\\\", \\\"{x:1431,y:500,t:1527027354269};\\\", \\\"{x:1432,y:500,t:1527027354294};\\\", \\\"{x:1433,y:500,t:1527027354374};\\\", \\\"{x:1434,y:500,t:1527027354392};\\\", \\\"{x:1435,y:500,t:1527027354408};\\\", \\\"{x:1437,y:500,t:1527027354424};\\\", \\\"{x:1438,y:500,t:1527027354441};\\\", \\\"{x:1439,y:500,t:1527027354478};\\\", \\\"{x:1440,y:500,t:1527027354518};\\\", \\\"{x:1441,y:500,t:1527027354533};\\\", \\\"{x:1442,y:499,t:1527027354558};\\\", \\\"{x:1443,y:499,t:1527027354766};\\\", \\\"{x:1444,y:499,t:1527027354775};\\\", \\\"{x:1446,y:499,t:1527027354792};\\\", \\\"{x:1452,y:499,t:1527027354809};\\\", \\\"{x:1458,y:499,t:1527027354825};\\\", \\\"{x:1462,y:498,t:1527027354841};\\\", \\\"{x:1465,y:498,t:1527027354857};\\\", \\\"{x:1466,y:498,t:1527027354874};\\\", \\\"{x:1468,y:498,t:1527027354891};\\\", \\\"{x:1470,y:497,t:1527027354907};\\\", \\\"{x:1474,y:497,t:1527027354924};\\\", \\\"{x:1479,y:496,t:1527027354940};\\\", \\\"{x:1482,y:496,t:1527027354957};\\\", \\\"{x:1486,y:496,t:1527027354974};\\\", \\\"{x:1489,y:496,t:1527027354991};\\\", \\\"{x:1494,y:496,t:1527027355007};\\\", \\\"{x:1497,y:496,t:1527027355025};\\\", \\\"{x:1498,y:496,t:1527027355041};\\\", \\\"{x:1499,y:496,t:1527027355058};\\\", \\\"{x:1500,y:495,t:1527027355085};\\\", \\\"{x:1501,y:495,t:1527027355166};\\\", \\\"{x:1502,y:495,t:1527027355176};\\\", \\\"{x:1503,y:495,t:1527027355192};\\\", \\\"{x:1504,y:495,t:1527027355208};\\\", \\\"{x:1506,y:495,t:1527027355429};\\\", \\\"{x:1507,y:495,t:1527027355442};\\\", \\\"{x:1508,y:493,t:1527027355458};\\\", \\\"{x:1513,y:493,t:1527027355475};\\\", \\\"{x:1516,y:493,t:1527027355492};\\\", \\\"{x:1520,y:493,t:1527027355509};\\\", \\\"{x:1523,y:492,t:1527027355525};\\\", \\\"{x:1524,y:492,t:1527027355549};\\\", \\\"{x:1524,y:491,t:1527027355559};\\\", \\\"{x:1526,y:491,t:1527027355598};\\\", \\\"{x:1529,y:491,t:1527027355614};\\\", \\\"{x:1532,y:491,t:1527027355625};\\\", \\\"{x:1538,y:491,t:1527027355642};\\\", \\\"{x:1543,y:491,t:1527027355659};\\\", \\\"{x:1547,y:491,t:1527027355675};\\\", \\\"{x:1550,y:491,t:1527027355692};\\\", \\\"{x:1552,y:491,t:1527027355709};\\\", \\\"{x:1553,y:491,t:1527027355790};\\\", \\\"{x:1554,y:491,t:1527027355806};\\\", \\\"{x:1555,y:491,t:1527027355822};\\\", \\\"{x:1556,y:491,t:1527027355837};\\\", \\\"{x:1557,y:491,t:1527027355846};\\\", \\\"{x:1558,y:491,t:1527027355862};\\\", \\\"{x:1560,y:491,t:1527027355910};\\\", \\\"{x:1570,y:493,t:1527027355925};\\\", \\\"{x:1589,y:495,t:1527027355942};\\\", \\\"{x:1609,y:495,t:1527027355959};\\\", \\\"{x:1619,y:496,t:1527027355977};\\\", \\\"{x:1620,y:496,t:1527027355993};\\\", \\\"{x:1619,y:496,t:1527027356133};\\\", \\\"{x:1618,y:496,t:1527027356142};\\\", \\\"{x:1616,y:495,t:1527027356159};\\\", \\\"{x:1611,y:494,t:1527027356176};\\\", \\\"{x:1607,y:494,t:1527027356191};\\\", \\\"{x:1599,y:494,t:1527027356209};\\\", \\\"{x:1591,y:494,t:1527027356225};\\\", \\\"{x:1587,y:494,t:1527027356242};\\\", \\\"{x:1585,y:494,t:1527027356258};\\\", \\\"{x:1583,y:494,t:1527027356276};\\\", \\\"{x:1582,y:494,t:1527027356292};\\\", \\\"{x:1580,y:494,t:1527027356309};\\\", \\\"{x:1578,y:494,t:1527027356326};\\\", \\\"{x:1577,y:494,t:1527027356342};\\\", \\\"{x:1575,y:494,t:1527027356359};\\\", \\\"{x:1574,y:494,t:1527027356381};\\\", \\\"{x:1575,y:494,t:1527027356508};\\\", \\\"{x:1576,y:494,t:1527027356677};\\\", \\\"{x:1575,y:493,t:1527027356701};\\\", \\\"{x:1574,y:493,t:1527027356718};\\\", \\\"{x:1572,y:493,t:1527027356725};\\\", \\\"{x:1567,y:493,t:1527027356743};\\\", \\\"{x:1560,y:493,t:1527027356759};\\\", \\\"{x:1552,y:493,t:1527027356775};\\\", \\\"{x:1547,y:493,t:1527027356792};\\\", \\\"{x:1546,y:493,t:1527027356809};\\\", \\\"{x:1545,y:493,t:1527027356926};\\\", \\\"{x:1544,y:493,t:1527027356990};\\\", \\\"{x:1544,y:494,t:1527027356998};\\\", \\\"{x:1544,y:495,t:1527027357046};\\\", \\\"{x:1543,y:499,t:1527027362270};\\\", \\\"{x:1538,y:504,t:1527027362281};\\\", \\\"{x:1518,y:515,t:1527027362297};\\\", \\\"{x:1490,y:524,t:1527027362315};\\\", \\\"{x:1458,y:533,t:1527027362330};\\\", \\\"{x:1418,y:540,t:1527027362347};\\\", \\\"{x:1384,y:545,t:1527027362365};\\\", \\\"{x:1344,y:550,t:1527027362381};\\\", \\\"{x:1273,y:555,t:1527027362397};\\\", \\\"{x:1227,y:558,t:1527027362414};\\\", \\\"{x:1185,y:562,t:1527027362431};\\\", \\\"{x:1157,y:564,t:1527027362448};\\\", \\\"{x:1132,y:567,t:1527027362465};\\\", \\\"{x:1111,y:567,t:1527027362481};\\\", \\\"{x:1091,y:571,t:1527027362497};\\\", \\\"{x:1073,y:573,t:1527027362515};\\\", \\\"{x:1055,y:575,t:1527027362531};\\\", \\\"{x:1038,y:576,t:1527027362548};\\\", \\\"{x:1027,y:577,t:1527027362564};\\\", \\\"{x:1021,y:578,t:1527027362581};\\\", \\\"{x:1020,y:578,t:1527027362597};\\\", \\\"{x:1024,y:578,t:1527027362782};\\\", \\\"{x:1033,y:578,t:1527027362797};\\\", \\\"{x:1041,y:577,t:1527027362815};\\\", \\\"{x:1046,y:577,t:1527027362831};\\\", \\\"{x:1047,y:576,t:1527027362848};\\\", \\\"{x:1048,y:576,t:1527027362865};\\\", \\\"{x:1049,y:576,t:1527027362881};\\\", \\\"{x:1049,y:575,t:1527027362898};\\\", \\\"{x:1050,y:575,t:1527027362926};\\\", \\\"{x:1052,y:575,t:1527027362933};\\\", \\\"{x:1053,y:575,t:1527027362949};\\\", \\\"{x:1054,y:574,t:1527027362964};\\\", \\\"{x:1055,y:574,t:1527027362982};\\\", \\\"{x:1056,y:573,t:1527027362997};\\\", \\\"{x:1057,y:572,t:1527027363038};\\\", \\\"{x:1059,y:571,t:1527027363053};\\\", \\\"{x:1059,y:570,t:1527027363065};\\\", \\\"{x:1061,y:566,t:1527027363082};\\\", \\\"{x:1062,y:565,t:1527027363098};\\\", \\\"{x:1062,y:564,t:1527027363114};\\\", \\\"{x:1062,y:563,t:1527027363189};\\\", \\\"{x:1061,y:563,t:1527027363326};\\\", \\\"{x:1058,y:563,t:1527027363333};\\\", \\\"{x:1055,y:563,t:1527027363349};\\\", \\\"{x:1046,y:564,t:1527027363365};\\\", \\\"{x:1019,y:567,t:1527027363382};\\\", \\\"{x:987,y:567,t:1527027363398};\\\", \\\"{x:940,y:567,t:1527027363417};\\\", \\\"{x:876,y:567,t:1527027363431};\\\", \\\"{x:817,y:567,t:1527027363447};\\\", \\\"{x:769,y:567,t:1527027363465};\\\", \\\"{x:745,y:567,t:1527027363482};\\\", \\\"{x:730,y:567,t:1527027363497};\\\", \\\"{x:721,y:567,t:1527027363515};\\\", \\\"{x:716,y:567,t:1527027363532};\\\", \\\"{x:711,y:567,t:1527027363547};\\\", \\\"{x:700,y:567,t:1527027363564};\\\", \\\"{x:695,y:567,t:1527027363582};\\\", \\\"{x:689,y:567,t:1527027363597};\\\", \\\"{x:685,y:567,t:1527027363615};\\\", \\\"{x:684,y:567,t:1527027363631};\\\", \\\"{x:683,y:567,t:1527027363765};\\\", \\\"{x:685,y:567,t:1527027363789};\\\", \\\"{x:691,y:567,t:1527027363798};\\\", \\\"{x:705,y:567,t:1527027363815};\\\", \\\"{x:728,y:567,t:1527027363834};\\\", \\\"{x:756,y:567,t:1527027363848};\\\", \\\"{x:787,y:567,t:1527027363866};\\\", \\\"{x:819,y:565,t:1527027363882};\\\", \\\"{x:854,y:562,t:1527027363899};\\\", \\\"{x:879,y:558,t:1527027363915};\\\", \\\"{x:897,y:556,t:1527027363933};\\\", \\\"{x:910,y:553,t:1527027363947};\\\", \\\"{x:918,y:550,t:1527027363965};\\\", \\\"{x:921,y:547,t:1527027363982};\\\", \\\"{x:927,y:543,t:1527027363998};\\\", \\\"{x:930,y:540,t:1527027364015};\\\", \\\"{x:932,y:539,t:1527027364032};\\\", \\\"{x:932,y:537,t:1527027364048};\\\", \\\"{x:933,y:535,t:1527027364066};\\\", \\\"{x:933,y:534,t:1527027364082};\\\", \\\"{x:934,y:532,t:1527027364098};\\\", \\\"{x:934,y:531,t:1527027364114};\\\", \\\"{x:934,y:530,t:1527027364133};\\\", \\\"{x:934,y:527,t:1527027364148};\\\", \\\"{x:920,y:523,t:1527027364164};\\\", \\\"{x:900,y:519,t:1527027364182};\\\", \\\"{x:881,y:518,t:1527027364198};\\\", \\\"{x:862,y:518,t:1527027364214};\\\", \\\"{x:842,y:518,t:1527027364232};\\\", \\\"{x:822,y:518,t:1527027364249};\\\", \\\"{x:803,y:520,t:1527027364267};\\\", \\\"{x:783,y:520,t:1527027364282};\\\", \\\"{x:769,y:520,t:1527027364299};\\\", \\\"{x:764,y:520,t:1527027364316};\\\", \\\"{x:760,y:521,t:1527027364332};\\\", \\\"{x:757,y:522,t:1527027364349};\\\", \\\"{x:755,y:524,t:1527027364366};\\\", \\\"{x:753,y:527,t:1527027364382};\\\", \\\"{x:751,y:530,t:1527027364399};\\\", \\\"{x:749,y:532,t:1527027364417};\\\", \\\"{x:749,y:534,t:1527027364432};\\\", \\\"{x:747,y:537,t:1527027364449};\\\", \\\"{x:747,y:540,t:1527027364466};\\\", \\\"{x:747,y:541,t:1527027364482};\\\", \\\"{x:747,y:543,t:1527027364499};\\\", \\\"{x:747,y:544,t:1527027364515};\\\", \\\"{x:755,y:548,t:1527027364532};\\\", \\\"{x:774,y:552,t:1527027364550};\\\", \\\"{x:787,y:553,t:1527027364566};\\\", \\\"{x:791,y:553,t:1527027364582};\\\", \\\"{x:788,y:553,t:1527027364645};\\\", \\\"{x:781,y:550,t:1527027364652};\\\", \\\"{x:767,y:549,t:1527027364666};\\\", \\\"{x:740,y:546,t:1527027364682};\\\", \\\"{x:708,y:540,t:1527027364700};\\\", \\\"{x:679,y:536,t:1527027364716};\\\", \\\"{x:660,y:533,t:1527027364732};\\\", \\\"{x:652,y:532,t:1527027364749};\\\", \\\"{x:649,y:531,t:1527027364796};\\\", \\\"{x:648,y:531,t:1527027364805};\\\", \\\"{x:645,y:531,t:1527027364816};\\\", \\\"{x:635,y:529,t:1527027364832};\\\", \\\"{x:627,y:529,t:1527027364849};\\\", \\\"{x:621,y:529,t:1527027364867};\\\", \\\"{x:619,y:529,t:1527027364884};\\\", \\\"{x:619,y:528,t:1527027364909};\\\", \\\"{x:618,y:528,t:1527027364917};\\\", \\\"{x:614,y:528,t:1527027364933};\\\", \\\"{x:610,y:528,t:1527027364949};\\\", \\\"{x:608,y:528,t:1527027364966};\\\", \\\"{x:607,y:528,t:1527027364983};\\\", \\\"{x:607,y:527,t:1527027365349};\\\", \\\"{x:607,y:526,t:1527027365356};\\\", \\\"{x:608,y:526,t:1527027365366};\\\", \\\"{x:614,y:525,t:1527027365383};\\\", \\\"{x:623,y:524,t:1527027365400};\\\", \\\"{x:641,y:524,t:1527027365416};\\\", \\\"{x:662,y:524,t:1527027365433};\\\", \\\"{x:683,y:524,t:1527027365450};\\\", \\\"{x:708,y:524,t:1527027365466};\\\", \\\"{x:730,y:524,t:1527027365484};\\\", \\\"{x:751,y:524,t:1527027365500};\\\", \\\"{x:770,y:524,t:1527027365516};\\\", \\\"{x:801,y:520,t:1527027365533};\\\", \\\"{x:828,y:515,t:1527027365551};\\\", \\\"{x:853,y:513,t:1527027365566};\\\", \\\"{x:882,y:508,t:1527027365583};\\\", \\\"{x:911,y:508,t:1527027365601};\\\", \\\"{x:934,y:508,t:1527027365617};\\\", \\\"{x:952,y:507,t:1527027365634};\\\", \\\"{x:963,y:505,t:1527027365650};\\\", \\\"{x:974,y:504,t:1527027365667};\\\", \\\"{x:984,y:504,t:1527027365684};\\\", \\\"{x:991,y:504,t:1527027365700};\\\", \\\"{x:998,y:504,t:1527027365718};\\\", \\\"{x:1006,y:504,t:1527027365733};\\\", \\\"{x:1016,y:504,t:1527027365751};\\\", \\\"{x:1026,y:504,t:1527027365767};\\\", \\\"{x:1038,y:504,t:1527027365783};\\\", \\\"{x:1048,y:504,t:1527027365801};\\\", \\\"{x:1059,y:504,t:1527027365818};\\\", \\\"{x:1070,y:504,t:1527027365836};\\\", \\\"{x:1081,y:504,t:1527027365851};\\\", \\\"{x:1092,y:504,t:1527027365868};\\\", \\\"{x:1108,y:504,t:1527027365885};\\\", \\\"{x:1121,y:504,t:1527027365900};\\\", \\\"{x:1142,y:504,t:1527027365917};\\\", \\\"{x:1153,y:504,t:1527027365935};\\\", \\\"{x:1164,y:504,t:1527027365951};\\\", \\\"{x:1173,y:504,t:1527027365967};\\\", \\\"{x:1178,y:503,t:1527027365985};\\\", \\\"{x:1185,y:503,t:1527027366001};\\\", \\\"{x:1189,y:503,t:1527027366018};\\\", \\\"{x:1192,y:503,t:1527027366035};\\\", \\\"{x:1195,y:503,t:1527027366051};\\\", \\\"{x:1199,y:503,t:1527027366067};\\\", \\\"{x:1201,y:503,t:1527027366085};\\\", \\\"{x:1204,y:503,t:1527027366102};\\\", \\\"{x:1206,y:503,t:1527027366117};\\\", \\\"{x:1211,y:501,t:1527027366134};\\\", \\\"{x:1217,y:501,t:1527027366151};\\\", \\\"{x:1224,y:500,t:1527027366167};\\\", \\\"{x:1229,y:499,t:1527027366184};\\\", \\\"{x:1235,y:499,t:1527027366201};\\\", \\\"{x:1239,y:497,t:1527027366217};\\\", \\\"{x:1240,y:497,t:1527027366235};\\\", \\\"{x:1240,y:496,t:1527027366261};\\\", \\\"{x:1241,y:495,t:1527027366285};\\\", \\\"{x:1241,y:494,t:1527027366421};\\\", \\\"{x:1241,y:493,t:1527027366435};\\\", \\\"{x:1230,y:492,t:1527027366451};\\\", \\\"{x:1215,y:492,t:1527027366468};\\\", \\\"{x:1196,y:492,t:1527027366484};\\\", \\\"{x:1165,y:495,t:1527027366501};\\\", \\\"{x:1151,y:497,t:1527027366518};\\\", \\\"{x:1142,y:499,t:1527027366534};\\\", \\\"{x:1137,y:500,t:1527027366551};\\\", \\\"{x:1135,y:500,t:1527027366568};\\\", \\\"{x:1132,y:500,t:1527027366584};\\\", \\\"{x:1130,y:501,t:1527027366601};\\\", \\\"{x:1127,y:501,t:1527027366619};\\\", \\\"{x:1121,y:503,t:1527027366635};\\\", \\\"{x:1118,y:503,t:1527027366651};\\\", \\\"{x:1116,y:503,t:1527027366669};\\\", \\\"{x:1115,y:503,t:1527027366685};\\\", \\\"{x:1117,y:503,t:1527027366766};\\\", \\\"{x:1118,y:503,t:1527027366773};\\\", \\\"{x:1120,y:503,t:1527027366786};\\\", \\\"{x:1131,y:503,t:1527027366801};\\\", \\\"{x:1146,y:502,t:1527027366819};\\\", \\\"{x:1168,y:502,t:1527027366836};\\\", \\\"{x:1190,y:502,t:1527027366852};\\\", \\\"{x:1216,y:502,t:1527027366868};\\\", \\\"{x:1251,y:502,t:1527027366886};\\\", \\\"{x:1271,y:502,t:1527027366903};\\\", \\\"{x:1286,y:502,t:1527027366918};\\\", \\\"{x:1296,y:502,t:1527027366935};\\\", \\\"{x:1302,y:502,t:1527027366953};\\\", \\\"{x:1307,y:502,t:1527027366969};\\\", \\\"{x:1311,y:499,t:1527027366986};\\\", \\\"{x:1316,y:499,t:1527027367002};\\\", \\\"{x:1321,y:499,t:1527027367020};\\\", \\\"{x:1325,y:498,t:1527027367036};\\\", \\\"{x:1326,y:498,t:1527027367053};\\\", \\\"{x:1323,y:498,t:1527027367230};\\\", \\\"{x:1318,y:499,t:1527027367238};\\\", \\\"{x:1311,y:503,t:1527027367254};\\\", \\\"{x:1294,y:514,t:1527027367270};\\\", \\\"{x:1280,y:520,t:1527027367285};\\\", \\\"{x:1270,y:525,t:1527027367303};\\\", \\\"{x:1262,y:529,t:1527027367319};\\\", \\\"{x:1252,y:533,t:1527027367335};\\\", \\\"{x:1243,y:538,t:1527027367353};\\\", \\\"{x:1233,y:542,t:1527027367370};\\\", \\\"{x:1223,y:547,t:1527027367385};\\\", \\\"{x:1209,y:553,t:1527027367403};\\\", \\\"{x:1198,y:557,t:1527027367420};\\\", \\\"{x:1189,y:560,t:1527027367436};\\\", \\\"{x:1179,y:563,t:1527027367453};\\\", \\\"{x:1167,y:568,t:1527027367470};\\\", \\\"{x:1159,y:572,t:1527027367487};\\\", \\\"{x:1152,y:573,t:1527027367502};\\\", \\\"{x:1147,y:576,t:1527027367519};\\\", \\\"{x:1149,y:576,t:1527027367670};\\\", \\\"{x:1157,y:575,t:1527027367687};\\\", \\\"{x:1163,y:575,t:1527027367704};\\\", \\\"{x:1168,y:575,t:1527027367720};\\\", \\\"{x:1169,y:575,t:1527027367830};\\\", \\\"{x:1170,y:575,t:1527027367886};\\\", \\\"{x:1172,y:575,t:1527027367942};\\\", \\\"{x:1174,y:575,t:1527027367954};\\\", \\\"{x:1180,y:575,t:1527027367971};\\\", \\\"{x:1191,y:575,t:1527027367986};\\\", \\\"{x:1205,y:575,t:1527027368004};\\\", \\\"{x:1220,y:575,t:1527027368021};\\\", \\\"{x:1233,y:575,t:1527027368037};\\\", \\\"{x:1249,y:573,t:1527027368053};\\\", \\\"{x:1261,y:571,t:1527027368070};\\\", \\\"{x:1272,y:569,t:1527027368087};\\\", \\\"{x:1280,y:567,t:1527027368103};\\\", \\\"{x:1291,y:564,t:1527027368120};\\\", \\\"{x:1301,y:562,t:1527027368137};\\\", \\\"{x:1314,y:560,t:1527027368154};\\\", \\\"{x:1325,y:557,t:1527027368170};\\\", \\\"{x:1336,y:557,t:1527027368187};\\\", \\\"{x:1348,y:556,t:1527027368204};\\\", \\\"{x:1356,y:555,t:1527027368221};\\\", \\\"{x:1368,y:555,t:1527027368237};\\\", \\\"{x:1373,y:555,t:1527027368254};\\\", \\\"{x:1379,y:555,t:1527027368270};\\\", \\\"{x:1382,y:555,t:1527027368287};\\\", \\\"{x:1385,y:554,t:1527027368303};\\\", \\\"{x:1386,y:554,t:1527027368320};\\\", \\\"{x:1387,y:554,t:1527027368340};\\\", \\\"{x:1388,y:554,t:1527027368365};\\\", \\\"{x:1389,y:554,t:1527027368373};\\\", \\\"{x:1390,y:554,t:1527027368389};\\\", \\\"{x:1391,y:554,t:1527027368405};\\\", \\\"{x:1392,y:554,t:1527027368420};\\\", \\\"{x:1393,y:554,t:1527027368453};\\\", \\\"{x:1394,y:554,t:1527027368469};\\\", \\\"{x:1395,y:554,t:1527027368477};\\\", \\\"{x:1398,y:554,t:1527027368487};\\\", \\\"{x:1399,y:554,t:1527027368505};\\\", \\\"{x:1402,y:554,t:1527027368520};\\\", \\\"{x:1403,y:554,t:1527027368537};\\\", \\\"{x:1404,y:554,t:1527027368557};\\\", \\\"{x:1405,y:555,t:1527027368571};\\\", \\\"{x:1406,y:555,t:1527027368630};\\\", \\\"{x:1407,y:555,t:1527027368669};\\\", \\\"{x:1408,y:555,t:1527027369086};\\\", \\\"{x:1409,y:555,t:1527027369094};\\\", \\\"{x:1409,y:556,t:1527027369105};\\\", \\\"{x:1412,y:556,t:1527027369122};\\\", \\\"{x:1415,y:557,t:1527027369139};\\\", \\\"{x:1418,y:557,t:1527027369155};\\\", \\\"{x:1421,y:557,t:1527027369172};\\\", \\\"{x:1422,y:557,t:1527027369189};\\\", \\\"{x:1424,y:557,t:1527027369206};\\\", \\\"{x:1426,y:557,t:1527027369222};\\\", \\\"{x:1431,y:559,t:1527027369239};\\\", \\\"{x:1434,y:560,t:1527027369256};\\\", \\\"{x:1441,y:560,t:1527027369272};\\\", \\\"{x:1445,y:560,t:1527027369288};\\\", \\\"{x:1449,y:560,t:1527027369305};\\\", \\\"{x:1452,y:560,t:1527027369321};\\\", \\\"{x:1453,y:560,t:1527027369338};\\\", \\\"{x:1454,y:560,t:1527027369365};\\\", \\\"{x:1455,y:560,t:1527027369372};\\\", \\\"{x:1456,y:560,t:1527027369396};\\\", \\\"{x:1457,y:560,t:1527027369429};\\\", \\\"{x:1458,y:560,t:1527027369438};\\\", \\\"{x:1459,y:560,t:1527027369455};\\\", \\\"{x:1460,y:561,t:1527027369477};\\\", \\\"{x:1462,y:561,t:1527027369489};\\\", \\\"{x:1464,y:561,t:1527027369505};\\\", \\\"{x:1466,y:561,t:1527027369522};\\\", \\\"{x:1470,y:561,t:1527027369539};\\\", \\\"{x:1472,y:561,t:1527027369555};\\\", \\\"{x:1475,y:561,t:1527027369572};\\\", \\\"{x:1476,y:561,t:1527027369588};\\\", \\\"{x:1480,y:561,t:1527027369606};\\\", \\\"{x:1481,y:561,t:1527027369623};\\\", \\\"{x:1482,y:561,t:1527027369638};\\\", \\\"{x:1483,y:561,t:1527027369886};\\\", \\\"{x:1485,y:561,t:1527027369892};\\\", \\\"{x:1486,y:561,t:1527027369905};\\\", \\\"{x:1490,y:561,t:1527027369922};\\\", \\\"{x:1496,y:561,t:1527027369939};\\\", \\\"{x:1500,y:561,t:1527027369955};\\\", \\\"{x:1505,y:561,t:1527027369972};\\\", \\\"{x:1509,y:561,t:1527027369989};\\\", \\\"{x:1510,y:561,t:1527027370013};\\\", \\\"{x:1511,y:561,t:1527027370036};\\\", \\\"{x:1512,y:561,t:1527027370053};\\\", \\\"{x:1513,y:561,t:1527027370069};\\\", \\\"{x:1515,y:561,t:1527027370077};\\\", \\\"{x:1516,y:561,t:1527027370090};\\\", \\\"{x:1520,y:561,t:1527027370107};\\\", \\\"{x:1524,y:561,t:1527027370122};\\\", \\\"{x:1528,y:562,t:1527027370139};\\\", \\\"{x:1534,y:562,t:1527027370156};\\\", \\\"{x:1535,y:562,t:1527027370172};\\\", \\\"{x:1538,y:563,t:1527027370190};\\\", \\\"{x:1541,y:563,t:1527027370207};\\\", \\\"{x:1543,y:563,t:1527027370493};\\\", \\\"{x:1544,y:563,t:1527027370506};\\\", \\\"{x:1546,y:563,t:1527027370524};\\\", \\\"{x:1548,y:563,t:1527027370541};\\\", \\\"{x:1550,y:563,t:1527027370557};\\\", \\\"{x:1552,y:563,t:1527027370574};\\\", \\\"{x:1553,y:563,t:1527027370606};\\\", \\\"{x:1555,y:563,t:1527027370630};\\\", \\\"{x:1556,y:563,t:1527027370641};\\\", \\\"{x:1558,y:563,t:1527027370657};\\\", \\\"{x:1562,y:563,t:1527027370674};\\\", \\\"{x:1563,y:563,t:1527027370691};\\\", \\\"{x:1566,y:563,t:1527027370707};\\\", \\\"{x:1571,y:563,t:1527027370723};\\\", \\\"{x:1576,y:563,t:1527027370741};\\\", \\\"{x:1581,y:563,t:1527027370757};\\\", \\\"{x:1586,y:563,t:1527027370774};\\\", \\\"{x:1589,y:563,t:1527027370791};\\\", \\\"{x:1592,y:563,t:1527027370808};\\\", \\\"{x:1594,y:563,t:1527027370823};\\\", \\\"{x:1595,y:563,t:1527027370841};\\\", \\\"{x:1597,y:563,t:1527027370861};\\\", \\\"{x:1598,y:563,t:1527027370874};\\\", \\\"{x:1600,y:563,t:1527027370891};\\\", \\\"{x:1605,y:562,t:1527027370908};\\\", \\\"{x:1612,y:562,t:1527027370924};\\\", \\\"{x:1622,y:561,t:1527027370943};\\\", \\\"{x:1625,y:561,t:1527027370958};\\\", \\\"{x:1626,y:561,t:1527027370974};\\\", \\\"{x:1627,y:561,t:1527027371118};\\\", \\\"{x:1627,y:559,t:1527027371134};\\\", \\\"{x:1625,y:559,t:1527027371158};\\\", \\\"{x:1624,y:559,t:1527027371175};\\\", \\\"{x:1622,y:559,t:1527027371191};\\\", \\\"{x:1620,y:559,t:1527027371208};\\\", \\\"{x:1618,y:559,t:1527027372894};\\\", \\\"{x:1613,y:561,t:1527027372909};\\\", \\\"{x:1606,y:564,t:1527027372928};\\\", \\\"{x:1597,y:569,t:1527027372944};\\\", \\\"{x:1588,y:574,t:1527027372960};\\\", \\\"{x:1577,y:580,t:1527027372977};\\\", \\\"{x:1568,y:585,t:1527027372994};\\\", \\\"{x:1554,y:592,t:1527027373010};\\\", \\\"{x:1542,y:599,t:1527027373027};\\\", \\\"{x:1527,y:608,t:1527027373045};\\\", \\\"{x:1515,y:614,t:1527027373060};\\\", \\\"{x:1503,y:620,t:1527027373078};\\\", \\\"{x:1498,y:623,t:1527027373093};\\\", \\\"{x:1495,y:625,t:1527027373110};\\\", \\\"{x:1492,y:627,t:1527027373127};\\\", \\\"{x:1490,y:628,t:1527027373145};\\\", \\\"{x:1490,y:630,t:1527027373161};\\\", \\\"{x:1489,y:630,t:1527027373357};\\\", \\\"{x:1488,y:630,t:1527027373365};\\\", \\\"{x:1487,y:630,t:1527027373382};\\\", \\\"{x:1490,y:630,t:1527027373502};\\\", \\\"{x:1495,y:630,t:1527027373511};\\\", \\\"{x:1499,y:630,t:1527027373528};\\\", \\\"{x:1505,y:629,t:1527027373544};\\\", \\\"{x:1506,y:629,t:1527027373561};\\\", \\\"{x:1506,y:628,t:1527027373622};\\\", \\\"{x:1500,y:628,t:1527027373646};\\\", \\\"{x:1487,y:628,t:1527027373662};\\\", \\\"{x:1466,y:628,t:1527027373678};\\\", \\\"{x:1439,y:628,t:1527027373695};\\\", \\\"{x:1409,y:628,t:1527027373711};\\\", \\\"{x:1375,y:628,t:1527027373728};\\\", \\\"{x:1352,y:628,t:1527027373744};\\\", \\\"{x:1333,y:628,t:1527027373760};\\\", \\\"{x:1320,y:628,t:1527027373777};\\\", \\\"{x:1309,y:626,t:1527027373794};\\\", \\\"{x:1305,y:626,t:1527027373811};\\\", \\\"{x:1300,y:626,t:1527027373827};\\\", \\\"{x:1298,y:626,t:1527027373844};\\\", \\\"{x:1295,y:626,t:1527027373861};\\\", \\\"{x:1293,y:626,t:1527027373884};\\\", \\\"{x:1292,y:627,t:1527027373895};\\\", \\\"{x:1291,y:627,t:1527027373911};\\\", \\\"{x:1294,y:627,t:1527027374037};\\\", \\\"{x:1297,y:627,t:1527027374045};\\\", \\\"{x:1301,y:627,t:1527027374061};\\\", \\\"{x:1305,y:628,t:1527027374077};\\\", \\\"{x:1306,y:628,t:1527027374095};\\\", \\\"{x:1307,y:628,t:1527027374111};\\\", \\\"{x:1308,y:628,t:1527027374133};\\\", \\\"{x:1309,y:629,t:1527027374174};\\\", \\\"{x:1310,y:629,t:1527027374195};\\\", \\\"{x:1312,y:629,t:1527027374211};\\\", \\\"{x:1315,y:629,t:1527027374229};\\\", \\\"{x:1317,y:629,t:1527027374253};\\\", \\\"{x:1318,y:629,t:1527027374277};\\\", \\\"{x:1320,y:630,t:1527027374350};\\\", \\\"{x:1321,y:630,t:1527027374366};\\\", \\\"{x:1323,y:630,t:1527027374379};\\\", \\\"{x:1324,y:630,t:1527027374395};\\\", \\\"{x:1326,y:630,t:1527027374702};\\\", \\\"{x:1327,y:630,t:1527027374713};\\\", \\\"{x:1331,y:630,t:1527027374729};\\\", \\\"{x:1335,y:630,t:1527027374746};\\\", \\\"{x:1341,y:630,t:1527027374763};\\\", \\\"{x:1343,y:630,t:1527027374779};\\\", \\\"{x:1345,y:630,t:1527027374796};\\\", \\\"{x:1351,y:630,t:1527027374812};\\\", \\\"{x:1357,y:630,t:1527027374828};\\\", \\\"{x:1362,y:630,t:1527027374845};\\\", \\\"{x:1367,y:630,t:1527027374862};\\\", \\\"{x:1371,y:630,t:1527027374878};\\\", \\\"{x:1373,y:630,t:1527027374895};\\\", \\\"{x:1374,y:630,t:1527027374981};\\\", \\\"{x:1375,y:630,t:1527027375206};\\\", \\\"{x:1376,y:630,t:1527027375213};\\\", \\\"{x:1377,y:630,t:1527027375230};\\\", \\\"{x:1380,y:630,t:1527027375247};\\\", \\\"{x:1382,y:630,t:1527027375263};\\\", \\\"{x:1386,y:629,t:1527027375279};\\\", \\\"{x:1388,y:628,t:1527027375296};\\\", \\\"{x:1391,y:628,t:1527027375313};\\\", \\\"{x:1396,y:628,t:1527027375329};\\\", \\\"{x:1401,y:628,t:1527027375346};\\\", \\\"{x:1405,y:627,t:1527027375362};\\\", \\\"{x:1406,y:627,t:1527027375380};\\\", \\\"{x:1407,y:627,t:1527027375397};\\\", \\\"{x:1409,y:626,t:1527027375412};\\\", \\\"{x:1411,y:626,t:1527027375453};\\\", \\\"{x:1412,y:626,t:1527027375464};\\\", \\\"{x:1415,y:625,t:1527027375480};\\\", \\\"{x:1416,y:625,t:1527027375497};\\\", \\\"{x:1417,y:625,t:1527027375514};\\\", \\\"{x:1418,y:625,t:1527027375621};\\\", \\\"{x:1419,y:625,t:1527027375701};\\\", \\\"{x:1420,y:625,t:1527027375714};\\\", \\\"{x:1424,y:625,t:1527027375731};\\\", \\\"{x:1428,y:625,t:1527027375746};\\\", \\\"{x:1431,y:625,t:1527027375764};\\\", \\\"{x:1435,y:625,t:1527027375781};\\\", \\\"{x:1436,y:625,t:1527027375806};\\\", \\\"{x:1437,y:625,t:1527027375821};\\\", \\\"{x:1438,y:625,t:1527027375831};\\\", \\\"{x:1439,y:625,t:1527027375847};\\\", \\\"{x:1441,y:625,t:1527027375863};\\\", \\\"{x:1442,y:625,t:1527027375881};\\\", \\\"{x:1443,y:625,t:1527027375897};\\\", \\\"{x:1444,y:625,t:1527027376086};\\\", \\\"{x:1446,y:624,t:1527027376098};\\\", \\\"{x:1448,y:624,t:1527027376114};\\\", \\\"{x:1454,y:624,t:1527027376131};\\\", \\\"{x:1462,y:622,t:1527027376148};\\\", \\\"{x:1466,y:621,t:1527027376164};\\\", \\\"{x:1470,y:621,t:1527027376181};\\\", \\\"{x:1473,y:621,t:1527027376198};\\\", \\\"{x:1474,y:621,t:1527027376214};\\\", \\\"{x:1475,y:621,t:1527027376231};\\\", \\\"{x:1477,y:621,t:1527027376248};\\\", \\\"{x:1480,y:621,t:1527027376267};\\\", \\\"{x:1484,y:621,t:1527027376280};\\\", \\\"{x:1490,y:621,t:1527027376298};\\\", \\\"{x:1498,y:621,t:1527027376315};\\\", \\\"{x:1500,y:621,t:1527027376330};\\\", \\\"{x:1502,y:621,t:1527027376347};\\\", \\\"{x:1505,y:621,t:1527027376365};\\\", \\\"{x:1508,y:621,t:1527027376380};\\\", \\\"{x:1511,y:621,t:1527027376397};\\\", \\\"{x:1516,y:621,t:1527027376415};\\\", \\\"{x:1520,y:621,t:1527027376431};\\\", \\\"{x:1523,y:621,t:1527027376448};\\\", \\\"{x:1524,y:621,t:1527027376469};\\\", \\\"{x:1522,y:621,t:1527027376782};\\\", \\\"{x:1514,y:623,t:1527027376800};\\\", \\\"{x:1502,y:626,t:1527027376816};\\\", \\\"{x:1490,y:627,t:1527027376832};\\\", \\\"{x:1485,y:627,t:1527027376849};\\\", \\\"{x:1484,y:627,t:1527027376870};\\\", \\\"{x:1483,y:627,t:1527027376885};\\\", \\\"{x:1482,y:627,t:1527027376901};\\\", \\\"{x:1480,y:627,t:1527027376915};\\\", \\\"{x:1479,y:627,t:1527027376932};\\\", \\\"{x:1476,y:628,t:1527027376949};\\\", \\\"{x:1476,y:629,t:1527027377014};\\\", \\\"{x:1478,y:629,t:1527027378581};\\\", \\\"{x:1482,y:629,t:1527027378590};\\\", \\\"{x:1488,y:630,t:1527027378601};\\\", \\\"{x:1498,y:630,t:1527027378618};\\\", \\\"{x:1506,y:630,t:1527027378634};\\\", \\\"{x:1510,y:630,t:1527027378652};\\\", \\\"{x:1512,y:630,t:1527027378709};\\\", \\\"{x:1513,y:630,t:1527027378749};\\\", \\\"{x:1514,y:630,t:1527027378846};\\\", \\\"{x:1514,y:629,t:1527027378901};\\\", \\\"{x:1515,y:627,t:1527027379205};\\\", \\\"{x:1516,y:627,t:1527027379218};\\\", \\\"{x:1519,y:626,t:1527027379235};\\\", \\\"{x:1520,y:626,t:1527027379253};\\\", \\\"{x:1521,y:626,t:1527027379268};\\\", \\\"{x:1523,y:625,t:1527027379284};\\\", \\\"{x:1525,y:625,t:1527027379302};\\\", \\\"{x:1526,y:625,t:1527027379318};\\\", \\\"{x:1530,y:624,t:1527027379335};\\\", \\\"{x:1532,y:623,t:1527027379352};\\\", \\\"{x:1536,y:622,t:1527027379369};\\\", \\\"{x:1539,y:622,t:1527027379385};\\\", \\\"{x:1542,y:622,t:1527027379401};\\\", \\\"{x:1545,y:622,t:1527027379419};\\\", \\\"{x:1551,y:622,t:1527027379435};\\\", \\\"{x:1558,y:620,t:1527027379452};\\\", \\\"{x:1570,y:619,t:1527027379469};\\\", \\\"{x:1576,y:618,t:1527027379485};\\\", \\\"{x:1579,y:618,t:1527027379502};\\\", \\\"{x:1581,y:618,t:1527027379519};\\\", \\\"{x:1577,y:620,t:1527027379637};\\\", \\\"{x:1570,y:624,t:1527027379652};\\\", \\\"{x:1544,y:643,t:1527027379669};\\\", \\\"{x:1520,y:655,t:1527027379686};\\\", \\\"{x:1499,y:665,t:1527027379703};\\\", \\\"{x:1479,y:674,t:1527027379719};\\\", \\\"{x:1460,y:681,t:1527027379736};\\\", \\\"{x:1444,y:688,t:1527027379752};\\\", \\\"{x:1431,y:693,t:1527027379769};\\\", \\\"{x:1422,y:697,t:1527027379786};\\\", \\\"{x:1416,y:702,t:1527027379802};\\\", \\\"{x:1411,y:705,t:1527027379820};\\\", \\\"{x:1408,y:708,t:1527027379837};\\\", \\\"{x:1406,y:712,t:1527027379853};\\\", \\\"{x:1405,y:718,t:1527027379870};\\\", \\\"{x:1404,y:725,t:1527027379885};\\\", \\\"{x:1404,y:730,t:1527027379903};\\\", \\\"{x:1402,y:738,t:1527027379919};\\\", \\\"{x:1401,y:748,t:1527027379936};\\\", \\\"{x:1401,y:754,t:1527027379952};\\\", \\\"{x:1400,y:759,t:1527027379969};\\\", \\\"{x:1398,y:764,t:1527027379986};\\\", \\\"{x:1398,y:768,t:1527027380003};\\\", \\\"{x:1397,y:770,t:1527027380019};\\\", \\\"{x:1396,y:772,t:1527027380036};\\\", \\\"{x:1395,y:773,t:1527027380053};\\\", \\\"{x:1394,y:774,t:1527027380069};\\\", \\\"{x:1394,y:776,t:1527027380086};\\\", \\\"{x:1393,y:777,t:1527027380103};\\\", \\\"{x:1391,y:777,t:1527027380133};\\\", \\\"{x:1389,y:776,t:1527027380150};\\\", \\\"{x:1388,y:776,t:1527027380158};\\\", \\\"{x:1386,y:775,t:1527027380173};\\\", \\\"{x:1385,y:775,t:1527027380189};\\\", \\\"{x:1384,y:774,t:1527027380203};\\\", \\\"{x:1384,y:773,t:1527027380237};\\\", \\\"{x:1384,y:771,t:1527027380253};\\\", \\\"{x:1384,y:770,t:1527027380277};\\\", \\\"{x:1384,y:768,t:1527027380302};\\\", \\\"{x:1384,y:767,t:1527027380333};\\\", \\\"{x:1384,y:765,t:1527027380357};\\\", \\\"{x:1384,y:764,t:1527027380373};\\\", \\\"{x:1384,y:762,t:1527027380606};\\\", \\\"{x:1386,y:761,t:1527027380621};\\\", \\\"{x:1401,y:761,t:1527027380638};\\\", \\\"{x:1417,y:759,t:1527027380654};\\\", \\\"{x:1425,y:759,t:1527027380671};\\\", \\\"{x:1432,y:759,t:1527027380687};\\\", \\\"{x:1435,y:759,t:1527027380704};\\\", \\\"{x:1438,y:759,t:1527027380720};\\\", \\\"{x:1439,y:759,t:1527027380737};\\\", \\\"{x:1441,y:759,t:1527027380754};\\\", \\\"{x:1444,y:758,t:1527027380771};\\\", \\\"{x:1445,y:756,t:1527027380787};\\\", \\\"{x:1447,y:756,t:1527027380804};\\\", \\\"{x:1449,y:755,t:1527027381070};\\\", \\\"{x:1450,y:755,t:1527027381077};\\\", \\\"{x:1451,y:755,t:1527027381087};\\\", \\\"{x:1457,y:755,t:1527027381104};\\\", \\\"{x:1460,y:755,t:1527027381121};\\\", \\\"{x:1463,y:755,t:1527027381139};\\\", \\\"{x:1465,y:755,t:1527027381154};\\\", \\\"{x:1466,y:755,t:1527027381170};\\\", \\\"{x:1467,y:755,t:1527027381188};\\\", \\\"{x:1469,y:755,t:1527027381204};\\\", \\\"{x:1474,y:755,t:1527027381221};\\\", \\\"{x:1479,y:755,t:1527027381238};\\\", \\\"{x:1483,y:755,t:1527027381253};\\\", \\\"{x:1488,y:755,t:1527027381271};\\\", \\\"{x:1491,y:755,t:1527027381288};\\\", \\\"{x:1493,y:755,t:1527027381303};\\\", \\\"{x:1494,y:755,t:1527027381332};\\\", \\\"{x:1495,y:755,t:1527027381349};\\\", \\\"{x:1497,y:755,t:1527027381357};\\\", \\\"{x:1500,y:755,t:1527027381371};\\\", \\\"{x:1506,y:755,t:1527027381388};\\\", \\\"{x:1508,y:755,t:1527027381405};\\\", \\\"{x:1509,y:755,t:1527027381614};\\\", \\\"{x:1510,y:755,t:1527027381622};\\\", \\\"{x:1513,y:755,t:1527027381639};\\\", \\\"{x:1516,y:755,t:1527027381656};\\\", \\\"{x:1524,y:755,t:1527027381672};\\\", \\\"{x:1528,y:755,t:1527027381689};\\\", \\\"{x:1533,y:756,t:1527027381705};\\\", \\\"{x:1536,y:757,t:1527027381723};\\\", \\\"{x:1538,y:757,t:1527027381738};\\\", \\\"{x:1540,y:757,t:1527027381756};\\\", \\\"{x:1541,y:757,t:1527027381773};\\\", \\\"{x:1542,y:758,t:1527027381788};\\\", \\\"{x:1551,y:758,t:1527027381806};\\\", \\\"{x:1556,y:760,t:1527027381822};\\\", \\\"{x:1560,y:762,t:1527027381839};\\\", \\\"{x:1563,y:762,t:1527027381855};\\\", \\\"{x:1565,y:762,t:1527027381872};\\\", \\\"{x:1566,y:762,t:1527027381889};\\\", \\\"{x:1568,y:762,t:1527027381905};\\\", \\\"{x:1569,y:762,t:1527027381922};\\\", \\\"{x:1570,y:762,t:1527027381941};\\\", \\\"{x:1571,y:762,t:1527027382013};\\\", \\\"{x:1572,y:762,t:1527027382022};\\\", \\\"{x:1573,y:762,t:1527027382133};\\\", \\\"{x:1568,y:765,t:1527027382414};\\\", \\\"{x:1562,y:769,t:1527027382423};\\\", \\\"{x:1554,y:772,t:1527027382439};\\\", \\\"{x:1545,y:774,t:1527027382456};\\\", \\\"{x:1535,y:777,t:1527027382473};\\\", \\\"{x:1528,y:780,t:1527027382490};\\\", \\\"{x:1519,y:784,t:1527027382506};\\\", \\\"{x:1512,y:788,t:1527027382524};\\\", \\\"{x:1504,y:791,t:1527027382539};\\\", \\\"{x:1497,y:796,t:1527027382557};\\\", \\\"{x:1491,y:799,t:1527027382573};\\\", \\\"{x:1488,y:803,t:1527027382589};\\\", \\\"{x:1487,y:807,t:1527027382606};\\\", \\\"{x:1484,y:810,t:1527027382624};\\\", \\\"{x:1484,y:812,t:1527027382640};\\\", \\\"{x:1483,y:814,t:1527027382656};\\\", \\\"{x:1483,y:817,t:1527027382673};\\\", \\\"{x:1482,y:819,t:1527027382689};\\\", \\\"{x:1482,y:822,t:1527027382705};\\\", \\\"{x:1482,y:825,t:1527027382723};\\\", \\\"{x:1482,y:827,t:1527027382756};\\\", \\\"{x:1482,y:828,t:1527027382772};\\\", \\\"{x:1481,y:829,t:1527027382790};\\\", \\\"{x:1481,y:830,t:1527027383334};\\\", \\\"{x:1484,y:830,t:1527027383341};\\\", \\\"{x:1491,y:828,t:1527027383358};\\\", \\\"{x:1498,y:827,t:1527027383375};\\\", \\\"{x:1506,y:826,t:1527027383390};\\\", \\\"{x:1513,y:826,t:1527027383408};\\\", \\\"{x:1517,y:826,t:1527027383424};\\\", \\\"{x:1523,y:825,t:1527027383441};\\\", \\\"{x:1528,y:824,t:1527027383458};\\\", \\\"{x:1533,y:824,t:1527027383474};\\\", \\\"{x:1541,y:822,t:1527027383491};\\\", \\\"{x:1544,y:822,t:1527027383506};\\\", \\\"{x:1546,y:822,t:1527027383524};\\\", \\\"{x:1547,y:822,t:1527027383541};\\\", \\\"{x:1548,y:822,t:1527027383573};\\\", \\\"{x:1549,y:822,t:1527027383580};\\\", \\\"{x:1551,y:821,t:1527027383613};\\\", \\\"{x:1552,y:821,t:1527027383628};\\\", \\\"{x:1555,y:821,t:1527027383774};\\\", \\\"{x:1560,y:821,t:1527027383791};\\\", \\\"{x:1569,y:821,t:1527027383809};\\\", \\\"{x:1583,y:822,t:1527027383825};\\\", \\\"{x:1598,y:825,t:1527027383842};\\\", \\\"{x:1612,y:826,t:1527027383859};\\\", \\\"{x:1622,y:828,t:1527027383875};\\\", \\\"{x:1626,y:828,t:1527027383891};\\\", \\\"{x:1622,y:828,t:1527027384045};\\\", \\\"{x:1616,y:828,t:1527027384059};\\\", \\\"{x:1601,y:830,t:1527027384075};\\\", \\\"{x:1580,y:830,t:1527027384092};\\\", \\\"{x:1557,y:830,t:1527027384109};\\\", \\\"{x:1530,y:834,t:1527027384126};\\\", \\\"{x:1513,y:835,t:1527027384141};\\\", \\\"{x:1500,y:836,t:1527027384159};\\\", \\\"{x:1485,y:837,t:1527027384176};\\\", \\\"{x:1471,y:838,t:1527027384191};\\\", \\\"{x:1461,y:838,t:1527027384208};\\\", \\\"{x:1450,y:840,t:1527027384225};\\\", \\\"{x:1445,y:841,t:1527027384243};\\\", \\\"{x:1436,y:842,t:1527027384258};\\\", \\\"{x:1429,y:843,t:1527027384275};\\\", \\\"{x:1420,y:847,t:1527027384292};\\\", \\\"{x:1415,y:848,t:1527027384308};\\\", \\\"{x:1403,y:851,t:1527027384325};\\\", \\\"{x:1399,y:853,t:1527027384343};\\\", \\\"{x:1395,y:856,t:1527027384359};\\\", \\\"{x:1392,y:859,t:1527027384375};\\\", \\\"{x:1387,y:863,t:1527027384393};\\\", \\\"{x:1384,y:865,t:1527027384409};\\\", \\\"{x:1381,y:867,t:1527027384425};\\\", \\\"{x:1379,y:867,t:1527027384443};\\\", \\\"{x:1376,y:869,t:1527027384459};\\\", \\\"{x:1371,y:873,t:1527027384476};\\\", \\\"{x:1363,y:879,t:1527027384493};\\\", \\\"{x:1340,y:894,t:1527027384509};\\\", \\\"{x:1332,y:901,t:1527027384526};\\\", \\\"{x:1327,y:904,t:1527027384543};\\\", \\\"{x:1324,y:907,t:1527027384559};\\\", \\\"{x:1324,y:908,t:1527027384662};\\\", \\\"{x:1326,y:907,t:1527027384685};\\\", \\\"{x:1328,y:907,t:1527027384693};\\\", \\\"{x:1332,y:906,t:1527027384709};\\\", \\\"{x:1337,y:904,t:1527027384726};\\\", \\\"{x:1342,y:902,t:1527027384743};\\\", \\\"{x:1347,y:901,t:1527027384760};\\\", \\\"{x:1348,y:900,t:1527027384777};\\\", \\\"{x:1350,y:899,t:1527027384792};\\\", \\\"{x:1351,y:899,t:1527027384809};\\\", \\\"{x:1353,y:899,t:1527027384861};\\\", \\\"{x:1353,y:898,t:1527027384908};\\\", \\\"{x:1352,y:897,t:1527027385165};\\\", \\\"{x:1351,y:897,t:1527027385197};\\\", \\\"{x:1352,y:896,t:1527027385485};\\\", \\\"{x:1354,y:896,t:1527027385494};\\\", \\\"{x:1356,y:896,t:1527027385510};\\\", \\\"{x:1357,y:896,t:1527027385528};\\\", \\\"{x:1358,y:895,t:1527027385550};\\\", \\\"{x:1359,y:895,t:1527027385598};\\\", \\\"{x:1360,y:895,t:1527027385611};\\\", \\\"{x:1362,y:895,t:1527027385627};\\\", \\\"{x:1368,y:895,t:1527027385643};\\\", \\\"{x:1376,y:895,t:1527027385661};\\\", \\\"{x:1384,y:895,t:1527027385677};\\\", \\\"{x:1388,y:895,t:1527027385694};\\\", \\\"{x:1390,y:894,t:1527027385710};\\\", \\\"{x:1391,y:894,t:1527027385790};\\\", \\\"{x:1392,y:894,t:1527027386069};\\\", \\\"{x:1394,y:894,t:1527027386078};\\\", \\\"{x:1398,y:894,t:1527027386095};\\\", \\\"{x:1402,y:894,t:1527027386111};\\\", \\\"{x:1404,y:894,t:1527027386128};\\\", \\\"{x:1406,y:894,t:1527027386213};\\\", \\\"{x:1403,y:893,t:1527027386726};\\\", \\\"{x:1396,y:891,t:1527027386734};\\\", \\\"{x:1389,y:887,t:1527027386745};\\\", \\\"{x:1371,y:880,t:1527027386761};\\\", \\\"{x:1358,y:876,t:1527027386778};\\\", \\\"{x:1346,y:872,t:1527027386795};\\\", \\\"{x:1341,y:871,t:1527027386812};\\\", \\\"{x:1335,y:867,t:1527027386828};\\\", \\\"{x:1319,y:858,t:1527027386845};\\\", \\\"{x:1303,y:848,t:1527027386862};\\\", \\\"{x:1287,y:844,t:1527027386878};\\\", \\\"{x:1284,y:844,t:1527027386896};\\\", \\\"{x:1282,y:844,t:1527027386932};\\\", \\\"{x:1281,y:843,t:1527027387086};\\\", \\\"{x:1281,y:842,t:1527027387101};\\\", \\\"{x:1281,y:840,t:1527027387113};\\\", \\\"{x:1281,y:838,t:1527027387129};\\\", \\\"{x:1281,y:837,t:1527027387145};\\\", \\\"{x:1281,y:835,t:1527027387163};\\\", \\\"{x:1281,y:834,t:1527027387179};\\\", \\\"{x:1281,y:832,t:1527027387374};\\\", \\\"{x:1281,y:831,t:1527027387397};\\\", \\\"{x:1281,y:830,t:1527027387421};\\\", \\\"{x:1281,y:828,t:1527027387430};\\\", \\\"{x:1281,y:826,t:1527027387447};\\\", \\\"{x:1281,y:825,t:1527027387477};\\\", \\\"{x:1282,y:825,t:1527027387662};\\\", \\\"{x:1284,y:825,t:1527027387669};\\\", \\\"{x:1287,y:825,t:1527027387681};\\\", \\\"{x:1296,y:825,t:1527027387697};\\\", \\\"{x:1307,y:826,t:1527027387714};\\\", \\\"{x:1318,y:827,t:1527027387729};\\\", \\\"{x:1330,y:827,t:1527027387746};\\\", \\\"{x:1340,y:828,t:1527027387764};\\\", \\\"{x:1344,y:828,t:1527027387780};\\\", \\\"{x:1346,y:828,t:1527027387797};\\\", \\\"{x:1347,y:828,t:1527027387862};\\\", \\\"{x:1348,y:828,t:1527027387934};\\\", \\\"{x:1350,y:828,t:1527027388142};\\\", \\\"{x:1353,y:828,t:1527027388157};\\\", \\\"{x:1356,y:828,t:1527027388165};\\\", \\\"{x:1357,y:828,t:1527027388180};\\\", \\\"{x:1370,y:828,t:1527027388198};\\\", \\\"{x:1376,y:828,t:1527027388214};\\\", \\\"{x:1379,y:828,t:1527027388231};\\\", \\\"{x:1380,y:828,t:1527027388248};\\\", \\\"{x:1382,y:828,t:1527027388264};\\\", \\\"{x:1383,y:828,t:1527027388280};\\\", \\\"{x:1384,y:828,t:1527027388297};\\\", \\\"{x:1389,y:828,t:1527027388314};\\\", \\\"{x:1392,y:828,t:1527027388330};\\\", \\\"{x:1393,y:828,t:1527027388347};\\\", \\\"{x:1394,y:828,t:1527027388364};\\\", \\\"{x:1395,y:828,t:1527027388389};\\\", \\\"{x:1396,y:828,t:1527027388398};\\\", \\\"{x:1399,y:828,t:1527027388414};\\\", \\\"{x:1403,y:828,t:1527027388431};\\\", \\\"{x:1406,y:828,t:1527027388447};\\\", \\\"{x:1407,y:828,t:1527027388464};\\\", \\\"{x:1409,y:828,t:1527027388480};\\\", \\\"{x:1409,y:827,t:1527027389430};\\\", \\\"{x:1409,y:822,t:1527027389437};\\\", \\\"{x:1407,y:816,t:1527027389449};\\\", \\\"{x:1405,y:805,t:1527027389466};\\\", \\\"{x:1398,y:787,t:1527027389483};\\\", \\\"{x:1395,y:769,t:1527027389498};\\\", \\\"{x:1394,y:754,t:1527027389516};\\\", \\\"{x:1388,y:722,t:1527027389533};\\\", \\\"{x:1378,y:695,t:1527027389549};\\\", \\\"{x:1365,y:670,t:1527027389565};\\\", \\\"{x:1353,y:654,t:1527027389583};\\\", \\\"{x:1347,y:647,t:1527027389599};\\\", \\\"{x:1340,y:637,t:1527027389616};\\\", \\\"{x:1332,y:625,t:1527027389632};\\\", \\\"{x:1327,y:620,t:1527027389650};\\\", \\\"{x:1325,y:618,t:1527027389667};\\\", \\\"{x:1323,y:616,t:1527027389683};\\\", \\\"{x:1323,y:615,t:1527027389700};\\\", \\\"{x:1323,y:613,t:1527027389716};\\\", \\\"{x:1323,y:606,t:1527027389733};\\\", \\\"{x:1324,y:603,t:1527027389749};\\\", \\\"{x:1325,y:598,t:1527027389765};\\\", \\\"{x:1328,y:595,t:1527027389783};\\\", \\\"{x:1334,y:591,t:1527027389800};\\\", \\\"{x:1344,y:587,t:1527027389816};\\\", \\\"{x:1360,y:584,t:1527027389832};\\\", \\\"{x:1375,y:583,t:1527027389850};\\\", \\\"{x:1392,y:580,t:1527027389866};\\\", \\\"{x:1404,y:579,t:1527027389883};\\\", \\\"{x:1410,y:578,t:1527027389899};\\\", \\\"{x:1419,y:576,t:1527027389916};\\\", \\\"{x:1423,y:575,t:1527027389932};\\\", \\\"{x:1426,y:574,t:1527027389949};\\\", \\\"{x:1429,y:572,t:1527027389967};\\\", \\\"{x:1432,y:570,t:1527027389982};\\\", \\\"{x:1434,y:569,t:1527027390000};\\\", \\\"{x:1434,y:568,t:1527027390016};\\\", \\\"{x:1435,y:567,t:1527027390032};\\\", \\\"{x:1435,y:565,t:1527027390049};\\\", \\\"{x:1435,y:562,t:1527027390067};\\\", \\\"{x:1431,y:560,t:1527027390082};\\\", \\\"{x:1428,y:559,t:1527027390099};\\\", \\\"{x:1427,y:558,t:1527027390117};\\\", \\\"{x:1425,y:558,t:1527027390133};\\\", \\\"{x:1423,y:558,t:1527027390149};\\\", \\\"{x:1419,y:558,t:1527027390167};\\\", \\\"{x:1416,y:558,t:1527027390184};\\\", \\\"{x:1415,y:558,t:1527027390200};\\\", \\\"{x:1415,y:559,t:1527027390285};\\\", \\\"{x:1413,y:560,t:1527027390301};\\\", \\\"{x:1413,y:561,t:1527027390317};\\\", \\\"{x:1412,y:562,t:1527027390341};\\\", \\\"{x:1414,y:562,t:1527027390845};\\\", \\\"{x:1415,y:562,t:1527027390853};\\\", \\\"{x:1417,y:562,t:1527027390867};\\\", \\\"{x:1423,y:562,t:1527027390885};\\\", \\\"{x:1438,y:562,t:1527027390901};\\\", \\\"{x:1446,y:562,t:1527027390917};\\\", \\\"{x:1455,y:562,t:1527027390935};\\\", \\\"{x:1460,y:562,t:1527027390951};\\\", \\\"{x:1463,y:562,t:1527027390968};\\\", \\\"{x:1464,y:562,t:1527027390985};\\\", \\\"{x:1466,y:562,t:1527027391005};\\\", \\\"{x:1467,y:562,t:1527027391029};\\\", \\\"{x:1470,y:562,t:1527027391037};\\\", \\\"{x:1473,y:562,t:1527027391051};\\\", \\\"{x:1483,y:564,t:1527027391068};\\\", \\\"{x:1494,y:564,t:1527027391086};\\\", \\\"{x:1497,y:564,t:1527027391101};\\\", \\\"{x:1499,y:564,t:1527027391117};\\\", \\\"{x:1498,y:564,t:1527027391310};\\\", \\\"{x:1496,y:565,t:1527027391318};\\\", \\\"{x:1491,y:566,t:1527027391335};\\\", \\\"{x:1487,y:566,t:1527027391352};\\\", \\\"{x:1484,y:566,t:1527027391368};\\\", \\\"{x:1482,y:566,t:1527027391390};\\\", \\\"{x:1481,y:566,t:1527027391414};\\\", \\\"{x:1480,y:566,t:1527027391429};\\\", \\\"{x:1479,y:566,t:1527027391437};\\\", \\\"{x:1477,y:566,t:1527027391452};\\\", \\\"{x:1476,y:566,t:1527027391469};\\\", \\\"{x:1477,y:566,t:1527027391604};\\\", \\\"{x:1478,y:566,t:1527027391618};\\\", \\\"{x:1481,y:566,t:1527027391634};\\\", \\\"{x:1484,y:566,t:1527027391652};\\\", \\\"{x:1488,y:566,t:1527027391669};\\\", \\\"{x:1491,y:566,t:1527027391685};\\\", \\\"{x:1494,y:566,t:1527027391701};\\\", \\\"{x:1499,y:566,t:1527027391718};\\\", \\\"{x:1506,y:566,t:1527027391736};\\\", \\\"{x:1512,y:566,t:1527027391751};\\\", \\\"{x:1513,y:566,t:1527027391768};\\\", \\\"{x:1514,y:566,t:1527027391785};\\\", \\\"{x:1515,y:566,t:1527027391802};\\\", \\\"{x:1516,y:566,t:1527027391822};\\\", \\\"{x:1517,y:566,t:1527027391836};\\\", \\\"{x:1520,y:566,t:1527027391852};\\\", \\\"{x:1527,y:566,t:1527027391869};\\\", \\\"{x:1530,y:566,t:1527027391885};\\\", \\\"{x:1531,y:566,t:1527027391909};\\\", \\\"{x:1532,y:566,t:1527027391997};\\\", \\\"{x:1533,y:566,t:1527027392005};\\\", \\\"{x:1535,y:565,t:1527027392094};\\\", \\\"{x:1535,y:564,t:1527027392109};\\\", \\\"{x:1537,y:564,t:1527027392119};\\\", \\\"{x:1540,y:562,t:1527027392206};\\\", \\\"{x:1541,y:562,t:1527027392221};\\\", \\\"{x:1543,y:562,t:1527027392237};\\\", \\\"{x:1548,y:562,t:1527027392254};\\\", \\\"{x:1551,y:561,t:1527027392270};\\\", \\\"{x:1555,y:559,t:1527027392285};\\\", \\\"{x:1560,y:558,t:1527027392302};\\\", \\\"{x:1567,y:557,t:1527027392319};\\\", \\\"{x:1574,y:556,t:1527027392336};\\\", \\\"{x:1577,y:555,t:1527027392352};\\\", \\\"{x:1580,y:554,t:1527027392369};\\\", \\\"{x:1582,y:554,t:1527027392621};\\\", \\\"{x:1583,y:555,t:1527027392645};\\\", \\\"{x:1583,y:556,t:1527027392661};\\\", \\\"{x:1584,y:556,t:1527027392677};\\\", \\\"{x:1585,y:556,t:1527027392687};\\\", \\\"{x:1586,y:557,t:1527027392703};\\\", \\\"{x:1586,y:558,t:1527027393030};\\\", \\\"{x:1586,y:560,t:1527027393045};\\\", \\\"{x:1586,y:561,t:1527027393054};\\\", \\\"{x:1586,y:562,t:1527027393085};\\\", \\\"{x:1586,y:563,t:1527027393157};\\\", \\\"{x:1578,y:564,t:1527027398134};\\\", \\\"{x:1561,y:564,t:1527027398144};\\\", \\\"{x:1486,y:564,t:1527027398162};\\\", \\\"{x:1389,y:564,t:1527027398177};\\\", \\\"{x:1290,y:564,t:1527027398194};\\\", \\\"{x:1190,y:564,t:1527027398211};\\\", \\\"{x:1095,y:564,t:1527027398227};\\\", \\\"{x:1014,y:567,t:1527027398244};\\\", \\\"{x:930,y:567,t:1527027398262};\\\", \\\"{x:891,y:567,t:1527027398276};\\\", \\\"{x:860,y:570,t:1527027398293};\\\", \\\"{x:845,y:572,t:1527027398303};\\\", \\\"{x:820,y:577,t:1527027398319};\\\", \\\"{x:789,y:581,t:1527027398336};\\\", \\\"{x:746,y:588,t:1527027398359};\\\", \\\"{x:723,y:591,t:1527027398377};\\\", \\\"{x:700,y:595,t:1527027398392};\\\", \\\"{x:680,y:598,t:1527027398410};\\\", \\\"{x:658,y:605,t:1527027398426};\\\", \\\"{x:640,y:610,t:1527027398443};\\\", \\\"{x:623,y:616,t:1527027398459};\\\", \\\"{x:604,y:620,t:1527027398477};\\\", \\\"{x:598,y:620,t:1527027398494};\\\", \\\"{x:597,y:620,t:1527027398509};\\\", \\\"{x:597,y:618,t:1527027398548};\\\", \\\"{x:597,y:616,t:1527027398560};\\\", \\\"{x:597,y:609,t:1527027398577};\\\", \\\"{x:597,y:602,t:1527027398592};\\\", \\\"{x:597,y:598,t:1527027398609};\\\", \\\"{x:597,y:594,t:1527027398628};\\\", \\\"{x:597,y:591,t:1527027398643};\\\", \\\"{x:597,y:589,t:1527027398659};\\\", \\\"{x:597,y:588,t:1527027398677};\\\", \\\"{x:598,y:587,t:1527027398693};\\\", \\\"{x:600,y:585,t:1527027398710};\\\", \\\"{x:601,y:584,t:1527027398727};\\\", \\\"{x:603,y:581,t:1527027398744};\\\", \\\"{x:605,y:578,t:1527027398760};\\\", \\\"{x:607,y:575,t:1527027398777};\\\", \\\"{x:608,y:572,t:1527027398793};\\\", \\\"{x:610,y:570,t:1527027398809};\\\", \\\"{x:611,y:569,t:1527027398827};\\\", \\\"{x:611,y:568,t:1527027398909};\\\", \\\"{x:612,y:566,t:1527027398916};\\\", \\\"{x:612,y:564,t:1527027398926};\\\", \\\"{x:613,y:563,t:1527027398944};\\\", \\\"{x:613,y:563,t:1527027399013};\\\", \\\"{x:613,y:564,t:1527027399053};\\\", \\\"{x:610,y:567,t:1527027399069};\\\", \\\"{x:609,y:569,t:1527027399077};\\\", \\\"{x:602,y:574,t:1527027399094};\\\", \\\"{x:593,y:581,t:1527027399112};\\\", \\\"{x:585,y:589,t:1527027399128};\\\", \\\"{x:575,y:597,t:1527027399144};\\\", \\\"{x:566,y:606,t:1527027399161};\\\", \\\"{x:561,y:614,t:1527027399177};\\\", \\\"{x:554,y:626,t:1527027399193};\\\", \\\"{x:546,y:640,t:1527027399211};\\\", \\\"{x:543,y:649,t:1527027399226};\\\", \\\"{x:539,y:658,t:1527027399243};\\\", \\\"{x:536,y:672,t:1527027399260};\\\", \\\"{x:534,y:679,t:1527027399277};\\\", \\\"{x:533,y:690,t:1527027399294};\\\", \\\"{x:532,y:700,t:1527027399310};\\\", \\\"{x:532,y:707,t:1527027399327};\\\", \\\"{x:532,y:715,t:1527027399345};\\\", \\\"{x:532,y:719,t:1527027399361};\\\", \\\"{x:532,y:722,t:1527027399378};\\\", \\\"{x:532,y:723,t:1527027399393};\\\", \\\"{x:532,y:724,t:1527027399421};\\\", \\\"{x:533,y:723,t:1527027399453};\\\", \\\"{x:535,y:716,t:1527027399460};\\\", \\\"{x:546,y:696,t:1527027399478};\\\", \\\"{x:557,y:671,t:1527027399493};\\\", \\\"{x:571,y:650,t:1527027399511};\\\", \\\"{x:582,y:635,t:1527027399528};\\\", \\\"{x:587,y:628,t:1527027399544};\\\", \\\"{x:588,y:620,t:1527027399561};\\\", \\\"{x:591,y:612,t:1527027399578};\\\", \\\"{x:596,y:604,t:1527027399594};\\\", \\\"{x:598,y:597,t:1527027399611};\\\", \\\"{x:601,y:593,t:1527027399629};\\\", \\\"{x:602,y:591,t:1527027399644};\\\", \\\"{x:603,y:589,t:1527027399660};\\\", \\\"{x:604,y:588,t:1527027399679};\\\", \\\"{x:604,y:587,t:1527027399701};\\\", \\\"{x:605,y:585,t:1527027399716};\\\", \\\"{x:606,y:583,t:1527027399728};\\\", \\\"{x:608,y:581,t:1527027399743};\\\", \\\"{x:611,y:578,t:1527027399761};\\\", \\\"{x:611,y:576,t:1527027399778};\\\", \\\"{x:611,y:575,t:1527027399794};\\\", \\\"{x:612,y:573,t:1527027399811};\\\", \\\"{x:612,y:570,t:1527027399828};\\\", \\\"{x:612,y:568,t:1527027399845};\\\", \\\"{x:611,y:569,t:1527027400084};\\\", \\\"{x:610,y:569,t:1527027400095};\\\", \\\"{x:606,y:573,t:1527027400110};\\\", \\\"{x:600,y:580,t:1527027400127};\\\", \\\"{x:593,y:590,t:1527027400145};\\\", \\\"{x:589,y:601,t:1527027400161};\\\", \\\"{x:584,y:611,t:1527027400177};\\\", \\\"{x:579,y:622,t:1527027400195};\\\", \\\"{x:577,y:629,t:1527027400211};\\\", \\\"{x:574,y:637,t:1527027400228};\\\", \\\"{x:571,y:657,t:1527027400244};\\\", \\\"{x:567,y:671,t:1527027400263};\\\", \\\"{x:566,y:686,t:1527027400277};\\\", \\\"{x:564,y:700,t:1527027400294};\\\", \\\"{x:563,y:712,t:1527027400310};\\\", \\\"{x:562,y:724,t:1527027400328};\\\", \\\"{x:562,y:733,t:1527027400345};\\\", \\\"{x:562,y:738,t:1527027400362};\\\", \\\"{x:560,y:745,t:1527027400377};\\\", \\\"{x:560,y:749,t:1527027400396};\\\", \\\"{x:560,y:751,t:1527027400411};\\\", \\\"{x:560,y:752,t:1527027400484};\\\", \\\"{x:559,y:746,t:1527027400558};\\\", \\\"{x:551,y:733,t:1527027400578};\\\", \\\"{x:546,y:727,t:1527027400594};\\\", \\\"{x:543,y:725,t:1527027400611};\\\", \\\"{x:542,y:724,t:1527027400637};\\\", \\\"{x:543,y:724,t:1527027400964};\\\", \\\"{x:549,y:724,t:1527027400979};\\\", \\\"{x:566,y:724,t:1527027400994};\\\", \\\"{x:595,y:724,t:1527027401011};\\\", \\\"{x:668,y:726,t:1527027401028};\\\", \\\"{x:728,y:729,t:1527027401045};\\\", \\\"{x:792,y:729,t:1527027401062};\\\", \\\"{x:831,y:729,t:1527027401079};\\\", \\\"{x:857,y:731,t:1527027401095};\\\", \\\"{x:872,y:732,t:1527027401111};\\\", \\\"{x:876,y:732,t:1527027401129};\\\", \\\"{x:877,y:733,t:1527027401145};\\\" ] }, { \\\"rt\\\": 8384, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 248844, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"C30CF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4-8-E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:880,y:733,t:1527027403988};\\\", \\\"{x:888,y:733,t:1527027404002};\\\", \\\"{x:903,y:731,t:1527027404017};\\\", \\\"{x:908,y:731,t:1527027404034};\\\", \\\"{x:920,y:730,t:1527027404052};\\\", \\\"{x:932,y:727,t:1527027404068};\\\", \\\"{x:944,y:726,t:1527027404085};\\\", \\\"{x:953,y:725,t:1527027404102};\\\", \\\"{x:966,y:722,t:1527027404118};\\\", \\\"{x:980,y:720,t:1527027404135};\\\", \\\"{x:995,y:719,t:1527027404152};\\\", \\\"{x:1009,y:716,t:1527027404168};\\\", \\\"{x:1026,y:714,t:1527027404185};\\\", \\\"{x:1037,y:711,t:1527027404201};\\\", \\\"{x:1046,y:707,t:1527027404218};\\\", \\\"{x:1056,y:701,t:1527027404235};\\\", \\\"{x:1060,y:697,t:1527027404252};\\\", \\\"{x:1063,y:693,t:1527027404268};\\\", \\\"{x:1065,y:691,t:1527027404285};\\\", \\\"{x:1067,y:687,t:1527027404302};\\\", \\\"{x:1070,y:678,t:1527027404318};\\\", \\\"{x:1078,y:663,t:1527027404335};\\\", \\\"{x:1083,y:648,t:1527027404352};\\\", \\\"{x:1085,y:620,t:1527027404368};\\\", \\\"{x:1086,y:610,t:1527027404385};\\\", \\\"{x:1086,y:603,t:1527027404402};\\\", \\\"{x:1086,y:597,t:1527027404420};\\\", \\\"{x:1084,y:590,t:1527027404435};\\\", \\\"{x:1083,y:583,t:1527027404452};\\\", \\\"{x:1079,y:573,t:1527027404469};\\\", \\\"{x:1074,y:561,t:1527027404485};\\\", \\\"{x:1069,y:547,t:1527027404503};\\\", \\\"{x:1062,y:533,t:1527027404519};\\\", \\\"{x:1057,y:521,t:1527027404535};\\\", \\\"{x:1053,y:513,t:1527027404552};\\\", \\\"{x:1050,y:506,t:1527027404569};\\\", \\\"{x:1049,y:500,t:1527027404585};\\\", \\\"{x:1049,y:494,t:1527027404602};\\\", \\\"{x:1048,y:490,t:1527027404619};\\\", \\\"{x:1048,y:482,t:1527027404635};\\\", \\\"{x:1049,y:465,t:1527027404652};\\\", \\\"{x:1056,y:449,t:1527027404670};\\\", \\\"{x:1063,y:437,t:1527027404685};\\\", \\\"{x:1068,y:432,t:1527027404702};\\\", \\\"{x:1070,y:430,t:1527027404719};\\\", \\\"{x:1071,y:431,t:1527027404777};\\\", \\\"{x:1071,y:438,t:1527027404785};\\\", \\\"{x:1076,y:458,t:1527027404802};\\\", \\\"{x:1076,y:478,t:1527027404819};\\\", \\\"{x:1077,y:499,t:1527027404835};\\\", \\\"{x:1077,y:511,t:1527027404853};\\\", \\\"{x:1077,y:522,t:1527027404869};\\\", \\\"{x:1077,y:533,t:1527027404886};\\\", \\\"{x:1077,y:547,t:1527027404903};\\\", \\\"{x:1077,y:557,t:1527027404920};\\\", \\\"{x:1077,y:565,t:1527027404937};\\\", \\\"{x:1078,y:572,t:1527027404952};\\\", \\\"{x:1080,y:577,t:1527027404969};\\\", \\\"{x:1081,y:580,t:1527027404987};\\\", \\\"{x:1081,y:581,t:1527027405002};\\\", \\\"{x:1082,y:581,t:1527027405057};\\\", \\\"{x:1083,y:581,t:1527027405069};\\\", \\\"{x:1092,y:580,t:1527027405086};\\\", \\\"{x:1103,y:579,t:1527027405103};\\\", \\\"{x:1119,y:577,t:1527027405120};\\\", \\\"{x:1138,y:574,t:1527027405136};\\\", \\\"{x:1171,y:569,t:1527027405153};\\\", \\\"{x:1191,y:567,t:1527027405169};\\\", \\\"{x:1207,y:563,t:1527027405187};\\\", \\\"{x:1217,y:563,t:1527027405203};\\\", \\\"{x:1230,y:561,t:1527027405220};\\\", \\\"{x:1237,y:561,t:1527027405237};\\\", \\\"{x:1246,y:559,t:1527027405253};\\\", \\\"{x:1251,y:558,t:1527027405270};\\\", \\\"{x:1256,y:558,t:1527027405286};\\\", \\\"{x:1261,y:557,t:1527027405303};\\\", \\\"{x:1265,y:557,t:1527027405319};\\\", \\\"{x:1270,y:555,t:1527027405337};\\\", \\\"{x:1272,y:555,t:1527027405353};\\\", \\\"{x:1274,y:554,t:1527027405370};\\\", \\\"{x:1275,y:554,t:1527027405481};\\\", \\\"{x:1276,y:554,t:1527027405489};\\\", \\\"{x:1278,y:554,t:1527027405513};\\\", \\\"{x:1280,y:556,t:1527027405521};\\\", \\\"{x:1282,y:558,t:1527027405548};\\\", \\\"{x:1282,y:559,t:1527027405569};\\\", \\\"{x:1282,y:560,t:1527027406802};\\\", \\\"{x:1282,y:561,t:1527027408281};\\\", \\\"{x:1278,y:561,t:1527027408289};\\\", \\\"{x:1256,y:561,t:1527027408307};\\\", \\\"{x:1228,y:561,t:1527027408321};\\\", \\\"{x:1186,y:560,t:1527027408338};\\\", \\\"{x:1144,y:560,t:1527027408355};\\\", \\\"{x:1101,y:559,t:1527027408372};\\\", \\\"{x:1067,y:554,t:1527027408388};\\\", \\\"{x:1031,y:549,t:1527027408406};\\\", \\\"{x:1000,y:545,t:1527027408421};\\\", \\\"{x:971,y:540,t:1527027408438};\\\", \\\"{x:943,y:539,t:1527027408457};\\\", \\\"{x:920,y:539,t:1527027408471};\\\", \\\"{x:889,y:539,t:1527027408488};\\\", \\\"{x:865,y:535,t:1527027408505};\\\", \\\"{x:842,y:531,t:1527027408522};\\\", \\\"{x:812,y:531,t:1527027408539};\\\", \\\"{x:786,y:533,t:1527027408555};\\\", \\\"{x:763,y:533,t:1527027408572};\\\", \\\"{x:742,y:533,t:1527027408589};\\\", \\\"{x:721,y:533,t:1527027408606};\\\", \\\"{x:702,y:533,t:1527027408621};\\\", \\\"{x:687,y:533,t:1527027408639};\\\", \\\"{x:677,y:533,t:1527027408655};\\\", \\\"{x:662,y:531,t:1527027408672};\\\", \\\"{x:653,y:530,t:1527027408688};\\\", \\\"{x:646,y:529,t:1527027408705};\\\", \\\"{x:641,y:528,t:1527027408722};\\\", \\\"{x:637,y:527,t:1527027408739};\\\", \\\"{x:635,y:526,t:1527027408755};\\\", \\\"{x:633,y:524,t:1527027408772};\\\", \\\"{x:628,y:522,t:1527027408789};\\\", \\\"{x:619,y:518,t:1527027408805};\\\", \\\"{x:608,y:515,t:1527027408823};\\\", \\\"{x:602,y:514,t:1527027408839};\\\", \\\"{x:598,y:513,t:1527027408854};\\\", \\\"{x:596,y:510,t:1527027408872};\\\", \\\"{x:594,y:508,t:1527027408889};\\\", \\\"{x:593,y:507,t:1527027408905};\\\", \\\"{x:593,y:505,t:1527027408922};\\\", \\\"{x:598,y:505,t:1527027409057};\\\", \\\"{x:608,y:505,t:1527027409074};\\\", \\\"{x:616,y:505,t:1527027409089};\\\", \\\"{x:623,y:505,t:1527027409106};\\\", \\\"{x:624,y:505,t:1527027409122};\\\", \\\"{x:627,y:505,t:1527027409408};\\\", \\\"{x:630,y:505,t:1527027409423};\\\", \\\"{x:640,y:506,t:1527027409439};\\\", \\\"{x:661,y:507,t:1527027409456};\\\", \\\"{x:681,y:512,t:1527027409473};\\\", \\\"{x:705,y:515,t:1527027409489};\\\", \\\"{x:731,y:518,t:1527027409507};\\\", \\\"{x:756,y:523,t:1527027409523};\\\", \\\"{x:774,y:527,t:1527027409539};\\\", \\\"{x:789,y:529,t:1527027409556};\\\", \\\"{x:800,y:533,t:1527027409573};\\\", \\\"{x:807,y:534,t:1527027409589};\\\", \\\"{x:813,y:536,t:1527027409606};\\\", \\\"{x:817,y:537,t:1527027409623};\\\", \\\"{x:818,y:537,t:1527027409639};\\\", \\\"{x:820,y:537,t:1527027409656};\\\", \\\"{x:821,y:538,t:1527027409673};\\\", \\\"{x:822,y:538,t:1527027409721};\\\", \\\"{x:824,y:539,t:1527027409729};\\\", \\\"{x:826,y:539,t:1527027409744};\\\", \\\"{x:828,y:540,t:1527027409756};\\\", \\\"{x:830,y:540,t:1527027409772};\\\", \\\"{x:831,y:540,t:1527027409789};\\\", \\\"{x:833,y:540,t:1527027409805};\\\", \\\"{x:833,y:542,t:1527027410006};\\\", \\\"{x:828,y:548,t:1527027410022};\\\", \\\"{x:811,y:557,t:1527027410041};\\\", \\\"{x:792,y:564,t:1527027410056};\\\", \\\"{x:774,y:571,t:1527027410073};\\\", \\\"{x:754,y:580,t:1527027410090};\\\", \\\"{x:739,y:588,t:1527027410106};\\\", \\\"{x:728,y:596,t:1527027410123};\\\", \\\"{x:718,y:605,t:1527027410141};\\\", \\\"{x:707,y:616,t:1527027410156};\\\", \\\"{x:691,y:629,t:1527027410173};\\\", \\\"{x:672,y:645,t:1527027410191};\\\", \\\"{x:659,y:655,t:1527027410206};\\\", \\\"{x:647,y:665,t:1527027410223};\\\", \\\"{x:633,y:687,t:1527027410240};\\\", \\\"{x:625,y:696,t:1527027410256};\\\", \\\"{x:616,y:705,t:1527027410274};\\\", \\\"{x:606,y:712,t:1527027410290};\\\", \\\"{x:600,y:716,t:1527027410306};\\\", \\\"{x:596,y:720,t:1527027410323};\\\", \\\"{x:593,y:723,t:1527027410340};\\\", \\\"{x:587,y:726,t:1527027410356};\\\", \\\"{x:581,y:729,t:1527027410373};\\\", \\\"{x:580,y:730,t:1527027410390};\\\", \\\"{x:577,y:730,t:1527027410408};\\\", \\\"{x:574,y:731,t:1527027410423};\\\", \\\"{x:570,y:731,t:1527027410440};\\\", \\\"{x:568,y:731,t:1527027410457};\\\", \\\"{x:567,y:732,t:1527027410473};\\\", \\\"{x:566,y:732,t:1527027410490};\\\", \\\"{x:565,y:732,t:1527027410513};\\\", \\\"{x:564,y:732,t:1527027410524};\\\", \\\"{x:553,y:732,t:1527027410540};\\\", \\\"{x:538,y:732,t:1527027410557};\\\", \\\"{x:526,y:732,t:1527027410573};\\\", \\\"{x:517,y:732,t:1527027410589};\\\", \\\"{x:511,y:732,t:1527027410607};\\\", \\\"{x:510,y:732,t:1527027410624};\\\", \\\"{x:510,y:733,t:1527027410888};\\\", \\\"{x:511,y:734,t:1527027410895};\\\", \\\"{x:518,y:734,t:1527027410907};\\\", \\\"{x:538,y:737,t:1527027410924};\\\", \\\"{x:562,y:739,t:1527027410940};\\\", \\\"{x:601,y:741,t:1527027410957};\\\", \\\"{x:661,y:746,t:1527027410974};\\\", \\\"{x:723,y:746,t:1527027410990};\\\", \\\"{x:781,y:746,t:1527027411007};\\\", \\\"{x:848,y:746,t:1527027411024};\\\", \\\"{x:874,y:746,t:1527027411040};\\\", \\\"{x:893,y:746,t:1527027411057};\\\", \\\"{x:903,y:746,t:1527027411074};\\\", \\\"{x:910,y:746,t:1527027411091};\\\", \\\"{x:913,y:746,t:1527027411107};\\\" ] }, { \\\"rt\\\": 16401, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 266458, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"C30CF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:914,y:746,t:1527027412385};\\\", \\\"{x:914,y:745,t:1527027412584};\\\", \\\"{x:914,y:743,t:1527027415545};\\\", \\\"{x:914,y:744,t:1527027416537};\\\", \\\"{x:914,y:745,t:1527027417898};\\\", \\\"{x:918,y:745,t:1527027417912};\\\", \\\"{x:927,y:747,t:1527027417930};\\\", \\\"{x:944,y:751,t:1527027417946};\\\", \\\"{x:964,y:756,t:1527027417963};\\\", \\\"{x:982,y:762,t:1527027417980};\\\", \\\"{x:1004,y:767,t:1527027417996};\\\", \\\"{x:1025,y:774,t:1527027418012};\\\", \\\"{x:1046,y:779,t:1527027418029};\\\", \\\"{x:1067,y:785,t:1527027418046};\\\", \\\"{x:1086,y:792,t:1527027418063};\\\", \\\"{x:1102,y:799,t:1527027418079};\\\", \\\"{x:1120,y:805,t:1527027418095};\\\", \\\"{x:1126,y:807,t:1527027418113};\\\", \\\"{x:1133,y:810,t:1527027418130};\\\", \\\"{x:1139,y:813,t:1527027418147};\\\", \\\"{x:1141,y:814,t:1527027418162};\\\", \\\"{x:1143,y:814,t:1527027418193};\\\", \\\"{x:1143,y:813,t:1527027418313};\\\", \\\"{x:1143,y:809,t:1527027418330};\\\", \\\"{x:1141,y:800,t:1527027418347};\\\", \\\"{x:1135,y:791,t:1527027418364};\\\", \\\"{x:1128,y:784,t:1527027418380};\\\", \\\"{x:1118,y:775,t:1527027418397};\\\", \\\"{x:1111,y:768,t:1527027418414};\\\", \\\"{x:1103,y:759,t:1527027418430};\\\", \\\"{x:1097,y:752,t:1527027418447};\\\", \\\"{x:1092,y:744,t:1527027418464};\\\", \\\"{x:1088,y:735,t:1527027418480};\\\", \\\"{x:1078,y:720,t:1527027418497};\\\", \\\"{x:1075,y:712,t:1527027418514};\\\", \\\"{x:1072,y:707,t:1527027418530};\\\", \\\"{x:1068,y:698,t:1527027418547};\\\", \\\"{x:1066,y:691,t:1527027418564};\\\", \\\"{x:1063,y:686,t:1527027418580};\\\", \\\"{x:1060,y:677,t:1527027418597};\\\", \\\"{x:1059,y:669,t:1527027418614};\\\", \\\"{x:1059,y:666,t:1527027418632};\\\", \\\"{x:1059,y:665,t:1527027418646};\\\", \\\"{x:1058,y:662,t:1527027418664};\\\", \\\"{x:1058,y:659,t:1527027418680};\\\", \\\"{x:1058,y:656,t:1527027418697};\\\", \\\"{x:1058,y:654,t:1527027418714};\\\", \\\"{x:1058,y:651,t:1527027418730};\\\", \\\"{x:1058,y:650,t:1527027418753};\\\", \\\"{x:1058,y:649,t:1527027418778};\\\", \\\"{x:1058,y:648,t:1527027418809};\\\", \\\"{x:1058,y:647,t:1527027418833};\\\", \\\"{x:1058,y:646,t:1527027418846};\\\", \\\"{x:1059,y:645,t:1527027418864};\\\", \\\"{x:1061,y:643,t:1527027418881};\\\", \\\"{x:1064,y:642,t:1527027418897};\\\", \\\"{x:1067,y:641,t:1527027418914};\\\", \\\"{x:1074,y:639,t:1527027418931};\\\", \\\"{x:1080,y:636,t:1527027418946};\\\", \\\"{x:1085,y:636,t:1527027418964};\\\", \\\"{x:1092,y:634,t:1527027418981};\\\", \\\"{x:1094,y:633,t:1527027418997};\\\", \\\"{x:1096,y:632,t:1527027419013};\\\", \\\"{x:1097,y:632,t:1527027419031};\\\", \\\"{x:1100,y:633,t:1527027420202};\\\", \\\"{x:1101,y:635,t:1527027420216};\\\", \\\"{x:1105,y:638,t:1527027420232};\\\", \\\"{x:1108,y:640,t:1527027420248};\\\", \\\"{x:1119,y:647,t:1527027420264};\\\", \\\"{x:1129,y:651,t:1527027420282};\\\", \\\"{x:1139,y:656,t:1527027420298};\\\", \\\"{x:1146,y:660,t:1527027420314};\\\", \\\"{x:1154,y:665,t:1527027420331};\\\", \\\"{x:1161,y:671,t:1527027420348};\\\", \\\"{x:1169,y:676,t:1527027420365};\\\", \\\"{x:1178,y:684,t:1527027420382};\\\", \\\"{x:1182,y:687,t:1527027420397};\\\", \\\"{x:1186,y:691,t:1527027420415};\\\", \\\"{x:1188,y:695,t:1527027420431};\\\", \\\"{x:1192,y:703,t:1527027420448};\\\", \\\"{x:1194,y:708,t:1527027420464};\\\", \\\"{x:1195,y:711,t:1527027420482};\\\", \\\"{x:1197,y:716,t:1527027420498};\\\", \\\"{x:1199,y:724,t:1527027420514};\\\", \\\"{x:1201,y:733,t:1527027420531};\\\", \\\"{x:1204,y:743,t:1527027420548};\\\", \\\"{x:1207,y:750,t:1527027420565};\\\", \\\"{x:1208,y:756,t:1527027420581};\\\", \\\"{x:1208,y:759,t:1527027420598};\\\", \\\"{x:1209,y:763,t:1527027420614};\\\", \\\"{x:1210,y:766,t:1527027420632};\\\", \\\"{x:1210,y:768,t:1527027420648};\\\", \\\"{x:1210,y:769,t:1527027420673};\\\", \\\"{x:1210,y:771,t:1527027420688};\\\", \\\"{x:1210,y:772,t:1527027420761};\\\", \\\"{x:1210,y:773,t:1527027420793};\\\", \\\"{x:1209,y:773,t:1527027420801};\\\", \\\"{x:1208,y:773,t:1527027420816};\\\", \\\"{x:1205,y:773,t:1527027420832};\\\", \\\"{x:1200,y:773,t:1527027420849};\\\", \\\"{x:1196,y:773,t:1527027420866};\\\", \\\"{x:1189,y:773,t:1527027420882};\\\", \\\"{x:1185,y:771,t:1527027420899};\\\", \\\"{x:1184,y:771,t:1527027420916};\\\", \\\"{x:1183,y:771,t:1527027420932};\\\", \\\"{x:1182,y:770,t:1527027420950};\\\", \\\"{x:1181,y:770,t:1527027420966};\\\", \\\"{x:1180,y:770,t:1527027420982};\\\", \\\"{x:1179,y:770,t:1527027420999};\\\", \\\"{x:1178,y:770,t:1527027421016};\\\", \\\"{x:1180,y:770,t:1527027421921};\\\", \\\"{x:1182,y:771,t:1527027421933};\\\", \\\"{x:1188,y:772,t:1527027421950};\\\", \\\"{x:1192,y:773,t:1527027421966};\\\", \\\"{x:1198,y:775,t:1527027421982};\\\", \\\"{x:1201,y:776,t:1527027421999};\\\", \\\"{x:1204,y:777,t:1527027422015};\\\", \\\"{x:1210,y:779,t:1527027422033};\\\", \\\"{x:1212,y:780,t:1527027422050};\\\", \\\"{x:1218,y:780,t:1527027422066};\\\", \\\"{x:1223,y:781,t:1527027422083};\\\", \\\"{x:1230,y:782,t:1527027422100};\\\", \\\"{x:1239,y:783,t:1527027422116};\\\", \\\"{x:1251,y:785,t:1527027422133};\\\", \\\"{x:1259,y:787,t:1527027422150};\\\", \\\"{x:1270,y:788,t:1527027422166};\\\", \\\"{x:1279,y:789,t:1527027422183};\\\", \\\"{x:1284,y:789,t:1527027422200};\\\", \\\"{x:1288,y:789,t:1527027422217};\\\", \\\"{x:1290,y:789,t:1527027422233};\\\", \\\"{x:1293,y:789,t:1527027422250};\\\", \\\"{x:1299,y:789,t:1527027422267};\\\", \\\"{x:1307,y:787,t:1527027422283};\\\", \\\"{x:1315,y:786,t:1527027422300};\\\", \\\"{x:1328,y:783,t:1527027422317};\\\", \\\"{x:1334,y:782,t:1527027422333};\\\", \\\"{x:1338,y:781,t:1527027422350};\\\", \\\"{x:1343,y:779,t:1527027422368};\\\", \\\"{x:1344,y:779,t:1527027422383};\\\", \\\"{x:1345,y:777,t:1527027422400};\\\", \\\"{x:1345,y:776,t:1527027422416};\\\", \\\"{x:1346,y:774,t:1527027422433};\\\", \\\"{x:1346,y:773,t:1527027422450};\\\", \\\"{x:1347,y:773,t:1527027422467};\\\", \\\"{x:1347,y:772,t:1527027422483};\\\", \\\"{x:1348,y:772,t:1527027422500};\\\", \\\"{x:1348,y:770,t:1527027422517};\\\", \\\"{x:1348,y:769,t:1527027422533};\\\", \\\"{x:1348,y:767,t:1527027422552};\\\", \\\"{x:1349,y:767,t:1527027422566};\\\", \\\"{x:1349,y:765,t:1527027422583};\\\", \\\"{x:1349,y:764,t:1527027422599};\\\", \\\"{x:1349,y:763,t:1527027422865};\\\", \\\"{x:1349,y:761,t:1527027422873};\\\", \\\"{x:1349,y:759,t:1527027422889};\\\", \\\"{x:1349,y:757,t:1527027422901};\\\", \\\"{x:1349,y:753,t:1527027422917};\\\", \\\"{x:1349,y:748,t:1527027422935};\\\", \\\"{x:1349,y:741,t:1527027422950};\\\", \\\"{x:1347,y:737,t:1527027422968};\\\", \\\"{x:1347,y:736,t:1527027422985};\\\", \\\"{x:1347,y:732,t:1527027423000};\\\", \\\"{x:1347,y:728,t:1527027423016};\\\", \\\"{x:1347,y:724,t:1527027423033};\\\", \\\"{x:1347,y:720,t:1527027423050};\\\", \\\"{x:1347,y:718,t:1527027423067};\\\", \\\"{x:1347,y:714,t:1527027423084};\\\", \\\"{x:1347,y:709,t:1527027423100};\\\", \\\"{x:1347,y:706,t:1527027423117};\\\", \\\"{x:1346,y:703,t:1527027423134};\\\", \\\"{x:1346,y:702,t:1527027423151};\\\", \\\"{x:1346,y:700,t:1527027423166};\\\", \\\"{x:1346,y:699,t:1527027423200};\\\", \\\"{x:1346,y:698,t:1527027423216};\\\", \\\"{x:1346,y:697,t:1527027423240};\\\", \\\"{x:1346,y:698,t:1527027424329};\\\", \\\"{x:1346,y:700,t:1527027424336};\\\", \\\"{x:1345,y:704,t:1527027424353};\\\", \\\"{x:1345,y:709,t:1527027424368};\\\", \\\"{x:1341,y:719,t:1527027424385};\\\", \\\"{x:1337,y:725,t:1527027424401};\\\", \\\"{x:1333,y:729,t:1527027424419};\\\", \\\"{x:1324,y:736,t:1527027424436};\\\", \\\"{x:1309,y:741,t:1527027424452};\\\", \\\"{x:1286,y:747,t:1527027424468};\\\", \\\"{x:1256,y:750,t:1527027424485};\\\", \\\"{x:1222,y:750,t:1527027424502};\\\", \\\"{x:1175,y:750,t:1527027424519};\\\", \\\"{x:1124,y:750,t:1527027424536};\\\", \\\"{x:1038,y:745,t:1527027424553};\\\", \\\"{x:1006,y:740,t:1527027424568};\\\", \\\"{x:925,y:724,t:1527027424585};\\\", \\\"{x:871,y:714,t:1527027424603};\\\", \\\"{x:837,y:709,t:1527027424619};\\\", \\\"{x:811,y:705,t:1527027424635};\\\", \\\"{x:788,y:701,t:1527027424653};\\\", \\\"{x:772,y:697,t:1527027424668};\\\", \\\"{x:754,y:693,t:1527027424685};\\\", \\\"{x:737,y:687,t:1527027424702};\\\", \\\"{x:720,y:686,t:1527027424718};\\\", \\\"{x:706,y:683,t:1527027424735};\\\", \\\"{x:693,y:682,t:1527027424752};\\\", \\\"{x:690,y:682,t:1527027424768};\\\", \\\"{x:689,y:681,t:1527027424785};\\\", \\\"{x:688,y:680,t:1527027424880};\\\", \\\"{x:688,y:679,t:1527027424888};\\\", \\\"{x:686,y:679,t:1527027424904};\\\", \\\"{x:685,y:679,t:1527027424920};\\\", \\\"{x:684,y:679,t:1527027424935};\\\", \\\"{x:681,y:677,t:1527027424952};\\\", \\\"{x:677,y:676,t:1527027424968};\\\", \\\"{x:672,y:675,t:1527027424985};\\\", \\\"{x:669,y:673,t:1527027425002};\\\", \\\"{x:664,y:671,t:1527027425020};\\\", \\\"{x:659,y:668,t:1527027425035};\\\", \\\"{x:654,y:663,t:1527027425052};\\\", \\\"{x:642,y:652,t:1527027425069};\\\", \\\"{x:627,y:643,t:1527027425085};\\\", \\\"{x:615,y:631,t:1527027425104};\\\", \\\"{x:598,y:617,t:1527027425119};\\\", \\\"{x:582,y:599,t:1527027425135};\\\", \\\"{x:571,y:585,t:1527027425144};\\\", \\\"{x:557,y:573,t:1527027425161};\\\", \\\"{x:546,y:566,t:1527027425177};\\\", \\\"{x:540,y:562,t:1527027425194};\\\", \\\"{x:538,y:559,t:1527027425211};\\\", \\\"{x:534,y:556,t:1527027425234};\\\", \\\"{x:533,y:553,t:1527027425252};\\\", \\\"{x:532,y:551,t:1527027425269};\\\", \\\"{x:531,y:549,t:1527027425286};\\\", \\\"{x:530,y:547,t:1527027425301};\\\", \\\"{x:530,y:545,t:1527027425319};\\\", \\\"{x:530,y:543,t:1527027425336};\\\", \\\"{x:530,y:541,t:1527027425351};\\\", \\\"{x:530,y:540,t:1527027425368};\\\", \\\"{x:531,y:537,t:1527027425386};\\\", \\\"{x:539,y:532,t:1527027425402};\\\", \\\"{x:544,y:532,t:1527027425419};\\\", \\\"{x:548,y:532,t:1527027425436};\\\", \\\"{x:550,y:532,t:1527027425452};\\\", \\\"{x:552,y:532,t:1527027425472};\\\", \\\"{x:553,y:532,t:1527027425486};\\\", \\\"{x:558,y:532,t:1527027425502};\\\", \\\"{x:570,y:532,t:1527027425519};\\\", \\\"{x:592,y:533,t:1527027425536};\\\", \\\"{x:609,y:535,t:1527027425554};\\\", \\\"{x:629,y:538,t:1527027425569};\\\", \\\"{x:640,y:538,t:1527027425586};\\\", \\\"{x:652,y:538,t:1527027425602};\\\", \\\"{x:658,y:538,t:1527027425619};\\\", \\\"{x:663,y:537,t:1527027425636};\\\", \\\"{x:668,y:534,t:1527027425652};\\\", \\\"{x:672,y:530,t:1527027425669};\\\", \\\"{x:677,y:525,t:1527027425686};\\\", \\\"{x:678,y:522,t:1527027425703};\\\", \\\"{x:679,y:518,t:1527027425718};\\\", \\\"{x:679,y:513,t:1527027425737};\\\", \\\"{x:681,y:510,t:1527027425753};\\\", \\\"{x:682,y:507,t:1527027425769};\\\", \\\"{x:684,y:505,t:1527027425786};\\\", \\\"{x:689,y:504,t:1527027425802};\\\", \\\"{x:697,y:502,t:1527027425819};\\\", \\\"{x:713,y:502,t:1527027425835};\\\", \\\"{x:737,y:502,t:1527027425854};\\\", \\\"{x:760,y:502,t:1527027425869};\\\", \\\"{x:792,y:502,t:1527027425885};\\\", \\\"{x:818,y:502,t:1527027425903};\\\", \\\"{x:843,y:502,t:1527027425920};\\\", \\\"{x:858,y:500,t:1527027425935};\\\", \\\"{x:858,y:499,t:1527027426032};\\\", \\\"{x:858,y:498,t:1527027426048};\\\", \\\"{x:858,y:496,t:1527027426063};\\\", \\\"{x:857,y:496,t:1527027426072};\\\", \\\"{x:854,y:495,t:1527027426086};\\\", \\\"{x:851,y:495,t:1527027426103};\\\", \\\"{x:843,y:495,t:1527027426120};\\\", \\\"{x:838,y:496,t:1527027426135};\\\", \\\"{x:833,y:499,t:1527027426153};\\\", \\\"{x:831,y:499,t:1527027426170};\\\", \\\"{x:829,y:498,t:1527027426431};\\\", \\\"{x:825,y:499,t:1527027426440};\\\", \\\"{x:820,y:501,t:1527027426452};\\\", \\\"{x:805,y:506,t:1527027426469};\\\", \\\"{x:788,y:510,t:1527027426486};\\\", \\\"{x:765,y:515,t:1527027426503};\\\", \\\"{x:718,y:520,t:1527027426521};\\\", \\\"{x:662,y:520,t:1527027426536};\\\", \\\"{x:600,y:520,t:1527027426552};\\\", \\\"{x:542,y:520,t:1527027426570};\\\", \\\"{x:494,y:520,t:1527027426587};\\\", \\\"{x:469,y:520,t:1527027426603};\\\", \\\"{x:447,y:520,t:1527027426620};\\\", \\\"{x:432,y:520,t:1527027426637};\\\", \\\"{x:420,y:520,t:1527027426653};\\\", \\\"{x:411,y:519,t:1527027426670};\\\", \\\"{x:404,y:519,t:1527027426687};\\\", \\\"{x:398,y:519,t:1527027426703};\\\", \\\"{x:388,y:520,t:1527027426720};\\\", \\\"{x:383,y:520,t:1527027426736};\\\", \\\"{x:380,y:521,t:1527027426753};\\\", \\\"{x:379,y:522,t:1527027426771};\\\", \\\"{x:375,y:524,t:1527027426787};\\\", \\\"{x:372,y:525,t:1527027426806};\\\", \\\"{x:366,y:529,t:1527027426819};\\\", \\\"{x:357,y:533,t:1527027426837};\\\", \\\"{x:345,y:534,t:1527027426854};\\\", \\\"{x:329,y:534,t:1527027426870};\\\", \\\"{x:318,y:534,t:1527027426886};\\\", \\\"{x:297,y:537,t:1527027426904};\\\", \\\"{x:276,y:539,t:1527027426920};\\\", \\\"{x:257,y:542,t:1527027426938};\\\", \\\"{x:235,y:542,t:1527027426954};\\\", \\\"{x:217,y:542,t:1527027426970};\\\", \\\"{x:206,y:542,t:1527027426987};\\\", \\\"{x:202,y:542,t:1527027427003};\\\", \\\"{x:200,y:542,t:1527027427020};\\\", \\\"{x:198,y:542,t:1527027427040};\\\", \\\"{x:197,y:542,t:1527027427054};\\\", \\\"{x:195,y:542,t:1527027427070};\\\", \\\"{x:186,y:542,t:1527027427087};\\\", \\\"{x:175,y:542,t:1527027427104};\\\", \\\"{x:173,y:542,t:1527027427120};\\\", \\\"{x:172,y:542,t:1527027427208};\\\", \\\"{x:169,y:542,t:1527027427219};\\\", \\\"{x:166,y:542,t:1527027427237};\\\", \\\"{x:165,y:542,t:1527027427254};\\\", \\\"{x:163,y:542,t:1527027427345};\\\", \\\"{x:162,y:543,t:1527027427537};\\\", \\\"{x:163,y:545,t:1527027427576};\\\", \\\"{x:165,y:545,t:1527027427586};\\\", \\\"{x:167,y:546,t:1527027427603};\\\", \\\"{x:174,y:548,t:1527027427620};\\\", \\\"{x:183,y:554,t:1527027427638};\\\", \\\"{x:202,y:565,t:1527027427655};\\\", \\\"{x:224,y:578,t:1527027427671};\\\", \\\"{x:255,y:595,t:1527027427687};\\\", \\\"{x:296,y:619,t:1527027427704};\\\", \\\"{x:330,y:637,t:1527027427721};\\\", \\\"{x:360,y:654,t:1527027427739};\\\", \\\"{x:388,y:673,t:1527027427754};\\\", \\\"{x:411,y:691,t:1527027427771};\\\", \\\"{x:425,y:703,t:1527027427788};\\\", \\\"{x:438,y:713,t:1527027427804};\\\", \\\"{x:448,y:723,t:1527027427821};\\\", \\\"{x:457,y:731,t:1527027427838};\\\", \\\"{x:465,y:737,t:1527027427854};\\\", \\\"{x:471,y:742,t:1527027427870};\\\", \\\"{x:477,y:746,t:1527027427887};\\\", \\\"{x:489,y:754,t:1527027427904};\\\", \\\"{x:495,y:757,t:1527027427921};\\\", \\\"{x:500,y:759,t:1527027427937};\\\", \\\"{x:503,y:761,t:1527027427954};\\\", \\\"{x:504,y:761,t:1527027427984};\\\", \\\"{x:505,y:761,t:1527027428088};\\\", \\\"{x:505,y:757,t:1527027428104};\\\", \\\"{x:506,y:750,t:1527027428122};\\\", \\\"{x:506,y:746,t:1527027428138};\\\", \\\"{x:506,y:744,t:1527027428154};\\\", \\\"{x:507,y:743,t:1527027428303};\\\", \\\"{x:507,y:743,t:1527027428379};\\\" ] }, { \\\"rt\\\": 25135, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 292810, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"C30CF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"J\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-3-I -B -B -I -I -J -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:743,t:1527027430849};\\\", \\\"{x:512,y:743,t:1527027430857};\\\", \\\"{x:519,y:743,t:1527027430877};\\\", \\\"{x:529,y:744,t:1527027430891};\\\", \\\"{x:545,y:746,t:1527027430908};\\\", \\\"{x:560,y:748,t:1527027430924};\\\", \\\"{x:570,y:749,t:1527027430942};\\\", \\\"{x:579,y:750,t:1527027430958};\\\", \\\"{x:589,y:751,t:1527027430973};\\\", \\\"{x:597,y:753,t:1527027430990};\\\", \\\"{x:609,y:754,t:1527027431007};\\\", \\\"{x:625,y:757,t:1527027431023};\\\", \\\"{x:646,y:759,t:1527027431039};\\\", \\\"{x:661,y:762,t:1527027431057};\\\", \\\"{x:681,y:765,t:1527027431073};\\\", \\\"{x:704,y:765,t:1527027431090};\\\", \\\"{x:731,y:765,t:1527027431107};\\\", \\\"{x:761,y:765,t:1527027431123};\\\", \\\"{x:798,y:765,t:1527027431140};\\\", \\\"{x:829,y:765,t:1527027431157};\\\", \\\"{x:859,y:765,t:1527027431173};\\\", \\\"{x:889,y:765,t:1527027431190};\\\", \\\"{x:915,y:766,t:1527027431207};\\\", \\\"{x:938,y:768,t:1527027431223};\\\", \\\"{x:968,y:769,t:1527027431240};\\\", \\\"{x:983,y:769,t:1527027431257};\\\", \\\"{x:992,y:769,t:1527027431273};\\\", \\\"{x:997,y:769,t:1527027431289};\\\", \\\"{x:1002,y:769,t:1527027431307};\\\", \\\"{x:1009,y:769,t:1527027431324};\\\", \\\"{x:1015,y:769,t:1527027431340};\\\", \\\"{x:1020,y:769,t:1527027431357};\\\", \\\"{x:1025,y:768,t:1527027431375};\\\", \\\"{x:1025,y:764,t:1527027431390};\\\", \\\"{x:1025,y:762,t:1527027432442};\\\", \\\"{x:1025,y:761,t:1527027432529};\\\", \\\"{x:1025,y:760,t:1527027432542};\\\", \\\"{x:1025,y:759,t:1527027432559};\\\", \\\"{x:1025,y:758,t:1527027432574};\\\", \\\"{x:1026,y:758,t:1527027432809};\\\", \\\"{x:1027,y:758,t:1527027432832};\\\", \\\"{x:1028,y:758,t:1527027432849};\\\", \\\"{x:1029,y:758,t:1527027432859};\\\", \\\"{x:1031,y:757,t:1527027432875};\\\", \\\"{x:1032,y:757,t:1527027432892};\\\", \\\"{x:1034,y:757,t:1527027432909};\\\", \\\"{x:1036,y:757,t:1527027432925};\\\", \\\"{x:1038,y:757,t:1527027432941};\\\", \\\"{x:1039,y:757,t:1527027432958};\\\", \\\"{x:1041,y:757,t:1527027432975};\\\", \\\"{x:1043,y:757,t:1527027433193};\\\", \\\"{x:1045,y:757,t:1527027433208};\\\", \\\"{x:1047,y:757,t:1527027433226};\\\", \\\"{x:1048,y:757,t:1527027433242};\\\", \\\"{x:1050,y:757,t:1527027433259};\\\", \\\"{x:1052,y:757,t:1527027433275};\\\", \\\"{x:1055,y:757,t:1527027433293};\\\", \\\"{x:1059,y:757,t:1527027433309};\\\", \\\"{x:1061,y:757,t:1527027433326};\\\", \\\"{x:1063,y:757,t:1527027433343};\\\", \\\"{x:1064,y:757,t:1527027433359};\\\", \\\"{x:1065,y:757,t:1527027433393};\\\", \\\"{x:1066,y:757,t:1527027433409};\\\", \\\"{x:1067,y:757,t:1527027433426};\\\", \\\"{x:1068,y:757,t:1527027433443};\\\", \\\"{x:1069,y:757,t:1527027433459};\\\", \\\"{x:1070,y:757,t:1527027433476};\\\", \\\"{x:1071,y:757,t:1527027433493};\\\", \\\"{x:1073,y:757,t:1527027433509};\\\", \\\"{x:1074,y:757,t:1527027433593};\\\", \\\"{x:1073,y:756,t:1527027435249};\\\", \\\"{x:1073,y:754,t:1527027436057};\\\", \\\"{x:1073,y:753,t:1527027436065};\\\", \\\"{x:1074,y:752,t:1527027436089};\\\", \\\"{x:1076,y:751,t:1527027436120};\\\", \\\"{x:1076,y:750,t:1527027436161};\\\", \\\"{x:1077,y:749,t:1527027436178};\\\", \\\"{x:1078,y:748,t:1527027436208};\\\", \\\"{x:1079,y:748,t:1527027436256};\\\", \\\"{x:1080,y:748,t:1527027436272};\\\", \\\"{x:1082,y:748,t:1527027436279};\\\", \\\"{x:1083,y:748,t:1527027436294};\\\", \\\"{x:1090,y:748,t:1527027436311};\\\", \\\"{x:1100,y:748,t:1527027436327};\\\", \\\"{x:1112,y:748,t:1527027436344};\\\", \\\"{x:1122,y:748,t:1527027436360};\\\", \\\"{x:1134,y:749,t:1527027436378};\\\", \\\"{x:1137,y:751,t:1527027436395};\\\", \\\"{x:1140,y:752,t:1527027436410};\\\", \\\"{x:1142,y:753,t:1527027436427};\\\", \\\"{x:1146,y:754,t:1527027436444};\\\", \\\"{x:1150,y:756,t:1527027436460};\\\", \\\"{x:1159,y:760,t:1527027436478};\\\", \\\"{x:1168,y:762,t:1527027436495};\\\", \\\"{x:1182,y:766,t:1527027436512};\\\", \\\"{x:1195,y:770,t:1527027436528};\\\", \\\"{x:1213,y:776,t:1527027436544};\\\", \\\"{x:1221,y:778,t:1527027436561};\\\", \\\"{x:1225,y:779,t:1527027436577};\\\", \\\"{x:1231,y:781,t:1527027436595};\\\", \\\"{x:1233,y:781,t:1527027436612};\\\", \\\"{x:1235,y:782,t:1527027436628};\\\", \\\"{x:1237,y:783,t:1527027436644};\\\", \\\"{x:1239,y:784,t:1527027436662};\\\", \\\"{x:1240,y:785,t:1527027436678};\\\", \\\"{x:1241,y:785,t:1527027436695};\\\", \\\"{x:1243,y:785,t:1527027436712};\\\", \\\"{x:1245,y:785,t:1527027436728};\\\", \\\"{x:1252,y:785,t:1527027436744};\\\", \\\"{x:1256,y:785,t:1527027436762};\\\", \\\"{x:1262,y:785,t:1527027436778};\\\", \\\"{x:1273,y:781,t:1527027436794};\\\", \\\"{x:1287,y:777,t:1527027436811};\\\", \\\"{x:1297,y:775,t:1527027436827};\\\", \\\"{x:1306,y:773,t:1527027436844};\\\", \\\"{x:1313,y:772,t:1527027436862};\\\", \\\"{x:1316,y:771,t:1527027436877};\\\", \\\"{x:1318,y:770,t:1527027436894};\\\", \\\"{x:1323,y:769,t:1527027436912};\\\", \\\"{x:1328,y:769,t:1527027436927};\\\", \\\"{x:1341,y:767,t:1527027436944};\\\", \\\"{x:1351,y:765,t:1527027436962};\\\", \\\"{x:1361,y:763,t:1527027436978};\\\", \\\"{x:1364,y:763,t:1527027436994};\\\", \\\"{x:1364,y:762,t:1527027437154};\\\", \\\"{x:1363,y:761,t:1527027437169};\\\", \\\"{x:1360,y:761,t:1527027437179};\\\", \\\"{x:1351,y:761,t:1527027437195};\\\", \\\"{x:1344,y:761,t:1527027437211};\\\", \\\"{x:1339,y:761,t:1527027437229};\\\", \\\"{x:1334,y:761,t:1527027437245};\\\", \\\"{x:1333,y:761,t:1527027437261};\\\", \\\"{x:1330,y:761,t:1527027437464};\\\", \\\"{x:1328,y:761,t:1527027437478};\\\", \\\"{x:1322,y:761,t:1527027437495};\\\", \\\"{x:1319,y:761,t:1527027437512};\\\", \\\"{x:1315,y:761,t:1527027437528};\\\", \\\"{x:1314,y:761,t:1527027437552};\\\", \\\"{x:1313,y:761,t:1527027437572};\\\", \\\"{x:1312,y:761,t:1527027437584};\\\", \\\"{x:1311,y:761,t:1527027437594};\\\", \\\"{x:1309,y:761,t:1527027437611};\\\", \\\"{x:1306,y:761,t:1527027437628};\\\", \\\"{x:1303,y:761,t:1527027437645};\\\", \\\"{x:1302,y:761,t:1527027437662};\\\", \\\"{x:1300,y:761,t:1527027437678};\\\", \\\"{x:1299,y:761,t:1527027437712};\\\", \\\"{x:1297,y:761,t:1527027442305};\\\", \\\"{x:1295,y:761,t:1527027442315};\\\", \\\"{x:1290,y:761,t:1527027442332};\\\", \\\"{x:1285,y:761,t:1527027442349};\\\", \\\"{x:1278,y:761,t:1527027442365};\\\", \\\"{x:1272,y:761,t:1527027442383};\\\", \\\"{x:1261,y:761,t:1527027442399};\\\", \\\"{x:1256,y:761,t:1527027442416};\\\", \\\"{x:1244,y:761,t:1527027442433};\\\", \\\"{x:1234,y:761,t:1527027442449};\\\", \\\"{x:1225,y:761,t:1527027442466};\\\", \\\"{x:1216,y:761,t:1527027442482};\\\", \\\"{x:1205,y:761,t:1527027442499};\\\", \\\"{x:1193,y:761,t:1527027442516};\\\", \\\"{x:1181,y:760,t:1527027442533};\\\", \\\"{x:1170,y:760,t:1527027442550};\\\", \\\"{x:1163,y:759,t:1527027442566};\\\", \\\"{x:1158,y:759,t:1527027442583};\\\", \\\"{x:1155,y:759,t:1527027442599};\\\", \\\"{x:1154,y:759,t:1527027442616};\\\", \\\"{x:1156,y:759,t:1527027442761};\\\", \\\"{x:1162,y:759,t:1527027442769};\\\", \\\"{x:1168,y:759,t:1527027442782};\\\", \\\"{x:1179,y:759,t:1527027442799};\\\", \\\"{x:1193,y:759,t:1527027442817};\\\", \\\"{x:1202,y:759,t:1527027442832};\\\", \\\"{x:1208,y:759,t:1527027442849};\\\", \\\"{x:1211,y:759,t:1527027442866};\\\", \\\"{x:1213,y:759,t:1527027442883};\\\", \\\"{x:1215,y:759,t:1527027442899};\\\", \\\"{x:1217,y:759,t:1527027442917};\\\", \\\"{x:1220,y:759,t:1527027442934};\\\", \\\"{x:1221,y:759,t:1527027442949};\\\", \\\"{x:1223,y:759,t:1527027442966};\\\", \\\"{x:1224,y:759,t:1527027442983};\\\", \\\"{x:1226,y:759,t:1527027442999};\\\", \\\"{x:1227,y:759,t:1527027443081};\\\", \\\"{x:1229,y:759,t:1527027443097};\\\", \\\"{x:1232,y:759,t:1527027443105};\\\", \\\"{x:1234,y:759,t:1527027443116};\\\", \\\"{x:1237,y:757,t:1527027443133};\\\", \\\"{x:1239,y:757,t:1527027443377};\\\", \\\"{x:1241,y:757,t:1527027443384};\\\", \\\"{x:1244,y:757,t:1527027443399};\\\", \\\"{x:1251,y:758,t:1527027443417};\\\", \\\"{x:1260,y:758,t:1527027443433};\\\", \\\"{x:1267,y:759,t:1527027443450};\\\", \\\"{x:1274,y:760,t:1527027443466};\\\", \\\"{x:1277,y:760,t:1527027443484};\\\", \\\"{x:1280,y:760,t:1527027443500};\\\", \\\"{x:1282,y:760,t:1527027443516};\\\", \\\"{x:1283,y:760,t:1527027443533};\\\", \\\"{x:1286,y:760,t:1527027443550};\\\", \\\"{x:1289,y:762,t:1527027443721};\\\", \\\"{x:1293,y:762,t:1527027443733};\\\", \\\"{x:1303,y:763,t:1527027443751};\\\", \\\"{x:1320,y:765,t:1527027443766};\\\", \\\"{x:1335,y:767,t:1527027443784};\\\", \\\"{x:1357,y:770,t:1527027443800};\\\", \\\"{x:1363,y:771,t:1527027443816};\\\", \\\"{x:1365,y:771,t:1527027443833};\\\", \\\"{x:1361,y:772,t:1527027443977};\\\", \\\"{x:1354,y:773,t:1527027443985};\\\", \\\"{x:1334,y:776,t:1527027444001};\\\", \\\"{x:1312,y:777,t:1527027444017};\\\", \\\"{x:1286,y:781,t:1527027444033};\\\", \\\"{x:1264,y:784,t:1527027444050};\\\", \\\"{x:1247,y:787,t:1527027444067};\\\", \\\"{x:1237,y:788,t:1527027444083};\\\", \\\"{x:1232,y:790,t:1527027444101};\\\", \\\"{x:1228,y:792,t:1527027444117};\\\", \\\"{x:1225,y:794,t:1527027444133};\\\", \\\"{x:1221,y:796,t:1527027444151};\\\", \\\"{x:1218,y:799,t:1527027444168};\\\", \\\"{x:1214,y:802,t:1527027444183};\\\", \\\"{x:1210,y:804,t:1527027444200};\\\", \\\"{x:1207,y:807,t:1527027444216};\\\", \\\"{x:1205,y:810,t:1527027444233};\\\", \\\"{x:1204,y:811,t:1527027444251};\\\", \\\"{x:1202,y:812,t:1527027444267};\\\", \\\"{x:1202,y:813,t:1527027444297};\\\", \\\"{x:1202,y:815,t:1527027444313};\\\", \\\"{x:1201,y:816,t:1527027444321};\\\", \\\"{x:1201,y:817,t:1527027444529};\\\", \\\"{x:1201,y:818,t:1527027444537};\\\", \\\"{x:1201,y:819,t:1527027444553};\\\", \\\"{x:1201,y:820,t:1527027444592};\\\", \\\"{x:1202,y:821,t:1527027444649};\\\", \\\"{x:1203,y:821,t:1527027444705};\\\", \\\"{x:1205,y:822,t:1527027444721};\\\", \\\"{x:1206,y:822,t:1527027444809};\\\", \\\"{x:1207,y:822,t:1527027444945};\\\", \\\"{x:1209,y:822,t:1527027444952};\\\", \\\"{x:1211,y:822,t:1527027444968};\\\", \\\"{x:1224,y:822,t:1527027444985};\\\", \\\"{x:1234,y:823,t:1527027445001};\\\", \\\"{x:1241,y:823,t:1527027445017};\\\", \\\"{x:1247,y:823,t:1527027445033};\\\", \\\"{x:1250,y:823,t:1527027445051};\\\", \\\"{x:1252,y:823,t:1527027445067};\\\", \\\"{x:1253,y:823,t:1527027445083};\\\", \\\"{x:1255,y:823,t:1527027445101};\\\", \\\"{x:1257,y:822,t:1527027445117};\\\", \\\"{x:1258,y:822,t:1527027445134};\\\", \\\"{x:1260,y:822,t:1527027445151};\\\", \\\"{x:1263,y:822,t:1527027445167};\\\", \\\"{x:1266,y:822,t:1527027445184};\\\", \\\"{x:1268,y:822,t:1527027445281};\\\", \\\"{x:1269,y:822,t:1527027445289};\\\", \\\"{x:1271,y:822,t:1527027445302};\\\", \\\"{x:1275,y:822,t:1527027445319};\\\", \\\"{x:1276,y:822,t:1527027445334};\\\", \\\"{x:1278,y:822,t:1527027445441};\\\", \\\"{x:1280,y:823,t:1527027445457};\\\", \\\"{x:1281,y:823,t:1527027445468};\\\", \\\"{x:1282,y:823,t:1527027445484};\\\", \\\"{x:1286,y:824,t:1527027445502};\\\", \\\"{x:1288,y:825,t:1527027445519};\\\", \\\"{x:1292,y:825,t:1527027445534};\\\", \\\"{x:1295,y:826,t:1527027445551};\\\", \\\"{x:1299,y:826,t:1527027445569};\\\", \\\"{x:1300,y:826,t:1527027445584};\\\", \\\"{x:1301,y:826,t:1527027445601};\\\", \\\"{x:1302,y:826,t:1527027445619};\\\", \\\"{x:1305,y:826,t:1527027445634};\\\", \\\"{x:1309,y:826,t:1527027445651};\\\", \\\"{x:1316,y:827,t:1527027445669};\\\", \\\"{x:1317,y:827,t:1527027445685};\\\", \\\"{x:1319,y:827,t:1527027445702};\\\", \\\"{x:1320,y:827,t:1527027445745};\\\", \\\"{x:1322,y:827,t:1527027445760};\\\", \\\"{x:1324,y:828,t:1527027445768};\\\", \\\"{x:1331,y:829,t:1527027445784};\\\", \\\"{x:1341,y:829,t:1527027445801};\\\", \\\"{x:1347,y:830,t:1527027445818};\\\", \\\"{x:1352,y:830,t:1527027445836};\\\", \\\"{x:1353,y:830,t:1527027445896};\\\", \\\"{x:1355,y:830,t:1527027445904};\\\", \\\"{x:1355,y:831,t:1527027446058};\\\", \\\"{x:1354,y:832,t:1527027446128};\\\", \\\"{x:1353,y:832,t:1527027446183};\\\", \\\"{x:1352,y:832,t:1527027446239};\\\", \\\"{x:1350,y:832,t:1527027446271};\\\", \\\"{x:1349,y:832,t:1527027446537};\\\", \\\"{x:1345,y:832,t:1527027446553};\\\", \\\"{x:1344,y:831,t:1527027446569};\\\", \\\"{x:1342,y:830,t:1527027446586};\\\", \\\"{x:1341,y:830,t:1527027446602};\\\", \\\"{x:1336,y:825,t:1527027449416};\\\", \\\"{x:1313,y:815,t:1527027449423};\\\", \\\"{x:1278,y:800,t:1527027449437};\\\", \\\"{x:1176,y:770,t:1527027449454};\\\", \\\"{x:1049,y:736,t:1527027449470};\\\", \\\"{x:941,y:706,t:1527027449486};\\\", \\\"{x:838,y:676,t:1527027449504};\\\", \\\"{x:806,y:663,t:1527027449520};\\\", \\\"{x:796,y:655,t:1527027449536};\\\", \\\"{x:793,y:651,t:1527027449554};\\\", \\\"{x:787,y:643,t:1527027449570};\\\", \\\"{x:777,y:631,t:1527027449589};\\\", \\\"{x:768,y:620,t:1527027449604};\\\", \\\"{x:750,y:606,t:1527027449621};\\\", \\\"{x:733,y:593,t:1527027449639};\\\", \\\"{x:725,y:587,t:1527027449655};\\\", \\\"{x:719,y:580,t:1527027449672};\\\", \\\"{x:717,y:572,t:1527027449688};\\\", \\\"{x:716,y:569,t:1527027449705};\\\", \\\"{x:716,y:568,t:1527027449722};\\\", \\\"{x:716,y:566,t:1527027449738};\\\", \\\"{x:716,y:565,t:1527027449755};\\\", \\\"{x:716,y:563,t:1527027449772};\\\", \\\"{x:716,y:562,t:1527027449790};\\\", \\\"{x:716,y:561,t:1527027449805};\\\", \\\"{x:708,y:559,t:1527027449822};\\\", \\\"{x:691,y:558,t:1527027449839};\\\", \\\"{x:653,y:560,t:1527027449856};\\\", \\\"{x:628,y:565,t:1527027449873};\\\", \\\"{x:610,y:566,t:1527027449889};\\\", \\\"{x:601,y:568,t:1527027449905};\\\", \\\"{x:596,y:568,t:1527027449922};\\\", \\\"{x:592,y:569,t:1527027449939};\\\", \\\"{x:589,y:571,t:1527027449955};\\\", \\\"{x:585,y:574,t:1527027449971};\\\", \\\"{x:578,y:577,t:1527027449988};\\\", \\\"{x:572,y:579,t:1527027450006};\\\", \\\"{x:559,y:583,t:1527027450022};\\\", \\\"{x:541,y:584,t:1527027450039};\\\", \\\"{x:519,y:584,t:1527027450055};\\\", \\\"{x:495,y:587,t:1527027450073};\\\", \\\"{x:490,y:588,t:1527027450089};\\\", \\\"{x:487,y:589,t:1527027450106};\\\", \\\"{x:485,y:589,t:1527027450121};\\\", \\\"{x:481,y:589,t:1527027450139};\\\", \\\"{x:472,y:589,t:1527027450156};\\\", \\\"{x:456,y:589,t:1527027450171};\\\", \\\"{x:441,y:589,t:1527027450189};\\\", \\\"{x:431,y:589,t:1527027450206};\\\", \\\"{x:425,y:589,t:1527027450221};\\\", \\\"{x:423,y:589,t:1527027450239};\\\", \\\"{x:419,y:591,t:1527027450255};\\\", \\\"{x:416,y:594,t:1527027450272};\\\", \\\"{x:412,y:595,t:1527027450289};\\\", \\\"{x:409,y:597,t:1527027450306};\\\", \\\"{x:406,y:599,t:1527027450322};\\\", \\\"{x:406,y:600,t:1527027450339};\\\", \\\"{x:405,y:601,t:1527027450357};\\\", \\\"{x:405,y:602,t:1527027450372};\\\", \\\"{x:403,y:603,t:1527027450388};\\\", \\\"{x:400,y:604,t:1527027450406};\\\", \\\"{x:393,y:605,t:1527027450423};\\\", \\\"{x:384,y:606,t:1527027450439};\\\", \\\"{x:368,y:609,t:1527027450455};\\\", \\\"{x:354,y:609,t:1527027450473};\\\", \\\"{x:333,y:606,t:1527027450488};\\\", \\\"{x:314,y:601,t:1527027450506};\\\", \\\"{x:293,y:596,t:1527027450524};\\\", \\\"{x:268,y:589,t:1527027450540};\\\", \\\"{x:246,y:585,t:1527027450556};\\\", \\\"{x:227,y:578,t:1527027450572};\\\", \\\"{x:211,y:574,t:1527027450588};\\\", \\\"{x:199,y:568,t:1527027450606};\\\", \\\"{x:189,y:563,t:1527027450623};\\\", \\\"{x:179,y:556,t:1527027450640};\\\", \\\"{x:176,y:553,t:1527027450656};\\\", \\\"{x:175,y:549,t:1527027450672};\\\", \\\"{x:175,y:541,t:1527027450689};\\\", \\\"{x:185,y:533,t:1527027450706};\\\", \\\"{x:203,y:528,t:1527027450723};\\\", \\\"{x:233,y:520,t:1527027450739};\\\", \\\"{x:262,y:517,t:1527027450756};\\\", \\\"{x:287,y:516,t:1527027450773};\\\", \\\"{x:312,y:516,t:1527027450789};\\\", \\\"{x:333,y:516,t:1527027450806};\\\", \\\"{x:347,y:516,t:1527027450823};\\\", \\\"{x:354,y:516,t:1527027450838};\\\", \\\"{x:358,y:512,t:1527027450856};\\\", \\\"{x:360,y:511,t:1527027450873};\\\", \\\"{x:361,y:510,t:1527027450888};\\\", \\\"{x:363,y:508,t:1527027450906};\\\", \\\"{x:364,y:507,t:1527027450923};\\\", \\\"{x:366,y:505,t:1527027450939};\\\", \\\"{x:366,y:504,t:1527027450956};\\\", \\\"{x:366,y:502,t:1527027450993};\\\", \\\"{x:368,y:501,t:1527027451007};\\\", \\\"{x:369,y:500,t:1527027451023};\\\", \\\"{x:374,y:498,t:1527027451039};\\\", \\\"{x:379,y:497,t:1527027451056};\\\", \\\"{x:382,y:497,t:1527027451072};\\\", \\\"{x:383,y:497,t:1527027451096};\\\", \\\"{x:384,y:497,t:1527027451112};\\\", \\\"{x:385,y:497,t:1527027451400};\\\", \\\"{x:387,y:497,t:1527027451408};\\\", \\\"{x:390,y:497,t:1527027451423};\\\", \\\"{x:413,y:503,t:1527027451440};\\\", \\\"{x:450,y:519,t:1527027451458};\\\", \\\"{x:515,y:542,t:1527027451474};\\\", \\\"{x:588,y:566,t:1527027451491};\\\", \\\"{x:680,y:593,t:1527027451507};\\\", \\\"{x:771,y:620,t:1527027451523};\\\", \\\"{x:866,y:652,t:1527027451541};\\\", \\\"{x:956,y:681,t:1527027451557};\\\", \\\"{x:1029,y:709,t:1527027451574};\\\", \\\"{x:1097,y:734,t:1527027451590};\\\", \\\"{x:1146,y:753,t:1527027451607};\\\", \\\"{x:1203,y:779,t:1527027451623};\\\", \\\"{x:1228,y:793,t:1527027451640};\\\", \\\"{x:1259,y:808,t:1527027451657};\\\", \\\"{x:1287,y:822,t:1527027451674};\\\", \\\"{x:1313,y:832,t:1527027451690};\\\", \\\"{x:1334,y:841,t:1527027451707};\\\", \\\"{x:1370,y:856,t:1527027451724};\\\", \\\"{x:1385,y:863,t:1527027451741};\\\", \\\"{x:1395,y:868,t:1527027451757};\\\", \\\"{x:1405,y:872,t:1527027451775};\\\", \\\"{x:1412,y:874,t:1527027451791};\\\", \\\"{x:1413,y:874,t:1527027451808};\\\", \\\"{x:1414,y:874,t:1527027451849};\\\", \\\"{x:1413,y:872,t:1527027451858};\\\", \\\"{x:1406,y:866,t:1527027451875};\\\", \\\"{x:1393,y:863,t:1527027451892};\\\", \\\"{x:1376,y:861,t:1527027451908};\\\", \\\"{x:1354,y:856,t:1527027451924};\\\", \\\"{x:1326,y:851,t:1527027451942};\\\", \\\"{x:1295,y:846,t:1527027451959};\\\", \\\"{x:1271,y:844,t:1527027451975};\\\", \\\"{x:1247,y:840,t:1527027451991};\\\", \\\"{x:1230,y:837,t:1527027452008};\\\", \\\"{x:1229,y:837,t:1527027452025};\\\", \\\"{x:1230,y:836,t:1527027452113};\\\", \\\"{x:1235,y:836,t:1527027452126};\\\", \\\"{x:1249,y:836,t:1527027452143};\\\", \\\"{x:1270,y:836,t:1527027452159};\\\", \\\"{x:1294,y:836,t:1527027452176};\\\", \\\"{x:1334,y:836,t:1527027452192};\\\", \\\"{x:1359,y:836,t:1527027452208};\\\", \\\"{x:1380,y:836,t:1527027452225};\\\", \\\"{x:1398,y:836,t:1527027452243};\\\", \\\"{x:1415,y:836,t:1527027452260};\\\", \\\"{x:1427,y:836,t:1527027452275};\\\", \\\"{x:1433,y:836,t:1527027452292};\\\", \\\"{x:1439,y:835,t:1527027452309};\\\", \\\"{x:1441,y:835,t:1527027452325};\\\", \\\"{x:1442,y:835,t:1527027452344};\\\", \\\"{x:1443,y:833,t:1527027452361};\\\", \\\"{x:1446,y:833,t:1527027452376};\\\", \\\"{x:1449,y:833,t:1527027452393};\\\", \\\"{x:1450,y:832,t:1527027452409};\\\", \\\"{x:1452,y:832,t:1527027452427};\\\", \\\"{x:1454,y:832,t:1527027452443};\\\", \\\"{x:1455,y:832,t:1527027452460};\\\", \\\"{x:1456,y:832,t:1527027452480};\\\", \\\"{x:1457,y:832,t:1527027452497};\\\", \\\"{x:1458,y:832,t:1527027452529};\\\", \\\"{x:1459,y:832,t:1527027452561};\\\", \\\"{x:1462,y:832,t:1527027452576};\\\", \\\"{x:1465,y:832,t:1527027452593};\\\", \\\"{x:1470,y:832,t:1527027452610};\\\", \\\"{x:1474,y:832,t:1527027452627};\\\", \\\"{x:1476,y:832,t:1527027452643};\\\", \\\"{x:1479,y:832,t:1527027452660};\\\", \\\"{x:1482,y:832,t:1527027452676};\\\", \\\"{x:1483,y:832,t:1527027452693};\\\", \\\"{x:1486,y:832,t:1527027452710};\\\", \\\"{x:1487,y:832,t:1527027452727};\\\", \\\"{x:1488,y:832,t:1527027452743};\\\", \\\"{x:1489,y:832,t:1527027452873};\\\", \\\"{x:1488,y:832,t:1527027452896};\\\", \\\"{x:1486,y:832,t:1527027452911};\\\", \\\"{x:1482,y:832,t:1527027452928};\\\", \\\"{x:1464,y:834,t:1527027452945};\\\", \\\"{x:1447,y:835,t:1527027452960};\\\", \\\"{x:1419,y:835,t:1527027452978};\\\", \\\"{x:1377,y:835,t:1527027452995};\\\", \\\"{x:1324,y:834,t:1527027453011};\\\", \\\"{x:1270,y:833,t:1527027453027};\\\", \\\"{x:1227,y:830,t:1527027453044};\\\", \\\"{x:1191,y:826,t:1527027453062};\\\", \\\"{x:1163,y:821,t:1527027453078};\\\", \\\"{x:1141,y:820,t:1527027453095};\\\", \\\"{x:1125,y:820,t:1527027453112};\\\", \\\"{x:1104,y:820,t:1527027453128};\\\", \\\"{x:1089,y:819,t:1527027453145};\\\", \\\"{x:1070,y:819,t:1527027453162};\\\", \\\"{x:1053,y:818,t:1527027453179};\\\", \\\"{x:1031,y:816,t:1527027453195};\\\", \\\"{x:1014,y:816,t:1527027453211};\\\", \\\"{x:993,y:816,t:1527027453229};\\\", \\\"{x:977,y:816,t:1527027453246};\\\", \\\"{x:963,y:816,t:1527027453262};\\\", \\\"{x:953,y:816,t:1527027453279};\\\", \\\"{x:945,y:816,t:1527027453297};\\\", \\\"{x:939,y:816,t:1527027453312};\\\", \\\"{x:931,y:816,t:1527027453329};\\\", \\\"{x:925,y:816,t:1527027453346};\\\", \\\"{x:923,y:816,t:1527027453363};\\\", \\\"{x:920,y:816,t:1527027453379};\\\", \\\"{x:924,y:816,t:1527027453465};\\\", \\\"{x:934,y:816,t:1527027453479};\\\", \\\"{x:962,y:815,t:1527027453496};\\\", \\\"{x:1010,y:815,t:1527027453513};\\\", \\\"{x:1043,y:815,t:1527027453529};\\\", \\\"{x:1064,y:816,t:1527027453546};\\\", \\\"{x:1077,y:819,t:1527027453563};\\\", \\\"{x:1082,y:820,t:1527027453580};\\\", \\\"{x:1086,y:820,t:1527027453595};\\\", \\\"{x:1089,y:820,t:1527027453612};\\\", \\\"{x:1095,y:820,t:1527027453629};\\\", \\\"{x:1104,y:821,t:1527027453646};\\\", \\\"{x:1120,y:824,t:1527027453662};\\\", \\\"{x:1142,y:826,t:1527027453679};\\\", \\\"{x:1176,y:832,t:1527027453695};\\\", \\\"{x:1199,y:835,t:1527027453712};\\\", \\\"{x:1215,y:837,t:1527027453729};\\\", \\\"{x:1224,y:838,t:1527027453746};\\\", \\\"{x:1229,y:840,t:1527027453764};\\\", \\\"{x:1231,y:840,t:1527027453780};\\\", \\\"{x:1236,y:840,t:1527027453796};\\\", \\\"{x:1241,y:840,t:1527027453814};\\\", \\\"{x:1243,y:840,t:1527027453829};\\\", \\\"{x:1248,y:840,t:1527027453846};\\\", \\\"{x:1251,y:839,t:1527027453863};\\\", \\\"{x:1255,y:838,t:1527027453880};\\\", \\\"{x:1258,y:838,t:1527027453896};\\\", \\\"{x:1261,y:838,t:1527027453914};\\\", \\\"{x:1266,y:836,t:1527027453931};\\\", \\\"{x:1271,y:836,t:1527027453947};\\\", \\\"{x:1273,y:835,t:1527027453964};\\\", \\\"{x:1275,y:833,t:1527027453980};\\\", \\\"{x:1276,y:833,t:1527027453997};\\\", \\\"{x:1280,y:832,t:1527027454014};\\\", \\\"{x:1286,y:832,t:1527027454031};\\\", \\\"{x:1296,y:832,t:1527027454047};\\\", \\\"{x:1304,y:832,t:1527027454064};\\\", \\\"{x:1317,y:832,t:1527027454080};\\\", \\\"{x:1324,y:832,t:1527027454098};\\\", \\\"{x:1325,y:832,t:1527027454114};\\\", \\\"{x:1318,y:832,t:1527027454169};\\\", \\\"{x:1308,y:832,t:1527027454181};\\\", \\\"{x:1268,y:832,t:1527027454198};\\\", \\\"{x:1186,y:826,t:1527027454215};\\\", \\\"{x:1070,y:812,t:1527027454231};\\\", \\\"{x:950,y:804,t:1527027454247};\\\", \\\"{x:796,y:800,t:1527027454264};\\\", \\\"{x:726,y:796,t:1527027454282};\\\", \\\"{x:686,y:790,t:1527027454297};\\\", \\\"{x:660,y:786,t:1527027454315};\\\", \\\"{x:635,y:783,t:1527027454332};\\\", \\\"{x:613,y:781,t:1527027454349};\\\", \\\"{x:599,y:779,t:1527027454365};\\\", \\\"{x:588,y:778,t:1527027454382};\\\", \\\"{x:575,y:776,t:1527027454399};\\\", \\\"{x:563,y:774,t:1527027454414};\\\", \\\"{x:546,y:769,t:1527027454431};\\\", \\\"{x:518,y:761,t:1527027454448};\\\", \\\"{x:505,y:757,t:1527027454466};\\\", \\\"{x:500,y:754,t:1527027454483};\\\", \\\"{x:500,y:753,t:1527027454498};\\\", \\\"{x:500,y:751,t:1527027454515};\\\", \\\"{x:500,y:749,t:1527027454523};\\\", \\\"{x:500,y:746,t:1527027454540};\\\", \\\"{x:500,y:739,t:1527027454556};\\\", \\\"{x:500,y:737,t:1527027454573};\\\", \\\"{x:500,y:735,t:1527027454590};\\\", \\\"{x:501,y:733,t:1527027454647};\\\", \\\"{x:502,y:732,t:1527027454656};\\\", \\\"{x:503,y:732,t:1527027454677};\\\", \\\"{x:504,y:732,t:1527027454692};\\\", \\\"{x:504,y:732,t:1527027454735};\\\", \\\"{x:505,y:732,t:1527027454823};\\\", \\\"{x:506,y:732,t:1527027454832};\\\", \\\"{x:508,y:732,t:1527027454843};\\\", \\\"{x:519,y:732,t:1527027454859};\\\", \\\"{x:537,y:734,t:1527027454876};\\\", \\\"{x:568,y:739,t:1527027454893};\\\", \\\"{x:616,y:746,t:1527027454909};\\\", \\\"{x:672,y:754,t:1527027454927};\\\", \\\"{x:738,y:759,t:1527027454944};\\\", \\\"{x:808,y:772,t:1527027454959};\\\", \\\"{x:931,y:784,t:1527027454976};\\\", \\\"{x:990,y:794,t:1527027454993};\\\", \\\"{x:1023,y:799,t:1527027455009};\\\", \\\"{x:1038,y:800,t:1527027455026};\\\", \\\"{x:1041,y:802,t:1527027455043};\\\" ] }, { \\\"rt\\\": 14105, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 308227, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"C30CF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -I -B -B -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1044,y:802,t:1527027457825};\\\", \\\"{x:1062,y:802,t:1527027457849};\\\", \\\"{x:1069,y:802,t:1527027457861};\\\", \\\"{x:1082,y:802,t:1527027457879};\\\", \\\"{x:1096,y:802,t:1527027457895};\\\", \\\"{x:1107,y:802,t:1527027457911};\\\", \\\"{x:1127,y:802,t:1527027457928};\\\", \\\"{x:1139,y:802,t:1527027457945};\\\", \\\"{x:1152,y:801,t:1527027457962};\\\", \\\"{x:1163,y:801,t:1527027457979};\\\", \\\"{x:1171,y:801,t:1527027457996};\\\", \\\"{x:1177,y:801,t:1527027458011};\\\", \\\"{x:1183,y:801,t:1527027458028};\\\", \\\"{x:1189,y:800,t:1527027458046};\\\", \\\"{x:1196,y:799,t:1527027458062};\\\", \\\"{x:1204,y:799,t:1527027458078};\\\", \\\"{x:1211,y:798,t:1527027458095};\\\", \\\"{x:1221,y:796,t:1527027458112};\\\", \\\"{x:1228,y:795,t:1527027458129};\\\", \\\"{x:1232,y:794,t:1527027458146};\\\", \\\"{x:1233,y:793,t:1527027458162};\\\", \\\"{x:1235,y:793,t:1527027458179};\\\", \\\"{x:1237,y:792,t:1527027458195};\\\", \\\"{x:1239,y:792,t:1527027458213};\\\", \\\"{x:1243,y:790,t:1527027458229};\\\", \\\"{x:1249,y:789,t:1527027458246};\\\", \\\"{x:1255,y:787,t:1527027458263};\\\", \\\"{x:1259,y:786,t:1527027458279};\\\", \\\"{x:1262,y:786,t:1527027458297};\\\", \\\"{x:1264,y:786,t:1527027458353};\\\", \\\"{x:1265,y:786,t:1527027458401};\\\", \\\"{x:1267,y:786,t:1527027458413};\\\", \\\"{x:1268,y:786,t:1527027458429};\\\", \\\"{x:1269,y:788,t:1527027458446};\\\", \\\"{x:1269,y:792,t:1527027458463};\\\", \\\"{x:1269,y:793,t:1527027458479};\\\", \\\"{x:1269,y:797,t:1527027458496};\\\", \\\"{x:1265,y:803,t:1527027458512};\\\", \\\"{x:1257,y:805,t:1527027458529};\\\", \\\"{x:1247,y:807,t:1527027458546};\\\", \\\"{x:1236,y:809,t:1527027458563};\\\", \\\"{x:1227,y:813,t:1527027458579};\\\", \\\"{x:1219,y:816,t:1527027458595};\\\", \\\"{x:1215,y:818,t:1527027458613};\\\", \\\"{x:1213,y:820,t:1527027458628};\\\", \\\"{x:1212,y:820,t:1527027458645};\\\", \\\"{x:1212,y:821,t:1527027458663};\\\", \\\"{x:1211,y:821,t:1527027458680};\\\", \\\"{x:1209,y:822,t:1527027458697};\\\", \\\"{x:1203,y:825,t:1527027458712};\\\", \\\"{x:1203,y:826,t:1527027458945};\\\", \\\"{x:1204,y:827,t:1527027459009};\\\", \\\"{x:1206,y:827,t:1527027459121};\\\", \\\"{x:1207,y:827,t:1527027460513};\\\", \\\"{x:1207,y:826,t:1527027460537};\\\", \\\"{x:1207,y:825,t:1527027460548};\\\", \\\"{x:1207,y:824,t:1527027460564};\\\", \\\"{x:1207,y:823,t:1527027460582};\\\", \\\"{x:1207,y:821,t:1527027460598};\\\", \\\"{x:1206,y:819,t:1527027460615};\\\", \\\"{x:1206,y:818,t:1527027460631};\\\", \\\"{x:1202,y:813,t:1527027460649};\\\", \\\"{x:1197,y:806,t:1527027460665};\\\", \\\"{x:1191,y:800,t:1527027460681};\\\", \\\"{x:1186,y:796,t:1527027460698};\\\", \\\"{x:1183,y:793,t:1527027460714};\\\", \\\"{x:1182,y:792,t:1527027460745};\\\", \\\"{x:1181,y:791,t:1527027460768};\\\", \\\"{x:1180,y:790,t:1527027460781};\\\", \\\"{x:1178,y:787,t:1527027460798};\\\", \\\"{x:1175,y:782,t:1527027460814};\\\", \\\"{x:1173,y:778,t:1527027460832};\\\", \\\"{x:1171,y:775,t:1527027460848};\\\", \\\"{x:1171,y:773,t:1527027460888};\\\", \\\"{x:1171,y:772,t:1527027460929};\\\", \\\"{x:1171,y:771,t:1527027460960};\\\", \\\"{x:1171,y:770,t:1527027460976};\\\", \\\"{x:1171,y:769,t:1527027460984};\\\", \\\"{x:1171,y:768,t:1527027461000};\\\", \\\"{x:1172,y:767,t:1527027461014};\\\", \\\"{x:1173,y:766,t:1527027461039};\\\", \\\"{x:1174,y:766,t:1527027461080};\\\", \\\"{x:1174,y:765,t:1527027461088};\\\", \\\"{x:1175,y:765,t:1527027461098};\\\", \\\"{x:1178,y:763,t:1527027461115};\\\", \\\"{x:1180,y:763,t:1527027462019};\\\", \\\"{x:1185,y:763,t:1527027462035};\\\", \\\"{x:1192,y:763,t:1527027462052};\\\", \\\"{x:1198,y:764,t:1527027462068};\\\", \\\"{x:1207,y:764,t:1527027462085};\\\", \\\"{x:1210,y:764,t:1527027462101};\\\", \\\"{x:1216,y:765,t:1527027462118};\\\", \\\"{x:1218,y:765,t:1527027462134};\\\", \\\"{x:1220,y:765,t:1527027462151};\\\", \\\"{x:1221,y:766,t:1527027462167};\\\", \\\"{x:1222,y:766,t:1527027462184};\\\", \\\"{x:1223,y:766,t:1527027462202};\\\", \\\"{x:1225,y:766,t:1527027462218};\\\", \\\"{x:1230,y:766,t:1527027462234};\\\", \\\"{x:1234,y:766,t:1527027462251};\\\", \\\"{x:1239,y:766,t:1527027462268};\\\", \\\"{x:1244,y:766,t:1527027462284};\\\", \\\"{x:1247,y:766,t:1527027462301};\\\", \\\"{x:1248,y:766,t:1527027462317};\\\", \\\"{x:1250,y:766,t:1527027462335};\\\", \\\"{x:1252,y:766,t:1527027462351};\\\", \\\"{x:1254,y:766,t:1527027462368};\\\", \\\"{x:1257,y:766,t:1527027462385};\\\", \\\"{x:1258,y:765,t:1527027462460};\\\", \\\"{x:1260,y:765,t:1527027462715};\\\", \\\"{x:1261,y:765,t:1527027462723};\\\", \\\"{x:1264,y:765,t:1527027462735};\\\", \\\"{x:1268,y:765,t:1527027462751};\\\", \\\"{x:1270,y:765,t:1527027462768};\\\", \\\"{x:1272,y:765,t:1527027462784};\\\", \\\"{x:1273,y:765,t:1527027462801};\\\", \\\"{x:1276,y:765,t:1527027462818};\\\", \\\"{x:1278,y:765,t:1527027462834};\\\", \\\"{x:1279,y:765,t:1527027462851};\\\", \\\"{x:1280,y:765,t:1527027462869};\\\", \\\"{x:1281,y:765,t:1527027462884};\\\", \\\"{x:1282,y:765,t:1527027462901};\\\", \\\"{x:1284,y:765,t:1527027462918};\\\", \\\"{x:1290,y:765,t:1527027462935};\\\", \\\"{x:1297,y:765,t:1527027462952};\\\", \\\"{x:1307,y:765,t:1527027462968};\\\", \\\"{x:1312,y:765,t:1527027462984};\\\", \\\"{x:1315,y:765,t:1527027463002};\\\", \\\"{x:1318,y:765,t:1527027463244};\\\", \\\"{x:1320,y:764,t:1527027463252};\\\", \\\"{x:1328,y:762,t:1527027463269};\\\", \\\"{x:1334,y:762,t:1527027463286};\\\", \\\"{x:1338,y:762,t:1527027463302};\\\", \\\"{x:1341,y:762,t:1527027463318};\\\", \\\"{x:1342,y:762,t:1527027463347};\\\", \\\"{x:1344,y:762,t:1527027463368};\\\", \\\"{x:1347,y:762,t:1527027463385};\\\", \\\"{x:1350,y:762,t:1527027463401};\\\", \\\"{x:1354,y:762,t:1527027463418};\\\", \\\"{x:1355,y:762,t:1527027463435};\\\", \\\"{x:1356,y:762,t:1527027463451};\\\", \\\"{x:1357,y:762,t:1527027463475};\\\", \\\"{x:1358,y:762,t:1527027463498};\\\", \\\"{x:1360,y:760,t:1527027463506};\\\", \\\"{x:1361,y:760,t:1527027463518};\\\", \\\"{x:1365,y:760,t:1527027463535};\\\", \\\"{x:1367,y:760,t:1527027463552};\\\", \\\"{x:1368,y:759,t:1527027463568};\\\", \\\"{x:1363,y:758,t:1527027465516};\\\", \\\"{x:1350,y:756,t:1527027465523};\\\", \\\"{x:1331,y:753,t:1527027465538};\\\", \\\"{x:1277,y:746,t:1527027465554};\\\", \\\"{x:1202,y:746,t:1527027465571};\\\", \\\"{x:1174,y:746,t:1527027465587};\\\", \\\"{x:1160,y:746,t:1527027465604};\\\", \\\"{x:1154,y:746,t:1527027465621};\\\", \\\"{x:1152,y:746,t:1527027465637};\\\", \\\"{x:1150,y:746,t:1527027465676};\\\", \\\"{x:1148,y:746,t:1527027465687};\\\", \\\"{x:1145,y:746,t:1527027465704};\\\", \\\"{x:1140,y:747,t:1527027465721};\\\", \\\"{x:1139,y:748,t:1527027465736};\\\", \\\"{x:1137,y:750,t:1527027465754};\\\", \\\"{x:1137,y:751,t:1527027465794};\\\", \\\"{x:1137,y:753,t:1527027465803};\\\", \\\"{x:1141,y:754,t:1527027465820};\\\", \\\"{x:1146,y:757,t:1527027465836};\\\", \\\"{x:1152,y:759,t:1527027465853};\\\", \\\"{x:1159,y:760,t:1527027465871};\\\", \\\"{x:1167,y:762,t:1527027465887};\\\", \\\"{x:1172,y:763,t:1527027465903};\\\", \\\"{x:1179,y:764,t:1527027465921};\\\", \\\"{x:1182,y:764,t:1527027465938};\\\", \\\"{x:1184,y:765,t:1527027465953};\\\", \\\"{x:1185,y:765,t:1527027465970};\\\", \\\"{x:1186,y:765,t:1527027466091};\\\", \\\"{x:1185,y:763,t:1527027466115};\\\", \\\"{x:1184,y:763,t:1527027466123};\\\", \\\"{x:1183,y:762,t:1527027466137};\\\", \\\"{x:1181,y:761,t:1527027467827};\\\", \\\"{x:1176,y:760,t:1527027467838};\\\", \\\"{x:1163,y:752,t:1527027467857};\\\", \\\"{x:1123,y:738,t:1527027467872};\\\", \\\"{x:1072,y:723,t:1527027467889};\\\", \\\"{x:1047,y:715,t:1527027467906};\\\", \\\"{x:1025,y:704,t:1527027467922};\\\", \\\"{x:998,y:687,t:1527027467938};\\\", \\\"{x:984,y:676,t:1527027467955};\\\", \\\"{x:968,y:662,t:1527027467972};\\\", \\\"{x:948,y:647,t:1527027467989};\\\", \\\"{x:912,y:628,t:1527027468007};\\\", \\\"{x:870,y:609,t:1527027468022};\\\", \\\"{x:837,y:595,t:1527027468039};\\\", \\\"{x:788,y:574,t:1527027468056};\\\", \\\"{x:735,y:551,t:1527027468073};\\\", \\\"{x:674,y:525,t:1527027468090};\\\", \\\"{x:598,y:493,t:1527027468106};\\\", \\\"{x:575,y:485,t:1527027468122};\\\", \\\"{x:566,y:482,t:1527027468139};\\\", \\\"{x:564,y:481,t:1527027468157};\\\", \\\"{x:564,y:483,t:1527027468282};\\\", \\\"{x:564,y:485,t:1527027468290};\\\", \\\"{x:564,y:492,t:1527027468306};\\\", \\\"{x:566,y:500,t:1527027468322};\\\", \\\"{x:568,y:505,t:1527027468339};\\\", \\\"{x:568,y:507,t:1527027468356};\\\", \\\"{x:568,y:508,t:1527027468372};\\\", \\\"{x:561,y:509,t:1527027468389};\\\", \\\"{x:542,y:509,t:1527027468406};\\\", \\\"{x:507,y:509,t:1527027468424};\\\", \\\"{x:454,y:509,t:1527027468441};\\\", \\\"{x:401,y:509,t:1527027468456};\\\", \\\"{x:371,y:509,t:1527027468474};\\\", \\\"{x:355,y:509,t:1527027468490};\\\", \\\"{x:347,y:509,t:1527027468506};\\\", \\\"{x:346,y:509,t:1527027468523};\\\", \\\"{x:344,y:511,t:1527027468539};\\\", \\\"{x:343,y:512,t:1527027468556};\\\", \\\"{x:342,y:512,t:1527027468573};\\\", \\\"{x:340,y:512,t:1527027468675};\\\", \\\"{x:335,y:512,t:1527027468690};\\\", \\\"{x:306,y:505,t:1527027468706};\\\", \\\"{x:274,y:497,t:1527027468723};\\\", \\\"{x:243,y:493,t:1527027468741};\\\", \\\"{x:217,y:491,t:1527027468756};\\\", \\\"{x:200,y:487,t:1527027468772};\\\", \\\"{x:188,y:486,t:1527027468790};\\\", \\\"{x:181,y:483,t:1527027468806};\\\", \\\"{x:178,y:483,t:1527027468824};\\\", \\\"{x:175,y:483,t:1527027468840};\\\", \\\"{x:172,y:483,t:1527027468856};\\\", \\\"{x:172,y:484,t:1527027468874};\\\", \\\"{x:171,y:485,t:1527027468939};\\\", \\\"{x:171,y:486,t:1527027468947};\\\", \\\"{x:170,y:486,t:1527027468956};\\\", \\\"{x:170,y:488,t:1527027468974};\\\", \\\"{x:170,y:489,t:1527027468990};\\\", \\\"{x:170,y:491,t:1527027469010};\\\", \\\"{x:169,y:492,t:1527027469026};\\\", \\\"{x:169,y:494,t:1527027469050};\\\", \\\"{x:168,y:495,t:1527027469058};\\\", \\\"{x:168,y:496,t:1527027469073};\\\", \\\"{x:165,y:498,t:1527027469091};\\\", \\\"{x:164,y:500,t:1527027469107};\\\", \\\"{x:164,y:501,t:1527027469410};\\\", \\\"{x:164,y:502,t:1527027469423};\\\", \\\"{x:171,y:506,t:1527027469440};\\\", \\\"{x:178,y:510,t:1527027469458};\\\", \\\"{x:192,y:519,t:1527027469474};\\\", \\\"{x:224,y:539,t:1527027469491};\\\", \\\"{x:257,y:556,t:1527027469508};\\\", \\\"{x:294,y:575,t:1527027469524};\\\", \\\"{x:342,y:597,t:1527027469541};\\\", \\\"{x:375,y:611,t:1527027469558};\\\", \\\"{x:402,y:623,t:1527027469573};\\\", \\\"{x:419,y:634,t:1527027469590};\\\", \\\"{x:433,y:643,t:1527027469608};\\\", \\\"{x:443,y:652,t:1527027469623};\\\", \\\"{x:449,y:658,t:1527027469641};\\\", \\\"{x:453,y:665,t:1527027469657};\\\", \\\"{x:458,y:670,t:1527027469674};\\\", \\\"{x:463,y:678,t:1527027469690};\\\", \\\"{x:466,y:684,t:1527027469708};\\\", \\\"{x:470,y:690,t:1527027469725};\\\", \\\"{x:472,y:693,t:1527027469741};\\\", \\\"{x:475,y:697,t:1527027469758};\\\", \\\"{x:475,y:699,t:1527027469775};\\\", \\\"{x:477,y:702,t:1527027469790};\\\", \\\"{x:478,y:705,t:1527027469807};\\\", \\\"{x:480,y:709,t:1527027469825};\\\", \\\"{x:481,y:711,t:1527027469841};\\\", \\\"{x:481,y:712,t:1527027469858};\\\", \\\"{x:482,y:714,t:1527027469875};\\\", \\\"{x:484,y:718,t:1527027469891};\\\", \\\"{x:484,y:719,t:1527027469907};\\\", \\\"{x:485,y:722,t:1527027469925};\\\", \\\"{x:487,y:724,t:1527027469940};\\\", \\\"{x:488,y:725,t:1527027469957};\\\", \\\"{x:489,y:726,t:1527027469975};\\\", \\\"{x:490,y:727,t:1527027469991};\\\", \\\"{x:491,y:727,t:1527027470411};\\\", \\\"{x:492,y:727,t:1527027471210};\\\", \\\"{x:494,y:725,t:1527027471225};\\\" ] }, { \\\"rt\\\": 37895, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 347338, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"C30CF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -Z -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:496,y:722,t:1527027471348};\\\", \\\"{x:496,y:721,t:1527027471801};\\\", \\\"{x:497,y:721,t:1527027472275};\\\", \\\"{x:500,y:721,t:1527027472283};\\\", \\\"{x:501,y:721,t:1527027472293};\\\", \\\"{x:507,y:720,t:1527027472310};\\\", \\\"{x:516,y:718,t:1527027472328};\\\", \\\"{x:530,y:716,t:1527027472343};\\\", \\\"{x:552,y:716,t:1527027472359};\\\", \\\"{x:584,y:715,t:1527027472376};\\\", \\\"{x:624,y:712,t:1527027472392};\\\", \\\"{x:681,y:711,t:1527027472409};\\\", \\\"{x:747,y:711,t:1527027472426};\\\", \\\"{x:862,y:709,t:1527027472442};\\\", \\\"{x:937,y:709,t:1527027472460};\\\", \\\"{x:1007,y:709,t:1527027472476};\\\", \\\"{x:1071,y:709,t:1527027472493};\\\", \\\"{x:1135,y:709,t:1527027472509};\\\", \\\"{x:1177,y:709,t:1527027472526};\\\", \\\"{x:1204,y:709,t:1527027472543};\\\", \\\"{x:1223,y:709,t:1527027472560};\\\", \\\"{x:1238,y:709,t:1527027472576};\\\", \\\"{x:1252,y:709,t:1527027472593};\\\", \\\"{x:1260,y:709,t:1527027472611};\\\", \\\"{x:1270,y:709,t:1527027472627};\\\", \\\"{x:1275,y:709,t:1527027472643};\\\", \\\"{x:1278,y:709,t:1527027472660};\\\", \\\"{x:1280,y:709,t:1527027472677};\\\", \\\"{x:1280,y:710,t:1527027473252};\\\", \\\"{x:1281,y:710,t:1527027473261};\\\", \\\"{x:1283,y:713,t:1527027473277};\\\", \\\"{x:1283,y:714,t:1527027473293};\\\", \\\"{x:1283,y:717,t:1527027473310};\\\", \\\"{x:1291,y:717,t:1527027473328};\\\", \\\"{x:1299,y:718,t:1527027473343};\\\", \\\"{x:1305,y:718,t:1527027473361};\\\", \\\"{x:1310,y:720,t:1527027473377};\\\", \\\"{x:1311,y:720,t:1527027473393};\\\", \\\"{x:1312,y:720,t:1527027473410};\\\", \\\"{x:1315,y:721,t:1527027473427};\\\", \\\"{x:1319,y:723,t:1527027473443};\\\", \\\"{x:1321,y:724,t:1527027473460};\\\", \\\"{x:1326,y:725,t:1527027473477};\\\", \\\"{x:1330,y:725,t:1527027473493};\\\", \\\"{x:1336,y:729,t:1527027473509};\\\", \\\"{x:1342,y:731,t:1527027473526};\\\", \\\"{x:1351,y:733,t:1527027473542};\\\", \\\"{x:1359,y:735,t:1527027473560};\\\", \\\"{x:1362,y:737,t:1527027473576};\\\", \\\"{x:1363,y:738,t:1527027473593};\\\", \\\"{x:1364,y:744,t:1527027473610};\\\", \\\"{x:1365,y:763,t:1527027473626};\\\", \\\"{x:1365,y:776,t:1527027473642};\\\", \\\"{x:1364,y:779,t:1527027473659};\\\", \\\"{x:1363,y:781,t:1527027473677};\\\", \\\"{x:1362,y:784,t:1527027473694};\\\", \\\"{x:1362,y:786,t:1527027473710};\\\", \\\"{x:1361,y:789,t:1527027473727};\\\", \\\"{x:1361,y:790,t:1527027473755};\\\", \\\"{x:1361,y:785,t:1527027473828};\\\", \\\"{x:1361,y:773,t:1527027473844};\\\", \\\"{x:1358,y:756,t:1527027473860};\\\", \\\"{x:1355,y:747,t:1527027473877};\\\", \\\"{x:1351,y:738,t:1527027473894};\\\", \\\"{x:1350,y:734,t:1527027473911};\\\", \\\"{x:1349,y:728,t:1527027473928};\\\", \\\"{x:1347,y:723,t:1527027473944};\\\", \\\"{x:1346,y:718,t:1527027473960};\\\", \\\"{x:1342,y:708,t:1527027473978};\\\", \\\"{x:1338,y:701,t:1527027473995};\\\", \\\"{x:1336,y:696,t:1527027474010};\\\", \\\"{x:1334,y:695,t:1527027474027};\\\", \\\"{x:1334,y:694,t:1527027474083};\\\", \\\"{x:1334,y:693,t:1527027474099};\\\", \\\"{x:1334,y:692,t:1527027474111};\\\", \\\"{x:1335,y:692,t:1527027474196};\\\", \\\"{x:1336,y:692,t:1527027474210};\\\", \\\"{x:1338,y:692,t:1527027474228};\\\", \\\"{x:1340,y:693,t:1527027474245};\\\", \\\"{x:1341,y:693,t:1527027474324};\\\", \\\"{x:1342,y:693,t:1527027474779};\\\", \\\"{x:1344,y:695,t:1527027474797};\\\", \\\"{x:1347,y:695,t:1527027474809};\\\", \\\"{x:1352,y:695,t:1527027474826};\\\", \\\"{x:1359,y:695,t:1527027474844};\\\", \\\"{x:1362,y:695,t:1527027474861};\\\", \\\"{x:1367,y:695,t:1527027474876};\\\", \\\"{x:1373,y:695,t:1527027474894};\\\", \\\"{x:1382,y:695,t:1527027474911};\\\", \\\"{x:1387,y:695,t:1527027474927};\\\", \\\"{x:1393,y:695,t:1527027474944};\\\", \\\"{x:1394,y:695,t:1527027474961};\\\", \\\"{x:1396,y:695,t:1527027474977};\\\", \\\"{x:1399,y:695,t:1527027474994};\\\", \\\"{x:1402,y:695,t:1527027475011};\\\", \\\"{x:1404,y:694,t:1527027475027};\\\", \\\"{x:1406,y:694,t:1527027475044};\\\", \\\"{x:1409,y:694,t:1527027475061};\\\", \\\"{x:1412,y:694,t:1527027475387};\\\", \\\"{x:1415,y:694,t:1527027475395};\\\", \\\"{x:1425,y:694,t:1527027475411};\\\", \\\"{x:1435,y:694,t:1527027475428};\\\", \\\"{x:1444,y:694,t:1527027475444};\\\", \\\"{x:1451,y:694,t:1527027475462};\\\", \\\"{x:1453,y:694,t:1527027475478};\\\", \\\"{x:1455,y:694,t:1527027475495};\\\", \\\"{x:1456,y:694,t:1527027475511};\\\", \\\"{x:1458,y:694,t:1527027475528};\\\", \\\"{x:1461,y:694,t:1527027475544};\\\", \\\"{x:1468,y:694,t:1527027475562};\\\", \\\"{x:1473,y:694,t:1527027475579};\\\", \\\"{x:1479,y:694,t:1527027475594};\\\", \\\"{x:1482,y:694,t:1527027475611};\\\", \\\"{x:1483,y:694,t:1527027475908};\\\", \\\"{x:1484,y:694,t:1527027475923};\\\", \\\"{x:1486,y:694,t:1527027475930};\\\", \\\"{x:1487,y:694,t:1527027475945};\\\", \\\"{x:1489,y:694,t:1527027475961};\\\", \\\"{x:1493,y:694,t:1527027475977};\\\", \\\"{x:1500,y:695,t:1527027475994};\\\", \\\"{x:1505,y:695,t:1527027476010};\\\", \\\"{x:1512,y:696,t:1527027476028};\\\", \\\"{x:1516,y:697,t:1527027476045};\\\", \\\"{x:1520,y:697,t:1527027476061};\\\", \\\"{x:1521,y:697,t:1527027476082};\\\", \\\"{x:1522,y:697,t:1527027476098};\\\", \\\"{x:1523,y:698,t:1527027476114};\\\", \\\"{x:1525,y:698,t:1527027476138};\\\", \\\"{x:1526,y:698,t:1527027476154};\\\", \\\"{x:1528,y:698,t:1527027476178};\\\", \\\"{x:1529,y:698,t:1527027476194};\\\", \\\"{x:1530,y:698,t:1527027476218};\\\", \\\"{x:1532,y:698,t:1527027476227};\\\", \\\"{x:1536,y:698,t:1527027476245};\\\", \\\"{x:1543,y:698,t:1527027476260};\\\", \\\"{x:1548,y:698,t:1527027476278};\\\", \\\"{x:1550,y:698,t:1527027476295};\\\", \\\"{x:1552,y:698,t:1527027476539};\\\", \\\"{x:1555,y:698,t:1527027476547};\\\", \\\"{x:1558,y:698,t:1527027476562};\\\", \\\"{x:1566,y:697,t:1527027476578};\\\", \\\"{x:1579,y:697,t:1527027476595};\\\", \\\"{x:1585,y:697,t:1527027476612};\\\", \\\"{x:1586,y:697,t:1527027476628};\\\", \\\"{x:1588,y:697,t:1527027476645};\\\", \\\"{x:1589,y:697,t:1527027476662};\\\", \\\"{x:1592,y:697,t:1527027476678};\\\", \\\"{x:1595,y:697,t:1527027476695};\\\", \\\"{x:1601,y:697,t:1527027476712};\\\", \\\"{x:1604,y:697,t:1527027476728};\\\", \\\"{x:1607,y:697,t:1527027476745};\\\", \\\"{x:1609,y:697,t:1527027477228};\\\", \\\"{x:1610,y:697,t:1527027477267};\\\", \\\"{x:1612,y:697,t:1527027482612};\\\", \\\"{x:1612,y:694,t:1527027491642};\\\", \\\"{x:1612,y:692,t:1527027491652};\\\", \\\"{x:1610,y:687,t:1527027491669};\\\", \\\"{x:1609,y:684,t:1527027491686};\\\", \\\"{x:1608,y:681,t:1527027491702};\\\", \\\"{x:1608,y:680,t:1527027491722};\\\", \\\"{x:1607,y:679,t:1527027491745};\\\", \\\"{x:1606,y:678,t:1527027491785};\\\", \\\"{x:1606,y:677,t:1527027491810};\\\", \\\"{x:1606,y:674,t:1527027491818};\\\", \\\"{x:1606,y:670,t:1527027491836};\\\", \\\"{x:1606,y:666,t:1527027491852};\\\", \\\"{x:1604,y:662,t:1527027491868};\\\", \\\"{x:1604,y:657,t:1527027491885};\\\", \\\"{x:1603,y:652,t:1527027491902};\\\", \\\"{x:1603,y:649,t:1527027491919};\\\", \\\"{x:1603,y:645,t:1527027491935};\\\", \\\"{x:1603,y:638,t:1527027491952};\\\", \\\"{x:1602,y:633,t:1527027491969};\\\", \\\"{x:1601,y:628,t:1527027491986};\\\", \\\"{x:1600,y:621,t:1527027492002};\\\", \\\"{x:1600,y:615,t:1527027492019};\\\", \\\"{x:1599,y:611,t:1527027492035};\\\", \\\"{x:1598,y:606,t:1527027492052};\\\", \\\"{x:1597,y:600,t:1527027492069};\\\", \\\"{x:1596,y:591,t:1527027492085};\\\", \\\"{x:1595,y:587,t:1527027492102};\\\", \\\"{x:1595,y:584,t:1527027492119};\\\", \\\"{x:1594,y:579,t:1527027492135};\\\", \\\"{x:1594,y:578,t:1527027492152};\\\", \\\"{x:1594,y:575,t:1527027492169};\\\", \\\"{x:1594,y:569,t:1527027492185};\\\", \\\"{x:1594,y:560,t:1527027492203};\\\", \\\"{x:1594,y:556,t:1527027492219};\\\", \\\"{x:1594,y:553,t:1527027492235};\\\", \\\"{x:1594,y:549,t:1527027492252};\\\", \\\"{x:1594,y:547,t:1527027492269};\\\", \\\"{x:1594,y:546,t:1527027492286};\\\", \\\"{x:1594,y:543,t:1527027492302};\\\", \\\"{x:1594,y:541,t:1527027492320};\\\", \\\"{x:1594,y:539,t:1527027492335};\\\", \\\"{x:1594,y:538,t:1527027492362};\\\", \\\"{x:1595,y:538,t:1527027492498};\\\", \\\"{x:1596,y:540,t:1527027492505};\\\", \\\"{x:1597,y:545,t:1527027492519};\\\", \\\"{x:1600,y:557,t:1527027492535};\\\", \\\"{x:1604,y:570,t:1527027492552};\\\", \\\"{x:1613,y:590,t:1527027492569};\\\", \\\"{x:1613,y:595,t:1527027492586};\\\", \\\"{x:1618,y:608,t:1527027492602};\\\", \\\"{x:1622,y:619,t:1527027492620};\\\", \\\"{x:1624,y:626,t:1527027492636};\\\", \\\"{x:1627,y:637,t:1527027492653};\\\", \\\"{x:1629,y:648,t:1527027492670};\\\", \\\"{x:1632,y:655,t:1527027492686};\\\", \\\"{x:1632,y:662,t:1527027492703};\\\", \\\"{x:1632,y:666,t:1527027492720};\\\", \\\"{x:1633,y:669,t:1527027492735};\\\", \\\"{x:1635,y:674,t:1527027492753};\\\", \\\"{x:1635,y:676,t:1527027492770};\\\", \\\"{x:1635,y:681,t:1527027492786};\\\", \\\"{x:1635,y:689,t:1527027492803};\\\", \\\"{x:1635,y:690,t:1527027492820};\\\", \\\"{x:1634,y:692,t:1527027492837};\\\", \\\"{x:1634,y:693,t:1527027492859};\\\", \\\"{x:1634,y:694,t:1527027492875};\\\", \\\"{x:1633,y:695,t:1527027492891};\\\", \\\"{x:1632,y:696,t:1527027492902};\\\", \\\"{x:1632,y:697,t:1527027492920};\\\", \\\"{x:1631,y:697,t:1527027492937};\\\", \\\"{x:1631,y:698,t:1527027492953};\\\", \\\"{x:1631,y:699,t:1527027492970};\\\", \\\"{x:1629,y:700,t:1527027492986};\\\", \\\"{x:1628,y:701,t:1527027493026};\\\", \\\"{x:1628,y:702,t:1527027493042};\\\", \\\"{x:1627,y:702,t:1527027493052};\\\", \\\"{x:1626,y:702,t:1527027493082};\\\", \\\"{x:1625,y:702,t:1527027493090};\\\", \\\"{x:1624,y:702,t:1527027493106};\\\", \\\"{x:1623,y:702,t:1527027493186};\\\", \\\"{x:1622,y:702,t:1527027493739};\\\", \\\"{x:1617,y:702,t:1527027494250};\\\", \\\"{x:1606,y:702,t:1527027494258};\\\", \\\"{x:1587,y:702,t:1527027494270};\\\", \\\"{x:1511,y:695,t:1527027494286};\\\", \\\"{x:1400,y:683,t:1527027494304};\\\", \\\"{x:1280,y:663,t:1527027494321};\\\", \\\"{x:1153,y:644,t:1527027494337};\\\", \\\"{x:1004,y:622,t:1527027494354};\\\", \\\"{x:938,y:614,t:1527027494371};\\\", \\\"{x:904,y:603,t:1527027494386};\\\", \\\"{x:881,y:597,t:1527027494404};\\\", \\\"{x:861,y:590,t:1527027494428};\\\", \\\"{x:848,y:586,t:1527027494444};\\\", \\\"{x:830,y:580,t:1527027494460};\\\", \\\"{x:803,y:574,t:1527027494477};\\\", \\\"{x:762,y:569,t:1527027494493};\\\", \\\"{x:717,y:562,t:1527027494511};\\\", \\\"{x:666,y:554,t:1527027494528};\\\", \\\"{x:619,y:548,t:1527027494544};\\\", \\\"{x:591,y:541,t:1527027494561};\\\", \\\"{x:557,y:535,t:1527027494577};\\\", \\\"{x:537,y:530,t:1527027494594};\\\", \\\"{x:516,y:525,t:1527027494610};\\\", \\\"{x:495,y:520,t:1527027494628};\\\", \\\"{x:476,y:518,t:1527027494643};\\\", \\\"{x:460,y:513,t:1527027494661};\\\", \\\"{x:451,y:509,t:1527027494678};\\\", \\\"{x:446,y:508,t:1527027494694};\\\", \\\"{x:444,y:507,t:1527027494714};\\\", \\\"{x:444,y:506,t:1527027494730};\\\", \\\"{x:444,y:505,t:1527027494753};\\\", \\\"{x:444,y:504,t:1527027494763};\\\", \\\"{x:445,y:502,t:1527027494778};\\\", \\\"{x:450,y:500,t:1527027494794};\\\", \\\"{x:455,y:499,t:1527027494810};\\\", \\\"{x:463,y:498,t:1527027494828};\\\", \\\"{x:471,y:498,t:1527027494845};\\\", \\\"{x:485,y:498,t:1527027494862};\\\", \\\"{x:500,y:498,t:1527027494880};\\\", \\\"{x:515,y:498,t:1527027494895};\\\", \\\"{x:529,y:498,t:1527027494911};\\\", \\\"{x:541,y:498,t:1527027494928};\\\", \\\"{x:548,y:498,t:1527027494943};\\\", \\\"{x:551,y:496,t:1527027494961};\\\", \\\"{x:553,y:496,t:1527027494978};\\\", \\\"{x:555,y:495,t:1527027494994};\\\", \\\"{x:559,y:495,t:1527027495011};\\\", \\\"{x:562,y:494,t:1527027495028};\\\", \\\"{x:568,y:494,t:1527027495044};\\\", \\\"{x:572,y:492,t:1527027495061};\\\", \\\"{x:575,y:492,t:1527027495078};\\\", \\\"{x:577,y:491,t:1527027495094};\\\", \\\"{x:579,y:490,t:1527027495111};\\\", \\\"{x:580,y:490,t:1527027495127};\\\", \\\"{x:585,y:489,t:1527027495144};\\\", \\\"{x:591,y:489,t:1527027495161};\\\", \\\"{x:599,y:489,t:1527027495178};\\\", \\\"{x:612,y:489,t:1527027495194};\\\", \\\"{x:619,y:489,t:1527027495211};\\\", \\\"{x:621,y:489,t:1527027495227};\\\", \\\"{x:621,y:491,t:1527027495291};\\\", \\\"{x:621,y:493,t:1527027495298};\\\", \\\"{x:616,y:496,t:1527027495312};\\\", \\\"{x:599,y:501,t:1527027495329};\\\", \\\"{x:578,y:506,t:1527027495344};\\\", \\\"{x:541,y:511,t:1527027495363};\\\", \\\"{x:512,y:515,t:1527027495377};\\\", \\\"{x:487,y:520,t:1527027495396};\\\", \\\"{x:467,y:523,t:1527027495412};\\\", \\\"{x:454,y:526,t:1527027495429};\\\", \\\"{x:447,y:527,t:1527027495445};\\\", \\\"{x:443,y:529,t:1527027495461};\\\", \\\"{x:438,y:531,t:1527027495478};\\\", \\\"{x:432,y:533,t:1527027495495};\\\", \\\"{x:422,y:534,t:1527027495512};\\\", \\\"{x:411,y:536,t:1527027495530};\\\", \\\"{x:396,y:536,t:1527027495544};\\\", \\\"{x:364,y:536,t:1527027495563};\\\", \\\"{x:348,y:536,t:1527027495578};\\\", \\\"{x:329,y:536,t:1527027495594};\\\", \\\"{x:315,y:536,t:1527027495611};\\\", \\\"{x:304,y:537,t:1527027495629};\\\", \\\"{x:294,y:538,t:1527027495645};\\\", \\\"{x:281,y:538,t:1527027495661};\\\", \\\"{x:265,y:538,t:1527027495680};\\\", \\\"{x:247,y:538,t:1527027495694};\\\", \\\"{x:226,y:539,t:1527027495712};\\\", \\\"{x:208,y:542,t:1527027495729};\\\", \\\"{x:191,y:545,t:1527027495745};\\\", \\\"{x:179,y:548,t:1527027495763};\\\", \\\"{x:177,y:550,t:1527027495779};\\\", \\\"{x:176,y:551,t:1527027495794};\\\", \\\"{x:174,y:553,t:1527027495812};\\\", \\\"{x:172,y:558,t:1527027495830};\\\", \\\"{x:170,y:562,t:1527027495845};\\\", \\\"{x:168,y:568,t:1527027495863};\\\", \\\"{x:166,y:572,t:1527027495879};\\\", \\\"{x:164,y:575,t:1527027495895};\\\", \\\"{x:164,y:579,t:1527027495912};\\\", \\\"{x:164,y:582,t:1527027495929};\\\", \\\"{x:164,y:587,t:1527027495946};\\\", \\\"{x:164,y:592,t:1527027495965};\\\", \\\"{x:165,y:594,t:1527027495979};\\\", \\\"{x:167,y:598,t:1527027495995};\\\", \\\"{x:168,y:602,t:1527027496012};\\\", \\\"{x:172,y:606,t:1527027496028};\\\", \\\"{x:176,y:611,t:1527027496046};\\\", \\\"{x:182,y:614,t:1527027496061};\\\", \\\"{x:195,y:617,t:1527027496079};\\\", \\\"{x:215,y:618,t:1527027496095};\\\", \\\"{x:243,y:618,t:1527027496111};\\\", \\\"{x:274,y:618,t:1527027496129};\\\", \\\"{x:316,y:620,t:1527027496146};\\\", \\\"{x:337,y:621,t:1527027496162};\\\", \\\"{x:350,y:621,t:1527027496178};\\\", \\\"{x:363,y:621,t:1527027496195};\\\", \\\"{x:374,y:619,t:1527027496212};\\\", \\\"{x:383,y:617,t:1527027496230};\\\", \\\"{x:392,y:613,t:1527027496245};\\\", \\\"{x:398,y:612,t:1527027496262};\\\", \\\"{x:405,y:610,t:1527027496279};\\\", \\\"{x:411,y:608,t:1527027496296};\\\", \\\"{x:421,y:603,t:1527027496312};\\\", \\\"{x:431,y:599,t:1527027496329};\\\", \\\"{x:439,y:595,t:1527027496345};\\\", \\\"{x:439,y:593,t:1527027496378};\\\", \\\"{x:439,y:592,t:1527027496409};\\\", \\\"{x:439,y:590,t:1527027496425};\\\", \\\"{x:439,y:589,t:1527027496442};\\\", \\\"{x:440,y:588,t:1527027496450};\\\", \\\"{x:440,y:587,t:1527027496461};\\\", \\\"{x:443,y:584,t:1527027496478};\\\", \\\"{x:449,y:582,t:1527027496496};\\\", \\\"{x:459,y:580,t:1527027496512};\\\", \\\"{x:474,y:580,t:1527027496528};\\\", \\\"{x:507,y:576,t:1527027496545};\\\", \\\"{x:531,y:576,t:1527027496562};\\\", \\\"{x:558,y:576,t:1527027496579};\\\", \\\"{x:580,y:576,t:1527027496596};\\\", \\\"{x:601,y:576,t:1527027496612};\\\", \\\"{x:617,y:576,t:1527027496629};\\\", \\\"{x:629,y:576,t:1527027496645};\\\", \\\"{x:639,y:576,t:1527027496663};\\\", \\\"{x:648,y:575,t:1527027496678};\\\", \\\"{x:656,y:572,t:1527027496695};\\\", \\\"{x:659,y:571,t:1527027496712};\\\", \\\"{x:665,y:569,t:1527027496728};\\\", \\\"{x:671,y:568,t:1527027496745};\\\", \\\"{x:679,y:564,t:1527027496762};\\\", \\\"{x:688,y:562,t:1527027496780};\\\", \\\"{x:703,y:558,t:1527027496796};\\\", \\\"{x:721,y:553,t:1527027496814};\\\", \\\"{x:733,y:550,t:1527027496830};\\\", \\\"{x:747,y:548,t:1527027496845};\\\", \\\"{x:755,y:543,t:1527027496863};\\\", \\\"{x:761,y:539,t:1527027496880};\\\", \\\"{x:766,y:535,t:1527027496895};\\\", \\\"{x:772,y:532,t:1527027496912};\\\", \\\"{x:780,y:526,t:1527027496930};\\\", \\\"{x:789,y:521,t:1527027496946};\\\", \\\"{x:800,y:515,t:1527027496963};\\\", \\\"{x:808,y:512,t:1527027496980};\\\", \\\"{x:815,y:509,t:1527027496996};\\\", \\\"{x:820,y:508,t:1527027497012};\\\", \\\"{x:823,y:506,t:1527027497029};\\\", \\\"{x:824,y:505,t:1527027497045};\\\", \\\"{x:827,y:503,t:1527027497063};\\\", \\\"{x:829,y:502,t:1527027497080};\\\", \\\"{x:831,y:501,t:1527027497097};\\\", \\\"{x:832,y:501,t:1527027497113};\\\", \\\"{x:833,y:501,t:1527027497258};\\\", \\\"{x:833,y:500,t:1527027497266};\\\", \\\"{x:834,y:500,t:1527027497296};\\\", \\\"{x:834,y:500,t:1527027497391};\\\", \\\"{x:835,y:500,t:1527027497522};\\\", \\\"{x:837,y:500,t:1527027497529};\\\", \\\"{x:848,y:505,t:1527027497547};\\\", \\\"{x:859,y:510,t:1527027497563};\\\", \\\"{x:881,y:519,t:1527027497580};\\\", \\\"{x:913,y:528,t:1527027497597};\\\", \\\"{x:969,y:543,t:1527027497614};\\\", \\\"{x:1023,y:556,t:1527027497630};\\\", \\\"{x:1100,y:574,t:1527027497647};\\\", \\\"{x:1174,y:588,t:1527027497664};\\\", \\\"{x:1242,y:604,t:1527027497680};\\\", \\\"{x:1310,y:616,t:1527027497697};\\\", \\\"{x:1372,y:629,t:1527027497714};\\\", \\\"{x:1408,y:637,t:1527027497730};\\\", \\\"{x:1436,y:641,t:1527027497747};\\\", \\\"{x:1462,y:646,t:1527027497764};\\\", \\\"{x:1489,y:650,t:1527027497779};\\\", \\\"{x:1515,y:657,t:1527027497797};\\\", \\\"{x:1540,y:663,t:1527027497814};\\\", \\\"{x:1559,y:666,t:1527027497830};\\\", \\\"{x:1575,y:668,t:1527027497848};\\\", \\\"{x:1584,y:670,t:1527027497864};\\\", \\\"{x:1587,y:670,t:1527027497880};\\\", \\\"{x:1588,y:670,t:1527027497897};\\\", \\\"{x:1589,y:670,t:1527027498283};\\\", \\\"{x:1589,y:669,t:1527027498483};\\\", \\\"{x:1587,y:668,t:1527027498498};\\\", \\\"{x:1586,y:667,t:1527027498514};\\\", \\\"{x:1584,y:666,t:1527027498531};\\\", \\\"{x:1583,y:664,t:1527027498548};\\\", \\\"{x:1581,y:662,t:1527027498565};\\\", \\\"{x:1580,y:660,t:1527027498582};\\\", \\\"{x:1578,y:659,t:1527027498598};\\\", \\\"{x:1577,y:657,t:1527027498614};\\\", \\\"{x:1575,y:656,t:1527027498632};\\\", \\\"{x:1574,y:655,t:1527027498649};\\\", \\\"{x:1571,y:653,t:1527027498665};\\\", \\\"{x:1569,y:652,t:1527027498681};\\\", \\\"{x:1568,y:650,t:1527027498699};\\\", \\\"{x:1567,y:650,t:1527027498715};\\\", \\\"{x:1566,y:649,t:1527027498731};\\\", \\\"{x:1566,y:648,t:1527027498748};\\\", \\\"{x:1565,y:647,t:1527027498765};\\\", \\\"{x:1565,y:646,t:1527027498781};\\\", \\\"{x:1564,y:646,t:1527027498798};\\\", \\\"{x:1564,y:645,t:1527027498815};\\\", \\\"{x:1563,y:645,t:1527027499884};\\\", \\\"{x:1562,y:645,t:1527027499900};\\\", \\\"{x:1561,y:646,t:1527027499923};\\\", \\\"{x:1561,y:647,t:1527027499933};\\\", \\\"{x:1560,y:648,t:1527027499955};\\\", \\\"{x:1559,y:648,t:1527027499979};\\\", \\\"{x:1559,y:650,t:1527027501827};\\\", \\\"{x:1558,y:652,t:1527027501835};\\\", \\\"{x:1557,y:654,t:1527027501850};\\\", \\\"{x:1553,y:657,t:1527027501867};\\\", \\\"{x:1552,y:657,t:1527027501884};\\\", \\\"{x:1549,y:659,t:1527027501900};\\\", \\\"{x:1548,y:659,t:1527027501917};\\\", \\\"{x:1546,y:659,t:1527027501938};\\\", \\\"{x:1545,y:660,t:1527027501950};\\\", \\\"{x:1542,y:660,t:1527027501967};\\\", \\\"{x:1535,y:661,t:1527027501984};\\\", \\\"{x:1528,y:662,t:1527027502000};\\\", \\\"{x:1523,y:662,t:1527027502017};\\\", \\\"{x:1521,y:662,t:1527027502033};\\\", \\\"{x:1521,y:663,t:1527027502187};\\\", \\\"{x:1521,y:664,t:1527027502210};\\\", \\\"{x:1521,y:665,t:1527027502218};\\\", \\\"{x:1521,y:666,t:1527027502251};\\\", \\\"{x:1522,y:667,t:1527027502267};\\\", \\\"{x:1522,y:669,t:1527027502284};\\\", \\\"{x:1524,y:671,t:1527027502301};\\\", \\\"{x:1526,y:672,t:1527027502317};\\\", \\\"{x:1529,y:674,t:1527027502334};\\\", \\\"{x:1531,y:675,t:1527027502351};\\\", \\\"{x:1533,y:675,t:1527027502368};\\\", \\\"{x:1536,y:675,t:1527027502384};\\\", \\\"{x:1539,y:675,t:1527027502402};\\\", \\\"{x:1545,y:675,t:1527027502417};\\\", \\\"{x:1562,y:675,t:1527027502434};\\\", \\\"{x:1574,y:675,t:1527027502452};\\\", \\\"{x:1584,y:675,t:1527027502467};\\\", \\\"{x:1590,y:675,t:1527027502484};\\\", \\\"{x:1592,y:675,t:1527027502502};\\\", \\\"{x:1594,y:675,t:1527027502522};\\\", \\\"{x:1595,y:675,t:1527027502538};\\\", \\\"{x:1596,y:677,t:1527027502811};\\\", \\\"{x:1597,y:678,t:1527027502819};\\\", \\\"{x:1597,y:679,t:1527027502834};\\\", \\\"{x:1598,y:681,t:1527027502851};\\\", \\\"{x:1599,y:681,t:1527027502964};\\\", \\\"{x:1599,y:682,t:1527027502978};\\\", \\\"{x:1599,y:683,t:1527027502986};\\\", \\\"{x:1600,y:683,t:1527027503002};\\\", \\\"{x:1600,y:684,t:1527027503019};\\\", \\\"{x:1601,y:684,t:1527027503036};\\\", \\\"{x:1602,y:684,t:1527027503107};\\\", \\\"{x:1604,y:685,t:1527027503122};\\\", \\\"{x:1604,y:686,t:1527027503135};\\\", \\\"{x:1604,y:687,t:1527027503152};\\\", \\\"{x:1604,y:688,t:1527027503170};\\\", \\\"{x:1599,y:688,t:1527027508411};\\\", \\\"{x:1594,y:687,t:1527027508423};\\\", \\\"{x:1574,y:684,t:1527027508440};\\\", \\\"{x:1547,y:684,t:1527027508458};\\\", \\\"{x:1507,y:684,t:1527027508473};\\\", \\\"{x:1449,y:684,t:1527027508490};\\\", \\\"{x:1340,y:684,t:1527027508506};\\\", \\\"{x:1268,y:684,t:1527027508523};\\\", \\\"{x:1185,y:684,t:1527027508540};\\\", \\\"{x:1085,y:684,t:1527027508557};\\\", \\\"{x:996,y:684,t:1527027508573};\\\", \\\"{x:918,y:684,t:1527027508590};\\\", \\\"{x:838,y:684,t:1527027508607};\\\", \\\"{x:743,y:684,t:1527027508623};\\\", \\\"{x:658,y:692,t:1527027508640};\\\", \\\"{x:569,y:705,t:1527027508657};\\\", \\\"{x:488,y:728,t:1527027508674};\\\", \\\"{x:431,y:751,t:1527027508690};\\\", \\\"{x:368,y:785,t:1527027508722};\\\", \\\"{x:365,y:788,t:1527027508739};\\\", \\\"{x:365,y:789,t:1527027508755};\\\", \\\"{x:365,y:790,t:1527027508772};\\\", \\\"{x:366,y:791,t:1527027508789};\\\", \\\"{x:367,y:792,t:1527027508805};\\\", \\\"{x:368,y:792,t:1527027508822};\\\", \\\"{x:370,y:793,t:1527027508840};\\\", \\\"{x:371,y:793,t:1527027508856};\\\", \\\"{x:373,y:793,t:1527027508882};\\\", \\\"{x:374,y:793,t:1527027508898};\\\", \\\"{x:376,y:792,t:1527027508906};\\\", \\\"{x:383,y:787,t:1527027508922};\\\", \\\"{x:396,y:782,t:1527027508939};\\\", \\\"{x:412,y:777,t:1527027508957};\\\", \\\"{x:424,y:772,t:1527027508972};\\\", \\\"{x:440,y:764,t:1527027508989};\\\", \\\"{x:451,y:759,t:1527027509007};\\\", \\\"{x:459,y:755,t:1527027509022};\\\", \\\"{x:466,y:750,t:1527027509040};\\\", \\\"{x:471,y:748,t:1527027509056};\\\", \\\"{x:476,y:745,t:1527027509072};\\\", \\\"{x:478,y:744,t:1527027509089};\\\", \\\"{x:479,y:744,t:1527027509106};\\\", \\\"{x:479,y:743,t:1527027509482};\\\", \\\"{x:480,y:743,t:1527027509490};\\\", \\\"{x:487,y:750,t:1527027509506};\\\", \\\"{x:493,y:756,t:1527027509523};\\\", \\\"{x:512,y:766,t:1527027509539};\\\", \\\"{x:532,y:773,t:1527027509556};\\\", \\\"{x:554,y:779,t:1527027509573};\\\", \\\"{x:588,y:786,t:1527027509589};\\\", \\\"{x:614,y:791,t:1527027509607};\\\", \\\"{x:640,y:798,t:1527027509624};\\\", \\\"{x:661,y:803,t:1527027509639};\\\", \\\"{x:677,y:808,t:1527027509656};\\\", \\\"{x:686,y:810,t:1527027509673};\\\", \\\"{x:690,y:812,t:1527027509690};\\\" ] }, { \\\"rt\\\": 9457, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 358089, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"C30CF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:692,y:811,t:1527027511755};\\\", \\\"{x:694,y:809,t:1527027511762};\\\", \\\"{x:697,y:805,t:1527027511775};\\\", \\\"{x:703,y:799,t:1527027511792};\\\", \\\"{x:708,y:795,t:1527027511809};\\\", \\\"{x:713,y:793,t:1527027511825};\\\", \\\"{x:717,y:790,t:1527027511841};\\\", \\\"{x:724,y:789,t:1527027511859};\\\", \\\"{x:730,y:787,t:1527027511875};\\\", \\\"{x:749,y:780,t:1527027511892};\\\", \\\"{x:779,y:774,t:1527027511909};\\\", \\\"{x:819,y:763,t:1527027511925};\\\", \\\"{x:864,y:748,t:1527027511942};\\\", \\\"{x:894,y:740,t:1527027511959};\\\", \\\"{x:924,y:730,t:1527027511974};\\\", \\\"{x:946,y:722,t:1527027511992};\\\", \\\"{x:962,y:718,t:1527027512009};\\\", \\\"{x:976,y:714,t:1527027512024};\\\", \\\"{x:993,y:709,t:1527027512042};\\\", \\\"{x:1013,y:705,t:1527027512058};\\\", \\\"{x:1023,y:702,t:1527027512075};\\\", \\\"{x:1036,y:701,t:1527027512092};\\\", \\\"{x:1046,y:701,t:1527027512109};\\\", \\\"{x:1054,y:701,t:1527027512126};\\\", \\\"{x:1058,y:698,t:1527027512142};\\\", \\\"{x:1061,y:688,t:1527027512160};\\\", \\\"{x:1067,y:686,t:1527027512483};\\\", \\\"{x:1078,y:687,t:1527027512492};\\\", \\\"{x:1088,y:692,t:1527027512509};\\\", \\\"{x:1089,y:694,t:1527027512526};\\\", \\\"{x:1100,y:695,t:1527027512543};\\\", \\\"{x:1107,y:695,t:1527027512559};\\\", \\\"{x:1119,y:692,t:1527027512576};\\\", \\\"{x:1132,y:690,t:1527027512593};\\\", \\\"{x:1148,y:689,t:1527027512609};\\\", \\\"{x:1178,y:689,t:1527027512627};\\\", \\\"{x:1202,y:689,t:1527027512642};\\\", \\\"{x:1226,y:689,t:1527027512659};\\\", \\\"{x:1252,y:689,t:1527027512676};\\\", \\\"{x:1273,y:689,t:1527027512693};\\\", \\\"{x:1291,y:689,t:1527027512708};\\\", \\\"{x:1306,y:688,t:1527027512726};\\\", \\\"{x:1324,y:688,t:1527027512742};\\\", \\\"{x:1339,y:688,t:1527027512758};\\\", \\\"{x:1350,y:688,t:1527027512775};\\\", \\\"{x:1364,y:688,t:1527027512792};\\\", \\\"{x:1375,y:688,t:1527027512808};\\\", \\\"{x:1387,y:688,t:1527027512826};\\\", \\\"{x:1392,y:685,t:1527027512842};\\\", \\\"{x:1395,y:684,t:1527027512859};\\\", \\\"{x:1397,y:684,t:1527027512876};\\\", \\\"{x:1398,y:684,t:1527027512892};\\\", \\\"{x:1399,y:684,t:1527027513025};\\\", \\\"{x:1397,y:690,t:1527027513042};\\\", \\\"{x:1396,y:696,t:1527027513059};\\\", \\\"{x:1393,y:708,t:1527027513075};\\\", \\\"{x:1389,y:721,t:1527027513093};\\\", \\\"{x:1387,y:732,t:1527027513110};\\\", \\\"{x:1386,y:750,t:1527027513126};\\\", \\\"{x:1381,y:767,t:1527027513142};\\\", \\\"{x:1375,y:790,t:1527027513159};\\\", \\\"{x:1369,y:807,t:1527027513175};\\\", \\\"{x:1361,y:824,t:1527027513192};\\\", \\\"{x:1353,y:846,t:1527027513209};\\\", \\\"{x:1349,y:859,t:1527027513225};\\\", \\\"{x:1344,y:869,t:1527027513243};\\\", \\\"{x:1340,y:881,t:1527027513260};\\\", \\\"{x:1339,y:894,t:1527027513275};\\\", \\\"{x:1334,y:910,t:1527027513292};\\\", \\\"{x:1331,y:924,t:1527027513310};\\\", \\\"{x:1331,y:936,t:1527027513326};\\\", \\\"{x:1332,y:942,t:1527027513342};\\\", \\\"{x:1332,y:947,t:1527027513359};\\\", \\\"{x:1336,y:954,t:1527027513376};\\\", \\\"{x:1338,y:956,t:1527027513392};\\\", \\\"{x:1341,y:959,t:1527027513409};\\\", \\\"{x:1342,y:960,t:1527027513427};\\\", \\\"{x:1344,y:960,t:1527027513442};\\\", \\\"{x:1344,y:961,t:1527027513465};\\\", \\\"{x:1345,y:961,t:1527027513753};\\\", \\\"{x:1345,y:958,t:1527027513761};\\\", \\\"{x:1344,y:953,t:1527027513776};\\\", \\\"{x:1343,y:945,t:1527027513793};\\\", \\\"{x:1343,y:941,t:1527027513810};\\\", \\\"{x:1343,y:936,t:1527027513827};\\\", \\\"{x:1343,y:930,t:1527027513843};\\\", \\\"{x:1341,y:922,t:1527027513860};\\\", \\\"{x:1338,y:916,t:1527027513876};\\\", \\\"{x:1337,y:908,t:1527027513893};\\\", \\\"{x:1335,y:900,t:1527027513910};\\\", \\\"{x:1334,y:894,t:1527027513927};\\\", \\\"{x:1332,y:887,t:1527027513944};\\\", \\\"{x:1330,y:880,t:1527027513959};\\\", \\\"{x:1330,y:872,t:1527027513976};\\\", \\\"{x:1329,y:868,t:1527027513993};\\\", \\\"{x:1329,y:863,t:1527027514009};\\\", \\\"{x:1329,y:856,t:1527027514026};\\\", \\\"{x:1329,y:848,t:1527027514043};\\\", \\\"{x:1329,y:839,t:1527027514059};\\\", \\\"{x:1332,y:830,t:1527027514076};\\\", \\\"{x:1337,y:821,t:1527027514093};\\\", \\\"{x:1343,y:811,t:1527027514109};\\\", \\\"{x:1345,y:805,t:1527027514126};\\\", \\\"{x:1348,y:799,t:1527027514143};\\\", \\\"{x:1352,y:790,t:1527027514159};\\\", \\\"{x:1355,y:783,t:1527027514176};\\\", \\\"{x:1359,y:776,t:1527027514194};\\\", \\\"{x:1360,y:773,t:1527027514209};\\\", \\\"{x:1362,y:769,t:1527027514227};\\\", \\\"{x:1362,y:767,t:1527027514243};\\\", \\\"{x:1363,y:762,t:1527027514259};\\\", \\\"{x:1363,y:760,t:1527027514277};\\\", \\\"{x:1363,y:759,t:1527027514294};\\\", \\\"{x:1363,y:757,t:1527027514337};\\\", \\\"{x:1363,y:756,t:1527027514369};\\\", \\\"{x:1362,y:755,t:1527027514386};\\\", \\\"{x:1360,y:755,t:1527027514401};\\\", \\\"{x:1359,y:755,t:1527027514411};\\\", \\\"{x:1354,y:753,t:1527027514426};\\\", \\\"{x:1348,y:753,t:1527027514444};\\\", \\\"{x:1344,y:754,t:1527027514461};\\\", \\\"{x:1340,y:756,t:1527027514477};\\\", \\\"{x:1339,y:756,t:1527027514513};\\\", \\\"{x:1338,y:755,t:1527027514690};\\\", \\\"{x:1338,y:754,t:1527027514697};\\\", \\\"{x:1338,y:752,t:1527027514713};\\\", \\\"{x:1338,y:750,t:1527027514727};\\\", \\\"{x:1338,y:748,t:1527027514744};\\\", \\\"{x:1338,y:744,t:1527027514760};\\\", \\\"{x:1338,y:739,t:1527027514777};\\\", \\\"{x:1338,y:735,t:1527027514793};\\\", \\\"{x:1337,y:732,t:1527027514811};\\\", \\\"{x:1337,y:726,t:1527027514827};\\\", \\\"{x:1337,y:723,t:1527027514843};\\\", \\\"{x:1337,y:717,t:1527027514860};\\\", \\\"{x:1337,y:713,t:1527027514877};\\\", \\\"{x:1337,y:707,t:1527027514894};\\\", \\\"{x:1337,y:704,t:1527027514911};\\\", \\\"{x:1338,y:702,t:1527027514928};\\\", \\\"{x:1338,y:700,t:1527027514943};\\\", \\\"{x:1338,y:699,t:1527027514960};\\\", \\\"{x:1338,y:696,t:1527027514978};\\\", \\\"{x:1338,y:694,t:1527027514994};\\\", \\\"{x:1338,y:693,t:1527027515010};\\\", \\\"{x:1338,y:692,t:1527027515074};\\\", \\\"{x:1339,y:690,t:1527027515097};\\\", \\\"{x:1340,y:690,t:1527027515110};\\\", \\\"{x:1336,y:690,t:1527027515401};\\\", \\\"{x:1329,y:690,t:1527027515410};\\\", \\\"{x:1306,y:690,t:1527027515427};\\\", \\\"{x:1264,y:690,t:1527027515444};\\\", \\\"{x:1200,y:690,t:1527027515460};\\\", \\\"{x:1125,y:688,t:1527027515478};\\\", \\\"{x:1032,y:682,t:1527027515494};\\\", \\\"{x:938,y:671,t:1527027515510};\\\", \\\"{x:855,y:660,t:1527027515528};\\\", \\\"{x:779,y:647,t:1527027515545};\\\", \\\"{x:694,y:634,t:1527027515561};\\\", \\\"{x:660,y:629,t:1527027515577};\\\", \\\"{x:630,y:621,t:1527027515595};\\\", \\\"{x:610,y:616,t:1527027515612};\\\", \\\"{x:591,y:613,t:1527027515626};\\\", \\\"{x:574,y:611,t:1527027515643};\\\", \\\"{x:560,y:608,t:1527027515661};\\\", \\\"{x:549,y:607,t:1527027515677};\\\", \\\"{x:543,y:604,t:1527027515694};\\\", \\\"{x:539,y:602,t:1527027515711};\\\", \\\"{x:536,y:599,t:1527027515728};\\\", \\\"{x:535,y:591,t:1527027515745};\\\", \\\"{x:534,y:584,t:1527027515761};\\\", \\\"{x:533,y:577,t:1527027515777};\\\", \\\"{x:532,y:571,t:1527027515794};\\\", \\\"{x:530,y:566,t:1527027515811};\\\", \\\"{x:530,y:562,t:1527027515828};\\\", \\\"{x:529,y:560,t:1527027515844};\\\", \\\"{x:528,y:554,t:1527027515862};\\\", \\\"{x:526,y:549,t:1527027515877};\\\", \\\"{x:525,y:547,t:1527027515895};\\\", \\\"{x:524,y:543,t:1527027515912};\\\", \\\"{x:524,y:541,t:1527027515929};\\\", \\\"{x:527,y:538,t:1527027515944};\\\", \\\"{x:552,y:534,t:1527027515961};\\\", \\\"{x:588,y:533,t:1527027515977};\\\", \\\"{x:638,y:533,t:1527027515995};\\\", \\\"{x:685,y:533,t:1527027516012};\\\", \\\"{x:741,y:533,t:1527027516030};\\\", \\\"{x:789,y:533,t:1527027516045};\\\", \\\"{x:816,y:533,t:1527027516062};\\\", \\\"{x:838,y:533,t:1527027516078};\\\", \\\"{x:847,y:533,t:1527027516095};\\\", \\\"{x:849,y:533,t:1527027516111};\\\", \\\"{x:851,y:531,t:1527027516154};\\\", \\\"{x:851,y:530,t:1527027516162};\\\", \\\"{x:851,y:527,t:1527027516179};\\\", \\\"{x:851,y:524,t:1527027516196};\\\", \\\"{x:851,y:522,t:1527027516211};\\\", \\\"{x:836,y:519,t:1527027516228};\\\", \\\"{x:805,y:519,t:1527027516245};\\\", \\\"{x:738,y:519,t:1527027516261};\\\", \\\"{x:652,y:532,t:1527027516279};\\\", \\\"{x:565,y:545,t:1527027516295};\\\", \\\"{x:496,y:554,t:1527027516312};\\\", \\\"{x:445,y:557,t:1527027516330};\\\", \\\"{x:394,y:557,t:1527027516345};\\\", \\\"{x:373,y:557,t:1527027516361};\\\", \\\"{x:358,y:557,t:1527027516378};\\\", \\\"{x:343,y:557,t:1527027516395};\\\", \\\"{x:329,y:557,t:1527027516411};\\\", \\\"{x:313,y:557,t:1527027516428};\\\", \\\"{x:293,y:555,t:1527027516446};\\\", \\\"{x:275,y:551,t:1527027516462};\\\", \\\"{x:254,y:545,t:1527027516479};\\\", \\\"{x:235,y:539,t:1527027516495};\\\", \\\"{x:219,y:536,t:1527027516511};\\\", \\\"{x:205,y:535,t:1527027516528};\\\", \\\"{x:190,y:535,t:1527027516545};\\\", \\\"{x:182,y:535,t:1527027516561};\\\", \\\"{x:174,y:534,t:1527027516579};\\\", \\\"{x:160,y:533,t:1527027516596};\\\", \\\"{x:147,y:530,t:1527027516612};\\\", \\\"{x:140,y:530,t:1527027516629};\\\", \\\"{x:136,y:530,t:1527027516646};\\\", \\\"{x:137,y:531,t:1527027516827};\\\", \\\"{x:138,y:531,t:1527027516834};\\\", \\\"{x:140,y:533,t:1527027516845};\\\", \\\"{x:141,y:535,t:1527027516863};\\\", \\\"{x:144,y:537,t:1527027516879};\\\", \\\"{x:146,y:538,t:1527027516896};\\\", \\\"{x:148,y:539,t:1527027516913};\\\", \\\"{x:149,y:540,t:1527027516930};\\\", \\\"{x:152,y:540,t:1527027517218};\\\", \\\"{x:153,y:540,t:1527027517229};\\\", \\\"{x:160,y:540,t:1527027517246};\\\", \\\"{x:168,y:539,t:1527027517262};\\\", \\\"{x:177,y:538,t:1527027517279};\\\", \\\"{x:194,y:538,t:1527027517295};\\\", \\\"{x:217,y:538,t:1527027517313};\\\", \\\"{x:259,y:538,t:1527027517330};\\\", \\\"{x:284,y:538,t:1527027517346};\\\", \\\"{x:313,y:538,t:1527027517362};\\\", \\\"{x:345,y:538,t:1527027517380};\\\", \\\"{x:381,y:538,t:1527027517396};\\\", \\\"{x:430,y:534,t:1527027517413};\\\", \\\"{x:491,y:527,t:1527027517430};\\\", \\\"{x:544,y:519,t:1527027517446};\\\", \\\"{x:608,y:513,t:1527027517463};\\\", \\\"{x:658,y:505,t:1527027517480};\\\", \\\"{x:695,y:500,t:1527027517496};\\\", \\\"{x:722,y:496,t:1527027517512};\\\", \\\"{x:758,y:491,t:1527027517530};\\\", \\\"{x:779,y:489,t:1527027517545};\\\", \\\"{x:796,y:484,t:1527027517563};\\\", \\\"{x:809,y:481,t:1527027517580};\\\", \\\"{x:815,y:480,t:1527027517595};\\\", \\\"{x:820,y:477,t:1527027517613};\\\", \\\"{x:822,y:477,t:1527027517630};\\\", \\\"{x:825,y:476,t:1527027517646};\\\", \\\"{x:826,y:476,t:1527027517663};\\\", \\\"{x:827,y:477,t:1527027517706};\\\", \\\"{x:828,y:481,t:1527027517714};\\\", \\\"{x:833,y:490,t:1527027517731};\\\", \\\"{x:835,y:495,t:1527027517746};\\\", \\\"{x:836,y:498,t:1527027517763};\\\", \\\"{x:836,y:499,t:1527027517779};\\\", \\\"{x:837,y:500,t:1527027517797};\\\", \\\"{x:837,y:501,t:1527027517812};\\\", \\\"{x:837,y:502,t:1527027517830};\\\", \\\"{x:837,y:503,t:1527027517847};\\\", \\\"{x:838,y:504,t:1527027517863};\\\", \\\"{x:839,y:505,t:1527027519249};\\\", \\\"{x:836,y:509,t:1527027519386};\\\", \\\"{x:830,y:514,t:1527027519398};\\\", \\\"{x:812,y:525,t:1527027519414};\\\", \\\"{x:792,y:535,t:1527027519431};\\\", \\\"{x:773,y:546,t:1527027519447};\\\", \\\"{x:752,y:558,t:1527027519464};\\\", \\\"{x:718,y:576,t:1527027519481};\\\", \\\"{x:679,y:599,t:1527027519498};\\\", \\\"{x:654,y:616,t:1527027519515};\\\", \\\"{x:628,y:633,t:1527027519530};\\\", \\\"{x:611,y:645,t:1527027519548};\\\", \\\"{x:600,y:656,t:1527027519565};\\\", \\\"{x:589,y:668,t:1527027519581};\\\", \\\"{x:582,y:680,t:1527027519597};\\\", \\\"{x:574,y:691,t:1527027519614};\\\", \\\"{x:567,y:700,t:1527027519631};\\\", \\\"{x:559,y:708,t:1527027519648};\\\", \\\"{x:553,y:712,t:1527027519663};\\\", \\\"{x:546,y:719,t:1527027519681};\\\", \\\"{x:530,y:729,t:1527027519698};\\\", \\\"{x:517,y:735,t:1527027519713};\\\", \\\"{x:509,y:738,t:1527027519730};\\\", \\\"{x:504,y:741,t:1527027519748};\\\", \\\"{x:504,y:742,t:1527027519769};\\\", \\\"{x:504,y:741,t:1527027520089};\\\", \\\"{x:504,y:739,t:1527027520105};\\\", \\\"{x:504,y:737,t:1527027520122};\\\", \\\"{x:504,y:735,t:1527027520138};\\\", \\\"{x:506,y:734,t:1527027520147};\\\", \\\"{x:509,y:733,t:1527027520164};\\\", \\\"{x:513,y:732,t:1527027520182};\\\", \\\"{x:519,y:730,t:1527027520198};\\\", \\\"{x:534,y:730,t:1527027520215};\\\", \\\"{x:555,y:730,t:1527027520232};\\\", \\\"{x:578,y:730,t:1527027520247};\\\", \\\"{x:606,y:730,t:1527027520265};\\\", \\\"{x:654,y:730,t:1527027520281};\\\", \\\"{x:683,y:730,t:1527027520298};\\\", \\\"{x:711,y:730,t:1527027520314};\\\", \\\"{x:732,y:730,t:1527027520332};\\\", \\\"{x:745,y:730,t:1527027520348};\\\", \\\"{x:747,y:730,t:1527027520365};\\\", \\\"{x:749,y:730,t:1527027520382};\\\", \\\"{x:750,y:730,t:1527027521073};\\\", \\\"{x:750,y:725,t:1527027521081};\\\", \\\"{x:748,y:707,t:1527027521099};\\\" ] }, { \\\"rt\\\": 9225, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 368532, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"C30CF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:744,y:674,t:1527027521206};\\\", \\\"{x:743,y:676,t:1527027521257};\\\", \\\"{x:743,y:677,t:1527027521265};\\\", \\\"{x:741,y:681,t:1527027521294};\\\", \\\"{x:740,y:683,t:1527027521298};\\\", \\\"{x:740,y:682,t:1527027521717};\\\", \\\"{x:740,y:680,t:1527027521740};\\\", \\\"{x:740,y:679,t:1527027521753};\\\", \\\"{x:741,y:678,t:1527027522926};\\\", \\\"{x:748,y:678,t:1527027522938};\\\", \\\"{x:766,y:679,t:1527027522953};\\\", \\\"{x:787,y:682,t:1527027522971};\\\", \\\"{x:809,y:686,t:1527027522987};\\\", \\\"{x:830,y:689,t:1527027523003};\\\", \\\"{x:841,y:691,t:1527027523020};\\\", \\\"{x:860,y:694,t:1527027523036};\\\", \\\"{x:874,y:695,t:1527027523053};\\\", \\\"{x:887,y:698,t:1527027523070};\\\", \\\"{x:905,y:700,t:1527027523087};\\\", \\\"{x:926,y:703,t:1527027523103};\\\", \\\"{x:949,y:705,t:1527027523120};\\\", \\\"{x:968,y:706,t:1527027523137};\\\", \\\"{x:977,y:706,t:1527027523153};\\\", \\\"{x:980,y:706,t:1527027523494};\\\", \\\"{x:985,y:704,t:1527027523505};\\\", \\\"{x:1004,y:704,t:1527027523521};\\\", \\\"{x:1022,y:704,t:1527027523538};\\\", \\\"{x:1044,y:705,t:1527027523555};\\\", \\\"{x:1070,y:705,t:1527027523571};\\\", \\\"{x:1096,y:707,t:1527027523588};\\\", \\\"{x:1127,y:712,t:1527027523605};\\\", \\\"{x:1154,y:716,t:1527027523621};\\\", \\\"{x:1198,y:722,t:1527027523638};\\\", \\\"{x:1227,y:722,t:1527027523655};\\\", \\\"{x:1255,y:722,t:1527027523672};\\\", \\\"{x:1281,y:722,t:1527027523687};\\\", \\\"{x:1307,y:722,t:1527027523705};\\\", \\\"{x:1331,y:722,t:1527027523721};\\\", \\\"{x:1352,y:722,t:1527027523738};\\\", \\\"{x:1370,y:721,t:1527027523754};\\\", \\\"{x:1383,y:717,t:1527027523772};\\\", \\\"{x:1390,y:714,t:1527027523788};\\\", \\\"{x:1393,y:711,t:1527027523805};\\\", \\\"{x:1395,y:704,t:1527027523821};\\\", \\\"{x:1395,y:702,t:1527027523838};\\\", \\\"{x:1395,y:701,t:1527027523855};\\\", \\\"{x:1395,y:699,t:1527027523872};\\\", \\\"{x:1395,y:697,t:1527027523894};\\\", \\\"{x:1393,y:697,t:1527027523904};\\\", \\\"{x:1385,y:695,t:1527027523922};\\\", \\\"{x:1373,y:694,t:1527027523938};\\\", \\\"{x:1362,y:694,t:1527027523955};\\\", \\\"{x:1352,y:694,t:1527027523974};\\\", \\\"{x:1349,y:694,t:1527027523987};\\\", \\\"{x:1348,y:694,t:1527027525318};\\\", \\\"{x:1348,y:695,t:1527027525349};\\\", \\\"{x:1348,y:696,t:1527027525357};\\\", \\\"{x:1348,y:697,t:1527027525382};\\\", \\\"{x:1348,y:698,t:1527027525414};\\\", \\\"{x:1348,y:699,t:1527027525461};\\\", \\\"{x:1348,y:700,t:1527027525477};\\\", \\\"{x:1348,y:701,t:1527027525489};\\\", \\\"{x:1348,y:702,t:1527027525505};\\\", \\\"{x:1348,y:706,t:1527027525524};\\\", \\\"{x:1349,y:710,t:1527027525539};\\\", \\\"{x:1350,y:714,t:1527027525556};\\\", \\\"{x:1350,y:717,t:1527027525573};\\\", \\\"{x:1351,y:723,t:1527027525590};\\\", \\\"{x:1351,y:727,t:1527027525606};\\\", \\\"{x:1352,y:731,t:1527027525623};\\\", \\\"{x:1353,y:735,t:1527027525639};\\\", \\\"{x:1354,y:739,t:1527027525656};\\\", \\\"{x:1354,y:743,t:1527027525673};\\\", \\\"{x:1354,y:747,t:1527027525690};\\\", \\\"{x:1355,y:749,t:1527027525706};\\\", \\\"{x:1355,y:752,t:1527027525723};\\\", \\\"{x:1355,y:754,t:1527027525740};\\\", \\\"{x:1355,y:756,t:1527027525756};\\\", \\\"{x:1355,y:758,t:1527027525773};\\\", \\\"{x:1355,y:759,t:1527027525790};\\\", \\\"{x:1355,y:761,t:1527027525807};\\\", \\\"{x:1355,y:762,t:1527027525822};\\\", \\\"{x:1355,y:765,t:1527027525840};\\\", \\\"{x:1354,y:765,t:1527027525856};\\\", \\\"{x:1353,y:760,t:1527027525950};\\\", \\\"{x:1352,y:753,t:1527027525958};\\\", \\\"{x:1352,y:747,t:1527027525973};\\\", \\\"{x:1351,y:728,t:1527027525990};\\\", \\\"{x:1351,y:718,t:1527027526006};\\\", \\\"{x:1351,y:713,t:1527027526023};\\\", \\\"{x:1351,y:710,t:1527027526039};\\\", \\\"{x:1351,y:707,t:1527027526055};\\\", \\\"{x:1351,y:704,t:1527027526072};\\\", \\\"{x:1351,y:703,t:1527027526089};\\\", \\\"{x:1351,y:701,t:1527027526106};\\\", \\\"{x:1351,y:699,t:1527027526123};\\\", \\\"{x:1351,y:698,t:1527027526139};\\\", \\\"{x:1351,y:697,t:1527027526181};\\\", \\\"{x:1350,y:696,t:1527027526197};\\\", \\\"{x:1350,y:695,t:1527027526213};\\\", \\\"{x:1346,y:695,t:1527027526974};\\\", \\\"{x:1331,y:695,t:1527027526991};\\\", \\\"{x:1301,y:689,t:1527027527008};\\\", \\\"{x:1251,y:678,t:1527027527024};\\\", \\\"{x:1167,y:661,t:1527027527040};\\\", \\\"{x:1061,y:641,t:1527027527057};\\\", \\\"{x:952,y:623,t:1527027527074};\\\", \\\"{x:851,y:605,t:1527027527092};\\\", \\\"{x:763,y:594,t:1527027527107};\\\", \\\"{x:696,y:584,t:1527027527124};\\\", \\\"{x:610,y:571,t:1527027527140};\\\", \\\"{x:562,y:564,t:1527027527157};\\\", \\\"{x:523,y:560,t:1527027527174};\\\", \\\"{x:497,y:555,t:1527027527191};\\\", \\\"{x:478,y:555,t:1527027527208};\\\", \\\"{x:459,y:552,t:1527027527223};\\\", \\\"{x:439,y:550,t:1527027527240};\\\", \\\"{x:421,y:549,t:1527027527258};\\\", \\\"{x:405,y:547,t:1527027527274};\\\", \\\"{x:388,y:544,t:1527027527290};\\\", \\\"{x:375,y:542,t:1527027527308};\\\", \\\"{x:365,y:541,t:1527027527323};\\\", \\\"{x:351,y:539,t:1527027527340};\\\", \\\"{x:318,y:533,t:1527027527357};\\\", \\\"{x:294,y:529,t:1527027527375};\\\", \\\"{x:271,y:524,t:1527027527391};\\\", \\\"{x:251,y:522,t:1527027527407};\\\", \\\"{x:229,y:519,t:1527027527423};\\\", \\\"{x:207,y:516,t:1527027527441};\\\", \\\"{x:192,y:514,t:1527027527457};\\\", \\\"{x:174,y:514,t:1527027527474};\\\", \\\"{x:162,y:514,t:1527027527491};\\\", \\\"{x:151,y:515,t:1527027527508};\\\", \\\"{x:147,y:516,t:1527027527525};\\\", \\\"{x:144,y:516,t:1527027527541};\\\", \\\"{x:141,y:517,t:1527027527558};\\\", \\\"{x:140,y:518,t:1527027527576};\\\", \\\"{x:140,y:521,t:1527027527591};\\\", \\\"{x:139,y:525,t:1527027527609};\\\", \\\"{x:139,y:527,t:1527027527624};\\\", \\\"{x:139,y:528,t:1527027527640};\\\", \\\"{x:139,y:531,t:1527027527657};\\\", \\\"{x:139,y:532,t:1527027527675};\\\", \\\"{x:139,y:535,t:1527027527691};\\\", \\\"{x:140,y:535,t:1527027527717};\\\", \\\"{x:141,y:535,t:1527027527726};\\\", \\\"{x:142,y:536,t:1527027527749};\\\", \\\"{x:143,y:536,t:1527027527766};\\\", \\\"{x:145,y:537,t:1527027527789};\\\", \\\"{x:146,y:537,t:1527027527862};\\\", \\\"{x:147,y:537,t:1527027527910};\\\", \\\"{x:148,y:538,t:1527027527925};\\\", \\\"{x:149,y:538,t:1527027527943};\\\", \\\"{x:150,y:538,t:1527027527957};\\\", \\\"{x:153,y:539,t:1527027527974};\\\", \\\"{x:154,y:540,t:1527027528269};\\\", \\\"{x:157,y:542,t:1527027528277};\\\", \\\"{x:158,y:542,t:1527027528291};\\\", \\\"{x:163,y:544,t:1527027528309};\\\", \\\"{x:172,y:547,t:1527027528325};\\\", \\\"{x:196,y:555,t:1527027528342};\\\", \\\"{x:226,y:561,t:1527027528359};\\\", \\\"{x:291,y:573,t:1527027528375};\\\", \\\"{x:364,y:586,t:1527027528391};\\\", \\\"{x:423,y:597,t:1527027528409};\\\", \\\"{x:489,y:611,t:1527027528425};\\\", \\\"{x:537,y:618,t:1527027528442};\\\", \\\"{x:582,y:624,t:1527027528458};\\\", \\\"{x:628,y:628,t:1527027528474};\\\", \\\"{x:670,y:634,t:1527027528493};\\\", \\\"{x:702,y:639,t:1527027528508};\\\", \\\"{x:735,y:643,t:1527027528525};\\\", \\\"{x:791,y:652,t:1527027528541};\\\", \\\"{x:836,y:659,t:1527027528559};\\\", \\\"{x:875,y:663,t:1527027528574};\\\", \\\"{x:906,y:668,t:1527027528591};\\\", \\\"{x:939,y:673,t:1527027528608};\\\", \\\"{x:971,y:679,t:1527027528624};\\\", \\\"{x:1000,y:683,t:1527027528642};\\\", \\\"{x:1025,y:690,t:1527027528659};\\\", \\\"{x:1051,y:692,t:1527027528676};\\\", \\\"{x:1072,y:696,t:1527027528692};\\\", \\\"{x:1093,y:701,t:1527027528709};\\\", \\\"{x:1122,y:704,t:1527027528725};\\\", \\\"{x:1140,y:708,t:1527027528742};\\\", \\\"{x:1156,y:712,t:1527027528759};\\\", \\\"{x:1170,y:714,t:1527027528777};\\\", \\\"{x:1187,y:717,t:1527027528792};\\\", \\\"{x:1201,y:718,t:1527027528809};\\\", \\\"{x:1210,y:719,t:1527027528825};\\\", \\\"{x:1217,y:721,t:1527027528842};\\\", \\\"{x:1221,y:721,t:1527027528858};\\\", \\\"{x:1224,y:722,t:1527027528876};\\\", \\\"{x:1232,y:723,t:1527027528891};\\\", \\\"{x:1243,y:724,t:1527027528908};\\\", \\\"{x:1268,y:728,t:1527027528925};\\\", \\\"{x:1285,y:730,t:1527027528942};\\\", \\\"{x:1299,y:732,t:1527027528960};\\\", \\\"{x:1309,y:736,t:1527027528977};\\\", \\\"{x:1318,y:738,t:1527027528992};\\\", \\\"{x:1323,y:738,t:1527027529009};\\\", \\\"{x:1324,y:740,t:1527027529027};\\\", \\\"{x:1325,y:740,t:1527027529041};\\\", \\\"{x:1326,y:741,t:1527027529058};\\\", \\\"{x:1329,y:743,t:1527027529076};\\\", \\\"{x:1332,y:745,t:1527027529092};\\\", \\\"{x:1336,y:748,t:1527027529108};\\\", \\\"{x:1338,y:748,t:1527027529125};\\\", \\\"{x:1338,y:749,t:1527027529143};\\\", \\\"{x:1339,y:750,t:1527027529159};\\\", \\\"{x:1340,y:752,t:1527027529181};\\\", \\\"{x:1340,y:753,t:1527027529192};\\\", \\\"{x:1342,y:756,t:1527027529209};\\\", \\\"{x:1343,y:758,t:1527027529226};\\\", \\\"{x:1344,y:760,t:1527027529243};\\\", \\\"{x:1344,y:762,t:1527027529259};\\\", \\\"{x:1345,y:762,t:1527027529276};\\\", \\\"{x:1345,y:763,t:1527027529414};\\\", \\\"{x:1334,y:764,t:1527027529823};\\\", \\\"{x:1317,y:765,t:1527027529829};\\\", \\\"{x:1288,y:770,t:1527027529843};\\\", \\\"{x:1213,y:779,t:1527027529861};\\\", \\\"{x:1135,y:781,t:1527027529876};\\\", \\\"{x:1021,y:781,t:1527027529893};\\\", \\\"{x:951,y:781,t:1527027529910};\\\", \\\"{x:879,y:781,t:1527027529925};\\\", \\\"{x:823,y:781,t:1527027529942};\\\", \\\"{x:784,y:781,t:1527027529960};\\\", \\\"{x:752,y:781,t:1527027529976};\\\", \\\"{x:717,y:782,t:1527027529992};\\\", \\\"{x:686,y:782,t:1527027530009};\\\", \\\"{x:660,y:782,t:1527027530026};\\\", \\\"{x:634,y:782,t:1527027530042};\\\", \\\"{x:610,y:782,t:1527027530059};\\\", \\\"{x:578,y:778,t:1527027530077};\\\", \\\"{x:564,y:775,t:1527027530094};\\\", \\\"{x:555,y:774,t:1527027530110};\\\", \\\"{x:542,y:769,t:1527027530127};\\\", \\\"{x:533,y:765,t:1527027530143};\\\", \\\"{x:527,y:760,t:1527027530160};\\\", \\\"{x:517,y:752,t:1527027530178};\\\", \\\"{x:512,y:748,t:1527027530192};\\\", \\\"{x:510,y:745,t:1527027530209};\\\", \\\"{x:510,y:743,t:1527027530226};\\\", \\\"{x:510,y:740,t:1527027530242};\\\", \\\"{x:510,y:738,t:1527027530341};\\\", \\\"{x:511,y:737,t:1527027530359};\\\", \\\"{x:511,y:737,t:1527027530451};\\\", \\\"{x:512,y:737,t:1527027530589};\\\", \\\"{x:514,y:737,t:1527027530597};\\\", \\\"{x:518,y:737,t:1527027530609};\\\", \\\"{x:530,y:737,t:1527027530626};\\\", \\\"{x:556,y:739,t:1527027530644};\\\", \\\"{x:602,y:746,t:1527027530659};\\\", \\\"{x:699,y:760,t:1527027530677};\\\", \\\"{x:774,y:771,t:1527027530694};\\\", \\\"{x:836,y:774,t:1527027530710};\\\", \\\"{x:891,y:779,t:1527027530727};\\\", \\\"{x:942,y:780,t:1527027530744};\\\", \\\"{x:968,y:780,t:1527027530760};\\\", \\\"{x:981,y:780,t:1527027530776};\\\", \\\"{x:984,y:780,t:1527027530794};\\\" ] }, { \\\"rt\\\": 43713, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 413486, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"C30CF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 5.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -Z -C -Z -H -O -O -B -B -O -F -B -O -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:985,y:781,t:1527027534421};\\\", \\\"{x:989,y:784,t:1527027534430};\\\", \\\"{x:1003,y:789,t:1527027534446};\\\", \\\"{x:1017,y:790,t:1527027534463};\\\", \\\"{x:1035,y:792,t:1527027534480};\\\", \\\"{x:1054,y:792,t:1527027534497};\\\", \\\"{x:1071,y:792,t:1527027534513};\\\", \\\"{x:1089,y:792,t:1527027534530};\\\", \\\"{x:1102,y:792,t:1527027534547};\\\", \\\"{x:1120,y:796,t:1527027534563};\\\", \\\"{x:1145,y:799,t:1527027534580};\\\", \\\"{x:1187,y:799,t:1527027534597};\\\", \\\"{x:1215,y:799,t:1527027534614};\\\", \\\"{x:1242,y:799,t:1527027534630};\\\", \\\"{x:1269,y:799,t:1527027534647};\\\", \\\"{x:1295,y:799,t:1527027534663};\\\", \\\"{x:1325,y:799,t:1527027534680};\\\", \\\"{x:1349,y:799,t:1527027534698};\\\", \\\"{x:1369,y:798,t:1527027534713};\\\", \\\"{x:1383,y:794,t:1527027534731};\\\", \\\"{x:1390,y:790,t:1527027534747};\\\", \\\"{x:1397,y:783,t:1527027534764};\\\", \\\"{x:1402,y:776,t:1527027534780};\\\", \\\"{x:1405,y:771,t:1527027534797};\\\", \\\"{x:1406,y:768,t:1527027534814};\\\", \\\"{x:1409,y:763,t:1527027534830};\\\", \\\"{x:1409,y:762,t:1527027534848};\\\", \\\"{x:1410,y:759,t:1527027534864};\\\", \\\"{x:1411,y:756,t:1527027534880};\\\", \\\"{x:1413,y:752,t:1527027534896};\\\", \\\"{x:1415,y:749,t:1527027534913};\\\", \\\"{x:1417,y:746,t:1527027534930};\\\", \\\"{x:1420,y:742,t:1527027534947};\\\", \\\"{x:1421,y:739,t:1527027534963};\\\", \\\"{x:1421,y:734,t:1527027534980};\\\", \\\"{x:1421,y:726,t:1527027534997};\\\", \\\"{x:1421,y:722,t:1527027535014};\\\", \\\"{x:1421,y:719,t:1527027535030};\\\", \\\"{x:1421,y:716,t:1527027535047};\\\", \\\"{x:1420,y:711,t:1527027535064};\\\", \\\"{x:1419,y:706,t:1527027535080};\\\", \\\"{x:1419,y:702,t:1527027535097};\\\", \\\"{x:1417,y:695,t:1527027535114};\\\", \\\"{x:1415,y:691,t:1527027535130};\\\", \\\"{x:1414,y:688,t:1527027535147};\\\", \\\"{x:1414,y:687,t:1527027535165};\\\", \\\"{x:1412,y:685,t:1527027535180};\\\", \\\"{x:1411,y:680,t:1527027535198};\\\", \\\"{x:1411,y:679,t:1527027535214};\\\", \\\"{x:1409,y:675,t:1527027535231};\\\", \\\"{x:1407,y:671,t:1527027535248};\\\", \\\"{x:1404,y:667,t:1527027535265};\\\", \\\"{x:1402,y:667,t:1527027535280};\\\", \\\"{x:1401,y:666,t:1527027535297};\\\", \\\"{x:1399,y:666,t:1527027535314};\\\", \\\"{x:1397,y:664,t:1527027535331};\\\", \\\"{x:1392,y:664,t:1527027535347};\\\", \\\"{x:1387,y:664,t:1527027535364};\\\", \\\"{x:1369,y:671,t:1527027535382};\\\", \\\"{x:1357,y:676,t:1527027535398};\\\", \\\"{x:1348,y:680,t:1527027535414};\\\", \\\"{x:1340,y:683,t:1527027535432};\\\", \\\"{x:1337,y:686,t:1527027535448};\\\", \\\"{x:1336,y:687,t:1527027535464};\\\", \\\"{x:1335,y:688,t:1527027535481};\\\", \\\"{x:1335,y:690,t:1527027535497};\\\", \\\"{x:1334,y:690,t:1527027535513};\\\", \\\"{x:1334,y:692,t:1527027535530};\\\", \\\"{x:1334,y:693,t:1527027535548};\\\", \\\"{x:1334,y:694,t:1527027535757};\\\", \\\"{x:1336,y:694,t:1527027535814};\\\", \\\"{x:1337,y:695,t:1527027535831};\\\", \\\"{x:1338,y:695,t:1527027535909};\\\", \\\"{x:1339,y:695,t:1527027535925};\\\", \\\"{x:1340,y:696,t:1527027537030};\\\", \\\"{x:1340,y:698,t:1527027538542};\\\", \\\"{x:1340,y:700,t:1527027538549};\\\", \\\"{x:1338,y:706,t:1527027538567};\\\", \\\"{x:1335,y:712,t:1527027538583};\\\", \\\"{x:1332,y:720,t:1527027538601};\\\", \\\"{x:1330,y:725,t:1527027538617};\\\", \\\"{x:1329,y:731,t:1527027538634};\\\", \\\"{x:1328,y:740,t:1527027538651};\\\", \\\"{x:1327,y:745,t:1527027538666};\\\", \\\"{x:1326,y:750,t:1527027538684};\\\", \\\"{x:1326,y:755,t:1527027538701};\\\", \\\"{x:1326,y:759,t:1527027538718};\\\", \\\"{x:1326,y:763,t:1527027538733};\\\", \\\"{x:1326,y:767,t:1527027538751};\\\", \\\"{x:1325,y:769,t:1527027538767};\\\", \\\"{x:1325,y:772,t:1527027538784};\\\", \\\"{x:1325,y:773,t:1527027538800};\\\", \\\"{x:1325,y:774,t:1527027538818};\\\", \\\"{x:1325,y:776,t:1527027538834};\\\", \\\"{x:1326,y:776,t:1527027538870};\\\", \\\"{x:1327,y:776,t:1527027538884};\\\", \\\"{x:1330,y:776,t:1527027538901};\\\", \\\"{x:1342,y:776,t:1527027538918};\\\", \\\"{x:1356,y:776,t:1527027538934};\\\", \\\"{x:1368,y:776,t:1527027538950};\\\", \\\"{x:1383,y:776,t:1527027538967};\\\", \\\"{x:1397,y:776,t:1527027538984};\\\", \\\"{x:1408,y:776,t:1527027539001};\\\", \\\"{x:1417,y:775,t:1527027539017};\\\", \\\"{x:1425,y:774,t:1527027539034};\\\", \\\"{x:1432,y:773,t:1527027539051};\\\", \\\"{x:1442,y:771,t:1527027539069};\\\", \\\"{x:1452,y:770,t:1527027539084};\\\", \\\"{x:1462,y:770,t:1527027539101};\\\", \\\"{x:1481,y:770,t:1527027539118};\\\", \\\"{x:1494,y:770,t:1527027539133};\\\", \\\"{x:1503,y:770,t:1527027539150};\\\", \\\"{x:1510,y:770,t:1527027539167};\\\", \\\"{x:1519,y:771,t:1527027539183};\\\", \\\"{x:1526,y:771,t:1527027539201};\\\", \\\"{x:1531,y:772,t:1527027539217};\\\", \\\"{x:1537,y:775,t:1527027539233};\\\", \\\"{x:1542,y:775,t:1527027539250};\\\", \\\"{x:1547,y:776,t:1527027539267};\\\", \\\"{x:1553,y:777,t:1527027539283};\\\", \\\"{x:1561,y:780,t:1527027539300};\\\", \\\"{x:1573,y:784,t:1527027539316};\\\", \\\"{x:1578,y:785,t:1527027539334};\\\", \\\"{x:1584,y:785,t:1527027539350};\\\", \\\"{x:1591,y:785,t:1527027539367};\\\", \\\"{x:1598,y:787,t:1527027539384};\\\", \\\"{x:1606,y:789,t:1527027539400};\\\", \\\"{x:1611,y:789,t:1527027539418};\\\", \\\"{x:1614,y:790,t:1527027539435};\\\", \\\"{x:1616,y:790,t:1527027539450};\\\", \\\"{x:1617,y:790,t:1527027539469};\\\", \\\"{x:1618,y:789,t:1527027539518};\\\", \\\"{x:1618,y:784,t:1527027539535};\\\", \\\"{x:1618,y:777,t:1527027539551};\\\", \\\"{x:1611,y:767,t:1527027539567};\\\", \\\"{x:1604,y:756,t:1527027539584};\\\", \\\"{x:1595,y:745,t:1527027539601};\\\", \\\"{x:1585,y:734,t:1527027539617};\\\", \\\"{x:1576,y:721,t:1527027539635};\\\", \\\"{x:1574,y:713,t:1527027539651};\\\", \\\"{x:1567,y:701,t:1527027539667};\\\", \\\"{x:1565,y:697,t:1527027539684};\\\", \\\"{x:1562,y:681,t:1527027539702};\\\", \\\"{x:1560,y:671,t:1527027539717};\\\", \\\"{x:1559,y:665,t:1527027539734};\\\", \\\"{x:1559,y:662,t:1527027539750};\\\", \\\"{x:1559,y:659,t:1527027539767};\\\", \\\"{x:1560,y:656,t:1527027539784};\\\", \\\"{x:1561,y:655,t:1527027539801};\\\", \\\"{x:1563,y:655,t:1527027539817};\\\", \\\"{x:1564,y:655,t:1527027539834};\\\", \\\"{x:1567,y:655,t:1527027539851};\\\", \\\"{x:1574,y:660,t:1527027539867};\\\", \\\"{x:1580,y:666,t:1527027539884};\\\", \\\"{x:1592,y:679,t:1527027539901};\\\", \\\"{x:1600,y:687,t:1527027539917};\\\", \\\"{x:1604,y:692,t:1527027539934};\\\", \\\"{x:1605,y:695,t:1527027539952};\\\", \\\"{x:1607,y:698,t:1527027539967};\\\", \\\"{x:1608,y:699,t:1527027539997};\\\", \\\"{x:1608,y:698,t:1527027540126};\\\", \\\"{x:1608,y:697,t:1527027540135};\\\", \\\"{x:1609,y:695,t:1527027540154};\\\", \\\"{x:1610,y:695,t:1527027540168};\\\", \\\"{x:1610,y:694,t:1527027540183};\\\", \\\"{x:1607,y:694,t:1527027541565};\\\", \\\"{x:1593,y:692,t:1527027541573};\\\", \\\"{x:1574,y:691,t:1527027541585};\\\", \\\"{x:1481,y:673,t:1527027541602};\\\", \\\"{x:1368,y:659,t:1527027541619};\\\", \\\"{x:1227,y:638,t:1527027541635};\\\", \\\"{x:1080,y:616,t:1527027541652};\\\", \\\"{x:887,y:589,t:1527027541670};\\\", \\\"{x:804,y:576,t:1527027541685};\\\", \\\"{x:769,y:571,t:1527027541701};\\\", \\\"{x:755,y:567,t:1527027541718};\\\", \\\"{x:753,y:566,t:1527027541736};\\\", \\\"{x:752,y:566,t:1527027541752};\\\", \\\"{x:751,y:565,t:1527027541769};\\\", \\\"{x:749,y:565,t:1527027541786};\\\", \\\"{x:748,y:565,t:1527027541869};\\\", \\\"{x:744,y:565,t:1527027541886};\\\", \\\"{x:738,y:559,t:1527027541903};\\\", \\\"{x:731,y:554,t:1527027541919};\\\", \\\"{x:722,y:550,t:1527027541936};\\\", \\\"{x:720,y:549,t:1527027541952};\\\", \\\"{x:719,y:547,t:1527027541972};\\\", \\\"{x:719,y:546,t:1527027541988};\\\", \\\"{x:723,y:543,t:1527027542002};\\\", \\\"{x:735,y:542,t:1527027542020};\\\", \\\"{x:757,y:541,t:1527027542036};\\\", \\\"{x:782,y:541,t:1527027542052};\\\", \\\"{x:827,y:541,t:1527027542069};\\\", \\\"{x:854,y:539,t:1527027542087};\\\", \\\"{x:867,y:536,t:1527027542102};\\\", \\\"{x:871,y:533,t:1527027542119};\\\", \\\"{x:872,y:531,t:1527027542136};\\\", \\\"{x:872,y:529,t:1527027542152};\\\", \\\"{x:871,y:524,t:1527027542170};\\\", \\\"{x:869,y:521,t:1527027542186};\\\", \\\"{x:867,y:519,t:1527027542203};\\\", \\\"{x:863,y:518,t:1527027542219};\\\", \\\"{x:860,y:516,t:1527027542237};\\\", \\\"{x:855,y:514,t:1527027542252};\\\", \\\"{x:851,y:514,t:1527027542268};\\\", \\\"{x:849,y:514,t:1527027542286};\\\", \\\"{x:846,y:512,t:1527027542303};\\\", \\\"{x:844,y:512,t:1527027542319};\\\", \\\"{x:839,y:512,t:1527027542336};\\\", \\\"{x:834,y:511,t:1527027542353};\\\", \\\"{x:832,y:510,t:1527027542369};\\\", \\\"{x:831,y:510,t:1527027542386};\\\", \\\"{x:829,y:509,t:1527027542403};\\\", \\\"{x:827,y:508,t:1527027542419};\\\", \\\"{x:825,y:507,t:1527027542436};\\\", \\\"{x:824,y:507,t:1527027542461};\\\", \\\"{x:824,y:506,t:1527027542533};\\\", \\\"{x:825,y:506,t:1527027542774};\\\", \\\"{x:829,y:506,t:1527027542788};\\\", \\\"{x:845,y:510,t:1527027542803};\\\", \\\"{x:867,y:518,t:1527027542821};\\\", \\\"{x:895,y:527,t:1527027542836};\\\", \\\"{x:963,y:546,t:1527027542853};\\\", \\\"{x:1017,y:559,t:1527027542870};\\\", \\\"{x:1075,y:574,t:1527027542886};\\\", \\\"{x:1137,y:593,t:1527027542903};\\\", \\\"{x:1182,y:600,t:1527027542920};\\\", \\\"{x:1230,y:614,t:1527027542936};\\\", \\\"{x:1270,y:622,t:1527027542954};\\\", \\\"{x:1302,y:632,t:1527027542971};\\\", \\\"{x:1334,y:642,t:1527027542986};\\\", \\\"{x:1365,y:650,t:1527027543003};\\\", \\\"{x:1390,y:656,t:1527027543020};\\\", \\\"{x:1415,y:660,t:1527027543037};\\\", \\\"{x:1451,y:666,t:1527027543053};\\\", \\\"{x:1469,y:667,t:1527027543071};\\\", \\\"{x:1477,y:669,t:1527027543087};\\\", \\\"{x:1483,y:670,t:1527027543104};\\\", \\\"{x:1488,y:670,t:1527027543120};\\\", \\\"{x:1492,y:671,t:1527027543136};\\\", \\\"{x:1496,y:673,t:1527027543154};\\\", \\\"{x:1501,y:673,t:1527027543171};\\\", \\\"{x:1502,y:673,t:1527027543310};\\\", \\\"{x:1503,y:673,t:1527027543320};\\\", \\\"{x:1506,y:673,t:1527027543337};\\\", \\\"{x:1507,y:673,t:1527027543374};\\\", \\\"{x:1509,y:673,t:1527027543470};\\\", \\\"{x:1512,y:674,t:1527027543486};\\\", \\\"{x:1514,y:674,t:1527027543503};\\\", \\\"{x:1515,y:674,t:1527027543566};\\\", \\\"{x:1512,y:674,t:1527027543573};\\\", \\\"{x:1493,y:671,t:1527027543587};\\\", \\\"{x:1391,y:649,t:1527027543604};\\\", \\\"{x:1227,y:620,t:1527027543621};\\\", \\\"{x:1048,y:596,t:1527027543637};\\\", \\\"{x:817,y:563,t:1527027543654};\\\", \\\"{x:733,y:550,t:1527027543670};\\\", \\\"{x:702,y:538,t:1527027543686};\\\", \\\"{x:692,y:532,t:1527027543702};\\\", \\\"{x:691,y:530,t:1527027543720};\\\", \\\"{x:691,y:528,t:1527027543737};\\\", \\\"{x:690,y:527,t:1527027543754};\\\", \\\"{x:690,y:526,t:1527027543770};\\\", \\\"{x:689,y:524,t:1527027543787};\\\", \\\"{x:689,y:523,t:1527027543804};\\\", \\\"{x:690,y:520,t:1527027543820};\\\", \\\"{x:703,y:519,t:1527027543837};\\\", \\\"{x:729,y:519,t:1527027543854};\\\", \\\"{x:772,y:519,t:1527027543871};\\\", \\\"{x:828,y:519,t:1527027543887};\\\", \\\"{x:878,y:519,t:1527027543904};\\\", \\\"{x:907,y:519,t:1527027543921};\\\", \\\"{x:919,y:517,t:1527027543938};\\\", \\\"{x:920,y:516,t:1527027543954};\\\", \\\"{x:920,y:514,t:1527027543988};\\\", \\\"{x:920,y:513,t:1527027544004};\\\", \\\"{x:914,y:504,t:1527027544020};\\\", \\\"{x:905,y:502,t:1527027544037};\\\", \\\"{x:890,y:498,t:1527027544054};\\\", \\\"{x:870,y:495,t:1527027544071};\\\", \\\"{x:850,y:494,t:1527027544088};\\\", \\\"{x:834,y:494,t:1527027544105};\\\", \\\"{x:816,y:493,t:1527027544121};\\\", \\\"{x:804,y:493,t:1527027544137};\\\", \\\"{x:800,y:493,t:1527027544154};\\\", \\\"{x:799,y:493,t:1527027544171};\\\", \\\"{x:800,y:493,t:1527027544309};\\\", \\\"{x:802,y:493,t:1527027544325};\\\", \\\"{x:804,y:494,t:1527027544341};\\\", \\\"{x:806,y:495,t:1527027544355};\\\", \\\"{x:808,y:496,t:1527027544372};\\\", \\\"{x:814,y:496,t:1527027544388};\\\", \\\"{x:816,y:497,t:1527027544405};\\\", \\\"{x:821,y:498,t:1527027544421};\\\", \\\"{x:825,y:499,t:1527027544438};\\\", \\\"{x:828,y:500,t:1527027544455};\\\", \\\"{x:831,y:500,t:1527027544471};\\\", \\\"{x:832,y:501,t:1527027544488};\\\", \\\"{x:833,y:501,t:1527027544669};\\\", \\\"{x:833,y:501,t:1527027544724};\\\", \\\"{x:834,y:501,t:1527027544925};\\\", \\\"{x:836,y:501,t:1527027544939};\\\", \\\"{x:841,y:501,t:1527027544956};\\\", \\\"{x:852,y:503,t:1527027544972};\\\", \\\"{x:870,y:505,t:1527027544989};\\\", \\\"{x:911,y:512,t:1527027545005};\\\", \\\"{x:956,y:520,t:1527027545022};\\\", \\\"{x:1012,y:529,t:1527027545038};\\\", \\\"{x:1074,y:537,t:1527027545056};\\\", \\\"{x:1142,y:552,t:1527027545071};\\\", \\\"{x:1206,y:560,t:1527027545088};\\\", \\\"{x:1257,y:569,t:1527027545105};\\\", \\\"{x:1298,y:579,t:1527027545122};\\\", \\\"{x:1331,y:587,t:1527027545139};\\\", \\\"{x:1358,y:595,t:1527027545155};\\\", \\\"{x:1383,y:602,t:1527027545171};\\\", \\\"{x:1405,y:608,t:1527027545189};\\\", \\\"{x:1432,y:618,t:1527027545205};\\\", \\\"{x:1451,y:628,t:1527027545222};\\\", \\\"{x:1462,y:635,t:1527027545240};\\\", \\\"{x:1472,y:640,t:1527027545255};\\\", \\\"{x:1478,y:643,t:1527027545271};\\\", \\\"{x:1487,y:647,t:1527027545288};\\\", \\\"{x:1499,y:651,t:1527027545306};\\\", \\\"{x:1507,y:653,t:1527027545322};\\\", \\\"{x:1514,y:655,t:1527027545338};\\\", \\\"{x:1525,y:660,t:1527027545355};\\\", \\\"{x:1535,y:664,t:1527027545372};\\\", \\\"{x:1546,y:670,t:1527027545389};\\\", \\\"{x:1566,y:676,t:1527027545405};\\\", \\\"{x:1575,y:677,t:1527027545422};\\\", \\\"{x:1580,y:677,t:1527027545439};\\\", \\\"{x:1583,y:679,t:1527027545456};\\\", \\\"{x:1584,y:679,t:1527027545472};\\\", \\\"{x:1585,y:680,t:1527027545606};\\\", \\\"{x:1590,y:683,t:1527027545623};\\\", \\\"{x:1598,y:685,t:1527027545639};\\\", \\\"{x:1601,y:687,t:1527027545656};\\\", \\\"{x:1603,y:688,t:1527027545673};\\\", \\\"{x:1605,y:688,t:1527027545689};\\\", \\\"{x:1606,y:689,t:1527027545706};\\\", \\\"{x:1607,y:691,t:1527027545723};\\\", \\\"{x:1608,y:692,t:1527027545739};\\\", \\\"{x:1609,y:692,t:1527027545766};\\\", \\\"{x:1610,y:692,t:1527027546958};\\\", \\\"{x:1610,y:690,t:1527027546973};\\\", \\\"{x:1609,y:684,t:1527027546990};\\\", \\\"{x:1608,y:681,t:1527027547007};\\\", \\\"{x:1607,y:677,t:1527027547023};\\\", \\\"{x:1606,y:675,t:1527027547040};\\\", \\\"{x:1603,y:670,t:1527027547057};\\\", \\\"{x:1601,y:664,t:1527027547073};\\\", \\\"{x:1599,y:661,t:1527027547090};\\\", \\\"{x:1592,y:653,t:1527027547107};\\\", \\\"{x:1588,y:648,t:1527027547123};\\\", \\\"{x:1587,y:648,t:1527027547140};\\\", \\\"{x:1585,y:647,t:1527027547207};\\\", \\\"{x:1584,y:646,t:1527027547223};\\\", \\\"{x:1584,y:645,t:1527027547240};\\\", \\\"{x:1584,y:644,t:1527027547257};\\\", \\\"{x:1583,y:642,t:1527027547273};\\\", \\\"{x:1582,y:641,t:1527027547290};\\\", \\\"{x:1581,y:639,t:1527027547307};\\\", \\\"{x:1578,y:634,t:1527027547323};\\\", \\\"{x:1577,y:632,t:1527027547340};\\\", \\\"{x:1576,y:629,t:1527027547356};\\\", \\\"{x:1574,y:627,t:1527027547374};\\\", \\\"{x:1574,y:625,t:1527027547390};\\\", \\\"{x:1574,y:624,t:1527027547414};\\\", \\\"{x:1574,y:625,t:1527027548245};\\\", \\\"{x:1574,y:628,t:1527027548257};\\\", \\\"{x:1575,y:636,t:1527027548274};\\\", \\\"{x:1576,y:641,t:1527027548290};\\\", \\\"{x:1576,y:645,t:1527027548307};\\\", \\\"{x:1577,y:649,t:1527027548325};\\\", \\\"{x:1578,y:658,t:1527027548341};\\\", \\\"{x:1578,y:662,t:1527027548358};\\\", \\\"{x:1578,y:665,t:1527027548374};\\\", \\\"{x:1578,y:670,t:1527027548391};\\\", \\\"{x:1578,y:674,t:1527027548407};\\\", \\\"{x:1578,y:678,t:1527027548424};\\\", \\\"{x:1578,y:682,t:1527027548441};\\\", \\\"{x:1579,y:688,t:1527027548457};\\\", \\\"{x:1580,y:691,t:1527027548474};\\\", \\\"{x:1581,y:694,t:1527027548491};\\\", \\\"{x:1582,y:696,t:1527027548507};\\\", \\\"{x:1583,y:698,t:1527027548524};\\\", \\\"{x:1586,y:704,t:1527027548541};\\\", \\\"{x:1588,y:710,t:1527027548557};\\\", \\\"{x:1590,y:713,t:1527027548574};\\\", \\\"{x:1591,y:717,t:1527027548591};\\\", \\\"{x:1592,y:721,t:1527027548607};\\\", \\\"{x:1594,y:726,t:1527027548624};\\\", \\\"{x:1595,y:733,t:1527027548641};\\\", \\\"{x:1595,y:738,t:1527027548657};\\\", \\\"{x:1596,y:742,t:1527027548674};\\\", \\\"{x:1596,y:745,t:1527027548691};\\\", \\\"{x:1596,y:747,t:1527027548707};\\\", \\\"{x:1596,y:748,t:1527027548724};\\\", \\\"{x:1596,y:752,t:1527027548741};\\\", \\\"{x:1596,y:754,t:1527027548758};\\\", \\\"{x:1595,y:756,t:1527027548774};\\\", \\\"{x:1590,y:759,t:1527027548791};\\\", \\\"{x:1584,y:762,t:1527027548808};\\\", \\\"{x:1575,y:766,t:1527027548824};\\\", \\\"{x:1569,y:766,t:1527027548842};\\\", \\\"{x:1560,y:766,t:1527027548858};\\\", \\\"{x:1551,y:768,t:1527027548874};\\\", \\\"{x:1545,y:768,t:1527027548891};\\\", \\\"{x:1538,y:768,t:1527027548908};\\\", \\\"{x:1528,y:770,t:1527027548924};\\\", \\\"{x:1515,y:770,t:1527027548941};\\\", \\\"{x:1510,y:770,t:1527027548958};\\\", \\\"{x:1507,y:770,t:1527027548974};\\\", \\\"{x:1505,y:770,t:1527027548991};\\\", \\\"{x:1504,y:770,t:1527027549102};\\\", \\\"{x:1504,y:769,t:1527027549142};\\\", \\\"{x:1504,y:767,t:1527027549158};\\\", \\\"{x:1504,y:765,t:1527027549174};\\\", \\\"{x:1504,y:764,t:1527027549192};\\\", \\\"{x:1505,y:763,t:1527027549237};\\\", \\\"{x:1505,y:762,t:1527027549286};\\\", \\\"{x:1507,y:762,t:1527027549509};\\\", \\\"{x:1514,y:762,t:1527027549525};\\\", \\\"{x:1520,y:762,t:1527027549541};\\\", \\\"{x:1528,y:762,t:1527027549559};\\\", \\\"{x:1531,y:762,t:1527027549575};\\\", \\\"{x:1532,y:762,t:1527027549591};\\\", \\\"{x:1529,y:762,t:1527027549742};\\\", \\\"{x:1520,y:762,t:1527027549758};\\\", \\\"{x:1502,y:762,t:1527027549776};\\\", \\\"{x:1482,y:762,t:1527027549791};\\\", \\\"{x:1460,y:762,t:1527027549808};\\\", \\\"{x:1440,y:762,t:1527027549825};\\\", \\\"{x:1425,y:762,t:1527027549840};\\\", \\\"{x:1418,y:762,t:1527027549857};\\\", \\\"{x:1412,y:762,t:1527027549874};\\\", \\\"{x:1406,y:762,t:1527027549890};\\\", \\\"{x:1401,y:762,t:1527027549908};\\\", \\\"{x:1391,y:763,t:1527027549924};\\\", \\\"{x:1382,y:763,t:1527027549940};\\\", \\\"{x:1376,y:763,t:1527027549958};\\\", \\\"{x:1371,y:763,t:1527027549974};\\\", \\\"{x:1366,y:763,t:1527027549991};\\\", \\\"{x:1362,y:763,t:1527027550007};\\\", \\\"{x:1361,y:763,t:1527027550024};\\\", \\\"{x:1360,y:763,t:1527027550045};\\\", \\\"{x:1359,y:763,t:1527027550058};\\\", \\\"{x:1358,y:763,t:1527027550074};\\\", \\\"{x:1355,y:763,t:1527027550092};\\\", \\\"{x:1350,y:763,t:1527027550108};\\\", \\\"{x:1344,y:763,t:1527027550125};\\\", \\\"{x:1345,y:763,t:1527027550309};\\\", \\\"{x:1352,y:763,t:1527027550325};\\\", \\\"{x:1359,y:763,t:1527027550341};\\\", \\\"{x:1364,y:763,t:1527027550357};\\\", \\\"{x:1371,y:762,t:1527027550374};\\\", \\\"{x:1372,y:762,t:1527027550392};\\\", \\\"{x:1374,y:762,t:1527027550408};\\\", \\\"{x:1375,y:762,t:1527027550425};\\\", \\\"{x:1378,y:762,t:1527027550442};\\\", \\\"{x:1384,y:762,t:1527027550458};\\\", \\\"{x:1393,y:762,t:1527027550475};\\\", \\\"{x:1401,y:762,t:1527027550492};\\\", \\\"{x:1406,y:762,t:1527027550508};\\\", \\\"{x:1411,y:762,t:1527027550525};\\\", \\\"{x:1413,y:762,t:1527027550590};\\\", \\\"{x:1415,y:762,t:1527027550598};\\\", \\\"{x:1416,y:763,t:1527027550608};\\\", \\\"{x:1421,y:763,t:1527027550626};\\\", \\\"{x:1423,y:763,t:1527027550643};\\\", \\\"{x:1425,y:763,t:1527027550658};\\\", \\\"{x:1426,y:763,t:1527027550982};\\\", \\\"{x:1427,y:763,t:1527027550997};\\\", \\\"{x:1429,y:763,t:1527027551010};\\\", \\\"{x:1432,y:763,t:1527027551025};\\\", \\\"{x:1433,y:763,t:1527027551053};\\\", \\\"{x:1434,y:763,t:1527027551077};\\\", \\\"{x:1435,y:763,t:1527027551092};\\\", \\\"{x:1440,y:763,t:1527027551109};\\\", \\\"{x:1447,y:763,t:1527027551125};\\\", \\\"{x:1452,y:763,t:1527027551142};\\\", \\\"{x:1456,y:763,t:1527027551160};\\\", \\\"{x:1457,y:763,t:1527027551175};\\\", \\\"{x:1458,y:763,t:1527027551213};\\\", \\\"{x:1459,y:763,t:1527027551225};\\\", \\\"{x:1460,y:763,t:1527027551243};\\\", \\\"{x:1461,y:763,t:1527027551259};\\\", \\\"{x:1460,y:763,t:1527027553654};\\\", \\\"{x:1459,y:763,t:1527027553678};\\\", \\\"{x:1458,y:763,t:1527027553717};\\\", \\\"{x:1456,y:763,t:1527027553734};\\\", \\\"{x:1455,y:763,t:1527027553743};\\\", \\\"{x:1453,y:763,t:1527027553760};\\\", \\\"{x:1451,y:763,t:1527027553777};\\\", \\\"{x:1448,y:763,t:1527027553794};\\\", \\\"{x:1445,y:763,t:1527027553811};\\\", \\\"{x:1441,y:763,t:1527027553827};\\\", \\\"{x:1439,y:763,t:1527027553844};\\\", \\\"{x:1438,y:763,t:1527027553860};\\\", \\\"{x:1436,y:763,t:1527027553877};\\\", \\\"{x:1435,y:763,t:1527027553901};\\\", \\\"{x:1433,y:763,t:1527027553917};\\\", \\\"{x:1432,y:763,t:1527027553927};\\\", \\\"{x:1429,y:763,t:1527027553943};\\\", \\\"{x:1427,y:763,t:1527027553960};\\\", \\\"{x:1425,y:763,t:1527027553977};\\\", \\\"{x:1423,y:762,t:1527027553994};\\\", \\\"{x:1420,y:762,t:1527027554011};\\\", \\\"{x:1418,y:761,t:1527027554028};\\\", \\\"{x:1416,y:761,t:1527027554043};\\\", \\\"{x:1412,y:761,t:1527027554061};\\\", \\\"{x:1406,y:761,t:1527027554077};\\\", \\\"{x:1404,y:761,t:1527027554093};\\\", \\\"{x:1399,y:761,t:1527027554110};\\\", \\\"{x:1393,y:761,t:1527027554128};\\\", \\\"{x:1385,y:759,t:1527027554143};\\\", \\\"{x:1377,y:759,t:1527027554160};\\\", \\\"{x:1369,y:758,t:1527027554176};\\\", \\\"{x:1364,y:758,t:1527027554194};\\\", \\\"{x:1360,y:758,t:1527027554210};\\\", \\\"{x:1359,y:758,t:1527027554226};\\\", \\\"{x:1358,y:758,t:1527027554260};\\\", \\\"{x:1357,y:758,t:1527027554276};\\\", \\\"{x:1354,y:758,t:1527027554294};\\\", \\\"{x:1353,y:758,t:1527027554317};\\\", \\\"{x:1352,y:758,t:1527027554326};\\\", \\\"{x:1351,y:758,t:1527027554413};\\\", \\\"{x:1350,y:759,t:1527027554429};\\\", \\\"{x:1348,y:759,t:1527027554444};\\\", \\\"{x:1346,y:759,t:1527027554460};\\\", \\\"{x:1344,y:761,t:1527027554477};\\\", \\\"{x:1343,y:761,t:1527027554533};\\\", \\\"{x:1345,y:761,t:1527027555165};\\\", \\\"{x:1348,y:761,t:1527027555177};\\\", \\\"{x:1354,y:761,t:1527027555195};\\\", \\\"{x:1359,y:761,t:1527027555211};\\\", \\\"{x:1361,y:761,t:1527027555227};\\\", \\\"{x:1363,y:761,t:1527027555244};\\\", \\\"{x:1365,y:761,t:1527027555261};\\\", \\\"{x:1368,y:761,t:1527027555278};\\\", \\\"{x:1372,y:761,t:1527027555294};\\\", \\\"{x:1377,y:760,t:1527027555311};\\\", \\\"{x:1379,y:760,t:1527027555329};\\\", \\\"{x:1383,y:760,t:1527027555344};\\\", \\\"{x:1386,y:760,t:1527027555361};\\\", \\\"{x:1391,y:760,t:1527027555378};\\\", \\\"{x:1396,y:760,t:1527027555394};\\\", \\\"{x:1399,y:760,t:1527027555411};\\\", \\\"{x:1403,y:760,t:1527027555429};\\\", \\\"{x:1406,y:759,t:1527027555444};\\\", \\\"{x:1408,y:759,t:1527027555494};\\\", \\\"{x:1409,y:759,t:1527027555517};\\\", \\\"{x:1411,y:759,t:1527027555533};\\\", \\\"{x:1412,y:759,t:1527027555544};\\\", \\\"{x:1414,y:759,t:1527027555561};\\\", \\\"{x:1416,y:759,t:1527027555578};\\\", \\\"{x:1418,y:759,t:1527027555595};\\\", \\\"{x:1420,y:759,t:1527027555613};\\\", \\\"{x:1420,y:758,t:1527027555645};\\\", \\\"{x:1421,y:758,t:1527027555662};\\\", \\\"{x:1425,y:758,t:1527027555679};\\\", \\\"{x:1428,y:758,t:1527027555694};\\\", \\\"{x:1429,y:758,t:1527027555711};\\\", \\\"{x:1430,y:758,t:1527027555902};\\\", \\\"{x:1429,y:758,t:1527027555917};\\\", \\\"{x:1428,y:758,t:1527027555929};\\\", \\\"{x:1426,y:758,t:1527027556006};\\\", \\\"{x:1425,y:758,t:1527027556022};\\\", \\\"{x:1423,y:759,t:1527027556038};\\\", \\\"{x:1421,y:759,t:1527027556045};\\\", \\\"{x:1416,y:759,t:1527027556061};\\\", \\\"{x:1411,y:759,t:1527027556078};\\\", \\\"{x:1407,y:760,t:1527027556096};\\\", \\\"{x:1404,y:760,t:1527027556111};\\\", \\\"{x:1402,y:760,t:1527027556128};\\\", \\\"{x:1401,y:760,t:1527027556149};\\\", \\\"{x:1400,y:760,t:1527027556190};\\\", \\\"{x:1399,y:760,t:1527027556198};\\\", \\\"{x:1398,y:761,t:1527027556212};\\\", \\\"{x:1395,y:762,t:1527027556229};\\\", \\\"{x:1396,y:764,t:1527027556420};\\\", \\\"{x:1397,y:764,t:1527027556444};\\\", \\\"{x:1398,y:764,t:1527027556460};\\\", \\\"{x:1400,y:764,t:1527027556478};\\\", \\\"{x:1402,y:764,t:1527027556495};\\\", \\\"{x:1405,y:764,t:1527027556511};\\\", \\\"{x:1412,y:764,t:1527027556528};\\\", \\\"{x:1419,y:764,t:1527027556545};\\\", \\\"{x:1424,y:764,t:1527027556561};\\\", \\\"{x:1426,y:764,t:1527027556578};\\\", \\\"{x:1427,y:764,t:1527027556594};\\\", \\\"{x:1428,y:764,t:1527027556725};\\\", \\\"{x:1427,y:762,t:1527027556740};\\\", \\\"{x:1426,y:762,t:1527027556749};\\\", \\\"{x:1424,y:762,t:1527027556773};\\\", \\\"{x:1423,y:762,t:1527027556789};\\\", \\\"{x:1423,y:761,t:1527027556797};\\\", \\\"{x:1421,y:761,t:1527027556950};\\\", \\\"{x:1420,y:761,t:1527027556963};\\\", \\\"{x:1417,y:761,t:1527027556979};\\\", \\\"{x:1415,y:761,t:1527027556996};\\\", \\\"{x:1411,y:761,t:1527027557012};\\\", \\\"{x:1410,y:761,t:1527027557029};\\\", \\\"{x:1410,y:762,t:1527027557045};\\\", \\\"{x:1408,y:762,t:1527027557063};\\\", \\\"{x:1407,y:763,t:1527027557126};\\\", \\\"{x:1408,y:764,t:1527027557206};\\\", \\\"{x:1409,y:764,t:1527027557221};\\\", \\\"{x:1411,y:764,t:1527027557237};\\\", \\\"{x:1413,y:764,t:1527027557253};\\\", \\\"{x:1416,y:764,t:1527027557262};\\\", \\\"{x:1421,y:764,t:1527027557279};\\\", \\\"{x:1428,y:764,t:1527027557295};\\\", \\\"{x:1432,y:764,t:1527027557312};\\\", \\\"{x:1435,y:764,t:1527027557329};\\\", \\\"{x:1437,y:764,t:1527027557345};\\\", \\\"{x:1439,y:764,t:1527027557362};\\\", \\\"{x:1442,y:763,t:1527027557379};\\\", \\\"{x:1444,y:763,t:1527027557395};\\\", \\\"{x:1445,y:763,t:1527027557413};\\\", \\\"{x:1448,y:762,t:1527027557430};\\\", \\\"{x:1449,y:762,t:1527027557454};\\\", \\\"{x:1450,y:761,t:1527027557462};\\\", \\\"{x:1451,y:761,t:1527027557479};\\\", \\\"{x:1454,y:761,t:1527027557495};\\\", \\\"{x:1455,y:761,t:1527027557511};\\\", \\\"{x:1458,y:761,t:1527027557529};\\\", \\\"{x:1461,y:761,t:1527027557545};\\\", \\\"{x:1462,y:761,t:1527027557562};\\\", \\\"{x:1464,y:761,t:1527027557578};\\\", \\\"{x:1466,y:761,t:1527027557595};\\\", \\\"{x:1470,y:761,t:1527027557612};\\\", \\\"{x:1472,y:761,t:1527027557629};\\\", \\\"{x:1472,y:760,t:1527027557661};\\\", \\\"{x:1473,y:760,t:1527027557719};\\\", \\\"{x:1474,y:760,t:1527027557981};\\\", \\\"{x:1477,y:760,t:1527027557996};\\\", \\\"{x:1484,y:760,t:1527027558013};\\\", \\\"{x:1492,y:760,t:1527027558029};\\\", \\\"{x:1495,y:760,t:1527027558046};\\\", \\\"{x:1499,y:760,t:1527027558062};\\\", \\\"{x:1501,y:760,t:1527027558079};\\\", \\\"{x:1503,y:760,t:1527027558096};\\\", \\\"{x:1506,y:760,t:1527027558112};\\\", \\\"{x:1508,y:760,t:1527027558129};\\\", \\\"{x:1512,y:760,t:1527027558146};\\\", \\\"{x:1515,y:760,t:1527027558161};\\\", \\\"{x:1519,y:760,t:1527027558178};\\\", \\\"{x:1523,y:760,t:1527027558196};\\\", \\\"{x:1524,y:760,t:1527027558212};\\\", \\\"{x:1528,y:760,t:1527027558229};\\\", \\\"{x:1530,y:760,t:1527027558246};\\\", \\\"{x:1534,y:760,t:1527027558262};\\\", \\\"{x:1538,y:760,t:1527027558279};\\\", \\\"{x:1542,y:760,t:1527027558296};\\\", \\\"{x:1544,y:760,t:1527027558312};\\\", \\\"{x:1535,y:760,t:1527027558662};\\\", \\\"{x:1524,y:760,t:1527027558669};\\\", \\\"{x:1506,y:760,t:1527027558679};\\\", \\\"{x:1443,y:754,t:1527027558696};\\\", \\\"{x:1361,y:747,t:1527027558713};\\\", \\\"{x:1266,y:743,t:1527027558729};\\\", \\\"{x:1177,y:732,t:1527027558746};\\\", \\\"{x:1106,y:718,t:1527027558763};\\\", \\\"{x:1064,y:711,t:1527027558779};\\\", \\\"{x:1025,y:701,t:1527027558796};\\\", \\\"{x:961,y:673,t:1527027558813};\\\", \\\"{x:915,y:658,t:1527027558829};\\\", \\\"{x:874,y:642,t:1527027558846};\\\", \\\"{x:824,y:619,t:1527027558864};\\\", \\\"{x:768,y:592,t:1527027558880};\\\", \\\"{x:620,y:515,t:1527027558914};\\\", \\\"{x:504,y:462,t:1527027558933};\\\", \\\"{x:465,y:450,t:1527027558949};\\\", \\\"{x:445,y:444,t:1527027558966};\\\", \\\"{x:432,y:441,t:1527027558983};\\\", \\\"{x:424,y:438,t:1527027559000};\\\", \\\"{x:416,y:437,t:1527027559016};\\\", \\\"{x:407,y:435,t:1527027559033};\\\", \\\"{x:393,y:435,t:1527027559050};\\\", \\\"{x:384,y:435,t:1527027559066};\\\", \\\"{x:382,y:436,t:1527027559083};\\\", \\\"{x:380,y:437,t:1527027559100};\\\", \\\"{x:380,y:438,t:1527027559116};\\\", \\\"{x:379,y:443,t:1527027559133};\\\", \\\"{x:378,y:448,t:1527027559150};\\\", \\\"{x:376,y:451,t:1527027559166};\\\", \\\"{x:376,y:453,t:1527027559183};\\\", \\\"{x:374,y:456,t:1527027559200};\\\", \\\"{x:370,y:459,t:1527027559216};\\\", \\\"{x:363,y:462,t:1527027559233};\\\", \\\"{x:357,y:465,t:1527027559250};\\\", \\\"{x:353,y:468,t:1527027559266};\\\", \\\"{x:346,y:472,t:1527027559284};\\\", \\\"{x:343,y:475,t:1527027559300};\\\", \\\"{x:340,y:476,t:1527027559316};\\\", \\\"{x:331,y:480,t:1527027559333};\\\", \\\"{x:319,y:484,t:1527027559351};\\\", \\\"{x:310,y:487,t:1527027559369};\\\", \\\"{x:304,y:489,t:1527027559383};\\\", \\\"{x:300,y:489,t:1527027559400};\\\", \\\"{x:296,y:491,t:1527027559417};\\\", \\\"{x:292,y:492,t:1527027559433};\\\", \\\"{x:282,y:493,t:1527027559450};\\\", \\\"{x:275,y:493,t:1527027559467};\\\", \\\"{x:267,y:496,t:1527027559483};\\\", \\\"{x:259,y:498,t:1527027559500};\\\", \\\"{x:251,y:500,t:1527027559516};\\\", \\\"{x:245,y:501,t:1527027559532};\\\", \\\"{x:233,y:504,t:1527027559550};\\\", \\\"{x:220,y:510,t:1527027559567};\\\", \\\"{x:212,y:512,t:1527027559583};\\\", \\\"{x:203,y:515,t:1527027559600};\\\", \\\"{x:198,y:519,t:1527027559618};\\\", \\\"{x:194,y:522,t:1527027559633};\\\", \\\"{x:191,y:524,t:1527027559650};\\\", \\\"{x:189,y:527,t:1527027559668};\\\", \\\"{x:188,y:530,t:1527027559683};\\\", \\\"{x:187,y:534,t:1527027559700};\\\", \\\"{x:184,y:537,t:1527027559716};\\\", \\\"{x:184,y:539,t:1527027559733};\\\", \\\"{x:183,y:540,t:1527027559750};\\\", \\\"{x:182,y:540,t:1527027559766};\\\", \\\"{x:181,y:540,t:1527027559812};\\\", \\\"{x:179,y:540,t:1527027559821};\\\", \\\"{x:176,y:540,t:1527027559834};\\\", \\\"{x:171,y:540,t:1527027559850};\\\", \\\"{x:165,y:540,t:1527027559868};\\\", \\\"{x:160,y:540,t:1527027559884};\\\", \\\"{x:157,y:540,t:1527027559900};\\\", \\\"{x:155,y:540,t:1527027559917};\\\", \\\"{x:154,y:540,t:1527027559934};\\\", \\\"{x:154,y:539,t:1527027559951};\\\", \\\"{x:152,y:539,t:1527027559967};\\\", \\\"{x:152,y:537,t:1527027560149};\\\", \\\"{x:152,y:537,t:1527027560193};\\\", \\\"{x:151,y:537,t:1527027560216};\\\", \\\"{x:150,y:537,t:1527027560252};\\\", \\\"{x:152,y:537,t:1527027560300};\\\", \\\"{x:161,y:537,t:1527027560317};\\\", \\\"{x:174,y:539,t:1527027560334};\\\", \\\"{x:192,y:543,t:1527027560352};\\\", \\\"{x:216,y:549,t:1527027560366};\\\", \\\"{x:239,y:555,t:1527027560384};\\\", \\\"{x:267,y:563,t:1527027560403};\\\", \\\"{x:296,y:571,t:1527027560418};\\\", \\\"{x:321,y:576,t:1527027560434};\\\", \\\"{x:347,y:578,t:1527027560451};\\\", \\\"{x:373,y:583,t:1527027560467};\\\", \\\"{x:401,y:588,t:1527027560484};\\\", \\\"{x:452,y:595,t:1527027560501};\\\", \\\"{x:500,y:602,t:1527027560517};\\\", \\\"{x:556,y:608,t:1527027560533};\\\", \\\"{x:615,y:618,t:1527027560551};\\\", \\\"{x:673,y:626,t:1527027560568};\\\", \\\"{x:732,y:635,t:1527027560584};\\\", \\\"{x:790,y:643,t:1527027560601};\\\", \\\"{x:846,y:650,t:1527027560617};\\\", \\\"{x:905,y:653,t:1527027560634};\\\", \\\"{x:967,y:663,t:1527027560651};\\\", \\\"{x:1019,y:667,t:1527027560668};\\\", \\\"{x:1072,y:673,t:1527027560684};\\\", \\\"{x:1137,y:681,t:1527027560700};\\\", \\\"{x:1176,y:685,t:1527027560718};\\\", \\\"{x:1210,y:691,t:1527027560733};\\\", \\\"{x:1238,y:694,t:1527027560751};\\\", \\\"{x:1268,y:696,t:1527027560769};\\\", \\\"{x:1295,y:696,t:1527027560784};\\\", \\\"{x:1324,y:696,t:1527027560801};\\\", \\\"{x:1346,y:699,t:1527027560819};\\\", \\\"{x:1366,y:699,t:1527027560835};\\\", \\\"{x:1383,y:700,t:1527027560852};\\\", \\\"{x:1403,y:700,t:1527027560869};\\\", \\\"{x:1412,y:700,t:1527027560884};\\\", \\\"{x:1427,y:700,t:1527027560901};\\\", \\\"{x:1437,y:700,t:1527027560919};\\\", \\\"{x:1449,y:700,t:1527027560934};\\\", \\\"{x:1459,y:700,t:1527027560952};\\\", \\\"{x:1467,y:700,t:1527027560968};\\\", \\\"{x:1474,y:700,t:1527027560984};\\\", \\\"{x:1480,y:700,t:1527027561002};\\\", \\\"{x:1485,y:700,t:1527027561019};\\\", \\\"{x:1491,y:700,t:1527027561035};\\\", \\\"{x:1500,y:700,t:1527027561051};\\\", \\\"{x:1518,y:697,t:1527027561069};\\\", \\\"{x:1525,y:696,t:1527027561084};\\\", \\\"{x:1530,y:694,t:1527027561101};\\\", \\\"{x:1532,y:693,t:1527027561119};\\\", \\\"{x:1532,y:690,t:1527027561134};\\\", \\\"{x:1532,y:685,t:1527027561152};\\\", \\\"{x:1531,y:681,t:1527027561169};\\\", \\\"{x:1530,y:678,t:1527027561185};\\\", \\\"{x:1528,y:676,t:1527027561201};\\\", \\\"{x:1523,y:673,t:1527027561219};\\\", \\\"{x:1520,y:671,t:1527027561235};\\\", \\\"{x:1515,y:668,t:1527027561252};\\\", \\\"{x:1506,y:663,t:1527027561269};\\\", \\\"{x:1503,y:661,t:1527027561285};\\\", \\\"{x:1490,y:655,t:1527027561301};\\\", \\\"{x:1484,y:653,t:1527027561318};\\\", \\\"{x:1478,y:651,t:1527027561334};\\\", \\\"{x:1474,y:651,t:1527027561351};\\\", \\\"{x:1472,y:650,t:1527027561368};\\\", \\\"{x:1470,y:649,t:1527027561383};\\\", \\\"{x:1467,y:648,t:1527027561401};\\\", \\\"{x:1466,y:648,t:1527027561418};\\\", \\\"{x:1465,y:647,t:1527027561434};\\\", \\\"{x:1464,y:646,t:1527027561451};\\\", \\\"{x:1462,y:645,t:1527027561468};\\\", \\\"{x:1459,y:642,t:1527027561484};\\\", \\\"{x:1458,y:640,t:1527027561501};\\\", \\\"{x:1457,y:639,t:1527027561525};\\\", \\\"{x:1457,y:638,t:1527027561534};\\\", \\\"{x:1456,y:636,t:1527027561551};\\\", \\\"{x:1456,y:635,t:1527027561568};\\\", \\\"{x:1455,y:631,t:1527027561584};\\\", \\\"{x:1455,y:630,t:1527027561710};\\\", \\\"{x:1456,y:630,t:1527027561726};\\\", \\\"{x:1458,y:630,t:1527027561741};\\\", \\\"{x:1461,y:630,t:1527027561751};\\\", \\\"{x:1464,y:630,t:1527027561768};\\\", \\\"{x:1469,y:630,t:1527027561785};\\\", \\\"{x:1474,y:631,t:1527027561802};\\\", \\\"{x:1481,y:632,t:1527027561818};\\\", \\\"{x:1490,y:634,t:1527027561834};\\\", \\\"{x:1499,y:634,t:1527027561852};\\\", \\\"{x:1512,y:636,t:1527027561870};\\\", \\\"{x:1519,y:638,t:1527027561886};\\\", \\\"{x:1520,y:639,t:1527027561902};\\\", \\\"{x:1521,y:639,t:1527027561919};\\\", \\\"{x:1521,y:642,t:1527027561936};\\\", \\\"{x:1521,y:648,t:1527027561952};\\\", \\\"{x:1518,y:656,t:1527027561969};\\\", \\\"{x:1508,y:665,t:1527027561985};\\\", \\\"{x:1493,y:676,t:1527027562002};\\\", \\\"{x:1474,y:686,t:1527027562018};\\\", \\\"{x:1455,y:694,t:1527027562036};\\\", \\\"{x:1439,y:701,t:1527027562052};\\\", \\\"{x:1423,y:706,t:1527027562069};\\\", \\\"{x:1409,y:713,t:1527027562085};\\\", \\\"{x:1404,y:715,t:1527027562102};\\\", \\\"{x:1399,y:717,t:1527027562119};\\\", \\\"{x:1397,y:718,t:1527027562135};\\\", \\\"{x:1390,y:723,t:1527027562152};\\\", \\\"{x:1385,y:726,t:1527027562169};\\\", \\\"{x:1380,y:729,t:1527027562185};\\\", \\\"{x:1374,y:732,t:1527027562201};\\\", \\\"{x:1372,y:732,t:1527027562219};\\\", \\\"{x:1370,y:733,t:1527027562236};\\\", \\\"{x:1367,y:734,t:1527027562251};\\\", \\\"{x:1366,y:735,t:1527027562271};\\\", \\\"{x:1365,y:736,t:1527027562284};\\\", \\\"{x:1363,y:738,t:1527027562301};\\\", \\\"{x:1362,y:739,t:1527027562318};\\\", \\\"{x:1360,y:741,t:1527027562335};\\\", \\\"{x:1358,y:742,t:1527027562351};\\\", \\\"{x:1357,y:743,t:1527027562368};\\\", \\\"{x:1357,y:744,t:1527027562385};\\\", \\\"{x:1356,y:745,t:1527027562401};\\\", \\\"{x:1355,y:746,t:1527027562418};\\\", \\\"{x:1355,y:748,t:1527027562435};\\\", \\\"{x:1354,y:750,t:1527027562451};\\\", \\\"{x:1353,y:751,t:1527027562468};\\\", \\\"{x:1353,y:752,t:1527027562486};\\\", \\\"{x:1352,y:753,t:1527027562517};\\\", \\\"{x:1352,y:754,t:1527027562549};\\\", \\\"{x:1352,y:755,t:1527027562557};\\\", \\\"{x:1352,y:756,t:1527027562569};\\\", \\\"{x:1351,y:756,t:1527027562586};\\\", \\\"{x:1351,y:757,t:1527027562602};\\\", \\\"{x:1350,y:758,t:1527027562619};\\\", \\\"{x:1350,y:759,t:1527027562653};\\\", \\\"{x:1349,y:759,t:1527027562718};\\\", \\\"{x:1349,y:760,t:1527027563133};\\\", \\\"{x:1350,y:761,t:1527027563149};\\\", \\\"{x:1350,y:762,t:1527027563157};\\\", \\\"{x:1353,y:762,t:1527027563168};\\\", \\\"{x:1356,y:763,t:1527027563186};\\\", \\\"{x:1359,y:763,t:1527027563202};\\\", \\\"{x:1364,y:763,t:1527027563219};\\\", \\\"{x:1370,y:763,t:1527027563236};\\\", \\\"{x:1378,y:763,t:1527027563253};\\\", \\\"{x:1384,y:763,t:1527027563269};\\\", \\\"{x:1390,y:763,t:1527027563285};\\\", \\\"{x:1394,y:763,t:1527027563302};\\\", \\\"{x:1398,y:762,t:1527027563319};\\\", \\\"{x:1401,y:762,t:1527027563336};\\\", \\\"{x:1407,y:762,t:1527027563353};\\\", \\\"{x:1409,y:761,t:1527027563369};\\\", \\\"{x:1414,y:761,t:1527027563386};\\\", \\\"{x:1417,y:761,t:1527027563403};\\\", \\\"{x:1421,y:761,t:1527027563419};\\\", \\\"{x:1427,y:761,t:1527027563436};\\\", \\\"{x:1435,y:761,t:1527027563453};\\\", \\\"{x:1445,y:761,t:1527027563469};\\\", \\\"{x:1454,y:761,t:1527027563486};\\\", \\\"{x:1458,y:761,t:1527027563503};\\\", \\\"{x:1463,y:760,t:1527027563519};\\\", \\\"{x:1468,y:760,t:1527027563536};\\\", \\\"{x:1470,y:760,t:1527027563552};\\\", \\\"{x:1472,y:760,t:1527027563569};\\\", \\\"{x:1475,y:760,t:1527027563585};\\\", \\\"{x:1478,y:760,t:1527027563603};\\\", \\\"{x:1484,y:760,t:1527027563619};\\\", \\\"{x:1486,y:759,t:1527027563636};\\\", \\\"{x:1492,y:758,t:1527027563652};\\\", \\\"{x:1497,y:758,t:1527027563669};\\\", \\\"{x:1500,y:758,t:1527027563686};\\\", \\\"{x:1504,y:758,t:1527027563703};\\\", \\\"{x:1507,y:758,t:1527027563719};\\\", \\\"{x:1512,y:758,t:1527027563736};\\\", \\\"{x:1517,y:758,t:1527027563753};\\\", \\\"{x:1519,y:758,t:1527027563769};\\\", \\\"{x:1522,y:758,t:1527027563786};\\\", \\\"{x:1524,y:758,t:1527027563813};\\\", \\\"{x:1524,y:761,t:1527027563941};\\\", \\\"{x:1524,y:762,t:1527027563953};\\\", \\\"{x:1522,y:766,t:1527027563968};\\\", \\\"{x:1521,y:767,t:1527027563986};\\\", \\\"{x:1520,y:769,t:1527027564002};\\\", \\\"{x:1520,y:771,t:1527027564019};\\\", \\\"{x:1518,y:773,t:1527027564036};\\\", \\\"{x:1518,y:775,t:1527027564053};\\\", \\\"{x:1516,y:776,t:1527027564070};\\\", \\\"{x:1516,y:777,t:1527027564086};\\\", \\\"{x:1515,y:778,t:1527027564103};\\\", \\\"{x:1515,y:779,t:1527027564119};\\\", \\\"{x:1514,y:779,t:1527027564141};\\\", \\\"{x:1513,y:780,t:1527027564165};\\\", \\\"{x:1512,y:781,t:1527027564214};\\\", \\\"{x:1512,y:782,t:1527027564318};\\\", \\\"{x:1511,y:783,t:1527027564365};\\\", \\\"{x:1511,y:784,t:1527027564390};\\\", \\\"{x:1511,y:785,t:1527027564403};\\\", \\\"{x:1511,y:787,t:1527027564420};\\\", \\\"{x:1511,y:789,t:1527027564436};\\\", \\\"{x:1511,y:790,t:1527027564454};\\\", \\\"{x:1511,y:793,t:1527027564469};\\\", \\\"{x:1511,y:794,t:1527027564486};\\\", \\\"{x:1511,y:796,t:1527027564503};\\\", \\\"{x:1511,y:798,t:1527027564519};\\\", \\\"{x:1511,y:802,t:1527027564535};\\\", \\\"{x:1511,y:805,t:1527027564553};\\\", \\\"{x:1510,y:807,t:1527027564570};\\\", \\\"{x:1509,y:809,t:1527027564586};\\\", \\\"{x:1508,y:811,t:1527027564603};\\\", \\\"{x:1508,y:812,t:1527027564620};\\\", \\\"{x:1507,y:813,t:1527027564636};\\\", \\\"{x:1506,y:815,t:1527027564653};\\\", \\\"{x:1506,y:816,t:1527027564670};\\\", \\\"{x:1506,y:817,t:1527027564701};\\\", \\\"{x:1506,y:818,t:1527027564742};\\\", \\\"{x:1506,y:819,t:1527027564766};\\\", \\\"{x:1505,y:819,t:1527027564797};\\\", \\\"{x:1504,y:820,t:1527027564805};\\\", \\\"{x:1502,y:820,t:1527027564829};\\\", \\\"{x:1500,y:820,t:1527027564854};\\\", \\\"{x:1499,y:820,t:1527027564870};\\\", \\\"{x:1496,y:820,t:1527027564886};\\\", \\\"{x:1495,y:822,t:1527027564902};\\\", \\\"{x:1492,y:822,t:1527027564920};\\\", \\\"{x:1490,y:822,t:1527027564974};\\\", \\\"{x:1489,y:822,t:1527027564986};\\\", \\\"{x:1486,y:822,t:1527027565003};\\\", \\\"{x:1484,y:822,t:1527027565021};\\\", \\\"{x:1483,y:822,t:1527027565035};\\\", \\\"{x:1482,y:822,t:1527027565053};\\\", \\\"{x:1481,y:822,t:1527027565070};\\\", \\\"{x:1480,y:822,t:1527027565085};\\\", \\\"{x:1479,y:823,t:1527027565165};\\\", \\\"{x:1478,y:824,t:1527027565365};\\\", \\\"{x:1478,y:825,t:1527027565382};\\\", \\\"{x:1481,y:825,t:1527027565403};\\\", \\\"{x:1484,y:825,t:1527027565420};\\\", \\\"{x:1488,y:825,t:1527027565437};\\\", \\\"{x:1492,y:825,t:1527027565453};\\\", \\\"{x:1496,y:825,t:1527027565469};\\\", \\\"{x:1498,y:825,t:1527027565485};\\\", \\\"{x:1501,y:824,t:1527027565503};\\\", \\\"{x:1505,y:824,t:1527027565520};\\\", \\\"{x:1510,y:824,t:1527027565536};\\\", \\\"{x:1515,y:824,t:1527027565552};\\\", \\\"{x:1519,y:822,t:1527027565570};\\\", \\\"{x:1524,y:821,t:1527027565586};\\\", \\\"{x:1527,y:821,t:1527027565603};\\\", \\\"{x:1530,y:821,t:1527027565620};\\\", \\\"{x:1533,y:821,t:1527027565637};\\\", \\\"{x:1535,y:821,t:1527027565653};\\\", \\\"{x:1538,y:820,t:1527027565669};\\\", \\\"{x:1539,y:820,t:1527027565687};\\\", \\\"{x:1540,y:820,t:1527027565703};\\\", \\\"{x:1541,y:820,t:1527027565720};\\\", \\\"{x:1543,y:820,t:1527027565918};\\\", \\\"{x:1545,y:820,t:1527027565925};\\\", \\\"{x:1547,y:820,t:1527027565937};\\\", \\\"{x:1550,y:820,t:1527027565953};\\\", \\\"{x:1554,y:820,t:1527027565970};\\\", \\\"{x:1559,y:820,t:1527027565987};\\\", \\\"{x:1564,y:820,t:1527027566003};\\\", \\\"{x:1566,y:821,t:1527027566020};\\\", \\\"{x:1568,y:821,t:1527027566036};\\\", \\\"{x:1570,y:822,t:1527027566054};\\\", \\\"{x:1571,y:822,t:1527027566118};\\\", \\\"{x:1572,y:822,t:1527027566125};\\\", \\\"{x:1573,y:822,t:1527027566136};\\\", \\\"{x:1576,y:822,t:1527027566152};\\\", \\\"{x:1580,y:822,t:1527027566169};\\\", \\\"{x:1584,y:822,t:1527027566186};\\\", \\\"{x:1588,y:822,t:1527027566202};\\\", \\\"{x:1590,y:822,t:1527027566219};\\\", \\\"{x:1593,y:822,t:1527027566237};\\\", \\\"{x:1594,y:822,t:1527027566252};\\\", \\\"{x:1595,y:822,t:1527027566270};\\\", \\\"{x:1596,y:822,t:1527027566286};\\\", \\\"{x:1599,y:822,t:1527027566302};\\\", \\\"{x:1600,y:822,t:1527027566319};\\\", \\\"{x:1603,y:822,t:1527027566337};\\\", \\\"{x:1606,y:822,t:1527027566352};\\\", \\\"{x:1607,y:822,t:1527027566370};\\\", \\\"{x:1609,y:822,t:1527027566386};\\\", \\\"{x:1610,y:822,t:1527027566402};\\\", \\\"{x:1612,y:822,t:1527027566454};\\\", \\\"{x:1613,y:822,t:1527027566469};\\\", \\\"{x:1616,y:823,t:1527027566487};\\\", \\\"{x:1617,y:823,t:1527027566503};\\\", \\\"{x:1618,y:823,t:1527027566520};\\\", \\\"{x:1619,y:825,t:1527027566806};\\\", \\\"{x:1619,y:826,t:1527027566821};\\\", \\\"{x:1619,y:828,t:1527027566837};\\\", \\\"{x:1619,y:829,t:1527027566877};\\\", \\\"{x:1618,y:830,t:1527027566894};\\\", \\\"{x:1616,y:831,t:1527027566917};\\\", \\\"{x:1616,y:833,t:1527027566982};\\\", \\\"{x:1613,y:833,t:1527027567213};\\\", \\\"{x:1611,y:832,t:1527027567220};\\\", \\\"{x:1609,y:830,t:1527027567236};\\\", \\\"{x:1607,y:830,t:1527027568614};\\\", \\\"{x:1605,y:830,t:1527027568625};\\\", \\\"{x:1602,y:830,t:1527027568642};\\\", \\\"{x:1596,y:830,t:1527027568658};\\\", \\\"{x:1593,y:830,t:1527027568675};\\\", \\\"{x:1589,y:828,t:1527027568692};\\\", \\\"{x:1587,y:828,t:1527027568709};\\\", \\\"{x:1586,y:828,t:1527027568725};\\\", \\\"{x:1585,y:828,t:1527027568741};\\\", \\\"{x:1583,y:828,t:1527027568759};\\\", \\\"{x:1578,y:828,t:1527027568775};\\\", \\\"{x:1570,y:826,t:1527027568792};\\\", \\\"{x:1562,y:824,t:1527027568809};\\\", \\\"{x:1550,y:823,t:1527027568825};\\\", \\\"{x:1535,y:821,t:1527027568842};\\\", \\\"{x:1517,y:818,t:1527027568859};\\\", \\\"{x:1497,y:816,t:1527027568875};\\\", \\\"{x:1471,y:811,t:1527027568892};\\\", \\\"{x:1437,y:805,t:1527027568909};\\\", \\\"{x:1420,y:805,t:1527027568925};\\\", \\\"{x:1401,y:803,t:1527027568942};\\\", \\\"{x:1387,y:800,t:1527027568960};\\\", \\\"{x:1370,y:800,t:1527027568976};\\\", \\\"{x:1355,y:797,t:1527027568992};\\\", \\\"{x:1338,y:795,t:1527027569009};\\\", \\\"{x:1320,y:793,t:1527027569026};\\\", \\\"{x:1306,y:792,t:1527027569042};\\\", \\\"{x:1292,y:791,t:1527027569059};\\\", \\\"{x:1279,y:789,t:1527027569076};\\\", \\\"{x:1267,y:787,t:1527027569092};\\\", \\\"{x:1243,y:784,t:1527027569109};\\\", \\\"{x:1229,y:781,t:1527027569125};\\\", \\\"{x:1217,y:781,t:1527027569142};\\\", \\\"{x:1202,y:779,t:1527027569158};\\\", \\\"{x:1185,y:773,t:1527027569175};\\\", \\\"{x:1158,y:765,t:1527027569193};\\\", \\\"{x:1108,y:752,t:1527027569208};\\\", \\\"{x:1043,y:740,t:1527027569225};\\\", \\\"{x:1007,y:737,t:1527027569243};\\\", \\\"{x:984,y:731,t:1527027569258};\\\", \\\"{x:973,y:726,t:1527027569276};\\\", \\\"{x:965,y:720,t:1527027569292};\\\", \\\"{x:957,y:711,t:1527027569308};\\\", \\\"{x:930,y:688,t:1527027569325};\\\", \\\"{x:877,y:654,t:1527027569342};\\\", \\\"{x:833,y:634,t:1527027569359};\\\", \\\"{x:802,y:620,t:1527027569376};\\\", \\\"{x:775,y:608,t:1527027569393};\\\", \\\"{x:750,y:593,t:1527027569410};\\\", \\\"{x:731,y:580,t:1527027569425};\\\", \\\"{x:722,y:574,t:1527027569441};\\\", \\\"{x:714,y:566,t:1527027569458};\\\", \\\"{x:701,y:557,t:1527027569474};\\\", \\\"{x:688,y:549,t:1527027569492};\\\", \\\"{x:674,y:545,t:1527027569508};\\\", \\\"{x:665,y:544,t:1527027569525};\\\", \\\"{x:654,y:542,t:1527027569541};\\\", \\\"{x:644,y:540,t:1527027569558};\\\", \\\"{x:632,y:540,t:1527027569575};\\\", \\\"{x:619,y:540,t:1527027569591};\\\", \\\"{x:606,y:540,t:1527027569607};\\\", \\\"{x:599,y:542,t:1527027569624};\\\", \\\"{x:593,y:543,t:1527027569641};\\\", \\\"{x:588,y:546,t:1527027569658};\\\", \\\"{x:584,y:549,t:1527027569674};\\\", \\\"{x:581,y:551,t:1527027569691};\\\", \\\"{x:572,y:556,t:1527027569710};\\\", \\\"{x:569,y:558,t:1527027569725};\\\", \\\"{x:565,y:559,t:1527027569741};\\\", \\\"{x:559,y:561,t:1527027569758};\\\", \\\"{x:553,y:562,t:1527027569776};\\\", \\\"{x:546,y:564,t:1527027569792};\\\", \\\"{x:536,y:565,t:1527027569808};\\\", \\\"{x:527,y:565,t:1527027569825};\\\", \\\"{x:515,y:567,t:1527027569842};\\\", \\\"{x:504,y:569,t:1527027569859};\\\", \\\"{x:493,y:571,t:1527027569876};\\\", \\\"{x:482,y:574,t:1527027569892};\\\", \\\"{x:471,y:576,t:1527027569908};\\\", \\\"{x:467,y:577,t:1527027569925};\\\", \\\"{x:464,y:578,t:1527027569941};\\\", \\\"{x:460,y:578,t:1527027569959};\\\", \\\"{x:456,y:579,t:1527027569976};\\\", \\\"{x:451,y:580,t:1527027569992};\\\", \\\"{x:447,y:582,t:1527027570009};\\\", \\\"{x:443,y:583,t:1527027570025};\\\", \\\"{x:442,y:583,t:1527027570042};\\\", \\\"{x:440,y:583,t:1527027570059};\\\", \\\"{x:437,y:585,t:1527027570075};\\\", \\\"{x:433,y:585,t:1527027570092};\\\", \\\"{x:425,y:587,t:1527027570109};\\\", \\\"{x:421,y:589,t:1527027570125};\\\", \\\"{x:413,y:589,t:1527027570141};\\\", \\\"{x:406,y:590,t:1527027570159};\\\", \\\"{x:396,y:591,t:1527027570176};\\\", \\\"{x:386,y:594,t:1527027570193};\\\", \\\"{x:376,y:595,t:1527027570208};\\\", \\\"{x:366,y:596,t:1527027570226};\\\", \\\"{x:357,y:596,t:1527027570242};\\\", \\\"{x:349,y:596,t:1527027570258};\\\", \\\"{x:343,y:596,t:1527027570275};\\\", \\\"{x:335,y:596,t:1527027570293};\\\", \\\"{x:331,y:596,t:1527027570308};\\\", \\\"{x:324,y:596,t:1527027570326};\\\", \\\"{x:314,y:596,t:1527027570342};\\\", \\\"{x:294,y:594,t:1527027570360};\\\", \\\"{x:279,y:593,t:1527027570376};\\\", \\\"{x:268,y:593,t:1527027570393};\\\", \\\"{x:262,y:593,t:1527027570409};\\\", \\\"{x:260,y:593,t:1527027570426};\\\", \\\"{x:257,y:593,t:1527027570443};\\\", \\\"{x:253,y:593,t:1527027570459};\\\", \\\"{x:247,y:593,t:1527027570476};\\\", \\\"{x:238,y:593,t:1527027570492};\\\", \\\"{x:234,y:593,t:1527027570508};\\\", \\\"{x:228,y:593,t:1527027570525};\\\", \\\"{x:220,y:593,t:1527027570542};\\\", \\\"{x:203,y:592,t:1527027570558};\\\", \\\"{x:179,y:590,t:1527027570575};\\\", \\\"{x:158,y:590,t:1527027570592};\\\", \\\"{x:144,y:590,t:1527027570608};\\\", \\\"{x:134,y:590,t:1527027570625};\\\", \\\"{x:128,y:590,t:1527027570642};\\\", \\\"{x:126,y:591,t:1527027570658};\\\", \\\"{x:126,y:592,t:1527027570692};\\\", \\\"{x:124,y:593,t:1527027570709};\\\", \\\"{x:124,y:594,t:1527027570726};\\\", \\\"{x:124,y:595,t:1527027570742};\\\", \\\"{x:124,y:596,t:1527027570759};\\\", \\\"{x:127,y:594,t:1527027570822};\\\", \\\"{x:130,y:590,t:1527027570831};\\\", \\\"{x:135,y:585,t:1527027570842};\\\", \\\"{x:144,y:574,t:1527027570859};\\\", \\\"{x:153,y:565,t:1527027570875};\\\", \\\"{x:157,y:557,t:1527027570893};\\\", \\\"{x:158,y:553,t:1527027570910};\\\", \\\"{x:160,y:549,t:1527027570926};\\\", \\\"{x:161,y:546,t:1527027570943};\\\", \\\"{x:161,y:545,t:1527027570959};\\\", \\\"{x:162,y:542,t:1527027570977};\\\", \\\"{x:162,y:539,t:1527027570992};\\\", \\\"{x:164,y:536,t:1527027571010};\\\", \\\"{x:164,y:535,t:1527027571026};\\\", \\\"{x:164,y:532,t:1527027571043};\\\", \\\"{x:165,y:531,t:1527027571060};\\\", \\\"{x:165,y:530,t:1527027571077};\\\", \\\"{x:166,y:529,t:1527027571192};\\\", \\\"{x:166,y:531,t:1527027571246};\\\", \\\"{x:166,y:532,t:1527027571252};\\\", \\\"{x:166,y:532,t:1527027571260};\\\", \\\"{x:166,y:534,t:1527027571276};\\\", \\\"{x:166,y:535,t:1527027571293};\\\", \\\"{x:166,y:536,t:1527027571340};\\\", \\\"{x:167,y:536,t:1527027571348};\\\", \\\"{x:168,y:537,t:1527027571550};\\\", \\\"{x:168,y:538,t:1527027571565};\\\", \\\"{x:168,y:539,t:1527027571581};\\\", \\\"{x:168,y:541,t:1527027571594};\\\", \\\"{x:167,y:541,t:1527027571610};\\\", \\\"{x:166,y:542,t:1527027571645};\\\", \\\"{x:167,y:542,t:1527027572110};\\\", \\\"{x:170,y:542,t:1527027572117};\\\", \\\"{x:176,y:543,t:1527027572126};\\\", \\\"{x:192,y:543,t:1527027572144};\\\", \\\"{x:218,y:543,t:1527027572161};\\\", \\\"{x:250,y:545,t:1527027572176};\\\", \\\"{x:277,y:546,t:1527027572195};\\\", \\\"{x:307,y:551,t:1527027572211};\\\", \\\"{x:331,y:554,t:1527027572226};\\\", \\\"{x:355,y:558,t:1527027572244};\\\", \\\"{x:398,y:563,t:1527027572261};\\\", \\\"{x:425,y:563,t:1527027572277};\\\", \\\"{x:455,y:563,t:1527027572294};\\\", \\\"{x:485,y:563,t:1527027572311};\\\", \\\"{x:512,y:563,t:1527027572328};\\\", \\\"{x:538,y:565,t:1527027572343};\\\", \\\"{x:563,y:569,t:1527027572360};\\\", \\\"{x:591,y:572,t:1527027572378};\\\", \\\"{x:614,y:575,t:1527027572394};\\\", \\\"{x:635,y:580,t:1527027572411};\\\", \\\"{x:650,y:581,t:1527027572428};\\\", \\\"{x:656,y:581,t:1527027572444};\\\", \\\"{x:657,y:581,t:1527027572477};\\\", \\\"{x:657,y:580,t:1527027572501};\\\", \\\"{x:657,y:579,t:1527027572511};\\\", \\\"{x:657,y:578,t:1527027572527};\\\", \\\"{x:657,y:577,t:1527027572544};\\\", \\\"{x:655,y:576,t:1527027572560};\\\", \\\"{x:648,y:574,t:1527027572577};\\\", \\\"{x:636,y:572,t:1527027572595};\\\", \\\"{x:620,y:572,t:1527027572611};\\\", \\\"{x:607,y:572,t:1527027572627};\\\", \\\"{x:598,y:572,t:1527027572644};\\\", \\\"{x:596,y:572,t:1527027572660};\\\", \\\"{x:594,y:572,t:1527027572677};\\\", \\\"{x:593,y:572,t:1527027572693};\\\", \\\"{x:592,y:572,t:1527027572716};\\\", \\\"{x:593,y:573,t:1527027572958};\\\", \\\"{x:595,y:573,t:1527027572973};\\\", \\\"{x:596,y:573,t:1527027573205};\\\", \\\"{x:597,y:573,t:1527027573213};\\\", \\\"{x:598,y:573,t:1527027573228};\\\", \\\"{x:603,y:573,t:1527027573245};\\\", \\\"{x:604,y:573,t:1527027573325};\\\", \\\"{x:605,y:573,t:1527027573332};\\\", \\\"{x:606,y:573,t:1527027573348};\\\", \\\"{x:607,y:573,t:1527027573364};\\\", \\\"{x:607,y:573,t:1527027573428};\\\", \\\"{x:609,y:573,t:1527027573508};\\\", \\\"{x:611,y:573,t:1527027573516};\\\", \\\"{x:612,y:573,t:1527027573527};\\\", \\\"{x:616,y:574,t:1527027573544};\\\", \\\"{x:621,y:575,t:1527027573562};\\\", \\\"{x:625,y:576,t:1527027573577};\\\", \\\"{x:629,y:577,t:1527027573595};\\\", \\\"{x:636,y:579,t:1527027573612};\\\", \\\"{x:644,y:581,t:1527027573628};\\\", \\\"{x:667,y:583,t:1527027573644};\\\", \\\"{x:689,y:588,t:1527027573662};\\\", \\\"{x:719,y:593,t:1527027573677};\\\", \\\"{x:759,y:601,t:1527027573695};\\\", \\\"{x:810,y:609,t:1527027573712};\\\", \\\"{x:866,y:619,t:1527027573729};\\\", \\\"{x:924,y:630,t:1527027573745};\\\", \\\"{x:989,y:644,t:1527027573762};\\\", \\\"{x:1067,y:656,t:1527027573778};\\\", \\\"{x:1139,y:665,t:1527027573795};\\\", \\\"{x:1201,y:674,t:1527027573811};\\\", \\\"{x:1304,y:695,t:1527027573829};\\\", \\\"{x:1362,y:710,t:1527027573844};\\\", \\\"{x:1396,y:715,t:1527027573862};\\\", \\\"{x:1423,y:721,t:1527027573879};\\\", \\\"{x:1445,y:723,t:1527027573895};\\\", \\\"{x:1466,y:726,t:1527027573912};\\\", \\\"{x:1484,y:727,t:1527027573929};\\\", \\\"{x:1500,y:727,t:1527027573945};\\\", \\\"{x:1520,y:727,t:1527027573962};\\\", \\\"{x:1533,y:727,t:1527027573979};\\\", \\\"{x:1550,y:727,t:1527027573996};\\\", \\\"{x:1566,y:727,t:1527027574012};\\\", \\\"{x:1587,y:729,t:1527027574029};\\\", \\\"{x:1594,y:729,t:1527027574045};\\\", \\\"{x:1595,y:729,t:1527027574062};\\\", \\\"{x:1597,y:730,t:1527027574126};\\\", \\\"{x:1597,y:732,t:1527027574133};\\\", \\\"{x:1597,y:734,t:1527027574147};\\\", \\\"{x:1594,y:740,t:1527027574162};\\\", \\\"{x:1590,y:742,t:1527027574180};\\\", \\\"{x:1585,y:746,t:1527027574196};\\\", \\\"{x:1577,y:751,t:1527027574213};\\\", \\\"{x:1563,y:757,t:1527027574229};\\\", \\\"{x:1549,y:762,t:1527027574245};\\\", \\\"{x:1537,y:767,t:1527027574263};\\\", \\\"{x:1523,y:771,t:1527027574279};\\\", \\\"{x:1514,y:775,t:1527027574296};\\\", \\\"{x:1503,y:778,t:1527027574312};\\\", \\\"{x:1499,y:780,t:1527027574329};\\\", \\\"{x:1493,y:782,t:1527027574346};\\\", \\\"{x:1488,y:784,t:1527027574363};\\\", \\\"{x:1483,y:785,t:1527027574379};\\\", \\\"{x:1471,y:786,t:1527027574396};\\\", \\\"{x:1448,y:788,t:1527027574413};\\\", \\\"{x:1435,y:783,t:1527027574429};\\\", \\\"{x:1433,y:780,t:1527027574446};\\\", \\\"{x:1427,y:779,t:1527027574662};\\\", \\\"{x:1395,y:771,t:1527027574680};\\\", \\\"{x:1331,y:752,t:1527027574696};\\\", \\\"{x:1248,y:733,t:1527027574713};\\\", \\\"{x:1138,y:704,t:1527027574730};\\\", \\\"{x:1021,y:684,t:1527027574747};\\\", \\\"{x:896,y:667,t:1527027574763};\\\", \\\"{x:785,y:651,t:1527027574780};\\\", \\\"{x:683,y:637,t:1527027574797};\\\", \\\"{x:565,y:623,t:1527027574814};\\\", \\\"{x:512,y:617,t:1527027574830};\\\", \\\"{x:488,y:617,t:1527027574845};\\\", \\\"{x:472,y:622,t:1527027574862};\\\", \\\"{x:467,y:629,t:1527027574879};\\\", \\\"{x:463,y:638,t:1527027574896};\\\", \\\"{x:461,y:647,t:1527027574912};\\\", \\\"{x:457,y:658,t:1527027574929};\\\", \\\"{x:457,y:664,t:1527027574945};\\\", \\\"{x:457,y:671,t:1527027574963};\\\", \\\"{x:457,y:676,t:1527027574979};\\\", \\\"{x:457,y:682,t:1527027574995};\\\", \\\"{x:459,y:690,t:1527027575013};\\\", \\\"{x:462,y:697,t:1527027575029};\\\", \\\"{x:465,y:703,t:1527027575046};\\\", \\\"{x:468,y:707,t:1527027575062};\\\", \\\"{x:474,y:713,t:1527027575080};\\\", \\\"{x:478,y:716,t:1527027575096};\\\", \\\"{x:479,y:717,t:1527027575113};\\\", \\\"{x:480,y:719,t:1527027575130};\\\", \\\"{x:481,y:720,t:1527027575146};\\\", \\\"{x:482,y:720,t:1527027575181};\\\", \\\"{x:484,y:720,t:1527027575197};\\\", \\\"{x:486,y:722,t:1527027575213};\\\", \\\"{x:486,y:723,t:1527027575229};\\\", \\\"{x:488,y:726,t:1527027575245};\\\", \\\"{x:489,y:728,t:1527027575263};\\\", \\\"{x:490,y:728,t:1527027575293};\\\", \\\"{x:491,y:728,t:1527027575312};\\\", \\\"{x:492,y:729,t:1527027575330};\\\", \\\"{x:492,y:729,t:1527027575406};\\\", \\\"{x:493,y:729,t:1527027575508};\\\", \\\"{x:496,y:729,t:1527027575516};\\\", \\\"{x:502,y:729,t:1527027575530};\\\", \\\"{x:513,y:729,t:1527027575546};\\\", \\\"{x:536,y:729,t:1527027575563};\\\", \\\"{x:562,y:730,t:1527027575579};\\\", \\\"{x:606,y:731,t:1527027575596};\\\", \\\"{x:651,y:731,t:1527027575612};\\\", \\\"{x:705,y:731,t:1527027575630};\\\", \\\"{x:777,y:731,t:1527027575647};\\\", \\\"{x:858,y:717,t:1527027575663};\\\", \\\"{x:938,y:708,t:1527027575680};\\\", \\\"{x:1006,y:704,t:1527027575697};\\\", \\\"{x:1050,y:700,t:1527027575713};\\\", \\\"{x:1077,y:699,t:1527027575730};\\\", \\\"{x:1094,y:697,t:1527027575747};\\\", \\\"{x:1102,y:693,t:1527027575762};\\\", \\\"{x:1103,y:692,t:1527027575779};\\\", \\\"{x:1105,y:688,t:1527027575797};\\\" ] }, { \\\"rt\\\": 39835, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 454543, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"C30CF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -I -X -J -X -X -F -B -B -O -O -O -M -M -M -O -O -C \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1105,y:687,t:1527027576796};\\\", \\\"{x:1103,y:686,t:1527027576804};\\\", \\\"{x:1102,y:685,t:1527027576813};\\\", \\\"{x:1101,y:684,t:1527027576885};\\\", \\\"{x:1101,y:682,t:1527027577087};\\\", \\\"{x:1100,y:681,t:1527027577177};\\\", \\\"{x:1099,y:681,t:1527027577181};\\\", \\\"{x:1099,y:679,t:1527027577204};\\\", \\\"{x:1098,y:679,t:1527027577214};\\\", \\\"{x:1098,y:678,t:1527027577231};\\\", \\\"{x:1098,y:676,t:1527027577292};\\\", \\\"{x:1097,y:676,t:1527027577300};\\\", \\\"{x:1097,y:675,t:1527027577315};\\\", \\\"{x:1096,y:675,t:1527027577348};\\\", \\\"{x:1096,y:673,t:1527027577381};\\\", \\\"{x:1095,y:673,t:1527027577398};\\\", \\\"{x:1095,y:672,t:1527027577421};\\\", \\\"{x:1095,y:671,t:1527027577510};\\\", \\\"{x:1095,y:670,t:1527027577533};\\\", \\\"{x:1095,y:669,t:1527027577548};\\\", \\\"{x:1096,y:669,t:1527027577565};\\\", \\\"{x:1106,y:669,t:1527027577581};\\\", \\\"{x:1121,y:669,t:1527027577599};\\\", \\\"{x:1139,y:669,t:1527027577615};\\\", \\\"{x:1151,y:669,t:1527027577632};\\\", \\\"{x:1159,y:666,t:1527027577648};\\\", \\\"{x:1164,y:669,t:1527027578014};\\\", \\\"{x:1173,y:668,t:1527027578023};\\\", \\\"{x:1175,y:668,t:1527027578032};\\\", \\\"{x:1178,y:668,t:1527027578049};\\\", \\\"{x:1184,y:669,t:1527027578065};\\\", \\\"{x:1188,y:669,t:1527027578082};\\\", \\\"{x:1198,y:670,t:1527027578099};\\\", \\\"{x:1213,y:673,t:1527027578115};\\\", \\\"{x:1234,y:675,t:1527027578132};\\\", \\\"{x:1270,y:681,t:1527027578149};\\\", \\\"{x:1291,y:684,t:1527027578165};\\\", \\\"{x:1311,y:686,t:1527027578182};\\\", \\\"{x:1328,y:689,t:1527027578200};\\\", \\\"{x:1342,y:690,t:1527027578215};\\\", \\\"{x:1352,y:691,t:1527027578232};\\\", \\\"{x:1357,y:691,t:1527027578249};\\\", \\\"{x:1359,y:691,t:1527027578265};\\\", \\\"{x:1360,y:691,t:1527027578283};\\\", \\\"{x:1360,y:690,t:1527027578373};\\\", \\\"{x:1360,y:689,t:1527027578397};\\\", \\\"{x:1360,y:688,t:1527027578413};\\\", \\\"{x:1359,y:687,t:1527027578423};\\\", \\\"{x:1359,y:688,t:1527027578588};\\\", \\\"{x:1358,y:691,t:1527027578599};\\\", \\\"{x:1354,y:695,t:1527027578616};\\\", \\\"{x:1350,y:700,t:1527027578633};\\\", \\\"{x:1347,y:705,t:1527027578650};\\\", \\\"{x:1344,y:710,t:1527027578666};\\\", \\\"{x:1343,y:711,t:1527027578682};\\\", \\\"{x:1342,y:713,t:1527027578700};\\\", \\\"{x:1342,y:715,t:1527027578716};\\\", \\\"{x:1341,y:718,t:1527027578732};\\\", \\\"{x:1340,y:719,t:1527027578749};\\\", \\\"{x:1339,y:721,t:1527027578767};\\\", \\\"{x:1338,y:721,t:1527027578829};\\\", \\\"{x:1338,y:722,t:1527027578845};\\\", \\\"{x:1336,y:722,t:1527027578950};\\\", \\\"{x:1336,y:721,t:1527027578966};\\\", \\\"{x:1335,y:719,t:1527027578983};\\\", \\\"{x:1334,y:717,t:1527027579000};\\\", \\\"{x:1334,y:715,t:1527027579017};\\\", \\\"{x:1334,y:714,t:1527027579037};\\\", \\\"{x:1334,y:712,t:1527027579078};\\\", \\\"{x:1334,y:711,t:1527027579109};\\\", \\\"{x:1333,y:711,t:1527027579158};\\\", \\\"{x:1331,y:711,t:1527027579173};\\\", \\\"{x:1330,y:711,t:1527027579183};\\\", \\\"{x:1323,y:711,t:1527027579199};\\\", \\\"{x:1310,y:715,t:1527027579216};\\\", \\\"{x:1299,y:719,t:1527027579233};\\\", \\\"{x:1284,y:727,t:1527027579249};\\\", \\\"{x:1274,y:729,t:1527027579267};\\\", \\\"{x:1264,y:731,t:1527027579284};\\\", \\\"{x:1254,y:733,t:1527027579298};\\\", \\\"{x:1239,y:736,t:1527027579316};\\\", \\\"{x:1222,y:741,t:1527027579332};\\\", \\\"{x:1212,y:743,t:1527027579350};\\\", \\\"{x:1200,y:746,t:1527027579366};\\\", \\\"{x:1191,y:748,t:1527027579383};\\\", \\\"{x:1183,y:750,t:1527027579400};\\\", \\\"{x:1180,y:751,t:1527027579416};\\\", \\\"{x:1177,y:752,t:1527027579433};\\\", \\\"{x:1175,y:755,t:1527027579450};\\\", \\\"{x:1172,y:759,t:1527027579466};\\\", \\\"{x:1170,y:762,t:1527027579483};\\\", \\\"{x:1170,y:764,t:1527027579501};\\\", \\\"{x:1170,y:765,t:1527027579558};\\\", \\\"{x:1170,y:766,t:1527027579581};\\\", \\\"{x:1171,y:767,t:1527027579597};\\\", \\\"{x:1173,y:768,t:1527027579613};\\\", \\\"{x:1175,y:769,t:1527027579629};\\\", \\\"{x:1176,y:769,t:1527027579637};\\\", \\\"{x:1178,y:769,t:1527027579651};\\\", \\\"{x:1184,y:769,t:1527027579666};\\\", \\\"{x:1187,y:769,t:1527027579684};\\\", \\\"{x:1189,y:769,t:1527027579701};\\\", \\\"{x:1190,y:771,t:1527027579813};\\\", \\\"{x:1192,y:771,t:1527027579829};\\\", \\\"{x:1194,y:771,t:1527027579845};\\\", \\\"{x:1196,y:771,t:1527027579853};\\\", \\\"{x:1199,y:771,t:1527027579869};\\\", \\\"{x:1201,y:772,t:1527027579884};\\\", \\\"{x:1201,y:773,t:1527027580086};\\\", \\\"{x:1203,y:773,t:1527027580101};\\\", \\\"{x:1207,y:776,t:1527027580117};\\\", \\\"{x:1213,y:778,t:1527027580133};\\\", \\\"{x:1220,y:780,t:1527027580150};\\\", \\\"{x:1227,y:783,t:1527027580168};\\\", \\\"{x:1236,y:785,t:1527027580184};\\\", \\\"{x:1240,y:788,t:1527027580201};\\\", \\\"{x:1247,y:788,t:1527027580217};\\\", \\\"{x:1252,y:791,t:1527027580234};\\\", \\\"{x:1259,y:792,t:1527027580251};\\\", \\\"{x:1262,y:794,t:1527027580268};\\\", \\\"{x:1267,y:794,t:1527027580284};\\\", \\\"{x:1274,y:795,t:1527027580300};\\\", \\\"{x:1284,y:796,t:1527027580317};\\\", \\\"{x:1291,y:798,t:1527027580334};\\\", \\\"{x:1299,y:799,t:1527027580351};\\\", \\\"{x:1308,y:799,t:1527027580368};\\\", \\\"{x:1314,y:800,t:1527027580385};\\\", \\\"{x:1320,y:802,t:1527027580400};\\\", \\\"{x:1324,y:802,t:1527027580417};\\\", \\\"{x:1327,y:802,t:1527027580435};\\\", \\\"{x:1333,y:802,t:1527027580451};\\\", \\\"{x:1336,y:803,t:1527027580467};\\\", \\\"{x:1341,y:803,t:1527027580484};\\\", \\\"{x:1345,y:803,t:1527027580501};\\\", \\\"{x:1359,y:806,t:1527027580517};\\\", \\\"{x:1368,y:808,t:1527027580535};\\\", \\\"{x:1377,y:809,t:1527027580550};\\\", \\\"{x:1384,y:809,t:1527027580567};\\\", \\\"{x:1390,y:810,t:1527027580585};\\\", \\\"{x:1394,y:811,t:1527027580601};\\\", \\\"{x:1399,y:812,t:1527027580618};\\\", \\\"{x:1407,y:812,t:1527027580635};\\\", \\\"{x:1418,y:813,t:1527027580651};\\\", \\\"{x:1429,y:813,t:1527027580667};\\\", \\\"{x:1435,y:813,t:1527027580685};\\\", \\\"{x:1444,y:814,t:1527027580702};\\\", \\\"{x:1448,y:815,t:1527027580717};\\\", \\\"{x:1454,y:816,t:1527027580734};\\\", \\\"{x:1458,y:817,t:1527027580751};\\\", \\\"{x:1463,y:817,t:1527027580768};\\\", \\\"{x:1465,y:819,t:1527027580784};\\\", \\\"{x:1468,y:820,t:1527027580802};\\\", \\\"{x:1469,y:820,t:1527027580818};\\\", \\\"{x:1471,y:821,t:1527027580835};\\\", \\\"{x:1474,y:824,t:1527027580851};\\\", \\\"{x:1477,y:826,t:1527027580868};\\\", \\\"{x:1478,y:828,t:1527027580885};\\\", \\\"{x:1480,y:833,t:1527027580901};\\\", \\\"{x:1480,y:834,t:1527027581558};\\\", \\\"{x:1476,y:834,t:1527027581986};\\\", \\\"{x:1465,y:834,t:1527027581992};\\\", \\\"{x:1454,y:834,t:1527027582004};\\\", \\\"{x:1425,y:834,t:1527027582022};\\\", \\\"{x:1398,y:831,t:1527027582038};\\\", \\\"{x:1378,y:827,t:1527027582054};\\\", \\\"{x:1358,y:824,t:1527027582071};\\\", \\\"{x:1339,y:821,t:1527027582088};\\\", \\\"{x:1329,y:819,t:1527027582106};\\\", \\\"{x:1320,y:819,t:1527027582122};\\\", \\\"{x:1308,y:819,t:1527027582139};\\\", \\\"{x:1297,y:819,t:1527027582156};\\\", \\\"{x:1287,y:819,t:1527027582172};\\\", \\\"{x:1276,y:817,t:1527027582189};\\\", \\\"{x:1267,y:817,t:1527027582206};\\\", \\\"{x:1263,y:817,t:1527027582222};\\\", \\\"{x:1260,y:817,t:1527027582239};\\\", \\\"{x:1259,y:817,t:1527027582256};\\\", \\\"{x:1257,y:819,t:1527027582272};\\\", \\\"{x:1251,y:823,t:1527027582288};\\\", \\\"{x:1244,y:825,t:1527027582306};\\\", \\\"{x:1239,y:825,t:1527027582322};\\\", \\\"{x:1233,y:828,t:1527027582339};\\\", \\\"{x:1229,y:828,t:1527027582356};\\\", \\\"{x:1226,y:829,t:1527027582372};\\\", \\\"{x:1225,y:830,t:1527027582389};\\\", \\\"{x:1223,y:830,t:1527027582405};\\\", \\\"{x:1223,y:832,t:1527027582422};\\\", \\\"{x:1222,y:832,t:1527027582438};\\\", \\\"{x:1221,y:833,t:1527027582480};\\\", \\\"{x:1220,y:833,t:1527027582488};\\\", \\\"{x:1219,y:834,t:1527027582505};\\\", \\\"{x:1218,y:835,t:1527027582522};\\\", \\\"{x:1216,y:835,t:1527027582568};\\\", \\\"{x:1215,y:835,t:1527027582592};\\\", \\\"{x:1214,y:836,t:1527027582606};\\\", \\\"{x:1215,y:836,t:1527027582689};\\\", \\\"{x:1225,y:836,t:1527027582706};\\\", \\\"{x:1235,y:834,t:1527027582723};\\\", \\\"{x:1247,y:834,t:1527027582739};\\\", \\\"{x:1253,y:834,t:1527027582755};\\\", \\\"{x:1258,y:833,t:1527027582772};\\\", \\\"{x:1260,y:833,t:1527027582789};\\\", \\\"{x:1261,y:833,t:1527027582806};\\\", \\\"{x:1264,y:832,t:1527027582823};\\\", \\\"{x:1269,y:830,t:1527027582839};\\\", \\\"{x:1275,y:829,t:1527027582857};\\\", \\\"{x:1277,y:829,t:1527027582872};\\\", \\\"{x:1278,y:829,t:1527027583145};\\\", \\\"{x:1280,y:829,t:1527027583156};\\\", \\\"{x:1289,y:829,t:1527027583173};\\\", \\\"{x:1300,y:829,t:1527027583190};\\\", \\\"{x:1314,y:829,t:1527027583205};\\\", \\\"{x:1319,y:829,t:1527027583223};\\\", \\\"{x:1320,y:830,t:1527027583240};\\\", \\\"{x:1322,y:830,t:1527027583312};\\\", \\\"{x:1323,y:829,t:1527027583344};\\\", \\\"{x:1324,y:829,t:1527027583385};\\\", \\\"{x:1325,y:828,t:1527027583408};\\\", \\\"{x:1326,y:828,t:1527027583433};\\\", \\\"{x:1327,y:828,t:1527027583440};\\\", \\\"{x:1328,y:827,t:1527027583536};\\\", \\\"{x:1329,y:827,t:1527027583577};\\\", \\\"{x:1332,y:827,t:1527027584161};\\\", \\\"{x:1338,y:828,t:1527027584174};\\\", \\\"{x:1347,y:831,t:1527027584190};\\\", \\\"{x:1356,y:832,t:1527027584207};\\\", \\\"{x:1366,y:835,t:1527027584225};\\\", \\\"{x:1368,y:835,t:1527027584240};\\\", \\\"{x:1370,y:835,t:1527027584257};\\\", \\\"{x:1372,y:836,t:1527027584274};\\\", \\\"{x:1376,y:836,t:1527027584291};\\\", \\\"{x:1381,y:838,t:1527027584307};\\\", \\\"{x:1386,y:838,t:1527027584324};\\\", \\\"{x:1390,y:838,t:1527027584341};\\\", \\\"{x:1396,y:838,t:1527027584357};\\\", \\\"{x:1401,y:838,t:1527027584374};\\\", \\\"{x:1404,y:838,t:1527027584391};\\\", \\\"{x:1408,y:838,t:1527027584407};\\\", \\\"{x:1412,y:838,t:1527027584426};\\\", \\\"{x:1419,y:838,t:1527027584440};\\\", \\\"{x:1428,y:838,t:1527027584458};\\\", \\\"{x:1435,y:838,t:1527027584474};\\\", \\\"{x:1441,y:838,t:1527027584491};\\\", \\\"{x:1444,y:838,t:1527027584507};\\\", \\\"{x:1446,y:838,t:1527027584524};\\\", \\\"{x:1447,y:838,t:1527027584541};\\\", \\\"{x:1449,y:838,t:1527027584577};\\\", \\\"{x:1450,y:838,t:1527027584601};\\\", \\\"{x:1452,y:838,t:1527027584608};\\\", \\\"{x:1454,y:838,t:1527027584626};\\\", \\\"{x:1456,y:838,t:1527027584640};\\\", \\\"{x:1459,y:838,t:1527027584657};\\\", \\\"{x:1460,y:838,t:1527027584675};\\\", \\\"{x:1462,y:836,t:1527027584696};\\\", \\\"{x:1463,y:836,t:1527027584707};\\\", \\\"{x:1463,y:835,t:1527027584724};\\\", \\\"{x:1467,y:833,t:1527027584741};\\\", \\\"{x:1469,y:832,t:1527027584758};\\\", \\\"{x:1470,y:831,t:1527027584774};\\\", \\\"{x:1474,y:830,t:1527027584792};\\\", \\\"{x:1475,y:830,t:1527027584808};\\\", \\\"{x:1476,y:830,t:1527027584826};\\\", \\\"{x:1476,y:829,t:1527027584864};\\\", \\\"{x:1477,y:828,t:1527027584888};\\\", \\\"{x:1478,y:827,t:1527027584897};\\\", \\\"{x:1479,y:825,t:1527027584920};\\\", \\\"{x:1479,y:823,t:1527027584937};\\\", \\\"{x:1479,y:822,t:1527027584944};\\\", \\\"{x:1479,y:820,t:1527027584958};\\\", \\\"{x:1479,y:816,t:1527027584973};\\\", \\\"{x:1479,y:811,t:1527027584991};\\\", \\\"{x:1479,y:805,t:1527027585009};\\\", \\\"{x:1479,y:799,t:1527027585025};\\\", \\\"{x:1479,y:793,t:1527027585040};\\\", \\\"{x:1479,y:783,t:1527027585058};\\\", \\\"{x:1477,y:771,t:1527027585074};\\\", \\\"{x:1473,y:759,t:1527027585091};\\\", \\\"{x:1467,y:744,t:1527027585108};\\\", \\\"{x:1460,y:727,t:1527027585124};\\\", \\\"{x:1454,y:714,t:1527027585141};\\\", \\\"{x:1451,y:708,t:1527027585158};\\\", \\\"{x:1448,y:699,t:1527027585175};\\\", \\\"{x:1447,y:693,t:1527027585191};\\\", \\\"{x:1444,y:677,t:1527027585208};\\\", \\\"{x:1443,y:670,t:1527027585226};\\\", \\\"{x:1443,y:663,t:1527027585241};\\\", \\\"{x:1441,y:654,t:1527027585258};\\\", \\\"{x:1440,y:648,t:1527027585275};\\\", \\\"{x:1440,y:643,t:1527027585291};\\\", \\\"{x:1440,y:639,t:1527027585308};\\\", \\\"{x:1440,y:635,t:1527027585325};\\\", \\\"{x:1440,y:631,t:1527027585341};\\\", \\\"{x:1440,y:630,t:1527027585358};\\\", \\\"{x:1440,y:627,t:1527027585376};\\\", \\\"{x:1440,y:625,t:1527027585391};\\\", \\\"{x:1440,y:624,t:1527027585408};\\\", \\\"{x:1440,y:622,t:1527027585426};\\\", \\\"{x:1441,y:620,t:1527027585441};\\\", \\\"{x:1440,y:622,t:1527027585593};\\\", \\\"{x:1432,y:625,t:1527027585608};\\\", \\\"{x:1401,y:637,t:1527027585626};\\\", \\\"{x:1378,y:646,t:1527027585642};\\\", \\\"{x:1358,y:651,t:1527027585658};\\\", \\\"{x:1345,y:658,t:1527027585675};\\\", \\\"{x:1343,y:660,t:1527027585692};\\\", \\\"{x:1342,y:661,t:1527027585708};\\\", \\\"{x:1341,y:666,t:1527027585726};\\\", \\\"{x:1337,y:675,t:1527027585742};\\\", \\\"{x:1335,y:683,t:1527027585758};\\\", \\\"{x:1334,y:688,t:1527027585775};\\\", \\\"{x:1334,y:692,t:1527027585793};\\\", \\\"{x:1334,y:694,t:1527027585808};\\\", \\\"{x:1334,y:696,t:1527027585825};\\\", \\\"{x:1335,y:697,t:1527027585843};\\\", \\\"{x:1336,y:698,t:1527027585858};\\\", \\\"{x:1339,y:700,t:1527027585875};\\\", \\\"{x:1344,y:702,t:1527027585892};\\\", \\\"{x:1349,y:704,t:1527027585908};\\\", \\\"{x:1355,y:705,t:1527027585925};\\\", \\\"{x:1357,y:706,t:1527027585942};\\\", \\\"{x:1358,y:705,t:1527027586049};\\\", \\\"{x:1358,y:704,t:1527027586059};\\\", \\\"{x:1358,y:701,t:1527027586075};\\\", \\\"{x:1357,y:699,t:1527027586092};\\\", \\\"{x:1356,y:697,t:1527027586109};\\\", \\\"{x:1356,y:695,t:1527027586144};\\\", \\\"{x:1353,y:695,t:1527027586592};\\\", \\\"{x:1352,y:695,t:1527027586609};\\\", \\\"{x:1350,y:695,t:1527027586625};\\\", \\\"{x:1349,y:695,t:1527027586712};\\\", \\\"{x:1348,y:697,t:1527027586728};\\\", \\\"{x:1347,y:697,t:1527027586741};\\\", \\\"{x:1341,y:701,t:1527027586760};\\\", \\\"{x:1331,y:706,t:1527027586776};\\\", \\\"{x:1320,y:710,t:1527027586792};\\\", \\\"{x:1307,y:713,t:1527027586809};\\\", \\\"{x:1290,y:720,t:1527027586826};\\\", \\\"{x:1276,y:723,t:1527027586842};\\\", \\\"{x:1263,y:727,t:1527027586859};\\\", \\\"{x:1251,y:734,t:1527027586876};\\\", \\\"{x:1242,y:739,t:1527027586892};\\\", \\\"{x:1235,y:745,t:1527027586909};\\\", \\\"{x:1229,y:749,t:1527027586926};\\\", \\\"{x:1224,y:753,t:1527027586943};\\\", \\\"{x:1218,y:753,t:1527027586959};\\\", \\\"{x:1206,y:758,t:1527027586976};\\\", \\\"{x:1196,y:762,t:1527027586992};\\\", \\\"{x:1193,y:765,t:1527027587009};\\\", \\\"{x:1191,y:767,t:1527027587026};\\\", \\\"{x:1190,y:767,t:1527027587043};\\\", \\\"{x:1190,y:768,t:1527027587080};\\\", \\\"{x:1189,y:768,t:1527027587093};\\\", \\\"{x:1188,y:769,t:1527027587109};\\\", \\\"{x:1187,y:769,t:1527027587126};\\\", \\\"{x:1186,y:770,t:1527027587160};\\\", \\\"{x:1188,y:772,t:1527027587736};\\\", \\\"{x:1189,y:772,t:1527027587745};\\\", \\\"{x:1193,y:773,t:1527027587761};\\\", \\\"{x:1195,y:773,t:1527027587777};\\\", \\\"{x:1198,y:773,t:1527027587793};\\\", \\\"{x:1203,y:774,t:1527027587810};\\\", \\\"{x:1205,y:774,t:1527027587827};\\\", \\\"{x:1207,y:774,t:1527027587865};\\\", \\\"{x:1208,y:774,t:1527027587877};\\\", \\\"{x:1210,y:774,t:1527027587920};\\\", \\\"{x:1211,y:774,t:1527027587936};\\\", \\\"{x:1213,y:774,t:1527027587961};\\\", \\\"{x:1214,y:774,t:1527027587977};\\\", \\\"{x:1216,y:774,t:1527027587993};\\\", \\\"{x:1220,y:774,t:1527027588010};\\\", \\\"{x:1226,y:775,t:1527027588027};\\\", \\\"{x:1228,y:775,t:1527027588043};\\\", \\\"{x:1231,y:775,t:1527027588060};\\\", \\\"{x:1232,y:775,t:1527027588080};\\\", \\\"{x:1233,y:775,t:1527027588093};\\\", \\\"{x:1239,y:775,t:1527027588110};\\\", \\\"{x:1243,y:775,t:1527027588127};\\\", \\\"{x:1248,y:775,t:1527027588144};\\\", \\\"{x:1250,y:775,t:1527027588160};\\\", \\\"{x:1250,y:774,t:1527027588184};\\\", \\\"{x:1251,y:774,t:1527027588208};\\\", \\\"{x:1251,y:773,t:1527027588216};\\\", \\\"{x:1251,y:772,t:1527027588233};\\\", \\\"{x:1252,y:772,t:1527027588377};\\\", \\\"{x:1253,y:769,t:1527027588457};\\\", \\\"{x:1255,y:768,t:1527027588472};\\\", \\\"{x:1256,y:768,t:1527027588481};\\\", \\\"{x:1258,y:768,t:1527027588495};\\\", \\\"{x:1262,y:766,t:1527027588510};\\\", \\\"{x:1267,y:765,t:1527027588527};\\\", \\\"{x:1276,y:762,t:1527027588544};\\\", \\\"{x:1279,y:761,t:1527027588561};\\\", \\\"{x:1282,y:760,t:1527027588577};\\\", \\\"{x:1284,y:759,t:1527027588601};\\\", \\\"{x:1285,y:759,t:1527027588610};\\\", \\\"{x:1287,y:758,t:1527027588627};\\\", \\\"{x:1292,y:758,t:1527027588644};\\\", \\\"{x:1296,y:758,t:1527027588660};\\\", \\\"{x:1300,y:758,t:1527027588677};\\\", \\\"{x:1301,y:757,t:1527027588694};\\\", \\\"{x:1303,y:757,t:1527027588760};\\\", \\\"{x:1308,y:757,t:1527027588778};\\\", \\\"{x:1311,y:757,t:1527027588794};\\\", \\\"{x:1314,y:757,t:1527027588811};\\\", \\\"{x:1315,y:757,t:1527027588827};\\\", \\\"{x:1317,y:758,t:1527027588848};\\\", \\\"{x:1318,y:759,t:1527027589033};\\\", \\\"{x:1321,y:759,t:1527027589048};\\\", \\\"{x:1322,y:759,t:1527027589062};\\\", \\\"{x:1325,y:759,t:1527027589078};\\\", \\\"{x:1329,y:759,t:1527027589094};\\\", \\\"{x:1334,y:759,t:1527027589112};\\\", \\\"{x:1343,y:759,t:1527027589128};\\\", \\\"{x:1350,y:759,t:1527027589145};\\\", \\\"{x:1358,y:759,t:1527027589162};\\\", \\\"{x:1368,y:759,t:1527027589178};\\\", \\\"{x:1375,y:759,t:1527027589194};\\\", \\\"{x:1384,y:759,t:1527027589211};\\\", \\\"{x:1389,y:759,t:1527027589229};\\\", \\\"{x:1393,y:759,t:1527027589244};\\\", \\\"{x:1396,y:759,t:1527027589261};\\\", \\\"{x:1397,y:759,t:1527027589496};\\\", \\\"{x:1396,y:759,t:1527027589511};\\\", \\\"{x:1388,y:759,t:1527027589528};\\\", \\\"{x:1381,y:761,t:1527027589544};\\\", \\\"{x:1378,y:762,t:1527027589561};\\\", \\\"{x:1377,y:763,t:1527027589578};\\\", \\\"{x:1376,y:763,t:1527027589656};\\\", \\\"{x:1375,y:763,t:1527027589664};\\\", \\\"{x:1374,y:763,t:1527027589678};\\\", \\\"{x:1374,y:762,t:1527027590041};\\\", \\\"{x:1373,y:762,t:1527027591305};\\\", \\\"{x:1372,y:762,t:1527027591328};\\\", \\\"{x:1371,y:762,t:1527027591346};\\\", \\\"{x:1370,y:762,t:1527027591363};\\\", \\\"{x:1369,y:762,t:1527027591392};\\\", \\\"{x:1368,y:762,t:1527027591409};\\\", \\\"{x:1367,y:762,t:1527027591432};\\\", \\\"{x:1365,y:762,t:1527027591445};\\\", \\\"{x:1364,y:762,t:1527027591462};\\\", \\\"{x:1363,y:762,t:1527027591479};\\\", \\\"{x:1361,y:762,t:1527027591519};\\\", \\\"{x:1359,y:762,t:1527027591528};\\\", \\\"{x:1357,y:762,t:1527027591546};\\\", \\\"{x:1356,y:762,t:1527027591563};\\\", \\\"{x:1355,y:762,t:1527027591640};\\\", \\\"{x:1354,y:762,t:1527027591648};\\\", \\\"{x:1352,y:762,t:1527027591663};\\\", \\\"{x:1349,y:763,t:1527027591679};\\\", \\\"{x:1348,y:763,t:1527027591920};\\\", \\\"{x:1348,y:765,t:1527027591936};\\\", \\\"{x:1351,y:766,t:1527027591952};\\\", \\\"{x:1354,y:767,t:1527027591964};\\\", \\\"{x:1359,y:770,t:1527027591980};\\\", \\\"{x:1364,y:771,t:1527027591996};\\\", \\\"{x:1369,y:773,t:1527027592013};\\\", \\\"{x:1372,y:773,t:1527027592031};\\\", \\\"{x:1375,y:773,t:1527027592046};\\\", \\\"{x:1377,y:774,t:1527027592064};\\\", \\\"{x:1378,y:774,t:1527027592080};\\\", \\\"{x:1384,y:774,t:1527027592096};\\\", \\\"{x:1390,y:774,t:1527027592114};\\\", \\\"{x:1397,y:774,t:1527027592131};\\\", \\\"{x:1405,y:774,t:1527027592146};\\\", \\\"{x:1409,y:774,t:1527027592164};\\\", \\\"{x:1412,y:774,t:1527027592181};\\\", \\\"{x:1414,y:774,t:1527027592201};\\\", \\\"{x:1415,y:774,t:1527027592216};\\\", \\\"{x:1416,y:773,t:1527027592231};\\\", \\\"{x:1419,y:772,t:1527027592247};\\\", \\\"{x:1421,y:770,t:1527027592263};\\\", \\\"{x:1421,y:769,t:1527027592280};\\\", \\\"{x:1421,y:768,t:1527027592313};\\\", \\\"{x:1419,y:767,t:1527027592331};\\\", \\\"{x:1418,y:766,t:1527027592348};\\\", \\\"{x:1415,y:765,t:1527027592363};\\\", \\\"{x:1414,y:765,t:1527027592380};\\\", \\\"{x:1413,y:764,t:1527027592465};\\\", \\\"{x:1412,y:764,t:1527027592480};\\\", \\\"{x:1413,y:764,t:1527027592616};\\\", \\\"{x:1415,y:764,t:1527027592630};\\\", \\\"{x:1418,y:764,t:1527027592647};\\\", \\\"{x:1425,y:764,t:1527027592664};\\\", \\\"{x:1434,y:765,t:1527027592680};\\\", \\\"{x:1440,y:766,t:1527027592697};\\\", \\\"{x:1444,y:767,t:1527027592715};\\\", \\\"{x:1448,y:767,t:1527027592731};\\\", \\\"{x:1449,y:767,t:1527027592748};\\\", \\\"{x:1450,y:767,t:1527027592768};\\\", \\\"{x:1452,y:767,t:1527027592781};\\\", \\\"{x:1453,y:767,t:1527027592798};\\\", \\\"{x:1456,y:767,t:1527027592815};\\\", \\\"{x:1458,y:767,t:1527027592830};\\\", \\\"{x:1461,y:767,t:1527027592847};\\\", \\\"{x:1462,y:767,t:1527027592864};\\\", \\\"{x:1463,y:767,t:1527027592888};\\\", \\\"{x:1465,y:767,t:1527027592904};\\\", \\\"{x:1466,y:767,t:1527027592914};\\\", \\\"{x:1468,y:767,t:1527027592931};\\\", \\\"{x:1471,y:767,t:1527027592948};\\\", \\\"{x:1472,y:767,t:1527027592964};\\\", \\\"{x:1474,y:767,t:1527027593313};\\\", \\\"{x:1475,y:767,t:1527027593320};\\\", \\\"{x:1477,y:767,t:1527027593331};\\\", \\\"{x:1479,y:767,t:1527027593348};\\\", \\\"{x:1481,y:767,t:1527027593364};\\\", \\\"{x:1484,y:767,t:1527027593381};\\\", \\\"{x:1486,y:767,t:1527027593400};\\\", \\\"{x:1488,y:767,t:1527027593414};\\\", \\\"{x:1491,y:766,t:1527027593431};\\\", \\\"{x:1496,y:766,t:1527027593448};\\\", \\\"{x:1505,y:764,t:1527027593465};\\\", \\\"{x:1509,y:763,t:1527027593482};\\\", \\\"{x:1510,y:762,t:1527027593497};\\\", \\\"{x:1512,y:761,t:1527027593544};\\\", \\\"{x:1513,y:760,t:1527027593560};\\\", \\\"{x:1514,y:760,t:1527027593576};\\\", \\\"{x:1515,y:760,t:1527027593584};\\\", \\\"{x:1516,y:759,t:1527027593598};\\\", \\\"{x:1517,y:759,t:1527027593614};\\\", \\\"{x:1516,y:759,t:1527027594625};\\\", \\\"{x:1513,y:759,t:1527027594632};\\\", \\\"{x:1506,y:761,t:1527027594650};\\\", \\\"{x:1498,y:762,t:1527027594666};\\\", \\\"{x:1485,y:763,t:1527027594683};\\\", \\\"{x:1470,y:766,t:1527027594699};\\\", \\\"{x:1452,y:767,t:1527027594716};\\\", \\\"{x:1428,y:771,t:1527027594733};\\\", \\\"{x:1409,y:772,t:1527027594748};\\\", \\\"{x:1394,y:772,t:1527027594765};\\\", \\\"{x:1388,y:772,t:1527027594782};\\\", \\\"{x:1385,y:772,t:1527027594798};\\\", \\\"{x:1384,y:772,t:1527027594816};\\\", \\\"{x:1377,y:772,t:1527027594832};\\\", \\\"{x:1376,y:772,t:1527027594848};\\\", \\\"{x:1379,y:772,t:1527027594951};\\\", \\\"{x:1382,y:772,t:1527027594965};\\\", \\\"{x:1388,y:771,t:1527027594982};\\\", \\\"{x:1391,y:770,t:1527027594999};\\\", \\\"{x:1395,y:768,t:1527027595015};\\\", \\\"{x:1398,y:768,t:1527027595032};\\\", \\\"{x:1400,y:766,t:1527027595049};\\\", \\\"{x:1403,y:765,t:1527027595065};\\\", \\\"{x:1406,y:764,t:1527027595082};\\\", \\\"{x:1408,y:764,t:1527027595099};\\\", \\\"{x:1409,y:764,t:1527027595115};\\\", \\\"{x:1409,y:763,t:1527027595132};\\\", \\\"{x:1410,y:762,t:1527027595705};\\\", \\\"{x:1411,y:762,t:1527027595716};\\\", \\\"{x:1412,y:762,t:1527027595737};\\\", \\\"{x:1414,y:762,t:1527027595817};\\\", \\\"{x:1415,y:762,t:1527027596137};\\\", \\\"{x:1417,y:762,t:1527027596150};\\\", \\\"{x:1418,y:762,t:1527027596166};\\\", \\\"{x:1422,y:762,t:1527027596183};\\\", \\\"{x:1425,y:763,t:1527027596200};\\\", \\\"{x:1429,y:764,t:1527027596217};\\\", \\\"{x:1431,y:764,t:1527027596234};\\\", \\\"{x:1435,y:764,t:1527027596250};\\\", \\\"{x:1436,y:764,t:1527027596267};\\\", \\\"{x:1438,y:764,t:1527027596283};\\\", \\\"{x:1440,y:764,t:1527027596300};\\\", \\\"{x:1441,y:764,t:1527027596316};\\\", \\\"{x:1443,y:764,t:1527027596334};\\\", \\\"{x:1445,y:764,t:1527027596350};\\\", \\\"{x:1449,y:765,t:1527027596366};\\\", \\\"{x:1454,y:766,t:1527027596383};\\\", \\\"{x:1462,y:767,t:1527027596399};\\\", \\\"{x:1465,y:767,t:1527027596416};\\\", \\\"{x:1467,y:767,t:1527027596433};\\\", \\\"{x:1469,y:767,t:1527027596450};\\\", \\\"{x:1471,y:767,t:1527027596466};\\\", \\\"{x:1472,y:767,t:1527027596483};\\\", \\\"{x:1474,y:767,t:1527027596500};\\\", \\\"{x:1475,y:767,t:1527027596517};\\\", \\\"{x:1476,y:767,t:1527027596543};\\\", \\\"{x:1477,y:767,t:1527027596584};\\\", \\\"{x:1478,y:767,t:1527027596600};\\\", \\\"{x:1478,y:766,t:1527027596632};\\\", \\\"{x:1478,y:765,t:1527027596705};\\\", \\\"{x:1478,y:764,t:1527027597041};\\\", \\\"{x:1478,y:763,t:1527027597073};\\\", \\\"{x:1479,y:763,t:1527027597084};\\\", \\\"{x:1481,y:762,t:1527027597101};\\\", \\\"{x:1483,y:762,t:1527027597118};\\\", \\\"{x:1485,y:762,t:1527027597134};\\\", \\\"{x:1487,y:762,t:1527027597151};\\\", \\\"{x:1488,y:762,t:1527027597168};\\\", \\\"{x:1496,y:762,t:1527027597184};\\\", \\\"{x:1499,y:762,t:1527027597201};\\\", \\\"{x:1502,y:762,t:1527027597218};\\\", \\\"{x:1503,y:762,t:1527027597235};\\\", \\\"{x:1505,y:762,t:1527027597250};\\\", \\\"{x:1508,y:762,t:1527027597268};\\\", \\\"{x:1511,y:762,t:1527027597285};\\\", \\\"{x:1515,y:762,t:1527027597299};\\\", \\\"{x:1518,y:762,t:1527027597317};\\\", \\\"{x:1522,y:762,t:1527027597334};\\\", \\\"{x:1527,y:762,t:1527027597350};\\\", \\\"{x:1531,y:762,t:1527027597367};\\\", \\\"{x:1533,y:762,t:1527027597384};\\\", \\\"{x:1534,y:762,t:1527027597464};\\\", \\\"{x:1536,y:762,t:1527027597472};\\\", \\\"{x:1537,y:762,t:1527027597488};\\\", \\\"{x:1538,y:762,t:1527027597500};\\\", \\\"{x:1539,y:762,t:1527027597518};\\\", \\\"{x:1540,y:761,t:1527027597561};\\\", \\\"{x:1542,y:761,t:1527027597601};\\\", \\\"{x:1543,y:761,t:1527027597617};\\\", \\\"{x:1545,y:761,t:1527027597635};\\\", \\\"{x:1545,y:760,t:1527027600985};\\\", \\\"{x:1543,y:760,t:1527027601001};\\\", \\\"{x:1539,y:760,t:1527027601008};\\\", \\\"{x:1535,y:760,t:1527027601021};\\\", \\\"{x:1517,y:760,t:1527027601038};\\\", \\\"{x:1481,y:760,t:1527027601055};\\\", \\\"{x:1401,y:760,t:1527027601071};\\\", \\\"{x:1293,y:760,t:1527027601088};\\\", \\\"{x:1182,y:743,t:1527027601103};\\\", \\\"{x:1028,y:709,t:1527027601120};\\\", \\\"{x:942,y:686,t:1527027601138};\\\", \\\"{x:864,y:671,t:1527027601154};\\\", \\\"{x:802,y:651,t:1527027601171};\\\", \\\"{x:730,y:631,t:1527027601188};\\\", \\\"{x:671,y:614,t:1527027601203};\\\", \\\"{x:620,y:595,t:1527027601220};\\\", \\\"{x:581,y:585,t:1527027601237};\\\", \\\"{x:556,y:578,t:1527027601254};\\\", \\\"{x:543,y:574,t:1527027601269};\\\", \\\"{x:536,y:571,t:1527027601287};\\\", \\\"{x:530,y:569,t:1527027601303};\\\", \\\"{x:523,y:565,t:1527027601320};\\\", \\\"{x:502,y:557,t:1527027601337};\\\", \\\"{x:460,y:541,t:1527027601354};\\\", \\\"{x:413,y:529,t:1527027601370};\\\", \\\"{x:384,y:520,t:1527027601388};\\\", \\\"{x:373,y:516,t:1527027601404};\\\", \\\"{x:367,y:514,t:1527027601420};\\\", \\\"{x:366,y:513,t:1527027601439};\\\", \\\"{x:365,y:513,t:1527027601455};\\\", \\\"{x:363,y:512,t:1527027601470};\\\", \\\"{x:358,y:511,t:1527027601487};\\\", \\\"{x:354,y:510,t:1527027601503};\\\", \\\"{x:348,y:510,t:1527027601520};\\\", \\\"{x:343,y:510,t:1527027601537};\\\", \\\"{x:341,y:510,t:1527027601554};\\\", \\\"{x:339,y:510,t:1527027601570};\\\", \\\"{x:334,y:511,t:1527027601588};\\\", \\\"{x:327,y:514,t:1527027601604};\\\", \\\"{x:311,y:519,t:1527027601623};\\\", \\\"{x:296,y:520,t:1527027601637};\\\", \\\"{x:282,y:520,t:1527027601654};\\\", \\\"{x:271,y:520,t:1527027601671};\\\", \\\"{x:266,y:520,t:1527027601687};\\\", \\\"{x:260,y:520,t:1527027601704};\\\", \\\"{x:248,y:520,t:1527027601721};\\\", \\\"{x:233,y:520,t:1527027601737};\\\", \\\"{x:217,y:520,t:1527027601754};\\\", \\\"{x:208,y:520,t:1527027601772};\\\", \\\"{x:200,y:520,t:1527027601787};\\\", \\\"{x:197,y:520,t:1527027601804};\\\", \\\"{x:196,y:520,t:1527027601821};\\\", \\\"{x:194,y:520,t:1527027601837};\\\", \\\"{x:189,y:522,t:1527027601854};\\\", \\\"{x:177,y:528,t:1527027601872};\\\", \\\"{x:169,y:533,t:1527027601887};\\\", \\\"{x:164,y:536,t:1527027601905};\\\", \\\"{x:161,y:538,t:1527027601921};\\\", \\\"{x:160,y:539,t:1527027601976};\\\", \\\"{x:159,y:540,t:1527027601991};\\\", \\\"{x:157,y:540,t:1527027602005};\\\", \\\"{x:155,y:540,t:1527027602021};\\\", \\\"{x:155,y:541,t:1527027602255};\\\", \\\"{x:158,y:543,t:1527027602271};\\\", \\\"{x:162,y:544,t:1527027602288};\\\", \\\"{x:171,y:547,t:1527027602304};\\\", \\\"{x:179,y:548,t:1527027602321};\\\", \\\"{x:186,y:550,t:1527027602338};\\\", \\\"{x:191,y:553,t:1527027602354};\\\", \\\"{x:200,y:559,t:1527027602372};\\\", \\\"{x:211,y:567,t:1527027602388};\\\", \\\"{x:235,y:577,t:1527027602405};\\\", \\\"{x:275,y:594,t:1527027602422};\\\", \\\"{x:324,y:615,t:1527027602438};\\\", \\\"{x:378,y:637,t:1527027602455};\\\", \\\"{x:399,y:647,t:1527027602472};\\\", \\\"{x:417,y:658,t:1527027602488};\\\", \\\"{x:434,y:666,t:1527027602506};\\\", \\\"{x:457,y:678,t:1527027602522};\\\", \\\"{x:484,y:689,t:1527027602538};\\\", \\\"{x:524,y:700,t:1527027602555};\\\", \\\"{x:574,y:714,t:1527027602571};\\\", \\\"{x:620,y:724,t:1527027602588};\\\", \\\"{x:671,y:740,t:1527027602606};\\\", \\\"{x:711,y:749,t:1527027602621};\\\", \\\"{x:742,y:758,t:1527027602638};\\\", \\\"{x:788,y:771,t:1527027602655};\\\", \\\"{x:807,y:774,t:1527027602671};\\\", \\\"{x:866,y:780,t:1527027602688};\\\", \\\"{x:903,y:786,t:1527027602705};\\\", \\\"{x:951,y:793,t:1527027602723};\\\", \\\"{x:1003,y:798,t:1527027602739};\\\", \\\"{x:1046,y:799,t:1527027602756};\\\", \\\"{x:1097,y:801,t:1527027602772};\\\", \\\"{x:1150,y:801,t:1527027602789};\\\", \\\"{x:1195,y:801,t:1527027602806};\\\", \\\"{x:1235,y:802,t:1527027602823};\\\", \\\"{x:1275,y:805,t:1527027602838};\\\", \\\"{x:1340,y:805,t:1527027602856};\\\", \\\"{x:1376,y:805,t:1527027602873};\\\", \\\"{x:1405,y:805,t:1527027602888};\\\", \\\"{x:1430,y:805,t:1527027602906};\\\", \\\"{x:1442,y:805,t:1527027602923};\\\", \\\"{x:1447,y:804,t:1527027602939};\\\", \\\"{x:1451,y:804,t:1527027602956};\\\", \\\"{x:1452,y:804,t:1527027602973};\\\", \\\"{x:1454,y:802,t:1527027602990};\\\", \\\"{x:1456,y:801,t:1527027603006};\\\", \\\"{x:1458,y:799,t:1527027603023};\\\", \\\"{x:1460,y:799,t:1527027603040};\\\", \\\"{x:1461,y:798,t:1527027603056};\\\", \\\"{x:1461,y:797,t:1527027603096};\\\", \\\"{x:1462,y:797,t:1527027603106};\\\", \\\"{x:1463,y:796,t:1527027603123};\\\", \\\"{x:1465,y:794,t:1527027603140};\\\", \\\"{x:1469,y:791,t:1527027603156};\\\", \\\"{x:1474,y:788,t:1527027603172};\\\", \\\"{x:1482,y:784,t:1527027603189};\\\", \\\"{x:1494,y:779,t:1527027603206};\\\", \\\"{x:1506,y:776,t:1527027603223};\\\", \\\"{x:1514,y:773,t:1527027603240};\\\", \\\"{x:1520,y:770,t:1527027603256};\\\", \\\"{x:1527,y:767,t:1527027603272};\\\", \\\"{x:1531,y:765,t:1527027603290};\\\", \\\"{x:1534,y:765,t:1527027603307};\\\", \\\"{x:1536,y:764,t:1527027603328};\\\", \\\"{x:1538,y:764,t:1527027603673};\\\", \\\"{x:1539,y:763,t:1527027603690};\\\", \\\"{x:1540,y:763,t:1527027603736};\\\", \\\"{x:1538,y:761,t:1527027603833};\\\", \\\"{x:1529,y:759,t:1527027603840};\\\", \\\"{x:1508,y:756,t:1527027603857};\\\", \\\"{x:1482,y:753,t:1527027603874};\\\", \\\"{x:1444,y:753,t:1527027603890};\\\", \\\"{x:1396,y:753,t:1527027603907};\\\", \\\"{x:1357,y:753,t:1527027603924};\\\", \\\"{x:1333,y:753,t:1527027603941};\\\", \\\"{x:1317,y:752,t:1527027603957};\\\", \\\"{x:1316,y:752,t:1527027603974};\\\", \\\"{x:1315,y:752,t:1527027604057};\\\", \\\"{x:1314,y:756,t:1527027604073};\\\", \\\"{x:1314,y:760,t:1527027604091};\\\", \\\"{x:1314,y:763,t:1527027604108};\\\", \\\"{x:1314,y:765,t:1527027604124};\\\", \\\"{x:1314,y:767,t:1527027604141};\\\", \\\"{x:1316,y:769,t:1527027604158};\\\", \\\"{x:1318,y:771,t:1527027604175};\\\", \\\"{x:1321,y:773,t:1527027604191};\\\", \\\"{x:1325,y:774,t:1527027604208};\\\", \\\"{x:1330,y:775,t:1527027604225};\\\", \\\"{x:1334,y:775,t:1527027604241};\\\", \\\"{x:1338,y:775,t:1527027604258};\\\", \\\"{x:1342,y:775,t:1527027604275};\\\", \\\"{x:1347,y:772,t:1527027604291};\\\", \\\"{x:1352,y:770,t:1527027604308};\\\", \\\"{x:1355,y:768,t:1527027604325};\\\", \\\"{x:1357,y:767,t:1527027604341};\\\", \\\"{x:1359,y:766,t:1527027604358};\\\", \\\"{x:1359,y:765,t:1527027604392};\\\", \\\"{x:1359,y:763,t:1527027604585};\\\", \\\"{x:1359,y:762,t:1527027604593};\\\", \\\"{x:1359,y:759,t:1527027604608};\\\", \\\"{x:1359,y:755,t:1527027604625};\\\", \\\"{x:1357,y:750,t:1527027604642};\\\", \\\"{x:1355,y:748,t:1527027604657};\\\", \\\"{x:1355,y:746,t:1527027604675};\\\", \\\"{x:1354,y:744,t:1527027604692};\\\", \\\"{x:1353,y:742,t:1527027604708};\\\", \\\"{x:1353,y:739,t:1527027604725};\\\", \\\"{x:1352,y:736,t:1527027604742};\\\", \\\"{x:1352,y:730,t:1527027604759};\\\", \\\"{x:1349,y:725,t:1527027604775};\\\", \\\"{x:1349,y:721,t:1527027604792};\\\", \\\"{x:1346,y:714,t:1527027604808};\\\", \\\"{x:1345,y:707,t:1527027604826};\\\", \\\"{x:1343,y:702,t:1527027604842};\\\", \\\"{x:1342,y:702,t:1527027604859};\\\", \\\"{x:1342,y:701,t:1527027604929};\\\", \\\"{x:1338,y:701,t:1527027604942};\\\", \\\"{x:1327,y:714,t:1527027604959};\\\", \\\"{x:1312,y:729,t:1527027604974};\\\", \\\"{x:1301,y:741,t:1527027604992};\\\", \\\"{x:1298,y:747,t:1527027605009};\\\", \\\"{x:1290,y:759,t:1527027605025};\\\", \\\"{x:1284,y:768,t:1527027605042};\\\", \\\"{x:1276,y:780,t:1527027605059};\\\", \\\"{x:1268,y:790,t:1527027605076};\\\", \\\"{x:1261,y:800,t:1527027605092};\\\", \\\"{x:1258,y:804,t:1527027605109};\\\", \\\"{x:1254,y:811,t:1527027605127};\\\", \\\"{x:1254,y:815,t:1527027605142};\\\", \\\"{x:1252,y:818,t:1527027605158};\\\", \\\"{x:1248,y:824,t:1527027605175};\\\", \\\"{x:1245,y:827,t:1527027605191};\\\", \\\"{x:1241,y:831,t:1527027605208};\\\", \\\"{x:1236,y:834,t:1527027605226};\\\", \\\"{x:1234,y:835,t:1527027605242};\\\", \\\"{x:1232,y:837,t:1527027605259};\\\", \\\"{x:1231,y:837,t:1527027605275};\\\", \\\"{x:1229,y:838,t:1527027605293};\\\", \\\"{x:1226,y:838,t:1527027605308};\\\", \\\"{x:1224,y:838,t:1527027605325};\\\", \\\"{x:1220,y:839,t:1527027605343};\\\", \\\"{x:1218,y:839,t:1527027605359};\\\", \\\"{x:1216,y:839,t:1527027605376};\\\", \\\"{x:1217,y:839,t:1527027605609};\\\", \\\"{x:1221,y:839,t:1527027605626};\\\", \\\"{x:1225,y:841,t:1527027605643};\\\", \\\"{x:1230,y:841,t:1527027605660};\\\", \\\"{x:1235,y:841,t:1527027605676};\\\", \\\"{x:1242,y:841,t:1527027605693};\\\", \\\"{x:1252,y:841,t:1527027605710};\\\", \\\"{x:1260,y:841,t:1527027605727};\\\", \\\"{x:1270,y:841,t:1527027605743};\\\", \\\"{x:1280,y:841,t:1527027605760};\\\", \\\"{x:1286,y:841,t:1527027605777};\\\", \\\"{x:1289,y:841,t:1527027605793};\\\", \\\"{x:1291,y:841,t:1527027605810};\\\", \\\"{x:1292,y:841,t:1527027605827};\\\", \\\"{x:1295,y:840,t:1527027605843};\\\", \\\"{x:1296,y:840,t:1527027605860};\\\", \\\"{x:1297,y:840,t:1527027605877};\\\", \\\"{x:1299,y:840,t:1527027605893};\\\", \\\"{x:1300,y:838,t:1527027606081};\\\", \\\"{x:1301,y:838,t:1527027606094};\\\", \\\"{x:1305,y:838,t:1527027606110};\\\", \\\"{x:1312,y:837,t:1527027606127};\\\", \\\"{x:1319,y:836,t:1527027606144};\\\", \\\"{x:1322,y:835,t:1527027606160};\\\", \\\"{x:1323,y:835,t:1527027606177};\\\", \\\"{x:1326,y:835,t:1527027606194};\\\", \\\"{x:1329,y:834,t:1527027606210};\\\", \\\"{x:1334,y:833,t:1527027606227};\\\", \\\"{x:1338,y:830,t:1527027606244};\\\", \\\"{x:1342,y:830,t:1527027606260};\\\", \\\"{x:1345,y:830,t:1527027606576};\\\", \\\"{x:1349,y:830,t:1527027606594};\\\", \\\"{x:1355,y:830,t:1527027606610};\\\", \\\"{x:1358,y:830,t:1527027606628};\\\", \\\"{x:1362,y:830,t:1527027606643};\\\", \\\"{x:1367,y:830,t:1527027606661};\\\", \\\"{x:1377,y:832,t:1527027606679};\\\", \\\"{x:1390,y:833,t:1527027606694};\\\", \\\"{x:1400,y:833,t:1527027606711};\\\", \\\"{x:1408,y:835,t:1527027606728};\\\", \\\"{x:1409,y:836,t:1527027606745};\\\", \\\"{x:1410,y:836,t:1527027606761};\\\", \\\"{x:1412,y:837,t:1527027606784};\\\", \\\"{x:1414,y:837,t:1527027606795};\\\", \\\"{x:1417,y:837,t:1527027606811};\\\", \\\"{x:1422,y:837,t:1527027606828};\\\", \\\"{x:1428,y:839,t:1527027606845};\\\", \\\"{x:1437,y:840,t:1527027606861};\\\", \\\"{x:1446,y:841,t:1527027606878};\\\", \\\"{x:1451,y:841,t:1527027606895};\\\", \\\"{x:1453,y:841,t:1527027606911};\\\", \\\"{x:1454,y:841,t:1527027606929};\\\", \\\"{x:1456,y:841,t:1527027606945};\\\", \\\"{x:1460,y:841,t:1527027606962};\\\", \\\"{x:1462,y:841,t:1527027606979};\\\", \\\"{x:1463,y:841,t:1527027606995};\\\", \\\"{x:1458,y:843,t:1527027607097};\\\", \\\"{x:1451,y:846,t:1527027607112};\\\", \\\"{x:1438,y:853,t:1527027607128};\\\", \\\"{x:1427,y:858,t:1527027607145};\\\", \\\"{x:1412,y:860,t:1527027607162};\\\", \\\"{x:1402,y:865,t:1527027607178};\\\", \\\"{x:1395,y:868,t:1527027607195};\\\", \\\"{x:1392,y:870,t:1527027607212};\\\", \\\"{x:1390,y:872,t:1527027607229};\\\", \\\"{x:1389,y:874,t:1527027607245};\\\", \\\"{x:1386,y:878,t:1527027607262};\\\", \\\"{x:1385,y:880,t:1527027607279};\\\", \\\"{x:1383,y:883,t:1527027607295};\\\", \\\"{x:1382,y:884,t:1527027607312};\\\", \\\"{x:1382,y:885,t:1527027607344};\\\", \\\"{x:1381,y:886,t:1527027607362};\\\", \\\"{x:1381,y:888,t:1527027607379};\\\", \\\"{x:1380,y:888,t:1527027607395};\\\", \\\"{x:1380,y:889,t:1527027607427};\\\", \\\"{x:1379,y:891,t:1527027607440};\\\", \\\"{x:1378,y:891,t:1527027607456};\\\", \\\"{x:1377,y:892,t:1527027607465};\\\", \\\"{x:1375,y:894,t:1527027607497};\\\", \\\"{x:1378,y:894,t:1527027607808};\\\", \\\"{x:1380,y:894,t:1527027607829};\\\", \\\"{x:1383,y:894,t:1527027607845};\\\", \\\"{x:1389,y:893,t:1527027607864};\\\", \\\"{x:1392,y:893,t:1527027607879};\\\", \\\"{x:1397,y:893,t:1527027607896};\\\", \\\"{x:1399,y:893,t:1527027607913};\\\", \\\"{x:1402,y:891,t:1527027607929};\\\", \\\"{x:1404,y:891,t:1527027607946};\\\", \\\"{x:1408,y:891,t:1527027607963};\\\", \\\"{x:1411,y:891,t:1527027607980};\\\", \\\"{x:1415,y:890,t:1527027607996};\\\", \\\"{x:1418,y:890,t:1527027608013};\\\", \\\"{x:1421,y:890,t:1527027608030};\\\", \\\"{x:1425,y:889,t:1527027608046};\\\", \\\"{x:1430,y:888,t:1527027608064};\\\", \\\"{x:1433,y:887,t:1527027608080};\\\", \\\"{x:1434,y:887,t:1527027608097};\\\", \\\"{x:1435,y:887,t:1527027608265};\\\", \\\"{x:1436,y:887,t:1527027608280};\\\", \\\"{x:1438,y:887,t:1527027608304};\\\", \\\"{x:1439,y:887,t:1527027608320};\\\", \\\"{x:1440,y:887,t:1527027608330};\\\", \\\"{x:1441,y:887,t:1527027608376};\\\", \\\"{x:1441,y:888,t:1527027608417};\\\", \\\"{x:1443,y:888,t:1527027608760};\\\", \\\"{x:1444,y:888,t:1527027608776};\\\", \\\"{x:1444,y:887,t:1527027608785};\\\", \\\"{x:1445,y:886,t:1527027608800};\\\", \\\"{x:1446,y:886,t:1527027608816};\\\", \\\"{x:1446,y:885,t:1527027608831};\\\", \\\"{x:1446,y:881,t:1527027608847};\\\", \\\"{x:1448,y:877,t:1527027608865};\\\", \\\"{x:1448,y:870,t:1527027608880};\\\", \\\"{x:1448,y:860,t:1527027608897};\\\", \\\"{x:1448,y:854,t:1527027608914};\\\", \\\"{x:1448,y:848,t:1527027608931};\\\", \\\"{x:1449,y:841,t:1527027608948};\\\", \\\"{x:1450,y:836,t:1527027608964};\\\", \\\"{x:1454,y:825,t:1527027608981};\\\", \\\"{x:1458,y:814,t:1527027608998};\\\", \\\"{x:1460,y:803,t:1527027609015};\\\", \\\"{x:1467,y:788,t:1527027609032};\\\", \\\"{x:1469,y:777,t:1527027609048};\\\", \\\"{x:1475,y:762,t:1527027609064};\\\", \\\"{x:1477,y:755,t:1527027609081};\\\", \\\"{x:1480,y:747,t:1527027609099};\\\", \\\"{x:1484,y:744,t:1527027609114};\\\", \\\"{x:1485,y:743,t:1527027609131};\\\", \\\"{x:1490,y:740,t:1527027609148};\\\", \\\"{x:1491,y:740,t:1527027609164};\\\", \\\"{x:1494,y:739,t:1527027609181};\\\", \\\"{x:1495,y:739,t:1527027609200};\\\", \\\"{x:1498,y:739,t:1527027609216};\\\", \\\"{x:1501,y:743,t:1527027609231};\\\", \\\"{x:1509,y:761,t:1527027609249};\\\", \\\"{x:1515,y:776,t:1527027609265};\\\", \\\"{x:1516,y:782,t:1527027609281};\\\", \\\"{x:1518,y:788,t:1527027609299};\\\", \\\"{x:1518,y:790,t:1527027609315};\\\", \\\"{x:1519,y:791,t:1527027609331};\\\", \\\"{x:1519,y:792,t:1527027609376};\\\", \\\"{x:1519,y:793,t:1527027609384};\\\", \\\"{x:1519,y:794,t:1527027609398};\\\", \\\"{x:1519,y:796,t:1527027609415};\\\", \\\"{x:1519,y:795,t:1527027609497};\\\", \\\"{x:1519,y:793,t:1527027609504};\\\", \\\"{x:1519,y:790,t:1527027609515};\\\", \\\"{x:1515,y:781,t:1527027609532};\\\", \\\"{x:1513,y:775,t:1527027609548};\\\", \\\"{x:1512,y:770,t:1527027609565};\\\", \\\"{x:1509,y:765,t:1527027609583};\\\", \\\"{x:1508,y:760,t:1527027609600};\\\", \\\"{x:1506,y:756,t:1527027609615};\\\", \\\"{x:1505,y:753,t:1527027609632};\\\", \\\"{x:1505,y:754,t:1527027609768};\\\", \\\"{x:1505,y:757,t:1527027609783};\\\", \\\"{x:1506,y:762,t:1527027609799};\\\", \\\"{x:1508,y:771,t:1527027609815};\\\", \\\"{x:1509,y:780,t:1527027609832};\\\", \\\"{x:1510,y:789,t:1527027609848};\\\", \\\"{x:1510,y:795,t:1527027609865};\\\", \\\"{x:1510,y:803,t:1527027609882};\\\", \\\"{x:1511,y:807,t:1527027609899};\\\", \\\"{x:1513,y:813,t:1527027609915};\\\", \\\"{x:1513,y:817,t:1527027609931};\\\", \\\"{x:1514,y:821,t:1527027609948};\\\", \\\"{x:1515,y:824,t:1527027609965};\\\", \\\"{x:1516,y:826,t:1527027609982};\\\", \\\"{x:1517,y:830,t:1527027609999};\\\", \\\"{x:1518,y:834,t:1527027610016};\\\", \\\"{x:1520,y:840,t:1527027610032};\\\", \\\"{x:1521,y:844,t:1527027610048};\\\", \\\"{x:1524,y:847,t:1527027610066};\\\", \\\"{x:1524,y:848,t:1527027610082};\\\", \\\"{x:1524,y:850,t:1527027610099};\\\", \\\"{x:1525,y:850,t:1527027610116};\\\", \\\"{x:1525,y:852,t:1527027610131};\\\", \\\"{x:1528,y:856,t:1527027610149};\\\", \\\"{x:1531,y:858,t:1527027610166};\\\", \\\"{x:1536,y:861,t:1527027610182};\\\", \\\"{x:1545,y:865,t:1527027610199};\\\", \\\"{x:1553,y:869,t:1527027610216};\\\", \\\"{x:1558,y:872,t:1527027610233};\\\", \\\"{x:1560,y:872,t:1527027610249};\\\", \\\"{x:1562,y:874,t:1527027610266};\\\", \\\"{x:1563,y:874,t:1527027610288};\\\", \\\"{x:1563,y:875,t:1527027610312};\\\", \\\"{x:1564,y:876,t:1527027610336};\\\", \\\"{x:1564,y:875,t:1527027610416};\\\", \\\"{x:1561,y:866,t:1527027610433};\\\", \\\"{x:1556,y:852,t:1527027610450};\\\", \\\"{x:1551,y:839,t:1527027610466};\\\", \\\"{x:1546,y:827,t:1527027610483};\\\", \\\"{x:1544,y:816,t:1527027610500};\\\", \\\"{x:1542,y:808,t:1527027610516};\\\", \\\"{x:1541,y:801,t:1527027610533};\\\", \\\"{x:1540,y:796,t:1527027610550};\\\", \\\"{x:1540,y:792,t:1527027610566};\\\", \\\"{x:1540,y:789,t:1527027610583};\\\", \\\"{x:1540,y:785,t:1527027610600};\\\", \\\"{x:1540,y:782,t:1527027610617};\\\", \\\"{x:1540,y:779,t:1527027610633};\\\", \\\"{x:1540,y:769,t:1527027610650};\\\", \\\"{x:1540,y:761,t:1527027610666};\\\", \\\"{x:1540,y:754,t:1527027610683};\\\", \\\"{x:1540,y:750,t:1527027610700};\\\", \\\"{x:1540,y:747,t:1527027610717};\\\", \\\"{x:1541,y:742,t:1527027610733};\\\", \\\"{x:1541,y:736,t:1527027610751};\\\", \\\"{x:1541,y:729,t:1527027610768};\\\", \\\"{x:1541,y:723,t:1527027610783};\\\", \\\"{x:1541,y:713,t:1527027610800};\\\", \\\"{x:1541,y:712,t:1527027610817};\\\", \\\"{x:1541,y:708,t:1527027610833};\\\", \\\"{x:1541,y:703,t:1527027610850};\\\", \\\"{x:1541,y:698,t:1527027610867};\\\", \\\"{x:1541,y:693,t:1527027610884};\\\", \\\"{x:1541,y:690,t:1527027610900};\\\", \\\"{x:1541,y:686,t:1527027610917};\\\", \\\"{x:1541,y:684,t:1527027610935};\\\", \\\"{x:1541,y:682,t:1527027610950};\\\", \\\"{x:1540,y:680,t:1527027610967};\\\", \\\"{x:1538,y:674,t:1527027610985};\\\", \\\"{x:1538,y:673,t:1527027611000};\\\", \\\"{x:1538,y:671,t:1527027611017};\\\", \\\"{x:1538,y:670,t:1527027611035};\\\", \\\"{x:1537,y:668,t:1527027611050};\\\", \\\"{x:1537,y:667,t:1527027611068};\\\", \\\"{x:1535,y:665,t:1527027611084};\\\", \\\"{x:1534,y:664,t:1527027611100};\\\", \\\"{x:1531,y:663,t:1527027611118};\\\", \\\"{x:1526,y:662,t:1527027611134};\\\", \\\"{x:1519,y:660,t:1527027611151};\\\", \\\"{x:1511,y:659,t:1527027611167};\\\", \\\"{x:1501,y:659,t:1527027611184};\\\", \\\"{x:1495,y:659,t:1527027611201};\\\", \\\"{x:1491,y:659,t:1527027611217};\\\", \\\"{x:1485,y:659,t:1527027611234};\\\", \\\"{x:1474,y:659,t:1527027611251};\\\", \\\"{x:1456,y:659,t:1527027611267};\\\", \\\"{x:1438,y:659,t:1527027611284};\\\", \\\"{x:1425,y:659,t:1527027611301};\\\", \\\"{x:1416,y:659,t:1527027611317};\\\", \\\"{x:1412,y:659,t:1527027611334};\\\", \\\"{x:1409,y:659,t:1527027611351};\\\", \\\"{x:1405,y:659,t:1527027611367};\\\", \\\"{x:1393,y:659,t:1527027611384};\\\", \\\"{x:1378,y:654,t:1527027611400};\\\", \\\"{x:1363,y:649,t:1527027611418};\\\", \\\"{x:1353,y:646,t:1527027611434};\\\", \\\"{x:1348,y:646,t:1527027611450};\\\", \\\"{x:1348,y:645,t:1527027611468};\\\", \\\"{x:1347,y:644,t:1527027611487};\\\", \\\"{x:1347,y:643,t:1527027611585};\\\", \\\"{x:1351,y:641,t:1527027611601};\\\", \\\"{x:1360,y:638,t:1527027611618};\\\", \\\"{x:1373,y:633,t:1527027611634};\\\", \\\"{x:1382,y:632,t:1527027611651};\\\", \\\"{x:1397,y:630,t:1527027611667};\\\", \\\"{x:1409,y:629,t:1527027611685};\\\", \\\"{x:1417,y:628,t:1527027611700};\\\", \\\"{x:1422,y:627,t:1527027611718};\\\", \\\"{x:1425,y:626,t:1527027611735};\\\", \\\"{x:1426,y:625,t:1527027611750};\\\", \\\"{x:1428,y:624,t:1527027611768};\\\", \\\"{x:1429,y:624,t:1527027611784};\\\", \\\"{x:1432,y:624,t:1527027611801};\\\", \\\"{x:1435,y:623,t:1527027611817};\\\", \\\"{x:1439,y:623,t:1527027611835};\\\", \\\"{x:1443,y:622,t:1527027611851};\\\", \\\"{x:1444,y:622,t:1527027611872};\\\", \\\"{x:1445,y:622,t:1527027612026};\\\", \\\"{x:1446,y:622,t:1527027612035};\\\", \\\"{x:1448,y:623,t:1527027612052};\\\", \\\"{x:1448,y:624,t:1527027612068};\\\", \\\"{x:1449,y:624,t:1527027612085};\\\", \\\"{x:1451,y:624,t:1527027612368};\\\", \\\"{x:1457,y:624,t:1527027612386};\\\", \\\"{x:1460,y:624,t:1527027612402};\\\", \\\"{x:1463,y:624,t:1527027612419};\\\", \\\"{x:1468,y:624,t:1527027612437};\\\", \\\"{x:1474,y:625,t:1527027612452};\\\", \\\"{x:1479,y:626,t:1527027612470};\\\", \\\"{x:1490,y:628,t:1527027612486};\\\", \\\"{x:1503,y:629,t:1527027612502};\\\", \\\"{x:1512,y:629,t:1527027612519};\\\", \\\"{x:1522,y:629,t:1527027612536};\\\", \\\"{x:1526,y:629,t:1527027612552};\\\", \\\"{x:1528,y:629,t:1527027612570};\\\", \\\"{x:1530,y:629,t:1527027612586};\\\", \\\"{x:1531,y:630,t:1527027612633};\\\", \\\"{x:1531,y:631,t:1527027612641};\\\", \\\"{x:1531,y:632,t:1527027612652};\\\", \\\"{x:1531,y:634,t:1527027612670};\\\", \\\"{x:1528,y:639,t:1527027612686};\\\", \\\"{x:1515,y:650,t:1527027612704};\\\", \\\"{x:1491,y:658,t:1527027612719};\\\", \\\"{x:1425,y:680,t:1527027612736};\\\", \\\"{x:1364,y:688,t:1527027612753};\\\", \\\"{x:1319,y:702,t:1527027612769};\\\", \\\"{x:1295,y:709,t:1527027612786};\\\", \\\"{x:1288,y:711,t:1527027612803};\\\", \\\"{x:1288,y:712,t:1527027612848};\\\", \\\"{x:1288,y:713,t:1527027612928};\\\", \\\"{x:1288,y:714,t:1527027612936};\\\", \\\"{x:1293,y:715,t:1527027612954};\\\", \\\"{x:1300,y:715,t:1527027612970};\\\", \\\"{x:1319,y:715,t:1527027612986};\\\", \\\"{x:1340,y:714,t:1527027613004};\\\", \\\"{x:1362,y:713,t:1527027613020};\\\", \\\"{x:1379,y:712,t:1527027613036};\\\", \\\"{x:1386,y:710,t:1527027613054};\\\", \\\"{x:1388,y:709,t:1527027613070};\\\", \\\"{x:1390,y:708,t:1527027613087};\\\", \\\"{x:1392,y:708,t:1527027613103};\\\", \\\"{x:1398,y:703,t:1527027613121};\\\", \\\"{x:1399,y:701,t:1527027613137};\\\", \\\"{x:1401,y:698,t:1527027613153};\\\", \\\"{x:1402,y:698,t:1527027613171};\\\", \\\"{x:1402,y:696,t:1527027613188};\\\", \\\"{x:1402,y:695,t:1527027613209};\\\", \\\"{x:1401,y:694,t:1527027613221};\\\", \\\"{x:1399,y:693,t:1527027613237};\\\", \\\"{x:1393,y:693,t:1527027613253};\\\", \\\"{x:1385,y:693,t:1527027613270};\\\", \\\"{x:1371,y:693,t:1527027613287};\\\", \\\"{x:1363,y:693,t:1527027613303};\\\", \\\"{x:1355,y:696,t:1527027613320};\\\", \\\"{x:1354,y:696,t:1527027613337};\\\", \\\"{x:1354,y:697,t:1527027613585};\\\", \\\"{x:1355,y:697,t:1527027613600};\\\", \\\"{x:1358,y:697,t:1527027613608};\\\", \\\"{x:1361,y:697,t:1527027613622};\\\", \\\"{x:1367,y:697,t:1527027613637};\\\", \\\"{x:1371,y:697,t:1527027613654};\\\", \\\"{x:1375,y:697,t:1527027613672};\\\", \\\"{x:1378,y:697,t:1527027613687};\\\", \\\"{x:1384,y:697,t:1527027613704};\\\", \\\"{x:1388,y:697,t:1527027613721};\\\", \\\"{x:1394,y:697,t:1527027613737};\\\", \\\"{x:1398,y:697,t:1527027613755};\\\", \\\"{x:1400,y:697,t:1527027613771};\\\", \\\"{x:1401,y:697,t:1527027613787};\\\", \\\"{x:1402,y:697,t:1527027613808};\\\", \\\"{x:1403,y:697,t:1527027613976};\\\", \\\"{x:1404,y:697,t:1527027613988};\\\", \\\"{x:1405,y:697,t:1527027614004};\\\", \\\"{x:1408,y:697,t:1527027614022};\\\", \\\"{x:1409,y:697,t:1527027614038};\\\", \\\"{x:1410,y:697,t:1527027614054};\\\", \\\"{x:1411,y:696,t:1527027614241};\\\", \\\"{x:1412,y:696,t:1527027614256};\\\", \\\"{x:1415,y:695,t:1527027614271};\\\", \\\"{x:1426,y:693,t:1527027614288};\\\", \\\"{x:1432,y:692,t:1527027614305};\\\", \\\"{x:1436,y:692,t:1527027614321};\\\", \\\"{x:1441,y:691,t:1527027614337};\\\", \\\"{x:1443,y:691,t:1527027614354};\\\", \\\"{x:1445,y:691,t:1527027614371};\\\", \\\"{x:1450,y:689,t:1527027614388};\\\", \\\"{x:1454,y:689,t:1527027614404};\\\", \\\"{x:1457,y:689,t:1527027614422};\\\", \\\"{x:1459,y:689,t:1527027614438};\\\", \\\"{x:1462,y:689,t:1527027614455};\\\", \\\"{x:1464,y:689,t:1527027614471};\\\", \\\"{x:1465,y:689,t:1527027614527};\\\", \\\"{x:1467,y:689,t:1527027614543};\\\", \\\"{x:1468,y:689,t:1527027614555};\\\", \\\"{x:1471,y:690,t:1527027614572};\\\", \\\"{x:1472,y:691,t:1527027614588};\\\", \\\"{x:1474,y:692,t:1527027614687};\\\", \\\"{x:1475,y:692,t:1527027614936};\\\", \\\"{x:1477,y:692,t:1527027614944};\\\", \\\"{x:1479,y:692,t:1527027614956};\\\", \\\"{x:1481,y:692,t:1527027614973};\\\", \\\"{x:1483,y:692,t:1527027614990};\\\", \\\"{x:1484,y:692,t:1527027615009};\\\", \\\"{x:1486,y:692,t:1527027615081};\\\", \\\"{x:1487,y:692,t:1527027615090};\\\", \\\"{x:1490,y:692,t:1527027615107};\\\", \\\"{x:1493,y:692,t:1527027615124};\\\", \\\"{x:1495,y:692,t:1527027615139};\\\", \\\"{x:1498,y:692,t:1527027615157};\\\", \\\"{x:1501,y:692,t:1527027615174};\\\", \\\"{x:1504,y:692,t:1527027615189};\\\", \\\"{x:1507,y:692,t:1527027615206};\\\", \\\"{x:1511,y:692,t:1527027615224};\\\", \\\"{x:1514,y:692,t:1527027615239};\\\", \\\"{x:1515,y:692,t:1527027615256};\\\", \\\"{x:1517,y:692,t:1527027615273};\\\", \\\"{x:1519,y:692,t:1527027615288};\\\", \\\"{x:1523,y:692,t:1527027615306};\\\", \\\"{x:1526,y:692,t:1527027615323};\\\", \\\"{x:1530,y:692,t:1527027615339};\\\", \\\"{x:1532,y:692,t:1527027615356};\\\", \\\"{x:1535,y:692,t:1527027615372};\\\", \\\"{x:1537,y:692,t:1527027615390};\\\", \\\"{x:1538,y:692,t:1527027615464};\\\", \\\"{x:1539,y:692,t:1527027615473};\\\", \\\"{x:1540,y:692,t:1527027615489};\\\", \\\"{x:1541,y:692,t:1527027615769};\\\", \\\"{x:1540,y:696,t:1527027615776};\\\", \\\"{x:1532,y:700,t:1527027615791};\\\", \\\"{x:1505,y:712,t:1527027615808};\\\", \\\"{x:1443,y:722,t:1527027615824};\\\", \\\"{x:1291,y:733,t:1527027615840};\\\", \\\"{x:1175,y:733,t:1527027615857};\\\", \\\"{x:1056,y:733,t:1527027615874};\\\", \\\"{x:939,y:733,t:1527027615891};\\\", \\\"{x:845,y:733,t:1527027615907};\\\", \\\"{x:775,y:733,t:1527027615924};\\\", \\\"{x:725,y:733,t:1527027615940};\\\", \\\"{x:680,y:733,t:1527027615957};\\\", \\\"{x:639,y:738,t:1527027615974};\\\", \\\"{x:615,y:743,t:1527027615990};\\\", \\\"{x:592,y:751,t:1527027616007};\\\", \\\"{x:558,y:761,t:1527027616024};\\\", \\\"{x:532,y:763,t:1527027616040};\\\", \\\"{x:510,y:769,t:1527027616057};\\\", \\\"{x:494,y:771,t:1527027616074};\\\", \\\"{x:487,y:771,t:1527027616090};\\\", \\\"{x:483,y:771,t:1527027616107};\\\", \\\"{x:481,y:771,t:1527027616124};\\\", \\\"{x:475,y:768,t:1527027616141};\\\", \\\"{x:472,y:768,t:1527027616158};\\\", \\\"{x:471,y:768,t:1527027616184};\\\", \\\"{x:470,y:767,t:1527027616192};\\\", \\\"{x:470,y:765,t:1527027616208};\\\", \\\"{x:470,y:756,t:1527027616223};\\\", \\\"{x:479,y:744,t:1527027616243};\\\", \\\"{x:494,y:734,t:1527027616257};\\\", \\\"{x:505,y:729,t:1527027616274};\\\", \\\"{x:513,y:726,t:1527027616290};\\\", \\\"{x:519,y:725,t:1527027616313};\\\", \\\"{x:519,y:726,t:1527027617104};\\\", \\\"{x:519,y:727,t:1527027617240};\\\", \\\"{x:519,y:729,t:1527027617250};\\\", \\\"{x:519,y:730,t:1527027617267};\\\", \\\"{x:518,y:733,t:1527027617283};\\\", \\\"{x:518,y:735,t:1527027617300};\\\", \\\"{x:518,y:739,t:1527027617317};\\\", \\\"{x:517,y:746,t:1527027617334};\\\", \\\"{x:517,y:752,t:1527027617350};\\\", \\\"{x:517,y:767,t:1527027617368};\\\", \\\"{x:517,y:782,t:1527027617384};\\\", \\\"{x:517,y:797,t:1527027617400};\\\", \\\"{x:517,y:820,t:1527027617417};\\\", \\\"{x:517,y:849,t:1527027617434};\\\", \\\"{x:519,y:878,t:1527027617450};\\\", \\\"{x:533,y:932,t:1527027617478};\\\", \\\"{x:538,y:942,t:1527027617487};\\\", \\\"{x:543,y:953,t:1527027617500};\\\", \\\"{x:551,y:969,t:1527027617516};\\\", \\\"{x:561,y:982,t:1527027617534};\\\", \\\"{x:578,y:996,t:1527027617549};\\\" ] }, { \\\"rt\\\": 44035, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 499802, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"C30CF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-X -J -I -B -B -B -B -B -F -C -C -E -G -G -E -E -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:649,y:1046,t:1527027617672};\\\", \\\"{x:650,y:1046,t:1527027619737};\\\", \\\"{x:652,y:1041,t:1527027619753};\\\", \\\"{x:654,y:1036,t:1527027619770};\\\", \\\"{x:658,y:1032,t:1527027619786};\\\", \\\"{x:661,y:1026,t:1527027619802};\\\", \\\"{x:664,y:1016,t:1527027619820};\\\", \\\"{x:667,y:1004,t:1527027619836};\\\", \\\"{x:675,y:990,t:1527027619853};\\\", \\\"{x:678,y:974,t:1527027619870};\\\", \\\"{x:685,y:957,t:1527027619887};\\\", \\\"{x:694,y:938,t:1527027619903};\\\", \\\"{x:711,y:908,t:1527027619920};\\\", \\\"{x:722,y:886,t:1527027619936};\\\", \\\"{x:737,y:856,t:1527027619952};\\\", \\\"{x:752,y:820,t:1527027619969};\\\", \\\"{x:764,y:788,t:1527027619986};\\\", \\\"{x:771,y:763,t:1527027620003};\\\", \\\"{x:775,y:741,t:1527027620020};\\\", \\\"{x:784,y:727,t:1527027620036};\\\", \\\"{x:793,y:705,t:1527027620052};\\\", \\\"{x:800,y:683,t:1527027620069};\\\", \\\"{x:810,y:658,t:1527027620087};\\\", \\\"{x:818,y:630,t:1527027620104};\\\", \\\"{x:836,y:592,t:1527027620120};\\\", \\\"{x:855,y:559,t:1527027620136};\\\", \\\"{x:874,y:527,t:1527027620152};\\\", \\\"{x:888,y:502,t:1527027620169};\\\", \\\"{x:906,y:475,t:1527027620187};\\\", \\\"{x:917,y:459,t:1527027620201};\\\", \\\"{x:920,y:455,t:1527027620219};\\\", \\\"{x:923,y:455,t:1527027620273};\\\", \\\"{x:927,y:459,t:1527027620285};\\\", \\\"{x:932,y:465,t:1527027620302};\\\", \\\"{x:942,y:473,t:1527027620319};\\\", \\\"{x:956,y:484,t:1527027620335};\\\", \\\"{x:972,y:496,t:1527027620352};\\\", \\\"{x:983,y:498,t:1527027620369};\\\", \\\"{x:986,y:500,t:1527027620896};\\\", \\\"{x:987,y:502,t:1527027620905};\\\", \\\"{x:988,y:503,t:1527027620917};\\\", \\\"{x:990,y:505,t:1527027620934};\\\", \\\"{x:991,y:506,t:1527027620951};\\\", \\\"{x:993,y:506,t:1527027620967};\\\", \\\"{x:996,y:507,t:1527027620984};\\\", \\\"{x:1000,y:508,t:1527027621000};\\\", \\\"{x:1006,y:508,t:1527027621017};\\\", \\\"{x:1016,y:510,t:1527027621034};\\\", \\\"{x:1023,y:511,t:1527027621050};\\\", \\\"{x:1027,y:512,t:1527027621068};\\\", \\\"{x:1032,y:512,t:1527027621084};\\\", \\\"{x:1036,y:512,t:1527027621100};\\\", \\\"{x:1041,y:514,t:1527027621118};\\\", \\\"{x:1046,y:515,t:1527027621133};\\\", \\\"{x:1051,y:516,t:1527027621150};\\\", \\\"{x:1055,y:516,t:1527027621167};\\\", \\\"{x:1056,y:516,t:1527027621184};\\\", \\\"{x:1057,y:517,t:1527027621200};\\\", \\\"{x:1058,y:518,t:1527027621232};\\\", \\\"{x:1060,y:518,t:1527027621248};\\\", \\\"{x:1063,y:519,t:1527027621256};\\\", \\\"{x:1065,y:519,t:1527027621267};\\\", \\\"{x:1071,y:520,t:1527027621283};\\\", \\\"{x:1080,y:523,t:1527027621300};\\\", \\\"{x:1092,y:527,t:1527027621316};\\\", \\\"{x:1103,y:528,t:1527027621333};\\\", \\\"{x:1109,y:529,t:1527027621351};\\\", \\\"{x:1117,y:531,t:1527027621366};\\\", \\\"{x:1121,y:532,t:1527027621383};\\\", \\\"{x:1125,y:532,t:1527027621399};\\\", \\\"{x:1131,y:532,t:1527027621416};\\\", \\\"{x:1135,y:532,t:1527027621433};\\\", \\\"{x:1141,y:532,t:1527027621449};\\\", \\\"{x:1146,y:532,t:1527027621466};\\\", \\\"{x:1150,y:533,t:1527027621483};\\\", \\\"{x:1154,y:533,t:1527027621499};\\\", \\\"{x:1158,y:535,t:1527027621517};\\\", \\\"{x:1162,y:536,t:1527027621533};\\\", \\\"{x:1174,y:540,t:1527027621550};\\\", \\\"{x:1185,y:545,t:1527027621567};\\\", \\\"{x:1200,y:549,t:1527027621582};\\\", \\\"{x:1221,y:555,t:1527027621600};\\\", \\\"{x:1239,y:561,t:1527027621616};\\\", \\\"{x:1253,y:565,t:1527027621632};\\\", \\\"{x:1267,y:569,t:1527027621650};\\\", \\\"{x:1285,y:577,t:1527027621667};\\\", \\\"{x:1299,y:581,t:1527027621683};\\\", \\\"{x:1311,y:586,t:1527027621700};\\\", \\\"{x:1325,y:590,t:1527027621716};\\\", \\\"{x:1340,y:594,t:1527027621733};\\\", \\\"{x:1349,y:600,t:1527027621750};\\\", \\\"{x:1370,y:608,t:1527027621766};\\\", \\\"{x:1396,y:621,t:1527027621783};\\\", \\\"{x:1431,y:631,t:1527027621800};\\\", \\\"{x:1448,y:638,t:1527027621816};\\\", \\\"{x:1466,y:643,t:1527027621832};\\\", \\\"{x:1475,y:646,t:1527027621849};\\\", \\\"{x:1483,y:647,t:1527027621866};\\\", \\\"{x:1489,y:647,t:1527027621883};\\\", \\\"{x:1493,y:647,t:1527027621899};\\\", \\\"{x:1497,y:643,t:1527027621916};\\\", \\\"{x:1497,y:638,t:1527027621933};\\\", \\\"{x:1496,y:638,t:1527027622320};\\\", \\\"{x:1493,y:638,t:1527027622331};\\\", \\\"{x:1490,y:639,t:1527027622348};\\\", \\\"{x:1489,y:640,t:1527027622364};\\\", \\\"{x:1486,y:641,t:1527027622382};\\\", \\\"{x:1486,y:642,t:1527027622398};\\\", \\\"{x:1484,y:643,t:1527027622415};\\\", \\\"{x:1483,y:646,t:1527027622433};\\\", \\\"{x:1482,y:648,t:1527027622448};\\\", \\\"{x:1482,y:652,t:1527027622464};\\\", \\\"{x:1480,y:655,t:1527027622480};\\\", \\\"{x:1480,y:656,t:1527027622498};\\\", \\\"{x:1479,y:659,t:1527027622515};\\\", \\\"{x:1478,y:662,t:1527027622531};\\\", \\\"{x:1475,y:666,t:1527027622548};\\\", \\\"{x:1473,y:670,t:1527027622565};\\\", \\\"{x:1470,y:677,t:1527027622581};\\\", \\\"{x:1462,y:688,t:1527027622598};\\\", \\\"{x:1451,y:712,t:1527027622614};\\\", \\\"{x:1436,y:747,t:1527027622631};\\\", \\\"{x:1413,y:789,t:1527027622648};\\\", \\\"{x:1404,y:810,t:1527027622664};\\\", \\\"{x:1396,y:828,t:1527027622681};\\\", \\\"{x:1390,y:846,t:1527027622697};\\\", \\\"{x:1384,y:858,t:1527027622714};\\\", \\\"{x:1378,y:874,t:1527027622730};\\\", \\\"{x:1373,y:885,t:1527027622748};\\\", \\\"{x:1368,y:894,t:1527027622763};\\\", \\\"{x:1363,y:905,t:1527027622781};\\\", \\\"{x:1361,y:909,t:1527027622796};\\\", \\\"{x:1360,y:915,t:1527027622814};\\\", \\\"{x:1360,y:923,t:1527027622831};\\\", \\\"{x:1360,y:931,t:1527027622847};\\\", \\\"{x:1360,y:941,t:1527027622864};\\\", \\\"{x:1362,y:950,t:1527027622881};\\\", \\\"{x:1363,y:955,t:1527027622896};\\\", \\\"{x:1366,y:959,t:1527027622913};\\\", \\\"{x:1369,y:965,t:1527027622929};\\\", \\\"{x:1373,y:969,t:1527027622946};\\\", \\\"{x:1377,y:973,t:1527027622963};\\\", \\\"{x:1379,y:975,t:1527027622979};\\\", \\\"{x:1380,y:975,t:1527027622996};\\\", \\\"{x:1381,y:975,t:1527027623014};\\\", \\\"{x:1383,y:975,t:1527027623048};\\\", \\\"{x:1384,y:975,t:1527027623063};\\\", \\\"{x:1387,y:975,t:1527027623080};\\\", \\\"{x:1389,y:974,t:1527027623096};\\\", \\\"{x:1395,y:970,t:1527027623113};\\\", \\\"{x:1402,y:969,t:1527027623129};\\\", \\\"{x:1413,y:965,t:1527027623148};\\\", \\\"{x:1427,y:961,t:1527027623162};\\\", \\\"{x:1436,y:959,t:1527027623180};\\\", \\\"{x:1444,y:956,t:1527027623196};\\\", \\\"{x:1445,y:956,t:1527027623212};\\\", \\\"{x:1448,y:956,t:1527027623229};\\\", \\\"{x:1452,y:956,t:1527027623245};\\\", \\\"{x:1459,y:956,t:1527027623263};\\\", \\\"{x:1473,y:956,t:1527027623281};\\\", \\\"{x:1486,y:956,t:1527027623296};\\\", \\\"{x:1490,y:956,t:1527027623313};\\\", \\\"{x:1494,y:956,t:1527027623329};\\\", \\\"{x:1496,y:956,t:1527027623346};\\\", \\\"{x:1497,y:956,t:1527027623363};\\\", \\\"{x:1497,y:958,t:1527027623425};\\\", \\\"{x:1495,y:959,t:1527027623440};\\\", \\\"{x:1494,y:960,t:1527027623448};\\\", \\\"{x:1489,y:961,t:1527027623463};\\\", \\\"{x:1485,y:961,t:1527027623480};\\\", \\\"{x:1476,y:961,t:1527027623496};\\\", \\\"{x:1472,y:961,t:1527027623512};\\\", \\\"{x:1471,y:961,t:1527027623529};\\\", \\\"{x:1470,y:961,t:1527027623689};\\\", \\\"{x:1471,y:960,t:1527027623696};\\\", \\\"{x:1472,y:958,t:1527027623712};\\\", \\\"{x:1474,y:954,t:1527027623728};\\\", \\\"{x:1476,y:952,t:1527027623745};\\\", \\\"{x:1480,y:945,t:1527027623762};\\\", \\\"{x:1485,y:937,t:1527027623778};\\\", \\\"{x:1488,y:930,t:1527027623794};\\\", \\\"{x:1492,y:922,t:1527027623812};\\\", \\\"{x:1493,y:911,t:1527027623827};\\\", \\\"{x:1493,y:906,t:1527027623845};\\\", \\\"{x:1493,y:903,t:1527027623862};\\\", \\\"{x:1493,y:901,t:1527027623878};\\\", \\\"{x:1493,y:897,t:1527027623895};\\\", \\\"{x:1493,y:893,t:1527027623912};\\\", \\\"{x:1493,y:890,t:1527027623928};\\\", \\\"{x:1493,y:885,t:1527027623945};\\\", \\\"{x:1493,y:879,t:1527027623961};\\\", \\\"{x:1492,y:876,t:1527027623978};\\\", \\\"{x:1490,y:872,t:1527027623995};\\\", \\\"{x:1488,y:870,t:1527027624011};\\\", \\\"{x:1487,y:869,t:1527027624027};\\\", \\\"{x:1487,y:867,t:1527027624044};\\\", \\\"{x:1487,y:864,t:1527027624061};\\\", \\\"{x:1487,y:857,t:1527027624078};\\\", \\\"{x:1487,y:851,t:1527027624094};\\\", \\\"{x:1485,y:843,t:1527027624111};\\\", \\\"{x:1483,y:832,t:1527027624131};\\\", \\\"{x:1483,y:831,t:1527027624143};\\\", \\\"{x:1483,y:829,t:1527027624160};\\\", \\\"{x:1483,y:828,t:1527027624191};\\\", \\\"{x:1483,y:827,t:1527027624199};\\\", \\\"{x:1483,y:826,t:1527027624247};\\\", \\\"{x:1481,y:826,t:1527027624312};\\\", \\\"{x:1480,y:826,t:1527027624327};\\\", \\\"{x:1469,y:825,t:1527027624345};\\\", \\\"{x:1457,y:825,t:1527027624360};\\\", \\\"{x:1441,y:825,t:1527027624377};\\\", \\\"{x:1426,y:825,t:1527027624393};\\\", \\\"{x:1411,y:824,t:1527027624410};\\\", \\\"{x:1398,y:824,t:1527027624427};\\\", \\\"{x:1384,y:824,t:1527027624444};\\\", \\\"{x:1368,y:824,t:1527027624460};\\\", \\\"{x:1350,y:822,t:1527027624476};\\\", \\\"{x:1328,y:822,t:1527027624493};\\\", \\\"{x:1305,y:822,t:1527027624510};\\\", \\\"{x:1285,y:822,t:1527027624528};\\\", \\\"{x:1268,y:821,t:1527027624544};\\\", \\\"{x:1255,y:821,t:1527027624560};\\\", \\\"{x:1250,y:821,t:1527027624577};\\\", \\\"{x:1245,y:821,t:1527027624593};\\\", \\\"{x:1238,y:822,t:1527027624610};\\\", \\\"{x:1231,y:823,t:1527027624627};\\\", \\\"{x:1222,y:826,t:1527027624642};\\\", \\\"{x:1217,y:826,t:1527027624660};\\\", \\\"{x:1214,y:828,t:1527027624677};\\\", \\\"{x:1213,y:828,t:1527027624693};\\\", \\\"{x:1213,y:829,t:1527027624841};\\\", \\\"{x:1214,y:829,t:1527027624864};\\\", \\\"{x:1215,y:829,t:1527027625120};\\\", \\\"{x:1216,y:829,t:1527027625127};\\\", \\\"{x:1217,y:829,t:1527027625142};\\\", \\\"{x:1218,y:829,t:1527027625159};\\\", \\\"{x:1221,y:829,t:1527027625176};\\\", \\\"{x:1229,y:829,t:1527027625192};\\\", \\\"{x:1234,y:830,t:1527027625208};\\\", \\\"{x:1241,y:830,t:1527027625225};\\\", \\\"{x:1247,y:830,t:1527027625242};\\\", \\\"{x:1249,y:830,t:1527027625259};\\\", \\\"{x:1250,y:830,t:1527027625275};\\\", \\\"{x:1251,y:830,t:1527027625292};\\\", \\\"{x:1254,y:830,t:1527027625308};\\\", \\\"{x:1258,y:830,t:1527027625325};\\\", \\\"{x:1262,y:830,t:1527027625341};\\\", \\\"{x:1269,y:830,t:1527027625357};\\\", \\\"{x:1272,y:830,t:1527027625375};\\\", \\\"{x:1274,y:830,t:1527027625391};\\\", \\\"{x:1276,y:830,t:1527027625448};\\\", \\\"{x:1278,y:830,t:1527027625458};\\\", \\\"{x:1279,y:830,t:1527027625475};\\\", \\\"{x:1280,y:830,t:1527027625491};\\\", \\\"{x:1281,y:830,t:1527027625625};\\\", \\\"{x:1282,y:832,t:1527027625640};\\\", \\\"{x:1285,y:832,t:1527027625658};\\\", \\\"{x:1292,y:832,t:1527027625674};\\\", \\\"{x:1303,y:832,t:1527027625691};\\\", \\\"{x:1311,y:832,t:1527027625708};\\\", \\\"{x:1323,y:833,t:1527027625724};\\\", \\\"{x:1334,y:833,t:1527027625741};\\\", \\\"{x:1342,y:833,t:1527027625757};\\\", \\\"{x:1347,y:833,t:1527027625774};\\\", \\\"{x:1349,y:833,t:1527027625791};\\\", \\\"{x:1350,y:833,t:1527027625808};\\\", \\\"{x:1349,y:833,t:1527027625929};\\\", \\\"{x:1346,y:833,t:1527027625940};\\\", \\\"{x:1343,y:833,t:1527027625958};\\\", \\\"{x:1337,y:833,t:1527027625974};\\\", \\\"{x:1331,y:831,t:1527027625990};\\\", \\\"{x:1324,y:828,t:1527027626007};\\\", \\\"{x:1315,y:824,t:1527027626023};\\\", \\\"{x:1298,y:819,t:1527027626040};\\\", \\\"{x:1284,y:814,t:1527027626056};\\\", \\\"{x:1273,y:810,t:1527027626073};\\\", \\\"{x:1263,y:804,t:1527027626090};\\\", \\\"{x:1250,y:798,t:1527027626107};\\\", \\\"{x:1238,y:794,t:1527027626123};\\\", \\\"{x:1225,y:792,t:1527027626140};\\\", \\\"{x:1210,y:791,t:1527027626157};\\\", \\\"{x:1197,y:788,t:1527027626173};\\\", \\\"{x:1189,y:786,t:1527027626190};\\\", \\\"{x:1188,y:785,t:1527027626206};\\\", \\\"{x:1189,y:785,t:1527027626297};\\\", \\\"{x:1191,y:784,t:1527027626312};\\\", \\\"{x:1193,y:783,t:1527027626323};\\\", \\\"{x:1195,y:782,t:1527027626339};\\\", \\\"{x:1198,y:780,t:1527027626356};\\\", \\\"{x:1200,y:777,t:1527027626372};\\\", \\\"{x:1200,y:772,t:1527027626388};\\\", \\\"{x:1200,y:768,t:1527027626405};\\\", \\\"{x:1199,y:765,t:1527027626422};\\\", \\\"{x:1198,y:763,t:1527027626442};\\\", \\\"{x:1196,y:761,t:1527027626495};\\\", \\\"{x:1196,y:760,t:1527027626511};\\\", \\\"{x:1194,y:760,t:1527027626527};\\\", \\\"{x:1193,y:760,t:1527027626539};\\\", \\\"{x:1191,y:760,t:1527027626559};\\\", \\\"{x:1190,y:760,t:1527027626572};\\\", \\\"{x:1188,y:761,t:1527027626599};\\\", \\\"{x:1186,y:762,t:1527027626615};\\\", \\\"{x:1186,y:764,t:1527027626672};\\\", \\\"{x:1192,y:764,t:1527027626689};\\\", \\\"{x:1199,y:764,t:1527027626705};\\\", \\\"{x:1206,y:764,t:1527027626722};\\\", \\\"{x:1208,y:766,t:1527027626739};\\\", \\\"{x:1210,y:767,t:1527027626755};\\\", \\\"{x:1214,y:767,t:1527027626772};\\\", \\\"{x:1218,y:767,t:1527027626788};\\\", \\\"{x:1221,y:767,t:1527027626804};\\\", \\\"{x:1224,y:767,t:1527027626822};\\\", \\\"{x:1230,y:767,t:1527027626838};\\\", \\\"{x:1235,y:767,t:1527027626855};\\\", \\\"{x:1242,y:767,t:1527027626872};\\\", \\\"{x:1245,y:767,t:1527027626887};\\\", \\\"{x:1246,y:767,t:1527027626905};\\\", \\\"{x:1247,y:767,t:1527027626921};\\\", \\\"{x:1248,y:767,t:1527027626938};\\\", \\\"{x:1248,y:766,t:1527027626977};\\\", \\\"{x:1248,y:765,t:1527027627040};\\\", \\\"{x:1246,y:765,t:1527027627056};\\\", \\\"{x:1248,y:765,t:1527027627167};\\\", \\\"{x:1251,y:765,t:1527027627175};\\\", \\\"{x:1254,y:765,t:1527027627187};\\\", \\\"{x:1261,y:765,t:1527027627203};\\\", \\\"{x:1269,y:765,t:1527027627221};\\\", \\\"{x:1276,y:765,t:1527027627236};\\\", \\\"{x:1287,y:765,t:1527027627254};\\\", \\\"{x:1296,y:765,t:1527027627270};\\\", \\\"{x:1303,y:763,t:1527027627287};\\\", \\\"{x:1306,y:763,t:1527027627303};\\\", \\\"{x:1308,y:763,t:1527027627320};\\\", \\\"{x:1311,y:763,t:1527027627337};\\\", \\\"{x:1314,y:762,t:1527027627353};\\\", \\\"{x:1315,y:761,t:1527027627369};\\\", \\\"{x:1316,y:761,t:1527027627386};\\\", \\\"{x:1317,y:761,t:1527027627415};\\\", \\\"{x:1317,y:760,t:1527027627447};\\\", \\\"{x:1316,y:760,t:1527027627456};\\\", \\\"{x:1317,y:760,t:1527027627552};\\\", \\\"{x:1318,y:760,t:1527027627559};\\\", \\\"{x:1320,y:759,t:1527027627569};\\\", \\\"{x:1325,y:759,t:1527027627586};\\\", \\\"{x:1332,y:759,t:1527027627603};\\\", \\\"{x:1339,y:758,t:1527027627620};\\\", \\\"{x:1343,y:758,t:1527027627636};\\\", \\\"{x:1344,y:758,t:1527027627652};\\\", \\\"{x:1346,y:758,t:1527027627670};\\\", \\\"{x:1347,y:758,t:1527027627685};\\\", \\\"{x:1349,y:757,t:1527027627703};\\\", \\\"{x:1350,y:757,t:1527027627720};\\\", \\\"{x:1351,y:757,t:1527027627768};\\\", \\\"{x:1355,y:757,t:1527027627786};\\\", \\\"{x:1360,y:757,t:1527027627803};\\\", \\\"{x:1363,y:757,t:1527027627819};\\\", \\\"{x:1364,y:756,t:1527027627904};\\\", \\\"{x:1364,y:754,t:1527027628161};\\\", \\\"{x:1364,y:752,t:1527027628169};\\\", \\\"{x:1363,y:749,t:1527027628185};\\\", \\\"{x:1363,y:742,t:1527027628202};\\\", \\\"{x:1361,y:728,t:1527027628219};\\\", \\\"{x:1360,y:722,t:1527027628235};\\\", \\\"{x:1359,y:718,t:1527027628252};\\\", \\\"{x:1358,y:714,t:1527027628269};\\\", \\\"{x:1357,y:712,t:1527027628285};\\\", \\\"{x:1357,y:711,t:1527027628302};\\\", \\\"{x:1356,y:710,t:1527027628318};\\\", \\\"{x:1355,y:708,t:1527027628335};\\\", \\\"{x:1353,y:707,t:1527027628353};\\\", \\\"{x:1352,y:709,t:1527027628400};\\\", \\\"{x:1352,y:712,t:1527027628408};\\\", \\\"{x:1349,y:716,t:1527027628418};\\\", \\\"{x:1347,y:725,t:1527027628435};\\\", \\\"{x:1344,y:731,t:1527027628451};\\\", \\\"{x:1343,y:739,t:1527027628468};\\\", \\\"{x:1343,y:744,t:1527027628485};\\\", \\\"{x:1343,y:746,t:1527027628501};\\\", \\\"{x:1343,y:748,t:1527027628518};\\\", \\\"{x:1344,y:749,t:1527027628534};\\\", \\\"{x:1344,y:750,t:1527027628551};\\\", \\\"{x:1344,y:752,t:1527027628568};\\\", \\\"{x:1344,y:753,t:1527027628632};\\\", \\\"{x:1344,y:754,t:1527027628640};\\\", \\\"{x:1344,y:755,t:1527027628656};\\\", \\\"{x:1345,y:756,t:1527027628696};\\\", \\\"{x:1345,y:757,t:1527027628704};\\\", \\\"{x:1345,y:758,t:1527027628718};\\\", \\\"{x:1346,y:758,t:1527027628768};\\\", \\\"{x:1347,y:759,t:1527027629056};\\\", \\\"{x:1348,y:759,t:1527027629080};\\\", \\\"{x:1350,y:759,t:1527027629087};\\\", \\\"{x:1351,y:760,t:1527027629100};\\\", \\\"{x:1353,y:760,t:1527027629118};\\\", \\\"{x:1357,y:760,t:1527027629133};\\\", \\\"{x:1360,y:760,t:1527027629150};\\\", \\\"{x:1364,y:761,t:1527027629166};\\\", \\\"{x:1365,y:762,t:1527027629184};\\\", \\\"{x:1368,y:762,t:1527027629200};\\\", \\\"{x:1371,y:763,t:1527027629216};\\\", \\\"{x:1372,y:763,t:1527027629233};\\\", \\\"{x:1374,y:763,t:1527027629250};\\\", \\\"{x:1375,y:763,t:1527027629272};\\\", \\\"{x:1376,y:763,t:1527027629283};\\\", \\\"{x:1377,y:763,t:1527027629299};\\\", \\\"{x:1378,y:763,t:1527027629320};\\\", \\\"{x:1379,y:763,t:1527027629336};\\\", \\\"{x:1380,y:763,t:1527027629349};\\\", \\\"{x:1381,y:763,t:1527027629368};\\\", \\\"{x:1382,y:763,t:1527027629384};\\\", \\\"{x:1383,y:763,t:1527027629399};\\\", \\\"{x:1386,y:763,t:1527027629416};\\\", \\\"{x:1388,y:764,t:1527027629433};\\\", \\\"{x:1389,y:764,t:1527027629449};\\\", \\\"{x:1393,y:764,t:1527027629466};\\\", \\\"{x:1396,y:765,t:1527027629482};\\\", \\\"{x:1402,y:766,t:1527027629499};\\\", \\\"{x:1408,y:767,t:1527027629515};\\\", \\\"{x:1412,y:767,t:1527027629531};\\\", \\\"{x:1418,y:768,t:1527027629548};\\\", \\\"{x:1419,y:768,t:1527027629705};\\\", \\\"{x:1419,y:767,t:1527027629752};\\\", \\\"{x:1418,y:765,t:1527027629765};\\\", \\\"{x:1417,y:765,t:1527027629792};\\\", \\\"{x:1417,y:764,t:1527027629800};\\\", \\\"{x:1417,y:763,t:1527027629833};\\\", \\\"{x:1417,y:762,t:1527027630161};\\\", \\\"{x:1418,y:762,t:1527027630184};\\\", \\\"{x:1419,y:762,t:1527027630208};\\\", \\\"{x:1420,y:762,t:1527027630232};\\\", \\\"{x:1421,y:762,t:1527027630247};\\\", \\\"{x:1424,y:762,t:1527027630264};\\\", \\\"{x:1425,y:762,t:1527027630281};\\\", \\\"{x:1427,y:762,t:1527027630297};\\\", \\\"{x:1428,y:762,t:1527027630314};\\\", \\\"{x:1430,y:762,t:1527027630330};\\\", \\\"{x:1431,y:762,t:1527027630348};\\\", \\\"{x:1434,y:762,t:1527027630364};\\\", \\\"{x:1436,y:762,t:1527027630380};\\\", \\\"{x:1437,y:762,t:1527027630398};\\\", \\\"{x:1438,y:762,t:1527027630414};\\\", \\\"{x:1440,y:762,t:1527027630430};\\\", \\\"{x:1443,y:762,t:1527027630447};\\\", \\\"{x:1448,y:762,t:1527027630464};\\\", \\\"{x:1453,y:762,t:1527027630482};\\\", \\\"{x:1454,y:762,t:1527027630497};\\\", \\\"{x:1456,y:762,t:1527027630513};\\\", \\\"{x:1457,y:762,t:1527027630536};\\\", \\\"{x:1458,y:762,t:1527027630547};\\\", \\\"{x:1460,y:761,t:1527027630563};\\\", \\\"{x:1461,y:761,t:1527027630580};\\\", \\\"{x:1464,y:760,t:1527027630597};\\\", \\\"{x:1465,y:759,t:1527027630624};\\\", \\\"{x:1466,y:759,t:1527027630689};\\\", \\\"{x:1467,y:759,t:1527027630712};\\\", \\\"{x:1468,y:759,t:1527027631368};\\\", \\\"{x:1467,y:759,t:1527027631672};\\\", \\\"{x:1463,y:759,t:1527027631680};\\\", \\\"{x:1458,y:759,t:1527027631694};\\\", \\\"{x:1443,y:759,t:1527027631710};\\\", \\\"{x:1418,y:757,t:1527027631727};\\\", \\\"{x:1388,y:752,t:1527027631743};\\\", \\\"{x:1380,y:752,t:1527027631761};\\\", \\\"{x:1379,y:751,t:1527027631777};\\\", \\\"{x:1381,y:751,t:1527027631952};\\\", \\\"{x:1384,y:751,t:1527027631960};\\\", \\\"{x:1395,y:751,t:1527027631977};\\\", \\\"{x:1405,y:753,t:1527027631994};\\\", \\\"{x:1412,y:754,t:1527027632010};\\\", \\\"{x:1420,y:754,t:1527027632027};\\\", \\\"{x:1422,y:754,t:1527027632043};\\\", \\\"{x:1423,y:754,t:1527027632060};\\\", \\\"{x:1424,y:755,t:1527027632145};\\\", \\\"{x:1424,y:756,t:1527027632184};\\\", \\\"{x:1424,y:757,t:1527027632240};\\\", \\\"{x:1424,y:759,t:1527027632264};\\\", \\\"{x:1423,y:760,t:1527027632360};\\\", \\\"{x:1422,y:760,t:1527027632544};\\\", \\\"{x:1424,y:760,t:1527027632824};\\\", \\\"{x:1431,y:760,t:1527027632841};\\\", \\\"{x:1437,y:760,t:1527027632859};\\\", \\\"{x:1443,y:760,t:1527027632876};\\\", \\\"{x:1448,y:760,t:1527027632891};\\\", \\\"{x:1450,y:760,t:1527027632909};\\\", \\\"{x:1451,y:760,t:1527027632925};\\\", \\\"{x:1454,y:760,t:1527027632941};\\\", \\\"{x:1456,y:760,t:1527027632960};\\\", \\\"{x:1458,y:760,t:1527027633056};\\\", \\\"{x:1459,y:760,t:1527027633064};\\\", \\\"{x:1463,y:760,t:1527027633075};\\\", \\\"{x:1466,y:760,t:1527027633091};\\\", \\\"{x:1468,y:760,t:1527027633107};\\\", \\\"{x:1469,y:760,t:1527027633328};\\\", \\\"{x:1470,y:760,t:1527027633344};\\\", \\\"{x:1471,y:760,t:1527027633360};\\\", \\\"{x:1473,y:760,t:1527027633544};\\\", \\\"{x:1476,y:760,t:1527027633560};\\\", \\\"{x:1478,y:760,t:1527027633573};\\\", \\\"{x:1481,y:760,t:1527027633590};\\\", \\\"{x:1483,y:760,t:1527027633606};\\\", \\\"{x:1484,y:760,t:1527027633672};\\\", \\\"{x:1485,y:760,t:1527027633744};\\\", \\\"{x:1484,y:760,t:1527027633888};\\\", \\\"{x:1472,y:760,t:1527027633906};\\\", \\\"{x:1447,y:756,t:1527027633922};\\\", \\\"{x:1393,y:745,t:1527027633939};\\\", \\\"{x:1304,y:734,t:1527027633956};\\\", \\\"{x:1203,y:716,t:1527027633973};\\\", \\\"{x:1104,y:704,t:1527027633990};\\\", \\\"{x:995,y:686,t:1527027634005};\\\", \\\"{x:909,y:671,t:1527027634022};\\\", \\\"{x:858,y:655,t:1527027634039};\\\", \\\"{x:816,y:635,t:1527027634057};\\\", \\\"{x:772,y:615,t:1527027634071};\\\", \\\"{x:746,y:604,t:1527027634089};\\\", \\\"{x:735,y:599,t:1527027634097};\\\", \\\"{x:715,y:590,t:1527027634114};\\\", \\\"{x:692,y:586,t:1527027634131};\\\", \\\"{x:676,y:581,t:1527027634147};\\\", \\\"{x:662,y:576,t:1527027634164};\\\", \\\"{x:645,y:570,t:1527027634180};\\\", \\\"{x:628,y:564,t:1527027634198};\\\", \\\"{x:595,y:554,t:1527027634213};\\\", \\\"{x:581,y:551,t:1527027634230};\\\", \\\"{x:573,y:549,t:1527027634246};\\\", \\\"{x:569,y:547,t:1527027634263};\\\", \\\"{x:567,y:545,t:1527027634280};\\\", \\\"{x:565,y:545,t:1527027634298};\\\", \\\"{x:557,y:543,t:1527027634313};\\\", \\\"{x:544,y:540,t:1527027634330};\\\", \\\"{x:525,y:537,t:1527027634347};\\\", \\\"{x:499,y:535,t:1527027634363};\\\", \\\"{x:460,y:528,t:1527027634381};\\\", \\\"{x:426,y:527,t:1527027634398};\\\", \\\"{x:398,y:527,t:1527027634414};\\\", \\\"{x:379,y:527,t:1527027634431};\\\", \\\"{x:367,y:527,t:1527027634447};\\\", \\\"{x:365,y:527,t:1527027634464};\\\", \\\"{x:360,y:527,t:1527027634480};\\\", \\\"{x:352,y:527,t:1527027634497};\\\", \\\"{x:341,y:527,t:1527027634514};\\\", \\\"{x:327,y:527,t:1527027634531};\\\", \\\"{x:312,y:527,t:1527027634547};\\\", \\\"{x:296,y:527,t:1527027634563};\\\", \\\"{x:278,y:527,t:1527027634581};\\\", \\\"{x:260,y:527,t:1527027634600};\\\", \\\"{x:245,y:527,t:1527027634614};\\\", \\\"{x:235,y:527,t:1527027634631};\\\", \\\"{x:225,y:527,t:1527027634646};\\\", \\\"{x:219,y:528,t:1527027634663};\\\", \\\"{x:212,y:529,t:1527027634680};\\\", \\\"{x:203,y:530,t:1527027634698};\\\", \\\"{x:196,y:531,t:1527027634714};\\\", \\\"{x:191,y:532,t:1527027634731};\\\", \\\"{x:189,y:533,t:1527027634751};\\\", \\\"{x:189,y:534,t:1527027634764};\\\", \\\"{x:188,y:534,t:1527027634780};\\\", \\\"{x:188,y:535,t:1527027634798};\\\", \\\"{x:188,y:538,t:1527027634814};\\\", \\\"{x:188,y:539,t:1527027634832};\\\", \\\"{x:185,y:545,t:1527027634848};\\\", \\\"{x:182,y:547,t:1527027634864};\\\", \\\"{x:179,y:548,t:1527027634880};\\\", \\\"{x:178,y:549,t:1527027634898};\\\", \\\"{x:177,y:549,t:1527027634915};\\\", \\\"{x:176,y:550,t:1527027634931};\\\", \\\"{x:175,y:551,t:1527027634948};\\\", \\\"{x:173,y:552,t:1527027634965};\\\", \\\"{x:171,y:553,t:1527027634981};\\\", \\\"{x:168,y:553,t:1527027634999};\\\", \\\"{x:165,y:553,t:1527027635015};\\\", \\\"{x:164,y:553,t:1527027635159};\\\", \\\"{x:163,y:553,t:1527027635167};\\\", \\\"{x:165,y:553,t:1527027635431};\\\", \\\"{x:172,y:557,t:1527027635447};\\\", \\\"{x:186,y:561,t:1527027635465};\\\", \\\"{x:201,y:563,t:1527027635482};\\\", \\\"{x:217,y:567,t:1527027635497};\\\", \\\"{x:242,y:573,t:1527027635516};\\\", \\\"{x:267,y:575,t:1527027635531};\\\", \\\"{x:297,y:581,t:1527027635548};\\\", \\\"{x:336,y:588,t:1527027635564};\\\", \\\"{x:376,y:595,t:1527027635582};\\\", \\\"{x:424,y:602,t:1527027635599};\\\", \\\"{x:497,y:616,t:1527027635616};\\\", \\\"{x:531,y:621,t:1527027635632};\\\", \\\"{x:567,y:627,t:1527027635649};\\\", \\\"{x:599,y:633,t:1527027635665};\\\", \\\"{x:637,y:641,t:1527027635682};\\\", \\\"{x:680,y:648,t:1527027635700};\\\", \\\"{x:731,y:656,t:1527027635715};\\\", \\\"{x:784,y:664,t:1527027635731};\\\", \\\"{x:821,y:670,t:1527027635748};\\\", \\\"{x:856,y:679,t:1527027635765};\\\", \\\"{x:888,y:684,t:1527027635782};\\\", \\\"{x:932,y:693,t:1527027635798};\\\", \\\"{x:976,y:699,t:1527027635814};\\\", \\\"{x:1045,y:708,t:1527027635832};\\\", \\\"{x:1075,y:712,t:1527027635848};\\\", \\\"{x:1113,y:721,t:1527027635865};\\\", \\\"{x:1143,y:724,t:1527027635882};\\\", \\\"{x:1180,y:731,t:1527027635898};\\\", \\\"{x:1214,y:737,t:1527027635914};\\\", \\\"{x:1244,y:740,t:1527027635932};\\\", \\\"{x:1269,y:744,t:1527027635948};\\\", \\\"{x:1293,y:749,t:1527027635965};\\\", \\\"{x:1312,y:751,t:1527027635982};\\\", \\\"{x:1330,y:753,t:1527027635998};\\\", \\\"{x:1349,y:756,t:1527027636015};\\\", \\\"{x:1382,y:756,t:1527027636032};\\\", \\\"{x:1401,y:759,t:1527027636048};\\\", \\\"{x:1414,y:760,t:1527027636065};\\\", \\\"{x:1427,y:761,t:1527027636083};\\\", \\\"{x:1434,y:763,t:1527027636098};\\\", \\\"{x:1441,y:764,t:1527027636116};\\\", \\\"{x:1448,y:765,t:1527027636132};\\\", \\\"{x:1458,y:766,t:1527027636149};\\\", \\\"{x:1467,y:768,t:1527027636165};\\\", \\\"{x:1477,y:769,t:1527027636182};\\\", \\\"{x:1488,y:770,t:1527027636198};\\\", \\\"{x:1499,y:773,t:1527027636215};\\\", \\\"{x:1516,y:777,t:1527027636231};\\\", \\\"{x:1526,y:777,t:1527027636249};\\\", \\\"{x:1530,y:778,t:1527027636266};\\\", \\\"{x:1524,y:776,t:1527027636329};\\\", \\\"{x:1514,y:772,t:1527027636336};\\\", \\\"{x:1507,y:768,t:1527027636349};\\\", \\\"{x:1486,y:759,t:1527027636365};\\\", \\\"{x:1466,y:754,t:1527027636382};\\\", \\\"{x:1451,y:751,t:1527027636398};\\\", \\\"{x:1434,y:745,t:1527027636415};\\\", \\\"{x:1425,y:741,t:1527027636431};\\\", \\\"{x:1418,y:739,t:1527027636448};\\\", \\\"{x:1409,y:735,t:1527027636465};\\\", \\\"{x:1405,y:735,t:1527027636482};\\\", \\\"{x:1402,y:734,t:1527027636498};\\\", \\\"{x:1399,y:734,t:1527027636515};\\\", \\\"{x:1394,y:733,t:1527027636531};\\\", \\\"{x:1386,y:731,t:1527027636548};\\\", \\\"{x:1377,y:728,t:1527027636565};\\\", \\\"{x:1372,y:727,t:1527027636582};\\\", \\\"{x:1368,y:723,t:1527027636599};\\\", \\\"{x:1362,y:717,t:1527027636615};\\\", \\\"{x:1359,y:713,t:1527027636631};\\\", \\\"{x:1356,y:711,t:1527027636648};\\\", \\\"{x:1354,y:710,t:1527027636665};\\\", \\\"{x:1353,y:709,t:1527027636687};\\\", \\\"{x:1352,y:709,t:1527027636825};\\\", \\\"{x:1352,y:707,t:1527027636832};\\\", \\\"{x:1352,y:705,t:1527027636849};\\\", \\\"{x:1352,y:702,t:1527027636866};\\\", \\\"{x:1351,y:702,t:1527027636882};\\\", \\\"{x:1351,y:701,t:1527027636899};\\\", \\\"{x:1351,y:699,t:1527027636915};\\\", \\\"{x:1351,y:698,t:1527027636960};\\\", \\\"{x:1351,y:697,t:1527027637240};\\\", \\\"{x:1353,y:697,t:1527027637248};\\\", \\\"{x:1354,y:697,t:1527027637267};\\\", \\\"{x:1358,y:697,t:1527027637282};\\\", \\\"{x:1363,y:697,t:1527027637299};\\\", \\\"{x:1366,y:697,t:1527027637316};\\\", \\\"{x:1370,y:697,t:1527027637332};\\\", \\\"{x:1373,y:697,t:1527027637349};\\\", \\\"{x:1379,y:697,t:1527027637365};\\\", \\\"{x:1382,y:697,t:1527027637382};\\\", \\\"{x:1386,y:697,t:1527027637398};\\\", \\\"{x:1393,y:697,t:1527027637416};\\\", \\\"{x:1396,y:697,t:1527027637432};\\\", \\\"{x:1399,y:697,t:1527027637449};\\\", \\\"{x:1403,y:698,t:1527027637466};\\\", \\\"{x:1406,y:698,t:1527027637481};\\\", \\\"{x:1409,y:698,t:1527027637498};\\\", \\\"{x:1412,y:698,t:1527027637515};\\\", \\\"{x:1414,y:699,t:1527027637531};\\\", \\\"{x:1415,y:699,t:1527027637745};\\\", \\\"{x:1416,y:699,t:1527027638184};\\\", \\\"{x:1417,y:699,t:1527027638200};\\\", \\\"{x:1421,y:699,t:1527027638215};\\\", \\\"{x:1428,y:699,t:1527027638232};\\\", \\\"{x:1431,y:699,t:1527027638247};\\\", \\\"{x:1434,y:699,t:1527027638265};\\\", \\\"{x:1436,y:699,t:1527027638281};\\\", \\\"{x:1440,y:699,t:1527027638299};\\\", \\\"{x:1447,y:699,t:1527027638315};\\\", \\\"{x:1452,y:699,t:1527027638331};\\\", \\\"{x:1455,y:699,t:1527027638349};\\\", \\\"{x:1456,y:699,t:1527027638416};\\\", \\\"{x:1457,y:699,t:1527027638432};\\\", \\\"{x:1460,y:699,t:1527027638447};\\\", \\\"{x:1462,y:699,t:1527027638464};\\\", \\\"{x:1463,y:699,t:1527027638482};\\\", \\\"{x:1465,y:699,t:1527027638512};\\\", \\\"{x:1466,y:698,t:1527027638520};\\\", \\\"{x:1467,y:697,t:1527027638532};\\\", \\\"{x:1469,y:697,t:1527027638549};\\\", \\\"{x:1471,y:697,t:1527027638564};\\\", \\\"{x:1472,y:697,t:1527027638582};\\\", \\\"{x:1473,y:697,t:1527027638624};\\\", \\\"{x:1474,y:697,t:1527027638640};\\\", \\\"{x:1475,y:697,t:1527027638648};\\\", \\\"{x:1476,y:696,t:1527027638681};\\\", \\\"{x:1477,y:696,t:1527027638752};\\\", \\\"{x:1478,y:696,t:1527027638764};\\\", \\\"{x:1481,y:696,t:1527027638782};\\\", \\\"{x:1482,y:696,t:1527027638798};\\\", \\\"{x:1483,y:696,t:1527027640689};\\\", \\\"{x:1481,y:696,t:1527027641407};\\\", \\\"{x:1471,y:696,t:1527027641415};\\\", \\\"{x:1459,y:696,t:1527027641430};\\\", \\\"{x:1395,y:690,t:1527027641447};\\\", \\\"{x:1320,y:679,t:1527027641463};\\\", \\\"{x:1246,y:674,t:1527027641480};\\\", \\\"{x:1169,y:663,t:1527027641497};\\\", \\\"{x:1094,y:654,t:1527027641513};\\\", \\\"{x:1016,y:645,t:1527027641531};\\\", \\\"{x:944,y:634,t:1527027641548};\\\", \\\"{x:868,y:622,t:1527027641563};\\\", \\\"{x:814,y:612,t:1527027641580};\\\", \\\"{x:729,y:601,t:1527027641603};\\\", \\\"{x:687,y:596,t:1527027641619};\\\", \\\"{x:655,y:591,t:1527027641636};\\\", \\\"{x:617,y:584,t:1527027641653};\\\", \\\"{x:593,y:582,t:1527027641670};\\\", \\\"{x:572,y:579,t:1527027641689};\\\", \\\"{x:548,y:574,t:1527027641707};\\\", \\\"{x:533,y:572,t:1527027641723};\\\", \\\"{x:517,y:572,t:1527027641739};\\\", \\\"{x:498,y:572,t:1527027641756};\\\", \\\"{x:479,y:572,t:1527027641774};\\\", \\\"{x:463,y:572,t:1527027641790};\\\", \\\"{x:446,y:572,t:1527027641806};\\\", \\\"{x:433,y:572,t:1527027641823};\\\", \\\"{x:417,y:572,t:1527027641839};\\\", \\\"{x:394,y:572,t:1527027641856};\\\", \\\"{x:367,y:572,t:1527027641873};\\\", \\\"{x:344,y:572,t:1527027641890};\\\", \\\"{x:329,y:572,t:1527027641907};\\\", \\\"{x:328,y:572,t:1527027641923};\\\", \\\"{x:337,y:572,t:1527027641988};\\\", \\\"{x:354,y:574,t:1527027641995};\\\", \\\"{x:378,y:577,t:1527027642007};\\\", \\\"{x:466,y:586,t:1527027642022};\\\", \\\"{x:544,y:588,t:1527027642041};\\\", \\\"{x:624,y:595,t:1527027642058};\\\", \\\"{x:663,y:601,t:1527027642074};\\\", \\\"{x:705,y:607,t:1527027642090};\\\", \\\"{x:724,y:608,t:1527027642107};\\\", \\\"{x:735,y:609,t:1527027642123};\\\", \\\"{x:746,y:607,t:1527027642141};\\\", \\\"{x:751,y:604,t:1527027642156};\\\", \\\"{x:753,y:601,t:1527027642174};\\\", \\\"{x:755,y:599,t:1527027642191};\\\", \\\"{x:756,y:595,t:1527027642208};\\\", \\\"{x:756,y:588,t:1527027642224};\\\", \\\"{x:748,y:578,t:1527027642241};\\\", \\\"{x:740,y:570,t:1527027642258};\\\", \\\"{x:733,y:563,t:1527027642274};\\\", \\\"{x:730,y:554,t:1527027642290};\\\", \\\"{x:730,y:551,t:1527027642308};\\\", \\\"{x:730,y:548,t:1527027642324};\\\", \\\"{x:730,y:542,t:1527027642341};\\\", \\\"{x:730,y:539,t:1527027642357};\\\", \\\"{x:736,y:533,t:1527027642374};\\\", \\\"{x:740,y:530,t:1527027642391};\\\", \\\"{x:740,y:529,t:1527027642419};\\\", \\\"{x:739,y:527,t:1527027642435};\\\", \\\"{x:740,y:527,t:1527027642492};\\\", \\\"{x:760,y:528,t:1527027642507};\\\", \\\"{x:793,y:529,t:1527027642524};\\\", \\\"{x:836,y:532,t:1527027642541};\\\", \\\"{x:877,y:535,t:1527027642557};\\\", \\\"{x:896,y:535,t:1527027642574};\\\", \\\"{x:898,y:535,t:1527027642591};\\\", \\\"{x:898,y:533,t:1527027642611};\\\", \\\"{x:897,y:533,t:1527027642625};\\\", \\\"{x:895,y:532,t:1527027642642};\\\", \\\"{x:892,y:531,t:1527027642659};\\\", \\\"{x:890,y:529,t:1527027642675};\\\", \\\"{x:884,y:528,t:1527027642691};\\\", \\\"{x:876,y:526,t:1527027642708};\\\", \\\"{x:864,y:522,t:1527027642726};\\\", \\\"{x:857,y:521,t:1527027642740};\\\", \\\"{x:846,y:520,t:1527027642758};\\\", \\\"{x:837,y:520,t:1527027642774};\\\", \\\"{x:835,y:520,t:1527027642791};\\\", \\\"{x:834,y:520,t:1527027642843};\\\", \\\"{x:834,y:522,t:1527027643139};\\\", \\\"{x:835,y:522,t:1527027643147};\\\", \\\"{x:837,y:523,t:1527027643158};\\\", \\\"{x:841,y:526,t:1527027643174};\\\", \\\"{x:847,y:529,t:1527027643193};\\\", \\\"{x:859,y:536,t:1527027643208};\\\", \\\"{x:881,y:545,t:1527027643226};\\\", \\\"{x:905,y:556,t:1527027643242};\\\", \\\"{x:946,y:571,t:1527027643259};\\\", \\\"{x:1014,y:593,t:1527027643275};\\\", \\\"{x:1059,y:615,t:1527027643292};\\\", \\\"{x:1098,y:632,t:1527027643308};\\\", \\\"{x:1141,y:647,t:1527027643325};\\\", \\\"{x:1174,y:661,t:1527027643342};\\\", \\\"{x:1207,y:674,t:1527027643358};\\\", \\\"{x:1240,y:692,t:1527027643375};\\\", \\\"{x:1264,y:704,t:1527027643392};\\\", \\\"{x:1287,y:719,t:1527027643408};\\\", \\\"{x:1310,y:729,t:1527027643425};\\\", \\\"{x:1333,y:738,t:1527027643442};\\\", \\\"{x:1367,y:751,t:1527027643459};\\\", \\\"{x:1383,y:757,t:1527027643475};\\\", \\\"{x:1401,y:762,t:1527027643493};\\\", \\\"{x:1414,y:765,t:1527027643509};\\\", \\\"{x:1419,y:767,t:1527027643525};\\\", \\\"{x:1420,y:767,t:1527027643543};\\\", \\\"{x:1421,y:767,t:1527027643724};\\\", \\\"{x:1422,y:767,t:1527027643743};\\\", \\\"{x:1423,y:766,t:1527027643759};\\\", \\\"{x:1424,y:765,t:1527027643775};\\\", \\\"{x:1429,y:763,t:1527027643793};\\\", \\\"{x:1430,y:762,t:1527027643809};\\\", \\\"{x:1434,y:761,t:1527027643827};\\\", \\\"{x:1439,y:758,t:1527027643842};\\\", \\\"{x:1445,y:754,t:1527027643859};\\\", \\\"{x:1446,y:752,t:1527027643876};\\\", \\\"{x:1446,y:751,t:1527027643893};\\\", \\\"{x:1446,y:748,t:1527027643909};\\\", \\\"{x:1440,y:737,t:1527027643927};\\\", \\\"{x:1426,y:726,t:1527027643942};\\\", \\\"{x:1406,y:711,t:1527027643960};\\\", \\\"{x:1383,y:698,t:1527027643976};\\\", \\\"{x:1361,y:689,t:1527027643992};\\\", \\\"{x:1354,y:685,t:1527027644008};\\\", \\\"{x:1353,y:683,t:1527027644026};\\\", \\\"{x:1352,y:682,t:1527027644041};\\\", \\\"{x:1352,y:679,t:1527027644059};\\\", \\\"{x:1352,y:676,t:1527027644083};\\\", \\\"{x:1352,y:672,t:1527027644092};\\\", \\\"{x:1356,y:666,t:1527027644109};\\\", \\\"{x:1362,y:661,t:1527027644126};\\\", \\\"{x:1371,y:657,t:1527027644143};\\\", \\\"{x:1379,y:652,t:1527027644159};\\\", \\\"{x:1388,y:648,t:1527027644176};\\\", \\\"{x:1398,y:644,t:1527027644193};\\\", \\\"{x:1409,y:643,t:1527027644209};\\\", \\\"{x:1416,y:640,t:1527027644226};\\\", \\\"{x:1421,y:639,t:1527027644244};\\\", \\\"{x:1423,y:636,t:1527027644259};\\\", \\\"{x:1427,y:635,t:1527027644277};\\\", \\\"{x:1430,y:635,t:1527027644293};\\\", \\\"{x:1435,y:632,t:1527027644309};\\\", \\\"{x:1437,y:632,t:1527027644327};\\\", \\\"{x:1439,y:632,t:1527027644343};\\\", \\\"{x:1442,y:631,t:1527027644360};\\\", \\\"{x:1444,y:631,t:1527027644376};\\\", \\\"{x:1445,y:631,t:1527027644508};\\\", \\\"{x:1441,y:631,t:1527027645213};\\\", \\\"{x:1428,y:631,t:1527027645228};\\\", \\\"{x:1409,y:631,t:1527027645243};\\\", \\\"{x:1383,y:631,t:1527027645260};\\\", \\\"{x:1351,y:631,t:1527027645278};\\\", \\\"{x:1323,y:631,t:1527027645293};\\\", \\\"{x:1279,y:631,t:1527027645310};\\\", \\\"{x:1226,y:631,t:1527027645328};\\\", \\\"{x:1176,y:631,t:1527027645345};\\\", \\\"{x:1142,y:628,t:1527027645361};\\\", \\\"{x:1119,y:627,t:1527027645378};\\\", \\\"{x:1107,y:627,t:1527027645395};\\\", \\\"{x:1102,y:627,t:1527027645410};\\\", \\\"{x:1101,y:627,t:1527027645428};\\\", \\\"{x:1099,y:628,t:1527027645445};\\\", \\\"{x:1098,y:628,t:1527027645461};\\\", \\\"{x:1096,y:629,t:1527027645477};\\\", \\\"{x:1093,y:631,t:1527027645495};\\\", \\\"{x:1087,y:632,t:1527027645511};\\\", \\\"{x:1086,y:632,t:1527027645528};\\\", \\\"{x:1084,y:633,t:1527027645545};\\\", \\\"{x:1088,y:633,t:1527027645652};\\\", \\\"{x:1094,y:633,t:1527027645662};\\\", \\\"{x:1112,y:633,t:1527027645678};\\\", \\\"{x:1136,y:633,t:1527027645693};\\\", \\\"{x:1159,y:633,t:1527027645711};\\\", \\\"{x:1182,y:633,t:1527027645727};\\\", \\\"{x:1199,y:635,t:1527027645744};\\\", \\\"{x:1215,y:635,t:1527027645761};\\\", \\\"{x:1225,y:635,t:1527027645776};\\\", \\\"{x:1234,y:635,t:1527027645794};\\\", \\\"{x:1242,y:632,t:1527027645811};\\\", \\\"{x:1242,y:631,t:1527027645827};\\\", \\\"{x:1245,y:631,t:1527027645844};\\\", \\\"{x:1251,y:631,t:1527027645862};\\\", \\\"{x:1264,y:629,t:1527027645878};\\\", \\\"{x:1283,y:629,t:1527027645895};\\\", \\\"{x:1310,y:629,t:1527027645911};\\\", \\\"{x:1334,y:629,t:1527027645927};\\\", \\\"{x:1356,y:629,t:1527027645944};\\\", \\\"{x:1372,y:629,t:1527027645962};\\\", \\\"{x:1390,y:629,t:1527027645977};\\\", \\\"{x:1405,y:630,t:1527027645994};\\\", \\\"{x:1426,y:632,t:1527027646011};\\\", \\\"{x:1436,y:632,t:1527027646028};\\\", \\\"{x:1443,y:632,t:1527027646045};\\\", \\\"{x:1447,y:632,t:1527027646062};\\\", \\\"{x:1447,y:631,t:1527027646078};\\\", \\\"{x:1448,y:631,t:1527027646094};\\\", \\\"{x:1450,y:631,t:1527027647685};\\\", \\\"{x:1451,y:629,t:1527027647696};\\\", \\\"{x:1455,y:629,t:1527027647714};\\\", \\\"{x:1458,y:629,t:1527027647729};\\\", \\\"{x:1462,y:629,t:1527027647747};\\\", \\\"{x:1465,y:629,t:1527027647763};\\\", \\\"{x:1469,y:629,t:1527027647779};\\\", \\\"{x:1470,y:629,t:1527027647796};\\\", \\\"{x:1473,y:629,t:1527027647813};\\\", \\\"{x:1475,y:629,t:1527027647830};\\\", \\\"{x:1480,y:629,t:1527027647847};\\\", \\\"{x:1485,y:629,t:1527027647864};\\\", \\\"{x:1490,y:629,t:1527027647880};\\\", \\\"{x:1493,y:629,t:1527027647897};\\\", \\\"{x:1496,y:629,t:1527027647914};\\\", \\\"{x:1498,y:629,t:1527027647930};\\\", \\\"{x:1503,y:629,t:1527027647947};\\\", \\\"{x:1513,y:629,t:1527027647963};\\\", \\\"{x:1522,y:631,t:1527027647980};\\\", \\\"{x:1528,y:632,t:1527027647997};\\\", \\\"{x:1534,y:632,t:1527027648014};\\\", \\\"{x:1535,y:633,t:1527027648030};\\\", \\\"{x:1537,y:633,t:1527027648046};\\\", \\\"{x:1535,y:633,t:1527027648115};\\\", \\\"{x:1532,y:632,t:1527027648130};\\\", \\\"{x:1518,y:625,t:1527027648147};\\\", \\\"{x:1487,y:611,t:1527027648164};\\\", \\\"{x:1456,y:603,t:1527027648180};\\\", \\\"{x:1435,y:598,t:1527027648197};\\\", \\\"{x:1423,y:594,t:1527027648213};\\\", \\\"{x:1420,y:593,t:1527027648230};\\\", \\\"{x:1419,y:593,t:1527027648252};\\\", \\\"{x:1417,y:592,t:1527027648264};\\\", \\\"{x:1415,y:591,t:1527027648281};\\\", \\\"{x:1409,y:590,t:1527027648296};\\\", \\\"{x:1399,y:589,t:1527027648313};\\\", \\\"{x:1387,y:588,t:1527027648330};\\\", \\\"{x:1374,y:586,t:1527027648346};\\\", \\\"{x:1360,y:585,t:1527027648363};\\\", \\\"{x:1354,y:585,t:1527027648380};\\\", \\\"{x:1350,y:584,t:1527027648396};\\\", \\\"{x:1344,y:582,t:1527027648413};\\\", \\\"{x:1336,y:581,t:1527027648430};\\\", \\\"{x:1324,y:580,t:1527027648447};\\\", \\\"{x:1312,y:577,t:1527027648463};\\\", \\\"{x:1299,y:574,t:1527027648480};\\\", \\\"{x:1290,y:573,t:1527027648496};\\\", \\\"{x:1281,y:571,t:1527027648513};\\\", \\\"{x:1272,y:567,t:1527027648530};\\\", \\\"{x:1266,y:566,t:1527027648546};\\\", \\\"{x:1264,y:565,t:1527027648563};\\\", \\\"{x:1263,y:564,t:1527027648604};\\\", \\\"{x:1262,y:563,t:1527027648635};\\\", \\\"{x:1261,y:563,t:1527027648651};\\\", \\\"{x:1261,y:562,t:1527027648900};\\\", \\\"{x:1262,y:562,t:1527027648914};\\\", \\\"{x:1262,y:561,t:1527027648931};\\\", \\\"{x:1263,y:561,t:1527027648948};\\\", \\\"{x:1264,y:561,t:1527027648965};\\\", \\\"{x:1267,y:561,t:1527027648980};\\\", \\\"{x:1269,y:561,t:1527027648997};\\\", \\\"{x:1272,y:560,t:1527027649015};\\\", \\\"{x:1275,y:560,t:1527027649030};\\\", \\\"{x:1277,y:560,t:1527027649048};\\\", \\\"{x:1278,y:560,t:1527027649064};\\\", \\\"{x:1279,y:560,t:1527027649080};\\\", \\\"{x:1280,y:560,t:1527027649219};\\\", \\\"{x:1281,y:560,t:1527027649232};\\\", \\\"{x:1282,y:560,t:1527027649372};\\\", \\\"{x:1282,y:561,t:1527027649404};\\\", \\\"{x:1283,y:561,t:1527027649427};\\\", \\\"{x:1284,y:561,t:1527027649686};\\\", \\\"{x:1286,y:561,t:1527027649699};\\\", \\\"{x:1291,y:561,t:1527027649716};\\\", \\\"{x:1298,y:561,t:1527027649731};\\\", \\\"{x:1302,y:561,t:1527027649749};\\\", \\\"{x:1305,y:561,t:1527027649765};\\\", \\\"{x:1310,y:561,t:1527027649782};\\\", \\\"{x:1313,y:561,t:1527027649799};\\\", \\\"{x:1316,y:561,t:1527027649815};\\\", \\\"{x:1318,y:561,t:1527027649832};\\\", \\\"{x:1319,y:561,t:1527027649849};\\\", \\\"{x:1322,y:561,t:1527027649864};\\\", \\\"{x:1326,y:561,t:1527027649881};\\\", \\\"{x:1330,y:561,t:1527027649899};\\\", \\\"{x:1333,y:561,t:1527027649915};\\\", \\\"{x:1338,y:561,t:1527027649932};\\\", \\\"{x:1339,y:562,t:1527027649948};\\\", \\\"{x:1340,y:562,t:1527027649965};\\\", \\\"{x:1342,y:562,t:1527027649982};\\\", \\\"{x:1344,y:562,t:1527027649998};\\\", \\\"{x:1346,y:563,t:1527027650016};\\\", \\\"{x:1347,y:563,t:1527027650032};\\\", \\\"{x:1349,y:563,t:1527027650049};\\\", \\\"{x:1350,y:563,t:1527027650066};\\\", \\\"{x:1351,y:563,t:1527027650082};\\\", \\\"{x:1352,y:563,t:1527027650123};\\\", \\\"{x:1353,y:563,t:1527027650260};\\\", \\\"{x:1354,y:563,t:1527027650267};\\\", \\\"{x:1355,y:563,t:1527027650282};\\\", \\\"{x:1356,y:562,t:1527027650300};\\\", \\\"{x:1358,y:561,t:1527027650315};\\\", \\\"{x:1360,y:561,t:1527027650340};\\\", \\\"{x:1362,y:561,t:1527027650356};\\\", \\\"{x:1363,y:561,t:1527027650366};\\\", \\\"{x:1369,y:561,t:1527027650382};\\\", \\\"{x:1381,y:561,t:1527027650398};\\\", \\\"{x:1392,y:562,t:1527027650416};\\\", \\\"{x:1404,y:562,t:1527027650433};\\\", \\\"{x:1413,y:563,t:1527027650449};\\\", \\\"{x:1416,y:563,t:1527027650466};\\\", \\\"{x:1419,y:563,t:1527027650485};\\\", \\\"{x:1420,y:563,t:1527027650788};\\\", \\\"{x:1422,y:563,t:1527027650804};\\\", \\\"{x:1424,y:563,t:1527027650816};\\\", \\\"{x:1431,y:563,t:1527027650832};\\\", \\\"{x:1436,y:563,t:1527027650850};\\\", \\\"{x:1442,y:564,t:1527027650866};\\\", \\\"{x:1452,y:565,t:1527027650884};\\\", \\\"{x:1458,y:565,t:1527027650899};\\\", \\\"{x:1461,y:565,t:1527027650915};\\\", \\\"{x:1462,y:565,t:1527027650932};\\\", \\\"{x:1464,y:565,t:1527027650949};\\\", \\\"{x:1465,y:565,t:1527027650971};\\\", \\\"{x:1467,y:565,t:1527027651020};\\\", \\\"{x:1468,y:565,t:1527027651132};\\\", \\\"{x:1470,y:565,t:1527027651228};\\\", \\\"{x:1471,y:565,t:1527027651292};\\\", \\\"{x:1474,y:565,t:1527027651300};\\\", \\\"{x:1479,y:565,t:1527027651317};\\\", \\\"{x:1485,y:565,t:1527027651333};\\\", \\\"{x:1489,y:565,t:1527027651350};\\\", \\\"{x:1497,y:565,t:1527027651366};\\\", \\\"{x:1502,y:565,t:1527027651384};\\\", \\\"{x:1505,y:564,t:1527027651399};\\\", \\\"{x:1508,y:564,t:1527027651416};\\\", \\\"{x:1509,y:564,t:1527027651433};\\\", \\\"{x:1510,y:564,t:1527027651450};\\\", \\\"{x:1511,y:563,t:1527027651466};\\\", \\\"{x:1513,y:563,t:1527027651483};\\\", \\\"{x:1515,y:563,t:1527027651499};\\\", \\\"{x:1518,y:563,t:1527027651516};\\\", \\\"{x:1523,y:563,t:1527027651533};\\\", \\\"{x:1525,y:562,t:1527027651549};\\\", \\\"{x:1526,y:562,t:1527027651567};\\\", \\\"{x:1528,y:562,t:1527027651584};\\\", \\\"{x:1531,y:561,t:1527027651600};\\\", \\\"{x:1535,y:561,t:1527027651616};\\\", \\\"{x:1541,y:560,t:1527027651634};\\\", \\\"{x:1542,y:560,t:1527027651649};\\\", \\\"{x:1544,y:560,t:1527027652748};\\\", \\\"{x:1545,y:560,t:1527027652772};\\\", \\\"{x:1546,y:559,t:1527027652804};\\\", \\\"{x:1547,y:559,t:1527027652819};\\\", \\\"{x:1549,y:558,t:1527027652844};\\\", \\\"{x:1551,y:557,t:1527027652868};\\\", \\\"{x:1552,y:556,t:1527027652885};\\\", \\\"{x:1555,y:556,t:1527027652902};\\\", \\\"{x:1559,y:555,t:1527027652918};\\\", \\\"{x:1562,y:555,t:1527027652935};\\\", \\\"{x:1564,y:555,t:1527027652964};\\\", \\\"{x:1565,y:555,t:1527027652971};\\\", \\\"{x:1567,y:555,t:1527027652988};\\\", \\\"{x:1569,y:555,t:1527027653002};\\\", \\\"{x:1571,y:554,t:1527027653018};\\\", \\\"{x:1575,y:553,t:1527027653035};\\\", \\\"{x:1576,y:553,t:1527027653052};\\\", \\\"{x:1578,y:553,t:1527027653067};\\\", \\\"{x:1579,y:553,t:1527027653085};\\\", \\\"{x:1581,y:553,t:1527027653101};\\\", \\\"{x:1584,y:553,t:1527027653117};\\\", \\\"{x:1586,y:553,t:1527027653134};\\\", \\\"{x:1588,y:553,t:1527027653151};\\\", \\\"{x:1592,y:553,t:1527027653168};\\\", \\\"{x:1594,y:553,t:1527027653184};\\\", \\\"{x:1597,y:553,t:1527027653201};\\\", \\\"{x:1599,y:554,t:1527027653218};\\\", \\\"{x:1600,y:555,t:1527027653234};\\\", \\\"{x:1601,y:555,t:1527027653251};\\\", \\\"{x:1602,y:556,t:1527027653380};\\\", \\\"{x:1603,y:557,t:1527027653468};\\\", \\\"{x:1605,y:558,t:1527027653499};\\\", \\\"{x:1606,y:558,t:1527027653515};\\\", \\\"{x:1607,y:558,t:1527027653523};\\\", \\\"{x:1608,y:558,t:1527027653572};\\\", \\\"{x:1609,y:559,t:1527027653587};\\\", \\\"{x:1610,y:559,t:1527027653602};\\\", \\\"{x:1611,y:559,t:1527027653619};\\\", \\\"{x:1621,y:559,t:1527027653636};\\\", \\\"{x:1626,y:559,t:1527027653652};\\\", \\\"{x:1632,y:559,t:1527027653669};\\\", \\\"{x:1638,y:559,t:1527027653686};\\\", \\\"{x:1649,y:559,t:1527027653702};\\\", \\\"{x:1662,y:559,t:1527027653719};\\\", \\\"{x:1676,y:559,t:1527027653736};\\\", \\\"{x:1686,y:561,t:1527027653752};\\\", \\\"{x:1688,y:561,t:1527027653769};\\\", \\\"{x:1689,y:561,t:1527027653786};\\\", \\\"{x:1690,y:561,t:1527027653828};\\\", \\\"{x:1689,y:561,t:1527027653859};\\\", \\\"{x:1685,y:561,t:1527027653869};\\\", \\\"{x:1669,y:561,t:1527027653886};\\\", \\\"{x:1644,y:561,t:1527027653903};\\\", \\\"{x:1611,y:563,t:1527027653919};\\\", \\\"{x:1580,y:563,t:1527027653936};\\\", \\\"{x:1543,y:563,t:1527027653953};\\\", \\\"{x:1510,y:563,t:1527027653969};\\\", \\\"{x:1487,y:563,t:1527027653985};\\\", \\\"{x:1470,y:563,t:1527027654003};\\\", \\\"{x:1455,y:563,t:1527027654018};\\\", \\\"{x:1430,y:563,t:1527027654036};\\\", \\\"{x:1414,y:564,t:1527027654054};\\\", \\\"{x:1401,y:564,t:1527027654070};\\\", \\\"{x:1389,y:564,t:1527027654086};\\\", \\\"{x:1375,y:564,t:1527027654102};\\\", \\\"{x:1361,y:564,t:1527027654119};\\\", \\\"{x:1353,y:564,t:1527027654136};\\\", \\\"{x:1346,y:564,t:1527027654153};\\\", \\\"{x:1337,y:564,t:1527027654169};\\\", \\\"{x:1329,y:566,t:1527027654186};\\\", \\\"{x:1316,y:566,t:1527027654203};\\\", \\\"{x:1296,y:568,t:1527027654219};\\\", \\\"{x:1284,y:568,t:1527027654236};\\\", \\\"{x:1273,y:568,t:1527027654254};\\\", \\\"{x:1261,y:567,t:1527027654270};\\\", \\\"{x:1254,y:565,t:1527027654286};\\\", \\\"{x:1246,y:564,t:1527027654303};\\\", \\\"{x:1240,y:562,t:1527027654320};\\\", \\\"{x:1237,y:562,t:1527027654336};\\\", \\\"{x:1239,y:562,t:1527027654404};\\\", \\\"{x:1247,y:562,t:1527027654420};\\\", \\\"{x:1253,y:562,t:1527027654436};\\\", \\\"{x:1261,y:562,t:1527027654453};\\\", \\\"{x:1269,y:561,t:1527027654470};\\\", \\\"{x:1275,y:561,t:1527027654486};\\\", \\\"{x:1278,y:561,t:1527027654503};\\\", \\\"{x:1283,y:561,t:1527027654520};\\\", \\\"{x:1292,y:561,t:1527027654537};\\\", \\\"{x:1307,y:561,t:1527027654553};\\\", \\\"{x:1326,y:561,t:1527027654570};\\\", \\\"{x:1336,y:561,t:1527027654587};\\\", \\\"{x:1341,y:561,t:1527027654603};\\\", \\\"{x:1344,y:560,t:1527027654620};\\\", \\\"{x:1346,y:560,t:1527027654637};\\\", \\\"{x:1350,y:560,t:1527027654654};\\\", \\\"{x:1356,y:559,t:1527027654670};\\\", \\\"{x:1361,y:558,t:1527027654687};\\\", \\\"{x:1363,y:557,t:1527027654703};\\\", \\\"{x:1362,y:557,t:1527027654844};\\\", \\\"{x:1360,y:557,t:1527027654853};\\\", \\\"{x:1359,y:557,t:1527027654870};\\\", \\\"{x:1357,y:557,t:1527027654887};\\\", \\\"{x:1356,y:557,t:1527027654904};\\\", \\\"{x:1354,y:557,t:1527027654931};\\\", \\\"{x:1353,y:557,t:1527027654938};\\\", \\\"{x:1352,y:557,t:1527027654954};\\\", \\\"{x:1350,y:557,t:1527027654970};\\\", \\\"{x:1350,y:558,t:1527027654987};\\\", \\\"{x:1348,y:558,t:1527027655004};\\\", \\\"{x:1347,y:558,t:1527027655020};\\\", \\\"{x:1350,y:558,t:1527027655172};\\\", \\\"{x:1356,y:558,t:1527027655187};\\\", \\\"{x:1363,y:558,t:1527027655203};\\\", \\\"{x:1370,y:558,t:1527027655220};\\\", \\\"{x:1378,y:558,t:1527027655237};\\\", \\\"{x:1382,y:558,t:1527027655254};\\\", \\\"{x:1386,y:558,t:1527027655270};\\\", \\\"{x:1389,y:558,t:1527027655287};\\\", \\\"{x:1391,y:558,t:1527027655304};\\\", \\\"{x:1392,y:558,t:1527027655320};\\\", \\\"{x:1393,y:558,t:1527027655337};\\\", \\\"{x:1394,y:558,t:1527027655354};\\\", \\\"{x:1395,y:558,t:1527027655428};\\\", \\\"{x:1398,y:558,t:1527027655437};\\\", \\\"{x:1401,y:558,t:1527027655454};\\\", \\\"{x:1404,y:560,t:1527027655471};\\\", \\\"{x:1409,y:561,t:1527027655487};\\\", \\\"{x:1413,y:562,t:1527027655504};\\\", \\\"{x:1414,y:562,t:1527027655554};\\\", \\\"{x:1416,y:562,t:1527027655675};\\\", \\\"{x:1417,y:562,t:1527027655688};\\\", \\\"{x:1425,y:562,t:1527027655704};\\\", \\\"{x:1433,y:562,t:1527027655721};\\\", \\\"{x:1441,y:562,t:1527027655738};\\\", \\\"{x:1447,y:562,t:1527027655754};\\\", \\\"{x:1456,y:562,t:1527027655771};\\\", \\\"{x:1463,y:562,t:1527027655787};\\\", \\\"{x:1468,y:562,t:1527027655804};\\\", \\\"{x:1474,y:562,t:1527027655821};\\\", \\\"{x:1481,y:562,t:1527027655838};\\\", \\\"{x:1484,y:562,t:1527027655855};\\\", \\\"{x:1483,y:562,t:1527027656250};\\\", \\\"{x:1482,y:562,t:1527027657532};\\\", \\\"{x:1481,y:561,t:1527027657548};\\\", \\\"{x:1480,y:561,t:1527027658452};\\\", \\\"{x:1477,y:561,t:1527027658459};\\\", \\\"{x:1473,y:561,t:1527027658473};\\\", \\\"{x:1456,y:561,t:1527027658490};\\\", \\\"{x:1398,y:561,t:1527027658507};\\\", \\\"{x:1331,y:561,t:1527027658523};\\\", \\\"{x:1275,y:561,t:1527027658540};\\\", \\\"{x:1233,y:561,t:1527027658557};\\\", \\\"{x:1198,y:561,t:1527027658575};\\\", \\\"{x:1170,y:561,t:1527027658590};\\\", \\\"{x:1131,y:561,t:1527027658607};\\\", \\\"{x:1078,y:561,t:1527027658624};\\\", \\\"{x:1010,y:564,t:1527027658640};\\\", \\\"{x:935,y:566,t:1527027658658};\\\", \\\"{x:876,y:566,t:1527027658673};\\\", \\\"{x:812,y:566,t:1527027658690};\\\", \\\"{x:742,y:565,t:1527027658702};\\\", \\\"{x:676,y:560,t:1527027658720};\\\", \\\"{x:622,y:557,t:1527027658737};\\\", \\\"{x:589,y:556,t:1527027658754};\\\", \\\"{x:560,y:554,t:1527027658770};\\\", \\\"{x:545,y:553,t:1527027658787};\\\", \\\"{x:540,y:553,t:1527027658805};\\\", \\\"{x:538,y:553,t:1527027658820};\\\", \\\"{x:537,y:552,t:1527027658875};\\\", \\\"{x:537,y:551,t:1527027658887};\\\", \\\"{x:540,y:546,t:1527027658905};\\\", \\\"{x:552,y:542,t:1527027658921};\\\", \\\"{x:568,y:538,t:1527027658939};\\\", \\\"{x:584,y:534,t:1527027658955};\\\", \\\"{x:589,y:533,t:1527027658970};\\\", \\\"{x:590,y:533,t:1527027658988};\\\", \\\"{x:592,y:533,t:1527027659005};\\\", \\\"{x:593,y:533,t:1527027659022};\\\", \\\"{x:594,y:532,t:1527027659091};\\\", \\\"{x:596,y:529,t:1527027659109};\\\", \\\"{x:597,y:527,t:1527027659123};\\\", \\\"{x:599,y:525,t:1527027659138};\\\", \\\"{x:599,y:522,t:1527027659155};\\\", \\\"{x:600,y:521,t:1527027659170};\\\", \\\"{x:600,y:520,t:1527027659188};\\\", \\\"{x:601,y:518,t:1527027659205};\\\", \\\"{x:603,y:516,t:1527027659222};\\\", \\\"{x:607,y:514,t:1527027659237};\\\", \\\"{x:608,y:512,t:1527027659254};\\\", \\\"{x:609,y:512,t:1527027659466};\\\", \\\"{x:611,y:512,t:1527027659474};\\\", \\\"{x:612,y:512,t:1527027659487};\\\", \\\"{x:618,y:512,t:1527027659505};\\\", \\\"{x:631,y:515,t:1527027659522};\\\", \\\"{x:654,y:521,t:1527027659538};\\\", \\\"{x:710,y:527,t:1527027659554};\\\", \\\"{x:771,y:543,t:1527027659572};\\\", \\\"{x:840,y:551,t:1527027659588};\\\", \\\"{x:912,y:562,t:1527027659605};\\\", \\\"{x:996,y:573,t:1527027659622};\\\", \\\"{x:1060,y:581,t:1527027659637};\\\", \\\"{x:1110,y:589,t:1527027659654};\\\", \\\"{x:1152,y:595,t:1527027659671};\\\", \\\"{x:1181,y:600,t:1527027659688};\\\", \\\"{x:1210,y:603,t:1527027659705};\\\", \\\"{x:1240,y:607,t:1527027659721};\\\", \\\"{x:1279,y:613,t:1527027659738};\\\", \\\"{x:1301,y:615,t:1527027659755};\\\", \\\"{x:1323,y:618,t:1527027659772};\\\", \\\"{x:1338,y:620,t:1527027659790};\\\", \\\"{x:1353,y:620,t:1527027659805};\\\", \\\"{x:1364,y:620,t:1527027659822};\\\", \\\"{x:1370,y:620,t:1527027659839};\\\", \\\"{x:1378,y:620,t:1527027659856};\\\", \\\"{x:1383,y:620,t:1527027659873};\\\", \\\"{x:1386,y:620,t:1527027659889};\\\", \\\"{x:1388,y:618,t:1527027659906};\\\", \\\"{x:1390,y:615,t:1527027659922};\\\", \\\"{x:1396,y:611,t:1527027659939};\\\", \\\"{x:1398,y:610,t:1527027659956};\\\", \\\"{x:1403,y:608,t:1527027659972};\\\", \\\"{x:1405,y:608,t:1527027659989};\\\", \\\"{x:1409,y:606,t:1527027660005};\\\", \\\"{x:1410,y:606,t:1527027660022};\\\", \\\"{x:1411,y:604,t:1527027660039};\\\", \\\"{x:1414,y:602,t:1527027660056};\\\", \\\"{x:1417,y:599,t:1527027660072};\\\", \\\"{x:1423,y:593,t:1527027660089};\\\", \\\"{x:1428,y:590,t:1527027660105};\\\", \\\"{x:1432,y:588,t:1527027660123};\\\", \\\"{x:1440,y:585,t:1527027660140};\\\", \\\"{x:1448,y:582,t:1527027660155};\\\", \\\"{x:1452,y:582,t:1527027660172};\\\", \\\"{x:1455,y:581,t:1527027660189};\\\", \\\"{x:1457,y:581,t:1527027660211};\\\", \\\"{x:1458,y:581,t:1527027660222};\\\", \\\"{x:1460,y:580,t:1527027660240};\\\", \\\"{x:1467,y:580,t:1527027660256};\\\", \\\"{x:1474,y:580,t:1527027660272};\\\", \\\"{x:1482,y:580,t:1527027660289};\\\", \\\"{x:1490,y:577,t:1527027660306};\\\", \\\"{x:1492,y:577,t:1527027660322};\\\", \\\"{x:1494,y:577,t:1527027660339};\\\", \\\"{x:1495,y:576,t:1527027660356};\\\", \\\"{x:1497,y:576,t:1527027660372};\\\", \\\"{x:1500,y:574,t:1527027660389};\\\", \\\"{x:1501,y:574,t:1527027660406};\\\", \\\"{x:1504,y:573,t:1527027660423};\\\", \\\"{x:1505,y:571,t:1527027660443};\\\", \\\"{x:1506,y:571,t:1527027660459};\\\", \\\"{x:1507,y:571,t:1527027660485};\\\", \\\"{x:1507,y:570,t:1527027660580};\\\", \\\"{x:1507,y:568,t:1527027660589};\\\", \\\"{x:1498,y:567,t:1527027660606};\\\", \\\"{x:1484,y:569,t:1527027660623};\\\", \\\"{x:1469,y:575,t:1527027660640};\\\", \\\"{x:1468,y:575,t:1527027660656};\\\", \\\"{x:1465,y:578,t:1527027660673};\\\", \\\"{x:1460,y:584,t:1527027660690};\\\", \\\"{x:1458,y:588,t:1527027660707};\\\", \\\"{x:1457,y:590,t:1527027660723};\\\", \\\"{x:1457,y:592,t:1527027660812};\\\", \\\"{x:1457,y:596,t:1527027660823};\\\", \\\"{x:1454,y:608,t:1527027660839};\\\", \\\"{x:1429,y:620,t:1527027660857};\\\", \\\"{x:1377,y:643,t:1527027660873};\\\", \\\"{x:1303,y:670,t:1527027660889};\\\", \\\"{x:1198,y:715,t:1527027660906};\\\", \\\"{x:1026,y:771,t:1527027660923};\\\", \\\"{x:898,y:810,t:1527027660939};\\\", \\\"{x:763,y:842,t:1527027660956};\\\", \\\"{x:626,y:874,t:1527027660973};\\\", \\\"{x:498,y:895,t:1527027660989};\\\", \\\"{x:365,y:916,t:1527027661006};\\\", \\\"{x:256,y:936,t:1527027661023};\\\", \\\"{x:183,y:949,t:1527027661039};\\\", \\\"{x:137,y:958,t:1527027661057};\\\", \\\"{x:111,y:959,t:1527027661073};\\\", \\\"{x:101,y:959,t:1527027661090};\\\", \\\"{x:97,y:959,t:1527027661106};\\\", \\\"{x:97,y:958,t:1527027661138};\\\", \\\"{x:97,y:956,t:1527027661146};\\\", \\\"{x:100,y:953,t:1527027661156};\\\", \\\"{x:114,y:936,t:1527027661173};\\\", \\\"{x:133,y:922,t:1527027661189};\\\", \\\"{x:158,y:909,t:1527027661205};\\\", \\\"{x:193,y:893,t:1527027661223};\\\", \\\"{x:234,y:874,t:1527027661239};\\\", \\\"{x:265,y:861,t:1527027661256};\\\", \\\"{x:298,y:848,t:1527027661273};\\\", \\\"{x:323,y:838,t:1527027661290};\\\", \\\"{x:347,y:826,t:1527027661306};\\\", \\\"{x:376,y:812,t:1527027661322};\\\", \\\"{x:389,y:807,t:1527027661339};\\\", \\\"{x:395,y:803,t:1527027661356};\\\", \\\"{x:402,y:799,t:1527027661373};\\\", \\\"{x:408,y:796,t:1527027661391};\\\", \\\"{x:412,y:794,t:1527027661407};\\\", \\\"{x:426,y:786,t:1527027661422};\\\", \\\"{x:446,y:776,t:1527027661439};\\\", \\\"{x:466,y:767,t:1527027661457};\\\", \\\"{x:483,y:758,t:1527027661473};\\\", \\\"{x:487,y:756,t:1527027661490};\\\", \\\"{x:488,y:755,t:1527027661506};\\\", \\\"{x:489,y:755,t:1527027661571};\\\", \\\"{x:490,y:753,t:1527027661579};\\\", \\\"{x:492,y:752,t:1527027661590};\\\", \\\"{x:494,y:750,t:1527027661606};\\\", \\\"{x:494,y:751,t:1527027661907};\\\", \\\"{x:494,y:752,t:1527027661939};\\\", \\\"{x:494,y:753,t:1527027661955};\\\", \\\"{x:494,y:754,t:1527027661963};\\\", \\\"{x:494,y:755,t:1527027662092};\\\" ] }, { \\\"rt\\\": 33013, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 534107, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"C30CF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"F and B starts their shifts,\\\\nJ ends its shift at 12\\\\n\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 7745, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 542859, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"C30CF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 11321, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Mandarin or Cantonese\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 555199, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"C30CF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 3578, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 559867, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"C30CF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"C30CF\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 167, dom: 1463, initialDom: 1563",
  "javascriptErrors": []
}