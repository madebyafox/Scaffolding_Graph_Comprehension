var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "5dbd3226c1ed328ddd3a7491b3555b81",
  "created": "2018-05-14T13:08:14.0167748-07:00",
  "lastActivity": "2018-05-14T13:08:52.6327748-07:00",
  "pageViews": [
    {
      "id": "0514149799f6c22faca7c743112290bc014c8979",
      "startTime": "2018-05-14T13:08:14.0167748-07:00",
      "endTime": "2018-05-14T13:08:52.6327748-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/4",
      "visitTime": 38616,
      "engagementTime": 33345,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 38616,
  "engagementTime": 33345,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=CKRHQ",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "319f37e3c63ff9b3201ddd3d4b1bafcb",
  "gdpr": false
}