var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["06010568579f1c156c48796c9beb11b23d0280e3"] = {
  "startTime": "2018-06-01T18:07:05.8049661Z",
  "websitePageUrl": "/",
  "visitTime": 127389,
  "engagementTime": 52019,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "97b2233c7c9c983767619aa42091b982",
    "created": "2018-06-01T18:07:05.8049661+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "d5c688158c7d09cc983ef301937bdcb8",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/97b2233c7c9c983767619aa42091b982/play"
  },
  "events": [
    {
      "t": 102,
      "e": 102,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 102,
      "e": 102,
      "ty": 2,
      "x": 1334,
      "y": 378
    },
    {
      "t": 201,
      "e": 201,
      "ty": 2,
      "x": 1047,
      "y": 446
    },
    {
      "t": 252,
      "e": 252,
      "ty": 41,
      "x": 33335,
      "y": 27199,
      "ta": "html > body"
    },
    {
      "t": 301,
      "e": 301,
      "ty": 2,
      "x": 976,
      "y": 455
    },
    {
      "t": 307,
      "e": 307,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 972,
      "y": 455
    },
    {
      "t": 1002,
      "e": 1002,
      "ty": 41,
      "x": 33450,
      "y": 25271,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 972,
      "y": 521
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 33450,
      "y": 26336,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 4400,
      "e": 4400,
      "ty": 2,
      "x": 994,
      "y": 558
    },
    {
      "t": 4500,
      "e": 4500,
      "ty": 41,
      "x": 34651,
      "y": 29367,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10000,
      "e": 9500,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 18101,
      "e": 9500,
      "ty": 2,
      "x": 943,
      "y": 566
    },
    {
      "t": 18200,
      "e": 9599,
      "ty": 2,
      "x": 696,
      "y": 572
    },
    {
      "t": 18251,
      "e": 9650,
      "ty": 41,
      "x": 18377,
      "y": 30514,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 18500,
      "e": 9899,
      "ty": 2,
      "x": 872,
      "y": 402
    },
    {
      "t": 18500,
      "e": 9899,
      "ty": 41,
      "x": 27988,
      "y": 16588,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 18601,
      "e": 10000,
      "ty": 2,
      "x": 891,
      "y": 362
    },
    {
      "t": 18751,
      "e": 10150,
      "ty": 41,
      "x": 29026,
      "y": 13311,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 18900,
      "e": 10299,
      "ty": 2,
      "x": 872,
      "y": 358
    },
    {
      "t": 19000,
      "e": 10399,
      "ty": 2,
      "x": 866,
      "y": 361
    },
    {
      "t": 19001,
      "e": 10400,
      "ty": 41,
      "x": 27661,
      "y": 13229,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 19101,
      "e": 10500,
      "ty": 2,
      "x": 822,
      "y": 366
    },
    {
      "t": 19250,
      "e": 10649,
      "ty": 41,
      "x": 24657,
      "y": 14130,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 19301,
      "e": 10700,
      "ty": 2,
      "x": 794,
      "y": 401
    },
    {
      "t": 19500,
      "e": 10899,
      "ty": 41,
      "x": 23729,
      "y": 16506,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 20801,
      "e": 12200,
      "ty": 2,
      "x": 795,
      "y": 401
    },
    {
      "t": 20900,
      "e": 12299,
      "ty": 2,
      "x": 795,
      "y": 400
    },
    {
      "t": 21001,
      "e": 12400,
      "ty": 41,
      "x": 23783,
      "y": 16424,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 30002,
      "e": 17400,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 92010,
      "e": 17400,
      "ty": 2,
      "x": 784,
      "y": 396
    },
    {
      "t": 92012,
      "e": 17402,
      "ty": 41,
      "x": 24133,
      "y": 9837,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 92111,
      "e": 17501,
      "ty": 2,
      "x": 755,
      "y": 382
    },
    {
      "t": 92210,
      "e": 17600,
      "ty": 2,
      "x": 787,
      "y": 401
    },
    {
      "t": 92261,
      "e": 17651,
      "ty": 41,
      "x": 27577,
      "y": 17428,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 92311,
      "e": 17701,
      "ty": 2,
      "x": 1013,
      "y": 629
    },
    {
      "t": 92411,
      "e": 17801,
      "ty": 2,
      "x": 1306,
      "y": 1135
    },
    {
      "t": 92510,
      "e": 17900,
      "ty": 2,
      "x": 1307,
      "y": 1149
    },
    {
      "t": 92511,
      "e": 17901,
      "ty": 41,
      "x": 44734,
      "y": 63208,
      "ta": "> div.masterdiv"
    },
    {
      "t": 92710,
      "e": 18100,
      "ty": 2,
      "x": 1262,
      "y": 1109
    },
    {
      "t": 92761,
      "e": 18151,
      "ty": 41,
      "x": 39532,
      "y": 61055,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 92811,
      "e": 18201,
      "ty": 2,
      "x": 1009,
      "y": 982
    },
    {
      "t": 92911,
      "e": 18301,
      "ty": 2,
      "x": 872,
      "y": 929
    },
    {
      "t": 93010,
      "e": 18400,
      "ty": 2,
      "x": 841,
      "y": 924
    },
    {
      "t": 93010,
      "e": 18400,
      "ty": 41,
      "x": 7887,
      "y": 47708,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 93110,
      "e": 18500,
      "ty": 2,
      "x": 841,
      "y": 937
    },
    {
      "t": 93261,
      "e": 18651,
      "ty": 41,
      "x": 26937,
      "y": 56139,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 93410,
      "e": 18800,
      "ty": 2,
      "x": 842,
      "y": 935
    },
    {
      "t": 93511,
      "e": 18901,
      "ty": 41,
      "x": 26986,
      "y": 56000,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 93610,
      "e": 19000,
      "ty": 2,
      "x": 857,
      "y": 926
    },
    {
      "t": 93696,
      "e": 19086,
      "ty": 3,
      "x": 859,
      "y": 925,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 93710,
      "e": 19100,
      "ty": 2,
      "x": 859,
      "y": 925
    },
    {
      "t": 93761,
      "e": 19151,
      "ty": 41,
      "x": 11666,
      "y": 50687,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 93793,
      "e": 19183,
      "ty": 4,
      "x": 11666,
      "y": 50687,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 93793,
      "e": 19183,
      "ty": 5,
      "x": 859,
      "y": 925,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 93794,
      "e": 19184,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 93798,
      "e": 19188,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 94011,
      "e": 19401,
      "ty": 2,
      "x": 895,
      "y": 939
    },
    {
      "t": 94011,
      "e": 19401,
      "ty": 41,
      "x": 29594,
      "y": 56277,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 94110,
      "e": 19500,
      "ty": 2,
      "x": 916,
      "y": 957
    },
    {
      "t": 94261,
      "e": 19651,
      "ty": 41,
      "x": 30627,
      "y": 57523,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 94310,
      "e": 19700,
      "ty": 2,
      "x": 923,
      "y": 957
    },
    {
      "t": 94410,
      "e": 19800,
      "ty": 2,
      "x": 932,
      "y": 982
    },
    {
      "t": 94511,
      "e": 19901,
      "ty": 2,
      "x": 944,
      "y": 1072
    },
    {
      "t": 94512,
      "e": 19902,
      "ty": 41,
      "x": 18841,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 94611,
      "e": 20001,
      "ty": 2,
      "x": 953,
      "y": 1114
    },
    {
      "t": 94711,
      "e": 20101,
      "ty": 2,
      "x": 961,
      "y": 1121
    },
    {
      "t": 94761,
      "e": 20151,
      "ty": 41,
      "x": 38150,
      "y": 20116,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 94811,
      "e": 20201,
      "ty": 2,
      "x": 975,
      "y": 1099
    },
    {
      "t": 94911,
      "e": 20301,
      "ty": 2,
      "x": 975,
      "y": 1097
    },
    {
      "t": 95011,
      "e": 20401,
      "ty": 41,
      "x": 35771,
      "y": 46862,
      "ta": "#start"
    },
    {
      "t": 95992,
      "e": 21382,
      "ty": 3,
      "x": 975,
      "y": 1097,
      "ta": "#start"
    },
    {
      "t": 95992,
      "e": 21382,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 95992,
      "e": 21382,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 96095,
      "e": 21485,
      "ty": 4,
      "x": 35771,
      "y": 46862,
      "ta": "#start"
    },
    {
      "t": 96097,
      "e": 21487,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 96098,
      "e": 21488,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 96098,
      "e": 21488,
      "ty": 5,
      "x": 975,
      "y": 1097,
      "ta": "#start"
    },
    {
      "t": 97099,
      "e": 22489,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 98410,
      "e": 23800,
      "ty": 2,
      "x": 981,
      "y": 916
    },
    {
      "t": 98446,
      "e": 23836,
      "ty": 6,
      "x": 948,
      "y": 711,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 98462,
      "e": 23852,
      "ty": 7,
      "x": 938,
      "y": 672,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 98495,
      "e": 23885,
      "ty": 6,
      "x": 929,
      "y": 604,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 98510,
      "e": 23900,
      "ty": 2,
      "x": 929,
      "y": 604
    },
    {
      "t": 98511,
      "e": 23901,
      "ty": 41,
      "x": 26170,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 98610,
      "e": 24000,
      "ty": 2,
      "x": 924,
      "y": 588
    },
    {
      "t": 98761,
      "e": 24151,
      "ty": 41,
      "x": 25089,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 98810,
      "e": 24200,
      "ty": 2,
      "x": 924,
      "y": 591
    },
    {
      "t": 98856,
      "e": 24246,
      "ty": 3,
      "x": 924,
      "y": 591,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 98856,
      "e": 24246,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 98927,
      "e": 24317,
      "ty": 4,
      "x": 25089,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 98927,
      "e": 24317,
      "ty": 5,
      "x": 924,
      "y": 591,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 99262,
      "e": 24652,
      "ty": 41,
      "x": 25089,
      "y": 24965,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 99310,
      "e": 24700,
      "ty": 2,
      "x": 924,
      "y": 597
    },
    {
      "t": 99410,
      "e": 24800,
      "ty": 2,
      "x": 924,
      "y": 600
    },
    {
      "t": 99511,
      "e": 24901,
      "ty": 41,
      "x": 25089,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 99511,
      "e": 24901,
      "ty": 2,
      "x": 924,
      "y": 602
    },
    {
      "t": 99610,
      "e": 25000,
      "ty": 2,
      "x": 924,
      "y": 604
    },
    {
      "t": 99630,
      "e": 25020,
      "ty": 7,
      "x": 924,
      "y": 607,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 99710,
      "e": 25100,
      "ty": 2,
      "x": 924,
      "y": 616
    },
    {
      "t": 99761,
      "e": 25151,
      "ty": 41,
      "x": 25089,
      "y": 704,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 100011,
      "e": 25401,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 100581,
      "e": 25971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 100699,
      "e": 26089,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": ""
    },
    {
      "t": 100827,
      "e": 26217,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "88"
    },
    {
      "t": 100828,
      "e": 26218,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 100923,
      "e": 26313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "X"
    },
    {
      "t": 101083,
      "e": 26473,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 101083,
      "e": 26473,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 101211,
      "e": 26601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 101211,
      "e": 26601,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 101227,
      "e": 26617,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "XRA"
    },
    {
      "t": 101316,
      "e": 26706,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "XRA"
    },
    {
      "t": 101323,
      "e": 26713,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "89"
    },
    {
      "t": 101323,
      "e": 26713,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 101387,
      "e": 26777,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "XRAY"
    },
    {
      "t": 101604,
      "e": 26994,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 101605,
      "e": 26995,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "XRAY"
    },
    {
      "t": 101606,
      "e": 26996,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 101607,
      "e": 26997,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 101675,
      "e": 27065,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 102580,
      "e": 27970,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 102708,
      "e": 28098,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 103036,
      "e": 28426,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "51"
    },
    {
      "t": 103037,
      "e": 28427,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 103099,
      "e": 28489,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "3"
    },
    {
      "t": 103179,
      "e": 28569,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 103180,
      "e": 28570,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 103243,
      "e": 28633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31"
    },
    {
      "t": 103332,
      "e": 28722,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 103333,
      "e": 28723,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 103396,
      "e": 28786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31*"
    },
    {
      "t": 103611,
      "e": 29001,
      "ty": 2,
      "x": 922,
      "y": 609
    },
    {
      "t": 103761,
      "e": 29151,
      "ty": 41,
      "x": 25089,
      "y": 61306,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 103811,
      "e": 29201,
      "ty": 2,
      "x": 930,
      "y": 611
    },
    {
      "t": 103910,
      "e": 29300,
      "ty": 2,
      "x": 930,
      "y": 612
    },
    {
      "t": 104011,
      "e": 29401,
      "ty": 41,
      "x": 26387,
      "y": 63420,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 104411,
      "e": 29801,
      "ty": 2,
      "x": 930,
      "y": 643
    },
    {
      "t": 104511,
      "e": 29901,
      "ty": 2,
      "x": 931,
      "y": 661
    },
    {
      "t": 104511,
      "e": 29901,
      "ty": 41,
      "x": 26603,
      "y": 32415,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 104585,
      "e": 29975,
      "ty": 6,
      "x": 933,
      "y": 685,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 104611,
      "e": 30001,
      "ty": 2,
      "x": 934,
      "y": 687
    },
    {
      "t": 104711,
      "e": 30101,
      "ty": 2,
      "x": 938,
      "y": 697
    },
    {
      "t": 104735,
      "e": 30125,
      "ty": 7,
      "x": 939,
      "y": 701,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 104761,
      "e": 30151,
      "ty": 41,
      "x": 28549,
      "y": 62011,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 104768,
      "e": 30158,
      "ty": 6,
      "x": 941,
      "y": 709,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 104811,
      "e": 30201,
      "ty": 2,
      "x": 943,
      "y": 716
    },
    {
      "t": 104911,
      "e": 30301,
      "ty": 2,
      "x": 943,
      "y": 720
    },
    {
      "t": 105012,
      "e": 30402,
      "ty": 41,
      "x": 24263,
      "y": 23830,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 105065,
      "e": 30455,
      "ty": 3,
      "x": 943,
      "y": 720,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 105065,
      "e": 30455,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31*"
    },
    {
      "t": 105067,
      "e": 30457,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 105068,
      "e": 30458,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 105199,
      "e": 30589,
      "ty": 4,
      "x": 24263,
      "y": 23830,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 105201,
      "e": 30591,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 105202,
      "e": 30592,
      "ty": 5,
      "x": 943,
      "y": 720,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 105203,
      "e": 30593,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 106310,
      "e": 31700,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 106338,
      "e": 31728,
      "ty": 6,
      "x": 943,
      "y": 720,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 108555,
      "e": 33945,
      "ty": 7,
      "x": 864,
      "y": 693,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 108555,
      "e": 33945,
      "ty": 6,
      "x": 864,
      "y": 693,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 108611,
      "e": 34001,
      "ty": 2,
      "x": 844,
      "y": 692
    },
    {
      "t": 108761,
      "e": 34151,
      "ty": 41,
      "x": 25938,
      "y": 49187,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 109011,
      "e": 34401,
      "ty": 2,
      "x": 891,
      "y": 680
    },
    {
      "t": 109011,
      "e": 34401,
      "ty": 41,
      "x": 28320,
      "y": 21101,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 109111,
      "e": 34501,
      "ty": 2,
      "x": 1055,
      "y": 698
    },
    {
      "t": 109262,
      "e": 34652,
      "ty": 41,
      "x": 36629,
      "y": 63231,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 110012,
      "e": 35402,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 110633,
      "e": 36023,
      "ty": 7,
      "x": 1055,
      "y": 699,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 110634,
      "e": 36024,
      "ty": 6,
      "x": 1055,
      "y": 699,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 110711,
      "e": 36101,
      "ty": 2,
      "x": 1040,
      "y": 726
    },
    {
      "t": 110723,
      "e": 36113,
      "ty": 7,
      "x": 1036,
      "y": 730,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 110724,
      "e": 36114,
      "ty": 6,
      "x": 1036,
      "y": 730,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 110762,
      "e": 36152,
      "ty": 41,
      "x": 35463,
      "y": 30463,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 110811,
      "e": 36201,
      "ty": 2,
      "x": 1027,
      "y": 751
    },
    {
      "t": 110856,
      "e": 36246,
      "ty": 7,
      "x": 1024,
      "y": 758,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 110856,
      "e": 36246,
      "ty": 6,
      "x": 1024,
      "y": 758,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 110911,
      "e": 36301,
      "ty": 2,
      "x": 1013,
      "y": 779
    },
    {
      "t": 110924,
      "e": 36314,
      "ty": 7,
      "x": 1007,
      "y": 791,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 111011,
      "e": 36401,
      "ty": 2,
      "x": 965,
      "y": 860
    },
    {
      "t": 111012,
      "e": 36402,
      "ty": 41,
      "x": 33038,
      "y": 50806,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 111111,
      "e": 36501,
      "ty": 2,
      "x": 964,
      "y": 861
    },
    {
      "t": 111262,
      "e": 36652,
      "ty": 41,
      "x": 32988,
      "y": 50876,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 111411,
      "e": 36801,
      "ty": 2,
      "x": 964,
      "y": 862
    },
    {
      "t": 111511,
      "e": 36901,
      "ty": 41,
      "x": 32988,
      "y": 50945,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 113211,
      "e": 38601,
      "ty": 2,
      "x": 962,
      "y": 867
    },
    {
      "t": 113261,
      "e": 38651,
      "ty": 41,
      "x": 32742,
      "y": 51568,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 113311,
      "e": 38701,
      "ty": 2,
      "x": 957,
      "y": 875
    },
    {
      "t": 113411,
      "e": 38801,
      "ty": 2,
      "x": 957,
      "y": 880
    },
    {
      "t": 113510,
      "e": 38900,
      "ty": 2,
      "x": 956,
      "y": 891
    },
    {
      "t": 113511,
      "e": 38901,
      "ty": 41,
      "x": 32595,
      "y": 52953,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 113611,
      "e": 39001,
      "ty": 2,
      "x": 956,
      "y": 924
    },
    {
      "t": 113712,
      "e": 39102,
      "ty": 2,
      "x": 958,
      "y": 937
    },
    {
      "t": 113762,
      "e": 39152,
      "ty": 41,
      "x": 32693,
      "y": 56139,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 114112,
      "e": 39502,
      "ty": 2,
      "x": 958,
      "y": 939
    },
    {
      "t": 114212,
      "e": 39602,
      "ty": 2,
      "x": 955,
      "y": 952
    },
    {
      "t": 114262,
      "e": 39652,
      "ty": 41,
      "x": 32496,
      "y": 57593,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 114311,
      "e": 39701,
      "ty": 2,
      "x": 952,
      "y": 963
    },
    {
      "t": 114411,
      "e": 39801,
      "ty": 2,
      "x": 950,
      "y": 978
    },
    {
      "t": 114511,
      "e": 39901,
      "ty": 2,
      "x": 950,
      "y": 997
    },
    {
      "t": 114512,
      "e": 39902,
      "ty": 41,
      "x": 32300,
      "y": 60293,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 114611,
      "e": 40001,
      "ty": 2,
      "x": 950,
      "y": 1011
    },
    {
      "t": 114711,
      "e": 40101,
      "ty": 2,
      "x": 950,
      "y": 1024
    },
    {
      "t": 114761,
      "e": 40151,
      "ty": 41,
      "x": 32300,
      "y": 62579,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 114811,
      "e": 40201,
      "ty": 2,
      "x": 951,
      "y": 1038
    },
    {
      "t": 114911,
      "e": 40301,
      "ty": 2,
      "x": 953,
      "y": 1045
    },
    {
      "t": 115012,
      "e": 40402,
      "ty": 2,
      "x": 954,
      "y": 1054
    },
    {
      "t": 115012,
      "e": 40402,
      "ty": 41,
      "x": 32496,
      "y": 64240,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 115112,
      "e": 40502,
      "ty": 2,
      "x": 957,
      "y": 1067
    },
    {
      "t": 115142,
      "e": 40532,
      "ty": 6,
      "x": 958,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 115211,
      "e": 40601,
      "ty": 2,
      "x": 963,
      "y": 1085
    },
    {
      "t": 115261,
      "e": 40651,
      "ty": 41,
      "x": 30309,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 115311,
      "e": 40701,
      "ty": 2,
      "x": 965,
      "y": 1095
    },
    {
      "t": 115411,
      "e": 40801,
      "ty": 2,
      "x": 965,
      "y": 1096
    },
    {
      "t": 115511,
      "e": 40901,
      "ty": 2,
      "x": 965,
      "y": 1097
    },
    {
      "t": 115511,
      "e": 40901,
      "ty": 41,
      "x": 30309,
      "y": 46862,
      "ta": "#start"
    },
    {
      "t": 115611,
      "e": 41001,
      "ty": 2,
      "x": 967,
      "y": 1096
    },
    {
      "t": 115711,
      "e": 41101,
      "ty": 2,
      "x": 969,
      "y": 1087
    },
    {
      "t": 115762,
      "e": 41152,
      "ty": 41,
      "x": 32494,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 117081,
      "e": 42471,
      "ty": 3,
      "x": 969,
      "y": 1087,
      "ta": "#start"
    },
    {
      "t": 117082,
      "e": 42472,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 117175,
      "e": 42565,
      "ty": 4,
      "x": 32494,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 117175,
      "e": 42565,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 117176,
      "e": 42566,
      "ty": 5,
      "x": 969,
      "y": 1087,
      "ta": "#start"
    },
    {
      "t": 117177,
      "e": 42567,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 117410,
      "e": 42800,
      "ty": 2,
      "x": 969,
      "y": 1073
    },
    {
      "t": 117512,
      "e": 42902,
      "ty": 2,
      "x": 926,
      "y": 791
    },
    {
      "t": 117512,
      "e": 42902,
      "ty": 41,
      "x": 31613,
      "y": 43376,
      "ta": "html > body"
    },
    {
      "t": 117612,
      "e": 43002,
      "ty": 2,
      "x": 919,
      "y": 754
    },
    {
      "t": 117762,
      "e": 43152,
      "ty": 41,
      "x": 31372,
      "y": 41326,
      "ta": "html > body"
    },
    {
      "t": 118010,
      "e": 43400,
      "ty": 2,
      "x": 917,
      "y": 749
    },
    {
      "t": 118010,
      "e": 43400,
      "ty": 41,
      "x": 31303,
      "y": 41049,
      "ta": "html > body"
    },
    {
      "t": 118110,
      "e": 43500,
      "ty": 2,
      "x": 913,
      "y": 748
    },
    {
      "t": 118181,
      "e": 43571,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 118260,
      "e": 43650,
      "ty": 41,
      "x": 30413,
      "y": 46705,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 118311,
      "e": 43701,
      "ty": 2,
      "x": 904,
      "y": 745
    },
    {
      "t": 118410,
      "e": 43800,
      "ty": 2,
      "x": 902,
      "y": 744
    },
    {
      "t": 118511,
      "e": 43901,
      "ty": 41,
      "x": 29976,
      "y": 46472,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 120020,
      "e": 45410,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 124271,
      "e": 48901,
      "ty": 41,
      "x": 30364,
      "y": 48646,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 124320,
      "e": 48950,
      "ty": 2,
      "x": 935,
      "y": 803
    },
    {
      "t": 124521,
      "e": 49151,
      "ty": 41,
      "x": 31578,
      "y": 51053,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 124720,
      "e": 49350,
      "ty": 2,
      "x": 946,
      "y": 808
    },
    {
      "t": 124770,
      "e": 49400,
      "ty": 41,
      "x": 32500,
      "y": 52373,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 124821,
      "e": 49451,
      "ty": 2,
      "x": 965,
      "y": 847
    },
    {
      "t": 124920,
      "e": 49550,
      "ty": 2,
      "x": 985,
      "y": 1100
    },
    {
      "t": 125020,
      "e": 49650,
      "ty": 2,
      "x": 987,
      "y": 1157
    },
    {
      "t": 125021,
      "e": 49651,
      "ty": 41,
      "x": 33714,
      "y": 63651,
      "ta": "html > body"
    },
    {
      "t": 125121,
      "e": 49751,
      "ty": 2,
      "x": 981,
      "y": 1058
    },
    {
      "t": 125221,
      "e": 49851,
      "ty": 2,
      "x": 969,
      "y": 943
    },
    {
      "t": 125271,
      "e": 49901,
      "ty": 41,
      "x": 33228,
      "y": 60914,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 125320,
      "e": 49950,
      "ty": 2,
      "x": 969,
      "y": 930
    },
    {
      "t": 126382,
      "e": 51012,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 127389,
      "e": 52019,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 153, dom: 590, initialDom: 594",
  "javascriptErrors": []
}