var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "e23dc9937eddc4a85348498f21553912",
  "created": "2018-05-29T10:11:40.2487228-07:00",
  "lastActivity": "2018-05-29T10:13:05.7292587-07:00",
  "pageViews": [
    {
      "id": "05294011ad433a414af7f3d9c82e1fa168ed6103",
      "startTime": "2018-05-29T10:11:40.3157296-07:00",
      "endTime": "2018-05-29T10:13:05.7292587-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 85524,
      "engagementTime": 78176,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 85524,
  "engagementTime": 78176,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=RRF03",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "021c3002b6a4dc47f60edcbd7ec36900",
  "gdpr": false
}