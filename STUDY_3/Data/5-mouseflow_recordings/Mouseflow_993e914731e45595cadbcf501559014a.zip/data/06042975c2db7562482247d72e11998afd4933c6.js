var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["06042975c2db7562482247d72e11998afd4933c6"] = {
  "startTime": "2018-06-04T19:22:29.3048411Z",
  "websitePageUrl": "/16",
  "visitTime": 74595,
  "engagementTime": 74162,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "993e914731e45595cadbcf501559014a",
    "created": "2018-06-04T19:22:29.3048411+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=G27Q3",
      "CONDITION=311"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "f69386c5eb36e59aefd75cab62ffe513",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/993e914731e45595cadbcf501559014a/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 226,
      "e": 226,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 226,
      "e": 226,
      "ty": 2,
      "x": 495,
      "y": 704
    },
    {
      "t": 251,
      "e": 251,
      "ty": 41,
      "x": 44728,
      "y": 42351,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 701,
      "e": 701,
      "ty": 2,
      "x": 497,
      "y": 704
    },
    {
      "t": 796,
      "e": 796,
      "ty": 41,
      "x": 42030,
      "y": 37361,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 801,
      "e": 801,
      "ty": 2,
      "x": 468,
      "y": 612
    },
    {
      "t": 879,
      "e": 879,
      "ty": 6,
      "x": 432,
      "y": 535,
      "ta": "#strategyAnswer"
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 424,
      "y": 515
    },
    {
      "t": 999,
      "e": 999,
      "ty": 2,
      "x": 412,
      "y": 470
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 41,
      "x": 35398,
      "y": 214,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1013,
      "e": 1013,
      "ty": 7,
      "x": 411,
      "y": 468,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1100,
      "e": 1100,
      "ty": 2,
      "x": 411,
      "y": 468
    },
    {
      "t": 1149,
      "e": 1149,
      "ty": 3,
      "x": 411,
      "y": 468,
      "ta": "#.strategy > p"
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 35286,
      "y": 61475,
      "ta": "#.strategy > p"
    },
    {
      "t": 1300,
      "e": 1300,
      "ty": 4,
      "x": 35286,
      "y": 61475,
      "ta": "#.strategy > p"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 5,
      "x": 411,
      "y": 468,
      "ta": "#.strategy > p"
    },
    {
      "t": 1700,
      "e": 1700,
      "ty": 2,
      "x": 412,
      "y": 468
    },
    {
      "t": 1749,
      "e": 1749,
      "ty": 3,
      "x": 412,
      "y": 468,
      "ta": "#.strategy > p"
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 35398,
      "y": 61475,
      "ta": "#.strategy > p"
    },
    {
      "t": 1893,
      "e": 1893,
      "ty": 4,
      "x": 35398,
      "y": 61475,
      "ta": "#.strategy > p"
    },
    {
      "t": 1893,
      "e": 1893,
      "ty": 5,
      "x": 412,
      "y": 468,
      "ta": "#.strategy > p"
    },
    {
      "t": 1966,
      "e": 1966,
      "ty": 6,
      "x": 412,
      "y": 471,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 2,
      "x": 414,
      "y": 478
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 41,
      "x": 35623,
      "y": 6687,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2100,
      "e": 2100,
      "ty": 2,
      "x": 415,
      "y": 488
    },
    {
      "t": 2174,
      "e": 2174,
      "ty": 3,
      "x": 415,
      "y": 489,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2174,
      "e": 2174,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2200,
      "e": 2200,
      "ty": 2,
      "x": 415,
      "y": 489
    },
    {
      "t": 2250,
      "e": 2250,
      "ty": 41,
      "x": 35735,
      "y": 15587,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2268,
      "e": 2268,
      "ty": 4,
      "x": 35735,
      "y": 15587,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2268,
      "e": 2268,
      "ty": 5,
      "x": 415,
      "y": 489,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2400,
      "e": 2400,
      "ty": 2,
      "x": 417,
      "y": 490
    },
    {
      "t": 2500,
      "e": 2500,
      "ty": 41,
      "x": 35960,
      "y": 16396,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3050,
      "e": 3050,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 3177,
      "e": 3177,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 3178,
      "e": 3178,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3248,
      "e": 3248,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "y"
    },
    {
      "t": 3265,
      "e": 3265,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "y"
    },
    {
      "t": 3441,
      "e": 3441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 3442,
      "e": 3442,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3520,
      "e": 3520,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yO"
    },
    {
      "t": 3617,
      "e": 3617,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 3617,
      "e": 3617,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3704,
      "e": 3704,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yOU"
    },
    {
      "t": 3712,
      "e": 3712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 3712,
      "e": 3712,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3832,
      "e": 3832,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 3832,
      "e": 3832,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3864,
      "e": 3864,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yOU G"
    },
    {
      "t": 3944,
      "e": 3944,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 3953,
      "e": 3953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 3954,
      "e": 3954,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4064,
      "e": 4064,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||O"
    },
    {
      "t": 4257,
      "e": 4257,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 4258,
      "e": 4258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4402,
      "e": 4402,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yOU GO "
    },
    {
      "t": 4440,
      "e": 4440,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 5105,
      "e": 5105,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 5241,
      "e": 5241,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 5289,
      "e": 5289,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 5385,
      "e": 5385,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yOU GO"
    },
    {
      "t": 5529,
      "e": 5529,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 5593,
      "e": 5593,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yOU G"
    },
    {
      "t": 5705,
      "e": 5705,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 5785,
      "e": 5785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yOU "
    },
    {
      "t": 5880,
      "e": 5880,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 5953,
      "e": 5953,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yOU"
    },
    {
      "t": 6049,
      "e": 6049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 6120,
      "e": 6120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yO"
    },
    {
      "t": 6217,
      "e": 6217,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 6281,
      "e": 6281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "y"
    },
    {
      "t": 6393,
      "e": 6393,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 6473,
      "e": 6473,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 6601,
      "e": 6601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 6809,
      "e": 6809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 6810,
      "e": 6810,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6872,
      "e": 6872,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Y"
    },
    {
      "t": 6881,
      "e": 6881,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Y"
    },
    {
      "t": 7033,
      "e": 7033,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 7034,
      "e": 7034,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7121,
      "e": 7121,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Yo"
    },
    {
      "t": 7233,
      "e": 7233,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 7233,
      "e": 7233,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7312,
      "e": 7312,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You"
    },
    {
      "t": 7353,
      "e": 7353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 7354,
      "e": 7354,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7465,
      "e": 7465,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You "
    },
    {
      "t": 7537,
      "e": 7537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 7538,
      "e": 7538,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7608,
      "e": 7608,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 7680,
      "e": 7680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 7681,
      "e": 7681,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7752,
      "e": 7752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 7761,
      "e": 7761,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 7762,
      "e": 7762,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7905,
      "e": 7905,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 7960,
      "e": 7960,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 7962,
      "e": 7962,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8064,
      "e": 8064,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 8104,
      "e": 8104,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 8105,
      "e": 8105,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8185,
      "e": 8185,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 8249,
      "e": 8249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8250,
      "e": 8250,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8384,
      "e": 8384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 8393,
      "e": 8393,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 8393,
      "e": 8393,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8513,
      "e": 8513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 8705,
      "e": 8705,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 8706,
      "e": 8706,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8784,
      "e": 8784,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 9185,
      "e": 9185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 9185,
      "e": 9185,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9320,
      "e": 9320,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 9384,
      "e": 9384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 9385,
      "e": 9385,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9465,
      "e": 9465,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 9833,
      "e": 9833,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 9912,
      "e": 9912,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to tha"
    },
    {
      "t": 10009,
      "e": 10009,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10025,
      "e": 10025,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 10105,
      "e": 10105,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to th"
    },
    {
      "t": 10210,
      "e": 10210,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to th"
    },
    {
      "t": 10216,
      "e": 10216,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 10304,
      "e": 10304,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to t"
    },
    {
      "t": 10410,
      "e": 10410,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to t"
    },
    {
      "t": 10449,
      "e": 10449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 10528,
      "e": 10528,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to "
    },
    {
      "t": 11033,
      "e": 11033,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 11034,
      "e": 11034,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11177,
      "e": 11177,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 11177,
      "e": 11177,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11185,
      "e": 11185,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 11257,
      "e": 11257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11305,
      "e": 11305,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11306,
      "e": 11306,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11376,
      "e": 11376,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11521,
      "e": 11521,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 11521,
      "e": 11521,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11585,
      "e": 11585,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 11713,
      "e": 11713,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 11713,
      "e": 11713,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11784,
      "e": 11784,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 11824,
      "e": 11824,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11824,
      "e": 11824,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11921,
      "e": 11921,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 11921,
      "e": 11921,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11944,
      "e": 11944,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| o"
    },
    {
      "t": 11992,
      "e": 11992,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12113,
      "e": 12113,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 12114,
      "e": 12114,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12200,
      "e": 12200,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 12216,
      "e": 12216,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12216,
      "e": 12216,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12313,
      "e": 12313,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12314,
      "e": 12314,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12344,
      "e": 12344,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 12368,
      "e": 12368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 12368,
      "e": 12368,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12432,
      "e": 12432,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 12457,
      "e": 12457,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12489,
      "e": 12489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 12489,
      "e": 12489,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12569,
      "e": 12569,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 12584,
      "e": 12584,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12584,
      "e": 12584,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12696,
      "e": 12696,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12913,
      "e": 12913,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 12913,
      "e": 12913,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13040,
      "e": 13040,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 13345,
      "e": 13345,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 13345,
      "e": 13345,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13400,
      "e": 13400,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 13513,
      "e": 13513,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 13513,
      "e": 13513,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13601,
      "e": 13601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 13632,
      "e": 13632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 13632,
      "e": 13632,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13705,
      "e": 13705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 13769,
      "e": 13769,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13770,
      "e": 13770,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13856,
      "e": 13856,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15113,
      "e": 15113,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15152,
      "e": 15152,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 pm on the axis"
    },
    {
      "t": 15401,
      "e": 15401,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15472,
      "e": 15472,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 pm on the axi"
    },
    {
      "t": 15576,
      "e": 15576,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15640,
      "e": 15640,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 pm on the ax"
    },
    {
      "t": 15728,
      "e": 15728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15808,
      "e": 15808,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 pm on the a"
    },
    {
      "t": 15897,
      "e": 15897,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15984,
      "e": 15984,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 pm on the "
    },
    {
      "t": 16690,
      "e": 16690,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 16691,
      "e": 16691,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16768,
      "e": 16768,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 17001,
      "e": 17001,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 17002,
      "e": 17002,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17056,
      "e": 17056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 17056,
      "e": 17056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17088,
      "e": 17088,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-a"
    },
    {
      "t": 17160,
      "e": 17160,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17713,
      "e": 17713,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 17714,
      "e": 17714,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17816,
      "e": 17816,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 18360,
      "e": 18360,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 18360,
      "e": 18360,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18449,
      "e": 18449,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 18457,
      "e": 18457,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 18457,
      "e": 18457,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18528,
      "e": 18528,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 18592,
      "e": 18592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18592,
      "e": 18592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18665,
      "e": 18665,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18745,
      "e": 18745,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18746,
      "e": 18746,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18856,
      "e": 18856,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 18857,
      "e": 18857,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18880,
      "e": 18880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 18953,
      "e": 18953,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19017,
      "e": 19017,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 19020,
      "e": 19020,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19144,
      "e": 19144,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 19233,
      "e": 19233,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 19233,
      "e": 19233,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19353,
      "e": 19353,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 19457,
      "e": 19457,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19458,
      "e": 19458,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19608,
      "e": 19608,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19945,
      "e": 19945,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 19947,
      "e": 19947,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20009,
      "e": 20009,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20016,
      "e": 20016,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 20088,
      "e": 20088,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 20089,
      "e": 20089,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20153,
      "e": 20153,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 20313,
      "e": 20313,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 20314,
      "e": 20314,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20376,
      "e": 20376,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 20489,
      "e": 20489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 20490,
      "e": 20490,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20568,
      "e": 20568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 20648,
      "e": 20648,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 20648,
      "e": 20648,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20697,
      "e": 20697,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 20697,
      "e": 20697,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20728,
      "e": 20728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ow"
    },
    {
      "t": 20857,
      "e": 20857,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20858,
      "e": 20858,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20858,
      "e": 20858,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20945,
      "e": 20945,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20952,
      "e": 20952,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20953,
      "e": 20953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21017,
      "e": 21017,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 21017,
      "e": 21017,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21056,
      "e": 21056,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 21097,
      "e": 21097,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21097,
      "e": 21097,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21120,
      "e": 21120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 21184,
      "e": 21184,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21184,
      "e": 21184,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21192,
      "e": 21192,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21272,
      "e": 21272,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21745,
      "e": 21745,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 21745,
      "e": 21745,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21832,
      "e": 21832,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 21945,
      "e": 21945,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 21946,
      "e": 21946,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22008,
      "e": 22008,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 22128,
      "e": 22128,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 22130,
      "e": 22130,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22193,
      "e": 22193,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22193,
      "e": 22193,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22224,
      "e": 22224,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ne"
    },
    {
      "t": 22296,
      "e": 22296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22393,
      "e": 22393,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22393,
      "e": 22393,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22496,
      "e": 22496,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22673,
      "e": 22673,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 22674,
      "e": 22674,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22744,
      "e": 22744,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 22768,
      "e": 22768,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 22769,
      "e": 22769,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22856,
      "e": 22856,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 22953,
      "e": 22953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 22953,
      "e": 22953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23033,
      "e": 23033,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 23145,
      "e": 23145,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 23146,
      "e": 23146,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23216,
      "e": 23216,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 23217,
      "e": 23217,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23256,
      "e": 23256,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ng"
    },
    {
      "t": 23297,
      "e": 23297,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23297,
      "e": 23297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23297,
      "e": 23297,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23400,
      "e": 23400,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24561,
      "e": 24561,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 24563,
      "e": 24563,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24632,
      "e": 24632,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 24825,
      "e": 24825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 24828,
      "e": 24828,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24904,
      "e": 24904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 25010,
      "e": 25010,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 pm on the x-axis then follow the line going up"
    },
    {
      "t": 25337,
      "e": 25337,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 25337,
      "e": 25337,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25457,
      "e": 25457,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 25505,
      "e": 25505,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 25506,
      "e": 25506,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25610,
      "e": 25610,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 pm on the x-axis then follow the line going upwa"
    },
    {
      "t": 25649,
      "e": 25649,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 25649,
      "e": 25649,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25689,
      "e": 25689,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 25745,
      "e": 25745,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25880,
      "e": 25880,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 25882,
      "e": 25882,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25904,
      "e": 25904,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 25905,
      "e": 25905,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25968,
      "e": 25968,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||dx"
    },
    {
      "t": 26089,
      "e": 26089,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26241,
      "e": 26241,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 26241,
      "e": 26241,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26368,
      "e": 26368,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 26601,
      "e": 26601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26602,
      "e": 26602,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26712,
      "e": 26712,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27265,
      "e": 27265,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27328,
      "e": 27328,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 pm on the x-axis then follow the line going upwardxs"
    },
    {
      "t": 27448,
      "e": 27448,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27504,
      "e": 27504,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 pm on the x-axis then follow the line going upwardx"
    },
    {
      "t": 27612,
      "e": 27505,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 pm on the x-axis then follow the line going upwardx"
    },
    {
      "t": 27616,
      "e": 27509,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27720,
      "e": 27613,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 pm on the x-axis then follow the line going upward"
    },
    {
      "t": 28113,
      "e": 28006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 28114,
      "e": 28007,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28201,
      "e": 28094,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 28217,
      "e": 28110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28218,
      "e": 28111,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28280,
      "e": 28173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 28280,
      "e": 28173,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28304,
      "e": 28197,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 28385,
      "e": 28278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 28385,
      "e": 28278,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28416,
      "e": 28309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 28417,
      "e": 28310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28424,
      "e": 28317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nd"
    },
    {
      "t": 28489,
      "e": 28382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28497,
      "e": 28390,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28545,
      "e": 28438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28545,
      "e": 28438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28624,
      "e": 28517,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28624,
      "e": 28517,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28632,
      "e": 28525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 28704,
      "e": 28597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28752,
      "e": 28645,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 28753,
      "e": 28646,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28808,
      "e": 28701,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28808,
      "e": 28701,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28832,
      "e": 28725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o "
    },
    {
      "t": 28904,
      "e": 28797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28904,
      "e": 28797,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28920,
      "e": 28813,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 29032,
      "e": 28925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29073,
      "e": 28966,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 29074,
      "e": 28967,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29169,
      "e": 29062,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 29321,
      "e": 29214,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 29322,
      "e": 29215,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29448,
      "e": 29341,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 29456,
      "e": 29349,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29456,
      "e": 29349,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29536,
      "e": 29429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29633,
      "e": 29526,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 29634,
      "e": 29527,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29720,
      "e": 29613,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 29721,
      "e": 29614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29728,
      "e": 29621,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 29800,
      "e": 29693,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29865,
      "e": 29758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 29866,
      "e": 29759,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29937,
      "e": 29830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 29952,
      "e": 29845,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 29953,
      "e": 29846,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30040,
      "e": 29933,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 30216,
      "e": 30109,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30217,
      "e": 30110,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30296,
      "e": 30189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 30411,
      "e": 30304,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 pm on the x-axis then follow the line going upwards and to the tight"
    },
    {
      "t": 30625,
      "e": 30518,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30688,
      "e": 30581,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 pm on the x-axis then follow the line going upwards and to the tigh"
    },
    {
      "t": 30793,
      "e": 30686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30856,
      "e": 30749,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 pm on the x-axis then follow the line going upwards and to the tig"
    },
    {
      "t": 30953,
      "e": 30846,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31008,
      "e": 30901,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 pm on the x-axis then follow the line going upwards and to the ti"
    },
    {
      "t": 31105,
      "e": 30998,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31178,
      "e": 30999,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 pm on the x-axis then follow the line going upwards and to the t"
    },
    {
      "t": 31264,
      "e": 31085,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31344,
      "e": 31165,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 pm on the x-axis then follow the line going upwards and to the "
    },
    {
      "t": 31937,
      "e": 31758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 31937,
      "e": 31758,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32025,
      "e": 31846,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 32057,
      "e": 31878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32057,
      "e": 31878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32129,
      "e": 31950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 32193,
      "e": 32014,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 32193,
      "e": 32014,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32289,
      "e": 32110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 32290,
      "e": 32111,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32297,
      "e": 32118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||gh"
    },
    {
      "t": 32352,
      "e": 32173,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32432,
      "e": 32253,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32433,
      "e": 32254,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32521,
      "e": 32342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 32729,
      "e": 32550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 32730,
      "e": 32551,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32808,
      "e": 32629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 32888,
      "e": 32709,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32889,
      "e": 32710,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33012,
      "e": 32833,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 pm on the x-axis then follow the line going upwards and to the right. "
    },
    {
      "t": 33017,
      "e": 32838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33280,
      "e": 33101,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 33720,
      "e": 33541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33721,
      "e": 33542,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33761,
      "e": 33582,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 33809,
      "e": 33630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34097,
      "e": 33918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 34098,
      "e": 33919,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34185,
      "e": 34006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 34186,
      "e": 34007,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34209,
      "e": 34030,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 34297,
      "e": 34118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35593,
      "e": 35414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35593,
      "e": 35414,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35704,
      "e": 35525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35728,
      "e": 35549,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 35729,
      "e": 35550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35816,
      "e": 35637,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 35904,
      "e": 35725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 35906,
      "e": 35727,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35984,
      "e": 35805,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 36080,
      "e": 35901,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 36081,
      "e": 35902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36136,
      "e": 35957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 36257,
      "e": 36078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 36257,
      "e": 36078,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36321,
      "e": 36142,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 36322,
      "e": 36143,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36352,
      "e": 36173,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nt"
    },
    {
      "t": 36384,
      "e": 36205,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36488,
      "e": 36309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 36488,
      "e": 36309,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36608,
      "e": 36429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 36648,
      "e": 36469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36649,
      "e": 36470,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36737,
      "e": 36558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37129,
      "e": 36950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 37129,
      "e": 36950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37200,
      "e": 37021,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 37354,
      "e": 37175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 37354,
      "e": 37175,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37441,
      "e": 37262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 37521,
      "e": 37342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37521,
      "e": 37342,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37640,
      "e": 37461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37640,
      "e": 37461,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37664,
      "e": 37485,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 37704,
      "e": 37525,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 37705,
      "e": 37526,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37728,
      "e": 37549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 37809,
      "e": 37630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37849,
      "e": 37670,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 37850,
      "e": 37671,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37936,
      "e": 37757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37936,
      "e": 37757,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37984,
      "e": 37805,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 38024,
      "e": 37845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38097,
      "e": 37918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38099,
      "e": 37920,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38200,
      "e": 38021,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38401,
      "e": 38222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 38402,
      "e": 38223,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38464,
      "e": 38285,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 38569,
      "e": 38390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 38570,
      "e": 38391,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38624,
      "e": 38445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 38769,
      "e": 38590,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 38769,
      "e": 38590,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38856,
      "e": 38677,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 38904,
      "e": 38725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 38905,
      "e": 38726,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38984,
      "e": 38805,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 39001,
      "e": 38822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39001,
      "e": 38822,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39105,
      "e": 38926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39417,
      "e": 39238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 39418,
      "e": 39239,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39521,
      "e": 39240,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 39673,
      "e": 39392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39673,
      "e": 39392,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39792,
      "e": 39511,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 39937,
      "e": 39656,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 39937,
      "e": 39656,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40145,
      "e": 39864,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 40177,
      "e": 39896,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 40177,
      "e": 39896,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40288,
      "e": 40007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 40376,
      "e": 40095,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40377,
      "e": 40096,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40464,
      "e": 40183,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 40641,
      "e": 40360,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40642,
      "e": 40361,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40728,
      "e": 40447,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40768,
      "e": 40487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 40768,
      "e": 40487,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40921,
      "e": 40640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40922,
      "e": 40641,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40944,
      "e": 40663,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 41009,
      "e": 40728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41057,
      "e": 40776,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41057,
      "e": 40776,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41137,
      "e": 40856,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41496,
      "e": 41215,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 41497,
      "e": 41216,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41609,
      "e": 41328,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 pm on the x-axis then follow the line going upwards and to the right. The points on that line start at 1"
    },
    {
      "t": 41632,
      "e": 41351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 41632,
      "e": 41351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41672,
      "e": 41391,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 41793,
      "e": 41512,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41904,
      "e": 41623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41906,
      "e": 41625,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42010,
      "e": 41729,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 pm on the x-axis then follow the line going upwards and to the right. The points on that line start at 12 "
    },
    {
      "t": 42040,
      "e": 41759,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 42064,
      "e": 41783,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 42065,
      "e": 41784,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42137,
      "e": 41856,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 42312,
      "e": 42031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 42313,
      "e": 42032,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42352,
      "e": 42071,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 43259,
      "e": 42978,
      "ty": 41,
      "x": 34948,
      "y": 19632,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43306,
      "e": 43025,
      "ty": 7,
      "x": 373,
      "y": 556,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43309,
      "e": 43028,
      "ty": 2,
      "x": 373,
      "y": 556
    },
    {
      "t": 43340,
      "e": 43059,
      "ty": 6,
      "x": 362,
      "y": 604,
      "ta": "#strategyButton"
    },
    {
      "t": 43372,
      "e": 43091,
      "ty": 7,
      "x": 369,
      "y": 675,
      "ta": "#strategyButton"
    },
    {
      "t": 43408,
      "e": 43127,
      "ty": 2,
      "x": 386,
      "y": 713
    },
    {
      "t": 43508,
      "e": 43227,
      "ty": 2,
      "x": 397,
      "y": 728
    },
    {
      "t": 43508,
      "e": 43227,
      "ty": 41,
      "x": 33712,
      "y": 43811,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 43681,
      "e": 43400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 43682,
      "e": 43401,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43708,
      "e": 43427,
      "ty": 2,
      "x": 394,
      "y": 729
    },
    {
      "t": 43759,
      "e": 43478,
      "ty": 41,
      "x": 28766,
      "y": 44846,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 43808,
      "e": 43527,
      "ty": 2,
      "x": 348,
      "y": 726
    },
    {
      "t": 43812,
      "e": 43531,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 pm on the x-axis then follow the line going upwards and to the right. The points on that line start at 12 pm."
    },
    {
      "t": 43833,
      "e": 43552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 43908,
      "e": 43627,
      "ty": 2,
      "x": 335,
      "y": 665
    },
    {
      "t": 44008,
      "e": 43727,
      "ty": 2,
      "x": 340,
      "y": 659
    },
    {
      "t": 44009,
      "e": 43728,
      "ty": 41,
      "x": 10020,
      "y": 59155,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 44108,
      "e": 43827,
      "ty": 2,
      "x": 368,
      "y": 645
    },
    {
      "t": 44208,
      "e": 43927,
      "ty": 2,
      "x": 377,
      "y": 639
    },
    {
      "t": 44257,
      "e": 43976,
      "ty": 6,
      "x": 382,
      "y": 635,
      "ta": "#strategyButton"
    },
    {
      "t": 44259,
      "e": 43978,
      "ty": 41,
      "x": 23705,
      "y": 64119,
      "ta": "#strategyButton"
    },
    {
      "t": 44308,
      "e": 44027,
      "ty": 2,
      "x": 385,
      "y": 633
    },
    {
      "t": 44408,
      "e": 44127,
      "ty": 2,
      "x": 394,
      "y": 616
    },
    {
      "t": 44468,
      "e": 44187,
      "ty": 3,
      "x": 394,
      "y": 616,
      "ta": "#strategyButton"
    },
    {
      "t": 44469,
      "e": 44188,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 pm on the x-axis then follow the line going upwards and to the right. The points on that line start at 12 pm."
    },
    {
      "t": 44470,
      "e": 44189,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44470,
      "e": 44189,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 44508,
      "e": 44227,
      "ty": 41,
      "x": 30258,
      "y": 27496,
      "ta": "#strategyButton"
    },
    {
      "t": 44588,
      "e": 44307,
      "ty": 4,
      "x": 30258,
      "y": 27496,
      "ta": "#strategyButton"
    },
    {
      "t": 44598,
      "e": 44317,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 44598,
      "e": 44317,
      "ty": 5,
      "x": 394,
      "y": 616,
      "ta": "#strategyButton"
    },
    {
      "t": 44603,
      "e": 44322,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 44708,
      "e": 44427,
      "ty": 2,
      "x": 389,
      "y": 618
    },
    {
      "t": 44758,
      "e": 44477,
      "ty": 41,
      "x": 12259,
      "y": 38091,
      "ta": "html > body"
    },
    {
      "t": 44808,
      "e": 44527,
      "ty": 2,
      "x": 364,
      "y": 634
    },
    {
      "t": 45408,
      "e": 45127,
      "ty": 2,
      "x": 372,
      "y": 634
    },
    {
      "t": 45508,
      "e": 45227,
      "ty": 2,
      "x": 392,
      "y": 624
    },
    {
      "t": 45508,
      "e": 45227,
      "ty": 41,
      "x": 13224,
      "y": 37483,
      "ta": "html > body"
    },
    {
      "t": 45602,
      "e": 45321,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 45608,
      "e": 45327,
      "ty": 2,
      "x": 409,
      "y": 637
    },
    {
      "t": 45708,
      "e": 45427,
      "ty": 2,
      "x": 418,
      "y": 653
    },
    {
      "t": 45758,
      "e": 45477,
      "ty": 41,
      "x": 14188,
      "y": 39308,
      "ta": "html > body"
    },
    {
      "t": 45808,
      "e": 45527,
      "ty": 2,
      "x": 420,
      "y": 654
    },
    {
      "t": 45909,
      "e": 45628,
      "ty": 2,
      "x": 422,
      "y": 660
    },
    {
      "t": 46009,
      "e": 45728,
      "ty": 2,
      "x": 440,
      "y": 674
    },
    {
      "t": 46009,
      "e": 45728,
      "ty": 41,
      "x": 14877,
      "y": 40525,
      "ta": "html > body"
    },
    {
      "t": 46409,
      "e": 46128,
      "ty": 2,
      "x": 866,
      "y": 584
    },
    {
      "t": 46508,
      "e": 46227,
      "ty": 2,
      "x": 922,
      "y": 558
    },
    {
      "t": 46508,
      "e": 46227,
      "ty": 41,
      "x": 24656,
      "y": 23405,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 46560,
      "e": 46279,
      "ty": 6,
      "x": 965,
      "y": 512,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46608,
      "e": 46327,
      "ty": 2,
      "x": 971,
      "y": 505
    },
    {
      "t": 46708,
      "e": 46427,
      "ty": 2,
      "x": 972,
      "y": 503
    },
    {
      "t": 46758,
      "e": 46477,
      "ty": 41,
      "x": 35471,
      "y": 9362,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46808,
      "e": 46527,
      "ty": 2,
      "x": 972,
      "y": 507
    },
    {
      "t": 46908,
      "e": 46627,
      "ty": 2,
      "x": 971,
      "y": 520
    },
    {
      "t": 47008,
      "e": 46727,
      "ty": 41,
      "x": 35254,
      "y": 59293,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47109,
      "e": 46828,
      "ty": 2,
      "x": 973,
      "y": 521
    },
    {
      "t": 47118,
      "e": 46837,
      "ty": 3,
      "x": 973,
      "y": 521,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47118,
      "e": 46837,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47237,
      "e": 46956,
      "ty": 4,
      "x": 35687,
      "y": 62414,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47237,
      "e": 46956,
      "ty": 5,
      "x": 973,
      "y": 521,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47259,
      "e": 46978,
      "ty": 41,
      "x": 35687,
      "y": 62414,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48417,
      "e": 48136,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 48418,
      "e": 48137,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48504,
      "e": 48223,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 48609,
      "e": 48328,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 48609,
      "e": 48328,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48687,
      "e": 48406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 49286,
      "e": 49005,
      "ty": 7,
      "x": 973,
      "y": 524,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 49308,
      "e": 49027,
      "ty": 2,
      "x": 973,
      "y": 528
    },
    {
      "t": 49408,
      "e": 49127,
      "ty": 2,
      "x": 975,
      "y": 559
    },
    {
      "t": 49478,
      "e": 49197,
      "ty": 6,
      "x": 986,
      "y": 594,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49508,
      "e": 49227,
      "ty": 2,
      "x": 986,
      "y": 599
    },
    {
      "t": 49508,
      "e": 49227,
      "ty": 41,
      "x": 38499,
      "y": 15603,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49608,
      "e": 49327,
      "ty": 2,
      "x": 990,
      "y": 607
    },
    {
      "t": 49708,
      "e": 49427,
      "ty": 2,
      "x": 990,
      "y": 609
    },
    {
      "t": 49749,
      "e": 49468,
      "ty": 3,
      "x": 990,
      "y": 609,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49750,
      "e": 49469,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 49750,
      "e": 49469,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 49752,
      "e": 49471,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49758,
      "e": 49477,
      "ty": 41,
      "x": 39364,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49820,
      "e": 49539,
      "ty": 4,
      "x": 39364,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49820,
      "e": 49539,
      "ty": 5,
      "x": 990,
      "y": 609,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50008,
      "e": 49727,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50257,
      "e": 49976,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 50393,
      "e": 50112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "74"
    },
    {
      "t": 50393,
      "e": 50112,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50440,
      "e": 50159,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "J"
    },
    {
      "t": 50472,
      "e": 50191,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "J"
    },
    {
      "t": 50593,
      "e": 50312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 50593,
      "e": 50312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50849,
      "e": 50568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Ja"
    },
    {
      "t": 50961,
      "e": 50680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "80"
    },
    {
      "t": 50961,
      "e": 50680,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51040,
      "e": 50759,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Jap"
    },
    {
      "t": 51080,
      "e": 50799,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 51080,
      "e": 50799,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51193,
      "e": 50912,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Japa"
    },
    {
      "t": 51297,
      "e": 51016,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 51297,
      "e": 51016,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51375,
      "e": 51094,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||n"
    },
    {
      "t": 52181,
      "e": 51900,
      "ty": 7,
      "x": 992,
      "y": 616,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52208,
      "e": 51927,
      "ty": 2,
      "x": 992,
      "y": 618
    },
    {
      "t": 52246,
      "e": 51965,
      "ty": 6,
      "x": 992,
      "y": 623,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 52259,
      "e": 51978,
      "ty": 41,
      "x": 49517,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 52308,
      "e": 52027,
      "ty": 2,
      "x": 992,
      "y": 626
    },
    {
      "t": 52408,
      "e": 52127,
      "ty": 2,
      "x": 993,
      "y": 637
    },
    {
      "t": 52437,
      "e": 52156,
      "ty": 3,
      "x": 993,
      "y": 637,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 52438,
      "e": 52157,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Japan"
    },
    {
      "t": 52439,
      "e": 52158,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52440,
      "e": 52159,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 52509,
      "e": 52228,
      "ty": 41,
      "x": 50033,
      "y": 27802,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 52564,
      "e": 52283,
      "ty": 4,
      "x": 50033,
      "y": 27802,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 52565,
      "e": 52284,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 52565,
      "e": 52284,
      "ty": 5,
      "x": 993,
      "y": 637,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 52565,
      "e": 52284,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 53409,
      "e": 53128,
      "ty": 2,
      "x": 903,
      "y": 540
    },
    {
      "t": 53508,
      "e": 53227,
      "ty": 2,
      "x": 611,
      "y": 245
    },
    {
      "t": 53509,
      "e": 53228,
      "ty": 41,
      "x": 20765,
      "y": 14421,
      "ta": "html > body"
    },
    {
      "t": 53578,
      "e": 53297,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 53608,
      "e": 53327,
      "ty": 2,
      "x": 578,
      "y": 215
    },
    {
      "t": 53708,
      "e": 53427,
      "ty": 2,
      "x": 571,
      "y": 212
    },
    {
      "t": 53759,
      "e": 53478,
      "ty": 41,
      "x": 19078,
      "y": 12230,
      "ta": "html > body"
    },
    {
      "t": 53809,
      "e": 53528,
      "ty": 2,
      "x": 555,
      "y": 207
    },
    {
      "t": 53908,
      "e": 53627,
      "ty": 2,
      "x": 552,
      "y": 204
    },
    {
      "t": 54009,
      "e": 53728,
      "ty": 41,
      "x": 18734,
      "y": 11926,
      "ta": "html > body"
    },
    {
      "t": 54209,
      "e": 53928,
      "ty": 2,
      "x": 689,
      "y": 240
    },
    {
      "t": 54249,
      "e": 53968,
      "ty": 6,
      "x": 833,
      "y": 236,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 54259,
      "e": 53978,
      "ty": 41,
      "x": 33161,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 54264,
      "e": 53983,
      "ty": 7,
      "x": 851,
      "y": 228,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 54309,
      "e": 54028,
      "ty": 2,
      "x": 863,
      "y": 214
    },
    {
      "t": 54408,
      "e": 54127,
      "ty": 2,
      "x": 876,
      "y": 180
    },
    {
      "t": 54508,
      "e": 54227,
      "ty": 2,
      "x": 879,
      "y": 159
    },
    {
      "t": 54509,
      "e": 54228,
      "ty": 41,
      "x": 13664,
      "y": 13687,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 54608,
      "e": 54327,
      "ty": 2,
      "x": 863,
      "y": 165
    },
    {
      "t": 54708,
      "e": 54427,
      "ty": 2,
      "x": 857,
      "y": 170
    },
    {
      "t": 54759,
      "e": 54478,
      "ty": 41,
      "x": 8206,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 54808,
      "e": 54527,
      "ty": 2,
      "x": 851,
      "y": 177
    },
    {
      "t": 54909,
      "e": 54628,
      "ty": 2,
      "x": 844,
      "y": 185
    },
    {
      "t": 55008,
      "e": 54727,
      "ty": 2,
      "x": 843,
      "y": 185
    },
    {
      "t": 55009,
      "e": 54728,
      "ty": 41,
      "x": 17669,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 55045,
      "e": 54764,
      "ty": 6,
      "x": 839,
      "y": 185,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 55108,
      "e": 54827,
      "ty": 2,
      "x": 835,
      "y": 185
    },
    {
      "t": 55209,
      "e": 54928,
      "ty": 2,
      "x": 833,
      "y": 185
    },
    {
      "t": 55259,
      "e": 54978,
      "ty": 41,
      "x": 33161,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 55357,
      "e": 55076,
      "ty": 3,
      "x": 833,
      "y": 185,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 55359,
      "e": 55078,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 55452,
      "e": 55171,
      "ty": 4,
      "x": 33161,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 55452,
      "e": 55171,
      "ty": 5,
      "x": 833,
      "y": 185,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 55452,
      "e": 55171,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 55599,
      "e": 55318,
      "ty": 7,
      "x": 828,
      "y": 193,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 55608,
      "e": 55327,
      "ty": 2,
      "x": 828,
      "y": 193
    },
    {
      "t": 55708,
      "e": 55427,
      "ty": 2,
      "x": 820,
      "y": 239
    },
    {
      "t": 55759,
      "e": 55478,
      "ty": 41,
      "x": 27928,
      "y": 16246,
      "ta": "html > body"
    },
    {
      "t": 55809,
      "e": 55528,
      "ty": 2,
      "x": 821,
      "y": 321
    },
    {
      "t": 55909,
      "e": 55628,
      "ty": 2,
      "x": 828,
      "y": 346
    },
    {
      "t": 56008,
      "e": 55727,
      "ty": 2,
      "x": 833,
      "y": 353
    },
    {
      "t": 56009,
      "e": 55728,
      "ty": 41,
      "x": 13553,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 56020,
      "e": 55732,
      "ty": 6,
      "x": 833,
      "y": 355,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 56082,
      "e": 55794,
      "ty": 7,
      "x": 835,
      "y": 370,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 56109,
      "e": 55821,
      "ty": 2,
      "x": 836,
      "y": 374
    },
    {
      "t": 56209,
      "e": 55921,
      "ty": 2,
      "x": 838,
      "y": 380
    },
    {
      "t": 56259,
      "e": 55971,
      "ty": 41,
      "x": 13241,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 56309,
      "e": 56021,
      "ty": 2,
      "x": 838,
      "y": 381
    },
    {
      "t": 56509,
      "e": 56221,
      "ty": 41,
      "x": 13241,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 56638,
      "e": 56350,
      "ty": 6,
      "x": 838,
      "y": 383,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 56701,
      "e": 56413,
      "ty": 7,
      "x": 832,
      "y": 408,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 56708,
      "e": 56420,
      "ty": 2,
      "x": 832,
      "y": 408
    },
    {
      "t": 56716,
      "e": 56428,
      "ty": 6,
      "x": 831,
      "y": 417,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 56734,
      "e": 56446,
      "ty": 7,
      "x": 831,
      "y": 424,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 56759,
      "e": 56471,
      "ty": 41,
      "x": 2273,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 56783,
      "e": 56495,
      "ty": 6,
      "x": 833,
      "y": 444,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 56809,
      "e": 56521,
      "ty": 2,
      "x": 834,
      "y": 450
    },
    {
      "t": 56817,
      "e": 56529,
      "ty": 7,
      "x": 834,
      "y": 460,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 56833,
      "e": 56545,
      "ty": 6,
      "x": 834,
      "y": 469,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 56883,
      "e": 56595,
      "ty": 7,
      "x": 834,
      "y": 484,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 56909,
      "e": 56621,
      "ty": 2,
      "x": 834,
      "y": 493
    },
    {
      "t": 56925,
      "e": 56637,
      "ty": 6,
      "x": 834,
      "y": 495,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 57009,
      "e": 56721,
      "ty": 2,
      "x": 836,
      "y": 501
    },
    {
      "t": 57010,
      "e": 56722,
      "ty": 41,
      "x": 48284,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 57109,
      "e": 56821,
      "ty": 2,
      "x": 837,
      "y": 502
    },
    {
      "t": 57209,
      "e": 56921,
      "ty": 2,
      "x": 839,
      "y": 506
    },
    {
      "t": 57218,
      "e": 56930,
      "ty": 7,
      "x": 838,
      "y": 508,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 57259,
      "e": 56971,
      "ty": 41,
      "x": 9946,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 57308,
      "e": 57020,
      "ty": 2,
      "x": 833,
      "y": 512
    },
    {
      "t": 57409,
      "e": 57121,
      "ty": 2,
      "x": 831,
      "y": 512
    },
    {
      "t": 57485,
      "e": 57197,
      "ty": 6,
      "x": 826,
      "y": 507,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 57509,
      "e": 57221,
      "ty": 2,
      "x": 826,
      "y": 505
    },
    {
      "t": 57509,
      "e": 57221,
      "ty": 41,
      "x": 0,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 57601,
      "e": 57313,
      "ty": 7,
      "x": 826,
      "y": 494,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 57609,
      "e": 57321,
      "ty": 2,
      "x": 826,
      "y": 494
    },
    {
      "t": 57709,
      "e": 57421,
      "ty": 2,
      "x": 825,
      "y": 483
    },
    {
      "t": 57762,
      "e": 57424,
      "ty": 41,
      "x": 1846,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 57809,
      "e": 57471,
      "ty": 2,
      "x": 823,
      "y": 481
    },
    {
      "t": 58108,
      "e": 57770,
      "ty": 2,
      "x": 823,
      "y": 474
    },
    {
      "t": 58168,
      "e": 57830,
      "ty": 6,
      "x": 830,
      "y": 443,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 58185,
      "e": 57847,
      "ty": 7,
      "x": 830,
      "y": 433,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 58209,
      "e": 57871,
      "ty": 2,
      "x": 830,
      "y": 424
    },
    {
      "t": 58219,
      "e": 57881,
      "ty": 6,
      "x": 830,
      "y": 414,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 58236,
      "e": 57898,
      "ty": 7,
      "x": 828,
      "y": 406,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 58259,
      "e": 57921,
      "ty": 41,
      "x": 5254,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 58268,
      "e": 57930,
      "ty": 6,
      "x": 827,
      "y": 391,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 58308,
      "e": 57970,
      "ty": 2,
      "x": 826,
      "y": 386
    },
    {
      "t": 58318,
      "e": 57980,
      "ty": 7,
      "x": 825,
      "y": 380,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 58409,
      "e": 58071,
      "ty": 2,
      "x": 822,
      "y": 367
    },
    {
      "t": 58508,
      "e": 58170,
      "ty": 2,
      "x": 821,
      "y": 361
    },
    {
      "t": 58509,
      "e": 58171,
      "ty": 41,
      "x": 0,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 58609,
      "e": 58271,
      "ty": 2,
      "x": 821,
      "y": 359
    },
    {
      "t": 58760,
      "e": 58422,
      "ty": 41,
      "x": 0,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 58909,
      "e": 58571,
      "ty": 2,
      "x": 822,
      "y": 357
    },
    {
      "t": 59010,
      "e": 58672,
      "ty": 41,
      "x": 676,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 59109,
      "e": 58771,
      "ty": 2,
      "x": 825,
      "y": 358
    },
    {
      "t": 59260,
      "e": 58922,
      "ty": 41,
      "x": 4188,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 59270,
      "e": 58932,
      "ty": 3,
      "x": 825,
      "y": 358,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 59271,
      "e": 58933,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 59387,
      "e": 59049,
      "ty": 4,
      "x": 4188,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 59389,
      "e": 59051,
      "ty": 5,
      "x": 825,
      "y": 358,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 59389,
      "e": 59051,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 59389,
      "e": 59051,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 59508,
      "e": 59170,
      "ty": 2,
      "x": 821,
      "y": 375
    },
    {
      "t": 59508,
      "e": 59170,
      "ty": 41,
      "x": 0,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 59609,
      "e": 59271,
      "ty": 2,
      "x": 820,
      "y": 439
    },
    {
      "t": 59669,
      "e": 59331,
      "ty": 6,
      "x": 831,
      "y": 468,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 59702,
      "e": 59364,
      "ty": 7,
      "x": 844,
      "y": 493,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 59709,
      "e": 59371,
      "ty": 2,
      "x": 844,
      "y": 493
    },
    {
      "t": 59759,
      "e": 59421,
      "ty": 41,
      "x": 51202,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-1-6 > label"
    },
    {
      "t": 59809,
      "e": 59471,
      "ty": 2,
      "x": 891,
      "y": 557
    },
    {
      "t": 59909,
      "e": 59571,
      "ty": 2,
      "x": 907,
      "y": 581
    },
    {
      "t": 60009,
      "e": 59671,
      "ty": 41,
      "x": 20309,
      "y": 44470,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 60109,
      "e": 59771,
      "ty": 2,
      "x": 902,
      "y": 563
    },
    {
      "t": 60209,
      "e": 59871,
      "ty": 2,
      "x": 896,
      "y": 542
    },
    {
      "t": 60259,
      "e": 59921,
      "ty": 41,
      "x": 17699,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 60409,
      "e": 60071,
      "ty": 2,
      "x": 893,
      "y": 559
    },
    {
      "t": 60508,
      "e": 60170,
      "ty": 2,
      "x": 880,
      "y": 655
    },
    {
      "t": 60509,
      "e": 60171,
      "ty": 41,
      "x": 14760,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 60609,
      "e": 60271,
      "ty": 2,
      "x": 884,
      "y": 683
    },
    {
      "t": 60759,
      "e": 60421,
      "ty": 41,
      "x": 15706,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 61008,
      "e": 60670,
      "ty": 2,
      "x": 861,
      "y": 642
    },
    {
      "t": 61009,
      "e": 60671,
      "ty": 41,
      "x": 9972,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 61108,
      "e": 60770,
      "ty": 2,
      "x": 845,
      "y": 630
    },
    {
      "t": 61208,
      "e": 60870,
      "ty": 2,
      "x": 842,
      "y": 626
    },
    {
      "t": 61259,
      "e": 60921,
      "ty": 41,
      "x": 4988,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 61270,
      "e": 60932,
      "ty": 6,
      "x": 835,
      "y": 643,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 61303,
      "e": 60965,
      "ty": 7,
      "x": 833,
      "y": 658,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 61309,
      "e": 60971,
      "ty": 2,
      "x": 833,
      "y": 658
    },
    {
      "t": 61353,
      "e": 60971,
      "ty": 6,
      "x": 831,
      "y": 672,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 61408,
      "e": 61026,
      "ty": 2,
      "x": 830,
      "y": 676
    },
    {
      "t": 61508,
      "e": 61126,
      "ty": 2,
      "x": 826,
      "y": 683
    },
    {
      "t": 61508,
      "e": 61126,
      "ty": 41,
      "x": 0,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 61521,
      "e": 61139,
      "ty": 7,
      "x": 826,
      "y": 686,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 61571,
      "e": 61189,
      "ty": 6,
      "x": 829,
      "y": 705,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 61587,
      "e": 61205,
      "ty": 7,
      "x": 833,
      "y": 718,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 61604,
      "e": 61222,
      "ty": 6,
      "x": 838,
      "y": 731,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 61608,
      "e": 61226,
      "ty": 2,
      "x": 838,
      "y": 731
    },
    {
      "t": 61620,
      "e": 61238,
      "ty": 7,
      "x": 840,
      "y": 737,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 61708,
      "e": 61326,
      "ty": 2,
      "x": 846,
      "y": 761
    },
    {
      "t": 61758,
      "e": 61376,
      "ty": 41,
      "x": 6544,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 61808,
      "e": 61426,
      "ty": 2,
      "x": 845,
      "y": 787
    },
    {
      "t": 61908,
      "e": 61526,
      "ty": 2,
      "x": 844,
      "y": 788
    },
    {
      "t": 61955,
      "e": 61573,
      "ty": 6,
      "x": 839,
      "y": 786,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 62005,
      "e": 61623,
      "ty": 7,
      "x": 835,
      "y": 779,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 62008,
      "e": 61626,
      "ty": 2,
      "x": 835,
      "y": 779
    },
    {
      "t": 62009,
      "e": 61627,
      "ty": 41,
      "x": 3222,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 62072,
      "e": 61690,
      "ty": 6,
      "x": 829,
      "y": 767,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 62108,
      "e": 61726,
      "ty": 2,
      "x": 826,
      "y": 765
    },
    {
      "t": 62122,
      "e": 61740,
      "ty": 7,
      "x": 825,
      "y": 764,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 62208,
      "e": 61826,
      "ty": 2,
      "x": 825,
      "y": 758
    },
    {
      "t": 62258,
      "e": 61876,
      "ty": 41,
      "x": 849,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 62308,
      "e": 61926,
      "ty": 2,
      "x": 828,
      "y": 745
    },
    {
      "t": 62372,
      "e": 61990,
      "ty": 6,
      "x": 830,
      "y": 737,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 62408,
      "e": 62026,
      "ty": 2,
      "x": 833,
      "y": 730
    },
    {
      "t": 62477,
      "e": 62095,
      "ty": 7,
      "x": 833,
      "y": 726,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 62508,
      "e": 62126,
      "ty": 2,
      "x": 833,
      "y": 725
    },
    {
      "t": 62509,
      "e": 62127,
      "ty": 41,
      "x": 6481,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 62708,
      "e": 62326,
      "ty": 2,
      "x": 832,
      "y": 726
    },
    {
      "t": 62709,
      "e": 62327,
      "ty": 6,
      "x": 832,
      "y": 727,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 62758,
      "e": 62376,
      "ty": 41,
      "x": 33161,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 62808,
      "e": 62426,
      "ty": 2,
      "x": 833,
      "y": 730
    },
    {
      "t": 62908,
      "e": 62526,
      "ty": 2,
      "x": 835,
      "y": 739
    },
    {
      "t": 62922,
      "e": 62540,
      "ty": 7,
      "x": 835,
      "y": 741,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 63008,
      "e": 62626,
      "ty": 2,
      "x": 832,
      "y": 753
    },
    {
      "t": 63009,
      "e": 62627,
      "ty": 41,
      "x": 6243,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 63038,
      "e": 62656,
      "ty": 6,
      "x": 832,
      "y": 755,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 63108,
      "e": 62726,
      "ty": 2,
      "x": 831,
      "y": 756
    },
    {
      "t": 63208,
      "e": 62826,
      "ty": 2,
      "x": 829,
      "y": 763
    },
    {
      "t": 63258,
      "e": 62876,
      "ty": 41,
      "x": 7955,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 63288,
      "e": 62906,
      "ty": 7,
      "x": 827,
      "y": 768,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 63308,
      "e": 62926,
      "ty": 2,
      "x": 827,
      "y": 768
    },
    {
      "t": 63408,
      "e": 63026,
      "ty": 2,
      "x": 827,
      "y": 779
    },
    {
      "t": 63439,
      "e": 63057,
      "ty": 6,
      "x": 829,
      "y": 783,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 63508,
      "e": 63126,
      "ty": 2,
      "x": 830,
      "y": 784
    },
    {
      "t": 63509,
      "e": 63127,
      "ty": 41,
      "x": 18037,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 63591,
      "e": 63209,
      "ty": 7,
      "x": 844,
      "y": 779,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 63608,
      "e": 63226,
      "ty": 2,
      "x": 847,
      "y": 770
    },
    {
      "t": 63708,
      "e": 63326,
      "ty": 2,
      "x": 842,
      "y": 733
    },
    {
      "t": 63758,
      "e": 63326,
      "ty": 41,
      "x": 6917,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 63772,
      "e": 63340,
      "ty": 6,
      "x": 838,
      "y": 711,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 63808,
      "e": 63376,
      "ty": 2,
      "x": 838,
      "y": 706
    },
    {
      "t": 63908,
      "e": 63476,
      "ty": 2,
      "x": 838,
      "y": 699
    },
    {
      "t": 63909,
      "e": 63477,
      "ty": 7,
      "x": 836,
      "y": 697,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 64008,
      "e": 63576,
      "ty": 2,
      "x": 828,
      "y": 685
    },
    {
      "t": 64009,
      "e": 63577,
      "ty": 41,
      "x": 1651,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 64040,
      "e": 63608,
      "ty": 6,
      "x": 826,
      "y": 681,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 64055,
      "e": 63623,
      "ty": 7,
      "x": 825,
      "y": 680,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 64109,
      "e": 63677,
      "ty": 2,
      "x": 824,
      "y": 678
    },
    {
      "t": 64258,
      "e": 63826,
      "ty": 41,
      "x": 647,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 64408,
      "e": 63976,
      "ty": 2,
      "x": 824,
      "y": 676
    },
    {
      "t": 64508,
      "e": 64076,
      "ty": 41,
      "x": 647,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 64608,
      "e": 64176,
      "ty": 2,
      "x": 824,
      "y": 675
    },
    {
      "t": 64693,
      "e": 64261,
      "ty": 6,
      "x": 826,
      "y": 672,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 64708,
      "e": 64276,
      "ty": 2,
      "x": 826,
      "y": 672
    },
    {
      "t": 64759,
      "e": 64327,
      "ty": 41,
      "x": 0,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 64808,
      "e": 64376,
      "ty": 2,
      "x": 828,
      "y": 672
    },
    {
      "t": 64908,
      "e": 64476,
      "ty": 2,
      "x": 831,
      "y": 672
    },
    {
      "t": 65008,
      "e": 64576,
      "ty": 2,
      "x": 832,
      "y": 672
    },
    {
      "t": 65009,
      "e": 64577,
      "ty": 41,
      "x": 28120,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 65045,
      "e": 64613,
      "ty": 3,
      "x": 832,
      "y": 672,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 65046,
      "e": 64614,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 65047,
      "e": 64615,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 65156,
      "e": 64724,
      "ty": 4,
      "x": 28120,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 65156,
      "e": 64724,
      "ty": 5,
      "x": 832,
      "y": 672,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 65156,
      "e": 64724,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 65409,
      "e": 64977,
      "ty": 2,
      "x": 832,
      "y": 674
    },
    {
      "t": 65508,
      "e": 65076,
      "ty": 7,
      "x": 832,
      "y": 687,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 65510,
      "e": 65078,
      "ty": 2,
      "x": 832,
      "y": 687
    },
    {
      "t": 65510,
      "e": 65078,
      "ty": 41,
      "x": 2654,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 65540,
      "e": 65108,
      "ty": 6,
      "x": 837,
      "y": 699,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 65608,
      "e": 65176,
      "ty": 7,
      "x": 840,
      "y": 710,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 65609,
      "e": 65177,
      "ty": 2,
      "x": 840,
      "y": 710
    },
    {
      "t": 65711,
      "e": 65279,
      "ty": 2,
      "x": 850,
      "y": 791
    },
    {
      "t": 65761,
      "e": 65329,
      "ty": 41,
      "x": 7968,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 65812,
      "e": 65380,
      "ty": 2,
      "x": 858,
      "y": 843
    },
    {
      "t": 65913,
      "e": 65481,
      "ty": 2,
      "x": 859,
      "y": 873
    },
    {
      "t": 66011,
      "e": 65579,
      "ty": 2,
      "x": 855,
      "y": 885
    },
    {
      "t": 66011,
      "e": 65579,
      "ty": 41,
      "x": 36675,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 66111,
      "e": 65679,
      "ty": 2,
      "x": 854,
      "y": 886
    },
    {
      "t": 66211,
      "e": 65779,
      "ty": 2,
      "x": 845,
      "y": 892
    },
    {
      "t": 66261,
      "e": 65829,
      "ty": 41,
      "x": 25753,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 66312,
      "e": 65880,
      "ty": 2,
      "x": 843,
      "y": 882
    },
    {
      "t": 66362,
      "e": 65930,
      "ty": 6,
      "x": 839,
      "y": 878,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 66411,
      "e": 65979,
      "ty": 2,
      "x": 829,
      "y": 875
    },
    {
      "t": 66428,
      "e": 65996,
      "ty": 7,
      "x": 827,
      "y": 874,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 66511,
      "e": 66079,
      "ty": 2,
      "x": 825,
      "y": 873
    },
    {
      "t": 66511,
      "e": 66079,
      "ty": 41,
      "x": 3908,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 66633,
      "e": 66201,
      "ty": 3,
      "x": 825,
      "y": 873,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 66633,
      "e": 66201,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 66711,
      "e": 66279,
      "ty": 4,
      "x": 3908,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 66711,
      "e": 66279,
      "ty": 5,
      "x": 825,
      "y": 873,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 66711,
      "e": 66279,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 66711,
      "e": 66279,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 66811,
      "e": 66379,
      "ty": 2,
      "x": 824,
      "y": 873
    },
    {
      "t": 66844,
      "e": 66412,
      "ty": 6,
      "x": 827,
      "y": 879,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 66911,
      "e": 66479,
      "ty": 2,
      "x": 828,
      "y": 880
    },
    {
      "t": 67012,
      "e": 66580,
      "ty": 41,
      "x": 7955,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 67048,
      "e": 66616,
      "ty": 3,
      "x": 828,
      "y": 880,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 67128,
      "e": 66696,
      "ty": 4,
      "x": 7955,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 67128,
      "e": 66696,
      "ty": 5,
      "x": 828,
      "y": 880,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 67662,
      "e": 67230,
      "ty": 7,
      "x": 828,
      "y": 893,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 67680,
      "e": 67248,
      "ty": 6,
      "x": 830,
      "y": 903,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 67695,
      "e": 67263,
      "ty": 7,
      "x": 837,
      "y": 920,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 67712,
      "e": 67280,
      "ty": 2,
      "x": 837,
      "y": 920
    },
    {
      "t": 67761,
      "e": 67329,
      "ty": 41,
      "x": 22413,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 67812,
      "e": 67380,
      "ty": 2,
      "x": 844,
      "y": 934
    },
    {
      "t": 67911,
      "e": 67479,
      "ty": 2,
      "x": 849,
      "y": 947
    },
    {
      "t": 67947,
      "e": 67515,
      "ty": 6,
      "x": 853,
      "y": 954,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68011,
      "e": 67579,
      "ty": 2,
      "x": 856,
      "y": 965
    },
    {
      "t": 68012,
      "e": 67579,
      "ty": 41,
      "x": 13698,
      "y": 25816,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68112,
      "e": 67679,
      "ty": 2,
      "x": 859,
      "y": 971
    },
    {
      "t": 68152,
      "e": 67719,
      "ty": 3,
      "x": 860,
      "y": 972,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68153,
      "e": 67720,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 68153,
      "e": 67720,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68211,
      "e": 67778,
      "ty": 2,
      "x": 860,
      "y": 972
    },
    {
      "t": 68240,
      "e": 67807,
      "ty": 4,
      "x": 15759,
      "y": 39718,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68241,
      "e": 67808,
      "ty": 5,
      "x": 860,
      "y": 972,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68246,
      "e": 67813,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68247,
      "e": 67814,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 68249,
      "e": 67816,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 68261,
      "e": 67828,
      "ty": 41,
      "x": 29340,
      "y": 58658,
      "ta": "html > body"
    },
    {
      "t": 68911,
      "e": 68478,
      "ty": 2,
      "x": 718,
      "y": 566
    },
    {
      "t": 69011,
      "e": 68578,
      "ty": 2,
      "x": 563,
      "y": 223
    },
    {
      "t": 69012,
      "e": 68579,
      "ty": 41,
      "x": 19112,
      "y": 13082,
      "ta": "html > body"
    },
    {
      "t": 69111,
      "e": 68678,
      "ty": 2,
      "x": 484,
      "y": 173
    },
    {
      "t": 69211,
      "e": 68778,
      "ty": 2,
      "x": 481,
      "y": 170
    },
    {
      "t": 69262,
      "e": 68829,
      "ty": 41,
      "x": 16289,
      "y": 9857,
      "ta": "html > body"
    },
    {
      "t": 69411,
      "e": 68978,
      "ty": 2,
      "x": 481,
      "y": 168
    },
    {
      "t": 69512,
      "e": 69079,
      "ty": 41,
      "x": 16289,
      "y": 9735,
      "ta": "html > body"
    },
    {
      "t": 69561,
      "e": 69128,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 69911,
      "e": 69478,
      "ty": 2,
      "x": 481,
      "y": 167
    },
    {
      "t": 70012,
      "e": 69579,
      "ty": 2,
      "x": 484,
      "y": 166
    },
    {
      "t": 70012,
      "e": 69579,
      "ty": 41,
      "x": 9374,
      "y": 3825,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 70111,
      "e": 69678,
      "ty": 2,
      "x": 488,
      "y": 166
    },
    {
      "t": 70211,
      "e": 69778,
      "ty": 2,
      "x": 605,
      "y": 231
    },
    {
      "t": 70261,
      "e": 69828,
      "ty": 41,
      "x": 19115,
      "y": 8191,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 70311,
      "e": 69878,
      "ty": 2,
      "x": 793,
      "y": 453
    },
    {
      "t": 70411,
      "e": 69978,
      "ty": 2,
      "x": 838,
      "y": 484
    },
    {
      "t": 70512,
      "e": 70079,
      "ty": 41,
      "x": 26790,
      "y": 21259,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 70611,
      "e": 70178,
      "ty": 2,
      "x": 821,
      "y": 475
    },
    {
      "t": 70712,
      "e": 70279,
      "ty": 2,
      "x": 660,
      "y": 433
    },
    {
      "t": 70762,
      "e": 70329,
      "ty": 41,
      "x": 17885,
      "y": 585,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 70811,
      "e": 70378,
      "ty": 2,
      "x": 657,
      "y": 431
    },
    {
      "t": 71762,
      "e": 71329,
      "ty": 41,
      "x": 17934,
      "y": 195,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 71812,
      "e": 71379,
      "ty": 2,
      "x": 704,
      "y": 474
    },
    {
      "t": 71912,
      "e": 71479,
      "ty": 2,
      "x": 824,
      "y": 698
    },
    {
      "t": 72012,
      "e": 71579,
      "ty": 2,
      "x": 885,
      "y": 847
    },
    {
      "t": 72012,
      "e": 71579,
      "ty": 41,
      "x": 29102,
      "y": 64364,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 72083,
      "e": 71650,
      "ty": 6,
      "x": 919,
      "y": 982,
      "ta": "#start"
    },
    {
      "t": 72111,
      "e": 71678,
      "ty": 2,
      "x": 923,
      "y": 1004
    },
    {
      "t": 72115,
      "e": 71682,
      "ty": 7,
      "x": 926,
      "y": 1023,
      "ta": "#start"
    },
    {
      "t": 72211,
      "e": 71778,
      "ty": 2,
      "x": 928,
      "y": 1029
    },
    {
      "t": 72262,
      "e": 71829,
      "ty": 41,
      "x": 18022,
      "y": 31464,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 72312,
      "e": 71879,
      "ty": 2,
      "x": 933,
      "y": 1029
    },
    {
      "t": 72350,
      "e": 71917,
      "ty": 6,
      "x": 955,
      "y": 1008,
      "ta": "#start"
    },
    {
      "t": 72411,
      "e": 71978,
      "ty": 2,
      "x": 964,
      "y": 987
    },
    {
      "t": 72511,
      "e": 72078,
      "ty": 2,
      "x": 967,
      "y": 981
    },
    {
      "t": 72512,
      "e": 72079,
      "ty": 41,
      "x": 31402,
      "y": 7137,
      "ta": "#start"
    },
    {
      "t": 72665,
      "e": 72232,
      "ty": 3,
      "x": 967,
      "y": 981,
      "ta": "#start"
    },
    {
      "t": 72666,
      "e": 72233,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 72776,
      "e": 72343,
      "ty": 4,
      "x": 31402,
      "y": 7137,
      "ta": "#start"
    },
    {
      "t": 72778,
      "e": 72345,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 72778,
      "e": 72345,
      "ty": 5,
      "x": 967,
      "y": 981,
      "ta": "#start"
    },
    {
      "t": 72779,
      "e": 72346,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 73762,
      "e": 73329,
      "ty": 41,
      "x": 33025,
      "y": 59145,
      "ta": "html > body"
    },
    {
      "t": 73802,
      "e": 73369,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 74140,
      "e": 73707,
      "ty": 2,
      "x": 967,
      "y": 980
    },
    {
      "t": 74595,
      "e": 74162,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 1211, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 1214, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"G27Q3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 2631, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 4939, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"G27Q3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 5785, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"YANKEE\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"311\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 11728, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"G27Q3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 1582, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 14400, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"G27Q3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 929, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 16332, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"G27Q3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 4672, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 22301, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"G27Q3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-12 PM-11 AM-F -F -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1026,y:862,t:1528139993245};\\\", \\\"{x:1022,y:796,t:1528139993489};\\\", \\\"{x:1017,y:780,t:1528139993508};\\\", \\\"{x:1015,y:776,t:1528139993524};\\\", \\\"{x:1013,y:774,t:1528139993542};\\\", \\\"{x:1011,y:769,t:1528139993558};\\\", \\\"{x:1001,y:759,t:1528139993575};\\\", \\\"{x:983,y:742,t:1528139993592};\\\", \\\"{x:956,y:727,t:1528139993608};\\\", \\\"{x:910,y:708,t:1528139993626};\\\", \\\"{x:826,y:679,t:1528139993642};\\\", \\\"{x:794,y:668,t:1528139993659};\\\", \\\"{x:778,y:663,t:1528139993675};\\\", \\\"{x:752,y:653,t:1528139993692};\\\", \\\"{x:740,y:651,t:1528139993708};\\\", \\\"{x:731,y:648,t:1528139993725};\\\", \\\"{x:717,y:642,t:1528139993743};\\\", \\\"{x:697,y:630,t:1528139993848};\\\", \\\"{x:696,y:627,t:1528139993858};\\\", \\\"{x:690,y:619,t:1528139993874};\\\", \\\"{x:684,y:615,t:1528139993892};\\\", \\\"{x:681,y:609,t:1528139993908};\\\", \\\"{x:678,y:597,t:1528139993925};\\\", \\\"{x:674,y:585,t:1528139993943};\\\", \\\"{x:673,y:579,t:1528139993959};\\\", \\\"{x:673,y:575,t:1528139993975};\\\", \\\"{x:684,y:568,t:1528139993992};\\\", \\\"{x:699,y:559,t:1528139994010};\\\", \\\"{x:729,y:557,t:1528139994025};\\\", \\\"{x:767,y:564,t:1528139994043};\\\", \\\"{x:776,y:568,t:1528139994060};\\\", \\\"{x:777,y:568,t:1528139994318};\\\", \\\"{x:782,y:572,t:1528139994349};\\\", \\\"{x:874,y:610,t:1528139994366};\\\", \\\"{x:933,y:651,t:1528139994375};\\\", \\\"{x:1013,y:705,t:1528139994392};\\\", \\\"{x:1087,y:768,t:1528139994409};\\\", \\\"{x:1170,y:819,t:1528139994426};\\\", \\\"{x:1206,y:848,t:1528139994442};\\\", \\\"{x:1230,y:865,t:1528139994459};\\\", \\\"{x:1252,y:884,t:1528139994476};\\\", \\\"{x:1259,y:889,t:1528139994492};\\\", \\\"{x:1263,y:891,t:1528139994509};\\\", \\\"{x:1271,y:897,t:1528139994526};\\\", \\\"{x:1283,y:908,t:1528139994542};\\\", \\\"{x:1298,y:920,t:1528139994559};\\\", \\\"{x:1327,y:940,t:1528139994577};\\\", \\\"{x:1342,y:951,t:1528139994592};\\\", \\\"{x:1364,y:954,t:1528139994609};\\\", \\\"{x:1371,y:954,t:1528139994627};\\\", \\\"{x:1372,y:954,t:1528139994686};\\\", \\\"{x:1370,y:949,t:1528139994693};\\\", \\\"{x:1362,y:941,t:1528139994709};\\\", \\\"{x:1355,y:935,t:1528139994727};\\\", \\\"{x:1348,y:932,t:1528139994744};\\\", \\\"{x:1346,y:931,t:1528139994760};\\\", \\\"{x:1345,y:931,t:1528139994797};\\\", \\\"{x:1343,y:931,t:1528139994813};\\\", \\\"{x:1340,y:931,t:1528139994827};\\\", \\\"{x:1333,y:929,t:1528139994844};\\\", \\\"{x:1323,y:928,t:1528139994860};\\\", \\\"{x:1305,y:924,t:1528139994877};\\\", \\\"{x:1298,y:922,t:1528139994893};\\\", \\\"{x:1297,y:922,t:1528139994910};\\\", \\\"{x:1295,y:921,t:1528139994932};\\\", \\\"{x:1294,y:920,t:1528139994944};\\\", \\\"{x:1294,y:918,t:1528139994964};\\\", \\\"{x:1293,y:916,t:1528139994996};\\\", \\\"{x:1292,y:914,t:1528139995012};\\\", \\\"{x:1292,y:913,t:1528139995026};\\\", \\\"{x:1291,y:909,t:1528139995044};\\\", \\\"{x:1289,y:906,t:1528139995060};\\\", \\\"{x:1283,y:895,t:1528139995076};\\\", \\\"{x:1281,y:893,t:1528139995093};\\\", \\\"{x:1281,y:892,t:1528139995111};\\\", \\\"{x:1281,y:891,t:1528139995127};\\\", \\\"{x:1280,y:890,t:1528139995143};\\\", \\\"{x:1280,y:888,t:1528139995160};\\\", \\\"{x:1280,y:886,t:1528139995176};\\\", \\\"{x:1280,y:885,t:1528139995193};\\\", \\\"{x:1280,y:882,t:1528139995211};\\\", \\\"{x:1280,y:879,t:1528139995227};\\\", \\\"{x:1280,y:875,t:1528139995244};\\\", \\\"{x:1281,y:871,t:1528139995261};\\\", \\\"{x:1288,y:859,t:1528139995276};\\\", \\\"{x:1294,y:845,t:1528139995295};\\\", \\\"{x:1300,y:829,t:1528139995310};\\\", \\\"{x:1305,y:817,t:1528139995326};\\\", \\\"{x:1309,y:806,t:1528139995343};\\\", \\\"{x:1315,y:797,t:1528139995361};\\\", \\\"{x:1323,y:784,t:1528139995377};\\\", \\\"{x:1330,y:773,t:1528139995394};\\\", \\\"{x:1334,y:762,t:1528139995410};\\\", \\\"{x:1339,y:752,t:1528139995427};\\\", \\\"{x:1345,y:745,t:1528139995443};\\\", \\\"{x:1357,y:737,t:1528139995460};\\\", \\\"{x:1358,y:734,t:1528139995477};\\\", \\\"{x:1365,y:729,t:1528139995494};\\\", \\\"{x:1370,y:724,t:1528139995511};\\\", \\\"{x:1375,y:714,t:1528139995527};\\\", \\\"{x:1378,y:711,t:1528139995548};\\\", \\\"{x:1380,y:708,t:1528139995560};\\\", \\\"{x:1383,y:704,t:1528139995578};\\\", \\\"{x:1384,y:701,t:1528139995594};\\\", \\\"{x:1386,y:698,t:1528139995611};\\\", \\\"{x:1390,y:694,t:1528139995627};\\\", \\\"{x:1395,y:686,t:1528139995643};\\\", \\\"{x:1400,y:676,t:1528139995660};\\\", \\\"{x:1402,y:674,t:1528139995678};\\\", \\\"{x:1402,y:673,t:1528139995693};\\\", \\\"{x:1403,y:672,t:1528139995740};\\\", \\\"{x:1405,y:671,t:1528139995748};\\\", \\\"{x:1405,y:669,t:1528139995765};\\\", \\\"{x:1406,y:667,t:1528139995778};\\\", \\\"{x:1407,y:667,t:1528139995796};\\\", \\\"{x:1407,y:666,t:1528139995869};\\\", \\\"{x:1407,y:663,t:1528139995893};\\\", \\\"{x:1410,y:661,t:1528139995910};\\\", \\\"{x:1412,y:658,t:1528139995928};\\\", \\\"{x:1412,y:655,t:1528139995945};\\\", \\\"{x:1412,y:654,t:1528139995961};\\\", \\\"{x:1410,y:656,t:1528139996046};\\\", \\\"{x:1406,y:661,t:1528139996061};\\\", \\\"{x:1395,y:673,t:1528139996079};\\\", \\\"{x:1381,y:687,t:1528139996095};\\\", \\\"{x:1365,y:704,t:1528139996111};\\\", \\\"{x:1327,y:727,t:1528139996128};\\\", \\\"{x:1280,y:760,t:1528139996145};\\\", \\\"{x:1219,y:788,t:1528139996162};\\\", \\\"{x:1120,y:806,t:1528139996178};\\\", \\\"{x:997,y:812,t:1528139996195};\\\", \\\"{x:878,y:812,t:1528139996211};\\\", \\\"{x:745,y:803,t:1528139996231};\\\", \\\"{x:662,y:794,t:1528139996245};\\\", \\\"{x:609,y:769,t:1528139996260};\\\", \\\"{x:589,y:755,t:1528139996277};\\\", \\\"{x:584,y:748,t:1528139996294};\\\", \\\"{x:578,y:739,t:1528139996310};\\\", \\\"{x:571,y:726,t:1528139996327};\\\", \\\"{x:566,y:717,t:1528139996344};\\\", \\\"{x:559,y:706,t:1528139996361};\\\", \\\"{x:550,y:695,t:1528139996377};\\\", \\\"{x:528,y:670,t:1528139996396};\\\", \\\"{x:518,y:661,t:1528139996414};\\\", \\\"{x:511,y:655,t:1528139996427};\\\", \\\"{x:504,y:648,t:1528139996444};\\\", \\\"{x:500,y:642,t:1528139996460};\\\", \\\"{x:498,y:636,t:1528139996478};\\\", \\\"{x:495,y:626,t:1528139996495};\\\", \\\"{x:494,y:622,t:1528139996511};\\\", \\\"{x:490,y:617,t:1528139996527};\\\", \\\"{x:490,y:615,t:1528139996545};\\\", \\\"{x:486,y:612,t:1528139996561};\\\", \\\"{x:484,y:607,t:1528139996577};\\\", \\\"{x:480,y:603,t:1528139996595};\\\", \\\"{x:479,y:600,t:1528139996612};\\\", \\\"{x:471,y:594,t:1528139996628};\\\", \\\"{x:463,y:587,t:1528139996644};\\\", \\\"{x:454,y:581,t:1528139996662};\\\", \\\"{x:447,y:578,t:1528139996678};\\\", \\\"{x:442,y:576,t:1528139996694};\\\", \\\"{x:436,y:573,t:1528139996712};\\\", \\\"{x:432,y:572,t:1528139996728};\\\", \\\"{x:430,y:570,t:1528139996745};\\\", \\\"{x:429,y:570,t:1528139996761};\\\", \\\"{x:425,y:568,t:1528139996778};\\\", \\\"{x:424,y:567,t:1528139996794};\\\", \\\"{x:418,y:563,t:1528139996813};\\\", \\\"{x:415,y:559,t:1528139996828};\\\", \\\"{x:410,y:555,t:1528139996845};\\\", \\\"{x:400,y:550,t:1528139996861};\\\", \\\"{x:397,y:545,t:1528139996877};\\\", \\\"{x:391,y:542,t:1528139996895};\\\", \\\"{x:389,y:541,t:1528139996912};\\\", \\\"{x:389,y:540,t:1528139996927};\\\", \\\"{x:388,y:538,t:1528139996944};\\\", \\\"{x:387,y:538,t:1528139996972};\\\", \\\"{x:387,y:542,t:1528139997236};\\\", \\\"{x:388,y:548,t:1528139997245};\\\", \\\"{x:396,y:555,t:1528139997262};\\\", \\\"{x:401,y:563,t:1528139997279};\\\", \\\"{x:419,y:582,t:1528139997295};\\\", \\\"{x:432,y:597,t:1528139997311};\\\", \\\"{x:441,y:608,t:1528139997328};\\\", \\\"{x:449,y:617,t:1528139997345};\\\", \\\"{x:455,y:624,t:1528139997361};\\\", \\\"{x:462,y:633,t:1528139997379};\\\", \\\"{x:467,y:641,t:1528139997396};\\\", \\\"{x:470,y:645,t:1528139997411};\\\", \\\"{x:475,y:651,t:1528139997428};\\\", \\\"{x:476,y:653,t:1528139997445};\\\", \\\"{x:480,y:658,t:1528139997462};\\\", \\\"{x:490,y:669,t:1528139997479};\\\", \\\"{x:495,y:675,t:1528139997496};\\\", \\\"{x:495,y:676,t:1528139997513};\\\", \\\"{x:496,y:679,t:1528139997529};\\\", \\\"{x:498,y:680,t:1528139997546};\\\", \\\"{x:498,y:681,t:1528139997572};\\\", \\\"{x:499,y:681,t:1528139997587};\\\", \\\"{x:499,y:682,t:1528139997595};\\\", \\\"{x:500,y:684,t:1528139997613};\\\", \\\"{x:500,y:686,t:1528139997644};\\\", \\\"{x:501,y:687,t:1528139997660};\\\", \\\"{x:501,y:690,t:1528139997668};\\\", \\\"{x:501,y:691,t:1528139997678};\\\", \\\"{x:502,y:696,t:1528139997695};\\\", \\\"{x:502,y:700,t:1528139997712};\\\", \\\"{x:503,y:701,t:1528139997728};\\\" ] }, { \\\"rt\\\": 6402, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 30011, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"G27Q3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:505,y:701,t:1528139999909};\\\", \\\"{x:510,y:700,t:1528139999917};\\\", \\\"{x:513,y:700,t:1528139999931};\\\", \\\"{x:530,y:689,t:1528139999948};\\\", \\\"{x:549,y:677,t:1528139999966};\\\", \\\"{x:567,y:659,t:1528139999981};\\\", \\\"{x:610,y:635,t:1528139999997};\\\", \\\"{x:664,y:615,t:1528140000015};\\\", \\\"{x:742,y:593,t:1528140000031};\\\", \\\"{x:814,y:573,t:1528140000047};\\\", \\\"{x:900,y:560,t:1528140000063};\\\", \\\"{x:925,y:556,t:1528140000081};\\\", \\\"{x:961,y:556,t:1528140000097};\\\", \\\"{x:982,y:558,t:1528140000114};\\\", \\\"{x:1007,y:565,t:1528140000130};\\\", \\\"{x:1030,y:571,t:1528140000147};\\\", \\\"{x:1068,y:585,t:1528140000164};\\\", \\\"{x:1095,y:595,t:1528140000180};\\\", \\\"{x:1108,y:602,t:1528140000197};\\\", \\\"{x:1117,y:608,t:1528140000213};\\\", \\\"{x:1129,y:614,t:1528140000230};\\\", \\\"{x:1134,y:618,t:1528140000247};\\\", \\\"{x:1147,y:624,t:1528140000264};\\\", \\\"{x:1174,y:639,t:1528140000281};\\\", \\\"{x:1188,y:652,t:1528140000297};\\\", \\\"{x:1229,y:667,t:1528140000315};\\\", \\\"{x:1253,y:676,t:1528140000330};\\\", \\\"{x:1286,y:684,t:1528140000347};\\\", \\\"{x:1331,y:700,t:1528140000364};\\\", \\\"{x:1343,y:701,t:1528140000380};\\\", \\\"{x:1355,y:702,t:1528140000397};\\\", \\\"{x:1361,y:702,t:1528140000415};\\\", \\\"{x:1364,y:701,t:1528140000430};\\\", \\\"{x:1365,y:701,t:1528140000448};\\\", \\\"{x:1361,y:701,t:1528140000549};\\\", \\\"{x:1337,y:702,t:1528140000565};\\\", \\\"{x:1321,y:706,t:1528140000581};\\\", \\\"{x:1299,y:713,t:1528140000597};\\\", \\\"{x:1273,y:717,t:1528140000614};\\\", \\\"{x:1273,y:719,t:1528140000630};\\\", \\\"{x:1273,y:718,t:1528140001662};\\\", \\\"{x:1273,y:716,t:1528140001669};\\\", \\\"{x:1273,y:713,t:1528140001682};\\\", \\\"{x:1276,y:704,t:1528140001699};\\\", \\\"{x:1286,y:686,t:1528140001715};\\\", \\\"{x:1294,y:658,t:1528140001731};\\\", \\\"{x:1307,y:595,t:1528140001749};\\\", \\\"{x:1313,y:558,t:1528140001766};\\\", \\\"{x:1313,y:537,t:1528140001782};\\\", \\\"{x:1313,y:522,t:1528140001798};\\\", \\\"{x:1313,y:513,t:1528140001816};\\\", \\\"{x:1313,y:505,t:1528140001832};\\\", \\\"{x:1313,y:500,t:1528140001849};\\\", \\\"{x:1313,y:497,t:1528140001866};\\\", \\\"{x:1312,y:497,t:1528140001882};\\\", \\\"{x:1312,y:496,t:1528140001899};\\\", \\\"{x:1308,y:495,t:1528140001916};\\\", \\\"{x:1308,y:494,t:1528140001932};\\\", \\\"{x:1310,y:495,t:1528140002414};\\\", \\\"{x:1315,y:499,t:1528140002420};\\\", \\\"{x:1320,y:500,t:1528140002433};\\\", \\\"{x:1324,y:504,t:1528140002449};\\\", \\\"{x:1329,y:506,t:1528140002466};\\\", \\\"{x:1355,y:502,t:1528140002483};\\\", \\\"{x:1399,y:476,t:1528140002499};\\\", \\\"{x:1480,y:436,t:1528140002516};\\\", \\\"{x:1559,y:382,t:1528140002533};\\\", \\\"{x:1598,y:353,t:1528140002549};\\\", \\\"{x:1624,y:328,t:1528140002566};\\\", \\\"{x:1648,y:308,t:1528140002583};\\\", \\\"{x:1661,y:296,t:1528140002599};\\\", \\\"{x:1681,y:291,t:1528140002616};\\\", \\\"{x:1695,y:288,t:1528140002633};\\\", \\\"{x:1703,y:287,t:1528140002650};\\\", \\\"{x:1709,y:287,t:1528140002665};\\\", \\\"{x:1711,y:287,t:1528140002683};\\\", \\\"{x:1713,y:287,t:1528140002709};\\\", \\\"{x:1715,y:287,t:1528140002717};\\\", \\\"{x:1718,y:293,t:1528140002733};\\\", \\\"{x:1721,y:308,t:1528140002750};\\\", \\\"{x:1721,y:322,t:1528140002766};\\\", \\\"{x:1712,y:345,t:1528140002783};\\\", \\\"{x:1701,y:365,t:1528140002800};\\\", \\\"{x:1689,y:384,t:1528140002816};\\\", \\\"{x:1677,y:401,t:1528140002833};\\\", \\\"{x:1657,y:416,t:1528140002850};\\\", \\\"{x:1642,y:432,t:1528140002867};\\\", \\\"{x:1620,y:448,t:1528140002883};\\\", \\\"{x:1605,y:458,t:1528140002900};\\\", \\\"{x:1592,y:474,t:1528140002916};\\\", \\\"{x:1570,y:491,t:1528140002933};\\\", \\\"{x:1556,y:503,t:1528140002950};\\\", \\\"{x:1546,y:520,t:1528140002966};\\\", \\\"{x:1541,y:540,t:1528140002983};\\\", \\\"{x:1535,y:558,t:1528140003000};\\\", \\\"{x:1527,y:578,t:1528140003016};\\\", \\\"{x:1516,y:593,t:1528140003033};\\\", \\\"{x:1513,y:602,t:1528140003050};\\\", \\\"{x:1509,y:609,t:1528140003066};\\\", \\\"{x:1506,y:614,t:1528140003083};\\\", \\\"{x:1504,y:617,t:1528140003101};\\\", \\\"{x:1502,y:619,t:1528140003116};\\\", \\\"{x:1502,y:620,t:1528140003133};\\\", \\\"{x:1502,y:617,t:1528140003253};\\\", \\\"{x:1503,y:616,t:1528140003268};\\\", \\\"{x:1505,y:611,t:1528140003283};\\\", \\\"{x:1507,y:608,t:1528140003300};\\\", \\\"{x:1510,y:602,t:1528140003316};\\\", \\\"{x:1511,y:598,t:1528140003333};\\\", \\\"{x:1513,y:595,t:1528140003350};\\\", \\\"{x:1513,y:594,t:1528140003367};\\\", \\\"{x:1513,y:593,t:1528140003389};\\\", \\\"{x:1514,y:591,t:1528140003413};\\\", \\\"{x:1515,y:591,t:1528140003453};\\\", \\\"{x:1515,y:589,t:1528140003477};\\\", \\\"{x:1515,y:588,t:1528140003501};\\\", \\\"{x:1516,y:588,t:1528140003524};\\\", \\\"{x:1517,y:586,t:1528140003540};\\\", \\\"{x:1517,y:584,t:1528140003556};\\\", \\\"{x:1517,y:583,t:1528140003581};\\\", \\\"{x:1515,y:583,t:1528140003750};\\\", \\\"{x:1502,y:593,t:1528140003759};\\\", \\\"{x:1468,y:601,t:1528140003766};\\\", \\\"{x:1389,y:615,t:1528140003784};\\\", \\\"{x:1275,y:634,t:1528140003800};\\\", \\\"{x:1105,y:642,t:1528140003816};\\\", \\\"{x:919,y:656,t:1528140003833};\\\", \\\"{x:738,y:669,t:1528140003849};\\\", \\\"{x:588,y:669,t:1528140003867};\\\", \\\"{x:472,y:669,t:1528140003883};\\\", \\\"{x:395,y:663,t:1528140003899};\\\", \\\"{x:355,y:658,t:1528140003916};\\\", \\\"{x:347,y:656,t:1528140003933};\\\", \\\"{x:346,y:656,t:1528140003949};\\\", \\\"{x:344,y:656,t:1528140004004};\\\", \\\"{x:340,y:653,t:1528140004017};\\\", \\\"{x:333,y:645,t:1528140004034};\\\", \\\"{x:313,y:637,t:1528140004049};\\\", \\\"{x:299,y:626,t:1528140004068};\\\", \\\"{x:290,y:619,t:1528140004083};\\\", \\\"{x:288,y:610,t:1528140004099};\\\", \\\"{x:291,y:594,t:1528140004117};\\\", \\\"{x:299,y:577,t:1528140004133};\\\", \\\"{x:319,y:565,t:1528140004150};\\\", \\\"{x:339,y:553,t:1528140004168};\\\", \\\"{x:356,y:548,t:1528140004183};\\\", \\\"{x:366,y:544,t:1528140004200};\\\", \\\"{x:372,y:543,t:1528140004217};\\\", \\\"{x:378,y:540,t:1528140004233};\\\", \\\"{x:384,y:540,t:1528140004250};\\\", \\\"{x:390,y:540,t:1528140004267};\\\", \\\"{x:392,y:538,t:1528140004283};\\\", \\\"{x:398,y:538,t:1528140004301};\\\", \\\"{x:403,y:538,t:1528140004317};\\\", \\\"{x:405,y:539,t:1528140004333};\\\", \\\"{x:405,y:541,t:1528140004388};\\\", \\\"{x:402,y:543,t:1528140004401};\\\", \\\"{x:400,y:550,t:1528140004418};\\\", \\\"{x:396,y:559,t:1528140004436};\\\", \\\"{x:395,y:565,t:1528140004451};\\\", \\\"{x:395,y:567,t:1528140004467};\\\", \\\"{x:394,y:569,t:1528140004573};\\\", \\\"{x:393,y:569,t:1528140004596};\\\", \\\"{x:393,y:570,t:1528140004669};\\\", \\\"{x:393,y:571,t:1528140004685};\\\", \\\"{x:392,y:576,t:1528140004701};\\\", \\\"{x:389,y:578,t:1528140004718};\\\", \\\"{x:388,y:579,t:1528140004733};\\\", \\\"{x:390,y:585,t:1528140004987};\\\", \\\"{x:398,y:596,t:1528140005004};\\\", \\\"{x:422,y:628,t:1528140005017};\\\", \\\"{x:456,y:671,t:1528140005035};\\\", \\\"{x:483,y:698,t:1528140005051};\\\", \\\"{x:511,y:723,t:1528140005068};\\\", \\\"{x:522,y:735,t:1528140005084};\\\", \\\"{x:525,y:737,t:1528140005101};\\\", \\\"{x:526,y:738,t:1528140005164};\\\", \\\"{x:527,y:739,t:1528140005228};\\\", \\\"{x:528,y:740,t:1528140005260};\\\", \\\"{x:529,y:740,t:1528140005268};\\\", \\\"{x:531,y:740,t:1528140005285};\\\", \\\"{x:534,y:738,t:1528140005302};\\\", \\\"{x:537,y:733,t:1528140005319};\\\", \\\"{x:538,y:727,t:1528140005335};\\\", \\\"{x:538,y:720,t:1528140005352};\\\", \\\"{x:538,y:714,t:1528140005369};\\\", \\\"{x:538,y:709,t:1528140005385};\\\", \\\"{x:538,y:707,t:1528140005402};\\\", \\\"{x:538,y:705,t:1528140005417};\\\", \\\"{x:538,y:703,t:1528140005434};\\\", \\\"{x:538,y:702,t:1528140006053};\\\", \\\"{x:537,y:702,t:1528140006068};\\\", \\\"{x:534,y:698,t:1528140006085};\\\" ] }, { \\\"rt\\\": 8888, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 40206, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"G27Q3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:531,y:698,t:1528140007557};\\\", \\\"{x:527,y:695,t:1528140007569};\\\", \\\"{x:516,y:689,t:1528140007586};\\\", \\\"{x:514,y:688,t:1528140007602};\\\", \\\"{x:512,y:684,t:1528140007619};\\\", \\\"{x:511,y:681,t:1528140007637};\\\", \\\"{x:508,y:672,t:1528140007652};\\\", \\\"{x:508,y:667,t:1528140007671};\\\", \\\"{x:509,y:659,t:1528140007686};\\\", \\\"{x:514,y:651,t:1528140007704};\\\", \\\"{x:522,y:633,t:1528140007722};\\\", \\\"{x:534,y:617,t:1528140007742};\\\", \\\"{x:535,y:615,t:1528140007754};\\\", \\\"{x:544,y:605,t:1528140007770};\\\", \\\"{x:554,y:593,t:1528140007787};\\\", \\\"{x:566,y:587,t:1528140007804};\\\", \\\"{x:568,y:583,t:1528140007820};\\\", \\\"{x:569,y:581,t:1528140007836};\\\", \\\"{x:569,y:580,t:1528140007867};\\\", \\\"{x:570,y:580,t:1528140007875};\\\", \\\"{x:577,y:579,t:1528140008213};\\\", \\\"{x:588,y:580,t:1528140008221};\\\", \\\"{x:619,y:593,t:1528140008237};\\\", \\\"{x:682,y:607,t:1528140008256};\\\", \\\"{x:797,y:633,t:1528140008270};\\\", \\\"{x:925,y:671,t:1528140008287};\\\", \\\"{x:1079,y:716,t:1528140008304};\\\", \\\"{x:1229,y:760,t:1528140008319};\\\", \\\"{x:1465,y:817,t:1528140008340};\\\", \\\"{x:1536,y:826,t:1528140008354};\\\", \\\"{x:1626,y:847,t:1528140008370};\\\", \\\"{x:1704,y:871,t:1528140008387};\\\", \\\"{x:1736,y:882,t:1528140008404};\\\", \\\"{x:1759,y:896,t:1528140008419};\\\", \\\"{x:1763,y:900,t:1528140008436};\\\", \\\"{x:1763,y:902,t:1528140008508};\\\", \\\"{x:1764,y:902,t:1528140008589};\\\", \\\"{x:1764,y:899,t:1528140008604};\\\", \\\"{x:1764,y:895,t:1528140008621};\\\", \\\"{x:1754,y:877,t:1528140008637};\\\", \\\"{x:1739,y:867,t:1528140008654};\\\", \\\"{x:1712,y:851,t:1528140008670};\\\", \\\"{x:1677,y:830,t:1528140008687};\\\", \\\"{x:1623,y:803,t:1528140008704};\\\", \\\"{x:1548,y:768,t:1528140008721};\\\", \\\"{x:1487,y:742,t:1528140008737};\\\", \\\"{x:1435,y:710,t:1528140008754};\\\", \\\"{x:1395,y:681,t:1528140008770};\\\", \\\"{x:1370,y:662,t:1528140008787};\\\", \\\"{x:1345,y:642,t:1528140008804};\\\", \\\"{x:1337,y:632,t:1528140008821};\\\", \\\"{x:1335,y:624,t:1528140008837};\\\", \\\"{x:1332,y:617,t:1528140008854};\\\", \\\"{x:1331,y:614,t:1528140008870};\\\", \\\"{x:1330,y:612,t:1528140008887};\\\", \\\"{x:1330,y:611,t:1528140008908};\\\", \\\"{x:1329,y:610,t:1528140008921};\\\", \\\"{x:1328,y:610,t:1528140009046};\\\", \\\"{x:1327,y:610,t:1528140009076};\\\", \\\"{x:1326,y:613,t:1528140009087};\\\", \\\"{x:1326,y:618,t:1528140009104};\\\", \\\"{x:1329,y:627,t:1528140009120};\\\", \\\"{x:1333,y:635,t:1528140009136};\\\", \\\"{x:1337,y:647,t:1528140009154};\\\", \\\"{x:1340,y:654,t:1528140009169};\\\", \\\"{x:1351,y:666,t:1528140009187};\\\", \\\"{x:1369,y:686,t:1528140009203};\\\", \\\"{x:1384,y:701,t:1528140009220};\\\", \\\"{x:1410,y:715,t:1528140009236};\\\", \\\"{x:1429,y:725,t:1528140009254};\\\", \\\"{x:1449,y:730,t:1528140009270};\\\", \\\"{x:1474,y:737,t:1528140009287};\\\", \\\"{x:1486,y:743,t:1528140009304};\\\", \\\"{x:1506,y:750,t:1528140009320};\\\", \\\"{x:1525,y:760,t:1528140009337};\\\", \\\"{x:1554,y:775,t:1528140009355};\\\", \\\"{x:1573,y:782,t:1528140009370};\\\", \\\"{x:1577,y:789,t:1528140009387};\\\", \\\"{x:1594,y:802,t:1528140009404};\\\", \\\"{x:1605,y:810,t:1528140009420};\\\", \\\"{x:1614,y:816,t:1528140009437};\\\", \\\"{x:1618,y:822,t:1528140009454};\\\", \\\"{x:1625,y:829,t:1528140009470};\\\", \\\"{x:1628,y:832,t:1528140009486};\\\", \\\"{x:1630,y:833,t:1528140009503};\\\", \\\"{x:1631,y:835,t:1528140009520};\\\", \\\"{x:1631,y:836,t:1528140009537};\\\", \\\"{x:1633,y:839,t:1528140009555};\\\", \\\"{x:1633,y:840,t:1528140009570};\\\", \\\"{x:1633,y:841,t:1528140009605};\\\", \\\"{x:1633,y:843,t:1528140009621};\\\", \\\"{x:1632,y:845,t:1528140009637};\\\", \\\"{x:1627,y:846,t:1528140009654};\\\", \\\"{x:1621,y:847,t:1528140009670};\\\", \\\"{x:1596,y:847,t:1528140009687};\\\", \\\"{x:1563,y:846,t:1528140009705};\\\", \\\"{x:1546,y:842,t:1528140009721};\\\", \\\"{x:1490,y:831,t:1528140009737};\\\", \\\"{x:1400,y:809,t:1528140009754};\\\", \\\"{x:1334,y:787,t:1528140009771};\\\", \\\"{x:1297,y:780,t:1528140009787};\\\", \\\"{x:1264,y:773,t:1528140009805};\\\", \\\"{x:1260,y:772,t:1528140009820};\\\", \\\"{x:1254,y:770,t:1528140009837};\\\", \\\"{x:1253,y:770,t:1528140010013};\\\", \\\"{x:1253,y:772,t:1528140010021};\\\", \\\"{x:1254,y:780,t:1528140010037};\\\", \\\"{x:1259,y:790,t:1528140010054};\\\", \\\"{x:1265,y:802,t:1528140010070};\\\", \\\"{x:1272,y:808,t:1528140010088};\\\", \\\"{x:1273,y:811,t:1528140010104};\\\", \\\"{x:1277,y:812,t:1528140010120};\\\", \\\"{x:1277,y:811,t:1528140010253};\\\", \\\"{x:1279,y:808,t:1528140010271};\\\", \\\"{x:1280,y:800,t:1528140010288};\\\", \\\"{x:1280,y:794,t:1528140010304};\\\", \\\"{x:1280,y:787,t:1528140010320};\\\", \\\"{x:1280,y:783,t:1528140010337};\\\", \\\"{x:1279,y:780,t:1528140010363};\\\", \\\"{x:1275,y:779,t:1528140010370};\\\", \\\"{x:1239,y:773,t:1528140010403};\\\", \\\"{x:1229,y:771,t:1528140010412};\\\", \\\"{x:1209,y:769,t:1528140010428};\\\", \\\"{x:1205,y:768,t:1528140010446};\\\", \\\"{x:1189,y:765,t:1528140010463};\\\", \\\"{x:1182,y:765,t:1528140010478};\\\", \\\"{x:1179,y:765,t:1528140010496};\\\", \\\"{x:1179,y:764,t:1528140010668};\\\", \\\"{x:1180,y:764,t:1528140010684};\\\", \\\"{x:1182,y:764,t:1528140010697};\\\", \\\"{x:1189,y:767,t:1528140010713};\\\", \\\"{x:1191,y:770,t:1528140010730};\\\", \\\"{x:1198,y:780,t:1528140010747};\\\", \\\"{x:1206,y:793,t:1528140010764};\\\", \\\"{x:1212,y:802,t:1528140010780};\\\", \\\"{x:1214,y:809,t:1528140010797};\\\", \\\"{x:1222,y:820,t:1528140010814};\\\", \\\"{x:1226,y:824,t:1528140010831};\\\", \\\"{x:1228,y:828,t:1528140010848};\\\", \\\"{x:1230,y:831,t:1528140010864};\\\", \\\"{x:1230,y:834,t:1528140010884};\\\", \\\"{x:1231,y:835,t:1528140010909};\\\", \\\"{x:1231,y:834,t:1528140011221};\\\", \\\"{x:1231,y:832,t:1528140011233};\\\", \\\"{x:1231,y:831,t:1528140011249};\\\", \\\"{x:1232,y:831,t:1528140011357};\\\", \\\"{x:1233,y:835,t:1528140011367};\\\", \\\"{x:1237,y:840,t:1528140011383};\\\", \\\"{x:1240,y:848,t:1528140011399};\\\", \\\"{x:1246,y:859,t:1528140011416};\\\", \\\"{x:1247,y:863,t:1528140011433};\\\", \\\"{x:1252,y:870,t:1528140011451};\\\", \\\"{x:1255,y:878,t:1528140011466};\\\", \\\"{x:1264,y:885,t:1528140011483};\\\", \\\"{x:1267,y:888,t:1528140011500};\\\", \\\"{x:1268,y:889,t:1528140011517};\\\", \\\"{x:1269,y:890,t:1528140011541};\\\", \\\"{x:1269,y:891,t:1528140011556};\\\", \\\"{x:1269,y:892,t:1528140011573};\\\", \\\"{x:1270,y:893,t:1528140011583};\\\", \\\"{x:1271,y:894,t:1528140011600};\\\", \\\"{x:1272,y:896,t:1528140011618};\\\", \\\"{x:1272,y:897,t:1528140011634};\\\", \\\"{x:1275,y:900,t:1528140011650};\\\", \\\"{x:1279,y:905,t:1528140011667};\\\", \\\"{x:1283,y:910,t:1528140011685};\\\", \\\"{x:1284,y:911,t:1528140011701};\\\", \\\"{x:1285,y:911,t:1528140011717};\\\", \\\"{x:1274,y:903,t:1528140012188};\\\", \\\"{x:1223,y:883,t:1528140012203};\\\", \\\"{x:1090,y:822,t:1528140012219};\\\", \\\"{x:895,y:736,t:1528140012236};\\\", \\\"{x:761,y:682,t:1528140012252};\\\", \\\"{x:679,y:651,t:1528140012270};\\\", \\\"{x:622,y:621,t:1528140012286};\\\", \\\"{x:601,y:604,t:1528140012303};\\\", \\\"{x:595,y:596,t:1528140012324};\\\", \\\"{x:594,y:591,t:1528140012342};\\\", \\\"{x:594,y:587,t:1528140012358};\\\", \\\"{x:594,y:585,t:1528140012374};\\\", \\\"{x:596,y:578,t:1528140012391};\\\", \\\"{x:597,y:571,t:1528140012408};\\\", \\\"{x:599,y:562,t:1528140012425};\\\", \\\"{x:599,y:555,t:1528140012442};\\\", \\\"{x:600,y:547,t:1528140012457};\\\", \\\"{x:601,y:545,t:1528140012473};\\\", \\\"{x:602,y:543,t:1528140012491};\\\", \\\"{x:603,y:542,t:1528140012508};\\\", \\\"{x:604,y:542,t:1528140012524};\\\", \\\"{x:603,y:542,t:1528140012621};\\\", \\\"{x:602,y:542,t:1528140012628};\\\", \\\"{x:597,y:542,t:1528140012642};\\\", \\\"{x:581,y:550,t:1528140012657};\\\", \\\"{x:559,y:557,t:1528140012674};\\\", \\\"{x:531,y:563,t:1528140012691};\\\", \\\"{x:485,y:568,t:1528140012708};\\\", \\\"{x:468,y:567,t:1528140012724};\\\", \\\"{x:463,y:567,t:1528140012741};\\\", \\\"{x:461,y:566,t:1528140012758};\\\", \\\"{x:459,y:565,t:1528140012773};\\\", \\\"{x:457,y:564,t:1528140012792};\\\", \\\"{x:451,y:561,t:1528140012808};\\\", \\\"{x:434,y:552,t:1528140012826};\\\", \\\"{x:417,y:546,t:1528140012842};\\\", \\\"{x:402,y:538,t:1528140012858};\\\", \\\"{x:389,y:532,t:1528140012874};\\\", \\\"{x:382,y:531,t:1528140012891};\\\", \\\"{x:377,y:528,t:1528140012908};\\\", \\\"{x:375,y:528,t:1528140012957};\\\", \\\"{x:374,y:528,t:1528140012964};\\\", \\\"{x:372,y:528,t:1528140013005};\\\", \\\"{x:375,y:531,t:1528140013253};\\\", \\\"{x:379,y:534,t:1528140013260};\\\", \\\"{x:382,y:539,t:1528140013274};\\\", \\\"{x:394,y:549,t:1528140013291};\\\", \\\"{x:404,y:557,t:1528140013309};\\\", \\\"{x:410,y:566,t:1528140013326};\\\", \\\"{x:427,y:578,t:1528140013341};\\\", \\\"{x:434,y:584,t:1528140013358};\\\", \\\"{x:436,y:586,t:1528140013375};\\\", \\\"{x:437,y:587,t:1528140013392};\\\", \\\"{x:433,y:585,t:1528140013500};\\\", \\\"{x:429,y:584,t:1528140013507};\\\", \\\"{x:427,y:581,t:1528140013525};\\\", \\\"{x:423,y:578,t:1528140013541};\\\", \\\"{x:422,y:576,t:1528140013558};\\\", \\\"{x:420,y:575,t:1528140013575};\\\", \\\"{x:418,y:571,t:1528140013592};\\\", \\\"{x:415,y:566,t:1528140013608};\\\", \\\"{x:411,y:562,t:1528140013626};\\\", \\\"{x:404,y:555,t:1528140013642};\\\", \\\"{x:401,y:553,t:1528140013658};\\\", \\\"{x:398,y:551,t:1528140013676};\\\", \\\"{x:392,y:547,t:1528140013692};\\\", \\\"{x:386,y:545,t:1528140013708};\\\", \\\"{x:378,y:541,t:1528140013725};\\\", \\\"{x:369,y:537,t:1528140013743};\\\", \\\"{x:364,y:534,t:1528140013759};\\\", \\\"{x:362,y:532,t:1528140013775};\\\", \\\"{x:361,y:532,t:1528140013792};\\\", \\\"{x:361,y:534,t:1528140014109};\\\", \\\"{x:361,y:535,t:1528140014124};\\\", \\\"{x:361,y:536,t:1528140014269};\\\", \\\"{x:362,y:536,t:1528140014277};\\\", \\\"{x:363,y:536,t:1528140014291};\\\", \\\"{x:366,y:537,t:1528140014309};\\\", \\\"{x:368,y:538,t:1528140014324};\\\", \\\"{x:369,y:538,t:1528140014341};\\\", \\\"{x:371,y:538,t:1528140014358};\\\", \\\"{x:373,y:538,t:1528140014374};\\\", \\\"{x:375,y:538,t:1528140014392};\\\", \\\"{x:378,y:538,t:1528140014408};\\\", \\\"{x:382,y:541,t:1528140014426};\\\", \\\"{x:384,y:541,t:1528140014444};\\\", \\\"{x:387,y:542,t:1528140014476};\\\", \\\"{x:391,y:546,t:1528140015068};\\\", \\\"{x:395,y:550,t:1528140015076};\\\", \\\"{x:403,y:558,t:1528140015093};\\\", \\\"{x:413,y:567,t:1528140015110};\\\", \\\"{x:419,y:573,t:1528140015126};\\\", \\\"{x:421,y:577,t:1528140015142};\\\", \\\"{x:427,y:582,t:1528140015160};\\\", \\\"{x:437,y:594,t:1528140015176};\\\", \\\"{x:440,y:602,t:1528140015194};\\\", \\\"{x:446,y:610,t:1528140015211};\\\", \\\"{x:459,y:622,t:1528140015226};\\\", \\\"{x:471,y:633,t:1528140015243};\\\", \\\"{x:476,y:644,t:1528140015260};\\\", \\\"{x:478,y:646,t:1528140015275};\\\", \\\"{x:484,y:653,t:1528140015294};\\\", \\\"{x:489,y:658,t:1528140015310};\\\", \\\"{x:493,y:666,t:1528140015326};\\\", \\\"{x:501,y:672,t:1528140015343};\\\", \\\"{x:502,y:674,t:1528140015360};\\\", \\\"{x:503,y:676,t:1528140015376};\\\", \\\"{x:505,y:678,t:1528140015393};\\\", \\\"{x:507,y:681,t:1528140015412};\\\", \\\"{x:510,y:684,t:1528140015428};\\\", \\\"{x:513,y:688,t:1528140015443};\\\", \\\"{x:516,y:696,t:1528140015460};\\\", \\\"{x:519,y:701,t:1528140015476};\\\", \\\"{x:519,y:703,t:1528140015493};\\\", \\\"{x:519,y:704,t:1528140015867};\\\", \\\"{x:520,y:704,t:1528140016421};\\\", \\\"{x:519,y:705,t:1528140016452};\\\", \\\"{x:518,y:706,t:1528140016468};\\\", \\\"{x:517,y:706,t:1528140016580};\\\", \\\"{x:517,y:707,t:1528140016594};\\\", \\\"{x:515,y:708,t:1528140016612};\\\", \\\"{x:514,y:708,t:1528140016644};\\\" ] }, { \\\"rt\\\": 5464, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 46941, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"G27Q3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:514,y:707,t:1528140017196};\\\", \\\"{x:514,y:706,t:1528140017211};\\\", \\\"{x:514,y:704,t:1528140017228};\\\", \\\"{x:523,y:704,t:1528140017909};\\\", \\\"{x:560,y:704,t:1528140017916};\\\", \\\"{x:596,y:704,t:1528140017932};\\\", \\\"{x:664,y:706,t:1528140017947};\\\", \\\"{x:755,y:718,t:1528140017963};\\\", \\\"{x:865,y:728,t:1528140017978};\\\", \\\"{x:914,y:735,t:1528140017996};\\\", \\\"{x:1025,y:744,t:1528140018012};\\\", \\\"{x:1092,y:752,t:1528140018029};\\\", \\\"{x:1134,y:758,t:1528140018045};\\\", \\\"{x:1161,y:761,t:1528140018063};\\\", \\\"{x:1173,y:761,t:1528140018078};\\\", \\\"{x:1181,y:762,t:1528140018096};\\\", \\\"{x:1186,y:763,t:1528140018112};\\\", \\\"{x:1188,y:764,t:1528140018128};\\\", \\\"{x:1189,y:765,t:1528140018146};\\\", \\\"{x:1191,y:766,t:1528140018163};\\\", \\\"{x:1192,y:767,t:1528140018179};\\\", \\\"{x:1194,y:769,t:1528140018195};\\\", \\\"{x:1195,y:769,t:1528140018212};\\\", \\\"{x:1195,y:770,t:1528140018829};\\\", \\\"{x:1203,y:770,t:1528140018847};\\\", \\\"{x:1214,y:773,t:1528140018870};\\\", \\\"{x:1234,y:780,t:1528140018897};\\\", \\\"{x:1235,y:781,t:1528140018912};\\\", \\\"{x:1238,y:783,t:1528140018929};\\\", \\\"{x:1240,y:784,t:1528140018946};\\\", \\\"{x:1243,y:785,t:1528140018963};\\\", \\\"{x:1252,y:789,t:1528140018979};\\\", \\\"{x:1270,y:795,t:1528140018995};\\\", \\\"{x:1289,y:802,t:1528140019014};\\\", \\\"{x:1301,y:810,t:1528140019029};\\\", \\\"{x:1318,y:816,t:1528140019046};\\\", \\\"{x:1330,y:822,t:1528140019063};\\\", \\\"{x:1343,y:828,t:1528140019079};\\\", \\\"{x:1366,y:837,t:1528140019097};\\\", \\\"{x:1381,y:845,t:1528140019113};\\\", \\\"{x:1386,y:846,t:1528140019130};\\\", \\\"{x:1397,y:851,t:1528140019146};\\\", \\\"{x:1415,y:856,t:1528140019163};\\\", \\\"{x:1424,y:861,t:1528140019180};\\\", \\\"{x:1452,y:868,t:1528140019196};\\\", \\\"{x:1471,y:873,t:1528140019214};\\\", \\\"{x:1490,y:878,t:1528140019230};\\\", \\\"{x:1502,y:883,t:1528140019246};\\\", \\\"{x:1509,y:887,t:1528140019263};\\\", \\\"{x:1510,y:887,t:1528140019280};\\\", \\\"{x:1517,y:891,t:1528140019297};\\\", \\\"{x:1521,y:894,t:1528140019325};\\\", \\\"{x:1523,y:895,t:1528140019333};\\\", \\\"{x:1524,y:895,t:1528140019347};\\\", \\\"{x:1527,y:895,t:1528140019364};\\\", \\\"{x:1528,y:896,t:1528140019381};\\\", \\\"{x:1530,y:896,t:1528140019397};\\\", \\\"{x:1531,y:896,t:1528140019453};\\\", \\\"{x:1533,y:896,t:1528140019468};\\\", \\\"{x:1534,y:898,t:1528140019481};\\\", \\\"{x:1535,y:899,t:1528140019497};\\\", \\\"{x:1543,y:906,t:1528140019513};\\\", \\\"{x:1545,y:907,t:1528140019531};\\\", \\\"{x:1550,y:910,t:1528140019547};\\\", \\\"{x:1566,y:912,t:1528140019564};\\\", \\\"{x:1579,y:914,t:1528140019580};\\\", \\\"{x:1585,y:915,t:1528140019597};\\\", \\\"{x:1595,y:915,t:1528140019614};\\\", \\\"{x:1597,y:915,t:1528140019631};\\\", \\\"{x:1604,y:915,t:1528140019647};\\\", \\\"{x:1614,y:915,t:1528140019664};\\\", \\\"{x:1619,y:914,t:1528140019681};\\\", \\\"{x:1623,y:914,t:1528140019697};\\\", \\\"{x:1625,y:914,t:1528140019714};\\\", \\\"{x:1626,y:913,t:1528140019730};\\\", \\\"{x:1627,y:913,t:1528140019868};\\\", \\\"{x:1627,y:915,t:1528140019887};\\\", \\\"{x:1626,y:915,t:1528140019908};\\\", \\\"{x:1625,y:915,t:1528140020420};\\\", \\\"{x:1623,y:915,t:1528140020467};\\\", \\\"{x:1615,y:911,t:1528140020480};\\\", \\\"{x:1536,y:887,t:1528140020498};\\\", \\\"{x:1381,y:834,t:1528140020515};\\\", \\\"{x:1198,y:781,t:1528140020530};\\\", \\\"{x:991,y:723,t:1528140020547};\\\", \\\"{x:693,y:631,t:1528140020565};\\\", \\\"{x:478,y:572,t:1528140020581};\\\", \\\"{x:312,y:527,t:1528140020597};\\\", \\\"{x:259,y:511,t:1528140020612};\\\", \\\"{x:199,y:500,t:1528140020629};\\\", \\\"{x:196,y:499,t:1528140020647};\\\", \\\"{x:196,y:498,t:1528140020820};\\\", \\\"{x:199,y:497,t:1528140020832};\\\", \\\"{x:208,y:499,t:1528140020848};\\\", \\\"{x:226,y:508,t:1528140020864};\\\", \\\"{x:232,y:513,t:1528140020882};\\\", \\\"{x:239,y:517,t:1528140020898};\\\", \\\"{x:264,y:532,t:1528140020918};\\\", \\\"{x:289,y:547,t:1528140020932};\\\", \\\"{x:310,y:555,t:1528140020947};\\\", \\\"{x:340,y:567,t:1528140020965};\\\", \\\"{x:349,y:574,t:1528140020981};\\\", \\\"{x:363,y:577,t:1528140020997};\\\", \\\"{x:387,y:581,t:1528140021015};\\\", \\\"{x:408,y:585,t:1528140021031};\\\", \\\"{x:430,y:587,t:1528140021048};\\\", \\\"{x:450,y:591,t:1528140021064};\\\", \\\"{x:463,y:591,t:1528140021081};\\\", \\\"{x:469,y:591,t:1528140021097};\\\", \\\"{x:473,y:592,t:1528140021114};\\\", \\\"{x:476,y:593,t:1528140021131};\\\", \\\"{x:476,y:594,t:1528140021147};\\\", \\\"{x:478,y:594,t:1528140021188};\\\", \\\"{x:480,y:594,t:1528140021204};\\\", \\\"{x:483,y:594,t:1528140021215};\\\", \\\"{x:487,y:593,t:1528140021232};\\\", \\\"{x:498,y:593,t:1528140021248};\\\", \\\"{x:509,y:593,t:1528140021266};\\\", \\\"{x:512,y:593,t:1528140021281};\\\", \\\"{x:516,y:592,t:1528140021298};\\\", \\\"{x:520,y:590,t:1528140021314};\\\", \\\"{x:530,y:585,t:1528140021331};\\\", \\\"{x:547,y:576,t:1528140021347};\\\", \\\"{x:560,y:571,t:1528140021365};\\\", \\\"{x:573,y:567,t:1528140021382};\\\", \\\"{x:576,y:564,t:1528140021399};\\\", \\\"{x:580,y:563,t:1528140021415};\\\", \\\"{x:587,y:559,t:1528140021432};\\\", \\\"{x:595,y:557,t:1528140021449};\\\", \\\"{x:596,y:557,t:1528140021557};\\\", \\\"{x:597,y:555,t:1528140021564};\\\", \\\"{x:599,y:553,t:1528140021725};\\\", \\\"{x:600,y:552,t:1528140021732};\\\", \\\"{x:601,y:552,t:1528140021939};\\\", \\\"{x:601,y:555,t:1528140021948};\\\", \\\"{x:601,y:569,t:1528140021966};\\\", \\\"{x:601,y:585,t:1528140021981};\\\", \\\"{x:601,y:599,t:1528140021999};\\\", \\\"{x:599,y:614,t:1528140022016};\\\", \\\"{x:596,y:629,t:1528140022032};\\\", \\\"{x:594,y:637,t:1528140022048};\\\", \\\"{x:591,y:648,t:1528140022065};\\\", \\\"{x:589,y:656,t:1528140022082};\\\", \\\"{x:587,y:658,t:1528140022098};\\\", \\\"{x:586,y:664,t:1528140022115};\\\", \\\"{x:581,y:671,t:1528140022132};\\\", \\\"{x:578,y:675,t:1528140022150};\\\", \\\"{x:572,y:681,t:1528140022165};\\\", \\\"{x:568,y:686,t:1528140022183};\\\", \\\"{x:559,y:690,t:1528140022200};\\\", \\\"{x:547,y:695,t:1528140022215};\\\", \\\"{x:536,y:698,t:1528140022232};\\\", \\\"{x:531,y:699,t:1528140022248};\\\", \\\"{x:527,y:700,t:1528140022266};\\\", \\\"{x:526,y:701,t:1528140022292};\\\", \\\"{x:525,y:701,t:1528140022333};\\\", \\\"{x:524,y:701,t:1528140022659};\\\" ] }, { \\\"rt\\\": 6168, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 54379, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"G27Q3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:522,y:701,t:1528140024741};\\\", \\\"{x:520,y:701,t:1528140024753};\\\", \\\"{x:517,y:701,t:1528140024767};\\\", \\\"{x:513,y:701,t:1528140024784};\\\", \\\"{x:509,y:699,t:1528140024800};\\\", \\\"{x:504,y:698,t:1528140024818};\\\", \\\"{x:499,y:698,t:1528140024834};\\\", \\\"{x:497,y:697,t:1528140024851};\\\", \\\"{x:495,y:696,t:1528140024867};\\\", \\\"{x:494,y:695,t:1528140024884};\\\", \\\"{x:493,y:695,t:1528140024907};\\\", \\\"{x:492,y:695,t:1528140024917};\\\", \\\"{x:491,y:695,t:1528140024934};\\\", \\\"{x:488,y:694,t:1528140024950};\\\", \\\"{x:487,y:694,t:1528140024968};\\\", \\\"{x:486,y:694,t:1528140024984};\\\", \\\"{x:485,y:694,t:1528140025001};\\\", \\\"{x:483,y:694,t:1528140025018};\\\", \\\"{x:482,y:694,t:1528140025035};\\\", \\\"{x:479,y:693,t:1528140025051};\\\", \\\"{x:477,y:692,t:1528140025068};\\\", \\\"{x:476,y:692,t:1528140025084};\\\", \\\"{x:475,y:692,t:1528140025102};\\\", \\\"{x:474,y:691,t:1528140025124};\\\", \\\"{x:473,y:691,t:1528140025157};\\\", \\\"{x:473,y:689,t:1528140025221};\\\", \\\"{x:473,y:688,t:1528140025236};\\\", \\\"{x:474,y:687,t:1528140025269};\\\", \\\"{x:476,y:685,t:1528140025285};\\\", \\\"{x:477,y:685,t:1528140025301};\\\", \\\"{x:483,y:682,t:1528140025317};\\\", \\\"{x:495,y:677,t:1528140025335};\\\", \\\"{x:502,y:677,t:1528140025352};\\\", \\\"{x:514,y:678,t:1528140025368};\\\", \\\"{x:560,y:684,t:1528140025385};\\\", \\\"{x:621,y:692,t:1528140025403};\\\", \\\"{x:729,y:706,t:1528140025418};\\\", \\\"{x:829,y:722,t:1528140025435};\\\", \\\"{x:923,y:733,t:1528140025452};\\\", \\\"{x:1127,y:761,t:1528140025469};\\\", \\\"{x:1263,y:784,t:1528140025485};\\\", \\\"{x:1394,y:805,t:1528140025502};\\\", \\\"{x:1517,y:818,t:1528140025519};\\\", \\\"{x:1640,y:836,t:1528140025535};\\\", \\\"{x:1709,y:847,t:1528140025553};\\\", \\\"{x:1753,y:853,t:1528140025569};\\\", \\\"{x:1775,y:856,t:1528140025585};\\\", \\\"{x:1784,y:858,t:1528140025601};\\\", \\\"{x:1795,y:858,t:1528140025619};\\\", \\\"{x:1794,y:858,t:1528140025692};\\\", \\\"{x:1793,y:859,t:1528140026021};\\\", \\\"{x:1785,y:859,t:1528140026036};\\\", \\\"{x:1762,y:859,t:1528140026052};\\\", \\\"{x:1724,y:856,t:1528140026069};\\\", \\\"{x:1694,y:847,t:1528140026086};\\\", \\\"{x:1664,y:842,t:1528140026102};\\\", \\\"{x:1630,y:837,t:1528140026119};\\\", \\\"{x:1621,y:835,t:1528140026136};\\\", \\\"{x:1603,y:831,t:1528140026152};\\\", \\\"{x:1591,y:826,t:1528140026169};\\\", \\\"{x:1577,y:824,t:1528140026186};\\\", \\\"{x:1561,y:821,t:1528140026202};\\\", \\\"{x:1553,y:820,t:1528140026219};\\\", \\\"{x:1544,y:819,t:1528140026236};\\\", \\\"{x:1541,y:819,t:1528140026252};\\\", \\\"{x:1526,y:819,t:1528140026270};\\\", \\\"{x:1508,y:817,t:1528140026287};\\\", \\\"{x:1496,y:815,t:1528140026302};\\\", \\\"{x:1488,y:813,t:1528140026319};\\\", \\\"{x:1483,y:811,t:1528140026336};\\\", \\\"{x:1482,y:810,t:1528140026413};\\\", \\\"{x:1481,y:809,t:1528140026444};\\\", \\\"{x:1480,y:808,t:1528140026461};\\\", \\\"{x:1478,y:806,t:1528140026469};\\\", \\\"{x:1472,y:800,t:1528140026486};\\\", \\\"{x:1463,y:789,t:1528140026503};\\\", \\\"{x:1455,y:775,t:1528140026519};\\\", \\\"{x:1450,y:763,t:1528140026536};\\\", \\\"{x:1441,y:748,t:1528140026553};\\\", \\\"{x:1435,y:730,t:1528140026569};\\\", \\\"{x:1428,y:707,t:1528140026586};\\\", \\\"{x:1426,y:693,t:1528140026602};\\\", \\\"{x:1420,y:685,t:1528140026619};\\\", \\\"{x:1416,y:669,t:1528140026636};\\\", \\\"{x:1414,y:657,t:1528140026652};\\\", \\\"{x:1413,y:649,t:1528140026669};\\\", \\\"{x:1412,y:640,t:1528140026686};\\\", \\\"{x:1406,y:624,t:1528140026703};\\\", \\\"{x:1403,y:602,t:1528140026719};\\\", \\\"{x:1395,y:585,t:1528140026735};\\\", \\\"{x:1388,y:570,t:1528140026753};\\\", \\\"{x:1379,y:555,t:1528140026769};\\\", \\\"{x:1371,y:539,t:1528140026786};\\\", \\\"{x:1361,y:526,t:1528140026803};\\\", \\\"{x:1352,y:516,t:1528140026820};\\\", \\\"{x:1335,y:495,t:1528140026836};\\\", \\\"{x:1328,y:484,t:1528140026852};\\\", \\\"{x:1321,y:477,t:1528140026870};\\\", \\\"{x:1317,y:473,t:1528140026885};\\\", \\\"{x:1315,y:472,t:1528140026902};\\\", \\\"{x:1312,y:470,t:1528140026919};\\\", \\\"{x:1311,y:469,t:1528140026996};\\\", \\\"{x:1310,y:468,t:1528140027020};\\\", \\\"{x:1310,y:467,t:1528140027036};\\\", \\\"{x:1310,y:463,t:1528140027053};\\\", \\\"{x:1310,y:460,t:1528140027070};\\\", \\\"{x:1315,y:455,t:1528140027086};\\\", \\\"{x:1319,y:453,t:1528140027103};\\\", \\\"{x:1322,y:451,t:1528140027120};\\\", \\\"{x:1323,y:449,t:1528140027136};\\\", \\\"{x:1324,y:449,t:1528140027153};\\\", \\\"{x:1324,y:448,t:1528140027269};\\\", \\\"{x:1323,y:447,t:1528140027287};\\\", \\\"{x:1322,y:447,t:1528140027303};\\\", \\\"{x:1320,y:446,t:1528140027320};\\\", \\\"{x:1315,y:444,t:1528140027342};\\\", \\\"{x:1315,y:443,t:1528140027353};\\\", \\\"{x:1313,y:441,t:1528140027369};\\\", \\\"{x:1311,y:439,t:1528140027386};\\\", \\\"{x:1309,y:438,t:1528140027403};\\\", \\\"{x:1307,y:437,t:1528140027420};\\\", \\\"{x:1306,y:436,t:1528140027436};\\\", \\\"{x:1305,y:439,t:1528140027572};\\\", \\\"{x:1305,y:443,t:1528140027587};\\\", \\\"{x:1303,y:457,t:1528140027605};\\\", \\\"{x:1303,y:465,t:1528140027621};\\\", \\\"{x:1303,y:472,t:1528140027637};\\\", \\\"{x:1303,y:483,t:1528140027654};\\\", \\\"{x:1303,y:490,t:1528140027670};\\\", \\\"{x:1304,y:494,t:1528140027687};\\\", \\\"{x:1306,y:497,t:1528140027704};\\\", \\\"{x:1307,y:501,t:1528140027721};\\\", \\\"{x:1307,y:503,t:1528140027737};\\\", \\\"{x:1307,y:505,t:1528140027754};\\\", \\\"{x:1307,y:508,t:1528140027770};\\\", \\\"{x:1307,y:512,t:1528140027787};\\\", \\\"{x:1307,y:518,t:1528140027805};\\\", \\\"{x:1307,y:521,t:1528140027820};\\\", \\\"{x:1307,y:523,t:1528140027837};\\\", \\\"{x:1307,y:525,t:1528140027854};\\\", \\\"{x:1307,y:526,t:1528140027915};\\\", \\\"{x:1308,y:527,t:1528140027924};\\\", \\\"{x:1308,y:528,t:1528140027937};\\\", \\\"{x:1308,y:530,t:1528140027954};\\\", \\\"{x:1300,y:540,t:1528140027969};\\\", \\\"{x:1287,y:558,t:1528140027986};\\\", \\\"{x:1238,y:610,t:1528140028004};\\\", \\\"{x:1185,y:659,t:1528140028019};\\\", \\\"{x:1110,y:711,t:1528140028037};\\\", \\\"{x:1060,y:744,t:1528140028054};\\\", \\\"{x:1028,y:759,t:1528140028071};\\\", \\\"{x:1009,y:766,t:1528140028087};\\\", \\\"{x:994,y:768,t:1528140028104};\\\", \\\"{x:982,y:769,t:1528140028121};\\\", \\\"{x:962,y:767,t:1528140028137};\\\", \\\"{x:939,y:761,t:1528140028154};\\\", \\\"{x:897,y:741,t:1528140028171};\\\", \\\"{x:844,y:725,t:1528140028187};\\\", \\\"{x:765,y:692,t:1528140028205};\\\", \\\"{x:736,y:680,t:1528140028220};\\\", \\\"{x:715,y:669,t:1528140028237};\\\", \\\"{x:696,y:657,t:1528140028254};\\\", \\\"{x:680,y:644,t:1528140028272};\\\", \\\"{x:674,y:635,t:1528140028287};\\\", \\\"{x:668,y:628,t:1528140028303};\\\", \\\"{x:667,y:623,t:1528140028321};\\\", \\\"{x:663,y:617,t:1528140028336};\\\", \\\"{x:658,y:611,t:1528140028355};\\\", \\\"{x:654,y:606,t:1528140028371};\\\", \\\"{x:644,y:601,t:1528140028387};\\\", \\\"{x:643,y:601,t:1528140028476};\\\", \\\"{x:642,y:601,t:1528140028540};\\\", \\\"{x:642,y:599,t:1528140028556};\\\", \\\"{x:642,y:597,t:1528140028571};\\\", \\\"{x:644,y:594,t:1528140028588};\\\", \\\"{x:660,y:584,t:1528140028604};\\\", \\\"{x:680,y:578,t:1528140028621};\\\", \\\"{x:701,y:571,t:1528140028638};\\\", \\\"{x:720,y:566,t:1528140028653};\\\", \\\"{x:737,y:561,t:1528140028671};\\\", \\\"{x:755,y:561,t:1528140028687};\\\", \\\"{x:783,y:561,t:1528140028703};\\\", \\\"{x:795,y:561,t:1528140028720};\\\", \\\"{x:805,y:561,t:1528140028737};\\\", \\\"{x:813,y:560,t:1528140028755};\\\", \\\"{x:815,y:560,t:1528140028770};\\\", \\\"{x:823,y:560,t:1528140028787};\\\", \\\"{x:825,y:560,t:1528140028804};\\\", \\\"{x:826,y:560,t:1528140028821};\\\", \\\"{x:826,y:559,t:1528140028837};\\\", \\\"{x:827,y:559,t:1528140028856};\\\", \\\"{x:830,y:555,t:1528140028871};\\\", \\\"{x:832,y:550,t:1528140028888};\\\", \\\"{x:833,y:543,t:1528140028905};\\\", \\\"{x:833,y:537,t:1528140028921};\\\", \\\"{x:833,y:533,t:1528140028938};\\\", \\\"{x:833,y:530,t:1528140028954};\\\", \\\"{x:833,y:529,t:1528140028971};\\\", \\\"{x:834,y:523,t:1528140028988};\\\", \\\"{x:835,y:520,t:1528140029004};\\\", \\\"{x:835,y:517,t:1528140029021};\\\", \\\"{x:835,y:515,t:1528140029037};\\\", \\\"{x:835,y:513,t:1528140029054};\\\", \\\"{x:834,y:512,t:1528140029259};\\\", \\\"{x:826,y:512,t:1528140029270};\\\", \\\"{x:813,y:521,t:1528140029288};\\\", \\\"{x:791,y:535,t:1528140029305};\\\", \\\"{x:765,y:555,t:1528140029322};\\\", \\\"{x:743,y:570,t:1528140029338};\\\", \\\"{x:714,y:598,t:1528140029355};\\\", \\\"{x:676,y:620,t:1528140029371};\\\", \\\"{x:618,y:653,t:1528140029388};\\\", \\\"{x:595,y:664,t:1528140029404};\\\", \\\"{x:576,y:676,t:1528140029422};\\\", \\\"{x:559,y:685,t:1528140029437};\\\", \\\"{x:540,y:691,t:1528140029455};\\\", \\\"{x:529,y:696,t:1528140029471};\\\", \\\"{x:519,y:699,t:1528140029488};\\\", \\\"{x:509,y:705,t:1528140029505};\\\", \\\"{x:500,y:708,t:1528140029521};\\\", \\\"{x:495,y:711,t:1528140029538};\\\", \\\"{x:493,y:711,t:1528140029555};\\\", \\\"{x:489,y:713,t:1528140029570};\\\", \\\"{x:485,y:715,t:1528140029588};\\\", \\\"{x:484,y:715,t:1528140029781};\\\", \\\"{x:484,y:713,t:1528140029796};\\\", \\\"{x:486,y:711,t:1528140029804};\\\", \\\"{x:489,y:709,t:1528140029821};\\\", \\\"{x:491,y:709,t:1528140030317};\\\", \\\"{x:494,y:709,t:1528140030324};\\\", \\\"{x:501,y:709,t:1528140030339};\\\", \\\"{x:515,y:716,t:1528140030356};\\\", \\\"{x:519,y:717,t:1528140030372};\\\", \\\"{x:521,y:717,t:1528140030396};\\\", \\\"{x:525,y:720,t:1528140030406};\\\", \\\"{x:534,y:725,t:1528140030422};\\\", \\\"{x:548,y:735,t:1528140030438};\\\", \\\"{x:558,y:744,t:1528140030455};\\\", \\\"{x:574,y:756,t:1528140030472};\\\", \\\"{x:599,y:769,t:1528140030488};\\\", \\\"{x:599,y:770,t:1528140030506};\\\", \\\"{x:599,y:771,t:1528140030522};\\\" ] }, { \\\"rt\\\": 9055, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 64685, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"G27Q3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-1\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:599,y:773,t:1528140034013};\\\", \\\"{x:599,y:775,t:1528140034116};\\\", \\\"{x:598,y:775,t:1528140034132};\\\", \\\"{x:597,y:776,t:1528140034172};\\\", \\\"{x:596,y:776,t:1528140034228};\\\", \\\"{x:595,y:775,t:1528140034893};\\\", \\\"{x:595,y:777,t:1528140034916};\\\", \\\"{x:595,y:778,t:1528140034926};\\\", \\\"{x:613,y:779,t:1528140034942};\\\", \\\"{x:628,y:782,t:1528140034959};\\\", \\\"{x:639,y:784,t:1528140034977};\\\", \\\"{x:650,y:787,t:1528140034993};\\\", \\\"{x:691,y:795,t:1528140035009};\\\", \\\"{x:730,y:800,t:1528140035026};\\\", \\\"{x:780,y:809,t:1528140035043};\\\", \\\"{x:804,y:818,t:1528140035059};\\\", \\\"{x:902,y:836,t:1528140035075};\\\", \\\"{x:950,y:844,t:1528140035093};\\\", \\\"{x:991,y:847,t:1528140035109};\\\", \\\"{x:1004,y:852,t:1528140035125};\\\", \\\"{x:1014,y:852,t:1528140035143};\\\", \\\"{x:1019,y:852,t:1528140035159};\\\", \\\"{x:1021,y:852,t:1528140035176};\\\", \\\"{x:1020,y:852,t:1528140035357};\\\", \\\"{x:1017,y:852,t:1528140035368};\\\", \\\"{x:1013,y:852,t:1528140035385};\\\", \\\"{x:1009,y:852,t:1528140035402};\\\", \\\"{x:1005,y:852,t:1528140035418};\\\", \\\"{x:1003,y:852,t:1528140035435};\\\", \\\"{x:999,y:852,t:1528140035452};\\\", \\\"{x:998,y:852,t:1528140035534};\\\", \\\"{x:1001,y:852,t:1528140035693};\\\", \\\"{x:1006,y:850,t:1528140035702};\\\", \\\"{x:1021,y:848,t:1528140035718};\\\", \\\"{x:1038,y:842,t:1528140035735};\\\", \\\"{x:1062,y:837,t:1528140035753};\\\", \\\"{x:1083,y:828,t:1528140035770};\\\", \\\"{x:1118,y:814,t:1528140035785};\\\", \\\"{x:1173,y:791,t:1528140035802};\\\", \\\"{x:1218,y:763,t:1528140035819};\\\", \\\"{x:1268,y:730,t:1528140035835};\\\", \\\"{x:1312,y:697,t:1528140035852};\\\", \\\"{x:1349,y:661,t:1528140035869};\\\", \\\"{x:1372,y:629,t:1528140035885};\\\", \\\"{x:1384,y:605,t:1528140035902};\\\", \\\"{x:1389,y:585,t:1528140035919};\\\", \\\"{x:1392,y:563,t:1528140035936};\\\", \\\"{x:1396,y:547,t:1528140035952};\\\", \\\"{x:1396,y:538,t:1528140035969};\\\", \\\"{x:1396,y:528,t:1528140035986};\\\", \\\"{x:1394,y:518,t:1528140036002};\\\", \\\"{x:1390,y:511,t:1528140036019};\\\", \\\"{x:1381,y:498,t:1528140036036};\\\", \\\"{x:1372,y:491,t:1528140036052};\\\", \\\"{x:1361,y:486,t:1528140036070};\\\", \\\"{x:1357,y:485,t:1528140036086};\\\", \\\"{x:1356,y:485,t:1528140036102};\\\", \\\"{x:1354,y:485,t:1528140036119};\\\", \\\"{x:1352,y:484,t:1528140036136};\\\", \\\"{x:1351,y:483,t:1528140036152};\\\", \\\"{x:1348,y:484,t:1528140036189};\\\", \\\"{x:1346,y:484,t:1528140036205};\\\", \\\"{x:1346,y:486,t:1528140036229};\\\", \\\"{x:1345,y:487,t:1528140036236};\\\", \\\"{x:1344,y:489,t:1528140036252};\\\", \\\"{x:1342,y:493,t:1528140036269};\\\", \\\"{x:1340,y:497,t:1528140036286};\\\", \\\"{x:1337,y:502,t:1528140036302};\\\", \\\"{x:1333,y:507,t:1528140036319};\\\", \\\"{x:1333,y:509,t:1528140036336};\\\", \\\"{x:1331,y:511,t:1528140036353};\\\", \\\"{x:1330,y:512,t:1528140036368};\\\", \\\"{x:1329,y:514,t:1528140036386};\\\", \\\"{x:1328,y:515,t:1528140036403};\\\", \\\"{x:1327,y:516,t:1528140036421};\\\", \\\"{x:1327,y:517,t:1528140036470};\\\", \\\"{x:1326,y:518,t:1528140036525};\\\", \\\"{x:1325,y:518,t:1528140037070};\\\", \\\"{x:1324,y:518,t:1528140037086};\\\", \\\"{x:1318,y:518,t:1528140037253};\\\", \\\"{x:1295,y:518,t:1528140037270};\\\", \\\"{x:1227,y:507,t:1528140037287};\\\", \\\"{x:1127,y:491,t:1528140037303};\\\", \\\"{x:1002,y:470,t:1528140037320};\\\", \\\"{x:877,y:452,t:1528140037339};\\\", \\\"{x:760,y:433,t:1528140037354};\\\", \\\"{x:554,y:413,t:1528140037386};\\\", \\\"{x:517,y:413,t:1528140037403};\\\", \\\"{x:490,y:412,t:1528140037419};\\\", \\\"{x:465,y:413,t:1528140037436};\\\", \\\"{x:445,y:415,t:1528140037452};\\\", \\\"{x:425,y:422,t:1528140037469};\\\", \\\"{x:405,y:427,t:1528140037486};\\\", \\\"{x:392,y:431,t:1528140037502};\\\", \\\"{x:386,y:436,t:1528140037520};\\\", \\\"{x:378,y:438,t:1528140037537};\\\", \\\"{x:377,y:438,t:1528140037552};\\\", \\\"{x:375,y:438,t:1528140037581};\\\", \\\"{x:374,y:438,t:1528140037596};\\\", \\\"{x:373,y:440,t:1528140037620};\\\", \\\"{x:371,y:443,t:1528140037637};\\\", \\\"{x:371,y:451,t:1528140037653};\\\", \\\"{x:375,y:467,t:1528140037671};\\\", \\\"{x:387,y:476,t:1528140037687};\\\", \\\"{x:398,y:486,t:1528140037704};\\\", \\\"{x:419,y:493,t:1528140037719};\\\", \\\"{x:432,y:498,t:1528140037736};\\\", \\\"{x:442,y:503,t:1528140037754};\\\", \\\"{x:450,y:505,t:1528140037769};\\\", \\\"{x:461,y:507,t:1528140037787};\\\", \\\"{x:477,y:511,t:1528140037804};\\\", \\\"{x:491,y:511,t:1528140037820};\\\", \\\"{x:521,y:510,t:1528140037838};\\\", \\\"{x:536,y:505,t:1528140037854};\\\", \\\"{x:566,y:504,t:1528140037869};\\\", \\\"{x:589,y:504,t:1528140037886};\\\", \\\"{x:598,y:504,t:1528140037903};\\\", \\\"{x:599,y:503,t:1528140037920};\\\", \\\"{x:599,y:501,t:1528140037966};\\\", \\\"{x:599,y:499,t:1528140037971};\\\", \\\"{x:599,y:498,t:1528140037987};\\\", \\\"{x:597,y:493,t:1528140038003};\\\", \\\"{x:597,y:492,t:1528140038020};\\\", \\\"{x:595,y:488,t:1528140038036};\\\", \\\"{x:594,y:486,t:1528140038053};\\\", \\\"{x:593,y:483,t:1528140038070};\\\", \\\"{x:593,y:481,t:1528140038087};\\\", \\\"{x:593,y:478,t:1528140038103};\\\", \\\"{x:597,y:474,t:1528140038121};\\\", \\\"{x:599,y:472,t:1528140038137};\\\", \\\"{x:600,y:471,t:1528140038157};\\\", \\\"{x:601,y:469,t:1528140038170};\\\", \\\"{x:602,y:467,t:1528140038203};\\\", \\\"{x:603,y:467,t:1528140038220};\\\", \\\"{x:605,y:465,t:1528140038236};\\\", \\\"{x:605,y:464,t:1528140038254};\\\", \\\"{x:606,y:462,t:1528140038284};\\\", \\\"{x:606,y:461,t:1528140038300};\\\", \\\"{x:606,y:459,t:1528140038316};\\\", \\\"{x:606,y:458,t:1528140038323};\\\", \\\"{x:606,y:456,t:1528140038337};\\\", \\\"{x:606,y:455,t:1528140038353};\\\", \\\"{x:606,y:452,t:1528140038370};\\\", \\\"{x:608,y:447,t:1528140038387};\\\", \\\"{x:609,y:446,t:1528140038403};\\\", \\\"{x:610,y:443,t:1528140038420};\\\", \\\"{x:615,y:442,t:1528140038660};\\\", \\\"{x:629,y:442,t:1528140038670};\\\", \\\"{x:660,y:450,t:1528140038687};\\\", \\\"{x:684,y:455,t:1528140038703};\\\", \\\"{x:733,y:466,t:1528140038721};\\\", \\\"{x:775,y:473,t:1528140038738};\\\", \\\"{x:791,y:477,t:1528140038754};\\\", \\\"{x:811,y:478,t:1528140038770};\\\", \\\"{x:824,y:480,t:1528140038787};\\\", \\\"{x:830,y:480,t:1528140038804};\\\", \\\"{x:831,y:480,t:1528140038820};\\\", \\\"{x:830,y:481,t:1528140038949};\\\", \\\"{x:829,y:482,t:1528140038964};\\\", \\\"{x:829,y:483,t:1528140039053};\\\", \\\"{x:829,y:485,t:1528140039093};\\\", \\\"{x:828,y:485,t:1528140039277};\\\", \\\"{x:826,y:486,t:1528140039288};\\\", \\\"{x:820,y:491,t:1528140039305};\\\", \\\"{x:805,y:503,t:1528140039322};\\\", \\\"{x:787,y:517,t:1528140039338};\\\", \\\"{x:765,y:528,t:1528140039354};\\\", \\\"{x:732,y:544,t:1528140039372};\\\", \\\"{x:723,y:551,t:1528140039388};\\\", \\\"{x:703,y:566,t:1528140039405};\\\", \\\"{x:691,y:573,t:1528140039422};\\\", \\\"{x:676,y:580,t:1528140039438};\\\", \\\"{x:662,y:590,t:1528140039454};\\\", \\\"{x:654,y:597,t:1528140039471};\\\", \\\"{x:652,y:605,t:1528140039488};\\\", \\\"{x:641,y:615,t:1528140039504};\\\", \\\"{x:633,y:621,t:1528140039522};\\\", \\\"{x:626,y:626,t:1528140039539};\\\", \\\"{x:620,y:629,t:1528140039554};\\\", \\\"{x:612,y:633,t:1528140039572};\\\", \\\"{x:599,y:640,t:1528140039589};\\\", \\\"{x:591,y:644,t:1528140039605};\\\", \\\"{x:584,y:650,t:1528140039622};\\\", \\\"{x:582,y:651,t:1528140039639};\\\", \\\"{x:581,y:653,t:1528140039757};\\\", \\\"{x:580,y:654,t:1528140039772};\\\", \\\"{x:577,y:658,t:1528140039789};\\\", \\\"{x:574,y:660,t:1528140039806};\\\", \\\"{x:574,y:661,t:1528140039822};\\\", \\\"{x:572,y:662,t:1528140039860};\\\", \\\"{x:570,y:664,t:1528140039872};\\\", \\\"{x:565,y:664,t:1528140039889};\\\", \\\"{x:551,y:669,t:1528140039908};\\\", \\\"{x:539,y:670,t:1528140039923};\\\", \\\"{x:539,y:671,t:1528140040036};\\\", \\\"{x:538,y:672,t:1528140040052};\\\" ] }, { \\\"rt\\\": 18544, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 84476, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"G27Q3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:538,y:673,t:1528140042741};\\\", \\\"{x:537,y:673,t:1528140042803};\\\", \\\"{x:536,y:674,t:1528140043069};\\\", \\\"{x:534,y:675,t:1528140043109};\\\", \\\"{x:533,y:676,t:1528140043117};\\\", \\\"{x:531,y:676,t:1528140043129};\\\", \\\"{x:524,y:676,t:1528140043146};\\\", \\\"{x:519,y:676,t:1528140043162};\\\", \\\"{x:506,y:674,t:1528140043179};\\\", \\\"{x:489,y:669,t:1528140043197};\\\", \\\"{x:484,y:666,t:1528140043214};\\\", \\\"{x:468,y:661,t:1528140043229};\\\", \\\"{x:464,y:659,t:1528140043241};\\\", \\\"{x:457,y:657,t:1528140043257};\\\", \\\"{x:452,y:656,t:1528140043274};\\\", \\\"{x:449,y:655,t:1528140043290};\\\", \\\"{x:448,y:655,t:1528140043308};\\\", \\\"{x:446,y:655,t:1528140043325};\\\", \\\"{x:446,y:656,t:1528140043908};\\\", \\\"{x:454,y:653,t:1528140044021};\\\", \\\"{x:457,y:650,t:1528140044029};\\\", \\\"{x:465,y:645,t:1528140044042};\\\", \\\"{x:498,y:624,t:1528140044059};\\\", \\\"{x:533,y:606,t:1528140044075};\\\", \\\"{x:575,y:585,t:1528140044092};\\\", \\\"{x:670,y:547,t:1528140044108};\\\", \\\"{x:695,y:534,t:1528140044126};\\\", \\\"{x:718,y:522,t:1528140044142};\\\", \\\"{x:723,y:516,t:1528140044158};\\\", \\\"{x:723,y:513,t:1528140044175};\\\", \\\"{x:724,y:512,t:1528140044196};\\\", \\\"{x:724,y:511,t:1528140044236};\\\", \\\"{x:724,y:510,t:1528140044252};\\\", \\\"{x:723,y:510,t:1528140044276};\\\", \\\"{x:718,y:510,t:1528140044292};\\\", \\\"{x:707,y:509,t:1528140044309};\\\", \\\"{x:690,y:509,t:1528140044325};\\\", \\\"{x:668,y:509,t:1528140044342};\\\", \\\"{x:653,y:509,t:1528140044358};\\\", \\\"{x:642,y:509,t:1528140044375};\\\", \\\"{x:629,y:509,t:1528140044392};\\\", \\\"{x:622,y:509,t:1528140044409};\\\", \\\"{x:621,y:509,t:1528140044425};\\\", \\\"{x:620,y:509,t:1528140044442};\\\", \\\"{x:619,y:509,t:1528140044459};\\\", \\\"{x:618,y:509,t:1528140044476};\\\", \\\"{x:616,y:509,t:1528140044516};\\\", \\\"{x:615,y:509,t:1528140044589};\\\", \\\"{x:610,y:508,t:1528140044596};\\\", \\\"{x:601,y:507,t:1528140044609};\\\", \\\"{x:591,y:504,t:1528140044626};\\\", \\\"{x:588,y:503,t:1528140044642};\\\", \\\"{x:578,y:499,t:1528140044660};\\\", \\\"{x:564,y:495,t:1528140044674};\\\", \\\"{x:537,y:494,t:1528140044692};\\\", \\\"{x:515,y:491,t:1528140044709};\\\", \\\"{x:498,y:489,t:1528140044726};\\\", \\\"{x:470,y:485,t:1528140044742};\\\", \\\"{x:450,y:483,t:1528140044759};\\\", \\\"{x:434,y:478,t:1528140044776};\\\", \\\"{x:421,y:476,t:1528140044792};\\\", \\\"{x:412,y:474,t:1528140044808};\\\", \\\"{x:412,y:473,t:1528140044826};\\\", \\\"{x:411,y:473,t:1528140049910};\\\", \\\"{x:410,y:472,t:1528140049933};\\\", \\\"{x:410,y:470,t:1528140049950};\\\", \\\"{x:410,y:469,t:1528140049963};\\\", \\\"{x:409,y:468,t:1528140050020};\\\", \\\"{x:409,y:466,t:1528140050741};\\\", \\\"{x:409,y:465,t:1528140050756};\\\", \\\"{x:410,y:465,t:1528140050764};\\\", \\\"{x:418,y:464,t:1528140050782};\\\", \\\"{x:504,y:476,t:1528140050797};\\\", \\\"{x:609,y:488,t:1528140050815};\\\", \\\"{x:680,y:495,t:1528140050831};\\\", \\\"{x:730,y:499,t:1528140050848};\\\", \\\"{x:765,y:504,t:1528140050864};\\\", \\\"{x:801,y:509,t:1528140050880};\\\", \\\"{x:817,y:512,t:1528140050898};\\\", \\\"{x:839,y:516,t:1528140050914};\\\", \\\"{x:857,y:522,t:1528140050931};\\\", \\\"{x:880,y:528,t:1528140050947};\\\", \\\"{x:918,y:534,t:1528140050964};\\\", \\\"{x:947,y:546,t:1528140050981};\\\", \\\"{x:986,y:557,t:1528140050997};\\\", \\\"{x:1047,y:565,t:1528140051014};\\\", \\\"{x:1112,y:577,t:1528140051031};\\\", \\\"{x:1175,y:592,t:1528140051048};\\\", \\\"{x:1225,y:605,t:1528140051064};\\\", \\\"{x:1263,y:613,t:1528140051081};\\\", \\\"{x:1288,y:620,t:1528140051098};\\\", \\\"{x:1330,y:629,t:1528140051115};\\\", \\\"{x:1380,y:641,t:1528140051131};\\\", \\\"{x:1421,y:651,t:1528140051147};\\\", \\\"{x:1478,y:663,t:1528140051164};\\\", \\\"{x:1506,y:664,t:1528140051181};\\\", \\\"{x:1536,y:667,t:1528140051197};\\\", \\\"{x:1565,y:667,t:1528140051214};\\\", \\\"{x:1581,y:667,t:1528140051230};\\\", \\\"{x:1585,y:667,t:1528140051247};\\\", \\\"{x:1585,y:666,t:1528140051284};\\\", \\\"{x:1581,y:663,t:1528140051297};\\\", \\\"{x:1564,y:654,t:1528140051314};\\\", \\\"{x:1548,y:648,t:1528140051331};\\\", \\\"{x:1542,y:645,t:1528140051348};\\\", \\\"{x:1541,y:645,t:1528140051693};\\\", \\\"{x:1541,y:644,t:1528140051733};\\\", \\\"{x:1541,y:643,t:1528140051747};\\\", \\\"{x:1541,y:642,t:1528140052133};\\\", \\\"{x:1541,y:641,t:1528140052148};\\\", \\\"{x:1541,y:640,t:1528140052165};\\\", \\\"{x:1541,y:637,t:1528140052181};\\\", \\\"{x:1541,y:635,t:1528140052198};\\\", \\\"{x:1541,y:633,t:1528140052214};\\\", \\\"{x:1542,y:630,t:1528140052231};\\\", \\\"{x:1543,y:625,t:1528140052248};\\\", \\\"{x:1543,y:622,t:1528140052265};\\\", \\\"{x:1543,y:618,t:1528140052281};\\\", \\\"{x:1543,y:615,t:1528140052298};\\\", \\\"{x:1543,y:612,t:1528140052315};\\\", \\\"{x:1542,y:607,t:1528140052331};\\\", \\\"{x:1542,y:606,t:1528140052347};\\\", \\\"{x:1541,y:603,t:1528140052364};\\\", \\\"{x:1541,y:602,t:1528140052380};\\\", \\\"{x:1540,y:602,t:1528140052468};\\\", \\\"{x:1537,y:602,t:1528140052484};\\\", \\\"{x:1535,y:602,t:1528140052500};\\\", \\\"{x:1533,y:602,t:1528140052514};\\\", \\\"{x:1529,y:605,t:1528140052531};\\\", \\\"{x:1526,y:606,t:1528140052548};\\\", \\\"{x:1522,y:609,t:1528140052563};\\\", \\\"{x:1521,y:621,t:1528140052581};\\\", \\\"{x:1519,y:626,t:1528140052597};\\\", \\\"{x:1519,y:634,t:1528140052613};\\\", \\\"{x:1521,y:639,t:1528140052630};\\\", \\\"{x:1523,y:642,t:1528140052647};\\\", \\\"{x:1525,y:644,t:1528140052668};\\\", \\\"{x:1526,y:645,t:1528140052797};\\\", \\\"{x:1525,y:647,t:1528140052869};\\\", \\\"{x:1523,y:647,t:1528140052881};\\\", \\\"{x:1517,y:651,t:1528140052898};\\\", \\\"{x:1508,y:652,t:1528140052914};\\\", \\\"{x:1493,y:656,t:1528140052931};\\\", \\\"{x:1478,y:662,t:1528140052948};\\\", \\\"{x:1465,y:668,t:1528140052963};\\\", \\\"{x:1438,y:674,t:1528140052981};\\\", \\\"{x:1417,y:678,t:1528140052998};\\\", \\\"{x:1407,y:679,t:1528140053014};\\\", \\\"{x:1402,y:679,t:1528140053031};\\\", \\\"{x:1401,y:681,t:1528140053048};\\\", \\\"{x:1399,y:685,t:1528140053063};\\\", \\\"{x:1393,y:686,t:1528140053081};\\\", \\\"{x:1392,y:687,t:1528140053109};\\\", \\\"{x:1392,y:688,t:1528140053309};\\\", \\\"{x:1393,y:689,t:1528140053862};\\\", \\\"{x:1393,y:690,t:1528140053869};\\\", \\\"{x:1394,y:690,t:1528140053884};\\\", \\\"{x:1397,y:693,t:1528140054053};\\\", \\\"{x:1399,y:693,t:1528140054064};\\\", \\\"{x:1402,y:694,t:1528140054125};\\\", \\\"{x:1402,y:695,t:1528140054357};\\\", \\\"{x:1403,y:695,t:1528140054365};\\\", \\\"{x:1406,y:695,t:1528140054381};\\\", \\\"{x:1420,y:696,t:1528140054397};\\\", \\\"{x:1430,y:697,t:1528140054414};\\\", \\\"{x:1431,y:697,t:1528140054468};\\\", \\\"{x:1431,y:698,t:1528140054548};\\\", \\\"{x:1431,y:699,t:1528140054588};\\\", \\\"{x:1431,y:700,t:1528140054997};\\\", \\\"{x:1433,y:700,t:1528140055013};\\\", \\\"{x:1438,y:700,t:1528140055693};\\\", \\\"{x:1448,y:700,t:1528140055701};\\\", \\\"{x:1458,y:700,t:1528140055714};\\\", \\\"{x:1462,y:700,t:1528140055730};\\\", \\\"{x:1472,y:703,t:1528140055747};\\\", \\\"{x:1488,y:707,t:1528140055764};\\\", \\\"{x:1506,y:711,t:1528140055780};\\\", \\\"{x:1510,y:713,t:1528140055799};\\\", \\\"{x:1510,y:714,t:1528140056165};\\\", \\\"{x:1510,y:715,t:1528140056606};\\\", \\\"{x:1511,y:716,t:1528140056669};\\\", \\\"{x:1511,y:717,t:1528140057013};\\\", \\\"{x:1508,y:720,t:1528140057031};\\\", \\\"{x:1505,y:723,t:1528140057047};\\\", \\\"{x:1499,y:725,t:1528140057063};\\\", \\\"{x:1476,y:728,t:1528140057080};\\\", \\\"{x:1455,y:730,t:1528140057097};\\\", \\\"{x:1403,y:730,t:1528140057113};\\\", \\\"{x:1298,y:730,t:1528140057130};\\\", \\\"{x:1161,y:720,t:1528140057147};\\\", \\\"{x:1015,y:703,t:1528140057163};\\\", \\\"{x:852,y:686,t:1528140057180};\\\", \\\"{x:675,y:655,t:1528140057196};\\\", \\\"{x:593,y:636,t:1528140057213};\\\", \\\"{x:537,y:628,t:1528140057230};\\\", \\\"{x:526,y:620,t:1528140057247};\\\", \\\"{x:509,y:613,t:1528140057262};\\\", \\\"{x:498,y:607,t:1528140057281};\\\", \\\"{x:486,y:603,t:1528140057297};\\\", \\\"{x:470,y:593,t:1528140057312};\\\", \\\"{x:455,y:587,t:1528140057326};\\\", \\\"{x:446,y:582,t:1528140057342};\\\", \\\"{x:430,y:573,t:1528140057360};\\\", \\\"{x:424,y:571,t:1528140057369};\\\", \\\"{x:415,y:565,t:1528140057385};\\\", \\\"{x:413,y:562,t:1528140057402};\\\", \\\"{x:413,y:553,t:1528140057419};\\\", \\\"{x:425,y:533,t:1528140057436};\\\", \\\"{x:459,y:499,t:1528140057453};\\\", \\\"{x:481,y:480,t:1528140057469};\\\", \\\"{x:497,y:473,t:1528140057486};\\\", \\\"{x:507,y:469,t:1528140057502};\\\", \\\"{x:521,y:468,t:1528140057519};\\\", \\\"{x:541,y:470,t:1528140057537};\\\", \\\"{x:555,y:476,t:1528140057553};\\\", \\\"{x:575,y:483,t:1528140057570};\\\", \\\"{x:603,y:495,t:1528140057586};\\\", \\\"{x:641,y:505,t:1528140057603};\\\", \\\"{x:675,y:510,t:1528140057620};\\\", \\\"{x:725,y:515,t:1528140057637};\\\", \\\"{x:758,y:515,t:1528140057652};\\\", \\\"{x:775,y:515,t:1528140057669};\\\", \\\"{x:787,y:515,t:1528140057686};\\\", \\\"{x:804,y:521,t:1528140057703};\\\", \\\"{x:824,y:524,t:1528140057721};\\\", \\\"{x:839,y:526,t:1528140057736};\\\", \\\"{x:850,y:530,t:1528140057753};\\\", \\\"{x:860,y:532,t:1528140057769};\\\", \\\"{x:870,y:534,t:1528140057787};\\\", \\\"{x:880,y:535,t:1528140057803};\\\", \\\"{x:883,y:537,t:1528140057819};\\\", \\\"{x:883,y:538,t:1528140057884};\\\", \\\"{x:882,y:538,t:1528140057892};\\\", \\\"{x:879,y:538,t:1528140057903};\\\", \\\"{x:876,y:539,t:1528140057919};\\\", \\\"{x:875,y:539,t:1528140057936};\\\", \\\"{x:873,y:539,t:1528140057954};\\\", \\\"{x:870,y:538,t:1528140057971};\\\", \\\"{x:868,y:536,t:1528140057987};\\\", \\\"{x:867,y:532,t:1528140058003};\\\", \\\"{x:863,y:530,t:1528140058019};\\\", \\\"{x:860,y:527,t:1528140058037};\\\", \\\"{x:858,y:527,t:1528140058053};\\\", \\\"{x:857,y:526,t:1528140058070};\\\", \\\"{x:856,y:525,t:1528140058093};\\\", \\\"{x:855,y:524,t:1528140058108};\\\", \\\"{x:854,y:523,t:1528140058120};\\\", \\\"{x:852,y:523,t:1528140058137};\\\", \\\"{x:851,y:523,t:1528140058154};\\\", \\\"{x:848,y:522,t:1528140058170};\\\", \\\"{x:847,y:522,t:1528140058205};\\\", \\\"{x:846,y:522,t:1528140058236};\\\", \\\"{x:845,y:522,t:1528140058276};\\\", \\\"{x:830,y:527,t:1528140058453};\\\", \\\"{x:815,y:535,t:1528140058471};\\\", \\\"{x:799,y:540,t:1528140058487};\\\", \\\"{x:794,y:543,t:1528140058504};\\\", \\\"{x:793,y:544,t:1528140058521};\\\", \\\"{x:792,y:544,t:1528140058701};\\\", \\\"{x:793,y:544,t:1528140058708};\\\", \\\"{x:791,y:544,t:1528140058781};\\\", \\\"{x:787,y:544,t:1528140058797};\\\", \\\"{x:783,y:545,t:1528140058805};\\\", \\\"{x:776,y:545,t:1528140058821};\\\", \\\"{x:753,y:545,t:1528140058837};\\\", \\\"{x:722,y:545,t:1528140058854};\\\", \\\"{x:686,y:545,t:1528140058870};\\\", \\\"{x:654,y:535,t:1528140058888};\\\", \\\"{x:632,y:530,t:1528140058903};\\\", \\\"{x:623,y:527,t:1528140058920};\\\", \\\"{x:622,y:526,t:1528140058937};\\\", \\\"{x:620,y:526,t:1528140059276};\\\", \\\"{x:615,y:527,t:1528140059288};\\\", \\\"{x:603,y:532,t:1528140059305};\\\", \\\"{x:590,y:546,t:1528140059321};\\\", \\\"{x:575,y:556,t:1528140059338};\\\", \\\"{x:567,y:565,t:1528140059355};\\\", \\\"{x:558,y:576,t:1528140059370};\\\", \\\"{x:554,y:585,t:1528140059387};\\\", \\\"{x:551,y:593,t:1528140059404};\\\", \\\"{x:550,y:594,t:1528140059421};\\\", \\\"{x:549,y:596,t:1528140059444};\\\", \\\"{x:549,y:598,t:1528140059455};\\\", \\\"{x:546,y:606,t:1528140059471};\\\", \\\"{x:545,y:611,t:1528140059487};\\\", \\\"{x:545,y:613,t:1528140059505};\\\", \\\"{x:544,y:618,t:1528140059621};\\\", \\\"{x:543,y:623,t:1528140059638};\\\", \\\"{x:540,y:635,t:1528140059655};\\\", \\\"{x:536,y:650,t:1528140059672};\\\", \\\"{x:534,y:658,t:1528140059688};\\\", \\\"{x:534,y:660,t:1528140059705};\\\", \\\"{x:534,y:661,t:1528140059722};\\\", \\\"{x:534,y:663,t:1528140059738};\\\", \\\"{x:534,y:664,t:1528140059755};\\\", \\\"{x:534,y:665,t:1528140059788};\\\", \\\"{x:535,y:667,t:1528140059806};\\\", \\\"{x:535,y:669,t:1528140059822};\\\", \\\"{x:536,y:670,t:1528140059837};\\\", \\\"{x:536,y:671,t:1528140059868};\\\", \\\"{x:536,y:673,t:1528140059876};\\\", \\\"{x:536,y:675,t:1528140059892};\\\", \\\"{x:536,y:676,t:1528140059904};\\\", \\\"{x:536,y:679,t:1528140059921};\\\", \\\"{x:538,y:680,t:1528140059939};\\\", \\\"{x:538,y:681,t:1528140060628};\\\" ] }, { \\\"rt\\\": 12670, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 98380, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"G27Q3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:534,y:681,t:1528140062012};\\\", \\\"{x:533,y:681,t:1528140062036};\\\", \\\"{x:536,y:679,t:1528140062477};\\\", \\\"{x:551,y:669,t:1528140062493};\\\", \\\"{x:562,y:662,t:1528140062510};\\\", \\\"{x:581,y:656,t:1528140062526};\\\", \\\"{x:633,y:645,t:1528140062540};\\\", \\\"{x:670,y:644,t:1528140062557};\\\", \\\"{x:740,y:639,t:1528140062573};\\\", \\\"{x:804,y:639,t:1528140062590};\\\", \\\"{x:860,y:643,t:1528140062606};\\\", \\\"{x:977,y:650,t:1528140062623};\\\", \\\"{x:1073,y:657,t:1528140062640};\\\", \\\"{x:1168,y:659,t:1528140062657};\\\", \\\"{x:1248,y:659,t:1528140062674};\\\", \\\"{x:1294,y:659,t:1528140062691};\\\", \\\"{x:1337,y:655,t:1528140062707};\\\", \\\"{x:1372,y:647,t:1528140062725};\\\", \\\"{x:1415,y:634,t:1528140062740};\\\", \\\"{x:1443,y:622,t:1528140062757};\\\", \\\"{x:1475,y:602,t:1528140062774};\\\", \\\"{x:1500,y:589,t:1528140062792};\\\", \\\"{x:1517,y:576,t:1528140062807};\\\", \\\"{x:1525,y:568,t:1528140062824};\\\", \\\"{x:1540,y:554,t:1528140062841};\\\", \\\"{x:1547,y:542,t:1528140062857};\\\", \\\"{x:1550,y:529,t:1528140062874};\\\", \\\"{x:1552,y:520,t:1528140062891};\\\", \\\"{x:1552,y:510,t:1528140062908};\\\", \\\"{x:1552,y:507,t:1528140062925};\\\", \\\"{x:1552,y:504,t:1528140062942};\\\", \\\"{x:1552,y:501,t:1528140062957};\\\", \\\"{x:1552,y:500,t:1528140062974};\\\", \\\"{x:1551,y:500,t:1528140062991};\\\", \\\"{x:1536,y:495,t:1528140063008};\\\", \\\"{x:1517,y:491,t:1528140063023};\\\", \\\"{x:1514,y:489,t:1528140063041};\\\", \\\"{x:1513,y:489,t:1528140063469};\\\", \\\"{x:1510,y:490,t:1528140063869};\\\", \\\"{x:1506,y:494,t:1528140063877};\\\", \\\"{x:1503,y:499,t:1528140063892};\\\", \\\"{x:1483,y:526,t:1528140063908};\\\", \\\"{x:1465,y:555,t:1528140063925};\\\", \\\"{x:1446,y:588,t:1528140063943};\\\", \\\"{x:1425,y:628,t:1528140063958};\\\", \\\"{x:1403,y:688,t:1528140063976};\\\", \\\"{x:1382,y:735,t:1528140063992};\\\", \\\"{x:1369,y:777,t:1528140064009};\\\", \\\"{x:1361,y:799,t:1528140064026};\\\", \\\"{x:1352,y:819,t:1528140064042};\\\", \\\"{x:1345,y:833,t:1528140064058};\\\", \\\"{x:1344,y:836,t:1528140064076};\\\", \\\"{x:1342,y:838,t:1528140064093};\\\", \\\"{x:1340,y:838,t:1528140064421};\\\", \\\"{x:1336,y:838,t:1528140064437};\\\", \\\"{x:1334,y:838,t:1528140064445};\\\", \\\"{x:1332,y:838,t:1528140064459};\\\", \\\"{x:1331,y:838,t:1528140064476};\\\", \\\"{x:1329,y:838,t:1528140064492};\\\", \\\"{x:1325,y:838,t:1528140064508};\\\", \\\"{x:1316,y:838,t:1528140064525};\\\", \\\"{x:1310,y:838,t:1528140064543};\\\", \\\"{x:1300,y:838,t:1528140064560};\\\", \\\"{x:1292,y:834,t:1528140064576};\\\", \\\"{x:1287,y:831,t:1528140064592};\\\", \\\"{x:1285,y:829,t:1528140064609};\\\", \\\"{x:1283,y:826,t:1528140064626};\\\", \\\"{x:1281,y:824,t:1528140064642};\\\", \\\"{x:1276,y:816,t:1528140064659};\\\", \\\"{x:1273,y:797,t:1528140064675};\\\", \\\"{x:1271,y:789,t:1528140064693};\\\", \\\"{x:1270,y:783,t:1528140064709};\\\", \\\"{x:1270,y:781,t:1528140064726};\\\", \\\"{x:1269,y:779,t:1528140064742};\\\", \\\"{x:1269,y:778,t:1528140064759};\\\", \\\"{x:1269,y:776,t:1528140064775};\\\", \\\"{x:1269,y:773,t:1528140064792};\\\", \\\"{x:1269,y:772,t:1528140064809};\\\", \\\"{x:1269,y:770,t:1528140064827};\\\", \\\"{x:1269,y:768,t:1528140064842};\\\", \\\"{x:1269,y:764,t:1528140064860};\\\", \\\"{x:1273,y:758,t:1528140064876};\\\", \\\"{x:1279,y:751,t:1528140064893};\\\", \\\"{x:1285,y:745,t:1528140064909};\\\", \\\"{x:1290,y:738,t:1528140064926};\\\", \\\"{x:1297,y:731,t:1528140064943};\\\", \\\"{x:1301,y:728,t:1528140064960};\\\", \\\"{x:1303,y:726,t:1528140064977};\\\", \\\"{x:1306,y:721,t:1528140064992};\\\", \\\"{x:1312,y:715,t:1528140065009};\\\", \\\"{x:1322,y:706,t:1528140065027};\\\", \\\"{x:1332,y:697,t:1528140065042};\\\", \\\"{x:1343,y:691,t:1528140065060};\\\", \\\"{x:1349,y:684,t:1528140065077};\\\", \\\"{x:1354,y:680,t:1528140065092};\\\", \\\"{x:1357,y:678,t:1528140065109};\\\", \\\"{x:1359,y:676,t:1528140065127};\\\", \\\"{x:1361,y:671,t:1528140065143};\\\", \\\"{x:1362,y:666,t:1528140065159};\\\", \\\"{x:1365,y:663,t:1528140065176};\\\", \\\"{x:1365,y:662,t:1528140065193};\\\", \\\"{x:1365,y:659,t:1528140065209};\\\", \\\"{x:1365,y:655,t:1528140065227};\\\", \\\"{x:1365,y:651,t:1528140065243};\\\", \\\"{x:1365,y:644,t:1528140065260};\\\", \\\"{x:1365,y:627,t:1528140065277};\\\", \\\"{x:1365,y:625,t:1528140065292};\\\", \\\"{x:1365,y:620,t:1528140065310};\\\", \\\"{x:1365,y:618,t:1528140065326};\\\", \\\"{x:1365,y:616,t:1528140065344};\\\", \\\"{x:1364,y:616,t:1528140065485};\\\", \\\"{x:1364,y:619,t:1528140065492};\\\", \\\"{x:1363,y:623,t:1528140065509};\\\", \\\"{x:1359,y:631,t:1528140065526};\\\", \\\"{x:1355,y:639,t:1528140065543};\\\", \\\"{x:1352,y:645,t:1528140065562};\\\", \\\"{x:1349,y:649,t:1528140065575};\\\", \\\"{x:1346,y:653,t:1528140065593};\\\", \\\"{x:1343,y:657,t:1528140065609};\\\", \\\"{x:1343,y:659,t:1528140065626};\\\", \\\"{x:1343,y:660,t:1528140065643};\\\", \\\"{x:1343,y:662,t:1528140065660};\\\", \\\"{x:1341,y:664,t:1528140065676};\\\", \\\"{x:1340,y:666,t:1528140065693};\\\", \\\"{x:1339,y:668,t:1528140065710};\\\", \\\"{x:1338,y:669,t:1528140065726};\\\", \\\"{x:1338,y:671,t:1528140065748};\\\", \\\"{x:1337,y:671,t:1528140065760};\\\", \\\"{x:1337,y:670,t:1528140065941};\\\", \\\"{x:1339,y:664,t:1528140065949};\\\", \\\"{x:1339,y:659,t:1528140065960};\\\", \\\"{x:1343,y:652,t:1528140065976};\\\", \\\"{x:1345,y:646,t:1528140065994};\\\", \\\"{x:1349,y:640,t:1528140066010};\\\", \\\"{x:1351,y:635,t:1528140066027};\\\", \\\"{x:1354,y:630,t:1528140066043};\\\", \\\"{x:1367,y:611,t:1528140066061};\\\", \\\"{x:1376,y:598,t:1528140066077};\\\", \\\"{x:1382,y:586,t:1528140066093};\\\", \\\"{x:1387,y:576,t:1528140066110};\\\", \\\"{x:1396,y:564,t:1528140066128};\\\", \\\"{x:1403,y:553,t:1528140066144};\\\", \\\"{x:1411,y:541,t:1528140066160};\\\", \\\"{x:1417,y:527,t:1528140066178};\\\", \\\"{x:1422,y:517,t:1528140066194};\\\", \\\"{x:1424,y:509,t:1528140066211};\\\", \\\"{x:1431,y:497,t:1528140066228};\\\", \\\"{x:1432,y:493,t:1528140066243};\\\", \\\"{x:1433,y:491,t:1528140066261};\\\", \\\"{x:1434,y:490,t:1528140066277};\\\", \\\"{x:1434,y:489,t:1528140066325};\\\", \\\"{x:1434,y:488,t:1528140066341};\\\", \\\"{x:1434,y:487,t:1528140066381};\\\", \\\"{x:1434,y:486,t:1528140066420};\\\", \\\"{x:1430,y:487,t:1528140066429};\\\", \\\"{x:1421,y:492,t:1528140066444};\\\", \\\"{x:1405,y:501,t:1528140066460};\\\", \\\"{x:1401,y:504,t:1528140066477};\\\", \\\"{x:1397,y:507,t:1528140066494};\\\", \\\"{x:1396,y:508,t:1528140066510};\\\", \\\"{x:1395,y:508,t:1528140066653};\\\", \\\"{x:1395,y:509,t:1528140066661};\\\", \\\"{x:1395,y:512,t:1528140066677};\\\", \\\"{x:1395,y:516,t:1528140066695};\\\", \\\"{x:1397,y:519,t:1528140066710};\\\", \\\"{x:1397,y:521,t:1528140066728};\\\", \\\"{x:1399,y:524,t:1528140066744};\\\", \\\"{x:1402,y:527,t:1528140066761};\\\", \\\"{x:1403,y:531,t:1528140066778};\\\", \\\"{x:1404,y:534,t:1528140066795};\\\", \\\"{x:1405,y:537,t:1528140066811};\\\", \\\"{x:1406,y:538,t:1528140066827};\\\", \\\"{x:1406,y:537,t:1528140066998};\\\", \\\"{x:1408,y:536,t:1528140067011};\\\", \\\"{x:1408,y:535,t:1528140067028};\\\", \\\"{x:1408,y:531,t:1528140067044};\\\", \\\"{x:1408,y:530,t:1528140067126};\\\", \\\"{x:1408,y:529,t:1528140067181};\\\", \\\"{x:1408,y:528,t:1528140067194};\\\", \\\"{x:1407,y:527,t:1528140067212};\\\", \\\"{x:1406,y:523,t:1528140067228};\\\", \\\"{x:1404,y:518,t:1528140067245};\\\", \\\"{x:1404,y:511,t:1528140067261};\\\", \\\"{x:1404,y:507,t:1528140067277};\\\", \\\"{x:1403,y:505,t:1528140067295};\\\", \\\"{x:1403,y:504,t:1528140067312};\\\", \\\"{x:1403,y:503,t:1528140067965};\\\", \\\"{x:1404,y:504,t:1528140068070};\\\", \\\"{x:1406,y:505,t:1528140068565};\\\", \\\"{x:1406,y:506,t:1528140068579};\\\", \\\"{x:1407,y:510,t:1528140068596};\\\", \\\"{x:1407,y:512,t:1528140068613};\\\", \\\"{x:1408,y:513,t:1528140068628};\\\", \\\"{x:1406,y:517,t:1528140069348};\\\", \\\"{x:1394,y:522,t:1528140069362};\\\", \\\"{x:1319,y:541,t:1528140069379};\\\", \\\"{x:1166,y:566,t:1528140069397};\\\", \\\"{x:1001,y:581,t:1528140069413};\\\", \\\"{x:840,y:582,t:1528140069429};\\\", \\\"{x:714,y:572,t:1528140069447};\\\", \\\"{x:622,y:570,t:1528140069462};\\\", \\\"{x:566,y:570,t:1528140069479};\\\", \\\"{x:554,y:573,t:1528140069512};\\\", \\\"{x:548,y:573,t:1528140069765};\\\", \\\"{x:540,y:567,t:1528140069780};\\\", \\\"{x:513,y:554,t:1528140069796};\\\", \\\"{x:482,y:543,t:1528140069814};\\\", \\\"{x:463,y:536,t:1528140069830};\\\", \\\"{x:450,y:533,t:1528140069846};\\\", \\\"{x:445,y:532,t:1528140069863};\\\", \\\"{x:444,y:532,t:1528140069879};\\\", \\\"{x:442,y:530,t:1528140069921};\\\", \\\"{x:440,y:530,t:1528140070004};\\\", \\\"{x:428,y:530,t:1528140070013};\\\", \\\"{x:381,y:529,t:1528140070031};\\\", \\\"{x:311,y:525,t:1528140070047};\\\", \\\"{x:218,y:519,t:1528140070064};\\\", \\\"{x:132,y:508,t:1528140070080};\\\", \\\"{x:86,y:501,t:1528140070097};\\\", \\\"{x:55,y:501,t:1528140070113};\\\", \\\"{x:42,y:498,t:1528140070131};\\\", \\\"{x:39,y:497,t:1528140070146};\\\", \\\"{x:43,y:497,t:1528140070317};\\\", \\\"{x:50,y:497,t:1528140070331};\\\", \\\"{x:68,y:499,t:1528140070346};\\\", \\\"{x:97,y:505,t:1528140070363};\\\", \\\"{x:135,y:511,t:1528140070380};\\\", \\\"{x:153,y:515,t:1528140070397};\\\", \\\"{x:174,y:520,t:1528140070413};\\\", \\\"{x:185,y:521,t:1528140070430};\\\", \\\"{x:203,y:523,t:1528140070448};\\\", \\\"{x:215,y:525,t:1528140070463};\\\", \\\"{x:227,y:525,t:1528140070480};\\\", \\\"{x:246,y:525,t:1528140070497};\\\", \\\"{x:278,y:525,t:1528140070520};\\\", \\\"{x:401,y:525,t:1528140070559};\\\", \\\"{x:414,y:525,t:1528140070565};\\\", \\\"{x:471,y:524,t:1528140070580};\\\", \\\"{x:503,y:524,t:1528140070598};\\\", \\\"{x:519,y:524,t:1528140070613};\\\", \\\"{x:528,y:524,t:1528140070630};\\\", \\\"{x:534,y:525,t:1528140070647};\\\", \\\"{x:538,y:525,t:1528140070821};\\\", \\\"{x:540,y:525,t:1528140070837};\\\", \\\"{x:547,y:525,t:1528140070848};\\\", \\\"{x:564,y:525,t:1528140070864};\\\", \\\"{x:594,y:525,t:1528140070880};\\\", \\\"{x:617,y:525,t:1528140070898};\\\", \\\"{x:623,y:525,t:1528140070914};\\\", \\\"{x:632,y:525,t:1528140070930};\\\", \\\"{x:637,y:525,t:1528140070947};\\\", \\\"{x:642,y:526,t:1528140070963};\\\", \\\"{x:643,y:526,t:1528140070980};\\\", \\\"{x:644,y:526,t:1528140071052};\\\", \\\"{x:645,y:526,t:1528140071064};\\\", \\\"{x:647,y:524,t:1528140071080};\\\", \\\"{x:654,y:521,t:1528140071097};\\\", \\\"{x:661,y:517,t:1528140071114};\\\", \\\"{x:676,y:514,t:1528140071130};\\\", \\\"{x:695,y:512,t:1528140071147};\\\", \\\"{x:710,y:511,t:1528140071164};\\\", \\\"{x:719,y:511,t:1528140071180};\\\", \\\"{x:727,y:511,t:1528140071200};\\\", \\\"{x:738,y:510,t:1528140071214};\\\", \\\"{x:744,y:510,t:1528140071230};\\\", \\\"{x:754,y:510,t:1528140071247};\\\", \\\"{x:759,y:509,t:1528140071264};\\\", \\\"{x:762,y:509,t:1528140071280};\\\", \\\"{x:765,y:509,t:1528140071296};\\\", \\\"{x:772,y:507,t:1528140071314};\\\", \\\"{x:779,y:505,t:1528140071331};\\\", \\\"{x:792,y:502,t:1528140071347};\\\", \\\"{x:812,y:497,t:1528140071364};\\\", \\\"{x:830,y:495,t:1528140071381};\\\", \\\"{x:844,y:493,t:1528140071397};\\\", \\\"{x:856,y:491,t:1528140071414};\\\", \\\"{x:860,y:489,t:1528140071431};\\\", \\\"{x:861,y:489,t:1528140071447};\\\", \\\"{x:865,y:488,t:1528140071468};\\\", \\\"{x:867,y:488,t:1528140071484};\\\", \\\"{x:868,y:488,t:1528140071497};\\\", \\\"{x:871,y:488,t:1528140071515};\\\", \\\"{x:873,y:488,t:1528140071531};\\\", \\\"{x:874,y:488,t:1528140071547};\\\", \\\"{x:873,y:488,t:1528140071644};\\\", \\\"{x:872,y:488,t:1528140071652};\\\", \\\"{x:870,y:488,t:1528140071664};\\\", \\\"{x:867,y:488,t:1528140071682};\\\", \\\"{x:866,y:488,t:1528140071700};\\\", \\\"{x:865,y:488,t:1528140071764};\\\", \\\"{x:862,y:488,t:1528140071788};\\\", \\\"{x:861,y:488,t:1528140071798};\\\", \\\"{x:854,y:488,t:1528140071814};\\\", \\\"{x:851,y:487,t:1528140071832};\\\", \\\"{x:849,y:487,t:1528140072156};\\\", \\\"{x:846,y:487,t:1528140072165};\\\", \\\"{x:843,y:487,t:1528140072181};\\\", \\\"{x:833,y:495,t:1528140072198};\\\", \\\"{x:828,y:503,t:1528140072216};\\\", \\\"{x:818,y:517,t:1528140072231};\\\", \\\"{x:808,y:531,t:1528140072248};\\\", \\\"{x:791,y:554,t:1528140072266};\\\", \\\"{x:774,y:567,t:1528140072281};\\\", \\\"{x:738,y:594,t:1528140072298};\\\", \\\"{x:692,y:625,t:1528140072314};\\\", \\\"{x:669,y:648,t:1528140072331};\\\", \\\"{x:596,y:689,t:1528140072348};\\\", \\\"{x:555,y:712,t:1528140072365};\\\", \\\"{x:539,y:719,t:1528140072381};\\\", \\\"{x:536,y:722,t:1528140072398};\\\", \\\"{x:534,y:723,t:1528140072415};\\\", \\\"{x:534,y:721,t:1528140072516};\\\", \\\"{x:534,y:720,t:1528140072531};\\\", \\\"{x:534,y:715,t:1528140072549};\\\", \\\"{x:535,y:710,t:1528140072565};\\\", \\\"{x:541,y:699,t:1528140072582};\\\", \\\"{x:543,y:689,t:1528140072598};\\\", \\\"{x:546,y:684,t:1528140072615};\\\", \\\"{x:546,y:681,t:1528140072632};\\\" ] }, { \\\"rt\\\": 10801, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 110446, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"G27Q3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -I -I -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:540,y:686,t:1528140076125};\\\", \\\"{x:543,y:687,t:1528140076981};\\\", \\\"{x:553,y:687,t:1528140076989};\\\", \\\"{x:561,y:687,t:1528140077003};\\\", \\\"{x:580,y:687,t:1528140077022};\\\", \\\"{x:603,y:688,t:1528140077035};\\\", \\\"{x:618,y:690,t:1528140077052};\\\", \\\"{x:640,y:693,t:1528140077069};\\\", \\\"{x:660,y:693,t:1528140077085};\\\", \\\"{x:680,y:694,t:1528140077103};\\\", \\\"{x:692,y:694,t:1528140077119};\\\", \\\"{x:703,y:694,t:1528140077136};\\\", \\\"{x:710,y:694,t:1528140077152};\\\", \\\"{x:714,y:694,t:1528140077169};\\\", \\\"{x:715,y:694,t:1528140077405};\\\", \\\"{x:716,y:694,t:1528140077517};\\\", \\\"{x:719,y:694,t:1528140077524};\\\", \\\"{x:727,y:692,t:1528140077537};\\\", \\\"{x:748,y:691,t:1528140077553};\\\", \\\"{x:780,y:686,t:1528140077570};\\\", \\\"{x:812,y:686,t:1528140077587};\\\", \\\"{x:874,y:686,t:1528140077602};\\\", \\\"{x:929,y:686,t:1528140077620};\\\", \\\"{x:953,y:686,t:1528140077637};\\\", \\\"{x:968,y:683,t:1528140077653};\\\", \\\"{x:1017,y:680,t:1528140077670};\\\", \\\"{x:1050,y:680,t:1528140077687};\\\", \\\"{x:1075,y:680,t:1528140077703};\\\", \\\"{x:1093,y:679,t:1528140077720};\\\", \\\"{x:1123,y:676,t:1528140077737};\\\", \\\"{x:1143,y:673,t:1528140077753};\\\", \\\"{x:1167,y:668,t:1528140077770};\\\", \\\"{x:1178,y:663,t:1528140077787};\\\", \\\"{x:1203,y:650,t:1528140077803};\\\", \\\"{x:1216,y:637,t:1528140077820};\\\", \\\"{x:1250,y:637,t:1528140077837};\\\", \\\"{x:1287,y:620,t:1528140077853};\\\", \\\"{x:1315,y:604,t:1528140077870};\\\", \\\"{x:1331,y:597,t:1528140077887};\\\", \\\"{x:1343,y:592,t:1528140077903};\\\", \\\"{x:1346,y:589,t:1528140077920};\\\", \\\"{x:1351,y:589,t:1528140078213};\\\", \\\"{x:1353,y:589,t:1528140078221};\\\", \\\"{x:1366,y:589,t:1528140078237};\\\", \\\"{x:1368,y:589,t:1528140078253};\\\", \\\"{x:1373,y:591,t:1528140078269};\\\", \\\"{x:1377,y:591,t:1528140078286};\\\", \\\"{x:1378,y:592,t:1528140078304};\\\", \\\"{x:1379,y:593,t:1528140078320};\\\", \\\"{x:1379,y:594,t:1528140078337};\\\", \\\"{x:1382,y:596,t:1528140078353};\\\", \\\"{x:1383,y:599,t:1528140078371};\\\", \\\"{x:1386,y:600,t:1528140078386};\\\", \\\"{x:1393,y:604,t:1528140078403};\\\", \\\"{x:1395,y:608,t:1528140078419};\\\", \\\"{x:1395,y:610,t:1528140078437};\\\", \\\"{x:1396,y:612,t:1528140078453};\\\", \\\"{x:1396,y:613,t:1528140078483};\\\", \\\"{x:1396,y:614,t:1528140078492};\\\", \\\"{x:1394,y:615,t:1528140078508};\\\", \\\"{x:1393,y:616,t:1528140078520};\\\", \\\"{x:1390,y:618,t:1528140078537};\\\", \\\"{x:1386,y:620,t:1528140078554};\\\", \\\"{x:1383,y:620,t:1528140078571};\\\", \\\"{x:1375,y:620,t:1528140078587};\\\", \\\"{x:1364,y:620,t:1528140078604};\\\", \\\"{x:1358,y:620,t:1528140078621};\\\", \\\"{x:1355,y:620,t:1528140078637};\\\", \\\"{x:1354,y:620,t:1528140078654};\\\", \\\"{x:1353,y:619,t:1528140078671};\\\", \\\"{x:1352,y:620,t:1528140079093};\\\", \\\"{x:1352,y:624,t:1528140079104};\\\", \\\"{x:1350,y:628,t:1528140079121};\\\", \\\"{x:1350,y:629,t:1528140079138};\\\", \\\"{x:1350,y:632,t:1528140079154};\\\", \\\"{x:1350,y:633,t:1528140079171};\\\", \\\"{x:1350,y:635,t:1528140079188};\\\", \\\"{x:1347,y:640,t:1528140079208};\\\", \\\"{x:1344,y:644,t:1528140079220};\\\", \\\"{x:1343,y:645,t:1528140079237};\\\", \\\"{x:1341,y:647,t:1528140079255};\\\", \\\"{x:1341,y:648,t:1528140079270};\\\", \\\"{x:1339,y:649,t:1528140079288};\\\", \\\"{x:1338,y:649,t:1528140079380};\\\", \\\"{x:1337,y:649,t:1528140079388};\\\", \\\"{x:1332,y:648,t:1528140079404};\\\", \\\"{x:1330,y:645,t:1528140079420};\\\", \\\"{x:1326,y:645,t:1528140079437};\\\", \\\"{x:1321,y:647,t:1528140079455};\\\", \\\"{x:1320,y:647,t:1528140079471};\\\", \\\"{x:1318,y:647,t:1528140079565};\\\", \\\"{x:1317,y:648,t:1528140079580};\\\", \\\"{x:1315,y:650,t:1528140079588};\\\", \\\"{x:1312,y:654,t:1528140079605};\\\", \\\"{x:1307,y:661,t:1528140079621};\\\", \\\"{x:1306,y:663,t:1528140079638};\\\", \\\"{x:1305,y:666,t:1528140079844};\\\", \\\"{x:1303,y:668,t:1528140079854};\\\", \\\"{x:1296,y:680,t:1528140079872};\\\", \\\"{x:1287,y:695,t:1528140079887};\\\", \\\"{x:1282,y:707,t:1528140079904};\\\", \\\"{x:1272,y:719,t:1528140079921};\\\", \\\"{x:1266,y:728,t:1528140079937};\\\", \\\"{x:1262,y:734,t:1528140079955};\\\", \\\"{x:1257,y:740,t:1528140079972};\\\", \\\"{x:1254,y:743,t:1528140079989};\\\", \\\"{x:1253,y:745,t:1528140080005};\\\", \\\"{x:1252,y:745,t:1528140080085};\\\", \\\"{x:1247,y:745,t:1528140080092};\\\", \\\"{x:1234,y:744,t:1528140080106};\\\", \\\"{x:1218,y:737,t:1528140080122};\\\", \\\"{x:1217,y:737,t:1528140080139};\\\", \\\"{x:1215,y:734,t:1528140080155};\\\", \\\"{x:1209,y:732,t:1528140080172};\\\", \\\"{x:1208,y:731,t:1528140080189};\\\", \\\"{x:1207,y:731,t:1528140080205};\\\", \\\"{x:1206,y:730,t:1528140080333};\\\", \\\"{x:1205,y:729,t:1528140080397};\\\", \\\"{x:1203,y:728,t:1528140080406};\\\", \\\"{x:1201,y:726,t:1528140080422};\\\", \\\"{x:1195,y:724,t:1528140080439};\\\", \\\"{x:1188,y:720,t:1528140080456};\\\", \\\"{x:1181,y:713,t:1528140080473};\\\", \\\"{x:1173,y:710,t:1528140080491};\\\", \\\"{x:1170,y:708,t:1528140080507};\\\", \\\"{x:1171,y:704,t:1528140082102};\\\", \\\"{x:1172,y:703,t:1528140082109};\\\", \\\"{x:1179,y:697,t:1528140082124};\\\", \\\"{x:1184,y:689,t:1528140082141};\\\", \\\"{x:1192,y:679,t:1528140082157};\\\", \\\"{x:1201,y:664,t:1528140082174};\\\", \\\"{x:1213,y:648,t:1528140082190};\\\", \\\"{x:1218,y:632,t:1528140082207};\\\", \\\"{x:1225,y:619,t:1528140082224};\\\", \\\"{x:1232,y:609,t:1528140082241};\\\", \\\"{x:1241,y:597,t:1528140082257};\\\", \\\"{x:1248,y:586,t:1528140082274};\\\", \\\"{x:1256,y:576,t:1528140082290};\\\", \\\"{x:1261,y:561,t:1528140082307};\\\", \\\"{x:1275,y:545,t:1528140082324};\\\", \\\"{x:1283,y:537,t:1528140082341};\\\", \\\"{x:1286,y:535,t:1528140082357};\\\", \\\"{x:1288,y:533,t:1528140082374};\\\", \\\"{x:1289,y:531,t:1528140082396};\\\", \\\"{x:1289,y:530,t:1528140082462};\\\", \\\"{x:1290,y:528,t:1528140082474};\\\", \\\"{x:1290,y:526,t:1528140082492};\\\", \\\"{x:1290,y:524,t:1528140082508};\\\", \\\"{x:1288,y:520,t:1528140082525};\\\", \\\"{x:1288,y:519,t:1528140082549};\\\", \\\"{x:1287,y:518,t:1528140082557};\\\", \\\"{x:1287,y:517,t:1528140082574};\\\", \\\"{x:1287,y:515,t:1528140082591};\\\", \\\"{x:1286,y:512,t:1528140082607};\\\", \\\"{x:1286,y:513,t:1528140082925};\\\", \\\"{x:1287,y:522,t:1528140082941};\\\", \\\"{x:1292,y:530,t:1528140082958};\\\", \\\"{x:1295,y:537,t:1528140082975};\\\", \\\"{x:1297,y:541,t:1528140082991};\\\", \\\"{x:1297,y:543,t:1528140083008};\\\", \\\"{x:1298,y:544,t:1528140083024};\\\", \\\"{x:1298,y:545,t:1528140083101};\\\", \\\"{x:1298,y:547,t:1528140083109};\\\", \\\"{x:1293,y:555,t:1528140083125};\\\", \\\"{x:1280,y:562,t:1528140083141};\\\", \\\"{x:1261,y:571,t:1528140083159};\\\", \\\"{x:1220,y:585,t:1528140083175};\\\", \\\"{x:1128,y:598,t:1528140083192};\\\", \\\"{x:1049,y:604,t:1528140083208};\\\", \\\"{x:960,y:604,t:1528140083224};\\\", \\\"{x:870,y:584,t:1528140083242};\\\", \\\"{x:809,y:569,t:1528140083260};\\\", \\\"{x:770,y:554,t:1528140083275};\\\", \\\"{x:757,y:547,t:1528140083291};\\\", \\\"{x:741,y:542,t:1528140083306};\\\", \\\"{x:733,y:537,t:1528140083324};\\\", \\\"{x:730,y:535,t:1528140083341};\\\", \\\"{x:729,y:534,t:1528140083364};\\\", \\\"{x:729,y:533,t:1528140083374};\\\", \\\"{x:727,y:531,t:1528140083391};\\\", \\\"{x:722,y:528,t:1528140083408};\\\", \\\"{x:717,y:525,t:1528140083423};\\\", \\\"{x:709,y:520,t:1528140083440};\\\", \\\"{x:692,y:514,t:1528140083457};\\\", \\\"{x:685,y:512,t:1528140083473};\\\", \\\"{x:680,y:510,t:1528140083490};\\\", \\\"{x:660,y:503,t:1528140083509};\\\", \\\"{x:644,y:500,t:1528140083525};\\\", \\\"{x:637,y:499,t:1528140083540};\\\", \\\"{x:637,y:497,t:1528140083580};\\\", \\\"{x:638,y:496,t:1528140083596};\\\", \\\"{x:640,y:494,t:1528140083607};\\\", \\\"{x:642,y:491,t:1528140083625};\\\", \\\"{x:646,y:486,t:1528140083641};\\\", \\\"{x:647,y:485,t:1528140083658};\\\", \\\"{x:648,y:481,t:1528140083674};\\\", \\\"{x:648,y:474,t:1528140083690};\\\", \\\"{x:648,y:466,t:1528140083708};\\\", \\\"{x:642,y:458,t:1528140083726};\\\", \\\"{x:635,y:451,t:1528140083741};\\\", \\\"{x:623,y:441,t:1528140083757};\\\", \\\"{x:611,y:435,t:1528140083775};\\\", \\\"{x:602,y:428,t:1528140083791};\\\", \\\"{x:598,y:426,t:1528140083808};\\\", \\\"{x:595,y:423,t:1528140083824};\\\", \\\"{x:594,y:423,t:1528140083841};\\\", \\\"{x:593,y:422,t:1528140083857};\\\", \\\"{x:593,y:421,t:1528140084085};\\\", \\\"{x:593,y:422,t:1528140084260};\\\", \\\"{x:593,y:424,t:1528140084274};\\\", \\\"{x:593,y:433,t:1528140084291};\\\", \\\"{x:596,y:438,t:1528140084308};\\\", \\\"{x:596,y:440,t:1528140084325};\\\", \\\"{x:597,y:440,t:1528140084341};\\\", \\\"{x:599,y:442,t:1528140084358};\\\", \\\"{x:600,y:444,t:1528140084375};\\\", \\\"{x:602,y:444,t:1528140084390};\\\", \\\"{x:603,y:444,t:1528140084408};\\\", \\\"{x:604,y:445,t:1528140084425};\\\", \\\"{x:605,y:446,t:1528140084442};\\\", \\\"{x:608,y:448,t:1528140084458};\\\", \\\"{x:608,y:449,t:1528140084475};\\\", \\\"{x:610,y:449,t:1528140084724};\\\", \\\"{x:610,y:450,t:1528140084740};\\\", \\\"{x:609,y:461,t:1528140084748};\\\", \\\"{x:608,y:474,t:1528140084759};\\\", \\\"{x:604,y:500,t:1528140084775};\\\", \\\"{x:598,y:525,t:1528140084793};\\\", \\\"{x:595,y:543,t:1528140084809};\\\", \\\"{x:590,y:568,t:1528140084825};\\\", \\\"{x:589,y:587,t:1528140084842};\\\", \\\"{x:584,y:602,t:1528140084859};\\\", \\\"{x:579,y:611,t:1528140084875};\\\", \\\"{x:572,y:621,t:1528140084892};\\\", \\\"{x:567,y:628,t:1528140084909};\\\", \\\"{x:560,y:635,t:1528140084925};\\\", \\\"{x:557,y:640,t:1528140084942};\\\", \\\"{x:555,y:645,t:1528140084958};\\\", \\\"{x:555,y:646,t:1528140084996};\\\", \\\"{x:555,y:647,t:1528140085008};\\\", \\\"{x:554,y:648,t:1528140085605};\\\", \\\"{x:554,y:649,t:1528140085612};\\\", \\\"{x:554,y:652,t:1528140085626};\\\", \\\"{x:554,y:655,t:1528140085643};\\\", \\\"{x:551,y:658,t:1528140085660};\\\", \\\"{x:548,y:664,t:1528140085676};\\\", \\\"{x:547,y:668,t:1528140085694};\\\", \\\"{x:546,y:669,t:1528140085709};\\\", \\\"{x:542,y:674,t:1528140085726};\\\", \\\"{x:541,y:675,t:1528140085742};\\\", \\\"{x:540,y:677,t:1528140085759};\\\", \\\"{x:539,y:677,t:1528140085777};\\\", \\\"{x:538,y:679,t:1528140085793};\\\", \\\"{x:538,y:680,t:1528140085820};\\\", \\\"{x:537,y:680,t:1528140085828};\\\", \\\"{x:537,y:681,t:1528140085843};\\\", \\\"{x:536,y:681,t:1528140085860};\\\" ] }, { \\\"rt\\\": 4927, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 116592, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"G27Q3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:541,y:681,t:1528140088317};\\\", \\\"{x:542,y:681,t:1528140088331};\\\", \\\"{x:544,y:683,t:1528140088347};\\\", \\\"{x:543,y:683,t:1528140090653};\\\", \\\"{x:541,y:683,t:1528140090668};\\\", \\\"{x:536,y:682,t:1528140090685};\\\", \\\"{x:531,y:678,t:1528140090702};\\\", \\\"{x:522,y:674,t:1528140090719};\\\", \\\"{x:518,y:671,t:1528140090736};\\\", \\\"{x:509,y:664,t:1528140090754};\\\", \\\"{x:499,y:655,t:1528140090769};\\\", \\\"{x:490,y:645,t:1528140090785};\\\", \\\"{x:481,y:630,t:1528140090802};\\\", \\\"{x:474,y:616,t:1528140090814};\\\", \\\"{x:460,y:591,t:1528140090830};\\\", \\\"{x:455,y:571,t:1528140090848};\\\", \\\"{x:452,y:559,t:1528140090863};\\\", \\\"{x:450,y:551,t:1528140090880};\\\", \\\"{x:449,y:544,t:1528140090897};\\\", \\\"{x:449,y:539,t:1528140090913};\\\", \\\"{x:448,y:532,t:1528140090929};\\\", \\\"{x:448,y:524,t:1528140090947};\\\", \\\"{x:451,y:507,t:1528140090964};\\\", \\\"{x:458,y:495,t:1528140090981};\\\", \\\"{x:467,y:487,t:1528140090997};\\\", \\\"{x:477,y:482,t:1528140091013};\\\", \\\"{x:489,y:479,t:1528140091030};\\\", \\\"{x:497,y:478,t:1528140091047};\\\", \\\"{x:504,y:475,t:1528140091065};\\\", \\\"{x:513,y:472,t:1528140091080};\\\", \\\"{x:522,y:470,t:1528140091098};\\\", \\\"{x:534,y:466,t:1528140091113};\\\", \\\"{x:548,y:464,t:1528140091130};\\\", \\\"{x:571,y:461,t:1528140091147};\\\", \\\"{x:591,y:460,t:1528140091163};\\\", \\\"{x:605,y:453,t:1528140091180};\\\", \\\"{x:606,y:453,t:1528140091197};\\\", \\\"{x:608,y:453,t:1528140091214};\\\", \\\"{x:609,y:453,t:1528140091285};\\\", \\\"{x:609,y:452,t:1528140091317};\\\", \\\"{x:609,y:459,t:1528140091668};\\\", \\\"{x:604,y:470,t:1528140091682};\\\", \\\"{x:596,y:494,t:1528140091698};\\\", \\\"{x:585,y:525,t:1528140091715};\\\", \\\"{x:577,y:555,t:1528140091732};\\\", \\\"{x:572,y:576,t:1528140091747};\\\", \\\"{x:568,y:605,t:1528140091765};\\\", \\\"{x:563,y:621,t:1528140091781};\\\", \\\"{x:562,y:628,t:1528140091797};\\\", \\\"{x:562,y:637,t:1528140091814};\\\", \\\"{x:562,y:653,t:1528140091831};\\\", \\\"{x:561,y:666,t:1528140091847};\\\", \\\"{x:557,y:677,t:1528140091865};\\\", \\\"{x:554,y:680,t:1528140091881};\\\", \\\"{x:554,y:681,t:1528140092021};\\\" ] }, { \\\"rt\\\": 10551, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 128424, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"G27Q3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:553,y:681,t:1528140094475};\\\", \\\"{x:553,y:678,t:1528140094483};\\\", \\\"{x:553,y:676,t:1528140094499};\\\", \\\"{x:551,y:670,t:1528140094516};\\\", \\\"{x:550,y:666,t:1528140094534};\\\", \\\"{x:546,y:656,t:1528140094550};\\\", \\\"{x:542,y:650,t:1528140094567};\\\", \\\"{x:540,y:645,t:1528140094583};\\\", \\\"{x:537,y:643,t:1528140094599};\\\", \\\"{x:533,y:638,t:1528140094616};\\\", \\\"{x:531,y:637,t:1528140094633};\\\", \\\"{x:530,y:636,t:1528140094686};\\\", \\\"{x:531,y:636,t:1528140101278};\\\", \\\"{x:536,y:634,t:1528140101296};\\\", \\\"{x:537,y:633,t:1528140101312};\\\", \\\"{x:543,y:630,t:1528140101329};\\\", \\\"{x:544,y:629,t:1528140101346};\\\", \\\"{x:545,y:624,t:1528140101362};\\\", \\\"{x:547,y:622,t:1528140101380};\\\", \\\"{x:549,y:622,t:1528140101397};\\\", \\\"{x:551,y:622,t:1528140101412};\\\", \\\"{x:560,y:617,t:1528140101429};\\\", \\\"{x:568,y:612,t:1528140101445};\\\", \\\"{x:571,y:608,t:1528140101462};\\\", \\\"{x:574,y:605,t:1528140101479};\\\", \\\"{x:575,y:602,t:1528140101496};\\\", \\\"{x:577,y:599,t:1528140101511};\\\", \\\"{x:581,y:592,t:1528140101529};\\\", \\\"{x:588,y:583,t:1528140101546};\\\", \\\"{x:594,y:571,t:1528140101562};\\\", \\\"{x:601,y:561,t:1528140101579};\\\", \\\"{x:606,y:554,t:1528140101596};\\\", \\\"{x:608,y:550,t:1528140101615};\\\", \\\"{x:608,y:548,t:1528140101632};\\\", \\\"{x:608,y:545,t:1528140101648};\\\", \\\"{x:601,y:543,t:1528140101665};\\\", \\\"{x:572,y:539,t:1528140101682};\\\", \\\"{x:505,y:530,t:1528140101698};\\\", \\\"{x:432,y:518,t:1528140101715};\\\", \\\"{x:394,y:517,t:1528140101732};\\\", \\\"{x:322,y:508,t:1528140101748};\\\", \\\"{x:273,y:499,t:1528140101765};\\\", \\\"{x:263,y:497,t:1528140101783};\\\", \\\"{x:261,y:496,t:1528140101798};\\\", \\\"{x:265,y:497,t:1528140101958};\\\", \\\"{x:267,y:498,t:1528140101966};\\\", \\\"{x:270,y:501,t:1528140101982};\\\", \\\"{x:274,y:503,t:1528140102000};\\\", \\\"{x:278,y:507,t:1528140102016};\\\", \\\"{x:286,y:519,t:1528140102033};\\\", \\\"{x:302,y:536,t:1528140102049};\\\", \\\"{x:319,y:553,t:1528140102065};\\\", \\\"{x:335,y:569,t:1528140102082};\\\", \\\"{x:344,y:579,t:1528140102100};\\\", \\\"{x:348,y:582,t:1528140102115};\\\", \\\"{x:351,y:584,t:1528140102132};\\\", \\\"{x:352,y:584,t:1528140102149};\\\", \\\"{x:354,y:584,t:1528140102205};\\\", \\\"{x:358,y:584,t:1528140102221};\\\", \\\"{x:361,y:584,t:1528140102237};\\\", \\\"{x:362,y:584,t:1528140102253};\\\", \\\"{x:364,y:584,t:1528140102269};\\\", \\\"{x:365,y:583,t:1528140102294};\\\", \\\"{x:367,y:583,t:1528140102302};\\\", \\\"{x:368,y:582,t:1528140102317};\\\", \\\"{x:370,y:580,t:1528140102333};\\\", \\\"{x:373,y:580,t:1528140102349};\\\", \\\"{x:377,y:578,t:1528140102367};\\\", \\\"{x:378,y:577,t:1528140102382};\\\", \\\"{x:379,y:576,t:1528140102420};\\\", \\\"{x:381,y:575,t:1528140102453};\\\", \\\"{x:382,y:573,t:1528140102466};\\\", \\\"{x:384,y:571,t:1528140102481};\\\", \\\"{x:385,y:570,t:1528140102499};\\\", \\\"{x:385,y:569,t:1528140102515};\\\", \\\"{x:386,y:569,t:1528140102532};\\\", \\\"{x:386,y:563,t:1528140102749};\\\", \\\"{x:386,y:552,t:1528140102766};\\\", \\\"{x:385,y:545,t:1528140102783};\\\", \\\"{x:384,y:539,t:1528140102799};\\\", \\\"{x:384,y:532,t:1528140102816};\\\", \\\"{x:384,y:527,t:1528140102833};\\\", \\\"{x:384,y:522,t:1528140102849};\\\", \\\"{x:384,y:519,t:1528140102866};\\\", \\\"{x:385,y:514,t:1528140102883};\\\", \\\"{x:385,y:513,t:1528140102898};\\\", \\\"{x:385,y:512,t:1528140102916};\\\", \\\"{x:385,y:506,t:1528140102934};\\\", \\\"{x:385,y:504,t:1528140102957};\\\", \\\"{x:385,y:503,t:1528140102966};\\\", \\\"{x:385,y:501,t:1528140102983};\\\", \\\"{x:385,y:499,t:1528140102999};\\\", \\\"{x:384,y:498,t:1528140103017};\\\", \\\"{x:384,y:497,t:1528140103037};\\\", \\\"{x:382,y:497,t:1528140103269};\\\", \\\"{x:378,y:498,t:1528140103283};\\\", \\\"{x:377,y:507,t:1528140103300};\\\", \\\"{x:379,y:526,t:1528140103316};\\\", \\\"{x:385,y:556,t:1528140103334};\\\", \\\"{x:391,y:583,t:1528140103350};\\\", \\\"{x:398,y:599,t:1528140103367};\\\", \\\"{x:414,y:619,t:1528140103384};\\\", \\\"{x:421,y:634,t:1528140103400};\\\", \\\"{x:426,y:643,t:1528140103416};\\\", \\\"{x:427,y:647,t:1528140103433};\\\", \\\"{x:428,y:648,t:1528140103450};\\\", \\\"{x:430,y:650,t:1528140103466};\\\", \\\"{x:430,y:652,t:1528140103483};\\\", \\\"{x:431,y:654,t:1528140103500};\\\", \\\"{x:433,y:657,t:1528140103516};\\\", \\\"{x:435,y:660,t:1528140103549};\\\", \\\"{x:436,y:661,t:1528140103557};\\\", \\\"{x:438,y:663,t:1528140103567};\\\", \\\"{x:439,y:664,t:1528140103583};\\\", \\\"{x:440,y:666,t:1528140103600};\\\", \\\"{x:443,y:667,t:1528140103617};\\\", \\\"{x:446,y:669,t:1528140103633};\\\", \\\"{x:452,y:673,t:1528140103651};\\\", \\\"{x:452,y:676,t:1528140103668};\\\", \\\"{x:458,y:679,t:1528140103683};\\\", \\\"{x:461,y:681,t:1528140103700};\\\", \\\"{x:463,y:681,t:1528140103717};\\\", \\\"{x:464,y:681,t:1528140103733};\\\", \\\"{x:465,y:681,t:1528140103758};\\\", \\\"{x:466,y:681,t:1528140103773};\\\", \\\"{x:468,y:681,t:1528140103789};\\\", \\\"{x:469,y:681,t:1528140103800};\\\", \\\"{x:470,y:681,t:1528140103817};\\\", \\\"{x:472,y:680,t:1528140103835};\\\", \\\"{x:473,y:680,t:1528140104333};\\\", \\\"{x:474,y:680,t:1528140104365};\\\", \\\"{x:475,y:680,t:1528140104382};\\\", \\\"{x:476,y:680,t:1528140104422};\\\", \\\"{x:477,y:680,t:1528140104445};\\\", \\\"{x:478,y:680,t:1528140104542};\\\", \\\"{x:478,y:681,t:1528140104582};\\\", \\\"{x:478,y:683,t:1528140104630};\\\" ] }, { \\\"rt\\\": 8844, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 138480, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"G27Q3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 3, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:478,y:684,t:1528140105949};\\\", \\\"{x:480,y:683,t:1528140106166};\\\", \\\"{x:483,y:681,t:1528140106174};\\\", \\\"{x:488,y:677,t:1528140106188};\\\", \\\"{x:491,y:673,t:1528140106204};\\\", \\\"{x:499,y:668,t:1528140106220};\\\", \\\"{x:508,y:659,t:1528140106238};\\\", \\\"{x:515,y:653,t:1528140106253};\\\", \\\"{x:520,y:648,t:1528140106269};\\\", \\\"{x:528,y:636,t:1528140106285};\\\", \\\"{x:535,y:628,t:1528140106302};\\\", \\\"{x:540,y:625,t:1528140106319};\\\", \\\"{x:543,y:619,t:1528140106334};\\\", \\\"{x:547,y:611,t:1528140106352};\\\", \\\"{x:547,y:602,t:1528140106369};\\\", \\\"{x:549,y:598,t:1528140106385};\\\", \\\"{x:551,y:590,t:1528140106402};\\\", \\\"{x:551,y:584,t:1528140106419};\\\", \\\"{x:551,y:578,t:1528140106436};\\\", \\\"{x:551,y:573,t:1528140106452};\\\", \\\"{x:551,y:567,t:1528140106469};\\\", \\\"{x:549,y:561,t:1528140106485};\\\", \\\"{x:546,y:558,t:1528140106501};\\\", \\\"{x:544,y:555,t:1528140106519};\\\", \\\"{x:541,y:553,t:1528140106535};\\\", \\\"{x:539,y:552,t:1528140106552};\\\", \\\"{x:538,y:551,t:1528140106569};\\\", \\\"{x:538,y:550,t:1528140106586};\\\", \\\"{x:538,y:549,t:1528140106606};\\\", \\\"{x:538,y:548,t:1528140106637};\\\", \\\"{x:538,y:546,t:1528140106655};\\\", \\\"{x:540,y:545,t:1528140106669};\\\", \\\"{x:541,y:545,t:1528140106686};\\\", \\\"{x:543,y:545,t:1528140106708};\\\", \\\"{x:543,y:544,t:1528140106719};\\\", \\\"{x:544,y:542,t:1528140107054};\\\", \\\"{x:545,y:542,t:1528140107069};\\\", \\\"{x:547,y:541,t:1528140107086};\\\", \\\"{x:551,y:540,t:1528140107104};\\\", \\\"{x:551,y:538,t:1528140107119};\\\", \\\"{x:560,y:534,t:1528140107136};\\\", \\\"{x:568,y:529,t:1528140107152};\\\", \\\"{x:574,y:525,t:1528140107169};\\\", \\\"{x:578,y:524,t:1528140107186};\\\", \\\"{x:581,y:523,t:1528140107203};\\\", \\\"{x:578,y:523,t:1528140107269};\\\", \\\"{x:569,y:523,t:1528140107286};\\\", \\\"{x:567,y:523,t:1528140107304};\\\", \\\"{x:561,y:523,t:1528140107320};\\\", \\\"{x:558,y:523,t:1528140107336};\\\", \\\"{x:562,y:519,t:1528140107381};\\\", \\\"{x:571,y:514,t:1528140107390};\\\", \\\"{x:581,y:509,t:1528140107404};\\\", \\\"{x:631,y:496,t:1528140107421};\\\", \\\"{x:673,y:486,t:1528140107436};\\\", \\\"{x:728,y:477,t:1528140107453};\\\", \\\"{x:767,y:472,t:1528140107470};\\\", \\\"{x:790,y:470,t:1528140107486};\\\", \\\"{x:810,y:470,t:1528140107503};\\\", \\\"{x:826,y:470,t:1528140107520};\\\", \\\"{x:840,y:470,t:1528140107536};\\\", \\\"{x:848,y:470,t:1528140107552};\\\", \\\"{x:849,y:470,t:1528140107570};\\\", \\\"{x:851,y:470,t:1528140107612};\\\", \\\"{x:852,y:470,t:1528140107621};\\\", \\\"{x:855,y:470,t:1528140107637};\\\", \\\"{x:859,y:469,t:1528140107653};\\\", \\\"{x:862,y:468,t:1528140107671};\\\", \\\"{x:860,y:468,t:1528140107774};\\\", \\\"{x:858,y:468,t:1528140107787};\\\", \\\"{x:855,y:467,t:1528140107804};\\\", \\\"{x:854,y:466,t:1528140107821};\\\", \\\"{x:852,y:464,t:1528140107838};\\\", \\\"{x:851,y:464,t:1528140107861};\\\", \\\"{x:851,y:463,t:1528140107870};\\\", \\\"{x:849,y:461,t:1528140107887};\\\", \\\"{x:847,y:456,t:1528140107904};\\\", \\\"{x:842,y:451,t:1528140107920};\\\", \\\"{x:838,y:448,t:1528140107937};\\\", \\\"{x:835,y:445,t:1528140107954};\\\", \\\"{x:833,y:444,t:1528140107974};\\\", \\\"{x:830,y:444,t:1528140108236};\\\", \\\"{x:815,y:449,t:1528140108254};\\\", \\\"{x:792,y:466,t:1528140108270};\\\", \\\"{x:763,y:485,t:1528140108287};\\\", \\\"{x:724,y:506,t:1528140108304};\\\", \\\"{x:673,y:530,t:1528140108320};\\\", \\\"{x:637,y:553,t:1528140108337};\\\", \\\"{x:611,y:574,t:1528140108354};\\\", \\\"{x:584,y:592,t:1528140108371};\\\", \\\"{x:568,y:607,t:1528140108387};\\\", \\\"{x:554,y:624,t:1528140108404};\\\", \\\"{x:551,y:632,t:1528140108420};\\\", \\\"{x:541,y:647,t:1528140108437};\\\", \\\"{x:537,y:656,t:1528140108454};\\\", \\\"{x:534,y:660,t:1528140108471};\\\", \\\"{x:527,y:666,t:1528140108487};\\\", \\\"{x:524,y:677,t:1528140108505};\\\", \\\"{x:519,y:686,t:1528140108521};\\\", \\\"{x:515,y:692,t:1528140108537};\\\", \\\"{x:514,y:696,t:1528140108554};\\\", \\\"{x:512,y:702,t:1528140108571};\\\", \\\"{x:510,y:707,t:1528140108587};\\\", \\\"{x:508,y:712,t:1528140108605};\\\", \\\"{x:505,y:719,t:1528140108620};\\\", \\\"{x:505,y:721,t:1528140108645};\\\", \\\"{x:503,y:723,t:1528140108910};\\\", \\\"{x:505,y:716,t:1528140108925};\\\", \\\"{x:510,y:711,t:1528140108937};\\\", \\\"{x:527,y:695,t:1528140108956};\\\", \\\"{x:569,y:672,t:1528140108972};\\\", \\\"{x:658,y:645,t:1528140108987};\\\", \\\"{x:741,y:618,t:1528140109005};\\\", \\\"{x:817,y:581,t:1528140109021};\\\", \\\"{x:838,y:567,t:1528140109039};\\\", \\\"{x:851,y:550,t:1528140109054};\\\", \\\"{x:861,y:535,t:1528140109072};\\\", \\\"{x:866,y:524,t:1528140109087};\\\", \\\"{x:867,y:519,t:1528140109104};\\\", \\\"{x:869,y:514,t:1528140109121};\\\", \\\"{x:869,y:512,t:1528140109137};\\\", \\\"{x:870,y:508,t:1528140109154};\\\", \\\"{x:871,y:506,t:1528140109171};\\\", \\\"{x:873,y:504,t:1528140109188};\\\", \\\"{x:873,y:502,t:1528140109204};\\\", \\\"{x:874,y:500,t:1528140109221};\\\", \\\"{x:873,y:500,t:1528140109469};\\\", \\\"{x:873,y:501,t:1528140109493};\\\", \\\"{x:872,y:500,t:1528140109646};\\\", \\\"{x:869,y:493,t:1528140109655};\\\", \\\"{x:865,y:486,t:1528140109671};\\\", \\\"{x:864,y:479,t:1528140109687};\\\", \\\"{x:864,y:471,t:1528140109705};\\\", \\\"{x:864,y:462,t:1528140109721};\\\", \\\"{x:864,y:458,t:1528140109738};\\\", \\\"{x:864,y:455,t:1528140109755};\\\", \\\"{x:864,y:453,t:1528140109771};\\\", \\\"{x:864,y:452,t:1528140109821};\\\", \\\"{x:864,y:450,t:1528140109868};\\\", \\\"{x:863,y:448,t:1528140109885};\\\", \\\"{x:860,y:446,t:1528140109893};\\\", \\\"{x:859,y:446,t:1528140109905};\\\", \\\"{x:854,y:445,t:1528140109922};\\\", \\\"{x:845,y:444,t:1528140109939};\\\", \\\"{x:839,y:442,t:1528140109956};\\\", \\\"{x:835,y:441,t:1528140109972};\\\", \\\"{x:833,y:441,t:1528140109988};\\\", \\\"{x:832,y:441,t:1528140110069};\\\", \\\"{x:831,y:441,t:1528140110078};\\\", \\\"{x:830,y:441,t:1528140110293};\\\", \\\"{x:830,y:443,t:1528140110305};\\\", \\\"{x:831,y:450,t:1528140110322};\\\", \\\"{x:832,y:458,t:1528140110338};\\\", \\\"{x:834,y:466,t:1528140110356};\\\", \\\"{x:835,y:470,t:1528140110372};\\\", \\\"{x:838,y:478,t:1528140110389};\\\", \\\"{x:838,y:479,t:1528140110405};\\\", \\\"{x:838,y:480,t:1528140110422};\\\", \\\"{x:839,y:482,t:1528140110621};\\\", \\\"{x:840,y:486,t:1528140110629};\\\", \\\"{x:844,y:495,t:1528140110640};\\\", \\\"{x:851,y:510,t:1528140110657};\\\", \\\"{x:859,y:519,t:1528140110673};\\\", \\\"{x:876,y:536,t:1528140110690};\\\", \\\"{x:890,y:551,t:1528140110706};\\\", \\\"{x:903,y:558,t:1528140110722};\\\", \\\"{x:908,y:565,t:1528140110739};\\\", \\\"{x:913,y:569,t:1528140110756};\\\", \\\"{x:921,y:572,t:1528140110772};\\\", \\\"{x:939,y:577,t:1528140110788};\\\", \\\"{x:944,y:580,t:1528140110806};\\\", \\\"{x:977,y:581,t:1528140110822};\\\", \\\"{x:1035,y:581,t:1528140110839};\\\", \\\"{x:1116,y:581,t:1528140110855};\\\", \\\"{x:1205,y:581,t:1528140110873};\\\", \\\"{x:1277,y:581,t:1528140110889};\\\", \\\"{x:1337,y:586,t:1528140110906};\\\", \\\"{x:1389,y:595,t:1528140110922};\\\", \\\"{x:1461,y:616,t:1528140110940};\\\", \\\"{x:1489,y:629,t:1528140110957};\\\", \\\"{x:1505,y:639,t:1528140110973};\\\", \\\"{x:1520,y:651,t:1528140110989};\\\", \\\"{x:1523,y:653,t:1528140111006};\\\", \\\"{x:1524,y:658,t:1528140111023};\\\", \\\"{x:1524,y:665,t:1528140111040};\\\", \\\"{x:1524,y:673,t:1528140111057};\\\", \\\"{x:1516,y:679,t:1528140111072};\\\", \\\"{x:1514,y:681,t:1528140111089};\\\", \\\"{x:1502,y:682,t:1528140111106};\\\", \\\"{x:1487,y:682,t:1528140111123};\\\", \\\"{x:1462,y:682,t:1528140111140};\\\", \\\"{x:1410,y:670,t:1528140111157};\\\", \\\"{x:1393,y:666,t:1528140111173};\\\", \\\"{x:1355,y:655,t:1528140111190};\\\", \\\"{x:1349,y:653,t:1528140111207};\\\", \\\"{x:1349,y:652,t:1528140111224};\\\", \\\"{x:1348,y:651,t:1528140111240};\\\", \\\"{x:1347,y:649,t:1528140111384};\\\", \\\"{x:1347,y:647,t:1528140111413};\\\", \\\"{x:1347,y:646,t:1528140111428};\\\", \\\"{x:1346,y:645,t:1528140111444};\\\", \\\"{x:1346,y:643,t:1528140111476};\\\", \\\"{x:1345,y:643,t:1528140111489};\\\", \\\"{x:1344,y:642,t:1528140111506};\\\", \\\"{x:1343,y:641,t:1528140111524};\\\", \\\"{x:1342,y:640,t:1528140111541};\\\", \\\"{x:1341,y:639,t:1528140111557};\\\", \\\"{x:1340,y:638,t:1528140111622};\\\", \\\"{x:1340,y:637,t:1528140111646};\\\", \\\"{x:1340,y:636,t:1528140111702};\\\", \\\"{x:1339,y:636,t:1528140111710};\\\", \\\"{x:1338,y:635,t:1528140111724};\\\", \\\"{x:1338,y:633,t:1528140111741};\\\", \\\"{x:1338,y:632,t:1528140111758};\\\", \\\"{x:1338,y:631,t:1528140111774};\\\", \\\"{x:1339,y:629,t:1528140111797};\\\", \\\"{x:1340,y:627,t:1528140111821};\\\", \\\"{x:1341,y:627,t:1528140111830};\\\", \\\"{x:1341,y:625,t:1528140111861};\\\", \\\"{x:1342,y:623,t:1528140111878};\\\", \\\"{x:1343,y:623,t:1528140111891};\\\", \\\"{x:1343,y:622,t:1528140111907};\\\", \\\"{x:1343,y:621,t:1528140111924};\\\", \\\"{x:1343,y:620,t:1528140111949};\\\", \\\"{x:1344,y:620,t:1528140111958};\\\", \\\"{x:1343,y:618,t:1528140112134};\\\", \\\"{x:1338,y:618,t:1528140112141};\\\", \\\"{x:1321,y:621,t:1528140112158};\\\", \\\"{x:1300,y:622,t:1528140112174};\\\", \\\"{x:1236,y:613,t:1528140112191};\\\", \\\"{x:1136,y:599,t:1528140112208};\\\", \\\"{x:1048,y:592,t:1528140112224};\\\", \\\"{x:992,y:584,t:1528140112240};\\\", \\\"{x:892,y:568,t:1528140112259};\\\", \\\"{x:820,y:558,t:1528140112273};\\\", \\\"{x:772,y:550,t:1528140112290};\\\", \\\"{x:755,y:546,t:1528140112309};\\\", \\\"{x:736,y:544,t:1528140112324};\\\", \\\"{x:729,y:544,t:1528140112341};\\\", \\\"{x:726,y:544,t:1528140112358};\\\", \\\"{x:726,y:543,t:1528140112429};\\\", \\\"{x:725,y:542,t:1528140112441};\\\", \\\"{x:723,y:541,t:1528140112470};\\\", \\\"{x:721,y:539,t:1528140112486};\\\", \\\"{x:710,y:536,t:1528140112507};\\\", \\\"{x:703,y:528,t:1528140112524};\\\", \\\"{x:687,y:520,t:1528140112540};\\\", \\\"{x:673,y:515,t:1528140112557};\\\", \\\"{x:663,y:513,t:1528140112574};\\\", \\\"{x:658,y:512,t:1528140112590};\\\", \\\"{x:656,y:511,t:1528140112607};\\\", \\\"{x:655,y:511,t:1528140112629};\\\", \\\"{x:654,y:511,t:1528140112640};\\\", \\\"{x:652,y:511,t:1528140112657};\\\", \\\"{x:651,y:511,t:1528140112675};\\\", \\\"{x:647,y:511,t:1528140112690};\\\", \\\"{x:646,y:511,t:1528140112725};\\\", \\\"{x:645,y:510,t:1528140112750};\\\", \\\"{x:648,y:508,t:1528140112758};\\\", \\\"{x:657,y:505,t:1528140112774};\\\", \\\"{x:672,y:497,t:1528140112790};\\\", \\\"{x:686,y:492,t:1528140112807};\\\", \\\"{x:704,y:490,t:1528140112824};\\\", \\\"{x:710,y:490,t:1528140112840};\\\", \\\"{x:729,y:490,t:1528140112858};\\\", \\\"{x:757,y:493,t:1528140112875};\\\", \\\"{x:787,y:495,t:1528140112890};\\\", \\\"{x:809,y:498,t:1528140112907};\\\", \\\"{x:824,y:499,t:1528140112924};\\\", \\\"{x:830,y:500,t:1528140112940};\\\", \\\"{x:831,y:500,t:1528140112958};\\\", \\\"{x:832,y:501,t:1528140112981};\\\", \\\"{x:832,y:502,t:1528140112991};\\\", \\\"{x:829,y:503,t:1528140113008};\\\", \\\"{x:826,y:506,t:1528140113024};\\\", \\\"{x:825,y:506,t:1528140113041};\\\", \\\"{x:825,y:507,t:1528140113058};\\\", \\\"{x:826,y:505,t:1528140113181};\\\", \\\"{x:828,y:503,t:1528140113191};\\\", \\\"{x:831,y:498,t:1528140113208};\\\", \\\"{x:834,y:497,t:1528140113224};\\\", \\\"{x:834,y:496,t:1528140113324};\\\", \\\"{x:834,y:496,t:1528140113395};\\\", \\\"{x:831,y:496,t:1528140113408};\\\", \\\"{x:818,y:500,t:1528140113425};\\\", \\\"{x:801,y:509,t:1528140113441};\\\", \\\"{x:779,y:522,t:1528140113458};\\\", \\\"{x:754,y:540,t:1528140113475};\\\", \\\"{x:737,y:555,t:1528140113492};\\\", \\\"{x:713,y:567,t:1528140113509};\\\", \\\"{x:689,y:582,t:1528140113525};\\\", \\\"{x:668,y:595,t:1528140113542};\\\", \\\"{x:655,y:606,t:1528140113559};\\\", \\\"{x:651,y:610,t:1528140113574};\\\", \\\"{x:647,y:615,t:1528140113592};\\\", \\\"{x:643,y:619,t:1528140113609};\\\", \\\"{x:635,y:631,t:1528140113624};\\\", \\\"{x:624,y:648,t:1528140113642};\\\", \\\"{x:613,y:658,t:1528140113658};\\\", \\\"{x:599,y:667,t:1528140113676};\\\", \\\"{x:587,y:672,t:1528140113692};\\\", \\\"{x:578,y:676,t:1528140113708};\\\", \\\"{x:577,y:677,t:1528140113725};\\\", \\\"{x:574,y:679,t:1528140113742};\\\", \\\"{x:570,y:680,t:1528140113759};\\\", \\\"{x:567,y:680,t:1528140113775};\\\", \\\"{x:562,y:680,t:1528140113793};\\\", \\\"{x:559,y:680,t:1528140113809};\\\", \\\"{x:557,y:680,t:1528140113825};\\\", \\\"{x:556,y:680,t:1528140113841};\\\", \\\"{x:555,y:680,t:1528140113925};\\\", \\\"{x:553,y:682,t:1528140113941};\\\", \\\"{x:552,y:682,t:1528140114574};\\\" ] }, { \\\"rt\\\": 17198, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 156930, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"G27Q3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -O -5-D -N -02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:551,y:680,t:1528140115925};\\\", \\\"{x:548,y:676,t:1528140115932};\\\", \\\"{x:547,y:675,t:1528140115943};\\\", \\\"{x:545,y:674,t:1528140115961};\\\", \\\"{x:544,y:672,t:1528140116012};\\\", \\\"{x:542,y:671,t:1528140116028};\\\", \\\"{x:542,y:670,t:1528140116044};\\\", \\\"{x:541,y:669,t:1528140116061};\\\", \\\"{x:541,y:668,t:1528140116076};\\\", \\\"{x:539,y:667,t:1528140116093};\\\", \\\"{x:539,y:661,t:1528140117567};\\\", \\\"{x:571,y:659,t:1528140117579};\\\", \\\"{x:605,y:644,t:1528140117594};\\\", \\\"{x:683,y:629,t:1528140117612};\\\", \\\"{x:789,y:625,t:1528140117628};\\\", \\\"{x:950,y:623,t:1528140117645};\\\", \\\"{x:1067,y:641,t:1528140117661};\\\", \\\"{x:1179,y:662,t:1528140117677};\\\", \\\"{x:1281,y:677,t:1528140117695};\\\", \\\"{x:1370,y:700,t:1528140117712};\\\", \\\"{x:1444,y:719,t:1528140117727};\\\", \\\"{x:1511,y:740,t:1528140117744};\\\", \\\"{x:1573,y:772,t:1528140117762};\\\", \\\"{x:1612,y:797,t:1528140117779};\\\", \\\"{x:1651,y:820,t:1528140117795};\\\", \\\"{x:1676,y:837,t:1528140117812};\\\", \\\"{x:1741,y:869,t:1528140117829};\\\", \\\"{x:1758,y:877,t:1528140117846};\\\", \\\"{x:1773,y:888,t:1528140117862};\\\", \\\"{x:1780,y:894,t:1528140117879};\\\", \\\"{x:1783,y:897,t:1528140117895};\\\", \\\"{x:1782,y:897,t:1528140118022};\\\", \\\"{x:1779,y:897,t:1528140118029};\\\", \\\"{x:1768,y:897,t:1528140118045};\\\", \\\"{x:1755,y:895,t:1528140118063};\\\", \\\"{x:1747,y:888,t:1528140118079};\\\", \\\"{x:1736,y:882,t:1528140118095};\\\", \\\"{x:1726,y:876,t:1528140118112};\\\", \\\"{x:1721,y:873,t:1528140118128};\\\", \\\"{x:1714,y:871,t:1528140118145};\\\", \\\"{x:1704,y:867,t:1528140118162};\\\", \\\"{x:1699,y:866,t:1528140118179};\\\", \\\"{x:1693,y:864,t:1528140118195};\\\", \\\"{x:1689,y:864,t:1528140118212};\\\", \\\"{x:1684,y:862,t:1528140118229};\\\", \\\"{x:1683,y:862,t:1528140118246};\\\", \\\"{x:1682,y:862,t:1528140118262};\\\", \\\"{x:1678,y:860,t:1528140118280};\\\", \\\"{x:1676,y:860,t:1528140118296};\\\", \\\"{x:1674,y:860,t:1528140118318};\\\", \\\"{x:1672,y:860,t:1528140118366};\\\", \\\"{x:1671,y:860,t:1528140118405};\\\", \\\"{x:1669,y:859,t:1528140118453};\\\", \\\"{x:1667,y:859,t:1528140119252};\\\", \\\"{x:1661,y:856,t:1528140119263};\\\", \\\"{x:1649,y:851,t:1528140119279};\\\", \\\"{x:1630,y:847,t:1528140119296};\\\", \\\"{x:1609,y:840,t:1528140119313};\\\", \\\"{x:1598,y:837,t:1528140119329};\\\", \\\"{x:1579,y:831,t:1528140119345};\\\", \\\"{x:1567,y:827,t:1528140119363};\\\", \\\"{x:1556,y:825,t:1528140119380};\\\", \\\"{x:1543,y:821,t:1528140119396};\\\", \\\"{x:1533,y:820,t:1528140119412};\\\", \\\"{x:1524,y:820,t:1528140119430};\\\", \\\"{x:1515,y:816,t:1528140119446};\\\", \\\"{x:1505,y:815,t:1528140119463};\\\", \\\"{x:1496,y:811,t:1528140119480};\\\", \\\"{x:1484,y:806,t:1528140119496};\\\", \\\"{x:1472,y:805,t:1528140119513};\\\", \\\"{x:1461,y:802,t:1528140119530};\\\", \\\"{x:1447,y:802,t:1528140119547};\\\", \\\"{x:1434,y:801,t:1528140119563};\\\", \\\"{x:1426,y:798,t:1528140119581};\\\", \\\"{x:1413,y:796,t:1528140119597};\\\", \\\"{x:1407,y:794,t:1528140119613};\\\", \\\"{x:1405,y:794,t:1528140119629};\\\", \\\"{x:1404,y:794,t:1528140119647};\\\", \\\"{x:1404,y:793,t:1528140119663};\\\", \\\"{x:1402,y:793,t:1528140119680};\\\", \\\"{x:1401,y:793,t:1528140119742};\\\", \\\"{x:1399,y:793,t:1528140119910};\\\", \\\"{x:1398,y:793,t:1528140119927};\\\", \\\"{x:1396,y:793,t:1528140119949};\\\", \\\"{x:1394,y:793,t:1528140119974};\\\", \\\"{x:1392,y:793,t:1528140119990};\\\", \\\"{x:1391,y:793,t:1528140119998};\\\", \\\"{x:1388,y:794,t:1528140120013};\\\", \\\"{x:1386,y:794,t:1528140120031};\\\", \\\"{x:1384,y:795,t:1528140120070};\\\", \\\"{x:1384,y:796,t:1528140120085};\\\", \\\"{x:1382,y:797,t:1528140120097};\\\", \\\"{x:1381,y:798,t:1528140120114};\\\", \\\"{x:1377,y:800,t:1528140120130};\\\", \\\"{x:1375,y:801,t:1528140120147};\\\", \\\"{x:1374,y:802,t:1528140120165};\\\", \\\"{x:1373,y:802,t:1528140120180};\\\", \\\"{x:1372,y:803,t:1528140120198};\\\", \\\"{x:1371,y:806,t:1528140120214};\\\", \\\"{x:1371,y:807,t:1528140120230};\\\", \\\"{x:1369,y:808,t:1528140120247};\\\", \\\"{x:1369,y:810,t:1528140120264};\\\", \\\"{x:1369,y:812,t:1528140120281};\\\", \\\"{x:1369,y:813,t:1528140120301};\\\", \\\"{x:1369,y:816,t:1528140120315};\\\", \\\"{x:1369,y:820,t:1528140120330};\\\", \\\"{x:1369,y:823,t:1528140120347};\\\", \\\"{x:1369,y:825,t:1528140120365};\\\", \\\"{x:1369,y:828,t:1528140120380};\\\", \\\"{x:1369,y:829,t:1528140120438};\\\", \\\"{x:1369,y:830,t:1528140120454};\\\", \\\"{x:1369,y:832,t:1528140120464};\\\", \\\"{x:1369,y:834,t:1528140120494};\\\", \\\"{x:1371,y:834,t:1528140120662};\\\", \\\"{x:1372,y:834,t:1528140120669};\\\", \\\"{x:1373,y:834,t:1528140120681};\\\", \\\"{x:1375,y:834,t:1528140120698};\\\", \\\"{x:1376,y:834,t:1528140120715};\\\", \\\"{x:1379,y:833,t:1528140120731};\\\", \\\"{x:1383,y:831,t:1528140120747};\\\", \\\"{x:1385,y:830,t:1528140120765};\\\", \\\"{x:1390,y:829,t:1528140120783};\\\", \\\"{x:1393,y:829,t:1528140120797};\\\", \\\"{x:1395,y:829,t:1528140120814};\\\", \\\"{x:1396,y:829,t:1528140120862};\\\", \\\"{x:1398,y:829,t:1528140120877};\\\", \\\"{x:1400,y:831,t:1528140120886};\\\", \\\"{x:1402,y:831,t:1528140120902};\\\", \\\"{x:1403,y:831,t:1528140120915};\\\", \\\"{x:1405,y:833,t:1528140120932};\\\", \\\"{x:1406,y:835,t:1528140120949};\\\", \\\"{x:1411,y:841,t:1528140120964};\\\", \\\"{x:1413,y:845,t:1528140120982};\\\", \\\"{x:1415,y:847,t:1528140120997};\\\", \\\"{x:1416,y:849,t:1528140121014};\\\", \\\"{x:1417,y:849,t:1528140121031};\\\", \\\"{x:1418,y:850,t:1528140121117};\\\", \\\"{x:1419,y:850,t:1528140121238};\\\", \\\"{x:1420,y:850,t:1528140121249};\\\", \\\"{x:1423,y:848,t:1528140121265};\\\", \\\"{x:1425,y:846,t:1528140121281};\\\", \\\"{x:1426,y:844,t:1528140121299};\\\", \\\"{x:1427,y:844,t:1528140121315};\\\", \\\"{x:1427,y:841,t:1528140121332};\\\", \\\"{x:1427,y:838,t:1528140121348};\\\", \\\"{x:1426,y:832,t:1528140121366};\\\", \\\"{x:1425,y:827,t:1528140121382};\\\", \\\"{x:1421,y:823,t:1528140121399};\\\", \\\"{x:1412,y:816,t:1528140121416};\\\", \\\"{x:1402,y:808,t:1528140121432};\\\", \\\"{x:1386,y:801,t:1528140121449};\\\", \\\"{x:1367,y:794,t:1528140121465};\\\", \\\"{x:1343,y:785,t:1528140121481};\\\", \\\"{x:1323,y:779,t:1528140121499};\\\", \\\"{x:1305,y:774,t:1528140121515};\\\", \\\"{x:1294,y:772,t:1528140121532};\\\", \\\"{x:1288,y:769,t:1528140121548};\\\", \\\"{x:1285,y:768,t:1528140121565};\\\", \\\"{x:1287,y:766,t:1528140123071};\\\", \\\"{x:1295,y:763,t:1528140123082};\\\", \\\"{x:1310,y:754,t:1528140123099};\\\", \\\"{x:1334,y:740,t:1528140123117};\\\", \\\"{x:1356,y:722,t:1528140123133};\\\", \\\"{x:1379,y:709,t:1528140123149};\\\", \\\"{x:1400,y:692,t:1528140123167};\\\", \\\"{x:1420,y:678,t:1528140123184};\\\", \\\"{x:1439,y:672,t:1528140123200};\\\", \\\"{x:1457,y:665,t:1528140123217};\\\", \\\"{x:1470,y:658,t:1528140123233};\\\", \\\"{x:1479,y:652,t:1528140123250};\\\", \\\"{x:1488,y:648,t:1528140123266};\\\", \\\"{x:1496,y:642,t:1528140123283};\\\", \\\"{x:1499,y:641,t:1528140123299};\\\", \\\"{x:1500,y:641,t:1528140123316};\\\", \\\"{x:1505,y:638,t:1528140123333};\\\", \\\"{x:1512,y:635,t:1528140123350};\\\", \\\"{x:1518,y:635,t:1528140123367};\\\", \\\"{x:1539,y:635,t:1528140123384};\\\", \\\"{x:1562,y:635,t:1528140123400};\\\", \\\"{x:1583,y:637,t:1528140123416};\\\", \\\"{x:1595,y:646,t:1528140123433};\\\", \\\"{x:1605,y:651,t:1528140123450};\\\", \\\"{x:1614,y:655,t:1528140123466};\\\", \\\"{x:1623,y:661,t:1528140123484};\\\", \\\"{x:1626,y:665,t:1528140123500};\\\", \\\"{x:1630,y:667,t:1528140123517};\\\", \\\"{x:1631,y:667,t:1528140123534};\\\", \\\"{x:1631,y:668,t:1528140123558};\\\", \\\"{x:1632,y:669,t:1528140123573};\\\", \\\"{x:1632,y:670,t:1528140123590};\\\", \\\"{x:1632,y:671,t:1528140123614};\\\", \\\"{x:1632,y:673,t:1528140123621};\\\", \\\"{x:1632,y:674,t:1528140123633};\\\", \\\"{x:1629,y:675,t:1528140123651};\\\", \\\"{x:1625,y:679,t:1528140123667};\\\", \\\"{x:1615,y:684,t:1528140123683};\\\", \\\"{x:1607,y:687,t:1528140123701};\\\", \\\"{x:1593,y:691,t:1528140123717};\\\", \\\"{x:1565,y:696,t:1528140123734};\\\", \\\"{x:1549,y:698,t:1528140123749};\\\", \\\"{x:1538,y:699,t:1528140123767};\\\", \\\"{x:1531,y:699,t:1528140123783};\\\", \\\"{x:1517,y:699,t:1528140123800};\\\", \\\"{x:1510,y:699,t:1528140123817};\\\", \\\"{x:1504,y:699,t:1528140123834};\\\", \\\"{x:1495,y:701,t:1528140123850};\\\", \\\"{x:1480,y:701,t:1528140123867};\\\", \\\"{x:1467,y:702,t:1528140123883};\\\", \\\"{x:1446,y:703,t:1528140123900};\\\", \\\"{x:1423,y:706,t:1528140123917};\\\", \\\"{x:1385,y:714,t:1528140123933};\\\", \\\"{x:1347,y:729,t:1528140123950};\\\", \\\"{x:1316,y:738,t:1528140123967};\\\", \\\"{x:1299,y:743,t:1528140123983};\\\", \\\"{x:1292,y:745,t:1528140124001};\\\", \\\"{x:1289,y:746,t:1528140124017};\\\", \\\"{x:1288,y:747,t:1528140124034};\\\", \\\"{x:1286,y:747,t:1528140124091};\\\", \\\"{x:1285,y:749,t:1528140125038};\\\", \\\"{x:1283,y:749,t:1528140125052};\\\", \\\"{x:1280,y:749,t:1528140125067};\\\", \\\"{x:1279,y:750,t:1528140125084};\\\", \\\"{x:1278,y:750,t:1528140125102};\\\", \\\"{x:1276,y:750,t:1528140125117};\\\", \\\"{x:1271,y:750,t:1528140125134};\\\", \\\"{x:1268,y:750,t:1528140125151};\\\", \\\"{x:1261,y:749,t:1528140125167};\\\", \\\"{x:1253,y:747,t:1528140125184};\\\", \\\"{x:1248,y:746,t:1528140125201};\\\", \\\"{x:1244,y:745,t:1528140125217};\\\", \\\"{x:1242,y:744,t:1528140125234};\\\", \\\"{x:1239,y:742,t:1528140125251};\\\", \\\"{x:1236,y:742,t:1528140125267};\\\", \\\"{x:1233,y:741,t:1528140125284};\\\", \\\"{x:1227,y:739,t:1528140125300};\\\", \\\"{x:1224,y:739,t:1528140125317};\\\", \\\"{x:1210,y:737,t:1528140125334};\\\", \\\"{x:1200,y:734,t:1528140125351};\\\", \\\"{x:1179,y:727,t:1528140125368};\\\", \\\"{x:1160,y:722,t:1528140125384};\\\", \\\"{x:1136,y:710,t:1528140125402};\\\", \\\"{x:1111,y:701,t:1528140125419};\\\", \\\"{x:1086,y:696,t:1528140125434};\\\", \\\"{x:1063,y:689,t:1528140125451};\\\", \\\"{x:1041,y:681,t:1528140125469};\\\", \\\"{x:1017,y:673,t:1528140125484};\\\", \\\"{x:973,y:656,t:1528140125502};\\\", \\\"{x:959,y:647,t:1528140125519};\\\", \\\"{x:947,y:634,t:1528140125535};\\\", \\\"{x:937,y:622,t:1528140125551};\\\", \\\"{x:919,y:610,t:1528140125568};\\\", \\\"{x:900,y:599,t:1528140125585};\\\", \\\"{x:885,y:586,t:1528140125601};\\\", \\\"{x:874,y:575,t:1528140125620};\\\", \\\"{x:871,y:573,t:1528140125633};\\\", \\\"{x:863,y:565,t:1528140125651};\\\", \\\"{x:851,y:559,t:1528140125668};\\\", \\\"{x:837,y:553,t:1528140125684};\\\", \\\"{x:828,y:552,t:1528140125701};\\\", \\\"{x:817,y:550,t:1528140125718};\\\", \\\"{x:801,y:550,t:1528140125735};\\\", \\\"{x:780,y:550,t:1528140125751};\\\", \\\"{x:756,y:550,t:1528140125768};\\\", \\\"{x:727,y:546,t:1528140125785};\\\", \\\"{x:700,y:546,t:1528140125801};\\\", \\\"{x:673,y:546,t:1528140125818};\\\", \\\"{x:661,y:546,t:1528140125835};\\\", \\\"{x:650,y:546,t:1528140125851};\\\", \\\"{x:646,y:546,t:1528140125868};\\\", \\\"{x:642,y:547,t:1528140125885};\\\", \\\"{x:639,y:550,t:1528140125902};\\\", \\\"{x:634,y:551,t:1528140125918};\\\", \\\"{x:632,y:551,t:1528140125935};\\\", \\\"{x:630,y:552,t:1528140125951};\\\", \\\"{x:625,y:552,t:1528140125968};\\\", \\\"{x:620,y:552,t:1528140125985};\\\", \\\"{x:618,y:552,t:1528140126002};\\\", \\\"{x:617,y:546,t:1528140126019};\\\", \\\"{x:617,y:548,t:1528140127519};\\\", \\\"{x:651,y:555,t:1528140127530};\\\", \\\"{x:752,y:588,t:1528140127553};\\\", \\\"{x:785,y:597,t:1528140127570};\\\", \\\"{x:870,y:614,t:1528140127585};\\\", \\\"{x:917,y:614,t:1528140127603};\\\", \\\"{x:934,y:610,t:1528140127619};\\\", \\\"{x:947,y:605,t:1528140127636};\\\", \\\"{x:969,y:595,t:1528140127653};\\\", \\\"{x:976,y:591,t:1528140127669};\\\", \\\"{x:981,y:587,t:1528140127687};\\\", \\\"{x:991,y:582,t:1528140127703};\\\", \\\"{x:1006,y:576,t:1528140127720};\\\", \\\"{x:1018,y:569,t:1528140127736};\\\", \\\"{x:1056,y:569,t:1528140127753};\\\", \\\"{x:1122,y:585,t:1528140127771};\\\", \\\"{x:1197,y:607,t:1528140127787};\\\", \\\"{x:1287,y:638,t:1528140127804};\\\", \\\"{x:1391,y:683,t:1528140127821};\\\", \\\"{x:1479,y:718,t:1528140127836};\\\", \\\"{x:1608,y:765,t:1528140127853};\\\", \\\"{x:1654,y:781,t:1528140127871};\\\", \\\"{x:1674,y:787,t:1528140127887};\\\", \\\"{x:1687,y:790,t:1528140127903};\\\", \\\"{x:1697,y:791,t:1528140127921};\\\", \\\"{x:1703,y:791,t:1528140127937};\\\", \\\"{x:1715,y:791,t:1528140127953};\\\", \\\"{x:1741,y:791,t:1528140127971};\\\", \\\"{x:1758,y:792,t:1528140127987};\\\", \\\"{x:1781,y:794,t:1528140128004};\\\", \\\"{x:1803,y:792,t:1528140128020};\\\", \\\"{x:1808,y:790,t:1528140128038};\\\", \\\"{x:1809,y:790,t:1528140128053};\\\", \\\"{x:1807,y:789,t:1528140128126};\\\", \\\"{x:1796,y:784,t:1528140128137};\\\", \\\"{x:1771,y:779,t:1528140128154};\\\", \\\"{x:1751,y:773,t:1528140128173};\\\", \\\"{x:1725,y:769,t:1528140128189};\\\", \\\"{x:1711,y:766,t:1528140128204};\\\", \\\"{x:1702,y:764,t:1528140128221};\\\", \\\"{x:1701,y:764,t:1528140128238};\\\", \\\"{x:1699,y:764,t:1528140128253};\\\", \\\"{x:1694,y:765,t:1528140128270};\\\", \\\"{x:1683,y:781,t:1528140128288};\\\", \\\"{x:1672,y:798,t:1528140128305};\\\", \\\"{x:1660,y:812,t:1528140128321};\\\", \\\"{x:1648,y:830,t:1528140128337};\\\", \\\"{x:1635,y:847,t:1528140128354};\\\", \\\"{x:1625,y:855,t:1528140128371};\\\", \\\"{x:1615,y:864,t:1528140128387};\\\", \\\"{x:1601,y:871,t:1528140128403};\\\", \\\"{x:1586,y:879,t:1528140128420};\\\", \\\"{x:1567,y:890,t:1528140128437};\\\", \\\"{x:1553,y:892,t:1528140128454};\\\", \\\"{x:1542,y:893,t:1528140128471};\\\", \\\"{x:1529,y:895,t:1528140128488};\\\", \\\"{x:1521,y:895,t:1528140128503};\\\", \\\"{x:1518,y:895,t:1528140128521};\\\", \\\"{x:1513,y:895,t:1528140128538};\\\", \\\"{x:1510,y:895,t:1528140128553};\\\", \\\"{x:1498,y:895,t:1528140128571};\\\", \\\"{x:1487,y:895,t:1528140128588};\\\", \\\"{x:1478,y:897,t:1528140128605};\\\", \\\"{x:1466,y:897,t:1528140128621};\\\", \\\"{x:1465,y:897,t:1528140128653};\\\", \\\"{x:1465,y:898,t:1528140129102};\\\", \\\"{x:1465,y:900,t:1528140129133};\\\", \\\"{x:1465,y:902,t:1528140129141};\\\", \\\"{x:1465,y:903,t:1528140129155};\\\", \\\"{x:1465,y:905,t:1528140129171};\\\", \\\"{x:1465,y:909,t:1528140129187};\\\", \\\"{x:1465,y:914,t:1528140129205};\\\", \\\"{x:1465,y:917,t:1528140129222};\\\", \\\"{x:1465,y:919,t:1528140129238};\\\", \\\"{x:1466,y:919,t:1528140129486};\\\", \\\"{x:1462,y:919,t:1528140129686};\\\", \\\"{x:1454,y:911,t:1528140129694};\\\", \\\"{x:1444,y:901,t:1528140129705};\\\", \\\"{x:1396,y:865,t:1528140129722};\\\", \\\"{x:1275,y:792,t:1528140129738};\\\", \\\"{x:1138,y:717,t:1528140129755};\\\", \\\"{x:967,y:642,t:1528140129772};\\\", \\\"{x:802,y:574,t:1528140129790};\\\", \\\"{x:613,y:505,t:1528140129806};\\\", \\\"{x:518,y:467,t:1528140129838};\\\", \\\"{x:497,y:461,t:1528140129855};\\\", \\\"{x:487,y:459,t:1528140129871};\\\", \\\"{x:480,y:459,t:1528140129888};\\\", \\\"{x:475,y:459,t:1528140129905};\\\", \\\"{x:467,y:459,t:1528140129921};\\\", \\\"{x:440,y:458,t:1528140129938};\\\", \\\"{x:414,y:453,t:1528140129955};\\\", \\\"{x:398,y:449,t:1528140129971};\\\", \\\"{x:379,y:445,t:1528140129989};\\\", \\\"{x:377,y:445,t:1528140130005};\\\", \\\"{x:377,y:444,t:1528140130045};\\\", \\\"{x:379,y:444,t:1528140130055};\\\", \\\"{x:389,y:446,t:1528140130071};\\\", \\\"{x:399,y:455,t:1528140130089};\\\", \\\"{x:412,y:466,t:1528140130106};\\\", \\\"{x:429,y:483,t:1528140130123};\\\", \\\"{x:470,y:497,t:1528140130138};\\\", \\\"{x:498,y:505,t:1528140130156};\\\", \\\"{x:533,y:517,t:1528140130172};\\\", \\\"{x:569,y:529,t:1528140130188};\\\", \\\"{x:585,y:532,t:1528140130205};\\\", \\\"{x:602,y:533,t:1528140130222};\\\", \\\"{x:611,y:533,t:1528140130238};\\\", \\\"{x:615,y:533,t:1528140130256};\\\", \\\"{x:617,y:532,t:1528140130301};\\\", \\\"{x:617,y:529,t:1528140130309};\\\", \\\"{x:617,y:526,t:1528140130322};\\\", \\\"{x:617,y:522,t:1528140130338};\\\", \\\"{x:617,y:517,t:1528140130355};\\\", \\\"{x:618,y:507,t:1528140130373};\\\", \\\"{x:620,y:492,t:1528140130389};\\\", \\\"{x:620,y:487,t:1528140130405};\\\", \\\"{x:620,y:484,t:1528140130422};\\\", \\\"{x:620,y:483,t:1528140130439};\\\", \\\"{x:620,y:480,t:1528140130455};\\\", \\\"{x:620,y:477,t:1528140130472};\\\", \\\"{x:620,y:472,t:1528140130489};\\\", \\\"{x:620,y:467,t:1528140130506};\\\", \\\"{x:620,y:465,t:1528140130522};\\\", \\\"{x:620,y:463,t:1528140130538};\\\", \\\"{x:620,y:460,t:1528140130556};\\\", \\\"{x:619,y:459,t:1528140130572};\\\", \\\"{x:618,y:457,t:1528140130588};\\\", \\\"{x:617,y:455,t:1528140130605};\\\", \\\"{x:617,y:453,t:1528140130622};\\\", \\\"{x:616,y:453,t:1528140130638};\\\", \\\"{x:615,y:452,t:1528140130655};\\\", \\\"{x:614,y:452,t:1528140130677};\\\", \\\"{x:614,y:451,t:1528140130688};\\\", \\\"{x:614,y:450,t:1528140130705};\\\", \\\"{x:613,y:450,t:1528140130726};\\\", \\\"{x:613,y:447,t:1528140131084};\\\", \\\"{x:616,y:443,t:1528140131092};\\\", \\\"{x:620,y:440,t:1528140131105};\\\", \\\"{x:634,y:438,t:1528140131122};\\\", \\\"{x:643,y:437,t:1528140131140};\\\", \\\"{x:657,y:432,t:1528140131156};\\\", \\\"{x:692,y:431,t:1528140131172};\\\", \\\"{x:709,y:432,t:1528140131189};\\\", \\\"{x:717,y:433,t:1528140131206};\\\", \\\"{x:720,y:433,t:1528140131222};\\\", \\\"{x:725,y:434,t:1528140131240};\\\", \\\"{x:726,y:434,t:1528140131256};\\\", \\\"{x:727,y:434,t:1528140131272};\\\", \\\"{x:729,y:434,t:1528140131289};\\\", \\\"{x:730,y:436,t:1528140131306};\\\", \\\"{x:733,y:436,t:1528140131323};\\\", \\\"{x:737,y:438,t:1528140131340};\\\", \\\"{x:743,y:442,t:1528140131357};\\\", \\\"{x:746,y:445,t:1528140131372};\\\", \\\"{x:754,y:451,t:1528140131389};\\\", \\\"{x:757,y:454,t:1528140131406};\\\", \\\"{x:764,y:457,t:1528140131422};\\\", \\\"{x:773,y:458,t:1528140131440};\\\", \\\"{x:782,y:458,t:1528140131456};\\\", \\\"{x:797,y:456,t:1528140131473};\\\", \\\"{x:804,y:456,t:1528140131489};\\\", \\\"{x:811,y:454,t:1528140131506};\\\", \\\"{x:815,y:452,t:1528140131523};\\\", \\\"{x:818,y:452,t:1528140131539};\\\", \\\"{x:819,y:451,t:1528140131556};\\\", \\\"{x:822,y:450,t:1528140131574};\\\", \\\"{x:824,y:449,t:1528140131589};\\\", \\\"{x:825,y:449,t:1528140131621};\\\", \\\"{x:826,y:448,t:1528140131686};\\\", \\\"{x:827,y:447,t:1528140131706};\\\", \\\"{x:824,y:448,t:1528140131861};\\\", \\\"{x:815,y:451,t:1528140131874};\\\", \\\"{x:804,y:462,t:1528140131889};\\\", \\\"{x:785,y:479,t:1528140131907};\\\", \\\"{x:776,y:487,t:1528140131923};\\\", \\\"{x:758,y:510,t:1528140131940};\\\", \\\"{x:728,y:535,t:1528140131956};\\\", \\\"{x:713,y:556,t:1528140131973};\\\", \\\"{x:699,y:580,t:1528140131990};\\\", \\\"{x:682,y:592,t:1528140132006};\\\", \\\"{x:675,y:600,t:1528140132023};\\\", \\\"{x:661,y:612,t:1528140132040};\\\", \\\"{x:656,y:620,t:1528140132056};\\\", \\\"{x:653,y:622,t:1528140132073};\\\", \\\"{x:650,y:624,t:1528140132090};\\\", \\\"{x:642,y:631,t:1528140132107};\\\", \\\"{x:632,y:639,t:1528140132124};\\\", \\\"{x:612,y:645,t:1528140132141};\\\", \\\"{x:596,y:649,t:1528140132157};\\\", \\\"{x:584,y:652,t:1528140132174};\\\", \\\"{x:573,y:656,t:1528140132190};\\\", \\\"{x:565,y:659,t:1528140132206};\\\", \\\"{x:561,y:660,t:1528140132224};\\\", \\\"{x:559,y:663,t:1528140132241};\\\", \\\"{x:559,y:664,t:1528140132256};\\\", \\\"{x:557,y:665,t:1528140132274};\\\", \\\"{x:553,y:668,t:1528140132292};\\\", \\\"{x:547,y:673,t:1528140132307};\\\", \\\"{x:540,y:678,t:1528140132323};\\\", \\\"{x:535,y:684,t:1528140132340};\\\", \\\"{x:534,y:685,t:1528140132357};\\\", \\\"{x:534,y:686,t:1528140132652};\\\", \\\"{x:534,y:687,t:1528140133158};\\\" ] }, { \\\"rt\\\": 5013, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 163194, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"G27Q3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:531,y:681,t:1528140134093};\\\", \\\"{x:525,y:667,t:1528140134108};\\\", \\\"{x:522,y:650,t:1528140134126};\\\", \\\"{x:513,y:622,t:1528140134141};\\\", \\\"{x:505,y:579,t:1528140134159};\\\", \\\"{x:495,y:550,t:1528140134175};\\\", \\\"{x:460,y:443,t:1528140134291};\\\", \\\"{x:460,y:440,t:1528140134309};\\\", \\\"{x:461,y:439,t:1528140134606};\\\", \\\"{x:464,y:437,t:1528140134613};\\\", \\\"{x:466,y:435,t:1528140134625};\\\", \\\"{x:469,y:434,t:1528140134642};\\\", \\\"{x:473,y:433,t:1528140134659};\\\", \\\"{x:475,y:432,t:1528140134674};\\\", \\\"{x:476,y:432,t:1528140134692};\\\", \\\"{x:476,y:431,t:1528140136333};\\\", \\\"{x:483,y:434,t:1528140136350};\\\", \\\"{x:489,y:436,t:1528140136361};\\\", \\\"{x:509,y:447,t:1528140136376};\\\", \\\"{x:534,y:459,t:1528140136393};\\\", \\\"{x:549,y:472,t:1528140136410};\\\", \\\"{x:572,y:486,t:1528140136426};\\\", \\\"{x:597,y:499,t:1528140136443};\\\", \\\"{x:620,y:512,t:1528140136461};\\\", \\\"{x:626,y:515,t:1528140136476};\\\", \\\"{x:626,y:516,t:1528140136508};\\\", \\\"{x:626,y:520,t:1528140136517};\\\", \\\"{x:623,y:525,t:1528140136526};\\\", \\\"{x:619,y:531,t:1528140136543};\\\", \\\"{x:615,y:538,t:1528140136560};\\\", \\\"{x:610,y:545,t:1528140136577};\\\", \\\"{x:607,y:550,t:1528140136594};\\\", \\\"{x:605,y:553,t:1528140136611};\\\", \\\"{x:605,y:554,t:1528140136629};\\\", \\\"{x:604,y:555,t:1528140136732};\\\", \\\"{x:602,y:555,t:1528140136749};\\\", \\\"{x:601,y:555,t:1528140136760};\\\", \\\"{x:598,y:554,t:1528140136779};\\\", \\\"{x:597,y:551,t:1528140136793};\\\", \\\"{x:597,y:546,t:1528140136812};\\\", \\\"{x:594,y:541,t:1528140136828};\\\", \\\"{x:594,y:538,t:1528140136844};\\\", \\\"{x:594,y:536,t:1528140136861};\\\", \\\"{x:594,y:535,t:1528140137109};\\\", \\\"{x:592,y:535,t:1528140137117};\\\", \\\"{x:589,y:538,t:1528140137128};\\\", \\\"{x:580,y:548,t:1528140137146};\\\", \\\"{x:577,y:557,t:1528140137161};\\\", \\\"{x:575,y:568,t:1528140137178};\\\", \\\"{x:567,y:581,t:1528140137195};\\\", \\\"{x:565,y:588,t:1528140137210};\\\", \\\"{x:558,y:598,t:1528140137227};\\\", \\\"{x:553,y:613,t:1528140137244};\\\", \\\"{x:551,y:620,t:1528140137260};\\\", \\\"{x:549,y:626,t:1528140137277};\\\", \\\"{x:548,y:630,t:1528140137295};\\\", \\\"{x:544,y:639,t:1528140137310};\\\", \\\"{x:543,y:642,t:1528140137328};\\\", \\\"{x:540,y:646,t:1528140137345};\\\", \\\"{x:537,y:650,t:1528140137361};\\\", \\\"{x:535,y:654,t:1528140137378};\\\", \\\"{x:535,y:655,t:1528140137395};\\\", \\\"{x:535,y:656,t:1528140137411};\\\", \\\"{x:541,y:653,t:1528140137453};\\\", \\\"{x:550,y:649,t:1528140137461};\\\", \\\"{x:576,y:633,t:1528140137477};\\\", \\\"{x:587,y:624,t:1528140137494};\\\", \\\"{x:596,y:608,t:1528140137511};\\\", \\\"{x:597,y:601,t:1528140137527};\\\", \\\"{x:597,y:590,t:1528140137545};\\\", \\\"{x:597,y:582,t:1528140137561};\\\", \\\"{x:596,y:575,t:1528140137579};\\\", \\\"{x:593,y:569,t:1528140137594};\\\", \\\"{x:591,y:565,t:1528140137610};\\\", \\\"{x:589,y:560,t:1528140137628};\\\", \\\"{x:586,y:548,t:1528140137644};\\\", \\\"{x:584,y:541,t:1528140137662};\\\", \\\"{x:583,y:540,t:1528140137678};\\\", \\\"{x:581,y:534,t:1528140137695};\\\", \\\"{x:581,y:531,t:1528140137711};\\\", \\\"{x:581,y:528,t:1528140137727};\\\", \\\"{x:581,y:525,t:1528140137745};\\\", \\\"{x:584,y:522,t:1528140137762};\\\", \\\"{x:585,y:522,t:1528140137796};\\\", \\\"{x:586,y:521,t:1528140137812};\\\", \\\"{x:587,y:520,t:1528140137828};\\\", \\\"{x:591,y:519,t:1528140137845};\\\", \\\"{x:592,y:519,t:1528140137869};\\\", \\\"{x:593,y:519,t:1528140137878};\\\", \\\"{x:595,y:519,t:1528140137895};\\\", \\\"{x:596,y:519,t:1528140137911};\\\", \\\"{x:599,y:520,t:1528140137928};\\\", \\\"{x:603,y:521,t:1528140137946};\\\", \\\"{x:609,y:524,t:1528140137961};\\\", \\\"{x:611,y:525,t:1528140137978};\\\", \\\"{x:612,y:525,t:1528140138204};\\\", \\\"{x:612,y:526,t:1528140138220};\\\", \\\"{x:612,y:527,t:1528140138228};\\\", \\\"{x:612,y:529,t:1528140138244};\\\", \\\"{x:607,y:532,t:1528140138261};\\\", \\\"{x:605,y:535,t:1528140138278};\\\", \\\"{x:602,y:538,t:1528140138295};\\\", \\\"{x:598,y:546,t:1528140138312};\\\", \\\"{x:591,y:556,t:1528140138329};\\\", \\\"{x:585,y:564,t:1528140138344};\\\", \\\"{x:576,y:570,t:1528140138362};\\\", \\\"{x:565,y:577,t:1528140138379};\\\", \\\"{x:554,y:586,t:1528140138395};\\\", \\\"{x:547,y:599,t:1528140138412};\\\", \\\"{x:545,y:608,t:1528140138428};\\\", \\\"{x:543,y:619,t:1528140138445};\\\", \\\"{x:537,y:636,t:1528140138462};\\\", \\\"{x:531,y:656,t:1528140138479};\\\", \\\"{x:526,y:672,t:1528140138496};\\\", \\\"{x:522,y:680,t:1528140138512};\\\", \\\"{x:520,y:684,t:1528140138529};\\\", \\\"{x:520,y:686,t:1528140138546};\\\", \\\"{x:520,y:687,t:1528140138562};\\\", \\\"{x:519,y:687,t:1528140138579};\\\" ] }, { \\\"rt\\\": 8662, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 173129, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"G27Q3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:687,t:1528140140557};\\\", \\\"{x:519,y:686,t:1528140140573};\\\", \\\"{x:523,y:681,t:1528140140580};\\\", \\\"{x:534,y:666,t:1528140140596};\\\", \\\"{x:546,y:650,t:1528140140613};\\\", \\\"{x:555,y:639,t:1528140140631};\\\", \\\"{x:559,y:632,t:1528140140646};\\\", \\\"{x:565,y:629,t:1528140140664};\\\", \\\"{x:570,y:624,t:1528140140680};\\\", \\\"{x:572,y:621,t:1528140140697};\\\", \\\"{x:573,y:619,t:1528140140713};\\\", \\\"{x:575,y:619,t:1528140140731};\\\", \\\"{x:575,y:618,t:1528140140747};\\\", \\\"{x:576,y:618,t:1528140143230};\\\", \\\"{x:585,y:618,t:1528140143237};\\\", \\\"{x:634,y:631,t:1528140143250};\\\", \\\"{x:720,y:644,t:1528140143267};\\\", \\\"{x:812,y:644,t:1528140143283};\\\", \\\"{x:911,y:656,t:1528140143301};\\\", \\\"{x:1051,y:675,t:1528140143318};\\\", \\\"{x:1140,y:691,t:1528140143333};\\\", \\\"{x:1221,y:704,t:1528140143351};\\\", \\\"{x:1290,y:719,t:1528140143368};\\\", \\\"{x:1325,y:725,t:1528140143385};\\\", \\\"{x:1349,y:732,t:1528140143401};\\\", \\\"{x:1365,y:738,t:1528140143417};\\\", \\\"{x:1393,y:747,t:1528140143434};\\\", \\\"{x:1415,y:758,t:1528140143451};\\\", \\\"{x:1436,y:767,t:1528140143468};\\\", \\\"{x:1450,y:777,t:1528140143485};\\\", \\\"{x:1473,y:797,t:1528140143501};\\\", \\\"{x:1508,y:816,t:1528140143517};\\\", \\\"{x:1526,y:827,t:1528140143534};\\\", \\\"{x:1533,y:832,t:1528140143550};\\\", \\\"{x:1535,y:834,t:1528140143568};\\\", \\\"{x:1536,y:835,t:1528140143590};\\\", \\\"{x:1536,y:838,t:1528140143606};\\\", \\\"{x:1536,y:841,t:1528140143618};\\\", \\\"{x:1528,y:855,t:1528140143635};\\\", \\\"{x:1527,y:860,t:1528140143651};\\\", \\\"{x:1525,y:861,t:1528140143668};\\\", \\\"{x:1523,y:867,t:1528140143685};\\\", \\\"{x:1521,y:870,t:1528140143701};\\\", \\\"{x:1519,y:871,t:1528140143718};\\\", \\\"{x:1519,y:872,t:1528140143750};\\\", \\\"{x:1519,y:873,t:1528140143765};\\\", \\\"{x:1519,y:875,t:1528140143782};\\\", \\\"{x:1519,y:876,t:1528140143789};\\\", \\\"{x:1519,y:877,t:1528140143801};\\\", \\\"{x:1516,y:881,t:1528140143818};\\\", \\\"{x:1515,y:883,t:1528140143835};\\\", \\\"{x:1511,y:886,t:1528140143851};\\\", \\\"{x:1509,y:887,t:1528140143868};\\\", \\\"{x:1505,y:889,t:1528140143884};\\\", \\\"{x:1503,y:890,t:1528140143902};\\\", \\\"{x:1495,y:891,t:1528140143917};\\\", \\\"{x:1486,y:891,t:1528140143934};\\\", \\\"{x:1479,y:892,t:1528140143951};\\\", \\\"{x:1479,y:893,t:1528140143967};\\\", \\\"{x:1477,y:891,t:1528140144062};\\\", \\\"{x:1477,y:889,t:1528140144069};\\\", \\\"{x:1477,y:886,t:1528140144084};\\\", \\\"{x:1477,y:871,t:1528140144102};\\\", \\\"{x:1476,y:864,t:1528140144118};\\\", \\\"{x:1476,y:854,t:1528140144134};\\\", \\\"{x:1476,y:847,t:1528140144152};\\\", \\\"{x:1476,y:843,t:1528140144169};\\\", \\\"{x:1473,y:836,t:1528140144185};\\\", \\\"{x:1473,y:832,t:1528140144202};\\\", \\\"{x:1472,y:828,t:1528140144219};\\\", \\\"{x:1471,y:823,t:1528140144234};\\\", \\\"{x:1471,y:819,t:1528140144252};\\\", \\\"{x:1471,y:817,t:1528140144267};\\\", \\\"{x:1471,y:813,t:1528140144285};\\\", \\\"{x:1472,y:811,t:1528140144300};\\\", \\\"{x:1472,y:810,t:1528140144318};\\\", \\\"{x:1472,y:806,t:1528140144357};\\\", \\\"{x:1472,y:805,t:1528140144368};\\\", \\\"{x:1474,y:803,t:1528140144385};\\\", \\\"{x:1476,y:799,t:1528140144401};\\\", \\\"{x:1476,y:796,t:1528140144418};\\\", \\\"{x:1477,y:794,t:1528140144435};\\\", \\\"{x:1477,y:793,t:1528140144451};\\\", \\\"{x:1477,y:791,t:1528140144468};\\\", \\\"{x:1478,y:789,t:1528140144485};\\\", \\\"{x:1478,y:788,t:1528140144501};\\\", \\\"{x:1479,y:787,t:1528140144519};\\\", \\\"{x:1479,y:786,t:1528140144535};\\\", \\\"{x:1479,y:785,t:1528140144551};\\\", \\\"{x:1479,y:784,t:1528140144614};\\\", \\\"{x:1479,y:783,t:1528140144621};\\\", \\\"{x:1479,y:782,t:1528140144655};\\\", \\\"{x:1479,y:781,t:1528140144692};\\\", \\\"{x:1479,y:780,t:1528140144917};\\\", \\\"{x:1478,y:780,t:1528140144933};\\\", \\\"{x:1477,y:780,t:1528140145109};\\\", \\\"{x:1476,y:781,t:1528140145121};\\\", \\\"{x:1475,y:782,t:1528140145135};\\\", \\\"{x:1472,y:783,t:1528140145153};\\\", \\\"{x:1458,y:783,t:1528140145169};\\\", \\\"{x:1434,y:783,t:1528140145186};\\\", \\\"{x:1410,y:777,t:1528140145203};\\\", \\\"{x:1348,y:760,t:1528140145220};\\\", \\\"{x:1273,y:738,t:1528140145236};\\\", \\\"{x:1170,y:722,t:1528140145253};\\\", \\\"{x:1028,y:684,t:1528140145269};\\\", \\\"{x:920,y:653,t:1528140145287};\\\", \\\"{x:812,y:621,t:1528140145302};\\\", \\\"{x:728,y:594,t:1528140145319};\\\", \\\"{x:698,y:585,t:1528140145338};\\\", \\\"{x:681,y:575,t:1528140145352};\\\", \\\"{x:670,y:566,t:1528140145369};\\\", \\\"{x:660,y:557,t:1528140145386};\\\", \\\"{x:657,y:555,t:1528140145400};\\\", \\\"{x:654,y:550,t:1528140145418};\\\", \\\"{x:649,y:544,t:1528140145434};\\\", \\\"{x:643,y:535,t:1528140145451};\\\", \\\"{x:638,y:526,t:1528140145468};\\\", \\\"{x:631,y:515,t:1528140145484};\\\", \\\"{x:628,y:511,t:1528140145501};\\\", \\\"{x:628,y:510,t:1528140145519};\\\", \\\"{x:626,y:509,t:1528140145694};\\\", \\\"{x:622,y:510,t:1528140145701};\\\", \\\"{x:613,y:516,t:1528140145719};\\\", \\\"{x:611,y:520,t:1528140145734};\\\", \\\"{x:610,y:521,t:1528140145750};\\\", \\\"{x:610,y:522,t:1528140145768};\\\", \\\"{x:609,y:525,t:1528140145786};\\\", \\\"{x:608,y:527,t:1528140145802};\\\", \\\"{x:608,y:528,t:1528140145818};\\\", \\\"{x:608,y:530,t:1528140145836};\\\", \\\"{x:608,y:532,t:1528140145852};\\\", \\\"{x:608,y:533,t:1528140145892};\\\", \\\"{x:608,y:534,t:1528140145924};\\\", \\\"{x:609,y:534,t:1528140145941};\\\", \\\"{x:610,y:535,t:1528140145957};\\\", \\\"{x:612,y:535,t:1528140145973};\\\", \\\"{x:613,y:536,t:1528140145989};\\\", \\\"{x:608,y:537,t:1528140146340};\\\", \\\"{x:600,y:537,t:1528140146352};\\\", \\\"{x:585,y:537,t:1528140146368};\\\", \\\"{x:565,y:532,t:1528140146385};\\\", \\\"{x:547,y:531,t:1528140146402};\\\", \\\"{x:541,y:530,t:1528140146418};\\\", \\\"{x:540,y:530,t:1528140146436};\\\", \\\"{x:538,y:530,t:1528140146484};\\\", \\\"{x:529,y:530,t:1528140146502};\\\", \\\"{x:512,y:530,t:1528140146518};\\\", \\\"{x:498,y:530,t:1528140146537};\\\", \\\"{x:483,y:532,t:1528140146552};\\\", \\\"{x:459,y:532,t:1528140146568};\\\", \\\"{x:447,y:532,t:1528140146585};\\\", \\\"{x:437,y:532,t:1528140146602};\\\", \\\"{x:430,y:534,t:1528140146618};\\\", \\\"{x:426,y:536,t:1528140146634};\\\", \\\"{x:425,y:536,t:1528140146652};\\\", \\\"{x:423,y:536,t:1528140146676};\\\", \\\"{x:422,y:536,t:1528140146686};\\\", \\\"{x:419,y:536,t:1528140146702};\\\", \\\"{x:413,y:530,t:1528140146720};\\\", \\\"{x:409,y:526,t:1528140146736};\\\", \\\"{x:406,y:524,t:1528140146752};\\\", \\\"{x:403,y:522,t:1528140146770};\\\", \\\"{x:402,y:520,t:1528140146785};\\\", \\\"{x:401,y:520,t:1528140146802};\\\", \\\"{x:400,y:518,t:1528140146819};\\\", \\\"{x:399,y:518,t:1528140146836};\\\", \\\"{x:397,y:518,t:1528140146853};\\\", \\\"{x:395,y:518,t:1528140146869};\\\", \\\"{x:388,y:522,t:1528140146886};\\\", \\\"{x:380,y:528,t:1528140146904};\\\", \\\"{x:374,y:534,t:1528140146919};\\\", \\\"{x:368,y:538,t:1528140146935};\\\", \\\"{x:367,y:539,t:1528140146952};\\\", \\\"{x:366,y:543,t:1528140146969};\\\", \\\"{x:368,y:550,t:1528140147229};\\\", \\\"{x:372,y:558,t:1528140147247};\\\", \\\"{x:383,y:566,t:1528140147253};\\\", \\\"{x:401,y:581,t:1528140147268};\\\", \\\"{x:422,y:600,t:1528140147287};\\\", \\\"{x:435,y:612,t:1528140147302};\\\", \\\"{x:441,y:615,t:1528140147319};\\\", \\\"{x:447,y:621,t:1528140147336};\\\", \\\"{x:454,y:628,t:1528140147352};\\\", \\\"{x:454,y:629,t:1528140147461};\\\", \\\"{x:448,y:627,t:1528140147469};\\\", \\\"{x:419,y:600,t:1528140147486};\\\", \\\"{x:402,y:581,t:1528140147504};\\\", \\\"{x:387,y:566,t:1528140147519};\\\", \\\"{x:378,y:557,t:1528140147537};\\\", \\\"{x:377,y:555,t:1528140147553};\\\", \\\"{x:377,y:553,t:1528140147569};\\\", \\\"{x:377,y:550,t:1528140147586};\\\", \\\"{x:376,y:549,t:1528140147602};\\\", \\\"{x:376,y:546,t:1528140147619};\\\", \\\"{x:376,y:545,t:1528140147636};\\\", \\\"{x:376,y:539,t:1528140147653};\\\", \\\"{x:376,y:538,t:1528140147677};\\\", \\\"{x:378,y:536,t:1528140147692};\\\", \\\"{x:378,y:535,t:1528140147709};\\\", \\\"{x:380,y:535,t:1528140147725};\\\", \\\"{x:382,y:535,t:1528140147741};\\\", \\\"{x:382,y:534,t:1528140147754};\\\", \\\"{x:382,y:539,t:1528140147932};\\\", \\\"{x:385,y:545,t:1528140147941};\\\", \\\"{x:391,y:555,t:1528140147954};\\\", \\\"{x:412,y:581,t:1528140147971};\\\", \\\"{x:422,y:594,t:1528140147986};\\\", \\\"{x:435,y:602,t:1528140148004};\\\", \\\"{x:435,y:603,t:1528140148020};\\\", \\\"{x:438,y:608,t:1528140148036};\\\", \\\"{x:438,y:610,t:1528140148053};\\\", \\\"{x:439,y:610,t:1528140148070};\\\", \\\"{x:441,y:610,t:1528140148108};\\\", \\\"{x:442,y:610,t:1528140148133};\\\", \\\"{x:444,y:610,t:1528140148157};\\\", \\\"{x:445,y:610,t:1528140148170};\\\", \\\"{x:447,y:614,t:1528140148186};\\\", \\\"{x:451,y:622,t:1528140148203};\\\", \\\"{x:455,y:631,t:1528140148221};\\\", \\\"{x:458,y:638,t:1528140148237};\\\", \\\"{x:463,y:646,t:1528140148253};\\\", \\\"{x:466,y:651,t:1528140148270};\\\", \\\"{x:468,y:655,t:1528140148287};\\\", \\\"{x:469,y:657,t:1528140148304};\\\", \\\"{x:471,y:659,t:1528140148320};\\\", \\\"{x:471,y:662,t:1528140148337};\\\", \\\"{x:474,y:666,t:1528140148354};\\\", \\\"{x:478,y:672,t:1528140148370};\\\", \\\"{x:481,y:680,t:1528140148387};\\\", \\\"{x:484,y:684,t:1528140148405};\\\", \\\"{x:485,y:688,t:1528140148420};\\\", \\\"{x:486,y:692,t:1528140148437};\\\", \\\"{x:488,y:697,t:1528140148453};\\\", \\\"{x:489,y:698,t:1528140148470};\\\", \\\"{x:489,y:700,t:1528140148488};\\\", \\\"{x:490,y:700,t:1528140148504};\\\", \\\"{x:490,y:701,t:1528140148520};\\\", \\\"{x:491,y:704,t:1528140148537};\\\", \\\"{x:492,y:704,t:1528140148553};\\\", \\\"{x:493,y:705,t:1528140148613};\\\", \\\"{x:494,y:705,t:1528140149324};\\\", \\\"{x:495,y:705,t:1528140149477};\\\" ] }, { \\\"rt\\\": 44365, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 218745, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"G27Q3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"You go to 12 pm on the x-axis then follow the line going upwards and to the right. The points on that line start at 12 pm.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 6965, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Japan\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 226712, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"G27Q3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 14667, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Biomedical & Health Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 242393, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"G27Q3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 3218, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 246925, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"G27Q3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"G27Q3\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 159, dom: 765, initialDom: 851",
  "javascriptErrors": []
}