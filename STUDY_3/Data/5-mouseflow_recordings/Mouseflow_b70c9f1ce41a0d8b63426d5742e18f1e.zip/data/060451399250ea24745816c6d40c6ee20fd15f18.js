var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["060451399250ea24745816c6d40c6ee20fd15f18"] = {
  "startTime": "2018-06-04T20:28:51.1533247Z",
  "websitePageUrl": "/16",
  "visitTime": 87325,
  "engagementTime": 83457,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "b70c9f1ce41a0d8b63426d5742e18f1e",
    "created": "2018-06-04T20:28:51.1533247+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=VVH1B",
      "CONDITION=211"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "2a839bfc777eae57ef68b240abd1ac10",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/b70c9f1ce41a0d8b63426d5742e18f1e/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 101,
      "e": 101,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 649,
      "e": 649,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 701,
      "e": 701,
      "ty": 2,
      "x": 485,
      "y": 752
    },
    {
      "t": 751,
      "e": 751,
      "ty": 41,
      "x": 43604,
      "y": 41215,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 44166,
      "y": 37891,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1300,
      "e": 1300,
      "ty": 2,
      "x": 491,
      "y": 672
    },
    {
      "t": 1400,
      "e": 1400,
      "ty": 2,
      "x": 506,
      "y": 660
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 2,
      "x": 605,
      "y": 648
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 41,
      "x": 57093,
      "y": 35454,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1600,
      "e": 1600,
      "ty": 2,
      "x": 619,
      "y": 646
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 58667,
      "y": 35454,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 619,
      "y": 648
    },
    {
      "t": 2301,
      "e": 2301,
      "ty": 2,
      "x": 619,
      "y": 649
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 58667,
      "y": 35509,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2665,
      "e": 2665,
      "ty": 6,
      "x": 537,
      "y": 595,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2701,
      "e": 2701,
      "ty": 2,
      "x": 489,
      "y": 577
    },
    {
      "t": 2750,
      "e": 2750,
      "ty": 41,
      "x": 40794,
      "y": 39050,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2800,
      "e": 2800,
      "ty": 2,
      "x": 455,
      "y": 571
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 40232,
      "y": 39050,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4781,
      "e": 4781,
      "ty": 3,
      "x": 455,
      "y": 571,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4781,
      "e": 4781,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4988,
      "e": 4988,
      "ty": 4,
      "x": 40007,
      "y": 39050,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4988,
      "e": 4988,
      "ty": 5,
      "x": 453,
      "y": 571,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5000,
      "e": 5000,
      "ty": 2,
      "x": 453,
      "y": 571
    },
    {
      "t": 5000,
      "e": 5000,
      "ty": 41,
      "x": 40007,
      "y": 39050,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 13672,
      "e": 10000,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 14008,
      "e": 10336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 14009,
      "e": 10337,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14064,
      "e": 10392,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 14112,
      "e": 10440,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 14152,
      "e": 10480,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 14152,
      "e": 10480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14272,
      "e": 10600,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fo"
    },
    {
      "t": 14408,
      "e": 10736,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 14409,
      "e": 10737,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14456,
      "e": 10784,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fol"
    },
    {
      "t": 14602,
      "e": 10930,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fol"
    },
    {
      "t": 16064,
      "e": 12392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 16064,
      "e": 12392,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16184,
      "e": 12512,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Foll"
    },
    {
      "t": 16328,
      "e": 12656,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 16328,
      "e": 12656,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16472,
      "e": 12800,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 17001,
      "e": 13329,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 17001,
      "e": 13329,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17096,
      "e": 13424,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17097,
      "e": 13425,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17105,
      "e": 13433,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w "
    },
    {
      "t": 17208,
      "e": 13536,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17352,
      "e": 13680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17352,
      "e": 13680,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17504,
      "e": 13832,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 17536,
      "e": 13864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 17536,
      "e": 13864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17656,
      "e": 13984,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 17656,
      "e": 13984,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17664,
      "e": 13992,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 17767,
      "e": 14095,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17808,
      "e": 14136,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17808,
      "e": 14136,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17936,
      "e": 14264,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19745,
      "e": 16073,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 19746,
      "e": 16074,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19816,
      "e": 16144,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 19864,
      "e": 16192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19864,
      "e": 16192,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19993,
      "e": 16321,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20001,
      "e": 16329,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20088,
      "e": 16416,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 20088,
      "e": 16416,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20203,
      "e": 16531,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the x a"
    },
    {
      "t": 20208,
      "e": 16536,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 20481,
      "e": 16809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 20482,
      "e": 16810,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20545,
      "e": 16873,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 20705,
      "e": 17033,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 20705,
      "e": 17033,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20816,
      "e": 17144,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 20848,
      "e": 17176,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 20850,
      "e": 17178,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20961,
      "e": 17289,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 21008,
      "e": 17336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21009,
      "e": 17337,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21113,
      "e": 17441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22073,
      "e": 18401,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22203,
      "e": 18531,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the x axis"
    },
    {
      "t": 22217,
      "e": 18545,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the x axis"
    },
    {
      "t": 22737,
      "e": 19065,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 22738,
      "e": 19066,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22840,
      "e": 19168,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 22920,
      "e": 19248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22920,
      "e": 19248,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23048,
      "e": 19376,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23137,
      "e": 19465,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23138,
      "e": 19466,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23265,
      "e": 19593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 23266,
      "e": 19594,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23273,
      "e": 19601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 23392,
      "e": 19720,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23432,
      "e": 19760,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23432,
      "e": 19760,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23545,
      "e": 19873,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 24090,
      "e": 20418,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 24090,
      "e": 20418,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24200,
      "e": 20528,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 24361,
      "e": 20689,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24362,
      "e": 20690,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24440,
      "e": 20768,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27489,
      "e": 23817,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 27490,
      "e": 23818,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27568,
      "e": 23896,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 27713,
      "e": 24041,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 27713,
      "e": 24041,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27777,
      "e": 24105,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 27873,
      "e": 24201,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 27873,
      "e": 24201,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27984,
      "e": 24312,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 28080,
      "e": 24408,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 28081,
      "e": 24409,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28160,
      "e": 24488,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 28385,
      "e": 24713,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28385,
      "e": 24713,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28488,
      "e": 24816,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28665,
      "e": 24993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 28666,
      "e": 24994,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28802,
      "e": 25130,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the x axis, then look a"
    },
    {
      "t": 28816,
      "e": 25144,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 29152,
      "e": 25480,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 29154,
      "e": 25482,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29280,
      "e": 25608,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 29369,
      "e": 25697,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29369,
      "e": 25697,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29472,
      "e": 25800,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30001,
      "e": 26329,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30024,
      "e": 26352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30024,
      "e": 26352,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30152,
      "e": 26480,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 30248,
      "e": 26576,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 30248,
      "e": 26576,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30329,
      "e": 26657,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 30369,
      "e": 26697,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30370,
      "e": 26698,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30457,
      "e": 26785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 30553,
      "e": 26881,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30553,
      "e": 26881,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30648,
      "e": 26976,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30809,
      "e": 27137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 30809,
      "e": 27137,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30904,
      "e": 27232,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 30968,
      "e": 27296,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 30968,
      "e": 27296,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31096,
      "e": 27424,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 31137,
      "e": 27465,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 31137,
      "e": 27465,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31239,
      "e": 27567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 31497,
      "e": 27825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 31497,
      "e": 27825,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31602,
      "e": 27930,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the x axis, then look at the diag"
    },
    {
      "t": 31608,
      "e": 27936,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 31664,
      "e": 27992,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31664,
      "e": 27992,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31769,
      "e": 28097,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 31945,
      "e": 28273,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 31946,
      "e": 28274,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32025,
      "e": 28353,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 32049,
      "e": 28377,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 32049,
      "e": 28377,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32153,
      "e": 28481,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 32177,
      "e": 28505,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 32177,
      "e": 28505,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32240,
      "e": 28568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 32368,
      "e": 28696,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32368,
      "e": 28696,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32456,
      "e": 28784,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32528,
      "e": 28856,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32528,
      "e": 28856,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32624,
      "e": 28952,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 32633,
      "e": 28961,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 32633,
      "e": 28961,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32721,
      "e": 29049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 32857,
      "e": 29185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32858,
      "e": 29186,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32927,
      "e": 29255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32976,
      "e": 29304,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 32976,
      "e": 29304,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33088,
      "e": 29416,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 33089,
      "e": 29417,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33104,
      "e": 29432,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||de"
    },
    {
      "t": 33272,
      "e": 29600,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33272,
      "e": 29600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33279,
      "e": 29607,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 33402,
      "e": 29730,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the x axis, then look at the diagonal to det"
    },
    {
      "t": 33424,
      "e": 29752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33496,
      "e": 29824,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 33496,
      "e": 29824,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33584,
      "e": 29912,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 33584,
      "e": 29912,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33632,
      "e": 29960,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 33712,
      "e": 30040,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33745,
      "e": 30073,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 33746,
      "e": 30074,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33864,
      "e": 30192,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 33928,
      "e": 30256,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 33928,
      "e": 30256,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34064,
      "e": 30392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 34066,
      "e": 30394,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34096,
      "e": 30424,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 34192,
      "e": 30520,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34248,
      "e": 30576,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 34248,
      "e": 30576,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34362,
      "e": 30690,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 34385,
      "e": 30713,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34386,
      "e": 30714,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34511,
      "e": 30839,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35089,
      "e": 31417,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 35090,
      "e": 31418,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35204,
      "e": 31532,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the x axis, then look at the diagonal to determine h"
    },
    {
      "t": 35232,
      "e": 31560,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 35305,
      "e": 31633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 35305,
      "e": 31633,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35417,
      "e": 31745,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 35529,
      "e": 31857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 35529,
      "e": 31857,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35649,
      "e": 31977,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 36840,
      "e": 33168,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36936,
      "e": 33264,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the x axis, then look at the diagonal to determine ho"
    },
    {
      "t": 37048,
      "e": 33376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37112,
      "e": 33440,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the x axis, then look at the diagonal to determine h"
    },
    {
      "t": 37370,
      "e": 33698,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37465,
      "e": 33699,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the x axis, then look at the diagonal to determine "
    },
    {
      "t": 38096,
      "e": 34330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 38098,
      "e": 34332,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38183,
      "e": 34417,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 39040,
      "e": 35274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 39041,
      "e": 35275,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39136,
      "e": 35370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 39136,
      "e": 35370,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39143,
      "e": 35377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 39248,
      "e": 35482,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39297,
      "e": 35531,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39297,
      "e": 35531,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39403,
      "e": 35637,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the x axis, then look at the diagonal to determine the "
    },
    {
      "t": 39440,
      "e": 35674,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39753,
      "e": 35987,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 39753,
      "e": 35987,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39855,
      "e": 36089,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 39895,
      "e": 36129,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 39896,
      "e": 36130,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40003,
      "e": 36237,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the x axis, then look at the diagonal to determine the du"
    },
    {
      "t": 40008,
      "e": 36242,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 40057,
      "e": 36291,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 40057,
      "e": 36291,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40145,
      "e": 36379,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 40281,
      "e": 36515,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 40282,
      "e": 36516,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40399,
      "e": 36633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 40561,
      "e": 36795,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40561,
      "e": 36795,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40640,
      "e": 36874,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 40656,
      "e": 36890,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 40656,
      "e": 36890,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40804,
      "e": 37038,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the x axis, then look at the diagonal to determine the durati"
    },
    {
      "t": 40833,
      "e": 37067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 40834,
      "e": 37068,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40936,
      "e": 37170,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||io"
    },
    {
      "t": 40976,
      "e": 37210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 40976,
      "e": 37210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41016,
      "e": 37250,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 41120,
      "e": 37354,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42321,
      "e": 38555,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 42321,
      "e": 38555,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42384,
      "e": 38618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 44901,
      "e": 41135,
      "ty": 2,
      "x": 433,
      "y": 586
    },
    {
      "t": 45001,
      "e": 41235,
      "ty": 2,
      "x": 433,
      "y": 591
    },
    {
      "t": 45001,
      "e": 41235,
      "ty": 41,
      "x": 37759,
      "y": 55231,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45101,
      "e": 41335,
      "ty": 2,
      "x": 435,
      "y": 597
    },
    {
      "t": 45148,
      "e": 41382,
      "ty": 7,
      "x": 438,
      "y": 605,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45201,
      "e": 41435,
      "ty": 2,
      "x": 442,
      "y": 619
    },
    {
      "t": 45251,
      "e": 41485,
      "ty": 41,
      "x": 57767,
      "y": 2140,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 45301,
      "e": 41535,
      "ty": 2,
      "x": 443,
      "y": 629
    },
    {
      "t": 45401,
      "e": 41635,
      "ty": 2,
      "x": 443,
      "y": 636
    },
    {
      "t": 45481,
      "e": 41715,
      "ty": 6,
      "x": 445,
      "y": 656,
      "ta": "#strategyButton"
    },
    {
      "t": 45501,
      "e": 41735,
      "ty": 2,
      "x": 446,
      "y": 659
    },
    {
      "t": 45501,
      "e": 41735,
      "ty": 41,
      "x": 58657,
      "y": 8221,
      "ta": "#strategyButton"
    },
    {
      "t": 45601,
      "e": 41835,
      "ty": 2,
      "x": 446,
      "y": 664
    },
    {
      "t": 45702,
      "e": 41936,
      "ty": 2,
      "x": 446,
      "y": 672
    },
    {
      "t": 45754,
      "e": 41988,
      "ty": 41,
      "x": 58657,
      "y": 42916,
      "ta": "#strategyButton"
    },
    {
      "t": 45802,
      "e": 42036,
      "ty": 7,
      "x": 443,
      "y": 690,
      "ta": "#strategyButton"
    },
    {
      "t": 45804,
      "e": 42038,
      "ty": 2,
      "x": 443,
      "y": 690
    },
    {
      "t": 45904,
      "e": 42138,
      "ty": 2,
      "x": 442,
      "y": 691
    },
    {
      "t": 46005,
      "e": 42239,
      "ty": 41,
      "x": 57767,
      "y": 45393,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 47153,
      "e": 43387,
      "ty": 3,
      "x": 442,
      "y": 691,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 47154,
      "e": 43388,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Follow the x axis, then look at the diagonal to determine the duration."
    },
    {
      "t": 47155,
      "e": 43389,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47368,
      "e": 43602,
      "ty": 4,
      "x": 57767,
      "y": 45393,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 47368,
      "e": 43602,
      "ty": 5,
      "x": 442,
      "y": 691,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 47720,
      "e": 43954,
      "ty": 6,
      "x": 442,
      "y": 683,
      "ta": "#strategyButton"
    },
    {
      "t": 47754,
      "e": 43988,
      "ty": 41,
      "x": 57564,
      "y": 33279,
      "ta": "#strategyButton"
    },
    {
      "t": 47804,
      "e": 44038,
      "ty": 2,
      "x": 445,
      "y": 670
    },
    {
      "t": 47953,
      "e": 44187,
      "ty": 3,
      "x": 445,
      "y": 670,
      "ta": "#strategyButton"
    },
    {
      "t": 47953,
      "e": 44187,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 48004,
      "e": 44238,
      "ty": 41,
      "x": 58111,
      "y": 29424,
      "ta": "#strategyButton"
    },
    {
      "t": 48064,
      "e": 44298,
      "ty": 4,
      "x": 58111,
      "y": 29424,
      "ta": "#strategyButton"
    },
    {
      "t": 48079,
      "e": 44313,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 48081,
      "e": 44315,
      "ty": 5,
      "x": 445,
      "y": 670,
      "ta": "#strategyButton"
    },
    {
      "t": 48087,
      "e": 44321,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 48255,
      "e": 44489,
      "ty": 41,
      "x": 15014,
      "y": 37005,
      "ta": "html > body"
    },
    {
      "t": 48305,
      "e": 44539,
      "ty": 2,
      "x": 444,
      "y": 676
    },
    {
      "t": 48504,
      "e": 44738,
      "ty": 2,
      "x": 442,
      "y": 677
    },
    {
      "t": 48504,
      "e": 44738,
      "ty": 41,
      "x": 14945,
      "y": 37060,
      "ta": "html > body"
    },
    {
      "t": 49088,
      "e": 45322,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 49704,
      "e": 45938,
      "ty": 2,
      "x": 521,
      "y": 649
    },
    {
      "t": 49754,
      "e": 45988,
      "ty": 41,
      "x": 22109,
      "y": 34734,
      "ta": "html > body"
    },
    {
      "t": 49804,
      "e": 46038,
      "ty": 2,
      "x": 663,
      "y": 635
    },
    {
      "t": 49905,
      "e": 46139,
      "ty": 2,
      "x": 736,
      "y": 636
    },
    {
      "t": 50004,
      "e": 46238,
      "ty": 2,
      "x": 911,
      "y": 622
    },
    {
      "t": 50004,
      "e": 46238,
      "ty": 41,
      "x": 22277,
      "y": 49151,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 50105,
      "e": 46339,
      "ty": 2,
      "x": 932,
      "y": 609
    },
    {
      "t": 50204,
      "e": 46438,
      "ty": 2,
      "x": 946,
      "y": 594
    },
    {
      "t": 50254,
      "e": 46488,
      "ty": 41,
      "x": 30712,
      "y": 704,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 50304,
      "e": 46538,
      "ty": 2,
      "x": 950,
      "y": 578
    },
    {
      "t": 50405,
      "e": 46639,
      "ty": 2,
      "x": 951,
      "y": 577
    },
    {
      "t": 50455,
      "e": 46689,
      "ty": 6,
      "x": 951,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50505,
      "e": 46739,
      "ty": 2,
      "x": 952,
      "y": 573
    },
    {
      "t": 50505,
      "e": 46739,
      "ty": 41,
      "x": 31145,
      "y": 59293,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50592,
      "e": 46826,
      "ty": 3,
      "x": 952,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50593,
      "e": 46827,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50604,
      "e": 46838,
      "ty": 2,
      "x": 952,
      "y": 572
    },
    {
      "t": 50727,
      "e": 46961,
      "ty": 4,
      "x": 31145,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50728,
      "e": 46962,
      "ty": 5,
      "x": 952,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50754,
      "e": 46988,
      "ty": 41,
      "x": 31145,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52243,
      "e": 48477,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 52244,
      "e": 48478,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52331,
      "e": 48565,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 52444,
      "e": 48678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "96"
    },
    {
      "t": 52444,
      "e": 48678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52531,
      "e": 48765,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 53291,
      "e": 49525,
      "ty": 7,
      "x": 1028,
      "y": 601,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53303,
      "e": 49537,
      "ty": 2,
      "x": 1028,
      "y": 601
    },
    {
      "t": 53404,
      "e": 49638,
      "ty": 2,
      "x": 1054,
      "y": 631
    },
    {
      "t": 53504,
      "e": 49738,
      "ty": 2,
      "x": 1054,
      "y": 632
    },
    {
      "t": 53504,
      "e": 49738,
      "ty": 41,
      "x": 53206,
      "y": 34529,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 53604,
      "e": 49838,
      "ty": 2,
      "x": 1054,
      "y": 634
    },
    {
      "t": 53754,
      "e": 49988,
      "ty": 41,
      "x": 52990,
      "y": 36643,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 53757,
      "e": 49991,
      "ty": 6,
      "x": 1053,
      "y": 648,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53804,
      "e": 50038,
      "ty": 2,
      "x": 1052,
      "y": 665
    },
    {
      "t": 53808,
      "e": 50042,
      "ty": 7,
      "x": 1052,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53903,
      "e": 50137,
      "ty": 2,
      "x": 1052,
      "y": 670
    },
    {
      "t": 54004,
      "e": 50238,
      "ty": 41,
      "x": 52774,
      "y": 61306,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 54058,
      "e": 50292,
      "ty": 6,
      "x": 1051,
      "y": 666,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54103,
      "e": 50337,
      "ty": 2,
      "x": 1051,
      "y": 665
    },
    {
      "t": 54254,
      "e": 50488,
      "ty": 41,
      "x": 52557,
      "y": 56172,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54403,
      "e": 50637,
      "ty": 2,
      "x": 1051,
      "y": 662
    },
    {
      "t": 54432,
      "e": 50666,
      "ty": 3,
      "x": 1051,
      "y": 662,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54433,
      "e": 50667,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 54434,
      "e": 50668,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54434,
      "e": 50668,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54504,
      "e": 50738,
      "ty": 41,
      "x": 52557,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54543,
      "e": 50777,
      "ty": 4,
      "x": 52557,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54544,
      "e": 50778,
      "ty": 5,
      "x": 1051,
      "y": 662,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55196,
      "e": 51430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 55283,
      "e": 51517,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 55284,
      "e": 51518,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55386,
      "e": 51620,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 55493,
      "e": 51727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 55493,
      "e": 51727,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55605,
      "e": 51839,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 55618,
      "e": 51852,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 55740,
      "e": 51974,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 55740,
      "e": 51974,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55763,
      "e": 51997,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 55842,
      "e": 52076,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 57203,
      "e": 53437,
      "ty": 2,
      "x": 1043,
      "y": 666
    },
    {
      "t": 57210,
      "e": 53444,
      "ty": 7,
      "x": 1031,
      "y": 680,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57227,
      "e": 53461,
      "ty": 6,
      "x": 1011,
      "y": 699,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 57244,
      "e": 53478,
      "ty": 7,
      "x": 1001,
      "y": 712,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 57254,
      "e": 53488,
      "ty": 41,
      "x": 34196,
      "y": 38999,
      "ta": "html > body"
    },
    {
      "t": 57304,
      "e": 53538,
      "ty": 2,
      "x": 1000,
      "y": 715
    },
    {
      "t": 57504,
      "e": 53738,
      "ty": 41,
      "x": 34162,
      "y": 39165,
      "ta": "html > body"
    },
    {
      "t": 57604,
      "e": 53838,
      "ty": 2,
      "x": 999,
      "y": 711
    },
    {
      "t": 57680,
      "e": 53914,
      "ty": 6,
      "x": 998,
      "y": 704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 57704,
      "e": 53938,
      "ty": 2,
      "x": 998,
      "y": 699
    },
    {
      "t": 57754,
      "e": 53988,
      "ty": 41,
      "x": 53125,
      "y": 9929,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 57804,
      "e": 54038,
      "ty": 2,
      "x": 1000,
      "y": 680
    },
    {
      "t": 58004,
      "e": 54238,
      "ty": 41,
      "x": 53640,
      "y": 7943,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 58257,
      "e": 54491,
      "ty": 3,
      "x": 1000,
      "y": 680,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 58257,
      "e": 54491,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 58258,
      "e": 54492,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58259,
      "e": 54493,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 58400,
      "e": 54634,
      "ty": 4,
      "x": 53640,
      "y": 7943,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 58401,
      "e": 54635,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 58403,
      "e": 54637,
      "ty": 5,
      "x": 1000,
      "y": 680,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 58403,
      "e": 54637,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 59417,
      "e": 55651,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 59754,
      "e": 55988,
      "ty": 41,
      "x": 46652,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 59804,
      "e": 56038,
      "ty": 2,
      "x": 1044,
      "y": 597
    },
    {
      "t": 59909,
      "e": 56143,
      "ty": 2,
      "x": 1038,
      "y": 579
    },
    {
      "t": 60004,
      "e": 56238,
      "ty": 2,
      "x": 1013,
      "y": 574
    },
    {
      "t": 60004,
      "e": 56238,
      "ty": 41,
      "x": 45466,
      "y": 11702,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 60004,
      "e": 56238,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60104,
      "e": 56338,
      "ty": 2,
      "x": 972,
      "y": 564
    },
    {
      "t": 60204,
      "e": 56438,
      "ty": 2,
      "x": 877,
      "y": 511
    },
    {
      "t": 60254,
      "e": 56488,
      "ty": 41,
      "x": 11766,
      "y": 14198,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 60303,
      "e": 56537,
      "ty": 2,
      "x": 868,
      "y": 191
    },
    {
      "t": 60403,
      "e": 56637,
      "ty": 2,
      "x": 871,
      "y": 166
    },
    {
      "t": 60504,
      "e": 56738,
      "ty": 2,
      "x": 863,
      "y": 218
    },
    {
      "t": 60504,
      "e": 56738,
      "ty": 41,
      "x": 9867,
      "y": 16176,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 60604,
      "e": 56838,
      "ty": 2,
      "x": 846,
      "y": 282
    },
    {
      "t": 60704,
      "e": 56938,
      "ty": 2,
      "x": 846,
      "y": 288
    },
    {
      "t": 60754,
      "e": 56988,
      "ty": 41,
      "x": 7702,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 60864,
      "e": 57098,
      "ty": 6,
      "x": 832,
      "y": 270,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 60904,
      "e": 57138,
      "ty": 2,
      "x": 831,
      "y": 268
    },
    {
      "t": 61004,
      "e": 57238,
      "ty": 41,
      "x": 23079,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 61064,
      "e": 57298,
      "ty": 3,
      "x": 831,
      "y": 268,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 61065,
      "e": 57299,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 61208,
      "e": 57442,
      "ty": 4,
      "x": 23079,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 61208,
      "e": 57442,
      "ty": 5,
      "x": 831,
      "y": 268,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 61208,
      "e": 57442,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf",
      "v": "Spanish"
    },
    {
      "t": 61804,
      "e": 58038,
      "ty": 2,
      "x": 831,
      "y": 263
    },
    {
      "t": 61831,
      "e": 58065,
      "ty": 7,
      "x": 828,
      "y": 256,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 61904,
      "e": 58138,
      "ty": 2,
      "x": 828,
      "y": 255
    },
    {
      "t": 62004,
      "e": 58238,
      "ty": 41,
      "x": 1561,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 62080,
      "e": 58314,
      "ty": 6,
      "x": 828,
      "y": 244,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 62104,
      "e": 58338,
      "ty": 2,
      "x": 828,
      "y": 243
    },
    {
      "t": 62204,
      "e": 58438,
      "ty": 2,
      "x": 828,
      "y": 242
    },
    {
      "t": 62248,
      "e": 58482,
      "ty": 3,
      "x": 828,
      "y": 241,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 62249,
      "e": 58483,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 62251,
      "e": 58485,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 62254,
      "e": 58488,
      "ty": 41,
      "x": 7955,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 62304,
      "e": 58538,
      "ty": 2,
      "x": 828,
      "y": 241
    },
    {
      "t": 62375,
      "e": 58609,
      "ty": 4,
      "x": 7955,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 62376,
      "e": 58610,
      "ty": 5,
      "x": 828,
      "y": 241,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 62377,
      "e": 58611,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 62560,
      "e": 58794,
      "ty": 7,
      "x": 828,
      "y": 247,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 62581,
      "e": 58815,
      "ty": 6,
      "x": 828,
      "y": 265,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 62598,
      "e": 58832,
      "ty": 7,
      "x": 829,
      "y": 275,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 62604,
      "e": 58838,
      "ty": 2,
      "x": 829,
      "y": 275
    },
    {
      "t": 62665,
      "e": 58899,
      "ty": 6,
      "x": 830,
      "y": 291,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 62698,
      "e": 58932,
      "ty": 7,
      "x": 833,
      "y": 301,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 62704,
      "e": 58938,
      "ty": 2,
      "x": 833,
      "y": 301
    },
    {
      "t": 62749,
      "e": 58983,
      "ty": 6,
      "x": 836,
      "y": 322,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 62754,
      "e": 58988,
      "ty": 41,
      "x": 48284,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 62781,
      "e": 59015,
      "ty": 7,
      "x": 838,
      "y": 333,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 62804,
      "e": 59038,
      "ty": 2,
      "x": 838,
      "y": 340
    },
    {
      "t": 62904,
      "e": 59138,
      "ty": 2,
      "x": 838,
      "y": 347
    },
    {
      "t": 63004,
      "e": 59238,
      "ty": 2,
      "x": 840,
      "y": 329
    },
    {
      "t": 63004,
      "e": 59238,
      "ty": 41,
      "x": 18442,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 63104,
      "e": 59338,
      "ty": 2,
      "x": 844,
      "y": 286
    },
    {
      "t": 63255,
      "e": 59489,
      "ty": 41,
      "x": 7075,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 64004,
      "e": 60238,
      "ty": 2,
      "x": 861,
      "y": 399
    },
    {
      "t": 64004,
      "e": 60238,
      "ty": 41,
      "x": 9392,
      "y": 11915,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 64104,
      "e": 60338,
      "ty": 2,
      "x": 865,
      "y": 412
    },
    {
      "t": 64204,
      "e": 60438,
      "ty": 2,
      "x": 872,
      "y": 453
    },
    {
      "t": 64255,
      "e": 60439,
      "ty": 41,
      "x": 12240,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 64304,
      "e": 60488,
      "ty": 2,
      "x": 874,
      "y": 458
    },
    {
      "t": 64504,
      "e": 60688,
      "ty": 41,
      "x": 12478,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 64604,
      "e": 60788,
      "ty": 2,
      "x": 874,
      "y": 459
    },
    {
      "t": 64704,
      "e": 60888,
      "ty": 2,
      "x": 871,
      "y": 467
    },
    {
      "t": 64754,
      "e": 60938,
      "ty": 41,
      "x": 47119,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 64804,
      "e": 60988,
      "ty": 2,
      "x": 856,
      "y": 473
    },
    {
      "t": 64904,
      "e": 61088,
      "ty": 2,
      "x": 837,
      "y": 458
    },
    {
      "t": 65005,
      "e": 61189,
      "ty": 41,
      "x": 3697,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 65184,
      "e": 61368,
      "ty": 6,
      "x": 827,
      "y": 444,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 65204,
      "e": 61388,
      "ty": 2,
      "x": 826,
      "y": 442
    },
    {
      "t": 65217,
      "e": 61401,
      "ty": 7,
      "x": 823,
      "y": 439,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 65254,
      "e": 61438,
      "ty": 41,
      "x": 1260,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 65304,
      "e": 61488,
      "ty": 2,
      "x": 823,
      "y": 439
    },
    {
      "t": 65352,
      "e": 61536,
      "ty": 3,
      "x": 823,
      "y": 439,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 65352,
      "e": 61536,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 65497,
      "e": 61681,
      "ty": 4,
      "x": 1260,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 65498,
      "e": 61682,
      "ty": 5,
      "x": 823,
      "y": 439,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 65498,
      "e": 61682,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 65500,
      "e": 61684,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 65704,
      "e": 61888,
      "ty": 2,
      "x": 825,
      "y": 469
    },
    {
      "t": 65754,
      "e": 61938,
      "ty": 41,
      "x": 4839,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 65783,
      "e": 61967,
      "ty": 6,
      "x": 830,
      "y": 494,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 65804,
      "e": 61988,
      "ty": 2,
      "x": 830,
      "y": 497
    },
    {
      "t": 65833,
      "e": 62017,
      "ty": 7,
      "x": 832,
      "y": 509,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 65866,
      "e": 62050,
      "ty": 6,
      "x": 835,
      "y": 527,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 65884,
      "e": 62068,
      "ty": 7,
      "x": 837,
      "y": 537,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 65904,
      "e": 62088,
      "ty": 2,
      "x": 837,
      "y": 544
    },
    {
      "t": 65918,
      "e": 62102,
      "ty": 6,
      "x": 838,
      "y": 553,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 65951,
      "e": 62135,
      "ty": 7,
      "x": 841,
      "y": 565,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 66004,
      "e": 62188,
      "ty": 2,
      "x": 842,
      "y": 580
    },
    {
      "t": 66004,
      "e": 62188,
      "ty": 41,
      "x": 20428,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-6 > label"
    },
    {
      "t": 66104,
      "e": 62288,
      "ty": 2,
      "x": 846,
      "y": 608
    },
    {
      "t": 66204,
      "e": 62388,
      "ty": 2,
      "x": 849,
      "y": 637
    },
    {
      "t": 66254,
      "e": 62438,
      "ty": 41,
      "x": 6544,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 66304,
      "e": 62488,
      "ty": 2,
      "x": 849,
      "y": 649
    },
    {
      "t": 66404,
      "e": 62588,
      "ty": 2,
      "x": 848,
      "y": 689
    },
    {
      "t": 66504,
      "e": 62688,
      "ty": 2,
      "x": 847,
      "y": 700
    },
    {
      "t": 66505,
      "e": 62688,
      "ty": 41,
      "x": 6445,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 66604,
      "e": 62787,
      "ty": 2,
      "x": 848,
      "y": 715
    },
    {
      "t": 66704,
      "e": 62887,
      "ty": 2,
      "x": 843,
      "y": 763
    },
    {
      "t": 66751,
      "e": 62934,
      "ty": 6,
      "x": 839,
      "y": 782,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 66754,
      "e": 62937,
      "ty": 41,
      "x": 63408,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 66802,
      "e": 62985,
      "ty": 7,
      "x": 837,
      "y": 793,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 66804,
      "e": 62987,
      "ty": 2,
      "x": 837,
      "y": 793
    },
    {
      "t": 66904,
      "e": 63087,
      "ty": 2,
      "x": 836,
      "y": 794
    },
    {
      "t": 67005,
      "e": 63188,
      "ty": 41,
      "x": 8161,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 67204,
      "e": 63387,
      "ty": 2,
      "x": 836,
      "y": 795
    },
    {
      "t": 67255,
      "e": 63438,
      "ty": 41,
      "x": 8161,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 67303,
      "e": 63486,
      "ty": 6,
      "x": 838,
      "y": 789,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 67305,
      "e": 63488,
      "ty": 2,
      "x": 838,
      "y": 789
    },
    {
      "t": 67337,
      "e": 63520,
      "ty": 7,
      "x": 840,
      "y": 778,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 67404,
      "e": 63587,
      "ty": 2,
      "x": 842,
      "y": 771
    },
    {
      "t": 67504,
      "e": 63687,
      "ty": 2,
      "x": 842,
      "y": 764
    },
    {
      "t": 67504,
      "e": 63687,
      "ty": 41,
      "x": 8586,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 67704,
      "e": 63887,
      "ty": 2,
      "x": 842,
      "y": 782
    },
    {
      "t": 67752,
      "e": 63935,
      "ty": 6,
      "x": 839,
      "y": 809,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 67754,
      "e": 63937,
      "ty": 41,
      "x": 63408,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 67804,
      "e": 63987,
      "ty": 2,
      "x": 838,
      "y": 819
    },
    {
      "t": 67818,
      "e": 64001,
      "ty": 7,
      "x": 838,
      "y": 822,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 67904,
      "e": 64087,
      "ty": 2,
      "x": 838,
      "y": 832
    },
    {
      "t": 68004,
      "e": 64187,
      "ty": 2,
      "x": 838,
      "y": 835
    },
    {
      "t": 68005,
      "e": 64188,
      "ty": 41,
      "x": 11680,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 68015,
      "e": 64198,
      "ty": 6,
      "x": 838,
      "y": 836,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 68104,
      "e": 64287,
      "ty": 2,
      "x": 838,
      "y": 841
    },
    {
      "t": 68204,
      "e": 64387,
      "ty": 2,
      "x": 838,
      "y": 842
    },
    {
      "t": 68255,
      "e": 64438,
      "ty": 41,
      "x": 58367,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 68272,
      "e": 64455,
      "ty": 7,
      "x": 838,
      "y": 835,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 68286,
      "e": 64469,
      "ty": 6,
      "x": 832,
      "y": 815,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 68304,
      "e": 64487,
      "ty": 7,
      "x": 830,
      "y": 790,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 68304,
      "e": 64487,
      "ty": 6,
      "x": 830,
      "y": 790,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 68306,
      "e": 64489,
      "ty": 2,
      "x": 830,
      "y": 790
    },
    {
      "t": 68336,
      "e": 64519,
      "ty": 7,
      "x": 830,
      "y": 775,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 68404,
      "e": 64587,
      "ty": 2,
      "x": 832,
      "y": 769
    },
    {
      "t": 68436,
      "e": 64619,
      "ty": 6,
      "x": 834,
      "y": 764,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 68503,
      "e": 64686,
      "ty": 7,
      "x": 842,
      "y": 753,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 68505,
      "e": 64688,
      "ty": 2,
      "x": 842,
      "y": 753
    },
    {
      "t": 68505,
      "e": 64688,
      "ty": 41,
      "x": 8586,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 68605,
      "e": 64788,
      "ty": 2,
      "x": 861,
      "y": 720
    },
    {
      "t": 68703,
      "e": 64886,
      "ty": 2,
      "x": 865,
      "y": 712
    },
    {
      "t": 68754,
      "e": 64937,
      "ty": 41,
      "x": 11232,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 68804,
      "e": 64987,
      "ty": 2,
      "x": 867,
      "y": 704
    },
    {
      "t": 68904,
      "e": 65087,
      "ty": 2,
      "x": 870,
      "y": 692
    },
    {
      "t": 69004,
      "e": 65187,
      "ty": 2,
      "x": 870,
      "y": 691
    },
    {
      "t": 69004,
      "e": 65187,
      "ty": 41,
      "x": 11528,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 69204,
      "e": 65387,
      "ty": 2,
      "x": 857,
      "y": 702
    },
    {
      "t": 69254,
      "e": 65437,
      "ty": 41,
      "x": 8713,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 69304,
      "e": 65487,
      "ty": 2,
      "x": 856,
      "y": 703
    },
    {
      "t": 69505,
      "e": 65688,
      "ty": 2,
      "x": 853,
      "y": 703
    },
    {
      "t": 69505,
      "e": 65688,
      "ty": 41,
      "x": 7957,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 69604,
      "e": 65787,
      "ty": 2,
      "x": 847,
      "y": 702
    },
    {
      "t": 69704,
      "e": 65887,
      "ty": 2,
      "x": 845,
      "y": 701
    },
    {
      "t": 69755,
      "e": 65938,
      "ty": 41,
      "x": 5689,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 69804,
      "e": 65987,
      "ty": 2,
      "x": 844,
      "y": 701
    },
    {
      "t": 69904,
      "e": 66087,
      "ty": 2,
      "x": 840,
      "y": 701
    },
    {
      "t": 69920,
      "e": 66103,
      "ty": 6,
      "x": 839,
      "y": 702,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 70004,
      "e": 66187,
      "ty": 2,
      "x": 837,
      "y": 703
    },
    {
      "t": 70005,
      "e": 66188,
      "ty": 41,
      "x": 53325,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 70103,
      "e": 66286,
      "ty": 3,
      "x": 837,
      "y": 703,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 70103,
      "e": 66286,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 70103,
      "e": 66286,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 70263,
      "e": 66446,
      "ty": 4,
      "x": 53325,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 70264,
      "e": 66447,
      "ty": 5,
      "x": 837,
      "y": 703,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 70264,
      "e": 66447,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 70502,
      "e": 66685,
      "ty": 7,
      "x": 837,
      "y": 711,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 70504,
      "e": 66687,
      "ty": 2,
      "x": 837,
      "y": 711
    },
    {
      "t": 70504,
      "e": 66687,
      "ty": 41,
      "x": 3925,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 70538,
      "e": 66721,
      "ty": 6,
      "x": 834,
      "y": 762,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 70553,
      "e": 66736,
      "ty": 7,
      "x": 834,
      "y": 770,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 70587,
      "e": 66770,
      "ty": 6,
      "x": 834,
      "y": 782,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 70604,
      "e": 66787,
      "ty": 2,
      "x": 834,
      "y": 786
    },
    {
      "t": 70704,
      "e": 66887,
      "ty": 2,
      "x": 834,
      "y": 792
    },
    {
      "t": 70755,
      "e": 66938,
      "ty": 41,
      "x": 38202,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 73152,
      "e": 69335,
      "ty": 7,
      "x": 834,
      "y": 793,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 73205,
      "e": 69388,
      "ty": 2,
      "x": 834,
      "y": 794
    },
    {
      "t": 73255,
      "e": 69438,
      "ty": 41,
      "x": 7041,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 73304,
      "e": 69487,
      "ty": 2,
      "x": 834,
      "y": 800
    },
    {
      "t": 73405,
      "e": 69588,
      "ty": 2,
      "x": 833,
      "y": 802
    },
    {
      "t": 73480,
      "e": 69663,
      "ty": 6,
      "x": 831,
      "y": 808,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 73505,
      "e": 69688,
      "ty": 2,
      "x": 831,
      "y": 808
    },
    {
      "t": 73505,
      "e": 69688,
      "ty": 41,
      "x": 23079,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 73604,
      "e": 69787,
      "ty": 2,
      "x": 829,
      "y": 811
    },
    {
      "t": 73704,
      "e": 69887,
      "ty": 2,
      "x": 829,
      "y": 812
    },
    {
      "t": 73755,
      "e": 69938,
      "ty": 41,
      "x": 12996,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 73804,
      "e": 69987,
      "ty": 2,
      "x": 829,
      "y": 813
    },
    {
      "t": 73904,
      "e": 70087,
      "ty": 2,
      "x": 828,
      "y": 815
    },
    {
      "t": 74004,
      "e": 70187,
      "ty": 41,
      "x": 7955,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 74592,
      "e": 70775,
      "ty": 7,
      "x": 827,
      "y": 828,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 74605,
      "e": 70788,
      "ty": 2,
      "x": 827,
      "y": 828
    },
    {
      "t": 74608,
      "e": 70791,
      "ty": 6,
      "x": 827,
      "y": 836,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 74640,
      "e": 70823,
      "ty": 7,
      "x": 824,
      "y": 856,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 74704,
      "e": 70887,
      "ty": 2,
      "x": 824,
      "y": 867
    },
    {
      "t": 74754,
      "e": 70937,
      "ty": 41,
      "x": 611,
      "y": 53279,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 74804,
      "e": 70987,
      "ty": 2,
      "x": 823,
      "y": 887
    },
    {
      "t": 74904,
      "e": 71087,
      "ty": 2,
      "x": 821,
      "y": 922
    },
    {
      "t": 75004,
      "e": 71187,
      "ty": 2,
      "x": 821,
      "y": 930
    },
    {
      "t": 75004,
      "e": 71187,
      "ty": 41,
      "x": 0,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 75105,
      "e": 71288,
      "ty": 2,
      "x": 821,
      "y": 935
    },
    {
      "t": 75204,
      "e": 71387,
      "ty": 2,
      "x": 821,
      "y": 938
    },
    {
      "t": 75254,
      "e": 71437,
      "ty": 41,
      "x": 1723,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 75255,
      "e": 71438,
      "ty": 3,
      "x": 824,
      "y": 938,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 75255,
      "e": 71438,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 75304,
      "e": 71487,
      "ty": 2,
      "x": 825,
      "y": 938
    },
    {
      "t": 75415,
      "e": 71598,
      "ty": 4,
      "x": 3908,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 75415,
      "e": 71598,
      "ty": 5,
      "x": 825,
      "y": 938,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 75415,
      "e": 71598,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 75416,
      "e": 71599,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 75505,
      "e": 71688,
      "ty": 41,
      "x": 3908,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 75592,
      "e": 71775,
      "ty": 6,
      "x": 835,
      "y": 964,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 75605,
      "e": 71788,
      "ty": 2,
      "x": 835,
      "y": 964
    },
    {
      "t": 75608,
      "e": 71791,
      "ty": 7,
      "x": 836,
      "y": 976,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 75625,
      "e": 71808,
      "ty": 6,
      "x": 839,
      "y": 989,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 75642,
      "e": 71825,
      "ty": 7,
      "x": 841,
      "y": 999,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 75675,
      "e": 71858,
      "ty": 6,
      "x": 844,
      "y": 1008,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 75704,
      "e": 71887,
      "ty": 2,
      "x": 844,
      "y": 1009
    },
    {
      "t": 75755,
      "e": 71887,
      "ty": 41,
      "x": 7513,
      "y": 7943,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 75804,
      "e": 71936,
      "ty": 2,
      "x": 846,
      "y": 1009
    },
    {
      "t": 75888,
      "e": 72020,
      "ty": 3,
      "x": 846,
      "y": 1009,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 75888,
      "e": 72020,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 75888,
      "e": 72020,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 76004,
      "e": 72136,
      "ty": 41,
      "x": 8544,
      "y": 7943,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 76071,
      "e": 72203,
      "ty": 4,
      "x": 8544,
      "y": 7943,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 76071,
      "e": 72203,
      "ty": 5,
      "x": 846,
      "y": 1009,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 76075,
      "e": 72207,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 76076,
      "e": 72208,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 76078,
      "e": 72210,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 77527,
      "e": 73659,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 78104,
      "e": 74236,
      "ty": 2,
      "x": 856,
      "y": 1029
    },
    {
      "t": 78203,
      "e": 74335,
      "ty": 2,
      "x": 917,
      "y": 1067
    },
    {
      "t": 78254,
      "e": 74386,
      "ty": 41,
      "x": 30775,
      "y": 65141,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 78304,
      "e": 74436,
      "ty": 2,
      "x": 919,
      "y": 1067
    },
    {
      "t": 78403,
      "e": 74535,
      "ty": 2,
      "x": 923,
      "y": 1069
    },
    {
      "t": 78504,
      "e": 74636,
      "ty": 2,
      "x": 930,
      "y": 1069
    },
    {
      "t": 78504,
      "e": 74636,
      "ty": 41,
      "x": 31316,
      "y": 65279,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 78527,
      "e": 74659,
      "ty": 6,
      "x": 933,
      "y": 1075,
      "ta": "#start"
    },
    {
      "t": 78603,
      "e": 74735,
      "ty": 2,
      "x": 952,
      "y": 1103
    },
    {
      "t": 78703,
      "e": 74835,
      "ty": 2,
      "x": 953,
      "y": 1103
    },
    {
      "t": 78754,
      "e": 74886,
      "ty": 41,
      "x": 23756,
      "y": 58427,
      "ta": "#start"
    },
    {
      "t": 78904,
      "e": 75036,
      "ty": 2,
      "x": 954,
      "y": 1103
    },
    {
      "t": 79004,
      "e": 75136,
      "ty": 2,
      "x": 955,
      "y": 1103
    },
    {
      "t": 79004,
      "e": 75136,
      "ty": 41,
      "x": 24848,
      "y": 58427,
      "ta": "#start"
    },
    {
      "t": 79104,
      "e": 75236,
      "ty": 2,
      "x": 956,
      "y": 1103
    },
    {
      "t": 79254,
      "e": 75386,
      "ty": 41,
      "x": 25394,
      "y": 58427,
      "ta": "#start"
    },
    {
      "t": 83804,
      "e": 79936,
      "ty": 2,
      "x": 956,
      "y": 1098
    },
    {
      "t": 83864,
      "e": 79996,
      "ty": 3,
      "x": 956,
      "y": 1097,
      "ta": "#start"
    },
    {
      "t": 83865,
      "e": 79997,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 83904,
      "e": 80036,
      "ty": 2,
      "x": 956,
      "y": 1097
    },
    {
      "t": 84004,
      "e": 80136,
      "ty": 41,
      "x": 25394,
      "y": 46862,
      "ta": "#start"
    },
    {
      "t": 84055,
      "e": 80187,
      "ty": 4,
      "x": 25394,
      "y": 46862,
      "ta": "#start"
    },
    {
      "t": 84055,
      "e": 80187,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 84056,
      "e": 80188,
      "ty": 5,
      "x": 956,
      "y": 1097,
      "ta": "#start"
    },
    {
      "t": 84056,
      "e": 80188,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 84503,
      "e": 80635,
      "ty": 2,
      "x": 956,
      "y": 1096
    },
    {
      "t": 84504,
      "e": 80636,
      "ty": 41,
      "x": 32646,
      "y": 60272,
      "ta": "html > body"
    },
    {
      "t": 84604,
      "e": 80736,
      "ty": 2,
      "x": 957,
      "y": 1093
    },
    {
      "t": 84754,
      "e": 80886,
      "ty": 41,
      "x": 32681,
      "y": 60106,
      "ta": "html > body"
    },
    {
      "t": 84904,
      "e": 81036,
      "ty": 2,
      "x": 959,
      "y": 1086
    },
    {
      "t": 85004,
      "e": 81136,
      "ty": 2,
      "x": 1136,
      "y": 798
    },
    {
      "t": 85004,
      "e": 81136,
      "ty": 41,
      "x": 38845,
      "y": 43763,
      "ta": "html > body"
    },
    {
      "t": 85089,
      "e": 81221,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 86010,
      "e": 82142,
      "ty": 2,
      "x": 1217,
      "y": 723
    },
    {
      "t": 86010,
      "e": 82142,
      "ty": 41,
      "x": 47725,
      "y": 32791,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 87325,
      "e": 83457,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2311,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"previousSibling\":{\"id\":2302},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2312,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"previousSibling\":{\"id\":2311},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2312},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2314,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"previousSibling\":{\"id\":2313},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"previousSibling\":{\"id\":2314},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2316,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"previousSibling\":{\"id\":2316},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2318,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"previousSibling\":{\"id\":2317},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"previousSibling\":{\"id\":2318},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2320,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"previousSibling\":{\"id\":2319},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"previousSibling\":{\"id\":2320},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2322,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"previousSibling\":{\"id\":2321},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"previousSibling\":{\"id\":2322},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2324,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"previousSibling\":{\"id\":2323},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"previousSibling\":{\"id\":2324},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2326,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"previousSibling\":{\"id\":2325},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"previousSibling\":{\"id\":2326},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2328,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"previousSibling\":{\"id\":2327},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"previousSibling\":{\"id\":2328},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2330,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"previousSibling\":{\"id\":2329},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"previousSibling\":{\"id\":2330},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2332,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"previousSibling\":{\"id\":2331},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"previousSibling\":{\"id\":2332},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2334,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"previousSibling\":{\"id\":2333},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"previousSibling\":{\"id\":2334},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2336,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"previousSibling\":{\"id\":2335},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"previousSibling\":{\"id\":2336},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2338,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"previousSibling\":{\"id\":2337},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"previousSibling\":{\"id\":2338},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2340,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"previousSibling\":{\"id\":2339},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"previousSibling\":{\"id\":2340},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2342,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2341},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2344,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2343},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2345,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2346,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2345},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2348,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2347},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2349,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2350,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2349},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2352,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2351},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2353,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2354,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2353},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2356,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2355},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2357,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2358,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2357},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2360,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2359},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2361,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2362,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2361},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2364,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2363},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2365,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2366,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2365},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2368,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2367},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2369,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2370,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2369},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2372,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2371},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2373,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2374,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2373},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2376,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2375},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2377,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2378,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2377},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2380,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2379},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2381,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2382,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2381},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2384,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2383},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2385,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2386,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2385},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2388,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2387},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2389,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2390,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2389},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2341}},{\"nodeType\":1,\"id\":2392,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2391},\"parentNode\":{\"id\":2341}},{\"nodeType\":3,\"id\":2393,\"textContent\":\"08 AM\",\"parentNode\":{\"id\":2344}},{\"nodeType\":3,\"id\":2394,\"textContent\":\"08:30\",\"parentNode\":{\"id\":2346}},{\"nodeType\":3,\"id\":2395,\"textContent\":\"09 AM\",\"parentNode\":{\"id\":2348}},{\"nodeType\":3,\"id\":2396,\"textContent\":\"09:30\",\"parentNode\":{\"id\":2350}},{\"nodeType\":3,\"id\":2397,\"textContent\":\"10 AM\",\"parentNode\":{\"id\":2352}},{\"nodeType\":3,\"id\":2398,\"textContent\":\"10:30\",\"parentNode\":{\"id\":2354}},{\"nodeType\":3,\"id\":2399,\"textContent\":\"11 AM\",\"parentNode\":{\"id\":2356}},{\"nodeType\":3,\"id\":2400,\"textContent\":\"11:30\",\"parentNode\":{\"id\":2358}},{\"nodeType\":3,\"id\":2401,\"textContent\":\"12 PM\",\"parentNode\":{\"id\":2360}},{\"nodeType\":3,\"id\":2402,\"textContent\":\"12:30\",\"parentNode\":{\"id\":2362}},{\"nodeType\":3,\"id\":2403,\"textContent\":\"01 PM\",\"parentNode\":{\"id\":2364}},{\"nodeType\":3,\"id\":2404,\"textContent\":\"01:30\",\"parentNode\":{\"id\":2366}},{\"nodeType\":3,\"id\":2405,\"textContent\":\"02 PM\",\"parentNode\":{\"id\":2368}},{\"nodeType\":3,\"id\":2406,\"textContent\":\"02:30\",\"parentNode\":{\"id\":2370}},{\"nodeType\":3,\"id\":2407,\"textContent\":\"03 PM\",\"parentNode\":{\"id\":2372}},{\"nodeType\":3,\"id\":2408,\"textContent\":\"03:30\",\"parentNode\":{\"id\":2374}},{\"nodeType\":3,\"id\":2409,\"textContent\":\"04 PM\",\"parentNode\":{\"id\":2376}},{\"nodeType\":3,\"id\":2410,\"textContent\":\"04:30\",\"parentNode\":{\"id\":2378}},{\"nodeType\":3,\"id\":2411,\"textContent\":\"05 PM\",\"parentNode\":{\"id\":2380}},{\"nodeType\":3,\"id\":2412,\"textContent\":\"05:30\",\"parentNode\":{\"id\":2382}},{\"nodeType\":3,\"id\":2413,\"textContent\":\"06 PM\",\"parentNode\":{\"id\":2384}},{\"nodeType\":3,\"id\":2414,\"textContent\":\"06:30\",\"parentNode\":{\"id\":2386}},{\"nodeType\":3,\"id\":2415,\"textContent\":\"07 PM\",\"parentNode\":{\"id\":2388}},{\"nodeType\":3,\"id\":2416,\"textContent\":\"07:30\",\"parentNode\":{\"id\":2390}},{\"nodeType\":3,\"id\":2417,\"textContent\":\"08 PM\",\"parentNode\":{\"id\":2392}},{\"nodeType\":1,\"id\":2418,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2342}},{\"nodeType\":3,\"id\":2419,\"textContent\":\"START & END TIME (time of day)\",\"parentNode\":{\"id\":2418}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2421,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"previousSibling\":{\"id\":2420},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"previousSibling\":{\"id\":2421},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"previousSibling\":{\"id\":2422},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"previousSibling\":{\"id\":2423},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2425,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"previousSibling\":{\"id\":2424},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"previousSibling\":{\"id\":2425},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2427,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"previousSibling\":{\"id\":2426},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"previousSibling\":{\"id\":2427},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2429,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"previousSibling\":{\"id\":2428},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"previousSibling\":{\"id\":2429},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"previousSibling\":{\"id\":2430},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"previousSibling\":{\"id\":2431},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"previousSibling\":{\"id\":2432},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2433},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2421}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2435},\"parentNode\":{\"id\":2421}},{\"nodeType\":1,\"id\":2437,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2438,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2437},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2439},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2441,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2442,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2441},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2443},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2445,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2446,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2445},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2447},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2449,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2450,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2449},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2451},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2453,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2454,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2453},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2455},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2457,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2458,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2457},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2433}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2459},\"parentNode\":{\"id\":2433}},{\"nodeType\":3,\"id\":2461,\"textContent\":\"0\",\"parentNode\":{\"id\":2436}},{\"nodeType\":3,\"id\":2462,\"textContent\":\"1\",\"parentNode\":{\"id\":2438}},{\"nodeType\":3,\"id\":2463,\"textContent\":\"2\",\"parentNode\":{\"id\":2440}},{\"nodeType\":3,\"id\":2464,\"textContent\":\"3\",\"parentNode\":{\"id\":2442}},{\"nodeType\":3,\"id\":2465,\"textContent\":\"4\",\"parentNode\":{\"id\":2444}},{\"nodeType\":3,\"id\":2466,\"textContent\":\"5\",\"parentNode\":{\"id\":2446}},{\"nodeType\":3,\"id\":2467,\"textContent\":\"6\",\"parentNode\":{\"id\":2448}},{\"nodeType\":3,\"id\":2468,\"textContent\":\"7\",\"parentNode\":{\"id\":2450}},{\"nodeType\":3,\"id\":2469,\"textContent\":\"8\",\"parentNode\":{\"id\":2452}},{\"nodeType\":3,\"id\":2470,\"textContent\":\"9\",\"parentNode\":{\"id\":2454}},{\"nodeType\":3,\"id\":2471,\"textContent\":\"10\",\"parentNode\":{\"id\":2456}},{\"nodeType\":3,\"id\":2472,\"textContent\":\"11\",\"parentNode\":{\"id\":2458}},{\"nodeType\":3,\"id\":2473,\"textContent\":\"12\",\"parentNode\":{\"id\":2460}},{\"nodeType\":1,\"id\":2474,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2434}},{\"nodeType\":3,\"id\":2475,\"textContent\":\"DURATION (in hours)\",\"parentNode\":{\"id\":2474}},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2477,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2476},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2477},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2479,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2478},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2479},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2481,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2480},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2481},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2483,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2482},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2483},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2485,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2484},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2485},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2487,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2486},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2488,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"},\"parentNode\":{\"id\":2476}},{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"},\"parentNode\":{\"id\":2477}},{\"nodeType\":1,\"id\":2490,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"},\"parentNode\":{\"id\":2478}},{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"},\"parentNode\":{\"id\":2479}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"},\"parentNode\":{\"id\":2480}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"},\"parentNode\":{\"id\":2481}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"},\"parentNode\":{\"id\":2482}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"},\"parentNode\":{\"id\":2483}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"},\"parentNode\":{\"id\":2484}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"},\"parentNode\":{\"id\":2485}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"},\"parentNode\":{\"id\":2486}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"},\"parentNode\":{\"id\":2487}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2500},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2501},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2502},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2503},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2504},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2505},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2506},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2507},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2508},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2509},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2510},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2511},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2512},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2513},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2514},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2515},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2516},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2517},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2518},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2519},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2520},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2521},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2522},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2525,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2524},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2525},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2527,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2526},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2527},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2529,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2528},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2529},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2530},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2531},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2533,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2532},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2533},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2534},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2535},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2537,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2536},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2537},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2538},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2539},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2541,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2540},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"previousSibling\":{\"id\":2542},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2544,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2545,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"previousSibling\":{\"id\":2544},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2547,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2546},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2548,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2549,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2548},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"previousSibling\":{\"id\":2550},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2552,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2553,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2552},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"previousSibling\":{\"id\":2554},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2556,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2557,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2556},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2559,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"previousSibling\":{\"id\":2558},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2560,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2561,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2560},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"previousSibling\":{\"id\":2562},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2564,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2565,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"previousSibling\":{\"id\":2564},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2567,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"previousSibling\":{\"id\":2566},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2568,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2569,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2568},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2571,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"previousSibling\":{\"id\":2570},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2572,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2573,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"previousSibling\":{\"id\":2572},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2575,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2574},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2576,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2577,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2576},\"parentNode\":{\"id\":2541}},{\"nodeType\":3,\"id\":2578,\"textContent\":\"A \",\"parentNode\":{\"id\":2543}},{\"nodeType\":3,\"id\":2579,\"textContent\":\"B \",\"parentNode\":{\"id\":2545}},{\"nodeType\":3,\"id\":2580,\"textContent\":\"C \",\"parentNode\":{\"id\":2547}},{\"nodeType\":3,\"id\":2581,\"textContent\":\"D \",\"parentNode\":{\"id\":2549}},{\"nodeType\":3,\"id\":2582,\"textContent\":\"E \",\"parentNode\":{\"id\":2551}},{\"nodeType\":3,\"id\":2583,\"textContent\":\"F \",\"parentNode\":{\"id\":2553}},{\"nodeType\":3,\"id\":2584,\"textContent\":\"G \",\"parentNode\":{\"id\":2555}},{\"nodeType\":3,\"id\":2585,\"textContent\":\"H \",\"parentNode\":{\"id\":2557}},{\"nodeType\":3,\"id\":2586,\"textContent\":\"I \",\"parentNode\":{\"id\":2559}},{\"nodeType\":3,\"id\":2587,\"textContent\":\"J \",\"parentNode\":{\"id\":2561}},{\"nodeType\":3,\"id\":2588,\"textContent\":\"K \",\"parentNode\":{\"id\":2563}},{\"nodeType\":3,\"id\":2589,\"textContent\":\"L \",\"parentNode\":{\"id\":2565}},{\"nodeType\":3,\"id\":2590,\"textContent\":\"M \",\"parentNode\":{\"id\":2567}},{\"nodeType\":3,\"id\":2591,\"textContent\":\"N \",\"parentNode\":{\"id\":2569}},{\"nodeType\":3,\"id\":2592,\"textContent\":\"O \",\"parentNode\":{\"id\":2571}},{\"nodeType\":3,\"id\":2593,\"textContent\":\"P \",\"parentNode\":{\"id\":2573}},{\"nodeType\":3,\"id\":2594,\"textContent\":\"Z \",\"parentNode\":{\"id\":2575}},{\"nodeType\":3,\"id\":2595,\"textContent\":\"X \",\"parentNode\":{\"id\":2577}}],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2311},{\"id\":2316},{\"id\":2317},{\"id\":2343},{\"id\":2344},{\"id\":2393},{\"id\":2318},{\"id\":2345},{\"id\":2346},{\"id\":2394},{\"id\":2319},{\"id\":2347},{\"id\":2348},{\"id\":2395},{\"id\":2320},{\"id\":2349},{\"id\":2350},{\"id\":2396},{\"id\":2321},{\"id\":2351},{\"id\":2352},{\"id\":2397},{\"id\":2322},{\"id\":2353},{\"id\":2354},{\"id\":2398},{\"id\":2323},{\"id\":2355},{\"id\":2356},{\"id\":2399},{\"id\":2324},{\"id\":2357},{\"id\":2358},{\"id\":2400},{\"id\":2325},{\"id\":2359},{\"id\":2360},{\"id\":2401},{\"id\":2326},{\"id\":2361},{\"id\":2362},{\"id\":2402},{\"id\":2327},{\"id\":2363},{\"id\":2364},{\"id\":2403},{\"id\":2328},{\"id\":2365},{\"id\":2366},{\"id\":2404},{\"id\":2329},{\"id\":2367},{\"id\":2368},{\"id\":2405},{\"id\":2330},{\"id\":2369},{\"id\":2370},{\"id\":2406},{\"id\":2331},{\"id\":2371},{\"id\":2372},{\"id\":2407},{\"id\":2332},{\"id\":2373},{\"id\":2374},{\"id\":2408},{\"id\":2333},{\"id\":2375},{\"id\":2376},{\"id\":2409},{\"id\":2334},{\"id\":2377},{\"id\":2378},{\"id\":2410},{\"id\":2335},{\"id\":2379},{\"id\":2380},{\"id\":2411},{\"id\":2336},{\"id\":2381},{\"id\":2382},{\"id\":2412},{\"id\":2337},{\"id\":2383},{\"id\":2384},{\"id\":2413},{\"id\":2338},{\"id\":2385},{\"id\":2386},{\"id\":2414},{\"id\":2339},{\"id\":2387},{\"id\":2388},{\"id\":2415},{\"id\":2340},{\"id\":2389},{\"id\":2390},{\"id\":2416},{\"id\":2341},{\"id\":2391},{\"id\":2392},{\"id\":2417},{\"id\":2342},{\"id\":2418},{\"id\":2419},{\"id\":2312},{\"id\":2420},{\"id\":2421},{\"id\":2435},{\"id\":2436},{\"id\":2461},{\"id\":2422},{\"id\":2437},{\"id\":2438},{\"id\":2462},{\"id\":2423},{\"id\":2439},{\"id\":2440},{\"id\":2463},{\"id\":2424},{\"id\":2441},{\"id\":2442},{\"id\":2464},{\"id\":2425},{\"id\":2443},{\"id\":2444},{\"id\":2465},{\"id\":2426},{\"id\":2445},{\"id\":2446},{\"id\":2466},{\"id\":2427},{\"id\":2447},{\"id\":2448},{\"id\":2467},{\"id\":2428},{\"id\":2449},{\"id\":2450},{\"id\":2468},{\"id\":2429},{\"id\":2451},{\"id\":2452},{\"id\":2469},{\"id\":2430},{\"id\":2453},{\"id\":2454},{\"id\":2470},{\"id\":2431},{\"id\":2455},{\"id\":2456},{\"id\":2471},{\"id\":2432},{\"id\":2457},{\"id\":2458},{\"id\":2472},{\"id\":2433},{\"id\":2459},{\"id\":2460},{\"id\":2473},{\"id\":2434},{\"id\":2474},{\"id\":2475},{\"id\":2313},{\"id\":2476},{\"id\":2488},{\"id\":2477},{\"id\":2489},{\"id\":2478},{\"id\":2490},{\"id\":2479},{\"id\":2491},{\"id\":2480},{\"id\":2492},{\"id\":2481},{\"id\":2493},{\"id\":2482},{\"id\":2494},{\"id\":2483},{\"id\":2495},{\"id\":2484},{\"id\":2496},{\"id\":2485},{\"id\":2497},{\"id\":2486},{\"id\":2498},{\"id\":2487},{\"id\":2499},{\"id\":2314},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2315},{\"id\":2524},{\"id\":2542},{\"id\":2543},{\"id\":2578},{\"id\":2525},{\"id\":2544},{\"id\":2545},{\"id\":2579},{\"id\":2526},{\"id\":2546},{\"id\":2547},{\"id\":2580},{\"id\":2527},{\"id\":2548},{\"id\":2549},{\"id\":2581},{\"id\":2528},{\"id\":2550},{\"id\":2551},{\"id\":2582},{\"id\":2529},{\"id\":2552},{\"id\":2553},{\"id\":2583},{\"id\":2530},{\"id\":2554},{\"id\":2555},{\"id\":2584},{\"id\":2531},{\"id\":2556},{\"id\":2557},{\"id\":2585},{\"id\":2532},{\"id\":2558},{\"id\":2559},{\"id\":2586},{\"id\":2533},{\"id\":2560},{\"id\":2561},{\"id\":2587},{\"id\":2534},{\"id\":2562},{\"id\":2563},{\"id\":2588},{\"id\":2535},{\"id\":2564},{\"id\":2565},{\"id\":2589},{\"id\":2536},{\"id\":2566},{\"id\":2567},{\"id\":2590},{\"id\":2537},{\"id\":2568},{\"id\":2569},{\"id\":2591},{\"id\":2538},{\"id\":2570},{\"id\":2571},{\"id\":2592},{\"id\":2539},{\"id\":2572},{\"id\":2573},{\"id\":2593},{\"id\":2540},{\"id\":2574},{\"id\":2575},{\"id\":2594},{\"id\":2541},{\"id\":2576},{\"id\":2577},{\"id\":2595},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2308},{\"id\":2309},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2310}],[],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 458139, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 458146, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"VVH1B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 8366, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 467844, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"VVH1B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 13822, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"zulu\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"211\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 482671, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"VVH1B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 31232, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 515038, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"VVH1B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 16424, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 532466, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"VVH1B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 49620, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 583446, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"VVH1B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -11 AM-A -5-10 AM-11 AM-12 PM-12 PM-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1413,y:392,t:1528143453870};\\\", \\\"{x:1413,y:436,t:1528143453880};\\\", \\\"{x:1414,y:465,t:1528143453889};\\\", \\\"{x:1419,y:477,t:1528143453906};\\\", \\\"{x:1420,y:478,t:1528143453925};\\\", \\\"{x:1420,y:480,t:1528143453941};\\\", \\\"{x:1423,y:482,t:1528143453956};\\\", \\\"{x:1424,y:491,t:1528143453973};\\\", \\\"{x:1426,y:502,t:1528143453988};\\\", \\\"{x:1426,y:523,t:1528143454005};\\\", \\\"{x:1428,y:554,t:1528143454022};\\\", \\\"{x:1428,y:583,t:1528143454038};\\\", \\\"{x:1428,y:611,t:1528143454055};\\\", \\\"{x:1428,y:641,t:1528143454073};\\\", \\\"{x:1424,y:677,t:1528143454089};\\\", \\\"{x:1416,y:720,t:1528143454106};\\\", \\\"{x:1402,y:765,t:1528143454122};\\\", \\\"{x:1387,y:804,t:1528143454139};\\\", \\\"{x:1372,y:837,t:1528143454156};\\\", \\\"{x:1348,y:887,t:1528143454173};\\\", \\\"{x:1331,y:916,t:1528143454191};\\\", \\\"{x:1315,y:937,t:1528143454206};\\\", \\\"{x:1288,y:966,t:1528143454223};\\\", \\\"{x:1255,y:993,t:1528143454239};\\\", \\\"{x:1235,y:1004,t:1528143454256};\\\", \\\"{x:1219,y:1015,t:1528143454273};\\\", \\\"{x:1212,y:1019,t:1528143454290};\\\", \\\"{x:1203,y:1022,t:1528143454307};\\\", \\\"{x:1198,y:1024,t:1528143454323};\\\", \\\"{x:1194,y:1024,t:1528143454340};\\\", \\\"{x:1182,y:1024,t:1528143454357};\\\", \\\"{x:1177,y:1024,t:1528143454374};\\\", \\\"{x:1174,y:1024,t:1528143454389};\\\", \\\"{x:1173,y:1024,t:1528143454406};\\\", \\\"{x:1171,y:1024,t:1528143454438};\\\", \\\"{x:1176,y:1024,t:1528143454541};\\\", \\\"{x:1202,y:1019,t:1528143454555};\\\", \\\"{x:1275,y:1006,t:1528143454573};\\\", \\\"{x:1306,y:1002,t:1528143454590};\\\", \\\"{x:1337,y:997,t:1528143454606};\\\", \\\"{x:1347,y:993,t:1528143454623};\\\", \\\"{x:1347,y:992,t:1528143454640};\\\", \\\"{x:1346,y:991,t:1528143454662};\\\", \\\"{x:1342,y:989,t:1528143454673};\\\", \\\"{x:1329,y:986,t:1528143454690};\\\", \\\"{x:1323,y:985,t:1528143454706};\\\", \\\"{x:1317,y:984,t:1528143454723};\\\", \\\"{x:1316,y:983,t:1528143454782};\\\", \\\"{x:1315,y:982,t:1528143454942};\\\", \\\"{x:1314,y:982,t:1528143454982};\\\", \\\"{x:1311,y:983,t:1528143454998};\\\", \\\"{x:1309,y:983,t:1528143455007};\\\", \\\"{x:1303,y:985,t:1528143455023};\\\", \\\"{x:1299,y:985,t:1528143455040};\\\", \\\"{x:1296,y:985,t:1528143455058};\\\", \\\"{x:1291,y:985,t:1528143455074};\\\", \\\"{x:1289,y:985,t:1528143455090};\\\", \\\"{x:1289,y:984,t:1528143455231};\\\", \\\"{x:1287,y:983,t:1528143455241};\\\", \\\"{x:1287,y:982,t:1528143455366};\\\", \\\"{x:1286,y:982,t:1528143455886};\\\", \\\"{x:1285,y:982,t:1528143456078};\\\", \\\"{x:1284,y:981,t:1528143456118};\\\", \\\"{x:1283,y:981,t:1528143456142};\\\", \\\"{x:1281,y:979,t:1528143456158};\\\", \\\"{x:1280,y:979,t:1528143456174};\\\", \\\"{x:1280,y:977,t:1528143456191};\\\", \\\"{x:1280,y:976,t:1528143456254};\\\", \\\"{x:1279,y:976,t:1528143456357};\\\", \\\"{x:1279,y:975,t:1528143456585};\\\", \\\"{x:1279,y:974,t:1528143456595};\\\", \\\"{x:1279,y:973,t:1528143456612};\\\", \\\"{x:1279,y:971,t:1528143456629};\\\", \\\"{x:1279,y:970,t:1528143456645};\\\", \\\"{x:1279,y:968,t:1528143456786};\\\", \\\"{x:1279,y:964,t:1528143456874};\\\", \\\"{x:1279,y:963,t:1528143456882};\\\", \\\"{x:1279,y:960,t:1528143456896};\\\", \\\"{x:1279,y:952,t:1528143456913};\\\", \\\"{x:1279,y:942,t:1528143456929};\\\", \\\"{x:1279,y:938,t:1528143456945};\\\", \\\"{x:1279,y:937,t:1528143456962};\\\", \\\"{x:1279,y:936,t:1528143456994};\\\", \\\"{x:1279,y:935,t:1528143457026};\\\", \\\"{x:1277,y:934,t:1528143457041};\\\", \\\"{x:1276,y:933,t:1528143457057};\\\", \\\"{x:1275,y:932,t:1528143457066};\\\", \\\"{x:1275,y:931,t:1528143457079};\\\", \\\"{x:1274,y:929,t:1528143457095};\\\", \\\"{x:1273,y:925,t:1528143457112};\\\", \\\"{x:1271,y:919,t:1528143457129};\\\", \\\"{x:1269,y:914,t:1528143457146};\\\", \\\"{x:1267,y:909,t:1528143457162};\\\", \\\"{x:1267,y:903,t:1528143457179};\\\", \\\"{x:1265,y:895,t:1528143457197};\\\", \\\"{x:1264,y:887,t:1528143457212};\\\", \\\"{x:1263,y:875,t:1528143457229};\\\", \\\"{x:1263,y:869,t:1528143457247};\\\", \\\"{x:1263,y:865,t:1528143457262};\\\", \\\"{x:1263,y:861,t:1528143457279};\\\", \\\"{x:1264,y:858,t:1528143457296};\\\", \\\"{x:1264,y:857,t:1528143457313};\\\", \\\"{x:1265,y:854,t:1528143457329};\\\", \\\"{x:1268,y:850,t:1528143457346};\\\", \\\"{x:1272,y:842,t:1528143457362};\\\", \\\"{x:1274,y:841,t:1528143457379};\\\", \\\"{x:1280,y:841,t:1528143457396};\\\", \\\"{x:1284,y:841,t:1528143457412};\\\", \\\"{x:1287,y:841,t:1528143457429};\\\", \\\"{x:1291,y:840,t:1528143457446};\\\", \\\"{x:1292,y:840,t:1528143457462};\\\", \\\"{x:1293,y:839,t:1528143457482};\\\", \\\"{x:1293,y:838,t:1528143457618};\\\", \\\"{x:1292,y:838,t:1528143457642};\\\", \\\"{x:1292,y:837,t:1528143457658};\\\", \\\"{x:1291,y:837,t:1528143457681};\\\", \\\"{x:1290,y:836,t:1528143457698};\\\", \\\"{x:1289,y:836,t:1528143459153};\\\", \\\"{x:1287,y:836,t:1528143459164};\\\", \\\"{x:1286,y:835,t:1528143459179};\\\", \\\"{x:1285,y:835,t:1528143459197};\\\", \\\"{x:1284,y:834,t:1528143459300};\\\", \\\"{x:1284,y:833,t:1528143459314};\\\", \\\"{x:1284,y:832,t:1528143459330};\\\", \\\"{x:1263,y:821,t:1528143459924};\\\", \\\"{x:1187,y:808,t:1528143459930};\\\", \\\"{x:972,y:787,t:1528143459947};\\\", \\\"{x:778,y:785,t:1528143459964};\\\", \\\"{x:639,y:761,t:1528143459980};\\\", \\\"{x:525,y:722,t:1528143459998};\\\", \\\"{x:412,y:674,t:1528143460013};\\\", \\\"{x:327,y:629,t:1528143460031};\\\", \\\"{x:303,y:612,t:1528143460048};\\\", \\\"{x:297,y:607,t:1528143460064};\\\", \\\"{x:297,y:606,t:1528143460136};\\\", \\\"{x:297,y:604,t:1528143460160};\\\", \\\"{x:297,y:602,t:1528143460168};\\\", \\\"{x:297,y:600,t:1528143460181};\\\", \\\"{x:297,y:597,t:1528143460198};\\\", \\\"{x:299,y:593,t:1528143460215};\\\", \\\"{x:308,y:585,t:1528143460232};\\\", \\\"{x:320,y:575,t:1528143460249};\\\", \\\"{x:349,y:557,t:1528143460265};\\\", \\\"{x:363,y:546,t:1528143460281};\\\", \\\"{x:368,y:541,t:1528143460298};\\\", \\\"{x:371,y:538,t:1528143460314};\\\", \\\"{x:372,y:536,t:1528143460332};\\\", \\\"{x:373,y:535,t:1528143460349};\\\", \\\"{x:373,y:534,t:1528143460400};\\\", \\\"{x:374,y:534,t:1528143460417};\\\", \\\"{x:377,y:531,t:1528143460431};\\\", \\\"{x:382,y:528,t:1528143460448};\\\", \\\"{x:385,y:527,t:1528143460464};\\\", \\\"{x:386,y:527,t:1528143460625};\\\", \\\"{x:389,y:530,t:1528143460633};\\\", \\\"{x:389,y:536,t:1528143460650};\\\", \\\"{x:390,y:540,t:1528143460665};\\\", \\\"{x:390,y:544,t:1528143460682};\\\", \\\"{x:390,y:546,t:1528143460704};\\\", \\\"{x:390,y:548,t:1528143460721};\\\", \\\"{x:390,y:550,t:1528143460732};\\\", \\\"{x:390,y:555,t:1528143460749};\\\", \\\"{x:390,y:563,t:1528143460765};\\\", \\\"{x:390,y:572,t:1528143460782};\\\", \\\"{x:390,y:577,t:1528143460799};\\\", \\\"{x:390,y:581,t:1528143460815};\\\", \\\"{x:391,y:582,t:1528143460832};\\\", \\\"{x:394,y:588,t:1528143460848};\\\", \\\"{x:404,y:599,t:1528143460865};\\\", \\\"{x:413,y:605,t:1528143460882};\\\", \\\"{x:422,y:610,t:1528143460899};\\\", \\\"{x:431,y:614,t:1528143460915};\\\", \\\"{x:442,y:618,t:1528143460932};\\\", \\\"{x:449,y:618,t:1528143460949};\\\", \\\"{x:457,y:616,t:1528143460966};\\\", \\\"{x:462,y:608,t:1528143460983};\\\", \\\"{x:464,y:600,t:1528143460999};\\\", \\\"{x:464,y:597,t:1528143461014};\\\", \\\"{x:464,y:596,t:1528143461057};\\\", \\\"{x:463,y:595,t:1528143461065};\\\", \\\"{x:453,y:591,t:1528143461082};\\\", \\\"{x:441,y:584,t:1528143461099};\\\", \\\"{x:428,y:571,t:1528143461117};\\\", \\\"{x:420,y:562,t:1528143461131};\\\", \\\"{x:418,y:560,t:1528143461149};\\\", \\\"{x:417,y:558,t:1528143461165};\\\", \\\"{x:416,y:557,t:1528143461193};\\\", \\\"{x:415,y:557,t:1528143461208};\\\", \\\"{x:414,y:557,t:1528143461216};\\\", \\\"{x:411,y:555,t:1528143461231};\\\", \\\"{x:403,y:553,t:1528143461248};\\\", \\\"{x:400,y:551,t:1528143461265};\\\", \\\"{x:396,y:550,t:1528143461281};\\\", \\\"{x:389,y:547,t:1528143461299};\\\", \\\"{x:387,y:545,t:1528143461316};\\\", \\\"{x:386,y:544,t:1528143461360};\\\", \\\"{x:386,y:543,t:1528143461474};\\\", \\\"{x:386,y:538,t:1528143461483};\\\", \\\"{x:386,y:532,t:1528143461499};\\\", \\\"{x:385,y:528,t:1528143461516};\\\", \\\"{x:385,y:526,t:1528143461533};\\\", \\\"{x:385,y:525,t:1528143462546};\\\", \\\"{x:385,y:524,t:1528143462553};\\\", \\\"{x:389,y:523,t:1528143462566};\\\", \\\"{x:398,y:521,t:1528143462583};\\\", \\\"{x:406,y:521,t:1528143462600};\\\", \\\"{x:423,y:523,t:1528143462617};\\\", \\\"{x:432,y:525,t:1528143462633};\\\", \\\"{x:438,y:525,t:1528143462650};\\\", \\\"{x:450,y:525,t:1528143462666};\\\", \\\"{x:456,y:525,t:1528143462682};\\\", \\\"{x:461,y:525,t:1528143462700};\\\", \\\"{x:470,y:525,t:1528143462717};\\\", \\\"{x:478,y:526,t:1528143462732};\\\", \\\"{x:484,y:526,t:1528143462749};\\\", \\\"{x:491,y:526,t:1528143462766};\\\", \\\"{x:496,y:526,t:1528143462783};\\\", \\\"{x:500,y:526,t:1528143462801};\\\", \\\"{x:503,y:526,t:1528143462816};\\\", \\\"{x:505,y:526,t:1528143462834};\\\", \\\"{x:512,y:526,t:1528143463338};\\\", \\\"{x:523,y:526,t:1528143463352};\\\", \\\"{x:549,y:526,t:1528143463367};\\\", \\\"{x:600,y:528,t:1528143463385};\\\", \\\"{x:730,y:535,t:1528143463403};\\\", \\\"{x:820,y:543,t:1528143463417};\\\", \\\"{x:909,y:556,t:1528143463434};\\\", \\\"{x:964,y:567,t:1528143463451};\\\", \\\"{x:1000,y:571,t:1528143463467};\\\", \\\"{x:1018,y:575,t:1528143463484};\\\", \\\"{x:1028,y:576,t:1528143463500};\\\", \\\"{x:1031,y:576,t:1528143463517};\\\", \\\"{x:1035,y:578,t:1528143463534};\\\", \\\"{x:1036,y:578,t:1528143463551};\\\", \\\"{x:1037,y:578,t:1528143463568};\\\", \\\"{x:1037,y:579,t:1528143463584};\\\", \\\"{x:1038,y:579,t:1528143463600};\\\", \\\"{x:1041,y:580,t:1528143463617};\\\", \\\"{x:1041,y:581,t:1528143463633};\\\", \\\"{x:1043,y:584,t:1528143463650};\\\", \\\"{x:1044,y:586,t:1528143463667};\\\", \\\"{x:1046,y:589,t:1528143463684};\\\", \\\"{x:1047,y:596,t:1528143463701};\\\", \\\"{x:1049,y:599,t:1528143463718};\\\", \\\"{x:1051,y:604,t:1528143463734};\\\", \\\"{x:1053,y:607,t:1528143463751};\\\", \\\"{x:1055,y:612,t:1528143463768};\\\", \\\"{x:1057,y:617,t:1528143463784};\\\", \\\"{x:1063,y:626,t:1528143463801};\\\", \\\"{x:1067,y:630,t:1528143463819};\\\", \\\"{x:1071,y:637,t:1528143463834};\\\", \\\"{x:1078,y:645,t:1528143463851};\\\", \\\"{x:1082,y:650,t:1528143463868};\\\", \\\"{x:1087,y:657,t:1528143463884};\\\", \\\"{x:1094,y:666,t:1528143463901};\\\", \\\"{x:1101,y:679,t:1528143463918};\\\", \\\"{x:1109,y:692,t:1528143463934};\\\", \\\"{x:1115,y:701,t:1528143463951};\\\", \\\"{x:1125,y:717,t:1528143463968};\\\", \\\"{x:1132,y:730,t:1528143463984};\\\", \\\"{x:1146,y:752,t:1528143464000};\\\", \\\"{x:1152,y:769,t:1528143464018};\\\", \\\"{x:1157,y:776,t:1528143464034};\\\", \\\"{x:1161,y:785,t:1528143464051};\\\", \\\"{x:1164,y:792,t:1528143464068};\\\", \\\"{x:1166,y:801,t:1528143464085};\\\", \\\"{x:1169,y:812,t:1528143464102};\\\", \\\"{x:1174,y:827,t:1528143464118};\\\", \\\"{x:1177,y:840,t:1528143464135};\\\", \\\"{x:1184,y:854,t:1528143464151};\\\", \\\"{x:1186,y:861,t:1528143464169};\\\", \\\"{x:1188,y:867,t:1528143464185};\\\", \\\"{x:1189,y:871,t:1528143464201};\\\", \\\"{x:1189,y:875,t:1528143464218};\\\", \\\"{x:1190,y:880,t:1528143464236};\\\", \\\"{x:1190,y:886,t:1528143464252};\\\", \\\"{x:1192,y:891,t:1528143464269};\\\", \\\"{x:1193,y:896,t:1528143464285};\\\", \\\"{x:1197,y:906,t:1528143464301};\\\", \\\"{x:1198,y:913,t:1528143464318};\\\", \\\"{x:1204,y:926,t:1528143464336};\\\", \\\"{x:1212,y:941,t:1528143464351};\\\", \\\"{x:1221,y:954,t:1528143464369};\\\", \\\"{x:1233,y:969,t:1528143464386};\\\", \\\"{x:1239,y:976,t:1528143464401};\\\", \\\"{x:1244,y:983,t:1528143464418};\\\", \\\"{x:1250,y:991,t:1528143464436};\\\", \\\"{x:1254,y:994,t:1528143464451};\\\", \\\"{x:1257,y:996,t:1528143464468};\\\", \\\"{x:1258,y:997,t:1528143464486};\\\", \\\"{x:1259,y:998,t:1528143464502};\\\", \\\"{x:1261,y:998,t:1528143464882};\\\", \\\"{x:1265,y:998,t:1528143464889};\\\", \\\"{x:1271,y:997,t:1528143464902};\\\", \\\"{x:1278,y:996,t:1528143464918};\\\", \\\"{x:1282,y:996,t:1528143464935};\\\", \\\"{x:1284,y:995,t:1528143464952};\\\", \\\"{x:1285,y:995,t:1528143465178};\\\", \\\"{x:1286,y:995,t:1528143465186};\\\", \\\"{x:1289,y:995,t:1528143465202};\\\", \\\"{x:1293,y:995,t:1528143465219};\\\", \\\"{x:1299,y:996,t:1528143465235};\\\", \\\"{x:1301,y:997,t:1528143465253};\\\", \\\"{x:1302,y:997,t:1528143465274};\\\", \\\"{x:1303,y:997,t:1528143465286};\\\", \\\"{x:1303,y:998,t:1528143465303};\\\", \\\"{x:1306,y:998,t:1528143465319};\\\", \\\"{x:1308,y:1000,t:1528143465335};\\\", \\\"{x:1310,y:1000,t:1528143465352};\\\", \\\"{x:1311,y:1001,t:1528143465369};\\\", \\\"{x:1312,y:1002,t:1528143465385};\\\", \\\"{x:1313,y:1002,t:1528143465403};\\\", \\\"{x:1314,y:1002,t:1528143465425};\\\", \\\"{x:1316,y:1002,t:1528143465435};\\\", \\\"{x:1317,y:1003,t:1528143465452};\\\", \\\"{x:1319,y:1004,t:1528143465470};\\\", \\\"{x:1320,y:1005,t:1528143465486};\\\", \\\"{x:1324,y:1006,t:1528143465502};\\\", \\\"{x:1327,y:1008,t:1528143465520};\\\", \\\"{x:1329,y:1008,t:1528143465536};\\\", \\\"{x:1330,y:1009,t:1528143465561};\\\", \\\"{x:1331,y:1010,t:1528143465569};\\\", \\\"{x:1332,y:1011,t:1528143465801};\\\", \\\"{x:1333,y:1011,t:1528143465820};\\\", \\\"{x:1334,y:1011,t:1528143465837};\\\", \\\"{x:1335,y:1011,t:1528143465853};\\\", \\\"{x:1336,y:1013,t:1528143465869};\\\", \\\"{x:1337,y:1014,t:1528143465905};\\\", \\\"{x:1339,y:1014,t:1528143465919};\\\", \\\"{x:1339,y:1015,t:1528143465937};\\\", \\\"{x:1341,y:1016,t:1528143465953};\\\", \\\"{x:1341,y:1017,t:1528143465969};\\\", \\\"{x:1342,y:1020,t:1528143465986};\\\", \\\"{x:1343,y:1023,t:1528143466003};\\\", \\\"{x:1345,y:1027,t:1528143466020};\\\", \\\"{x:1346,y:1028,t:1528143466036};\\\", \\\"{x:1347,y:1028,t:1528143466055};\\\", \\\"{x:1347,y:1030,t:1528143466097};\\\", \\\"{x:1348,y:1030,t:1528143466114};\\\", \\\"{x:1349,y:1030,t:1528143466130};\\\", \\\"{x:1349,y:1031,t:1528143466162};\\\", \\\"{x:1350,y:1031,t:1528143466169};\\\", \\\"{x:1350,y:1032,t:1528143466217};\\\", \\\"{x:1352,y:1033,t:1528143466225};\\\", \\\"{x:1352,y:1034,t:1528143466236};\\\", \\\"{x:1356,y:1036,t:1528143466256};\\\", \\\"{x:1358,y:1037,t:1528143466270};\\\", \\\"{x:1359,y:1038,t:1528143466286};\\\", \\\"{x:1361,y:1038,t:1528143466922};\\\", \\\"{x:1356,y:1036,t:1528143466945};\\\", \\\"{x:1352,y:1035,t:1528143466953};\\\", \\\"{x:1344,y:1031,t:1528143466970};\\\", \\\"{x:1340,y:1029,t:1528143466988};\\\", \\\"{x:1339,y:1029,t:1528143467010};\\\", \\\"{x:1338,y:1029,t:1528143467266};\\\", \\\"{x:1334,y:1027,t:1528143467273};\\\", \\\"{x:1326,y:1023,t:1528143467287};\\\", \\\"{x:1320,y:1021,t:1528143467303};\\\", \\\"{x:1312,y:1018,t:1528143467320};\\\", \\\"{x:1294,y:1008,t:1528143467337};\\\", \\\"{x:1287,y:1002,t:1528143467353};\\\", \\\"{x:1285,y:1001,t:1528143467371};\\\", \\\"{x:1285,y:1000,t:1528143467498};\\\", \\\"{x:1288,y:996,t:1528143467505};\\\", \\\"{x:1291,y:990,t:1528143467520};\\\", \\\"{x:1296,y:983,t:1528143467537};\\\", \\\"{x:1296,y:981,t:1528143467554};\\\", \\\"{x:1296,y:980,t:1528143467570};\\\", \\\"{x:1296,y:979,t:1528143467673};\\\", \\\"{x:1296,y:978,t:1528143467688};\\\", \\\"{x:1295,y:978,t:1528143467705};\\\", \\\"{x:1295,y:977,t:1528143467721};\\\", \\\"{x:1294,y:976,t:1528143467737};\\\", \\\"{x:1292,y:975,t:1528143467759};\\\", \\\"{x:1291,y:974,t:1528143467800};\\\", \\\"{x:1290,y:973,t:1528143467816};\\\", \\\"{x:1290,y:972,t:1528143467824};\\\", \\\"{x:1288,y:971,t:1528143467849};\\\", \\\"{x:1288,y:970,t:1528143467993};\\\", \\\"{x:1287,y:967,t:1528143468338};\\\", \\\"{x:1287,y:952,t:1528143468354};\\\", \\\"{x:1287,y:944,t:1528143468372};\\\", \\\"{x:1287,y:933,t:1528143468388};\\\", \\\"{x:1287,y:928,t:1528143468405};\\\", \\\"{x:1287,y:925,t:1528143468421};\\\", \\\"{x:1287,y:918,t:1528143468439};\\\", \\\"{x:1287,y:912,t:1528143468454};\\\", \\\"{x:1287,y:906,t:1528143468471};\\\", \\\"{x:1287,y:900,t:1528143468488};\\\", \\\"{x:1287,y:895,t:1528143468504};\\\", \\\"{x:1287,y:886,t:1528143468521};\\\", \\\"{x:1286,y:884,t:1528143468539};\\\", \\\"{x:1286,y:882,t:1528143468555};\\\", \\\"{x:1285,y:881,t:1528143468571};\\\", \\\"{x:1285,y:879,t:1528143468589};\\\", \\\"{x:1284,y:873,t:1528143468605};\\\", \\\"{x:1283,y:865,t:1528143468622};\\\", \\\"{x:1281,y:861,t:1528143468639};\\\", \\\"{x:1279,y:858,t:1528143468654};\\\", \\\"{x:1278,y:855,t:1528143468672};\\\", \\\"{x:1278,y:853,t:1528143468689};\\\", \\\"{x:1276,y:852,t:1528143468705};\\\", \\\"{x:1273,y:845,t:1528143468721};\\\", \\\"{x:1271,y:841,t:1528143468738};\\\", \\\"{x:1271,y:840,t:1528143468761};\\\", \\\"{x:1270,y:840,t:1528143468834};\\\", \\\"{x:1270,y:839,t:1528143469090};\\\", \\\"{x:1272,y:839,t:1528143469105};\\\", \\\"{x:1274,y:838,t:1528143469122};\\\", \\\"{x:1277,y:837,t:1528143469138};\\\", \\\"{x:1277,y:836,t:1528143469194};\\\", \\\"{x:1278,y:836,t:1528143469258};\\\", \\\"{x:1279,y:836,t:1528143469281};\\\", \\\"{x:1280,y:836,t:1528143469313};\\\", \\\"{x:1281,y:843,t:1528143479473};\\\", \\\"{x:1294,y:880,t:1528143479481};\\\", \\\"{x:1313,y:905,t:1528143479496};\\\", \\\"{x:1362,y:971,t:1528143479513};\\\", \\\"{x:1392,y:1011,t:1528143479530};\\\", \\\"{x:1405,y:1032,t:1528143479546};\\\", \\\"{x:1415,y:1049,t:1528143479564};\\\", \\\"{x:1418,y:1053,t:1528143479580};\\\", \\\"{x:1413,y:1047,t:1528143479834};\\\", \\\"{x:1405,y:1037,t:1528143479846};\\\", \\\"{x:1389,y:1019,t:1528143479863};\\\", \\\"{x:1372,y:1001,t:1528143479881};\\\", \\\"{x:1359,y:990,t:1528143479898};\\\", \\\"{x:1359,y:989,t:1528143479914};\\\", \\\"{x:1358,y:989,t:1528143479985};\\\", \\\"{x:1356,y:988,t:1528143480001};\\\", \\\"{x:1352,y:987,t:1528143480014};\\\", \\\"{x:1329,y:982,t:1528143480030};\\\", \\\"{x:1288,y:975,t:1528143480048};\\\", \\\"{x:1229,y:965,t:1528143480063};\\\", \\\"{x:1146,y:952,t:1528143480080};\\\", \\\"{x:1000,y:933,t:1528143480097};\\\", \\\"{x:924,y:920,t:1528143480113};\\\", \\\"{x:857,y:910,t:1528143480130};\\\", \\\"{x:833,y:898,t:1528143480147};\\\", \\\"{x:818,y:892,t:1528143480163};\\\", \\\"{x:810,y:889,t:1528143480180};\\\", \\\"{x:805,y:886,t:1528143480197};\\\", \\\"{x:804,y:885,t:1528143480213};\\\", \\\"{x:798,y:881,t:1528143480230};\\\", \\\"{x:789,y:875,t:1528143480247};\\\", \\\"{x:776,y:866,t:1528143480263};\\\", \\\"{x:758,y:855,t:1528143480279};\\\", \\\"{x:724,y:835,t:1528143480296};\\\", \\\"{x:706,y:827,t:1528143480313};\\\", \\\"{x:694,y:819,t:1528143480329};\\\", \\\"{x:687,y:815,t:1528143480347};\\\", \\\"{x:683,y:809,t:1528143480363};\\\", \\\"{x:679,y:803,t:1528143480379};\\\", \\\"{x:673,y:795,t:1528143480397};\\\", \\\"{x:665,y:787,t:1528143480413};\\\", \\\"{x:653,y:781,t:1528143480429};\\\", \\\"{x:639,y:771,t:1528143480446};\\\", \\\"{x:627,y:765,t:1528143480464};\\\", \\\"{x:612,y:759,t:1528143480480};\\\", \\\"{x:590,y:749,t:1528143480496};\\\", \\\"{x:573,y:741,t:1528143480513};\\\", \\\"{x:557,y:734,t:1528143480530};\\\", \\\"{x:542,y:729,t:1528143480546};\\\", \\\"{x:534,y:727,t:1528143480563};\\\", \\\"{x:531,y:726,t:1528143480580};\\\", \\\"{x:529,y:725,t:1528143480648};\\\" ] }, { \\\"rt\\\": 29224, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 613928, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"VVH1B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -D -D -E -E -D -E -E -04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:534,y:726,t:1528143505169};\\\", \\\"{x:541,y:727,t:1528143505183};\\\", \\\"{x:591,y:722,t:1528143505201};\\\", \\\"{x:612,y:721,t:1528143505217};\\\", \\\"{x:620,y:721,t:1528143505233};\\\", \\\"{x:625,y:721,t:1528143505250};\\\", \\\"{x:627,y:720,t:1528143505266};\\\", \\\"{x:628,y:720,t:1528143505283};\\\", \\\"{x:634,y:719,t:1528143505300};\\\", \\\"{x:639,y:718,t:1528143505316};\\\", \\\"{x:649,y:718,t:1528143505333};\\\", \\\"{x:656,y:718,t:1528143505350};\\\", \\\"{x:666,y:718,t:1528143505366};\\\", \\\"{x:673,y:718,t:1528143505383};\\\", \\\"{x:681,y:719,t:1528143505400};\\\", \\\"{x:689,y:721,t:1528143505417};\\\", \\\"{x:696,y:723,t:1528143505433};\\\", \\\"{x:704,y:725,t:1528143505450};\\\", \\\"{x:716,y:729,t:1528143505467};\\\", \\\"{x:731,y:734,t:1528143505483};\\\", \\\"{x:741,y:738,t:1528143505500};\\\", \\\"{x:754,y:741,t:1528143505518};\\\", \\\"{x:764,y:745,t:1528143505534};\\\", \\\"{x:771,y:750,t:1528143505550};\\\", \\\"{x:779,y:754,t:1528143505568};\\\", \\\"{x:787,y:759,t:1528143505584};\\\", \\\"{x:800,y:766,t:1528143505600};\\\", \\\"{x:807,y:770,t:1528143505617};\\\", \\\"{x:814,y:772,t:1528143505633};\\\", \\\"{x:822,y:775,t:1528143505651};\\\", \\\"{x:830,y:776,t:1528143505667};\\\", \\\"{x:841,y:779,t:1528143505684};\\\", \\\"{x:853,y:781,t:1528143505701};\\\", \\\"{x:866,y:783,t:1528143505717};\\\", \\\"{x:878,y:784,t:1528143505733};\\\", \\\"{x:889,y:784,t:1528143505750};\\\", \\\"{x:904,y:784,t:1528143505767};\\\", \\\"{x:938,y:784,t:1528143505783};\\\", \\\"{x:960,y:784,t:1528143505801};\\\", \\\"{x:975,y:784,t:1528143505818};\\\", \\\"{x:986,y:784,t:1528143505834};\\\", \\\"{x:1002,y:784,t:1528143505851};\\\", \\\"{x:1017,y:784,t:1528143505868};\\\", \\\"{x:1032,y:784,t:1528143505885};\\\", \\\"{x:1047,y:783,t:1528143505901};\\\", \\\"{x:1060,y:780,t:1528143505917};\\\", \\\"{x:1078,y:777,t:1528143505935};\\\", \\\"{x:1102,y:772,t:1528143505951};\\\", \\\"{x:1126,y:765,t:1528143505968};\\\", \\\"{x:1167,y:757,t:1528143505985};\\\", \\\"{x:1209,y:751,t:1528143506000};\\\", \\\"{x:1251,y:745,t:1528143506018};\\\", \\\"{x:1280,y:741,t:1528143506035};\\\", \\\"{x:1288,y:738,t:1528143506051};\\\", \\\"{x:1294,y:735,t:1528143506068};\\\", \\\"{x:1300,y:734,t:1528143506085};\\\", \\\"{x:1305,y:733,t:1528143506102};\\\", \\\"{x:1306,y:732,t:1528143506118};\\\", \\\"{x:1308,y:732,t:1528143506256};\\\", \\\"{x:1310,y:732,t:1528143506272};\\\", \\\"{x:1311,y:732,t:1528143506288};\\\", \\\"{x:1312,y:733,t:1528143506301};\\\", \\\"{x:1312,y:734,t:1528143506329};\\\", \\\"{x:1312,y:735,t:1528143506336};\\\", \\\"{x:1312,y:736,t:1528143506352};\\\", \\\"{x:1312,y:737,t:1528143506368};\\\", \\\"{x:1312,y:738,t:1528143506385};\\\", \\\"{x:1312,y:739,t:1528143506417};\\\", \\\"{x:1312,y:740,t:1528143506481};\\\", \\\"{x:1312,y:741,t:1528143506488};\\\", \\\"{x:1312,y:742,t:1528143506504};\\\", \\\"{x:1312,y:743,t:1528143506520};\\\", \\\"{x:1312,y:744,t:1528143506535};\\\", \\\"{x:1312,y:746,t:1528143506552};\\\", \\\"{x:1312,y:749,t:1528143506568};\\\", \\\"{x:1313,y:752,t:1528143506585};\\\", \\\"{x:1313,y:754,t:1528143506602};\\\", \\\"{x:1313,y:758,t:1528143506618};\\\", \\\"{x:1313,y:759,t:1528143506634};\\\", \\\"{x:1313,y:760,t:1528143506652};\\\", \\\"{x:1313,y:761,t:1528143506667};\\\", \\\"{x:1313,y:762,t:1528143506769};\\\", \\\"{x:1313,y:763,t:1528143506808};\\\", \\\"{x:1313,y:764,t:1528143506825};\\\", \\\"{x:1313,y:765,t:1528143506848};\\\", \\\"{x:1313,y:768,t:1528143506873};\\\", \\\"{x:1313,y:771,t:1528143506885};\\\", \\\"{x:1313,y:777,t:1528143506902};\\\", \\\"{x:1312,y:782,t:1528143506919};\\\", \\\"{x:1312,y:786,t:1528143506935};\\\", \\\"{x:1312,y:793,t:1528143506952};\\\", \\\"{x:1312,y:797,t:1528143506969};\\\", \\\"{x:1312,y:804,t:1528143506984};\\\", \\\"{x:1310,y:808,t:1528143507002};\\\", \\\"{x:1308,y:810,t:1528143507019};\\\", \\\"{x:1307,y:814,t:1528143507035};\\\", \\\"{x:1305,y:819,t:1528143507052};\\\", \\\"{x:1304,y:823,t:1528143507068};\\\", \\\"{x:1303,y:825,t:1528143507085};\\\", \\\"{x:1302,y:827,t:1528143507101};\\\", \\\"{x:1302,y:829,t:1528143507118};\\\", \\\"{x:1302,y:831,t:1528143507134};\\\", \\\"{x:1302,y:836,t:1528143507152};\\\", \\\"{x:1302,y:845,t:1528143507168};\\\", \\\"{x:1302,y:847,t:1528143507184};\\\", \\\"{x:1302,y:849,t:1528143507202};\\\", \\\"{x:1302,y:851,t:1528143507219};\\\", \\\"{x:1302,y:854,t:1528143507234};\\\", \\\"{x:1302,y:858,t:1528143507251};\\\", \\\"{x:1302,y:860,t:1528143507268};\\\", \\\"{x:1302,y:863,t:1528143507285};\\\", \\\"{x:1303,y:866,t:1528143507301};\\\", \\\"{x:1304,y:867,t:1528143507318};\\\", \\\"{x:1305,y:869,t:1528143507336};\\\", \\\"{x:1306,y:870,t:1528143507352};\\\", \\\"{x:1309,y:876,t:1528143507368};\\\", \\\"{x:1312,y:880,t:1528143507385};\\\", \\\"{x:1313,y:883,t:1528143507401};\\\", \\\"{x:1314,y:884,t:1528143507419};\\\", \\\"{x:1316,y:886,t:1528143507436};\\\", \\\"{x:1317,y:888,t:1528143507452};\\\", \\\"{x:1320,y:890,t:1528143507468};\\\", \\\"{x:1325,y:894,t:1528143507486};\\\", \\\"{x:1332,y:895,t:1528143507502};\\\", \\\"{x:1346,y:899,t:1528143507520};\\\", \\\"{x:1367,y:905,t:1528143507536};\\\", \\\"{x:1369,y:905,t:1528143507552};\\\", \\\"{x:1371,y:903,t:1528143509081};\\\", \\\"{x:1377,y:871,t:1528143509089};\\\", \\\"{x:1386,y:838,t:1528143509104};\\\", \\\"{x:1392,y:808,t:1528143509121};\\\", \\\"{x:1398,y:789,t:1528143509137};\\\", \\\"{x:1401,y:776,t:1528143509153};\\\", \\\"{x:1403,y:763,t:1528143509170};\\\", \\\"{x:1405,y:752,t:1528143509188};\\\", \\\"{x:1406,y:744,t:1528143509204};\\\", \\\"{x:1408,y:734,t:1528143509220};\\\", \\\"{x:1411,y:725,t:1528143509237};\\\", \\\"{x:1415,y:715,t:1528143509254};\\\", \\\"{x:1421,y:704,t:1528143509270};\\\", \\\"{x:1426,y:697,t:1528143509287};\\\", \\\"{x:1435,y:683,t:1528143509304};\\\", \\\"{x:1441,y:677,t:1528143509320};\\\", \\\"{x:1449,y:667,t:1528143509336};\\\", \\\"{x:1454,y:659,t:1528143509355};\\\", \\\"{x:1461,y:649,t:1528143509371};\\\", \\\"{x:1465,y:643,t:1528143509387};\\\", \\\"{x:1465,y:642,t:1528143509416};\\\", \\\"{x:1466,y:642,t:1528143509440};\\\", \\\"{x:1466,y:639,t:1528143509617};\\\", \\\"{x:1468,y:633,t:1528143509625};\\\", \\\"{x:1472,y:624,t:1528143509637};\\\", \\\"{x:1484,y:601,t:1528143509654};\\\", \\\"{x:1503,y:575,t:1528143509671};\\\", \\\"{x:1534,y:535,t:1528143509688};\\\", \\\"{x:1569,y:490,t:1528143509704};\\\", \\\"{x:1577,y:472,t:1528143509720};\\\", \\\"{x:1580,y:463,t:1528143509737};\\\", \\\"{x:1584,y:454,t:1528143509754};\\\", \\\"{x:1588,y:447,t:1528143509771};\\\", \\\"{x:1590,y:443,t:1528143509787};\\\", \\\"{x:1590,y:442,t:1528143509804};\\\", \\\"{x:1591,y:441,t:1528143509821};\\\", \\\"{x:1591,y:439,t:1528143509865};\\\", \\\"{x:1593,y:435,t:1528143509872};\\\", \\\"{x:1595,y:433,t:1528143509887};\\\", \\\"{x:1605,y:426,t:1528143509904};\\\", \\\"{x:1608,y:421,t:1528143509920};\\\", \\\"{x:1611,y:416,t:1528143509937};\\\", \\\"{x:1613,y:414,t:1528143509954};\\\", \\\"{x:1614,y:414,t:1528143509971};\\\", \\\"{x:1615,y:414,t:1528143509992};\\\", \\\"{x:1618,y:414,t:1528143510005};\\\", \\\"{x:1619,y:414,t:1528143510021};\\\", \\\"{x:1623,y:414,t:1528143510037};\\\", \\\"{x:1625,y:415,t:1528143510054};\\\", \\\"{x:1626,y:415,t:1528143510071};\\\", \\\"{x:1627,y:416,t:1528143510088};\\\", \\\"{x:1628,y:417,t:1528143510144};\\\", \\\"{x:1628,y:418,t:1528143510161};\\\", \\\"{x:1628,y:420,t:1528143510170};\\\", \\\"{x:1628,y:421,t:1528143510192};\\\", \\\"{x:1628,y:422,t:1528143510204};\\\", \\\"{x:1628,y:423,t:1528143510224};\\\", \\\"{x:1628,y:424,t:1528143510240};\\\", \\\"{x:1628,y:425,t:1528143510254};\\\", \\\"{x:1627,y:427,t:1528143510271};\\\", \\\"{x:1626,y:429,t:1528143510288};\\\", \\\"{x:1626,y:430,t:1528143510305};\\\", \\\"{x:1625,y:431,t:1528143510320};\\\", \\\"{x:1623,y:432,t:1528143510338};\\\", \\\"{x:1622,y:433,t:1528143510354};\\\", \\\"{x:1618,y:434,t:1528143510371};\\\", \\\"{x:1616,y:435,t:1528143510388};\\\", \\\"{x:1615,y:435,t:1528143510403};\\\", \\\"{x:1613,y:435,t:1528143510421};\\\", \\\"{x:1612,y:435,t:1528143510438};\\\", \\\"{x:1611,y:436,t:1528143510769};\\\", \\\"{x:1611,y:442,t:1528143510777};\\\", \\\"{x:1611,y:448,t:1528143510788};\\\", \\\"{x:1611,y:458,t:1528143510805};\\\", \\\"{x:1611,y:466,t:1528143510821};\\\", \\\"{x:1611,y:473,t:1528143510838};\\\", \\\"{x:1611,y:477,t:1528143510855};\\\", \\\"{x:1611,y:480,t:1528143510871};\\\", \\\"{x:1611,y:483,t:1528143510888};\\\", \\\"{x:1611,y:485,t:1528143510904};\\\", \\\"{x:1611,y:487,t:1528143510921};\\\", \\\"{x:1611,y:490,t:1528143510938};\\\", \\\"{x:1610,y:491,t:1528143510955};\\\", \\\"{x:1610,y:493,t:1528143510976};\\\", \\\"{x:1610,y:494,t:1528143510992};\\\", \\\"{x:1610,y:496,t:1528143511005};\\\", \\\"{x:1610,y:505,t:1528143511022};\\\", \\\"{x:1610,y:516,t:1528143511039};\\\", \\\"{x:1610,y:529,t:1528143511055};\\\", \\\"{x:1610,y:538,t:1528143511072};\\\", \\\"{x:1610,y:549,t:1528143511088};\\\", \\\"{x:1610,y:552,t:1528143511104};\\\", \\\"{x:1610,y:553,t:1528143511121};\\\", \\\"{x:1610,y:554,t:1528143511344};\\\", \\\"{x:1610,y:557,t:1528143511355};\\\", \\\"{x:1610,y:563,t:1528143511372};\\\", \\\"{x:1610,y:565,t:1528143511387};\\\", \\\"{x:1610,y:566,t:1528143511404};\\\", \\\"{x:1611,y:567,t:1528143511422};\\\", \\\"{x:1611,y:563,t:1528143513377};\\\", \\\"{x:1611,y:558,t:1528143513391};\\\", \\\"{x:1609,y:551,t:1528143513406};\\\", \\\"{x:1608,y:544,t:1528143513424};\\\", \\\"{x:1608,y:539,t:1528143513440};\\\", \\\"{x:1608,y:538,t:1528143513456};\\\", \\\"{x:1607,y:536,t:1528143513473};\\\", \\\"{x:1607,y:535,t:1528143513490};\\\", \\\"{x:1607,y:533,t:1528143513507};\\\", \\\"{x:1607,y:530,t:1528143513524};\\\", \\\"{x:1607,y:526,t:1528143513540};\\\", \\\"{x:1607,y:521,t:1528143513557};\\\", \\\"{x:1607,y:513,t:1528143513573};\\\", \\\"{x:1607,y:505,t:1528143513590};\\\", \\\"{x:1607,y:494,t:1528143513608};\\\", \\\"{x:1607,y:481,t:1528143513624};\\\", \\\"{x:1612,y:460,t:1528143513640};\\\", \\\"{x:1616,y:448,t:1528143513656};\\\", \\\"{x:1619,y:440,t:1528143513674};\\\", \\\"{x:1620,y:436,t:1528143513691};\\\", \\\"{x:1621,y:432,t:1528143513707};\\\", \\\"{x:1621,y:430,t:1528143513729};\\\", \\\"{x:1621,y:429,t:1528143513744};\\\", \\\"{x:1621,y:428,t:1528143513758};\\\", \\\"{x:1621,y:425,t:1528143513773};\\\", \\\"{x:1621,y:423,t:1528143513790};\\\", \\\"{x:1621,y:422,t:1528143513816};\\\", \\\"{x:1620,y:422,t:1528143513961};\\\", \\\"{x:1619,y:423,t:1528143513984};\\\", \\\"{x:1618,y:427,t:1528143513992};\\\", \\\"{x:1618,y:430,t:1528143514007};\\\", \\\"{x:1616,y:439,t:1528143514025};\\\", \\\"{x:1615,y:446,t:1528143514040};\\\", \\\"{x:1614,y:456,t:1528143514057};\\\", \\\"{x:1611,y:469,t:1528143514074};\\\", \\\"{x:1610,y:484,t:1528143514090};\\\", \\\"{x:1609,y:496,t:1528143514107};\\\", \\\"{x:1609,y:502,t:1528143514125};\\\", \\\"{x:1609,y:508,t:1528143514140};\\\", \\\"{x:1607,y:516,t:1528143514157};\\\", \\\"{x:1606,y:526,t:1528143514175};\\\", \\\"{x:1606,y:541,t:1528143514191};\\\", \\\"{x:1605,y:554,t:1528143514207};\\\", \\\"{x:1602,y:571,t:1528143514224};\\\", \\\"{x:1602,y:579,t:1528143514240};\\\", \\\"{x:1601,y:584,t:1528143514258};\\\", \\\"{x:1597,y:593,t:1528143514274};\\\", \\\"{x:1590,y:605,t:1528143514290};\\\", \\\"{x:1575,y:622,t:1528143514307};\\\", \\\"{x:1549,y:639,t:1528143514325};\\\", \\\"{x:1494,y:664,t:1528143514341};\\\", \\\"{x:1411,y:684,t:1528143514358};\\\", \\\"{x:1313,y:704,t:1528143514374};\\\", \\\"{x:1215,y:721,t:1528143514391};\\\", \\\"{x:1130,y:731,t:1528143514408};\\\", \\\"{x:1001,y:746,t:1528143514424};\\\", \\\"{x:932,y:754,t:1528143514440};\\\", \\\"{x:892,y:756,t:1528143514457};\\\", \\\"{x:871,y:756,t:1528143514474};\\\", \\\"{x:849,y:749,t:1528143514491};\\\", \\\"{x:795,y:731,t:1528143514507};\\\", \\\"{x:710,y:694,t:1528143514524};\\\", \\\"{x:600,y:651,t:1528143514541};\\\", \\\"{x:522,y:615,t:1528143514557};\\\", \\\"{x:489,y:602,t:1528143514576};\\\", \\\"{x:479,y:596,t:1528143514590};\\\", \\\"{x:479,y:595,t:1528143514607};\\\", \\\"{x:479,y:593,t:1528143514664};\\\", \\\"{x:479,y:588,t:1528143514674};\\\", \\\"{x:480,y:577,t:1528143514691};\\\", \\\"{x:480,y:575,t:1528143514708};\\\", \\\"{x:480,y:574,t:1528143514744};\\\", \\\"{x:478,y:574,t:1528143514767};\\\", \\\"{x:473,y:571,t:1528143514775};\\\", \\\"{x:459,y:571,t:1528143514791};\\\", \\\"{x:414,y:571,t:1528143514807};\\\", \\\"{x:375,y:576,t:1528143514825};\\\", \\\"{x:327,y:590,t:1528143514842};\\\", \\\"{x:285,y:603,t:1528143514857};\\\", \\\"{x:268,y:608,t:1528143514876};\\\", \\\"{x:263,y:609,t:1528143514890};\\\", \\\"{x:262,y:609,t:1528143514908};\\\", \\\"{x:260,y:609,t:1528143514952};\\\", \\\"{x:256,y:609,t:1528143514960};\\\", \\\"{x:251,y:609,t:1528143514974};\\\", \\\"{x:241,y:606,t:1528143514991};\\\", \\\"{x:234,y:603,t:1528143515008};\\\", \\\"{x:232,y:602,t:1528143515024};\\\", \\\"{x:230,y:602,t:1528143515097};\\\", \\\"{x:229,y:602,t:1528143515112};\\\", \\\"{x:228,y:602,t:1528143515127};\\\", \\\"{x:224,y:602,t:1528143515141};\\\", \\\"{x:219,y:602,t:1528143515158};\\\", \\\"{x:216,y:602,t:1528143515175};\\\", \\\"{x:212,y:603,t:1528143515192};\\\", \\\"{x:209,y:604,t:1528143515208};\\\", \\\"{x:205,y:607,t:1528143515224};\\\", \\\"{x:202,y:609,t:1528143515242};\\\", \\\"{x:200,y:611,t:1528143515257};\\\", \\\"{x:199,y:611,t:1528143515296};\\\", \\\"{x:198,y:612,t:1528143515307};\\\", \\\"{x:196,y:614,t:1528143515326};\\\", \\\"{x:193,y:617,t:1528143515341};\\\", \\\"{x:192,y:619,t:1528143515357};\\\", \\\"{x:189,y:622,t:1528143515375};\\\", \\\"{x:185,y:625,t:1528143515392};\\\", \\\"{x:184,y:627,t:1528143515407};\\\", \\\"{x:182,y:629,t:1528143515424};\\\", \\\"{x:181,y:631,t:1528143515441};\\\", \\\"{x:179,y:632,t:1528143515457};\\\", \\\"{x:177,y:634,t:1528143515475};\\\", \\\"{x:175,y:634,t:1528143515492};\\\", \\\"{x:167,y:636,t:1528143515508};\\\", \\\"{x:163,y:638,t:1528143515525};\\\", \\\"{x:175,y:638,t:1528143516564};\\\", \\\"{x:233,y:612,t:1528143516580};\\\", \\\"{x:319,y:585,t:1528143516597};\\\", \\\"{x:427,y:559,t:1528143516613};\\\", \\\"{x:536,y:539,t:1528143516630};\\\", \\\"{x:650,y:518,t:1528143516647};\\\", \\\"{x:778,y:500,t:1528143516663};\\\", \\\"{x:889,y:481,t:1528143516679};\\\", \\\"{x:974,y:461,t:1528143516697};\\\", \\\"{x:1046,y:452,t:1528143516713};\\\", \\\"{x:1103,y:442,t:1528143516730};\\\", \\\"{x:1126,y:436,t:1528143516746};\\\", \\\"{x:1145,y:430,t:1528143516763};\\\", \\\"{x:1154,y:428,t:1528143516780};\\\", \\\"{x:1173,y:425,t:1528143516797};\\\", \\\"{x:1195,y:421,t:1528143516814};\\\", \\\"{x:1238,y:414,t:1528143516830};\\\", \\\"{x:1320,y:410,t:1528143516846};\\\", \\\"{x:1405,y:401,t:1528143516864};\\\", \\\"{x:1489,y:397,t:1528143516880};\\\", \\\"{x:1571,y:396,t:1528143516896};\\\", \\\"{x:1615,y:396,t:1528143516914};\\\", \\\"{x:1633,y:396,t:1528143516930};\\\", \\\"{x:1637,y:396,t:1528143516947};\\\", \\\"{x:1639,y:396,t:1528143516963};\\\", \\\"{x:1640,y:396,t:1528143516987};\\\", \\\"{x:1642,y:396,t:1528143517004};\\\", \\\"{x:1643,y:396,t:1528143517014};\\\", \\\"{x:1643,y:397,t:1528143517030};\\\", \\\"{x:1645,y:401,t:1528143517048};\\\", \\\"{x:1645,y:405,t:1528143517064};\\\", \\\"{x:1645,y:409,t:1528143517081};\\\", \\\"{x:1645,y:412,t:1528143517097};\\\", \\\"{x:1645,y:414,t:1528143517114};\\\", \\\"{x:1645,y:416,t:1528143517140};\\\", \\\"{x:1645,y:418,t:1528143517163};\\\", \\\"{x:1645,y:420,t:1528143517188};\\\", \\\"{x:1645,y:421,t:1528143517228};\\\", \\\"{x:1644,y:424,t:1528143517300};\\\", \\\"{x:1637,y:432,t:1528143517315};\\\", \\\"{x:1625,y:442,t:1528143517331};\\\", \\\"{x:1607,y:469,t:1528143517348};\\\", \\\"{x:1596,y:486,t:1528143517365};\\\", \\\"{x:1589,y:499,t:1528143517382};\\\", \\\"{x:1588,y:500,t:1528143517398};\\\", \\\"{x:1587,y:503,t:1528143517415};\\\", \\\"{x:1587,y:505,t:1528143517476};\\\", \\\"{x:1588,y:505,t:1528143517484};\\\", \\\"{x:1591,y:505,t:1528143517507};\\\", \\\"{x:1596,y:505,t:1528143517514};\\\", \\\"{x:1610,y:483,t:1528143517531};\\\", \\\"{x:1624,y:462,t:1528143517549};\\\", \\\"{x:1638,y:442,t:1528143517565};\\\", \\\"{x:1647,y:431,t:1528143517582};\\\", \\\"{x:1648,y:426,t:1528143517599};\\\", \\\"{x:1645,y:425,t:1528143517716};\\\", \\\"{x:1638,y:429,t:1528143517732};\\\", \\\"{x:1634,y:432,t:1528143517749};\\\", \\\"{x:1630,y:435,t:1528143517765};\\\", \\\"{x:1627,y:437,t:1528143517782};\\\", \\\"{x:1626,y:437,t:1528143517799};\\\", \\\"{x:1626,y:438,t:1528143517816};\\\", \\\"{x:1624,y:438,t:1528143517844};\\\", \\\"{x:1622,y:438,t:1528143517860};\\\", \\\"{x:1621,y:438,t:1528143517868};\\\", \\\"{x:1620,y:438,t:1528143517924};\\\", \\\"{x:1619,y:438,t:1528143517940};\\\", \\\"{x:1618,y:438,t:1528143517964};\\\", \\\"{x:1617,y:438,t:1528143518309};\\\", \\\"{x:1616,y:438,t:1528143518357};\\\", \\\"{x:1615,y:437,t:1528143518367};\\\", \\\"{x:1614,y:436,t:1528143518384};\\\", \\\"{x:1613,y:436,t:1528143518428};\\\", \\\"{x:1610,y:441,t:1528143521355};\\\", \\\"{x:1604,y:460,t:1528143521363};\\\", \\\"{x:1602,y:472,t:1528143521373};\\\", \\\"{x:1594,y:496,t:1528143521389};\\\", \\\"{x:1590,y:515,t:1528143521407};\\\", \\\"{x:1586,y:531,t:1528143521424};\\\", \\\"{x:1582,y:543,t:1528143521440};\\\", \\\"{x:1581,y:548,t:1528143521457};\\\", \\\"{x:1581,y:551,t:1528143521474};\\\", \\\"{x:1579,y:555,t:1528143521490};\\\", \\\"{x:1579,y:557,t:1528143521507};\\\", \\\"{x:1578,y:561,t:1528143521524};\\\", \\\"{x:1578,y:563,t:1528143521541};\\\", \\\"{x:1578,y:565,t:1528143521669};\\\", \\\"{x:1580,y:566,t:1528143521676};\\\", \\\"{x:1582,y:567,t:1528143521691};\\\", \\\"{x:1590,y:570,t:1528143521707};\\\", \\\"{x:1592,y:571,t:1528143521724};\\\", \\\"{x:1593,y:572,t:1528143521740};\\\", \\\"{x:1594,y:572,t:1528143521853};\\\", \\\"{x:1595,y:572,t:1528143521859};\\\", \\\"{x:1597,y:573,t:1528143521876};\\\", \\\"{x:1599,y:573,t:1528143521915};\\\", \\\"{x:1600,y:573,t:1528143521948};\\\", \\\"{x:1602,y:573,t:1528143521958};\\\", \\\"{x:1603,y:573,t:1528143522036};\\\", \\\"{x:1604,y:572,t:1528143522308};\\\", \\\"{x:1606,y:567,t:1528143522326};\\\", \\\"{x:1606,y:566,t:1528143522343};\\\", \\\"{x:1607,y:565,t:1528143522359};\\\", \\\"{x:1607,y:564,t:1528143522376};\\\", \\\"{x:1608,y:564,t:1528143522500};\\\", \\\"{x:1608,y:563,t:1528143522556};\\\", \\\"{x:1608,y:562,t:1528143522564};\\\", \\\"{x:1609,y:562,t:1528143522577};\\\", \\\"{x:1609,y:561,t:1528143522593};\\\", \\\"{x:1609,y:560,t:1528143522613};\\\", \\\"{x:1609,y:559,t:1528143522628};\\\", \\\"{x:1610,y:558,t:1528143522643};\\\", \\\"{x:1612,y:558,t:1528143522805};\\\", \\\"{x:1612,y:559,t:1528143522827};\\\", \\\"{x:1606,y:576,t:1528143522845};\\\", \\\"{x:1594,y:589,t:1528143522860};\\\", \\\"{x:1590,y:595,t:1528143522878};\\\", \\\"{x:1582,y:605,t:1528143522894};\\\", \\\"{x:1578,y:612,t:1528143522911};\\\", \\\"{x:1567,y:623,t:1528143522927};\\\", \\\"{x:1556,y:636,t:1528143522945};\\\", \\\"{x:1542,y:650,t:1528143522961};\\\", \\\"{x:1534,y:657,t:1528143522977};\\\", \\\"{x:1528,y:663,t:1528143522994};\\\", \\\"{x:1523,y:670,t:1528143523011};\\\", \\\"{x:1518,y:676,t:1528143523027};\\\", \\\"{x:1514,y:682,t:1528143523044};\\\", \\\"{x:1514,y:685,t:1528143523062};\\\", \\\"{x:1511,y:691,t:1528143523077};\\\", \\\"{x:1511,y:694,t:1528143523094};\\\", \\\"{x:1511,y:695,t:1528143523111};\\\", \\\"{x:1510,y:698,t:1528143523128};\\\", \\\"{x:1510,y:708,t:1528143523144};\\\", \\\"{x:1514,y:722,t:1528143523161};\\\", \\\"{x:1519,y:729,t:1528143523178};\\\", \\\"{x:1522,y:733,t:1528143523193};\\\", \\\"{x:1524,y:737,t:1528143523210};\\\", \\\"{x:1525,y:737,t:1528143523227};\\\", \\\"{x:1526,y:737,t:1528143523244};\\\", \\\"{x:1528,y:739,t:1528143523260};\\\", \\\"{x:1529,y:739,t:1528143523291};\\\", \\\"{x:1531,y:739,t:1528143523315};\\\", \\\"{x:1534,y:739,t:1528143523347};\\\", \\\"{x:1539,y:739,t:1528143523361};\\\", \\\"{x:1554,y:725,t:1528143523379};\\\", \\\"{x:1579,y:695,t:1528143523395};\\\", \\\"{x:1618,y:636,t:1528143523412};\\\", \\\"{x:1641,y:596,t:1528143523428};\\\", \\\"{x:1650,y:573,t:1528143523445};\\\", \\\"{x:1651,y:566,t:1528143523462};\\\", \\\"{x:1652,y:563,t:1528143523479};\\\", \\\"{x:1651,y:562,t:1528143523564};\\\", \\\"{x:1647,y:562,t:1528143523579};\\\", \\\"{x:1631,y:572,t:1528143523595};\\\", \\\"{x:1608,y:589,t:1528143523612};\\\", \\\"{x:1598,y:596,t:1528143523630};\\\", \\\"{x:1593,y:603,t:1528143523646};\\\", \\\"{x:1593,y:604,t:1528143523662};\\\", \\\"{x:1593,y:603,t:1528143523740};\\\", \\\"{x:1593,y:599,t:1528143523748};\\\", \\\"{x:1593,y:595,t:1528143523763};\\\", \\\"{x:1597,y:589,t:1528143523779};\\\", \\\"{x:1605,y:580,t:1528143523795};\\\", \\\"{x:1610,y:577,t:1528143523812};\\\", \\\"{x:1614,y:575,t:1528143523829};\\\", \\\"{x:1616,y:573,t:1528143523847};\\\", \\\"{x:1617,y:572,t:1528143523940};\\\", \\\"{x:1618,y:572,t:1528143523948};\\\", \\\"{x:1618,y:571,t:1528143523964};\\\", \\\"{x:1618,y:570,t:1528143523980};\\\", \\\"{x:1618,y:569,t:1528143524012};\\\", \\\"{x:1619,y:568,t:1528143524030};\\\", \\\"{x:1619,y:572,t:1528143524580};\\\", \\\"{x:1619,y:580,t:1528143524598};\\\", \\\"{x:1619,y:584,t:1528143524614};\\\", \\\"{x:1619,y:589,t:1528143524631};\\\", \\\"{x:1617,y:593,t:1528143524648};\\\", \\\"{x:1617,y:597,t:1528143524664};\\\", \\\"{x:1617,y:599,t:1528143524682};\\\", \\\"{x:1615,y:602,t:1528143524698};\\\", \\\"{x:1615,y:606,t:1528143524715};\\\", \\\"{x:1613,y:612,t:1528143524732};\\\", \\\"{x:1613,y:614,t:1528143524748};\\\", \\\"{x:1613,y:618,t:1528143524765};\\\", \\\"{x:1612,y:621,t:1528143524781};\\\", \\\"{x:1610,y:628,t:1528143524798};\\\", \\\"{x:1609,y:634,t:1528143524816};\\\", \\\"{x:1609,y:639,t:1528143524832};\\\", \\\"{x:1608,y:646,t:1528143524848};\\\", \\\"{x:1605,y:653,t:1528143524866};\\\", \\\"{x:1604,y:659,t:1528143524882};\\\", \\\"{x:1601,y:664,t:1528143524898};\\\", \\\"{x:1597,y:672,t:1528143524915};\\\", \\\"{x:1596,y:678,t:1528143524932};\\\", \\\"{x:1592,y:687,t:1528143524948};\\\", \\\"{x:1587,y:696,t:1528143524965};\\\", \\\"{x:1584,y:702,t:1528143524983};\\\", \\\"{x:1584,y:708,t:1528143524998};\\\", \\\"{x:1583,y:718,t:1528143525015};\\\", \\\"{x:1583,y:726,t:1528143525033};\\\", \\\"{x:1583,y:732,t:1528143525049};\\\", \\\"{x:1583,y:736,t:1528143525065};\\\", \\\"{x:1583,y:742,t:1528143525082};\\\", \\\"{x:1583,y:751,t:1528143525100};\\\", \\\"{x:1583,y:763,t:1528143525116};\\\", \\\"{x:1583,y:779,t:1528143525133};\\\", \\\"{x:1583,y:792,t:1528143525150};\\\", \\\"{x:1583,y:807,t:1528143525165};\\\", \\\"{x:1583,y:821,t:1528143525183};\\\", \\\"{x:1583,y:836,t:1528143525199};\\\", \\\"{x:1583,y:846,t:1528143525216};\\\", \\\"{x:1583,y:856,t:1528143525232};\\\", \\\"{x:1583,y:870,t:1528143525249};\\\", \\\"{x:1585,y:881,t:1528143525267};\\\", \\\"{x:1587,y:893,t:1528143525282};\\\", \\\"{x:1591,y:906,t:1528143525300};\\\", \\\"{x:1595,y:918,t:1528143525316};\\\", \\\"{x:1599,y:929,t:1528143525332};\\\", \\\"{x:1604,y:939,t:1528143525349};\\\", \\\"{x:1611,y:956,t:1528143525366};\\\", \\\"{x:1617,y:973,t:1528143525383};\\\", \\\"{x:1626,y:986,t:1528143525400};\\\", \\\"{x:1637,y:1003,t:1528143525416};\\\", \\\"{x:1648,y:1017,t:1528143525433};\\\", \\\"{x:1654,y:1025,t:1528143525450};\\\", \\\"{x:1657,y:1031,t:1528143525466};\\\", \\\"{x:1658,y:1033,t:1528143525483};\\\", \\\"{x:1658,y:1034,t:1528143525572};\\\", \\\"{x:1657,y:1034,t:1528143525583};\\\", \\\"{x:1653,y:1033,t:1528143525600};\\\", \\\"{x:1651,y:1032,t:1528143525616};\\\", \\\"{x:1648,y:1030,t:1528143525634};\\\", \\\"{x:1646,y:1028,t:1528143525650};\\\", \\\"{x:1646,y:1027,t:1528143525667};\\\", \\\"{x:1646,y:1026,t:1528143525684};\\\", \\\"{x:1647,y:1024,t:1528143525700};\\\", \\\"{x:1648,y:1020,t:1528143525717};\\\", \\\"{x:1650,y:1016,t:1528143525733};\\\", \\\"{x:1652,y:1012,t:1528143525750};\\\", \\\"{x:1653,y:1008,t:1528143525767};\\\", \\\"{x:1653,y:1004,t:1528143525784};\\\", \\\"{x:1653,y:1003,t:1528143525800};\\\", \\\"{x:1653,y:1002,t:1528143525852};\\\", \\\"{x:1653,y:1001,t:1528143525867};\\\", \\\"{x:1651,y:1001,t:1528143525884};\\\", \\\"{x:1650,y:1000,t:1528143525907};\\\", \\\"{x:1650,y:999,t:1528143525918};\\\", \\\"{x:1648,y:995,t:1528143525934};\\\", \\\"{x:1646,y:988,t:1528143525950};\\\", \\\"{x:1646,y:981,t:1528143525967};\\\", \\\"{x:1645,y:972,t:1528143525984};\\\", \\\"{x:1645,y:966,t:1528143526000};\\\", \\\"{x:1645,y:957,t:1528143526018};\\\", \\\"{x:1645,y:951,t:1528143526035};\\\", \\\"{x:1645,y:939,t:1528143526050};\\\", \\\"{x:1644,y:934,t:1528143526067};\\\", \\\"{x:1644,y:933,t:1528143526123};\\\", \\\"{x:1644,y:932,t:1528143526155};\\\", \\\"{x:1644,y:931,t:1528143526168};\\\", \\\"{x:1644,y:930,t:1528143526184};\\\", \\\"{x:1643,y:928,t:1528143526201};\\\", \\\"{x:1641,y:927,t:1528143526218};\\\", \\\"{x:1638,y:923,t:1528143526234};\\\", \\\"{x:1635,y:920,t:1528143526251};\\\", \\\"{x:1634,y:919,t:1528143526284};\\\", \\\"{x:1633,y:919,t:1528143526300};\\\", \\\"{x:1633,y:917,t:1528143526308};\\\", \\\"{x:1632,y:917,t:1528143526318};\\\", \\\"{x:1632,y:916,t:1528143526336};\\\", \\\"{x:1632,y:915,t:1528143526372};\\\", \\\"{x:1632,y:914,t:1528143526385};\\\", \\\"{x:1631,y:914,t:1528143526404};\\\", \\\"{x:1630,y:914,t:1528143526418};\\\", \\\"{x:1628,y:912,t:1528143526436};\\\", \\\"{x:1626,y:910,t:1528143526452};\\\", \\\"{x:1624,y:908,t:1528143526468};\\\", \\\"{x:1624,y:907,t:1528143526516};\\\", \\\"{x:1623,y:907,t:1528143526540};\\\", \\\"{x:1622,y:905,t:1528143526552};\\\", \\\"{x:1621,y:905,t:1528143526568};\\\", \\\"{x:1620,y:903,t:1528143526585};\\\", \\\"{x:1619,y:901,t:1528143526603};\\\", \\\"{x:1619,y:898,t:1528143526620};\\\", \\\"{x:1619,y:897,t:1528143526636};\\\", \\\"{x:1617,y:894,t:1528143526652};\\\", \\\"{x:1616,y:887,t:1528143526670};\\\", \\\"{x:1616,y:880,t:1528143526686};\\\", \\\"{x:1616,y:876,t:1528143526702};\\\", \\\"{x:1616,y:872,t:1528143526720};\\\", \\\"{x:1617,y:872,t:1528143526736};\\\", \\\"{x:1617,y:870,t:1528143526764};\\\", \\\"{x:1617,y:869,t:1528143526780};\\\", \\\"{x:1619,y:865,t:1528143526788};\\\", \\\"{x:1621,y:862,t:1528143526803};\\\", \\\"{x:1621,y:857,t:1528143526820};\\\", \\\"{x:1621,y:854,t:1528143526837};\\\", \\\"{x:1621,y:853,t:1528143526860};\\\", \\\"{x:1621,y:852,t:1528143526876};\\\", \\\"{x:1621,y:851,t:1528143526908};\\\", \\\"{x:1621,y:850,t:1528143526920};\\\", \\\"{x:1621,y:848,t:1528143526937};\\\", \\\"{x:1621,y:845,t:1528143526953};\\\", \\\"{x:1621,y:843,t:1528143526970};\\\", \\\"{x:1621,y:842,t:1528143526986};\\\", \\\"{x:1621,y:841,t:1528143527020};\\\", \\\"{x:1621,y:840,t:1528143527044};\\\", \\\"{x:1620,y:840,t:1528143527060};\\\", \\\"{x:1619,y:839,t:1528143527070};\\\", \\\"{x:1618,y:839,t:1528143527092};\\\", \\\"{x:1617,y:838,t:1528143527148};\\\", \\\"{x:1617,y:837,t:1528143527244};\\\", \\\"{x:1617,y:835,t:1528143527284};\\\", \\\"{x:1617,y:833,t:1528143527300};\\\", \\\"{x:1616,y:832,t:1528143527341};\\\", \\\"{x:1616,y:830,t:1528143527372};\\\", \\\"{x:1616,y:829,t:1528143527404};\\\", \\\"{x:1615,y:826,t:1528143527420};\\\", \\\"{x:1615,y:823,t:1528143527438};\\\", \\\"{x:1615,y:820,t:1528143527455};\\\", \\\"{x:1615,y:817,t:1528143527470};\\\", \\\"{x:1615,y:815,t:1528143527489};\\\", \\\"{x:1615,y:812,t:1528143527504};\\\", \\\"{x:1615,y:808,t:1528143527521};\\\", \\\"{x:1615,y:806,t:1528143527537};\\\", \\\"{x:1615,y:805,t:1528143527554};\\\", \\\"{x:1615,y:803,t:1528143527594};\\\", \\\"{x:1615,y:802,t:1528143527619};\\\", \\\"{x:1616,y:800,t:1528143527644};\\\", \\\"{x:1616,y:799,t:1528143527655};\\\", \\\"{x:1616,y:797,t:1528143527671};\\\", \\\"{x:1616,y:795,t:1528143527688};\\\", \\\"{x:1616,y:793,t:1528143527704};\\\", \\\"{x:1616,y:790,t:1528143527721};\\\", \\\"{x:1617,y:786,t:1528143527738};\\\", \\\"{x:1617,y:783,t:1528143527852};\\\", \\\"{x:1617,y:782,t:1528143527860};\\\", \\\"{x:1617,y:780,t:1528143527871};\\\", \\\"{x:1617,y:779,t:1528143527888};\\\", \\\"{x:1617,y:777,t:1528143527905};\\\", \\\"{x:1617,y:774,t:1528143527922};\\\", \\\"{x:1617,y:773,t:1528143527938};\\\", \\\"{x:1617,y:770,t:1528143527955};\\\", \\\"{x:1616,y:769,t:1528143527972};\\\", \\\"{x:1616,y:768,t:1528143527988};\\\", \\\"{x:1616,y:767,t:1528143528012};\\\", \\\"{x:1615,y:764,t:1528143528037};\\\", \\\"{x:1615,y:762,t:1528143528044};\\\", \\\"{x:1615,y:760,t:1528143528056};\\\", \\\"{x:1614,y:757,t:1528143528072};\\\", \\\"{x:1614,y:753,t:1528143528089};\\\", \\\"{x:1614,y:751,t:1528143528106};\\\", \\\"{x:1614,y:747,t:1528143528122};\\\", \\\"{x:1612,y:739,t:1528143528139};\\\", \\\"{x:1612,y:738,t:1528143528154};\\\", \\\"{x:1612,y:736,t:1528143528186};\\\", \\\"{x:1611,y:735,t:1528143528235};\\\", \\\"{x:1610,y:732,t:1528143528243};\\\", \\\"{x:1610,y:731,t:1528143528259};\\\", \\\"{x:1610,y:730,t:1528143528331};\\\", \\\"{x:1609,y:728,t:1528143528348};\\\", \\\"{x:1608,y:725,t:1528143528356};\\\", \\\"{x:1608,y:722,t:1528143528373};\\\", \\\"{x:1608,y:720,t:1528143528390};\\\", \\\"{x:1608,y:719,t:1528143528407};\\\", \\\"{x:1608,y:718,t:1528143528423};\\\", \\\"{x:1608,y:716,t:1528143528439};\\\", \\\"{x:1608,y:715,t:1528143528456};\\\", \\\"{x:1608,y:712,t:1528143528473};\\\", \\\"{x:1607,y:710,t:1528143528489};\\\", \\\"{x:1607,y:706,t:1528143528507};\\\", \\\"{x:1607,y:699,t:1528143528524};\\\", \\\"{x:1607,y:696,t:1528143528539};\\\", \\\"{x:1607,y:694,t:1528143528556};\\\", \\\"{x:1607,y:689,t:1528143528573};\\\", \\\"{x:1607,y:686,t:1528143528590};\\\", \\\"{x:1607,y:679,t:1528143528606};\\\", \\\"{x:1607,y:677,t:1528143528623};\\\", \\\"{x:1606,y:672,t:1528143528640};\\\", \\\"{x:1606,y:670,t:1528143528656};\\\", \\\"{x:1606,y:669,t:1528143528673};\\\", \\\"{x:1606,y:668,t:1528143528690};\\\", \\\"{x:1606,y:667,t:1528143528707};\\\", \\\"{x:1606,y:666,t:1528143528723};\\\", \\\"{x:1606,y:665,t:1528143528740};\\\", \\\"{x:1606,y:664,t:1528143528757};\\\", \\\"{x:1606,y:663,t:1528143528780};\\\", \\\"{x:1607,y:663,t:1528143528790};\\\", \\\"{x:1608,y:661,t:1528143528808};\\\", \\\"{x:1608,y:658,t:1528143528823};\\\", \\\"{x:1608,y:655,t:1528143528840};\\\", \\\"{x:1609,y:650,t:1528143528858};\\\", \\\"{x:1611,y:644,t:1528143528875};\\\", \\\"{x:1611,y:640,t:1528143528890};\\\", \\\"{x:1611,y:635,t:1528143528908};\\\", \\\"{x:1612,y:629,t:1528143528923};\\\", \\\"{x:1612,y:624,t:1528143528940};\\\", \\\"{x:1612,y:617,t:1528143528958};\\\", \\\"{x:1612,y:610,t:1528143528974};\\\", \\\"{x:1612,y:604,t:1528143528990};\\\", \\\"{x:1612,y:598,t:1528143529007};\\\", \\\"{x:1612,y:592,t:1528143529024};\\\", \\\"{x:1612,y:586,t:1528143529041};\\\", \\\"{x:1610,y:577,t:1528143529058};\\\", \\\"{x:1609,y:569,t:1528143529074};\\\", \\\"{x:1607,y:560,t:1528143529092};\\\", \\\"{x:1606,y:552,t:1528143529108};\\\", \\\"{x:1606,y:550,t:1528143529124};\\\", \\\"{x:1605,y:546,t:1528143529141};\\\", \\\"{x:1605,y:542,t:1528143529157};\\\", \\\"{x:1605,y:539,t:1528143529174};\\\", \\\"{x:1603,y:535,t:1528143529191};\\\", \\\"{x:1603,y:532,t:1528143529208};\\\", \\\"{x:1602,y:529,t:1528143529224};\\\", \\\"{x:1602,y:525,t:1528143529242};\\\", \\\"{x:1602,y:521,t:1528143529258};\\\", \\\"{x:1602,y:512,t:1528143529274};\\\", \\\"{x:1602,y:506,t:1528143529292};\\\", \\\"{x:1601,y:504,t:1528143529308};\\\", \\\"{x:1600,y:504,t:1528143529460};\\\", \\\"{x:1573,y:525,t:1528143529475};\\\", \\\"{x:1503,y:574,t:1528143529491};\\\", \\\"{x:1416,y:621,t:1528143529508};\\\", \\\"{x:1340,y:659,t:1528143529526};\\\", \\\"{x:1276,y:689,t:1528143529542};\\\", \\\"{x:1212,y:710,t:1528143529559};\\\", \\\"{x:1134,y:721,t:1528143529576};\\\", \\\"{x:1074,y:724,t:1528143529592};\\\", \\\"{x:1007,y:724,t:1528143529609};\\\", \\\"{x:954,y:724,t:1528143529626};\\\", \\\"{x:909,y:724,t:1528143529643};\\\", \\\"{x:867,y:724,t:1528143529659};\\\", \\\"{x:842,y:728,t:1528143529675};\\\", \\\"{x:825,y:730,t:1528143529693};\\\", \\\"{x:819,y:730,t:1528143529709};\\\", \\\"{x:817,y:730,t:1528143529725};\\\", \\\"{x:814,y:730,t:1528143529763};\\\", \\\"{x:811,y:730,t:1528143529775};\\\", \\\"{x:802,y:730,t:1528143529792};\\\", \\\"{x:788,y:730,t:1528143529809};\\\", \\\"{x:766,y:730,t:1528143529826};\\\", \\\"{x:743,y:730,t:1528143529843};\\\", \\\"{x:713,y:730,t:1528143529859};\\\", \\\"{x:701,y:730,t:1528143529876};\\\", \\\"{x:690,y:730,t:1528143529892};\\\", \\\"{x:684,y:730,t:1528143529910};\\\", \\\"{x:682,y:730,t:1528143529926};\\\", \\\"{x:679,y:727,t:1528143530020};\\\", \\\"{x:676,y:727,t:1528143530027};\\\", \\\"{x:668,y:726,t:1528143530044};\\\", \\\"{x:649,y:726,t:1528143530059};\\\", \\\"{x:617,y:726,t:1528143530076};\\\", \\\"{x:582,y:730,t:1528143530094};\\\", \\\"{x:546,y:734,t:1528143530111};\\\", \\\"{x:521,y:737,t:1528143530127};\\\", \\\"{x:505,y:737,t:1528143530143};\\\", \\\"{x:500,y:737,t:1528143530156};\\\", \\\"{x:499,y:737,t:1528143530172};\\\", \\\"{x:496,y:736,t:1528143530190};\\\", \\\"{x:490,y:735,t:1528143530207};\\\", \\\"{x:485,y:731,t:1528143530222};\\\", \\\"{x:484,y:731,t:1528143530240};\\\", \\\"{x:483,y:730,t:1528143530259};\\\", \\\"{x:483,y:729,t:1528143530274};\\\", \\\"{x:483,y:725,t:1528143530290};\\\", \\\"{x:483,y:723,t:1528143530306};\\\", \\\"{x:485,y:720,t:1528143530324};\\\", \\\"{x:486,y:719,t:1528143530341};\\\", \\\"{x:487,y:717,t:1528143530357};\\\", \\\"{x:487,y:715,t:1528143530374};\\\", \\\"{x:490,y:711,t:1528143530391};\\\", \\\"{x:490,y:709,t:1528143530407};\\\" ] }, { \\\"rt\\\": 40535, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 655694, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"VVH1B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -C -O -C -O -O -O -O -I -O -O -O -O -1\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:491,y:708,t:1528143534748};\\\", \\\"{x:493,y:708,t:1528143534771};\\\", \\\"{x:526,y:700,t:1528143534781};\\\", \\\"{x:602,y:691,t:1528143534792};\\\", \\\"{x:724,y:691,t:1528143534808};\\\", \\\"{x:826,y:698,t:1528143534824};\\\", \\\"{x:911,y:710,t:1528143534844};\\\", \\\"{x:932,y:716,t:1528143534861};\\\", \\\"{x:937,y:717,t:1528143534877};\\\", \\\"{x:938,y:719,t:1528143534955};\\\", \\\"{x:938,y:722,t:1528143534962};\\\", \\\"{x:940,y:725,t:1528143534977};\\\", \\\"{x:946,y:735,t:1528143534994};\\\", \\\"{x:964,y:750,t:1528143535011};\\\", \\\"{x:977,y:762,t:1528143535027};\\\", \\\"{x:988,y:770,t:1528143535044};\\\", \\\"{x:998,y:775,t:1528143535061};\\\", \\\"{x:1009,y:778,t:1528143535077};\\\", \\\"{x:1019,y:779,t:1528143535094};\\\", \\\"{x:1032,y:783,t:1528143535111};\\\", \\\"{x:1053,y:786,t:1528143535128};\\\", \\\"{x:1075,y:789,t:1528143535144};\\\", \\\"{x:1097,y:794,t:1528143535161};\\\", \\\"{x:1125,y:797,t:1528143535178};\\\", \\\"{x:1154,y:802,t:1528143535194};\\\", \\\"{x:1203,y:816,t:1528143535212};\\\", \\\"{x:1230,y:821,t:1528143535229};\\\", \\\"{x:1250,y:827,t:1528143535245};\\\", \\\"{x:1261,y:831,t:1528143535261};\\\", \\\"{x:1263,y:832,t:1528143535278};\\\", \\\"{x:1260,y:832,t:1528143535484};\\\", \\\"{x:1255,y:832,t:1528143535495};\\\", \\\"{x:1250,y:832,t:1528143535512};\\\", \\\"{x:1247,y:832,t:1528143535529};\\\", \\\"{x:1244,y:832,t:1528143535545};\\\", \\\"{x:1243,y:831,t:1528143535716};\\\", \\\"{x:1241,y:829,t:1528143535732};\\\", \\\"{x:1240,y:829,t:1528143535748};\\\", \\\"{x:1239,y:829,t:1528143535762};\\\", \\\"{x:1234,y:827,t:1528143535779};\\\", \\\"{x:1229,y:825,t:1528143535795};\\\", \\\"{x:1225,y:823,t:1528143535813};\\\", \\\"{x:1223,y:823,t:1528143535829};\\\", \\\"{x:1222,y:823,t:1528143536084};\\\", \\\"{x:1221,y:823,t:1528143536148};\\\", \\\"{x:1220,y:823,t:1528143536163};\\\", \\\"{x:1219,y:823,t:1528143536180};\\\", \\\"{x:1217,y:823,t:1528143536197};\\\", \\\"{x:1215,y:823,t:1528143536212};\\\", \\\"{x:1213,y:823,t:1528143536230};\\\", \\\"{x:1210,y:824,t:1528143536251};\\\", \\\"{x:1210,y:825,t:1528143536581};\\\", \\\"{x:1210,y:827,t:1528143536599};\\\", \\\"{x:1209,y:829,t:1528143536613};\\\", \\\"{x:1209,y:830,t:1528143536630};\\\", \\\"{x:1208,y:831,t:1528143536646};\\\", \\\"{x:1208,y:832,t:1528143536664};\\\", \\\"{x:1208,y:833,t:1528143536680};\\\", \\\"{x:1208,y:831,t:1528143548170};\\\", \\\"{x:1217,y:822,t:1528143548180};\\\", \\\"{x:1239,y:803,t:1528143548198};\\\", \\\"{x:1267,y:784,t:1528143548215};\\\", \\\"{x:1284,y:773,t:1528143548231};\\\", \\\"{x:1293,y:765,t:1528143548247};\\\", \\\"{x:1297,y:761,t:1528143548264};\\\", \\\"{x:1299,y:758,t:1528143548281};\\\", \\\"{x:1301,y:756,t:1528143548298};\\\", \\\"{x:1304,y:750,t:1528143548315};\\\", \\\"{x:1305,y:748,t:1528143548331};\\\", \\\"{x:1307,y:744,t:1528143548348};\\\", \\\"{x:1308,y:742,t:1528143548365};\\\", \\\"{x:1308,y:740,t:1528143548381};\\\", \\\"{x:1308,y:737,t:1528143548398};\\\", \\\"{x:1308,y:735,t:1528143548416};\\\", \\\"{x:1308,y:730,t:1528143548432};\\\", \\\"{x:1308,y:729,t:1528143548448};\\\", \\\"{x:1308,y:723,t:1528143548466};\\\", \\\"{x:1308,y:719,t:1528143548483};\\\", \\\"{x:1308,y:715,t:1528143548498};\\\", \\\"{x:1308,y:708,t:1528143548515};\\\", \\\"{x:1308,y:701,t:1528143548531};\\\", \\\"{x:1308,y:690,t:1528143548548};\\\", \\\"{x:1309,y:672,t:1528143548565};\\\", \\\"{x:1316,y:655,t:1528143548582};\\\", \\\"{x:1320,y:642,t:1528143548598};\\\", \\\"{x:1322,y:631,t:1528143548615};\\\", \\\"{x:1323,y:626,t:1528143548633};\\\", \\\"{x:1323,y:625,t:1528143548651};\\\", \\\"{x:1322,y:624,t:1528143548691};\\\", \\\"{x:1322,y:625,t:1528143548835};\\\", \\\"{x:1320,y:626,t:1528143548849};\\\", \\\"{x:1320,y:629,t:1528143548867};\\\", \\\"{x:1320,y:632,t:1528143548883};\\\", \\\"{x:1320,y:635,t:1528143548899};\\\", \\\"{x:1320,y:637,t:1528143548916};\\\", \\\"{x:1320,y:638,t:1528143548932};\\\", \\\"{x:1317,y:639,t:1528143549292};\\\", \\\"{x:1311,y:637,t:1528143549300};\\\", \\\"{x:1304,y:633,t:1528143549317};\\\", \\\"{x:1302,y:630,t:1528143549333};\\\", \\\"{x:1301,y:630,t:1528143549350};\\\", \\\"{x:1302,y:630,t:1528143550379};\\\", \\\"{x:1302,y:631,t:1528143553202};\\\", \\\"{x:1285,y:633,t:1528143553210};\\\", \\\"{x:1266,y:637,t:1528143553222};\\\", \\\"{x:1238,y:638,t:1528143553238};\\\", \\\"{x:1221,y:638,t:1528143553255};\\\", \\\"{x:1217,y:638,t:1528143553272};\\\", \\\"{x:1216,y:638,t:1528143553371};\\\", \\\"{x:1216,y:639,t:1528143553379};\\\", \\\"{x:1211,y:640,t:1528143553389};\\\", \\\"{x:1205,y:643,t:1528143553406};\\\", \\\"{x:1201,y:645,t:1528143553422};\\\", \\\"{x:1199,y:646,t:1528143553439};\\\", \\\"{x:1198,y:646,t:1528143553466};\\\", \\\"{x:1199,y:646,t:1528143553740};\\\", \\\"{x:1225,y:638,t:1528143553757};\\\", \\\"{x:1261,y:629,t:1528143553774};\\\", \\\"{x:1304,y:620,t:1528143553790};\\\", \\\"{x:1330,y:615,t:1528143553806};\\\", \\\"{x:1336,y:614,t:1528143553823};\\\", \\\"{x:1332,y:614,t:1528143553916};\\\", \\\"{x:1309,y:617,t:1528143553923};\\\", \\\"{x:1188,y:630,t:1528143553940};\\\", \\\"{x:1038,y:634,t:1528143553957};\\\", \\\"{x:899,y:634,t:1528143553973};\\\", \\\"{x:788,y:638,t:1528143553990};\\\", \\\"{x:715,y:638,t:1528143554007};\\\", \\\"{x:688,y:638,t:1528143554023};\\\", \\\"{x:683,y:637,t:1528143554039};\\\", \\\"{x:690,y:630,t:1528143554139};\\\", \\\"{x:702,y:622,t:1528143554147};\\\", \\\"{x:710,y:616,t:1528143554160};\\\", \\\"{x:735,y:598,t:1528143554177};\\\", \\\"{x:773,y:576,t:1528143554194};\\\", \\\"{x:816,y:553,t:1528143554210};\\\", \\\"{x:847,y:540,t:1528143554226};\\\", \\\"{x:858,y:534,t:1528143554243};\\\", \\\"{x:855,y:534,t:1528143554427};\\\", \\\"{x:849,y:533,t:1528143554442};\\\", \\\"{x:840,y:529,t:1528143554460};\\\", \\\"{x:835,y:529,t:1528143554476};\\\", \\\"{x:829,y:529,t:1528143554493};\\\", \\\"{x:827,y:529,t:1528143554510};\\\", \\\"{x:825,y:530,t:1528143554526};\\\", \\\"{x:826,y:530,t:1528143554995};\\\", \\\"{x:827,y:531,t:1528143555010};\\\", \\\"{x:829,y:532,t:1528143555026};\\\", \\\"{x:830,y:532,t:1528143555043};\\\", \\\"{x:831,y:533,t:1528143555060};\\\", \\\"{x:833,y:534,t:1528143555076};\\\", \\\"{x:836,y:536,t:1528143555093};\\\", \\\"{x:838,y:538,t:1528143555110};\\\", \\\"{x:841,y:542,t:1528143555127};\\\", \\\"{x:845,y:547,t:1528143555143};\\\", \\\"{x:849,y:551,t:1528143555160};\\\", \\\"{x:854,y:559,t:1528143555176};\\\", \\\"{x:858,y:566,t:1528143555193};\\\", \\\"{x:863,y:573,t:1528143555210};\\\", \\\"{x:870,y:584,t:1528143555227};\\\", \\\"{x:874,y:587,t:1528143555242};\\\", \\\"{x:876,y:591,t:1528143555260};\\\", \\\"{x:879,y:596,t:1528143555277};\\\", \\\"{x:884,y:602,t:1528143555293};\\\", \\\"{x:889,y:608,t:1528143555310};\\\", \\\"{x:895,y:617,t:1528143555328};\\\", \\\"{x:902,y:624,t:1528143555343};\\\", \\\"{x:906,y:628,t:1528143555360};\\\", \\\"{x:911,y:634,t:1528143555377};\\\", \\\"{x:919,y:641,t:1528143555393};\\\", \\\"{x:929,y:649,t:1528143555409};\\\", \\\"{x:948,y:664,t:1528143555426};\\\", \\\"{x:964,y:673,t:1528143555444};\\\", \\\"{x:981,y:683,t:1528143555460};\\\", \\\"{x:997,y:691,t:1528143555477};\\\", \\\"{x:1010,y:698,t:1528143555494};\\\", \\\"{x:1019,y:702,t:1528143555510};\\\", \\\"{x:1029,y:708,t:1528143555527};\\\", \\\"{x:1036,y:711,t:1528143555544};\\\", \\\"{x:1045,y:714,t:1528143555560};\\\", \\\"{x:1048,y:717,t:1528143555577};\\\", \\\"{x:1049,y:717,t:1528143555595};\\\", \\\"{x:1051,y:718,t:1528143555611};\\\", \\\"{x:1063,y:728,t:1528143555628};\\\", \\\"{x:1077,y:737,t:1528143555644};\\\", \\\"{x:1091,y:746,t:1528143555661};\\\", \\\"{x:1108,y:757,t:1528143555677};\\\", \\\"{x:1129,y:769,t:1528143555694};\\\", \\\"{x:1144,y:774,t:1528143555710};\\\", \\\"{x:1148,y:775,t:1528143555727};\\\", \\\"{x:1150,y:775,t:1528143555744};\\\", \\\"{x:1153,y:777,t:1528143555760};\\\", \\\"{x:1154,y:777,t:1528143555779};\\\", \\\"{x:1155,y:778,t:1528143555795};\\\", \\\"{x:1159,y:780,t:1528143555811};\\\", \\\"{x:1164,y:782,t:1528143555828};\\\", \\\"{x:1166,y:784,t:1528143555844};\\\", \\\"{x:1170,y:787,t:1528143555861};\\\", \\\"{x:1172,y:792,t:1528143555877};\\\", \\\"{x:1175,y:796,t:1528143555894};\\\", \\\"{x:1178,y:799,t:1528143555910};\\\", \\\"{x:1182,y:805,t:1528143555927};\\\", \\\"{x:1185,y:809,t:1528143555944};\\\", \\\"{x:1185,y:812,t:1528143555961};\\\", \\\"{x:1186,y:813,t:1528143555978};\\\", \\\"{x:1187,y:814,t:1528143555995};\\\", \\\"{x:1188,y:814,t:1528143556012};\\\", \\\"{x:1189,y:815,t:1528143556060};\\\", \\\"{x:1191,y:815,t:1528143556092};\\\", \\\"{x:1191,y:816,t:1528143556099};\\\", \\\"{x:1192,y:816,t:1528143556111};\\\", \\\"{x:1193,y:817,t:1528143556128};\\\", \\\"{x:1194,y:817,t:1528143556145};\\\", \\\"{x:1197,y:818,t:1528143556161};\\\", \\\"{x:1199,y:820,t:1528143556178};\\\", \\\"{x:1199,y:821,t:1528143556194};\\\", \\\"{x:1200,y:821,t:1528143556212};\\\", \\\"{x:1201,y:821,t:1528143556228};\\\", \\\"{x:1203,y:822,t:1528143556245};\\\", \\\"{x:1205,y:823,t:1528143556262};\\\", \\\"{x:1207,y:825,t:1528143556278};\\\", \\\"{x:1208,y:825,t:1528143556294};\\\", \\\"{x:1210,y:827,t:1528143556312};\\\", \\\"{x:1211,y:827,t:1528143556328};\\\", \\\"{x:1213,y:827,t:1528143556788};\\\", \\\"{x:1221,y:823,t:1528143556796};\\\", \\\"{x:1230,y:818,t:1528143556811};\\\", \\\"{x:1238,y:811,t:1528143556828};\\\", \\\"{x:1245,y:803,t:1528143556846};\\\", \\\"{x:1248,y:799,t:1528143556861};\\\", \\\"{x:1251,y:795,t:1528143556879};\\\", \\\"{x:1256,y:789,t:1528143556896};\\\", \\\"{x:1267,y:775,t:1528143556912};\\\", \\\"{x:1279,y:759,t:1528143556928};\\\", \\\"{x:1292,y:742,t:1528143556945};\\\", \\\"{x:1301,y:728,t:1528143556961};\\\", \\\"{x:1309,y:715,t:1528143556979};\\\", \\\"{x:1315,y:704,t:1528143556995};\\\", \\\"{x:1319,y:697,t:1528143557012};\\\", \\\"{x:1323,y:690,t:1528143557028};\\\", \\\"{x:1328,y:682,t:1528143557045};\\\", \\\"{x:1332,y:672,t:1528143557062};\\\", \\\"{x:1336,y:665,t:1528143557079};\\\", \\\"{x:1337,y:659,t:1528143557095};\\\", \\\"{x:1338,y:656,t:1528143557113};\\\", \\\"{x:1338,y:653,t:1528143557128};\\\", \\\"{x:1338,y:652,t:1528143557146};\\\", \\\"{x:1338,y:649,t:1528143557161};\\\", \\\"{x:1338,y:647,t:1528143557178};\\\", \\\"{x:1336,y:645,t:1528143557196};\\\", \\\"{x:1334,y:643,t:1528143557212};\\\", \\\"{x:1333,y:642,t:1528143557229};\\\", \\\"{x:1332,y:642,t:1528143557245};\\\", \\\"{x:1332,y:641,t:1528143557262};\\\", \\\"{x:1331,y:641,t:1528143557279};\\\", \\\"{x:1330,y:640,t:1528143557295};\\\", \\\"{x:1329,y:638,t:1528143557312};\\\", \\\"{x:1328,y:636,t:1528143557327};\\\", \\\"{x:1328,y:634,t:1528143557344};\\\", \\\"{x:1328,y:633,t:1528143557362};\\\", \\\"{x:1327,y:633,t:1528143557378};\\\", \\\"{x:1327,y:631,t:1528143557483};\\\", \\\"{x:1327,y:630,t:1528143557495};\\\", \\\"{x:1327,y:628,t:1528143557513};\\\", \\\"{x:1327,y:626,t:1528143557529};\\\", \\\"{x:1327,y:624,t:1528143557545};\\\", \\\"{x:1327,y:622,t:1528143557563};\\\", \\\"{x:1327,y:619,t:1528143557579};\\\", \\\"{x:1327,y:622,t:1528143558123};\\\", \\\"{x:1327,y:627,t:1528143558132};\\\", \\\"{x:1327,y:631,t:1528143558147};\\\", \\\"{x:1327,y:637,t:1528143558163};\\\", \\\"{x:1327,y:644,t:1528143558179};\\\", \\\"{x:1327,y:648,t:1528143558196};\\\", \\\"{x:1327,y:649,t:1528143558214};\\\", \\\"{x:1327,y:650,t:1528143558235};\\\", \\\"{x:1327,y:651,t:1528143558275};\\\", \\\"{x:1326,y:652,t:1528143558412};\\\", \\\"{x:1325,y:652,t:1528143558419};\\\", \\\"{x:1323,y:651,t:1528143558430};\\\", \\\"{x:1322,y:642,t:1528143558446};\\\", \\\"{x:1320,y:635,t:1528143558464};\\\", \\\"{x:1319,y:629,t:1528143558480};\\\", \\\"{x:1318,y:627,t:1528143558496};\\\", \\\"{x:1316,y:625,t:1528143558513};\\\", \\\"{x:1316,y:624,t:1528143558556};\\\", \\\"{x:1316,y:621,t:1528143558570};\\\", \\\"{x:1316,y:620,t:1528143558587};\\\", \\\"{x:1316,y:618,t:1528143558603};\\\", \\\"{x:1316,y:617,t:1528143558635};\\\", \\\"{x:1316,y:615,t:1528143558659};\\\", \\\"{x:1316,y:620,t:1528143559347};\\\", \\\"{x:1316,y:624,t:1528143559363};\\\", \\\"{x:1317,y:628,t:1528143559381};\\\", \\\"{x:1317,y:632,t:1528143559397};\\\", \\\"{x:1317,y:633,t:1528143559413};\\\", \\\"{x:1318,y:634,t:1528143559467};\\\", \\\"{x:1318,y:633,t:1528143559627};\\\", \\\"{x:1318,y:628,t:1528143559635};\\\", \\\"{x:1318,y:623,t:1528143559648};\\\", \\\"{x:1318,y:615,t:1528143559665};\\\", \\\"{x:1318,y:607,t:1528143559681};\\\", \\\"{x:1318,y:598,t:1528143559698};\\\", \\\"{x:1318,y:592,t:1528143559714};\\\", \\\"{x:1318,y:584,t:1528143559730};\\\", \\\"{x:1318,y:578,t:1528143559747};\\\", \\\"{x:1318,y:573,t:1528143559764};\\\", \\\"{x:1318,y:569,t:1528143559780};\\\", \\\"{x:1318,y:563,t:1528143559797};\\\", \\\"{x:1318,y:557,t:1528143559814};\\\", \\\"{x:1318,y:550,t:1528143559830};\\\", \\\"{x:1318,y:545,t:1528143559847};\\\", \\\"{x:1318,y:539,t:1528143559864};\\\", \\\"{x:1318,y:532,t:1528143559881};\\\", \\\"{x:1318,y:525,t:1528143559897};\\\", \\\"{x:1318,y:515,t:1528143559915};\\\", \\\"{x:1318,y:511,t:1528143559931};\\\", \\\"{x:1318,y:507,t:1528143559947};\\\", \\\"{x:1318,y:504,t:1528143559964};\\\", \\\"{x:1318,y:501,t:1528143559982};\\\", \\\"{x:1318,y:499,t:1528143559997};\\\", \\\"{x:1318,y:497,t:1528143560014};\\\", \\\"{x:1318,y:495,t:1528143560031};\\\", \\\"{x:1318,y:494,t:1528143560047};\\\", \\\"{x:1318,y:500,t:1528143561379};\\\", \\\"{x:1317,y:515,t:1528143561388};\\\", \\\"{x:1315,y:531,t:1528143561399};\\\", \\\"{x:1313,y:561,t:1528143561416};\\\", \\\"{x:1313,y:606,t:1528143561432};\\\", \\\"{x:1313,y:646,t:1528143561448};\\\", \\\"{x:1313,y:679,t:1528143561466};\\\", \\\"{x:1296,y:748,t:1528143561483};\\\", \\\"{x:1277,y:787,t:1528143561499};\\\", \\\"{x:1260,y:819,t:1528143561516};\\\", \\\"{x:1240,y:844,t:1528143561532};\\\", \\\"{x:1226,y:863,t:1528143561550};\\\", \\\"{x:1212,y:877,t:1528143561566};\\\", \\\"{x:1197,y:886,t:1528143561583};\\\", \\\"{x:1179,y:898,t:1528143561599};\\\", \\\"{x:1157,y:904,t:1528143561616};\\\", \\\"{x:1134,y:910,t:1528143561633};\\\", \\\"{x:1107,y:910,t:1528143561650};\\\", \\\"{x:1073,y:909,t:1528143561666};\\\", \\\"{x:975,y:885,t:1528143561683};\\\", \\\"{x:875,y:857,t:1528143561699};\\\", \\\"{x:773,y:816,t:1528143561716};\\\", \\\"{x:695,y:774,t:1528143561733};\\\", \\\"{x:639,y:736,t:1528143561750};\\\", \\\"{x:618,y:720,t:1528143561765};\\\", \\\"{x:613,y:715,t:1528143561783};\\\", \\\"{x:610,y:712,t:1528143561800};\\\", \\\"{x:610,y:711,t:1528143561815};\\\", \\\"{x:610,y:710,t:1528143561833};\\\", \\\"{x:608,y:702,t:1528143561849};\\\", \\\"{x:595,y:683,t:1528143561866};\\\", \\\"{x:585,y:670,t:1528143561882};\\\", \\\"{x:576,y:660,t:1528143561899};\\\", \\\"{x:574,y:658,t:1528143561916};\\\", \\\"{x:574,y:657,t:1528143561932};\\\", \\\"{x:574,y:654,t:1528143561949};\\\", \\\"{x:571,y:649,t:1528143561966};\\\", \\\"{x:570,y:643,t:1528143561982};\\\", \\\"{x:569,y:635,t:1528143561999};\\\", \\\"{x:569,y:629,t:1528143562015};\\\", \\\"{x:569,y:622,t:1528143562031};\\\", \\\"{x:569,y:618,t:1528143562049};\\\", \\\"{x:572,y:614,t:1528143562065};\\\", \\\"{x:590,y:602,t:1528143562083};\\\", \\\"{x:607,y:588,t:1528143562098};\\\", \\\"{x:614,y:581,t:1528143562116};\\\", \\\"{x:618,y:574,t:1528143562133};\\\", \\\"{x:620,y:569,t:1528143562149};\\\", \\\"{x:621,y:567,t:1528143562165};\\\", \\\"{x:621,y:565,t:1528143562182};\\\", \\\"{x:621,y:564,t:1528143562199};\\\", \\\"{x:621,y:562,t:1528143562235};\\\", \\\"{x:621,y:559,t:1528143562249};\\\", \\\"{x:621,y:553,t:1528143562267};\\\", \\\"{x:621,y:548,t:1528143562282};\\\", \\\"{x:621,y:545,t:1528143562300};\\\", \\\"{x:620,y:544,t:1528143562316};\\\", \\\"{x:619,y:542,t:1528143562429};\\\", \\\"{x:619,y:539,t:1528143562449};\\\", \\\"{x:618,y:535,t:1528143562467};\\\", \\\"{x:617,y:534,t:1528143562570};\\\", \\\"{x:617,y:533,t:1528143562602};\\\", \\\"{x:617,y:532,t:1528143562619};\\\", \\\"{x:617,y:530,t:1528143562632};\\\", \\\"{x:617,y:528,t:1528143562649};\\\", \\\"{x:617,y:525,t:1528143562666};\\\", \\\"{x:633,y:520,t:1528143563404};\\\", \\\"{x:689,y:518,t:1528143563417};\\\", \\\"{x:794,y:518,t:1528143563434};\\\", \\\"{x:902,y:518,t:1528143563449};\\\", \\\"{x:1016,y:518,t:1528143563467};\\\", \\\"{x:1039,y:518,t:1528143563483};\\\", \\\"{x:1040,y:518,t:1528143563587};\\\", \\\"{x:1041,y:518,t:1528143563715};\\\", \\\"{x:1041,y:519,t:1528143563723};\\\", \\\"{x:1044,y:524,t:1528143563733};\\\", \\\"{x:1053,y:534,t:1528143563751};\\\", \\\"{x:1063,y:545,t:1528143563766};\\\", \\\"{x:1075,y:561,t:1528143563783};\\\", \\\"{x:1095,y:583,t:1528143563801};\\\", \\\"{x:1102,y:592,t:1528143563817};\\\", \\\"{x:1107,y:600,t:1528143563834};\\\", \\\"{x:1110,y:606,t:1528143563851};\\\", \\\"{x:1111,y:607,t:1528143563866};\\\", \\\"{x:1113,y:609,t:1528143563883};\\\", \\\"{x:1114,y:609,t:1528143563948};\\\", \\\"{x:1116,y:610,t:1528143563955};\\\", \\\"{x:1117,y:611,t:1528143563966};\\\", \\\"{x:1120,y:612,t:1528143563983};\\\", \\\"{x:1121,y:612,t:1528143564044};\\\", \\\"{x:1122,y:613,t:1528143564115};\\\", \\\"{x:1124,y:615,t:1528143564131};\\\", \\\"{x:1127,y:615,t:1528143564138};\\\", \\\"{x:1134,y:615,t:1528143564151};\\\", \\\"{x:1157,y:615,t:1528143564168};\\\", \\\"{x:1187,y:618,t:1528143564183};\\\", \\\"{x:1215,y:620,t:1528143564201};\\\", \\\"{x:1240,y:620,t:1528143564218};\\\", \\\"{x:1259,y:620,t:1528143564234};\\\", \\\"{x:1272,y:620,t:1528143564251};\\\", \\\"{x:1273,y:619,t:1528143564267};\\\", \\\"{x:1275,y:619,t:1528143564531};\\\", \\\"{x:1277,y:626,t:1528143564539};\\\", \\\"{x:1277,y:635,t:1528143564551};\\\", \\\"{x:1277,y:654,t:1528143564568};\\\", \\\"{x:1276,y:682,t:1528143564584};\\\", \\\"{x:1272,y:711,t:1528143564600};\\\", \\\"{x:1269,y:738,t:1528143564618};\\\", \\\"{x:1264,y:763,t:1528143564634};\\\", \\\"{x:1262,y:785,t:1528143564651};\\\", \\\"{x:1262,y:791,t:1528143564668};\\\", \\\"{x:1259,y:794,t:1528143564685};\\\", \\\"{x:1259,y:795,t:1528143564701};\\\", \\\"{x:1259,y:798,t:1528143564718};\\\", \\\"{x:1259,y:799,t:1528143564734};\\\", \\\"{x:1259,y:800,t:1528143564751};\\\", \\\"{x:1259,y:801,t:1528143564768};\\\", \\\"{x:1259,y:804,t:1528143564795};\\\", \\\"{x:1259,y:806,t:1528143564803};\\\", \\\"{x:1259,y:810,t:1528143564817};\\\", \\\"{x:1257,y:821,t:1528143564835};\\\", \\\"{x:1255,y:825,t:1528143564851};\\\", \\\"{x:1254,y:827,t:1528143564868};\\\", \\\"{x:1253,y:828,t:1528143564885};\\\", \\\"{x:1253,y:829,t:1528143564901};\\\", \\\"{x:1255,y:826,t:1528143565100};\\\", \\\"{x:1256,y:824,t:1528143565107};\\\", \\\"{x:1258,y:820,t:1528143565118};\\\", \\\"{x:1261,y:813,t:1528143565135};\\\", \\\"{x:1262,y:811,t:1528143565151};\\\", \\\"{x:1263,y:809,t:1528143565168};\\\", \\\"{x:1263,y:808,t:1528143565185};\\\", \\\"{x:1264,y:806,t:1528143565201};\\\", \\\"{x:1264,y:805,t:1528143565217};\\\", \\\"{x:1265,y:803,t:1528143565235};\\\", \\\"{x:1265,y:802,t:1528143565251};\\\", \\\"{x:1266,y:802,t:1528143565268};\\\", \\\"{x:1266,y:800,t:1528143565285};\\\", \\\"{x:1267,y:798,t:1528143565301};\\\", \\\"{x:1268,y:796,t:1528143565318};\\\", \\\"{x:1268,y:795,t:1528143565334};\\\", \\\"{x:1269,y:794,t:1528143565351};\\\", \\\"{x:1270,y:792,t:1528143565368};\\\", \\\"{x:1271,y:789,t:1528143565385};\\\", \\\"{x:1275,y:784,t:1528143565401};\\\", \\\"{x:1282,y:775,t:1528143565417};\\\", \\\"{x:1290,y:763,t:1528143565435};\\\", \\\"{x:1293,y:758,t:1528143565451};\\\", \\\"{x:1296,y:753,t:1528143565468};\\\", \\\"{x:1299,y:745,t:1528143565485};\\\", \\\"{x:1301,y:738,t:1528143565502};\\\", \\\"{x:1301,y:735,t:1528143565518};\\\", \\\"{x:1300,y:735,t:1528143565780};\\\", \\\"{x:1298,y:740,t:1528143565787};\\\", \\\"{x:1295,y:749,t:1528143565802};\\\", \\\"{x:1290,y:764,t:1528143565818};\\\", \\\"{x:1285,y:778,t:1528143565835};\\\", \\\"{x:1280,y:789,t:1528143565852};\\\", \\\"{x:1278,y:795,t:1528143565868};\\\", \\\"{x:1273,y:803,t:1528143565885};\\\", \\\"{x:1269,y:811,t:1528143565902};\\\", \\\"{x:1264,y:818,t:1528143565918};\\\", \\\"{x:1262,y:823,t:1528143565935};\\\", \\\"{x:1261,y:827,t:1528143565952};\\\", \\\"{x:1261,y:828,t:1528143566028};\\\", \\\"{x:1259,y:830,t:1528143566059};\\\", \\\"{x:1252,y:834,t:1528143566068};\\\", \\\"{x:1248,y:836,t:1528143566085};\\\", \\\"{x:1243,y:838,t:1528143566102};\\\", \\\"{x:1237,y:841,t:1528143566119};\\\", \\\"{x:1230,y:844,t:1528143566135};\\\", \\\"{x:1229,y:845,t:1528143566152};\\\", \\\"{x:1229,y:844,t:1528143566235};\\\", \\\"{x:1229,y:825,t:1528143566252};\\\", \\\"{x:1229,y:813,t:1528143566269};\\\", \\\"{x:1229,y:801,t:1528143566285};\\\", \\\"{x:1229,y:795,t:1528143566303};\\\", \\\"{x:1229,y:791,t:1528143566319};\\\", \\\"{x:1229,y:787,t:1528143566335};\\\", \\\"{x:1230,y:783,t:1528143566352};\\\", \\\"{x:1233,y:777,t:1528143566369};\\\", \\\"{x:1235,y:772,t:1528143566385};\\\", \\\"{x:1239,y:763,t:1528143566403};\\\", \\\"{x:1242,y:755,t:1528143566419};\\\", \\\"{x:1246,y:748,t:1528143566435};\\\", \\\"{x:1248,y:742,t:1528143566452};\\\", \\\"{x:1250,y:735,t:1528143566469};\\\", \\\"{x:1255,y:727,t:1528143566485};\\\", \\\"{x:1257,y:717,t:1528143566502};\\\", \\\"{x:1260,y:705,t:1528143566519};\\\", \\\"{x:1265,y:692,t:1528143566535};\\\", \\\"{x:1267,y:681,t:1528143566552};\\\", \\\"{x:1270,y:673,t:1528143566569};\\\", \\\"{x:1272,y:665,t:1528143566585};\\\", \\\"{x:1273,y:662,t:1528143566602};\\\", \\\"{x:1274,y:658,t:1528143566619};\\\", \\\"{x:1274,y:656,t:1528143566636};\\\", \\\"{x:1275,y:654,t:1528143566652};\\\", \\\"{x:1275,y:653,t:1528143566675};\\\", \\\"{x:1276,y:652,t:1528143566685};\\\", \\\"{x:1277,y:651,t:1528143566702};\\\", \\\"{x:1277,y:650,t:1528143566719};\\\", \\\"{x:1278,y:648,t:1528143566736};\\\", \\\"{x:1281,y:643,t:1528143566751};\\\", \\\"{x:1283,y:641,t:1528143566769};\\\", \\\"{x:1288,y:638,t:1528143566786};\\\", \\\"{x:1290,y:636,t:1528143566802};\\\", \\\"{x:1295,y:633,t:1528143566819};\\\", \\\"{x:1298,y:632,t:1528143566835};\\\", \\\"{x:1299,y:631,t:1528143566852};\\\", \\\"{x:1300,y:631,t:1528143566900};\\\", \\\"{x:1301,y:631,t:1528143566908};\\\", \\\"{x:1302,y:631,t:1528143566920};\\\", \\\"{x:1308,y:631,t:1528143566936};\\\", \\\"{x:1311,y:631,t:1528143566952};\\\", \\\"{x:1315,y:631,t:1528143566969};\\\", \\\"{x:1316,y:630,t:1528143566986};\\\", \\\"{x:1317,y:631,t:1528143569115};\\\", \\\"{x:1317,y:636,t:1528143569123};\\\", \\\"{x:1317,y:641,t:1528143569136};\\\", \\\"{x:1319,y:647,t:1528143569152};\\\", \\\"{x:1319,y:653,t:1528143569170};\\\", \\\"{x:1320,y:659,t:1528143569186};\\\", \\\"{x:1320,y:660,t:1528143569203};\\\", \\\"{x:1320,y:662,t:1528143569219};\\\", \\\"{x:1320,y:663,t:1528143569242};\\\", \\\"{x:1320,y:664,t:1528143569322};\\\", \\\"{x:1320,y:665,t:1528143569363};\\\", \\\"{x:1320,y:667,t:1528143569371};\\\", \\\"{x:1320,y:669,t:1528143569387};\\\", \\\"{x:1320,y:670,t:1528143569404};\\\", \\\"{x:1321,y:672,t:1528143569420};\\\", \\\"{x:1315,y:670,t:1528143569548};\\\", \\\"{x:1314,y:667,t:1528143569554};\\\", \\\"{x:1311,y:661,t:1528143569570};\\\", \\\"{x:1308,y:653,t:1528143569587};\\\", \\\"{x:1306,y:646,t:1528143569604};\\\", \\\"{x:1305,y:642,t:1528143569621};\\\", \\\"{x:1305,y:641,t:1528143569637};\\\", \\\"{x:1305,y:640,t:1528143569654};\\\", \\\"{x:1305,y:637,t:1528143569884};\\\", \\\"{x:1309,y:632,t:1528143569892};\\\", \\\"{x:1311,y:629,t:1528143569904};\\\", \\\"{x:1315,y:622,t:1528143569922};\\\", \\\"{x:1316,y:619,t:1528143569936};\\\", \\\"{x:1317,y:617,t:1528143569953};\\\", \\\"{x:1317,y:621,t:1528143570178};\\\", \\\"{x:1315,y:626,t:1528143570186};\\\", \\\"{x:1315,y:631,t:1528143570203};\\\", \\\"{x:1315,y:634,t:1528143570221};\\\", \\\"{x:1314,y:637,t:1528143570237};\\\", \\\"{x:1314,y:639,t:1528143570254};\\\", \\\"{x:1314,y:641,t:1528143570271};\\\", \\\"{x:1313,y:644,t:1528143570286};\\\", \\\"{x:1313,y:645,t:1528143570304};\\\", \\\"{x:1313,y:647,t:1528143570323};\\\", \\\"{x:1313,y:649,t:1528143570337};\\\", \\\"{x:1313,y:650,t:1528143570353};\\\", \\\"{x:1312,y:651,t:1528143570370};\\\", \\\"{x:1312,y:652,t:1528143570386};\\\", \\\"{x:1312,y:653,t:1528143570403};\\\", \\\"{x:1312,y:655,t:1528143570420};\\\", \\\"{x:1312,y:658,t:1528143570436};\\\", \\\"{x:1312,y:659,t:1528143570453};\\\", \\\"{x:1311,y:663,t:1528143570470};\\\", \\\"{x:1311,y:665,t:1528143570487};\\\", \\\"{x:1311,y:668,t:1528143570503};\\\", \\\"{x:1311,y:671,t:1528143570522};\\\", \\\"{x:1311,y:672,t:1528143570538};\\\", \\\"{x:1311,y:675,t:1528143570554};\\\", \\\"{x:1311,y:678,t:1528143570572};\\\", \\\"{x:1311,y:681,t:1528143570588};\\\", \\\"{x:1311,y:682,t:1528143570605};\\\", \\\"{x:1311,y:684,t:1528143570621};\\\", \\\"{x:1310,y:688,t:1528143570638};\\\", \\\"{x:1310,y:692,t:1528143570654};\\\", \\\"{x:1308,y:696,t:1528143570671};\\\", \\\"{x:1308,y:699,t:1528143570689};\\\", \\\"{x:1308,y:702,t:1528143570705};\\\", \\\"{x:1308,y:705,t:1528143570722};\\\", \\\"{x:1308,y:709,t:1528143570737};\\\", \\\"{x:1308,y:713,t:1528143570753};\\\", \\\"{x:1308,y:718,t:1528143570771};\\\", \\\"{x:1308,y:720,t:1528143570787};\\\", \\\"{x:1308,y:721,t:1528143570804};\\\", \\\"{x:1308,y:722,t:1528143570820};\\\", \\\"{x:1308,y:724,t:1528143570875};\\\", \\\"{x:1308,y:725,t:1528143570888};\\\", \\\"{x:1308,y:729,t:1528143570904};\\\", \\\"{x:1308,y:732,t:1528143570922};\\\", \\\"{x:1308,y:736,t:1528143570939};\\\", \\\"{x:1308,y:739,t:1528143570955};\\\", \\\"{x:1308,y:746,t:1528143570971};\\\", \\\"{x:1307,y:750,t:1528143570988};\\\", \\\"{x:1306,y:755,t:1528143571004};\\\", \\\"{x:1306,y:761,t:1528143571021};\\\", \\\"{x:1306,y:764,t:1528143571038};\\\", \\\"{x:1306,y:768,t:1528143571054};\\\", \\\"{x:1306,y:771,t:1528143571071};\\\", \\\"{x:1306,y:775,t:1528143571088};\\\", \\\"{x:1306,y:783,t:1528143571104};\\\", \\\"{x:1306,y:792,t:1528143571122};\\\", \\\"{x:1306,y:806,t:1528143571138};\\\", \\\"{x:1306,y:818,t:1528143571154};\\\", \\\"{x:1306,y:836,t:1528143571171};\\\", \\\"{x:1306,y:849,t:1528143571188};\\\", \\\"{x:1308,y:862,t:1528143571206};\\\", \\\"{x:1309,y:876,t:1528143571221};\\\", \\\"{x:1311,y:891,t:1528143571238};\\\", \\\"{x:1311,y:901,t:1528143571255};\\\", \\\"{x:1311,y:907,t:1528143571271};\\\", \\\"{x:1304,y:914,t:1528143571288};\\\", \\\"{x:1289,y:915,t:1528143571305};\\\", \\\"{x:1257,y:915,t:1528143571323};\\\", \\\"{x:1215,y:915,t:1528143571339};\\\", \\\"{x:1155,y:909,t:1528143571355};\\\", \\\"{x:1124,y:908,t:1528143571371};\\\", \\\"{x:1093,y:904,t:1528143571388};\\\", \\\"{x:1057,y:899,t:1528143571405};\\\", \\\"{x:1011,y:892,t:1528143571421};\\\", \\\"{x:965,y:881,t:1528143571438};\\\", \\\"{x:896,y:864,t:1528143571455};\\\", \\\"{x:837,y:845,t:1528143571470};\\\", \\\"{x:805,y:839,t:1528143571487};\\\", \\\"{x:776,y:834,t:1528143571504};\\\", \\\"{x:755,y:833,t:1528143571521};\\\", \\\"{x:726,y:830,t:1528143571538};\\\", \\\"{x:695,y:830,t:1528143571554};\\\", \\\"{x:685,y:830,t:1528143571571};\\\", \\\"{x:682,y:830,t:1528143571587};\\\", \\\"{x:680,y:830,t:1528143571604};\\\", \\\"{x:673,y:830,t:1528143571621};\\\", \\\"{x:658,y:830,t:1528143571637};\\\", \\\"{x:633,y:830,t:1528143571655};\\\", \\\"{x:602,y:830,t:1528143571670};\\\", \\\"{x:564,y:830,t:1528143571688};\\\", \\\"{x:538,y:830,t:1528143571705};\\\", \\\"{x:528,y:830,t:1528143571721};\\\", \\\"{x:523,y:828,t:1528143571738};\\\", \\\"{x:505,y:819,t:1528143571755};\\\", \\\"{x:492,y:813,t:1528143571771};\\\", \\\"{x:482,y:805,t:1528143571787};\\\", \\\"{x:480,y:804,t:1528143571805};\\\", \\\"{x:479,y:802,t:1528143571821};\\\", \\\"{x:479,y:799,t:1528143571858};\\\", \\\"{x:479,y:789,t:1528143571872};\\\", \\\"{x:479,y:779,t:1528143571888};\\\", \\\"{x:479,y:774,t:1528143571905};\\\", \\\"{x:479,y:770,t:1528143571922};\\\", \\\"{x:480,y:764,t:1528143571939};\\\", \\\"{x:481,y:761,t:1528143571955};\\\", \\\"{x:481,y:759,t:1528143571971};\\\", \\\"{x:482,y:758,t:1528143571988};\\\", \\\"{x:483,y:757,t:1528143572011};\\\", \\\"{x:484,y:754,t:1528143572022};\\\", \\\"{x:487,y:750,t:1528143572038};\\\", \\\"{x:491,y:745,t:1528143572055};\\\", \\\"{x:492,y:744,t:1528143572072};\\\", \\\"{x:492,y:743,t:1528143572091};\\\", \\\"{x:492,y:742,t:1528143572115};\\\", \\\"{x:493,y:742,t:1528143572122};\\\", \\\"{x:493,y:741,t:1528143572138};\\\", \\\"{x:495,y:732,t:1528143572155};\\\", \\\"{x:496,y:726,t:1528143572172};\\\", \\\"{x:498,y:720,t:1528143572188};\\\", \\\"{x:498,y:719,t:1528143572204};\\\", \\\"{x:499,y:718,t:1528143572221};\\\" ] }, { \\\"rt\\\": 28456, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 685461, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"VVH1B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"D\\\", \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -02 PM-03 PM-04 PM-04 PM-12 PM-02 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:499,y:672,t:1528143574363};\\\", \\\"{x:499,y:576,t:1528143574375};\\\", \\\"{x:495,y:517,t:1528143574393};\\\", \\\"{x:495,y:494,t:1528143574409};\\\", \\\"{x:494,y:480,t:1528143574425};\\\", \\\"{x:493,y:476,t:1528143574441};\\\", \\\"{x:494,y:475,t:1528143575092};\\\", \\\"{x:504,y:470,t:1528143575098};\\\", \\\"{x:534,y:464,t:1528143575109};\\\", \\\"{x:590,y:462,t:1528143575126};\\\", \\\"{x:645,y:458,t:1528143575143};\\\", \\\"{x:682,y:456,t:1528143575159};\\\", \\\"{x:706,y:456,t:1528143575176};\\\", \\\"{x:723,y:455,t:1528143575193};\\\", \\\"{x:728,y:455,t:1528143575209};\\\", \\\"{x:729,y:455,t:1528143575226};\\\", \\\"{x:730,y:455,t:1528143575283};\\\", \\\"{x:733,y:455,t:1528143576179};\\\", \\\"{x:741,y:455,t:1528143576193};\\\", \\\"{x:770,y:455,t:1528143576209};\\\", \\\"{x:791,y:459,t:1528143576226};\\\", \\\"{x:822,y:476,t:1528143576242};\\\", \\\"{x:860,y:507,t:1528143576260};\\\", \\\"{x:887,y:536,t:1528143576277};\\\", \\\"{x:915,y:566,t:1528143576293};\\\", \\\"{x:931,y:588,t:1528143576310};\\\", \\\"{x:947,y:609,t:1528143576326};\\\", \\\"{x:957,y:626,t:1528143576344};\\\", \\\"{x:963,y:636,t:1528143576360};\\\", \\\"{x:965,y:639,t:1528143576377};\\\", \\\"{x:966,y:640,t:1528143576394};\\\", \\\"{x:968,y:640,t:1528143576591};\\\", \\\"{x:971,y:640,t:1528143576598};\\\", \\\"{x:975,y:640,t:1528143576614};\\\", \\\"{x:990,y:646,t:1528143576631};\\\", \\\"{x:993,y:648,t:1528143576647};\\\", \\\"{x:999,y:653,t:1528143576664};\\\", \\\"{x:1009,y:667,t:1528143576681};\\\", \\\"{x:1018,y:684,t:1528143576697};\\\", \\\"{x:1022,y:697,t:1528143576714};\\\", \\\"{x:1025,y:707,t:1528143576731};\\\", \\\"{x:1026,y:717,t:1528143576747};\\\", \\\"{x:1028,y:725,t:1528143576764};\\\", \\\"{x:1029,y:731,t:1528143576781};\\\", \\\"{x:1030,y:733,t:1528143576797};\\\", \\\"{x:1030,y:735,t:1528143576814};\\\", \\\"{x:1031,y:736,t:1528143576830};\\\", \\\"{x:1034,y:738,t:1528143576847};\\\", \\\"{x:1037,y:738,t:1528143576864};\\\", \\\"{x:1039,y:740,t:1528143576881};\\\", \\\"{x:1041,y:740,t:1528143576897};\\\", \\\"{x:1042,y:740,t:1528143576914};\\\", \\\"{x:1040,y:740,t:1528143577478};\\\", \\\"{x:997,y:709,t:1528143577497};\\\", \\\"{x:932,y:675,t:1528143577513};\\\", \\\"{x:861,y:649,t:1528143577530};\\\", \\\"{x:800,y:631,t:1528143577547};\\\", \\\"{x:741,y:614,t:1528143577562};\\\", \\\"{x:681,y:599,t:1528143577581};\\\", \\\"{x:640,y:589,t:1528143577596};\\\", \\\"{x:615,y:584,t:1528143577615};\\\", \\\"{x:611,y:584,t:1528143577631};\\\", \\\"{x:609,y:584,t:1528143577649};\\\", \\\"{x:608,y:584,t:1528143577664};\\\", \\\"{x:607,y:583,t:1528143577681};\\\", \\\"{x:604,y:581,t:1528143577698};\\\", \\\"{x:601,y:580,t:1528143577714};\\\", \\\"{x:600,y:580,t:1528143577731};\\\", \\\"{x:598,y:579,t:1528143577747};\\\", \\\"{x:597,y:579,t:1528143577765};\\\", \\\"{x:596,y:578,t:1528143577780};\\\", \\\"{x:595,y:578,t:1528143577797};\\\", \\\"{x:594,y:578,t:1528143577821};\\\", \\\"{x:593,y:577,t:1528143577831};\\\", \\\"{x:592,y:576,t:1528143577911};\\\", \\\"{x:607,y:581,t:1528143578119};\\\", \\\"{x:654,y:583,t:1528143578132};\\\", \\\"{x:780,y:589,t:1528143578148};\\\", \\\"{x:984,y:663,t:1528143578165};\\\", \\\"{x:1088,y:706,t:1528143578181};\\\", \\\"{x:1182,y:750,t:1528143578199};\\\", \\\"{x:1237,y:780,t:1528143578215};\\\", \\\"{x:1258,y:793,t:1528143578231};\\\", \\\"{x:1267,y:800,t:1528143578249};\\\", \\\"{x:1268,y:801,t:1528143578265};\\\", \\\"{x:1269,y:802,t:1528143578318};\\\", \\\"{x:1269,y:805,t:1528143578332};\\\", \\\"{x:1277,y:828,t:1528143578350};\\\", \\\"{x:1304,y:883,t:1528143578366};\\\", \\\"{x:1320,y:906,t:1528143578381};\\\", \\\"{x:1332,y:923,t:1528143578398};\\\", \\\"{x:1337,y:933,t:1528143578415};\\\", \\\"{x:1346,y:944,t:1528143578432};\\\", \\\"{x:1348,y:947,t:1528143578449};\\\", \\\"{x:1348,y:948,t:1528143578471};\\\", \\\"{x:1350,y:949,t:1528143578482};\\\", \\\"{x:1362,y:952,t:1528143578498};\\\", \\\"{x:1384,y:955,t:1528143578516};\\\", \\\"{x:1412,y:959,t:1528143578532};\\\", \\\"{x:1443,y:964,t:1528143578549};\\\", \\\"{x:1487,y:970,t:1528143578567};\\\", \\\"{x:1509,y:973,t:1528143578583};\\\", \\\"{x:1516,y:974,t:1528143578598};\\\", \\\"{x:1517,y:974,t:1528143578718};\\\", \\\"{x:1519,y:974,t:1528143578734};\\\", \\\"{x:1521,y:974,t:1528143578749};\\\", \\\"{x:1525,y:974,t:1528143578766};\\\", \\\"{x:1531,y:974,t:1528143578782};\\\", \\\"{x:1544,y:974,t:1528143578799};\\\", \\\"{x:1554,y:975,t:1528143578816};\\\", \\\"{x:1564,y:975,t:1528143578833};\\\", \\\"{x:1572,y:975,t:1528143578850};\\\", \\\"{x:1576,y:975,t:1528143578866};\\\", \\\"{x:1581,y:975,t:1528143578883};\\\", \\\"{x:1584,y:975,t:1528143578899};\\\", \\\"{x:1586,y:975,t:1528143578916};\\\", \\\"{x:1588,y:975,t:1528143578933};\\\", \\\"{x:1589,y:975,t:1528143578949};\\\", \\\"{x:1592,y:975,t:1528143578966};\\\", \\\"{x:1593,y:975,t:1528143578982};\\\", \\\"{x:1598,y:975,t:1528143579000};\\\", \\\"{x:1603,y:975,t:1528143579015};\\\", \\\"{x:1609,y:975,t:1528143579033};\\\", \\\"{x:1613,y:975,t:1528143579049};\\\", \\\"{x:1622,y:975,t:1528143579066};\\\", \\\"{x:1629,y:975,t:1528143579083};\\\", \\\"{x:1633,y:975,t:1528143579100};\\\", \\\"{x:1636,y:975,t:1528143579117};\\\", \\\"{x:1638,y:975,t:1528143579133};\\\", \\\"{x:1633,y:975,t:1528143579679};\\\", \\\"{x:1629,y:976,t:1528143579686};\\\", \\\"{x:1628,y:977,t:1528143579700};\\\", \\\"{x:1621,y:978,t:1528143579717};\\\", \\\"{x:1617,y:978,t:1528143579733};\\\", \\\"{x:1616,y:979,t:1528143579758};\\\", \\\"{x:1616,y:978,t:1528143580255};\\\", \\\"{x:1616,y:976,t:1528143580287};\\\", \\\"{x:1616,y:974,t:1528143580300};\\\", \\\"{x:1614,y:971,t:1528143580317};\\\", \\\"{x:1614,y:965,t:1528143580335};\\\", \\\"{x:1614,y:964,t:1528143580350};\\\", \\\"{x:1614,y:963,t:1528143580368};\\\", \\\"{x:1614,y:961,t:1528143580384};\\\", \\\"{x:1614,y:960,t:1528143580454};\\\", \\\"{x:1614,y:959,t:1528143580486};\\\", \\\"{x:1614,y:958,t:1528143580509};\\\", \\\"{x:1614,y:957,t:1528143580574};\\\", \\\"{x:1614,y:956,t:1528143580815};\\\", \\\"{x:1614,y:955,t:1528143580838};\\\", \\\"{x:1614,y:953,t:1528143580854};\\\", \\\"{x:1614,y:952,t:1528143580867};\\\", \\\"{x:1614,y:949,t:1528143580884};\\\", \\\"{x:1614,y:946,t:1528143580901};\\\", \\\"{x:1614,y:943,t:1528143580917};\\\", \\\"{x:1614,y:939,t:1528143580934};\\\", \\\"{x:1614,y:938,t:1528143580951};\\\", \\\"{x:1614,y:937,t:1528143580967};\\\", \\\"{x:1614,y:935,t:1528143580984};\\\", \\\"{x:1614,y:933,t:1528143581007};\\\", \\\"{x:1613,y:932,t:1528143581022};\\\", \\\"{x:1613,y:930,t:1528143581055};\\\", \\\"{x:1613,y:929,t:1528143581078};\\\", \\\"{x:1613,y:927,t:1528143581095};\\\", \\\"{x:1613,y:926,t:1528143581110};\\\", \\\"{x:1613,y:925,t:1528143581118};\\\", \\\"{x:1613,y:924,t:1528143581142};\\\", \\\"{x:1613,y:923,t:1528143581151};\\\", \\\"{x:1613,y:921,t:1528143581168};\\\", \\\"{x:1613,y:920,t:1528143581185};\\\", \\\"{x:1613,y:916,t:1528143581201};\\\", \\\"{x:1613,y:914,t:1528143581218};\\\", \\\"{x:1613,y:910,t:1528143581235};\\\", \\\"{x:1613,y:908,t:1528143581251};\\\", \\\"{x:1613,y:906,t:1528143581268};\\\", \\\"{x:1613,y:904,t:1528143581284};\\\", \\\"{x:1613,y:902,t:1528143581301};\\\", \\\"{x:1613,y:896,t:1528143581319};\\\", \\\"{x:1613,y:893,t:1528143581334};\\\", \\\"{x:1612,y:889,t:1528143581351};\\\", \\\"{x:1612,y:887,t:1528143581368};\\\", \\\"{x:1612,y:885,t:1528143581384};\\\", \\\"{x:1611,y:884,t:1528143581400};\\\", \\\"{x:1611,y:882,t:1528143581417};\\\", \\\"{x:1611,y:878,t:1528143581433};\\\", \\\"{x:1610,y:874,t:1528143581451};\\\", \\\"{x:1610,y:870,t:1528143581468};\\\", \\\"{x:1610,y:867,t:1528143581484};\\\", \\\"{x:1609,y:864,t:1528143581500};\\\", \\\"{x:1609,y:861,t:1528143581518};\\\", \\\"{x:1609,y:860,t:1528143581533};\\\", \\\"{x:1608,y:858,t:1528143581550};\\\", \\\"{x:1608,y:857,t:1528143581568};\\\", \\\"{x:1607,y:854,t:1528143581584};\\\", \\\"{x:1606,y:850,t:1528143581600};\\\", \\\"{x:1606,y:847,t:1528143581618};\\\", \\\"{x:1606,y:843,t:1528143581634};\\\", \\\"{x:1606,y:840,t:1528143581651};\\\", \\\"{x:1606,y:837,t:1528143581668};\\\", \\\"{x:1606,y:836,t:1528143581684};\\\", \\\"{x:1606,y:834,t:1528143581701};\\\", \\\"{x:1606,y:831,t:1528143581718};\\\", \\\"{x:1606,y:830,t:1528143581735};\\\", \\\"{x:1606,y:827,t:1528143581751};\\\", \\\"{x:1606,y:824,t:1528143581768};\\\", \\\"{x:1606,y:822,t:1528143581786};\\\", \\\"{x:1606,y:820,t:1528143581801};\\\", \\\"{x:1606,y:818,t:1528143581818};\\\", \\\"{x:1606,y:815,t:1528143581835};\\\", \\\"{x:1606,y:814,t:1528143581851};\\\", \\\"{x:1606,y:812,t:1528143581868};\\\", \\\"{x:1606,y:810,t:1528143581886};\\\", \\\"{x:1606,y:808,t:1528143581901};\\\", \\\"{x:1606,y:806,t:1528143581919};\\\", \\\"{x:1606,y:805,t:1528143581935};\\\", \\\"{x:1606,y:802,t:1528143581951};\\\", \\\"{x:1606,y:800,t:1528143581969};\\\", \\\"{x:1606,y:799,t:1528143581991};\\\", \\\"{x:1606,y:798,t:1528143582002};\\\", \\\"{x:1606,y:797,t:1528143582019};\\\", \\\"{x:1606,y:796,t:1528143582035};\\\", \\\"{x:1606,y:794,t:1528143582052};\\\", \\\"{x:1606,y:793,t:1528143582070};\\\", \\\"{x:1606,y:792,t:1528143582085};\\\", \\\"{x:1606,y:790,t:1528143582101};\\\", \\\"{x:1604,y:788,t:1528143582118};\\\", \\\"{x:1604,y:787,t:1528143582150};\\\", \\\"{x:1604,y:785,t:1528143582223};\\\", \\\"{x:1604,y:784,t:1528143582262};\\\", \\\"{x:1604,y:783,t:1528143582286};\\\", \\\"{x:1604,y:782,t:1528143582317};\\\", \\\"{x:1604,y:781,t:1528143582335};\\\", \\\"{x:1603,y:781,t:1528143582351};\\\", \\\"{x:1603,y:779,t:1528143582367};\\\", \\\"{x:1603,y:778,t:1528143582384};\\\", \\\"{x:1603,y:777,t:1528143582413};\\\", \\\"{x:1603,y:776,t:1528143582430};\\\", \\\"{x:1603,y:775,t:1528143582438};\\\", \\\"{x:1603,y:774,t:1528143582478};\\\", \\\"{x:1603,y:773,t:1528143582485};\\\", \\\"{x:1603,y:772,t:1528143582510};\\\", \\\"{x:1603,y:771,t:1528143582557};\\\", \\\"{x:1603,y:770,t:1528143582589};\\\", \\\"{x:1603,y:769,t:1528143582622};\\\", \\\"{x:1601,y:769,t:1528143583686};\\\", \\\"{x:1511,y:789,t:1528143583702};\\\", \\\"{x:1364,y:795,t:1528143583719};\\\", \\\"{x:1203,y:795,t:1528143583736};\\\", \\\"{x:1050,y:790,t:1528143583752};\\\", \\\"{x:926,y:778,t:1528143583769};\\\", \\\"{x:851,y:765,t:1528143583786};\\\", \\\"{x:828,y:760,t:1528143583802};\\\", \\\"{x:826,y:759,t:1528143583819};\\\", \\\"{x:825,y:758,t:1528143583854};\\\", \\\"{x:824,y:756,t:1528143583870};\\\", \\\"{x:817,y:747,t:1528143583886};\\\", \\\"{x:812,y:738,t:1528143583902};\\\", \\\"{x:808,y:729,t:1528143583919};\\\", \\\"{x:797,y:714,t:1528143583936};\\\", \\\"{x:788,y:699,t:1528143583953};\\\", \\\"{x:781,y:687,t:1528143583969};\\\", \\\"{x:775,y:677,t:1528143583986};\\\", \\\"{x:764,y:664,t:1528143584003};\\\", \\\"{x:752,y:647,t:1528143584019};\\\", \\\"{x:737,y:634,t:1528143584036};\\\", \\\"{x:720,y:625,t:1528143584054};\\\", \\\"{x:703,y:619,t:1528143584069};\\\", \\\"{x:692,y:615,t:1528143584085};\\\", \\\"{x:688,y:613,t:1528143584102};\\\", \\\"{x:687,y:612,t:1528143584158};\\\", \\\"{x:686,y:612,t:1528143584169};\\\", \\\"{x:685,y:609,t:1528143584186};\\\", \\\"{x:684,y:605,t:1528143584203};\\\", \\\"{x:681,y:602,t:1528143584219};\\\", \\\"{x:679,y:599,t:1528143584237};\\\", \\\"{x:671,y:593,t:1528143584252};\\\", \\\"{x:650,y:587,t:1528143584270};\\\", \\\"{x:628,y:586,t:1528143584287};\\\", \\\"{x:605,y:586,t:1528143584302};\\\", \\\"{x:575,y:586,t:1528143584320};\\\", \\\"{x:546,y:586,t:1528143584337};\\\", \\\"{x:523,y:586,t:1528143584353};\\\", \\\"{x:505,y:586,t:1528143584370};\\\", \\\"{x:493,y:586,t:1528143584387};\\\", \\\"{x:485,y:589,t:1528143584403};\\\", \\\"{x:481,y:590,t:1528143584419};\\\", \\\"{x:480,y:590,t:1528143584526};\\\", \\\"{x:474,y:590,t:1528143584537};\\\", \\\"{x:447,y:590,t:1528143584553};\\\", \\\"{x:420,y:590,t:1528143584570};\\\", \\\"{x:390,y:590,t:1528143584587};\\\", \\\"{x:373,y:590,t:1528143584603};\\\", \\\"{x:371,y:590,t:1528143584620};\\\", \\\"{x:371,y:589,t:1528143584734};\\\", \\\"{x:372,y:587,t:1528143584742};\\\", \\\"{x:373,y:585,t:1528143584757};\\\", \\\"{x:374,y:585,t:1528143584774};\\\", \\\"{x:374,y:584,t:1528143584798};\\\", \\\"{x:375,y:584,t:1528143584830};\\\", \\\"{x:375,y:583,t:1528143584862};\\\", \\\"{x:376,y:582,t:1528143584870};\\\", \\\"{x:376,y:581,t:1528143584903};\\\", \\\"{x:376,y:577,t:1528143584920};\\\", \\\"{x:376,y:575,t:1528143584936};\\\", \\\"{x:376,y:565,t:1528143584954};\\\", \\\"{x:364,y:545,t:1528143584971};\\\", \\\"{x:317,y:515,t:1528143584987};\\\", \\\"{x:225,y:483,t:1528143585003};\\\", \\\"{x:151,y:469,t:1528143585020};\\\", \\\"{x:115,y:465,t:1528143585036};\\\", \\\"{x:99,y:465,t:1528143585054};\\\", \\\"{x:95,y:465,t:1528143585070};\\\", \\\"{x:95,y:466,t:1528143585094};\\\", \\\"{x:95,y:469,t:1528143585103};\\\", \\\"{x:93,y:478,t:1528143585120};\\\", \\\"{x:94,y:489,t:1528143585137};\\\", \\\"{x:97,y:498,t:1528143585153};\\\", \\\"{x:100,y:501,t:1528143585171};\\\", \\\"{x:101,y:501,t:1528143585198};\\\", \\\"{x:101,y:502,t:1528143585214};\\\", \\\"{x:103,y:502,t:1528143585222};\\\", \\\"{x:105,y:504,t:1528143585238};\\\", \\\"{x:115,y:509,t:1528143585255};\\\", \\\"{x:122,y:516,t:1528143585271};\\\", \\\"{x:131,y:527,t:1528143585287};\\\", \\\"{x:135,y:533,t:1528143585304};\\\", \\\"{x:140,y:541,t:1528143585322};\\\", \\\"{x:141,y:545,t:1528143585338};\\\", \\\"{x:141,y:547,t:1528143585354};\\\", \\\"{x:145,y:554,t:1528143585371};\\\", \\\"{x:148,y:561,t:1528143585387};\\\", \\\"{x:151,y:572,t:1528143585403};\\\", \\\"{x:153,y:582,t:1528143585421};\\\", \\\"{x:155,y:592,t:1528143585437};\\\", \\\"{x:155,y:596,t:1528143585453};\\\", \\\"{x:155,y:601,t:1528143585470};\\\", \\\"{x:155,y:607,t:1528143585488};\\\", \\\"{x:157,y:614,t:1528143585504};\\\", \\\"{x:158,y:618,t:1528143585520};\\\", \\\"{x:159,y:620,t:1528143585539};\\\", \\\"{x:160,y:620,t:1528143585726};\\\", \\\"{x:160,y:621,t:1528143585742};\\\", \\\"{x:160,y:622,t:1528143585753};\\\", \\\"{x:161,y:623,t:1528143585772};\\\", \\\"{x:171,y:624,t:1528143586294};\\\", \\\"{x:193,y:624,t:1528143586306};\\\", \\\"{x:247,y:626,t:1528143586321};\\\", \\\"{x:289,y:632,t:1528143586339};\\\", \\\"{x:319,y:635,t:1528143586354};\\\", \\\"{x:336,y:639,t:1528143586371};\\\", \\\"{x:341,y:640,t:1528143586387};\\\", \\\"{x:343,y:640,t:1528143586404};\\\", \\\"{x:344,y:640,t:1528143586421};\\\", \\\"{x:347,y:640,t:1528143586438};\\\", \\\"{x:352,y:638,t:1528143586454};\\\", \\\"{x:360,y:637,t:1528143586472};\\\", \\\"{x:374,y:634,t:1528143586489};\\\", \\\"{x:393,y:632,t:1528143586504};\\\", \\\"{x:417,y:628,t:1528143586521};\\\", \\\"{x:437,y:624,t:1528143586539};\\\", \\\"{x:450,y:622,t:1528143586555};\\\", \\\"{x:457,y:621,t:1528143586572};\\\", \\\"{x:461,y:619,t:1528143586589};\\\", \\\"{x:463,y:619,t:1528143586605};\\\", \\\"{x:467,y:618,t:1528143586621};\\\", \\\"{x:477,y:618,t:1528143586639};\\\", \\\"{x:497,y:618,t:1528143586654};\\\", \\\"{x:522,y:619,t:1528143586672};\\\", \\\"{x:555,y:626,t:1528143586690};\\\", \\\"{x:587,y:627,t:1528143586704};\\\", \\\"{x:616,y:628,t:1528143586722};\\\", \\\"{x:638,y:628,t:1528143586739};\\\", \\\"{x:649,y:628,t:1528143586755};\\\", \\\"{x:655,y:628,t:1528143586772};\\\", \\\"{x:660,y:628,t:1528143586789};\\\", \\\"{x:664,y:628,t:1528143586805};\\\", \\\"{x:666,y:627,t:1528143586822};\\\", \\\"{x:668,y:627,t:1528143586878};\\\", \\\"{x:669,y:627,t:1528143586888};\\\", \\\"{x:670,y:627,t:1528143586942};\\\", \\\"{x:670,y:626,t:1528143586982};\\\", \\\"{x:673,y:624,t:1528143586998};\\\", \\\"{x:675,y:623,t:1528143587005};\\\", \\\"{x:692,y:614,t:1528143587022};\\\", \\\"{x:723,y:600,t:1528143587039};\\\", \\\"{x:758,y:584,t:1528143587057};\\\", \\\"{x:777,y:575,t:1528143587072};\\\", \\\"{x:786,y:570,t:1528143587089};\\\", \\\"{x:787,y:569,t:1528143587106};\\\", \\\"{x:791,y:569,t:1528143587286};\\\", \\\"{x:795,y:577,t:1528143587296};\\\", \\\"{x:796,y:581,t:1528143587305};\\\", \\\"{x:799,y:586,t:1528143587322};\\\", \\\"{x:801,y:591,t:1528143587339};\\\", \\\"{x:803,y:595,t:1528143587355};\\\", \\\"{x:804,y:596,t:1528143587372};\\\", \\\"{x:805,y:597,t:1528143587389};\\\", \\\"{x:806,y:597,t:1528143587422};\\\", \\\"{x:806,y:598,t:1528143587429};\\\", \\\"{x:808,y:598,t:1528143587462};\\\", \\\"{x:809,y:598,t:1528143587473};\\\", \\\"{x:810,y:599,t:1528143587489};\\\", \\\"{x:811,y:599,t:1528143587510};\\\", \\\"{x:813,y:599,t:1528143587550};\\\", \\\"{x:816,y:599,t:1528143587566};\\\", \\\"{x:818,y:599,t:1528143587582};\\\", \\\"{x:819,y:599,t:1528143587590};\\\", \\\"{x:822,y:599,t:1528143587605};\\\", \\\"{x:825,y:600,t:1528143587624};\\\", \\\"{x:826,y:600,t:1528143587646};\\\", \\\"{x:827,y:600,t:1528143587656};\\\", \\\"{x:828,y:600,t:1528143587673};\\\", \\\"{x:828,y:601,t:1528143587689};\\\", \\\"{x:829,y:601,t:1528143587726};\\\", \\\"{x:830,y:601,t:1528143587739};\\\", \\\"{x:831,y:601,t:1528143587756};\\\", \\\"{x:835,y:601,t:1528143588390};\\\", \\\"{x:843,y:604,t:1528143588406};\\\", \\\"{x:844,y:605,t:1528143588423};\\\", \\\"{x:846,y:605,t:1528143588440};\\\", \\\"{x:853,y:607,t:1528143588458};\\\", \\\"{x:877,y:613,t:1528143588473};\\\", \\\"{x:930,y:620,t:1528143588489};\\\", \\\"{x:1009,y:637,t:1528143588507};\\\", \\\"{x:1080,y:649,t:1528143588523};\\\", \\\"{x:1122,y:655,t:1528143588540};\\\", \\\"{x:1156,y:655,t:1528143588556};\\\", \\\"{x:1209,y:655,t:1528143588573};\\\", \\\"{x:1247,y:657,t:1528143588590};\\\", \\\"{x:1264,y:660,t:1528143588606};\\\", \\\"{x:1272,y:660,t:1528143588623};\\\", \\\"{x:1273,y:660,t:1528143588640};\\\", \\\"{x:1275,y:660,t:1528143588657};\\\", \\\"{x:1276,y:660,t:1528143588686};\\\", \\\"{x:1278,y:661,t:1528143588693};\\\", \\\"{x:1279,y:662,t:1528143588710};\\\", \\\"{x:1280,y:662,t:1528143588723};\\\", \\\"{x:1283,y:664,t:1528143588740};\\\", \\\"{x:1296,y:669,t:1528143588757};\\\", \\\"{x:1323,y:682,t:1528143588773};\\\", \\\"{x:1347,y:696,t:1528143588790};\\\", \\\"{x:1373,y:708,t:1528143588807};\\\", \\\"{x:1403,y:721,t:1528143588823};\\\", \\\"{x:1417,y:727,t:1528143588841};\\\", \\\"{x:1424,y:729,t:1528143588857};\\\", \\\"{x:1426,y:731,t:1528143588874};\\\", \\\"{x:1427,y:731,t:1528143588894};\\\", \\\"{x:1428,y:731,t:1528143588907};\\\", \\\"{x:1434,y:732,t:1528143588924};\\\", \\\"{x:1449,y:735,t:1528143588940};\\\", \\\"{x:1467,y:738,t:1528143588958};\\\", \\\"{x:1491,y:741,t:1528143588975};\\\", \\\"{x:1500,y:742,t:1528143588990};\\\", \\\"{x:1507,y:742,t:1528143589007};\\\", \\\"{x:1513,y:742,t:1528143589025};\\\", \\\"{x:1517,y:742,t:1528143589041};\\\", \\\"{x:1523,y:742,t:1528143589058};\\\", \\\"{x:1531,y:742,t:1528143589075};\\\", \\\"{x:1539,y:740,t:1528143589090};\\\", \\\"{x:1545,y:740,t:1528143589107};\\\", \\\"{x:1547,y:739,t:1528143589124};\\\", \\\"{x:1554,y:737,t:1528143590055};\\\", \\\"{x:1569,y:729,t:1528143590062};\\\", \\\"{x:1585,y:726,t:1528143590074};\\\", \\\"{x:1609,y:718,t:1528143590091};\\\", \\\"{x:1633,y:712,t:1528143590108};\\\", \\\"{x:1649,y:705,t:1528143590125};\\\", \\\"{x:1653,y:702,t:1528143590141};\\\", \\\"{x:1656,y:697,t:1528143590157};\\\", \\\"{x:1656,y:696,t:1528143590174};\\\", \\\"{x:1657,y:695,t:1528143590191};\\\", \\\"{x:1655,y:699,t:1528143590310};\\\", \\\"{x:1654,y:705,t:1528143590326};\\\", \\\"{x:1648,y:721,t:1528143590341};\\\", \\\"{x:1638,y:748,t:1528143590358};\\\", \\\"{x:1626,y:773,t:1528143590376};\\\", \\\"{x:1614,y:802,t:1528143590391};\\\", \\\"{x:1595,y:842,t:1528143590408};\\\", \\\"{x:1576,y:879,t:1528143590426};\\\", \\\"{x:1564,y:906,t:1528143590442};\\\", \\\"{x:1549,y:933,t:1528143590458};\\\", \\\"{x:1541,y:947,t:1528143590475};\\\", \\\"{x:1538,y:954,t:1528143590491};\\\", \\\"{x:1538,y:955,t:1528143590509};\\\", \\\"{x:1538,y:951,t:1528143590607};\\\", \\\"{x:1545,y:936,t:1528143590614};\\\", \\\"{x:1552,y:918,t:1528143590625};\\\", \\\"{x:1559,y:894,t:1528143590643};\\\", \\\"{x:1564,y:875,t:1528143590658};\\\", \\\"{x:1566,y:857,t:1528143590675};\\\", \\\"{x:1568,y:842,t:1528143590693};\\\", \\\"{x:1570,y:828,t:1528143590709};\\\", \\\"{x:1571,y:817,t:1528143590725};\\\", \\\"{x:1571,y:805,t:1528143590743};\\\", \\\"{x:1571,y:798,t:1528143590758};\\\", \\\"{x:1573,y:790,t:1528143590776};\\\", \\\"{x:1573,y:784,t:1528143590792};\\\", \\\"{x:1573,y:781,t:1528143590809};\\\", \\\"{x:1573,y:779,t:1528143590825};\\\", \\\"{x:1573,y:778,t:1528143590951};\\\", \\\"{x:1571,y:786,t:1528143591359};\\\", \\\"{x:1543,y:824,t:1528143591376};\\\", \\\"{x:1514,y:851,t:1528143591393};\\\", \\\"{x:1471,y:894,t:1528143591410};\\\", \\\"{x:1404,y:943,t:1528143591426};\\\", \\\"{x:1349,y:977,t:1528143591442};\\\", \\\"{x:1328,y:989,t:1528143591459};\\\", \\\"{x:1313,y:998,t:1528143591474};\\\", \\\"{x:1307,y:1002,t:1528143591492};\\\", \\\"{x:1304,y:1003,t:1528143591509};\\\", \\\"{x:1304,y:1004,t:1528143591526};\\\", \\\"{x:1304,y:1002,t:1528143591654};\\\", \\\"{x:1309,y:979,t:1528143591662};\\\", \\\"{x:1320,y:943,t:1528143591677};\\\", \\\"{x:1329,y:912,t:1528143591692};\\\", \\\"{x:1344,y:874,t:1528143591709};\\\", \\\"{x:1385,y:803,t:1528143591726};\\\", \\\"{x:1402,y:777,t:1528143591743};\\\", \\\"{x:1419,y:751,t:1528143591759};\\\", \\\"{x:1435,y:729,t:1528143591776};\\\", \\\"{x:1448,y:711,t:1528143591793};\\\", \\\"{x:1454,y:702,t:1528143591810};\\\", \\\"{x:1456,y:699,t:1528143591826};\\\", \\\"{x:1456,y:706,t:1528143591967};\\\", \\\"{x:1453,y:716,t:1528143591976};\\\", \\\"{x:1445,y:741,t:1528143591993};\\\", \\\"{x:1439,y:760,t:1528143592010};\\\", \\\"{x:1434,y:783,t:1528143592027};\\\", \\\"{x:1430,y:806,t:1528143592043};\\\", \\\"{x:1428,y:824,t:1528143592059};\\\", \\\"{x:1427,y:834,t:1528143592077};\\\", \\\"{x:1426,y:845,t:1528143592094};\\\", \\\"{x:1425,y:851,t:1528143592109};\\\", \\\"{x:1425,y:859,t:1528143592125};\\\", \\\"{x:1425,y:863,t:1528143592143};\\\", \\\"{x:1425,y:868,t:1528143592159};\\\", \\\"{x:1425,y:872,t:1528143592176};\\\", \\\"{x:1425,y:874,t:1528143592193};\\\", \\\"{x:1425,y:876,t:1528143592209};\\\", \\\"{x:1425,y:880,t:1528143592226};\\\", \\\"{x:1425,y:893,t:1528143592243};\\\", \\\"{x:1430,y:905,t:1528143592259};\\\", \\\"{x:1438,y:921,t:1528143592276};\\\", \\\"{x:1444,y:934,t:1528143592293};\\\", \\\"{x:1457,y:950,t:1528143592309};\\\", \\\"{x:1474,y:966,t:1528143592326};\\\", \\\"{x:1481,y:971,t:1528143592343};\\\", \\\"{x:1483,y:973,t:1528143592359};\\\", \\\"{x:1484,y:973,t:1528143592470};\\\", \\\"{x:1484,y:972,t:1528143592671};\\\", \\\"{x:1484,y:963,t:1528143592679};\\\", \\\"{x:1484,y:954,t:1528143592693};\\\", \\\"{x:1483,y:941,t:1528143592710};\\\", \\\"{x:1482,y:937,t:1528143592726};\\\", \\\"{x:1481,y:935,t:1528143592744};\\\", \\\"{x:1481,y:934,t:1528143592774};\\\", \\\"{x:1480,y:934,t:1528143592983};\\\", \\\"{x:1480,y:937,t:1528143593022};\\\", \\\"{x:1480,y:940,t:1528143593030};\\\", \\\"{x:1480,y:943,t:1528143593043};\\\", \\\"{x:1480,y:947,t:1528143593061};\\\", \\\"{x:1480,y:949,t:1528143593077};\\\", \\\"{x:1480,y:950,t:1528143593093};\\\", \\\"{x:1480,y:952,t:1528143593110};\\\", \\\"{x:1480,y:953,t:1528143593391};\\\", \\\"{x:1480,y:955,t:1528143593406};\\\", \\\"{x:1479,y:959,t:1528143593414};\\\", \\\"{x:1477,y:961,t:1528143593428};\\\", \\\"{x:1475,y:963,t:1528143593444};\\\", \\\"{x:1475,y:964,t:1528143593460};\\\", \\\"{x:1474,y:965,t:1528143593478};\\\", \\\"{x:1473,y:966,t:1528143593502};\\\", \\\"{x:1464,y:967,t:1528143593870};\\\", \\\"{x:1448,y:968,t:1528143593878};\\\", \\\"{x:1414,y:968,t:1528143593895};\\\", \\\"{x:1385,y:968,t:1528143593910};\\\", \\\"{x:1362,y:966,t:1528143593926};\\\", \\\"{x:1353,y:964,t:1528143593944};\\\", \\\"{x:1351,y:964,t:1528143593961};\\\", \\\"{x:1351,y:963,t:1528143594190};\\\", \\\"{x:1351,y:962,t:1528143594206};\\\", \\\"{x:1350,y:961,t:1528143594214};\\\", \\\"{x:1348,y:959,t:1528143594230};\\\", \\\"{x:1347,y:959,t:1528143594254};\\\", \\\"{x:1345,y:958,t:1528143594310};\\\", \\\"{x:1345,y:957,t:1528143594654};\\\", \\\"{x:1345,y:954,t:1528143594663};\\\", \\\"{x:1346,y:951,t:1528143594679};\\\", \\\"{x:1349,y:947,t:1528143594694};\\\", \\\"{x:1354,y:943,t:1528143594711};\\\", \\\"{x:1356,y:942,t:1528143594729};\\\", \\\"{x:1358,y:940,t:1528143594744};\\\", \\\"{x:1360,y:939,t:1528143594766};\\\", \\\"{x:1359,y:938,t:1528143595103};\\\", \\\"{x:1358,y:937,t:1528143595126};\\\", \\\"{x:1358,y:936,t:1528143595151};\\\", \\\"{x:1357,y:936,t:1528143595162};\\\", \\\"{x:1357,y:935,t:1528143595179};\\\", \\\"{x:1357,y:934,t:1528143595198};\\\", \\\"{x:1357,y:933,t:1528143595214};\\\", \\\"{x:1357,y:932,t:1528143595230};\\\", \\\"{x:1357,y:931,t:1528143595254};\\\", \\\"{x:1357,y:930,t:1528143595286};\\\", \\\"{x:1358,y:928,t:1528143595297};\\\", \\\"{x:1360,y:928,t:1528143595311};\\\", \\\"{x:1363,y:927,t:1528143595329};\\\", \\\"{x:1365,y:927,t:1528143595345};\\\", \\\"{x:1366,y:927,t:1528143595366};\\\", \\\"{x:1367,y:927,t:1528143595382};\\\", \\\"{x:1369,y:927,t:1528143595398};\\\", \\\"{x:1395,y:918,t:1528143598543};\\\", \\\"{x:1445,y:900,t:1528143598550};\\\", \\\"{x:1504,y:881,t:1528143598565};\\\", \\\"{x:1620,y:850,t:1528143598581};\\\", \\\"{x:1747,y:814,t:1528143598598};\\\", \\\"{x:1791,y:796,t:1528143598614};\\\", \\\"{x:1825,y:772,t:1528143598630};\\\", \\\"{x:1846,y:755,t:1528143598647};\\\", \\\"{x:1859,y:742,t:1528143598664};\\\", \\\"{x:1863,y:734,t:1528143598682};\\\", \\\"{x:1863,y:732,t:1528143598698};\\\", \\\"{x:1864,y:731,t:1528143598715};\\\", \\\"{x:1863,y:735,t:1528143598815};\\\", \\\"{x:1851,y:746,t:1528143598832};\\\", \\\"{x:1836,y:762,t:1528143598848};\\\", \\\"{x:1820,y:779,t:1528143598865};\\\", \\\"{x:1809,y:791,t:1528143598881};\\\", \\\"{x:1804,y:799,t:1528143598898};\\\", \\\"{x:1803,y:800,t:1528143598914};\\\", \\\"{x:1803,y:801,t:1528143598932};\\\", \\\"{x:1801,y:797,t:1528143599054};\\\", \\\"{x:1800,y:794,t:1528143599064};\\\", \\\"{x:1800,y:791,t:1528143599082};\\\", \\\"{x:1800,y:790,t:1528143599098};\\\", \\\"{x:1799,y:788,t:1528143599115};\\\", \\\"{x:1790,y:797,t:1528143599614};\\\", \\\"{x:1766,y:815,t:1528143599632};\\\", \\\"{x:1750,y:830,t:1528143599649};\\\", \\\"{x:1736,y:845,t:1528143599666};\\\", \\\"{x:1726,y:856,t:1528143599682};\\\", \\\"{x:1719,y:867,t:1528143599699};\\\", \\\"{x:1717,y:874,t:1528143599716};\\\", \\\"{x:1710,y:888,t:1528143599732};\\\", \\\"{x:1705,y:902,t:1528143599749};\\\", \\\"{x:1694,y:920,t:1528143599766};\\\", \\\"{x:1688,y:935,t:1528143599782};\\\", \\\"{x:1684,y:942,t:1528143599798};\\\", \\\"{x:1681,y:946,t:1528143599816};\\\", \\\"{x:1681,y:947,t:1528143599832};\\\", \\\"{x:1680,y:947,t:1528143600975};\\\", \\\"{x:1680,y:939,t:1528143600990};\\\", \\\"{x:1676,y:928,t:1528143601000};\\\", \\\"{x:1667,y:906,t:1528143601016};\\\", \\\"{x:1660,y:894,t:1528143601033};\\\", \\\"{x:1654,y:886,t:1528143601050};\\\", \\\"{x:1650,y:878,t:1528143601067};\\\", \\\"{x:1648,y:875,t:1528143601083};\\\", \\\"{x:1647,y:873,t:1528143601102};\\\", \\\"{x:1641,y:878,t:1528143601167};\\\", \\\"{x:1629,y:908,t:1528143601183};\\\", \\\"{x:1622,y:925,t:1528143601200};\\\", \\\"{x:1610,y:946,t:1528143601217};\\\", \\\"{x:1579,y:989,t:1528143601232};\\\", \\\"{x:1546,y:1026,t:1528143601250};\\\", \\\"{x:1519,y:1044,t:1528143601267};\\\", \\\"{x:1495,y:1055,t:1528143601283};\\\", \\\"{x:1451,y:1070,t:1528143601300};\\\", \\\"{x:1400,y:1079,t:1528143601317};\\\", \\\"{x:1333,y:1079,t:1528143601333};\\\", \\\"{x:1239,y:1075,t:1528143601350};\\\", \\\"{x:1208,y:1063,t:1528143601366};\\\", \\\"{x:1185,y:1053,t:1528143601383};\\\", \\\"{x:1164,y:1044,t:1528143601400};\\\", \\\"{x:1154,y:1039,t:1528143601417};\\\", \\\"{x:1151,y:1035,t:1528143601510};\\\", \\\"{x:1128,y:1020,t:1528143601518};\\\", \\\"{x:1082,y:998,t:1528143601533};\\\", \\\"{x:895,y:930,t:1528143601550};\\\", \\\"{x:768,y:898,t:1528143601567};\\\", \\\"{x:666,y:868,t:1528143601583};\\\", \\\"{x:599,y:849,t:1528143601600};\\\", \\\"{x:568,y:839,t:1528143601617};\\\", \\\"{x:557,y:833,t:1528143601634};\\\", \\\"{x:549,y:826,t:1528143601650};\\\", \\\"{x:539,y:809,t:1528143601666};\\\", \\\"{x:535,y:793,t:1528143601684};\\\", \\\"{x:529,y:775,t:1528143601700};\\\", \\\"{x:522,y:763,t:1528143601717};\\\", \\\"{x:519,y:758,t:1528143601734};\\\", \\\"{x:520,y:758,t:1528143601799};\\\", \\\"{x:521,y:758,t:1528143601806};\\\", \\\"{x:522,y:758,t:1528143601817};\\\", \\\"{x:524,y:758,t:1528143601833};\\\", \\\"{x:532,y:748,t:1528143601850};\\\", \\\"{x:534,y:736,t:1528143601866};\\\", \\\"{x:537,y:727,t:1528143601885};\\\", \\\"{x:538,y:723,t:1528143601899};\\\", \\\"{x:539,y:719,t:1528143601916};\\\", \\\"{x:540,y:718,t:1528143601934};\\\", \\\"{x:540,y:717,t:1528143601950};\\\", \\\"{x:540,y:715,t:1528143601973};\\\", \\\"{x:540,y:714,t:1528143601983};\\\", \\\"{x:540,y:712,t:1528143602000};\\\" ] }, { \\\"rt\\\": 83002, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 769705, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"VVH1B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 4.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\", \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -I -I -H -H -K -K -11 AM-12 PM-I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:541,y:705,t:1528143605950};\\\", \\\"{x:567,y:657,t:1528143605964};\\\", \\\"{x:598,y:605,t:1528143605971};\\\", \\\"{x:639,y:556,t:1528143605987};\\\", \\\"{x:669,y:519,t:1528143606020};\\\", \\\"{x:694,y:490,t:1528143606037};\\\", \\\"{x:699,y:481,t:1528143606053};\\\", \\\"{x:702,y:477,t:1528143606071};\\\", \\\"{x:703,y:474,t:1528143606088};\\\", \\\"{x:704,y:472,t:1528143606103};\\\", \\\"{x:704,y:471,t:1528143606120};\\\", \\\"{x:704,y:469,t:1528143606157};\\\", \\\"{x:711,y:469,t:1528143608150};\\\", \\\"{x:734,y:470,t:1528143608157};\\\", \\\"{x:747,y:474,t:1528143608172};\\\", \\\"{x:749,y:475,t:1528143608189};\\\", \\\"{x:765,y:470,t:1528143608205};\\\", \\\"{x:782,y:467,t:1528143608222};\\\", \\\"{x:801,y:461,t:1528143608238};\\\", \\\"{x:830,y:458,t:1528143608256};\\\", \\\"{x:881,y:456,t:1528143608272};\\\", \\\"{x:935,y:455,t:1528143608288};\\\", \\\"{x:977,y:455,t:1528143608305};\\\", \\\"{x:1015,y:452,t:1528143608321};\\\", \\\"{x:1037,y:452,t:1528143608339};\\\", \\\"{x:1047,y:452,t:1528143608356};\\\", \\\"{x:1050,y:452,t:1528143608373};\\\", \\\"{x:1052,y:452,t:1528143608389};\\\", \\\"{x:1053,y:452,t:1528143608430};\\\", \\\"{x:1054,y:452,t:1528143608439};\\\", \\\"{x:1058,y:452,t:1528143608456};\\\", \\\"{x:1071,y:462,t:1528143608473};\\\", \\\"{x:1087,y:473,t:1528143608489};\\\", \\\"{x:1109,y:488,t:1528143608506};\\\", \\\"{x:1130,y:502,t:1528143608523};\\\", \\\"{x:1149,y:518,t:1528143608539};\\\", \\\"{x:1163,y:529,t:1528143608556};\\\", \\\"{x:1178,y:541,t:1528143608573};\\\", \\\"{x:1187,y:548,t:1528143608589};\\\", \\\"{x:1198,y:557,t:1528143608606};\\\", \\\"{x:1203,y:560,t:1528143608623};\\\", \\\"{x:1208,y:563,t:1528143608639};\\\", \\\"{x:1214,y:566,t:1528143608657};\\\", \\\"{x:1222,y:568,t:1528143608673};\\\", \\\"{x:1233,y:574,t:1528143608689};\\\", \\\"{x:1247,y:579,t:1528143608705};\\\", \\\"{x:1262,y:582,t:1528143608723};\\\", \\\"{x:1281,y:588,t:1528143608739};\\\", \\\"{x:1297,y:595,t:1528143608756};\\\", \\\"{x:1313,y:603,t:1528143608774};\\\", \\\"{x:1332,y:612,t:1528143608789};\\\", \\\"{x:1352,y:622,t:1528143608806};\\\", \\\"{x:1364,y:632,t:1528143608823};\\\", \\\"{x:1375,y:643,t:1528143608839};\\\", \\\"{x:1385,y:653,t:1528143608857};\\\", \\\"{x:1393,y:662,t:1528143608874};\\\", \\\"{x:1401,y:674,t:1528143608890};\\\", \\\"{x:1406,y:679,t:1528143608907};\\\", \\\"{x:1410,y:686,t:1528143608923};\\\", \\\"{x:1410,y:690,t:1528143608941};\\\", \\\"{x:1411,y:695,t:1528143608956};\\\", \\\"{x:1412,y:700,t:1528143608973};\\\", \\\"{x:1412,y:707,t:1528143608990};\\\", \\\"{x:1412,y:711,t:1528143609006};\\\", \\\"{x:1412,y:716,t:1528143609024};\\\", \\\"{x:1412,y:723,t:1528143609040};\\\", \\\"{x:1409,y:730,t:1528143609057};\\\", \\\"{x:1406,y:737,t:1528143609073};\\\", \\\"{x:1405,y:740,t:1528143609090};\\\", \\\"{x:1404,y:742,t:1528143609105};\\\", \\\"{x:1403,y:744,t:1528143609122};\\\", \\\"{x:1402,y:744,t:1528143609140};\\\", \\\"{x:1402,y:745,t:1528143609156};\\\", \\\"{x:1402,y:746,t:1528143609172};\\\", \\\"{x:1400,y:747,t:1528143609366};\\\", \\\"{x:1393,y:756,t:1528143609373};\\\", \\\"{x:1368,y:786,t:1528143609390};\\\", \\\"{x:1338,y:821,t:1528143609408};\\\", \\\"{x:1326,y:842,t:1528143609424};\\\", \\\"{x:1324,y:848,t:1528143609440};\\\", \\\"{x:1324,y:849,t:1528143609457};\\\", \\\"{x:1323,y:851,t:1528143609473};\\\", \\\"{x:1320,y:854,t:1528143609490};\\\", \\\"{x:1317,y:863,t:1528143609507};\\\", \\\"{x:1314,y:871,t:1528143609523};\\\", \\\"{x:1313,y:879,t:1528143609541};\\\", \\\"{x:1312,y:883,t:1528143609557};\\\", \\\"{x:1310,y:888,t:1528143609573};\\\", \\\"{x:1310,y:892,t:1528143609590};\\\", \\\"{x:1310,y:894,t:1528143609614};\\\", \\\"{x:1318,y:881,t:1528143610774};\\\", \\\"{x:1359,y:867,t:1528143610791};\\\", \\\"{x:1380,y:853,t:1528143610808};\\\", \\\"{x:1398,y:844,t:1528143610824};\\\", \\\"{x:1405,y:843,t:1528143610841};\\\", \\\"{x:1399,y:841,t:1528143611134};\\\", \\\"{x:1395,y:840,t:1528143611142};\\\", \\\"{x:1382,y:835,t:1528143611158};\\\", \\\"{x:1366,y:830,t:1528143611175};\\\", \\\"{x:1351,y:824,t:1528143611192};\\\", \\\"{x:1339,y:816,t:1528143611209};\\\", \\\"{x:1332,y:813,t:1528143611225};\\\", \\\"{x:1322,y:805,t:1528143611241};\\\", \\\"{x:1316,y:801,t:1528143611258};\\\", \\\"{x:1311,y:796,t:1528143611274};\\\", \\\"{x:1306,y:787,t:1528143611292};\\\", \\\"{x:1299,y:778,t:1528143611308};\\\", \\\"{x:1294,y:769,t:1528143611326};\\\", \\\"{x:1290,y:761,t:1528143611341};\\\", \\\"{x:1288,y:751,t:1528143611358};\\\", \\\"{x:1288,y:740,t:1528143611375};\\\", \\\"{x:1288,y:730,t:1528143611391};\\\", \\\"{x:1295,y:709,t:1528143611408};\\\", \\\"{x:1317,y:667,t:1528143611425};\\\", \\\"{x:1356,y:619,t:1528143611441};\\\", \\\"{x:1394,y:570,t:1528143611458};\\\", \\\"{x:1426,y:527,t:1528143611475};\\\", \\\"{x:1435,y:504,t:1528143611491};\\\", \\\"{x:1442,y:490,t:1528143611508};\\\", \\\"{x:1444,y:481,t:1528143611525};\\\", \\\"{x:1444,y:476,t:1528143611541};\\\", \\\"{x:1444,y:473,t:1528143611558};\\\", \\\"{x:1442,y:472,t:1528143611575};\\\", \\\"{x:1439,y:470,t:1528143611591};\\\", \\\"{x:1438,y:470,t:1528143611609};\\\", \\\"{x:1436,y:470,t:1528143611625};\\\", \\\"{x:1432,y:469,t:1528143611641};\\\", \\\"{x:1431,y:469,t:1528143611658};\\\", \\\"{x:1430,y:469,t:1528143611678};\\\", \\\"{x:1428,y:469,t:1528143611692};\\\", \\\"{x:1420,y:469,t:1528143611708};\\\", \\\"{x:1406,y:473,t:1528143611725};\\\", \\\"{x:1386,y:483,t:1528143611742};\\\", \\\"{x:1377,y:486,t:1528143611758};\\\", \\\"{x:1363,y:493,t:1528143611775};\\\", \\\"{x:1346,y:503,t:1528143611793};\\\", \\\"{x:1326,y:514,t:1528143611808};\\\", \\\"{x:1311,y:523,t:1528143611825};\\\", \\\"{x:1301,y:529,t:1528143611842};\\\", \\\"{x:1299,y:530,t:1528143611858};\\\", \\\"{x:1299,y:531,t:1528143611918};\\\", \\\"{x:1298,y:531,t:1528143611925};\\\", \\\"{x:1297,y:531,t:1528143612014};\\\", \\\"{x:1297,y:530,t:1528143612029};\\\", \\\"{x:1299,y:527,t:1528143612050};\\\", \\\"{x:1301,y:525,t:1528143612076};\\\", \\\"{x:1306,y:519,t:1528143612092};\\\", \\\"{x:1314,y:513,t:1528143612109};\\\", \\\"{x:1316,y:512,t:1528143612125};\\\", \\\"{x:1319,y:509,t:1528143612142};\\\", \\\"{x:1316,y:506,t:1528143612707};\\\", \\\"{x:1315,y:505,t:1528143612709};\\\", \\\"{x:1311,y:504,t:1528143612724};\\\", \\\"{x:1309,y:503,t:1528143612742};\\\", \\\"{x:1306,y:502,t:1528143612759};\\\", \\\"{x:1306,y:501,t:1528143612775};\\\", \\\"{x:1305,y:501,t:1528143613238};\\\", \\\"{x:1306,y:501,t:1528143613325};\\\", \\\"{x:1307,y:501,t:1528143613702};\\\", \\\"{x:1310,y:503,t:1528143613871};\\\", \\\"{x:1315,y:505,t:1528143613878};\\\", \\\"{x:1320,y:506,t:1528143613893};\\\", \\\"{x:1326,y:510,t:1528143613910};\\\", \\\"{x:1331,y:511,t:1528143613926};\\\", \\\"{x:1335,y:513,t:1528143613943};\\\", \\\"{x:1336,y:514,t:1528143613960};\\\", \\\"{x:1337,y:514,t:1528143613976};\\\", \\\"{x:1335,y:514,t:1528143614214};\\\", \\\"{x:1334,y:514,t:1528143614230};\\\", \\\"{x:1332,y:514,t:1528143614243};\\\", \\\"{x:1329,y:514,t:1528143614260};\\\", \\\"{x:1323,y:510,t:1528143614277};\\\", \\\"{x:1323,y:506,t:1528143614293};\\\", \\\"{x:1323,y:505,t:1528143614317};\\\", \\\"{x:1323,y:504,t:1528143614328};\\\", \\\"{x:1323,y:502,t:1528143614343};\\\", \\\"{x:1325,y:498,t:1528143614360};\\\", \\\"{x:1329,y:491,t:1528143614378};\\\", \\\"{x:1333,y:483,t:1528143614393};\\\", \\\"{x:1336,y:477,t:1528143614411};\\\", \\\"{x:1337,y:474,t:1528143614427};\\\", \\\"{x:1338,y:473,t:1528143614444};\\\", \\\"{x:1341,y:469,t:1528143614460};\\\", \\\"{x:1346,y:462,t:1528143614477};\\\", \\\"{x:1353,y:453,t:1528143614494};\\\", \\\"{x:1357,y:449,t:1528143614510};\\\", \\\"{x:1357,y:447,t:1528143614527};\\\", \\\"{x:1359,y:445,t:1528143614543};\\\", \\\"{x:1360,y:443,t:1528143614560};\\\", \\\"{x:1361,y:441,t:1528143614577};\\\", \\\"{x:1362,y:440,t:1528143614595};\\\", \\\"{x:1363,y:439,t:1528143614610};\\\", \\\"{x:1364,y:438,t:1528143614627};\\\", \\\"{x:1364,y:437,t:1528143614702};\\\", \\\"{x:1364,y:436,t:1528143614711};\\\", \\\"{x:1360,y:434,t:1528143614728};\\\", \\\"{x:1358,y:433,t:1528143614744};\\\", \\\"{x:1358,y:432,t:1528143614760};\\\", \\\"{x:1357,y:432,t:1528143614777};\\\", \\\"{x:1356,y:432,t:1528143614794};\\\", \\\"{x:1355,y:431,t:1528143614811};\\\", \\\"{x:1354,y:431,t:1528143615638};\\\", \\\"{x:1349,y:429,t:1528143615646};\\\", \\\"{x:1348,y:428,t:1528143615661};\\\", \\\"{x:1347,y:428,t:1528143615694};\\\", \\\"{x:1347,y:427,t:1528143615894};\\\", \\\"{x:1357,y:413,t:1528143615911};\\\", \\\"{x:1365,y:405,t:1528143615929};\\\", \\\"{x:1369,y:399,t:1528143615944};\\\", \\\"{x:1373,y:395,t:1528143615961};\\\", \\\"{x:1377,y:392,t:1528143615979};\\\", \\\"{x:1378,y:391,t:1528143615995};\\\", \\\"{x:1379,y:391,t:1528143616011};\\\", \\\"{x:1379,y:390,t:1528143616028};\\\", \\\"{x:1380,y:389,t:1528143616045};\\\", \\\"{x:1381,y:387,t:1528143616062};\\\", \\\"{x:1382,y:386,t:1528143616086};\\\", \\\"{x:1382,y:385,t:1528143616095};\\\", \\\"{x:1382,y:384,t:1528143616133};\\\", \\\"{x:1383,y:384,t:1528143616144};\\\", \\\"{x:1383,y:383,t:1528143616161};\\\", \\\"{x:1383,y:380,t:1528143616178};\\\", \\\"{x:1386,y:377,t:1528143616195};\\\", \\\"{x:1386,y:374,t:1528143616211};\\\", \\\"{x:1387,y:371,t:1528143616228};\\\", \\\"{x:1387,y:370,t:1528143616245};\\\", \\\"{x:1387,y:369,t:1528143616318};\\\", \\\"{x:1387,y:366,t:1528143616328};\\\", \\\"{x:1387,y:363,t:1528143616345};\\\", \\\"{x:1387,y:361,t:1528143616361};\\\", \\\"{x:1387,y:360,t:1528143616378};\\\", \\\"{x:1389,y:358,t:1528143616718};\\\", \\\"{x:1392,y:351,t:1528143616729};\\\", \\\"{x:1402,y:331,t:1528143616745};\\\", \\\"{x:1411,y:312,t:1528143616762};\\\", \\\"{x:1419,y:296,t:1528143616778};\\\", \\\"{x:1424,y:284,t:1528143616795};\\\", \\\"{x:1426,y:278,t:1528143616813};\\\", \\\"{x:1427,y:276,t:1528143616829};\\\", \\\"{x:1427,y:274,t:1528143616846};\\\", \\\"{x:1428,y:272,t:1528143616894};\\\", \\\"{x:1429,y:271,t:1528143616902};\\\", \\\"{x:1429,y:270,t:1528143616918};\\\", \\\"{x:1429,y:271,t:1528143617030};\\\", \\\"{x:1429,y:278,t:1528143617046};\\\", \\\"{x:1429,y:279,t:1528143617070};\\\", \\\"{x:1428,y:280,t:1528143617086};\\\", \\\"{x:1428,y:281,t:1528143617110};\\\", \\\"{x:1426,y:284,t:1528143617126};\\\", \\\"{x:1426,y:285,t:1528143617133};\\\", \\\"{x:1425,y:286,t:1528143617145};\\\", \\\"{x:1423,y:289,t:1528143617163};\\\", \\\"{x:1422,y:294,t:1528143617180};\\\", \\\"{x:1420,y:297,t:1528143617196};\\\", \\\"{x:1420,y:299,t:1528143617212};\\\", \\\"{x:1419,y:300,t:1528143617398};\\\", \\\"{x:1419,y:298,t:1528143617646};\\\", \\\"{x:1425,y:290,t:1528143617662};\\\", \\\"{x:1427,y:285,t:1528143617679};\\\", \\\"{x:1429,y:284,t:1528143617697};\\\", \\\"{x:1429,y:282,t:1528143617742};\\\", \\\"{x:1430,y:282,t:1528143617749};\\\", \\\"{x:1430,y:279,t:1528143617762};\\\", \\\"{x:1433,y:277,t:1528143617779};\\\", \\\"{x:1433,y:275,t:1528143617795};\\\", \\\"{x:1433,y:273,t:1528143617812};\\\", \\\"{x:1435,y:269,t:1528143617829};\\\", \\\"{x:1436,y:268,t:1528143617846};\\\", \\\"{x:1440,y:263,t:1528143617863};\\\", \\\"{x:1443,y:253,t:1528143617879};\\\", \\\"{x:1448,y:243,t:1528143617896};\\\", \\\"{x:1453,y:233,t:1528143617913};\\\", \\\"{x:1454,y:228,t:1528143617929};\\\", \\\"{x:1456,y:224,t:1528143617946};\\\", \\\"{x:1458,y:218,t:1528143618758};\\\", \\\"{x:1470,y:187,t:1528143618765};\\\", \\\"{x:1473,y:176,t:1528143618781};\\\", \\\"{x:1475,y:168,t:1528143618797};\\\", \\\"{x:1478,y:164,t:1528143618816};\\\", \\\"{x:1475,y:167,t:1528143619111};\\\", \\\"{x:1470,y:184,t:1528143619117};\\\", \\\"{x:1465,y:198,t:1528143619131};\\\", \\\"{x:1454,y:229,t:1528143619148};\\\", \\\"{x:1440,y:258,t:1528143619164};\\\", \\\"{x:1421,y:298,t:1528143619181};\\\", \\\"{x:1408,y:328,t:1528143619197};\\\", \\\"{x:1403,y:342,t:1528143619213};\\\", \\\"{x:1398,y:357,t:1528143619230};\\\", \\\"{x:1393,y:368,t:1528143619247};\\\", \\\"{x:1390,y:374,t:1528143619263};\\\", \\\"{x:1389,y:375,t:1528143619281};\\\", \\\"{x:1387,y:372,t:1528143619414};\\\", \\\"{x:1385,y:356,t:1528143619431};\\\", \\\"{x:1384,y:356,t:1528143619447};\\\", \\\"{x:1384,y:355,t:1528143619465};\\\", \\\"{x:1382,y:361,t:1528143619510};\\\", \\\"{x:1376,y:377,t:1528143619518};\\\", \\\"{x:1369,y:400,t:1528143619531};\\\", \\\"{x:1347,y:459,t:1528143619548};\\\", \\\"{x:1321,y:519,t:1528143619565};\\\", \\\"{x:1295,y:570,t:1528143619581};\\\", \\\"{x:1280,y:604,t:1528143619598};\\\", \\\"{x:1277,y:607,t:1528143619614};\\\", \\\"{x:1276,y:609,t:1528143619630};\\\", \\\"{x:1276,y:603,t:1528143619742};\\\", \\\"{x:1276,y:594,t:1528143619750};\\\", \\\"{x:1276,y:588,t:1528143619764};\\\", \\\"{x:1276,y:576,t:1528143619780};\\\", \\\"{x:1285,y:547,t:1528143619798};\\\", \\\"{x:1290,y:537,t:1528143619814};\\\", \\\"{x:1293,y:531,t:1528143619831};\\\", \\\"{x:1294,y:529,t:1528143619848};\\\", \\\"{x:1296,y:525,t:1528143619864};\\\", \\\"{x:1299,y:521,t:1528143619880};\\\", \\\"{x:1303,y:515,t:1528143619896};\\\", \\\"{x:1310,y:504,t:1528143619914};\\\", \\\"{x:1317,y:495,t:1528143619931};\\\", \\\"{x:1321,y:488,t:1528143619947};\\\", \\\"{x:1324,y:483,t:1528143619964};\\\", \\\"{x:1326,y:480,t:1528143619981};\\\", \\\"{x:1326,y:479,t:1528143620004};\\\", \\\"{x:1327,y:479,t:1528143620036};\\\", \\\"{x:1326,y:479,t:1528143620229};\\\", \\\"{x:1325,y:480,t:1528143620237};\\\", \\\"{x:1321,y:485,t:1528143620247};\\\", \\\"{x:1316,y:491,t:1528143620264};\\\", \\\"{x:1314,y:495,t:1528143620281};\\\", \\\"{x:1313,y:495,t:1528143620298};\\\", \\\"{x:1313,y:494,t:1528143620766};\\\", \\\"{x:1313,y:488,t:1528143620783};\\\", \\\"{x:1315,y:482,t:1528143620799};\\\", \\\"{x:1317,y:477,t:1528143620816};\\\", \\\"{x:1318,y:474,t:1528143620832};\\\", \\\"{x:1318,y:472,t:1528143620848};\\\", \\\"{x:1318,y:471,t:1528143620865};\\\", \\\"{x:1319,y:469,t:1528143620919};\\\", \\\"{x:1320,y:467,t:1528143620934};\\\", \\\"{x:1321,y:466,t:1528143620948};\\\", \\\"{x:1322,y:459,t:1528143620965};\\\", \\\"{x:1325,y:454,t:1528143620981};\\\", \\\"{x:1326,y:452,t:1528143620999};\\\", \\\"{x:1326,y:451,t:1528143621016};\\\", \\\"{x:1328,y:449,t:1528143621086};\\\", \\\"{x:1329,y:447,t:1528143621099};\\\", \\\"{x:1329,y:446,t:1528143621116};\\\", \\\"{x:1331,y:444,t:1528143621131};\\\", \\\"{x:1331,y:443,t:1528143621149};\\\", \\\"{x:1332,y:442,t:1528143621166};\\\", \\\"{x:1332,y:439,t:1528143621181};\\\", \\\"{x:1334,y:438,t:1528143621198};\\\", \\\"{x:1335,y:437,t:1528143621215};\\\", \\\"{x:1335,y:436,t:1528143621231};\\\", \\\"{x:1336,y:435,t:1528143621248};\\\", \\\"{x:1337,y:435,t:1528143621277};\\\", \\\"{x:1338,y:435,t:1528143621285};\\\", \\\"{x:1340,y:435,t:1528143621298};\\\", \\\"{x:1344,y:435,t:1528143621315};\\\", \\\"{x:1346,y:435,t:1528143621332};\\\", \\\"{x:1349,y:435,t:1528143621348};\\\", \\\"{x:1350,y:435,t:1528143621365};\\\", \\\"{x:1351,y:435,t:1528143621438};\\\", \\\"{x:1352,y:435,t:1528143622222};\\\", \\\"{x:1352,y:431,t:1528143622233};\\\", \\\"{x:1353,y:423,t:1528143622250};\\\", \\\"{x:1355,y:417,t:1528143622267};\\\", \\\"{x:1355,y:413,t:1528143622282};\\\", \\\"{x:1356,y:410,t:1528143622300};\\\", \\\"{x:1357,y:405,t:1528143622317};\\\", \\\"{x:1360,y:402,t:1528143622333};\\\", \\\"{x:1363,y:395,t:1528143622350};\\\", \\\"{x:1366,y:391,t:1528143622367};\\\", \\\"{x:1366,y:390,t:1528143622382};\\\", \\\"{x:1367,y:387,t:1528143622400};\\\", \\\"{x:1368,y:385,t:1528143622416};\\\", \\\"{x:1369,y:384,t:1528143622432};\\\", \\\"{x:1370,y:381,t:1528143622450};\\\", \\\"{x:1370,y:380,t:1528143622466};\\\", \\\"{x:1371,y:378,t:1528143622482};\\\", \\\"{x:1373,y:374,t:1528143622499};\\\", \\\"{x:1374,y:372,t:1528143622517};\\\", \\\"{x:1376,y:368,t:1528143622533};\\\", \\\"{x:1377,y:361,t:1528143622549};\\\", \\\"{x:1377,y:358,t:1528143622567};\\\", \\\"{x:1378,y:356,t:1528143622582};\\\", \\\"{x:1378,y:355,t:1528143622599};\\\", \\\"{x:1378,y:353,t:1528143622617};\\\", \\\"{x:1379,y:353,t:1528143622634};\\\", \\\"{x:1380,y:352,t:1528143622669};\\\", \\\"{x:1381,y:352,t:1528143622862};\\\", \\\"{x:1382,y:352,t:1528143622894};\\\", \\\"{x:1383,y:352,t:1528143622918};\\\", \\\"{x:1384,y:353,t:1528143629382};\\\", \\\"{x:1385,y:357,t:1528143629390};\\\", \\\"{x:1385,y:359,t:1528143629405};\\\", \\\"{x:1386,y:365,t:1528143629422};\\\", \\\"{x:1387,y:367,t:1528143629438};\\\", \\\"{x:1387,y:368,t:1528143629461};\\\", \\\"{x:1387,y:369,t:1528143629550};\\\", \\\"{x:1387,y:371,t:1528143629558};\\\", \\\"{x:1387,y:373,t:1528143629572};\\\", \\\"{x:1387,y:374,t:1528143629589};\\\", \\\"{x:1389,y:376,t:1528143629605};\\\", \\\"{x:1390,y:381,t:1528143629622};\\\", \\\"{x:1390,y:383,t:1528143629638};\\\", \\\"{x:1391,y:385,t:1528143629656};\\\", \\\"{x:1392,y:387,t:1528143629672};\\\", \\\"{x:1392,y:388,t:1528143629688};\\\", \\\"{x:1393,y:389,t:1528143629765};\\\", \\\"{x:1393,y:390,t:1528143629854};\\\", \\\"{x:1394,y:399,t:1528143629872};\\\", \\\"{x:1396,y:405,t:1528143629890};\\\", \\\"{x:1397,y:409,t:1528143629905};\\\", \\\"{x:1398,y:412,t:1528143629922};\\\", \\\"{x:1398,y:413,t:1528143629940};\\\", \\\"{x:1399,y:414,t:1528143629965};\\\", \\\"{x:1399,y:415,t:1528143630030};\\\", \\\"{x:1399,y:416,t:1528143630070};\\\", \\\"{x:1400,y:418,t:1528143630078};\\\", \\\"{x:1401,y:420,t:1528143630089};\\\", \\\"{x:1404,y:426,t:1528143630105};\\\", \\\"{x:1406,y:431,t:1528143630122};\\\", \\\"{x:1409,y:437,t:1528143630139};\\\", \\\"{x:1411,y:442,t:1528143630155};\\\", \\\"{x:1413,y:446,t:1528143630172};\\\", \\\"{x:1415,y:449,t:1528143630189};\\\", \\\"{x:1417,y:452,t:1528143630205};\\\", \\\"{x:1419,y:454,t:1528143630222};\\\", \\\"{x:1420,y:455,t:1528143630238};\\\", \\\"{x:1420,y:457,t:1528143630257};\\\", \\\"{x:1422,y:458,t:1528143630272};\\\", \\\"{x:1424,y:460,t:1528143630288};\\\", \\\"{x:1427,y:464,t:1528143630305};\\\", \\\"{x:1430,y:468,t:1528143630322};\\\", \\\"{x:1433,y:472,t:1528143630338};\\\", \\\"{x:1438,y:478,t:1528143630355};\\\", \\\"{x:1442,y:482,t:1528143630371};\\\", \\\"{x:1445,y:487,t:1528143630389};\\\", \\\"{x:1446,y:488,t:1528143630413};\\\", \\\"{x:1447,y:489,t:1528143630573};\\\", \\\"{x:1448,y:490,t:1528143630605};\\\", \\\"{x:1448,y:491,t:1528143630622};\\\", \\\"{x:1449,y:492,t:1528143630639};\\\", \\\"{x:1449,y:493,t:1528143630658};\\\", \\\"{x:1451,y:495,t:1528143630673};\\\", \\\"{x:1451,y:496,t:1528143630690};\\\", \\\"{x:1452,y:497,t:1528143630710};\\\", \\\"{x:1443,y:506,t:1528143642674};\\\", \\\"{x:1427,y:536,t:1528143642684};\\\", \\\"{x:1414,y:550,t:1528143642702};\\\", \\\"{x:1403,y:558,t:1528143642718};\\\", \\\"{x:1398,y:563,t:1528143642735};\\\", \\\"{x:1396,y:566,t:1528143642752};\\\", \\\"{x:1388,y:570,t:1528143643057};\\\", \\\"{x:1366,y:575,t:1528143643068};\\\", \\\"{x:1261,y:587,t:1528143643084};\\\", \\\"{x:1114,y:589,t:1528143643101};\\\", \\\"{x:964,y:598,t:1528143643119};\\\", \\\"{x:847,y:598,t:1528143643136};\\\", \\\"{x:738,y:600,t:1528143643151};\\\", \\\"{x:619,y:600,t:1528143643168};\\\", \\\"{x:575,y:612,t:1528143643185};\\\", \\\"{x:554,y:617,t:1528143643200};\\\", \\\"{x:543,y:621,t:1528143643219};\\\", \\\"{x:540,y:621,t:1528143643236};\\\", \\\"{x:539,y:622,t:1528143643252};\\\", \\\"{x:537,y:622,t:1528143643271};\\\", \\\"{x:536,y:622,t:1528143643286};\\\", \\\"{x:533,y:621,t:1528143643303};\\\", \\\"{x:532,y:621,t:1528143643319};\\\", \\\"{x:531,y:621,t:1528143643335};\\\", \\\"{x:533,y:621,t:1528143643367};\\\", \\\"{x:536,y:621,t:1528143643375};\\\", \\\"{x:540,y:622,t:1528143643386};\\\", \\\"{x:550,y:622,t:1528143643403};\\\", \\\"{x:561,y:618,t:1528143643419};\\\", \\\"{x:568,y:615,t:1528143643436};\\\", \\\"{x:578,y:610,t:1528143643453};\\\", \\\"{x:583,y:606,t:1528143643470};\\\", \\\"{x:588,y:602,t:1528143643486};\\\", \\\"{x:590,y:602,t:1528143643503};\\\", \\\"{x:591,y:600,t:1528143643520};\\\", \\\"{x:592,y:599,t:1528143643543};\\\", \\\"{x:593,y:598,t:1528143643553};\\\", \\\"{x:594,y:594,t:1528143643570};\\\", \\\"{x:597,y:589,t:1528143643586};\\\", \\\"{x:597,y:588,t:1528143643608};\\\", \\\"{x:598,y:587,t:1528143643623};\\\", \\\"{x:598,y:586,t:1528143643688};\\\", \\\"{x:600,y:585,t:1528143643768};\\\", \\\"{x:600,y:583,t:1528143643776};\\\", \\\"{x:601,y:583,t:1528143643787};\\\", \\\"{x:601,y:581,t:1528143643803};\\\", \\\"{x:603,y:579,t:1528143643820};\\\", \\\"{x:604,y:578,t:1528143643837};\\\", \\\"{x:606,y:576,t:1528143643853};\\\", \\\"{x:608,y:574,t:1528143644393};\\\", \\\"{x:634,y:567,t:1528143644405};\\\", \\\"{x:728,y:555,t:1528143644422};\\\", \\\"{x:841,y:545,t:1528143644437};\\\", \\\"{x:949,y:545,t:1528143644454};\\\", \\\"{x:1030,y:543,t:1528143644470};\\\", \\\"{x:1084,y:545,t:1528143644487};\\\", \\\"{x:1111,y:547,t:1528143644504};\\\", \\\"{x:1114,y:548,t:1528143644520};\\\", \\\"{x:1119,y:548,t:1528143644576};\\\", \\\"{x:1129,y:548,t:1528143644587};\\\", \\\"{x:1155,y:548,t:1528143644604};\\\", \\\"{x:1198,y:548,t:1528143644621};\\\", \\\"{x:1243,y:548,t:1528143644639};\\\", \\\"{x:1282,y:548,t:1528143644654};\\\", \\\"{x:1309,y:553,t:1528143644671};\\\", \\\"{x:1321,y:555,t:1528143644687};\\\", \\\"{x:1325,y:555,t:1528143644872};\\\", \\\"{x:1337,y:552,t:1528143644888};\\\", \\\"{x:1349,y:550,t:1528143644905};\\\", \\\"{x:1357,y:549,t:1528143644922};\\\", \\\"{x:1359,y:549,t:1528143644939};\\\", \\\"{x:1360,y:549,t:1528143644956};\\\", \\\"{x:1361,y:549,t:1528143645016};\\\", \\\"{x:1363,y:549,t:1528143645024};\\\", \\\"{x:1366,y:549,t:1528143645040};\\\", \\\"{x:1375,y:552,t:1528143645056};\\\", \\\"{x:1383,y:554,t:1528143645072};\\\", \\\"{x:1385,y:554,t:1528143645145};\\\", \\\"{x:1388,y:555,t:1528143645577};\\\", \\\"{x:1389,y:555,t:1528143645591};\\\", \\\"{x:1389,y:556,t:1528143645608};\\\", \\\"{x:1392,y:556,t:1528143645624};\\\", \\\"{x:1396,y:556,t:1528143645640};\\\", \\\"{x:1400,y:556,t:1528143645658};\\\", \\\"{x:1402,y:556,t:1528143645675};\\\", \\\"{x:1403,y:556,t:1528143645691};\\\", \\\"{x:1405,y:556,t:1528143645720};\\\", \\\"{x:1406,y:556,t:1528143645745};\\\", \\\"{x:1408,y:556,t:1528143645808};\\\", \\\"{x:1408,y:557,t:1528143645825};\\\", \\\"{x:1409,y:557,t:1528143645842};\\\", \\\"{x:1410,y:558,t:1528143645858};\\\", \\\"{x:1413,y:559,t:1528143646609};\\\", \\\"{x:1427,y:569,t:1528143646628};\\\", \\\"{x:1452,y:578,t:1528143646644};\\\", \\\"{x:1471,y:583,t:1528143646661};\\\", \\\"{x:1480,y:586,t:1528143646677};\\\", \\\"{x:1485,y:587,t:1528143646694};\\\", \\\"{x:1486,y:588,t:1528143646710};\\\", \\\"{x:1486,y:589,t:1528143646881};\\\", \\\"{x:1487,y:592,t:1528143646894};\\\", \\\"{x:1487,y:595,t:1528143646911};\\\", \\\"{x:1488,y:597,t:1528143646927};\\\", \\\"{x:1490,y:600,t:1528143646945};\\\", \\\"{x:1493,y:601,t:1528143646960};\\\", \\\"{x:1494,y:602,t:1528143646977};\\\", \\\"{x:1497,y:603,t:1528143646995};\\\", \\\"{x:1498,y:603,t:1528143647011};\\\", \\\"{x:1500,y:603,t:1528143647027};\\\", \\\"{x:1502,y:604,t:1528143647045};\\\", \\\"{x:1504,y:607,t:1528143647062};\\\", \\\"{x:1509,y:610,t:1528143647078};\\\", \\\"{x:1512,y:612,t:1528143647095};\\\", \\\"{x:1515,y:614,t:1528143647112};\\\", \\\"{x:1519,y:617,t:1528143647128};\\\", \\\"{x:1521,y:619,t:1528143647145};\\\", \\\"{x:1522,y:620,t:1528143647161};\\\", \\\"{x:1522,y:622,t:1528143647178};\\\", \\\"{x:1525,y:625,t:1528143647194};\\\", \\\"{x:1526,y:628,t:1528143647212};\\\", \\\"{x:1526,y:629,t:1528143647229};\\\", \\\"{x:1527,y:629,t:1528143647245};\\\", \\\"{x:1527,y:630,t:1528143647321};\\\", \\\"{x:1527,y:632,t:1528143647352};\\\", \\\"{x:1526,y:632,t:1528143647368};\\\", \\\"{x:1525,y:632,t:1528143647392};\\\", \\\"{x:1524,y:633,t:1528143647409};\\\", \\\"{x:1523,y:633,t:1528143647449};\\\", \\\"{x:1522,y:633,t:1528143647945};\\\", \\\"{x:1521,y:633,t:1528143654840};\\\", \\\"{x:1515,y:634,t:1528143654849};\\\", \\\"{x:1506,y:638,t:1528143654866};\\\", \\\"{x:1503,y:639,t:1528143654883};\\\", \\\"{x:1502,y:640,t:1528143654899};\\\", \\\"{x:1501,y:640,t:1528143654960};\\\", \\\"{x:1499,y:640,t:1528143655040};\\\", \\\"{x:1495,y:641,t:1528143655050};\\\", \\\"{x:1489,y:645,t:1528143655065};\\\", \\\"{x:1477,y:653,t:1528143655083};\\\", \\\"{x:1458,y:665,t:1528143655100};\\\", \\\"{x:1443,y:672,t:1528143655117};\\\", \\\"{x:1424,y:682,t:1528143655133};\\\", \\\"{x:1392,y:695,t:1528143655150};\\\", \\\"{x:1359,y:709,t:1528143655167};\\\", \\\"{x:1336,y:720,t:1528143655183};\\\", \\\"{x:1298,y:736,t:1528143655200};\\\", \\\"{x:1268,y:744,t:1528143655217};\\\", \\\"{x:1230,y:757,t:1528143655233};\\\", \\\"{x:1192,y:772,t:1528143655250};\\\", \\\"{x:1168,y:782,t:1528143655267};\\\", \\\"{x:1148,y:790,t:1528143655284};\\\", \\\"{x:1133,y:798,t:1528143655300};\\\", \\\"{x:1112,y:807,t:1528143655317};\\\", \\\"{x:1098,y:813,t:1528143655334};\\\", \\\"{x:1095,y:815,t:1528143655351};\\\", \\\"{x:1093,y:817,t:1528143655367};\\\", \\\"{x:1093,y:813,t:1528143655488};\\\", \\\"{x:1102,y:799,t:1528143655501};\\\", \\\"{x:1113,y:780,t:1528143655518};\\\", \\\"{x:1121,y:769,t:1528143655533};\\\", \\\"{x:1126,y:762,t:1528143655551};\\\", \\\"{x:1127,y:760,t:1528143655568};\\\", \\\"{x:1128,y:758,t:1528143655592};\\\", \\\"{x:1129,y:758,t:1528143655712};\\\", \\\"{x:1129,y:757,t:1528143655720};\\\", \\\"{x:1129,y:752,t:1528143655735};\\\", \\\"{x:1129,y:744,t:1528143655752};\\\", \\\"{x:1128,y:739,t:1528143655768};\\\", \\\"{x:1127,y:731,t:1528143655785};\\\", \\\"{x:1127,y:721,t:1528143655802};\\\", \\\"{x:1127,y:707,t:1528143655818};\\\", \\\"{x:1127,y:683,t:1528143655835};\\\", \\\"{x:1127,y:657,t:1528143655852};\\\", \\\"{x:1132,y:632,t:1528143655869};\\\", \\\"{x:1141,y:607,t:1528143655885};\\\", \\\"{x:1150,y:590,t:1528143655902};\\\", \\\"{x:1157,y:572,t:1528143655919};\\\", \\\"{x:1163,y:561,t:1528143655935};\\\", \\\"{x:1176,y:545,t:1528143655952};\\\", \\\"{x:1190,y:531,t:1528143655969};\\\", \\\"{x:1203,y:520,t:1528143655985};\\\", \\\"{x:1215,y:512,t:1528143656002};\\\", \\\"{x:1225,y:504,t:1528143656019};\\\", \\\"{x:1230,y:500,t:1528143656036};\\\", \\\"{x:1233,y:498,t:1528143656052};\\\", \\\"{x:1234,y:496,t:1528143656070};\\\", \\\"{x:1235,y:495,t:1528143656086};\\\", \\\"{x:1236,y:495,t:1528143656103};\\\", \\\"{x:1236,y:494,t:1528143656119};\\\", \\\"{x:1236,y:497,t:1528143656208};\\\", \\\"{x:1236,y:502,t:1528143656220};\\\", \\\"{x:1237,y:506,t:1528143656236};\\\", \\\"{x:1238,y:511,t:1528143656253};\\\", \\\"{x:1238,y:515,t:1528143656270};\\\", \\\"{x:1238,y:518,t:1528143656286};\\\", \\\"{x:1238,y:521,t:1528143656303};\\\", \\\"{x:1238,y:522,t:1528143656320};\\\", \\\"{x:1238,y:523,t:1528143656336};\\\", \\\"{x:1238,y:524,t:1528143656456};\\\", \\\"{x:1243,y:521,t:1528143656470};\\\", \\\"{x:1254,y:513,t:1528143656487};\\\", \\\"{x:1287,y:501,t:1528143656504};\\\", \\\"{x:1321,y:491,t:1528143656520};\\\", \\\"{x:1340,y:486,t:1528143656538};\\\", \\\"{x:1351,y:482,t:1528143656554};\\\", \\\"{x:1359,y:479,t:1528143656571};\\\", \\\"{x:1362,y:477,t:1528143656588};\\\", \\\"{x:1358,y:483,t:1528143658745};\\\", \\\"{x:1352,y:492,t:1528143658760};\\\", \\\"{x:1345,y:502,t:1528143658776};\\\", \\\"{x:1340,y:510,t:1528143658793};\\\", \\\"{x:1337,y:515,t:1528143658810};\\\", \\\"{x:1336,y:516,t:1528143658827};\\\", \\\"{x:1335,y:517,t:1528143658843};\\\", \\\"{x:1334,y:518,t:1528143658860};\\\", \\\"{x:1333,y:515,t:1528143659433};\\\", \\\"{x:1333,y:514,t:1528143659446};\\\", \\\"{x:1332,y:510,t:1528143659462};\\\", \\\"{x:1332,y:506,t:1528143659478};\\\", \\\"{x:1331,y:502,t:1528143659495};\\\", \\\"{x:1331,y:500,t:1528143659512};\\\", \\\"{x:1331,y:499,t:1528143659552};\\\", \\\"{x:1324,y:502,t:1528143661161};\\\", \\\"{x:1302,y:520,t:1528143661168};\\\", \\\"{x:1266,y:531,t:1528143661183};\\\", \\\"{x:1075,y:560,t:1528143661200};\\\", \\\"{x:956,y:564,t:1528143661216};\\\", \\\"{x:869,y:568,t:1528143661234};\\\", \\\"{x:831,y:568,t:1528143661250};\\\", \\\"{x:814,y:568,t:1528143661283};\\\", \\\"{x:813,y:568,t:1528143661359};\\\", \\\"{x:811,y:568,t:1528143661367};\\\", \\\"{x:809,y:568,t:1528143661384};\\\", \\\"{x:807,y:568,t:1528143661401};\\\", \\\"{x:804,y:567,t:1528143661416};\\\", \\\"{x:792,y:566,t:1528143661433};\\\", \\\"{x:780,y:566,t:1528143661449};\\\", \\\"{x:765,y:566,t:1528143661467};\\\", \\\"{x:751,y:566,t:1528143661483};\\\", \\\"{x:733,y:567,t:1528143661500};\\\", \\\"{x:723,y:570,t:1528143661518};\\\", \\\"{x:716,y:574,t:1528143661533};\\\", \\\"{x:712,y:578,t:1528143661550};\\\", \\\"{x:708,y:581,t:1528143661567};\\\", \\\"{x:708,y:582,t:1528143661584};\\\", \\\"{x:707,y:585,t:1528143661601};\\\", \\\"{x:707,y:588,t:1528143661618};\\\", \\\"{x:707,y:589,t:1528143661635};\\\", \\\"{x:707,y:590,t:1528143661651};\\\", \\\"{x:706,y:591,t:1528143661668};\\\", \\\"{x:706,y:594,t:1528143661683};\\\", \\\"{x:706,y:596,t:1528143661702};\\\", \\\"{x:705,y:599,t:1528143661718};\\\", \\\"{x:704,y:604,t:1528143661734};\\\", \\\"{x:703,y:609,t:1528143661751};\\\", \\\"{x:698,y:617,t:1528143661768};\\\", \\\"{x:695,y:620,t:1528143661785};\\\", \\\"{x:693,y:623,t:1528143661801};\\\", \\\"{x:691,y:625,t:1528143661818};\\\", \\\"{x:690,y:625,t:1528143661834};\\\", \\\"{x:689,y:627,t:1528143661853};\\\", \\\"{x:685,y:627,t:1528143661911};\\\", \\\"{x:675,y:627,t:1528143661918};\\\", \\\"{x:668,y:623,t:1528143661935};\\\", \\\"{x:654,y:616,t:1528143661951};\\\", \\\"{x:641,y:607,t:1528143661967};\\\", \\\"{x:632,y:600,t:1528143661985};\\\", \\\"{x:628,y:597,t:1528143662000};\\\", \\\"{x:626,y:596,t:1528143662018};\\\", \\\"{x:625,y:596,t:1528143662232};\\\", \\\"{x:624,y:595,t:1528143662241};\\\", \\\"{x:621,y:593,t:1528143662252};\\\", \\\"{x:616,y:590,t:1528143662267};\\\", \\\"{x:611,y:588,t:1528143662285};\\\", \\\"{x:609,y:587,t:1528143662300};\\\", \\\"{x:609,y:586,t:1528143662318};\\\", \\\"{x:606,y:584,t:1528143662335};\\\", \\\"{x:605,y:582,t:1528143662350};\\\", \\\"{x:605,y:581,t:1528143662367};\\\", \\\"{x:604,y:579,t:1528143662384};\\\", \\\"{x:602,y:577,t:1528143662401};\\\", \\\"{x:605,y:577,t:1528143662831};\\\", \\\"{x:609,y:579,t:1528143662839};\\\", \\\"{x:611,y:580,t:1528143662852};\\\", \\\"{x:615,y:582,t:1528143662869};\\\", \\\"{x:620,y:584,t:1528143662885};\\\", \\\"{x:621,y:585,t:1528143662902};\\\", \\\"{x:624,y:585,t:1528143662919};\\\", \\\"{x:628,y:587,t:1528143662934};\\\", \\\"{x:636,y:590,t:1528143662952};\\\", \\\"{x:644,y:594,t:1528143662968};\\\", \\\"{x:653,y:598,t:1528143662985};\\\", \\\"{x:668,y:604,t:1528143663001};\\\", \\\"{x:692,y:615,t:1528143663018};\\\", \\\"{x:746,y:636,t:1528143663035};\\\", \\\"{x:842,y:678,t:1528143663051};\\\", \\\"{x:961,y:729,t:1528143663069};\\\", \\\"{x:1088,y:782,t:1528143663085};\\\", \\\"{x:1176,y:822,t:1528143663102};\\\", \\\"{x:1212,y:847,t:1528143663119};\\\", \\\"{x:1230,y:861,t:1528143663135};\\\", \\\"{x:1230,y:862,t:1528143663208};\\\", \\\"{x:1230,y:866,t:1528143663219};\\\", \\\"{x:1223,y:885,t:1528143663236};\\\", \\\"{x:1217,y:903,t:1528143663251};\\\", \\\"{x:1208,y:918,t:1528143663269};\\\", \\\"{x:1204,y:925,t:1528143663286};\\\", \\\"{x:1200,y:929,t:1528143663302};\\\", \\\"{x:1199,y:929,t:1528143663319};\\\", \\\"{x:1196,y:931,t:1528143663471};\\\", \\\"{x:1194,y:931,t:1528143663486};\\\", \\\"{x:1185,y:932,t:1528143663503};\\\", \\\"{x:1180,y:932,t:1528143663519};\\\", \\\"{x:1176,y:932,t:1528143663536};\\\", \\\"{x:1174,y:932,t:1528143663552};\\\", \\\"{x:1173,y:932,t:1528143663575};\\\", \\\"{x:1171,y:932,t:1528143663591};\\\", \\\"{x:1168,y:932,t:1528143663602};\\\", \\\"{x:1157,y:932,t:1528143663619};\\\", \\\"{x:1145,y:932,t:1528143663636};\\\", \\\"{x:1135,y:932,t:1528143663653};\\\", \\\"{x:1128,y:932,t:1528143663668};\\\", \\\"{x:1121,y:932,t:1528143663686};\\\", \\\"{x:1115,y:935,t:1528143663703};\\\", \\\"{x:1105,y:938,t:1528143663720};\\\", \\\"{x:1088,y:945,t:1528143663736};\\\", \\\"{x:1080,y:948,t:1528143663753};\\\", \\\"{x:1078,y:949,t:1528143663769};\\\", \\\"{x:1085,y:949,t:1528143664249};\\\", \\\"{x:1096,y:949,t:1528143664256};\\\", \\\"{x:1116,y:949,t:1528143664269};\\\", \\\"{x:1166,y:955,t:1528143664287};\\\", \\\"{x:1217,y:963,t:1528143664303};\\\", \\\"{x:1276,y:974,t:1528143664320};\\\", \\\"{x:1297,y:978,t:1528143664337};\\\", \\\"{x:1301,y:978,t:1528143664352};\\\", \\\"{x:1302,y:978,t:1528143664473};\\\", \\\"{x:1304,y:978,t:1528143664616};\\\", \\\"{x:1305,y:978,t:1528143664624};\\\", \\\"{x:1307,y:978,t:1528143664637};\\\", \\\"{x:1311,y:978,t:1528143664654};\\\", \\\"{x:1313,y:978,t:1528143664670};\\\", \\\"{x:1315,y:978,t:1528143665304};\\\", \\\"{x:1343,y:984,t:1528143665322};\\\", \\\"{x:1376,y:990,t:1528143665338};\\\", \\\"{x:1385,y:995,t:1528143665354};\\\", \\\"{x:1392,y:997,t:1528143665371};\\\", \\\"{x:1391,y:997,t:1528143665448};\\\", \\\"{x:1389,y:997,t:1528143665456};\\\", \\\"{x:1388,y:997,t:1528143665471};\\\", \\\"{x:1386,y:997,t:1528143665488};\\\", \\\"{x:1385,y:997,t:1528143665520};\\\", \\\"{x:1384,y:997,t:1528143670528};\\\", \\\"{x:1378,y:988,t:1528143674376};\\\", \\\"{x:1358,y:949,t:1528143674384};\\\", \\\"{x:1339,y:918,t:1528143674396};\\\", \\\"{x:1295,y:864,t:1528143674413};\\\", \\\"{x:1240,y:829,t:1528143674430};\\\", \\\"{x:1184,y:804,t:1528143674446};\\\", \\\"{x:1151,y:782,t:1528143674463};\\\", \\\"{x:1113,y:755,t:1528143674480};\\\", \\\"{x:1102,y:748,t:1528143674496};\\\", \\\"{x:1093,y:741,t:1528143674512};\\\", \\\"{x:1081,y:734,t:1528143674530};\\\", \\\"{x:1063,y:720,t:1528143674547};\\\", \\\"{x:1025,y:693,t:1528143674562};\\\", \\\"{x:948,y:647,t:1528143674580};\\\", \\\"{x:891,y:623,t:1528143674598};\\\", \\\"{x:855,y:609,t:1528143674613};\\\", \\\"{x:771,y:584,t:1528143674646};\\\", \\\"{x:748,y:579,t:1528143674661};\\\", \\\"{x:732,y:575,t:1528143674677};\\\", \\\"{x:722,y:573,t:1528143674695};\\\", \\\"{x:705,y:570,t:1528143674710};\\\", \\\"{x:697,y:569,t:1528143674728};\\\", \\\"{x:694,y:569,t:1528143674744};\\\", \\\"{x:692,y:569,t:1528143674761};\\\", \\\"{x:689,y:569,t:1528143674778};\\\", \\\"{x:687,y:569,t:1528143674794};\\\", \\\"{x:686,y:569,t:1528143674811};\\\", \\\"{x:685,y:569,t:1528143674839};\\\", \\\"{x:684,y:569,t:1528143674856};\\\", \\\"{x:683,y:569,t:1528143674863};\\\", \\\"{x:683,y:568,t:1528143675304};\\\", \\\"{x:683,y:567,t:1528143675311};\\\", \\\"{x:683,y:566,t:1528143675328};\\\", \\\"{x:683,y:565,t:1528143675352};\\\", \\\"{x:683,y:564,t:1528143675368};\\\", \\\"{x:683,y:563,t:1528143675391};\\\", \\\"{x:684,y:563,t:1528143675432};\\\", \\\"{x:684,y:561,t:1528143675464};\\\", \\\"{x:684,y:560,t:1528143675480};\\\", \\\"{x:685,y:559,t:1528143675495};\\\", \\\"{x:686,y:558,t:1528143675512};\\\", \\\"{x:687,y:557,t:1528143675530};\\\", \\\"{x:691,y:554,t:1528143675545};\\\", \\\"{x:699,y:549,t:1528143675563};\\\", \\\"{x:709,y:546,t:1528143675578};\\\", \\\"{x:718,y:543,t:1528143675593};\\\", \\\"{x:731,y:538,t:1528143675611};\\\", \\\"{x:742,y:534,t:1528143675627};\\\", \\\"{x:756,y:530,t:1528143675645};\\\", \\\"{x:779,y:527,t:1528143675662};\\\", \\\"{x:804,y:523,t:1528143675678};\\\", \\\"{x:841,y:523,t:1528143675695};\\\", \\\"{x:864,y:523,t:1528143675712};\\\", \\\"{x:892,y:523,t:1528143675729};\\\", \\\"{x:924,y:523,t:1528143675745};\\\", \\\"{x:943,y:523,t:1528143675762};\\\", \\\"{x:970,y:523,t:1528143675778};\\\", \\\"{x:992,y:523,t:1528143675795};\\\", \\\"{x:1007,y:524,t:1528143675812};\\\", \\\"{x:1020,y:524,t:1528143675828};\\\", \\\"{x:1028,y:524,t:1528143675845};\\\", \\\"{x:1038,y:524,t:1528143675862};\\\", \\\"{x:1048,y:527,t:1528143675878};\\\", \\\"{x:1056,y:529,t:1528143675895};\\\", \\\"{x:1067,y:529,t:1528143675912};\\\", \\\"{x:1078,y:529,t:1528143675928};\\\", \\\"{x:1092,y:529,t:1528143675945};\\\", \\\"{x:1114,y:530,t:1528143675963};\\\", \\\"{x:1130,y:530,t:1528143675979};\\\", \\\"{x:1135,y:530,t:1528143675995};\\\", \\\"{x:1139,y:530,t:1528143676013};\\\", \\\"{x:1152,y:527,t:1528143676029};\\\", \\\"{x:1167,y:523,t:1528143676046};\\\", \\\"{x:1179,y:519,t:1528143676063};\\\", \\\"{x:1193,y:513,t:1528143676079};\\\", \\\"{x:1201,y:508,t:1528143676095};\\\", \\\"{x:1205,y:506,t:1528143676113};\\\", \\\"{x:1208,y:504,t:1528143676130};\\\", \\\"{x:1210,y:503,t:1528143676146};\\\", \\\"{x:1212,y:501,t:1528143676162};\\\", \\\"{x:1217,y:500,t:1528143676179};\\\", \\\"{x:1223,y:499,t:1528143676196};\\\", \\\"{x:1232,y:496,t:1528143676213};\\\", \\\"{x:1242,y:493,t:1528143676230};\\\", \\\"{x:1250,y:492,t:1528143676246};\\\", \\\"{x:1258,y:490,t:1528143676263};\\\", \\\"{x:1267,y:489,t:1528143676280};\\\", \\\"{x:1274,y:488,t:1528143676296};\\\", \\\"{x:1277,y:488,t:1528143676313};\\\", \\\"{x:1279,y:488,t:1528143676329};\\\", \\\"{x:1282,y:488,t:1528143676346};\\\", \\\"{x:1284,y:488,t:1528143676400};\\\", \\\"{x:1285,y:488,t:1528143676413};\\\", \\\"{x:1286,y:488,t:1528143676432};\\\", \\\"{x:1286,y:489,t:1528143676446};\\\", \\\"{x:1287,y:490,t:1528143676463};\\\", \\\"{x:1288,y:491,t:1528143676480};\\\", \\\"{x:1289,y:492,t:1528143676544};\\\", \\\"{x:1289,y:493,t:1528143676560};\\\", \\\"{x:1290,y:493,t:1528143676584};\\\", \\\"{x:1291,y:494,t:1528143676633};\\\", \\\"{x:1292,y:495,t:1528143676656};\\\", \\\"{x:1292,y:496,t:1528143676688};\\\", \\\"{x:1292,y:498,t:1528143676696};\\\", \\\"{x:1293,y:499,t:1528143676719};\\\", \\\"{x:1295,y:502,t:1528143676735};\\\", \\\"{x:1296,y:502,t:1528143676792};\\\", \\\"{x:1298,y:502,t:1528143676800};\\\", \\\"{x:1300,y:502,t:1528143676823};\\\", \\\"{x:1302,y:502,t:1528143676832};\\\", \\\"{x:1303,y:502,t:1528143676847};\\\", \\\"{x:1306,y:501,t:1528143676863};\\\", \\\"{x:1309,y:499,t:1528143676880};\\\", \\\"{x:1310,y:498,t:1528143676897};\\\", \\\"{x:1311,y:497,t:1528143676913};\\\", \\\"{x:1315,y:493,t:1528143677639};\\\", \\\"{x:1321,y:487,t:1528143677647};\\\", \\\"{x:1336,y:475,t:1528143677663};\\\", \\\"{x:1350,y:462,t:1528143677680};\\\", \\\"{x:1361,y:447,t:1528143677697};\\\", \\\"{x:1376,y:429,t:1528143677713};\\\", \\\"{x:1387,y:413,t:1528143677731};\\\", \\\"{x:1400,y:396,t:1528143677747};\\\", \\\"{x:1406,y:387,t:1528143677763};\\\", \\\"{x:1408,y:380,t:1528143677781};\\\", \\\"{x:1409,y:379,t:1528143677797};\\\", \\\"{x:1409,y:380,t:1528143677936};\\\", \\\"{x:1409,y:381,t:1528143677948};\\\", \\\"{x:1406,y:388,t:1528143677965};\\\", \\\"{x:1404,y:393,t:1528143677981};\\\", \\\"{x:1401,y:399,t:1528143677998};\\\", \\\"{x:1395,y:408,t:1528143678014};\\\", \\\"{x:1390,y:417,t:1528143678030};\\\", \\\"{x:1383,y:428,t:1528143678048};\\\", \\\"{x:1379,y:434,t:1528143678064};\\\", \\\"{x:1375,y:442,t:1528143678081};\\\", \\\"{x:1369,y:450,t:1528143678097};\\\", \\\"{x:1363,y:460,t:1528143678115};\\\", \\\"{x:1355,y:474,t:1528143678131};\\\", \\\"{x:1350,y:482,t:1528143678148};\\\", \\\"{x:1345,y:490,t:1528143678165};\\\", \\\"{x:1341,y:497,t:1528143678181};\\\", \\\"{x:1339,y:501,t:1528143678198};\\\", \\\"{x:1338,y:506,t:1528143678215};\\\", \\\"{x:1337,y:507,t:1528143678231};\\\", \\\"{x:1337,y:510,t:1528143678440};\\\", \\\"{x:1340,y:512,t:1528143678448};\\\", \\\"{x:1353,y:520,t:1528143678464};\\\", \\\"{x:1366,y:530,t:1528143678481};\\\", \\\"{x:1377,y:536,t:1528143678497};\\\", \\\"{x:1384,y:541,t:1528143678515};\\\", \\\"{x:1389,y:542,t:1528143678532};\\\", \\\"{x:1389,y:543,t:1528143678548};\\\", \\\"{x:1390,y:543,t:1528143678564};\\\", \\\"{x:1391,y:544,t:1528143678582};\\\", \\\"{x:1392,y:544,t:1528143678598};\\\", \\\"{x:1394,y:545,t:1528143678614};\\\", \\\"{x:1396,y:545,t:1528143678632};\\\", \\\"{x:1397,y:545,t:1528143678656};\\\", \\\"{x:1397,y:546,t:1528143678712};\\\", \\\"{x:1397,y:547,t:1528143678720};\\\", \\\"{x:1398,y:548,t:1528143678732};\\\", \\\"{x:1398,y:552,t:1528143678748};\\\", \\\"{x:1401,y:557,t:1528143678765};\\\", \\\"{x:1401,y:560,t:1528143678782};\\\", \\\"{x:1402,y:563,t:1528143678799};\\\", \\\"{x:1403,y:565,t:1528143678815};\\\", \\\"{x:1405,y:568,t:1528143678832};\\\", \\\"{x:1408,y:573,t:1528143678848};\\\", \\\"{x:1414,y:580,t:1528143678865};\\\", \\\"{x:1419,y:585,t:1528143678882};\\\", \\\"{x:1425,y:590,t:1528143678899};\\\", \\\"{x:1427,y:592,t:1528143678915};\\\", \\\"{x:1432,y:595,t:1528143678932};\\\", \\\"{x:1436,y:597,t:1528143678949};\\\", \\\"{x:1438,y:599,t:1528143678965};\\\", \\\"{x:1443,y:602,t:1528143678982};\\\", \\\"{x:1446,y:604,t:1528143678999};\\\", \\\"{x:1449,y:606,t:1528143679015};\\\", \\\"{x:1455,y:609,t:1528143679032};\\\", \\\"{x:1457,y:611,t:1528143679049};\\\", \\\"{x:1459,y:612,t:1528143679065};\\\", \\\"{x:1461,y:613,t:1528143679082};\\\", \\\"{x:1462,y:614,t:1528143679099};\\\", \\\"{x:1463,y:614,t:1528143679115};\\\", \\\"{x:1464,y:615,t:1528143679132};\\\", \\\"{x:1467,y:616,t:1528143679149};\\\", \\\"{x:1468,y:617,t:1528143679165};\\\", \\\"{x:1470,y:617,t:1528143679182};\\\", \\\"{x:1471,y:618,t:1528143679200};\\\", \\\"{x:1473,y:619,t:1528143679215};\\\", \\\"{x:1474,y:620,t:1528143679231};\\\", \\\"{x:1477,y:621,t:1528143679249};\\\", \\\"{x:1480,y:623,t:1528143679266};\\\", \\\"{x:1485,y:627,t:1528143679282};\\\", \\\"{x:1488,y:629,t:1528143679299};\\\", \\\"{x:1490,y:631,t:1528143679316};\\\", \\\"{x:1491,y:631,t:1528143679332};\\\", \\\"{x:1492,y:632,t:1528143679349};\\\", \\\"{x:1492,y:633,t:1528143679366};\\\", \\\"{x:1492,y:634,t:1528143679512};\\\", \\\"{x:1490,y:637,t:1528143679519};\\\", \\\"{x:1479,y:640,t:1528143679532};\\\", \\\"{x:1453,y:648,t:1528143679549};\\\", \\\"{x:1410,y:657,t:1528143679566};\\\", \\\"{x:1356,y:666,t:1528143679582};\\\", \\\"{x:1284,y:677,t:1528143679599};\\\", \\\"{x:1147,y:680,t:1528143679616};\\\", \\\"{x:1047,y:680,t:1528143679633};\\\", \\\"{x:939,y:680,t:1528143679649};\\\", \\\"{x:843,y:676,t:1528143679666};\\\", \\\"{x:764,y:659,t:1528143679683};\\\", \\\"{x:708,y:643,t:1528143679700};\\\", \\\"{x:687,y:632,t:1528143679716};\\\", \\\"{x:652,y:617,t:1528143679749};\\\", \\\"{x:644,y:614,t:1528143679765};\\\", \\\"{x:639,y:611,t:1528143679781};\\\", \\\"{x:632,y:607,t:1528143679798};\\\", \\\"{x:622,y:602,t:1528143679815};\\\", \\\"{x:611,y:595,t:1528143679832};\\\", \\\"{x:602,y:588,t:1528143679848};\\\", \\\"{x:583,y:578,t:1528143679864};\\\", \\\"{x:557,y:568,t:1528143679882};\\\", \\\"{x:530,y:560,t:1528143679898};\\\", \\\"{x:504,y:554,t:1528143679914};\\\", \\\"{x:475,y:549,t:1528143679932};\\\", \\\"{x:447,y:548,t:1528143679948};\\\", \\\"{x:422,y:548,t:1528143679965};\\\", \\\"{x:406,y:547,t:1528143679981};\\\", \\\"{x:399,y:547,t:1528143679999};\\\", \\\"{x:398,y:547,t:1528143680016};\\\", \\\"{x:397,y:547,t:1528143680047};\\\", \\\"{x:396,y:547,t:1528143680063};\\\", \\\"{x:394,y:550,t:1528143680071};\\\", \\\"{x:394,y:551,t:1528143680082};\\\", \\\"{x:392,y:556,t:1528143680099};\\\", \\\"{x:390,y:562,t:1528143680117};\\\", \\\"{x:390,y:568,t:1528143680132};\\\", \\\"{x:390,y:573,t:1528143680148};\\\", \\\"{x:390,y:576,t:1528143680165};\\\", \\\"{x:390,y:578,t:1528143680182};\\\", \\\"{x:391,y:579,t:1528143680198};\\\", \\\"{x:404,y:582,t:1528143680215};\\\", \\\"{x:427,y:585,t:1528143680233};\\\", \\\"{x:463,y:590,t:1528143680249};\\\", \\\"{x:506,y:597,t:1528143680265};\\\", \\\"{x:558,y:610,t:1528143680282};\\\", \\\"{x:586,y:617,t:1528143680298};\\\", \\\"{x:599,y:619,t:1528143680316};\\\", \\\"{x:601,y:620,t:1528143680332};\\\", \\\"{x:602,y:620,t:1528143680615};\\\", \\\"{x:607,y:617,t:1528143680633};\\\", \\\"{x:610,y:612,t:1528143680649};\\\", \\\"{x:614,y:606,t:1528143680665};\\\", \\\"{x:616,y:602,t:1528143680683};\\\", \\\"{x:618,y:599,t:1528143680700};\\\", \\\"{x:618,y:598,t:1528143680717};\\\", \\\"{x:619,y:598,t:1528143680733};\\\", \\\"{x:619,y:597,t:1528143680752};\\\", \\\"{x:621,y:594,t:1528143680825};\\\", \\\"{x:622,y:591,t:1528143680832};\\\", \\\"{x:625,y:589,t:1528143680850};\\\", \\\"{x:628,y:583,t:1528143680866};\\\", \\\"{x:630,y:581,t:1528143680883};\\\", \\\"{x:629,y:580,t:1528143681208};\\\", \\\"{x:624,y:580,t:1528143681719};\\\", \\\"{x:614,y:581,t:1528143681734};\\\", \\\"{x:597,y:581,t:1528143681751};\\\", \\\"{x:579,y:581,t:1528143681767};\\\", \\\"{x:560,y:581,t:1528143681783};\\\", \\\"{x:551,y:581,t:1528143681799};\\\", \\\"{x:545,y:582,t:1528143681816};\\\", \\\"{x:537,y:584,t:1528143681833};\\\", \\\"{x:530,y:584,t:1528143681849};\\\", \\\"{x:520,y:584,t:1528143681866};\\\", \\\"{x:512,y:584,t:1528143681884};\\\", \\\"{x:504,y:584,t:1528143681899};\\\", \\\"{x:502,y:584,t:1528143681917};\\\", \\\"{x:498,y:584,t:1528143681934};\\\", \\\"{x:494,y:585,t:1528143681951};\\\", \\\"{x:485,y:586,t:1528143681967};\\\", \\\"{x:467,y:586,t:1528143681983};\\\", \\\"{x:457,y:586,t:1528143682000};\\\", \\\"{x:449,y:586,t:1528143682017};\\\", \\\"{x:438,y:585,t:1528143682033};\\\", \\\"{x:428,y:584,t:1528143682050};\\\", \\\"{x:417,y:583,t:1528143682066};\\\", \\\"{x:397,y:583,t:1528143682084};\\\", \\\"{x:378,y:583,t:1528143682102};\\\", \\\"{x:362,y:583,t:1528143682117};\\\", \\\"{x:352,y:585,t:1528143682133};\\\", \\\"{x:345,y:585,t:1528143682151};\\\", \\\"{x:341,y:586,t:1528143682167};\\\", \\\"{x:339,y:586,t:1528143682184};\\\", \\\"{x:336,y:586,t:1528143682200};\\\", \\\"{x:331,y:586,t:1528143682217};\\\", \\\"{x:324,y:588,t:1528143682233};\\\", \\\"{x:315,y:590,t:1528143682251};\\\", \\\"{x:310,y:592,t:1528143682268};\\\", \\\"{x:307,y:596,t:1528143682284};\\\", \\\"{x:306,y:599,t:1528143682301};\\\", \\\"{x:306,y:606,t:1528143682317};\\\", \\\"{x:306,y:608,t:1528143682333};\\\", \\\"{x:305,y:611,t:1528143682351};\\\", \\\"{x:305,y:617,t:1528143682368};\\\", \\\"{x:307,y:621,t:1528143682383};\\\", \\\"{x:312,y:626,t:1528143682401};\\\", \\\"{x:318,y:629,t:1528143682419};\\\", \\\"{x:323,y:630,t:1528143682433};\\\", \\\"{x:325,y:631,t:1528143682450};\\\", \\\"{x:326,y:631,t:1528143682467};\\\", \\\"{x:327,y:631,t:1528143682487};\\\", \\\"{x:330,y:631,t:1528143682500};\\\", \\\"{x:335,y:629,t:1528143682516};\\\", \\\"{x:342,y:627,t:1528143682533};\\\", \\\"{x:346,y:627,t:1528143682550};\\\", \\\"{x:351,y:626,t:1528143682566};\\\", \\\"{x:356,y:625,t:1528143682584};\\\", \\\"{x:359,y:624,t:1528143682601};\\\", \\\"{x:360,y:624,t:1528143682618};\\\", \\\"{x:363,y:621,t:1528143682634};\\\", \\\"{x:364,y:621,t:1528143682650};\\\", \\\"{x:364,y:620,t:1528143682672};\\\", \\\"{x:365,y:620,t:1528143682711};\\\", \\\"{x:366,y:620,t:1528143682727};\\\", \\\"{x:367,y:619,t:1528143682736};\\\", \\\"{x:369,y:618,t:1528143682751};\\\", \\\"{x:370,y:618,t:1528143682767};\\\", \\\"{x:372,y:618,t:1528143682785};\\\", \\\"{x:373,y:618,t:1528143682807};\\\", \\\"{x:374,y:618,t:1528143683241};\\\", \\\"{x:376,y:618,t:1528143683252};\\\", \\\"{x:385,y:631,t:1528143683268};\\\", \\\"{x:394,y:645,t:1528143683285};\\\", \\\"{x:406,y:657,t:1528143683301};\\\", \\\"{x:413,y:666,t:1528143683318};\\\", \\\"{x:425,y:682,t:1528143683335};\\\", \\\"{x:429,y:687,t:1528143683350};\\\", \\\"{x:432,y:691,t:1528143683367};\\\", \\\"{x:434,y:692,t:1528143683384};\\\", \\\"{x:434,y:693,t:1528143683401};\\\", \\\"{x:435,y:694,t:1528143683417};\\\", \\\"{x:435,y:695,t:1528143683439};\\\", \\\"{x:436,y:695,t:1528143683452};\\\", \\\"{x:437,y:698,t:1528143683468};\\\", \\\"{x:444,y:705,t:1528143683484};\\\", \\\"{x:450,y:712,t:1528143683502};\\\", \\\"{x:457,y:720,t:1528143683518};\\\", \\\"{x:465,y:725,t:1528143683534};\\\", \\\"{x:469,y:728,t:1528143683550};\\\", \\\"{x:471,y:728,t:1528143683567};\\\", \\\"{x:472,y:729,t:1528143683585};\\\", \\\"{x:473,y:729,t:1528143683607};\\\", \\\"{x:474,y:729,t:1528143683618};\\\", \\\"{x:477,y:729,t:1528143683634};\\\", \\\"{x:482,y:718,t:1528143683651};\\\", \\\"{x:483,y:704,t:1528143683669};\\\", \\\"{x:483,y:695,t:1528143683684};\\\", \\\"{x:482,y:689,t:1528143683701};\\\", \\\"{x:477,y:684,t:1528143683719};\\\", \\\"{x:477,y:683,t:1528143683734};\\\", \\\"{x:475,y:682,t:1528143683752};\\\", \\\"{x:471,y:681,t:1528143683768};\\\", \\\"{x:466,y:675,t:1528143683785};\\\", \\\"{x:461,y:667,t:1528143683801};\\\", \\\"{x:453,y:657,t:1528143683819};\\\", \\\"{x:447,y:649,t:1528143683835};\\\", \\\"{x:443,y:645,t:1528143683851};\\\", \\\"{x:441,y:641,t:1528143683868};\\\", \\\"{x:438,y:638,t:1528143683885};\\\", \\\"{x:434,y:634,t:1528143683901};\\\", \\\"{x:432,y:634,t:1528143683919};\\\", \\\"{x:430,y:632,t:1528143683935};\\\", \\\"{x:428,y:632,t:1528143683951};\\\", \\\"{x:425,y:631,t:1528143683968};\\\", \\\"{x:422,y:629,t:1528143683985};\\\", \\\"{x:419,y:628,t:1528143684002};\\\", \\\"{x:416,y:627,t:1528143684018};\\\", \\\"{x:414,y:626,t:1528143684036};\\\", \\\"{x:412,y:625,t:1528143684051};\\\", \\\"{x:409,y:624,t:1528143684068};\\\", \\\"{x:408,y:623,t:1528143684085};\\\", \\\"{x:407,y:623,t:1528143684102};\\\", \\\"{x:406,y:623,t:1528143684118};\\\", \\\"{x:404,y:622,t:1528143684144};\\\", \\\"{x:402,y:621,t:1528143684192};\\\", \\\"{x:400,y:620,t:1528143684208};\\\", \\\"{x:399,y:619,t:1528143684218};\\\", \\\"{x:398,y:619,t:1528143684235};\\\", \\\"{x:398,y:622,t:1528143684511};\\\", \\\"{x:404,y:632,t:1528143684519};\\\", \\\"{x:418,y:652,t:1528143684535};\\\", \\\"{x:429,y:668,t:1528143684552};\\\", \\\"{x:440,y:683,t:1528143684568};\\\", \\\"{x:452,y:697,t:1528143684585};\\\", \\\"{x:458,y:704,t:1528143684603};\\\", \\\"{x:460,y:707,t:1528143684618};\\\", \\\"{x:463,y:710,t:1528143684635};\\\", \\\"{x:464,y:710,t:1528143684653};\\\", \\\"{x:466,y:711,t:1528143684668};\\\", \\\"{x:468,y:712,t:1528143684685};\\\", \\\"{x:471,y:714,t:1528143684703};\\\", \\\"{x:472,y:715,t:1528143684720};\\\", \\\"{x:473,y:715,t:1528143684735};\\\", \\\"{x:475,y:717,t:1528143684752};\\\", \\\"{x:476,y:718,t:1528143684768};\\\", \\\"{x:477,y:719,t:1528143684785};\\\", \\\"{x:480,y:723,t:1528143684802};\\\", \\\"{x:487,y:729,t:1528143684819};\\\", \\\"{x:496,y:733,t:1528143684835};\\\", \\\"{x:503,y:740,t:1528143684853};\\\", \\\"{x:509,y:746,t:1528143684868};\\\", \\\"{x:511,y:748,t:1528143684885};\\\", \\\"{x:512,y:749,t:1528143684902};\\\", \\\"{x:513,y:750,t:1528143684928};\\\", \\\"{x:514,y:748,t:1528143685193};\\\", \\\"{x:517,y:744,t:1528143685203};\\\", \\\"{x:517,y:742,t:1528143685219};\\\", \\\"{x:520,y:737,t:1528143685236};\\\", \\\"{x:520,y:736,t:1528143685252};\\\" ] }, { \\\"rt\\\": 25104, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 796466, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"VVH1B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -08 AM-I -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:520,y:731,t:1528143688744};\\\", \\\"{x:494,y:683,t:1528143688757};\\\", \\\"{x:454,y:612,t:1528143688772};\\\", \\\"{x:414,y:565,t:1528143688789};\\\", \\\"{x:387,y:537,t:1528143688806};\\\", \\\"{x:368,y:518,t:1528143688822};\\\", \\\"{x:357,y:510,t:1528143688839};\\\", \\\"{x:355,y:510,t:1528143688855};\\\", \\\"{x:353,y:509,t:1528143688871};\\\", \\\"{x:352,y:508,t:1528143688888};\\\", \\\"{x:351,y:508,t:1528143688905};\\\", \\\"{x:350,y:508,t:1528143689472};\\\", \\\"{x:366,y:508,t:1528143692263};\\\", \\\"{x:443,y:526,t:1528143692280};\\\", \\\"{x:512,y:545,t:1528143692296};\\\", \\\"{x:541,y:557,t:1528143692309};\\\", \\\"{x:588,y:577,t:1528143692325};\\\", \\\"{x:610,y:586,t:1528143692342};\\\", \\\"{x:623,y:592,t:1528143692358};\\\", \\\"{x:624,y:593,t:1528143692374};\\\", \\\"{x:625,y:593,t:1528143692454};\\\", \\\"{x:625,y:594,t:1528143692503};\\\", \\\"{x:626,y:594,t:1528143692511};\\\", \\\"{x:627,y:594,t:1528143692525};\\\", \\\"{x:640,y:598,t:1528143692541};\\\", \\\"{x:663,y:611,t:1528143692563};\\\", \\\"{x:683,y:618,t:1528143692574};\\\", \\\"{x:708,y:629,t:1528143692592};\\\", \\\"{x:733,y:642,t:1528143692609};\\\", \\\"{x:759,y:651,t:1528143692625};\\\", \\\"{x:782,y:663,t:1528143692641};\\\", \\\"{x:800,y:670,t:1528143692659};\\\", \\\"{x:823,y:678,t:1528143692675};\\\", \\\"{x:843,y:683,t:1528143692691};\\\", \\\"{x:860,y:687,t:1528143692709};\\\", \\\"{x:883,y:691,t:1528143692725};\\\", \\\"{x:911,y:696,t:1528143692742};\\\", \\\"{x:953,y:702,t:1528143692759};\\\", \\\"{x:973,y:704,t:1528143692775};\\\", \\\"{x:990,y:704,t:1528143692792};\\\", \\\"{x:1005,y:704,t:1528143692809};\\\", \\\"{x:1013,y:704,t:1528143692825};\\\", \\\"{x:1027,y:704,t:1528143692842};\\\", \\\"{x:1041,y:704,t:1528143692859};\\\", \\\"{x:1055,y:704,t:1528143692875};\\\", \\\"{x:1068,y:701,t:1528143692892};\\\", \\\"{x:1083,y:700,t:1528143692909};\\\", \\\"{x:1098,y:699,t:1528143692925};\\\", \\\"{x:1112,y:699,t:1528143692942};\\\", \\\"{x:1123,y:696,t:1528143692959};\\\", \\\"{x:1125,y:696,t:1528143692975};\\\", \\\"{x:1129,y:694,t:1528143692992};\\\", \\\"{x:1131,y:693,t:1528143693009};\\\", \\\"{x:1135,y:690,t:1528143693026};\\\", \\\"{x:1140,y:686,t:1528143693042};\\\", \\\"{x:1148,y:682,t:1528143693059};\\\", \\\"{x:1160,y:678,t:1528143693077};\\\", \\\"{x:1176,y:671,t:1528143693093};\\\", \\\"{x:1195,y:666,t:1528143693109};\\\", \\\"{x:1234,y:659,t:1528143693128};\\\", \\\"{x:1248,y:659,t:1528143693143};\\\", \\\"{x:1291,y:658,t:1528143693159};\\\", \\\"{x:1321,y:658,t:1528143693176};\\\", \\\"{x:1358,y:658,t:1528143693192};\\\", \\\"{x:1397,y:658,t:1528143693209};\\\", \\\"{x:1445,y:658,t:1528143693226};\\\", \\\"{x:1495,y:663,t:1528143693243};\\\", \\\"{x:1545,y:677,t:1528143693259};\\\", \\\"{x:1585,y:690,t:1528143693277};\\\", \\\"{x:1607,y:697,t:1528143693292};\\\", \\\"{x:1622,y:704,t:1528143693310};\\\", \\\"{x:1632,y:715,t:1528143693328};\\\", \\\"{x:1633,y:718,t:1528143693343};\\\", \\\"{x:1638,y:735,t:1528143693359};\\\", \\\"{x:1640,y:750,t:1528143693377};\\\", \\\"{x:1641,y:762,t:1528143693392};\\\", \\\"{x:1641,y:773,t:1528143693409};\\\", \\\"{x:1641,y:782,t:1528143693427};\\\", \\\"{x:1640,y:792,t:1528143693443};\\\", \\\"{x:1636,y:804,t:1528143693459};\\\", \\\"{x:1634,y:814,t:1528143693476};\\\", \\\"{x:1630,y:822,t:1528143693493};\\\", \\\"{x:1629,y:829,t:1528143693509};\\\", \\\"{x:1627,y:832,t:1528143693526};\\\", \\\"{x:1625,y:836,t:1528143693542};\\\", \\\"{x:1624,y:838,t:1528143693559};\\\", \\\"{x:1623,y:839,t:1528143693577};\\\", \\\"{x:1621,y:842,t:1528143693593};\\\", \\\"{x:1620,y:843,t:1528143693609};\\\", \\\"{x:1618,y:845,t:1528143693626};\\\", \\\"{x:1616,y:846,t:1528143693643};\\\", \\\"{x:1615,y:848,t:1528143693660};\\\", \\\"{x:1613,y:849,t:1528143693676};\\\", \\\"{x:1613,y:850,t:1528143693693};\\\", \\\"{x:1611,y:851,t:1528143693710};\\\", \\\"{x:1608,y:852,t:1528143693727};\\\", \\\"{x:1605,y:853,t:1528143693744};\\\", \\\"{x:1604,y:854,t:1528143693760};\\\", \\\"{x:1602,y:854,t:1528143693777};\\\", \\\"{x:1597,y:856,t:1528143693794};\\\", \\\"{x:1591,y:857,t:1528143693810};\\\", \\\"{x:1578,y:858,t:1528143693827};\\\", \\\"{x:1560,y:860,t:1528143693844};\\\", \\\"{x:1538,y:864,t:1528143693859};\\\", \\\"{x:1519,y:866,t:1528143693876};\\\", \\\"{x:1500,y:869,t:1528143693894};\\\", \\\"{x:1485,y:871,t:1528143693909};\\\", \\\"{x:1465,y:874,t:1528143693927};\\\", \\\"{x:1453,y:878,t:1528143693943};\\\", \\\"{x:1438,y:880,t:1528143693959};\\\", \\\"{x:1424,y:884,t:1528143693976};\\\", \\\"{x:1411,y:887,t:1528143693993};\\\", \\\"{x:1396,y:891,t:1528143694010};\\\", \\\"{x:1378,y:896,t:1528143694029};\\\", \\\"{x:1355,y:900,t:1528143694043};\\\", \\\"{x:1331,y:902,t:1528143694059};\\\", \\\"{x:1305,y:907,t:1528143694075};\\\", \\\"{x:1268,y:912,t:1528143694093};\\\", \\\"{x:1228,y:912,t:1528143694109};\\\", \\\"{x:1161,y:918,t:1528143694127};\\\", \\\"{x:1126,y:920,t:1528143694142};\\\", \\\"{x:1101,y:925,t:1528143694159};\\\", \\\"{x:1093,y:926,t:1528143694176};\\\", \\\"{x:1092,y:926,t:1528143694193};\\\", \\\"{x:1091,y:926,t:1528143694209};\\\", \\\"{x:1091,y:927,t:1528143694272};\\\", \\\"{x:1090,y:927,t:1528143694280};\\\", \\\"{x:1090,y:928,t:1528143694293};\\\", \\\"{x:1089,y:929,t:1528143694310};\\\", \\\"{x:1088,y:933,t:1528143694327};\\\", \\\"{x:1088,y:938,t:1528143694343};\\\", \\\"{x:1086,y:940,t:1528143694360};\\\", \\\"{x:1086,y:944,t:1528143694376};\\\", \\\"{x:1088,y:955,t:1528143694393};\\\", \\\"{x:1091,y:962,t:1528143694411};\\\", \\\"{x:1092,y:970,t:1528143694426};\\\", \\\"{x:1092,y:974,t:1528143694443};\\\", \\\"{x:1092,y:977,t:1528143694461};\\\", \\\"{x:1092,y:978,t:1528143694608};\\\", \\\"{x:1087,y:977,t:1528143694615};\\\", \\\"{x:1080,y:974,t:1528143694626};\\\", \\\"{x:1074,y:957,t:1528143694645};\\\", \\\"{x:1074,y:943,t:1528143694660};\\\", \\\"{x:1071,y:932,t:1528143694676};\\\", \\\"{x:1071,y:922,t:1528143694693};\\\", \\\"{x:1071,y:917,t:1528143694710};\\\", \\\"{x:1074,y:907,t:1528143694727};\\\", \\\"{x:1077,y:899,t:1528143694743};\\\", \\\"{x:1085,y:888,t:1528143694760};\\\", \\\"{x:1098,y:873,t:1528143694776};\\\", \\\"{x:1114,y:855,t:1528143694793};\\\", \\\"{x:1128,y:841,t:1528143694811};\\\", \\\"{x:1141,y:830,t:1528143694826};\\\", \\\"{x:1146,y:823,t:1528143694844};\\\", \\\"{x:1150,y:819,t:1528143694860};\\\", \\\"{x:1153,y:815,t:1528143694877};\\\", \\\"{x:1154,y:814,t:1528143694896};\\\", \\\"{x:1155,y:813,t:1528143694911};\\\", \\\"{x:1156,y:812,t:1528143695144};\\\", \\\"{x:1163,y:808,t:1528143695161};\\\", \\\"{x:1165,y:805,t:1528143695177};\\\", \\\"{x:1171,y:802,t:1528143695194};\\\", \\\"{x:1174,y:800,t:1528143695211};\\\", \\\"{x:1181,y:797,t:1528143695227};\\\", \\\"{x:1189,y:793,t:1528143695243};\\\", \\\"{x:1195,y:792,t:1528143695261};\\\", \\\"{x:1200,y:789,t:1528143695278};\\\", \\\"{x:1202,y:788,t:1528143695294};\\\", \\\"{x:1203,y:786,t:1528143695310};\\\", \\\"{x:1205,y:785,t:1528143695328};\\\", \\\"{x:1206,y:785,t:1528143695352};\\\", \\\"{x:1206,y:784,t:1528143695400};\\\", \\\"{x:1207,y:784,t:1528143695472};\\\", \\\"{x:1207,y:783,t:1528143695720};\\\", \\\"{x:1206,y:782,t:1528143695744};\\\", \\\"{x:1204,y:777,t:1528143697275};\\\", \\\"{x:1200,y:771,t:1528143697283};\\\", \\\"{x:1199,y:769,t:1528143697298};\\\", \\\"{x:1196,y:766,t:1528143697315};\\\", \\\"{x:1195,y:765,t:1528143697333};\\\", \\\"{x:1194,y:764,t:1528143697348};\\\", \\\"{x:1193,y:763,t:1528143697658};\\\", \\\"{x:1192,y:763,t:1528143697674};\\\", \\\"{x:1191,y:763,t:1528143697691};\\\", \\\"{x:1190,y:763,t:1528143697722};\\\", \\\"{x:1189,y:763,t:1528143697732};\\\", \\\"{x:1188,y:762,t:1528143697755};\\\", \\\"{x:1187,y:762,t:1528143697765};\\\", \\\"{x:1186,y:761,t:1528143697796};\\\", \\\"{x:1185,y:761,t:1528143697827};\\\", \\\"{x:1185,y:760,t:1528143697899};\\\", \\\"{x:1184,y:760,t:1528143703220};\\\", \\\"{x:1184,y:709,t:1528143703236};\\\", \\\"{x:1184,y:669,t:1528143703253};\\\", \\\"{x:1186,y:645,t:1528143703269};\\\", \\\"{x:1191,y:621,t:1528143703285};\\\", \\\"{x:1198,y:600,t:1528143703302};\\\", \\\"{x:1203,y:587,t:1528143703318};\\\", \\\"{x:1206,y:578,t:1528143703335};\\\", \\\"{x:1209,y:572,t:1528143703352};\\\", \\\"{x:1209,y:568,t:1528143703368};\\\", \\\"{x:1210,y:566,t:1528143703385};\\\", \\\"{x:1211,y:563,t:1528143703402};\\\", \\\"{x:1212,y:561,t:1528143703418};\\\", \\\"{x:1212,y:559,t:1528143703435};\\\", \\\"{x:1213,y:557,t:1528143703452};\\\", \\\"{x:1214,y:557,t:1528143703468};\\\", \\\"{x:1214,y:556,t:1528143703485};\\\", \\\"{x:1214,y:555,t:1528143703523};\\\", \\\"{x:1217,y:556,t:1528143703620};\\\", \\\"{x:1222,y:557,t:1528143703635};\\\", \\\"{x:1224,y:559,t:1528143703652};\\\", \\\"{x:1225,y:559,t:1528143703683};\\\", \\\"{x:1225,y:560,t:1528143703724};\\\", \\\"{x:1226,y:560,t:1528143703763};\\\", \\\"{x:1227,y:562,t:1528143703771};\\\", \\\"{x:1227,y:563,t:1528143703786};\\\", \\\"{x:1227,y:565,t:1528143703803};\\\", \\\"{x:1227,y:566,t:1528143703819};\\\", \\\"{x:1228,y:568,t:1528143703835};\\\", \\\"{x:1230,y:568,t:1528143704179};\\\", \\\"{x:1232,y:568,t:1528143704187};\\\", \\\"{x:1237,y:568,t:1528143704203};\\\", \\\"{x:1243,y:568,t:1528143704219};\\\", \\\"{x:1249,y:568,t:1528143704235};\\\", \\\"{x:1252,y:568,t:1528143704253};\\\", \\\"{x:1253,y:568,t:1528143704270};\\\", \\\"{x:1254,y:568,t:1528143704291};\\\", \\\"{x:1255,y:568,t:1528143704316};\\\", \\\"{x:1256,y:568,t:1528143704339};\\\", \\\"{x:1257,y:568,t:1528143704355};\\\", \\\"{x:1259,y:568,t:1528143704369};\\\", \\\"{x:1260,y:568,t:1528143704386};\\\", \\\"{x:1262,y:568,t:1528143704402};\\\", \\\"{x:1264,y:567,t:1528143704419};\\\", \\\"{x:1265,y:567,t:1528143704476};\\\", \\\"{x:1266,y:567,t:1528143704491};\\\", \\\"{x:1267,y:567,t:1528143704503};\\\", \\\"{x:1268,y:567,t:1528143704520};\\\", \\\"{x:1269,y:567,t:1528143704537};\\\", \\\"{x:1271,y:567,t:1528143704552};\\\", \\\"{x:1272,y:567,t:1528143704570};\\\", \\\"{x:1276,y:568,t:1528143704587};\\\", \\\"{x:1281,y:569,t:1528143704603};\\\", \\\"{x:1285,y:570,t:1528143704619};\\\", \\\"{x:1288,y:572,t:1528143704636};\\\", \\\"{x:1290,y:572,t:1528143704652};\\\", \\\"{x:1291,y:572,t:1528143704669};\\\", \\\"{x:1292,y:572,t:1528143704687};\\\", \\\"{x:1293,y:573,t:1528143704772};\\\", \\\"{x:1296,y:573,t:1528143705595};\\\", \\\"{x:1302,y:573,t:1528143705603};\\\", \\\"{x:1323,y:580,t:1528143705619};\\\", \\\"{x:1353,y:589,t:1528143705637};\\\", \\\"{x:1384,y:598,t:1528143705654};\\\", \\\"{x:1409,y:604,t:1528143705670};\\\", \\\"{x:1422,y:604,t:1528143705687};\\\", \\\"{x:1425,y:604,t:1528143705704};\\\", \\\"{x:1425,y:603,t:1528143705860};\\\", \\\"{x:1424,y:601,t:1528143705870};\\\", \\\"{x:1421,y:599,t:1528143705887};\\\", \\\"{x:1418,y:596,t:1528143705904};\\\", \\\"{x:1417,y:594,t:1528143705921};\\\", \\\"{x:1416,y:591,t:1528143705937};\\\", \\\"{x:1416,y:588,t:1528143705954};\\\", \\\"{x:1416,y:585,t:1528143705970};\\\", \\\"{x:1413,y:580,t:1528143705987};\\\", \\\"{x:1413,y:578,t:1528143706004};\\\", \\\"{x:1411,y:576,t:1528143706021};\\\", \\\"{x:1411,y:575,t:1528143706172};\\\", \\\"{x:1409,y:575,t:1528143709508};\\\", \\\"{x:1385,y:582,t:1528143709523};\\\", \\\"{x:1207,y:617,t:1528143709538};\\\", \\\"{x:1092,y:625,t:1528143709556};\\\", \\\"{x:981,y:627,t:1528143709572};\\\", \\\"{x:886,y:627,t:1528143709590};\\\", \\\"{x:844,y:627,t:1528143709605};\\\", \\\"{x:831,y:627,t:1528143709622};\\\", \\\"{x:813,y:627,t:1528143709642};\\\", \\\"{x:795,y:627,t:1528143709659};\\\", \\\"{x:773,y:627,t:1528143709675};\\\", \\\"{x:751,y:627,t:1528143709692};\\\", \\\"{x:737,y:624,t:1528143709709};\\\", \\\"{x:731,y:623,t:1528143709725};\\\", \\\"{x:727,y:621,t:1528143709742};\\\", \\\"{x:720,y:617,t:1528143709760};\\\", \\\"{x:711,y:612,t:1528143709777};\\\", \\\"{x:703,y:605,t:1528143709792};\\\", \\\"{x:691,y:594,t:1528143709810};\\\", \\\"{x:665,y:577,t:1528143709826};\\\", \\\"{x:640,y:561,t:1528143709843};\\\", \\\"{x:600,y:541,t:1528143709860};\\\", \\\"{x:552,y:525,t:1528143709877};\\\", \\\"{x:507,y:512,t:1528143709893};\\\", \\\"{x:475,y:506,t:1528143709910};\\\", \\\"{x:469,y:505,t:1528143709926};\\\", \\\"{x:470,y:505,t:1528143710050};\\\", \\\"{x:478,y:506,t:1528143710059};\\\", \\\"{x:494,y:507,t:1528143710076};\\\", \\\"{x:502,y:507,t:1528143710093};\\\", \\\"{x:510,y:507,t:1528143710110};\\\", \\\"{x:518,y:507,t:1528143710126};\\\", \\\"{x:523,y:507,t:1528143710142};\\\", \\\"{x:527,y:505,t:1528143710159};\\\", \\\"{x:530,y:504,t:1528143710176};\\\", \\\"{x:531,y:504,t:1528143710193};\\\", \\\"{x:532,y:504,t:1528143710209};\\\", \\\"{x:537,y:500,t:1528143710226};\\\", \\\"{x:542,y:497,t:1528143710243};\\\", \\\"{x:548,y:494,t:1528143710260};\\\", \\\"{x:553,y:491,t:1528143710277};\\\", \\\"{x:555,y:490,t:1528143710293};\\\", \\\"{x:557,y:489,t:1528143710309};\\\", \\\"{x:559,y:489,t:1528143710326};\\\", \\\"{x:560,y:489,t:1528143710343};\\\", \\\"{x:562,y:489,t:1528143710359};\\\", \\\"{x:564,y:489,t:1528143710376};\\\", \\\"{x:565,y:489,t:1528143710392};\\\", \\\"{x:567,y:489,t:1528143710409};\\\", \\\"{x:568,y:489,t:1528143710427};\\\", \\\"{x:569,y:489,t:1528143710443};\\\", \\\"{x:571,y:490,t:1528143710459};\\\", \\\"{x:573,y:491,t:1528143710477};\\\", \\\"{x:580,y:493,t:1528143710493};\\\", \\\"{x:585,y:495,t:1528143710510};\\\", \\\"{x:590,y:497,t:1528143710527};\\\", \\\"{x:593,y:499,t:1528143710543};\\\", \\\"{x:594,y:499,t:1528143710560};\\\", \\\"{x:595,y:499,t:1528143710577};\\\", \\\"{x:596,y:499,t:1528143710593};\\\", \\\"{x:597,y:499,t:1528143710715};\\\", \\\"{x:597,y:499,t:1528143710812};\\\", \\\"{x:606,y:502,t:1528143710932};\\\", \\\"{x:627,y:510,t:1528143710943};\\\", \\\"{x:699,y:539,t:1528143710961};\\\", \\\"{x:778,y:574,t:1528143710978};\\\", \\\"{x:839,y:600,t:1528143710993};\\\", \\\"{x:873,y:614,t:1528143711010};\\\", \\\"{x:878,y:614,t:1528143711027};\\\", \\\"{x:879,y:614,t:1528143711066};\\\", \\\"{x:876,y:614,t:1528143711154};\\\", \\\"{x:870,y:614,t:1528143711162};\\\", \\\"{x:866,y:612,t:1528143711178};\\\", \\\"{x:863,y:610,t:1528143711193};\\\", \\\"{x:860,y:608,t:1528143711211};\\\", \\\"{x:858,y:604,t:1528143711227};\\\", \\\"{x:858,y:600,t:1528143711244};\\\", \\\"{x:855,y:595,t:1528143711260};\\\", \\\"{x:855,y:588,t:1528143711278};\\\", \\\"{x:852,y:579,t:1528143711293};\\\", \\\"{x:850,y:572,t:1528143711310};\\\", \\\"{x:850,y:569,t:1528143711327};\\\", \\\"{x:850,y:566,t:1528143711343};\\\", \\\"{x:850,y:565,t:1528143711371};\\\", \\\"{x:850,y:563,t:1528143711523};\\\", \\\"{x:850,y:558,t:1528143711533};\\\", \\\"{x:849,y:554,t:1528143711544};\\\", \\\"{x:846,y:549,t:1528143711560};\\\", \\\"{x:845,y:544,t:1528143711577};\\\", \\\"{x:843,y:540,t:1528143711594};\\\", \\\"{x:842,y:540,t:1528143711610};\\\", \\\"{x:836,y:539,t:1528143711874};\\\", \\\"{x:797,y:541,t:1528143711882};\\\", \\\"{x:758,y:541,t:1528143711894};\\\", \\\"{x:675,y:541,t:1528143711911};\\\", \\\"{x:613,y:541,t:1528143711928};\\\", \\\"{x:582,y:537,t:1528143711944};\\\", \\\"{x:577,y:536,t:1528143711961};\\\", \\\"{x:577,y:535,t:1528143712083};\\\", \\\"{x:577,y:532,t:1528143712094};\\\", \\\"{x:579,y:529,t:1528143712112};\\\", \\\"{x:587,y:523,t:1528143712129};\\\", \\\"{x:593,y:519,t:1528143712145};\\\", \\\"{x:597,y:515,t:1528143712161};\\\", \\\"{x:599,y:512,t:1528143712178};\\\", \\\"{x:601,y:510,t:1528143712194};\\\", \\\"{x:600,y:516,t:1528143712546};\\\", \\\"{x:593,y:529,t:1528143712562};\\\", \\\"{x:555,y:618,t:1528143712579};\\\", \\\"{x:542,y:670,t:1528143712595};\\\", \\\"{x:536,y:706,t:1528143712611};\\\", \\\"{x:536,y:725,t:1528143712628};\\\", \\\"{x:536,y:729,t:1528143712645};\\\", \\\"{x:536,y:730,t:1528143712755};\\\", \\\"{x:536,y:733,t:1528143712763};\\\", \\\"{x:536,y:744,t:1528143712778};\\\", \\\"{x:536,y:748,t:1528143712795};\\\", \\\"{x:536,y:749,t:1528143712811};\\\", \\\"{x:537,y:749,t:1528143712835};\\\", \\\"{x:537,y:747,t:1528143712971};\\\", \\\"{x:537,y:745,t:1528143712979};\\\", \\\"{x:537,y:739,t:1528143712996};\\\", \\\"{x:538,y:733,t:1528143713012};\\\", \\\"{x:538,y:729,t:1528143713029};\\\", \\\"{x:538,y:727,t:1528143713046};\\\", \\\"{x:538,y:726,t:1528143713062};\\\" ] }, { \\\"rt\\\": 26571, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 824334, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"VVH1B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"N\\\", \\\"D\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:536,y:725,t:1528143715236};\\\", \\\"{x:527,y:717,t:1528143715249};\\\", \\\"{x:521,y:683,t:1528143715263};\\\", \\\"{x:516,y:667,t:1528143715280};\\\", \\\"{x:510,y:648,t:1528143715296};\\\", \\\"{x:507,y:635,t:1528143715313};\\\", \\\"{x:503,y:620,t:1528143715330};\\\", \\\"{x:502,y:613,t:1528143715346};\\\", \\\"{x:500,y:610,t:1528143715364};\\\", \\\"{x:500,y:603,t:1528143715381};\\\", \\\"{x:497,y:597,t:1528143715397};\\\", \\\"{x:496,y:591,t:1528143715414};\\\", \\\"{x:493,y:587,t:1528143715430};\\\", \\\"{x:492,y:584,t:1528143715446};\\\", \\\"{x:490,y:580,t:1528143715463};\\\", \\\"{x:487,y:578,t:1528143715481};\\\", \\\"{x:484,y:574,t:1528143715497};\\\", \\\"{x:481,y:570,t:1528143715514};\\\", \\\"{x:477,y:567,t:1528143715531};\\\", \\\"{x:474,y:566,t:1528143715547};\\\", \\\"{x:470,y:564,t:1528143715564};\\\", \\\"{x:458,y:559,t:1528143715581};\\\", \\\"{x:443,y:553,t:1528143715598};\\\", \\\"{x:429,y:548,t:1528143715614};\\\", \\\"{x:413,y:543,t:1528143715631};\\\", \\\"{x:400,y:539,t:1528143715648};\\\", \\\"{x:395,y:538,t:1528143715663};\\\", \\\"{x:389,y:535,t:1528143715681};\\\", \\\"{x:385,y:534,t:1528143715697};\\\", \\\"{x:383,y:532,t:1528143715713};\\\", \\\"{x:381,y:531,t:1528143715731};\\\", \\\"{x:377,y:528,t:1528143715748};\\\", \\\"{x:373,y:524,t:1528143715766};\\\", \\\"{x:371,y:522,t:1528143715781};\\\", \\\"{x:369,y:521,t:1528143715803};\\\", \\\"{x:376,y:520,t:1528143718299};\\\", \\\"{x:482,y:511,t:1528143718316};\\\", \\\"{x:563,y:511,t:1528143718333};\\\", \\\"{x:644,y:514,t:1528143718349};\\\", \\\"{x:666,y:517,t:1528143718366};\\\", \\\"{x:672,y:520,t:1528143718383};\\\", \\\"{x:674,y:521,t:1528143718399};\\\", \\\"{x:674,y:522,t:1528143719564};\\\", \\\"{x:673,y:522,t:1528143720595};\\\", \\\"{x:636,y:524,t:1528143720602};\\\", \\\"{x:511,y:526,t:1528143720620};\\\", \\\"{x:419,y:523,t:1528143720635};\\\", \\\"{x:375,y:519,t:1528143720651};\\\", \\\"{x:354,y:515,t:1528143720668};\\\", \\\"{x:352,y:515,t:1528143720685};\\\", \\\"{x:352,y:512,t:1528143721043};\\\", \\\"{x:352,y:508,t:1528143721052};\\\", \\\"{x:357,y:503,t:1528143721068};\\\", \\\"{x:363,y:499,t:1528143721085};\\\", \\\"{x:367,y:498,t:1528143721102};\\\", \\\"{x:370,y:496,t:1528143721118};\\\", \\\"{x:371,y:495,t:1528143721135};\\\", \\\"{x:372,y:495,t:1528143721152};\\\", \\\"{x:373,y:494,t:1528143721168};\\\", \\\"{x:373,y:493,t:1528143722027};\\\", \\\"{x:384,y:490,t:1528143722037};\\\", \\\"{x:409,y:484,t:1528143722053};\\\", \\\"{x:432,y:481,t:1528143722068};\\\", \\\"{x:441,y:479,t:1528143722085};\\\", \\\"{x:442,y:479,t:1528143722101};\\\", \\\"{x:443,y:479,t:1528143722119};\\\", \\\"{x:442,y:479,t:1528143722210};\\\", \\\"{x:442,y:480,t:1528143722242};\\\", \\\"{x:441,y:481,t:1528143722253};\\\", \\\"{x:446,y:481,t:1528143723451};\\\", \\\"{x:450,y:481,t:1528143723458};\\\", \\\"{x:453,y:481,t:1528143723470};\\\", \\\"{x:458,y:480,t:1528143723487};\\\", \\\"{x:463,y:479,t:1528143723503};\\\", \\\"{x:464,y:479,t:1528143723521};\\\", \\\"{x:465,y:479,t:1528143723691};\\\", \\\"{x:467,y:479,t:1528143723704};\\\", \\\"{x:472,y:477,t:1528143723720};\\\", \\\"{x:477,y:476,t:1528143723737};\\\", \\\"{x:486,y:475,t:1528143723754};\\\", \\\"{x:490,y:475,t:1528143723770};\\\", \\\"{x:494,y:473,t:1528143723787};\\\", \\\"{x:495,y:473,t:1528143723804};\\\", \\\"{x:498,y:473,t:1528143723820};\\\", \\\"{x:502,y:472,t:1528143723837};\\\", \\\"{x:507,y:472,t:1528143723854};\\\", \\\"{x:509,y:472,t:1528143723870};\\\", \\\"{x:510,y:472,t:1528143723907};\\\", \\\"{x:511,y:471,t:1528143724099};\\\", \\\"{x:514,y:470,t:1528143724115};\\\", \\\"{x:515,y:470,t:1528143724123};\\\", \\\"{x:518,y:470,t:1528143724139};\\\", \\\"{x:521,y:470,t:1528143724154};\\\", \\\"{x:523,y:470,t:1528143724170};\\\", \\\"{x:527,y:470,t:1528143724187};\\\", \\\"{x:530,y:470,t:1528143724204};\\\", \\\"{x:532,y:470,t:1528143724221};\\\", \\\"{x:538,y:471,t:1528143724237};\\\", \\\"{x:542,y:474,t:1528143724254};\\\", \\\"{x:544,y:475,t:1528143724270};\\\", \\\"{x:545,y:476,t:1528143724287};\\\", \\\"{x:546,y:476,t:1528143724304};\\\", \\\"{x:546,y:477,t:1528143724322};\\\", \\\"{x:548,y:477,t:1528143724394};\\\", \\\"{x:549,y:477,t:1528143725211};\\\", \\\"{x:551,y:477,t:1528143725267};\\\", \\\"{x:553,y:477,t:1528143725291};\\\", \\\"{x:555,y:477,t:1528143725306};\\\", \\\"{x:557,y:477,t:1528143725321};\\\", \\\"{x:559,y:477,t:1528143725338};\\\", \\\"{x:562,y:477,t:1528143725355};\\\", \\\"{x:564,y:477,t:1528143725372};\\\", \\\"{x:570,y:476,t:1528143725388};\\\", \\\"{x:584,y:475,t:1528143725405};\\\", \\\"{x:602,y:475,t:1528143725421};\\\", \\\"{x:627,y:475,t:1528143725438};\\\", \\\"{x:663,y:475,t:1528143725455};\\\", \\\"{x:695,y:479,t:1528143725472};\\\", \\\"{x:738,y:486,t:1528143725488};\\\", \\\"{x:797,y:494,t:1528143725506};\\\", \\\"{x:913,y:514,t:1528143725521};\\\", \\\"{x:986,y:525,t:1528143725538};\\\", \\\"{x:1040,y:536,t:1528143725554};\\\", \\\"{x:1064,y:544,t:1528143725572};\\\", \\\"{x:1079,y:549,t:1528143725588};\\\", \\\"{x:1092,y:553,t:1528143725605};\\\", \\\"{x:1095,y:554,t:1528143725622};\\\", \\\"{x:1099,y:555,t:1528143725638};\\\", \\\"{x:1101,y:555,t:1528143725655};\\\", \\\"{x:1103,y:557,t:1528143725672};\\\", \\\"{x:1104,y:557,t:1528143725690};\\\", \\\"{x:1105,y:557,t:1528143725714};\\\", \\\"{x:1107,y:558,t:1528143725722};\\\", \\\"{x:1113,y:563,t:1528143725739};\\\", \\\"{x:1122,y:574,t:1528143725755};\\\", \\\"{x:1136,y:586,t:1528143725772};\\\", \\\"{x:1152,y:599,t:1528143725789};\\\", \\\"{x:1172,y:614,t:1528143725805};\\\", \\\"{x:1190,y:624,t:1528143725822};\\\", \\\"{x:1215,y:637,t:1528143725840};\\\", \\\"{x:1244,y:655,t:1528143725855};\\\", \\\"{x:1274,y:667,t:1528143725872};\\\", \\\"{x:1314,y:681,t:1528143725889};\\\", \\\"{x:1360,y:692,t:1528143725905};\\\", \\\"{x:1480,y:728,t:1528143725923};\\\", \\\"{x:1585,y:756,t:1528143725940};\\\", \\\"{x:1692,y:782,t:1528143725956};\\\", \\\"{x:1787,y:812,t:1528143725973};\\\", \\\"{x:1878,y:837,t:1528143725989};\\\", \\\"{x:1919,y:853,t:1528143726005};\\\", \\\"{x:1919,y:864,t:1528143726022};\\\", \\\"{x:1919,y:865,t:1528143726039};\\\", \\\"{x:1919,y:866,t:1528143726055};\\\", \\\"{x:1919,y:865,t:1528143726578};\\\", \\\"{x:1912,y:866,t:1528143726589};\\\", \\\"{x:1898,y:871,t:1528143726607};\\\", \\\"{x:1886,y:875,t:1528143726623};\\\", \\\"{x:1873,y:880,t:1528143726640};\\\", \\\"{x:1864,y:882,t:1528143726656};\\\", \\\"{x:1860,y:884,t:1528143726673};\\\", \\\"{x:1857,y:885,t:1528143726690};\\\", \\\"{x:1850,y:888,t:1528143726706};\\\", \\\"{x:1841,y:891,t:1528143726723};\\\", \\\"{x:1831,y:892,t:1528143726740};\\\", \\\"{x:1819,y:895,t:1528143726756};\\\", \\\"{x:1801,y:898,t:1528143726774};\\\", \\\"{x:1784,y:901,t:1528143726789};\\\", \\\"{x:1765,y:901,t:1528143726807};\\\", \\\"{x:1749,y:901,t:1528143726824};\\\", \\\"{x:1723,y:901,t:1528143726839};\\\", \\\"{x:1696,y:901,t:1528143726856};\\\", \\\"{x:1667,y:901,t:1528143726874};\\\", \\\"{x:1632,y:898,t:1528143726890};\\\", \\\"{x:1585,y:890,t:1528143726906};\\\", \\\"{x:1543,y:885,t:1528143726923};\\\", \\\"{x:1510,y:877,t:1528143726939};\\\", \\\"{x:1478,y:873,t:1528143726956};\\\", \\\"{x:1455,y:867,t:1528143726974};\\\", \\\"{x:1434,y:865,t:1528143726990};\\\", \\\"{x:1412,y:861,t:1528143727007};\\\", \\\"{x:1389,y:858,t:1528143727024};\\\", \\\"{x:1371,y:856,t:1528143727040};\\\", \\\"{x:1352,y:853,t:1528143727057};\\\", \\\"{x:1341,y:852,t:1528143727074};\\\", \\\"{x:1331,y:850,t:1528143727090};\\\", \\\"{x:1323,y:848,t:1528143727106};\\\", \\\"{x:1322,y:848,t:1528143727123};\\\", \\\"{x:1320,y:848,t:1528143727155};\\\", \\\"{x:1319,y:847,t:1528143727163};\\\", \\\"{x:1318,y:847,t:1528143727186};\\\", \\\"{x:1317,y:847,t:1528143727195};\\\", \\\"{x:1315,y:846,t:1528143727207};\\\", \\\"{x:1314,y:846,t:1528143727224};\\\", \\\"{x:1312,y:845,t:1528143727241};\\\", \\\"{x:1307,y:845,t:1528143727257};\\\", \\\"{x:1303,y:845,t:1528143727274};\\\", \\\"{x:1295,y:845,t:1528143727291};\\\", \\\"{x:1290,y:845,t:1528143727306};\\\", \\\"{x:1285,y:843,t:1528143727323};\\\", \\\"{x:1283,y:843,t:1528143727340};\\\", \\\"{x:1279,y:842,t:1528143727356};\\\", \\\"{x:1277,y:842,t:1528143727374};\\\", \\\"{x:1273,y:842,t:1528143727390};\\\", \\\"{x:1270,y:842,t:1528143727407};\\\", \\\"{x:1265,y:841,t:1528143727424};\\\", \\\"{x:1261,y:841,t:1528143727441};\\\", \\\"{x:1253,y:837,t:1528143727458};\\\", \\\"{x:1247,y:837,t:1528143727474};\\\", \\\"{x:1240,y:837,t:1528143727490};\\\", \\\"{x:1234,y:835,t:1528143727507};\\\", \\\"{x:1231,y:834,t:1528143727524};\\\", \\\"{x:1226,y:833,t:1528143727541};\\\", \\\"{x:1224,y:833,t:1528143727558};\\\", \\\"{x:1223,y:833,t:1528143727573};\\\", \\\"{x:1222,y:833,t:1528143727591};\\\", \\\"{x:1221,y:833,t:1528143727607};\\\", \\\"{x:1216,y:830,t:1528143734373};\\\", \\\"{x:1197,y:828,t:1528143734380};\\\", \\\"{x:1125,y:822,t:1528143734395};\\\", \\\"{x:1025,y:806,t:1528143734412};\\\", \\\"{x:930,y:776,t:1528143734429};\\\", \\\"{x:846,y:746,t:1528143734445};\\\", \\\"{x:814,y:731,t:1528143734462};\\\", \\\"{x:805,y:725,t:1528143734480};\\\", \\\"{x:802,y:723,t:1528143734495};\\\", \\\"{x:801,y:722,t:1528143734512};\\\", \\\"{x:801,y:721,t:1528143734529};\\\", \\\"{x:801,y:720,t:1528143734545};\\\", \\\"{x:797,y:717,t:1528143734562};\\\", \\\"{x:790,y:712,t:1528143734579};\\\", \\\"{x:785,y:708,t:1528143734595};\\\", \\\"{x:779,y:704,t:1528143734612};\\\", \\\"{x:770,y:698,t:1528143734629};\\\", \\\"{x:763,y:693,t:1528143734646};\\\", \\\"{x:758,y:690,t:1528143734662};\\\", \\\"{x:754,y:686,t:1528143734679};\\\", \\\"{x:744,y:680,t:1528143734695};\\\", \\\"{x:724,y:673,t:1528143734712};\\\", \\\"{x:690,y:662,t:1528143734729};\\\", \\\"{x:642,y:649,t:1528143734746};\\\", \\\"{x:586,y:633,t:1528143734762};\\\", \\\"{x:572,y:625,t:1528143734780};\\\", \\\"{x:568,y:623,t:1528143734796};\\\", \\\"{x:563,y:621,t:1528143734812};\\\", \\\"{x:554,y:617,t:1528143734829};\\\", \\\"{x:520,y:610,t:1528143734845};\\\", \\\"{x:443,y:592,t:1528143734862};\\\", \\\"{x:347,y:570,t:1528143734879};\\\", \\\"{x:258,y:543,t:1528143734896};\\\", \\\"{x:183,y:525,t:1528143734913};\\\", \\\"{x:147,y:516,t:1528143734930};\\\", \\\"{x:137,y:512,t:1528143734945};\\\", \\\"{x:136,y:511,t:1528143734962};\\\", \\\"{x:134,y:511,t:1528143735066};\\\", \\\"{x:133,y:511,t:1528143735090};\\\", \\\"{x:131,y:514,t:1528143735098};\\\", \\\"{x:130,y:519,t:1528143735113};\\\", \\\"{x:129,y:526,t:1528143735130};\\\", \\\"{x:129,y:533,t:1528143735146};\\\", \\\"{x:130,y:534,t:1528143735162};\\\", \\\"{x:132,y:537,t:1528143735180};\\\", \\\"{x:133,y:538,t:1528143735218};\\\", \\\"{x:133,y:539,t:1528143735230};\\\", \\\"{x:135,y:541,t:1528143735246};\\\", \\\"{x:136,y:543,t:1528143735263};\\\", \\\"{x:136,y:547,t:1528143735279};\\\", \\\"{x:137,y:553,t:1528143735297};\\\", \\\"{x:140,y:559,t:1528143735314};\\\", \\\"{x:142,y:568,t:1528143735330};\\\", \\\"{x:144,y:575,t:1528143735346};\\\", \\\"{x:144,y:577,t:1528143735363};\\\", \\\"{x:145,y:578,t:1528143735379};\\\", \\\"{x:145,y:579,t:1528143735466};\\\", \\\"{x:145,y:580,t:1528143735480};\\\", \\\"{x:145,y:581,t:1528143735498};\\\", \\\"{x:145,y:582,t:1528143735514};\\\", \\\"{x:145,y:584,t:1528143735579};\\\", \\\"{x:145,y:585,t:1528143735594};\\\", \\\"{x:145,y:586,t:1528143735602};\\\", \\\"{x:146,y:587,t:1528143735614};\\\", \\\"{x:146,y:591,t:1528143735631};\\\", \\\"{x:147,y:596,t:1528143735648};\\\", \\\"{x:148,y:602,t:1528143735666};\\\", \\\"{x:150,y:605,t:1528143735681};\\\", \\\"{x:151,y:606,t:1528143735697};\\\", \\\"{x:153,y:606,t:1528143735794};\\\", \\\"{x:155,y:606,t:1528143735810};\\\", \\\"{x:163,y:606,t:1528143735817};\\\", \\\"{x:181,y:605,t:1528143735829};\\\", \\\"{x:247,y:588,t:1528143735847};\\\", \\\"{x:337,y:572,t:1528143735864};\\\", \\\"{x:406,y:564,t:1528143735880};\\\", \\\"{x:448,y:557,t:1528143735897};\\\", \\\"{x:481,y:549,t:1528143735914};\\\", \\\"{x:485,y:548,t:1528143735929};\\\", \\\"{x:484,y:548,t:1528143736051};\\\", \\\"{x:482,y:550,t:1528143736064};\\\", \\\"{x:480,y:552,t:1528143736081};\\\", \\\"{x:478,y:553,t:1528143736097};\\\", \\\"{x:471,y:555,t:1528143736114};\\\", \\\"{x:459,y:557,t:1528143736131};\\\", \\\"{x:442,y:559,t:1528143736148};\\\", \\\"{x:423,y:559,t:1528143736164};\\\", \\\"{x:404,y:560,t:1528143736180};\\\", \\\"{x:390,y:562,t:1528143736197};\\\", \\\"{x:379,y:564,t:1528143736216};\\\", \\\"{x:377,y:565,t:1528143736230};\\\", \\\"{x:375,y:565,t:1528143736247};\\\", \\\"{x:374,y:565,t:1528143736306};\\\", \\\"{x:374,y:566,t:1528143736322};\\\", \\\"{x:371,y:567,t:1528143736329};\\\", \\\"{x:364,y:572,t:1528143736346};\\\", \\\"{x:358,y:576,t:1528143736363};\\\", \\\"{x:347,y:584,t:1528143736381};\\\", \\\"{x:340,y:590,t:1528143736397};\\\", \\\"{x:338,y:593,t:1528143736414};\\\", \\\"{x:337,y:595,t:1528143736431};\\\", \\\"{x:337,y:597,t:1528143736447};\\\", \\\"{x:337,y:600,t:1528143736463};\\\", \\\"{x:341,y:600,t:1528143736481};\\\", \\\"{x:344,y:602,t:1528143736498};\\\", \\\"{x:348,y:603,t:1528143736513};\\\", \\\"{x:349,y:604,t:1528143736530};\\\", \\\"{x:350,y:604,t:1528143736553};\\\", \\\"{x:354,y:604,t:1528143736569};\\\", \\\"{x:361,y:603,t:1528143736580};\\\", \\\"{x:383,y:598,t:1528143736598};\\\", \\\"{x:411,y:593,t:1528143736614};\\\", \\\"{x:444,y:589,t:1528143736630};\\\", \\\"{x:481,y:583,t:1528143736647};\\\", \\\"{x:506,y:579,t:1528143736663};\\\", \\\"{x:520,y:577,t:1528143736680};\\\", \\\"{x:524,y:575,t:1528143736697};\\\", \\\"{x:526,y:574,t:1528143736713};\\\", \\\"{x:529,y:572,t:1528143736794};\\\", \\\"{x:535,y:572,t:1528143736802};\\\", \\\"{x:546,y:572,t:1528143736814};\\\", \\\"{x:575,y:572,t:1528143736830};\\\", \\\"{x:607,y:572,t:1528143736849};\\\", \\\"{x:628,y:572,t:1528143736865};\\\", \\\"{x:632,y:571,t:1528143736881};\\\", \\\"{x:634,y:571,t:1528143736898};\\\", \\\"{x:632,y:571,t:1528143736970};\\\", \\\"{x:622,y:572,t:1528143736980};\\\", \\\"{x:586,y:581,t:1528143736999};\\\", \\\"{x:553,y:588,t:1528143737014};\\\", \\\"{x:527,y:596,t:1528143737031};\\\", \\\"{x:507,y:598,t:1528143737047};\\\", \\\"{x:498,y:598,t:1528143737065};\\\", \\\"{x:492,y:598,t:1528143737080};\\\", \\\"{x:487,y:598,t:1528143737098};\\\", \\\"{x:485,y:597,t:1528143737114};\\\", \\\"{x:479,y:596,t:1528143737130};\\\", \\\"{x:472,y:593,t:1528143737148};\\\", \\\"{x:468,y:593,t:1528143737164};\\\", \\\"{x:466,y:592,t:1528143737180};\\\", \\\"{x:465,y:592,t:1528143737202};\\\", \\\"{x:464,y:592,t:1528143737218};\\\", \\\"{x:463,y:592,t:1528143737274};\\\", \\\"{x:462,y:592,t:1528143737282};\\\", \\\"{x:460,y:591,t:1528143737298};\\\", \\\"{x:449,y:579,t:1528143737314};\\\", \\\"{x:428,y:561,t:1528143737332};\\\", \\\"{x:379,y:529,t:1528143737348};\\\", \\\"{x:324,y:497,t:1528143737364};\\\", \\\"{x:269,y:475,t:1528143737382};\\\", \\\"{x:236,y:461,t:1528143737397};\\\", \\\"{x:215,y:452,t:1528143737414};\\\", \\\"{x:196,y:446,t:1528143737431};\\\", \\\"{x:189,y:446,t:1528143737447};\\\", \\\"{x:187,y:446,t:1528143737464};\\\", \\\"{x:186,y:446,t:1528143737481};\\\", \\\"{x:184,y:446,t:1528143737497};\\\", \\\"{x:181,y:447,t:1528143737514};\\\", \\\"{x:177,y:454,t:1528143737532};\\\", \\\"{x:174,y:461,t:1528143737548};\\\", \\\"{x:173,y:468,t:1528143737564};\\\", \\\"{x:173,y:474,t:1528143737582};\\\", \\\"{x:173,y:481,t:1528143737597};\\\", \\\"{x:173,y:487,t:1528143737615};\\\", \\\"{x:173,y:490,t:1528143737631};\\\", \\\"{x:174,y:497,t:1528143737649};\\\", \\\"{x:175,y:502,t:1528143737665};\\\", \\\"{x:180,y:518,t:1528143737682};\\\", \\\"{x:181,y:531,t:1528143737698};\\\", \\\"{x:181,y:545,t:1528143737715};\\\", \\\"{x:181,y:557,t:1528143737732};\\\", \\\"{x:181,y:570,t:1528143737749};\\\", \\\"{x:181,y:577,t:1528143737764};\\\", \\\"{x:181,y:582,t:1528143737782};\\\", \\\"{x:180,y:587,t:1528143737798};\\\", \\\"{x:180,y:590,t:1528143737814};\\\", \\\"{x:179,y:594,t:1528143737833};\\\", \\\"{x:179,y:595,t:1528143737923};\\\", \\\"{x:179,y:597,t:1528143737946};\\\", \\\"{x:179,y:600,t:1528143737955};\\\", \\\"{x:179,y:603,t:1528143737967};\\\", \\\"{x:179,y:609,t:1528143737983};\\\", \\\"{x:179,y:624,t:1528143737998};\\\", \\\"{x:179,y:635,t:1528143738015};\\\", \\\"{x:179,y:640,t:1528143738032};\\\", \\\"{x:179,y:644,t:1528143738048};\\\", \\\"{x:180,y:647,t:1528143738065};\\\", \\\"{x:180,y:648,t:1528143738081};\\\", \\\"{x:180,y:649,t:1528143738098};\\\", \\\"{x:180,y:650,t:1528143738114};\\\", \\\"{x:180,y:652,t:1528143738193};\\\", \\\"{x:180,y:653,t:1528143738201};\\\", \\\"{x:180,y:654,t:1528143738215};\\\", \\\"{x:179,y:656,t:1528143738231};\\\", \\\"{x:178,y:656,t:1528143738248};\\\", \\\"{x:178,y:657,t:1528143738266};\\\", \\\"{x:181,y:654,t:1528143738811};\\\", \\\"{x:188,y:646,t:1528143738818};\\\", \\\"{x:196,y:640,t:1528143738833};\\\", \\\"{x:202,y:632,t:1528143738849};\\\", \\\"{x:211,y:623,t:1528143738867};\\\", \\\"{x:214,y:621,t:1528143738883};\\\", \\\"{x:216,y:619,t:1528143738898};\\\", \\\"{x:223,y:616,t:1528143738915};\\\", \\\"{x:230,y:610,t:1528143738933};\\\", \\\"{x:240,y:605,t:1528143738948};\\\", \\\"{x:251,y:599,t:1528143738965};\\\", \\\"{x:257,y:593,t:1528143738983};\\\", \\\"{x:264,y:585,t:1528143739000};\\\", \\\"{x:268,y:578,t:1528143739016};\\\", \\\"{x:269,y:574,t:1528143739033};\\\", \\\"{x:267,y:560,t:1528143739050};\\\", \\\"{x:248,y:542,t:1528143739065};\\\", \\\"{x:215,y:525,t:1528143739083};\\\", \\\"{x:198,y:519,t:1528143739100};\\\", \\\"{x:179,y:519,t:1528143739116};\\\", \\\"{x:162,y:520,t:1528143739133};\\\", \\\"{x:155,y:524,t:1528143739150};\\\", \\\"{x:154,y:525,t:1528143739228};\\\", \\\"{x:154,y:527,t:1528143739242};\\\", \\\"{x:154,y:534,t:1528143739250};\\\", \\\"{x:159,y:541,t:1528143739265};\\\", \\\"{x:165,y:549,t:1528143739283};\\\", \\\"{x:171,y:555,t:1528143739300};\\\", \\\"{x:179,y:564,t:1528143739317};\\\", \\\"{x:187,y:576,t:1528143739333};\\\", \\\"{x:193,y:583,t:1528143739350};\\\", \\\"{x:197,y:589,t:1528143739365};\\\", \\\"{x:201,y:592,t:1528143739382};\\\", \\\"{x:204,y:594,t:1528143739400};\\\", \\\"{x:205,y:595,t:1528143739416};\\\", \\\"{x:209,y:596,t:1528143739432};\\\", \\\"{x:230,y:596,t:1528143739449};\\\", \\\"{x:258,y:599,t:1528143739465};\\\", \\\"{x:291,y:603,t:1528143739483};\\\", \\\"{x:313,y:607,t:1528143739499};\\\", \\\"{x:325,y:610,t:1528143739517};\\\", \\\"{x:327,y:611,t:1528143739532};\\\", \\\"{x:328,y:612,t:1528143739549};\\\", \\\"{x:329,y:612,t:1528143739566};\\\", \\\"{x:330,y:613,t:1528143739582};\\\", \\\"{x:336,y:617,t:1528143739600};\\\", \\\"{x:342,y:622,t:1528143739616};\\\", \\\"{x:349,y:627,t:1528143739633};\\\", \\\"{x:364,y:637,t:1528143739652};\\\", \\\"{x:375,y:646,t:1528143739667};\\\", \\\"{x:385,y:653,t:1528143739682};\\\", \\\"{x:393,y:661,t:1528143739699};\\\", \\\"{x:399,y:666,t:1528143739717};\\\", \\\"{x:406,y:670,t:1528143739733};\\\", \\\"{x:410,y:674,t:1528143739749};\\\", \\\"{x:412,y:676,t:1528143739766};\\\", \\\"{x:413,y:676,t:1528143739782};\\\", \\\"{x:414,y:676,t:1528143739799};\\\", \\\"{x:413,y:676,t:1528143739923};\\\", \\\"{x:412,y:674,t:1528143739933};\\\", \\\"{x:411,y:672,t:1528143739950};\\\", \\\"{x:410,y:670,t:1528143739967};\\\", \\\"{x:409,y:670,t:1528143739984};\\\", \\\"{x:409,y:669,t:1528143740001};\\\", \\\"{x:408,y:669,t:1528143740042};\\\", \\\"{x:406,y:669,t:1528143740058};\\\", \\\"{x:404,y:668,t:1528143740067};\\\", \\\"{x:401,y:667,t:1528143740084};\\\", \\\"{x:396,y:664,t:1528143740100};\\\", \\\"{x:394,y:663,t:1528143740118};\\\", \\\"{x:392,y:663,t:1528143740134};\\\", \\\"{x:391,y:663,t:1528143740384};\\\", \\\"{x:399,y:668,t:1528143740401};\\\", \\\"{x:437,y:721,t:1528143740417};\\\", \\\"{x:502,y:790,t:1528143740433};\\\", \\\"{x:512,y:798,t:1528143740450};\\\", \\\"{x:512,y:800,t:1528143740466};\\\", \\\"{x:510,y:798,t:1528143740554};\\\", \\\"{x:506,y:796,t:1528143740567};\\\", \\\"{x:495,y:787,t:1528143740584};\\\", \\\"{x:479,y:775,t:1528143740601};\\\", \\\"{x:462,y:763,t:1528143740617};\\\", \\\"{x:456,y:760,t:1528143740634};\\\", \\\"{x:454,y:758,t:1528143740651};\\\", \\\"{x:452,y:756,t:1528143740691};\\\", \\\"{x:452,y:755,t:1528143740701};\\\", \\\"{x:452,y:754,t:1528143740738};\\\", \\\"{x:452,y:753,t:1528143740752};\\\", \\\"{x:453,y:752,t:1528143740778};\\\", \\\"{x:454,y:752,t:1528143740802};\\\", \\\"{x:455,y:751,t:1528143740818};\\\", \\\"{x:457,y:749,t:1528143740835};\\\", \\\"{x:460,y:745,t:1528143740851};\\\", \\\"{x:461,y:744,t:1528143740867};\\\", \\\"{x:462,y:741,t:1528143740885};\\\", \\\"{x:463,y:741,t:1528143740923};\\\" ] }, { \\\"rt\\\": 76876, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 902530, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"VVH1B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"J\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -M -X -X -X -M -M -M -M -X -X -B -J -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:463,y:723,t:1528143743379};\\\", \\\"{x:463,y:714,t:1528143743390};\\\", \\\"{x:463,y:701,t:1528143743404};\\\", \\\"{x:466,y:684,t:1528143743419};\\\", \\\"{x:467,y:675,t:1528143743436};\\\", \\\"{x:470,y:669,t:1528143743453};\\\", \\\"{x:471,y:665,t:1528143743470};\\\", \\\"{x:471,y:662,t:1528143743485};\\\", \\\"{x:471,y:657,t:1528143743502};\\\", \\\"{x:471,y:649,t:1528143743519};\\\", \\\"{x:471,y:626,t:1528143743536};\\\", \\\"{x:471,y:606,t:1528143743553};\\\", \\\"{x:471,y:596,t:1528143743570};\\\", \\\"{x:470,y:589,t:1528143743586};\\\", \\\"{x:469,y:588,t:1528143743603};\\\", \\\"{x:469,y:587,t:1528143743620};\\\", \\\"{x:469,y:586,t:1528143743636};\\\", \\\"{x:468,y:583,t:1528143743653};\\\", \\\"{x:467,y:582,t:1528143743669};\\\", \\\"{x:466,y:582,t:1528143743738};\\\", \\\"{x:465,y:582,t:1528143743754};\\\", \\\"{x:461,y:581,t:1528143743770};\\\", \\\"{x:460,y:580,t:1528143743786};\\\", \\\"{x:450,y:575,t:1528143743803};\\\", \\\"{x:442,y:573,t:1528143743820};\\\", \\\"{x:432,y:568,t:1528143743836};\\\", \\\"{x:428,y:568,t:1528143743853};\\\", \\\"{x:425,y:567,t:1528143743870};\\\", \\\"{x:424,y:566,t:1528143744627};\\\", \\\"{x:423,y:558,t:1528143744638};\\\", \\\"{x:423,y:541,t:1528143744655};\\\", \\\"{x:422,y:532,t:1528143744668};\\\", \\\"{x:422,y:520,t:1528143744686};\\\", \\\"{x:422,y:506,t:1528143744702};\\\", \\\"{x:422,y:502,t:1528143744719};\\\", \\\"{x:422,y:497,t:1528143744736};\\\", \\\"{x:422,y:490,t:1528143744753};\\\", \\\"{x:422,y:487,t:1528143744769};\\\", \\\"{x:422,y:486,t:1528143744787};\\\", \\\"{x:422,y:485,t:1528143744803};\\\", \\\"{x:423,y:483,t:1528143744819};\\\", \\\"{x:426,y:479,t:1528143745267};\\\", \\\"{x:433,y:471,t:1528143745274};\\\", \\\"{x:437,y:468,t:1528143745287};\\\", \\\"{x:446,y:461,t:1528143745304};\\\", \\\"{x:449,y:459,t:1528143745321};\\\", \\\"{x:450,y:459,t:1528143745337};\\\", \\\"{x:451,y:459,t:1528143745395};\\\", \\\"{x:452,y:459,t:1528143745411};\\\", \\\"{x:453,y:459,t:1528143745421};\\\", \\\"{x:457,y:461,t:1528143745437};\\\", \\\"{x:459,y:461,t:1528143745454};\\\", \\\"{x:462,y:462,t:1528143745471};\\\", \\\"{x:464,y:464,t:1528143745499};\\\", \\\"{x:466,y:464,t:1528143745546};\\\", \\\"{x:468,y:465,t:1528143745579};\\\", \\\"{x:469,y:465,t:1528143745594};\\\", \\\"{x:470,y:465,t:1528143745604};\\\", \\\"{x:473,y:465,t:1528143745621};\\\", \\\"{x:480,y:465,t:1528143745638};\\\", \\\"{x:490,y:465,t:1528143745655};\\\", \\\"{x:501,y:465,t:1528143745671};\\\", \\\"{x:518,y:468,t:1528143745688};\\\", \\\"{x:541,y:471,t:1528143745705};\\\", \\\"{x:568,y:475,t:1528143745721};\\\", \\\"{x:609,y:480,t:1528143745738};\\\", \\\"{x:634,y:483,t:1528143745754};\\\", \\\"{x:654,y:483,t:1528143745771};\\\", \\\"{x:671,y:483,t:1528143745788};\\\", \\\"{x:683,y:483,t:1528143745804};\\\", \\\"{x:687,y:483,t:1528143745821};\\\", \\\"{x:690,y:483,t:1528143745838};\\\", \\\"{x:694,y:483,t:1528143745855};\\\", \\\"{x:698,y:483,t:1528143745871};\\\", \\\"{x:703,y:481,t:1528143745888};\\\", \\\"{x:707,y:480,t:1528143745904};\\\", \\\"{x:709,y:479,t:1528143745921};\\\", \\\"{x:712,y:477,t:1528143745938};\\\", \\\"{x:713,y:477,t:1528143745970};\\\", \\\"{x:714,y:477,t:1528143745988};\\\", \\\"{x:716,y:477,t:1528143746004};\\\", \\\"{x:718,y:477,t:1528143746021};\\\", \\\"{x:719,y:477,t:1528143746038};\\\", \\\"{x:722,y:477,t:1528143746054};\\\", \\\"{x:724,y:477,t:1528143746074};\\\", \\\"{x:725,y:477,t:1528143746114};\\\", \\\"{x:727,y:475,t:1528143746124};\\\", \\\"{x:732,y:472,t:1528143746138};\\\", \\\"{x:737,y:469,t:1528143746155};\\\", \\\"{x:739,y:466,t:1528143746172};\\\", \\\"{x:740,y:466,t:1528143746188};\\\", \\\"{x:743,y:466,t:1528143746506};\\\", \\\"{x:747,y:466,t:1528143746521};\\\", \\\"{x:766,y:466,t:1528143746538};\\\", \\\"{x:771,y:466,t:1528143746555};\\\", \\\"{x:783,y:466,t:1528143746571};\\\", \\\"{x:797,y:466,t:1528143746588};\\\", \\\"{x:815,y:466,t:1528143746606};\\\", \\\"{x:842,y:464,t:1528143746622};\\\", \\\"{x:894,y:451,t:1528143746638};\\\", \\\"{x:965,y:427,t:1528143746656};\\\", \\\"{x:1071,y:392,t:1528143746672};\\\", \\\"{x:1190,y:355,t:1528143746688};\\\", \\\"{x:1314,y:321,t:1528143746705};\\\", \\\"{x:1415,y:287,t:1528143746721};\\\", \\\"{x:1510,y:259,t:1528143746738};\\\", \\\"{x:1536,y:251,t:1528143746755};\\\", \\\"{x:1553,y:249,t:1528143746772};\\\", \\\"{x:1562,y:247,t:1528143746788};\\\", \\\"{x:1565,y:247,t:1528143746806};\\\", \\\"{x:1568,y:247,t:1528143746821};\\\", \\\"{x:1570,y:247,t:1528143746838};\\\", \\\"{x:1573,y:247,t:1528143746856};\\\", \\\"{x:1577,y:249,t:1528143746873};\\\", \\\"{x:1578,y:249,t:1528143746889};\\\", \\\"{x:1579,y:249,t:1528143746905};\\\", \\\"{x:1580,y:249,t:1528143746921};\\\", \\\"{x:1584,y:249,t:1528143746939};\\\", \\\"{x:1586,y:249,t:1528143746955};\\\", \\\"{x:1588,y:249,t:1528143747747};\\\", \\\"{x:1579,y:254,t:1528143747755};\\\", \\\"{x:1559,y:270,t:1528143747772};\\\", \\\"{x:1541,y:292,t:1528143747789};\\\", \\\"{x:1531,y:314,t:1528143747806};\\\", \\\"{x:1519,y:337,t:1528143747823};\\\", \\\"{x:1507,y:368,t:1528143747840};\\\", \\\"{x:1486,y:415,t:1528143747855};\\\", \\\"{x:1460,y:481,t:1528143747873};\\\", \\\"{x:1411,y:565,t:1528143747892};\\\", \\\"{x:1365,y:655,t:1528143747907};\\\", \\\"{x:1323,y:755,t:1528143747923};\\\", \\\"{x:1316,y:790,t:1528143747940};\\\", \\\"{x:1316,y:800,t:1528143747955};\\\", \\\"{x:1316,y:801,t:1528143747973};\\\", \\\"{x:1316,y:802,t:1528143748018};\\\", \\\"{x:1317,y:803,t:1528143748034};\\\", \\\"{x:1318,y:804,t:1528143748042};\\\", \\\"{x:1318,y:806,t:1528143748056};\\\", \\\"{x:1321,y:823,t:1528143748073};\\\", \\\"{x:1325,y:844,t:1528143748090};\\\", \\\"{x:1330,y:858,t:1528143748106};\\\", \\\"{x:1334,y:861,t:1528143748123};\\\", \\\"{x:1339,y:864,t:1528143748139};\\\", \\\"{x:1345,y:862,t:1528143748155};\\\", \\\"{x:1350,y:856,t:1528143748173};\\\", \\\"{x:1358,y:840,t:1528143748189};\\\", \\\"{x:1363,y:817,t:1528143748206};\\\", \\\"{x:1372,y:793,t:1528143748223};\\\", \\\"{x:1374,y:775,t:1528143748239};\\\", \\\"{x:1374,y:769,t:1528143748255};\\\", \\\"{x:1374,y:768,t:1528143748272};\\\", \\\"{x:1374,y:769,t:1528143748465};\\\", \\\"{x:1373,y:771,t:1528143748474};\\\", \\\"{x:1372,y:772,t:1528143748489};\\\", \\\"{x:1369,y:775,t:1528143748506};\\\", \\\"{x:1367,y:777,t:1528143748522};\\\", \\\"{x:1365,y:779,t:1528143748540};\\\", \\\"{x:1364,y:778,t:1528143748603};\\\", \\\"{x:1362,y:778,t:1528143748618};\\\", \\\"{x:1362,y:777,t:1528143748627};\\\", \\\"{x:1361,y:777,t:1528143748641};\\\", \\\"{x:1360,y:776,t:1528143748656};\\\", \\\"{x:1359,y:775,t:1528143748674};\\\", \\\"{x:1358,y:774,t:1528143748689};\\\", \\\"{x:1354,y:772,t:1528143748706};\\\", \\\"{x:1352,y:771,t:1528143748721};\\\", \\\"{x:1351,y:771,t:1528143748746};\\\", \\\"{x:1350,y:785,t:1528143756291};\\\", \\\"{x:1360,y:821,t:1528143756298};\\\", \\\"{x:1365,y:838,t:1528143756310};\\\", \\\"{x:1373,y:862,t:1528143756326};\\\", \\\"{x:1378,y:872,t:1528143756343};\\\", \\\"{x:1380,y:882,t:1528143756359};\\\", \\\"{x:1381,y:883,t:1528143756376};\\\", \\\"{x:1383,y:884,t:1528143756393};\\\", \\\"{x:1384,y:884,t:1528143756418};\\\", \\\"{x:1386,y:884,t:1528143756442};\\\", \\\"{x:1386,y:885,t:1528143756449};\\\", \\\"{x:1387,y:885,t:1528143756465};\\\", \\\"{x:1388,y:890,t:1528143756530};\\\", \\\"{x:1391,y:895,t:1528143756543};\\\", \\\"{x:1396,y:903,t:1528143756559};\\\", \\\"{x:1396,y:906,t:1528143756576};\\\", \\\"{x:1398,y:911,t:1528143756594};\\\", \\\"{x:1399,y:911,t:1528143756666};\\\", \\\"{x:1400,y:911,t:1528143756707};\\\", \\\"{x:1400,y:910,t:1528143756715};\\\", \\\"{x:1400,y:908,t:1528143756727};\\\", \\\"{x:1399,y:905,t:1528143756747};\\\", \\\"{x:1397,y:904,t:1528143756763};\\\", \\\"{x:1397,y:903,t:1528143756780};\\\", \\\"{x:1397,y:902,t:1528143756870};\\\", \\\"{x:1396,y:902,t:1528143756880};\\\", \\\"{x:1396,y:901,t:1528143756897};\\\", \\\"{x:1396,y:900,t:1528143756913};\\\", \\\"{x:1396,y:899,t:1528143756949};\\\", \\\"{x:1397,y:891,t:1528143757743};\\\", \\\"{x:1405,y:886,t:1528143757750};\\\", \\\"{x:1413,y:882,t:1528143757765};\\\", \\\"{x:1434,y:864,t:1528143757781};\\\", \\\"{x:1451,y:844,t:1528143757798};\\\", \\\"{x:1455,y:838,t:1528143757815};\\\", \\\"{x:1456,y:837,t:1528143757831};\\\", \\\"{x:1456,y:836,t:1528143757848};\\\", \\\"{x:1457,y:836,t:1528143757910};\\\", \\\"{x:1458,y:835,t:1528143758103};\\\", \\\"{x:1460,y:835,t:1528143758115};\\\", \\\"{x:1466,y:833,t:1528143758131};\\\", \\\"{x:1472,y:830,t:1528143758148};\\\", \\\"{x:1474,y:829,t:1528143758165};\\\", \\\"{x:1478,y:827,t:1528143758183};\\\", \\\"{x:1480,y:825,t:1528143758198};\\\", \\\"{x:1485,y:821,t:1528143758215};\\\", \\\"{x:1487,y:819,t:1528143758232};\\\", \\\"{x:1489,y:817,t:1528143758248};\\\", \\\"{x:1489,y:818,t:1528143760118};\\\", \\\"{x:1487,y:821,t:1528143760133};\\\", \\\"{x:1486,y:824,t:1528143760149};\\\", \\\"{x:1482,y:830,t:1528143760166};\\\", \\\"{x:1480,y:832,t:1528143760183};\\\", \\\"{x:1480,y:833,t:1528143760199};\\\", \\\"{x:1479,y:833,t:1528143760285};\\\", \\\"{x:1479,y:838,t:1528143765231};\\\", \\\"{x:1467,y:842,t:1528143765238};\\\", \\\"{x:1451,y:847,t:1528143765252};\\\", \\\"{x:1426,y:854,t:1528143765268};\\\", \\\"{x:1411,y:859,t:1528143765285};\\\", \\\"{x:1406,y:861,t:1528143765302};\\\", \\\"{x:1405,y:861,t:1528143765366};\\\", \\\"{x:1404,y:861,t:1528143765374};\\\", \\\"{x:1399,y:858,t:1528143765385};\\\", \\\"{x:1394,y:853,t:1528143765402};\\\", \\\"{x:1387,y:847,t:1528143765418};\\\", \\\"{x:1378,y:842,t:1528143765435};\\\", \\\"{x:1371,y:840,t:1528143765452};\\\", \\\"{x:1361,y:834,t:1528143765468};\\\", \\\"{x:1355,y:829,t:1528143765485};\\\", \\\"{x:1349,y:827,t:1528143765502};\\\", \\\"{x:1347,y:825,t:1528143765518};\\\", \\\"{x:1342,y:824,t:1528143765535};\\\", \\\"{x:1333,y:823,t:1528143765552};\\\", \\\"{x:1332,y:823,t:1528143765574};\\\", \\\"{x:1331,y:823,t:1528143765631};\\\", \\\"{x:1333,y:830,t:1528143765926};\\\", \\\"{x:1335,y:835,t:1528143765935};\\\", \\\"{x:1338,y:839,t:1528143765952};\\\", \\\"{x:1339,y:840,t:1528143765969};\\\", \\\"{x:1341,y:840,t:1528143765990};\\\", \\\"{x:1341,y:841,t:1528143766002};\\\", \\\"{x:1344,y:842,t:1528143766019};\\\", \\\"{x:1346,y:842,t:1528143766035};\\\", \\\"{x:1348,y:844,t:1528143766052};\\\", \\\"{x:1350,y:844,t:1528143766069};\\\", \\\"{x:1351,y:844,t:1528143766085};\\\", \\\"{x:1353,y:844,t:1528143766102};\\\", \\\"{x:1354,y:844,t:1528143766128};\\\", \\\"{x:1356,y:844,t:1528143766191};\\\", \\\"{x:1359,y:845,t:1528143766206};\\\", \\\"{x:1361,y:846,t:1528143766219};\\\", \\\"{x:1364,y:847,t:1528143766235};\\\", \\\"{x:1366,y:848,t:1528143766252};\\\", \\\"{x:1369,y:849,t:1528143766269};\\\", \\\"{x:1373,y:850,t:1528143766286};\\\", \\\"{x:1382,y:851,t:1528143766302};\\\", \\\"{x:1388,y:852,t:1528143766319};\\\", \\\"{x:1391,y:852,t:1528143766335};\\\", \\\"{x:1395,y:854,t:1528143766352};\\\", \\\"{x:1401,y:854,t:1528143766369};\\\", \\\"{x:1409,y:856,t:1528143766385};\\\", \\\"{x:1412,y:856,t:1528143766402};\\\", \\\"{x:1414,y:856,t:1528143766419};\\\", \\\"{x:1415,y:856,t:1528143766436};\\\", \\\"{x:1416,y:856,t:1528143766487};\\\", \\\"{x:1419,y:856,t:1528143766526};\\\", \\\"{x:1422,y:856,t:1528143766537};\\\", \\\"{x:1432,y:851,t:1528143766552};\\\", \\\"{x:1447,y:847,t:1528143766569};\\\", \\\"{x:1455,y:846,t:1528143766586};\\\", \\\"{x:1456,y:846,t:1528143766602};\\\", \\\"{x:1457,y:846,t:1528143766619};\\\", \\\"{x:1458,y:846,t:1528143766678};\\\", \\\"{x:1459,y:845,t:1528143766686};\\\", \\\"{x:1466,y:842,t:1528143766702};\\\", \\\"{x:1470,y:839,t:1528143766719};\\\", \\\"{x:1476,y:837,t:1528143766736};\\\", \\\"{x:1480,y:834,t:1528143766752};\\\", \\\"{x:1482,y:832,t:1528143766769};\\\", \\\"{x:1483,y:831,t:1528143766789};\\\", \\\"{x:1483,y:830,t:1528143766838};\\\", \\\"{x:1484,y:830,t:1528143766852};\\\", \\\"{x:1485,y:831,t:1528143767278};\\\", \\\"{x:1481,y:839,t:1528143767287};\\\", \\\"{x:1474,y:848,t:1528143767303};\\\", \\\"{x:1465,y:857,t:1528143767319};\\\", \\\"{x:1461,y:863,t:1528143767336};\\\", \\\"{x:1458,y:867,t:1528143767353};\\\", \\\"{x:1456,y:868,t:1528143767510};\\\", \\\"{x:1453,y:869,t:1528143767519};\\\", \\\"{x:1446,y:873,t:1528143767535};\\\", \\\"{x:1439,y:875,t:1528143767552};\\\", \\\"{x:1429,y:879,t:1528143767569};\\\", \\\"{x:1421,y:883,t:1528143767585};\\\", \\\"{x:1417,y:883,t:1528143767603};\\\", \\\"{x:1415,y:884,t:1528143767618};\\\", \\\"{x:1410,y:884,t:1528143767636};\\\", \\\"{x:1404,y:886,t:1528143767652};\\\", \\\"{x:1398,y:886,t:1528143767668};\\\", \\\"{x:1392,y:887,t:1528143767685};\\\", \\\"{x:1390,y:888,t:1528143767702};\\\", \\\"{x:1389,y:889,t:1528143767742};\\\", \\\"{x:1389,y:890,t:1528143767807};\\\", \\\"{x:1387,y:890,t:1528143767822};\\\", \\\"{x:1386,y:890,t:1528143767836};\\\", \\\"{x:1383,y:891,t:1528143767853};\\\", \\\"{x:1378,y:893,t:1528143767870};\\\", \\\"{x:1378,y:894,t:1528143767886};\\\", \\\"{x:1377,y:894,t:1528143768030};\\\", \\\"{x:1377,y:895,t:1528143771774};\\\", \\\"{x:1377,y:896,t:1528143776246};\\\", \\\"{x:1377,y:899,t:1528143776278};\\\", \\\"{x:1377,y:911,t:1528143776291};\\\", \\\"{x:1377,y:921,t:1528143776308};\\\", \\\"{x:1376,y:925,t:1528143776323};\\\", \\\"{x:1376,y:931,t:1528143776341};\\\", \\\"{x:1374,y:937,t:1528143776357};\\\", \\\"{x:1374,y:938,t:1528143776373};\\\", \\\"{x:1373,y:940,t:1528143776391};\\\", \\\"{x:1373,y:941,t:1528143776430};\\\", \\\"{x:1372,y:941,t:1528143776469};\\\", \\\"{x:1372,y:942,t:1528143776542};\\\", \\\"{x:1372,y:945,t:1528143776558};\\\", \\\"{x:1372,y:946,t:1528143776574};\\\", \\\"{x:1369,y:951,t:1528143776591};\\\", \\\"{x:1368,y:955,t:1528143776608};\\\", \\\"{x:1367,y:957,t:1528143776624};\\\", \\\"{x:1366,y:960,t:1528143776640};\\\", \\\"{x:1364,y:962,t:1528143776657};\\\", \\\"{x:1364,y:963,t:1528143776675};\\\", \\\"{x:1363,y:964,t:1528143776870};\\\", \\\"{x:1361,y:964,t:1528143776878};\\\", \\\"{x:1361,y:965,t:1528143776891};\\\", \\\"{x:1359,y:966,t:1528143776908};\\\", \\\"{x:1358,y:966,t:1528143776926};\\\", \\\"{x:1357,y:966,t:1528143776942};\\\", \\\"{x:1356,y:967,t:1528143776958};\\\", \\\"{x:1355,y:967,t:1528143777005};\\\", \\\"{x:1354,y:967,t:1528143777062};\\\", \\\"{x:1353,y:967,t:1528143778046};\\\", \\\"{x:1351,y:966,t:1528143778058};\\\", \\\"{x:1350,y:961,t:1528143778075};\\\", \\\"{x:1350,y:959,t:1528143778092};\\\", \\\"{x:1350,y:958,t:1528143778108};\\\", \\\"{x:1350,y:955,t:1528143778125};\\\", \\\"{x:1350,y:948,t:1528143778141};\\\", \\\"{x:1351,y:944,t:1528143778158};\\\", \\\"{x:1354,y:939,t:1528143778174};\\\", \\\"{x:1355,y:935,t:1528143778192};\\\", \\\"{x:1357,y:930,t:1528143778208};\\\", \\\"{x:1358,y:927,t:1528143778224};\\\", \\\"{x:1361,y:923,t:1528143778241};\\\", \\\"{x:1365,y:917,t:1528143778258};\\\", \\\"{x:1366,y:913,t:1528143778274};\\\", \\\"{x:1368,y:910,t:1528143778292};\\\", \\\"{x:1369,y:909,t:1528143778308};\\\", \\\"{x:1370,y:908,t:1528143778325};\\\", \\\"{x:1370,y:907,t:1528143778421};\\\", \\\"{x:1370,y:906,t:1528143778429};\\\", \\\"{x:1370,y:904,t:1528143778441};\\\", \\\"{x:1372,y:902,t:1528143778458};\\\", \\\"{x:1374,y:901,t:1528143778474};\\\", \\\"{x:1376,y:898,t:1528143778491};\\\", \\\"{x:1377,y:896,t:1528143778507};\\\", \\\"{x:1378,y:892,t:1528143778524};\\\", \\\"{x:1380,y:890,t:1528143778541};\\\", \\\"{x:1380,y:889,t:1528143778558};\\\", \\\"{x:1380,y:888,t:1528143778597};\\\", \\\"{x:1388,y:883,t:1528143788174};\\\", \\\"{x:1422,y:857,t:1528143788181};\\\", \\\"{x:1432,y:851,t:1528143788197};\\\", \\\"{x:1464,y:831,t:1528143788213};\\\", \\\"{x:1486,y:804,t:1528143788229};\\\", \\\"{x:1489,y:792,t:1528143788247};\\\", \\\"{x:1489,y:790,t:1528143788263};\\\", \\\"{x:1489,y:788,t:1528143788280};\\\", \\\"{x:1489,y:789,t:1528143788397};\\\", \\\"{x:1484,y:794,t:1528143788413};\\\", \\\"{x:1477,y:812,t:1528143788430};\\\", \\\"{x:1476,y:829,t:1528143788447};\\\", \\\"{x:1476,y:851,t:1528143788464};\\\", \\\"{x:1475,y:866,t:1528143788480};\\\", \\\"{x:1474,y:876,t:1528143788497};\\\", \\\"{x:1472,y:882,t:1528143788513};\\\", \\\"{x:1472,y:884,t:1528143788530};\\\", \\\"{x:1472,y:882,t:1528143788701};\\\", \\\"{x:1471,y:876,t:1528143788713};\\\", \\\"{x:1470,y:867,t:1528143788730};\\\", \\\"{x:1470,y:859,t:1528143788747};\\\", \\\"{x:1468,y:854,t:1528143788763};\\\", \\\"{x:1468,y:850,t:1528143788780};\\\", \\\"{x:1468,y:849,t:1528143788797};\\\", \\\"{x:1468,y:848,t:1528143788813};\\\", \\\"{x:1468,y:846,t:1528143788829};\\\", \\\"{x:1466,y:844,t:1528143788847};\\\", \\\"{x:1460,y:839,t:1528143788863};\\\", \\\"{x:1446,y:833,t:1528143788879};\\\", \\\"{x:1434,y:829,t:1528143788896};\\\", \\\"{x:1423,y:827,t:1528143788914};\\\", \\\"{x:1413,y:825,t:1528143788929};\\\", \\\"{x:1407,y:825,t:1528143788946};\\\", \\\"{x:1406,y:825,t:1528143788963};\\\", \\\"{x:1401,y:823,t:1528143788980};\\\", \\\"{x:1394,y:817,t:1528143788996};\\\", \\\"{x:1384,y:801,t:1528143789012};\\\", \\\"{x:1381,y:793,t:1528143789029};\\\", \\\"{x:1377,y:784,t:1528143789046};\\\", \\\"{x:1375,y:780,t:1528143789063};\\\", \\\"{x:1373,y:777,t:1528143789079};\\\", \\\"{x:1372,y:775,t:1528143789096};\\\", \\\"{x:1371,y:774,t:1528143789113};\\\", \\\"{x:1369,y:772,t:1528143789129};\\\", \\\"{x:1368,y:772,t:1528143789147};\\\", \\\"{x:1367,y:772,t:1528143789164};\\\", \\\"{x:1366,y:772,t:1528143789180};\\\", \\\"{x:1365,y:770,t:1528143789197};\\\", \\\"{x:1363,y:769,t:1528143789422};\\\", \\\"{x:1362,y:767,t:1528143789430};\\\", \\\"{x:1360,y:761,t:1528143789447};\\\", \\\"{x:1359,y:759,t:1528143789464};\\\", \\\"{x:1357,y:755,t:1528143789480};\\\", \\\"{x:1357,y:753,t:1528143789510};\\\", \\\"{x:1356,y:755,t:1528143789718};\\\", \\\"{x:1356,y:756,t:1528143789733};\\\", \\\"{x:1356,y:757,t:1528143789747};\\\", \\\"{x:1356,y:758,t:1528143789764};\\\", \\\"{x:1356,y:759,t:1528143789782};\\\", \\\"{x:1356,y:760,t:1528143789797};\\\", \\\"{x:1356,y:761,t:1528143789814};\\\", \\\"{x:1356,y:762,t:1528143789877};\\\", \\\"{x:1356,y:763,t:1528143789950};\\\", \\\"{x:1355,y:764,t:1528143789964};\\\", \\\"{x:1354,y:765,t:1528143790206};\\\", \\\"{x:1353,y:766,t:1528143790213};\\\", \\\"{x:1353,y:767,t:1528143790246};\\\", \\\"{x:1352,y:768,t:1528143790302};\\\", \\\"{x:1351,y:768,t:1528143790350};\\\", \\\"{x:1350,y:768,t:1528143790365};\\\", \\\"{x:1346,y:771,t:1528143790382};\\\", \\\"{x:1342,y:773,t:1528143790398};\\\", \\\"{x:1340,y:775,t:1528143790414};\\\", \\\"{x:1337,y:776,t:1528143790431};\\\", \\\"{x:1335,y:778,t:1528143790448};\\\", \\\"{x:1334,y:778,t:1528143790464};\\\", \\\"{x:1332,y:780,t:1528143790481};\\\", \\\"{x:1331,y:780,t:1528143790498};\\\", \\\"{x:1330,y:781,t:1528143790514};\\\", \\\"{x:1328,y:781,t:1528143790590};\\\", \\\"{x:1326,y:781,t:1528143790597};\\\", \\\"{x:1321,y:782,t:1528143790614};\\\", \\\"{x:1314,y:786,t:1528143790630};\\\", \\\"{x:1307,y:789,t:1528143790648};\\\", \\\"{x:1297,y:793,t:1528143790664};\\\", \\\"{x:1291,y:795,t:1528143790681};\\\", \\\"{x:1289,y:797,t:1528143790698};\\\", \\\"{x:1275,y:800,t:1528143790714};\\\", \\\"{x:1259,y:800,t:1528143790731};\\\", \\\"{x:1246,y:800,t:1528143790748};\\\", \\\"{x:1237,y:800,t:1528143790764};\\\", \\\"{x:1234,y:800,t:1528143790781};\\\", \\\"{x:1233,y:800,t:1528143790894};\\\", \\\"{x:1232,y:802,t:1528143790901};\\\", \\\"{x:1232,y:804,t:1528143790914};\\\", \\\"{x:1230,y:808,t:1528143790931};\\\", \\\"{x:1229,y:814,t:1528143790948};\\\", \\\"{x:1229,y:817,t:1528143790964};\\\", \\\"{x:1227,y:821,t:1528143790981};\\\", \\\"{x:1226,y:823,t:1528143790998};\\\", \\\"{x:1226,y:824,t:1528143791021};\\\", \\\"{x:1225,y:824,t:1528143791061};\\\", \\\"{x:1227,y:829,t:1528143795006};\\\", \\\"{x:1228,y:832,t:1528143795016};\\\", \\\"{x:1228,y:835,t:1528143795033};\\\", \\\"{x:1230,y:840,t:1528143795050};\\\", \\\"{x:1230,y:842,t:1528143795066};\\\", \\\"{x:1230,y:844,t:1528143795083};\\\", \\\"{x:1230,y:845,t:1528143795100};\\\", \\\"{x:1231,y:846,t:1528143795118};\\\", \\\"{x:1225,y:844,t:1528143795998};\\\", \\\"{x:1222,y:843,t:1528143796005};\\\", \\\"{x:1221,y:843,t:1528143796022};\\\", \\\"{x:1221,y:842,t:1528143796033};\\\", \\\"{x:1220,y:841,t:1528143796050};\\\", \\\"{x:1220,y:844,t:1528143799878};\\\", \\\"{x:1222,y:846,t:1528143799885};\\\", \\\"{x:1222,y:847,t:1528143799910};\\\", \\\"{x:1223,y:848,t:1528143799925};\\\", \\\"{x:1223,y:847,t:1528143800438};\\\", \\\"{x:1217,y:841,t:1528143800453};\\\", \\\"{x:1216,y:836,t:1528143800469};\\\", \\\"{x:1215,y:835,t:1528143800486};\\\", \\\"{x:1215,y:834,t:1528143800502};\\\", \\\"{x:1215,y:833,t:1528143800757};\\\", \\\"{x:1220,y:828,t:1528143800770};\\\", \\\"{x:1224,y:825,t:1528143800787};\\\", \\\"{x:1226,y:824,t:1528143800802};\\\", \\\"{x:1226,y:823,t:1528143800819};\\\", \\\"{x:1229,y:821,t:1528143800837};\\\", \\\"{x:1231,y:820,t:1528143800853};\\\", \\\"{x:1235,y:818,t:1528143800869};\\\", \\\"{x:1236,y:817,t:1528143800886};\\\", \\\"{x:1237,y:817,t:1528143800902};\\\", \\\"{x:1238,y:815,t:1528143800919};\\\", \\\"{x:1240,y:813,t:1528143800936};\\\", \\\"{x:1242,y:811,t:1528143800952};\\\", \\\"{x:1242,y:810,t:1528143800969};\\\", \\\"{x:1244,y:807,t:1528143800986};\\\", \\\"{x:1244,y:806,t:1528143801002};\\\", \\\"{x:1245,y:805,t:1528143801020};\\\", \\\"{x:1246,y:804,t:1528143801036};\\\", \\\"{x:1246,y:803,t:1528143801052};\\\", \\\"{x:1242,y:807,t:1528143803134};\\\", \\\"{x:1236,y:813,t:1528143803141};\\\", \\\"{x:1233,y:817,t:1528143803154};\\\", \\\"{x:1227,y:821,t:1528143803171};\\\", \\\"{x:1223,y:824,t:1528143803188};\\\", \\\"{x:1221,y:827,t:1528143803203};\\\", \\\"{x:1220,y:828,t:1528143803221};\\\", \\\"{x:1227,y:821,t:1528143803566};\\\", \\\"{x:1231,y:815,t:1528143803573};\\\", \\\"{x:1236,y:807,t:1528143803587};\\\", \\\"{x:1247,y:794,t:1528143803605};\\\", \\\"{x:1256,y:781,t:1528143803621};\\\", \\\"{x:1261,y:774,t:1528143803637};\\\", \\\"{x:1263,y:772,t:1528143803655};\\\", \\\"{x:1263,y:776,t:1528143804164};\\\", \\\"{x:1255,y:794,t:1528143804172};\\\", \\\"{x:1249,y:807,t:1528143804187};\\\", \\\"{x:1237,y:825,t:1528143804204};\\\", \\\"{x:1221,y:847,t:1528143804220};\\\", \\\"{x:1217,y:851,t:1528143804237};\\\", \\\"{x:1215,y:853,t:1528143804254};\\\", \\\"{x:1215,y:852,t:1528143806845};\\\", \\\"{x:1215,y:850,t:1528143806856};\\\", \\\"{x:1215,y:847,t:1528143806872};\\\", \\\"{x:1215,y:845,t:1528143806889};\\\", \\\"{x:1216,y:843,t:1528143806906};\\\", \\\"{x:1216,y:842,t:1528143806949};\\\", \\\"{x:1216,y:841,t:1528143806965};\\\", \\\"{x:1220,y:841,t:1528143813516};\\\", \\\"{x:1231,y:847,t:1528143813525};\\\", \\\"{x:1239,y:852,t:1528143813542};\\\", \\\"{x:1243,y:855,t:1528143813558};\\\", \\\"{x:1247,y:859,t:1528143813576};\\\", \\\"{x:1249,y:861,t:1528143813592};\\\", \\\"{x:1249,y:862,t:1528143813608};\\\", \\\"{x:1249,y:863,t:1528143813626};\\\", \\\"{x:1250,y:864,t:1528143813653};\\\", \\\"{x:1247,y:864,t:1528143814069};\\\", \\\"{x:1245,y:864,t:1528143814077};\\\", \\\"{x:1243,y:864,t:1528143814093};\\\", \\\"{x:1241,y:863,t:1528143814149};\\\", \\\"{x:1240,y:863,t:1528143814181};\\\", \\\"{x:1239,y:862,t:1528143814192};\\\", \\\"{x:1238,y:862,t:1528143814213};\\\", \\\"{x:1237,y:862,t:1528143814254};\\\", \\\"{x:1236,y:862,t:1528143814437};\\\", \\\"{x:1235,y:862,t:1528143814805};\\\", \\\"{x:1234,y:862,t:1528143814813};\\\", \\\"{x:1222,y:862,t:1528143814826};\\\", \\\"{x:1118,y:825,t:1528143814843};\\\", \\\"{x:966,y:751,t:1528143814860};\\\", \\\"{x:633,y:584,t:1528143814878};\\\", \\\"{x:398,y:479,t:1528143814892};\\\", \\\"{x:213,y:391,t:1528143814909};\\\", \\\"{x:113,y:344,t:1528143814929};\\\", \\\"{x:90,y:321,t:1528143814946};\\\", \\\"{x:89,y:318,t:1528143814963};\\\", \\\"{x:88,y:317,t:1528143814979};\\\", \\\"{x:88,y:316,t:1528143814996};\\\", \\\"{x:88,y:315,t:1528143815020};\\\", \\\"{x:89,y:327,t:1528143815150};\\\", \\\"{x:97,y:352,t:1528143815164};\\\", \\\"{x:130,y:421,t:1528143815180};\\\", \\\"{x:186,y:505,t:1528143815198};\\\", \\\"{x:214,y:532,t:1528143815214};\\\", \\\"{x:216,y:534,t:1528143815230};\\\", \\\"{x:217,y:534,t:1528143815246};\\\", \\\"{x:219,y:535,t:1528143815263};\\\", \\\"{x:221,y:536,t:1528143815280};\\\", \\\"{x:223,y:537,t:1528143815297};\\\", \\\"{x:226,y:538,t:1528143815313};\\\", \\\"{x:226,y:539,t:1528143815330};\\\", \\\"{x:227,y:541,t:1528143815348};\\\", \\\"{x:229,y:547,t:1528143815363};\\\", \\\"{x:232,y:554,t:1528143815380};\\\", \\\"{x:235,y:559,t:1528143815398};\\\", \\\"{x:236,y:565,t:1528143815416};\\\", \\\"{x:239,y:568,t:1528143815429};\\\", \\\"{x:239,y:570,t:1528143815446};\\\", \\\"{x:241,y:572,t:1528143815463};\\\", \\\"{x:241,y:573,t:1528143815479};\\\", \\\"{x:242,y:574,t:1528143815516};\\\", \\\"{x:242,y:576,t:1528143815572};\\\", \\\"{x:240,y:580,t:1528143815580};\\\", \\\"{x:240,y:583,t:1528143815596};\\\", \\\"{x:239,y:587,t:1528143815613};\\\", \\\"{x:236,y:592,t:1528143815629};\\\", \\\"{x:232,y:602,t:1528143815648};\\\", \\\"{x:231,y:613,t:1528143815663};\\\", \\\"{x:231,y:624,t:1528143815680};\\\", \\\"{x:233,y:635,t:1528143815698};\\\", \\\"{x:239,y:637,t:1528143815715};\\\", \\\"{x:246,y:635,t:1528143815730};\\\", \\\"{x:260,y:624,t:1528143815747};\\\", \\\"{x:266,y:613,t:1528143815763};\\\", \\\"{x:275,y:592,t:1528143815782};\\\", \\\"{x:280,y:578,t:1528143815797};\\\", \\\"{x:280,y:573,t:1528143815814};\\\", \\\"{x:281,y:565,t:1528143815831};\\\", \\\"{x:282,y:560,t:1528143815854};\\\", \\\"{x:283,y:554,t:1528143815864};\\\", \\\"{x:284,y:547,t:1528143815880};\\\", \\\"{x:287,y:534,t:1528143815898};\\\", \\\"{x:290,y:527,t:1528143815913};\\\", \\\"{x:292,y:518,t:1528143815931};\\\", \\\"{x:294,y:514,t:1528143815947};\\\", \\\"{x:297,y:508,t:1528143815964};\\\", \\\"{x:299,y:504,t:1528143815980};\\\", \\\"{x:300,y:500,t:1528143815998};\\\", \\\"{x:302,y:498,t:1528143816015};\\\", \\\"{x:303,y:497,t:1528143816030};\\\", \\\"{x:303,y:496,t:1528143816047};\\\", \\\"{x:304,y:496,t:1528143816068};\\\", \\\"{x:307,y:496,t:1528143816081};\\\", \\\"{x:311,y:496,t:1528143816097};\\\", \\\"{x:317,y:499,t:1528143816115};\\\", \\\"{x:331,y:515,t:1528143816131};\\\", \\\"{x:344,y:529,t:1528143816149};\\\", \\\"{x:354,y:537,t:1528143816164};\\\", \\\"{x:356,y:537,t:1528143816180};\\\", \\\"{x:358,y:537,t:1528143816236};\\\", \\\"{x:363,y:536,t:1528143816247};\\\", \\\"{x:366,y:534,t:1528143816264};\\\", \\\"{x:369,y:529,t:1528143816280};\\\", \\\"{x:375,y:521,t:1528143816297};\\\", \\\"{x:377,y:515,t:1528143816315};\\\", \\\"{x:379,y:511,t:1528143816330};\\\", \\\"{x:379,y:510,t:1528143816347};\\\", \\\"{x:379,y:511,t:1528143816660};\\\", \\\"{x:377,y:517,t:1528143816668};\\\", \\\"{x:374,y:523,t:1528143816682};\\\", \\\"{x:372,y:532,t:1528143816697};\\\", \\\"{x:369,y:543,t:1528143816714};\\\", \\\"{x:369,y:547,t:1528143816731};\\\", \\\"{x:371,y:553,t:1528143816751};\\\", \\\"{x:374,y:562,t:1528143816768};\\\", \\\"{x:382,y:576,t:1528143816785};\\\", \\\"{x:421,y:619,t:1528143816802};\\\", \\\"{x:481,y:666,t:1528143816819};\\\", \\\"{x:562,y:727,t:1528143816836};\\\", \\\"{x:660,y:796,t:1528143816851};\\\", \\\"{x:731,y:843,t:1528143816868};\\\", \\\"{x:761,y:869,t:1528143816885};\\\", \\\"{x:763,y:875,t:1528143816901};\\\", \\\"{x:762,y:875,t:1528143816928};\\\", \\\"{x:760,y:875,t:1528143816936};\\\", \\\"{x:756,y:875,t:1528143816951};\\\", \\\"{x:752,y:872,t:1528143816968};\\\", \\\"{x:750,y:871,t:1528143816985};\\\", \\\"{x:749,y:871,t:1528143817137};\\\", \\\"{x:747,y:871,t:1528143817152};\\\", \\\"{x:745,y:871,t:1528143817168};\\\", \\\"{x:744,y:872,t:1528143817185};\\\", \\\"{x:743,y:872,t:1528143817203};\\\", \\\"{x:742,y:873,t:1528143817232};\\\", \\\"{x:740,y:873,t:1528143817305};\\\", \\\"{x:739,y:872,t:1528143817328};\\\", \\\"{x:738,y:872,t:1528143817385};\\\", \\\"{x:737,y:871,t:1528143817403};\\\", \\\"{x:735,y:871,t:1528143817456};\\\", \\\"{x:734,y:870,t:1528143817469};\\\", \\\"{x:733,y:869,t:1528143817488};\\\", \\\"{x:732,y:869,t:1528143817513};\\\", \\\"{x:732,y:868,t:1528143817520};\\\", \\\"{x:731,y:868,t:1528143817577};\\\", \\\"{x:730,y:868,t:1528143817689};\\\", \\\"{x:729,y:868,t:1528143817712};\\\", \\\"{x:728,y:867,t:1528143817785};\\\", \\\"{x:727,y:867,t:1528143817905};\\\", \\\"{x:727,y:866,t:1528143817920};\\\", \\\"{x:723,y:865,t:1528143817935};\\\", \\\"{x:717,y:863,t:1528143817953};\\\", \\\"{x:715,y:862,t:1528143817970};\\\", \\\"{x:714,y:861,t:1528143817985};\\\", \\\"{x:712,y:861,t:1528143818002};\\\", \\\"{x:710,y:859,t:1528143818019};\\\", \\\"{x:709,y:857,t:1528143818037};\\\", \\\"{x:708,y:855,t:1528143818052};\\\", \\\"{x:708,y:854,t:1528143818069};\\\", \\\"{x:707,y:853,t:1528143818086};\\\", \\\"{x:706,y:852,t:1528143818102};\\\", \\\"{x:705,y:852,t:1528143818119};\\\", \\\"{x:704,y:851,t:1528143818136};\\\", \\\"{x:702,y:850,t:1528143818152};\\\", \\\"{x:701,y:849,t:1528143818169};\\\", \\\"{x:700,y:849,t:1528143818208};\\\", \\\"{x:699,y:849,t:1528143818305};\\\", \\\"{x:697,y:849,t:1528143818320};\\\", \\\"{x:690,y:846,t:1528143818337};\\\", \\\"{x:687,y:845,t:1528143818353};\\\", \\\"{x:685,y:844,t:1528143818369};\\\", \\\"{x:684,y:844,t:1528143818386};\\\", \\\"{x:683,y:843,t:1528143818403};\\\", \\\"{x:678,y:841,t:1528143818419};\\\", \\\"{x:669,y:833,t:1528143818436};\\\", \\\"{x:663,y:827,t:1528143818452};\\\", \\\"{x:659,y:822,t:1528143818470};\\\", \\\"{x:654,y:817,t:1528143818487};\\\", \\\"{x:644,y:807,t:1528143818504};\\\", \\\"{x:623,y:793,t:1528143818519};\\\", \\\"{x:597,y:775,t:1528143818537};\\\", \\\"{x:578,y:765,t:1528143818553};\\\", \\\"{x:567,y:759,t:1528143818569};\\\", \\\"{x:563,y:757,t:1528143818587};\\\", \\\"{x:563,y:756,t:1528143818617};\\\", \\\"{x:562,y:756,t:1528143818641};\\\", \\\"{x:561,y:755,t:1528143818904};\\\", \\\"{x:560,y:750,t:1528143818920};\\\", \\\"{x:555,y:739,t:1528143818936};\\\", \\\"{x:553,y:735,t:1528143818953};\\\", \\\"{x:552,y:734,t:1528143818984};\\\" ] }, { \\\"rt\\\": 12775, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 916891, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"VVH1B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-2-J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:552,y:733,t:1528143823281};\\\", \\\"{x:579,y:723,t:1528143823290};\\\", \\\"{x:613,y:718,t:1528143823306};\\\", \\\"{x:638,y:714,t:1528143823323};\\\", \\\"{x:650,y:712,t:1528143823340};\\\", \\\"{x:662,y:709,t:1528143823356};\\\", \\\"{x:677,y:709,t:1528143823373};\\\", \\\"{x:690,y:709,t:1528143823390};\\\", \\\"{x:704,y:712,t:1528143823408};\\\", \\\"{x:721,y:718,t:1528143823423};\\\", \\\"{x:729,y:721,t:1528143823440};\\\", \\\"{x:731,y:721,t:1528143823457};\\\", \\\"{x:731,y:723,t:1528143823528};\\\", \\\"{x:736,y:726,t:1528143823540};\\\", \\\"{x:755,y:741,t:1528143823558};\\\", \\\"{x:789,y:760,t:1528143823575};\\\", \\\"{x:864,y:784,t:1528143823591};\\\", \\\"{x:961,y:811,t:1528143823607};\\\", \\\"{x:1033,y:827,t:1528143823625};\\\", \\\"{x:1043,y:827,t:1528143823641};\\\", \\\"{x:1048,y:827,t:1528143823658};\\\", \\\"{x:1059,y:822,t:1528143823675};\\\", \\\"{x:1061,y:820,t:1528143823692};\\\", \\\"{x:1065,y:819,t:1528143823708};\\\", \\\"{x:1082,y:810,t:1528143823725};\\\", \\\"{x:1107,y:805,t:1528143823742};\\\", \\\"{x:1146,y:802,t:1528143823758};\\\", \\\"{x:1173,y:802,t:1528143823775};\\\", \\\"{x:1195,y:802,t:1528143823792};\\\", \\\"{x:1217,y:800,t:1528143823808};\\\", \\\"{x:1229,y:802,t:1528143823825};\\\", \\\"{x:1232,y:803,t:1528143823842};\\\", \\\"{x:1233,y:804,t:1528143823872};\\\", \\\"{x:1233,y:805,t:1528143823888};\\\", \\\"{x:1233,y:808,t:1528143823897};\\\", \\\"{x:1233,y:812,t:1528143823909};\\\", \\\"{x:1233,y:824,t:1528143823925};\\\", \\\"{x:1233,y:833,t:1528143823942};\\\", \\\"{x:1233,y:837,t:1528143823958};\\\", \\\"{x:1233,y:838,t:1528143823975};\\\", \\\"{x:1233,y:839,t:1528143824073};\\\", \\\"{x:1233,y:840,t:1528143824129};\\\", \\\"{x:1232,y:840,t:1528143824161};\\\", \\\"{x:1229,y:841,t:1528143824176};\\\", \\\"{x:1225,y:841,t:1528143824193};\\\", \\\"{x:1223,y:841,t:1528143824209};\\\", \\\"{x:1222,y:841,t:1528143824226};\\\", \\\"{x:1221,y:841,t:1528143824265};\\\", \\\"{x:1220,y:841,t:1528143824297};\\\", \\\"{x:1219,y:841,t:1528143824689};\\\", \\\"{x:1218,y:841,t:1528143826017};\\\", \\\"{x:1213,y:838,t:1528143826609};\\\", \\\"{x:1211,y:833,t:1528143826619};\\\", \\\"{x:1207,y:829,t:1528143826632};\\\", \\\"{x:1205,y:826,t:1528143826648};\\\", \\\"{x:1202,y:824,t:1528143826665};\\\", \\\"{x:1201,y:823,t:1528143826682};\\\", \\\"{x:1200,y:819,t:1528143826857};\\\", \\\"{x:1197,y:811,t:1528143826866};\\\", \\\"{x:1188,y:796,t:1528143826881};\\\", \\\"{x:1181,y:785,t:1528143826899};\\\", \\\"{x:1178,y:775,t:1528143826915};\\\", \\\"{x:1176,y:772,t:1528143826933};\\\", \\\"{x:1175,y:771,t:1528143826948};\\\", \\\"{x:1175,y:770,t:1528143826966};\\\", \\\"{x:1175,y:769,t:1528143826982};\\\", \\\"{x:1175,y:768,t:1528143827041};\\\", \\\"{x:1171,y:768,t:1528143828649};\\\", \\\"{x:1147,y:753,t:1528143828656};\\\", \\\"{x:1120,y:738,t:1528143828670};\\\", \\\"{x:1075,y:706,t:1528143828687};\\\", \\\"{x:1027,y:682,t:1528143828703};\\\", \\\"{x:991,y:667,t:1528143828722};\\\", \\\"{x:986,y:666,t:1528143828737};\\\", \\\"{x:982,y:664,t:1528143828754};\\\", \\\"{x:968,y:661,t:1528143828770};\\\", \\\"{x:948,y:655,t:1528143828787};\\\", \\\"{x:897,y:639,t:1528143828804};\\\", \\\"{x:819,y:616,t:1528143828822};\\\", \\\"{x:728,y:591,t:1528143828837};\\\", \\\"{x:634,y:564,t:1528143828854};\\\", \\\"{x:518,y:534,t:1528143828878};\\\", \\\"{x:459,y:516,t:1528143828895};\\\", \\\"{x:406,y:501,t:1528143828911};\\\", \\\"{x:364,y:492,t:1528143828928};\\\", \\\"{x:293,y:477,t:1528143828945};\\\", \\\"{x:221,y:469,t:1528143828961};\\\", \\\"{x:176,y:454,t:1528143828977};\\\", \\\"{x:160,y:445,t:1528143828994};\\\", \\\"{x:153,y:443,t:1528143829010};\\\", \\\"{x:152,y:443,t:1528143829040};\\\", \\\"{x:148,y:445,t:1528143829177};\\\", \\\"{x:145,y:450,t:1528143829185};\\\", \\\"{x:143,y:453,t:1528143829195};\\\", \\\"{x:138,y:461,t:1528143829212};\\\", \\\"{x:136,y:467,t:1528143829228};\\\", \\\"{x:134,y:470,t:1528143829245};\\\", \\\"{x:134,y:473,t:1528143829262};\\\", \\\"{x:134,y:477,t:1528143829279};\\\", \\\"{x:134,y:479,t:1528143829295};\\\", \\\"{x:136,y:485,t:1528143829312};\\\", \\\"{x:139,y:487,t:1528143829329};\\\", \\\"{x:142,y:489,t:1528143829344};\\\", \\\"{x:146,y:490,t:1528143829361};\\\", \\\"{x:149,y:492,t:1528143829378};\\\", \\\"{x:150,y:492,t:1528143829395};\\\", \\\"{x:152,y:492,t:1528143829411};\\\", \\\"{x:153,y:493,t:1528143829428};\\\", \\\"{x:155,y:494,t:1528143829448};\\\", \\\"{x:156,y:497,t:1528143829696};\\\", \\\"{x:157,y:500,t:1528143829712};\\\", \\\"{x:157,y:502,t:1528143829729};\\\", \\\"{x:157,y:503,t:1528143829745};\\\", \\\"{x:159,y:504,t:1528143829762};\\\", \\\"{x:159,y:505,t:1528143829779};\\\", \\\"{x:159,y:506,t:1528143829795};\\\", \\\"{x:159,y:507,t:1528143831473};\\\", \\\"{x:159,y:508,t:1528143831545};\\\", \\\"{x:161,y:513,t:1528143831560};\\\", \\\"{x:168,y:526,t:1528143831571};\\\", \\\"{x:182,y:545,t:1528143831581};\\\", \\\"{x:198,y:568,t:1528143831597};\\\", \\\"{x:216,y:591,t:1528143831613};\\\", \\\"{x:227,y:607,t:1528143831630};\\\", \\\"{x:233,y:617,t:1528143831646};\\\", \\\"{x:239,y:623,t:1528143831662};\\\", \\\"{x:240,y:626,t:1528143831679};\\\", \\\"{x:241,y:628,t:1528143831696};\\\", \\\"{x:243,y:629,t:1528143831713};\\\", \\\"{x:243,y:630,t:1528143831743};\\\", \\\"{x:244,y:630,t:1528143831776};\\\", \\\"{x:244,y:632,t:1528143831801};\\\", \\\"{x:246,y:633,t:1528143831813};\\\", \\\"{x:248,y:634,t:1528143831829};\\\", \\\"{x:255,y:640,t:1528143831848};\\\", \\\"{x:272,y:652,t:1528143831863};\\\", \\\"{x:291,y:661,t:1528143831881};\\\", \\\"{x:316,y:674,t:1528143831897};\\\", \\\"{x:355,y:695,t:1528143831913};\\\", \\\"{x:382,y:707,t:1528143831929};\\\", \\\"{x:399,y:715,t:1528143831946};\\\", \\\"{x:408,y:719,t:1528143831964};\\\", \\\"{x:410,y:719,t:1528143831979};\\\", \\\"{x:412,y:720,t:1528143832073};\\\", \\\"{x:414,y:721,t:1528143832105};\\\", \\\"{x:415,y:722,t:1528143832136};\\\", \\\"{x:416,y:722,t:1528143832152};\\\", \\\"{x:418,y:723,t:1528143832163};\\\", \\\"{x:421,y:726,t:1528143832181};\\\", \\\"{x:423,y:729,t:1528143832197};\\\", \\\"{x:427,y:733,t:1528143832213};\\\", \\\"{x:430,y:736,t:1528143832230};\\\", \\\"{x:432,y:737,t:1528143832247};\\\", \\\"{x:433,y:738,t:1528143832263};\\\", \\\"{x:434,y:738,t:1528143832280};\\\", \\\"{x:436,y:739,t:1528143832297};\\\", \\\"{x:438,y:739,t:1528143832321};\\\", \\\"{x:439,y:740,t:1528143832345};\\\", \\\"{x:442,y:741,t:1528143832368};\\\", \\\"{x:443,y:742,t:1528143832409};\\\", \\\"{x:445,y:743,t:1528143832425};\\\", \\\"{x:450,y:745,t:1528143832446};\\\", \\\"{x:467,y:754,t:1528143832463};\\\", \\\"{x:484,y:760,t:1528143832481};\\\", \\\"{x:496,y:765,t:1528143832498};\\\", \\\"{x:508,y:768,t:1528143832513};\\\", \\\"{x:516,y:770,t:1528143832531};\\\", \\\"{x:519,y:771,t:1528143832546};\\\", \\\"{x:521,y:772,t:1528143832564};\\\", \\\"{x:522,y:772,t:1528143832581};\\\", \\\"{x:523,y:772,t:1528143832597};\\\", \\\"{x:524,y:772,t:1528143832616};\\\", \\\"{x:526,y:772,t:1528143832697};\\\", \\\"{x:527,y:772,t:1528143832704};\\\", \\\"{x:530,y:772,t:1528143832714};\\\", \\\"{x:534,y:772,t:1528143832731};\\\", \\\"{x:538,y:772,t:1528143832749};\\\", \\\"{x:543,y:772,t:1528143832764};\\\", \\\"{x:545,y:773,t:1528143832781};\\\", \\\"{x:548,y:773,t:1528143832798};\\\", \\\"{x:549,y:773,t:1528143832832};\\\", \\\"{x:551,y:773,t:1528143832889};\\\", \\\"{x:552,y:773,t:1528143832905};\\\", \\\"{x:553,y:773,t:1528143832921};\\\", \\\"{x:554,y:773,t:1528143832931};\\\", \\\"{x:555,y:773,t:1528143832976};\\\", \\\"{x:556,y:773,t:1528143832984};\\\", \\\"{x:557,y:773,t:1528143832998};\\\", \\\"{x:558,y:773,t:1528143833014};\\\", \\\"{x:560,y:773,t:1528143833032};\\\", \\\"{x:563,y:772,t:1528143833049};\\\", \\\"{x:564,y:771,t:1528143833064};\\\", \\\"{x:566,y:770,t:1528143833082};\\\", \\\"{x:567,y:768,t:1528143833099};\\\", \\\"{x:568,y:768,t:1528143833115};\\\", \\\"{x:569,y:767,t:1528143833152};\\\", \\\"{x:567,y:765,t:1528143833257};\\\", \\\"{x:562,y:764,t:1528143833264};\\\", \\\"{x:555,y:760,t:1528143833281};\\\", \\\"{x:552,y:757,t:1528143833298};\\\", \\\"{x:549,y:753,t:1528143833316};\\\", \\\"{x:546,y:749,t:1528143833331};\\\", \\\"{x:542,y:745,t:1528143833348};\\\", \\\"{x:541,y:743,t:1528143833364};\\\", \\\"{x:540,y:742,t:1528143833382};\\\", \\\"{x:539,y:742,t:1528143834712};\\\" ] }, { \\\"rt\\\": 13846, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 932099, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"VVH1B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:538,y:742,t:1528143841625};\\\", \\\"{x:519,y:705,t:1528143841650};\\\", \\\"{x:483,y:647,t:1528143841660};\\\", \\\"{x:432,y:589,t:1528143841677};\\\", \\\"{x:413,y:564,t:1528143841704};\\\", \\\"{x:408,y:556,t:1528143841721};\\\", \\\"{x:403,y:549,t:1528143841738};\\\", \\\"{x:398,y:543,t:1528143841754};\\\", \\\"{x:392,y:533,t:1528143841771};\\\", \\\"{x:387,y:525,t:1528143841788};\\\", \\\"{x:382,y:520,t:1528143841804};\\\", \\\"{x:381,y:519,t:1528143841820};\\\", \\\"{x:379,y:519,t:1528143841864};\\\", \\\"{x:376,y:519,t:1528143841871};\\\", \\\"{x:366,y:522,t:1528143841888};\\\", \\\"{x:358,y:527,t:1528143841905};\\\", \\\"{x:353,y:543,t:1528143841921};\\\", \\\"{x:348,y:565,t:1528143841938};\\\", \\\"{x:344,y:585,t:1528143841955};\\\", \\\"{x:343,y:593,t:1528143841971};\\\", \\\"{x:343,y:596,t:1528143841988};\\\", \\\"{x:343,y:597,t:1528143842005};\\\", \\\"{x:342,y:598,t:1528143842113};\\\", \\\"{x:340,y:600,t:1528143842122};\\\", \\\"{x:335,y:602,t:1528143842140};\\\", \\\"{x:330,y:603,t:1528143842155};\\\", \\\"{x:320,y:604,t:1528143842171};\\\", \\\"{x:307,y:605,t:1528143842188};\\\", \\\"{x:297,y:605,t:1528143842205};\\\", \\\"{x:288,y:603,t:1528143842221};\\\", \\\"{x:281,y:597,t:1528143842238};\\\", \\\"{x:273,y:590,t:1528143842255};\\\", \\\"{x:263,y:577,t:1528143842272};\\\", \\\"{x:257,y:566,t:1528143842288};\\\", \\\"{x:252,y:555,t:1528143842306};\\\", \\\"{x:249,y:547,t:1528143842322};\\\", \\\"{x:248,y:545,t:1528143842338};\\\", \\\"{x:247,y:543,t:1528143842355};\\\", \\\"{x:246,y:542,t:1528143842375};\\\", \\\"{x:249,y:542,t:1528143842456};\\\", \\\"{x:255,y:542,t:1528143842471};\\\", \\\"{x:262,y:542,t:1528143842488};\\\", \\\"{x:270,y:544,t:1528143842505};\\\", \\\"{x:275,y:544,t:1528143842523};\\\", \\\"{x:281,y:544,t:1528143842538};\\\", \\\"{x:285,y:544,t:1528143842555};\\\", \\\"{x:293,y:542,t:1528143842572};\\\", \\\"{x:299,y:540,t:1528143842588};\\\", \\\"{x:309,y:540,t:1528143842605};\\\", \\\"{x:315,y:540,t:1528143842622};\\\", \\\"{x:323,y:540,t:1528143842638};\\\", \\\"{x:326,y:540,t:1528143842655};\\\", \\\"{x:331,y:540,t:1528143842672};\\\", \\\"{x:334,y:540,t:1528143842688};\\\", \\\"{x:340,y:540,t:1528143842705};\\\", \\\"{x:355,y:540,t:1528143842722};\\\", \\\"{x:379,y:541,t:1528143842739};\\\", \\\"{x:429,y:554,t:1528143842755};\\\", \\\"{x:492,y:570,t:1528143842773};\\\", \\\"{x:553,y:583,t:1528143842790};\\\", \\\"{x:578,y:586,t:1528143842804};\\\", \\\"{x:581,y:586,t:1528143842822};\\\", \\\"{x:583,y:586,t:1528143842888};\\\", \\\"{x:583,y:585,t:1528143842894};\\\", \\\"{x:584,y:583,t:1528143842911};\\\", \\\"{x:586,y:580,t:1528143842922};\\\", \\\"{x:588,y:577,t:1528143842939};\\\", \\\"{x:590,y:575,t:1528143842955};\\\", \\\"{x:593,y:572,t:1528143842973};\\\", \\\"{x:597,y:570,t:1528143842989};\\\", \\\"{x:598,y:569,t:1528143843005};\\\", \\\"{x:599,y:568,t:1528143843023};\\\", \\\"{x:601,y:568,t:1528143843072};\\\", \\\"{x:616,y:568,t:1528143843089};\\\", \\\"{x:643,y:568,t:1528143843106};\\\", \\\"{x:666,y:568,t:1528143843122};\\\", \\\"{x:680,y:569,t:1528143843139};\\\", \\\"{x:691,y:570,t:1528143843155};\\\", \\\"{x:701,y:570,t:1528143843172};\\\", \\\"{x:705,y:570,t:1528143843189};\\\", \\\"{x:708,y:570,t:1528143843206};\\\", \\\"{x:709,y:571,t:1528143843256};\\\", \\\"{x:709,y:577,t:1528143843272};\\\", \\\"{x:711,y:588,t:1528143843290};\\\", \\\"{x:711,y:597,t:1528143843307};\\\", \\\"{x:711,y:605,t:1528143843323};\\\", \\\"{x:711,y:613,t:1528143843339};\\\", \\\"{x:707,y:625,t:1528143843356};\\\", \\\"{x:700,y:635,t:1528143843372};\\\", \\\"{x:694,y:645,t:1528143843389};\\\", \\\"{x:691,y:648,t:1528143843406};\\\", \\\"{x:700,y:647,t:1528143843472};\\\", \\\"{x:713,y:644,t:1528143843489};\\\", \\\"{x:719,y:641,t:1528143843505};\\\", \\\"{x:724,y:638,t:1528143843522};\\\", \\\"{x:734,y:632,t:1528143843540};\\\", \\\"{x:740,y:629,t:1528143843556};\\\", \\\"{x:742,y:626,t:1528143843572};\\\", \\\"{x:743,y:624,t:1528143843589};\\\", \\\"{x:748,y:622,t:1528143843606};\\\", \\\"{x:756,y:619,t:1528143843623};\\\", \\\"{x:760,y:619,t:1528143843639};\\\", \\\"{x:766,y:618,t:1528143843656};\\\", \\\"{x:771,y:616,t:1528143843673};\\\", \\\"{x:779,y:614,t:1528143843689};\\\", \\\"{x:787,y:614,t:1528143843706};\\\", \\\"{x:797,y:614,t:1528143843723};\\\", \\\"{x:803,y:615,t:1528143843739};\\\", \\\"{x:813,y:615,t:1528143843756};\\\", \\\"{x:820,y:617,t:1528143843774};\\\", \\\"{x:823,y:619,t:1528143843790};\\\", \\\"{x:824,y:620,t:1528143843816};\\\", \\\"{x:825,y:620,t:1528143843831};\\\", \\\"{x:827,y:620,t:1528143843969};\\\", \\\"{x:827,y:622,t:1528143844264};\\\", \\\"{x:827,y:623,t:1528143844319};\\\", \\\"{x:823,y:627,t:1528143847114};\\\", \\\"{x:813,y:634,t:1528143847126};\\\", \\\"{x:790,y:646,t:1528143847142};\\\", \\\"{x:757,y:664,t:1528143847159};\\\", \\\"{x:742,y:672,t:1528143847175};\\\", \\\"{x:733,y:676,t:1528143847192};\\\", \\\"{x:728,y:679,t:1528143847209};\\\", \\\"{x:727,y:680,t:1528143847225};\\\", \\\"{x:726,y:680,t:1528143847242};\\\", \\\"{x:725,y:681,t:1528143847263};\\\", \\\"{x:725,y:682,t:1528143847279};\\\", \\\"{x:724,y:682,t:1528143847328};\\\", \\\"{x:723,y:682,t:1528143847342};\\\", \\\"{x:716,y:684,t:1528143847359};\\\", \\\"{x:708,y:686,t:1528143847376};\\\", \\\"{x:692,y:690,t:1528143847393};\\\", \\\"{x:662,y:699,t:1528143847410};\\\", \\\"{x:629,y:714,t:1528143847426};\\\", \\\"{x:594,y:726,t:1528143847443};\\\", \\\"{x:572,y:735,t:1528143847460};\\\", \\\"{x:556,y:740,t:1528143847477};\\\", \\\"{x:548,y:742,t:1528143847492};\\\", \\\"{x:546,y:742,t:1528143847510};\\\", \\\"{x:544,y:742,t:1528143847525};\\\" ] }, { \\\"rt\\\": 17425, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 950850, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"VVH1B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:544,y:743,t:1528143850185};\\\", \\\"{x:540,y:730,t:1528143862296};\\\", \\\"{x:526,y:698,t:1528143862305};\\\", \\\"{x:499,y:650,t:1528143862355};\\\", \\\"{x:495,y:641,t:1528143862371};\\\", \\\"{x:491,y:634,t:1528143862388};\\\", \\\"{x:487,y:628,t:1528143862404};\\\", \\\"{x:479,y:617,t:1528143862420};\\\", \\\"{x:468,y:601,t:1528143862437};\\\", \\\"{x:453,y:588,t:1528143862454};\\\", \\\"{x:440,y:580,t:1528143862471};\\\", \\\"{x:438,y:579,t:1528143862487};\\\", \\\"{x:437,y:579,t:1528143862511};\\\", \\\"{x:436,y:579,t:1528143862551};\\\", \\\"{x:435,y:579,t:1528143862560};\\\", \\\"{x:433,y:579,t:1528143862575};\\\", \\\"{x:430,y:578,t:1528143862587};\\\", \\\"{x:425,y:576,t:1528143862604};\\\", \\\"{x:421,y:574,t:1528143862621};\\\", \\\"{x:418,y:572,t:1528143862638};\\\", \\\"{x:416,y:571,t:1528143862655};\\\", \\\"{x:414,y:571,t:1528143862670};\\\", \\\"{x:412,y:570,t:1528143862688};\\\", \\\"{x:404,y:567,t:1528143862704};\\\", \\\"{x:388,y:560,t:1528143862722};\\\", \\\"{x:364,y:551,t:1528143862738};\\\", \\\"{x:341,y:547,t:1528143862755};\\\", \\\"{x:315,y:545,t:1528143862771};\\\", \\\"{x:291,y:540,t:1528143862788};\\\", \\\"{x:278,y:539,t:1528143862805};\\\", \\\"{x:270,y:536,t:1528143862822};\\\", \\\"{x:268,y:536,t:1528143862838};\\\", \\\"{x:267,y:536,t:1528143862855};\\\", \\\"{x:266,y:536,t:1528143862984};\\\", \\\"{x:263,y:536,t:1528143863000};\\\", \\\"{x:255,y:536,t:1528143863008};\\\", \\\"{x:244,y:536,t:1528143863023};\\\", \\\"{x:202,y:536,t:1528143863040};\\\", \\\"{x:189,y:536,t:1528143863057};\\\", \\\"{x:181,y:536,t:1528143863071};\\\", \\\"{x:179,y:536,t:1528143863088};\\\", \\\"{x:178,y:536,t:1528143863105};\\\", \\\"{x:178,y:535,t:1528143863239};\\\", \\\"{x:178,y:535,t:1528143863364};\\\", \\\"{x:185,y:535,t:1528143863535};\\\", \\\"{x:192,y:534,t:1528143863543};\\\", \\\"{x:202,y:531,t:1528143863555};\\\", \\\"{x:224,y:526,t:1528143863572};\\\", \\\"{x:246,y:525,t:1528143863588};\\\", \\\"{x:261,y:523,t:1528143863606};\\\", \\\"{x:278,y:523,t:1528143863622};\\\", \\\"{x:287,y:520,t:1528143863638};\\\", \\\"{x:297,y:520,t:1528143863656};\\\", \\\"{x:303,y:516,t:1528143863674};\\\", \\\"{x:308,y:516,t:1528143863689};\\\", \\\"{x:318,y:515,t:1528143863705};\\\", \\\"{x:334,y:512,t:1528143863721};\\\", \\\"{x:347,y:512,t:1528143863739};\\\", \\\"{x:359,y:512,t:1528143863755};\\\", \\\"{x:368,y:512,t:1528143863771};\\\", \\\"{x:370,y:512,t:1528143863789};\\\", \\\"{x:372,y:512,t:1528143863804};\\\", \\\"{x:373,y:512,t:1528143863822};\\\", \\\"{x:374,y:512,t:1528143863847};\\\", \\\"{x:375,y:513,t:1528143863864};\\\", \\\"{x:378,y:515,t:1528143863879};\\\", \\\"{x:380,y:518,t:1528143863896};\\\", \\\"{x:382,y:519,t:1528143863905};\\\", \\\"{x:387,y:520,t:1528143863923};\\\", \\\"{x:392,y:520,t:1528143863939};\\\", \\\"{x:400,y:522,t:1528143863955};\\\", \\\"{x:410,y:522,t:1528143863972};\\\", \\\"{x:422,y:522,t:1528143863989};\\\", \\\"{x:435,y:523,t:1528143864005};\\\", \\\"{x:461,y:526,t:1528143864023};\\\", \\\"{x:483,y:529,t:1528143864039};\\\", \\\"{x:490,y:528,t:1528143864055};\\\", \\\"{x:497,y:527,t:1528143864072};\\\", \\\"{x:503,y:526,t:1528143864089};\\\", \\\"{x:511,y:526,t:1528143864106};\\\", \\\"{x:517,y:525,t:1528143864122};\\\", \\\"{x:519,y:525,t:1528143864138};\\\", \\\"{x:525,y:525,t:1528143864156};\\\", \\\"{x:529,y:525,t:1528143864172};\\\", \\\"{x:537,y:525,t:1528143864189};\\\", \\\"{x:546,y:525,t:1528143864206};\\\", \\\"{x:551,y:525,t:1528143864222};\\\", \\\"{x:558,y:525,t:1528143864239};\\\", \\\"{x:563,y:526,t:1528143864256};\\\", \\\"{x:566,y:531,t:1528143864271};\\\", \\\"{x:574,y:536,t:1528143864289};\\\", \\\"{x:580,y:546,t:1528143864306};\\\", \\\"{x:590,y:561,t:1528143864323};\\\", \\\"{x:601,y:576,t:1528143864339};\\\", \\\"{x:613,y:585,t:1528143864355};\\\", \\\"{x:629,y:595,t:1528143864373};\\\", \\\"{x:647,y:604,t:1528143864389};\\\", \\\"{x:662,y:606,t:1528143864406};\\\", \\\"{x:677,y:607,t:1528143864422};\\\", \\\"{x:702,y:605,t:1528143864439};\\\", \\\"{x:729,y:594,t:1528143864456};\\\", \\\"{x:750,y:581,t:1528143864474};\\\", \\\"{x:771,y:566,t:1528143864489};\\\", \\\"{x:790,y:552,t:1528143864506};\\\", \\\"{x:803,y:541,t:1528143864524};\\\", \\\"{x:811,y:532,t:1528143864538};\\\", \\\"{x:817,y:526,t:1528143864556};\\\", \\\"{x:819,y:523,t:1528143864574};\\\", \\\"{x:820,y:518,t:1528143864589};\\\", \\\"{x:820,y:514,t:1528143864606};\\\", \\\"{x:820,y:509,t:1528143864623};\\\", \\\"{x:820,y:507,t:1528143864639};\\\", \\\"{x:820,y:506,t:1528143864760};\\\", \\\"{x:821,y:505,t:1528143864784};\\\", \\\"{x:822,y:505,t:1528143864800};\\\", \\\"{x:818,y:508,t:1528143864951};\\\", \\\"{x:815,y:516,t:1528143864959};\\\", \\\"{x:812,y:524,t:1528143864974};\\\", \\\"{x:802,y:539,t:1528143864991};\\\", \\\"{x:792,y:556,t:1528143865007};\\\", \\\"{x:776,y:584,t:1528143865023};\\\", \\\"{x:761,y:602,t:1528143865041};\\\", \\\"{x:744,y:621,t:1528143865056};\\\", \\\"{x:728,y:639,t:1528143865073};\\\", \\\"{x:713,y:650,t:1528143865090};\\\", \\\"{x:698,y:663,t:1528143865106};\\\", \\\"{x:681,y:679,t:1528143865124};\\\", \\\"{x:668,y:700,t:1528143865141};\\\", \\\"{x:652,y:722,t:1528143865156};\\\", \\\"{x:636,y:741,t:1528143865173};\\\", \\\"{x:625,y:756,t:1528143865190};\\\", \\\"{x:621,y:761,t:1528143865206};\\\", \\\"{x:617,y:766,t:1528143865223};\\\", \\\"{x:617,y:767,t:1528143865248};\\\", \\\"{x:612,y:766,t:1528143865384};\\\", \\\"{x:608,y:765,t:1528143865392};\\\", \\\"{x:605,y:764,t:1528143865406};\\\", \\\"{x:601,y:763,t:1528143865423};\\\", \\\"{x:600,y:763,t:1528143865448};\\\", \\\"{x:599,y:763,t:1528143865480};\\\", \\\"{x:598,y:762,t:1528143865584};\\\", \\\"{x:597,y:760,t:1528143865625};\\\", \\\"{x:596,y:760,t:1528143865673};\\\", \\\"{x:594,y:759,t:1528143865690};\\\", \\\"{x:589,y:757,t:1528143865708};\\\", \\\"{x:587,y:752,t:1528143865725};\\\", \\\"{x:596,y:723,t:1528143865741};\\\", \\\"{x:610,y:705,t:1528143865757};\\\", \\\"{x:629,y:690,t:1528143865773};\\\", \\\"{x:647,y:675,t:1528143865791};\\\", \\\"{x:671,y:656,t:1528143865808};\\\", \\\"{x:692,y:644,t:1528143865824};\\\", \\\"{x:720,y:632,t:1528143865840};\\\", \\\"{x:749,y:621,t:1528143865859};\\\", \\\"{x:773,y:610,t:1528143865873};\\\", \\\"{x:784,y:604,t:1528143865889};\\\", \\\"{x:791,y:598,t:1528143865907};\\\", \\\"{x:796,y:595,t:1528143865924};\\\", \\\"{x:799,y:592,t:1528143865941};\\\", \\\"{x:803,y:589,t:1528143865957};\\\", \\\"{x:805,y:587,t:1528143865974};\\\", \\\"{x:808,y:582,t:1528143865990};\\\", \\\"{x:811,y:575,t:1528143866007};\\\", \\\"{x:815,y:570,t:1528143866024};\\\", \\\"{x:816,y:560,t:1528143866041};\\\", \\\"{x:820,y:550,t:1528143866058};\\\", \\\"{x:824,y:541,t:1528143866074};\\\", \\\"{x:826,y:534,t:1528143866090};\\\", \\\"{x:830,y:524,t:1528143866107};\\\", \\\"{x:834,y:516,t:1528143866124};\\\", \\\"{x:836,y:513,t:1528143866140};\\\", \\\"{x:836,y:512,t:1528143866157};\\\", \\\"{x:836,y:511,t:1528143866174};\\\", \\\"{x:836,y:510,t:1528143866191};\\\", \\\"{x:831,y:513,t:1528143866447};\\\", \\\"{x:819,y:519,t:1528143866457};\\\", \\\"{x:794,y:540,t:1528143866474};\\\", \\\"{x:753,y:572,t:1528143866491};\\\", \\\"{x:719,y:609,t:1528143866507};\\\", \\\"{x:693,y:642,t:1528143866524};\\\", \\\"{x:678,y:662,t:1528143866541};\\\", \\\"{x:658,y:692,t:1528143866557};\\\", \\\"{x:643,y:714,t:1528143866574};\\\", \\\"{x:633,y:731,t:1528143866591};\\\", \\\"{x:632,y:735,t:1528143866607};\\\", \\\"{x:629,y:738,t:1528143866808};\\\", \\\"{x:611,y:754,t:1528143866825};\\\", \\\"{x:605,y:756,t:1528143866842};\\\", \\\"{x:603,y:756,t:1528143866905};\\\", \\\"{x:601,y:756,t:1528143866911};\\\", \\\"{x:597,y:754,t:1528143866924};\\\", \\\"{x:588,y:750,t:1528143866941};\\\", \\\"{x:585,y:750,t:1528143866958};\\\", \\\"{x:581,y:748,t:1528143866974};\\\", \\\"{x:577,y:746,t:1528143866991};\\\", \\\"{x:576,y:746,t:1528143867008};\\\", \\\"{x:575,y:746,t:1528143867025};\\\", \\\"{x:574,y:746,t:1528143867063};\\\", \\\"{x:569,y:744,t:1528143867288};\\\", \\\"{x:566,y:742,t:1528143867296};\\\", \\\"{x:565,y:742,t:1528143867308};\\\", \\\"{x:563,y:741,t:1528143867325};\\\", \\\"{x:560,y:740,t:1528143867341};\\\", \\\"{x:558,y:738,t:1528143867358};\\\", \\\"{x:555,y:738,t:1528143867375};\\\", \\\"{x:553,y:736,t:1528143867422};\\\" ] }, { \\\"rt\\\": 13594, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 965707, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"VVH1B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:552,y:736,t:1528143872104};\\\", \\\"{x:535,y:714,t:1528143876657};\\\", \\\"{x:480,y:655,t:1528143876667};\\\", \\\"{x:408,y:605,t:1528143876699};\\\", \\\"{x:403,y:600,t:1528143876716};\\\", \\\"{x:403,y:599,t:1528143876733};\\\", \\\"{x:403,y:592,t:1528143876749};\\\", \\\"{x:403,y:584,t:1528143876769};\\\", \\\"{x:404,y:575,t:1528143876786};\\\", \\\"{x:415,y:558,t:1528143876802};\\\", \\\"{x:436,y:546,t:1528143876819};\\\", \\\"{x:458,y:536,t:1528143876835};\\\", \\\"{x:479,y:529,t:1528143876852};\\\", \\\"{x:493,y:527,t:1528143876869};\\\", \\\"{x:509,y:527,t:1528143876886};\\\", \\\"{x:524,y:527,t:1528143876903};\\\", \\\"{x:534,y:527,t:1528143876919};\\\", \\\"{x:545,y:531,t:1528143876936};\\\", \\\"{x:556,y:534,t:1528143876952};\\\", \\\"{x:566,y:538,t:1528143876968};\\\", \\\"{x:575,y:541,t:1528143876986};\\\", \\\"{x:594,y:545,t:1528143877002};\\\", \\\"{x:615,y:549,t:1528143877019};\\\", \\\"{x:642,y:549,t:1528143877036};\\\", \\\"{x:671,y:549,t:1528143877054};\\\", \\\"{x:695,y:549,t:1528143877069};\\\", \\\"{x:716,y:545,t:1528143877086};\\\", \\\"{x:727,y:541,t:1528143877104};\\\", \\\"{x:735,y:535,t:1528143877119};\\\", \\\"{x:740,y:531,t:1528143877136};\\\", \\\"{x:742,y:529,t:1528143877153};\\\", \\\"{x:745,y:525,t:1528143877168};\\\", \\\"{x:747,y:524,t:1528143877187};\\\", \\\"{x:748,y:522,t:1528143877203};\\\", \\\"{x:749,y:522,t:1528143877235};\\\", \\\"{x:751,y:521,t:1528143877250};\\\", \\\"{x:754,y:521,t:1528143877259};\\\", \\\"{x:759,y:521,t:1528143877275};\\\", \\\"{x:768,y:521,t:1528143877286};\\\", \\\"{x:777,y:520,t:1528143877303};\\\", \\\"{x:792,y:517,t:1528143877321};\\\", \\\"{x:800,y:516,t:1528143877336};\\\", \\\"{x:801,y:516,t:1528143877353};\\\", \\\"{x:802,y:515,t:1528143877370};\\\", \\\"{x:804,y:515,t:1528143877386};\\\", \\\"{x:806,y:514,t:1528143877403};\\\", \\\"{x:807,y:513,t:1528143877420};\\\", \\\"{x:809,y:513,t:1528143877556};\\\", \\\"{x:811,y:513,t:1528143877570};\\\", \\\"{x:817,y:509,t:1528143877587};\\\", \\\"{x:822,y:506,t:1528143877603};\\\", \\\"{x:827,y:504,t:1528143877621};\\\", \\\"{x:830,y:502,t:1528143877637};\\\", \\\"{x:833,y:498,t:1528143877654};\\\", \\\"{x:834,y:498,t:1528143877930};\\\", \\\"{x:834,y:499,t:1528143877938};\\\", \\\"{x:834,y:502,t:1528143877953};\\\", \\\"{x:831,y:507,t:1528143877970};\\\", \\\"{x:819,y:521,t:1528143877987};\\\", \\\"{x:809,y:531,t:1528143878003};\\\", \\\"{x:792,y:543,t:1528143878020};\\\", \\\"{x:773,y:556,t:1528143878037};\\\", \\\"{x:753,y:568,t:1528143878054};\\\", \\\"{x:731,y:581,t:1528143878069};\\\", \\\"{x:705,y:595,t:1528143878088};\\\", \\\"{x:673,y:611,t:1528143878104};\\\", \\\"{x:621,y:632,t:1528143878120};\\\", \\\"{x:556,y:655,t:1528143878137};\\\", \\\"{x:488,y:680,t:1528143878153};\\\", \\\"{x:426,y:692,t:1528143878171};\\\", \\\"{x:413,y:695,t:1528143878186};\\\", \\\"{x:412,y:695,t:1528143878203};\\\", \\\"{x:410,y:695,t:1528143878220};\\\", \\\"{x:409,y:695,t:1528143878244};\\\", \\\"{x:406,y:695,t:1528143878254};\\\", \\\"{x:402,y:695,t:1528143878270};\\\", \\\"{x:393,y:694,t:1528143878288};\\\", \\\"{x:384,y:689,t:1528143878304};\\\", \\\"{x:379,y:688,t:1528143878320};\\\", \\\"{x:365,y:680,t:1528143878338};\\\", \\\"{x:345,y:668,t:1528143878355};\\\", \\\"{x:330,y:652,t:1528143878370};\\\", \\\"{x:295,y:627,t:1528143878388};\\\", \\\"{x:280,y:620,t:1528143878404};\\\", \\\"{x:275,y:612,t:1528143878420};\\\", \\\"{x:272,y:609,t:1528143878439};\\\", \\\"{x:270,y:606,t:1528143878454};\\\", \\\"{x:268,y:602,t:1528143878470};\\\", \\\"{x:267,y:602,t:1528143878486};\\\", \\\"{x:267,y:600,t:1528143878504};\\\", \\\"{x:265,y:600,t:1528143878562};\\\", \\\"{x:263,y:600,t:1528143878570};\\\", \\\"{x:253,y:600,t:1528143878587};\\\", \\\"{x:238,y:600,t:1528143878604};\\\", \\\"{x:221,y:598,t:1528143878620};\\\", \\\"{x:206,y:597,t:1528143878637};\\\", \\\"{x:195,y:594,t:1528143878654};\\\", \\\"{x:185,y:590,t:1528143878670};\\\", \\\"{x:175,y:583,t:1528143878687};\\\", \\\"{x:171,y:578,t:1528143878703};\\\", \\\"{x:165,y:570,t:1528143878721};\\\", \\\"{x:161,y:561,t:1528143878737};\\\", \\\"{x:160,y:555,t:1528143878754};\\\", \\\"{x:159,y:554,t:1528143878770};\\\", \\\"{x:159,y:552,t:1528143878787};\\\", \\\"{x:159,y:551,t:1528143878811};\\\", \\\"{x:159,y:549,t:1528143878819};\\\", \\\"{x:159,y:541,t:1528143878837};\\\", \\\"{x:160,y:539,t:1528143878853};\\\", \\\"{x:161,y:539,t:1528143879203};\\\", \\\"{x:166,y:540,t:1528143879210};\\\", \\\"{x:177,y:552,t:1528143879222};\\\", \\\"{x:195,y:569,t:1528143879238};\\\", \\\"{x:216,y:588,t:1528143879254};\\\", \\\"{x:240,y:606,t:1528143879272};\\\", \\\"{x:263,y:624,t:1528143879288};\\\", \\\"{x:274,y:635,t:1528143879305};\\\", \\\"{x:280,y:639,t:1528143879321};\\\", \\\"{x:283,y:644,t:1528143879338};\\\", \\\"{x:283,y:645,t:1528143879353};\\\", \\\"{x:290,y:656,t:1528143879371};\\\", \\\"{x:296,y:665,t:1528143879387};\\\", \\\"{x:299,y:673,t:1528143879405};\\\", \\\"{x:306,y:683,t:1528143879420};\\\", \\\"{x:308,y:688,t:1528143879438};\\\", \\\"{x:313,y:693,t:1528143879454};\\\", \\\"{x:314,y:695,t:1528143879471};\\\", \\\"{x:317,y:697,t:1528143879487};\\\", \\\"{x:321,y:699,t:1528143879504};\\\", \\\"{x:326,y:701,t:1528143879521};\\\", \\\"{x:333,y:703,t:1528143879537};\\\", \\\"{x:339,y:706,t:1528143879554};\\\", \\\"{x:342,y:707,t:1528143879571};\\\", \\\"{x:345,y:709,t:1528143879587};\\\", \\\"{x:348,y:710,t:1528143879604};\\\", \\\"{x:353,y:712,t:1528143879621};\\\", \\\"{x:365,y:721,t:1528143879637};\\\", \\\"{x:374,y:728,t:1528143879654};\\\", \\\"{x:378,y:729,t:1528143879670};\\\", \\\"{x:381,y:730,t:1528143879687};\\\", \\\"{x:384,y:730,t:1528143879704};\\\", \\\"{x:389,y:731,t:1528143879720};\\\", \\\"{x:395,y:731,t:1528143879737};\\\", \\\"{x:400,y:731,t:1528143879755};\\\", \\\"{x:403,y:732,t:1528143879771};\\\", \\\"{x:405,y:732,t:1528143879795};\\\", \\\"{x:406,y:732,t:1528143879804};\\\", \\\"{x:409,y:732,t:1528143879820};\\\", \\\"{x:413,y:732,t:1528143879837};\\\", \\\"{x:421,y:735,t:1528143879855};\\\", \\\"{x:426,y:737,t:1528143879870};\\\", \\\"{x:431,y:740,t:1528143879887};\\\", \\\"{x:434,y:741,t:1528143879904};\\\", \\\"{x:437,y:743,t:1528143879920};\\\", \\\"{x:441,y:744,t:1528143879937};\\\", \\\"{x:448,y:747,t:1528143879954};\\\", \\\"{x:456,y:748,t:1528143879970};\\\", \\\"{x:457,y:748,t:1528143879989};\\\", \\\"{x:458,y:749,t:1528143880091};\\\", \\\"{x:459,y:749,t:1528143880244};\\\", \\\"{x:460,y:749,t:1528143880255};\\\", \\\"{x:461,y:750,t:1528143881251};\\\", \\\"{x:462,y:751,t:1528143881444};\\\", \\\"{x:462,y:755,t:1528143881459};\\\", \\\"{x:467,y:767,t:1528143881473};\\\", \\\"{x:470,y:771,t:1528143881489};\\\", \\\"{x:473,y:777,t:1528143881506};\\\", \\\"{x:473,y:779,t:1528143881523};\\\", \\\"{x:474,y:780,t:1528143881539};\\\", \\\"{x:475,y:780,t:1528143881971};\\\", \\\"{x:476,y:777,t:1528143881979};\\\", \\\"{x:477,y:775,t:1528143881990};\\\", \\\"{x:478,y:769,t:1528143882006};\\\", \\\"{x:480,y:764,t:1528143882023};\\\", \\\"{x:481,y:759,t:1528143882041};\\\", \\\"{x:482,y:759,t:1528143882056};\\\", \\\"{x:483,y:758,t:1528143882073};\\\", \\\"{x:483,y:757,t:1528143882164};\\\", \\\"{x:484,y:753,t:1528143882175};\\\", \\\"{x:486,y:750,t:1528143882189};\\\", \\\"{x:488,y:747,t:1528143882207};\\\", \\\"{x:490,y:744,t:1528143882222};\\\", \\\"{x:490,y:743,t:1528143882239};\\\" ] }, { \\\"rt\\\": 135297, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 1102267, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"VVH1B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-01 PM-M -X -Z -Z -Z -Z -Z -Z -L -H -P -P -Z -Z -Z -C -I -04 PM-Z -H -H -O -X -X -L -L -L \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:540,y:734,t:1528143887627};\\\", \\\"{x:710,y:723,t:1528143887647};\\\", \\\"{x:882,y:723,t:1528143887661};\\\", \\\"{x:1042,y:723,t:1528143887684};\\\", \\\"{x:1071,y:721,t:1528143887694};\\\", \\\"{x:1094,y:720,t:1528143887711};\\\", \\\"{x:1103,y:718,t:1528143887727};\\\", \\\"{x:1110,y:718,t:1528143887744};\\\", \\\"{x:1112,y:717,t:1528143887761};\\\", \\\"{x:1117,y:717,t:1528143887777};\\\", \\\"{x:1127,y:717,t:1528143887794};\\\", \\\"{x:1133,y:717,t:1528143887811};\\\", \\\"{x:1136,y:717,t:1528143887827};\\\", \\\"{x:1137,y:717,t:1528143887844};\\\", \\\"{x:1138,y:715,t:1528143888890};\\\", \\\"{x:1164,y:703,t:1528143888898};\\\", \\\"{x:1204,y:684,t:1528143888911};\\\", \\\"{x:1276,y:662,t:1528143888928};\\\", \\\"{x:1319,y:653,t:1528143888946};\\\", \\\"{x:1375,y:643,t:1528143888962};\\\", \\\"{x:1423,y:636,t:1528143888979};\\\", \\\"{x:1462,y:632,t:1528143888995};\\\", \\\"{x:1485,y:632,t:1528143889012};\\\", \\\"{x:1497,y:632,t:1528143889029};\\\", \\\"{x:1501,y:632,t:1528143889045};\\\", \\\"{x:1507,y:634,t:1528143889062};\\\", \\\"{x:1515,y:640,t:1528143889079};\\\", \\\"{x:1519,y:645,t:1528143889095};\\\", \\\"{x:1524,y:652,t:1528143889112};\\\", \\\"{x:1529,y:661,t:1528143889128};\\\", \\\"{x:1530,y:670,t:1528143889145};\\\", \\\"{x:1532,y:688,t:1528143889163};\\\", \\\"{x:1532,y:702,t:1528143889178};\\\", \\\"{x:1522,y:722,t:1528143889196};\\\", \\\"{x:1510,y:741,t:1528143889213};\\\", \\\"{x:1495,y:764,t:1528143889228};\\\", \\\"{x:1476,y:785,t:1528143889245};\\\", \\\"{x:1451,y:800,t:1528143889263};\\\", \\\"{x:1430,y:812,t:1528143889279};\\\", \\\"{x:1407,y:824,t:1528143889296};\\\", \\\"{x:1390,y:835,t:1528143889312};\\\", \\\"{x:1376,y:844,t:1528143889329};\\\", \\\"{x:1362,y:853,t:1528143889346};\\\", \\\"{x:1340,y:871,t:1528143889362};\\\", \\\"{x:1324,y:883,t:1528143889379};\\\", \\\"{x:1311,y:891,t:1528143889395};\\\", \\\"{x:1300,y:897,t:1528143889413};\\\", \\\"{x:1296,y:898,t:1528143889429};\\\", \\\"{x:1295,y:899,t:1528143889467};\\\", \\\"{x:1295,y:900,t:1528143889483};\\\", \\\"{x:1294,y:901,t:1528143889507};\\\", \\\"{x:1294,y:902,t:1528143889522};\\\", \\\"{x:1294,y:904,t:1528143889531};\\\", \\\"{x:1294,y:906,t:1528143889546};\\\", \\\"{x:1294,y:911,t:1528143889563};\\\", \\\"{x:1299,y:917,t:1528143889580};\\\", \\\"{x:1306,y:922,t:1528143889596};\\\", \\\"{x:1316,y:927,t:1528143889613};\\\", \\\"{x:1331,y:933,t:1528143889630};\\\", \\\"{x:1347,y:939,t:1528143889646};\\\", \\\"{x:1362,y:946,t:1528143889663};\\\", \\\"{x:1379,y:953,t:1528143889680};\\\", \\\"{x:1390,y:958,t:1528143889696};\\\", \\\"{x:1393,y:960,t:1528143889713};\\\", \\\"{x:1395,y:961,t:1528143889729};\\\", \\\"{x:1396,y:962,t:1528143889746};\\\", \\\"{x:1397,y:963,t:1528143889763};\\\", \\\"{x:1397,y:964,t:1528143889780};\\\", \\\"{x:1397,y:965,t:1528143889828};\\\", \\\"{x:1397,y:966,t:1528143889834};\\\", \\\"{x:1397,y:967,t:1528143889845};\\\", \\\"{x:1397,y:968,t:1528143889863};\\\", \\\"{x:1397,y:970,t:1528143889880};\\\", \\\"{x:1397,y:971,t:1528143889923};\\\", \\\"{x:1397,y:972,t:1528143889939};\\\", \\\"{x:1397,y:973,t:1528143889971};\\\", \\\"{x:1399,y:971,t:1528143890067};\\\", \\\"{x:1402,y:969,t:1528143890080};\\\", \\\"{x:1413,y:963,t:1528143890098};\\\", \\\"{x:1425,y:956,t:1528143890113};\\\", \\\"{x:1435,y:950,t:1528143890130};\\\", \\\"{x:1441,y:946,t:1528143890147};\\\", \\\"{x:1441,y:945,t:1528143890163};\\\", \\\"{x:1442,y:944,t:1528143890186};\\\", \\\"{x:1441,y:944,t:1528143890555};\\\", \\\"{x:1439,y:949,t:1528143890563};\\\", \\\"{x:1439,y:952,t:1528143890580};\\\", \\\"{x:1436,y:957,t:1528143890597};\\\", \\\"{x:1433,y:961,t:1528143890614};\\\", \\\"{x:1433,y:963,t:1528143890630};\\\", \\\"{x:1432,y:965,t:1528143890647};\\\", \\\"{x:1431,y:968,t:1528143890664};\\\", \\\"{x:1429,y:970,t:1528143890680};\\\", \\\"{x:1428,y:973,t:1528143890697};\\\", \\\"{x:1427,y:974,t:1528143890714};\\\", \\\"{x:1426,y:974,t:1528143890739};\\\", \\\"{x:1425,y:975,t:1528143890779};\\\", \\\"{x:1423,y:976,t:1528143890797};\\\", \\\"{x:1420,y:977,t:1528143890814};\\\", \\\"{x:1417,y:978,t:1528143890830};\\\", \\\"{x:1414,y:979,t:1528143890847};\\\", \\\"{x:1412,y:979,t:1528143890864};\\\", \\\"{x:1411,y:980,t:1528143890881};\\\", \\\"{x:1409,y:980,t:1528143890897};\\\", \\\"{x:1408,y:980,t:1528143890913};\\\", \\\"{x:1406,y:980,t:1528143890931};\\\", \\\"{x:1405,y:980,t:1528143890946};\\\", \\\"{x:1404,y:980,t:1528143890964};\\\", \\\"{x:1400,y:979,t:1528143890981};\\\", \\\"{x:1397,y:976,t:1528143890996};\\\", \\\"{x:1396,y:973,t:1528143891014};\\\", \\\"{x:1393,y:969,t:1528143891032};\\\", \\\"{x:1390,y:963,t:1528143891048};\\\", \\\"{x:1387,y:955,t:1528143891064};\\\", \\\"{x:1383,y:944,t:1528143891081};\\\", \\\"{x:1380,y:939,t:1528143891097};\\\", \\\"{x:1379,y:937,t:1528143891114};\\\", \\\"{x:1379,y:934,t:1528143891131};\\\", \\\"{x:1379,y:933,t:1528143891155};\\\", \\\"{x:1378,y:933,t:1528143891164};\\\", \\\"{x:1377,y:932,t:1528143891227};\\\", \\\"{x:1377,y:931,t:1528143891315};\\\", \\\"{x:1377,y:928,t:1528143891331};\\\", \\\"{x:1377,y:924,t:1528143891347};\\\", \\\"{x:1375,y:920,t:1528143891364};\\\", \\\"{x:1374,y:913,t:1528143891381};\\\", \\\"{x:1373,y:910,t:1528143891398};\\\", \\\"{x:1373,y:906,t:1528143891414};\\\", \\\"{x:1372,y:903,t:1528143891431};\\\", \\\"{x:1372,y:901,t:1528143891448};\\\", \\\"{x:1372,y:900,t:1528143891464};\\\", \\\"{x:1372,y:899,t:1528143891481};\\\", \\\"{x:1372,y:896,t:1528143893467};\\\", \\\"{x:1381,y:881,t:1528143893481};\\\", \\\"{x:1437,y:851,t:1528143893499};\\\", \\\"{x:1480,y:826,t:1528143893516};\\\", \\\"{x:1517,y:811,t:1528143893532};\\\", \\\"{x:1533,y:803,t:1528143893549};\\\", \\\"{x:1538,y:800,t:1528143893565};\\\", \\\"{x:1540,y:798,t:1528143893581};\\\", \\\"{x:1541,y:797,t:1528143893598};\\\", \\\"{x:1544,y:794,t:1528143893615};\\\", \\\"{x:1547,y:792,t:1528143893631};\\\", \\\"{x:1550,y:789,t:1528143893649};\\\", \\\"{x:1553,y:783,t:1528143893666};\\\", \\\"{x:1559,y:774,t:1528143893682};\\\", \\\"{x:1564,y:764,t:1528143893698};\\\", \\\"{x:1569,y:755,t:1528143893716};\\\", \\\"{x:1573,y:747,t:1528143893733};\\\", \\\"{x:1578,y:738,t:1528143893749};\\\", \\\"{x:1583,y:730,t:1528143893765};\\\", \\\"{x:1588,y:718,t:1528143893782};\\\", \\\"{x:1595,y:701,t:1528143893799};\\\", \\\"{x:1599,y:680,t:1528143893816};\\\", \\\"{x:1604,y:658,t:1528143893833};\\\", \\\"{x:1606,y:639,t:1528143893849};\\\", \\\"{x:1606,y:627,t:1528143893866};\\\", \\\"{x:1603,y:601,t:1528143893883};\\\", \\\"{x:1598,y:584,t:1528143893899};\\\", \\\"{x:1596,y:566,t:1528143893916};\\\", \\\"{x:1592,y:550,t:1528143893933};\\\", \\\"{x:1591,y:540,t:1528143893949};\\\", \\\"{x:1591,y:535,t:1528143893966};\\\", \\\"{x:1589,y:530,t:1528143893983};\\\", \\\"{x:1589,y:528,t:1528143893999};\\\", \\\"{x:1587,y:526,t:1528143894016};\\\", \\\"{x:1586,y:525,t:1528143894043};\\\", \\\"{x:1585,y:525,t:1528143894796};\\\", \\\"{x:1584,y:526,t:1528143895011};\\\", \\\"{x:1583,y:527,t:1528143895171};\\\", \\\"{x:1583,y:528,t:1528143895283};\\\", \\\"{x:1582,y:528,t:1528143895301};\\\", \\\"{x:1582,y:529,t:1528143895411};\\\", \\\"{x:1581,y:531,t:1528143896659};\\\", \\\"{x:1578,y:536,t:1528143896674};\\\", \\\"{x:1576,y:545,t:1528143896685};\\\", \\\"{x:1572,y:557,t:1528143896702};\\\", \\\"{x:1570,y:565,t:1528143896719};\\\", \\\"{x:1569,y:579,t:1528143896735};\\\", \\\"{x:1568,y:590,t:1528143896751};\\\", \\\"{x:1567,y:602,t:1528143896768};\\\", \\\"{x:1567,y:612,t:1528143896786};\\\", \\\"{x:1567,y:617,t:1528143896802};\\\", \\\"{x:1567,y:623,t:1528143896818};\\\", \\\"{x:1567,y:627,t:1528143896835};\\\", \\\"{x:1567,y:633,t:1528143896852};\\\", \\\"{x:1567,y:638,t:1528143896868};\\\", \\\"{x:1567,y:642,t:1528143896886};\\\", \\\"{x:1569,y:646,t:1528143896902};\\\", \\\"{x:1570,y:649,t:1528143896918};\\\", \\\"{x:1573,y:656,t:1528143896936};\\\", \\\"{x:1575,y:662,t:1528143896951};\\\", \\\"{x:1579,y:671,t:1528143896968};\\\", \\\"{x:1584,y:682,t:1528143896985};\\\", \\\"{x:1587,y:689,t:1528143897001};\\\", \\\"{x:1592,y:699,t:1528143897019};\\\", \\\"{x:1601,y:719,t:1528143897034};\\\", \\\"{x:1605,y:728,t:1528143897052};\\\", \\\"{x:1606,y:729,t:1528143897068};\\\", \\\"{x:1606,y:731,t:1528143897085};\\\", \\\"{x:1609,y:727,t:1528143897235};\\\", \\\"{x:1610,y:720,t:1528143897252};\\\", \\\"{x:1611,y:714,t:1528143897269};\\\", \\\"{x:1614,y:707,t:1528143897285};\\\", \\\"{x:1614,y:705,t:1528143897302};\\\", \\\"{x:1614,y:704,t:1528143897318};\\\", \\\"{x:1614,y:703,t:1528143909667};\\\", \\\"{x:1598,y:703,t:1528143909779};\\\", \\\"{x:1434,y:706,t:1528143909794};\\\", \\\"{x:1290,y:684,t:1528143909812};\\\", \\\"{x:1154,y:662,t:1528143909828};\\\", \\\"{x:1056,y:643,t:1528143909845};\\\", \\\"{x:1000,y:635,t:1528143909861};\\\", \\\"{x:979,y:633,t:1528143909878};\\\", \\\"{x:975,y:632,t:1528143909895};\\\", \\\"{x:973,y:632,t:1528143909911};\\\", \\\"{x:972,y:632,t:1528143909927};\\\", \\\"{x:963,y:634,t:1528143909944};\\\", \\\"{x:948,y:635,t:1528143909961};\\\", \\\"{x:927,y:635,t:1528143909978};\\\", \\\"{x:898,y:635,t:1528143909994};\\\", \\\"{x:880,y:629,t:1528143910013};\\\", \\\"{x:874,y:626,t:1528143910027};\\\", \\\"{x:872,y:625,t:1528143910044};\\\", \\\"{x:872,y:622,t:1528143910061};\\\", \\\"{x:872,y:617,t:1528143910078};\\\", \\\"{x:875,y:607,t:1528143910095};\\\", \\\"{x:887,y:593,t:1528143910112};\\\", \\\"{x:896,y:583,t:1528143910128};\\\", \\\"{x:902,y:574,t:1528143910145};\\\", \\\"{x:905,y:570,t:1528143910162};\\\", \\\"{x:905,y:568,t:1528143910178};\\\", \\\"{x:905,y:567,t:1528143910217};\\\", \\\"{x:905,y:566,t:1528143910242};\\\", \\\"{x:904,y:566,t:1528143910258};\\\", \\\"{x:901,y:566,t:1528143910266};\\\", \\\"{x:898,y:566,t:1528143910280};\\\", \\\"{x:889,y:567,t:1528143910295};\\\", \\\"{x:879,y:568,t:1528143910312};\\\", \\\"{x:875,y:568,t:1528143910329};\\\", \\\"{x:872,y:568,t:1528143910345};\\\", \\\"{x:869,y:568,t:1528143910362};\\\", \\\"{x:867,y:568,t:1528143910402};\\\", \\\"{x:866,y:568,t:1528143910426};\\\", \\\"{x:865,y:568,t:1528143910458};\\\", \\\"{x:864,y:568,t:1528143910474};\\\", \\\"{x:863,y:568,t:1528143910506};\\\", \\\"{x:861,y:568,t:1528143910539};\\\", \\\"{x:860,y:568,t:1528143910555};\\\", \\\"{x:859,y:569,t:1528143910578};\\\", \\\"{x:858,y:569,t:1528143910594};\\\", \\\"{x:857,y:569,t:1528143910618};\\\", \\\"{x:856,y:569,t:1528143910642};\\\", \\\"{x:855,y:569,t:1528143910650};\\\", \\\"{x:854,y:569,t:1528143910674};\\\", \\\"{x:853,y:569,t:1528143910698};\\\", \\\"{x:852,y:569,t:1528143910714};\\\", \\\"{x:851,y:569,t:1528143910729};\\\", \\\"{x:847,y:569,t:1528143910747};\\\", \\\"{x:843,y:569,t:1528143910764};\\\", \\\"{x:840,y:569,t:1528143910779};\\\", \\\"{x:837,y:569,t:1528143910796};\\\", \\\"{x:836,y:569,t:1528143910813};\\\", \\\"{x:835,y:570,t:1528143910829};\\\", \\\"{x:834,y:570,t:1528143910846};\\\", \\\"{x:833,y:571,t:1528143910863};\\\", \\\"{x:832,y:571,t:1528143910880};\\\", \\\"{x:831,y:572,t:1528143910896};\\\", \\\"{x:837,y:574,t:1528143929442};\\\", \\\"{x:867,y:553,t:1528143929458};\\\", \\\"{x:898,y:532,t:1528143929471};\\\", \\\"{x:928,y:513,t:1528143929488};\\\", \\\"{x:1009,y:480,t:1528143929511};\\\", \\\"{x:1036,y:468,t:1528143929527};\\\", \\\"{x:1052,y:458,t:1528143929544};\\\", \\\"{x:1061,y:450,t:1528143929561};\\\", \\\"{x:1065,y:447,t:1528143929577};\\\", \\\"{x:1069,y:444,t:1528143929593};\\\", \\\"{x:1072,y:442,t:1528143929611};\\\", \\\"{x:1072,y:441,t:1528143929627};\\\", \\\"{x:1076,y:440,t:1528143929644};\\\", \\\"{x:1082,y:440,t:1528143929661};\\\", \\\"{x:1093,y:444,t:1528143929676};\\\", \\\"{x:1110,y:456,t:1528143929694};\\\", \\\"{x:1141,y:478,t:1528143929711};\\\", \\\"{x:1188,y:519,t:1528143929728};\\\", \\\"{x:1240,y:564,t:1528143929744};\\\", \\\"{x:1300,y:613,t:1528143929761};\\\", \\\"{x:1375,y:675,t:1528143929777};\\\", \\\"{x:1447,y:722,t:1528143929794};\\\", \\\"{x:1529,y:769,t:1528143929811};\\\", \\\"{x:1578,y:795,t:1528143929828};\\\", \\\"{x:1611,y:809,t:1528143929844};\\\", \\\"{x:1631,y:818,t:1528143929861};\\\", \\\"{x:1638,y:821,t:1528143929878};\\\", \\\"{x:1642,y:823,t:1528143929894};\\\", \\\"{x:1643,y:823,t:1528143929911};\\\", \\\"{x:1645,y:823,t:1528143929937};\\\", \\\"{x:1647,y:822,t:1528143929946};\\\", \\\"{x:1651,y:809,t:1528143929961};\\\", \\\"{x:1662,y:772,t:1528143929977};\\\", \\\"{x:1662,y:754,t:1528143929994};\\\", \\\"{x:1661,y:740,t:1528143930011};\\\", \\\"{x:1658,y:730,t:1528143930028};\\\", \\\"{x:1656,y:722,t:1528143930044};\\\", \\\"{x:1655,y:718,t:1528143930061};\\\", \\\"{x:1654,y:713,t:1528143930078};\\\", \\\"{x:1654,y:712,t:1528143930094};\\\", \\\"{x:1654,y:709,t:1528143930111};\\\", \\\"{x:1654,y:708,t:1528143930128};\\\", \\\"{x:1654,y:705,t:1528143930144};\\\", \\\"{x:1654,y:704,t:1528143930162};\\\", \\\"{x:1653,y:703,t:1528143930419};\\\", \\\"{x:1651,y:702,t:1528143930428};\\\", \\\"{x:1646,y:700,t:1528143930445};\\\", \\\"{x:1645,y:699,t:1528143930462};\\\", \\\"{x:1639,y:697,t:1528143930479};\\\", \\\"{x:1638,y:696,t:1528143930496};\\\", \\\"{x:1637,y:696,t:1528143930511};\\\", \\\"{x:1636,y:696,t:1528143930528};\\\", \\\"{x:1635,y:695,t:1528143930579};\\\", \\\"{x:1634,y:694,t:1528143930595};\\\", \\\"{x:1633,y:694,t:1528143930612};\\\", \\\"{x:1632,y:693,t:1528143930629};\\\", \\\"{x:1631,y:693,t:1528143930646};\\\", \\\"{x:1629,y:691,t:1528143930663};\\\", \\\"{x:1628,y:690,t:1528143930682};\\\", \\\"{x:1627,y:690,t:1528143930695};\\\", \\\"{x:1626,y:683,t:1528143930713};\\\", \\\"{x:1626,y:674,t:1528143930729};\\\", \\\"{x:1626,y:662,t:1528143930746};\\\", \\\"{x:1626,y:641,t:1528143930762};\\\", \\\"{x:1630,y:622,t:1528143930778};\\\", \\\"{x:1637,y:602,t:1528143930795};\\\", \\\"{x:1641,y:582,t:1528143930813};\\\", \\\"{x:1644,y:568,t:1528143930828};\\\", \\\"{x:1646,y:558,t:1528143930845};\\\", \\\"{x:1647,y:550,t:1528143930862};\\\", \\\"{x:1647,y:546,t:1528143930879};\\\", \\\"{x:1647,y:545,t:1528143930895};\\\", \\\"{x:1645,y:548,t:1528143931082};\\\", \\\"{x:1641,y:554,t:1528143931095};\\\", \\\"{x:1635,y:564,t:1528143931113};\\\", \\\"{x:1631,y:571,t:1528143931129};\\\", \\\"{x:1629,y:573,t:1528143931146};\\\", \\\"{x:1626,y:579,t:1528143931162};\\\", \\\"{x:1625,y:583,t:1528143931179};\\\", \\\"{x:1624,y:587,t:1528143931196};\\\", \\\"{x:1621,y:594,t:1528143931212};\\\", \\\"{x:1620,y:597,t:1528143931230};\\\", \\\"{x:1619,y:602,t:1528143931245};\\\", \\\"{x:1618,y:607,t:1528143931263};\\\", \\\"{x:1617,y:617,t:1528143931279};\\\", \\\"{x:1617,y:625,t:1528143931295};\\\", \\\"{x:1617,y:631,t:1528143931313};\\\", \\\"{x:1617,y:639,t:1528143931329};\\\", \\\"{x:1617,y:645,t:1528143931345};\\\", \\\"{x:1618,y:660,t:1528143931362};\\\", \\\"{x:1619,y:665,t:1528143931380};\\\", \\\"{x:1619,y:667,t:1528143931396};\\\", \\\"{x:1619,y:669,t:1528143931413};\\\", \\\"{x:1619,y:671,t:1528143931429};\\\", \\\"{x:1619,y:672,t:1528143931445};\\\", \\\"{x:1619,y:674,t:1528143931462};\\\", \\\"{x:1619,y:675,t:1528143931489};\\\", \\\"{x:1619,y:677,t:1528143931513};\\\", \\\"{x:1619,y:678,t:1528143931545};\\\", \\\"{x:1619,y:679,t:1528143931585};\\\", \\\"{x:1619,y:681,t:1528143931596};\\\", \\\"{x:1616,y:686,t:1528143931612};\\\", \\\"{x:1614,y:690,t:1528143931629};\\\", \\\"{x:1614,y:692,t:1528143931646};\\\", \\\"{x:1614,y:693,t:1528143931662};\\\", \\\"{x:1613,y:695,t:1528143931681};\\\", \\\"{x:1609,y:693,t:1528143931924};\\\", \\\"{x:1609,y:691,t:1528143931930};\\\", \\\"{x:1609,y:687,t:1528143931946};\\\", \\\"{x:1609,y:681,t:1528143931962};\\\", \\\"{x:1608,y:677,t:1528143931979};\\\", \\\"{x:1608,y:675,t:1528143931996};\\\", \\\"{x:1608,y:670,t:1528143932012};\\\", \\\"{x:1608,y:667,t:1528143932029};\\\", \\\"{x:1609,y:661,t:1528143932046};\\\", \\\"{x:1609,y:656,t:1528143932063};\\\", \\\"{x:1609,y:655,t:1528143932079};\\\", \\\"{x:1609,y:652,t:1528143932096};\\\", \\\"{x:1610,y:649,t:1528143932113};\\\", \\\"{x:1610,y:648,t:1528143932129};\\\", \\\"{x:1611,y:641,t:1528143932147};\\\", \\\"{x:1611,y:637,t:1528143932163};\\\", \\\"{x:1611,y:631,t:1528143932179};\\\", \\\"{x:1613,y:626,t:1528143932196};\\\", \\\"{x:1614,y:622,t:1528143932213};\\\", \\\"{x:1614,y:618,t:1528143932229};\\\", \\\"{x:1614,y:615,t:1528143932246};\\\", \\\"{x:1614,y:611,t:1528143932263};\\\", \\\"{x:1615,y:606,t:1528143932279};\\\", \\\"{x:1617,y:601,t:1528143932296};\\\", \\\"{x:1617,y:595,t:1528143932313};\\\", \\\"{x:1617,y:591,t:1528143932329};\\\", \\\"{x:1617,y:589,t:1528143932346};\\\", \\\"{x:1617,y:586,t:1528143932363};\\\", \\\"{x:1617,y:583,t:1528143932379};\\\", \\\"{x:1617,y:580,t:1528143932396};\\\", \\\"{x:1617,y:575,t:1528143932414};\\\", \\\"{x:1617,y:570,t:1528143932429};\\\", \\\"{x:1617,y:566,t:1528143932446};\\\", \\\"{x:1617,y:561,t:1528143932464};\\\", \\\"{x:1617,y:555,t:1528143932480};\\\", \\\"{x:1618,y:549,t:1528143932496};\\\", \\\"{x:1618,y:543,t:1528143932514};\\\", \\\"{x:1618,y:539,t:1528143932530};\\\", \\\"{x:1618,y:535,t:1528143932547};\\\", \\\"{x:1618,y:532,t:1528143932563};\\\", \\\"{x:1618,y:528,t:1528143932581};\\\", \\\"{x:1618,y:525,t:1528143932596};\\\", \\\"{x:1618,y:522,t:1528143932614};\\\", \\\"{x:1618,y:518,t:1528143932631};\\\", \\\"{x:1618,y:514,t:1528143932646};\\\", \\\"{x:1618,y:510,t:1528143932663};\\\", \\\"{x:1618,y:505,t:1528143932681};\\\", \\\"{x:1618,y:501,t:1528143932696};\\\", \\\"{x:1618,y:494,t:1528143932714};\\\", \\\"{x:1618,y:490,t:1528143932730};\\\", \\\"{x:1618,y:485,t:1528143932747};\\\", \\\"{x:1618,y:483,t:1528143932763};\\\", \\\"{x:1618,y:479,t:1528143932780};\\\", \\\"{x:1618,y:477,t:1528143932796};\\\", \\\"{x:1618,y:473,t:1528143932813};\\\", \\\"{x:1618,y:471,t:1528143932830};\\\", \\\"{x:1618,y:468,t:1528143932846};\\\", \\\"{x:1618,y:465,t:1528143932863};\\\", \\\"{x:1618,y:462,t:1528143932880};\\\", \\\"{x:1618,y:459,t:1528143932896};\\\", \\\"{x:1618,y:457,t:1528143932913};\\\", \\\"{x:1618,y:452,t:1528143932930};\\\", \\\"{x:1618,y:448,t:1528143932946};\\\", \\\"{x:1618,y:446,t:1528143932963};\\\", \\\"{x:1618,y:442,t:1528143932980};\\\", \\\"{x:1618,y:439,t:1528143932996};\\\", \\\"{x:1618,y:436,t:1528143933013};\\\", \\\"{x:1618,y:435,t:1528143933031};\\\", \\\"{x:1618,y:434,t:1528143933047};\\\", \\\"{x:1618,y:433,t:1528143933065};\\\", \\\"{x:1591,y:440,t:1528143936497};\\\", \\\"{x:1499,y:470,t:1528143936505};\\\", \\\"{x:1371,y:484,t:1528143936516};\\\", \\\"{x:1125,y:484,t:1528143936532};\\\", \\\"{x:940,y:483,t:1528143936549};\\\", \\\"{x:757,y:481,t:1528143936566};\\\", \\\"{x:669,y:481,t:1528143936582};\\\", \\\"{x:661,y:481,t:1528143936599};\\\", \\\"{x:661,y:480,t:1528143936649};\\\", \\\"{x:661,y:481,t:1528143936738};\\\", \\\"{x:664,y:481,t:1528143936750};\\\", \\\"{x:668,y:484,t:1528143936767};\\\", \\\"{x:669,y:492,t:1528143936787};\\\", \\\"{x:667,y:504,t:1528143936803};\\\", \\\"{x:661,y:517,t:1528143936820};\\\", \\\"{x:651,y:528,t:1528143936837};\\\", \\\"{x:625,y:542,t:1528143936853};\\\", \\\"{x:604,y:552,t:1528143936870};\\\", \\\"{x:585,y:562,t:1528143936887};\\\", \\\"{x:570,y:568,t:1528143936905};\\\", \\\"{x:562,y:573,t:1528143936920};\\\", \\\"{x:553,y:576,t:1528143936937};\\\", \\\"{x:545,y:576,t:1528143936954};\\\", \\\"{x:536,y:576,t:1528143936970};\\\", \\\"{x:526,y:577,t:1528143936987};\\\", \\\"{x:511,y:581,t:1528143937004};\\\", \\\"{x:491,y:587,t:1528143937021};\\\", \\\"{x:467,y:593,t:1528143937036};\\\", \\\"{x:447,y:595,t:1528143937054};\\\", \\\"{x:427,y:595,t:1528143937070};\\\", \\\"{x:414,y:595,t:1528143937087};\\\", \\\"{x:406,y:591,t:1528143937105};\\\", \\\"{x:401,y:589,t:1528143937120};\\\", \\\"{x:394,y:585,t:1528143937137};\\\", \\\"{x:391,y:583,t:1528143937154};\\\", \\\"{x:389,y:582,t:1528143937170};\\\", \\\"{x:388,y:581,t:1528143937278};\\\", \\\"{x:385,y:580,t:1528143937288};\\\", \\\"{x:382,y:578,t:1528143937304};\\\", \\\"{x:376,y:573,t:1528143937322};\\\", \\\"{x:373,y:559,t:1528143937339};\\\", \\\"{x:373,y:549,t:1528143937355};\\\", \\\"{x:372,y:546,t:1528143937372};\\\", \\\"{x:372,y:545,t:1528143937387};\\\", \\\"{x:372,y:543,t:1528143937405};\\\", \\\"{x:372,y:539,t:1528143937421};\\\", \\\"{x:373,y:536,t:1528143937438};\\\", \\\"{x:375,y:535,t:1528143937477};\\\", \\\"{x:378,y:535,t:1528143937487};\\\", \\\"{x:380,y:536,t:1528143937504};\\\", \\\"{x:382,y:540,t:1528143937521};\\\", \\\"{x:384,y:554,t:1528143937538};\\\", \\\"{x:384,y:568,t:1528143937554};\\\", \\\"{x:384,y:579,t:1528143937571};\\\", \\\"{x:384,y:586,t:1528143937587};\\\", \\\"{x:384,y:593,t:1528143937604};\\\", \\\"{x:386,y:600,t:1528143937621};\\\", \\\"{x:386,y:601,t:1528143937639};\\\", \\\"{x:386,y:604,t:1528143937655};\\\", \\\"{x:386,y:607,t:1528143937671};\\\", \\\"{x:386,y:612,t:1528143937688};\\\", \\\"{x:385,y:616,t:1528143937704};\\\", \\\"{x:385,y:618,t:1528143937721};\\\", \\\"{x:385,y:619,t:1528143937738};\\\", \\\"{x:385,y:621,t:1528143937797};\\\", \\\"{x:385,y:622,t:1528143937845};\\\", \\\"{x:393,y:616,t:1528143938246};\\\", \\\"{x:410,y:608,t:1528143938255};\\\", \\\"{x:456,y:590,t:1528143938272};\\\", \\\"{x:552,y:568,t:1528143938289};\\\", \\\"{x:651,y:546,t:1528143938306};\\\", \\\"{x:753,y:537,t:1528143938322};\\\", \\\"{x:876,y:530,t:1528143938338};\\\", \\\"{x:1003,y:530,t:1528143938356};\\\", \\\"{x:1114,y:530,t:1528143938371};\\\", \\\"{x:1181,y:530,t:1528143938388};\\\", \\\"{x:1248,y:530,t:1528143938405};\\\", \\\"{x:1276,y:530,t:1528143938421};\\\", \\\"{x:1294,y:530,t:1528143938439};\\\", \\\"{x:1303,y:530,t:1528143938455};\\\", \\\"{x:1306,y:531,t:1528143938472};\\\", \\\"{x:1307,y:531,t:1528143938488};\\\", \\\"{x:1308,y:532,t:1528143938533};\\\", \\\"{x:1309,y:532,t:1528143938566};\\\", \\\"{x:1312,y:532,t:1528143938573};\\\", \\\"{x:1316,y:532,t:1528143938588};\\\", \\\"{x:1344,y:532,t:1528143938606};\\\", \\\"{x:1371,y:532,t:1528143938622};\\\", \\\"{x:1410,y:532,t:1528143938638};\\\", \\\"{x:1454,y:532,t:1528143938655};\\\", \\\"{x:1497,y:532,t:1528143938672};\\\", \\\"{x:1523,y:537,t:1528143938688};\\\", \\\"{x:1533,y:542,t:1528143938705};\\\", \\\"{x:1535,y:545,t:1528143938723};\\\", \\\"{x:1539,y:554,t:1528143938739};\\\", \\\"{x:1547,y:570,t:1528143938755};\\\", \\\"{x:1558,y:594,t:1528143938773};\\\", \\\"{x:1577,y:635,t:1528143938790};\\\", \\\"{x:1591,y:661,t:1528143938806};\\\", \\\"{x:1602,y:678,t:1528143938822};\\\", \\\"{x:1605,y:681,t:1528143938840};\\\", \\\"{x:1605,y:683,t:1528143938855};\\\", \\\"{x:1607,y:683,t:1528143938918};\\\", \\\"{x:1608,y:684,t:1528143938926};\\\", \\\"{x:1609,y:684,t:1528143938950};\\\", \\\"{x:1611,y:684,t:1528143938958};\\\", \\\"{x:1614,y:684,t:1528143938972};\\\", \\\"{x:1617,y:684,t:1528143938990};\\\", \\\"{x:1618,y:684,t:1528143939118};\\\", \\\"{x:1619,y:683,t:1528143939166};\\\", \\\"{x:1621,y:677,t:1528143939174};\\\", \\\"{x:1623,y:669,t:1528143939190};\\\", \\\"{x:1626,y:653,t:1528143939206};\\\", \\\"{x:1628,y:640,t:1528143939223};\\\", \\\"{x:1629,y:631,t:1528143939239};\\\", \\\"{x:1631,y:625,t:1528143939257};\\\", \\\"{x:1631,y:620,t:1528143939272};\\\", \\\"{x:1632,y:614,t:1528143939289};\\\", \\\"{x:1633,y:606,t:1528143939307};\\\", \\\"{x:1635,y:600,t:1528143939323};\\\", \\\"{x:1636,y:595,t:1528143939339};\\\", \\\"{x:1637,y:591,t:1528143939357};\\\", \\\"{x:1637,y:587,t:1528143939374};\\\", \\\"{x:1639,y:584,t:1528143939390};\\\", \\\"{x:1639,y:581,t:1528143939407};\\\", \\\"{x:1639,y:579,t:1528143939424};\\\", \\\"{x:1639,y:575,t:1528143939440};\\\", \\\"{x:1639,y:572,t:1528143939457};\\\", \\\"{x:1639,y:567,t:1528143939474};\\\", \\\"{x:1639,y:564,t:1528143939490};\\\", \\\"{x:1639,y:563,t:1528143939506};\\\", \\\"{x:1639,y:561,t:1528143939523};\\\", \\\"{x:1639,y:573,t:1528143939622};\\\", \\\"{x:1639,y:581,t:1528143939630};\\\", \\\"{x:1639,y:592,t:1528143939639};\\\", \\\"{x:1639,y:609,t:1528143939656};\\\", \\\"{x:1640,y:619,t:1528143939674};\\\", \\\"{x:1640,y:631,t:1528143939689};\\\", \\\"{x:1640,y:649,t:1528143939707};\\\", \\\"{x:1640,y:664,t:1528143939724};\\\", \\\"{x:1640,y:669,t:1528143939740};\\\", \\\"{x:1640,y:676,t:1528143939757};\\\", \\\"{x:1639,y:684,t:1528143939774};\\\", \\\"{x:1638,y:687,t:1528143939790};\\\", \\\"{x:1637,y:689,t:1528143939806};\\\", \\\"{x:1637,y:690,t:1528143939823};\\\", \\\"{x:1637,y:691,t:1528143939894};\\\", \\\"{x:1636,y:692,t:1528143939906};\\\", \\\"{x:1635,y:692,t:1528143939941};\\\", \\\"{x:1635,y:693,t:1528143939956};\\\", \\\"{x:1633,y:696,t:1528143939973};\\\", \\\"{x:1632,y:697,t:1528143939990};\\\", \\\"{x:1629,y:701,t:1528143940006};\\\", \\\"{x:1628,y:702,t:1528143940022};\\\", \\\"{x:1627,y:703,t:1528143940040};\\\", \\\"{x:1626,y:703,t:1528143940060};\\\", \\\"{x:1625,y:703,t:1528143940197};\\\", \\\"{x:1624,y:702,t:1528143940221};\\\", \\\"{x:1624,y:701,t:1528143940237};\\\", \\\"{x:1623,y:701,t:1528143940244};\\\", \\\"{x:1623,y:700,t:1528143940257};\\\", \\\"{x:1622,y:697,t:1528143940273};\\\", \\\"{x:1620,y:694,t:1528143940290};\\\", \\\"{x:1619,y:690,t:1528143940306};\\\", \\\"{x:1619,y:687,t:1528143940324};\\\", \\\"{x:1617,y:684,t:1528143940340};\\\", \\\"{x:1617,y:679,t:1528143940356};\\\", \\\"{x:1617,y:672,t:1528143940374};\\\", \\\"{x:1617,y:658,t:1528143940390};\\\", \\\"{x:1617,y:645,t:1528143940407};\\\", \\\"{x:1617,y:636,t:1528143940424};\\\", \\\"{x:1617,y:632,t:1528143940440};\\\", \\\"{x:1617,y:630,t:1528143940457};\\\", \\\"{x:1616,y:628,t:1528143940474};\\\", \\\"{x:1615,y:626,t:1528143940490};\\\", \\\"{x:1615,y:624,t:1528143940507};\\\", \\\"{x:1615,y:622,t:1528143940523};\\\", \\\"{x:1615,y:621,t:1528143940539};\\\", \\\"{x:1615,y:619,t:1528143940557};\\\", \\\"{x:1615,y:618,t:1528143940597};\\\", \\\"{x:1615,y:616,t:1528143940620};\\\", \\\"{x:1615,y:615,t:1528143940628};\\\", \\\"{x:1615,y:614,t:1528143940641};\\\", \\\"{x:1614,y:610,t:1528143940657};\\\", \\\"{x:1614,y:608,t:1528143940674};\\\", \\\"{x:1613,y:606,t:1528143940691};\\\", \\\"{x:1613,y:602,t:1528143940707};\\\", \\\"{x:1613,y:598,t:1528143940724};\\\", \\\"{x:1613,y:589,t:1528143940741};\\\", \\\"{x:1613,y:584,t:1528143940757};\\\", \\\"{x:1613,y:580,t:1528143940774};\\\", \\\"{x:1613,y:577,t:1528143940791};\\\", \\\"{x:1613,y:576,t:1528143940807};\\\", \\\"{x:1613,y:574,t:1528143940829};\\\", \\\"{x:1613,y:572,t:1528143940845};\\\", \\\"{x:1613,y:571,t:1528143940858};\\\", \\\"{x:1613,y:569,t:1528143940874};\\\", \\\"{x:1613,y:567,t:1528143940891};\\\", \\\"{x:1613,y:563,t:1528143940908};\\\", \\\"{x:1613,y:560,t:1528143940925};\\\", \\\"{x:1613,y:554,t:1528143940942};\\\", \\\"{x:1613,y:551,t:1528143940958};\\\", \\\"{x:1613,y:545,t:1528143940974};\\\", \\\"{x:1613,y:538,t:1528143940992};\\\", \\\"{x:1613,y:530,t:1528143941009};\\\", \\\"{x:1613,y:525,t:1528143941025};\\\", \\\"{x:1613,y:516,t:1528143941042};\\\", \\\"{x:1613,y:510,t:1528143941059};\\\", \\\"{x:1612,y:503,t:1528143941074};\\\", \\\"{x:1612,y:494,t:1528143941091};\\\", \\\"{x:1611,y:482,t:1528143941109};\\\", \\\"{x:1611,y:475,t:1528143941124};\\\", \\\"{x:1611,y:465,t:1528143941141};\\\", \\\"{x:1610,y:461,t:1528143941159};\\\", \\\"{x:1610,y:457,t:1528143941175};\\\", \\\"{x:1609,y:454,t:1528143941192};\\\", \\\"{x:1609,y:450,t:1528143941208};\\\", \\\"{x:1608,y:445,t:1528143941224};\\\", \\\"{x:1608,y:441,t:1528143941241};\\\", \\\"{x:1606,y:435,t:1528143941258};\\\", \\\"{x:1604,y:432,t:1528143941275};\\\", \\\"{x:1604,y:430,t:1528143941291};\\\", \\\"{x:1603,y:429,t:1528143941309};\\\", \\\"{x:1602,y:429,t:1528143941324};\\\", \\\"{x:1602,y:426,t:1528143942070};\\\", \\\"{x:1606,y:424,t:1528143942078};\\\", \\\"{x:1608,y:424,t:1528143942093};\\\", \\\"{x:1609,y:424,t:1528143942439};\\\", \\\"{x:1609,y:426,t:1528143942638};\\\", \\\"{x:1608,y:427,t:1528143942646};\\\", \\\"{x:1608,y:428,t:1528143942660};\\\", \\\"{x:1607,y:430,t:1528143942677};\\\", \\\"{x:1607,y:434,t:1528143942694};\\\", \\\"{x:1606,y:437,t:1528143942710};\\\", \\\"{x:1606,y:441,t:1528143942727};\\\", \\\"{x:1606,y:444,t:1528143942744};\\\", \\\"{x:1605,y:447,t:1528143942760};\\\", \\\"{x:1605,y:451,t:1528143942776};\\\", \\\"{x:1605,y:455,t:1528143942794};\\\", \\\"{x:1605,y:461,t:1528143942809};\\\", \\\"{x:1605,y:464,t:1528143942827};\\\", \\\"{x:1605,y:469,t:1528143942844};\\\", \\\"{x:1605,y:476,t:1528143942860};\\\", \\\"{x:1605,y:483,t:1528143942877};\\\", \\\"{x:1606,y:492,t:1528143942893};\\\", \\\"{x:1606,y:498,t:1528143942910};\\\", \\\"{x:1606,y:504,t:1528143942927};\\\", \\\"{x:1606,y:509,t:1528143942943};\\\", \\\"{x:1606,y:512,t:1528143942961};\\\", \\\"{x:1607,y:515,t:1528143942977};\\\", \\\"{x:1608,y:518,t:1528143942994};\\\", \\\"{x:1608,y:523,t:1528143943010};\\\", \\\"{x:1609,y:528,t:1528143943026};\\\", \\\"{x:1609,y:533,t:1528143943044};\\\", \\\"{x:1609,y:538,t:1528143943061};\\\", \\\"{x:1609,y:543,t:1528143943077};\\\", \\\"{x:1610,y:548,t:1528143943094};\\\", \\\"{x:1610,y:550,t:1528143943111};\\\", \\\"{x:1610,y:553,t:1528143943127};\\\", \\\"{x:1610,y:557,t:1528143943144};\\\", \\\"{x:1610,y:562,t:1528143943160};\\\", \\\"{x:1610,y:571,t:1528143943178};\\\", \\\"{x:1610,y:579,t:1528143943194};\\\", \\\"{x:1610,y:586,t:1528143943211};\\\", \\\"{x:1610,y:591,t:1528143943228};\\\", \\\"{x:1610,y:594,t:1528143943245};\\\", \\\"{x:1610,y:598,t:1528143943261};\\\", \\\"{x:1609,y:605,t:1528143943278};\\\", \\\"{x:1608,y:616,t:1528143943294};\\\", \\\"{x:1606,y:633,t:1528143943311};\\\", \\\"{x:1606,y:649,t:1528143943328};\\\", \\\"{x:1606,y:658,t:1528143943344};\\\", \\\"{x:1606,y:664,t:1528143943361};\\\", \\\"{x:1606,y:668,t:1528143943377};\\\", \\\"{x:1606,y:673,t:1528143943393};\\\", \\\"{x:1607,y:680,t:1528143943411};\\\", \\\"{x:1607,y:681,t:1528143943428};\\\", \\\"{x:1608,y:684,t:1528143943444};\\\", \\\"{x:1609,y:686,t:1528143943461};\\\", \\\"{x:1610,y:687,t:1528143943502};\\\", \\\"{x:1611,y:688,t:1528143943718};\\\", \\\"{x:1612,y:689,t:1528143943728};\\\", \\\"{x:1612,y:691,t:1528143943745};\\\", \\\"{x:1613,y:692,t:1528143943761};\\\", \\\"{x:1613,y:693,t:1528143943794};\\\", \\\"{x:1614,y:694,t:1528143943830};\\\", \\\"{x:1614,y:690,t:1528143949551};\\\", \\\"{x:1614,y:680,t:1528143949568};\\\", \\\"{x:1614,y:675,t:1528143949584};\\\", \\\"{x:1614,y:669,t:1528143949601};\\\", \\\"{x:1614,y:665,t:1528143949618};\\\", \\\"{x:1614,y:663,t:1528143949634};\\\", \\\"{x:1614,y:661,t:1528143949651};\\\", \\\"{x:1614,y:659,t:1528143949670};\\\", \\\"{x:1614,y:658,t:1528143949694};\\\", \\\"{x:1614,y:656,t:1528143949710};\\\", \\\"{x:1614,y:655,t:1528143949726};\\\", \\\"{x:1614,y:654,t:1528143949734};\\\", \\\"{x:1614,y:652,t:1528143949751};\\\", \\\"{x:1614,y:649,t:1528143949768};\\\", \\\"{x:1614,y:647,t:1528143949785};\\\", \\\"{x:1614,y:645,t:1528143949801};\\\", \\\"{x:1612,y:641,t:1528143949818};\\\", \\\"{x:1612,y:638,t:1528143949835};\\\", \\\"{x:1612,y:632,t:1528143949851};\\\", \\\"{x:1612,y:626,t:1528143949868};\\\", \\\"{x:1612,y:620,t:1528143949885};\\\", \\\"{x:1611,y:612,t:1528143949901};\\\", \\\"{x:1610,y:607,t:1528143949917};\\\", \\\"{x:1610,y:603,t:1528143949935};\\\", \\\"{x:1610,y:599,t:1528143949951};\\\", \\\"{x:1610,y:595,t:1528143949968};\\\", \\\"{x:1610,y:591,t:1528143949985};\\\", \\\"{x:1610,y:588,t:1528143950001};\\\", \\\"{x:1610,y:584,t:1528143950018};\\\", \\\"{x:1610,y:580,t:1528143950035};\\\", \\\"{x:1610,y:576,t:1528143950051};\\\", \\\"{x:1610,y:570,t:1528143950067};\\\", \\\"{x:1611,y:561,t:1528143950084};\\\", \\\"{x:1611,y:560,t:1528143950100};\\\", \\\"{x:1611,y:556,t:1528143950118};\\\", \\\"{x:1611,y:551,t:1528143950134};\\\", \\\"{x:1611,y:549,t:1528143950152};\\\", \\\"{x:1611,y:547,t:1528143950167};\\\", \\\"{x:1611,y:546,t:1528143950184};\\\", \\\"{x:1611,y:545,t:1528143950213};\\\", \\\"{x:1611,y:544,t:1528143950495};\\\", \\\"{x:1611,y:545,t:1528143951318};\\\", \\\"{x:1610,y:545,t:1528143951341};\\\", \\\"{x:1608,y:549,t:1528143951353};\\\", \\\"{x:1607,y:554,t:1528143951370};\\\", \\\"{x:1605,y:558,t:1528143951386};\\\", \\\"{x:1604,y:560,t:1528143951402};\\\", \\\"{x:1604,y:563,t:1528143951419};\\\", \\\"{x:1603,y:569,t:1528143951436};\\\", \\\"{x:1599,y:579,t:1528143951453};\\\", \\\"{x:1596,y:588,t:1528143951469};\\\", \\\"{x:1594,y:597,t:1528143951486};\\\", \\\"{x:1591,y:605,t:1528143951502};\\\", \\\"{x:1590,y:612,t:1528143951520};\\\", \\\"{x:1588,y:618,t:1528143951536};\\\", \\\"{x:1586,y:626,t:1528143951552};\\\", \\\"{x:1585,y:636,t:1528143951570};\\\", \\\"{x:1583,y:645,t:1528143951585};\\\", \\\"{x:1582,y:652,t:1528143951603};\\\", \\\"{x:1582,y:657,t:1528143951620};\\\", \\\"{x:1581,y:662,t:1528143951636};\\\", \\\"{x:1581,y:666,t:1528143951654};\\\", \\\"{x:1581,y:669,t:1528143951670};\\\", \\\"{x:1581,y:670,t:1528143951687};\\\", \\\"{x:1581,y:672,t:1528143951703};\\\", \\\"{x:1581,y:673,t:1528143951720};\\\", \\\"{x:1581,y:676,t:1528143951738};\\\", \\\"{x:1583,y:679,t:1528143951753};\\\", \\\"{x:1583,y:681,t:1528143951770};\\\", \\\"{x:1583,y:682,t:1528143951787};\\\", \\\"{x:1584,y:682,t:1528143951804};\\\", \\\"{x:1585,y:683,t:1528143951845};\\\", \\\"{x:1589,y:681,t:1528143951951};\\\", \\\"{x:1595,y:672,t:1528143951957};\\\", \\\"{x:1601,y:665,t:1528143951970};\\\", \\\"{x:1607,y:651,t:1528143951987};\\\", \\\"{x:1612,y:638,t:1528143952003};\\\", \\\"{x:1617,y:626,t:1528143952020};\\\", \\\"{x:1621,y:610,t:1528143952037};\\\", \\\"{x:1624,y:595,t:1528143952054};\\\", \\\"{x:1627,y:582,t:1528143952070};\\\", \\\"{x:1629,y:573,t:1528143952087};\\\", \\\"{x:1629,y:571,t:1528143952104};\\\", \\\"{x:1629,y:569,t:1528143952120};\\\", \\\"{x:1629,y:567,t:1528143952138};\\\", \\\"{x:1629,y:566,t:1528143952154};\\\", \\\"{x:1629,y:563,t:1528143952170};\\\", \\\"{x:1627,y:558,t:1528143952188};\\\", \\\"{x:1626,y:557,t:1528143952204};\\\", \\\"{x:1626,y:555,t:1528143952220};\\\", \\\"{x:1624,y:554,t:1528143952238};\\\", \\\"{x:1623,y:553,t:1528143952253};\\\", \\\"{x:1620,y:551,t:1528143952270};\\\", \\\"{x:1617,y:548,t:1528143952287};\\\", \\\"{x:1612,y:541,t:1528143952304};\\\", \\\"{x:1604,y:533,t:1528143952321};\\\", \\\"{x:1599,y:527,t:1528143952337};\\\", \\\"{x:1596,y:524,t:1528143952354};\\\", \\\"{x:1595,y:522,t:1528143952371};\\\", \\\"{x:1594,y:520,t:1528143952387};\\\", \\\"{x:1593,y:518,t:1528143952404};\\\", \\\"{x:1588,y:513,t:1528143952422};\\\", \\\"{x:1588,y:511,t:1528143952437};\\\", \\\"{x:1587,y:509,t:1528143952454};\\\", \\\"{x:1586,y:506,t:1528143952471};\\\", \\\"{x:1586,y:503,t:1528143952488};\\\", \\\"{x:1585,y:501,t:1528143952504};\\\", \\\"{x:1584,y:499,t:1528143952521};\\\", \\\"{x:1584,y:497,t:1528143952537};\\\", \\\"{x:1584,y:496,t:1528143952558};\\\", \\\"{x:1583,y:496,t:1528143952574};\\\", \\\"{x:1582,y:496,t:1528143952598};\\\", \\\"{x:1582,y:495,t:1528143953830};\\\", \\\"{x:1582,y:492,t:1528143954806};\\\", \\\"{x:1588,y:481,t:1528143954824};\\\", \\\"{x:1595,y:469,t:1528143954841};\\\", \\\"{x:1598,y:462,t:1528143954857};\\\", \\\"{x:1601,y:458,t:1528143954873};\\\", \\\"{x:1601,y:457,t:1528143954890};\\\", \\\"{x:1601,y:456,t:1528143954907};\\\", \\\"{x:1601,y:455,t:1528143954966};\\\", \\\"{x:1601,y:454,t:1528143954990};\\\", \\\"{x:1605,y:448,t:1528143955007};\\\", \\\"{x:1607,y:447,t:1528143955024};\\\", \\\"{x:1609,y:444,t:1528143955041};\\\", \\\"{x:1613,y:440,t:1528143955057};\\\", \\\"{x:1615,y:437,t:1528143955074};\\\", \\\"{x:1617,y:435,t:1528143955091};\\\", \\\"{x:1617,y:434,t:1528143955107};\\\", \\\"{x:1618,y:434,t:1528143955124};\\\", \\\"{x:1618,y:433,t:1528143955158};\\\", \\\"{x:1619,y:433,t:1528143955173};\\\", \\\"{x:1620,y:431,t:1528143955190};\\\", \\\"{x:1620,y:428,t:1528143955207};\\\", \\\"{x:1618,y:427,t:1528143955446};\\\", \\\"{x:1614,y:426,t:1528143955458};\\\", \\\"{x:1598,y:421,t:1528143955474};\\\", \\\"{x:1593,y:419,t:1528143955491};\\\", \\\"{x:1590,y:415,t:1528143955510};\\\", \\\"{x:1586,y:408,t:1528143955524};\\\", \\\"{x:1574,y:390,t:1528143955542};\\\", \\\"{x:1567,y:382,t:1528143955558};\\\", \\\"{x:1563,y:376,t:1528143955574};\\\", \\\"{x:1559,y:373,t:1528143955591};\\\", \\\"{x:1558,y:373,t:1528143955774};\\\", \\\"{x:1559,y:386,t:1528143955791};\\\", \\\"{x:1561,y:399,t:1528143955808};\\\", \\\"{x:1565,y:418,t:1528143955824};\\\", \\\"{x:1566,y:437,t:1528143955841};\\\", \\\"{x:1569,y:453,t:1528143955857};\\\", \\\"{x:1572,y:469,t:1528143955874};\\\", \\\"{x:1574,y:487,t:1528143955891};\\\", \\\"{x:1577,y:503,t:1528143955908};\\\", \\\"{x:1580,y:514,t:1528143955924};\\\", \\\"{x:1581,y:520,t:1528143955940};\\\", \\\"{x:1583,y:522,t:1528143955958};\\\", \\\"{x:1583,y:525,t:1528143955974};\\\", \\\"{x:1584,y:530,t:1528143955991};\\\", \\\"{x:1585,y:537,t:1528143956008};\\\", \\\"{x:1588,y:545,t:1528143956024};\\\", \\\"{x:1592,y:551,t:1528143956041};\\\", \\\"{x:1596,y:556,t:1528143956058};\\\", \\\"{x:1599,y:560,t:1528143956075};\\\", \\\"{x:1600,y:561,t:1528143956090};\\\", \\\"{x:1601,y:562,t:1528143956108};\\\", \\\"{x:1602,y:562,t:1528143956125};\\\", \\\"{x:1602,y:564,t:1528143956206};\\\", \\\"{x:1602,y:566,t:1528143956214};\\\", \\\"{x:1602,y:568,t:1528143956226};\\\", \\\"{x:1602,y:572,t:1528143956241};\\\", \\\"{x:1600,y:578,t:1528143956258};\\\", \\\"{x:1598,y:581,t:1528143956275};\\\", \\\"{x:1597,y:586,t:1528143956292};\\\", \\\"{x:1595,y:590,t:1528143956308};\\\", \\\"{x:1589,y:598,t:1528143956326};\\\", \\\"{x:1585,y:602,t:1528143956341};\\\", \\\"{x:1581,y:608,t:1528143956358};\\\", \\\"{x:1579,y:611,t:1528143956376};\\\", \\\"{x:1578,y:611,t:1528143956392};\\\", \\\"{x:1577,y:613,t:1528143956408};\\\", \\\"{x:1576,y:614,t:1528143956470};\\\", \\\"{x:1576,y:616,t:1528143956502};\\\", \\\"{x:1576,y:617,t:1528143956517};\\\", \\\"{x:1576,y:618,t:1528143956534};\\\", \\\"{x:1576,y:619,t:1528143956541};\\\", \\\"{x:1576,y:620,t:1528143956566};\\\", \\\"{x:1576,y:621,t:1528143956590};\\\", \\\"{x:1578,y:620,t:1528143957989};\\\", \\\"{x:1580,y:618,t:1528143957997};\\\", \\\"{x:1582,y:616,t:1528143958013};\\\", \\\"{x:1583,y:615,t:1528143958028};\\\", \\\"{x:1584,y:614,t:1528143958052};\\\", \\\"{x:1585,y:613,t:1528143958070};\\\", \\\"{x:1586,y:612,t:1528143958093};\\\", \\\"{x:1587,y:611,t:1528143958125};\\\", \\\"{x:1588,y:610,t:1528143958150};\\\", \\\"{x:1588,y:609,t:1528143958165};\\\", \\\"{x:1589,y:609,t:1528143958178};\\\", \\\"{x:1589,y:608,t:1528143958193};\\\", \\\"{x:1590,y:607,t:1528143958210};\\\", \\\"{x:1592,y:605,t:1528143958228};\\\", \\\"{x:1593,y:604,t:1528143958244};\\\", \\\"{x:1594,y:603,t:1528143958261};\\\", \\\"{x:1596,y:600,t:1528143958278};\\\", \\\"{x:1599,y:596,t:1528143958294};\\\", \\\"{x:1602,y:591,t:1528143958310};\\\", \\\"{x:1606,y:587,t:1528143958328};\\\", \\\"{x:1609,y:584,t:1528143958344};\\\", \\\"{x:1610,y:583,t:1528143958361};\\\", \\\"{x:1611,y:582,t:1528143958377};\\\", \\\"{x:1612,y:580,t:1528143958394};\\\", \\\"{x:1613,y:579,t:1528143958411};\\\", \\\"{x:1614,y:578,t:1528143958428};\\\", \\\"{x:1615,y:576,t:1528143958445};\\\", \\\"{x:1616,y:574,t:1528143958461};\\\", \\\"{x:1616,y:573,t:1528143958477};\\\", \\\"{x:1617,y:573,t:1528143958496};\\\", \\\"{x:1617,y:571,t:1528143958510};\\\", \\\"{x:1619,y:569,t:1528143958527};\\\", \\\"{x:1619,y:568,t:1528143958544};\\\", \\\"{x:1620,y:567,t:1528143958561};\\\", \\\"{x:1620,y:566,t:1528143958577};\\\", \\\"{x:1620,y:565,t:1528143958595};\\\", \\\"{x:1621,y:564,t:1528143958612};\\\", \\\"{x:1622,y:564,t:1528143958627};\\\", \\\"{x:1616,y:578,t:1528143960710};\\\", \\\"{x:1607,y:596,t:1528143960717};\\\", \\\"{x:1603,y:606,t:1528143960729};\\\", \\\"{x:1599,y:615,t:1528143960746};\\\", \\\"{x:1598,y:621,t:1528143960764};\\\", \\\"{x:1595,y:627,t:1528143960780};\\\", \\\"{x:1594,y:629,t:1528143960797};\\\", \\\"{x:1594,y:630,t:1528143960814};\\\", \\\"{x:1594,y:632,t:1528143960831};\\\", \\\"{x:1593,y:633,t:1528143960853};\\\", \\\"{x:1593,y:634,t:1528143960870};\\\", \\\"{x:1593,y:637,t:1528143960881};\\\", \\\"{x:1592,y:641,t:1528143960897};\\\", \\\"{x:1592,y:644,t:1528143960913};\\\", \\\"{x:1592,y:635,t:1528143961028};\\\", \\\"{x:1594,y:619,t:1528143961037};\\\", \\\"{x:1597,y:610,t:1528143961046};\\\", \\\"{x:1601,y:596,t:1528143961063};\\\", \\\"{x:1604,y:575,t:1528143961080};\\\", \\\"{x:1605,y:559,t:1528143961098};\\\", \\\"{x:1605,y:545,t:1528143961114};\\\", \\\"{x:1605,y:528,t:1528143961130};\\\", \\\"{x:1605,y:519,t:1528143961147};\\\", \\\"{x:1605,y:515,t:1528143961163};\\\", \\\"{x:1604,y:511,t:1528143961181};\\\", \\\"{x:1604,y:506,t:1528143961197};\\\", \\\"{x:1604,y:501,t:1528143961213};\\\", \\\"{x:1603,y:498,t:1528143961230};\\\", \\\"{x:1602,y:494,t:1528143961247};\\\", \\\"{x:1600,y:491,t:1528143961264};\\\", \\\"{x:1600,y:490,t:1528143961281};\\\", \\\"{x:1599,y:488,t:1528143961298};\\\", \\\"{x:1599,y:487,t:1528143961313};\\\", \\\"{x:1599,y:485,t:1528143961330};\\\", \\\"{x:1599,y:484,t:1528143961348};\\\", \\\"{x:1599,y:483,t:1528143961363};\\\", \\\"{x:1598,y:481,t:1528143961380};\\\", \\\"{x:1597,y:480,t:1528143961398};\\\", \\\"{x:1596,y:478,t:1528143961414};\\\", \\\"{x:1596,y:477,t:1528143961437};\\\", \\\"{x:1595,y:476,t:1528143961453};\\\", \\\"{x:1595,y:475,t:1528143961465};\\\", \\\"{x:1594,y:475,t:1528143961510};\\\", \\\"{x:1594,y:474,t:1528143961766};\\\", \\\"{x:1594,y:472,t:1528143961782};\\\", \\\"{x:1594,y:470,t:1528143961797};\\\", \\\"{x:1594,y:468,t:1528143961815};\\\", \\\"{x:1594,y:467,t:1528143961831};\\\", \\\"{x:1594,y:466,t:1528143961847};\\\", \\\"{x:1595,y:466,t:1528143961869};\\\", \\\"{x:1595,y:465,t:1528143961893};\\\", \\\"{x:1596,y:463,t:1528143962166};\\\", \\\"{x:1598,y:461,t:1528143962182};\\\", \\\"{x:1601,y:456,t:1528143962199};\\\", \\\"{x:1602,y:448,t:1528143962215};\\\", \\\"{x:1602,y:433,t:1528143962232};\\\", \\\"{x:1602,y:423,t:1528143962249};\\\", \\\"{x:1602,y:416,t:1528143962265};\\\", \\\"{x:1602,y:410,t:1528143962282};\\\", \\\"{x:1602,y:403,t:1528143962299};\\\", \\\"{x:1602,y:395,t:1528143962314};\\\", \\\"{x:1602,y:387,t:1528143962332};\\\", \\\"{x:1602,y:383,t:1528143962349};\\\", \\\"{x:1602,y:376,t:1528143962365};\\\", \\\"{x:1601,y:374,t:1528143962381};\\\", \\\"{x:1600,y:371,t:1528143962398};\\\", \\\"{x:1599,y:370,t:1528143962429};\\\", \\\"{x:1598,y:369,t:1528143962454};\\\", \\\"{x:1596,y:369,t:1528143962526};\\\", \\\"{x:1594,y:369,t:1528143962534};\\\", \\\"{x:1591,y:369,t:1528143962549};\\\", \\\"{x:1578,y:369,t:1528143962566};\\\", \\\"{x:1572,y:370,t:1528143962582};\\\", \\\"{x:1569,y:370,t:1528143962599};\\\", \\\"{x:1567,y:370,t:1528143962616};\\\", \\\"{x:1568,y:370,t:1528143962830};\\\", \\\"{x:1570,y:370,t:1528143962837};\\\", \\\"{x:1572,y:370,t:1528143962854};\\\", \\\"{x:1573,y:370,t:1528143962865};\\\", \\\"{x:1576,y:370,t:1528143962883};\\\", \\\"{x:1578,y:370,t:1528143962898};\\\", \\\"{x:1579,y:370,t:1528143962916};\\\", \\\"{x:1581,y:369,t:1528143962942};\\\", \\\"{x:1583,y:369,t:1528143962966};\\\", \\\"{x:1584,y:369,t:1528143962982};\\\", \\\"{x:1586,y:368,t:1528143963000};\\\", \\\"{x:1587,y:368,t:1528143963016};\\\", \\\"{x:1587,y:367,t:1528143963032};\\\", \\\"{x:1588,y:367,t:1528143963060};\\\", \\\"{x:1588,y:366,t:1528143963076};\\\", \\\"{x:1589,y:366,t:1528143963101};\\\", \\\"{x:1589,y:365,t:1528143963116};\\\", \\\"{x:1590,y:365,t:1528143963188};\\\", \\\"{x:1591,y:365,t:1528143963629};\\\", \\\"{x:1590,y:363,t:1528143963636};\\\", \\\"{x:1589,y:362,t:1528143963653};\\\", \\\"{x:1588,y:360,t:1528143963668};\\\", \\\"{x:1586,y:358,t:1528143963683};\\\", \\\"{x:1585,y:356,t:1528143963699};\\\", \\\"{x:1584,y:354,t:1528143963716};\\\", \\\"{x:1584,y:363,t:1528143965430};\\\", \\\"{x:1579,y:417,t:1528143965453};\\\", \\\"{x:1567,y:476,t:1528143965469};\\\", \\\"{x:1556,y:543,t:1528143965485};\\\", \\\"{x:1553,y:571,t:1528143965502};\\\", \\\"{x:1551,y:585,t:1528143965518};\\\", \\\"{x:1551,y:600,t:1528143965536};\\\", \\\"{x:1551,y:617,t:1528143965552};\\\", \\\"{x:1550,y:628,t:1528143965569};\\\", \\\"{x:1550,y:637,t:1528143965586};\\\", \\\"{x:1550,y:646,t:1528143965602};\\\", \\\"{x:1550,y:659,t:1528143965619};\\\", \\\"{x:1550,y:666,t:1528143965636};\\\", \\\"{x:1551,y:674,t:1528143965652};\\\", \\\"{x:1554,y:679,t:1528143965669};\\\", \\\"{x:1555,y:680,t:1528143965685};\\\", \\\"{x:1557,y:680,t:1528143965701};\\\", \\\"{x:1558,y:681,t:1528143965719};\\\", \\\"{x:1560,y:681,t:1528143965736};\\\", \\\"{x:1565,y:682,t:1528143965752};\\\", \\\"{x:1569,y:683,t:1528143965769};\\\", \\\"{x:1573,y:683,t:1528143965786};\\\", \\\"{x:1579,y:683,t:1528143965802};\\\", \\\"{x:1586,y:683,t:1528143965819};\\\", \\\"{x:1592,y:683,t:1528143965836};\\\", \\\"{x:1595,y:685,t:1528143965853};\\\", \\\"{x:1596,y:686,t:1528143965869};\\\", \\\"{x:1598,y:686,t:1528143965885};\\\", \\\"{x:1600,y:687,t:1528143965950};\\\", \\\"{x:1603,y:688,t:1528143965957};\\\", \\\"{x:1603,y:689,t:1528143965974};\\\", \\\"{x:1604,y:689,t:1528143965986};\\\", \\\"{x:1605,y:689,t:1528143966003};\\\", \\\"{x:1607,y:690,t:1528143966019};\\\", \\\"{x:1609,y:692,t:1528143966036};\\\", \\\"{x:1611,y:692,t:1528143966054};\\\", \\\"{x:1613,y:692,t:1528143966070};\\\", \\\"{x:1614,y:693,t:1528143966085};\\\", \\\"{x:1615,y:694,t:1528143966109};\\\", \\\"{x:1617,y:695,t:1528143966119};\\\", \\\"{x:1619,y:696,t:1528143966136};\\\", \\\"{x:1621,y:698,t:1528143966154};\\\", \\\"{x:1622,y:700,t:1528143966169};\\\", \\\"{x:1622,y:698,t:1528143966253};\\\", \\\"{x:1622,y:686,t:1528143966270};\\\", \\\"{x:1625,y:672,t:1528143966286};\\\", \\\"{x:1627,y:660,t:1528143966303};\\\", \\\"{x:1627,y:652,t:1528143966320};\\\", \\\"{x:1627,y:645,t:1528143966335};\\\", \\\"{x:1628,y:641,t:1528143966353};\\\", \\\"{x:1628,y:636,t:1528143966369};\\\", \\\"{x:1628,y:630,t:1528143966386};\\\", \\\"{x:1628,y:624,t:1528143966403};\\\", \\\"{x:1628,y:621,t:1528143966420};\\\", \\\"{x:1628,y:619,t:1528143966436};\\\", \\\"{x:1628,y:618,t:1528143966550};\\\", \\\"{x:1628,y:616,t:1528143966566};\\\", \\\"{x:1628,y:615,t:1528143966574};\\\", \\\"{x:1628,y:614,t:1528143966587};\\\", \\\"{x:1628,y:613,t:1528143966602};\\\", \\\"{x:1628,y:611,t:1528143966619};\\\", \\\"{x:1628,y:610,t:1528143966637};\\\", \\\"{x:1627,y:608,t:1528143966654};\\\", \\\"{x:1627,y:606,t:1528143966669};\\\", \\\"{x:1626,y:603,t:1528143966687};\\\", \\\"{x:1626,y:602,t:1528143966702};\\\", \\\"{x:1626,y:599,t:1528143966720};\\\", \\\"{x:1626,y:598,t:1528143966737};\\\", \\\"{x:1626,y:596,t:1528143966753};\\\", \\\"{x:1626,y:591,t:1528143966770};\\\", \\\"{x:1626,y:586,t:1528143966787};\\\", \\\"{x:1626,y:581,t:1528143966804};\\\", \\\"{x:1626,y:575,t:1528143966820};\\\", \\\"{x:1626,y:567,t:1528143966837};\\\", \\\"{x:1626,y:564,t:1528143966853};\\\", \\\"{x:1626,y:561,t:1528143966870};\\\", \\\"{x:1627,y:560,t:1528143966887};\\\", \\\"{x:1627,y:555,t:1528143966904};\\\", \\\"{x:1628,y:552,t:1528143966920};\\\", \\\"{x:1629,y:544,t:1528143966936};\\\", \\\"{x:1630,y:538,t:1528143966954};\\\", \\\"{x:1630,y:535,t:1528143966970};\\\", \\\"{x:1630,y:528,t:1528143966987};\\\", \\\"{x:1630,y:523,t:1528143967003};\\\", \\\"{x:1630,y:515,t:1528143967020};\\\", \\\"{x:1631,y:505,t:1528143967037};\\\", \\\"{x:1631,y:491,t:1528143967053};\\\", \\\"{x:1631,y:478,t:1528143967070};\\\", \\\"{x:1631,y:468,t:1528143967087};\\\", \\\"{x:1631,y:459,t:1528143967103};\\\", \\\"{x:1631,y:452,t:1528143967120};\\\", \\\"{x:1631,y:447,t:1528143967136};\\\", \\\"{x:1631,y:443,t:1528143967153};\\\", \\\"{x:1631,y:440,t:1528143967170};\\\", \\\"{x:1631,y:439,t:1528143967186};\\\", \\\"{x:1631,y:437,t:1528143967203};\\\", \\\"{x:1630,y:436,t:1528143967374};\\\", \\\"{x:1628,y:436,t:1528143967406};\\\", \\\"{x:1624,y:438,t:1528143967421};\\\", \\\"{x:1619,y:440,t:1528143967438};\\\", \\\"{x:1618,y:440,t:1528143967455};\\\", \\\"{x:1618,y:441,t:1528143967670};\\\", \\\"{x:1617,y:441,t:1528143967701};\\\", \\\"{x:1616,y:450,t:1528143967918};\\\", \\\"{x:1616,y:465,t:1528143967925};\\\", \\\"{x:1616,y:479,t:1528143967937};\\\", \\\"{x:1616,y:505,t:1528143967955};\\\", \\\"{x:1616,y:528,t:1528143967971};\\\", \\\"{x:1616,y:549,t:1528143967988};\\\", \\\"{x:1616,y:564,t:1528143968005};\\\", \\\"{x:1616,y:574,t:1528143968021};\\\", \\\"{x:1616,y:583,t:1528143968038};\\\", \\\"{x:1617,y:591,t:1528143968055};\\\", \\\"{x:1617,y:602,t:1528143968072};\\\", \\\"{x:1617,y:613,t:1528143968088};\\\", \\\"{x:1617,y:627,t:1528143968105};\\\", \\\"{x:1618,y:632,t:1528143968122};\\\", \\\"{x:1619,y:638,t:1528143968138};\\\", \\\"{x:1619,y:639,t:1528143968155};\\\", \\\"{x:1620,y:641,t:1528143968172};\\\", \\\"{x:1620,y:642,t:1528143968198};\\\", \\\"{x:1620,y:643,t:1528143968230};\\\", \\\"{x:1620,y:644,t:1528143968237};\\\", \\\"{x:1620,y:647,t:1528143968255};\\\", \\\"{x:1620,y:648,t:1528143968272};\\\", \\\"{x:1620,y:651,t:1528143968288};\\\", \\\"{x:1620,y:655,t:1528143968305};\\\", \\\"{x:1620,y:659,t:1528143968322};\\\", \\\"{x:1620,y:665,t:1528143968338};\\\", \\\"{x:1620,y:670,t:1528143968355};\\\", \\\"{x:1620,y:672,t:1528143968372};\\\", \\\"{x:1620,y:674,t:1528143968388};\\\", \\\"{x:1620,y:677,t:1528143968405};\\\", \\\"{x:1620,y:683,t:1528143968422};\\\", \\\"{x:1620,y:686,t:1528143968439};\\\", \\\"{x:1620,y:687,t:1528143968456};\\\", \\\"{x:1620,y:688,t:1528143968472};\\\", \\\"{x:1620,y:689,t:1528143968489};\\\", \\\"{x:1620,y:690,t:1528143968505};\\\", \\\"{x:1620,y:691,t:1528143968644};\\\", \\\"{x:1620,y:692,t:1528143968655};\\\", \\\"{x:1620,y:693,t:1528143968949};\\\", \\\"{x:1619,y:695,t:1528143969023};\\\", \\\"{x:1615,y:701,t:1528143969039};\\\", \\\"{x:1611,y:706,t:1528143969057};\\\", \\\"{x:1610,y:711,t:1528143969073};\\\", \\\"{x:1608,y:716,t:1528143969089};\\\", \\\"{x:1607,y:718,t:1528143969106};\\\", \\\"{x:1606,y:721,t:1528143969123};\\\", \\\"{x:1605,y:724,t:1528143969139};\\\", \\\"{x:1604,y:726,t:1528143969156};\\\", \\\"{x:1603,y:730,t:1528143969173};\\\", \\\"{x:1603,y:731,t:1528143969189};\\\", \\\"{x:1601,y:732,t:1528143969206};\\\", \\\"{x:1601,y:734,t:1528143969223};\\\", \\\"{x:1601,y:736,t:1528143969245};\\\", \\\"{x:1601,y:737,t:1528143969256};\\\", \\\"{x:1601,y:739,t:1528143969273};\\\", \\\"{x:1601,y:741,t:1528143969309};\\\", \\\"{x:1600,y:741,t:1528143969325};\\\", \\\"{x:1600,y:742,t:1528143969341};\\\", \\\"{x:1600,y:743,t:1528143969382};\\\", \\\"{x:1600,y:744,t:1528143969389};\\\", \\\"{x:1600,y:746,t:1528143969406};\\\", \\\"{x:1600,y:747,t:1528143969453};\\\", \\\"{x:1601,y:748,t:1528143969461};\\\", \\\"{x:1601,y:749,t:1528143969473};\\\", \\\"{x:1601,y:750,t:1528143969490};\\\", \\\"{x:1601,y:752,t:1528143969506};\\\", \\\"{x:1601,y:753,t:1528143969522};\\\", \\\"{x:1602,y:755,t:1528143969540};\\\", \\\"{x:1602,y:758,t:1528143969556};\\\", \\\"{x:1602,y:759,t:1528143969572};\\\", \\\"{x:1604,y:763,t:1528143969590};\\\", \\\"{x:1604,y:764,t:1528143969607};\\\", \\\"{x:1604,y:765,t:1528143969622};\\\", \\\"{x:1604,y:766,t:1528143969645};\\\", \\\"{x:1604,y:768,t:1528143969657};\\\", \\\"{x:1605,y:769,t:1528143969672};\\\", \\\"{x:1605,y:772,t:1528143969689};\\\", \\\"{x:1605,y:774,t:1528143969706};\\\", \\\"{x:1605,y:776,t:1528143969722};\\\", \\\"{x:1605,y:782,t:1528143969740};\\\", \\\"{x:1605,y:788,t:1528143969757};\\\", \\\"{x:1605,y:792,t:1528143969773};\\\", \\\"{x:1605,y:795,t:1528143969790};\\\", \\\"{x:1606,y:796,t:1528143969807};\\\", \\\"{x:1607,y:798,t:1528143969823};\\\", \\\"{x:1607,y:799,t:1528143969840};\\\", \\\"{x:1608,y:800,t:1528143969862};\\\", \\\"{x:1608,y:801,t:1528143969894};\\\", \\\"{x:1608,y:802,t:1528143969909};\\\", \\\"{x:1608,y:803,t:1528143970157};\\\", \\\"{x:1608,y:806,t:1528143970173};\\\", \\\"{x:1608,y:812,t:1528143970190};\\\", \\\"{x:1608,y:816,t:1528143970208};\\\", \\\"{x:1608,y:817,t:1528143970224};\\\", \\\"{x:1608,y:818,t:1528143970241};\\\", \\\"{x:1608,y:819,t:1528143970257};\\\", \\\"{x:1608,y:820,t:1528143970470};\\\", \\\"{x:1608,y:822,t:1528143970638};\\\", \\\"{x:1608,y:823,t:1528143970646};\\\", \\\"{x:1609,y:823,t:1528143970658};\\\", \\\"{x:1609,y:825,t:1528143970674};\\\", \\\"{x:1609,y:826,t:1528143970691};\\\", \\\"{x:1610,y:826,t:1528143970708};\\\", \\\"{x:1609,y:826,t:1528143973013};\\\", \\\"{x:1607,y:824,t:1528143973027};\\\", \\\"{x:1606,y:814,t:1528143973044};\\\", \\\"{x:1602,y:802,t:1528143973061};\\\", \\\"{x:1602,y:771,t:1528143973077};\\\", \\\"{x:1602,y:745,t:1528143973093};\\\", \\\"{x:1604,y:720,t:1528143973111};\\\", \\\"{x:1607,y:701,t:1528143973127};\\\", \\\"{x:1611,y:680,t:1528143973144};\\\", \\\"{x:1613,y:664,t:1528143973161};\\\", \\\"{x:1614,y:652,t:1528143973177};\\\", \\\"{x:1615,y:643,t:1528143973194};\\\", \\\"{x:1615,y:639,t:1528143973210};\\\", \\\"{x:1618,y:636,t:1528143973227};\\\", \\\"{x:1618,y:633,t:1528143973245};\\\", \\\"{x:1619,y:632,t:1528143973260};\\\", \\\"{x:1619,y:630,t:1528143973278};\\\", \\\"{x:1620,y:629,t:1528143973294};\\\", \\\"{x:1619,y:629,t:1528143975150};\\\", \\\"{x:1618,y:629,t:1528143975174};\\\", \\\"{x:1617,y:629,t:1528143975181};\\\", \\\"{x:1615,y:629,t:1528143975197};\\\", \\\"{x:1614,y:629,t:1528143975213};\\\", \\\"{x:1612,y:629,t:1528143975228};\\\", \\\"{x:1611,y:629,t:1528143975324};\\\", \\\"{x:1610,y:629,t:1528143976254};\\\", \\\"{x:1609,y:630,t:1528143976710};\\\", \\\"{x:1608,y:630,t:1528143977102};\\\", \\\"{x:1608,y:631,t:1528143977214};\\\", \\\"{x:1607,y:631,t:1528143977221};\\\", \\\"{x:1607,y:632,t:1528143977357};\\\", \\\"{x:1606,y:632,t:1528143977502};\\\", \\\"{x:1605,y:633,t:1528143977532};\\\", \\\"{x:1604,y:634,t:1528143977549};\\\", \\\"{x:1603,y:635,t:1528143977564};\\\", \\\"{x:1602,y:635,t:1528143977588};\\\", \\\"{x:1598,y:637,t:1528143977934};\\\", \\\"{x:1596,y:643,t:1528143977949};\\\", \\\"{x:1594,y:645,t:1528143977965};\\\", \\\"{x:1594,y:648,t:1528143977982};\\\", \\\"{x:1594,y:649,t:1528143978000};\\\", \\\"{x:1594,y:650,t:1528143978015};\\\", \\\"{x:1594,y:652,t:1528143978033};\\\", \\\"{x:1594,y:653,t:1528143978049};\\\", \\\"{x:1594,y:656,t:1528143978066};\\\", \\\"{x:1594,y:658,t:1528143978083};\\\", \\\"{x:1593,y:662,t:1528143978099};\\\", \\\"{x:1593,y:666,t:1528143978116};\\\", \\\"{x:1592,y:670,t:1528143978132};\\\", \\\"{x:1592,y:674,t:1528143978149};\\\", \\\"{x:1592,y:676,t:1528143978166};\\\", \\\"{x:1592,y:677,t:1528143978189};\\\", \\\"{x:1592,y:676,t:1528143978293};\\\", \\\"{x:1592,y:667,t:1528143978301};\\\", \\\"{x:1594,y:658,t:1528143978316};\\\", \\\"{x:1599,y:640,t:1528143978332};\\\", \\\"{x:1602,y:615,t:1528143978349};\\\", \\\"{x:1603,y:605,t:1528143978366};\\\", \\\"{x:1604,y:596,t:1528143978382};\\\", \\\"{x:1604,y:589,t:1528143978399};\\\", \\\"{x:1606,y:583,t:1528143978417};\\\", \\\"{x:1606,y:577,t:1528143978433};\\\", \\\"{x:1606,y:573,t:1528143978449};\\\", \\\"{x:1606,y:569,t:1528143978467};\\\", \\\"{x:1606,y:567,t:1528143978483};\\\", \\\"{x:1606,y:566,t:1528143978499};\\\", \\\"{x:1607,y:564,t:1528143978588};\\\", \\\"{x:1608,y:564,t:1528143978645};\\\", \\\"{x:1608,y:563,t:1528143978701};\\\", \\\"{x:1609,y:563,t:1528143978758};\\\", \\\"{x:1602,y:567,t:1528143988726};\\\", \\\"{x:1566,y:586,t:1528143988733};\\\", \\\"{x:1530,y:599,t:1528143988744};\\\", \\\"{x:1447,y:621,t:1528143988760};\\\", \\\"{x:1364,y:644,t:1528143988778};\\\", \\\"{x:1300,y:661,t:1528143988795};\\\", \\\"{x:1250,y:674,t:1528143988811};\\\", \\\"{x:1227,y:679,t:1528143988828};\\\", \\\"{x:1198,y:691,t:1528143988845};\\\", \\\"{x:1170,y:701,t:1528143988861};\\\", \\\"{x:1144,y:714,t:1528143988878};\\\", \\\"{x:1111,y:727,t:1528143988897};\\\", \\\"{x:1081,y:741,t:1528143988911};\\\", \\\"{x:1054,y:750,t:1528143988927};\\\", \\\"{x:1034,y:759,t:1528143988945};\\\", \\\"{x:1017,y:769,t:1528143988961};\\\", \\\"{x:1002,y:776,t:1528143988978};\\\", \\\"{x:989,y:783,t:1528143988994};\\\", \\\"{x:978,y:786,t:1528143989011};\\\", \\\"{x:975,y:788,t:1528143989027};\\\", \\\"{x:973,y:789,t:1528143989045};\\\", \\\"{x:973,y:787,t:1528143989254};\\\", \\\"{x:993,y:782,t:1528143989261};\\\", \\\"{x:1037,y:773,t:1528143989277};\\\", \\\"{x:1079,y:766,t:1528143989296};\\\", \\\"{x:1127,y:764,t:1528143989312};\\\", \\\"{x:1162,y:764,t:1528143989328};\\\", \\\"{x:1184,y:764,t:1528143989345};\\\", \\\"{x:1189,y:764,t:1528143989363};\\\", \\\"{x:1190,y:764,t:1528143989377};\\\", \\\"{x:1191,y:764,t:1528143989395};\\\", \\\"{x:1192,y:764,t:1528143989909};\\\", \\\"{x:1198,y:767,t:1528143989917};\\\", \\\"{x:1207,y:773,t:1528143989929};\\\", \\\"{x:1215,y:786,t:1528143989946};\\\", \\\"{x:1221,y:795,t:1528143989962};\\\", \\\"{x:1226,y:803,t:1528143989979};\\\", \\\"{x:1226,y:809,t:1528143989996};\\\", \\\"{x:1227,y:813,t:1528143990012};\\\", \\\"{x:1228,y:816,t:1528143990028};\\\", \\\"{x:1228,y:817,t:1528143990269};\\\", \\\"{x:1229,y:814,t:1528143990437};\\\", \\\"{x:1229,y:812,t:1528143990446};\\\", \\\"{x:1234,y:803,t:1528143990463};\\\", \\\"{x:1238,y:793,t:1528143990480};\\\", \\\"{x:1240,y:784,t:1528143990496};\\\", \\\"{x:1245,y:777,t:1528143990512};\\\", \\\"{x:1249,y:770,t:1528143990529};\\\", \\\"{x:1252,y:765,t:1528143990545};\\\", \\\"{x:1255,y:758,t:1528143990563};\\\", \\\"{x:1260,y:751,t:1528143990579};\\\", \\\"{x:1260,y:747,t:1528143990596};\\\", \\\"{x:1268,y:738,t:1528143990612};\\\", \\\"{x:1270,y:735,t:1528143990629};\\\", \\\"{x:1272,y:732,t:1528143990646};\\\", \\\"{x:1276,y:726,t:1528143990662};\\\", \\\"{x:1280,y:721,t:1528143990680};\\\", \\\"{x:1282,y:715,t:1528143990696};\\\", \\\"{x:1284,y:710,t:1528143990713};\\\", \\\"{x:1288,y:705,t:1528143990730};\\\", \\\"{x:1290,y:700,t:1528143990747};\\\", \\\"{x:1296,y:691,t:1528143990763};\\\", \\\"{x:1302,y:680,t:1528143990779};\\\", \\\"{x:1316,y:662,t:1528143990797};\\\", \\\"{x:1323,y:648,t:1528143990813};\\\", \\\"{x:1334,y:632,t:1528143990830};\\\", \\\"{x:1346,y:612,t:1528143990847};\\\", \\\"{x:1362,y:591,t:1528143990863};\\\", \\\"{x:1373,y:574,t:1528143990880};\\\", \\\"{x:1380,y:562,t:1528143990897};\\\", \\\"{x:1387,y:551,t:1528143990913};\\\", \\\"{x:1393,y:540,t:1528143990929};\\\", \\\"{x:1396,y:530,t:1528143990947};\\\", \\\"{x:1399,y:523,t:1528143990963};\\\", \\\"{x:1402,y:515,t:1528143990979};\\\", \\\"{x:1405,y:510,t:1528143990997};\\\", \\\"{x:1405,y:507,t:1528143991013};\\\", \\\"{x:1405,y:506,t:1528143991030};\\\", \\\"{x:1405,y:513,t:1528143991278};\\\", \\\"{x:1402,y:527,t:1528143991285};\\\", \\\"{x:1399,y:539,t:1528143991297};\\\", \\\"{x:1392,y:568,t:1528143991314};\\\", \\\"{x:1385,y:591,t:1528143991331};\\\", \\\"{x:1376,y:615,t:1528143991347};\\\", \\\"{x:1361,y:657,t:1528143991363};\\\", \\\"{x:1330,y:730,t:1528143991381};\\\", \\\"{x:1317,y:757,t:1528143991397};\\\", \\\"{x:1315,y:765,t:1528143991414};\\\", \\\"{x:1318,y:745,t:1528143991621};\\\", \\\"{x:1327,y:718,t:1528143991631};\\\", \\\"{x:1332,y:700,t:1528143991648};\\\", \\\"{x:1337,y:683,t:1528143991664};\\\", \\\"{x:1340,y:673,t:1528143991681};\\\", \\\"{x:1343,y:666,t:1528143991698};\\\", \\\"{x:1344,y:664,t:1528143991714};\\\", \\\"{x:1346,y:662,t:1528143991731};\\\", \\\"{x:1346,y:661,t:1528143991748};\\\", \\\"{x:1347,y:660,t:1528143991764};\\\", \\\"{x:1349,y:660,t:1528143992357};\\\", \\\"{x:1368,y:655,t:1528143992366};\\\", \\\"{x:1425,y:653,t:1528143992382};\\\", \\\"{x:1461,y:653,t:1528143992398};\\\", \\\"{x:1493,y:653,t:1528143992415};\\\", \\\"{x:1516,y:660,t:1528143992432};\\\", \\\"{x:1528,y:664,t:1528143992448};\\\", \\\"{x:1530,y:666,t:1528143992465};\\\", \\\"{x:1530,y:672,t:1528143992482};\\\", \\\"{x:1532,y:681,t:1528143992498};\\\", \\\"{x:1532,y:692,t:1528143992515};\\\", \\\"{x:1532,y:707,t:1528143992532};\\\", \\\"{x:1532,y:718,t:1528143992548};\\\", \\\"{x:1532,y:733,t:1528143992565};\\\", \\\"{x:1530,y:744,t:1528143992581};\\\", \\\"{x:1525,y:753,t:1528143992599};\\\", \\\"{x:1522,y:762,t:1528143992615};\\\", \\\"{x:1519,y:769,t:1528143992632};\\\", \\\"{x:1518,y:773,t:1528143992648};\\\", \\\"{x:1517,y:777,t:1528143992665};\\\", \\\"{x:1517,y:779,t:1528143992682};\\\", \\\"{x:1516,y:783,t:1528143992699};\\\", \\\"{x:1514,y:791,t:1528143992715};\\\", \\\"{x:1513,y:799,t:1528143992731};\\\", \\\"{x:1506,y:817,t:1528143992749};\\\", \\\"{x:1500,y:827,t:1528143992765};\\\", \\\"{x:1498,y:833,t:1528143992781};\\\", \\\"{x:1498,y:840,t:1528143992798};\\\", \\\"{x:1498,y:849,t:1528143992816};\\\", \\\"{x:1507,y:861,t:1528143992832};\\\", \\\"{x:1517,y:875,t:1528143992849};\\\", \\\"{x:1527,y:892,t:1528143992866};\\\", \\\"{x:1541,y:917,t:1528143992881};\\\", \\\"{x:1552,y:933,t:1528143992899};\\\", \\\"{x:1559,y:945,t:1528143992916};\\\", \\\"{x:1562,y:951,t:1528143992932};\\\", \\\"{x:1564,y:953,t:1528143992949};\\\", \\\"{x:1565,y:955,t:1528143993205};\\\", \\\"{x:1569,y:955,t:1528143993216};\\\", \\\"{x:1582,y:946,t:1528143993233};\\\", \\\"{x:1596,y:931,t:1528143993249};\\\", \\\"{x:1610,y:911,t:1528143993266};\\\", \\\"{x:1620,y:889,t:1528143993283};\\\", \\\"{x:1625,y:869,t:1528143993299};\\\", \\\"{x:1625,y:851,t:1528143993316};\\\", \\\"{x:1622,y:818,t:1528143993334};\\\", \\\"{x:1617,y:794,t:1528143993349};\\\", \\\"{x:1611,y:769,t:1528143993366};\\\", \\\"{x:1602,y:753,t:1528143993383};\\\", \\\"{x:1595,y:741,t:1528143993399};\\\", \\\"{x:1591,y:733,t:1528143993416};\\\", \\\"{x:1589,y:731,t:1528143993433};\\\", \\\"{x:1590,y:731,t:1528143993628};\\\", \\\"{x:1598,y:729,t:1528143993636};\\\", \\\"{x:1604,y:729,t:1528143993649};\\\", \\\"{x:1615,y:727,t:1528143993665};\\\", \\\"{x:1629,y:723,t:1528143993682};\\\", \\\"{x:1640,y:718,t:1528143993699};\\\", \\\"{x:1647,y:713,t:1528143993715};\\\", \\\"{x:1650,y:711,t:1528143993732};\\\", \\\"{x:1650,y:710,t:1528143993749};\\\", \\\"{x:1648,y:707,t:1528143993876};\\\", \\\"{x:1647,y:706,t:1528143993883};\\\", \\\"{x:1645,y:705,t:1528143993900};\\\", \\\"{x:1640,y:699,t:1528143993916};\\\", \\\"{x:1638,y:697,t:1528143993933};\\\", \\\"{x:1635,y:695,t:1528143993949};\\\", \\\"{x:1634,y:695,t:1528143993967};\\\", \\\"{x:1633,y:693,t:1528143993982};\\\", \\\"{x:1632,y:693,t:1528143994004};\\\", \\\"{x:1631,y:693,t:1528143994053};\\\", \\\"{x:1630,y:693,t:1528143994653};\\\", \\\"{x:1629,y:696,t:1528143994669};\\\", \\\"{x:1625,y:701,t:1528143994684};\\\", \\\"{x:1624,y:703,t:1528143994701};\\\", \\\"{x:1624,y:705,t:1528143995101};\\\", \\\"{x:1620,y:720,t:1528143995118};\\\", \\\"{x:1617,y:734,t:1528143995135};\\\", \\\"{x:1616,y:743,t:1528143995151};\\\", \\\"{x:1614,y:757,t:1528143995168};\\\", \\\"{x:1612,y:767,t:1528143995185};\\\", \\\"{x:1609,y:779,t:1528143995201};\\\", \\\"{x:1609,y:791,t:1528143995218};\\\", \\\"{x:1609,y:805,t:1528143995235};\\\", \\\"{x:1609,y:816,t:1528143995251};\\\", \\\"{x:1609,y:827,t:1528143995268};\\\", \\\"{x:1609,y:838,t:1528143995285};\\\", \\\"{x:1612,y:844,t:1528143995301};\\\", \\\"{x:1613,y:847,t:1528143995318};\\\", \\\"{x:1615,y:851,t:1528143995335};\\\", \\\"{x:1615,y:855,t:1528143995351};\\\", \\\"{x:1616,y:857,t:1528143995368};\\\", \\\"{x:1617,y:859,t:1528143995385};\\\", \\\"{x:1617,y:860,t:1528143995402};\\\", \\\"{x:1617,y:862,t:1528143995418};\\\", \\\"{x:1618,y:865,t:1528143995435};\\\", \\\"{x:1618,y:867,t:1528143995452};\\\", \\\"{x:1619,y:872,t:1528143995468};\\\", \\\"{x:1619,y:881,t:1528143995485};\\\", \\\"{x:1619,y:887,t:1528143995501};\\\", \\\"{x:1622,y:892,t:1528143995518};\\\", \\\"{x:1622,y:894,t:1528143995535};\\\", \\\"{x:1622,y:896,t:1528143995551};\\\", \\\"{x:1622,y:898,t:1528143995567};\\\", \\\"{x:1622,y:901,t:1528143995585};\\\", \\\"{x:1622,y:907,t:1528143995601};\\\", \\\"{x:1622,y:912,t:1528143995617};\\\", \\\"{x:1622,y:917,t:1528143995635};\\\", \\\"{x:1622,y:924,t:1528143995651};\\\", \\\"{x:1622,y:933,t:1528143995668};\\\", \\\"{x:1622,y:939,t:1528143995684};\\\", \\\"{x:1620,y:945,t:1528143995702};\\\", \\\"{x:1620,y:954,t:1528143995719};\\\", \\\"{x:1618,y:960,t:1528143995735};\\\", \\\"{x:1618,y:964,t:1528143995752};\\\", \\\"{x:1617,y:968,t:1528143995769};\\\", \\\"{x:1617,y:969,t:1528143995785};\\\", \\\"{x:1617,y:970,t:1528143995802};\\\", \\\"{x:1617,y:949,t:1528143995925};\\\", \\\"{x:1617,y:927,t:1528143995935};\\\", \\\"{x:1617,y:874,t:1528143995952};\\\", \\\"{x:1616,y:828,t:1528143995968};\\\", \\\"{x:1612,y:790,t:1528143995986};\\\", \\\"{x:1612,y:782,t:1528143996001};\\\", \\\"{x:1613,y:782,t:1528143996045};\\\", \\\"{x:1614,y:782,t:1528143996053};\\\", \\\"{x:1615,y:781,t:1528143996068};\\\", \\\"{x:1616,y:780,t:1528143996086};\\\", \\\"{x:1617,y:779,t:1528143996102};\\\", \\\"{x:1619,y:778,t:1528143996119};\\\", \\\"{x:1619,y:776,t:1528143996136};\\\", \\\"{x:1619,y:773,t:1528143996152};\\\", \\\"{x:1621,y:767,t:1528143996169};\\\", \\\"{x:1621,y:753,t:1528143996186};\\\", \\\"{x:1621,y:724,t:1528143996202};\\\", \\\"{x:1621,y:703,t:1528143996219};\\\", \\\"{x:1621,y:695,t:1528143996236};\\\", \\\"{x:1621,y:692,t:1528143996252};\\\", \\\"{x:1621,y:689,t:1528143996269};\\\", \\\"{x:1621,y:688,t:1528143996293};\\\", \\\"{x:1621,y:687,t:1528143996309};\\\", \\\"{x:1621,y:686,t:1528143996319};\\\", \\\"{x:1621,y:685,t:1528143996686};\\\", \\\"{x:1623,y:677,t:1528143996703};\\\", \\\"{x:1627,y:667,t:1528143996720};\\\", \\\"{x:1631,y:654,t:1528143996735};\\\", \\\"{x:1636,y:638,t:1528143996753};\\\", \\\"{x:1636,y:629,t:1528143996769};\\\", \\\"{x:1638,y:626,t:1528143996785};\\\", \\\"{x:1639,y:623,t:1528143996806};\\\", \\\"{x:1640,y:622,t:1528143996824};\\\", \\\"{x:1640,y:621,t:1528143996839};\\\", \\\"{x:1641,y:619,t:1528143996857};\\\", \\\"{x:1642,y:620,t:1528143997033};\\\", \\\"{x:1643,y:624,t:1528143997041};\\\", \\\"{x:1645,y:628,t:1528143997057};\\\", \\\"{x:1646,y:630,t:1528143997074};\\\", \\\"{x:1647,y:631,t:1528143997091};\\\", \\\"{x:1648,y:633,t:1528143997107};\\\", \\\"{x:1649,y:634,t:1528143997129};\\\", \\\"{x:1650,y:634,t:1528143997145};\\\", \\\"{x:1652,y:634,t:1528143997161};\\\", \\\"{x:1653,y:634,t:1528143997177};\\\", \\\"{x:1655,y:634,t:1528143997191};\\\", \\\"{x:1656,y:634,t:1528143997207};\\\", \\\"{x:1663,y:634,t:1528143997224};\\\", \\\"{x:1675,y:609,t:1528143997241};\\\", \\\"{x:1683,y:589,t:1528143997257};\\\", \\\"{x:1688,y:579,t:1528143997274};\\\", \\\"{x:1690,y:573,t:1528143997291};\\\", \\\"{x:1691,y:572,t:1528143997308};\\\", \\\"{x:1686,y:581,t:1528143997825};\\\", \\\"{x:1658,y:615,t:1528143997841};\\\", \\\"{x:1642,y:637,t:1528143997858};\\\", \\\"{x:1631,y:652,t:1528143997875};\\\", \\\"{x:1623,y:663,t:1528143997892};\\\", \\\"{x:1618,y:670,t:1528143997908};\\\", \\\"{x:1618,y:672,t:1528143997925};\\\", \\\"{x:1616,y:677,t:1528143997942};\\\", \\\"{x:1614,y:680,t:1528143997958};\\\", \\\"{x:1614,y:682,t:1528143997975};\\\", \\\"{x:1612,y:684,t:1528143997992};\\\", \\\"{x:1612,y:685,t:1528143998025};\\\", \\\"{x:1611,y:686,t:1528143998105};\\\", \\\"{x:1610,y:689,t:1528143998209};\\\", \\\"{x:1608,y:693,t:1528143998226};\\\", \\\"{x:1608,y:694,t:1528143998257};\\\", \\\"{x:1600,y:689,t:1528143998545};\\\", \\\"{x:1589,y:666,t:1528143998559};\\\", \\\"{x:1569,y:637,t:1528143998575};\\\", \\\"{x:1559,y:627,t:1528143998591};\\\", \\\"{x:1551,y:618,t:1528143998609};\\\", \\\"{x:1553,y:621,t:1528143998801};\\\", \\\"{x:1554,y:622,t:1528143998809};\\\", \\\"{x:1556,y:624,t:1528143998826};\\\", \\\"{x:1559,y:627,t:1528143998843};\\\", \\\"{x:1563,y:631,t:1528143998860};\\\", \\\"{x:1565,y:633,t:1528143998876};\\\", \\\"{x:1565,y:634,t:1528143998892};\\\", \\\"{x:1568,y:634,t:1528143998909};\\\", \\\"{x:1568,y:635,t:1528143998926};\\\", \\\"{x:1569,y:636,t:1528143998953};\\\", \\\"{x:1569,y:637,t:1528143998969};\\\", \\\"{x:1570,y:638,t:1528143998976};\\\", \\\"{x:1571,y:641,t:1528143998993};\\\", \\\"{x:1572,y:642,t:1528143999009};\\\", \\\"{x:1572,y:643,t:1528143999026};\\\", \\\"{x:1572,y:645,t:1528143999043};\\\", \\\"{x:1575,y:650,t:1528143999059};\\\", \\\"{x:1575,y:653,t:1528143999076};\\\", \\\"{x:1576,y:656,t:1528143999093};\\\", \\\"{x:1577,y:659,t:1528143999109};\\\", \\\"{x:1577,y:660,t:1528143999126};\\\", \\\"{x:1577,y:661,t:1528143999143};\\\", \\\"{x:1577,y:662,t:1528143999160};\\\", \\\"{x:1578,y:663,t:1528143999177};\\\", \\\"{x:1578,y:666,t:1528143999193};\\\", \\\"{x:1578,y:672,t:1528143999210};\\\", \\\"{x:1578,y:677,t:1528143999226};\\\", \\\"{x:1578,y:683,t:1528143999243};\\\", \\\"{x:1577,y:692,t:1528143999260};\\\", \\\"{x:1576,y:697,t:1528143999276};\\\", \\\"{x:1574,y:705,t:1528143999293};\\\", \\\"{x:1572,y:710,t:1528143999310};\\\", \\\"{x:1570,y:717,t:1528143999326};\\\", \\\"{x:1568,y:720,t:1528143999343};\\\", \\\"{x:1566,y:725,t:1528143999361};\\\", \\\"{x:1565,y:729,t:1528143999376};\\\", \\\"{x:1562,y:733,t:1528143999393};\\\", \\\"{x:1560,y:736,t:1528143999410};\\\", \\\"{x:1558,y:739,t:1528143999427};\\\", \\\"{x:1554,y:744,t:1528143999443};\\\", \\\"{x:1551,y:751,t:1528143999460};\\\", \\\"{x:1545,y:760,t:1528143999477};\\\", \\\"{x:1540,y:769,t:1528143999493};\\\", \\\"{x:1537,y:772,t:1528143999509};\\\", \\\"{x:1537,y:773,t:1528143999527};\\\", \\\"{x:1536,y:774,t:1528143999542};\\\", \\\"{x:1536,y:775,t:1528143999559};\\\", \\\"{x:1539,y:760,t:1528143999753};\\\", \\\"{x:1544,y:746,t:1528143999761};\\\", \\\"{x:1548,y:721,t:1528143999777};\\\", \\\"{x:1551,y:694,t:1528143999794};\\\", \\\"{x:1553,y:674,t:1528143999810};\\\", \\\"{x:1555,y:669,t:1528143999827};\\\", \\\"{x:1555,y:667,t:1528143999844};\\\", \\\"{x:1556,y:667,t:1528144000015};\\\", \\\"{x:1559,y:663,t:1528144000026};\\\", \\\"{x:1566,y:658,t:1528144000044};\\\", \\\"{x:1570,y:651,t:1528144000061};\\\", \\\"{x:1578,y:642,t:1528144000077};\\\", \\\"{x:1580,y:640,t:1528144000093};\\\", \\\"{x:1581,y:639,t:1528144000111};\\\", \\\"{x:1582,y:638,t:1528144000192};\\\", \\\"{x:1582,y:637,t:1528144000912};\\\", \\\"{x:1582,y:632,t:1528144000928};\\\", \\\"{x:1582,y:613,t:1528144000944};\\\", \\\"{x:1582,y:608,t:1528144000961};\\\", \\\"{x:1582,y:605,t:1528144000978};\\\", \\\"{x:1582,y:603,t:1528144000994};\\\", \\\"{x:1582,y:602,t:1528144001032};\\\", \\\"{x:1577,y:608,t:1528144001394};\\\", \\\"{x:1570,y:617,t:1528144001401};\\\", \\\"{x:1565,y:624,t:1528144001412};\\\", \\\"{x:1557,y:637,t:1528144001429};\\\", \\\"{x:1550,y:646,t:1528144001446};\\\", \\\"{x:1542,y:661,t:1528144001463};\\\", \\\"{x:1538,y:668,t:1528144001479};\\\", \\\"{x:1536,y:672,t:1528144001495};\\\", \\\"{x:1535,y:677,t:1528144001512};\\\", \\\"{x:1531,y:686,t:1528144001528};\\\", \\\"{x:1528,y:689,t:1528144001544};\\\", \\\"{x:1528,y:692,t:1528144001561};\\\", \\\"{x:1526,y:698,t:1528144001578};\\\", \\\"{x:1525,y:700,t:1528144001595};\\\", \\\"{x:1524,y:704,t:1528144001611};\\\", \\\"{x:1523,y:707,t:1528144001629};\\\", \\\"{x:1521,y:712,t:1528144001645};\\\", \\\"{x:1519,y:721,t:1528144001661};\\\", \\\"{x:1516,y:729,t:1528144001679};\\\", \\\"{x:1512,y:739,t:1528144001696};\\\", \\\"{x:1510,y:748,t:1528144001712};\\\", \\\"{x:1507,y:760,t:1528144001728};\\\", \\\"{x:1506,y:762,t:1528144001746};\\\", \\\"{x:1506,y:763,t:1528144001762};\\\", \\\"{x:1506,y:764,t:1528144001779};\\\", \\\"{x:1506,y:765,t:1528144001796};\\\", \\\"{x:1506,y:766,t:1528144001812};\\\", \\\"{x:1505,y:768,t:1528144001833};\\\", \\\"{x:1504,y:768,t:1528144001846};\\\", \\\"{x:1501,y:774,t:1528144001862};\\\", \\\"{x:1499,y:778,t:1528144001879};\\\", \\\"{x:1498,y:780,t:1528144001896};\\\", \\\"{x:1498,y:782,t:1528144001913};\\\", \\\"{x:1497,y:783,t:1528144001929};\\\", \\\"{x:1497,y:785,t:1528144001946};\\\", \\\"{x:1496,y:785,t:1528144001969};\\\", \\\"{x:1496,y:786,t:1528144002225};\\\", \\\"{x:1502,y:784,t:1528144002257};\\\", \\\"{x:1511,y:778,t:1528144002265};\\\", \\\"{x:1511,y:777,t:1528144002279};\\\", \\\"{x:1514,y:776,t:1528144002296};\\\", \\\"{x:1516,y:775,t:1528144002313};\\\", \\\"{x:1516,y:774,t:1528144002537};\\\", \\\"{x:1516,y:775,t:1528144002985};\\\", \\\"{x:1512,y:779,t:1528144002997};\\\", \\\"{x:1504,y:788,t:1528144003014};\\\", \\\"{x:1495,y:801,t:1528144003030};\\\", \\\"{x:1487,y:814,t:1528144003048};\\\", \\\"{x:1482,y:820,t:1528144003064};\\\", \\\"{x:1481,y:823,t:1528144003080};\\\", \\\"{x:1480,y:825,t:1528144003098};\\\", \\\"{x:1480,y:826,t:1528144003114};\\\", \\\"{x:1479,y:827,t:1528144003130};\\\", \\\"{x:1477,y:830,t:1528144003147};\\\", \\\"{x:1475,y:836,t:1528144003165};\\\", \\\"{x:1472,y:840,t:1528144003180};\\\", \\\"{x:1467,y:846,t:1528144003198};\\\", \\\"{x:1460,y:853,t:1528144003214};\\\", \\\"{x:1454,y:859,t:1528144003231};\\\", \\\"{x:1450,y:864,t:1528144003247};\\\", \\\"{x:1447,y:866,t:1528144003264};\\\", \\\"{x:1446,y:869,t:1528144003281};\\\", \\\"{x:1448,y:867,t:1528144003442};\\\", \\\"{x:1449,y:860,t:1528144003449};\\\", \\\"{x:1451,y:855,t:1528144003465};\\\", \\\"{x:1455,y:843,t:1528144003480};\\\", \\\"{x:1460,y:834,t:1528144003497};\\\", \\\"{x:1463,y:830,t:1528144003513};\\\", \\\"{x:1465,y:827,t:1528144003530};\\\", \\\"{x:1466,y:825,t:1528144003547};\\\", \\\"{x:1467,y:825,t:1528144003564};\\\", \\\"{x:1467,y:820,t:1528144004049};\\\", \\\"{x:1451,y:802,t:1528144004064};\\\", \\\"{x:1439,y:790,t:1528144004081};\\\", \\\"{x:1427,y:777,t:1528144004099};\\\", \\\"{x:1419,y:768,t:1528144004116};\\\", \\\"{x:1417,y:770,t:1528144004329};\\\", \\\"{x:1405,y:784,t:1528144004337};\\\", \\\"{x:1393,y:798,t:1528144004348};\\\", \\\"{x:1386,y:812,t:1528144004366};\\\", \\\"{x:1383,y:817,t:1528144004382};\\\", \\\"{x:1381,y:822,t:1528144004398};\\\", \\\"{x:1379,y:827,t:1528144004415};\\\", \\\"{x:1379,y:830,t:1528144004433};\\\", \\\"{x:1378,y:831,t:1528144004449};\\\", \\\"{x:1377,y:834,t:1528144004521};\\\", \\\"{x:1376,y:835,t:1528144004532};\\\", \\\"{x:1375,y:836,t:1528144004549};\\\", \\\"{x:1374,y:839,t:1528144004566};\\\", \\\"{x:1372,y:843,t:1528144004582};\\\", \\\"{x:1372,y:844,t:1528144004599};\\\", \\\"{x:1372,y:846,t:1528144004616};\\\", \\\"{x:1371,y:851,t:1528144004633};\\\", \\\"{x:1371,y:853,t:1528144004649};\\\", \\\"{x:1370,y:855,t:1528144004666};\\\", \\\"{x:1370,y:856,t:1528144004682};\\\", \\\"{x:1370,y:857,t:1528144004700};\\\", \\\"{x:1369,y:857,t:1528144004720};\\\", \\\"{x:1369,y:859,t:1528144004809};\\\", \\\"{x:1369,y:861,t:1528144004816};\\\", \\\"{x:1369,y:863,t:1528144004833};\\\", \\\"{x:1369,y:865,t:1528144004849};\\\", \\\"{x:1369,y:866,t:1528144004866};\\\", \\\"{x:1369,y:867,t:1528144004882};\\\", \\\"{x:1369,y:869,t:1528144004899};\\\", \\\"{x:1369,y:871,t:1528144004916};\\\", \\\"{x:1369,y:873,t:1528144004932};\\\", \\\"{x:1369,y:874,t:1528144004950};\\\", \\\"{x:1369,y:875,t:1528144004966};\\\", \\\"{x:1369,y:876,t:1528144004982};\\\", \\\"{x:1370,y:876,t:1528144005089};\\\", \\\"{x:1378,y:872,t:1528144005112};\\\", \\\"{x:1391,y:865,t:1528144005120};\\\", \\\"{x:1398,y:863,t:1528144005133};\\\", \\\"{x:1407,y:860,t:1528144005150};\\\", \\\"{x:1426,y:855,t:1528144005166};\\\", \\\"{x:1435,y:854,t:1528144005183};\\\", \\\"{x:1437,y:853,t:1528144005199};\\\", \\\"{x:1439,y:853,t:1528144005217};\\\", \\\"{x:1440,y:852,t:1528144005241};\\\", \\\"{x:1439,y:848,t:1528144005385};\\\", \\\"{x:1438,y:846,t:1528144005399};\\\", \\\"{x:1432,y:839,t:1528144005416};\\\", \\\"{x:1431,y:837,t:1528144005432};\\\", \\\"{x:1429,y:837,t:1528144005537};\\\", \\\"{x:1427,y:836,t:1528144005625};\\\", \\\"{x:1426,y:835,t:1528144005633};\\\", \\\"{x:1422,y:834,t:1528144005650};\\\", \\\"{x:1420,y:832,t:1528144005667};\\\", \\\"{x:1418,y:832,t:1528144005683};\\\", \\\"{x:1417,y:832,t:1528144005701};\\\", \\\"{x:1417,y:829,t:1528144006129};\\\", \\\"{x:1419,y:824,t:1528144006137};\\\", \\\"{x:1423,y:818,t:1528144006150};\\\", \\\"{x:1429,y:808,t:1528144006167};\\\", \\\"{x:1431,y:806,t:1528144006185};\\\", \\\"{x:1432,y:806,t:1528144006256};\\\", \\\"{x:1433,y:806,t:1528144006345};\\\", \\\"{x:1433,y:805,t:1528144006353};\\\", \\\"{x:1433,y:803,t:1528144006367};\\\", \\\"{x:1435,y:796,t:1528144006385};\\\", \\\"{x:1437,y:791,t:1528144006401};\\\", \\\"{x:1439,y:787,t:1528144006417};\\\", \\\"{x:1440,y:785,t:1528144006434};\\\", \\\"{x:1441,y:784,t:1528144006452};\\\", \\\"{x:1441,y:781,t:1528144006467};\\\", \\\"{x:1442,y:778,t:1528144006484};\\\", \\\"{x:1444,y:775,t:1528144006501};\\\", \\\"{x:1444,y:774,t:1528144006517};\\\", \\\"{x:1445,y:774,t:1528144006585};\\\", \\\"{x:1445,y:773,t:1528144006600};\\\", \\\"{x:1447,y:769,t:1528144006617};\\\", \\\"{x:1448,y:767,t:1528144006635};\\\", \\\"{x:1449,y:764,t:1528144006652};\\\", \\\"{x:1450,y:762,t:1528144006668};\\\", \\\"{x:1451,y:760,t:1528144006684};\\\", \\\"{x:1451,y:759,t:1528144006712};\\\", \\\"{x:1451,y:758,t:1528144006729};\\\", \\\"{x:1452,y:757,t:1528144006752};\\\", \\\"{x:1454,y:755,t:1528144006768};\\\", \\\"{x:1455,y:752,t:1528144006785};\\\", \\\"{x:1457,y:749,t:1528144006801};\\\", \\\"{x:1459,y:744,t:1528144006818};\\\", \\\"{x:1463,y:739,t:1528144006834};\\\", \\\"{x:1467,y:731,t:1528144006851};\\\", \\\"{x:1470,y:725,t:1528144006868};\\\", \\\"{x:1474,y:720,t:1528144006884};\\\", \\\"{x:1475,y:716,t:1528144006901};\\\", \\\"{x:1476,y:714,t:1528144006919};\\\", \\\"{x:1478,y:710,t:1528144006935};\\\", \\\"{x:1479,y:709,t:1528144006951};\\\", \\\"{x:1479,y:708,t:1528144006968};\\\", \\\"{x:1481,y:705,t:1528144007001};\\\", \\\"{x:1483,y:704,t:1528144007025};\\\", \\\"{x:1483,y:701,t:1528144007036};\\\", \\\"{x:1485,y:699,t:1528144007052};\\\", \\\"{x:1488,y:695,t:1528144007068};\\\", \\\"{x:1490,y:691,t:1528144007086};\\\", \\\"{x:1492,y:689,t:1528144007101};\\\", \\\"{x:1493,y:687,t:1528144007118};\\\", \\\"{x:1495,y:684,t:1528144007136};\\\", \\\"{x:1496,y:682,t:1528144007151};\\\", \\\"{x:1499,y:678,t:1528144007169};\\\", \\\"{x:1500,y:675,t:1528144007185};\\\", \\\"{x:1501,y:673,t:1528144007202};\\\", \\\"{x:1502,y:672,t:1528144007219};\\\", \\\"{x:1502,y:671,t:1528144007257};\\\", \\\"{x:1503,y:670,t:1528144007272};\\\", \\\"{x:1503,y:669,t:1528144007285};\\\", \\\"{x:1504,y:666,t:1528144007301};\\\", \\\"{x:1504,y:663,t:1528144007319};\\\", \\\"{x:1505,y:662,t:1528144007335};\\\", \\\"{x:1507,y:656,t:1528144007353};\\\", \\\"{x:1510,y:651,t:1528144007369};\\\", \\\"{x:1513,y:645,t:1528144007385};\\\", \\\"{x:1515,y:640,t:1528144007402};\\\", \\\"{x:1517,y:635,t:1528144007419};\\\", \\\"{x:1519,y:629,t:1528144007436};\\\", \\\"{x:1521,y:625,t:1528144007452};\\\", \\\"{x:1522,y:622,t:1528144007468};\\\", \\\"{x:1523,y:620,t:1528144007485};\\\", \\\"{x:1524,y:619,t:1528144007502};\\\", \\\"{x:1525,y:618,t:1528144007518};\\\", \\\"{x:1525,y:616,t:1528144007535};\\\", \\\"{x:1525,y:615,t:1528144007553};\\\", \\\"{x:1526,y:614,t:1528144007568};\\\", \\\"{x:1527,y:611,t:1528144007585};\\\", \\\"{x:1529,y:609,t:1528144007602};\\\", \\\"{x:1531,y:605,t:1528144007618};\\\", \\\"{x:1534,y:599,t:1528144007635};\\\", \\\"{x:1540,y:591,t:1528144007652};\\\", \\\"{x:1547,y:580,t:1528144007669};\\\", \\\"{x:1551,y:571,t:1528144007685};\\\", \\\"{x:1556,y:563,t:1528144007702};\\\", \\\"{x:1562,y:552,t:1528144007719};\\\", \\\"{x:1568,y:545,t:1528144007735};\\\", \\\"{x:1575,y:535,t:1528144007752};\\\", \\\"{x:1578,y:530,t:1528144007770};\\\", \\\"{x:1581,y:526,t:1528144007785};\\\", \\\"{x:1582,y:524,t:1528144007802};\\\", \\\"{x:1584,y:521,t:1528144007819};\\\", \\\"{x:1587,y:516,t:1528144007836};\\\", \\\"{x:1590,y:511,t:1528144007853};\\\", \\\"{x:1593,y:507,t:1528144007869};\\\", \\\"{x:1595,y:504,t:1528144007885};\\\", \\\"{x:1597,y:501,t:1528144007902};\\\", \\\"{x:1597,y:500,t:1528144007919};\\\", \\\"{x:1598,y:498,t:1528144007936};\\\", \\\"{x:1599,y:497,t:1528144007953};\\\", \\\"{x:1599,y:495,t:1528144007969};\\\", \\\"{x:1599,y:494,t:1528144007993};\\\", \\\"{x:1600,y:494,t:1528144008016};\\\", \\\"{x:1600,y:493,t:1528144008025};\\\", \\\"{x:1595,y:495,t:1528144008337};\\\", \\\"{x:1587,y:497,t:1528144008353};\\\", \\\"{x:1579,y:500,t:1528144008370};\\\", \\\"{x:1573,y:502,t:1528144008388};\\\", \\\"{x:1566,y:505,t:1528144008403};\\\", \\\"{x:1563,y:506,t:1528144008419};\\\", \\\"{x:1562,y:506,t:1528144008437};\\\", \\\"{x:1563,y:506,t:1528144008641};\\\", \\\"{x:1564,y:506,t:1528144008653};\\\", \\\"{x:1566,y:504,t:1528144008671};\\\", \\\"{x:1569,y:501,t:1528144008686};\\\", \\\"{x:1570,y:501,t:1528144008703};\\\", \\\"{x:1570,y:500,t:1528144008721};\\\", \\\"{x:1572,y:501,t:1528144009666};\\\", \\\"{x:1574,y:501,t:1528144009673};\\\", \\\"{x:1575,y:501,t:1528144009688};\\\", \\\"{x:1577,y:502,t:1528144009705};\\\", \\\"{x:1578,y:502,t:1528144009728};\\\", \\\"{x:1581,y:502,t:1528144009738};\\\", \\\"{x:1583,y:502,t:1528144009756};\\\", \\\"{x:1585,y:500,t:1528144009771};\\\", \\\"{x:1586,y:500,t:1528144010722};\\\", \\\"{x:1586,y:503,t:1528144010739};\\\", \\\"{x:1585,y:509,t:1528144010755};\\\", \\\"{x:1585,y:511,t:1528144010772};\\\", \\\"{x:1585,y:512,t:1528144010789};\\\", \\\"{x:1585,y:513,t:1528144010808};\\\", \\\"{x:1585,y:514,t:1528144010873};\\\", \\\"{x:1585,y:515,t:1528144010897};\\\", \\\"{x:1585,y:517,t:1528144010920};\\\", \\\"{x:1585,y:519,t:1528144010929};\\\", \\\"{x:1585,y:521,t:1528144010940};\\\", \\\"{x:1584,y:524,t:1528144010955};\\\", \\\"{x:1584,y:526,t:1528144010973};\\\", \\\"{x:1583,y:527,t:1528144010989};\\\", \\\"{x:1582,y:532,t:1528144011769};\\\", \\\"{x:1582,y:535,t:1528144011776};\\\", \\\"{x:1581,y:537,t:1528144011791};\\\", \\\"{x:1580,y:541,t:1528144011806};\\\", \\\"{x:1580,y:544,t:1528144011823};\\\", \\\"{x:1580,y:546,t:1528144011841};\\\", \\\"{x:1580,y:547,t:1528144011864};\\\", \\\"{x:1580,y:549,t:1528144011929};\\\", \\\"{x:1579,y:551,t:1528144011941};\\\", \\\"{x:1578,y:555,t:1528144011957};\\\", \\\"{x:1577,y:560,t:1528144011974};\\\", \\\"{x:1577,y:564,t:1528144011991};\\\", \\\"{x:1576,y:569,t:1528144012007};\\\", \\\"{x:1574,y:573,t:1528144012023};\\\", \\\"{x:1574,y:576,t:1528144012041};\\\", \\\"{x:1574,y:578,t:1528144012057};\\\", \\\"{x:1574,y:579,t:1528144012144};\\\", \\\"{x:1574,y:581,t:1528144012161};\\\", \\\"{x:1574,y:584,t:1528144012173};\\\", \\\"{x:1574,y:589,t:1528144012190};\\\", \\\"{x:1574,y:594,t:1528144012207};\\\", \\\"{x:1574,y:601,t:1528144012224};\\\", \\\"{x:1574,y:612,t:1528144012240};\\\", \\\"{x:1574,y:618,t:1528144012257};\\\", \\\"{x:1574,y:625,t:1528144012273};\\\", \\\"{x:1574,y:629,t:1528144012291};\\\", \\\"{x:1574,y:633,t:1528144012308};\\\", \\\"{x:1574,y:636,t:1528144012324};\\\", \\\"{x:1574,y:638,t:1528144012341};\\\", \\\"{x:1574,y:639,t:1528144012358};\\\", \\\"{x:1574,y:640,t:1528144012409};\\\", \\\"{x:1574,y:642,t:1528144012424};\\\", \\\"{x:1574,y:648,t:1528144012440};\\\", \\\"{x:1573,y:654,t:1528144012457};\\\", \\\"{x:1570,y:663,t:1528144012475};\\\", \\\"{x:1570,y:670,t:1528144012491};\\\", \\\"{x:1570,y:677,t:1528144012508};\\\", \\\"{x:1568,y:683,t:1528144012524};\\\", \\\"{x:1568,y:688,t:1528144012541};\\\", \\\"{x:1567,y:692,t:1528144012558};\\\", \\\"{x:1567,y:694,t:1528144012575};\\\", \\\"{x:1566,y:695,t:1528144012590};\\\", \\\"{x:1566,y:696,t:1528144012608};\\\", \\\"{x:1566,y:697,t:1528144012633};\\\", \\\"{x:1566,y:698,t:1528144012648};\\\", \\\"{x:1566,y:699,t:1528144012681};\\\", \\\"{x:1566,y:701,t:1528144012691};\\\", \\\"{x:1566,y:704,t:1528144012707};\\\", \\\"{x:1566,y:709,t:1528144012725};\\\", \\\"{x:1566,y:713,t:1528144012742};\\\", \\\"{x:1566,y:718,t:1528144012758};\\\", \\\"{x:1566,y:720,t:1528144012774};\\\", \\\"{x:1565,y:723,t:1528144012792};\\\", \\\"{x:1565,y:724,t:1528144012808};\\\", \\\"{x:1565,y:727,t:1528144012824};\\\", \\\"{x:1565,y:728,t:1528144012848};\\\", \\\"{x:1565,y:729,t:1528144012857};\\\", \\\"{x:1565,y:730,t:1528144012875};\\\", \\\"{x:1565,y:731,t:1528144012891};\\\", \\\"{x:1565,y:732,t:1528144012907};\\\", \\\"{x:1565,y:733,t:1528144012925};\\\", \\\"{x:1565,y:736,t:1528144012941};\\\", \\\"{x:1565,y:738,t:1528144012957};\\\", \\\"{x:1565,y:741,t:1528144012974};\\\", \\\"{x:1565,y:745,t:1528144012991};\\\", \\\"{x:1565,y:749,t:1528144013008};\\\", \\\"{x:1565,y:753,t:1528144013025};\\\", \\\"{x:1565,y:757,t:1528144013042};\\\", \\\"{x:1565,y:760,t:1528144013059};\\\", \\\"{x:1565,y:762,t:1528144013074};\\\", \\\"{x:1565,y:763,t:1528144013096};\\\", \\\"{x:1565,y:764,t:1528144013109};\\\", \\\"{x:1565,y:765,t:1528144013125};\\\", \\\"{x:1565,y:766,t:1528144013142};\\\", \\\"{x:1565,y:767,t:1528144013158};\\\", \\\"{x:1565,y:768,t:1528144013175};\\\", \\\"{x:1565,y:769,t:1528144013217};\\\", \\\"{x:1565,y:770,t:1528144013225};\\\", \\\"{x:1565,y:772,t:1528144013242};\\\", \\\"{x:1565,y:775,t:1528144013258};\\\", \\\"{x:1565,y:779,t:1528144013275};\\\", \\\"{x:1565,y:782,t:1528144013292};\\\", \\\"{x:1565,y:784,t:1528144013308};\\\", \\\"{x:1565,y:788,t:1528144013324};\\\", \\\"{x:1565,y:789,t:1528144013342};\\\", \\\"{x:1565,y:791,t:1528144013359};\\\", \\\"{x:1565,y:792,t:1528144013376};\\\", \\\"{x:1565,y:793,t:1528144013391};\\\", \\\"{x:1565,y:795,t:1528144013408};\\\", \\\"{x:1565,y:797,t:1528144013432};\\\", \\\"{x:1565,y:798,t:1528144013449};\\\", \\\"{x:1565,y:800,t:1528144013465};\\\", \\\"{x:1565,y:803,t:1528144013476};\\\", \\\"{x:1565,y:807,t:1528144013492};\\\", \\\"{x:1565,y:811,t:1528144013508};\\\", \\\"{x:1562,y:817,t:1528144013525};\\\", \\\"{x:1561,y:824,t:1528144013541};\\\", \\\"{x:1559,y:832,t:1528144013558};\\\", \\\"{x:1557,y:836,t:1528144013575};\\\", \\\"{x:1557,y:840,t:1528144013591};\\\", \\\"{x:1557,y:844,t:1528144013607};\\\", \\\"{x:1556,y:847,t:1528144013625};\\\", \\\"{x:1555,y:849,t:1528144013642};\\\", \\\"{x:1555,y:850,t:1528144013672};\\\", \\\"{x:1555,y:852,t:1528144013729};\\\", \\\"{x:1554,y:853,t:1528144013752};\\\", \\\"{x:1554,y:855,t:1528144013776};\\\", \\\"{x:1552,y:858,t:1528144013793};\\\", \\\"{x:1552,y:860,t:1528144013809};\\\", \\\"{x:1552,y:863,t:1528144013826};\\\", \\\"{x:1552,y:870,t:1528144013842};\\\", \\\"{x:1551,y:874,t:1528144013857};\\\", \\\"{x:1550,y:878,t:1528144013875};\\\", \\\"{x:1550,y:881,t:1528144013892};\\\", \\\"{x:1550,y:883,t:1528144013909};\\\", \\\"{x:1549,y:884,t:1528144013924};\\\", \\\"{x:1549,y:885,t:1528144013942};\\\", \\\"{x:1548,y:886,t:1528144013959};\\\", \\\"{x:1548,y:889,t:1528144013975};\\\", \\\"{x:1547,y:893,t:1528144013992};\\\", \\\"{x:1545,y:896,t:1528144014009};\\\", \\\"{x:1544,y:900,t:1528144014025};\\\", \\\"{x:1543,y:904,t:1528144014042};\\\", \\\"{x:1540,y:910,t:1528144014059};\\\", \\\"{x:1535,y:920,t:1528144014075};\\\", \\\"{x:1532,y:930,t:1528144014093};\\\", \\\"{x:1527,y:941,t:1528144014109};\\\", \\\"{x:1525,y:946,t:1528144014125};\\\", \\\"{x:1522,y:953,t:1528144014143};\\\", \\\"{x:1517,y:964,t:1528144014160};\\\", \\\"{x:1510,y:973,t:1528144014175};\\\", \\\"{x:1502,y:983,t:1528144014192};\\\", \\\"{x:1496,y:989,t:1528144014209};\\\", \\\"{x:1492,y:992,t:1528144014225};\\\", \\\"{x:1483,y:996,t:1528144014242};\\\", \\\"{x:1466,y:997,t:1528144014259};\\\", \\\"{x:1432,y:997,t:1528144014276};\\\", \\\"{x:1372,y:973,t:1528144014292};\\\", \\\"{x:1278,y:934,t:1528144014310};\\\", \\\"{x:1168,y:888,t:1528144014326};\\\", \\\"{x:1064,y:843,t:1528144014342};\\\", \\\"{x:965,y:802,t:1528144014359};\\\", \\\"{x:861,y:757,t:1528144014375};\\\", \\\"{x:819,y:737,t:1528144014392};\\\", \\\"{x:791,y:725,t:1528144014409};\\\", \\\"{x:765,y:714,t:1528144014426};\\\", \\\"{x:744,y:705,t:1528144014443};\\\", \\\"{x:717,y:695,t:1528144014459};\\\", \\\"{x:673,y:667,t:1528144014477};\\\", \\\"{x:621,y:633,t:1528144014492};\\\", \\\"{x:578,y:601,t:1528144014510};\\\", \\\"{x:532,y:576,t:1528144014527};\\\", \\\"{x:474,y:550,t:1528144014543};\\\", \\\"{x:398,y:518,t:1528144014562};\\\", \\\"{x:368,y:504,t:1528144014579};\\\", \\\"{x:345,y:494,t:1528144014602};\\\", \\\"{x:342,y:494,t:1528144014619};\\\", \\\"{x:341,y:492,t:1528144014636};\\\", \\\"{x:339,y:492,t:1528144014687};\\\", \\\"{x:335,y:492,t:1528144014702};\\\", \\\"{x:319,y:493,t:1528144014718};\\\", \\\"{x:300,y:507,t:1528144014736};\\\", \\\"{x:292,y:513,t:1528144014752};\\\", \\\"{x:283,y:524,t:1528144014769};\\\", \\\"{x:276,y:537,t:1528144014786};\\\", \\\"{x:271,y:546,t:1528144014803};\\\", \\\"{x:264,y:557,t:1528144014819};\\\", \\\"{x:259,y:569,t:1528144014836};\\\", \\\"{x:254,y:580,t:1528144014853};\\\", \\\"{x:252,y:587,t:1528144014869};\\\", \\\"{x:249,y:593,t:1528144014886};\\\", \\\"{x:249,y:596,t:1528144014903};\\\", \\\"{x:247,y:599,t:1528144014919};\\\", \\\"{x:246,y:600,t:1528144014936};\\\", \\\"{x:246,y:601,t:1528144014954};\\\", \\\"{x:245,y:601,t:1528144015696};\\\", \\\"{x:245,y:610,t:1528144017472};\\\", \\\"{x:245,y:621,t:1528144017488};\\\", \\\"{x:247,y:628,t:1528144017505};\\\", \\\"{x:248,y:631,t:1528144017521};\\\", \\\"{x:248,y:632,t:1528144017552};\\\", \\\"{x:248,y:633,t:1528144017623};\\\", \\\"{x:249,y:633,t:1528144017639};\\\", \\\"{x:250,y:633,t:1528144017655};\\\", \\\"{x:278,y:633,t:1528144017671};\\\", \\\"{x:308,y:633,t:1528144017688};\\\", \\\"{x:338,y:633,t:1528144017705};\\\", \\\"{x:366,y:632,t:1528144017723};\\\", \\\"{x:387,y:629,t:1528144017739};\\\", \\\"{x:394,y:628,t:1528144017755};\\\", \\\"{x:396,y:628,t:1528144017772};\\\", \\\"{x:398,y:627,t:1528144017808};\\\", \\\"{x:400,y:626,t:1528144017822};\\\", \\\"{x:411,y:619,t:1528144017839};\\\", \\\"{x:422,y:611,t:1528144017856};\\\", \\\"{x:428,y:602,t:1528144017871};\\\", \\\"{x:430,y:599,t:1528144017889};\\\", \\\"{x:431,y:595,t:1528144017905};\\\", \\\"{x:433,y:592,t:1528144017922};\\\", \\\"{x:433,y:591,t:1528144017938};\\\", \\\"{x:433,y:590,t:1528144017955};\\\", \\\"{x:433,y:588,t:1528144017972};\\\", \\\"{x:433,y:585,t:1528144017988};\\\", \\\"{x:433,y:583,t:1528144018005};\\\", \\\"{x:433,y:582,t:1528144018022};\\\", \\\"{x:433,y:581,t:1528144018038};\\\", \\\"{x:433,y:580,t:1528144018055};\\\", \\\"{x:430,y:577,t:1528144018080};\\\", \\\"{x:430,y:576,t:1528144018088};\\\", \\\"{x:427,y:572,t:1528144018105};\\\", \\\"{x:425,y:568,t:1528144018122};\\\", \\\"{x:424,y:566,t:1528144018139};\\\", \\\"{x:422,y:564,t:1528144018168};\\\", \\\"{x:422,y:563,t:1528144018184};\\\", \\\"{x:421,y:562,t:1528144018192};\\\", \\\"{x:419,y:561,t:1528144018208};\\\", \\\"{x:418,y:560,t:1528144018222};\\\", \\\"{x:414,y:558,t:1528144018238};\\\", \\\"{x:410,y:555,t:1528144018256};\\\", \\\"{x:404,y:552,t:1528144018272};\\\", \\\"{x:398,y:549,t:1528144018289};\\\", \\\"{x:396,y:549,t:1528144018305};\\\", \\\"{x:395,y:548,t:1528144018323};\\\", \\\"{x:395,y:555,t:1528144018568};\\\", \\\"{x:399,y:567,t:1528144018575};\\\", \\\"{x:406,y:580,t:1528144018589};\\\", \\\"{x:421,y:613,t:1528144018606};\\\", \\\"{x:441,y:651,t:1528144018622};\\\", \\\"{x:458,y:675,t:1528144018639};\\\", \\\"{x:472,y:700,t:1528144018655};\\\", \\\"{x:479,y:713,t:1528144018672};\\\", \\\"{x:484,y:724,t:1528144018689};\\\", \\\"{x:488,y:733,t:1528144018706};\\\", \\\"{x:492,y:739,t:1528144018722};\\\", \\\"{x:493,y:740,t:1528144018739};\\\", \\\"{x:493,y:741,t:1528144018755};\\\", \\\"{x:497,y:741,t:1528144018772};\\\", \\\"{x:502,y:744,t:1528144018789};\\\", \\\"{x:504,y:744,t:1528144018805};\\\", \\\"{x:507,y:745,t:1528144018822};\\\", \\\"{x:507,y:744,t:1528144019087};\\\", \\\"{x:508,y:738,t:1528144019472};\\\", \\\"{x:516,y:717,t:1528144019489};\\\", \\\"{x:520,y:701,t:1528144019507};\\\", \\\"{x:535,y:666,t:1528144019524};\\\", \\\"{x:558,y:614,t:1528144019539};\\\", \\\"{x:577,y:583,t:1528144019556};\\\", \\\"{x:588,y:559,t:1528144019573};\\\", \\\"{x:603,y:539,t:1528144019590};\\\", \\\"{x:618,y:519,t:1528144019607};\\\", \\\"{x:632,y:503,t:1528144019623};\\\", \\\"{x:641,y:491,t:1528144019640};\\\", \\\"{x:650,y:481,t:1528144019657};\\\", \\\"{x:652,y:478,t:1528144019674};\\\", \\\"{x:655,y:474,t:1528144019689};\\\", \\\"{x:658,y:470,t:1528144019707};\\\", \\\"{x:661,y:466,t:1528144019723};\\\", \\\"{x:664,y:463,t:1528144019739};\\\", \\\"{x:673,y:458,t:1528144019756};\\\", \\\"{x:683,y:455,t:1528144019773};\\\", \\\"{x:693,y:450,t:1528144019791};\\\", \\\"{x:705,y:446,t:1528144019806};\\\", \\\"{x:714,y:445,t:1528144019823};\\\", \\\"{x:717,y:444,t:1528144019840};\\\" ] }, { \\\"rt\\\": 45261, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 1149183, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"VVH1B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 3.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-03 PM-03 PM-03 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:717,y:445,t:1528144025296};\\\", \\\"{x:717,y:446,t:1528144025793};\\\", \\\"{x:717,y:449,t:1528144025808};\\\", \\\"{x:717,y:451,t:1528144025816};\\\", \\\"{x:715,y:453,t:1528144025827};\\\", \\\"{x:714,y:455,t:1528144027848};\\\", \\\"{x:714,y:456,t:1528144028088};\\\", \\\"{x:712,y:460,t:1528144028096};\\\", \\\"{x:711,y:462,t:1528144028113};\\\", \\\"{x:711,y:463,t:1528144028185};\\\", \\\"{x:710,y:463,t:1528144031041};\\\", \\\"{x:707,y:471,t:1528144031817};\\\", \\\"{x:632,y:519,t:1528144031832};\\\", \\\"{x:556,y:573,t:1528144031851};\\\", \\\"{x:508,y:608,t:1528144031866};\\\", \\\"{x:485,y:627,t:1528144031882};\\\", \\\"{x:479,y:631,t:1528144031900};\\\", \\\"{x:478,y:631,t:1528144031916};\\\", \\\"{x:477,y:631,t:1528144031936};\\\", \\\"{x:477,y:632,t:1528144031959};\\\", \\\"{x:476,y:632,t:1528144032409};\\\", \\\"{x:467,y:629,t:1528144032417};\\\", \\\"{x:443,y:619,t:1528144032434};\\\", \\\"{x:429,y:613,t:1528144032449};\\\", \\\"{x:418,y:607,t:1528144032466};\\\", \\\"{x:415,y:606,t:1528144032483};\\\", \\\"{x:414,y:605,t:1528144032499};\\\", \\\"{x:413,y:605,t:1528144032516};\\\", \\\"{x:413,y:604,t:1528144032532};\\\", \\\"{x:412,y:604,t:1528144032552};\\\", \\\"{x:410,y:603,t:1528144032592};\\\", \\\"{x:408,y:602,t:1528144032607};\\\", \\\"{x:407,y:601,t:1528144032631};\\\", \\\"{x:406,y:600,t:1528144032640};\\\", \\\"{x:405,y:600,t:1528144032650};\\\", \\\"{x:402,y:598,t:1528144032667};\\\", \\\"{x:400,y:597,t:1528144032684};\\\", \\\"{x:396,y:595,t:1528144032700};\\\", \\\"{x:395,y:594,t:1528144032717};\\\", \\\"{x:394,y:593,t:1528144032735};\\\", \\\"{x:393,y:593,t:1528144032749};\\\", \\\"{x:391,y:593,t:1528144032767};\\\", \\\"{x:388,y:591,t:1528144032784};\\\", \\\"{x:385,y:588,t:1528144032800};\\\", \\\"{x:384,y:587,t:1528144032816};\\\", \\\"{x:407,y:595,t:1528144045626};\\\", \\\"{x:564,y:700,t:1528144045643};\\\", \\\"{x:706,y:803,t:1528144045660};\\\", \\\"{x:844,y:902,t:1528144045676};\\\", \\\"{x:1006,y:1024,t:1528144045693};\\\", \\\"{x:1147,y:1120,t:1528144045710};\\\", \\\"{x:1238,y:1186,t:1528144045726};\\\", \\\"{x:1277,y:1215,t:1528144045743};\\\", \\\"{x:1279,y:1215,t:1528144045760};\\\", \\\"{x:1280,y:1215,t:1528144045832};\\\", \\\"{x:1287,y:1215,t:1528144045843};\\\", \\\"{x:1312,y:1215,t:1528144045860};\\\", \\\"{x:1370,y:1215,t:1528144045877};\\\", \\\"{x:1448,y:1215,t:1528144045893};\\\", \\\"{x:1504,y:1215,t:1528144045910};\\\", \\\"{x:1555,y:1200,t:1528144045927};\\\", \\\"{x:1578,y:1185,t:1528144045944};\\\", \\\"{x:1592,y:1171,t:1528144045961};\\\", \\\"{x:1594,y:1165,t:1528144045978};\\\", \\\"{x:1594,y:1159,t:1528144045995};\\\", \\\"{x:1594,y:1157,t:1528144046011};\\\", \\\"{x:1594,y:1154,t:1528144046027};\\\", \\\"{x:1594,y:1151,t:1528144046045};\\\", \\\"{x:1590,y:1142,t:1528144046060};\\\", \\\"{x:1569,y:1131,t:1528144046078};\\\", \\\"{x:1532,y:1116,t:1528144046094};\\\", \\\"{x:1477,y:1090,t:1528144046111};\\\", \\\"{x:1415,y:1059,t:1528144046127};\\\", \\\"{x:1404,y:1049,t:1528144046145};\\\", \\\"{x:1406,y:1042,t:1528144046162};\\\", \\\"{x:1418,y:1031,t:1528144046178};\\\", \\\"{x:1429,y:1020,t:1528144046195};\\\", \\\"{x:1443,y:1010,t:1528144046211};\\\", \\\"{x:1456,y:1000,t:1528144046227};\\\", \\\"{x:1466,y:992,t:1528144046245};\\\", \\\"{x:1472,y:987,t:1528144046261};\\\", \\\"{x:1474,y:986,t:1528144046278};\\\", \\\"{x:1476,y:984,t:1528144046295};\\\", \\\"{x:1477,y:983,t:1528144046311};\\\", \\\"{x:1479,y:983,t:1528144046328};\\\", \\\"{x:1484,y:981,t:1528144046345};\\\", \\\"{x:1496,y:976,t:1528144046362};\\\", \\\"{x:1508,y:968,t:1528144046379};\\\", \\\"{x:1513,y:965,t:1528144046395};\\\", \\\"{x:1516,y:963,t:1528144046412};\\\", \\\"{x:1517,y:963,t:1528144046428};\\\", \\\"{x:1517,y:962,t:1528144046445};\\\", \\\"{x:1517,y:961,t:1528144046464};\\\", \\\"{x:1518,y:961,t:1528144046536};\\\", \\\"{x:1520,y:961,t:1528144046544};\\\", \\\"{x:1524,y:964,t:1528144046562};\\\", \\\"{x:1529,y:969,t:1528144046579};\\\", \\\"{x:1536,y:973,t:1528144046595};\\\", \\\"{x:1548,y:977,t:1528144046612};\\\", \\\"{x:1552,y:978,t:1528144046629};\\\", \\\"{x:1554,y:978,t:1528144046644};\\\", \\\"{x:1555,y:978,t:1528144046662};\\\", \\\"{x:1557,y:977,t:1528144046679};\\\", \\\"{x:1557,y:976,t:1528144046695};\\\", \\\"{x:1558,y:975,t:1528144046712};\\\", \\\"{x:1558,y:974,t:1528144046729};\\\", \\\"{x:1559,y:973,t:1528144046746};\\\", \\\"{x:1560,y:971,t:1528144046762};\\\", \\\"{x:1560,y:968,t:1528144046779};\\\", \\\"{x:1562,y:967,t:1528144046795};\\\", \\\"{x:1562,y:965,t:1528144046812};\\\", \\\"{x:1562,y:963,t:1528144046829};\\\", \\\"{x:1562,y:962,t:1528144046846};\\\", \\\"{x:1563,y:959,t:1528144046862};\\\", \\\"{x:1563,y:955,t:1528144046879};\\\", \\\"{x:1563,y:947,t:1528144046896};\\\", \\\"{x:1565,y:937,t:1528144046912};\\\", \\\"{x:1567,y:924,t:1528144046929};\\\", \\\"{x:1569,y:914,t:1528144046946};\\\", \\\"{x:1573,y:897,t:1528144046962};\\\", \\\"{x:1580,y:879,t:1528144046979};\\\", \\\"{x:1588,y:856,t:1528144046996};\\\", \\\"{x:1594,y:834,t:1528144047013};\\\", \\\"{x:1605,y:808,t:1528144047029};\\\", \\\"{x:1611,y:787,t:1528144047046};\\\", \\\"{x:1614,y:777,t:1528144047063};\\\", \\\"{x:1616,y:774,t:1528144047079};\\\", \\\"{x:1616,y:773,t:1528144047280};\\\", \\\"{x:1615,y:774,t:1528144047384};\\\", \\\"{x:1606,y:788,t:1528144047396};\\\", \\\"{x:1592,y:808,t:1528144047413};\\\", \\\"{x:1581,y:828,t:1528144047430};\\\", \\\"{x:1569,y:856,t:1528144047446};\\\", \\\"{x:1555,y:898,t:1528144047463};\\\", \\\"{x:1543,y:942,t:1528144047480};\\\", \\\"{x:1539,y:962,t:1528144047496};\\\", \\\"{x:1534,y:978,t:1528144047513};\\\", \\\"{x:1531,y:990,t:1528144047531};\\\", \\\"{x:1528,y:997,t:1528144047546};\\\", \\\"{x:1527,y:1004,t:1528144047562};\\\", \\\"{x:1527,y:1006,t:1528144047580};\\\", \\\"{x:1527,y:1007,t:1528144047599};\\\", \\\"{x:1527,y:1008,t:1528144047656};\\\", \\\"{x:1527,y:1010,t:1528144047663};\\\", \\\"{x:1527,y:1016,t:1528144047678};\\\", \\\"{x:1527,y:1025,t:1528144047696};\\\", \\\"{x:1527,y:1029,t:1528144047712};\\\", \\\"{x:1528,y:1030,t:1528144047730};\\\", \\\"{x:1531,y:1027,t:1528144047783};\\\", \\\"{x:1535,y:1016,t:1528144047797};\\\", \\\"{x:1540,y:994,t:1528144047812};\\\", \\\"{x:1544,y:978,t:1528144047829};\\\", \\\"{x:1545,y:970,t:1528144047846};\\\", \\\"{x:1547,y:964,t:1528144047863};\\\", \\\"{x:1547,y:962,t:1528144047880};\\\", \\\"{x:1547,y:960,t:1528144047896};\\\", \\\"{x:1547,y:958,t:1528144047913};\\\", \\\"{x:1547,y:954,t:1528144047929};\\\", \\\"{x:1548,y:951,t:1528144047947};\\\", \\\"{x:1549,y:945,t:1528144047964};\\\", \\\"{x:1550,y:943,t:1528144047980};\\\", \\\"{x:1551,y:940,t:1528144047997};\\\", \\\"{x:1552,y:937,t:1528144048014};\\\", \\\"{x:1553,y:934,t:1528144048030};\\\", \\\"{x:1553,y:930,t:1528144048047};\\\", \\\"{x:1555,y:922,t:1528144048064};\\\", \\\"{x:1556,y:918,t:1528144048080};\\\", \\\"{x:1556,y:914,t:1528144048096};\\\", \\\"{x:1556,y:910,t:1528144048113};\\\", \\\"{x:1557,y:906,t:1528144048130};\\\", \\\"{x:1557,y:900,t:1528144048146};\\\", \\\"{x:1557,y:896,t:1528144048163};\\\", \\\"{x:1557,y:892,t:1528144048179};\\\", \\\"{x:1557,y:890,t:1528144048196};\\\", \\\"{x:1557,y:889,t:1528144048214};\\\", \\\"{x:1557,y:887,t:1528144048231};\\\", \\\"{x:1557,y:885,t:1528144048247};\\\", \\\"{x:1557,y:877,t:1528144048264};\\\", \\\"{x:1557,y:872,t:1528144048280};\\\", \\\"{x:1557,y:868,t:1528144048296};\\\", \\\"{x:1559,y:863,t:1528144048313};\\\", \\\"{x:1559,y:860,t:1528144048330};\\\", \\\"{x:1559,y:857,t:1528144048346};\\\", \\\"{x:1559,y:852,t:1528144048363};\\\", \\\"{x:1559,y:845,t:1528144048380};\\\", \\\"{x:1559,y:839,t:1528144048397};\\\", \\\"{x:1559,y:833,t:1528144048413};\\\", \\\"{x:1559,y:829,t:1528144048430};\\\", \\\"{x:1559,y:824,t:1528144048447};\\\", \\\"{x:1559,y:818,t:1528144048463};\\\", \\\"{x:1559,y:815,t:1528144048481};\\\", \\\"{x:1559,y:813,t:1528144048497};\\\", \\\"{x:1559,y:812,t:1528144048513};\\\", \\\"{x:1559,y:810,t:1528144048531};\\\", \\\"{x:1559,y:806,t:1528144048548};\\\", \\\"{x:1559,y:805,t:1528144048564};\\\", \\\"{x:1558,y:800,t:1528144048581};\\\", \\\"{x:1558,y:796,t:1528144048598};\\\", \\\"{x:1558,y:790,t:1528144048614};\\\", \\\"{x:1556,y:787,t:1528144048630};\\\", \\\"{x:1556,y:784,t:1528144048647};\\\", \\\"{x:1556,y:782,t:1528144048663};\\\", \\\"{x:1556,y:781,t:1528144048681};\\\", \\\"{x:1556,y:775,t:1528144048698};\\\", \\\"{x:1555,y:767,t:1528144048714};\\\", \\\"{x:1553,y:758,t:1528144048731};\\\", \\\"{x:1550,y:750,t:1528144048748};\\\", \\\"{x:1549,y:745,t:1528144048764};\\\", \\\"{x:1548,y:743,t:1528144048781};\\\", \\\"{x:1548,y:742,t:1528144048800};\\\", \\\"{x:1547,y:741,t:1528144048816};\\\", \\\"{x:1547,y:739,t:1528144048847};\\\", \\\"{x:1547,y:738,t:1528144048864};\\\", \\\"{x:1547,y:737,t:1528144048881};\\\", \\\"{x:1545,y:733,t:1528144048897};\\\", \\\"{x:1544,y:730,t:1528144048915};\\\", \\\"{x:1544,y:728,t:1528144048931};\\\", \\\"{x:1544,y:725,t:1528144048948};\\\", \\\"{x:1543,y:724,t:1528144048965};\\\", \\\"{x:1543,y:722,t:1528144048980};\\\", \\\"{x:1543,y:720,t:1528144048998};\\\", \\\"{x:1543,y:715,t:1528144049015};\\\", \\\"{x:1543,y:710,t:1528144049031};\\\", \\\"{x:1543,y:704,t:1528144049048};\\\", \\\"{x:1543,y:702,t:1528144049065};\\\", \\\"{x:1543,y:700,t:1528144049082};\\\", \\\"{x:1543,y:696,t:1528144049098};\\\", \\\"{x:1543,y:692,t:1528144049116};\\\", \\\"{x:1540,y:684,t:1528144049132};\\\", \\\"{x:1539,y:676,t:1528144049148};\\\", \\\"{x:1539,y:666,t:1528144049165};\\\", \\\"{x:1539,y:660,t:1528144049182};\\\", \\\"{x:1539,y:652,t:1528144049198};\\\", \\\"{x:1539,y:646,t:1528144049215};\\\", \\\"{x:1539,y:637,t:1528144049232};\\\", \\\"{x:1539,y:633,t:1528144049248};\\\", \\\"{x:1539,y:627,t:1528144049265};\\\", \\\"{x:1539,y:624,t:1528144049282};\\\", \\\"{x:1539,y:621,t:1528144049298};\\\", \\\"{x:1539,y:620,t:1528144049328};\\\", \\\"{x:1539,y:618,t:1528144049785};\\\", \\\"{x:1539,y:598,t:1528144049799};\\\", \\\"{x:1541,y:559,t:1528144049815};\\\", \\\"{x:1541,y:544,t:1528144049832};\\\", \\\"{x:1541,y:526,t:1528144049849};\\\", \\\"{x:1541,y:518,t:1528144049866};\\\", \\\"{x:1542,y:513,t:1528144049882};\\\", \\\"{x:1544,y:511,t:1528144049898};\\\", \\\"{x:1544,y:508,t:1528144049916};\\\", \\\"{x:1548,y:499,t:1528144049931};\\\", \\\"{x:1549,y:494,t:1528144049948};\\\", \\\"{x:1552,y:486,t:1528144049965};\\\", \\\"{x:1553,y:484,t:1528144049982};\\\", \\\"{x:1553,y:483,t:1528144050086};\\\", \\\"{x:1553,y:482,t:1528144050099};\\\", \\\"{x:1554,y:477,t:1528144050116};\\\", \\\"{x:1554,y:474,t:1528144050133};\\\", \\\"{x:1554,y:469,t:1528144050148};\\\", \\\"{x:1554,y:460,t:1528144050166};\\\", \\\"{x:1554,y:449,t:1528144050183};\\\", \\\"{x:1554,y:444,t:1528144050199};\\\", \\\"{x:1554,y:438,t:1528144050215};\\\", \\\"{x:1554,y:436,t:1528144050233};\\\", \\\"{x:1554,y:432,t:1528144050248};\\\", \\\"{x:1553,y:429,t:1528144050266};\\\", \\\"{x:1553,y:428,t:1528144050282};\\\", \\\"{x:1552,y:424,t:1528144050299};\\\", \\\"{x:1552,y:423,t:1528144050316};\\\", \\\"{x:1552,y:421,t:1528144050333};\\\", \\\"{x:1552,y:419,t:1528144050351};\\\", \\\"{x:1552,y:417,t:1528144050366};\\\", \\\"{x:1551,y:412,t:1528144050383};\\\", \\\"{x:1549,y:403,t:1528144050400};\\\", \\\"{x:1549,y:400,t:1528144050415};\\\", \\\"{x:1549,y:397,t:1528144050433};\\\", \\\"{x:1548,y:396,t:1528144050449};\\\", \\\"{x:1548,y:395,t:1528144050466};\\\", \\\"{x:1548,y:393,t:1528144050483};\\\", \\\"{x:1547,y:392,t:1528144050512};\\\", \\\"{x:1547,y:391,t:1528144050520};\\\", \\\"{x:1547,y:390,t:1528144050533};\\\", \\\"{x:1547,y:389,t:1528144050550};\\\", \\\"{x:1547,y:387,t:1528144050566};\\\", \\\"{x:1547,y:386,t:1528144050584};\\\", \\\"{x:1546,y:382,t:1528144050600};\\\", \\\"{x:1546,y:381,t:1528144050616};\\\", \\\"{x:1546,y:376,t:1528144050633};\\\", \\\"{x:1546,y:373,t:1528144050650};\\\", \\\"{x:1545,y:368,t:1528144050667};\\\", \\\"{x:1545,y:365,t:1528144050683};\\\", \\\"{x:1544,y:359,t:1528144050700};\\\", \\\"{x:1544,y:357,t:1528144050717};\\\", \\\"{x:1544,y:355,t:1528144050733};\\\", \\\"{x:1544,y:354,t:1528144050800};\\\", \\\"{x:1544,y:351,t:1528144050817};\\\", \\\"{x:1544,y:350,t:1528144050833};\\\", \\\"{x:1544,y:348,t:1528144050850};\\\", \\\"{x:1544,y:345,t:1528144050867};\\\", \\\"{x:1542,y:343,t:1528144050883};\\\", \\\"{x:1542,y:339,t:1528144050900};\\\", \\\"{x:1542,y:334,t:1528144050917};\\\", \\\"{x:1541,y:328,t:1528144050933};\\\", \\\"{x:1541,y:321,t:1528144050950};\\\", \\\"{x:1541,y:314,t:1528144050967};\\\", \\\"{x:1541,y:306,t:1528144050983};\\\", \\\"{x:1541,y:303,t:1528144051000};\\\", \\\"{x:1541,y:302,t:1528144051017};\\\", \\\"{x:1541,y:301,t:1528144051033};\\\", \\\"{x:1541,y:300,t:1528144051049};\\\", \\\"{x:1541,y:299,t:1528144051103};\\\", \\\"{x:1541,y:298,t:1528144051117};\\\", \\\"{x:1541,y:297,t:1528144051134};\\\", \\\"{x:1527,y:320,t:1528144051688};\\\", \\\"{x:1496,y:390,t:1528144051701};\\\", \\\"{x:1447,y:475,t:1528144051718};\\\", \\\"{x:1396,y:545,t:1528144051734};\\\", \\\"{x:1339,y:604,t:1528144051751};\\\", \\\"{x:1268,y:659,t:1528144051767};\\\", \\\"{x:1246,y:668,t:1528144051785};\\\", \\\"{x:1227,y:674,t:1528144051801};\\\", \\\"{x:1203,y:677,t:1528144051818};\\\", \\\"{x:1181,y:679,t:1528144051835};\\\", \\\"{x:1150,y:683,t:1528144051851};\\\", \\\"{x:1110,y:684,t:1528144051868};\\\", \\\"{x:1088,y:684,t:1528144051885};\\\", \\\"{x:1072,y:684,t:1528144051901};\\\", \\\"{x:1059,y:684,t:1528144051918};\\\", \\\"{x:1044,y:684,t:1528144051935};\\\", \\\"{x:1018,y:682,t:1528144051952};\\\", \\\"{x:939,y:663,t:1528144051968};\\\", \\\"{x:841,y:647,t:1528144051984};\\\", \\\"{x:739,y:636,t:1528144052001};\\\", \\\"{x:663,y:632,t:1528144052017};\\\", \\\"{x:604,y:632,t:1528144052034};\\\", \\\"{x:575,y:629,t:1528144052052};\\\", \\\"{x:564,y:628,t:1528144052068};\\\", \\\"{x:556,y:625,t:1528144052084};\\\", \\\"{x:547,y:623,t:1528144052098};\\\", \\\"{x:532,y:618,t:1528144052115};\\\", \\\"{x:521,y:615,t:1528144052132};\\\", \\\"{x:515,y:614,t:1528144052148};\\\", \\\"{x:512,y:611,t:1528144052165};\\\", \\\"{x:509,y:611,t:1528144052183};\\\", \\\"{x:490,y:609,t:1528144052199};\\\", \\\"{x:390,y:603,t:1528144052215};\\\", \\\"{x:308,y:596,t:1528144052233};\\\", \\\"{x:258,y:596,t:1528144052248};\\\", \\\"{x:234,y:596,t:1528144052266};\\\", \\\"{x:228,y:596,t:1528144052283};\\\", \\\"{x:227,y:596,t:1528144052298};\\\", \\\"{x:227,y:595,t:1528144052384};\\\", \\\"{x:226,y:595,t:1528144052448};\\\", \\\"{x:225,y:595,t:1528144052536};\\\", \\\"{x:222,y:598,t:1528144052549};\\\", \\\"{x:217,y:602,t:1528144052567};\\\", \\\"{x:215,y:605,t:1528144052582};\\\", \\\"{x:210,y:612,t:1528144052599};\\\", \\\"{x:207,y:616,t:1528144052615};\\\", \\\"{x:206,y:616,t:1528144052632};\\\", \\\"{x:206,y:617,t:1528144052649};\\\", \\\"{x:208,y:612,t:1528144052727};\\\", \\\"{x:217,y:609,t:1528144052734};\\\", \\\"{x:227,y:604,t:1528144052749};\\\", \\\"{x:252,y:595,t:1528144052766};\\\", \\\"{x:269,y:588,t:1528144052784};\\\", \\\"{x:296,y:581,t:1528144052800};\\\", \\\"{x:303,y:579,t:1528144052815};\\\", \\\"{x:308,y:579,t:1528144052833};\\\", \\\"{x:311,y:579,t:1528144052849};\\\", \\\"{x:321,y:579,t:1528144052865};\\\", \\\"{x:336,y:578,t:1528144052883};\\\", \\\"{x:365,y:576,t:1528144052899};\\\", \\\"{x:410,y:569,t:1528144052917};\\\", \\\"{x:444,y:564,t:1528144052933};\\\", \\\"{x:458,y:561,t:1528144052950};\\\", \\\"{x:459,y:561,t:1528144052966};\\\", \\\"{x:460,y:561,t:1528144053144};\\\", \\\"{x:463,y:565,t:1528144053160};\\\", \\\"{x:468,y:570,t:1528144053167};\\\", \\\"{x:474,y:572,t:1528144053183};\\\", \\\"{x:506,y:577,t:1528144053201};\\\", \\\"{x:541,y:577,t:1528144053217};\\\", \\\"{x:591,y:577,t:1528144053232};\\\", \\\"{x:647,y:570,t:1528144053248};\\\", \\\"{x:679,y:565,t:1528144053265};\\\", \\\"{x:693,y:564,t:1528144053282};\\\", \\\"{x:700,y:561,t:1528144053299};\\\", \\\"{x:702,y:561,t:1528144053315};\\\", \\\"{x:706,y:561,t:1528144053333};\\\", \\\"{x:709,y:561,t:1528144053350};\\\", \\\"{x:715,y:560,t:1528144053367};\\\", \\\"{x:728,y:560,t:1528144053383};\\\", \\\"{x:757,y:560,t:1528144053400};\\\", \\\"{x:769,y:560,t:1528144053417};\\\", \\\"{x:773,y:560,t:1528144053433};\\\", \\\"{x:775,y:560,t:1528144053450};\\\", \\\"{x:776,y:560,t:1528144053487};\\\", \\\"{x:780,y:558,t:1528144053499};\\\", \\\"{x:789,y:556,t:1528144053517};\\\", \\\"{x:800,y:552,t:1528144053534};\\\", \\\"{x:805,y:549,t:1528144053549};\\\", \\\"{x:809,y:547,t:1528144053567};\\\", \\\"{x:811,y:546,t:1528144053583};\\\", \\\"{x:812,y:545,t:1528144053655};\\\", \\\"{x:814,y:544,t:1528144053671};\\\", \\\"{x:816,y:543,t:1528144053683};\\\", \\\"{x:817,y:542,t:1528144053699};\\\", \\\"{x:818,y:542,t:1528144053783};\\\", \\\"{x:818,y:542,t:1528144053944};\\\", \\\"{x:822,y:546,t:1528144054088};\\\", \\\"{x:846,y:564,t:1528144054102};\\\", \\\"{x:906,y:613,t:1528144054118};\\\", \\\"{x:969,y:663,t:1528144054134};\\\", \\\"{x:1018,y:707,t:1528144054151};\\\", \\\"{x:1096,y:769,t:1528144054167};\\\", \\\"{x:1142,y:808,t:1528144054184};\\\", \\\"{x:1187,y:847,t:1528144054201};\\\", \\\"{x:1240,y:887,t:1528144054216};\\\", \\\"{x:1318,y:939,t:1528144054234};\\\", \\\"{x:1405,y:985,t:1528144054250};\\\", \\\"{x:1496,y:1028,t:1528144054267};\\\", \\\"{x:1575,y:1071,t:1528144054284};\\\", \\\"{x:1628,y:1094,t:1528144054301};\\\", \\\"{x:1656,y:1106,t:1528144054317};\\\", \\\"{x:1673,y:1112,t:1528144054334};\\\", \\\"{x:1682,y:1113,t:1528144054351};\\\", \\\"{x:1688,y:1113,t:1528144054367};\\\", \\\"{x:1693,y:1109,t:1528144054383};\\\", \\\"{x:1695,y:1104,t:1528144054400};\\\", \\\"{x:1695,y:1101,t:1528144054418};\\\", \\\"{x:1695,y:1097,t:1528144054434};\\\", \\\"{x:1695,y:1092,t:1528144054451};\\\", \\\"{x:1693,y:1078,t:1528144054468};\\\", \\\"{x:1684,y:1052,t:1528144054483};\\\", \\\"{x:1670,y:1030,t:1528144054501};\\\", \\\"{x:1657,y:1018,t:1528144054517};\\\", \\\"{x:1646,y:1011,t:1528144054533};\\\", \\\"{x:1635,y:1010,t:1528144054551};\\\", \\\"{x:1619,y:1006,t:1528144054566};\\\", \\\"{x:1618,y:1006,t:1528144054583};\\\", \\\"{x:1617,y:1006,t:1528144054600};\\\", \\\"{x:1614,y:1006,t:1528144054618};\\\", \\\"{x:1610,y:1006,t:1528144054634};\\\", \\\"{x:1604,y:1004,t:1528144054651};\\\", \\\"{x:1599,y:1002,t:1528144054668};\\\", \\\"{x:1599,y:1001,t:1528144054684};\\\", \\\"{x:1597,y:1001,t:1528144054704};\\\", \\\"{x:1596,y:1001,t:1528144054718};\\\", \\\"{x:1591,y:998,t:1528144054734};\\\", \\\"{x:1583,y:995,t:1528144054751};\\\", \\\"{x:1570,y:989,t:1528144054767};\\\", \\\"{x:1568,y:988,t:1528144054785};\\\", \\\"{x:1567,y:988,t:1528144054807};\\\", \\\"{x:1566,y:987,t:1528144054872};\\\", \\\"{x:1565,y:986,t:1528144054885};\\\", \\\"{x:1563,y:984,t:1528144054901};\\\", \\\"{x:1560,y:982,t:1528144054918};\\\", \\\"{x:1559,y:982,t:1528144054935};\\\", \\\"{x:1557,y:981,t:1528144054951};\\\", \\\"{x:1555,y:979,t:1528144054968};\\\", \\\"{x:1554,y:977,t:1528144054999};\\\", \\\"{x:1554,y:976,t:1528144055007};\\\", \\\"{x:1553,y:975,t:1528144055018};\\\", \\\"{x:1553,y:973,t:1528144055035};\\\", \\\"{x:1553,y:969,t:1528144055051};\\\", \\\"{x:1553,y:966,t:1528144055068};\\\", \\\"{x:1553,y:962,t:1528144055085};\\\", \\\"{x:1553,y:960,t:1528144055101};\\\", \\\"{x:1553,y:958,t:1528144055118};\\\", \\\"{x:1553,y:956,t:1528144055134};\\\", \\\"{x:1553,y:952,t:1528144055151};\\\", \\\"{x:1553,y:949,t:1528144055168};\\\", \\\"{x:1553,y:947,t:1528144055184};\\\", \\\"{x:1553,y:946,t:1528144055200};\\\", \\\"{x:1553,y:944,t:1528144055218};\\\", \\\"{x:1553,y:943,t:1528144055234};\\\", \\\"{x:1553,y:941,t:1528144055252};\\\", \\\"{x:1552,y:940,t:1528144055268};\\\", \\\"{x:1552,y:938,t:1528144055295};\\\", \\\"{x:1552,y:937,t:1528144055303};\\\", \\\"{x:1552,y:935,t:1528144055320};\\\", \\\"{x:1552,y:934,t:1528144055335};\\\", \\\"{x:1552,y:932,t:1528144055351};\\\", \\\"{x:1552,y:929,t:1528144055368};\\\", \\\"{x:1552,y:926,t:1528144055385};\\\", \\\"{x:1552,y:924,t:1528144055402};\\\", \\\"{x:1552,y:920,t:1528144055418};\\\", \\\"{x:1552,y:917,t:1528144055436};\\\", \\\"{x:1552,y:915,t:1528144055452};\\\", \\\"{x:1551,y:912,t:1528144055468};\\\", \\\"{x:1551,y:910,t:1528144055486};\\\", \\\"{x:1550,y:908,t:1528144055502};\\\", \\\"{x:1550,y:907,t:1528144055518};\\\", \\\"{x:1550,y:906,t:1528144055535};\\\", \\\"{x:1550,y:904,t:1528144055551};\\\", \\\"{x:1550,y:903,t:1528144055568};\\\", \\\"{x:1550,y:902,t:1528144055592};\\\", \\\"{x:1550,y:901,t:1528144055602};\\\", \\\"{x:1550,y:900,t:1528144055618};\\\", \\\"{x:1549,y:898,t:1528144055636};\\\", \\\"{x:1549,y:897,t:1528144055653};\\\", \\\"{x:1548,y:892,t:1528144055668};\\\", \\\"{x:1548,y:889,t:1528144055685};\\\", \\\"{x:1547,y:884,t:1528144055703};\\\", \\\"{x:1547,y:880,t:1528144055719};\\\", \\\"{x:1546,y:875,t:1528144055735};\\\", \\\"{x:1545,y:870,t:1528144055751};\\\", \\\"{x:1544,y:867,t:1528144055770};\\\", \\\"{x:1544,y:865,t:1528144055785};\\\", \\\"{x:1543,y:861,t:1528144055802};\\\", \\\"{x:1542,y:855,t:1528144055819};\\\", \\\"{x:1540,y:850,t:1528144055835};\\\", \\\"{x:1539,y:844,t:1528144055853};\\\", \\\"{x:1536,y:838,t:1528144055870};\\\", \\\"{x:1536,y:835,t:1528144055885};\\\", \\\"{x:1535,y:831,t:1528144055902};\\\", \\\"{x:1535,y:823,t:1528144055920};\\\", \\\"{x:1534,y:818,t:1528144055935};\\\", \\\"{x:1532,y:809,t:1528144055952};\\\", \\\"{x:1531,y:806,t:1528144055969};\\\", \\\"{x:1531,y:802,t:1528144055985};\\\", \\\"{x:1531,y:799,t:1528144056002};\\\", \\\"{x:1531,y:795,t:1528144056019};\\\", \\\"{x:1530,y:792,t:1528144056036};\\\", \\\"{x:1530,y:790,t:1528144056051};\\\", \\\"{x:1530,y:789,t:1528144056068};\\\", \\\"{x:1530,y:788,t:1528144056085};\\\", \\\"{x:1530,y:787,t:1528144056102};\\\", \\\"{x:1528,y:781,t:1528144056119};\\\", \\\"{x:1528,y:778,t:1528144056135};\\\", \\\"{x:1528,y:775,t:1528144056151};\\\", \\\"{x:1528,y:772,t:1528144056168};\\\", \\\"{x:1528,y:768,t:1528144056186};\\\", \\\"{x:1528,y:764,t:1528144056201};\\\", \\\"{x:1528,y:759,t:1528144056219};\\\", \\\"{x:1528,y:753,t:1528144056236};\\\", \\\"{x:1528,y:749,t:1528144056251};\\\", \\\"{x:1528,y:745,t:1528144056269};\\\", \\\"{x:1528,y:742,t:1528144056286};\\\", \\\"{x:1528,y:739,t:1528144056302};\\\", \\\"{x:1528,y:734,t:1528144056319};\\\", \\\"{x:1529,y:732,t:1528144056336};\\\", \\\"{x:1529,y:730,t:1528144056352};\\\", \\\"{x:1529,y:727,t:1528144056369};\\\", \\\"{x:1529,y:726,t:1528144056386};\\\", \\\"{x:1529,y:722,t:1528144056401};\\\", \\\"{x:1531,y:719,t:1528144056418};\\\", \\\"{x:1531,y:717,t:1528144056436};\\\", \\\"{x:1531,y:715,t:1528144056452};\\\", \\\"{x:1531,y:713,t:1528144056469};\\\", \\\"{x:1532,y:712,t:1528144056486};\\\", \\\"{x:1533,y:709,t:1528144056502};\\\", \\\"{x:1535,y:703,t:1528144056519};\\\", \\\"{x:1536,y:700,t:1528144056535};\\\", \\\"{x:1536,y:697,t:1528144056552};\\\", \\\"{x:1536,y:696,t:1528144056569};\\\", \\\"{x:1537,y:695,t:1528144056586};\\\", \\\"{x:1537,y:694,t:1528144056602};\\\", \\\"{x:1538,y:693,t:1528144056619};\\\", \\\"{x:1539,y:691,t:1528144056636};\\\", \\\"{x:1539,y:690,t:1528144057252};\\\", \\\"{x:1540,y:686,t:1528144057259};\\\", \\\"{x:1540,y:681,t:1528144057274};\\\", \\\"{x:1540,y:678,t:1528144057289};\\\", \\\"{x:1540,y:672,t:1528144057306};\\\", \\\"{x:1540,y:671,t:1528144057323};\\\", \\\"{x:1540,y:670,t:1528144057340};\\\", \\\"{x:1540,y:669,t:1528144057357};\\\", \\\"{x:1540,y:668,t:1528144057373};\\\", \\\"{x:1540,y:665,t:1528144057389};\\\", \\\"{x:1540,y:663,t:1528144057406};\\\", \\\"{x:1540,y:661,t:1528144057424};\\\", \\\"{x:1540,y:657,t:1528144057440};\\\", \\\"{x:1540,y:654,t:1528144057456};\\\", \\\"{x:1540,y:650,t:1528144057474};\\\", \\\"{x:1541,y:647,t:1528144057490};\\\", \\\"{x:1541,y:643,t:1528144057507};\\\", \\\"{x:1541,y:636,t:1528144057523};\\\", \\\"{x:1541,y:631,t:1528144057540};\\\", \\\"{x:1541,y:627,t:1528144057556};\\\", \\\"{x:1541,y:624,t:1528144057573};\\\", \\\"{x:1541,y:620,t:1528144057591};\\\", \\\"{x:1541,y:618,t:1528144057607};\\\", \\\"{x:1541,y:617,t:1528144057623};\\\", \\\"{x:1540,y:615,t:1528144057641};\\\", \\\"{x:1540,y:613,t:1528144057657};\\\", \\\"{x:1540,y:610,t:1528144057673};\\\", \\\"{x:1540,y:607,t:1528144057691};\\\", \\\"{x:1540,y:602,t:1528144057707};\\\", \\\"{x:1540,y:598,t:1528144057724};\\\", \\\"{x:1540,y:594,t:1528144057740};\\\", \\\"{x:1540,y:592,t:1528144057756};\\\", \\\"{x:1540,y:590,t:1528144057774};\\\", \\\"{x:1540,y:588,t:1528144057790};\\\", \\\"{x:1540,y:585,t:1528144057806};\\\", \\\"{x:1540,y:583,t:1528144057824};\\\", \\\"{x:1540,y:580,t:1528144057841};\\\", \\\"{x:1542,y:577,t:1528144057857};\\\", \\\"{x:1542,y:576,t:1528144057873};\\\", \\\"{x:1542,y:574,t:1528144057891};\\\", \\\"{x:1542,y:573,t:1528144057907};\\\", \\\"{x:1543,y:572,t:1528144057924};\\\", \\\"{x:1543,y:571,t:1528144058036};\\\", \\\"{x:1545,y:568,t:1528144058068};\\\", \\\"{x:1545,y:567,t:1528144058083};\\\", \\\"{x:1545,y:566,t:1528144058091};\\\", \\\"{x:1545,y:565,t:1528144058114};\\\", \\\"{x:1545,y:564,t:1528144058123};\\\", \\\"{x:1546,y:562,t:1528144058141};\\\", \\\"{x:1546,y:561,t:1528144058682};\\\", \\\"{x:1547,y:560,t:1528144058690};\\\", \\\"{x:1547,y:553,t:1528144058707};\\\", \\\"{x:1547,y:549,t:1528144058724};\\\", \\\"{x:1547,y:539,t:1528144058740};\\\", \\\"{x:1547,y:531,t:1528144058757};\\\", \\\"{x:1547,y:525,t:1528144058774};\\\", \\\"{x:1547,y:524,t:1528144058790};\\\", \\\"{x:1547,y:523,t:1528144058807};\\\", \\\"{x:1547,y:522,t:1528144058827};\\\", \\\"{x:1547,y:520,t:1528144058859};\\\", \\\"{x:1547,y:517,t:1528144058874};\\\", \\\"{x:1547,y:514,t:1528144058891};\\\", \\\"{x:1547,y:509,t:1528144058907};\\\", \\\"{x:1547,y:506,t:1528144058924};\\\", \\\"{x:1547,y:503,t:1528144058941};\\\", \\\"{x:1547,y:501,t:1528144058957};\\\", \\\"{x:1547,y:498,t:1528144058974};\\\", \\\"{x:1547,y:497,t:1528144058990};\\\", \\\"{x:1547,y:494,t:1528144059007};\\\", \\\"{x:1547,y:492,t:1528144059024};\\\", \\\"{x:1547,y:490,t:1528144059041};\\\", \\\"{x:1547,y:488,t:1528144059057};\\\", \\\"{x:1547,y:483,t:1528144059073};\\\", \\\"{x:1547,y:480,t:1528144059091};\\\", \\\"{x:1547,y:478,t:1528144059107};\\\", \\\"{x:1547,y:477,t:1528144059130};\\\", \\\"{x:1547,y:475,t:1528144059146};\\\", \\\"{x:1547,y:474,t:1528144059162};\\\", \\\"{x:1547,y:473,t:1528144059174};\\\", \\\"{x:1547,y:471,t:1528144059191};\\\", \\\"{x:1547,y:468,t:1528144059207};\\\", \\\"{x:1547,y:467,t:1528144059224};\\\", \\\"{x:1547,y:464,t:1528144059241};\\\", \\\"{x:1548,y:460,t:1528144059257};\\\", \\\"{x:1549,y:457,t:1528144059274};\\\", \\\"{x:1549,y:456,t:1528144059291};\\\", \\\"{x:1549,y:454,t:1528144059308};\\\", \\\"{x:1549,y:453,t:1528144059324};\\\", \\\"{x:1549,y:452,t:1528144059341};\\\", \\\"{x:1549,y:451,t:1528144059357};\\\", \\\"{x:1549,y:449,t:1528144059374};\\\", \\\"{x:1549,y:448,t:1528144059392};\\\", \\\"{x:1549,y:447,t:1528144059411};\\\", \\\"{x:1549,y:446,t:1528144059424};\\\", \\\"{x:1549,y:445,t:1528144059442};\\\", \\\"{x:1549,y:444,t:1528144059467};\\\", \\\"{x:1549,y:443,t:1528144059475};\\\", \\\"{x:1549,y:442,t:1528144059491};\\\", \\\"{x:1549,y:441,t:1528144059563};\\\", \\\"{x:1549,y:440,t:1528144059578};\\\", \\\"{x:1553,y:426,t:1528144060555};\\\", \\\"{x:1560,y:399,t:1528144060563};\\\", \\\"{x:1561,y:385,t:1528144060576};\\\", \\\"{x:1561,y:375,t:1528144060593};\\\", \\\"{x:1559,y:364,t:1528144060609};\\\", \\\"{x:1556,y:357,t:1528144060626};\\\", \\\"{x:1556,y:356,t:1528144060643};\\\", \\\"{x:1555,y:356,t:1528144061019};\\\", \\\"{x:1553,y:356,t:1528144061027};\\\", \\\"{x:1543,y:353,t:1528144061042};\\\", \\\"{x:1526,y:345,t:1528144061059};\\\", \\\"{x:1514,y:340,t:1528144061075};\\\", \\\"{x:1509,y:339,t:1528144061092};\\\", \\\"{x:1505,y:337,t:1528144061109};\\\", \\\"{x:1504,y:337,t:1528144061125};\\\", \\\"{x:1504,y:336,t:1528144061170};\\\", \\\"{x:1504,y:329,t:1528144061243};\\\", \\\"{x:1504,y:325,t:1528144061259};\\\", \\\"{x:1503,y:324,t:1528144061476};\\\", \\\"{x:1474,y:357,t:1528144061493};\\\", \\\"{x:1410,y:451,t:1528144061510};\\\", \\\"{x:1301,y:565,t:1528144061527};\\\", \\\"{x:1155,y:690,t:1528144061543};\\\", \\\"{x:991,y:814,t:1528144061560};\\\", \\\"{x:819,y:904,t:1528144061576};\\\", \\\"{x:679,y:961,t:1528144061592};\\\", \\\"{x:590,y:998,t:1528144061609};\\\", \\\"{x:558,y:1006,t:1528144061627};\\\", \\\"{x:552,y:1005,t:1528144061643};\\\", \\\"{x:548,y:1001,t:1528144061659};\\\", \\\"{x:544,y:993,t:1528144061677};\\\", \\\"{x:538,y:984,t:1528144061692};\\\", \\\"{x:533,y:977,t:1528144061710};\\\", \\\"{x:533,y:976,t:1528144061727};\\\", \\\"{x:533,y:975,t:1528144061743};\\\", \\\"{x:535,y:969,t:1528144061759};\\\", \\\"{x:538,y:951,t:1528144061776};\\\", \\\"{x:540,y:929,t:1528144061793};\\\", \\\"{x:541,y:918,t:1528144061810};\\\", \\\"{x:542,y:907,t:1528144061826};\\\", \\\"{x:542,y:905,t:1528144061843};\\\", \\\"{x:543,y:889,t:1528144061860};\\\", \\\"{x:543,y:870,t:1528144061875};\\\", \\\"{x:531,y:833,t:1528144061893};\\\", \\\"{x:506,y:752,t:1528144061910};\\\", \\\"{x:492,y:716,t:1528144061926};\\\", \\\"{x:487,y:695,t:1528144061943};\\\", \\\"{x:485,y:681,t:1528144061960};\\\", \\\"{x:483,y:674,t:1528144061976};\\\", \\\"{x:483,y:672,t:1528144061993};\\\", \\\"{x:480,y:674,t:1528144062074};\\\", \\\"{x:479,y:676,t:1528144062083};\\\", \\\"{x:477,y:681,t:1528144062093};\\\", \\\"{x:473,y:689,t:1528144062110};\\\", \\\"{x:469,y:694,t:1528144062127};\\\", \\\"{x:469,y:695,t:1528144062143};\\\", \\\"{x:468,y:696,t:1528144062160};\\\", \\\"{x:466,y:698,t:1528144062177};\\\", \\\"{x:462,y:703,t:1528144062193};\\\", \\\"{x:459,y:712,t:1528144062209};\\\", \\\"{x:458,y:715,t:1528144062227};\\\", \\\"{x:458,y:717,t:1528144062243};\\\", \\\"{x:458,y:718,t:1528144062260};\\\", \\\"{x:458,y:719,t:1528144062282};\\\", \\\"{x:458,y:721,t:1528144062306};\\\", \\\"{x:458,y:722,t:1528144062321};\\\", \\\"{x:458,y:725,t:1528144062329};\\\", \\\"{x:459,y:728,t:1528144062343};\\\", \\\"{x:459,y:732,t:1528144062360};\\\", \\\"{x:459,y:735,t:1528144062377};\\\", \\\"{x:460,y:736,t:1528144062394};\\\", \\\"{x:461,y:738,t:1528144062410};\\\", \\\"{x:461,y:743,t:1528144062426};\\\", \\\"{x:462,y:751,t:1528144062444};\\\", \\\"{x:462,y:758,t:1528144062462};\\\", \\\"{x:462,y:762,t:1528144062477};\\\", \\\"{x:462,y:765,t:1528144062493};\\\", \\\"{x:462,y:766,t:1528144062510};\\\", \\\"{x:462,y:760,t:1528144062611};\\\", \\\"{x:462,y:745,t:1528144062628};\\\", \\\"{x:462,y:730,t:1528144062643};\\\", \\\"{x:461,y:715,t:1528144062660};\\\", \\\"{x:456,y:696,t:1528144062677};\\\", \\\"{x:446,y:678,t:1528144062693};\\\", \\\"{x:435,y:665,t:1528144062710};\\\", \\\"{x:428,y:655,t:1528144062727};\\\", \\\"{x:421,y:647,t:1528144062743};\\\", \\\"{x:413,y:637,t:1528144062761};\\\", \\\"{x:404,y:626,t:1528144062777};\\\", \\\"{x:398,y:618,t:1528144062793};\\\", \\\"{x:390,y:606,t:1528144062810};\\\", \\\"{x:386,y:601,t:1528144062827};\\\", \\\"{x:377,y:594,t:1528144062844};\\\", \\\"{x:373,y:591,t:1528144062860};\\\", \\\"{x:371,y:590,t:1528144062877};\\\", \\\"{x:370,y:589,t:1528144062894};\\\", \\\"{x:370,y:588,t:1528144062930};\\\", \\\"{x:370,y:586,t:1528144062944};\\\", \\\"{x:370,y:583,t:1528144062961};\\\", \\\"{x:372,y:580,t:1528144063099};\\\", \\\"{x:374,y:579,t:1528144063113};\\\", \\\"{x:376,y:578,t:1528144063127};\\\", \\\"{x:377,y:577,t:1528144063144};\\\", \\\"{x:378,y:577,t:1528144063162};\\\", \\\"{x:381,y:580,t:1528144065187};\\\", \\\"{x:394,y:596,t:1528144065196};\\\", \\\"{x:412,y:620,t:1528144065213};\\\", \\\"{x:420,y:632,t:1528144065230};\\\", \\\"{x:426,y:647,t:1528144065245};\\\", \\\"{x:430,y:655,t:1528144065262};\\\", \\\"{x:430,y:657,t:1528144065279};\\\", \\\"{x:432,y:661,t:1528144065295};\\\", \\\"{x:433,y:662,t:1528144065312};\\\", \\\"{x:433,y:663,t:1528144065329};\\\", \\\"{x:433,y:666,t:1528144065345};\\\", \\\"{x:433,y:669,t:1528144065362};\\\", \\\"{x:434,y:669,t:1528144065379};\\\", \\\"{x:434,y:670,t:1528144065427};\\\", \\\"{x:434,y:673,t:1528144065446};\\\", \\\"{x:434,y:680,t:1528144065463};\\\", \\\"{x:438,y:688,t:1528144065480};\\\", \\\"{x:441,y:693,t:1528144065496};\\\", \\\"{x:443,y:694,t:1528144065512};\\\", \\\"{x:446,y:697,t:1528144065529};\\\", \\\"{x:451,y:698,t:1528144065546};\\\", \\\"{x:454,y:700,t:1528144065562};\\\", \\\"{x:456,y:701,t:1528144065579};\\\", \\\"{x:459,y:707,t:1528144065596};\\\", \\\"{x:461,y:713,t:1528144065614};\\\", \\\"{x:463,y:716,t:1528144065630};\\\", \\\"{x:463,y:720,t:1528144065647};\\\", \\\"{x:465,y:724,t:1528144065663};\\\", \\\"{x:466,y:730,t:1528144065679};\\\", \\\"{x:467,y:734,t:1528144065696};\\\", \\\"{x:467,y:739,t:1528144065712};\\\", \\\"{x:467,y:742,t:1528144065729};\\\", \\\"{x:469,y:745,t:1528144065747};\\\", \\\"{x:471,y:745,t:1528144066251};\\\", \\\"{x:474,y:746,t:1528144066264};\\\", \\\"{x:476,y:747,t:1528144066282};\\\", \\\"{x:477,y:748,t:1528144066314};\\\", \\\"{x:478,y:749,t:1528144066571};\\\", \\\"{x:480,y:749,t:1528144066580};\\\" ] }, { \\\"rt\\\": 62958, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 1213451, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"VVH1B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-02 PM-X -X -02 PM-02 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:481,y:750,t:1528144068283};\\\", \\\"{x:482,y:751,t:1528144068891};\\\", \\\"{x:483,y:751,t:1528144069435};\\\", \\\"{x:484,y:752,t:1528144069739};\\\", \\\"{x:485,y:752,t:1528144072747};\\\", \\\"{x:486,y:752,t:1528144072760};\\\", \\\"{x:486,y:747,t:1528144072778};\\\", \\\"{x:479,y:741,t:1528144072793};\\\", \\\"{x:477,y:740,t:1528144072810};\\\", \\\"{x:470,y:740,t:1528144073315};\\\", \\\"{x:443,y:751,t:1528144073327};\\\", \\\"{x:410,y:761,t:1528144073343};\\\", \\\"{x:399,y:766,t:1528144073358};\\\", \\\"{x:395,y:766,t:1528144073368};\\\", \\\"{x:370,y:761,t:1528144073385};\\\", \\\"{x:368,y:760,t:1528144073402};\\\", \\\"{x:378,y:741,t:1528144073419};\\\", \\\"{x:395,y:712,t:1528144073435};\\\", \\\"{x:412,y:683,t:1528144073453};\\\", \\\"{x:423,y:663,t:1528144073468};\\\", \\\"{x:432,y:644,t:1528144073486};\\\", \\\"{x:443,y:628,t:1528144073502};\\\", \\\"{x:447,y:619,t:1528144073518};\\\", \\\"{x:455,y:611,t:1528144073536};\\\", \\\"{x:460,y:602,t:1528144073553};\\\", \\\"{x:467,y:594,t:1528144073568};\\\", \\\"{x:490,y:574,t:1528144073586};\\\", \\\"{x:511,y:564,t:1528144073603};\\\", \\\"{x:534,y:552,t:1528144073618};\\\", \\\"{x:557,y:539,t:1528144073635};\\\", \\\"{x:576,y:527,t:1528144073653};\\\", \\\"{x:587,y:518,t:1528144073668};\\\", \\\"{x:595,y:512,t:1528144073685};\\\", \\\"{x:606,y:507,t:1528144073702};\\\", \\\"{x:619,y:502,t:1528144073718};\\\", \\\"{x:629,y:498,t:1528144073736};\\\", \\\"{x:632,y:495,t:1528144073753};\\\", \\\"{x:635,y:494,t:1528144073769};\\\", \\\"{x:636,y:493,t:1528144073786};\\\", \\\"{x:637,y:492,t:1528144073810};\\\", \\\"{x:639,y:491,t:1528144074867};\\\", \\\"{x:644,y:487,t:1528144074875};\\\", \\\"{x:650,y:485,t:1528144074887};\\\", \\\"{x:653,y:484,t:1528144074903};\\\", \\\"{x:659,y:478,t:1528144074921};\\\", \\\"{x:662,y:474,t:1528144074936};\\\", \\\"{x:666,y:467,t:1528144074955};\\\", \\\"{x:669,y:464,t:1528144074970};\\\", \\\"{x:669,y:462,t:1528144074987};\\\", \\\"{x:670,y:461,t:1528144075004};\\\", \\\"{x:672,y:459,t:1528144075035};\\\", \\\"{x:670,y:461,t:1528144075203};\\\", \\\"{x:669,y:462,t:1528144075210};\\\", \\\"{x:666,y:466,t:1528144075221};\\\", \\\"{x:658,y:472,t:1528144075237};\\\", \\\"{x:644,y:481,t:1528144075254};\\\", \\\"{x:629,y:488,t:1528144075271};\\\", \\\"{x:609,y:498,t:1528144075286};\\\", \\\"{x:588,y:508,t:1528144075305};\\\", \\\"{x:560,y:520,t:1528144075320};\\\", \\\"{x:516,y:530,t:1528144075335};\\\", \\\"{x:471,y:538,t:1528144075352};\\\", \\\"{x:448,y:540,t:1528144075369};\\\", \\\"{x:434,y:542,t:1528144075387};\\\", \\\"{x:432,y:542,t:1528144075490};\\\", \\\"{x:430,y:542,t:1528144075504};\\\", \\\"{x:430,y:534,t:1528144075521};\\\", \\\"{x:432,y:522,t:1528144075537};\\\", \\\"{x:446,y:501,t:1528144075554};\\\", \\\"{x:461,y:485,t:1528144075571};\\\", \\\"{x:478,y:471,t:1528144075587};\\\", \\\"{x:491,y:466,t:1528144075604};\\\", \\\"{x:508,y:466,t:1528144075620};\\\", \\\"{x:524,y:467,t:1528144075636};\\\", \\\"{x:537,y:470,t:1528144075654};\\\", \\\"{x:546,y:471,t:1528144075671};\\\", \\\"{x:553,y:473,t:1528144075687};\\\", \\\"{x:557,y:474,t:1528144075704};\\\", \\\"{x:562,y:477,t:1528144075719};\\\", \\\"{x:569,y:481,t:1528144075737};\\\", \\\"{x:572,y:481,t:1528144075754};\\\", \\\"{x:573,y:482,t:1528144075769};\\\", \\\"{x:575,y:483,t:1528144075786};\\\", \\\"{x:576,y:483,t:1528144075804};\\\", \\\"{x:576,y:484,t:1528144075821};\\\", \\\"{x:577,y:484,t:1528144075915};\\\", \\\"{x:578,y:484,t:1528144076715};\\\", \\\"{x:593,y:476,t:1528144076722};\\\", \\\"{x:616,y:467,t:1528144076734};\\\", \\\"{x:658,y:454,t:1528144076751};\\\", \\\"{x:688,y:445,t:1528144076767};\\\", \\\"{x:706,y:439,t:1528144076784};\\\", \\\"{x:715,y:436,t:1528144076801};\\\", \\\"{x:718,y:435,t:1528144076817};\\\", \\\"{x:722,y:434,t:1528144076834};\\\", \\\"{x:725,y:434,t:1528144076851};\\\", \\\"{x:728,y:434,t:1528144076867};\\\", \\\"{x:735,y:434,t:1528144076884};\\\", \\\"{x:744,y:434,t:1528144076900};\\\", \\\"{x:761,y:435,t:1528144076917};\\\", \\\"{x:778,y:440,t:1528144076934};\\\", \\\"{x:800,y:447,t:1528144076950};\\\", \\\"{x:819,y:453,t:1528144076967};\\\", \\\"{x:832,y:457,t:1528144076984};\\\", \\\"{x:841,y:459,t:1528144076999};\\\", \\\"{x:850,y:462,t:1528144077017};\\\", \\\"{x:864,y:466,t:1528144077032};\\\", \\\"{x:893,y:476,t:1528144077049};\\\", \\\"{x:921,y:488,t:1528144077067};\\\", \\\"{x:951,y:502,t:1528144077082};\\\", \\\"{x:1000,y:522,t:1528144077099};\\\", \\\"{x:1061,y:548,t:1528144077116};\\\", \\\"{x:1122,y:574,t:1528144077133};\\\", \\\"{x:1184,y:596,t:1528144077150};\\\", \\\"{x:1246,y:615,t:1528144077166};\\\", \\\"{x:1316,y:640,t:1528144077182};\\\", \\\"{x:1387,y:666,t:1528144077200};\\\", \\\"{x:1475,y:699,t:1528144077215};\\\", \\\"{x:1597,y:743,t:1528144077233};\\\", \\\"{x:1744,y:785,t:1528144077248};\\\", \\\"{x:1919,y:831,t:1528144077266};\\\", \\\"{x:1919,y:850,t:1528144077283};\\\", \\\"{x:1919,y:859,t:1528144077305};\\\", \\\"{x:1919,y:860,t:1528144077450};\\\", \\\"{x:1909,y:862,t:1528144077457};\\\", \\\"{x:1898,y:863,t:1528144077473};\\\", \\\"{x:1836,y:881,t:1528144077490};\\\", \\\"{x:1785,y:897,t:1528144077505};\\\", \\\"{x:1744,y:907,t:1528144077522};\\\", \\\"{x:1701,y:923,t:1528144077539};\\\", \\\"{x:1678,y:936,t:1528144077556};\\\", \\\"{x:1658,y:947,t:1528144077572};\\\", \\\"{x:1644,y:955,t:1528144077589};\\\", \\\"{x:1632,y:964,t:1528144077606};\\\", \\\"{x:1620,y:972,t:1528144077622};\\\", \\\"{x:1605,y:982,t:1528144077639};\\\", \\\"{x:1588,y:991,t:1528144077656};\\\", \\\"{x:1571,y:1000,t:1528144077672};\\\", \\\"{x:1562,y:1005,t:1528144077689};\\\", \\\"{x:1559,y:1007,t:1528144077706};\\\", \\\"{x:1558,y:1008,t:1528144077730};\\\", \\\"{x:1557,y:1010,t:1528144077771};\\\", \\\"{x:1552,y:1011,t:1528144077779};\\\", \\\"{x:1549,y:1013,t:1528144077789};\\\", \\\"{x:1540,y:1017,t:1528144077806};\\\", \\\"{x:1528,y:1020,t:1528144077822};\\\", \\\"{x:1518,y:1023,t:1528144077839};\\\", \\\"{x:1510,y:1023,t:1528144077855};\\\", \\\"{x:1508,y:1023,t:1528144077873};\\\", \\\"{x:1505,y:1023,t:1528144077888};\\\", \\\"{x:1491,y:1019,t:1528144077906};\\\", \\\"{x:1487,y:1017,t:1528144077922};\\\", \\\"{x:1486,y:1017,t:1528144077939};\\\", \\\"{x:1486,y:1016,t:1528144077957};\\\", \\\"{x:1485,y:1014,t:1528144077973};\\\", \\\"{x:1485,y:1005,t:1528144077989};\\\", \\\"{x:1484,y:999,t:1528144078006};\\\", \\\"{x:1481,y:993,t:1528144078023};\\\", \\\"{x:1480,y:989,t:1528144078039};\\\", \\\"{x:1480,y:988,t:1528144078059};\\\", \\\"{x:1479,y:987,t:1528144078073};\\\", \\\"{x:1479,y:986,t:1528144078155};\\\", \\\"{x:1479,y:984,t:1528144078173};\\\", \\\"{x:1479,y:983,t:1528144078189};\\\", \\\"{x:1479,y:982,t:1528144078206};\\\", \\\"{x:1479,y:981,t:1528144078223};\\\", \\\"{x:1479,y:979,t:1528144078475};\\\", \\\"{x:1479,y:977,t:1528144078490};\\\", \\\"{x:1479,y:976,t:1528144078506};\\\", \\\"{x:1479,y:974,t:1528144078523};\\\", \\\"{x:1479,y:970,t:1528144078540};\\\", \\\"{x:1479,y:968,t:1528144078556};\\\", \\\"{x:1479,y:966,t:1528144078573};\\\", \\\"{x:1479,y:965,t:1528144078591};\\\", \\\"{x:1479,y:964,t:1528144078611};\\\", \\\"{x:1479,y:963,t:1528144078635};\\\", \\\"{x:1479,y:962,t:1528144078643};\\\", \\\"{x:1479,y:960,t:1528144078655};\\\", \\\"{x:1479,y:957,t:1528144078673};\\\", \\\"{x:1479,y:954,t:1528144078689};\\\", \\\"{x:1479,y:951,t:1528144078706};\\\", \\\"{x:1479,y:947,t:1528144078722};\\\", \\\"{x:1479,y:941,t:1528144078740};\\\", \\\"{x:1481,y:936,t:1528144078757};\\\", \\\"{x:1482,y:932,t:1528144078773};\\\", \\\"{x:1482,y:927,t:1528144078789};\\\", \\\"{x:1482,y:922,t:1528144078806};\\\", \\\"{x:1483,y:919,t:1528144078823};\\\", \\\"{x:1483,y:915,t:1528144078840};\\\", \\\"{x:1484,y:913,t:1528144078857};\\\", \\\"{x:1484,y:909,t:1528144078873};\\\", \\\"{x:1486,y:903,t:1528144078890};\\\", \\\"{x:1486,y:901,t:1528144078907};\\\", \\\"{x:1486,y:897,t:1528144078923};\\\", \\\"{x:1487,y:895,t:1528144078940};\\\", \\\"{x:1487,y:894,t:1528144078957};\\\", \\\"{x:1487,y:892,t:1528144078973};\\\", \\\"{x:1487,y:891,t:1528144078990};\\\", \\\"{x:1487,y:889,t:1528144079007};\\\", \\\"{x:1487,y:888,t:1528144079023};\\\", \\\"{x:1487,y:886,t:1528144079040};\\\", \\\"{x:1487,y:885,t:1528144079059};\\\", \\\"{x:1487,y:884,t:1528144079074};\\\", \\\"{x:1487,y:883,t:1528144079090};\\\", \\\"{x:1487,y:881,t:1528144079107};\\\", \\\"{x:1487,y:880,t:1528144079123};\\\", \\\"{x:1487,y:878,t:1528144079140};\\\", \\\"{x:1487,y:876,t:1528144079157};\\\", \\\"{x:1487,y:875,t:1528144079173};\\\", \\\"{x:1487,y:873,t:1528144079190};\\\", \\\"{x:1487,y:871,t:1528144079207};\\\", \\\"{x:1487,y:869,t:1528144079223};\\\", \\\"{x:1487,y:864,t:1528144079240};\\\", \\\"{x:1487,y:860,t:1528144079257};\\\", \\\"{x:1487,y:856,t:1528144079273};\\\", \\\"{x:1487,y:852,t:1528144079289};\\\", \\\"{x:1487,y:850,t:1528144079307};\\\", \\\"{x:1487,y:848,t:1528144079324};\\\", \\\"{x:1487,y:845,t:1528144079340};\\\", \\\"{x:1487,y:840,t:1528144079357};\\\", \\\"{x:1487,y:835,t:1528144079373};\\\", \\\"{x:1487,y:832,t:1528144079389};\\\", \\\"{x:1487,y:829,t:1528144079407};\\\", \\\"{x:1485,y:828,t:1528144079426};\\\", \\\"{x:1485,y:827,t:1528144079458};\\\", \\\"{x:1485,y:825,t:1528144080453};\\\", \\\"{x:1485,y:823,t:1528144080475};\\\", \\\"{x:1485,y:822,t:1528144080491};\\\", \\\"{x:1484,y:820,t:1528144080508};\\\", \\\"{x:1484,y:818,t:1528144080524};\\\", \\\"{x:1483,y:817,t:1528144080541};\\\", \\\"{x:1483,y:816,t:1528144080558};\\\", \\\"{x:1483,y:814,t:1528144080850};\\\", \\\"{x:1483,y:813,t:1528144080875};\\\", \\\"{x:1483,y:812,t:1528144080891};\\\", \\\"{x:1483,y:810,t:1528144080908};\\\", \\\"{x:1483,y:809,t:1528144080925};\\\", \\\"{x:1483,y:808,t:1528144080941};\\\", \\\"{x:1483,y:807,t:1528144080958};\\\", \\\"{x:1483,y:804,t:1528144080976};\\\", \\\"{x:1483,y:803,t:1528144081011};\\\", \\\"{x:1482,y:802,t:1528144090675};\\\", \\\"{x:1481,y:802,t:1528144095882};\\\", \\\"{x:1480,y:802,t:1528144095889};\\\", \\\"{x:1476,y:802,t:1528144095903};\\\", \\\"{x:1442,y:835,t:1528144095919};\\\", \\\"{x:1410,y:860,t:1528144095935};\\\", \\\"{x:1393,y:874,t:1528144095953};\\\", \\\"{x:1364,y:896,t:1528144095969};\\\", \\\"{x:1356,y:901,t:1528144095985};\\\", \\\"{x:1355,y:901,t:1528144096003};\\\", \\\"{x:1355,y:902,t:1528144096025};\\\", \\\"{x:1354,y:902,t:1528144096082};\\\", \\\"{x:1354,y:903,t:1528144096090};\\\", \\\"{x:1353,y:904,t:1528144096103};\\\", \\\"{x:1353,y:905,t:1528144096120};\\\", \\\"{x:1353,y:903,t:1528144096259};\\\", \\\"{x:1354,y:896,t:1528144096270};\\\", \\\"{x:1356,y:891,t:1528144096287};\\\", \\\"{x:1357,y:888,t:1528144096303};\\\", \\\"{x:1358,y:887,t:1528144096320};\\\", \\\"{x:1361,y:884,t:1528144096336};\\\", \\\"{x:1363,y:882,t:1528144096355};\\\", \\\"{x:1364,y:881,t:1528144096370};\\\", \\\"{x:1365,y:878,t:1528144096387};\\\", \\\"{x:1366,y:878,t:1528144096403};\\\", \\\"{x:1367,y:877,t:1528144096420};\\\", \\\"{x:1369,y:875,t:1528144096437};\\\", \\\"{x:1369,y:874,t:1528144096466};\\\", \\\"{x:1370,y:874,t:1528144096482};\\\", \\\"{x:1370,y:873,t:1528144096491};\\\", \\\"{x:1371,y:872,t:1528144096503};\\\", \\\"{x:1372,y:870,t:1528144096520};\\\", \\\"{x:1374,y:869,t:1528144096538};\\\", \\\"{x:1376,y:867,t:1528144096553};\\\", \\\"{x:1380,y:864,t:1528144096571};\\\", \\\"{x:1381,y:863,t:1528144096586};\\\", \\\"{x:1383,y:862,t:1528144096603};\\\", \\\"{x:1384,y:860,t:1528144096620};\\\", \\\"{x:1385,y:859,t:1528144096637};\\\", \\\"{x:1386,y:857,t:1528144096653};\\\", \\\"{x:1389,y:855,t:1528144096670};\\\", \\\"{x:1390,y:852,t:1528144096687};\\\", \\\"{x:1391,y:850,t:1528144096703};\\\", \\\"{x:1392,y:849,t:1528144096723};\\\", \\\"{x:1392,y:847,t:1528144096746};\\\", \\\"{x:1393,y:847,t:1528144096754};\\\", \\\"{x:1396,y:843,t:1528144096770};\\\", \\\"{x:1396,y:842,t:1528144096786};\\\", \\\"{x:1397,y:839,t:1528144096804};\\\", \\\"{x:1398,y:838,t:1528144096820};\\\", \\\"{x:1399,y:836,t:1528144096843};\\\", \\\"{x:1400,y:835,t:1528144096866};\\\", \\\"{x:1400,y:834,t:1528144096875};\\\", \\\"{x:1401,y:832,t:1528144096887};\\\", \\\"{x:1402,y:830,t:1528144096904};\\\", \\\"{x:1402,y:827,t:1528144096921};\\\", \\\"{x:1404,y:824,t:1528144096937};\\\", \\\"{x:1405,y:821,t:1528144096954};\\\", \\\"{x:1406,y:820,t:1528144096970};\\\", \\\"{x:1407,y:817,t:1528144096987};\\\", \\\"{x:1409,y:813,t:1528144097003};\\\", \\\"{x:1411,y:810,t:1528144097019};\\\", \\\"{x:1412,y:807,t:1528144097036};\\\", \\\"{x:1413,y:806,t:1528144097053};\\\", \\\"{x:1414,y:804,t:1528144097069};\\\", \\\"{x:1415,y:803,t:1528144097087};\\\", \\\"{x:1415,y:802,t:1528144097104};\\\", \\\"{x:1415,y:801,t:1528144097119};\\\", \\\"{x:1416,y:799,t:1528144097136};\\\", \\\"{x:1419,y:795,t:1528144097153};\\\", \\\"{x:1419,y:794,t:1528144097186};\\\", \\\"{x:1419,y:793,t:1528144097194};\\\", \\\"{x:1419,y:792,t:1528144097210};\\\", \\\"{x:1420,y:791,t:1528144097226};\\\", \\\"{x:1421,y:790,t:1528144097266};\\\", \\\"{x:1422,y:789,t:1528144097274};\\\", \\\"{x:1422,y:788,t:1528144097298};\\\", \\\"{x:1422,y:787,t:1528144097306};\\\", \\\"{x:1423,y:787,t:1528144097320};\\\", \\\"{x:1423,y:786,t:1528144097337};\\\", \\\"{x:1425,y:785,t:1528144097354};\\\", \\\"{x:1425,y:784,t:1528144097370};\\\", \\\"{x:1425,y:783,t:1528144097387};\\\", \\\"{x:1427,y:781,t:1528144097403};\\\", \\\"{x:1428,y:780,t:1528144097421};\\\", \\\"{x:1429,y:779,t:1528144097437};\\\", \\\"{x:1430,y:778,t:1528144097454};\\\", \\\"{x:1430,y:777,t:1528144097471};\\\", \\\"{x:1431,y:776,t:1528144097486};\\\", \\\"{x:1432,y:775,t:1528144097602};\\\", \\\"{x:1433,y:774,t:1528144097674};\\\", \\\"{x:1434,y:773,t:1528144098003};\\\", \\\"{x:1436,y:772,t:1528144098034};\\\", \\\"{x:1436,y:771,t:1528144098042};\\\", \\\"{x:1437,y:770,t:1528144098054};\\\", \\\"{x:1438,y:770,t:1528144098074};\\\", \\\"{x:1439,y:769,t:1528144098088};\\\", \\\"{x:1439,y:768,t:1528144098106};\\\", \\\"{x:1440,y:768,t:1528144098563};\\\", \\\"{x:1441,y:767,t:1528144099227};\\\", \\\"{x:1443,y:765,t:1528144099239};\\\", \\\"{x:1445,y:764,t:1528144099255};\\\", \\\"{x:1447,y:762,t:1528144099272};\\\", \\\"{x:1448,y:762,t:1528144099290};\\\", \\\"{x:1449,y:762,t:1528144100771};\\\", \\\"{x:1451,y:757,t:1528144100779};\\\", \\\"{x:1457,y:746,t:1528144100789};\\\", \\\"{x:1464,y:736,t:1528144100805};\\\", \\\"{x:1468,y:729,t:1528144100823};\\\", \\\"{x:1473,y:722,t:1528144100839};\\\", \\\"{x:1475,y:719,t:1528144100855};\\\", \\\"{x:1478,y:715,t:1528144100873};\\\", \\\"{x:1479,y:713,t:1528144100889};\\\", \\\"{x:1480,y:713,t:1528144100921};\\\", \\\"{x:1481,y:711,t:1528144100937};\\\", \\\"{x:1482,y:711,t:1528144100946};\\\", \\\"{x:1483,y:709,t:1528144100956};\\\", \\\"{x:1486,y:705,t:1528144100973};\\\", \\\"{x:1487,y:704,t:1528144100990};\\\", \\\"{x:1488,y:703,t:1528144101006};\\\", \\\"{x:1488,y:702,t:1528144101083};\\\", \\\"{x:1488,y:701,t:1528144101099};\\\", \\\"{x:1487,y:701,t:1528144101491};\\\", \\\"{x:1486,y:700,t:1528144101507};\\\", \\\"{x:1483,y:698,t:1528144101524};\\\", \\\"{x:1481,y:697,t:1528144101540};\\\", \\\"{x:1479,y:697,t:1528144101558};\\\", \\\"{x:1477,y:696,t:1528144101659};\\\", \\\"{x:1441,y:696,t:1528144108626};\\\", \\\"{x:1319,y:689,t:1528144108635};\\\", \\\"{x:1154,y:660,t:1528144108645};\\\", \\\"{x:864,y:614,t:1528144108663};\\\", \\\"{x:662,y:579,t:1528144108679};\\\", \\\"{x:585,y:570,t:1528144108695};\\\", \\\"{x:580,y:570,t:1528144108712};\\\", \\\"{x:579,y:570,t:1528144108761};\\\", \\\"{x:578,y:570,t:1528144108825};\\\", \\\"{x:577,y:570,t:1528144108849};\\\", \\\"{x:575,y:570,t:1528144108863};\\\", \\\"{x:555,y:570,t:1528144108880};\\\", \\\"{x:526,y:571,t:1528144108896};\\\", \\\"{x:503,y:573,t:1528144108913};\\\", \\\"{x:496,y:575,t:1528144108930};\\\", \\\"{x:495,y:576,t:1528144108947};\\\", \\\"{x:494,y:576,t:1528144109058};\\\", \\\"{x:493,y:576,t:1528144109066};\\\", \\\"{x:491,y:576,t:1528144109081};\\\", \\\"{x:488,y:576,t:1528144109097};\\\", \\\"{x:484,y:576,t:1528144109113};\\\", \\\"{x:478,y:576,t:1528144109130};\\\", \\\"{x:475,y:575,t:1528144109147};\\\", \\\"{x:474,y:575,t:1528144109163};\\\", \\\"{x:473,y:573,t:1528144109180};\\\", \\\"{x:472,y:573,t:1528144109197};\\\", \\\"{x:469,y:572,t:1528144109214};\\\", \\\"{x:463,y:569,t:1528144109231};\\\", \\\"{x:458,y:567,t:1528144109246};\\\", \\\"{x:455,y:566,t:1528144109264};\\\", \\\"{x:453,y:565,t:1528144109281};\\\", \\\"{x:449,y:563,t:1528144109297};\\\", \\\"{x:447,y:562,t:1528144109314};\\\", \\\"{x:445,y:562,t:1528144109331};\\\", \\\"{x:442,y:561,t:1528144109347};\\\", \\\"{x:439,y:561,t:1528144109364};\\\", \\\"{x:436,y:560,t:1528144109381};\\\", \\\"{x:432,y:558,t:1528144109397};\\\", \\\"{x:428,y:558,t:1528144109414};\\\", \\\"{x:421,y:557,t:1528144109431};\\\", \\\"{x:415,y:556,t:1528144109447};\\\", \\\"{x:408,y:554,t:1528144109464};\\\", \\\"{x:405,y:552,t:1528144109481};\\\", \\\"{x:405,y:551,t:1528144109563};\\\", \\\"{x:447,y:572,t:1528144110556};\\\", \\\"{x:539,y:613,t:1528144110565};\\\", \\\"{x:728,y:683,t:1528144110581};\\\", \\\"{x:887,y:745,t:1528144110598};\\\", \\\"{x:994,y:784,t:1528144110615};\\\", \\\"{x:1017,y:791,t:1528144110631};\\\", \\\"{x:1021,y:792,t:1528144110648};\\\", \\\"{x:1022,y:793,t:1528144110665};\\\", \\\"{x:1024,y:795,t:1528144110753};\\\", \\\"{x:1028,y:798,t:1528144110765};\\\", \\\"{x:1047,y:811,t:1528144110782};\\\", \\\"{x:1093,y:846,t:1528144110798};\\\", \\\"{x:1173,y:894,t:1528144110815};\\\", \\\"{x:1249,y:950,t:1528144110832};\\\", \\\"{x:1315,y:993,t:1528144110848};\\\", \\\"{x:1336,y:1005,t:1528144110865};\\\", \\\"{x:1338,y:1005,t:1528144110882};\\\", \\\"{x:1339,y:1005,t:1528144110906};\\\", \\\"{x:1340,y:1005,t:1528144110938};\\\", \\\"{x:1345,y:1005,t:1528144110948};\\\", \\\"{x:1358,y:1005,t:1528144110966};\\\", \\\"{x:1380,y:1003,t:1528144110983};\\\", \\\"{x:1409,y:1001,t:1528144110998};\\\", \\\"{x:1450,y:994,t:1528144111015};\\\", \\\"{x:1479,y:988,t:1528144111032};\\\", \\\"{x:1499,y:982,t:1528144111048};\\\", \\\"{x:1506,y:978,t:1528144111067};\\\", \\\"{x:1507,y:977,t:1528144111082};\\\", \\\"{x:1508,y:976,t:1528144111219};\\\", \\\"{x:1506,y:975,t:1528144111233};\\\", \\\"{x:1498,y:973,t:1528144111250};\\\", \\\"{x:1492,y:973,t:1528144111266};\\\", \\\"{x:1490,y:973,t:1528144111282};\\\", \\\"{x:1489,y:973,t:1528144111300};\\\", \\\"{x:1488,y:973,t:1528144111316};\\\", \\\"{x:1487,y:973,t:1528144111332};\\\", \\\"{x:1486,y:973,t:1528144111361};\\\", \\\"{x:1485,y:973,t:1528144111392};\\\", \\\"{x:1484,y:972,t:1528144111449};\\\", \\\"{x:1483,y:972,t:1528144111505};\\\", \\\"{x:1482,y:972,t:1528144111546};\\\", \\\"{x:1481,y:972,t:1528144111554};\\\", \\\"{x:1480,y:972,t:1528144111570};\\\", \\\"{x:1479,y:972,t:1528144111582};\\\", \\\"{x:1478,y:972,t:1528144111599};\\\", \\\"{x:1478,y:971,t:1528144111616};\\\", \\\"{x:1477,y:971,t:1528144111632};\\\", \\\"{x:1477,y:970,t:1528144111657};\\\", \\\"{x:1476,y:970,t:1528144111665};\\\", \\\"{x:1475,y:969,t:1528144111683};\\\", \\\"{x:1474,y:969,t:1528144111700};\\\", \\\"{x:1472,y:968,t:1528144111717};\\\", \\\"{x:1469,y:967,t:1528144111732};\\\", \\\"{x:1468,y:966,t:1528144111770};\\\", \\\"{x:1466,y:966,t:1528144112234};\\\", \\\"{x:1465,y:966,t:1528144112266};\\\", \\\"{x:1464,y:966,t:1528144112306};\\\", \\\"{x:1463,y:966,t:1528144112346};\\\", \\\"{x:1463,y:967,t:1528144112354};\\\", \\\"{x:1461,y:967,t:1528144112386};\\\", \\\"{x:1459,y:968,t:1528144112400};\\\", \\\"{x:1456,y:968,t:1528144112416};\\\", \\\"{x:1451,y:971,t:1528144112433};\\\", \\\"{x:1450,y:972,t:1528144112450};\\\", \\\"{x:1448,y:973,t:1528144112467};\\\", \\\"{x:1446,y:974,t:1528144112484};\\\", \\\"{x:1445,y:974,t:1528144112506};\\\", \\\"{x:1445,y:976,t:1528144112516};\\\", \\\"{x:1443,y:978,t:1528144112533};\\\", \\\"{x:1441,y:981,t:1528144112550};\\\", \\\"{x:1440,y:983,t:1528144112567};\\\", \\\"{x:1440,y:984,t:1528144112594};\\\", \\\"{x:1439,y:984,t:1528144112602};\\\", \\\"{x:1440,y:981,t:1528144112786};\\\", \\\"{x:1440,y:977,t:1528144112801};\\\", \\\"{x:1442,y:973,t:1528144112817};\\\", \\\"{x:1445,y:968,t:1528144112834};\\\", \\\"{x:1446,y:966,t:1528144112850};\\\", \\\"{x:1447,y:965,t:1528144112866};\\\", \\\"{x:1449,y:965,t:1528144112939};\\\", \\\"{x:1450,y:965,t:1528144112962};\\\", \\\"{x:1453,y:965,t:1528144112970};\\\", \\\"{x:1455,y:966,t:1528144112986};\\\", \\\"{x:1458,y:968,t:1528144113001};\\\", \\\"{x:1459,y:968,t:1528144113018};\\\", \\\"{x:1460,y:969,t:1528144113034};\\\", \\\"{x:1461,y:969,t:1528144113051};\\\", \\\"{x:1463,y:969,t:1528144113291};\\\", \\\"{x:1464,y:968,t:1528144113301};\\\", \\\"{x:1465,y:967,t:1528144113318};\\\", \\\"{x:1467,y:963,t:1528144113334};\\\", \\\"{x:1468,y:960,t:1528144113351};\\\", \\\"{x:1468,y:957,t:1528144113368};\\\", \\\"{x:1468,y:955,t:1528144113384};\\\", \\\"{x:1468,y:954,t:1528144113401};\\\", \\\"{x:1468,y:953,t:1528144113418};\\\", \\\"{x:1468,y:950,t:1528144113746};\\\", \\\"{x:1468,y:939,t:1528144113754};\\\", \\\"{x:1463,y:929,t:1528144113768};\\\", \\\"{x:1459,y:924,t:1528144113785};\\\", \\\"{x:1456,y:920,t:1528144113801};\\\", \\\"{x:1455,y:918,t:1528144113818};\\\", \\\"{x:1454,y:917,t:1528144113858};\\\", \\\"{x:1454,y:916,t:1528144113947};\\\", \\\"{x:1454,y:915,t:1528144113954};\\\", \\\"{x:1454,y:914,t:1528144113968};\\\", \\\"{x:1453,y:907,t:1528144113984};\\\", \\\"{x:1453,y:902,t:1528144114002};\\\", \\\"{x:1452,y:899,t:1528144114018};\\\", \\\"{x:1452,y:898,t:1528144114034};\\\", \\\"{x:1452,y:897,t:1528144114051};\\\", \\\"{x:1452,y:895,t:1528144114067};\\\", \\\"{x:1452,y:893,t:1528144114085};\\\", \\\"{x:1452,y:891,t:1528144114102};\\\", \\\"{x:1451,y:889,t:1528144114118};\\\", \\\"{x:1450,y:887,t:1528144114135};\\\", \\\"{x:1450,y:885,t:1528144114154};\\\", \\\"{x:1450,y:884,t:1528144114168};\\\", \\\"{x:1450,y:882,t:1528144114185};\\\", \\\"{x:1450,y:878,t:1528144114202};\\\", \\\"{x:1450,y:876,t:1528144114218};\\\", \\\"{x:1450,y:872,t:1528144114235};\\\", \\\"{x:1450,y:869,t:1528144114252};\\\", \\\"{x:1449,y:865,t:1528144114267};\\\", \\\"{x:1449,y:862,t:1528144114285};\\\", \\\"{x:1449,y:860,t:1528144114302};\\\", \\\"{x:1449,y:857,t:1528144114318};\\\", \\\"{x:1449,y:855,t:1528144114334};\\\", \\\"{x:1449,y:852,t:1528144114352};\\\", \\\"{x:1449,y:848,t:1528144114368};\\\", \\\"{x:1449,y:846,t:1528144114385};\\\", \\\"{x:1449,y:841,t:1528144114402};\\\", \\\"{x:1449,y:838,t:1528144114418};\\\", \\\"{x:1449,y:836,t:1528144114434};\\\", \\\"{x:1450,y:833,t:1528144114451};\\\", \\\"{x:1450,y:831,t:1528144114468};\\\", \\\"{x:1450,y:828,t:1528144114485};\\\", \\\"{x:1450,y:825,t:1528144114501};\\\", \\\"{x:1450,y:821,t:1528144114519};\\\", \\\"{x:1450,y:819,t:1528144114535};\\\", \\\"{x:1450,y:814,t:1528144114551};\\\", \\\"{x:1450,y:811,t:1528144114569};\\\", \\\"{x:1450,y:806,t:1528144114585};\\\", \\\"{x:1450,y:801,t:1528144114601};\\\", \\\"{x:1450,y:796,t:1528144114618};\\\", \\\"{x:1450,y:792,t:1528144114635};\\\", \\\"{x:1450,y:787,t:1528144114652};\\\", \\\"{x:1450,y:781,t:1528144114669};\\\", \\\"{x:1450,y:776,t:1528144114684};\\\", \\\"{x:1450,y:771,t:1528144114701};\\\", \\\"{x:1451,y:766,t:1528144114719};\\\", \\\"{x:1451,y:762,t:1528144114735};\\\", \\\"{x:1451,y:759,t:1528144114751};\\\", \\\"{x:1452,y:757,t:1528144114769};\\\", \\\"{x:1452,y:754,t:1528144114785};\\\", \\\"{x:1453,y:752,t:1528144114802};\\\", \\\"{x:1454,y:750,t:1528144114818};\\\", \\\"{x:1454,y:749,t:1528144114835};\\\", \\\"{x:1454,y:747,t:1528144114852};\\\", \\\"{x:1455,y:745,t:1528144114869};\\\", \\\"{x:1457,y:741,t:1528144114886};\\\", \\\"{x:1457,y:738,t:1528144114902};\\\", \\\"{x:1458,y:737,t:1528144114930};\\\", \\\"{x:1458,y:736,t:1528144114962};\\\", \\\"{x:1458,y:735,t:1528144115202};\\\", \\\"{x:1458,y:734,t:1528144115234};\\\", \\\"{x:1458,y:733,t:1528144115258};\\\", \\\"{x:1458,y:740,t:1528144115490};\\\", \\\"{x:1458,y:759,t:1528144115502};\\\", \\\"{x:1456,y:779,t:1528144115519};\\\", \\\"{x:1456,y:784,t:1528144115536};\\\", \\\"{x:1455,y:788,t:1528144115553};\\\", \\\"{x:1455,y:789,t:1528144115579};\\\", \\\"{x:1455,y:787,t:1528144115770};\\\", \\\"{x:1455,y:780,t:1528144115785};\\\", \\\"{x:1455,y:776,t:1528144115802};\\\", \\\"{x:1455,y:772,t:1528144115819};\\\", \\\"{x:1455,y:769,t:1528144115836};\\\", \\\"{x:1454,y:768,t:1528144115853};\\\", \\\"{x:1453,y:767,t:1528144116362};\\\", \\\"{x:1454,y:761,t:1528144117678};\\\", \\\"{x:1457,y:756,t:1528144117691};\\\", \\\"{x:1460,y:750,t:1528144117708};\\\", \\\"{x:1462,y:745,t:1528144117725};\\\", \\\"{x:1466,y:736,t:1528144117742};\\\", \\\"{x:1468,y:735,t:1528144117758};\\\", \\\"{x:1469,y:732,t:1528144117775};\\\", \\\"{x:1469,y:731,t:1528144117792};\\\", \\\"{x:1470,y:729,t:1528144117808};\\\", \\\"{x:1471,y:728,t:1528144117825};\\\", \\\"{x:1471,y:727,t:1528144117842};\\\", \\\"{x:1472,y:725,t:1528144117858};\\\", \\\"{x:1472,y:724,t:1528144117874};\\\", \\\"{x:1472,y:723,t:1528144117891};\\\", \\\"{x:1473,y:722,t:1528144117926};\\\", \\\"{x:1473,y:720,t:1528144117957};\\\", \\\"{x:1474,y:718,t:1528144117974};\\\", \\\"{x:1475,y:715,t:1528144117992};\\\", \\\"{x:1475,y:714,t:1528144118007};\\\", \\\"{x:1476,y:711,t:1528144118024};\\\", \\\"{x:1477,y:708,t:1528144118041};\\\", \\\"{x:1478,y:705,t:1528144118057};\\\", \\\"{x:1478,y:703,t:1528144118074};\\\", \\\"{x:1478,y:700,t:1528144118092};\\\", \\\"{x:1478,y:699,t:1528144118107};\\\", \\\"{x:1479,y:698,t:1528144118124};\\\", \\\"{x:1479,y:697,t:1528144118182};\\\", \\\"{x:1479,y:696,t:1528144118319};\\\", \\\"{x:1479,y:695,t:1528144118343};\\\", \\\"{x:1479,y:693,t:1528144118359};\\\", \\\"{x:1479,y:691,t:1528144118375};\\\", \\\"{x:1479,y:690,t:1528144118392};\\\", \\\"{x:1480,y:689,t:1528144118414};\\\", \\\"{x:1481,y:689,t:1528144119166};\\\", \\\"{x:1481,y:688,t:1528144122461};\\\", \\\"{x:1481,y:683,t:1528144122477};\\\", \\\"{x:1482,y:677,t:1528144122494};\\\", \\\"{x:1482,y:674,t:1528144122511};\\\", \\\"{x:1483,y:671,t:1528144122527};\\\", \\\"{x:1483,y:668,t:1528144122545};\\\", \\\"{x:1483,y:667,t:1528144122562};\\\", \\\"{x:1484,y:666,t:1528144122578};\\\", \\\"{x:1484,y:665,t:1528144122595};\\\", \\\"{x:1485,y:663,t:1528144122638};\\\", \\\"{x:1485,y:662,t:1528144122694};\\\", \\\"{x:1485,y:661,t:1528144122718};\\\", \\\"{x:1485,y:660,t:1528144122728};\\\", \\\"{x:1485,y:658,t:1528144122745};\\\", \\\"{x:1485,y:655,t:1528144122762};\\\", \\\"{x:1485,y:653,t:1528144122782};\\\", \\\"{x:1486,y:653,t:1528144122795};\\\", \\\"{x:1486,y:652,t:1528144122812};\\\", \\\"{x:1486,y:651,t:1528144122830};\\\", \\\"{x:1486,y:650,t:1528144122846};\\\", \\\"{x:1486,y:649,t:1528144122862};\\\", \\\"{x:1486,y:647,t:1528144122886};\\\", \\\"{x:1486,y:645,t:1528144122926};\\\", \\\"{x:1486,y:644,t:1528144122941};\\\", \\\"{x:1486,y:643,t:1528144122950};\\\", \\\"{x:1486,y:642,t:1528144122966};\\\", \\\"{x:1486,y:641,t:1528144122979};\\\", \\\"{x:1486,y:639,t:1528144122995};\\\", \\\"{x:1486,y:637,t:1528144123012};\\\", \\\"{x:1486,y:635,t:1528144123029};\\\", \\\"{x:1486,y:634,t:1528144123046};\\\", \\\"{x:1486,y:630,t:1528144123062};\\\", \\\"{x:1486,y:626,t:1528144123079};\\\", \\\"{x:1486,y:623,t:1528144123095};\\\", \\\"{x:1486,y:618,t:1528144123112};\\\", \\\"{x:1486,y:614,t:1528144123129};\\\", \\\"{x:1485,y:612,t:1528144123145};\\\", \\\"{x:1485,y:610,t:1528144123162};\\\", \\\"{x:1485,y:609,t:1528144123179};\\\", \\\"{x:1484,y:606,t:1528144123195};\\\", \\\"{x:1484,y:605,t:1528144123212};\\\", \\\"{x:1484,y:603,t:1528144123229};\\\", \\\"{x:1483,y:600,t:1528144123245};\\\", \\\"{x:1483,y:594,t:1528144123262};\\\", \\\"{x:1481,y:588,t:1528144123279};\\\", \\\"{x:1481,y:585,t:1528144123295};\\\", \\\"{x:1480,y:581,t:1528144123312};\\\", \\\"{x:1480,y:575,t:1528144123329};\\\", \\\"{x:1479,y:572,t:1528144123345};\\\", \\\"{x:1477,y:568,t:1528144123362};\\\", \\\"{x:1477,y:565,t:1528144123379};\\\", \\\"{x:1477,y:563,t:1528144123395};\\\", \\\"{x:1477,y:560,t:1528144123413};\\\", \\\"{x:1476,y:560,t:1528144123429};\\\", \\\"{x:1476,y:558,t:1528144123446};\\\", \\\"{x:1476,y:557,t:1528144123486};\\\", \\\"{x:1476,y:555,t:1528144123678};\\\", \\\"{x:1476,y:554,t:1528144123717};\\\", \\\"{x:1476,y:552,t:1528144123733};\\\", \\\"{x:1476,y:551,t:1528144123748};\\\", \\\"{x:1476,y:550,t:1528144123797};\\\", \\\"{x:1476,y:549,t:1528144123811};\\\", \\\"{x:1477,y:548,t:1528144123829};\\\", \\\"{x:1477,y:547,t:1528144123862};\\\", \\\"{x:1478,y:545,t:1528144123885};\\\", \\\"{x:1478,y:543,t:1528144123934};\\\", \\\"{x:1478,y:542,t:1528144123949};\\\", \\\"{x:1478,y:541,t:1528144123966};\\\", \\\"{x:1478,y:540,t:1528144123982};\\\", \\\"{x:1478,y:539,t:1528144124118};\\\", \\\"{x:1478,y:537,t:1528144124150};\\\", \\\"{x:1478,y:536,t:1528144124173};\\\", \\\"{x:1478,y:534,t:1528144124189};\\\", \\\"{x:1478,y:533,t:1528144124206};\\\", \\\"{x:1478,y:531,t:1528144124230};\\\", \\\"{x:1478,y:530,t:1528144124269};\\\", \\\"{x:1478,y:528,t:1528144124438};\\\", \\\"{x:1478,y:527,t:1528144124462};\\\", \\\"{x:1478,y:524,t:1528144124480};\\\", \\\"{x:1478,y:521,t:1528144124496};\\\", \\\"{x:1478,y:520,t:1528144124517};\\\", \\\"{x:1478,y:519,t:1528144124530};\\\", \\\"{x:1478,y:517,t:1528144124546};\\\", \\\"{x:1478,y:515,t:1528144124564};\\\", \\\"{x:1478,y:509,t:1528144124583};\\\", \\\"{x:1478,y:508,t:1528144124596};\\\", \\\"{x:1478,y:504,t:1528144124612};\\\", \\\"{x:1478,y:499,t:1528144124628};\\\", \\\"{x:1478,y:498,t:1528144124646};\\\", \\\"{x:1478,y:497,t:1528144124663};\\\", \\\"{x:1478,y:495,t:1528144124679};\\\", \\\"{x:1477,y:493,t:1528144124701};\\\", \\\"{x:1477,y:492,t:1528144124713};\\\", \\\"{x:1477,y:489,t:1528144124730};\\\", \\\"{x:1476,y:486,t:1528144124745};\\\", \\\"{x:1476,y:484,t:1528144124762};\\\", \\\"{x:1476,y:481,t:1528144124779};\\\", \\\"{x:1476,y:478,t:1528144124795};\\\", \\\"{x:1475,y:475,t:1528144124813};\\\", \\\"{x:1475,y:471,t:1528144124830};\\\", \\\"{x:1474,y:469,t:1528144124845};\\\", \\\"{x:1474,y:468,t:1528144124863};\\\", \\\"{x:1474,y:466,t:1528144124880};\\\", \\\"{x:1473,y:463,t:1528144124897};\\\", \\\"{x:1473,y:461,t:1528144124913};\\\", \\\"{x:1472,y:459,t:1528144124930};\\\", \\\"{x:1472,y:458,t:1528144124947};\\\", \\\"{x:1472,y:456,t:1528144124963};\\\", \\\"{x:1472,y:453,t:1528144124981};\\\", \\\"{x:1472,y:450,t:1528144124997};\\\", \\\"{x:1472,y:449,t:1528144125013};\\\", \\\"{x:1472,y:444,t:1528144125029};\\\", \\\"{x:1472,y:443,t:1528144125047};\\\", \\\"{x:1472,y:442,t:1528144125063};\\\", \\\"{x:1472,y:439,t:1528144125080};\\\", \\\"{x:1472,y:438,t:1528144125097};\\\", \\\"{x:1472,y:437,t:1528144125113};\\\", \\\"{x:1472,y:436,t:1528144125133};\\\", \\\"{x:1472,y:435,t:1528144125150};\\\", \\\"{x:1472,y:434,t:1528144125164};\\\", \\\"{x:1472,y:433,t:1528144125182};\\\", \\\"{x:1472,y:432,t:1528144125197};\\\", \\\"{x:1472,y:431,t:1528144125213};\\\", \\\"{x:1472,y:430,t:1528144125230};\\\", \\\"{x:1472,y:429,t:1528144125286};\\\", \\\"{x:1472,y:427,t:1528144125297};\\\", \\\"{x:1474,y:427,t:1528144125313};\\\", \\\"{x:1474,y:425,t:1528144125330};\\\", \\\"{x:1475,y:424,t:1528144125358};\\\", \\\"{x:1476,y:424,t:1528144125798};\\\", \\\"{x:1477,y:424,t:1528144125838};\\\", \\\"{x:1477,y:425,t:1528144126118};\\\", \\\"{x:1477,y:426,t:1528144126278};\\\", \\\"{x:1478,y:427,t:1528144126358};\\\", \\\"{x:1476,y:435,t:1528144126646};\\\", \\\"{x:1456,y:453,t:1528144126654};\\\", \\\"{x:1412,y:478,t:1528144126664};\\\", \\\"{x:1270,y:533,t:1528144126681};\\\", \\\"{x:1064,y:570,t:1528144126698};\\\", \\\"{x:829,y:584,t:1528144126715};\\\", \\\"{x:640,y:595,t:1528144126731};\\\", \\\"{x:480,y:606,t:1528144126749};\\\", \\\"{x:372,y:606,t:1528144126764};\\\", \\\"{x:253,y:606,t:1528144126781};\\\", \\\"{x:214,y:606,t:1528144126798};\\\", \\\"{x:195,y:606,t:1528144126814};\\\", \\\"{x:192,y:606,t:1528144126832};\\\", \\\"{x:191,y:606,t:1528144126848};\\\", \\\"{x:190,y:607,t:1528144127020};\\\", \\\"{x:192,y:609,t:1528144127032};\\\", \\\"{x:196,y:612,t:1528144127047};\\\", \\\"{x:197,y:613,t:1528144127066};\\\", \\\"{x:199,y:613,t:1528144127092};\\\", \\\"{x:200,y:613,t:1528144127100};\\\", \\\"{x:201,y:614,t:1528144127157};\\\", \\\"{x:202,y:614,t:1528144127165};\\\", \\\"{x:204,y:617,t:1528144127183};\\\", \\\"{x:205,y:619,t:1528144127200};\\\", \\\"{x:205,y:620,t:1528144127215};\\\", \\\"{x:223,y:620,t:1528144127493};\\\", \\\"{x:240,y:620,t:1528144127502};\\\", \\\"{x:254,y:620,t:1528144127515};\\\", \\\"{x:279,y:618,t:1528144127538};\\\", \\\"{x:301,y:616,t:1528144127548};\\\", \\\"{x:311,y:614,t:1528144127565};\\\", \\\"{x:317,y:613,t:1528144127582};\\\", \\\"{x:330,y:613,t:1528144127598};\\\", \\\"{x:353,y:613,t:1528144127615};\\\", \\\"{x:386,y:613,t:1528144127632};\\\", \\\"{x:437,y:613,t:1528144127648};\\\", \\\"{x:492,y:613,t:1528144127665};\\\", \\\"{x:521,y:613,t:1528144127682};\\\", \\\"{x:532,y:611,t:1528144127699};\\\", \\\"{x:534,y:611,t:1528144127715};\\\", \\\"{x:536,y:610,t:1528144127732};\\\", \\\"{x:540,y:609,t:1528144127748};\\\", \\\"{x:551,y:603,t:1528144127766};\\\", \\\"{x:569,y:593,t:1528144127782};\\\", \\\"{x:596,y:580,t:1528144127799};\\\", \\\"{x:613,y:569,t:1528144127816};\\\", \\\"{x:619,y:565,t:1528144127832};\\\", \\\"{x:623,y:562,t:1528144127849};\\\", \\\"{x:626,y:560,t:1528144127866};\\\", \\\"{x:630,y:558,t:1528144127883};\\\", \\\"{x:639,y:557,t:1528144127899};\\\", \\\"{x:654,y:555,t:1528144127916};\\\", \\\"{x:685,y:555,t:1528144127933};\\\", \\\"{x:696,y:555,t:1528144127949};\\\", \\\"{x:698,y:555,t:1528144127966};\\\", \\\"{x:699,y:555,t:1528144127988};\\\", \\\"{x:701,y:555,t:1528144128000};\\\", \\\"{x:704,y:555,t:1528144128016};\\\", \\\"{x:710,y:555,t:1528144128032};\\\", \\\"{x:718,y:555,t:1528144128050};\\\", \\\"{x:725,y:555,t:1528144128069};\\\", \\\"{x:730,y:555,t:1528144128082};\\\", \\\"{x:736,y:555,t:1528144128100};\\\", \\\"{x:745,y:555,t:1528144128115};\\\", \\\"{x:759,y:556,t:1528144128133};\\\", \\\"{x:766,y:559,t:1528144128149};\\\", \\\"{x:775,y:561,t:1528144128166};\\\", \\\"{x:787,y:566,t:1528144128183};\\\", \\\"{x:794,y:568,t:1528144128199};\\\", \\\"{x:797,y:568,t:1528144128216};\\\", \\\"{x:799,y:568,t:1528144128233};\\\", \\\"{x:801,y:568,t:1528144128250};\\\", \\\"{x:803,y:568,t:1528144128266};\\\", \\\"{x:804,y:568,t:1528144128282};\\\", \\\"{x:806,y:568,t:1528144128300};\\\", \\\"{x:807,y:568,t:1528144128316};\\\", \\\"{x:813,y:568,t:1528144128333};\\\", \\\"{x:817,y:568,t:1528144128350};\\\", \\\"{x:818,y:568,t:1528144128366};\\\", \\\"{x:820,y:568,t:1528144128382};\\\", \\\"{x:821,y:568,t:1528144128422};\\\", \\\"{x:823,y:568,t:1528144128437};\\\", \\\"{x:824,y:568,t:1528144128515};\\\", \\\"{x:824,y:568,t:1528144128646};\\\", \\\"{x:825,y:567,t:1528144128982};\\\", \\\"{x:827,y:565,t:1528144128990};\\\", \\\"{x:828,y:564,t:1528144129001};\\\", \\\"{x:829,y:563,t:1528144129029};\\\", \\\"{x:830,y:562,t:1528144129068};\\\", \\\"{x:831,y:561,t:1528144129101};\\\", \\\"{x:832,y:560,t:1528144129133};\\\", \\\"{x:834,y:560,t:1528144129381};\\\", \\\"{x:834,y:569,t:1528144129389};\\\", \\\"{x:818,y:586,t:1528144129401};\\\", \\\"{x:805,y:599,t:1528144129416};\\\", \\\"{x:785,y:620,t:1528144129434};\\\", \\\"{x:767,y:637,t:1528144129450};\\\", \\\"{x:757,y:646,t:1528144129467};\\\", \\\"{x:752,y:651,t:1528144129484};\\\", \\\"{x:745,y:655,t:1528144129501};\\\", \\\"{x:735,y:663,t:1528144129517};\\\", \\\"{x:719,y:670,t:1528144129533};\\\", \\\"{x:699,y:682,t:1528144129550};\\\", \\\"{x:679,y:695,t:1528144129567};\\\", \\\"{x:661,y:704,t:1528144129584};\\\", \\\"{x:653,y:708,t:1528144129601};\\\", \\\"{x:647,y:711,t:1528144129616};\\\", \\\"{x:643,y:712,t:1528144129634};\\\", \\\"{x:638,y:715,t:1528144129650};\\\", \\\"{x:629,y:715,t:1528144129667};\\\", \\\"{x:609,y:715,t:1528144129683};\\\", \\\"{x:572,y:713,t:1528144129701};\\\", \\\"{x:546,y:713,t:1528144129717};\\\", \\\"{x:510,y:713,t:1528144129734};\\\", \\\"{x:493,y:718,t:1528144129750};\\\", \\\"{x:491,y:720,t:1528144129767};\\\", \\\"{x:487,y:726,t:1528144129784};\\\", \\\"{x:485,y:730,t:1528144129801};\\\", \\\"{x:484,y:732,t:1528144129818};\\\", \\\"{x:484,y:733,t:1528144129834};\\\", \\\"{x:484,y:734,t:1528144129852};\\\", \\\"{x:484,y:736,t:1528144129893};\\\", \\\"{x:484,y:738,t:1528144129901};\\\", \\\"{x:484,y:745,t:1528144129917};\\\", \\\"{x:484,y:747,t:1528144129934};\\\", \\\"{x:484,y:750,t:1528144129951};\\\", \\\"{x:485,y:751,t:1528144130006};\\\" ] }, { \\\"rt\\\": 47558, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 1262552, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"VVH1B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Follow the x axis, then look at the diagonal to determine the duration.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 9314, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 1272874, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"VVH1B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 16659, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 1290547, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"VVH1B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 6539, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 1298527, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"VVH1B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"VVH1B\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}}]}]}]},{\"nodeType\":3,\"id\":2303,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2304,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2305},{\"nodeType\":3,\"id\":2306,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2307,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2308,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2309,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2310,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 28, dom: 75, initialDom: 96",
  "javascriptErrors": []
}