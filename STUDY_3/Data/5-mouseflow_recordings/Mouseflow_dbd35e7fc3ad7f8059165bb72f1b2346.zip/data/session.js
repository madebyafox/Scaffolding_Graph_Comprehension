var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "dbd35e7fc3ad7f8059165bb72f1b2346",
  "created": "2018-05-29T10:11:32.0477898-07:00",
  "lastActivity": "2018-05-29T10:11:39.9988083-07:00",
  "pageViews": [
    {
      "id": "05293276cdf106a682c0be924ca1dc8f401e011c",
      "startTime": "2018-05-29T10:11:32.2671112-07:00",
      "endTime": "2018-05-29T10:11:39.9988083-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/12",
      "visitTime": 7978,
      "engagementTime": 7978,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 7978,
  "engagementTime": 7978,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=FR69M",
    "CONDITION=114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "39a1c5db28569056a6166b49e93d2e5d",
  "gdpr": false
}