var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "8a1c999958caf6f8a2267ee25093ddf2",
  "created": "2018-05-21T12:13:57.5213497-07:00",
  "lastActivity": "2018-05-21T12:14:21.5075872-07:00",
  "pageViews": [
    {
      "id": "05215757b41a1dedfd6e53d207628a15fe03e51d",
      "startTime": "2018-05-21T12:13:57.5213497-07:00",
      "endTime": "2018-05-21T12:14:21.5075872-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 24019,
      "engagementTime": 23919,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 24019,
  "engagementTime": 23919,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.33",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=WKBNA",
    "CONDITION=111",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "be72f8a1ac0c303b973869c6ff91ef8b",
  "gdpr": false
}