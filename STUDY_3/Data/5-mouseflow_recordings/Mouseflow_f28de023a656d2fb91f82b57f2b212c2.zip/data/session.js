var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "f28de023a656d2fb91f82b57f2b212c2",
  "created": "2018-05-22T14:17:32.8710337-07:00",
  "lastActivity": "2018-05-22T14:18:49.7900337-07:00",
  "pageViews": [
    {
      "id": "0522335662fbbedc9e49c474a591f330ea94f278",
      "startTime": "2018-05-22T14:17:32.8710337-07:00",
      "endTime": "2018-05-22T14:18:49.7900337-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 76919,
      "engagementTime": 76744,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 76919,
  "engagementTime": 76744,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=JSK2P",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "e987b0651cf92aeb57c3b0cf26feff48",
  "gdpr": false
}