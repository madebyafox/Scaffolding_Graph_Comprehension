var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "ba7f76aba0e6226d995b63c86cb01e38",
  "created": "2018-05-29T16:12:09.4746247-07:00",
  "lastActivity": "2018-05-29T16:14:23.7074307-07:00",
  "pageViews": [
    {
      "id": "052909178b803586b1e43bd20ed764f2d9f649b3",
      "startTime": "2018-05-29T16:12:09.4746247-07:00",
      "endTime": "2018-05-29T16:14:23.7074307-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 134505,
      "engagementTime": 122240,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 134505,
  "engagementTime": 122240,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.48",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=SQ6AK",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "03dd64d7ddc348ed55b8d062d5a89a09",
  "gdpr": false
}