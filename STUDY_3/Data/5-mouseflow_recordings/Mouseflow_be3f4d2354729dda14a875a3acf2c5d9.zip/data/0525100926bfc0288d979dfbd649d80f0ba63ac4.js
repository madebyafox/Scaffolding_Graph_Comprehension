var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0525100926bfc0288d979dfbd649d80f0ba63ac4"] = {
  "startTime": "2018-05-25T18:17:10.4196288Z",
  "websitePageUrl": "/16",
  "visitTime": 76940,
  "engagementTime": 74411,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "be3f4d2354729dda14a875a3acf2c5d9",
    "created": "2018-05-25T18:17:10.3163757+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=K8DJ0",
      "CONDITION=114"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "d8cceb8e8abded7efed976b6911090c9",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/be3f4d2354729dda14a875a3acf2c5d9/play"
  },
  "events": [
    {
      "t": 0,
      "e": 0,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 292,
      "e": 292,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 2801,
      "e": 2801,
      "ty": 2,
      "x": 507,
      "y": 731
    },
    {
      "t": 2901,
      "e": 2901,
      "ty": 2,
      "x": 516,
      "y": 681
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 2,
      "x": 535,
      "y": 612
    },
    {
      "t": 3002,
      "e": 3002,
      "ty": 41,
      "x": 49225,
      "y": 61119,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 3003,
      "e": 3003,
      "ty": 6,
      "x": 540,
      "y": 594,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3101,
      "e": 3101,
      "ty": 2,
      "x": 553,
      "y": 544
    },
    {
      "t": 3174,
      "e": 3174,
      "ty": 3,
      "x": 554,
      "y": 541,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3174,
      "e": 3174,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3201,
      "e": 3201,
      "ty": 2,
      "x": 554,
      "y": 541
    },
    {
      "t": 3250,
      "e": 3250,
      "ty": 41,
      "x": 51360,
      "y": 14778,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3315,
      "e": 3315,
      "ty": 4,
      "x": 51360,
      "y": 14778,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3316,
      "e": 3316,
      "ty": 5,
      "x": 554,
      "y": 541,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 2,
      "x": 608,
      "y": 558
    },
    {
      "t": 3502,
      "e": 3502,
      "ty": 41,
      "x": 57430,
      "y": 28532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3519,
      "e": 3519,
      "ty": 7,
      "x": 691,
      "y": 583,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3601,
      "e": 3601,
      "ty": 2,
      "x": 1082,
      "y": 667
    },
    {
      "t": 3701,
      "e": 3701,
      "ty": 2,
      "x": 1295,
      "y": 709
    },
    {
      "t": 3752,
      "e": 3752,
      "ty": 41,
      "x": 36080,
      "y": 40896,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3801,
      "e": 3801,
      "ty": 2,
      "x": 1302,
      "y": 709
    },
    {
      "t": 3901,
      "e": 3901,
      "ty": 2,
      "x": 1311,
      "y": 706
    },
    {
      "t": 4000,
      "e": 4000,
      "ty": 2,
      "x": 1323,
      "y": 694
    },
    {
      "t": 4002,
      "e": 4002,
      "ty": 41,
      "x": 37842,
      "y": 39822,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4100,
      "e": 4100,
      "ty": 2,
      "x": 1337,
      "y": 674
    },
    {
      "t": 4201,
      "e": 4201,
      "ty": 2,
      "x": 1342,
      "y": 670
    },
    {
      "t": 4251,
      "e": 4251,
      "ty": 41,
      "x": 39251,
      "y": 38103,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4301,
      "e": 4301,
      "ty": 2,
      "x": 1350,
      "y": 691
    },
    {
      "t": 4401,
      "e": 4401,
      "ty": 2,
      "x": 1356,
      "y": 734
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 2,
      "x": 1318,
      "y": 771
    },
    {
      "t": 4502,
      "e": 4502,
      "ty": 41,
      "x": 37489,
      "y": 45337,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4601,
      "e": 4601,
      "ty": 2,
      "x": 1201,
      "y": 815
    },
    {
      "t": 4701,
      "e": 4701,
      "ty": 2,
      "x": 1163,
      "y": 837
    },
    {
      "t": 4751,
      "e": 4751,
      "ty": 41,
      "x": 26285,
      "y": 50780,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4800,
      "e": 4800,
      "ty": 2,
      "x": 1155,
      "y": 858
    },
    {
      "t": 4901,
      "e": 4901,
      "ty": 2,
      "x": 1148,
      "y": 883
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 2,
      "x": 1148,
      "y": 900
    },
    {
      "t": 5002,
      "e": 5002,
      "ty": 41,
      "x": 25510,
      "y": 54576,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5101,
      "e": 5101,
      "ty": 2,
      "x": 1100,
      "y": 961
    },
    {
      "t": 5201,
      "e": 5201,
      "ty": 2,
      "x": 1099,
      "y": 963
    },
    {
      "t": 5252,
      "e": 5252,
      "ty": 41,
      "x": 17409,
      "y": 0,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > path"
    },
    {
      "t": 5301,
      "e": 5301,
      "ty": 2,
      "x": 1099,
      "y": 964
    },
    {
      "t": 5401,
      "e": 5401,
      "ty": 2,
      "x": 1119,
      "y": 981
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 2,
      "x": 1136,
      "y": 988
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 41,
      "x": 24664,
      "y": 60879,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5601,
      "e": 5601,
      "ty": 2,
      "x": 1138,
      "y": 988
    },
    {
      "t": 5701,
      "e": 5701,
      "ty": 2,
      "x": 1145,
      "y": 983
    },
    {
      "t": 5751,
      "e": 5751,
      "ty": 41,
      "x": 24410,
      "y": 28927,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 5801,
      "e": 5801,
      "ty": 2,
      "x": 1149,
      "y": 970
    },
    {
      "t": 5901,
      "e": 5901,
      "ty": 2,
      "x": 1151,
      "y": 955
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 2,
      "x": 1153,
      "y": 935
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 41,
      "x": 25862,
      "y": 57083,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6101,
      "e": 6101,
      "ty": 2,
      "x": 1157,
      "y": 914
    },
    {
      "t": 6201,
      "e": 6201,
      "ty": 2,
      "x": 1159,
      "y": 899
    },
    {
      "t": 6252,
      "e": 6252,
      "ty": 41,
      "x": 26356,
      "y": 53932,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6301,
      "e": 6301,
      "ty": 2,
      "x": 1163,
      "y": 880
    },
    {
      "t": 6401,
      "e": 6401,
      "ty": 2,
      "x": 1174,
      "y": 860
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 41,
      "x": 38476,
      "y": 50064,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 2,
      "x": 1332,
      "y": 837
    },
    {
      "t": 6601,
      "e": 6601,
      "ty": 2,
      "x": 1447,
      "y": 837
    },
    {
      "t": 6701,
      "e": 6701,
      "ty": 2,
      "x": 1452,
      "y": 837
    },
    {
      "t": 6751,
      "e": 6751,
      "ty": 41,
      "x": 46932,
      "y": 50064,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 14186,
      "e": 11751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 14186,
      "e": 11751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14264,
      "e": 11829,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14264,
      "e": 11829,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14295,
      "e": 11860,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I "
    },
    {
      "t": 14402,
      "e": 11967,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I "
    },
    {
      "t": 14407,
      "e": 11972,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I "
    },
    {
      "t": 14487,
      "e": 12052,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 14487,
      "e": 12052,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14601,
      "e": 12166,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I S"
    },
    {
      "t": 14624,
      "e": 12189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I S"
    },
    {
      "t": 14824,
      "e": 12389,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14824,
      "e": 12389,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14951,
      "e": 12516,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I SE"
    },
    {
      "t": 15112,
      "e": 12677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 15113,
      "e": 12678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15255,
      "e": 12820,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 15344,
      "e": 12909,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15345,
      "e": 12910,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15471,
      "e": 13036,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15479,
      "e": 13044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 15479,
      "e": 13044,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15592,
      "e": 13157,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||W"
    },
    {
      "t": 15664,
      "e": 13229,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 15665,
      "e": 13230,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15751,
      "e": 13316,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||H"
    },
    {
      "t": 15759,
      "e": 13324,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 15760,
      "e": 13325,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15920,
      "e": 13485,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 15928,
      "e": 13493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 15929,
      "e": 13494,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16048,
      "e": 13613,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||C"
    },
    {
      "t": 16055,
      "e": 13620,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 16055,
      "e": 13620,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16203,
      "e": 13768,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I SEE WHICH"
    },
    {
      "t": 16208,
      "e": 13773,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||H"
    },
    {
      "t": 16223,
      "e": 13788,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16223,
      "e": 13788,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16402,
      "e": 13967,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I SEE WHICH "
    },
    {
      "t": 16423,
      "e": 13988,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16464,
      "e": 14029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 16465,
      "e": 14030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16603,
      "e": 14168,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I SEE WHICH P"
    },
    {
      "t": 16704,
      "e": 14269,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 16705,
      "e": 14270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16840,
      "e": 14405,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||PO"
    },
    {
      "t": 16880,
      "e": 14445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17048,
      "e": 14613,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 17048,
      "e": 14613,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17206,
      "e": 14771,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I SEE WHICH POI"
    },
    {
      "t": 17235,
      "e": 14800,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 17236,
      "e": 14801,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17283,
      "e": 14848,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||IN"
    },
    {
      "t": 17380,
      "e": 14945,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17387,
      "e": 14952,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17388,
      "e": 14953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17499,
      "e": 15064,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 17676,
      "e": 15241,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 17676,
      "e": 15241,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17779,
      "e": 15344,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S"
    },
    {
      "t": 17835,
      "e": 15400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17835,
      "e": 15400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17948,
      "e": 15513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18004,
      "e": 15569,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 18005,
      "e": 15570,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18131,
      "e": 15696,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||H"
    },
    {
      "t": 18164,
      "e": 15729,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18164,
      "e": 15729,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18243,
      "e": 15808,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 18284,
      "e": 15849,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18284,
      "e": 15849,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18372,
      "e": 15937,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 18468,
      "e": 16033,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 18469,
      "e": 16034,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18595,
      "e": 16160,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||V"
    },
    {
      "t": 18691,
      "e": 16256,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 18691,
      "e": 16256,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18747,
      "e": 16312,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 18964,
      "e": 16529,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19042,
      "e": 16607,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I SEE WHICH POINTS HAAV"
    },
    {
      "t": 19156,
      "e": 16721,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19236,
      "e": 16801,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I SEE WHICH POINTS HAA"
    },
    {
      "t": 19355,
      "e": 16920,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19467,
      "e": 17032,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I SEE WHICH POINTS HA"
    },
    {
      "t": 20004,
      "e": 17569,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20107,
      "e": 17672,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 20108,
      "e": 17673,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20163,
      "e": 17728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||V"
    },
    {
      "t": 20300,
      "e": 17865,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20300,
      "e": 17865,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20406,
      "e": 17971,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I SEE WHICH POINTS HAVE"
    },
    {
      "t": 20411,
      "e": 17976,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 20531,
      "e": 18096,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20532,
      "e": 18097,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20684,
      "e": 18249,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20916,
      "e": 18481,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 20917,
      "e": 18482,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21027,
      "e": 18592,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 22164,
      "e": 19729,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 22164,
      "e": 19729,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22227,
      "e": 19792,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 22420,
      "e": 19985,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22420,
      "e": 19985,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22507,
      "e": 20072,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22644,
      "e": 20209,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 22645,
      "e": 20210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22730,
      "e": 20295,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 22925,
      "e": 20490,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 22925,
      "e": 20490,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23035,
      "e": 20600,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 23115,
      "e": 20680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23116,
      "e": 20681,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23195,
      "e": 20760,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23316,
      "e": 20881,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 23316,
      "e": 20881,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23395,
      "e": 20960,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 23395,
      "e": 20960,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23467,
      "e": 21032,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||AS"
    },
    {
      "t": 23532,
      "e": 21097,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23635,
      "e": 21200,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23637,
      "e": 21202,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23747,
      "e": 21312,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23843,
      "e": 21408,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23844,
      "e": 21409,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23964,
      "e": 21529,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 24059,
      "e": 21624,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 24061,
      "e": 21626,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24163,
      "e": 21728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||H"
    },
    {
      "t": 24203,
      "e": 21768,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 24203,
      "e": 21768,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24307,
      "e": 21872,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 24339,
      "e": 21904,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 24339,
      "e": 21904,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24458,
      "e": 22023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 24491,
      "e": 22056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 24491,
      "e": 22056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24579,
      "e": 22144,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||R"
    },
    {
      "t": 24627,
      "e": 22192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24629,
      "e": 22194,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24740,
      "e": 22305,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26667,
      "e": 24232,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 26669,
      "e": 24234,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26739,
      "e": 24304,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||X"
    },
    {
      "t": 26867,
      "e": 24432,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26868,
      "e": 24433,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27006,
      "e": 24571,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I SEE WHICH POINTS HAVE 12 PM AS THEIR X "
    },
    {
      "t": 27027,
      "e": 24592,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27436,
      "e": 25001,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 27436,
      "e": 25001,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27563,
      "e": 25128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||C"
    },
    {
      "t": 27851,
      "e": 25416,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 27853,
      "e": 25418,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27931,
      "e": 25496,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||O"
    },
    {
      "t": 28099,
      "e": 25664,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 28100,
      "e": 25665,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28206,
      "e": 25771,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I SEE WHICH POINTS HAVE 12 PM AS THEIR X COO"
    },
    {
      "t": 28218,
      "e": 25783,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||O"
    },
    {
      "t": 28331,
      "e": 25896,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 28333,
      "e": 25898,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28418,
      "e": 25983,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||R"
    },
    {
      "t": 28604,
      "e": 26169,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 28604,
      "e": 26169,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28763,
      "e": 26328,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||D"
    },
    {
      "t": 28827,
      "e": 26392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 28828,
      "e": 26393,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28995,
      "e": 26560,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 29011,
      "e": 26576,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 29011,
      "e": 26576,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29188,
      "e": 26753,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||N"
    },
    {
      "t": 29219,
      "e": 26784,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 29221,
      "e": 26786,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29339,
      "e": 26904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 29748,
      "e": 27313,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 29749,
      "e": 27314,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29915,
      "e": 27480,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 29963,
      "e": 27528,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 29964,
      "e": 27529,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30005,
      "e": 27570,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30091,
      "e": 27656,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 30211,
      "e": 27776,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "13"
    },
    {
      "t": 30211,
      "e": 27776,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30314,
      "e": 27879,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||\n"
    },
    {
      "t": 31505,
      "e": 29070,
      "ty": 2,
      "x": 1445,
      "y": 837
    },
    {
      "t": 31505,
      "e": 29070,
      "ty": 41,
      "x": 46439,
      "y": 50064,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 31605,
      "e": 29170,
      "ty": 2,
      "x": 1248,
      "y": 883
    },
    {
      "t": 31705,
      "e": 29270,
      "ty": 2,
      "x": 886,
      "y": 908
    },
    {
      "t": 31755,
      "e": 29320,
      "ty": 41,
      "x": 5779,
      "y": 55364,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 31804,
      "e": 29369,
      "ty": 2,
      "x": 834,
      "y": 882
    },
    {
      "t": 31904,
      "e": 29469,
      "ty": 2,
      "x": 733,
      "y": 803
    },
    {
      "t": 32005,
      "e": 29570,
      "ty": 2,
      "x": 670,
      "y": 773
    },
    {
      "t": 32005,
      "e": 29570,
      "ty": 41,
      "x": 64400,
      "y": 42378,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 32105,
      "e": 29670,
      "ty": 2,
      "x": 529,
      "y": 748
    },
    {
      "t": 32205,
      "e": 29770,
      "ty": 2,
      "x": 479,
      "y": 734
    },
    {
      "t": 32254,
      "e": 29819,
      "ty": 41,
      "x": 59171,
      "y": 61121,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 32305,
      "e": 29870,
      "ty": 2,
      "x": 430,
      "y": 703
    },
    {
      "t": 32364,
      "e": 29929,
      "ty": 6,
      "x": 417,
      "y": 687,
      "ta": "#strategyButton"
    },
    {
      "t": 32405,
      "e": 29970,
      "ty": 2,
      "x": 414,
      "y": 680
    },
    {
      "t": 32504,
      "e": 30069,
      "ty": 2,
      "x": 411,
      "y": 678
    },
    {
      "t": 32505,
      "e": 30070,
      "ty": 41,
      "x": 39542,
      "y": 44844,
      "ta": "#strategyButton"
    },
    {
      "t": 32567,
      "e": 30132,
      "ty": 3,
      "x": 410,
      "y": 677,
      "ta": "#strategyButton"
    },
    {
      "t": 32569,
      "e": 30134,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I SEE WHICH POINTS HAVE 12 PM AS THEIR X COORDINATE\n"
    },
    {
      "t": 32570,
      "e": 30135,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32570,
      "e": 30135,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 32604,
      "e": 30169,
      "ty": 2,
      "x": 410,
      "y": 677
    },
    {
      "t": 32671,
      "e": 30236,
      "ty": 4,
      "x": 38996,
      "y": 42916,
      "ta": "#strategyButton"
    },
    {
      "t": 32682,
      "e": 30247,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 32684,
      "e": 30249,
      "ty": 5,
      "x": 410,
      "y": 677,
      "ta": "#strategyButton"
    },
    {
      "t": 32689,
      "e": 30254,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 32755,
      "e": 30320,
      "ty": 41,
      "x": 13843,
      "y": 37060,
      "ta": "html > body"
    },
    {
      "t": 32905,
      "e": 30470,
      "ty": 2,
      "x": 411,
      "y": 687
    },
    {
      "t": 33005,
      "e": 30570,
      "ty": 2,
      "x": 450,
      "y": 777
    },
    {
      "t": 33005,
      "e": 30570,
      "ty": 41,
      "x": 15221,
      "y": 42600,
      "ta": "html > body"
    },
    {
      "t": 33105,
      "e": 30670,
      "ty": 2,
      "x": 1329,
      "y": 1065
    },
    {
      "t": 33205,
      "e": 30770,
      "ty": 2,
      "x": 1672,
      "y": 1089
    },
    {
      "t": 33255,
      "e": 30820,
      "ty": 41,
      "x": 57442,
      "y": 59607,
      "ta": "html > body"
    },
    {
      "t": 33305,
      "e": 30870,
      "ty": 2,
      "x": 1676,
      "y": 1084
    },
    {
      "t": 33689,
      "e": 31254,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 34005,
      "e": 31570,
      "ty": 2,
      "x": 1414,
      "y": 826
    },
    {
      "t": 34005,
      "e": 31570,
      "ty": 41,
      "x": 48419,
      "y": 45314,
      "ta": "html > body"
    },
    {
      "t": 34104,
      "e": 31669,
      "ty": 2,
      "x": 1293,
      "y": 725
    },
    {
      "t": 34254,
      "e": 31819,
      "ty": 41,
      "x": 44252,
      "y": 39719,
      "ta": "html > body"
    },
    {
      "t": 34304,
      "e": 31869,
      "ty": 2,
      "x": 1276,
      "y": 716
    },
    {
      "t": 34404,
      "e": 31969,
      "ty": 2,
      "x": 1206,
      "y": 676
    },
    {
      "t": 34504,
      "e": 32069,
      "ty": 2,
      "x": 1086,
      "y": 621
    },
    {
      "t": 34505,
      "e": 32070,
      "ty": 41,
      "x": 60127,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 34581,
      "e": 32146,
      "ty": 6,
      "x": 991,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34604,
      "e": 32169,
      "ty": 2,
      "x": 978,
      "y": 567
    },
    {
      "t": 34705,
      "e": 32270,
      "ty": 2,
      "x": 966,
      "y": 562
    },
    {
      "t": 34755,
      "e": 32320,
      "ty": 41,
      "x": 33957,
      "y": 24965,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34784,
      "e": 32349,
      "ty": 3,
      "x": 965,
      "y": 562,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34786,
      "e": 32351,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34805,
      "e": 32370,
      "ty": 2,
      "x": 965,
      "y": 562
    },
    {
      "t": 34879,
      "e": 32444,
      "ty": 4,
      "x": 33957,
      "y": 24965,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34879,
      "e": 32444,
      "ty": 5,
      "x": 965,
      "y": 562,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35332,
      "e": 32897,
      "ty": 7,
      "x": 939,
      "y": 575,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35404,
      "e": 32969,
      "ty": 2,
      "x": 937,
      "y": 576
    },
    {
      "t": 35505,
      "e": 33070,
      "ty": 41,
      "x": 27901,
      "y": 60602,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 35851,
      "e": 33416,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "97"
    },
    {
      "t": 35852,
      "e": 33417,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36005,
      "e": 33570,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 36011,
      "e": 33576,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 36115,
      "e": 33680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "105"
    },
    {
      "t": 36116,
      "e": 33681,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36203,
      "e": 33768,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 36805,
      "e": 34370,
      "ty": 2,
      "x": 922,
      "y": 576
    },
    {
      "t": 36904,
      "e": 34469,
      "ty": 2,
      "x": 906,
      "y": 584
    },
    {
      "t": 37004,
      "e": 34569,
      "ty": 2,
      "x": 898,
      "y": 596
    },
    {
      "t": 37005,
      "e": 34570,
      "ty": 41,
      "x": 19465,
      "y": 9160,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 37105,
      "e": 34670,
      "ty": 2,
      "x": 895,
      "y": 613
    },
    {
      "t": 37205,
      "e": 34770,
      "ty": 2,
      "x": 894,
      "y": 620
    },
    {
      "t": 37255,
      "e": 34820,
      "ty": 41,
      "x": 18600,
      "y": 56172,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 37305,
      "e": 34870,
      "ty": 2,
      "x": 894,
      "y": 634
    },
    {
      "t": 37368,
      "e": 34933,
      "ty": 6,
      "x": 894,
      "y": 648,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37405,
      "e": 34970,
      "ty": 2,
      "x": 894,
      "y": 649
    },
    {
      "t": 37505,
      "e": 35070,
      "ty": 2,
      "x": 894,
      "y": 650
    },
    {
      "t": 37505,
      "e": 35070,
      "ty": 41,
      "x": 18600,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37520,
      "e": 35085,
      "ty": 3,
      "x": 894,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37521,
      "e": 35086,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 37521,
      "e": 35086,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 37522,
      "e": 35087,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37663,
      "e": 35228,
      "ty": 4,
      "x": 18600,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37663,
      "e": 35228,
      "ty": 5,
      "x": 894,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39380,
      "e": 36945,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 39380,
      "e": 36945,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39506,
      "e": 37071,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 39554,
      "e": 37119,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 39555,
      "e": 37120,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39691,
      "e": 37256,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 39851,
      "e": 37416,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 39852,
      "e": 37417,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39922,
      "e": 37487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 40005,
      "e": 37570,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40971,
      "e": 38536,
      "ty": 7,
      "x": 911,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41003,
      "e": 38568,
      "ty": 2,
      "x": 914,
      "y": 672
    },
    {
      "t": 41004,
      "e": 38569,
      "ty": 41,
      "x": 22926,
      "y": 62716,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 41224,
      "e": 38789,
      "ty": 6,
      "x": 915,
      "y": 676,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41254,
      "e": 38819,
      "ty": 41,
      "x": 12925,
      "y": 33760,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41305,
      "e": 38870,
      "ty": 2,
      "x": 925,
      "y": 703
    },
    {
      "t": 41415,
      "e": 38980,
      "ty": 3,
      "x": 925,
      "y": 703,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41417,
      "e": 38982,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 41417,
      "e": 38982,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41417,
      "e": 38982,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41505,
      "e": 39070,
      "ty": 41,
      "x": 14986,
      "y": 53619,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41535,
      "e": 39100,
      "ty": 4,
      "x": 14986,
      "y": 53619,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41535,
      "e": 39100,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41536,
      "e": 39101,
      "ty": 5,
      "x": 925,
      "y": 703,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41536,
      "e": 39101,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 42560,
      "e": 40125,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 43254,
      "e": 40819,
      "ty": 41,
      "x": 26855,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 43304,
      "e": 40869,
      "ty": 2,
      "x": 934,
      "y": 679
    },
    {
      "t": 43404,
      "e": 40969,
      "ty": 2,
      "x": 938,
      "y": 655
    },
    {
      "t": 43504,
      "e": 41069,
      "ty": 2,
      "x": 941,
      "y": 586
    },
    {
      "t": 43504,
      "e": 41069,
      "ty": 41,
      "x": 28378,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 43604,
      "e": 41169,
      "ty": 2,
      "x": 935,
      "y": 514
    },
    {
      "t": 43704,
      "e": 41269,
      "ty": 2,
      "x": 878,
      "y": 306
    },
    {
      "t": 43754,
      "e": 41319,
      "ty": 41,
      "x": 26620,
      "y": 221,
      "ta": "html"
    },
    {
      "t": 43804,
      "e": 41369,
      "ty": 2,
      "x": 678,
      "y": 0
    },
    {
      "t": 43904,
      "e": 41469,
      "ty": 2,
      "x": 664,
      "y": 64
    },
    {
      "t": 44004,
      "e": 41569,
      "ty": 2,
      "x": 792,
      "y": 391
    },
    {
      "t": 44004,
      "e": 41569,
      "ty": 41,
      "x": 26999,
      "y": 21217,
      "ta": "html > body"
    },
    {
      "t": 44104,
      "e": 41669,
      "ty": 2,
      "x": 799,
      "y": 367
    },
    {
      "t": 44204,
      "e": 41769,
      "ty": 2,
      "x": 799,
      "y": 300
    },
    {
      "t": 44254,
      "e": 41819,
      "ty": 41,
      "x": 27343,
      "y": 15455,
      "ta": "html > body"
    },
    {
      "t": 44304,
      "e": 41869,
      "ty": 2,
      "x": 808,
      "y": 271
    },
    {
      "t": 44404,
      "e": 41969,
      "ty": 2,
      "x": 816,
      "y": 264
    },
    {
      "t": 44504,
      "e": 42069,
      "ty": 2,
      "x": 821,
      "y": 261
    },
    {
      "t": 44504,
      "e": 42069,
      "ty": 41,
      "x": 0,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 44604,
      "e": 42169,
      "ty": 2,
      "x": 829,
      "y": 253
    },
    {
      "t": 44754,
      "e": 42319,
      "ty": 41,
      "x": 2273,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 44791,
      "e": 42356,
      "ty": 6,
      "x": 832,
      "y": 244,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 44804,
      "e": 42369,
      "ty": 2,
      "x": 832,
      "y": 244
    },
    {
      "t": 44904,
      "e": 42469,
      "ty": 2,
      "x": 833,
      "y": 242
    },
    {
      "t": 45000,
      "e": 42565,
      "ty": 3,
      "x": 833,
      "y": 242,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 45001,
      "e": 42566,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 45004,
      "e": 42569,
      "ty": 41,
      "x": 33161,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 45127,
      "e": 42692,
      "ty": 4,
      "x": 33161,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 45128,
      "e": 42693,
      "ty": 5,
      "x": 833,
      "y": 242,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 45129,
      "e": 42694,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 45905,
      "e": 43470,
      "ty": 2,
      "x": 831,
      "y": 243
    },
    {
      "t": 45911,
      "e": 43476,
      "ty": 7,
      "x": 831,
      "y": 245,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 46005,
      "e": 43570,
      "ty": 2,
      "x": 831,
      "y": 252
    },
    {
      "t": 46005,
      "e": 43570,
      "ty": 41,
      "x": 2273,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 46042,
      "e": 43607,
      "ty": 6,
      "x": 831,
      "y": 261,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 46104,
      "e": 43669,
      "ty": 2,
      "x": 831,
      "y": 267
    },
    {
      "t": 46174,
      "e": 43739,
      "ty": 7,
      "x": 831,
      "y": 276,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 46204,
      "e": 43769,
      "ty": 2,
      "x": 831,
      "y": 278
    },
    {
      "t": 46254,
      "e": 43819,
      "ty": 41,
      "x": 2510,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 46292,
      "e": 43857,
      "ty": 6,
      "x": 833,
      "y": 289,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 46304,
      "e": 43869,
      "ty": 2,
      "x": 833,
      "y": 289
    },
    {
      "t": 46357,
      "e": 43922,
      "ty": 7,
      "x": 836,
      "y": 304,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 46404,
      "e": 43969,
      "ty": 2,
      "x": 836,
      "y": 314
    },
    {
      "t": 46440,
      "e": 43970,
      "ty": 6,
      "x": 836,
      "y": 317,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 46504,
      "e": 44034,
      "ty": 2,
      "x": 836,
      "y": 317
    },
    {
      "t": 46505,
      "e": 44035,
      "ty": 41,
      "x": 48284,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 46904,
      "e": 44434,
      "ty": 3,
      "x": 836,
      "y": 317,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 46905,
      "e": 44435,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 46906,
      "e": 44436,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 47015,
      "e": 44545,
      "ty": 4,
      "x": 48284,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 47016,
      "e": 44546,
      "ty": 5,
      "x": 836,
      "y": 317,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 47017,
      "e": 44547,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf",
      "v": "Other"
    },
    {
      "t": 47304,
      "e": 44834,
      "ty": 2,
      "x": 836,
      "y": 325
    },
    {
      "t": 47308,
      "e": 44838,
      "ty": 7,
      "x": 836,
      "y": 331,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 47404,
      "e": 44934,
      "ty": 2,
      "x": 835,
      "y": 347
    },
    {
      "t": 47504,
      "e": 45034,
      "ty": 2,
      "x": 832,
      "y": 363
    },
    {
      "t": 47505,
      "e": 45035,
      "ty": 41,
      "x": 2510,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 47604,
      "e": 45134,
      "ty": 2,
      "x": 828,
      "y": 380
    },
    {
      "t": 47704,
      "e": 45234,
      "ty": 2,
      "x": 828,
      "y": 385
    },
    {
      "t": 47754,
      "e": 45284,
      "ty": 41,
      "x": 1323,
      "y": 10290,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 47804,
      "e": 45334,
      "ty": 2,
      "x": 826,
      "y": 401
    },
    {
      "t": 47904,
      "e": 45434,
      "ty": 2,
      "x": 825,
      "y": 406
    },
    {
      "t": 48004,
      "e": 45534,
      "ty": 2,
      "x": 824,
      "y": 406
    },
    {
      "t": 48005,
      "e": 45535,
      "ty": 41,
      "x": 3017,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 48104,
      "e": 45634,
      "ty": 2,
      "x": 824,
      "y": 409
    },
    {
      "t": 48204,
      "e": 45734,
      "ty": 2,
      "x": 824,
      "y": 417
    },
    {
      "t": 48255,
      "e": 45785,
      "ty": 41,
      "x": 3017,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 48305,
      "e": 45835,
      "ty": 2,
      "x": 824,
      "y": 420
    },
    {
      "t": 48344,
      "e": 45874,
      "ty": 3,
      "x": 824,
      "y": 420,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 48345,
      "e": 45875,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 48455,
      "e": 45985,
      "ty": 4,
      "x": 3017,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 48455,
      "e": 45985,
      "ty": 5,
      "x": 824,
      "y": 420,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 48456,
      "e": 45986,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 48458,
      "e": 45988,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 49204,
      "e": 46734,
      "ty": 2,
      "x": 822,
      "y": 430
    },
    {
      "t": 49254,
      "e": 46784,
      "ty": 41,
      "x": 27791,
      "y": 24485,
      "ta": "html > body"
    },
    {
      "t": 49304,
      "e": 46834,
      "ty": 2,
      "x": 815,
      "y": 460
    },
    {
      "t": 49404,
      "e": 46934,
      "ty": 2,
      "x": 813,
      "y": 478
    },
    {
      "t": 49504,
      "e": 47034,
      "ty": 2,
      "x": 812,
      "y": 535
    },
    {
      "t": 49504,
      "e": 47034,
      "ty": 41,
      "x": 27687,
      "y": 29194,
      "ta": "html > body"
    },
    {
      "t": 49604,
      "e": 47134,
      "ty": 2,
      "x": 810,
      "y": 596
    },
    {
      "t": 49704,
      "e": 47234,
      "ty": 2,
      "x": 816,
      "y": 624
    },
    {
      "t": 49755,
      "e": 47285,
      "ty": 41,
      "x": 27825,
      "y": 34180,
      "ta": "html > body"
    },
    {
      "t": 49805,
      "e": 47335,
      "ty": 2,
      "x": 816,
      "y": 628
    },
    {
      "t": 49905,
      "e": 47435,
      "ty": 2,
      "x": 817,
      "y": 631
    },
    {
      "t": 50004,
      "e": 47534,
      "ty": 41,
      "x": 27860,
      "y": 34512,
      "ta": "html > body"
    },
    {
      "t": 50104,
      "e": 47634,
      "ty": 2,
      "x": 822,
      "y": 631
    },
    {
      "t": 50254,
      "e": 47784,
      "ty": 41,
      "x": 137,
      "y": 37448,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 50305,
      "e": 47835,
      "ty": 2,
      "x": 823,
      "y": 633
    },
    {
      "t": 50404,
      "e": 47934,
      "ty": 2,
      "x": 824,
      "y": 679
    },
    {
      "t": 50504,
      "e": 48034,
      "ty": 41,
      "x": 692,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 50864,
      "e": 48394,
      "ty": 6,
      "x": 826,
      "y": 680,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 50904,
      "e": 48434,
      "ty": 2,
      "x": 830,
      "y": 679
    },
    {
      "t": 51004,
      "e": 48534,
      "ty": 41,
      "x": 18037,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 51072,
      "e": 48602,
      "ty": 3,
      "x": 830,
      "y": 679,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 51072,
      "e": 48602,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 51073,
      "e": 48603,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 51214,
      "e": 48744,
      "ty": 4,
      "x": 18037,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 51215,
      "e": 48745,
      "ty": 5,
      "x": 830,
      "y": 679,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 51215,
      "e": 48745,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf",
      "v": "Math or Computer Sciences"
    },
    {
      "t": 52247,
      "e": 49777,
      "ty": 7,
      "x": 830,
      "y": 681,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 52255,
      "e": 49785,
      "ty": 41,
      "x": 2303,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 52304,
      "e": 49834,
      "ty": 2,
      "x": 833,
      "y": 694
    },
    {
      "t": 52313,
      "e": 49834,
      "ty": 6,
      "x": 834,
      "y": 698,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 52362,
      "e": 49883,
      "ty": 7,
      "x": 836,
      "y": 709,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 52404,
      "e": 49925,
      "ty": 2,
      "x": 838,
      "y": 723
    },
    {
      "t": 52504,
      "e": 50025,
      "ty": 2,
      "x": 852,
      "y": 769
    },
    {
      "t": 52504,
      "e": 50025,
      "ty": 41,
      "x": 7256,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 52605,
      "e": 50126,
      "ty": 2,
      "x": 856,
      "y": 780
    },
    {
      "t": 52704,
      "e": 50225,
      "ty": 2,
      "x": 860,
      "y": 804
    },
    {
      "t": 52755,
      "e": 50276,
      "ty": 41,
      "x": 20409,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 52804,
      "e": 50325,
      "ty": 2,
      "x": 850,
      "y": 835
    },
    {
      "t": 52905,
      "e": 50426,
      "ty": 2,
      "x": 848,
      "y": 841
    },
    {
      "t": 53005,
      "e": 50526,
      "ty": 41,
      "x": 18725,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 53205,
      "e": 50726,
      "ty": 2,
      "x": 851,
      "y": 839
    },
    {
      "t": 53254,
      "e": 50775,
      "ty": 41,
      "x": 20839,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 53304,
      "e": 50825,
      "ty": 2,
      "x": 851,
      "y": 831
    },
    {
      "t": 53405,
      "e": 50926,
      "ty": 2,
      "x": 851,
      "y": 814
    },
    {
      "t": 53504,
      "e": 51025,
      "ty": 2,
      "x": 851,
      "y": 800
    },
    {
      "t": 53505,
      "e": 51026,
      "ty": 41,
      "x": 7019,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 53604,
      "e": 51125,
      "ty": 2,
      "x": 851,
      "y": 772
    },
    {
      "t": 53704,
      "e": 51225,
      "ty": 2,
      "x": 851,
      "y": 740
    },
    {
      "t": 53754,
      "e": 51275,
      "ty": 41,
      "x": 7423,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 53804,
      "e": 51325,
      "ty": 2,
      "x": 851,
      "y": 729
    },
    {
      "t": 54005,
      "e": 51526,
      "ty": 2,
      "x": 854,
      "y": 747
    },
    {
      "t": 54005,
      "e": 51526,
      "ty": 41,
      "x": 7731,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 54105,
      "e": 51626,
      "ty": 2,
      "x": 860,
      "y": 779
    },
    {
      "t": 54204,
      "e": 51725,
      "ty": 2,
      "x": 860,
      "y": 809
    },
    {
      "t": 54254,
      "e": 51775,
      "ty": 41,
      "x": 21589,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 54304,
      "e": 51825,
      "ty": 2,
      "x": 857,
      "y": 829
    },
    {
      "t": 54405,
      "e": 51926,
      "ty": 2,
      "x": 855,
      "y": 842
    },
    {
      "t": 54504,
      "e": 52025,
      "ty": 2,
      "x": 853,
      "y": 860
    },
    {
      "t": 54505,
      "e": 52026,
      "ty": 41,
      "x": 7494,
      "y": 52233,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 54604,
      "e": 52125,
      "ty": 2,
      "x": 851,
      "y": 878
    },
    {
      "t": 54705,
      "e": 52226,
      "ty": 2,
      "x": 852,
      "y": 904
    },
    {
      "t": 54755,
      "e": 52276,
      "ty": 41,
      "x": 8206,
      "y": 18148,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 54804,
      "e": 52325,
      "ty": 2,
      "x": 856,
      "y": 912
    },
    {
      "t": 55004,
      "e": 52525,
      "ty": 2,
      "x": 857,
      "y": 912
    },
    {
      "t": 55005,
      "e": 52526,
      "ty": 41,
      "x": 8443,
      "y": 18652,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 55105,
      "e": 52626,
      "ty": 2,
      "x": 846,
      "y": 939
    },
    {
      "t": 55204,
      "e": 52725,
      "ty": 2,
      "x": 837,
      "y": 946
    },
    {
      "t": 55255,
      "e": 52776,
      "ty": 41,
      "x": 3697,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 55404,
      "e": 52925,
      "ty": 2,
      "x": 833,
      "y": 946
    },
    {
      "t": 55505,
      "e": 53026,
      "ty": 2,
      "x": 832,
      "y": 946
    },
    {
      "t": 55505,
      "e": 53026,
      "ty": 41,
      "x": 2510,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 55705,
      "e": 53226,
      "ty": 2,
      "x": 832,
      "y": 942
    },
    {
      "t": 55733,
      "e": 53254,
      "ty": 6,
      "x": 832,
      "y": 940,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 55755,
      "e": 53276,
      "ty": 41,
      "x": 28120,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 55804,
      "e": 53325,
      "ty": 2,
      "x": 831,
      "y": 939
    },
    {
      "t": 55888,
      "e": 53409,
      "ty": 3,
      "x": 831,
      "y": 939,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 55889,
      "e": 53410,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 55889,
      "e": 53410,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 55975,
      "e": 53496,
      "ty": 4,
      "x": 23079,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 55975,
      "e": 53496,
      "ty": 5,
      "x": 831,
      "y": 939,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 55976,
      "e": 53497,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 56005,
      "e": 53526,
      "ty": 41,
      "x": 23079,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 56105,
      "e": 53626,
      "ty": 2,
      "x": 833,
      "y": 939
    },
    {
      "t": 56115,
      "e": 53636,
      "ty": 7,
      "x": 833,
      "y": 941,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 56204,
      "e": 53725,
      "ty": 2,
      "x": 844,
      "y": 968
    },
    {
      "t": 56255,
      "e": 53726,
      "ty": 41,
      "x": 7256,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 56304,
      "e": 53775,
      "ty": 2,
      "x": 856,
      "y": 985
    },
    {
      "t": 56404,
      "e": 53875,
      "ty": 2,
      "x": 858,
      "y": 990
    },
    {
      "t": 56500,
      "e": 53971,
      "ty": 6,
      "x": 867,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 56504,
      "e": 53975,
      "ty": 2,
      "x": 867,
      "y": 1005
    },
    {
      "t": 56504,
      "e": 53975,
      "ty": 41,
      "x": 19367,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 56604,
      "e": 54075,
      "ty": 2,
      "x": 872,
      "y": 1012
    },
    {
      "t": 56703,
      "e": 54174,
      "ty": 3,
      "x": 872,
      "y": 1012,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 56704,
      "e": 54175,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 56705,
      "e": 54176,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 56754,
      "e": 54225,
      "ty": 41,
      "x": 21944,
      "y": 13901,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 56799,
      "e": 54270,
      "ty": 4,
      "x": 21944,
      "y": 13901,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 56799,
      "e": 54270,
      "ty": 5,
      "x": 872,
      "y": 1012,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 56801,
      "e": 54272,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 56801,
      "e": 54272,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 56802,
      "e": 54273,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 57205,
      "e": 54676,
      "ty": 2,
      "x": 872,
      "y": 1011
    },
    {
      "t": 57255,
      "e": 54726,
      "ty": 41,
      "x": 29754,
      "y": 54843,
      "ta": "html > body"
    },
    {
      "t": 57305,
      "e": 54776,
      "ty": 2,
      "x": 870,
      "y": 975
    },
    {
      "t": 57404,
      "e": 54875,
      "ty": 2,
      "x": 865,
      "y": 831
    },
    {
      "t": 57504,
      "e": 54975,
      "ty": 2,
      "x": 871,
      "y": 721
    },
    {
      "t": 57505,
      "e": 54976,
      "ty": 41,
      "x": 29719,
      "y": 39498,
      "ta": "html > body"
    },
    {
      "t": 57605,
      "e": 55076,
      "ty": 2,
      "x": 876,
      "y": 682
    },
    {
      "t": 57705,
      "e": 55176,
      "ty": 2,
      "x": 877,
      "y": 679
    },
    {
      "t": 57755,
      "e": 55226,
      "ty": 41,
      "x": 29926,
      "y": 37171,
      "ta": "html > body"
    },
    {
      "t": 57897,
      "e": 55368,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 57905,
      "e": 55376,
      "ty": 2,
      "x": 882,
      "y": 654
    },
    {
      "t": 58005,
      "e": 55476,
      "ty": 2,
      "x": 889,
      "y": 606
    },
    {
      "t": 58005,
      "e": 55476,
      "ty": 41,
      "x": 29299,
      "y": 48182,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 58104,
      "e": 55575,
      "ty": 2,
      "x": 891,
      "y": 594
    },
    {
      "t": 58255,
      "e": 55726,
      "ty": 41,
      "x": 29348,
      "y": 39990,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 58311,
      "e": 55782,
      "ty": 2,
      "x": 888,
      "y": 580
    },
    {
      "t": 58404,
      "e": 55875,
      "ty": 2,
      "x": 889,
      "y": 573
    },
    {
      "t": 58505,
      "e": 55976,
      "ty": 2,
      "x": 890,
      "y": 569
    },
    {
      "t": 58505,
      "e": 55976,
      "ty": 41,
      "x": 29348,
      "y": 33748,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 58605,
      "e": 56076,
      "ty": 2,
      "x": 891,
      "y": 590
    },
    {
      "t": 58705,
      "e": 56176,
      "ty": 2,
      "x": 863,
      "y": 881
    },
    {
      "t": 58755,
      "e": 56226,
      "ty": 41,
      "x": 28216,
      "y": 54061,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 58805,
      "e": 56276,
      "ty": 2,
      "x": 867,
      "y": 908
    },
    {
      "t": 58905,
      "e": 56376,
      "ty": 2,
      "x": 869,
      "y": 910
    },
    {
      "t": 59005,
      "e": 56476,
      "ty": 2,
      "x": 878,
      "y": 917
    },
    {
      "t": 59005,
      "e": 56476,
      "ty": 41,
      "x": 28757,
      "y": 54754,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 59105,
      "e": 56576,
      "ty": 2,
      "x": 894,
      "y": 924
    },
    {
      "t": 59205,
      "e": 56676,
      "ty": 2,
      "x": 919,
      "y": 933
    },
    {
      "t": 59255,
      "e": 56726,
      "ty": 41,
      "x": 32004,
      "y": 56554,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 59304,
      "e": 56775,
      "ty": 2,
      "x": 974,
      "y": 961
    },
    {
      "t": 59404,
      "e": 56875,
      "ty": 2,
      "x": 1002,
      "y": 982
    },
    {
      "t": 59505,
      "e": 56976,
      "ty": 2,
      "x": 1002,
      "y": 983
    },
    {
      "t": 59505,
      "e": 56976,
      "ty": 41,
      "x": 34858,
      "y": 59324,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 60504,
      "e": 57975,
      "ty": 2,
      "x": 999,
      "y": 968
    },
    {
      "t": 60505,
      "e": 57976,
      "ty": 41,
      "x": 34710,
      "y": 58285,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 60604,
      "e": 58075,
      "ty": 2,
      "x": 943,
      "y": 870
    },
    {
      "t": 60705,
      "e": 58176,
      "ty": 2,
      "x": 844,
      "y": 756
    },
    {
      "t": 60755,
      "e": 58226,
      "ty": 41,
      "x": 24428,
      "y": 37921,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 60805,
      "e": 58276,
      "ty": 2,
      "x": 772,
      "y": 614
    },
    {
      "t": 60905,
      "e": 58376,
      "ty": 2,
      "x": 809,
      "y": 547
    },
    {
      "t": 61005,
      "e": 58476,
      "ty": 2,
      "x": 881,
      "y": 437
    },
    {
      "t": 61005,
      "e": 58476,
      "ty": 41,
      "x": 28905,
      "y": 44092,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 61105,
      "e": 58576,
      "ty": 2,
      "x": 1025,
      "y": 287
    },
    {
      "t": 61204,
      "e": 58675,
      "ty": 2,
      "x": 1390,
      "y": 213
    },
    {
      "t": 61255,
      "e": 58726,
      "ty": 41,
      "x": 54684,
      "y": 6003,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 61305,
      "e": 58776,
      "ty": 2,
      "x": 1422,
      "y": 236
    },
    {
      "t": 61405,
      "e": 58876,
      "ty": 2,
      "x": 1319,
      "y": 407
    },
    {
      "t": 61505,
      "e": 58976,
      "ty": 2,
      "x": 1234,
      "y": 432
    },
    {
      "t": 61505,
      "e": 58976,
      "ty": 41,
      "x": 46272,
      "y": 40191,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 61605,
      "e": 59076,
      "ty": 2,
      "x": 1118,
      "y": 429
    },
    {
      "t": 61705,
      "e": 59176,
      "ty": 2,
      "x": 1055,
      "y": 429
    },
    {
      "t": 61755,
      "e": 59226,
      "ty": 41,
      "x": 37416,
      "y": 37850,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 61805,
      "e": 59276,
      "ty": 2,
      "x": 981,
      "y": 453
    },
    {
      "t": 61905,
      "e": 59376,
      "ty": 2,
      "x": 427,
      "y": 518
    },
    {
      "t": 62004,
      "e": 59475,
      "ty": 2,
      "x": 376,
      "y": 518
    },
    {
      "t": 62005,
      "e": 59476,
      "ty": 41,
      "x": 4061,
      "y": 13854,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 62104,
      "e": 59575,
      "ty": 2,
      "x": 337,
      "y": 507
    },
    {
      "t": 62205,
      "e": 59676,
      "ty": 2,
      "x": 299,
      "y": 476
    },
    {
      "t": 62255,
      "e": 59726,
      "ty": 41,
      "x": 174,
      "y": 16038,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 62305,
      "e": 59776,
      "ty": 2,
      "x": 308,
      "y": 461
    },
    {
      "t": 62405,
      "e": 59876,
      "ty": 2,
      "x": 339,
      "y": 445
    },
    {
      "t": 62432,
      "e": 59903,
      "ty": 3,
      "x": 365,
      "y": 439,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 62505,
      "e": 59976,
      "ty": 2,
      "x": 482,
      "y": 423
    },
    {
      "t": 62505,
      "e": 59976,
      "ty": 41,
      "x": 9275,
      "y": 33169,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 62605,
      "e": 60076,
      "ty": 2,
      "x": 761,
      "y": 384
    },
    {
      "t": 62705,
      "e": 60176,
      "ty": 2,
      "x": 906,
      "y": 373
    },
    {
      "t": 62755,
      "e": 60226,
      "ty": 41,
      "x": 30922,
      "y": 4459,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 62805,
      "e": 60276,
      "ty": 2,
      "x": 935,
      "y": 374
    },
    {
      "t": 62905,
      "e": 60376,
      "ty": 2,
      "x": 1028,
      "y": 394
    },
    {
      "t": 63005,
      "e": 60476,
      "ty": 2,
      "x": 1038,
      "y": 401
    },
    {
      "t": 63005,
      "e": 60476,
      "ty": 41,
      "x": 36629,
      "y": 16005,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 63104,
      "e": 60575,
      "ty": 2,
      "x": 1039,
      "y": 409
    },
    {
      "t": 63127,
      "e": 60598,
      "ty": 4,
      "x": 36531,
      "y": 23807,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 63127,
      "e": 60598,
      "ty": 5,
      "x": 1036,
      "y": 411,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 63205,
      "e": 60676,
      "ty": 2,
      "x": 1005,
      "y": 424
    },
    {
      "t": 63255,
      "e": 60726,
      "ty": 41,
      "x": 32890,
      "y": 46432,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 63305,
      "e": 60776,
      "ty": 2,
      "x": 929,
      "y": 452
    },
    {
      "t": 63405,
      "e": 60876,
      "ty": 2,
      "x": 818,
      "y": 486
    },
    {
      "t": 63505,
      "e": 60976,
      "ty": 2,
      "x": 707,
      "y": 501
    },
    {
      "t": 63505,
      "e": 60976,
      "ty": 41,
      "x": 20345,
      "y": 7222,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 63604,
      "e": 61075,
      "ty": 2,
      "x": 661,
      "y": 497
    },
    {
      "t": 63705,
      "e": 61176,
      "ty": 2,
      "x": 643,
      "y": 495
    },
    {
      "t": 63755,
      "e": 61226,
      "ty": 41,
      "x": 17196,
      "y": 4882,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 63888,
      "e": 61359,
      "ty": 3,
      "x": 655,
      "y": 495,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 63905,
      "e": 61376,
      "ty": 2,
      "x": 655,
      "y": 495
    },
    {
      "t": 64005,
      "e": 61476,
      "ty": 2,
      "x": 719,
      "y": 488
    },
    {
      "t": 64005,
      "e": 61476,
      "ty": 41,
      "x": 20935,
      "y": 2151,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 64104,
      "e": 61575,
      "ty": 2,
      "x": 814,
      "y": 476
    },
    {
      "t": 64205,
      "e": 61676,
      "ty": 2,
      "x": 945,
      "y": 459
    },
    {
      "t": 64255,
      "e": 61726,
      "ty": 41,
      "x": 35940,
      "y": 52674,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 64305,
      "e": 61776,
      "ty": 2,
      "x": 1084,
      "y": 448
    },
    {
      "t": 64405,
      "e": 61876,
      "ty": 2,
      "x": 1274,
      "y": 448
    },
    {
      "t": 64505,
      "e": 61976,
      "ty": 2,
      "x": 1340,
      "y": 448
    },
    {
      "t": 64505,
      "e": 61976,
      "ty": 41,
      "x": 51486,
      "y": 52674,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 64605,
      "e": 62076,
      "ty": 2,
      "x": 1421,
      "y": 460
    },
    {
      "t": 64704,
      "e": 62175,
      "ty": 2,
      "x": 1482,
      "y": 479
    },
    {
      "t": 64755,
      "e": 62226,
      "ty": 41,
      "x": 59063,
      "y": 17080,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 64804,
      "e": 62275,
      "ty": 2,
      "x": 1495,
      "y": 482
    },
    {
      "t": 65005,
      "e": 62476,
      "ty": 41,
      "x": 59112,
      "y": 17080,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 65405,
      "e": 62876,
      "ty": 2,
      "x": 1495,
      "y": 485
    },
    {
      "t": 65504,
      "e": 62975,
      "ty": 2,
      "x": 1498,
      "y": 491
    },
    {
      "t": 65505,
      "e": 62976,
      "ty": 41,
      "x": 59260,
      "y": 3321,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 65604,
      "e": 63075,
      "ty": 2,
      "x": 1501,
      "y": 496
    },
    {
      "t": 65705,
      "e": 63176,
      "ty": 2,
      "x": 1502,
      "y": 498
    },
    {
      "t": 65755,
      "e": 63226,
      "ty": 41,
      "x": 59456,
      "y": 6052,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 65905,
      "e": 63376,
      "ty": 2,
      "x": 1502,
      "y": 501
    },
    {
      "t": 66005,
      "e": 63476,
      "ty": 41,
      "x": 59456,
      "y": 7222,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 66105,
      "e": 63576,
      "ty": 2,
      "x": 1502,
      "y": 504
    },
    {
      "t": 66205,
      "e": 63676,
      "ty": 2,
      "x": 1507,
      "y": 522
    },
    {
      "t": 66255,
      "e": 63726,
      "ty": 41,
      "x": 59801,
      "y": 17755,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 66304,
      "e": 63775,
      "ty": 2,
      "x": 1509,
      "y": 530
    },
    {
      "t": 66505,
      "e": 63976,
      "ty": 2,
      "x": 1510,
      "y": 537
    },
    {
      "t": 66505,
      "e": 63976,
      "ty": 41,
      "x": 59850,
      "y": 21265,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 66605,
      "e": 64076,
      "ty": 2,
      "x": 1512,
      "y": 547
    },
    {
      "t": 66705,
      "e": 64176,
      "ty": 2,
      "x": 1513,
      "y": 556
    },
    {
      "t": 66755,
      "e": 64226,
      "ty": 41,
      "x": 59998,
      "y": 29067,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 66805,
      "e": 64276,
      "ty": 2,
      "x": 1514,
      "y": 560
    },
    {
      "t": 66904,
      "e": 64375,
      "ty": 2,
      "x": 1515,
      "y": 568
    },
    {
      "t": 67004,
      "e": 64475,
      "ty": 2,
      "x": 1521,
      "y": 586
    },
    {
      "t": 67005,
      "e": 64476,
      "ty": 41,
      "x": 60391,
      "y": 40380,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 67105,
      "e": 64576,
      "ty": 2,
      "x": 1524,
      "y": 596
    },
    {
      "t": 67205,
      "e": 64676,
      "ty": 2,
      "x": 1526,
      "y": 602
    },
    {
      "t": 67256,
      "e": 64727,
      "ty": 41,
      "x": 60686,
      "y": 47401,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 67305,
      "e": 64776,
      "ty": 2,
      "x": 1527,
      "y": 608
    },
    {
      "t": 67405,
      "e": 64876,
      "ty": 2,
      "x": 1528,
      "y": 612
    },
    {
      "t": 67505,
      "e": 64976,
      "ty": 2,
      "x": 1530,
      "y": 622
    },
    {
      "t": 67505,
      "e": 64976,
      "ty": 41,
      "x": 60834,
      "y": 54423,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 67605,
      "e": 65076,
      "ty": 2,
      "x": 1530,
      "y": 631
    },
    {
      "t": 67705,
      "e": 65176,
      "ty": 2,
      "x": 1532,
      "y": 638
    },
    {
      "t": 67755,
      "e": 65226,
      "ty": 41,
      "x": 60932,
      "y": 60664,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 67805,
      "e": 65276,
      "ty": 2,
      "x": 1533,
      "y": 639
    },
    {
      "t": 67895,
      "e": 65366,
      "ty": 4,
      "x": 60981,
      "y": 61055,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 67895,
      "e": 65366,
      "ty": 5,
      "x": 1533,
      "y": 639,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 68005,
      "e": 65476,
      "ty": 41,
      "x": 60981,
      "y": 61055,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 68105,
      "e": 65576,
      "ty": 2,
      "x": 1462,
      "y": 661
    },
    {
      "t": 68204,
      "e": 65675,
      "ty": 2,
      "x": 1252,
      "y": 721
    },
    {
      "t": 68255,
      "e": 65726,
      "ty": 41,
      "x": 39728,
      "y": 38335,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 68305,
      "e": 65776,
      "ty": 2,
      "x": 948,
      "y": 737
    },
    {
      "t": 68405,
      "e": 65876,
      "ty": 2,
      "x": 692,
      "y": 731
    },
    {
      "t": 68505,
      "e": 65976,
      "ty": 2,
      "x": 601,
      "y": 716
    },
    {
      "t": 68505,
      "e": 65976,
      "ty": 41,
      "x": 15130,
      "y": 27803,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 68605,
      "e": 66076,
      "ty": 2,
      "x": 564,
      "y": 709
    },
    {
      "t": 68705,
      "e": 66176,
      "ty": 2,
      "x": 561,
      "y": 707
    },
    {
      "t": 68756,
      "e": 66227,
      "ty": 41,
      "x": 13113,
      "y": 16685,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 68805,
      "e": 66276,
      "ty": 2,
      "x": 591,
      "y": 670
    },
    {
      "t": 68905,
      "e": 66376,
      "ty": 2,
      "x": 702,
      "y": 631
    },
    {
      "t": 69005,
      "e": 66476,
      "ty": 41,
      "x": 20099,
      "y": 57934,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 69105,
      "e": 66576,
      "ty": 2,
      "x": 657,
      "y": 659
    },
    {
      "t": 69205,
      "e": 66676,
      "ty": 2,
      "x": 633,
      "y": 668
    },
    {
      "t": 69256,
      "e": 66727,
      "ty": 41,
      "x": 16606,
      "y": 301,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 69305,
      "e": 66776,
      "ty": 2,
      "x": 631,
      "y": 669
    },
    {
      "t": 69336,
      "e": 66807,
      "ty": 3,
      "x": 631,
      "y": 669,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 69405,
      "e": 66876,
      "ty": 2,
      "x": 631,
      "y": 670
    },
    {
      "t": 69505,
      "e": 66976,
      "ty": 2,
      "x": 671,
      "y": 673
    },
    {
      "t": 69505,
      "e": 66976,
      "ty": 41,
      "x": 18574,
      "y": 2642,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 69605,
      "e": 67076,
      "ty": 2,
      "x": 790,
      "y": 688
    },
    {
      "t": 69704,
      "e": 67175,
      "ty": 2,
      "x": 943,
      "y": 709
    },
    {
      "t": 69755,
      "e": 67226,
      "ty": 41,
      "x": 35645,
      "y": 27803,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 69805,
      "e": 67276,
      "ty": 2,
      "x": 1107,
      "y": 727
    },
    {
      "t": 69905,
      "e": 67376,
      "ty": 2,
      "x": 1299,
      "y": 744
    },
    {
      "t": 70004,
      "e": 67475,
      "ty": 2,
      "x": 1337,
      "y": 749
    },
    {
      "t": 70004,
      "e": 67475,
      "ty": 41,
      "x": 51339,
      "y": 47112,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 70604,
      "e": 68075,
      "ty": 2,
      "x": 1338,
      "y": 749
    },
    {
      "t": 70755,
      "e": 68226,
      "ty": 41,
      "x": 51388,
      "y": 47112,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 72430,
      "e": 69901,
      "ty": 4,
      "x": 51388,
      "y": 47112,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 72431,
      "e": 69902,
      "ty": 5,
      "x": 1338,
      "y": 749,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 72904,
      "e": 70375,
      "ty": 2,
      "x": 1337,
      "y": 769
    },
    {
      "t": 73004,
      "e": 70475,
      "ty": 2,
      "x": 1296,
      "y": 831
    },
    {
      "t": 73004,
      "e": 70475,
      "ty": 41,
      "x": 49322,
      "y": 38051,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 73105,
      "e": 70576,
      "ty": 2,
      "x": 1275,
      "y": 895
    },
    {
      "t": 73204,
      "e": 70675,
      "ty": 2,
      "x": 1258,
      "y": 932
    },
    {
      "t": 73254,
      "e": 70725,
      "ty": 41,
      "x": 47108,
      "y": 56762,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 73304,
      "e": 70775,
      "ty": 2,
      "x": 1236,
      "y": 958
    },
    {
      "t": 73404,
      "e": 70875,
      "ty": 2,
      "x": 1187,
      "y": 993
    },
    {
      "t": 73504,
      "e": 70975,
      "ty": 2,
      "x": 1174,
      "y": 1006
    },
    {
      "t": 73505,
      "e": 70976,
      "ty": 41,
      "x": 43320,
      "y": 60917,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 73604,
      "e": 71075,
      "ty": 2,
      "x": 1145,
      "y": 1025
    },
    {
      "t": 73704,
      "e": 71175,
      "ty": 2,
      "x": 1115,
      "y": 1045
    },
    {
      "t": 73755,
      "e": 71226,
      "ty": 41,
      "x": 39532,
      "y": 64587,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 73804,
      "e": 71275,
      "ty": 2,
      "x": 1095,
      "y": 1061
    },
    {
      "t": 74004,
      "e": 71475,
      "ty": 2,
      "x": 1091,
      "y": 1063
    },
    {
      "t": 74004,
      "e": 71475,
      "ty": 41,
      "x": 39236,
      "y": 64864,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 74104,
      "e": 71575,
      "ty": 2,
      "x": 1035,
      "y": 1068
    },
    {
      "t": 74204,
      "e": 71675,
      "ty": 2,
      "x": 966,
      "y": 1068
    },
    {
      "t": 74254,
      "e": 71725,
      "ty": 41,
      "x": 32742,
      "y": 65418,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 74282,
      "e": 71753,
      "ty": 6,
      "x": 955,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 74304,
      "e": 71775,
      "ty": 2,
      "x": 954,
      "y": 1072
    },
    {
      "t": 74404,
      "e": 71875,
      "ty": 2,
      "x": 952,
      "y": 1073
    },
    {
      "t": 74504,
      "e": 71975,
      "ty": 2,
      "x": 947,
      "y": 1081
    },
    {
      "t": 74504,
      "e": 71975,
      "ty": 41,
      "x": 20479,
      "y": 16022,
      "ta": "#start"
    },
    {
      "t": 74604,
      "e": 72075,
      "ty": 2,
      "x": 944,
      "y": 1090
    },
    {
      "t": 74755,
      "e": 72226,
      "ty": 41,
      "x": 18841,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 74807,
      "e": 72278,
      "ty": 3,
      "x": 944,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 74808,
      "e": 72279,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 74999,
      "e": 72470,
      "ty": 4,
      "x": 18841,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 74999,
      "e": 72470,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 75000,
      "e": 72471,
      "ty": 5,
      "x": 944,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 75001,
      "e": 72472,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 76034,
      "e": 73505,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 76940,
      "e": 74411,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 14256, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 14260, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"K8DJ0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 4051, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 19408, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"K8DJ0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 13046, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"NOVEMBER\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"114\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 33456, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"K8DJ0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 3949, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 38503, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"K8DJ0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 12384, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 51889, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"K8DJ0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 15379, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 68582, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"K8DJ0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:915,y:567,t:1527271821220};\\\", \\\"{x:914,y:562,t:1527271821244};\\\", \\\"{x:913,y:560,t:1527271821253};\\\", \\\"{x:910,y:549,t:1527271821460};\\\", \\\"{x:910,y:546,t:1527271821467};\\\", \\\"{x:910,y:544,t:1527271821484};\\\", \\\"{x:910,y:535,t:1527271821605};\\\", \\\"{x:910,y:534,t:1527271823190};\\\", \\\"{x:910,y:533,t:1527271823202};\\\", \\\"{x:910,y:532,t:1527271823558};\\\", \\\"{x:910,y:531,t:1527271824215};\\\", \\\"{x:911,y:531,t:1527271824501};\\\", \\\"{x:912,y:530,t:1527271825407};\\\", \\\"{x:912,y:529,t:1527271826054};\\\", \\\"{x:913,y:529,t:1527271827365};\\\", \\\"{x:914,y:529,t:1527271827380};\\\", \\\"{x:916,y:529,t:1527271827388};\\\", \\\"{x:922,y:529,t:1527271827404};\\\", \\\"{x:935,y:529,t:1527271827420};\\\", \\\"{x:962,y:533,t:1527271827438};\\\", \\\"{x:974,y:536,t:1527271827453};\\\", \\\"{x:983,y:538,t:1527271827470};\\\", \\\"{x:991,y:540,t:1527271827488};\\\", \\\"{x:1004,y:542,t:1527271827504};\\\", \\\"{x:1019,y:543,t:1527271827520};\\\", \\\"{x:1035,y:547,t:1527271827538};\\\", \\\"{x:1051,y:552,t:1527271827554};\\\", \\\"{x:1075,y:558,t:1527271827571};\\\", \\\"{x:1099,y:564,t:1527271827587};\\\", \\\"{x:1133,y:577,t:1527271827603};\\\", \\\"{x:1157,y:585,t:1527271827620};\\\", \\\"{x:1173,y:590,t:1527271827637};\\\", \\\"{x:1186,y:595,t:1527271827655};\\\", \\\"{x:1195,y:600,t:1527271827671};\\\", \\\"{x:1209,y:607,t:1527271827687};\\\", \\\"{x:1225,y:617,t:1527271827704};\\\", \\\"{x:1240,y:625,t:1527271827721};\\\", \\\"{x:1250,y:632,t:1527271827737};\\\", \\\"{x:1256,y:635,t:1527271827755};\\\", \\\"{x:1258,y:638,t:1527271827772};\\\", \\\"{x:1259,y:640,t:1527271827787};\\\", \\\"{x:1260,y:643,t:1527271827804};\\\", \\\"{x:1262,y:645,t:1527271827821};\\\", \\\"{x:1266,y:648,t:1527271827837};\\\", \\\"{x:1270,y:651,t:1527271827855};\\\", \\\"{x:1279,y:661,t:1527271827872};\\\", \\\"{x:1286,y:675,t:1527271827888};\\\", \\\"{x:1286,y:676,t:1527271827904};\\\", \\\"{x:1287,y:676,t:1527271827921};\\\", \\\"{x:1286,y:680,t:1527271827938};\\\", \\\"{x:1281,y:690,t:1527271827955};\\\", \\\"{x:1277,y:696,t:1527271827971};\\\", \\\"{x:1277,y:698,t:1527271827987};\\\", \\\"{x:1275,y:698,t:1527271828133};\\\", \\\"{x:1275,y:699,t:1527271828140};\\\", \\\"{x:1275,y:700,t:1527271828155};\\\", \\\"{x:1275,y:704,t:1527271828172};\\\", \\\"{x:1274,y:708,t:1527271828189};\\\", \\\"{x:1274,y:710,t:1527271828205};\\\", \\\"{x:1273,y:711,t:1527271828222};\\\", \\\"{x:1273,y:712,t:1527271828277};\\\", \\\"{x:1273,y:714,t:1527271828289};\\\", \\\"{x:1276,y:723,t:1527271828305};\\\", \\\"{x:1281,y:732,t:1527271828322};\\\", \\\"{x:1288,y:747,t:1527271828339};\\\", \\\"{x:1303,y:763,t:1527271828355};\\\", \\\"{x:1312,y:776,t:1527271828372};\\\", \\\"{x:1331,y:805,t:1527271828388};\\\", \\\"{x:1342,y:824,t:1527271828405};\\\", \\\"{x:1360,y:848,t:1527271828422};\\\", \\\"{x:1387,y:876,t:1527271828439};\\\", \\\"{x:1416,y:904,t:1527271828455};\\\", \\\"{x:1438,y:928,t:1527271828472};\\\", \\\"{x:1450,y:945,t:1527271828489};\\\", \\\"{x:1458,y:962,t:1527271828506};\\\", \\\"{x:1461,y:971,t:1527271828522};\\\", \\\"{x:1461,y:973,t:1527271828539};\\\", \\\"{x:1461,y:974,t:1527271828557};\\\", \\\"{x:1461,y:975,t:1527271828572};\\\", \\\"{x:1460,y:978,t:1527271828589};\\\", \\\"{x:1456,y:981,t:1527271828606};\\\", \\\"{x:1454,y:984,t:1527271828622};\\\", \\\"{x:1449,y:989,t:1527271828639};\\\", \\\"{x:1443,y:992,t:1527271828656};\\\", \\\"{x:1438,y:994,t:1527271828672};\\\", \\\"{x:1433,y:996,t:1527271828689};\\\", \\\"{x:1424,y:997,t:1527271828706};\\\", \\\"{x:1410,y:997,t:1527271828722};\\\", \\\"{x:1399,y:1001,t:1527271828738};\\\", \\\"{x:1386,y:1002,t:1527271828756};\\\", \\\"{x:1368,y:1002,t:1527271828772};\\\", \\\"{x:1367,y:1002,t:1527271828789};\\\", \\\"{x:1363,y:1002,t:1527271828805};\\\", \\\"{x:1360,y:1001,t:1527271828822};\\\", \\\"{x:1354,y:998,t:1527271828838};\\\", \\\"{x:1350,y:998,t:1527271828855};\\\", \\\"{x:1345,y:996,t:1527271828873};\\\", \\\"{x:1342,y:995,t:1527271828888};\\\", \\\"{x:1340,y:994,t:1527271828905};\\\", \\\"{x:1339,y:993,t:1527271828922};\\\", \\\"{x:1337,y:993,t:1527271829060};\\\", \\\"{x:1336,y:993,t:1527271829099};\\\", \\\"{x:1335,y:993,t:1527271829172};\\\", \\\"{x:1335,y:992,t:1527271829357};\\\", \\\"{x:1335,y:991,t:1527271829444};\\\", \\\"{x:1335,y:989,t:1527271829525};\\\", \\\"{x:1335,y:988,t:1527271829587};\\\", \\\"{x:1335,y:986,t:1527271829628};\\\", \\\"{x:1335,y:985,t:1527271829667};\\\", \\\"{x:1335,y:983,t:1527271829708};\\\", \\\"{x:1335,y:982,t:1527271829732};\\\", \\\"{x:1335,y:980,t:1527271829771};\\\", \\\"{x:1335,y:979,t:1527271829820};\\\", \\\"{x:1335,y:977,t:1527271829901};\\\", \\\"{x:1335,y:976,t:1527271830021};\\\", \\\"{x:1335,y:973,t:1527271830172};\\\", \\\"{x:1333,y:973,t:1527271830190};\\\", \\\"{x:1331,y:972,t:1527271830206};\\\", \\\"{x:1328,y:969,t:1527271830223};\\\", \\\"{x:1325,y:968,t:1527271830239};\\\", \\\"{x:1318,y:966,t:1527271830256};\\\", \\\"{x:1311,y:964,t:1527271830273};\\\", \\\"{x:1309,y:964,t:1527271830289};\\\", \\\"{x:1308,y:963,t:1527271830307};\\\", \\\"{x:1306,y:962,t:1527271830323};\\\", \\\"{x:1303,y:962,t:1527271830421};\\\", \\\"{x:1302,y:961,t:1527271830493};\\\", \\\"{x:1301,y:960,t:1527271830517};\\\", \\\"{x:1300,y:960,t:1527271830524};\\\", \\\"{x:1299,y:960,t:1527271830541};\\\", \\\"{x:1297,y:960,t:1527271830558};\\\", \\\"{x:1296,y:959,t:1527271830575};\\\", \\\"{x:1294,y:958,t:1527271830684};\\\", \\\"{x:1293,y:957,t:1527271830724};\\\", \\\"{x:1292,y:957,t:1527271830789};\\\", \\\"{x:1291,y:957,t:1527271830813};\\\", \\\"{x:1290,y:957,t:1527271830845};\\\", \\\"{x:1288,y:957,t:1527271830858};\\\", \\\"{x:1287,y:957,t:1527271830874};\\\", \\\"{x:1285,y:957,t:1527271830891};\\\", \\\"{x:1280,y:958,t:1527271830908};\\\", \\\"{x:1278,y:959,t:1527271830925};\\\", \\\"{x:1275,y:961,t:1527271830941};\\\", \\\"{x:1272,y:963,t:1527271830957};\\\", \\\"{x:1271,y:964,t:1527271830973};\\\", \\\"{x:1270,y:964,t:1527271830990};\\\", \\\"{x:1269,y:965,t:1527271831007};\\\", \\\"{x:1268,y:966,t:1527271831024};\\\", \\\"{x:1267,y:967,t:1527271831040};\\\", \\\"{x:1266,y:967,t:1527271831092};\\\", \\\"{x:1266,y:966,t:1527271832549};\\\", \\\"{x:1265,y:965,t:1527271832559};\\\", \\\"{x:1258,y:960,t:1527271832576};\\\", \\\"{x:1251,y:958,t:1527271832593};\\\", \\\"{x:1220,y:949,t:1527271832609};\\\", \\\"{x:1163,y:929,t:1527271832626};\\\", \\\"{x:1106,y:917,t:1527271832644};\\\", \\\"{x:1032,y:899,t:1527271832660};\\\", \\\"{x:937,y:880,t:1527271832676};\\\", \\\"{x:861,y:866,t:1527271832693};\\\", \\\"{x:813,y:859,t:1527271832709};\\\", \\\"{x:786,y:851,t:1527271832726};\\\", \\\"{x:760,y:842,t:1527271832742};\\\", \\\"{x:736,y:831,t:1527271832758};\\\", \\\"{x:717,y:821,t:1527271832776};\\\", \\\"{x:703,y:809,t:1527271832793};\\\", \\\"{x:687,y:796,t:1527271832808};\\\", \\\"{x:668,y:779,t:1527271832826};\\\", \\\"{x:648,y:758,t:1527271832843};\\\", \\\"{x:624,y:728,t:1527271832858};\\\", \\\"{x:567,y:678,t:1527271832876};\\\", \\\"{x:530,y:642,t:1527271832892};\\\", \\\"{x:496,y:616,t:1527271832910};\\\", \\\"{x:474,y:605,t:1527271832926};\\\", \\\"{x:454,y:597,t:1527271832942};\\\", \\\"{x:431,y:583,t:1527271832958};\\\", \\\"{x:392,y:568,t:1527271832976};\\\", \\\"{x:366,y:554,t:1527271832991};\\\", \\\"{x:346,y:538,t:1527271833009};\\\", \\\"{x:322,y:526,t:1527271833026};\\\", \\\"{x:294,y:516,t:1527271833042};\\\", \\\"{x:266,y:509,t:1527271833059};\\\", \\\"{x:217,y:495,t:1527271833076};\\\", \\\"{x:175,y:489,t:1527271833092};\\\", \\\"{x:149,y:484,t:1527271833108};\\\", \\\"{x:133,y:483,t:1527271833126};\\\", \\\"{x:130,y:483,t:1527271833142};\\\", \\\"{x:129,y:483,t:1527271833164};\\\", \\\"{x:128,y:483,t:1527271833203};\\\", \\\"{x:128,y:484,t:1527271833219};\\\", \\\"{x:130,y:485,t:1527271833228};\\\", \\\"{x:133,y:489,t:1527271833243};\\\", \\\"{x:157,y:493,t:1527271833258};\\\", \\\"{x:263,y:499,t:1527271833275};\\\", \\\"{x:357,y:511,t:1527271833292};\\\", \\\"{x:419,y:512,t:1527271833308};\\\", \\\"{x:445,y:512,t:1527271833326};\\\", \\\"{x:453,y:509,t:1527271833343};\\\", \\\"{x:454,y:509,t:1527271833404};\\\", \\\"{x:454,y:508,t:1527271833412};\\\", \\\"{x:454,y:507,t:1527271833426};\\\", \\\"{x:452,y:506,t:1527271833442};\\\", \\\"{x:444,y:502,t:1527271833460};\\\", \\\"{x:429,y:499,t:1527271833477};\\\", \\\"{x:412,y:499,t:1527271833492};\\\", \\\"{x:399,y:499,t:1527271833509};\\\", \\\"{x:383,y:499,t:1527271833526};\\\", \\\"{x:374,y:500,t:1527271833543};\\\", \\\"{x:372,y:502,t:1527271833559};\\\", \\\"{x:370,y:502,t:1527271833576};\\\", \\\"{x:370,y:503,t:1527271833596};\\\", \\\"{x:369,y:504,t:1527271833608};\\\", \\\"{x:367,y:506,t:1527271833626};\\\", \\\"{x:366,y:509,t:1527271833642};\\\", \\\"{x:365,y:512,t:1527271833659};\\\", \\\"{x:364,y:514,t:1527271833675};\\\", \\\"{x:364,y:515,t:1527271833692};\\\", \\\"{x:364,y:517,t:1527271833708};\\\", \\\"{x:366,y:519,t:1527271833725};\\\", \\\"{x:367,y:519,t:1527271833748};\\\", \\\"{x:369,y:519,t:1527271833764};\\\", \\\"{x:370,y:519,t:1527271833780};\\\", \\\"{x:372,y:519,t:1527271833795};\\\", \\\"{x:373,y:519,t:1527271833828};\\\", \\\"{x:375,y:519,t:1527271834156};\\\", \\\"{x:376,y:519,t:1527271834163};\\\", \\\"{x:377,y:519,t:1527271834176};\\\", \\\"{x:380,y:523,t:1527271834193};\\\", \\\"{x:383,y:529,t:1527271834209};\\\", \\\"{x:385,y:535,t:1527271834227};\\\", \\\"{x:391,y:546,t:1527271834243};\\\", \\\"{x:403,y:566,t:1527271834260};\\\", \\\"{x:414,y:579,t:1527271834277};\\\", \\\"{x:420,y:592,t:1527271834293};\\\", \\\"{x:430,y:605,t:1527271834310};\\\", \\\"{x:439,y:615,t:1527271834327};\\\", \\\"{x:444,y:622,t:1527271834344};\\\", \\\"{x:447,y:626,t:1527271834360};\\\", \\\"{x:449,y:628,t:1527271834376};\\\", \\\"{x:454,y:631,t:1527271834393};\\\", \\\"{x:455,y:633,t:1527271834410};\\\", \\\"{x:456,y:634,t:1527271834427};\\\", \\\"{x:457,y:634,t:1527271834442};\\\", \\\"{x:457,y:635,t:1527271834460};\\\", \\\"{x:457,y:636,t:1527271834492};\\\", \\\"{x:457,y:635,t:1527271834564};\\\", \\\"{x:454,y:630,t:1527271834577};\\\", \\\"{x:447,y:623,t:1527271834594};\\\", \\\"{x:439,y:614,t:1527271834610};\\\", \\\"{x:432,y:606,t:1527271834627};\\\", \\\"{x:417,y:587,t:1527271834643};\\\", \\\"{x:410,y:578,t:1527271834660};\\\", \\\"{x:404,y:572,t:1527271834676};\\\", \\\"{x:402,y:568,t:1527271834693};\\\", \\\"{x:399,y:565,t:1527271834709};\\\", \\\"{x:397,y:563,t:1527271834726};\\\", \\\"{x:395,y:560,t:1527271834743};\\\", \\\"{x:392,y:557,t:1527271834759};\\\", \\\"{x:389,y:554,t:1527271834776};\\\", \\\"{x:386,y:552,t:1527271834793};\\\", \\\"{x:385,y:550,t:1527271834810};\\\", \\\"{x:383,y:548,t:1527271834827};\\\", \\\"{x:381,y:544,t:1527271834843};\\\", \\\"{x:381,y:543,t:1527271834868};\\\", \\\"{x:381,y:542,t:1527271834884};\\\", \\\"{x:380,y:541,t:1527271834894};\\\", \\\"{x:380,y:540,t:1527271834924};\\\", \\\"{x:380,y:539,t:1527271834940};\\\", \\\"{x:380,y:538,t:1527271834964};\\\", \\\"{x:380,y:536,t:1527271835030};\\\", \\\"{x:380,y:534,t:1527271835044};\\\", \\\"{x:382,y:532,t:1527271835061};\\\", \\\"{x:384,y:529,t:1527271835077};\\\", \\\"{x:385,y:527,t:1527271835094};\\\", \\\"{x:386,y:526,t:1527271835110};\\\", \\\"{x:388,y:524,t:1527271835126};\\\", \\\"{x:388,y:523,t:1527271835147};\\\", \\\"{x:389,y:523,t:1527271835179};\\\", \\\"{x:389,y:524,t:1527271835645};\\\", \\\"{x:391,y:534,t:1527271835662};\\\", \\\"{x:398,y:548,t:1527271835678};\\\", \\\"{x:408,y:567,t:1527271835694};\\\", \\\"{x:418,y:589,t:1527271835711};\\\", \\\"{x:425,y:605,t:1527271835727};\\\", \\\"{x:430,y:617,t:1527271835744};\\\", \\\"{x:433,y:625,t:1527271835761};\\\", \\\"{x:433,y:627,t:1527271835778};\\\", \\\"{x:433,y:628,t:1527271835793};\\\", \\\"{x:433,y:629,t:1527271835867};\\\", \\\"{x:434,y:630,t:1527271835877};\\\", \\\"{x:439,y:637,t:1527271835894};\\\", \\\"{x:447,y:648,t:1527271835911};\\\", \\\"{x:458,y:659,t:1527271835928};\\\", \\\"{x:466,y:670,t:1527271835945};\\\", \\\"{x:476,y:678,t:1527271835961};\\\", \\\"{x:481,y:683,t:1527271835977};\\\", \\\"{x:482,y:685,t:1527271835994};\\\", \\\"{x:483,y:686,t:1527271836011};\\\", \\\"{x:483,y:687,t:1527271836117};\\\", \\\"{x:483,y:688,t:1527271836155};\\\", \\\"{x:483,y:690,t:1527271836164};\\\", \\\"{x:484,y:691,t:1527271836176};\\\", \\\"{x:485,y:692,t:1527271836194};\\\", \\\"{x:485,y:693,t:1527271836210};\\\", \\\"{x:485,y:695,t:1527271836226};\\\", \\\"{x:486,y:696,t:1527271836242};\\\", \\\"{x:489,y:699,t:1527271836259};\\\", \\\"{x:493,y:702,t:1527271836278};\\\", \\\"{x:494,y:704,t:1527271836292};\\\", \\\"{x:496,y:705,t:1527271836312};\\\", \\\"{x:497,y:705,t:1527271836331};\\\", \\\"{x:498,y:705,t:1527271836355};\\\", \\\"{x:499,y:705,t:1527271836372};\\\", \\\"{x:500,y:705,t:1527271836395};\\\", \\\"{x:501,y:705,t:1527271836811};\\\", \\\"{x:501,y:701,t:1527271836828};\\\", \\\"{x:505,y:690,t:1527271836844};\\\", \\\"{x:508,y:680,t:1527271836862};\\\", \\\"{x:513,y:662,t:1527271836878};\\\", \\\"{x:518,y:645,t:1527271836894};\\\", \\\"{x:528,y:627,t:1527271836911};\\\", \\\"{x:537,y:610,t:1527271836929};\\\", \\\"{x:545,y:596,t:1527271836944};\\\", \\\"{x:555,y:584,t:1527271836961};\\\", \\\"{x:566,y:570,t:1527271836978};\\\", \\\"{x:579,y:557,t:1527271836994};\\\", \\\"{x:610,y:538,t:1527271837011};\\\", \\\"{x:635,y:525,t:1527271837028};\\\", \\\"{x:658,y:512,t:1527271837044};\\\", \\\"{x:690,y:503,t:1527271837061};\\\", \\\"{x:715,y:494,t:1527271837079};\\\", \\\"{x:736,y:490,t:1527271837095};\\\", \\\"{x:757,y:486,t:1527271837112};\\\", \\\"{x:770,y:482,t:1527271837129};\\\", \\\"{x:779,y:480,t:1527271837145};\\\", \\\"{x:786,y:479,t:1527271837162};\\\", \\\"{x:789,y:478,t:1527271837179};\\\", \\\"{x:792,y:476,t:1527271837195};\\\", \\\"{x:796,y:475,t:1527271837211};\\\", \\\"{x:799,y:474,t:1527271837228};\\\", \\\"{x:803,y:471,t:1527271837246};\\\", \\\"{x:804,y:471,t:1527271837261};\\\", \\\"{x:806,y:469,t:1527271837278};\\\", \\\"{x:810,y:469,t:1527271837296};\\\", \\\"{x:820,y:467,t:1527271837311};\\\", \\\"{x:835,y:465,t:1527271837329};\\\", \\\"{x:848,y:464,t:1527271837345};\\\", \\\"{x:867,y:462,t:1527271837361};\\\", \\\"{x:888,y:458,t:1527271837379};\\\", \\\"{x:915,y:454,t:1527271837396};\\\", \\\"{x:932,y:448,t:1527271837412};\\\", \\\"{x:939,y:442,t:1527271837428};\\\" ] }, { \\\"rt\\\": 6870, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 76766, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"K8DJ0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:935,y:441,t:1527271839005};\\\", \\\"{x:926,y:439,t:1527271839014};\\\", \\\"{x:908,y:439,t:1527271839030};\\\", \\\"{x:905,y:439,t:1527271839047};\\\", \\\"{x:904,y:439,t:1527271839064};\\\", \\\"{x:901,y:439,t:1527271839164};\\\", \\\"{x:900,y:438,t:1527271839187};\\\", \\\"{x:899,y:437,t:1527271839197};\\\", \\\"{x:898,y:437,t:1527271839214};\\\", \\\"{x:895,y:436,t:1527271839230};\\\", \\\"{x:895,y:435,t:1527271839259};\\\", \\\"{x:894,y:435,t:1527271839291};\\\", \\\"{x:895,y:432,t:1527271839964};\\\", \\\"{x:911,y:426,t:1527271839981};\\\", \\\"{x:922,y:419,t:1527271839998};\\\", \\\"{x:935,y:415,t:1527271840015};\\\", \\\"{x:948,y:411,t:1527271840031};\\\", \\\"{x:967,y:410,t:1527271840048};\\\", \\\"{x:1000,y:409,t:1527271840065};\\\", \\\"{x:1053,y:409,t:1527271840081};\\\", \\\"{x:1111,y:420,t:1527271840098};\\\", \\\"{x:1198,y:435,t:1527271840115};\\\", \\\"{x:1282,y:450,t:1527271840131};\\\", \\\"{x:1413,y:481,t:1527271840148};\\\", \\\"{x:1489,y:504,t:1527271840166};\\\", \\\"{x:1561,y:524,t:1527271840181};\\\", \\\"{x:1618,y:542,t:1527271840197};\\\", \\\"{x:1656,y:558,t:1527271840215};\\\", \\\"{x:1707,y:573,t:1527271840230};\\\", \\\"{x:1759,y:595,t:1527271840248};\\\", \\\"{x:1809,y:611,t:1527271840265};\\\", \\\"{x:1846,y:623,t:1527271840282};\\\", \\\"{x:1871,y:631,t:1527271840298};\\\", \\\"{x:1890,y:639,t:1527271840315};\\\", \\\"{x:1907,y:648,t:1527271840332};\\\", \\\"{x:1918,y:656,t:1527271840348};\\\", \\\"{x:1919,y:661,t:1527271840365};\\\", \\\"{x:1919,y:663,t:1527271840380};\\\", \\\"{x:1919,y:665,t:1527271840397};\\\", \\\"{x:1919,y:668,t:1527271840415};\\\", \\\"{x:1919,y:671,t:1527271840431};\\\", \\\"{x:1919,y:676,t:1527271840448};\\\", \\\"{x:1919,y:679,t:1527271840465};\\\", \\\"{x:1919,y:685,t:1527271840482};\\\", \\\"{x:1919,y:689,t:1527271840497};\\\", \\\"{x:1919,y:693,t:1527271840515};\\\", \\\"{x:1919,y:697,t:1527271840532};\\\", \\\"{x:1919,y:700,t:1527271840548};\\\", \\\"{x:1919,y:703,t:1527271840565};\\\", \\\"{x:1919,y:708,t:1527271840581};\\\", \\\"{x:1919,y:712,t:1527271840598};\\\", \\\"{x:1919,y:718,t:1527271840615};\\\", \\\"{x:1919,y:723,t:1527271840632};\\\", \\\"{x:1919,y:730,t:1527271840647};\\\", \\\"{x:1919,y:735,t:1527271840665};\\\", \\\"{x:1919,y:742,t:1527271840681};\\\", \\\"{x:1919,y:748,t:1527271840698};\\\", \\\"{x:1919,y:753,t:1527271840714};\\\", \\\"{x:1919,y:762,t:1527271840731};\\\", \\\"{x:1919,y:770,t:1527271840748};\\\", \\\"{x:1916,y:778,t:1527271840765};\\\", \\\"{x:1915,y:784,t:1527271840782};\\\", \\\"{x:1913,y:786,t:1527271840799};\\\", \\\"{x:1913,y:788,t:1527271840815};\\\", \\\"{x:1914,y:790,t:1527271841331};\\\", \\\"{x:1915,y:790,t:1527271841348};\\\", \\\"{x:1917,y:789,t:1527271841365};\\\", \\\"{x:1917,y:786,t:1527271841382};\\\", \\\"{x:1917,y:771,t:1527271841399};\\\", \\\"{x:1911,y:749,t:1527271841416};\\\", \\\"{x:1903,y:723,t:1527271841431};\\\", \\\"{x:1898,y:705,t:1527271841449};\\\", \\\"{x:1894,y:685,t:1527271841466};\\\", \\\"{x:1889,y:667,t:1527271841481};\\\", \\\"{x:1882,y:651,t:1527271841498};\\\", \\\"{x:1871,y:623,t:1527271841515};\\\", \\\"{x:1863,y:606,t:1527271841531};\\\", \\\"{x:1858,y:596,t:1527271841549};\\\", \\\"{x:1855,y:589,t:1527271841565};\\\", \\\"{x:1852,y:584,t:1527271841582};\\\", \\\"{x:1850,y:580,t:1527271841598};\\\", \\\"{x:1846,y:571,t:1527271841615};\\\", \\\"{x:1840,y:561,t:1527271841632};\\\", \\\"{x:1838,y:553,t:1527271841648};\\\", \\\"{x:1831,y:542,t:1527271841666};\\\", \\\"{x:1826,y:534,t:1527271841683};\\\", \\\"{x:1819,y:526,t:1527271841698};\\\", \\\"{x:1810,y:520,t:1527271841716};\\\", \\\"{x:1800,y:517,t:1527271841733};\\\", \\\"{x:1775,y:515,t:1527271841749};\\\", \\\"{x:1745,y:515,t:1527271841766};\\\", \\\"{x:1722,y:515,t:1527271841783};\\\", \\\"{x:1703,y:517,t:1527271841799};\\\", \\\"{x:1687,y:525,t:1527271841815};\\\", \\\"{x:1673,y:533,t:1527271841833};\\\", \\\"{x:1661,y:539,t:1527271841849};\\\", \\\"{x:1649,y:545,t:1527271841866};\\\", \\\"{x:1640,y:553,t:1527271841883};\\\", \\\"{x:1636,y:556,t:1527271841899};\\\", \\\"{x:1633,y:560,t:1527271841916};\\\", \\\"{x:1631,y:562,t:1527271841933};\\\", \\\"{x:1630,y:564,t:1527271841949};\\\", \\\"{x:1630,y:566,t:1527271841966};\\\", \\\"{x:1630,y:567,t:1527271841983};\\\", \\\"{x:1628,y:570,t:1527271841999};\\\", \\\"{x:1628,y:573,t:1527271842016};\\\", \\\"{x:1627,y:576,t:1527271842033};\\\", \\\"{x:1627,y:579,t:1527271842049};\\\", \\\"{x:1626,y:582,t:1527271842067};\\\", \\\"{x:1625,y:584,t:1527271842083};\\\", \\\"{x:1623,y:585,t:1527271842100};\\\", \\\"{x:1622,y:587,t:1527271842116};\\\", \\\"{x:1619,y:589,t:1527271842133};\\\", \\\"{x:1616,y:592,t:1527271842150};\\\", \\\"{x:1607,y:599,t:1527271842166};\\\", \\\"{x:1591,y:610,t:1527271842183};\\\", \\\"{x:1549,y:628,t:1527271842201};\\\", \\\"{x:1459,y:655,t:1527271842216};\\\", \\\"{x:1350,y:675,t:1527271842233};\\\", \\\"{x:1206,y:696,t:1527271842250};\\\", \\\"{x:1027,y:721,t:1527271842266};\\\", \\\"{x:849,y:752,t:1527271842283};\\\", \\\"{x:613,y:785,t:1527271842299};\\\", \\\"{x:439,y:803,t:1527271842316};\\\", \\\"{x:290,y:803,t:1527271842333};\\\", \\\"{x:203,y:801,t:1527271842349};\\\", \\\"{x:155,y:793,t:1527271842365};\\\", \\\"{x:129,y:781,t:1527271842383};\\\", \\\"{x:113,y:768,t:1527271842400};\\\", \\\"{x:105,y:754,t:1527271842415};\\\", \\\"{x:100,y:740,t:1527271842432};\\\", \\\"{x:95,y:723,t:1527271842450};\\\", \\\"{x:95,y:701,t:1527271842467};\\\", \\\"{x:96,y:679,t:1527271842483};\\\", \\\"{x:101,y:651,t:1527271842500};\\\", \\\"{x:107,y:633,t:1527271842518};\\\", \\\"{x:117,y:614,t:1527271842533};\\\", \\\"{x:150,y:576,t:1527271842566};\\\", \\\"{x:175,y:559,t:1527271842583};\\\", \\\"{x:204,y:543,t:1527271842600};\\\", \\\"{x:233,y:526,t:1527271842617};\\\", \\\"{x:250,y:514,t:1527271842632};\\\", \\\"{x:263,y:506,t:1527271842649};\\\", \\\"{x:268,y:502,t:1527271842667};\\\", \\\"{x:271,y:500,t:1527271842682};\\\", \\\"{x:272,y:499,t:1527271842699};\\\", \\\"{x:272,y:498,t:1527271842716};\\\", \\\"{x:274,y:498,t:1527271842836};\\\", \\\"{x:275,y:498,t:1527271842850};\\\", \\\"{x:283,y:502,t:1527271842867};\\\", \\\"{x:296,y:507,t:1527271842885};\\\", \\\"{x:302,y:509,t:1527271842900};\\\", \\\"{x:309,y:512,t:1527271842916};\\\", \\\"{x:316,y:516,t:1527271842933};\\\", \\\"{x:317,y:516,t:1527271842949};\\\", \\\"{x:317,y:518,t:1527271843043};\\\", \\\"{x:317,y:519,t:1527271843052};\\\", \\\"{x:317,y:522,t:1527271843067};\\\", \\\"{x:310,y:529,t:1527271843083};\\\", \\\"{x:301,y:537,t:1527271843101};\\\", \\\"{x:285,y:547,t:1527271843117};\\\", \\\"{x:266,y:558,t:1527271843134};\\\", \\\"{x:250,y:564,t:1527271843150};\\\", \\\"{x:237,y:569,t:1527271843167};\\\", \\\"{x:230,y:573,t:1527271843183};\\\", \\\"{x:226,y:574,t:1527271843199};\\\", \\\"{x:222,y:576,t:1527271843217};\\\", \\\"{x:220,y:577,t:1527271843233};\\\", \\\"{x:218,y:578,t:1527271843250};\\\", \\\"{x:216,y:579,t:1527271843267};\\\", \\\"{x:214,y:580,t:1527271843283};\\\", \\\"{x:213,y:581,t:1527271843299};\\\", \\\"{x:212,y:581,t:1527271843316};\\\", \\\"{x:211,y:583,t:1527271843334};\\\", \\\"{x:210,y:584,t:1527271843350};\\\", \\\"{x:206,y:587,t:1527271843367};\\\", \\\"{x:203,y:590,t:1527271843383};\\\", \\\"{x:194,y:598,t:1527271843401};\\\", \\\"{x:188,y:605,t:1527271843417};\\\", \\\"{x:181,y:614,t:1527271843434};\\\", \\\"{x:177,y:619,t:1527271843451};\\\", \\\"{x:173,y:622,t:1527271843467};\\\", \\\"{x:171,y:623,t:1527271843484};\\\", \\\"{x:170,y:624,t:1527271843500};\\\", \\\"{x:170,y:625,t:1527271843517};\\\", \\\"{x:169,y:625,t:1527271843534};\\\", \\\"{x:168,y:626,t:1527271843571};\\\", \\\"{x:168,y:627,t:1527271843584};\\\", \\\"{x:167,y:627,t:1527271843771};\\\", \\\"{x:167,y:628,t:1527271843783};\\\", \\\"{x:166,y:628,t:1527271843800};\\\", \\\"{x:165,y:629,t:1527271843979};\\\", \\\"{x:165,y:630,t:1527271843987};\\\", \\\"{x:165,y:631,t:1527271844003};\\\", \\\"{x:167,y:633,t:1527271844017};\\\", \\\"{x:170,y:634,t:1527271844034};\\\", \\\"{x:171,y:634,t:1527271844051};\\\", \\\"{x:173,y:635,t:1527271844067};\\\", \\\"{x:177,y:637,t:1527271844084};\\\", \\\"{x:185,y:638,t:1527271844101};\\\", \\\"{x:199,y:642,t:1527271844119};\\\", \\\"{x:224,y:644,t:1527271844134};\\\", \\\"{x:257,y:648,t:1527271844151};\\\", \\\"{x:289,y:648,t:1527271844169};\\\", \\\"{x:319,y:649,t:1527271844184};\\\", \\\"{x:336,y:650,t:1527271844201};\\\", \\\"{x:350,y:650,t:1527271844217};\\\", \\\"{x:360,y:652,t:1527271844235};\\\", \\\"{x:367,y:653,t:1527271844250};\\\", \\\"{x:368,y:653,t:1527271844268};\\\", \\\"{x:369,y:653,t:1527271844307};\\\", \\\"{x:370,y:653,t:1527271844318};\\\", \\\"{x:375,y:654,t:1527271844335};\\\", \\\"{x:388,y:661,t:1527271844351};\\\", \\\"{x:404,y:671,t:1527271844368};\\\", \\\"{x:420,y:680,t:1527271844385};\\\", \\\"{x:430,y:684,t:1527271844401};\\\", \\\"{x:443,y:692,t:1527271844418};\\\", \\\"{x:457,y:699,t:1527271844435};\\\", \\\"{x:469,y:705,t:1527271844452};\\\", \\\"{x:484,y:713,t:1527271844467};\\\", \\\"{x:490,y:718,t:1527271844485};\\\", \\\"{x:494,y:720,t:1527271844501};\\\", \\\"{x:494,y:721,t:1527271844518};\\\", \\\"{x:495,y:721,t:1527271844539};\\\", \\\"{x:496,y:721,t:1527271844552};\\\", \\\"{x:497,y:722,t:1527271844568};\\\", \\\"{x:499,y:724,t:1527271844585};\\\", \\\"{x:501,y:726,t:1527271844602};\\\" ] }, { \\\"rt\\\": 12406, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 90398, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"K8DJ0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -A -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:502,y:725,t:1527271846486};\\\", \\\"{x:503,y:724,t:1527271846507};\\\", \\\"{x:505,y:723,t:1527271846523};\\\", \\\"{x:505,y:721,t:1527271846548};\\\", \\\"{x:506,y:721,t:1527271846587};\\\", \\\"{x:506,y:720,t:1527271846611};\\\", \\\"{x:506,y:719,t:1527271846627};\\\", \\\"{x:507,y:717,t:1527271846659};\\\", \\\"{x:507,y:716,t:1527271846708};\\\", \\\"{x:507,y:715,t:1527271846719};\\\", \\\"{x:507,y:714,t:1527271846739};\\\", \\\"{x:507,y:713,t:1527271846755};\\\", \\\"{x:507,y:712,t:1527271846771};\\\", \\\"{x:507,y:711,t:1527271846787};\\\", \\\"{x:508,y:710,t:1527271846803};\\\", \\\"{x:508,y:709,t:1527271846828};\\\", \\\"{x:509,y:708,t:1527271846884};\\\", \\\"{x:510,y:708,t:1527271846940};\\\", \\\"{x:510,y:707,t:1527271846989};\\\", \\\"{x:510,y:706,t:1527271847011};\\\", \\\"{x:510,y:705,t:1527271847052};\\\", \\\"{x:510,y:704,t:1527271847075};\\\", \\\"{x:510,y:703,t:1527271847092};\\\", \\\"{x:511,y:702,t:1527271847189};\\\", \\\"{x:511,y:701,t:1527271847852};\\\", \\\"{x:511,y:700,t:1527271848355};\\\", \\\"{x:512,y:699,t:1527271849156};\\\", \\\"{x:513,y:699,t:1527271849180};\\\", \\\"{x:515,y:699,t:1527271849195};\\\", \\\"{x:516,y:698,t:1527271849220};\\\", \\\"{x:518,y:698,t:1527271849236};\\\", \\\"{x:519,y:698,t:1527271849307};\\\", \\\"{x:520,y:698,t:1527271849339};\\\", \\\"{x:522,y:698,t:1527271849395};\\\", \\\"{x:523,y:698,t:1527271849804};\\\", \\\"{x:525,y:698,t:1527271849812};\\\", \\\"{x:526,y:697,t:1527271849824};\\\", \\\"{x:526,y:696,t:1527271849840};\\\", \\\"{x:529,y:695,t:1527271849856};\\\", \\\"{x:531,y:693,t:1527271849873};\\\", \\\"{x:541,y:688,t:1527271849889};\\\", \\\"{x:555,y:687,t:1527271849907};\\\", \\\"{x:568,y:683,t:1527271849923};\\\", \\\"{x:586,y:682,t:1527271849939};\\\", \\\"{x:610,y:677,t:1527271849956};\\\", \\\"{x:623,y:676,t:1527271849973};\\\", \\\"{x:639,y:674,t:1527271849990};\\\", \\\"{x:656,y:674,t:1527271850006};\\\", \\\"{x:674,y:674,t:1527271850024};\\\", \\\"{x:689,y:674,t:1527271850040};\\\", \\\"{x:705,y:674,t:1527271850056};\\\", \\\"{x:724,y:674,t:1527271850073};\\\", \\\"{x:747,y:675,t:1527271850089};\\\", \\\"{x:769,y:678,t:1527271850106};\\\", \\\"{x:793,y:681,t:1527271850122};\\\", \\\"{x:818,y:686,t:1527271850139};\\\", \\\"{x:867,y:693,t:1527271850156};\\\", \\\"{x:895,y:698,t:1527271850173};\\\", \\\"{x:924,y:702,t:1527271850190};\\\", \\\"{x:952,y:706,t:1527271850206};\\\", \\\"{x:981,y:709,t:1527271850224};\\\", \\\"{x:1002,y:715,t:1527271850240};\\\", \\\"{x:1019,y:719,t:1527271850256};\\\", \\\"{x:1033,y:722,t:1527271850273};\\\", \\\"{x:1047,y:728,t:1527271850290};\\\", \\\"{x:1057,y:733,t:1527271850307};\\\", \\\"{x:1072,y:741,t:1527271850324};\\\", \\\"{x:1075,y:744,t:1527271850339};\\\", \\\"{x:1080,y:747,t:1527271850356};\\\", \\\"{x:1082,y:749,t:1527271850373};\\\", \\\"{x:1084,y:754,t:1527271850389};\\\", \\\"{x:1085,y:759,t:1527271850406};\\\", \\\"{x:1087,y:766,t:1527271850422};\\\", \\\"{x:1092,y:776,t:1527271850439};\\\", \\\"{x:1096,y:787,t:1527271850456};\\\", \\\"{x:1102,y:796,t:1527271850473};\\\", \\\"{x:1105,y:804,t:1527271850489};\\\", \\\"{x:1110,y:810,t:1527271850506};\\\", \\\"{x:1118,y:820,t:1527271850523};\\\", \\\"{x:1131,y:829,t:1527271850539};\\\", \\\"{x:1135,y:831,t:1527271850556};\\\", \\\"{x:1142,y:834,t:1527271850573};\\\", \\\"{x:1151,y:837,t:1527271850589};\\\", \\\"{x:1158,y:838,t:1527271850606};\\\", \\\"{x:1164,y:841,t:1527271850623};\\\", \\\"{x:1167,y:842,t:1527271850639};\\\", \\\"{x:1168,y:842,t:1527271850656};\\\", \\\"{x:1169,y:843,t:1527271850673};\\\", \\\"{x:1170,y:843,t:1527271850690};\\\", \\\"{x:1172,y:844,t:1527271850706};\\\", \\\"{x:1174,y:848,t:1527271850723};\\\", \\\"{x:1177,y:851,t:1527271850739};\\\", \\\"{x:1177,y:853,t:1527271850756};\\\", \\\"{x:1180,y:858,t:1527271850773};\\\", \\\"{x:1181,y:861,t:1527271850790};\\\", \\\"{x:1183,y:868,t:1527271850807};\\\", \\\"{x:1184,y:873,t:1527271850823};\\\", \\\"{x:1187,y:882,t:1527271850840};\\\", \\\"{x:1190,y:891,t:1527271850856};\\\", \\\"{x:1195,y:901,t:1527271850873};\\\", \\\"{x:1197,y:908,t:1527271850891};\\\", \\\"{x:1201,y:914,t:1527271850906};\\\", \\\"{x:1206,y:923,t:1527271850923};\\\", \\\"{x:1207,y:926,t:1527271850939};\\\", \\\"{x:1208,y:926,t:1527271851027};\\\", \\\"{x:1208,y:924,t:1527271851043};\\\", \\\"{x:1209,y:921,t:1527271851056};\\\", \\\"{x:1209,y:916,t:1527271851073};\\\", \\\"{x:1210,y:911,t:1527271851090};\\\", \\\"{x:1210,y:905,t:1527271851106};\\\", \\\"{x:1210,y:899,t:1527271851123};\\\", \\\"{x:1212,y:892,t:1527271851140};\\\", \\\"{x:1212,y:887,t:1527271851156};\\\", \\\"{x:1213,y:881,t:1527271851173};\\\", \\\"{x:1214,y:875,t:1527271851190};\\\", \\\"{x:1214,y:868,t:1527271851206};\\\", \\\"{x:1214,y:861,t:1527271851223};\\\", \\\"{x:1214,y:856,t:1527271851240};\\\", \\\"{x:1214,y:852,t:1527271851257};\\\", \\\"{x:1214,y:850,t:1527271851273};\\\", \\\"{x:1214,y:848,t:1527271851290};\\\", \\\"{x:1214,y:847,t:1527271851307};\\\", \\\"{x:1214,y:846,t:1527271851323};\\\", \\\"{x:1214,y:844,t:1527271851340};\\\", \\\"{x:1214,y:843,t:1527271851363};\\\", \\\"{x:1214,y:841,t:1527271851380};\\\", \\\"{x:1214,y:840,t:1527271851412};\\\", \\\"{x:1214,y:838,t:1527271851525};\\\", \\\"{x:1214,y:837,t:1527271851580};\\\", \\\"{x:1214,y:836,t:1527271851629};\\\", \\\"{x:1214,y:835,t:1527271851643};\\\", \\\"{x:1214,y:834,t:1527271851715};\\\", \\\"{x:1215,y:833,t:1527271852044};\\\", \\\"{x:1216,y:832,t:1527271853292};\\\", \\\"{x:1217,y:832,t:1527271854419};\\\", \\\"{x:1219,y:832,t:1527271854426};\\\", \\\"{x:1223,y:832,t:1527271854443};\\\", \\\"{x:1231,y:831,t:1527271854458};\\\", \\\"{x:1239,y:830,t:1527271854475};\\\", \\\"{x:1250,y:830,t:1527271854492};\\\", \\\"{x:1258,y:829,t:1527271854510};\\\", \\\"{x:1268,y:827,t:1527271854526};\\\", \\\"{x:1282,y:826,t:1527271854543};\\\", \\\"{x:1293,y:826,t:1527271854560};\\\", \\\"{x:1311,y:826,t:1527271854576};\\\", \\\"{x:1331,y:826,t:1527271854592};\\\", \\\"{x:1347,y:826,t:1527271854609};\\\", \\\"{x:1353,y:826,t:1527271854626};\\\", \\\"{x:1357,y:826,t:1527271854642};\\\", \\\"{x:1358,y:826,t:1527271854659};\\\", \\\"{x:1356,y:826,t:1527271854884};\\\", \\\"{x:1356,y:828,t:1527271854893};\\\", \\\"{x:1354,y:833,t:1527271854910};\\\", \\\"{x:1352,y:838,t:1527271854927};\\\", \\\"{x:1351,y:842,t:1527271854942};\\\", \\\"{x:1351,y:846,t:1527271854959};\\\", \\\"{x:1351,y:850,t:1527271854976};\\\", \\\"{x:1351,y:853,t:1527271854992};\\\", \\\"{x:1351,y:856,t:1527271855009};\\\", \\\"{x:1350,y:858,t:1527271855026};\\\", \\\"{x:1350,y:864,t:1527271855043};\\\", \\\"{x:1350,y:869,t:1527271855059};\\\", \\\"{x:1350,y:873,t:1527271855076};\\\", \\\"{x:1350,y:874,t:1527271855093};\\\", \\\"{x:1350,y:876,t:1527271855109};\\\", \\\"{x:1350,y:877,t:1527271855171};\\\", \\\"{x:1350,y:879,t:1527271855211};\\\", \\\"{x:1348,y:880,t:1527271855252};\\\", \\\"{x:1346,y:880,t:1527271855259};\\\", \\\"{x:1322,y:872,t:1527271855277};\\\", \\\"{x:1289,y:859,t:1527271855293};\\\", \\\"{x:1247,y:847,t:1527271855309};\\\", \\\"{x:1201,y:831,t:1527271855326};\\\", \\\"{x:1151,y:808,t:1527271855343};\\\", \\\"{x:1087,y:787,t:1527271855359};\\\", \\\"{x:1026,y:761,t:1527271855377};\\\", \\\"{x:968,y:726,t:1527271855393};\\\", \\\"{x:925,y:701,t:1527271855409};\\\", \\\"{x:903,y:687,t:1527271855426};\\\", \\\"{x:877,y:669,t:1527271855443};\\\", \\\"{x:859,y:659,t:1527271855460};\\\", \\\"{x:847,y:653,t:1527271855477};\\\", \\\"{x:838,y:647,t:1527271855493};\\\", \\\"{x:829,y:644,t:1527271855510};\\\", \\\"{x:817,y:640,t:1527271855526};\\\", \\\"{x:802,y:636,t:1527271855543};\\\", \\\"{x:788,y:634,t:1527271855560};\\\", \\\"{x:774,y:633,t:1527271855576};\\\", \\\"{x:759,y:630,t:1527271855594};\\\", \\\"{x:741,y:630,t:1527271855611};\\\", \\\"{x:717,y:630,t:1527271855628};\\\", \\\"{x:673,y:629,t:1527271855643};\\\", \\\"{x:646,y:629,t:1527271855660};\\\", \\\"{x:614,y:629,t:1527271855678};\\\", \\\"{x:586,y:629,t:1527271855695};\\\", \\\"{x:557,y:629,t:1527271855710};\\\", \\\"{x:530,y:627,t:1527271855727};\\\", \\\"{x:507,y:627,t:1527271855744};\\\", \\\"{x:498,y:627,t:1527271855761};\\\", \\\"{x:490,y:627,t:1527271855777};\\\", \\\"{x:486,y:627,t:1527271855794};\\\", \\\"{x:483,y:627,t:1527271855811};\\\", \\\"{x:481,y:627,t:1527271855826};\\\", \\\"{x:477,y:627,t:1527271855844};\\\", \\\"{x:473,y:627,t:1527271855861};\\\", \\\"{x:466,y:627,t:1527271855878};\\\", \\\"{x:453,y:625,t:1527271855894};\\\", \\\"{x:432,y:625,t:1527271855911};\\\", \\\"{x:413,y:622,t:1527271855928};\\\", \\\"{x:399,y:619,t:1527271855944};\\\", \\\"{x:383,y:617,t:1527271855961};\\\", \\\"{x:368,y:613,t:1527271855977};\\\", \\\"{x:356,y:609,t:1527271855995};\\\", \\\"{x:333,y:602,t:1527271856011};\\\", \\\"{x:313,y:597,t:1527271856027};\\\", \\\"{x:294,y:592,t:1527271856044};\\\", \\\"{x:273,y:590,t:1527271856061};\\\", \\\"{x:255,y:587,t:1527271856078};\\\", \\\"{x:238,y:585,t:1527271856094};\\\", \\\"{x:222,y:582,t:1527271856111};\\\", \\\"{x:212,y:580,t:1527271856128};\\\", \\\"{x:203,y:576,t:1527271856144};\\\", \\\"{x:195,y:574,t:1527271856162};\\\", \\\"{x:192,y:573,t:1527271856178};\\\", \\\"{x:190,y:572,t:1527271856194};\\\", \\\"{x:189,y:572,t:1527271856211};\\\", \\\"{x:188,y:572,t:1527271856251};\\\", \\\"{x:187,y:572,t:1527271856292};\\\", \\\"{x:186,y:572,t:1527271856299};\\\", \\\"{x:185,y:572,t:1527271856323};\\\", \\\"{x:182,y:572,t:1527271856331};\\\", \\\"{x:180,y:572,t:1527271856347};\\\", \\\"{x:179,y:572,t:1527271856363};\\\", \\\"{x:178,y:572,t:1527271856378};\\\", \\\"{x:177,y:572,t:1527271856394};\\\", \\\"{x:175,y:572,t:1527271856443};\\\", \\\"{x:174,y:575,t:1527271856463};\\\", \\\"{x:172,y:580,t:1527271856478};\\\", \\\"{x:172,y:583,t:1527271856495};\\\", \\\"{x:172,y:587,t:1527271856511};\\\", \\\"{x:172,y:591,t:1527271856528};\\\", \\\"{x:177,y:598,t:1527271856544};\\\", \\\"{x:181,y:602,t:1527271856561};\\\", \\\"{x:183,y:604,t:1527271856578};\\\", \\\"{x:184,y:604,t:1527271856594};\\\", \\\"{x:185,y:605,t:1527271856611};\\\", \\\"{x:186,y:605,t:1527271856683};\\\", \\\"{x:187,y:605,t:1527271856699};\\\", \\\"{x:188,y:605,t:1527271856715};\\\", \\\"{x:190,y:605,t:1527271856729};\\\", \\\"{x:195,y:605,t:1527271856746};\\\", \\\"{x:204,y:605,t:1527271856761};\\\", \\\"{x:226,y:602,t:1527271856778};\\\", \\\"{x:257,y:597,t:1527271856795};\\\", \\\"{x:268,y:593,t:1527271856811};\\\", \\\"{x:273,y:591,t:1527271856829};\\\", \\\"{x:274,y:591,t:1527271856845};\\\", \\\"{x:275,y:590,t:1527271856907};\\\", \\\"{x:275,y:589,t:1527271856914};\\\", \\\"{x:273,y:586,t:1527271856931};\\\", \\\"{x:267,y:584,t:1527271856945};\\\", \\\"{x:251,y:578,t:1527271856962};\\\", \\\"{x:235,y:570,t:1527271856979};\\\", \\\"{x:221,y:564,t:1527271856995};\\\", \\\"{x:213,y:561,t:1527271857011};\\\", \\\"{x:208,y:559,t:1527271857028};\\\", \\\"{x:207,y:559,t:1527271857045};\\\", \\\"{x:204,y:557,t:1527271857062};\\\", \\\"{x:202,y:557,t:1527271857155};\\\", \\\"{x:201,y:557,t:1527271857163};\\\", \\\"{x:199,y:556,t:1527271857178};\\\", \\\"{x:190,y:553,t:1527271857195};\\\", \\\"{x:183,y:552,t:1527271857212};\\\", \\\"{x:176,y:552,t:1527271857228};\\\", \\\"{x:169,y:554,t:1527271857244};\\\", \\\"{x:165,y:554,t:1527271857261};\\\", \\\"{x:162,y:555,t:1527271857277};\\\", \\\"{x:161,y:556,t:1527271857315};\\\", \\\"{x:160,y:556,t:1527271857459};\\\", \\\"{x:159,y:557,t:1527271857507};\\\", \\\"{x:159,y:557,t:1527271857572};\\\", \\\"{x:160,y:558,t:1527271857820};\\\", \\\"{x:162,y:560,t:1527271857829};\\\", \\\"{x:170,y:562,t:1527271857845};\\\", \\\"{x:182,y:567,t:1527271857863};\\\", \\\"{x:206,y:578,t:1527271857879};\\\", \\\"{x:233,y:590,t:1527271857896};\\\", \\\"{x:275,y:610,t:1527271857913};\\\", \\\"{x:338,y:636,t:1527271857930};\\\", \\\"{x:391,y:659,t:1527271857947};\\\", \\\"{x:435,y:679,t:1527271857962};\\\", \\\"{x:470,y:696,t:1527271857978};\\\", \\\"{x:482,y:702,t:1527271857997};\\\", \\\"{x:489,y:706,t:1527271858012};\\\", \\\"{x:499,y:711,t:1527271858029};\\\", \\\"{x:508,y:716,t:1527271858045};\\\", \\\"{x:512,y:717,t:1527271858063};\\\", \\\"{x:513,y:718,t:1527271858079};\\\", \\\"{x:515,y:719,t:1527271858096};\\\", \\\"{x:516,y:720,t:1527271858180};\\\", \\\"{x:516,y:721,t:1527271858212};\\\", \\\"{x:517,y:721,t:1527271859499};\\\" ] }, { \\\"rt\\\": 11698, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 103328, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"K8DJ0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-04 PM-04 PM-03 PM-02 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:720,t:1527271859643};\\\", \\\"{x:519,y:719,t:1527271859763};\\\", \\\"{x:519,y:718,t:1527271859785};\\\", \\\"{x:519,y:717,t:1527271860283};\\\", \\\"{x:520,y:716,t:1527271860322};\\\", \\\"{x:520,y:715,t:1527271860451};\\\", \\\"{x:521,y:714,t:1527271860466};\\\", \\\"{x:522,y:713,t:1527271860483};\\\", \\\"{x:523,y:713,t:1527271860498};\\\", \\\"{x:524,y:712,t:1527271860514};\\\", \\\"{x:526,y:711,t:1527271860531};\\\", \\\"{x:528,y:708,t:1527271860548};\\\", \\\"{x:529,y:708,t:1527271860564};\\\", \\\"{x:529,y:707,t:1527271860587};\\\", \\\"{x:531,y:705,t:1527271860603};\\\", \\\"{x:532,y:703,t:1527271860627};\\\", \\\"{x:532,y:702,t:1527271860635};\\\", \\\"{x:534,y:701,t:1527271860650};\\\", \\\"{x:534,y:700,t:1527271860665};\\\", \\\"{x:537,y:698,t:1527271860681};\\\", \\\"{x:539,y:698,t:1527271860699};\\\", \\\"{x:541,y:696,t:1527271860715};\\\", \\\"{x:542,y:696,t:1527271860739};\\\", \\\"{x:543,y:695,t:1527271860755};\\\", \\\"{x:544,y:695,t:1527271860765};\\\", \\\"{x:545,y:695,t:1527271860782};\\\", \\\"{x:549,y:693,t:1527271860798};\\\", \\\"{x:554,y:691,t:1527271860816};\\\", \\\"{x:558,y:689,t:1527271860831};\\\", \\\"{x:560,y:688,t:1527271860848};\\\", \\\"{x:563,y:687,t:1527271860865};\\\", \\\"{x:565,y:685,t:1527271860881};\\\", \\\"{x:566,y:685,t:1527271860898};\\\", \\\"{x:571,y:684,t:1527271860915};\\\", \\\"{x:575,y:681,t:1527271860932};\\\", \\\"{x:579,y:681,t:1527271860949};\\\", \\\"{x:587,y:678,t:1527271860966};\\\", \\\"{x:611,y:674,t:1527271860981};\\\", \\\"{x:655,y:674,t:1527271860999};\\\", \\\"{x:717,y:674,t:1527271861016};\\\", \\\"{x:783,y:674,t:1527271861032};\\\", \\\"{x:848,y:674,t:1527271861048};\\\", \\\"{x:904,y:671,t:1527271861066};\\\", \\\"{x:944,y:671,t:1527271861081};\\\", \\\"{x:1016,y:671,t:1527271861099};\\\", \\\"{x:1045,y:671,t:1527271861116};\\\", \\\"{x:1064,y:668,t:1527271861132};\\\", \\\"{x:1071,y:661,t:1527271861149};\\\", \\\"{x:1076,y:661,t:1527271862068};\\\", \\\"{x:1106,y:667,t:1527271862083};\\\", \\\"{x:1182,y:683,t:1527271862099};\\\", \\\"{x:1248,y:700,t:1527271862117};\\\", \\\"{x:1315,y:720,t:1527271862133};\\\", \\\"{x:1386,y:749,t:1527271862150};\\\", \\\"{x:1458,y:780,t:1527271862167};\\\", \\\"{x:1514,y:806,t:1527271862183};\\\", \\\"{x:1549,y:825,t:1527271862200};\\\", \\\"{x:1586,y:854,t:1527271862217};\\\", \\\"{x:1644,y:888,t:1527271862233};\\\", \\\"{x:1710,y:929,t:1527271862251};\\\", \\\"{x:1783,y:970,t:1527271862267};\\\", \\\"{x:1862,y:1014,t:1527271862284};\\\", \\\"{x:1894,y:1033,t:1527271862300};\\\", \\\"{x:1918,y:1049,t:1527271862317};\\\", \\\"{x:1919,y:1057,t:1527271862333};\\\", \\\"{x:1919,y:1060,t:1527271862350};\\\", \\\"{x:1915,y:1060,t:1527271862404};\\\", \\\"{x:1903,y:1059,t:1527271862417};\\\", \\\"{x:1881,y:1058,t:1527271862434};\\\", \\\"{x:1852,y:1058,t:1527271862449};\\\", \\\"{x:1825,y:1058,t:1527271862467};\\\", \\\"{x:1777,y:1064,t:1527271862483};\\\", \\\"{x:1750,y:1064,t:1527271862499};\\\", \\\"{x:1732,y:1064,t:1527271862516};\\\", \\\"{x:1729,y:1064,t:1527271862534};\\\", \\\"{x:1728,y:1064,t:1527271862563};\\\", \\\"{x:1728,y:1061,t:1527271862586};\\\", \\\"{x:1728,y:1060,t:1527271862600};\\\", \\\"{x:1727,y:1056,t:1527271862617};\\\", \\\"{x:1723,y:1049,t:1527271862633};\\\", \\\"{x:1716,y:1038,t:1527271862650};\\\", \\\"{x:1706,y:1027,t:1527271862667};\\\", \\\"{x:1689,y:1009,t:1527271862683};\\\", \\\"{x:1674,y:996,t:1527271862699};\\\", \\\"{x:1650,y:983,t:1527271862717};\\\", \\\"{x:1636,y:976,t:1527271862734};\\\", \\\"{x:1626,y:969,t:1527271862750};\\\", \\\"{x:1619,y:966,t:1527271862767};\\\", \\\"{x:1616,y:965,t:1527271862783};\\\", \\\"{x:1615,y:965,t:1527271862924};\\\", \\\"{x:1615,y:966,t:1527271862940};\\\", \\\"{x:1615,y:965,t:1527271863180};\\\", \\\"{x:1615,y:964,t:1527271863204};\\\", \\\"{x:1614,y:964,t:1527271863219};\\\", \\\"{x:1613,y:964,t:1527271863244};\\\", \\\"{x:1613,y:963,t:1527271863643};\\\", \\\"{x:1613,y:962,t:1527271864900};\\\", \\\"{x:1613,y:961,t:1527271864915};\\\", \\\"{x:1613,y:960,t:1527271864931};\\\", \\\"{x:1613,y:959,t:1527271864948};\\\", \\\"{x:1613,y:958,t:1527271864964};\\\", \\\"{x:1613,y:957,t:1527271864972};\\\", \\\"{x:1612,y:954,t:1527271864995};\\\", \\\"{x:1612,y:953,t:1527271865012};\\\", \\\"{x:1611,y:951,t:1527271865028};\\\", \\\"{x:1611,y:949,t:1527271865035};\\\", \\\"{x:1609,y:946,t:1527271865052};\\\", \\\"{x:1609,y:942,t:1527271865069};\\\", \\\"{x:1606,y:937,t:1527271865086};\\\", \\\"{x:1605,y:935,t:1527271865103};\\\", \\\"{x:1605,y:931,t:1527271865119};\\\", \\\"{x:1604,y:927,t:1527271865136};\\\", \\\"{x:1604,y:922,t:1527271865152};\\\", \\\"{x:1602,y:921,t:1527271865169};\\\", \\\"{x:1601,y:918,t:1527271865186};\\\", \\\"{x:1601,y:916,t:1527271865203};\\\", \\\"{x:1600,y:912,t:1527271865219};\\\", \\\"{x:1600,y:907,t:1527271865235};\\\", \\\"{x:1600,y:904,t:1527271865252};\\\", \\\"{x:1599,y:902,t:1527271865270};\\\", \\\"{x:1599,y:901,t:1527271865286};\\\", \\\"{x:1599,y:898,t:1527271865303};\\\", \\\"{x:1599,y:897,t:1527271865319};\\\", \\\"{x:1599,y:895,t:1527271865336};\\\", \\\"{x:1599,y:894,t:1527271865352};\\\", \\\"{x:1599,y:893,t:1527271865369};\\\", \\\"{x:1599,y:892,t:1527271865386};\\\", \\\"{x:1599,y:891,t:1527271865403};\\\", \\\"{x:1599,y:890,t:1527271865419};\\\", \\\"{x:1599,y:889,t:1527271865436};\\\", \\\"{x:1599,y:888,t:1527271865460};\\\", \\\"{x:1599,y:887,t:1527271865469};\\\", \\\"{x:1599,y:886,t:1527271865486};\\\", \\\"{x:1599,y:885,t:1527271865502};\\\", \\\"{x:1599,y:884,t:1527271865519};\\\", \\\"{x:1600,y:883,t:1527271865716};\\\", \\\"{x:1600,y:884,t:1527271865723};\\\", \\\"{x:1600,y:886,t:1527271865737};\\\", \\\"{x:1601,y:894,t:1527271865753};\\\", \\\"{x:1601,y:904,t:1527271865769};\\\", \\\"{x:1601,y:913,t:1527271865786};\\\", \\\"{x:1603,y:933,t:1527271865803};\\\", \\\"{x:1603,y:944,t:1527271865820};\\\", \\\"{x:1603,y:956,t:1527271865836};\\\", \\\"{x:1601,y:962,t:1527271865853};\\\", \\\"{x:1600,y:966,t:1527271865870};\\\", \\\"{x:1600,y:967,t:1527271865891};\\\", \\\"{x:1600,y:968,t:1527271866075};\\\", \\\"{x:1601,y:970,t:1527271866132};\\\", \\\"{x:1602,y:970,t:1527271866180};\\\", \\\"{x:1604,y:970,t:1527271867772};\\\", \\\"{x:1608,y:970,t:1527271867788};\\\", \\\"{x:1611,y:969,t:1527271867804};\\\", \\\"{x:1616,y:966,t:1527271867821};\\\", \\\"{x:1621,y:964,t:1527271867839};\\\", \\\"{x:1624,y:963,t:1527271867854};\\\", \\\"{x:1625,y:962,t:1527271867871};\\\", \\\"{x:1624,y:962,t:1527271868300};\\\", \\\"{x:1623,y:962,t:1527271868307};\\\", \\\"{x:1622,y:962,t:1527271868321};\\\", \\\"{x:1622,y:963,t:1527271868338};\\\", \\\"{x:1621,y:963,t:1527271868355};\\\", \\\"{x:1620,y:963,t:1527271868371};\\\", \\\"{x:1619,y:963,t:1527271868404};\\\", \\\"{x:1618,y:963,t:1527271868508};\\\", \\\"{x:1617,y:964,t:1527271868522};\\\", \\\"{x:1614,y:966,t:1527271868539};\\\", \\\"{x:1608,y:969,t:1527271868555};\\\", \\\"{x:1604,y:969,t:1527271868571};\\\", \\\"{x:1595,y:973,t:1527271868587};\\\", \\\"{x:1586,y:975,t:1527271868604};\\\", \\\"{x:1566,y:978,t:1527271868622};\\\", \\\"{x:1542,y:979,t:1527271868638};\\\", \\\"{x:1521,y:979,t:1527271868655};\\\", \\\"{x:1506,y:979,t:1527271868672};\\\", \\\"{x:1501,y:979,t:1527271868688};\\\", \\\"{x:1499,y:979,t:1527271868705};\\\", \\\"{x:1498,y:979,t:1527271868747};\\\", \\\"{x:1496,y:979,t:1527271868828};\\\", \\\"{x:1494,y:979,t:1527271868996};\\\", \\\"{x:1491,y:979,t:1527271869006};\\\", \\\"{x:1487,y:978,t:1527271869023};\\\", \\\"{x:1483,y:978,t:1527271869039};\\\", \\\"{x:1480,y:977,t:1527271869055};\\\", \\\"{x:1480,y:976,t:1527271869073};\\\", \\\"{x:1479,y:976,t:1527271869089};\\\", \\\"{x:1478,y:976,t:1527271869108};\\\", \\\"{x:1477,y:976,t:1527271869122};\\\", \\\"{x:1451,y:973,t:1527271869139};\\\", \\\"{x:1420,y:968,t:1527271869155};\\\", \\\"{x:1382,y:961,t:1527271869173};\\\", \\\"{x:1337,y:954,t:1527271869190};\\\", \\\"{x:1276,y:939,t:1527271869205};\\\", \\\"{x:1218,y:922,t:1527271869223};\\\", \\\"{x:1167,y:904,t:1527271869240};\\\", \\\"{x:1120,y:884,t:1527271869255};\\\", \\\"{x:1075,y:864,t:1527271869273};\\\", \\\"{x:1035,y:842,t:1527271869289};\\\", \\\"{x:1000,y:822,t:1527271869305};\\\", \\\"{x:963,y:795,t:1527271869323};\\\", \\\"{x:905,y:753,t:1527271869339};\\\", \\\"{x:867,y:728,t:1527271869355};\\\", \\\"{x:851,y:715,t:1527271869372};\\\", \\\"{x:839,y:704,t:1527271869389};\\\", \\\"{x:833,y:696,t:1527271869406};\\\", \\\"{x:831,y:692,t:1527271869422};\\\", \\\"{x:829,y:690,t:1527271869441};\\\", \\\"{x:829,y:689,t:1527271869455};\\\", \\\"{x:828,y:689,t:1527271869475};\\\", \\\"{x:828,y:687,t:1527271869498};\\\", \\\"{x:828,y:684,t:1527271869506};\\\", \\\"{x:827,y:679,t:1527271869521};\\\", \\\"{x:827,y:664,t:1527271869539};\\\", \\\"{x:827,y:654,t:1527271869555};\\\", \\\"{x:826,y:640,t:1527271869571};\\\", \\\"{x:823,y:623,t:1527271869588};\\\", \\\"{x:818,y:602,t:1527271869606};\\\", \\\"{x:813,y:587,t:1527271869622};\\\", \\\"{x:805,y:571,t:1527271869639};\\\", \\\"{x:798,y:562,t:1527271869654};\\\", \\\"{x:792,y:558,t:1527271869671};\\\", \\\"{x:780,y:553,t:1527271869687};\\\", \\\"{x:773,y:551,t:1527271869704};\\\", \\\"{x:762,y:551,t:1527271869721};\\\", \\\"{x:749,y:553,t:1527271869737};\\\", \\\"{x:730,y:559,t:1527271869753};\\\", \\\"{x:709,y:569,t:1527271869772};\\\", \\\"{x:703,y:575,t:1527271869787};\\\", \\\"{x:694,y:584,t:1527271869807};\\\", \\\"{x:683,y:593,t:1527271869822};\\\", \\\"{x:678,y:597,t:1527271869838};\\\", \\\"{x:673,y:601,t:1527271869856};\\\", \\\"{x:668,y:605,t:1527271869873};\\\", \\\"{x:661,y:610,t:1527271869889};\\\", \\\"{x:652,y:613,t:1527271869907};\\\", \\\"{x:634,y:616,t:1527271869923};\\\", \\\"{x:622,y:616,t:1527271869939};\\\", \\\"{x:612,y:616,t:1527271869955};\\\", \\\"{x:607,y:616,t:1527271869973};\\\", \\\"{x:605,y:616,t:1527271869990};\\\", \\\"{x:603,y:616,t:1527271870005};\\\", \\\"{x:603,y:615,t:1527271870147};\\\", \\\"{x:603,y:614,t:1527271870156};\\\", \\\"{x:603,y:612,t:1527271870181};\\\", \\\"{x:603,y:611,t:1527271870250};\\\", \\\"{x:604,y:611,t:1527271870267};\\\", \\\"{x:605,y:611,t:1527271870274};\\\", \\\"{x:605,y:610,t:1527271870290};\\\", \\\"{x:606,y:609,t:1527271870306};\\\", \\\"{x:606,y:608,t:1527271870380};\\\", \\\"{x:604,y:609,t:1527271870668};\\\", \\\"{x:599,y:610,t:1527271870675};\\\", \\\"{x:595,y:612,t:1527271870690};\\\", \\\"{x:582,y:620,t:1527271870708};\\\", \\\"{x:577,y:622,t:1527271870723};\\\", \\\"{x:572,y:626,t:1527271870739};\\\", \\\"{x:567,y:629,t:1527271870757};\\\", \\\"{x:563,y:632,t:1527271870773};\\\", \\\"{x:559,y:635,t:1527271870790};\\\", \\\"{x:556,y:639,t:1527271870807};\\\", \\\"{x:550,y:645,t:1527271870823};\\\", \\\"{x:542,y:654,t:1527271870841};\\\", \\\"{x:535,y:662,t:1527271870857};\\\", \\\"{x:527,y:675,t:1527271870874};\\\", \\\"{x:521,y:689,t:1527271870890};\\\", \\\"{x:515,y:705,t:1527271870908};\\\", \\\"{x:514,y:711,t:1527271870924};\\\", \\\"{x:513,y:714,t:1527271870939};\\\", \\\"{x:513,y:715,t:1527271871084};\\\", \\\"{x:513,y:716,t:1527271871108};\\\", \\\"{x:514,y:717,t:1527271871147};\\\" ] }, { \\\"rt\\\": 96228, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 200880, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"K8DJ0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -O -O -O -12 PM-01 PM-07 PM-07 PM-F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:515,y:717,t:1527271872691};\\\", \\\"{x:518,y:717,t:1527271872707};\\\", \\\"{x:519,y:716,t:1527271872725};\\\", \\\"{x:521,y:715,t:1527271872741};\\\", \\\"{x:523,y:711,t:1527271872768};\\\", \\\"{x:523,y:710,t:1527271872775};\\\", \\\"{x:525,y:707,t:1527271872791};\\\", \\\"{x:526,y:702,t:1527271872808};\\\", \\\"{x:529,y:700,t:1527271872825};\\\", \\\"{x:531,y:695,t:1527271872841};\\\", \\\"{x:533,y:693,t:1527271872859};\\\", \\\"{x:535,y:691,t:1527271872875};\\\", \\\"{x:536,y:688,t:1527271872892};\\\", \\\"{x:538,y:685,t:1527271872909};\\\", \\\"{x:539,y:683,t:1527271872924};\\\", \\\"{x:540,y:680,t:1527271872942};\\\", \\\"{x:555,y:651,t:1527271873038};\\\", \\\"{x:556,y:648,t:1527271873045};\\\", \\\"{x:558,y:645,t:1527271873059};\\\", \\\"{x:558,y:644,t:1527271873074};\\\", \\\"{x:559,y:644,t:1527271873091};\\\", \\\"{x:559,y:642,t:1527271873108};\\\", \\\"{x:559,y:641,t:1527271874044};\\\", \\\"{x:561,y:639,t:1527271874316};\\\", \\\"{x:561,y:638,t:1527271874331};\\\", \\\"{x:561,y:637,t:1527271874371};\\\", \\\"{x:561,y:636,t:1527271874403};\\\", \\\"{x:562,y:636,t:1527271874419};\\\", \\\"{x:562,y:634,t:1527271875099};\\\", \\\"{x:563,y:634,t:1527271876604};\\\", \\\"{x:564,y:634,t:1527271876611};\\\", \\\"{x:565,y:633,t:1527271876645};\\\", \\\"{x:566,y:632,t:1527271876666};\\\", \\\"{x:567,y:631,t:1527271876979};\\\", \\\"{x:568,y:631,t:1527271877018};\\\", \\\"{x:569,y:629,t:1527271877058};\\\", \\\"{x:570,y:629,t:1527271877083};\\\", \\\"{x:571,y:628,t:1527271877114};\\\", \\\"{x:573,y:628,t:1527271879348};\\\", \\\"{x:574,y:628,t:1527271879371};\\\", \\\"{x:577,y:624,t:1527271879571};\\\", \\\"{x:621,y:616,t:1527271879580};\\\", \\\"{x:718,y:601,t:1527271879596};\\\", \\\"{x:776,y:584,t:1527271879632};\\\", \\\"{x:777,y:582,t:1527271879647};\\\", \\\"{x:778,y:582,t:1527271879664};\\\", \\\"{x:779,y:581,t:1527271879681};\\\", \\\"{x:779,y:580,t:1527271879697};\\\", \\\"{x:779,y:576,t:1527271879714};\\\", \\\"{x:779,y:571,t:1527271879731};\\\", \\\"{x:779,y:565,t:1527271879747};\\\", \\\"{x:778,y:560,t:1527271879764};\\\", \\\"{x:778,y:552,t:1527271879782};\\\", \\\"{x:778,y:543,t:1527271879798};\\\", \\\"{x:778,y:535,t:1527271879813};\\\", \\\"{x:781,y:525,t:1527271879831};\\\", \\\"{x:787,y:516,t:1527271879847};\\\", \\\"{x:792,y:503,t:1527271879864};\\\", \\\"{x:799,y:488,t:1527271879881};\\\", \\\"{x:807,y:474,t:1527271879898};\\\", \\\"{x:822,y:458,t:1527271879914};\\\", \\\"{x:854,y:431,t:1527271879931};\\\", \\\"{x:878,y:417,t:1527271879948};\\\", \\\"{x:900,y:402,t:1527271879965};\\\", \\\"{x:920,y:391,t:1527271879981};\\\", \\\"{x:939,y:381,t:1527271879998};\\\", \\\"{x:960,y:371,t:1527271880015};\\\", \\\"{x:987,y:361,t:1527271880031};\\\", \\\"{x:1023,y:353,t:1527271880048};\\\", \\\"{x:1060,y:348,t:1527271880065};\\\", \\\"{x:1088,y:342,t:1527271880082};\\\", \\\"{x:1114,y:340,t:1527271880099};\\\", \\\"{x:1139,y:336,t:1527271880115};\\\", \\\"{x:1146,y:336,t:1527271880132};\\\", \\\"{x:1149,y:336,t:1527271880148};\\\", \\\"{x:1153,y:336,t:1527271880165};\\\", \\\"{x:1155,y:337,t:1527271880182};\\\", \\\"{x:1159,y:338,t:1527271880200};\\\", \\\"{x:1162,y:341,t:1527271880215};\\\", \\\"{x:1165,y:341,t:1527271880233};\\\", \\\"{x:1166,y:343,t:1527271880249};\\\", \\\"{x:1170,y:348,t:1527271880267};\\\", \\\"{x:1173,y:351,t:1527271880283};\\\", \\\"{x:1183,y:361,t:1527271880299};\\\", \\\"{x:1196,y:371,t:1527271880317};\\\", \\\"{x:1212,y:385,t:1527271880333};\\\", \\\"{x:1231,y:398,t:1527271880349};\\\", \\\"{x:1253,y:412,t:1527271880367};\\\", \\\"{x:1269,y:420,t:1527271880384};\\\", \\\"{x:1283,y:429,t:1527271880400};\\\", \\\"{x:1296,y:437,t:1527271880417};\\\", \\\"{x:1309,y:444,t:1527271880434};\\\", \\\"{x:1311,y:447,t:1527271880450};\\\", \\\"{x:1313,y:448,t:1527271880467};\\\", \\\"{x:1314,y:449,t:1527271880484};\\\", \\\"{x:1316,y:451,t:1527271880501};\\\", \\\"{x:1316,y:453,t:1527271880517};\\\", \\\"{x:1316,y:455,t:1527271880547};\\\", \\\"{x:1317,y:455,t:1527271880555};\\\", \\\"{x:1317,y:456,t:1527271880568};\\\", \\\"{x:1317,y:458,t:1527271880583};\\\", \\\"{x:1317,y:461,t:1527271880600};\\\", \\\"{x:1317,y:463,t:1527271880617};\\\", \\\"{x:1317,y:467,t:1527271880633};\\\", \\\"{x:1317,y:472,t:1527271880651};\\\", \\\"{x:1317,y:479,t:1527271880666};\\\", \\\"{x:1317,y:485,t:1527271880684};\\\", \\\"{x:1317,y:491,t:1527271880702};\\\", \\\"{x:1317,y:496,t:1527271880717};\\\", \\\"{x:1318,y:501,t:1527271880734};\\\", \\\"{x:1319,y:506,t:1527271880750};\\\", \\\"{x:1320,y:509,t:1527271880768};\\\", \\\"{x:1321,y:511,t:1527271880784};\\\", \\\"{x:1321,y:512,t:1527271880801};\\\", \\\"{x:1321,y:511,t:1527271881435};\\\", \\\"{x:1319,y:510,t:1527271881454};\\\", \\\"{x:1319,y:509,t:1527271881469};\\\", \\\"{x:1317,y:508,t:1527271881487};\\\", \\\"{x:1316,y:507,t:1527271881504};\\\", \\\"{x:1315,y:507,t:1527271881524};\\\", \\\"{x:1314,y:506,t:1527271881555};\\\", \\\"{x:1314,y:505,t:1527271881572};\\\", \\\"{x:1314,y:504,t:1527271881595};\\\", \\\"{x:1314,y:503,t:1527271881763};\\\", \\\"{x:1314,y:502,t:1527271881860};\\\", \\\"{x:1314,y:501,t:1527271881923};\\\", \\\"{x:1314,y:500,t:1527271882028};\\\", \\\"{x:1314,y:499,t:1527271882059};\\\", \\\"{x:1314,y:498,t:1527271882107};\\\", \\\"{x:1314,y:497,t:1527271882140};\\\", \\\"{x:1314,y:496,t:1527271882164};\\\", \\\"{x:1314,y:495,t:1527271882187};\\\", \\\"{x:1314,y:496,t:1527271883251};\\\", \\\"{x:1314,y:499,t:1527271883259};\\\", \\\"{x:1314,y:504,t:1527271883276};\\\", \\\"{x:1316,y:510,t:1527271883293};\\\", \\\"{x:1316,y:516,t:1527271883309};\\\", \\\"{x:1316,y:522,t:1527271883327};\\\", \\\"{x:1316,y:529,t:1527271883343};\\\", \\\"{x:1316,y:534,t:1527271883360};\\\", \\\"{x:1316,y:541,t:1527271883377};\\\", \\\"{x:1316,y:545,t:1527271883393};\\\", \\\"{x:1316,y:549,t:1527271883410};\\\", \\\"{x:1316,y:554,t:1527271883427};\\\", \\\"{x:1316,y:558,t:1527271883443};\\\", \\\"{x:1316,y:561,t:1527271883460};\\\", \\\"{x:1316,y:566,t:1527271883477};\\\", \\\"{x:1316,y:574,t:1527271883494};\\\", \\\"{x:1316,y:582,t:1527271883510};\\\", \\\"{x:1316,y:593,t:1527271883527};\\\", \\\"{x:1316,y:605,t:1527271883544};\\\", \\\"{x:1316,y:614,t:1527271883561};\\\", \\\"{x:1316,y:628,t:1527271883577};\\\", \\\"{x:1316,y:640,t:1527271883595};\\\", \\\"{x:1316,y:657,t:1527271883611};\\\", \\\"{x:1318,y:667,t:1527271883627};\\\", \\\"{x:1318,y:673,t:1527271883644};\\\", \\\"{x:1318,y:681,t:1527271883661};\\\", \\\"{x:1318,y:688,t:1527271883678};\\\", \\\"{x:1318,y:694,t:1527271883694};\\\", \\\"{x:1318,y:700,t:1527271883711};\\\", \\\"{x:1318,y:706,t:1527271883728};\\\", \\\"{x:1318,y:710,t:1527271883745};\\\", \\\"{x:1318,y:716,t:1527271883761};\\\", \\\"{x:1318,y:720,t:1527271883778};\\\", \\\"{x:1319,y:725,t:1527271883795};\\\", \\\"{x:1319,y:728,t:1527271883811};\\\", \\\"{x:1320,y:735,t:1527271883828};\\\", \\\"{x:1320,y:739,t:1527271883845};\\\", \\\"{x:1320,y:744,t:1527271883862};\\\", \\\"{x:1321,y:749,t:1527271883878};\\\", \\\"{x:1321,y:754,t:1527271883895};\\\", \\\"{x:1321,y:758,t:1527271883912};\\\", \\\"{x:1321,y:762,t:1527271883928};\\\", \\\"{x:1321,y:768,t:1527271883945};\\\", \\\"{x:1321,y:774,t:1527271883962};\\\", \\\"{x:1321,y:782,t:1527271883979};\\\", \\\"{x:1321,y:787,t:1527271883995};\\\", \\\"{x:1321,y:791,t:1527271884012};\\\", \\\"{x:1321,y:793,t:1527271884029};\\\", \\\"{x:1321,y:795,t:1527271884046};\\\", \\\"{x:1322,y:796,t:1527271884062};\\\", \\\"{x:1322,y:798,t:1527271884079};\\\", \\\"{x:1322,y:800,t:1527271884096};\\\", \\\"{x:1322,y:801,t:1527271884112};\\\", \\\"{x:1322,y:806,t:1527271884129};\\\", \\\"{x:1320,y:814,t:1527271884146};\\\", \\\"{x:1316,y:820,t:1527271884163};\\\", \\\"{x:1315,y:825,t:1527271884179};\\\", \\\"{x:1314,y:827,t:1527271884195};\\\", \\\"{x:1314,y:828,t:1527271884306};\\\", \\\"{x:1314,y:824,t:1527271884452};\\\", \\\"{x:1314,y:814,t:1527271884464};\\\", \\\"{x:1314,y:796,t:1527271884480};\\\", \\\"{x:1314,y:750,t:1527271884497};\\\", \\\"{x:1307,y:694,t:1527271884514};\\\", \\\"{x:1304,y:651,t:1527271884530};\\\", \\\"{x:1304,y:600,t:1527271884547};\\\", \\\"{x:1304,y:561,t:1527271884564};\\\", \\\"{x:1304,y:539,t:1527271884581};\\\", \\\"{x:1304,y:526,t:1527271884597};\\\", \\\"{x:1304,y:521,t:1527271884614};\\\", \\\"{x:1304,y:520,t:1527271884708};\\\", \\\"{x:1304,y:518,t:1527271884715};\\\", \\\"{x:1305,y:515,t:1527271884731};\\\", \\\"{x:1306,y:511,t:1527271884748};\\\", \\\"{x:1306,y:508,t:1527271884764};\\\", \\\"{x:1306,y:507,t:1527271884780};\\\", \\\"{x:1306,y:506,t:1527271884843};\\\", \\\"{x:1306,y:508,t:1527271885132};\\\", \\\"{x:1306,y:521,t:1527271885149};\\\", \\\"{x:1303,y:534,t:1527271885166};\\\", \\\"{x:1303,y:539,t:1527271885183};\\\", \\\"{x:1303,y:542,t:1527271885198};\\\", \\\"{x:1303,y:546,t:1527271885216};\\\", \\\"{x:1301,y:547,t:1527271885232};\\\", \\\"{x:1301,y:548,t:1527271885248};\\\", \\\"{x:1301,y:549,t:1527271885266};\\\", \\\"{x:1301,y:550,t:1527271885282};\\\", \\\"{x:1301,y:551,t:1527271885299};\\\", \\\"{x:1301,y:553,t:1527271885315};\\\", \\\"{x:1301,y:555,t:1527271885332};\\\", \\\"{x:1302,y:559,t:1527271885349};\\\", \\\"{x:1303,y:563,t:1527271885367};\\\", \\\"{x:1304,y:566,t:1527271885382};\\\", \\\"{x:1305,y:570,t:1527271885399};\\\", \\\"{x:1308,y:579,t:1527271885416};\\\", \\\"{x:1309,y:582,t:1527271885432};\\\", \\\"{x:1310,y:586,t:1527271885450};\\\", \\\"{x:1311,y:589,t:1527271885467};\\\", \\\"{x:1312,y:590,t:1527271885483};\\\", \\\"{x:1312,y:589,t:1527271885580};\\\", \\\"{x:1312,y:585,t:1527271885587};\\\", \\\"{x:1313,y:578,t:1527271885601};\\\", \\\"{x:1317,y:561,t:1527271885617};\\\", \\\"{x:1319,y:543,t:1527271885634};\\\", \\\"{x:1322,y:518,t:1527271885651};\\\", \\\"{x:1322,y:507,t:1527271885667};\\\", \\\"{x:1322,y:498,t:1527271885684};\\\", \\\"{x:1322,y:492,t:1527271885701};\\\", \\\"{x:1322,y:489,t:1527271885718};\\\", \\\"{x:1323,y:487,t:1527271885734};\\\", \\\"{x:1323,y:486,t:1527271885755};\\\", \\\"{x:1323,y:485,t:1527271885883};\\\", \\\"{x:1323,y:488,t:1527271886172};\\\", \\\"{x:1323,y:491,t:1527271886187};\\\", \\\"{x:1322,y:498,t:1527271886204};\\\", \\\"{x:1322,y:503,t:1527271886219};\\\", \\\"{x:1320,y:513,t:1527271886236};\\\", \\\"{x:1320,y:520,t:1527271886253};\\\", \\\"{x:1319,y:527,t:1527271886269};\\\", \\\"{x:1317,y:533,t:1527271886286};\\\", \\\"{x:1317,y:537,t:1527271886303};\\\", \\\"{x:1317,y:543,t:1527271886320};\\\", \\\"{x:1317,y:553,t:1527271886336};\\\", \\\"{x:1317,y:560,t:1527271886353};\\\", \\\"{x:1317,y:569,t:1527271886370};\\\", \\\"{x:1317,y:585,t:1527271886386};\\\", \\\"{x:1317,y:599,t:1527271886402};\\\", \\\"{x:1317,y:618,t:1527271886419};\\\", \\\"{x:1317,y:639,t:1527271886436};\\\", \\\"{x:1317,y:656,t:1527271886452};\\\", \\\"{x:1317,y:673,t:1527271886469};\\\", \\\"{x:1320,y:688,t:1527271886487};\\\", \\\"{x:1323,y:701,t:1527271886503};\\\", \\\"{x:1327,y:713,t:1527271886519};\\\", \\\"{x:1330,y:726,t:1527271886536};\\\", \\\"{x:1334,y:741,t:1527271886553};\\\", \\\"{x:1339,y:758,t:1527271886569};\\\", \\\"{x:1342,y:779,t:1527271886586};\\\", \\\"{x:1344,y:789,t:1527271886603};\\\", \\\"{x:1344,y:794,t:1527271886620};\\\", \\\"{x:1344,y:799,t:1527271886636};\\\", \\\"{x:1344,y:801,t:1527271886654};\\\", \\\"{x:1344,y:803,t:1527271886670};\\\", \\\"{x:1344,y:806,t:1527271886687};\\\", \\\"{x:1344,y:810,t:1527271886703};\\\", \\\"{x:1343,y:817,t:1527271886720};\\\", \\\"{x:1342,y:826,t:1527271886737};\\\", \\\"{x:1341,y:831,t:1527271886753};\\\", \\\"{x:1338,y:838,t:1527271886770};\\\", \\\"{x:1338,y:844,t:1527271886787};\\\", \\\"{x:1338,y:851,t:1527271886804};\\\", \\\"{x:1338,y:858,t:1527271886821};\\\", \\\"{x:1338,y:861,t:1527271886837};\\\", \\\"{x:1338,y:864,t:1527271886855};\\\", \\\"{x:1338,y:867,t:1527271886871};\\\", \\\"{x:1339,y:871,t:1527271886888};\\\", \\\"{x:1342,y:880,t:1527271886905};\\\", \\\"{x:1343,y:892,t:1527271886922};\\\", \\\"{x:1347,y:905,t:1527271886937};\\\", \\\"{x:1350,y:925,t:1527271886954};\\\", \\\"{x:1352,y:933,t:1527271886971};\\\", \\\"{x:1352,y:936,t:1527271886988};\\\", \\\"{x:1351,y:938,t:1527271887018};\\\", \\\"{x:1347,y:940,t:1527271887075};\\\", \\\"{x:1346,y:940,t:1527271887088};\\\", \\\"{x:1339,y:946,t:1527271887106};\\\", \\\"{x:1333,y:949,t:1527271887121};\\\", \\\"{x:1332,y:949,t:1527271887138};\\\", \\\"{x:1331,y:950,t:1527271887260};\\\", \\\"{x:1331,y:951,t:1527271887283};\\\", \\\"{x:1331,y:952,t:1527271887299};\\\", \\\"{x:1331,y:953,t:1527271887315};\\\", \\\"{x:1331,y:955,t:1527271887331};\\\", \\\"{x:1331,y:958,t:1527271887339};\\\", \\\"{x:1330,y:963,t:1527271887356};\\\", \\\"{x:1327,y:968,t:1527271887372};\\\", \\\"{x:1325,y:970,t:1527271887389};\\\", \\\"{x:1324,y:972,t:1527271887406};\\\", \\\"{x:1323,y:973,t:1527271887423};\\\", \\\"{x:1322,y:975,t:1527271887483};\\\", \\\"{x:1321,y:976,t:1527271887490};\\\", \\\"{x:1318,y:981,t:1527271887507};\\\", \\\"{x:1316,y:984,t:1527271887523};\\\", \\\"{x:1315,y:985,t:1527271887540};\\\", \\\"{x:1324,y:985,t:1527271901291};\\\", \\\"{x:1332,y:984,t:1527271901303};\\\", \\\"{x:1345,y:982,t:1527271901319};\\\", \\\"{x:1366,y:981,t:1527271901336};\\\", \\\"{x:1395,y:976,t:1527271901352};\\\", \\\"{x:1433,y:962,t:1527271901370};\\\", \\\"{x:1461,y:950,t:1527271901386};\\\", \\\"{x:1499,y:935,t:1527271901402};\\\", \\\"{x:1552,y:907,t:1527271901419};\\\", \\\"{x:1591,y:889,t:1527271901437};\\\", \\\"{x:1620,y:877,t:1527271901454};\\\", \\\"{x:1643,y:868,t:1527271901469};\\\", \\\"{x:1664,y:859,t:1527271901486};\\\", \\\"{x:1681,y:853,t:1527271901503};\\\", \\\"{x:1697,y:849,t:1527271901519};\\\", \\\"{x:1712,y:847,t:1527271901536};\\\", \\\"{x:1726,y:846,t:1527271901554};\\\", \\\"{x:1737,y:846,t:1527271901570};\\\", \\\"{x:1746,y:846,t:1527271901586};\\\", \\\"{x:1753,y:846,t:1527271901603};\\\", \\\"{x:1755,y:846,t:1527271901652};\\\", \\\"{x:1756,y:846,t:1527271901675};\\\", \\\"{x:1758,y:846,t:1527271901688};\\\", \\\"{x:1759,y:846,t:1527271901703};\\\", \\\"{x:1762,y:851,t:1527271901720};\\\", \\\"{x:1764,y:856,t:1527271901738};\\\", \\\"{x:1772,y:869,t:1527271901754};\\\", \\\"{x:1778,y:884,t:1527271901770};\\\", \\\"{x:1788,y:912,t:1527271901787};\\\", \\\"{x:1791,y:929,t:1527271901804};\\\", \\\"{x:1794,y:945,t:1527271901821};\\\", \\\"{x:1798,y:959,t:1527271901837};\\\", \\\"{x:1802,y:972,t:1527271901855};\\\", \\\"{x:1803,y:981,t:1527271901871};\\\", \\\"{x:1803,y:984,t:1527271901887};\\\", \\\"{x:1803,y:986,t:1527271901905};\\\", \\\"{x:1799,y:983,t:1527271902203};\\\", \\\"{x:1797,y:982,t:1527271902219};\\\", \\\"{x:1796,y:981,t:1527271902227};\\\", \\\"{x:1794,y:980,t:1527271902243};\\\", \\\"{x:1794,y:979,t:1527271902259};\\\", \\\"{x:1793,y:979,t:1527271902299};\\\", \\\"{x:1792,y:978,t:1527271902355};\\\", \\\"{x:1791,y:978,t:1527271902372};\\\", \\\"{x:1790,y:977,t:1527271902411};\\\", \\\"{x:1789,y:977,t:1527271902443};\\\", \\\"{x:1789,y:976,t:1527271902456};\\\", \\\"{x:1788,y:976,t:1527271902473};\\\", \\\"{x:1786,y:975,t:1527271902489};\\\", \\\"{x:1785,y:974,t:1527271902506};\\\", \\\"{x:1784,y:973,t:1527271902523};\\\", \\\"{x:1783,y:973,t:1527271902540};\\\", \\\"{x:1783,y:972,t:1527271902579};\\\", \\\"{x:1782,y:971,t:1527271902603};\\\", \\\"{x:1781,y:970,t:1527271902634};\\\", \\\"{x:1780,y:970,t:1527271902643};\\\", \\\"{x:1780,y:968,t:1527271902659};\\\", \\\"{x:1778,y:966,t:1527271902673};\\\", \\\"{x:1778,y:963,t:1527271902690};\\\", \\\"{x:1777,y:958,t:1527271902706};\\\", \\\"{x:1775,y:956,t:1527271902723};\\\", \\\"{x:1774,y:954,t:1527271902740};\\\", \\\"{x:1774,y:950,t:1527271902757};\\\", \\\"{x:1774,y:949,t:1527271902774};\\\", \\\"{x:1773,y:947,t:1527271902790};\\\", \\\"{x:1773,y:945,t:1527271902807};\\\", \\\"{x:1772,y:944,t:1527271902824};\\\", \\\"{x:1772,y:943,t:1527271902840};\\\", \\\"{x:1772,y:942,t:1527271902858};\\\", \\\"{x:1772,y:941,t:1527271902874};\\\", \\\"{x:1771,y:941,t:1527271902906};\\\", \\\"{x:1771,y:940,t:1527271902955};\\\", \\\"{x:1771,y:939,t:1527271902970};\\\", \\\"{x:1771,y:938,t:1527271902979};\\\", \\\"{x:1771,y:937,t:1527271902991};\\\", \\\"{x:1771,y:935,t:1527271903008};\\\", \\\"{x:1770,y:932,t:1527271903024};\\\", \\\"{x:1770,y:928,t:1527271903042};\\\", \\\"{x:1770,y:924,t:1527271903058};\\\", \\\"{x:1770,y:922,t:1527271903074};\\\", \\\"{x:1769,y:920,t:1527271903091};\\\", \\\"{x:1769,y:919,t:1527271903108};\\\", \\\"{x:1769,y:918,t:1527271903124};\\\", \\\"{x:1769,y:917,t:1527271903141};\\\", \\\"{x:1769,y:915,t:1527271903158};\\\", \\\"{x:1769,y:913,t:1527271903176};\\\", \\\"{x:1769,y:912,t:1527271903193};\\\", \\\"{x:1769,y:910,t:1527271903208};\\\", \\\"{x:1769,y:909,t:1527271903225};\\\", \\\"{x:1769,y:905,t:1527271903242};\\\", \\\"{x:1769,y:904,t:1527271903259};\\\", \\\"{x:1769,y:900,t:1527271903275};\\\", \\\"{x:1769,y:898,t:1527271903292};\\\", \\\"{x:1769,y:896,t:1527271903309};\\\", \\\"{x:1769,y:895,t:1527271903331};\\\", \\\"{x:1769,y:894,t:1527271903343};\\\", \\\"{x:1769,y:893,t:1527271903359};\\\", \\\"{x:1769,y:892,t:1527271903379};\\\", \\\"{x:1769,y:891,t:1527271903395};\\\", \\\"{x:1769,y:890,t:1527271903443};\\\", \\\"{x:1769,y:889,t:1527271903523};\\\", \\\"{x:1769,y:888,t:1527271903539};\\\", \\\"{x:1769,y:887,t:1527271903547};\\\", \\\"{x:1769,y:885,t:1527271903570};\\\", \\\"{x:1770,y:884,t:1527271903579};\\\", \\\"{x:1770,y:882,t:1527271903611};\\\", \\\"{x:1771,y:884,t:1527271903907};\\\", \\\"{x:1771,y:887,t:1527271903915};\\\", \\\"{x:1771,y:889,t:1527271903928};\\\", \\\"{x:1771,y:896,t:1527271903945};\\\", \\\"{x:1771,y:903,t:1527271903961};\\\", \\\"{x:1771,y:916,t:1527271903978};\\\", \\\"{x:1771,y:921,t:1527271903994};\\\", \\\"{x:1771,y:925,t:1527271904011};\\\", \\\"{x:1771,y:928,t:1527271904027};\\\", \\\"{x:1771,y:930,t:1527271904043};\\\", \\\"{x:1771,y:932,t:1527271904060};\\\", \\\"{x:1771,y:933,t:1527271904077};\\\", \\\"{x:1771,y:934,t:1527271904094};\\\", \\\"{x:1771,y:935,t:1527271904111};\\\", \\\"{x:1771,y:936,t:1527271904128};\\\", \\\"{x:1771,y:937,t:1527271904145};\\\", \\\"{x:1771,y:939,t:1527271904161};\\\", \\\"{x:1772,y:943,t:1527271904178};\\\", \\\"{x:1773,y:946,t:1527271904195};\\\", \\\"{x:1775,y:949,t:1527271904212};\\\", \\\"{x:1776,y:950,t:1527271904228};\\\", \\\"{x:1777,y:952,t:1527271904245};\\\", \\\"{x:1778,y:953,t:1527271904261};\\\", \\\"{x:1779,y:955,t:1527271904278};\\\", \\\"{x:1781,y:957,t:1527271904323};\\\", \\\"{x:1781,y:958,t:1527271904338};\\\", \\\"{x:1782,y:959,t:1527271904354};\\\", \\\"{x:1783,y:960,t:1527271904362};\\\", \\\"{x:1785,y:963,t:1527271904378};\\\", \\\"{x:1786,y:965,t:1527271904397};\\\", \\\"{x:1786,y:966,t:1527271904419};\\\", \\\"{x:1786,y:967,t:1527271904429};\\\", \\\"{x:1785,y:967,t:1527271905475};\\\", \\\"{x:1783,y:967,t:1527271905795};\\\", \\\"{x:1782,y:967,t:1527271905803};\\\", \\\"{x:1781,y:967,t:1527271905883};\\\", \\\"{x:1780,y:967,t:1527271905907};\\\", \\\"{x:1779,y:967,t:1527271905938};\\\", \\\"{x:1778,y:967,t:1527271912857};\\\", \\\"{x:1755,y:954,t:1527271966934};\\\", \\\"{x:1710,y:922,t:1527271966940};\\\", \\\"{x:1666,y:889,t:1527271966955};\\\", \\\"{x:1572,y:834,t:1527271966972};\\\", \\\"{x:1465,y:782,t:1527271966988};\\\", \\\"{x:1424,y:765,t:1527271967006};\\\", \\\"{x:1403,y:757,t:1527271967022};\\\", \\\"{x:1385,y:749,t:1527271967039};\\\", \\\"{x:1382,y:748,t:1527271967056};\\\", \\\"{x:1379,y:747,t:1527271967071};\\\", \\\"{x:1378,y:747,t:1527271967125};\\\", \\\"{x:1375,y:747,t:1527271967139};\\\", \\\"{x:1356,y:747,t:1527271967156};\\\", \\\"{x:1325,y:747,t:1527271967172};\\\", \\\"{x:1233,y:747,t:1527271967189};\\\", \\\"{x:1137,y:754,t:1527271967206};\\\", \\\"{x:1018,y:773,t:1527271967222};\\\", \\\"{x:904,y:787,t:1527271967239};\\\", \\\"{x:777,y:803,t:1527271967255};\\\", \\\"{x:661,y:816,t:1527271967272};\\\", \\\"{x:556,y:828,t:1527271967288};\\\", \\\"{x:462,y:843,t:1527271967306};\\\", \\\"{x:395,y:852,t:1527271967322};\\\", \\\"{x:361,y:852,t:1527271967338};\\\", \\\"{x:342,y:851,t:1527271967356};\\\", \\\"{x:335,y:849,t:1527271967372};\\\", \\\"{x:334,y:846,t:1527271967388};\\\", \\\"{x:334,y:839,t:1527271967406};\\\", \\\"{x:336,y:829,t:1527271967422};\\\", \\\"{x:342,y:810,t:1527271967438};\\\", \\\"{x:353,y:790,t:1527271967455};\\\", \\\"{x:368,y:769,t:1527271967472};\\\", \\\"{x:385,y:749,t:1527271967489};\\\", \\\"{x:406,y:727,t:1527271967505};\\\", \\\"{x:437,y:700,t:1527271967524};\\\", \\\"{x:459,y:675,t:1527271967539};\\\", \\\"{x:483,y:648,t:1527271967557};\\\", \\\"{x:508,y:615,t:1527271967572};\\\", \\\"{x:519,y:597,t:1527271967588};\\\", \\\"{x:526,y:586,t:1527271967608};\\\", \\\"{x:533,y:578,t:1527271967623};\\\", \\\"{x:537,y:573,t:1527271967640};\\\", \\\"{x:539,y:570,t:1527271967657};\\\", \\\"{x:540,y:570,t:1527271967683};\\\", \\\"{x:542,y:570,t:1527271967699};\\\", \\\"{x:545,y:569,t:1527271967707};\\\", \\\"{x:552,y:569,t:1527271967723};\\\", \\\"{x:561,y:566,t:1527271967740};\\\", \\\"{x:568,y:566,t:1527271967757};\\\", \\\"{x:582,y:566,t:1527271967774};\\\", \\\"{x:597,y:566,t:1527271967790};\\\", \\\"{x:608,y:566,t:1527271967808};\\\", \\\"{x:615,y:568,t:1527271967824};\\\", \\\"{x:618,y:569,t:1527271967840};\\\", \\\"{x:620,y:569,t:1527271967858};\\\", \\\"{x:621,y:570,t:1527271967874};\\\", \\\"{x:621,y:572,t:1527271968204};\\\", \\\"{x:620,y:575,t:1527271968211};\\\", \\\"{x:619,y:576,t:1527271968224};\\\", \\\"{x:617,y:580,t:1527271968242};\\\", \\\"{x:614,y:585,t:1527271968257};\\\", \\\"{x:611,y:589,t:1527271968275};\\\", \\\"{x:607,y:595,t:1527271968292};\\\", \\\"{x:606,y:600,t:1527271968308};\\\", \\\"{x:601,y:611,t:1527271968325};\\\", \\\"{x:596,y:621,t:1527271968341};\\\", \\\"{x:591,y:633,t:1527271968358};\\\", \\\"{x:584,y:645,t:1527271968375};\\\", \\\"{x:577,y:657,t:1527271968391};\\\", \\\"{x:571,y:668,t:1527271968409};\\\", \\\"{x:563,y:680,t:1527271968424};\\\", \\\"{x:558,y:689,t:1527271968442};\\\", \\\"{x:552,y:698,t:1527271968458};\\\", \\\"{x:548,y:705,t:1527271968474};\\\", \\\"{x:545,y:710,t:1527271968492};\\\", \\\"{x:543,y:714,t:1527271968509};\\\", \\\"{x:542,y:715,t:1527271968525};\\\", \\\"{x:541,y:716,t:1527271968542};\\\", \\\"{x:541,y:717,t:1527271968558};\\\", \\\"{x:540,y:719,t:1527271968575};\\\", \\\"{x:538,y:721,t:1527271968591};\\\", \\\"{x:537,y:724,t:1527271968608};\\\", \\\"{x:536,y:725,t:1527271968625};\\\", \\\"{x:535,y:727,t:1527271968641};\\\", \\\"{x:535,y:728,t:1527271968658};\\\", \\\"{x:535,y:729,t:1527271968675};\\\", \\\"{x:535,y:730,t:1527271968691};\\\", \\\"{x:534,y:732,t:1527271968708};\\\", \\\"{x:534,y:733,t:1527271969180};\\\" ] }, { \\\"rt\\\": 6812, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 209248, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"K8DJ0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:534,y:734,t:1527271971861};\\\", \\\"{x:534,y:735,t:1527271971997};\\\", \\\"{x:534,y:737,t:1527271972013};\\\", \\\"{x:534,y:738,t:1527271972036};\\\", \\\"{x:534,y:739,t:1527271972053};\\\", \\\"{x:534,y:740,t:1527271972062};\\\", \\\"{x:534,y:742,t:1527271972093};\\\", \\\"{x:534,y:743,t:1527271972135};\\\", \\\"{x:534,y:744,t:1527271972145};\\\", \\\"{x:534,y:745,t:1527271972180};\\\", \\\"{x:534,y:746,t:1527271972195};\\\", \\\"{x:535,y:746,t:1527271973781};\\\", \\\"{x:535,y:743,t:1527271973788};\\\", \\\"{x:535,y:739,t:1527271973798};\\\", \\\"{x:537,y:734,t:1527271973815};\\\", \\\"{x:539,y:726,t:1527271973833};\\\", \\\"{x:541,y:718,t:1527271973849};\\\", \\\"{x:543,y:708,t:1527271973865};\\\", \\\"{x:547,y:700,t:1527271973882};\\\", \\\"{x:548,y:695,t:1527271973896};\\\", \\\"{x:550,y:688,t:1527271973911};\\\", \\\"{x:553,y:681,t:1527271973928};\\\", \\\"{x:556,y:674,t:1527271973945};\\\", \\\"{x:559,y:667,t:1527271973961};\\\", \\\"{x:560,y:663,t:1527271973978};\\\", \\\"{x:563,y:656,t:1527271973995};\\\", \\\"{x:564,y:651,t:1527271974011};\\\", \\\"{x:566,y:647,t:1527271974028};\\\", \\\"{x:568,y:642,t:1527271974045};\\\", \\\"{x:571,y:635,t:1527271974063};\\\", \\\"{x:575,y:627,t:1527271974079};\\\", \\\"{x:577,y:619,t:1527271974095};\\\", \\\"{x:579,y:614,t:1527271974112};\\\", \\\"{x:581,y:607,t:1527271974129};\\\", \\\"{x:584,y:602,t:1527271974146};\\\", \\\"{x:587,y:597,t:1527271974163};\\\", \\\"{x:589,y:590,t:1527271974180};\\\", \\\"{x:591,y:586,t:1527271974195};\\\", \\\"{x:592,y:584,t:1527271974213};\\\", \\\"{x:593,y:582,t:1527271974230};\\\", \\\"{x:594,y:579,t:1527271974247};\\\", \\\"{x:595,y:576,t:1527271974263};\\\", \\\"{x:596,y:571,t:1527271974279};\\\", \\\"{x:599,y:567,t:1527271974296};\\\", \\\"{x:599,y:565,t:1527271974313};\\\", \\\"{x:600,y:562,t:1527271974330};\\\", \\\"{x:602,y:560,t:1527271974347};\\\", \\\"{x:603,y:556,t:1527271974364};\\\", \\\"{x:603,y:555,t:1527271974381};\\\", \\\"{x:603,y:553,t:1527271974396};\\\", \\\"{x:604,y:551,t:1527271974413};\\\", \\\"{x:604,y:550,t:1527271974435};\\\", \\\"{x:605,y:549,t:1527271974452};\\\", \\\"{x:605,y:548,t:1527271974476};\\\", \\\"{x:605,y:547,t:1527271974483};\\\", \\\"{x:606,y:546,t:1527271974496};\\\", \\\"{x:606,y:544,t:1527271974540};\\\", \\\"{x:606,y:543,t:1527271974572};\\\", \\\"{x:606,y:541,t:1527271974612};\\\", \\\"{x:606,y:539,t:1527271974645};\\\", \\\"{x:606,y:538,t:1527271974677};\\\", \\\"{x:606,y:537,t:1527271974684};\\\", \\\"{x:606,y:536,t:1527271974708};\\\", \\\"{x:606,y:535,t:1527271974716};\\\", \\\"{x:606,y:534,t:1527271974730};\\\", \\\"{x:606,y:532,t:1527271974747};\\\", \\\"{x:606,y:531,t:1527271974764};\\\", \\\"{x:606,y:529,t:1527271974781};\\\", \\\"{x:606,y:527,t:1527271974798};\\\", \\\"{x:606,y:524,t:1527271974814};\\\", \\\"{x:606,y:522,t:1527271974830};\\\", \\\"{x:606,y:518,t:1527271974846};\\\", \\\"{x:606,y:511,t:1527271974864};\\\", \\\"{x:606,y:507,t:1527271974880};\\\", \\\"{x:606,y:505,t:1527271974896};\\\", \\\"{x:606,y:504,t:1527271974916};\\\", \\\"{x:612,y:501,t:1527271975460};\\\", \\\"{x:614,y:499,t:1527271975468};\\\", \\\"{x:619,y:497,t:1527271975481};\\\", \\\"{x:625,y:495,t:1527271975498};\\\", \\\"{x:630,y:494,t:1527271975514};\\\", \\\"{x:636,y:494,t:1527271975530};\\\", \\\"{x:646,y:492,t:1527271975549};\\\", \\\"{x:667,y:489,t:1527271975563};\\\", \\\"{x:694,y:489,t:1527271975581};\\\", \\\"{x:730,y:489,t:1527271975599};\\\", \\\"{x:757,y:489,t:1527271975613};\\\", \\\"{x:776,y:489,t:1527271975630};\\\", \\\"{x:782,y:489,t:1527271975647};\\\", \\\"{x:784,y:489,t:1527271975664};\\\", \\\"{x:786,y:489,t:1527271975680};\\\", \\\"{x:787,y:489,t:1527271975732};\\\", \\\"{x:791,y:489,t:1527271975747};\\\", \\\"{x:796,y:489,t:1527271975763};\\\", \\\"{x:800,y:489,t:1527271975780};\\\", \\\"{x:801,y:489,t:1527271975797};\\\", \\\"{x:802,y:489,t:1527271975815};\\\", \\\"{x:805,y:491,t:1527271975831};\\\", \\\"{x:808,y:494,t:1527271975847};\\\", \\\"{x:812,y:500,t:1527271975864};\\\", \\\"{x:816,y:505,t:1527271975880};\\\", \\\"{x:818,y:508,t:1527271975898};\\\", \\\"{x:820,y:511,t:1527271975915};\\\", \\\"{x:821,y:515,t:1527271975931};\\\", \\\"{x:824,y:519,t:1527271975948};\\\", \\\"{x:826,y:522,t:1527271975965};\\\", \\\"{x:827,y:524,t:1527271975981};\\\", \\\"{x:828,y:525,t:1527271975998};\\\", \\\"{x:829,y:526,t:1527271976013};\\\", \\\"{x:830,y:527,t:1527271976149};\\\", \\\"{x:830,y:528,t:1527271976165};\\\", \\\"{x:830,y:529,t:1527271976187};\\\", \\\"{x:830,y:530,t:1527271976197};\\\", \\\"{x:830,y:531,t:1527271976215};\\\", \\\"{x:830,y:532,t:1527271976231};\\\", \\\"{x:830,y:533,t:1527271976251};\\\", \\\"{x:830,y:534,t:1527271976297};\\\", \\\"{x:830,y:534,t:1527271976397};\\\", \\\"{x:830,y:535,t:1527271976414};\\\", \\\"{x:830,y:536,t:1527271976432};\\\", \\\"{x:830,y:538,t:1527271976448};\\\", \\\"{x:828,y:541,t:1527271976465};\\\", \\\"{x:825,y:544,t:1527271976481};\\\", \\\"{x:820,y:549,t:1527271976498};\\\", \\\"{x:812,y:554,t:1527271976515};\\\", \\\"{x:801,y:563,t:1527271976533};\\\", \\\"{x:794,y:569,t:1527271976547};\\\", \\\"{x:785,y:578,t:1527271976564};\\\", \\\"{x:778,y:584,t:1527271976582};\\\", \\\"{x:770,y:591,t:1527271976598};\\\", \\\"{x:761,y:596,t:1527271976615};\\\", \\\"{x:750,y:604,t:1527271976634};\\\", \\\"{x:741,y:610,t:1527271976648};\\\", \\\"{x:732,y:616,t:1527271976665};\\\", \\\"{x:724,y:621,t:1527271976681};\\\", \\\"{x:717,y:628,t:1527271976699};\\\", \\\"{x:707,y:634,t:1527271976714};\\\", \\\"{x:691,y:645,t:1527271976731};\\\", \\\"{x:679,y:653,t:1527271976748};\\\", \\\"{x:665,y:664,t:1527271976765};\\\", \\\"{x:651,y:674,t:1527271976782};\\\", \\\"{x:640,y:684,t:1527271976799};\\\", \\\"{x:624,y:695,t:1527271976816};\\\", \\\"{x:609,y:705,t:1527271976832};\\\", \\\"{x:592,y:717,t:1527271976848};\\\", \\\"{x:576,y:728,t:1527271976865};\\\", \\\"{x:560,y:737,t:1527271976882};\\\", \\\"{x:554,y:742,t:1527271976898};\\\", \\\"{x:551,y:744,t:1527271976915};\\\", \\\"{x:551,y:745,t:1527271976932};\\\", \\\"{x:550,y:745,t:1527271976971};\\\", \\\"{x:549,y:745,t:1527271977004};\\\", \\\"{x:548,y:745,t:1527271977020};\\\", \\\"{x:542,y:745,t:1527271977032};\\\", \\\"{x:534,y:740,t:1527271977048};\\\", \\\"{x:529,y:735,t:1527271977065};\\\", \\\"{x:528,y:735,t:1527271977081};\\\", \\\"{x:527,y:734,t:1527271977097};\\\" ] }, { \\\"rt\\\": 21884, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 232407, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"K8DJ0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 AM-B -B -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:527,y:733,t:1527271978566};\\\", \\\"{x:527,y:732,t:1527271978582};\\\", \\\"{x:528,y:732,t:1527271978600};\\\", \\\"{x:528,y:731,t:1527271978643};\\\", \\\"{x:529,y:731,t:1527271978747};\\\", \\\"{x:529,y:730,t:1527271978772};\\\", \\\"{x:530,y:728,t:1527271978835};\\\", \\\"{x:531,y:727,t:1527271978859};\\\", \\\"{x:531,y:726,t:1527271978867};\\\", \\\"{x:535,y:717,t:1527271978968};\\\", \\\"{x:536,y:714,t:1527271978983};\\\", \\\"{x:536,y:713,t:1527271979011};\\\", \\\"{x:536,y:712,t:1527271979036};\\\", \\\"{x:537,y:711,t:1527271979067};\\\", \\\"{x:538,y:711,t:1527271979324};\\\", \\\"{x:538,y:710,t:1527271979421};\\\", \\\"{x:539,y:710,t:1527271979460};\\\", \\\"{x:539,y:709,t:1527271979533};\\\", \\\"{x:540,y:709,t:1527271984421};\\\", \\\"{x:549,y:710,t:1527271990837};\\\", \\\"{x:561,y:721,t:1527271990845};\\\", \\\"{x:599,y:741,t:1527271990859};\\\", \\\"{x:639,y:770,t:1527271990876};\\\", \\\"{x:664,y:787,t:1527271990892};\\\", \\\"{x:683,y:800,t:1527271990908};\\\", \\\"{x:726,y:818,t:1527271990925};\\\", \\\"{x:759,y:830,t:1527271990942};\\\", \\\"{x:794,y:842,t:1527271990958};\\\", \\\"{x:821,y:849,t:1527271990975};\\\", \\\"{x:850,y:859,t:1527271990992};\\\", \\\"{x:875,y:864,t:1527271991008};\\\", \\\"{x:890,y:868,t:1527271991025};\\\", \\\"{x:909,y:871,t:1527271991042};\\\", \\\"{x:928,y:877,t:1527271991058};\\\", \\\"{x:964,y:883,t:1527271991076};\\\", \\\"{x:993,y:887,t:1527271991093};\\\", \\\"{x:1024,y:894,t:1527271991109};\\\", \\\"{x:1053,y:900,t:1527271991125};\\\", \\\"{x:1078,y:906,t:1527271991143};\\\", \\\"{x:1098,y:911,t:1527271991159};\\\", \\\"{x:1113,y:915,t:1527271991175};\\\", \\\"{x:1120,y:917,t:1527271991192};\\\", \\\"{x:1124,y:919,t:1527271991209};\\\", \\\"{x:1125,y:919,t:1527271991235};\\\", \\\"{x:1126,y:921,t:1527271991356};\\\", \\\"{x:1125,y:923,t:1527271991364};\\\", \\\"{x:1125,y:925,t:1527271991375};\\\", \\\"{x:1120,y:932,t:1527271991393};\\\", \\\"{x:1115,y:940,t:1527271991409};\\\", \\\"{x:1108,y:950,t:1527271991426};\\\", \\\"{x:1103,y:957,t:1527271991443};\\\", \\\"{x:1099,y:965,t:1527271991460};\\\", \\\"{x:1098,y:967,t:1527271991476};\\\", \\\"{x:1096,y:970,t:1527271991493};\\\", \\\"{x:1095,y:971,t:1527271991509};\\\", \\\"{x:1095,y:972,t:1527271991732};\\\", \\\"{x:1095,y:971,t:1527271992100};\\\", \\\"{x:1095,y:964,t:1527271992111};\\\", \\\"{x:1095,y:945,t:1527271992127};\\\", \\\"{x:1102,y:913,t:1527271992143};\\\", \\\"{x:1110,y:870,t:1527271992160};\\\", \\\"{x:1121,y:816,t:1527271992177};\\\", \\\"{x:1141,y:761,t:1527271992194};\\\", \\\"{x:1158,y:715,t:1527271992210};\\\", \\\"{x:1175,y:674,t:1527271992227};\\\", \\\"{x:1194,y:635,t:1527271992244};\\\", \\\"{x:1205,y:616,t:1527271992260};\\\", \\\"{x:1214,y:605,t:1527271992276};\\\", \\\"{x:1218,y:599,t:1527271992294};\\\", \\\"{x:1221,y:596,t:1527271992310};\\\", \\\"{x:1223,y:595,t:1527271992326};\\\", \\\"{x:1224,y:595,t:1527271992343};\\\", \\\"{x:1224,y:594,t:1527271992359};\\\", \\\"{x:1225,y:594,t:1527271992460};\\\", \\\"{x:1225,y:601,t:1527271992476};\\\", \\\"{x:1223,y:616,t:1527271992493};\\\", \\\"{x:1222,y:634,t:1527271992509};\\\", \\\"{x:1221,y:655,t:1527271992526};\\\", \\\"{x:1221,y:679,t:1527271992544};\\\", \\\"{x:1221,y:704,t:1527271992560};\\\", \\\"{x:1219,y:732,t:1527271992576};\\\", \\\"{x:1220,y:754,t:1527271992593};\\\", \\\"{x:1221,y:769,t:1527271992609};\\\", \\\"{x:1224,y:780,t:1527271992626};\\\", \\\"{x:1225,y:788,t:1527271992643};\\\", \\\"{x:1225,y:790,t:1527271992659};\\\", \\\"{x:1226,y:789,t:1527271992740};\\\", \\\"{x:1228,y:784,t:1527271992748};\\\", \\\"{x:1231,y:773,t:1527271992760};\\\", \\\"{x:1239,y:750,t:1527271992777};\\\", \\\"{x:1248,y:720,t:1527271992793};\\\", \\\"{x:1259,y:681,t:1527271992811};\\\", \\\"{x:1269,y:640,t:1527271992827};\\\", \\\"{x:1286,y:590,t:1527271992844};\\\", \\\"{x:1292,y:570,t:1527271992860};\\\", \\\"{x:1293,y:564,t:1527271992876};\\\", \\\"{x:1294,y:562,t:1527271992894};\\\", \\\"{x:1294,y:564,t:1527271992980};\\\", \\\"{x:1295,y:571,t:1527271992994};\\\", \\\"{x:1300,y:591,t:1527271993012};\\\", \\\"{x:1302,y:614,t:1527271993027};\\\", \\\"{x:1308,y:662,t:1527271993044};\\\", \\\"{x:1320,y:705,t:1527271993060};\\\", \\\"{x:1327,y:738,t:1527271993077};\\\", \\\"{x:1340,y:775,t:1527271993094};\\\", \\\"{x:1349,y:799,t:1527271993111};\\\", \\\"{x:1358,y:819,t:1527271993127};\\\", \\\"{x:1364,y:831,t:1527271993143};\\\", \\\"{x:1368,y:836,t:1527271993160};\\\", \\\"{x:1370,y:835,t:1527271993276};\\\", \\\"{x:1371,y:833,t:1527271993284};\\\", \\\"{x:1371,y:831,t:1527271993293};\\\", \\\"{x:1376,y:819,t:1527271993311};\\\", \\\"{x:1377,y:809,t:1527271993327};\\\", \\\"{x:1378,y:797,t:1527271993343};\\\", \\\"{x:1381,y:780,t:1527271993361};\\\", \\\"{x:1381,y:767,t:1527271993378};\\\", \\\"{x:1381,y:755,t:1527271993393};\\\", \\\"{x:1381,y:748,t:1527271993410};\\\", \\\"{x:1381,y:740,t:1527271993428};\\\", \\\"{x:1382,y:737,t:1527271993444};\\\", \\\"{x:1382,y:735,t:1527271993461};\\\", \\\"{x:1382,y:734,t:1527271993716};\\\", \\\"{x:1382,y:732,t:1527271993727};\\\", \\\"{x:1380,y:731,t:1527271993744};\\\", \\\"{x:1380,y:730,t:1527271993761};\\\", \\\"{x:1378,y:728,t:1527271993778};\\\", \\\"{x:1377,y:725,t:1527271993795};\\\", \\\"{x:1376,y:723,t:1527271993811};\\\", \\\"{x:1374,y:719,t:1527271993828};\\\", \\\"{x:1374,y:718,t:1527271993844};\\\", \\\"{x:1373,y:717,t:1527271993861};\\\", \\\"{x:1373,y:715,t:1527271993878};\\\", \\\"{x:1371,y:714,t:1527271993894};\\\", \\\"{x:1370,y:713,t:1527271993915};\\\", \\\"{x:1370,y:717,t:1527271994204};\\\", \\\"{x:1371,y:720,t:1527271994212};\\\", \\\"{x:1371,y:730,t:1527271994228};\\\", \\\"{x:1371,y:737,t:1527271994244};\\\", \\\"{x:1372,y:748,t:1527271994262};\\\", \\\"{x:1374,y:760,t:1527271994278};\\\", \\\"{x:1374,y:770,t:1527271994295};\\\", \\\"{x:1376,y:779,t:1527271994312};\\\", \\\"{x:1376,y:784,t:1527271994327};\\\", \\\"{x:1376,y:787,t:1527271994345};\\\", \\\"{x:1377,y:788,t:1527271994362};\\\", \\\"{x:1377,y:780,t:1527271994421};\\\", \\\"{x:1377,y:773,t:1527271994428};\\\", \\\"{x:1377,y:756,t:1527271994445};\\\", \\\"{x:1377,y:734,t:1527271994462};\\\", \\\"{x:1377,y:712,t:1527271994478};\\\", \\\"{x:1376,y:691,t:1527271994495};\\\", \\\"{x:1374,y:679,t:1527271994511};\\\", \\\"{x:1371,y:673,t:1527271994527};\\\", \\\"{x:1371,y:671,t:1527271994544};\\\", \\\"{x:1371,y:672,t:1527271994611};\\\", \\\"{x:1366,y:686,t:1527271994627};\\\", \\\"{x:1360,y:702,t:1527271994644};\\\", \\\"{x:1355,y:718,t:1527271994661};\\\", \\\"{x:1351,y:735,t:1527271994677};\\\", \\\"{x:1348,y:748,t:1527271994694};\\\", \\\"{x:1344,y:760,t:1527271994712};\\\", \\\"{x:1343,y:764,t:1527271994728};\\\", \\\"{x:1341,y:768,t:1527271994745};\\\", \\\"{x:1341,y:770,t:1527271994761};\\\", \\\"{x:1341,y:771,t:1527271994820};\\\", \\\"{x:1341,y:770,t:1527271994828};\\\", \\\"{x:1342,y:762,t:1527271994845};\\\", \\\"{x:1345,y:754,t:1527271994862};\\\", \\\"{x:1346,y:750,t:1527271994878};\\\", \\\"{x:1348,y:745,t:1527271994894};\\\", \\\"{x:1349,y:743,t:1527271994912};\\\", \\\"{x:1349,y:742,t:1527271994929};\\\", \\\"{x:1349,y:741,t:1527271994945};\\\", \\\"{x:1350,y:740,t:1527271994980};\\\", \\\"{x:1350,y:737,t:1527271995637};\\\", \\\"{x:1349,y:734,t:1527271995646};\\\", \\\"{x:1347,y:728,t:1527271995662};\\\", \\\"{x:1344,y:721,t:1527271995679};\\\", \\\"{x:1340,y:712,t:1527271995696};\\\", \\\"{x:1336,y:704,t:1527271995713};\\\", \\\"{x:1331,y:696,t:1527271995729};\\\", \\\"{x:1324,y:688,t:1527271995746};\\\", \\\"{x:1318,y:682,t:1527271995763};\\\", \\\"{x:1310,y:677,t:1527271995779};\\\", \\\"{x:1298,y:671,t:1527271995796};\\\", \\\"{x:1288,y:667,t:1527271995812};\\\", \\\"{x:1274,y:664,t:1527271995828};\\\", \\\"{x:1250,y:658,t:1527271995846};\\\", \\\"{x:1217,y:653,t:1527271995862};\\\", \\\"{x:1171,y:646,t:1527271995879};\\\", \\\"{x:1110,y:637,t:1527271995896};\\\", \\\"{x:1046,y:627,t:1527271995913};\\\", \\\"{x:1000,y:620,t:1527271995928};\\\", \\\"{x:964,y:614,t:1527271995945};\\\", \\\"{x:931,y:609,t:1527271995962};\\\", \\\"{x:894,y:602,t:1527271995978};\\\", \\\"{x:847,y:597,t:1527271995998};\\\", \\\"{x:819,y:594,t:1527271996014};\\\", \\\"{x:790,y:593,t:1527271996031};\\\", \\\"{x:762,y:593,t:1527271996049};\\\", \\\"{x:736,y:590,t:1527271996064};\\\", \\\"{x:711,y:587,t:1527271996082};\\\", \\\"{x:688,y:583,t:1527271996097};\\\", \\\"{x:670,y:580,t:1527271996114};\\\", \\\"{x:645,y:579,t:1527271996131};\\\", \\\"{x:632,y:578,t:1527271996147};\\\", \\\"{x:624,y:578,t:1527271996164};\\\", \\\"{x:619,y:578,t:1527271996182};\\\", \\\"{x:614,y:578,t:1527271996197};\\\", \\\"{x:612,y:578,t:1527271996214};\\\", \\\"{x:605,y:578,t:1527271996231};\\\", \\\"{x:599,y:578,t:1527271996248};\\\", \\\"{x:585,y:578,t:1527271996264};\\\", \\\"{x:566,y:579,t:1527271996281};\\\", \\\"{x:544,y:580,t:1527271996298};\\\", \\\"{x:519,y:585,t:1527271996314};\\\", \\\"{x:487,y:586,t:1527271996333};\\\", \\\"{x:461,y:587,t:1527271996348};\\\", \\\"{x:439,y:587,t:1527271996364};\\\", \\\"{x:415,y:591,t:1527271996381};\\\", \\\"{x:398,y:596,t:1527271996399};\\\", \\\"{x:375,y:601,t:1527271996415};\\\", \\\"{x:349,y:603,t:1527271996431};\\\", \\\"{x:320,y:609,t:1527271996448};\\\", \\\"{x:298,y:614,t:1527271996464};\\\", \\\"{x:275,y:619,t:1527271996481};\\\", \\\"{x:254,y:625,t:1527271996499};\\\", \\\"{x:241,y:629,t:1527271996514};\\\", \\\"{x:232,y:633,t:1527271996531};\\\", \\\"{x:224,y:636,t:1527271996548};\\\", \\\"{x:219,y:639,t:1527271996565};\\\", \\\"{x:208,y:644,t:1527271996581};\\\", \\\"{x:197,y:648,t:1527271996598};\\\", \\\"{x:185,y:652,t:1527271996616};\\\", \\\"{x:177,y:654,t:1527271996631};\\\", \\\"{x:176,y:656,t:1527271996648};\\\", \\\"{x:174,y:657,t:1527271996664};\\\", \\\"{x:172,y:658,t:1527271996681};\\\", \\\"{x:172,y:660,t:1527271996698};\\\", \\\"{x:171,y:662,t:1527271996715};\\\", \\\"{x:170,y:663,t:1527271996731};\\\", \\\"{x:169,y:666,t:1527271996748};\\\", \\\"{x:172,y:663,t:1527271996869};\\\", \\\"{x:174,y:661,t:1527271996881};\\\", \\\"{x:179,y:657,t:1527271996898};\\\", \\\"{x:190,y:650,t:1527271996915};\\\", \\\"{x:195,y:646,t:1527271996932};\\\", \\\"{x:201,y:642,t:1527271996948};\\\", \\\"{x:209,y:639,t:1527271996965};\\\", \\\"{x:224,y:635,t:1527271996982};\\\", \\\"{x:246,y:634,t:1527271996998};\\\", \\\"{x:272,y:632,t:1527271997015};\\\", \\\"{x:305,y:632,t:1527271997032};\\\", \\\"{x:338,y:631,t:1527271997048};\\\", \\\"{x:376,y:628,t:1527271997065};\\\", \\\"{x:404,y:624,t:1527271997081};\\\", \\\"{x:429,y:620,t:1527271997099};\\\", \\\"{x:454,y:613,t:1527271997115};\\\", \\\"{x:470,y:609,t:1527271997133};\\\", \\\"{x:486,y:604,t:1527271997148};\\\", \\\"{x:500,y:601,t:1527271997167};\\\", \\\"{x:517,y:596,t:1527271997183};\\\", \\\"{x:530,y:592,t:1527271997198};\\\", \\\"{x:538,y:589,t:1527271997215};\\\", \\\"{x:542,y:588,t:1527271997233};\\\", \\\"{x:547,y:587,t:1527271997248};\\\", \\\"{x:555,y:584,t:1527271997265};\\\", \\\"{x:566,y:582,t:1527271997282};\\\", \\\"{x:588,y:579,t:1527271997298};\\\", \\\"{x:629,y:573,t:1527271997315};\\\", \\\"{x:667,y:571,t:1527271997333};\\\", \\\"{x:703,y:565,t:1527271997348};\\\", \\\"{x:736,y:558,t:1527271997366};\\\", \\\"{x:766,y:553,t:1527271997383};\\\", \\\"{x:790,y:546,t:1527271997398};\\\", \\\"{x:806,y:540,t:1527271997415};\\\", \\\"{x:815,y:536,t:1527271997432};\\\", \\\"{x:819,y:534,t:1527271997448};\\\", \\\"{x:821,y:533,t:1527271997465};\\\", \\\"{x:822,y:532,t:1527271997540};\\\", \\\"{x:822,y:531,t:1527271997564};\\\", \\\"{x:822,y:529,t:1527271997587};\\\", \\\"{x:822,y:527,t:1527271997603};\\\", \\\"{x:822,y:526,t:1527271997615};\\\", \\\"{x:822,y:525,t:1527271997632};\\\", \\\"{x:822,y:523,t:1527271997651};\\\", \\\"{x:822,y:520,t:1527271997665};\\\", \\\"{x:822,y:519,t:1527271997683};\\\", \\\"{x:822,y:518,t:1527271997699};\\\", \\\"{x:822,y:517,t:1527271997715};\\\", \\\"{x:823,y:516,t:1527271997739};\\\", \\\"{x:824,y:515,t:1527271997749};\\\", \\\"{x:825,y:515,t:1527271997779};\\\", \\\"{x:825,y:513,t:1527271997802};\\\", \\\"{x:826,y:513,t:1527271997816};\\\", \\\"{x:827,y:512,t:1527271997835};\\\", \\\"{x:828,y:511,t:1527271997884};\\\", \\\"{x:828,y:510,t:1527271997899};\\\", \\\"{x:828,y:509,t:1527271997948};\\\", \\\"{x:829,y:509,t:1527271997964};\\\", \\\"{x:827,y:508,t:1527271998251};\\\", \\\"{x:825,y:508,t:1527271998268};\\\", \\\"{x:822,y:506,t:1527271998283};\\\", \\\"{x:816,y:506,t:1527271998299};\\\", \\\"{x:809,y:506,t:1527271998317};\\\", \\\"{x:799,y:507,t:1527271998333};\\\", \\\"{x:778,y:511,t:1527271998350};\\\", \\\"{x:754,y:516,t:1527271998366};\\\", \\\"{x:721,y:523,t:1527271998384};\\\", \\\"{x:686,y:529,t:1527271998400};\\\", \\\"{x:646,y:536,t:1527271998416};\\\", \\\"{x:601,y:544,t:1527271998434};\\\", \\\"{x:557,y:548,t:1527271998450};\\\", \\\"{x:504,y:556,t:1527271998467};\\\", \\\"{x:447,y:568,t:1527271998484};\\\", \\\"{x:421,y:574,t:1527271998499};\\\", \\\"{x:398,y:582,t:1527271998516};\\\", \\\"{x:377,y:586,t:1527271998533};\\\", \\\"{x:362,y:589,t:1527271998550};\\\", \\\"{x:350,y:593,t:1527271998566};\\\", \\\"{x:335,y:598,t:1527271998584};\\\", \\\"{x:327,y:602,t:1527271998600};\\\", \\\"{x:323,y:605,t:1527271998616};\\\", \\\"{x:312,y:610,t:1527271998634};\\\", \\\"{x:303,y:616,t:1527271998649};\\\", \\\"{x:293,y:621,t:1527271998666};\\\", \\\"{x:279,y:628,t:1527271998683};\\\", \\\"{x:267,y:637,t:1527271998700};\\\", \\\"{x:253,y:643,t:1527271998717};\\\", \\\"{x:237,y:649,t:1527271998733};\\\", \\\"{x:223,y:657,t:1527271998749};\\\", \\\"{x:212,y:661,t:1527271998767};\\\", \\\"{x:207,y:663,t:1527271998784};\\\", \\\"{x:205,y:664,t:1527271998799};\\\", \\\"{x:204,y:664,t:1527271998816};\\\", \\\"{x:203,y:665,t:1527271998833};\\\", \\\"{x:202,y:665,t:1527271998860};\\\", \\\"{x:200,y:665,t:1527271998876};\\\", \\\"{x:199,y:665,t:1527271998883};\\\", \\\"{x:194,y:661,t:1527271998900};\\\", \\\"{x:187,y:649,t:1527271998917};\\\", \\\"{x:180,y:637,t:1527271998934};\\\", \\\"{x:173,y:621,t:1527271998950};\\\", \\\"{x:165,y:604,t:1527271998966};\\\", \\\"{x:161,y:593,t:1527271998983};\\\", \\\"{x:157,y:585,t:1527271999001};\\\", \\\"{x:155,y:579,t:1527271999016};\\\", \\\"{x:154,y:574,t:1527271999033};\\\", \\\"{x:153,y:571,t:1527271999050};\\\", \\\"{x:152,y:569,t:1527271999067};\\\", \\\"{x:152,y:568,t:1527271999083};\\\", \\\"{x:151,y:567,t:1527271999100};\\\", \\\"{x:151,y:564,t:1527271999117};\\\", \\\"{x:150,y:561,t:1527271999133};\\\", \\\"{x:150,y:557,t:1527271999150};\\\", \\\"{x:150,y:555,t:1527271999167};\\\", \\\"{x:150,y:553,t:1527271999183};\\\", \\\"{x:150,y:551,t:1527271999201};\\\", \\\"{x:150,y:550,t:1527271999216};\\\", \\\"{x:150,y:549,t:1527271999233};\\\", \\\"{x:150,y:548,t:1527271999250};\\\", \\\"{x:150,y:547,t:1527271999267};\\\", \\\"{x:150,y:546,t:1527271999291};\\\", \\\"{x:150,y:545,t:1527271999307};\\\", \\\"{x:151,y:545,t:1527271999547};\\\", \\\"{x:154,y:545,t:1527271999555};\\\", \\\"{x:155,y:545,t:1527271999567};\\\", \\\"{x:158,y:546,t:1527271999584};\\\", \\\"{x:164,y:550,t:1527271999600};\\\", \\\"{x:182,y:558,t:1527271999618};\\\", \\\"{x:200,y:565,t:1527271999635};\\\", \\\"{x:219,y:574,t:1527271999651};\\\", \\\"{x:244,y:586,t:1527271999667};\\\", \\\"{x:258,y:592,t:1527271999685};\\\", \\\"{x:275,y:600,t:1527271999700};\\\", \\\"{x:292,y:610,t:1527271999718};\\\", \\\"{x:305,y:618,t:1527271999734};\\\", \\\"{x:320,y:625,t:1527271999750};\\\", \\\"{x:335,y:633,t:1527271999768};\\\", \\\"{x:349,y:639,t:1527271999785};\\\", \\\"{x:360,y:644,t:1527271999802};\\\", \\\"{x:373,y:651,t:1527271999818};\\\", \\\"{x:383,y:659,t:1527271999835};\\\", \\\"{x:397,y:670,t:1527271999852};\\\", \\\"{x:402,y:674,t:1527271999867};\\\", \\\"{x:405,y:678,t:1527271999884};\\\", \\\"{x:409,y:683,t:1527271999900};\\\", \\\"{x:411,y:687,t:1527271999917};\\\", \\\"{x:415,y:692,t:1527271999935};\\\", \\\"{x:420,y:700,t:1527271999951};\\\", \\\"{x:427,y:709,t:1527271999968};\\\", \\\"{x:431,y:718,t:1527271999984};\\\", \\\"{x:435,y:725,t:1527272000000};\\\", \\\"{x:436,y:726,t:1527272000017};\\\", \\\"{x:437,y:727,t:1527272000034};\\\", \\\"{x:439,y:728,t:1527272000083};\\\", \\\"{x:440,y:728,t:1527272000099};\\\", \\\"{x:441,y:728,t:1527272000115};\\\", \\\"{x:443,y:729,t:1527272000131};\\\", \\\"{x:443,y:730,t:1527272000139};\\\", \\\"{x:446,y:730,t:1527272000156};\\\", \\\"{x:447,y:730,t:1527272000167};\\\", \\\"{x:452,y:730,t:1527272000185};\\\", \\\"{x:466,y:732,t:1527272000201};\\\", \\\"{x:482,y:735,t:1527272000218};\\\", \\\"{x:495,y:737,t:1527272000235};\\\", \\\"{x:508,y:740,t:1527272000252};\\\", \\\"{x:507,y:740,t:1527272000587};\\\", \\\"{x:506,y:740,t:1527272000603};\\\", \\\"{x:506,y:738,t:1527272000618};\\\", \\\"{x:504,y:737,t:1527272000634};\\\", \\\"{x:504,y:735,t:1527272000651};\\\", \\\"{x:503,y:733,t:1527272000668};\\\", \\\"{x:503,y:731,t:1527272000691};\\\", \\\"{x:503,y:730,t:1527272000707};\\\", \\\"{x:502,y:728,t:1527272000731};\\\", \\\"{x:502,y:727,t:1527272000747};\\\", \\\"{x:502,y:725,t:1527272000756};\\\", \\\"{x:502,y:724,t:1527272000768};\\\", \\\"{x:502,y:721,t:1527272000785};\\\", \\\"{x:502,y:720,t:1527272000801};\\\", \\\"{x:502,y:718,t:1527272000819};\\\", \\\"{x:501,y:717,t:1527272000835};\\\", \\\"{x:501,y:716,t:1527272000852};\\\", \\\"{x:501,y:715,t:1527272000869};\\\", \\\"{x:501,y:713,t:1527272000892};\\\", \\\"{x:501,y:712,t:1527272000902};\\\", \\\"{x:501,y:711,t:1527272000919};\\\", \\\"{x:501,y:708,t:1527272000936};\\\", \\\"{x:502,y:705,t:1527272000952};\\\", \\\"{x:503,y:701,t:1527272000968};\\\", \\\"{x:504,y:698,t:1527272000985};\\\", \\\"{x:506,y:693,t:1527272001001};\\\", \\\"{x:508,y:688,t:1527272001019};\\\", \\\"{x:512,y:679,t:1527272001035};\\\", \\\"{x:517,y:673,t:1527272001051};\\\", \\\"{x:523,y:666,t:1527272001069};\\\", \\\"{x:527,y:661,t:1527272001086};\\\", \\\"{x:532,y:654,t:1527272001101};\\\", \\\"{x:542,y:645,t:1527272001119};\\\", \\\"{x:550,y:640,t:1527272001136};\\\", \\\"{x:559,y:633,t:1527272001152};\\\", \\\"{x:569,y:626,t:1527272001168};\\\", \\\"{x:578,y:620,t:1527272001186};\\\", \\\"{x:582,y:617,t:1527272001201};\\\", \\\"{x:584,y:616,t:1527272001219};\\\", \\\"{x:586,y:615,t:1527272001235};\\\", \\\"{x:587,y:615,t:1527272001308};\\\" ] }, { \\\"rt\\\": 30342, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 264062, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"K8DJ0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:587,y:616,t:1527272001931};\\\", \\\"{x:588,y:619,t:1527272001939};\\\", \\\"{x:589,y:622,t:1527272001953};\\\", \\\"{x:589,y:627,t:1527272001969};\\\", \\\"{x:589,y:633,t:1527272001987};\\\", \\\"{x:590,y:637,t:1527272002002};\\\", \\\"{x:590,y:641,t:1527272002019};\\\", \\\"{x:591,y:642,t:1527272002035};\\\", \\\"{x:591,y:646,t:1527272002118};\\\", \\\"{x:591,y:647,t:1527272002124};\\\", \\\"{x:591,y:648,t:1527272002147};\\\", \\\"{x:591,y:650,t:1527272002153};\\\", \\\"{x:591,y:652,t:1527272002170};\\\", \\\"{x:591,y:654,t:1527272002187};\\\", \\\"{x:591,y:658,t:1527272002202};\\\", \\\"{x:591,y:660,t:1527272002219};\\\", \\\"{x:591,y:662,t:1527272002236};\\\", \\\"{x:591,y:664,t:1527272002253};\\\", \\\"{x:591,y:665,t:1527272002275};\\\", \\\"{x:591,y:666,t:1527272002299};\\\", \\\"{x:591,y:667,t:1527272002339};\\\", \\\"{x:590,y:669,t:1527272002355};\\\", \\\"{x:589,y:670,t:1527272002428};\\\", \\\"{x:589,y:671,t:1527272004476};\\\", \\\"{x:588,y:671,t:1527272007607};\\\", \\\"{x:587,y:671,t:1527272013752};\\\", \\\"{x:591,y:666,t:1527272013766};\\\", \\\"{x:642,y:634,t:1527272013783};\\\", \\\"{x:671,y:620,t:1527272013801};\\\", \\\"{x:691,y:608,t:1527272013816};\\\", \\\"{x:709,y:596,t:1527272013833};\\\", \\\"{x:751,y:578,t:1527272013847};\\\", \\\"{x:789,y:563,t:1527272013862};\\\", \\\"{x:831,y:549,t:1527272013880};\\\", \\\"{x:874,y:536,t:1527272013897};\\\", \\\"{x:895,y:529,t:1527272013917};\\\", \\\"{x:914,y:520,t:1527272013933};\\\", \\\"{x:920,y:519,t:1527272013950};\\\", \\\"{x:931,y:515,t:1527272013967};\\\", \\\"{x:940,y:513,t:1527272013983};\\\", \\\"{x:952,y:509,t:1527272014000};\\\", \\\"{x:968,y:507,t:1527272014017};\\\", \\\"{x:987,y:503,t:1527272014033};\\\", \\\"{x:1006,y:498,t:1527272014050};\\\", \\\"{x:1029,y:492,t:1527272014067};\\\", \\\"{x:1044,y:487,t:1527272014083};\\\", \\\"{x:1050,y:486,t:1527272014100};\\\", \\\"{x:1054,y:484,t:1527272014117};\\\", \\\"{x:1057,y:482,t:1527272014132};\\\", \\\"{x:1061,y:481,t:1527272014150};\\\", \\\"{x:1064,y:479,t:1527272014167};\\\", \\\"{x:1070,y:477,t:1527272014183};\\\", \\\"{x:1074,y:476,t:1527272014200};\\\", \\\"{x:1077,y:476,t:1527272014216};\\\", \\\"{x:1086,y:473,t:1527272014234};\\\", \\\"{x:1101,y:473,t:1527272014250};\\\", \\\"{x:1124,y:472,t:1527272014267};\\\", \\\"{x:1154,y:472,t:1527272014284};\\\", \\\"{x:1188,y:472,t:1527272014299};\\\", \\\"{x:1230,y:472,t:1527272014317};\\\", \\\"{x:1280,y:472,t:1527272014334};\\\", \\\"{x:1325,y:472,t:1527272014349};\\\", \\\"{x:1384,y:472,t:1527272014367};\\\", \\\"{x:1420,y:472,t:1527272014384};\\\", \\\"{x:1459,y:472,t:1527272014400};\\\", \\\"{x:1489,y:472,t:1527272014417};\\\", \\\"{x:1515,y:472,t:1527272014434};\\\", \\\"{x:1535,y:472,t:1527272014450};\\\", \\\"{x:1557,y:472,t:1527272014466};\\\", \\\"{x:1575,y:472,t:1527272014484};\\\", \\\"{x:1591,y:472,t:1527272014500};\\\", \\\"{x:1612,y:472,t:1527272014517};\\\", \\\"{x:1627,y:472,t:1527272014534};\\\", \\\"{x:1639,y:472,t:1527272014550};\\\", \\\"{x:1649,y:472,t:1527272014567};\\\", \\\"{x:1651,y:472,t:1527272014584};\\\", \\\"{x:1652,y:472,t:1527272014656};\\\", \\\"{x:1653,y:472,t:1527272014824};\\\", \\\"{x:1652,y:473,t:1527272014840};\\\", \\\"{x:1651,y:473,t:1527272014864};\\\", \\\"{x:1651,y:474,t:1527272014880};\\\", \\\"{x:1649,y:475,t:1527272014895};\\\", \\\"{x:1645,y:477,t:1527272014926};\\\", \\\"{x:1643,y:480,t:1527272014950};\\\", \\\"{x:1641,y:481,t:1527272014966};\\\", \\\"{x:1636,y:485,t:1527272014984};\\\", \\\"{x:1631,y:487,t:1527272015001};\\\", \\\"{x:1628,y:488,t:1527272015017};\\\", \\\"{x:1626,y:489,t:1527272015034};\\\", \\\"{x:1622,y:490,t:1527272015051};\\\", \\\"{x:1619,y:492,t:1527272015068};\\\", \\\"{x:1617,y:492,t:1527272015083};\\\", \\\"{x:1616,y:494,t:1527272015101};\\\", \\\"{x:1613,y:494,t:1527272015117};\\\", \\\"{x:1609,y:496,t:1527272015134};\\\", \\\"{x:1603,y:498,t:1527272015151};\\\", \\\"{x:1602,y:499,t:1527272015168};\\\", \\\"{x:1599,y:499,t:1527272015183};\\\", \\\"{x:1598,y:501,t:1527272015201};\\\", \\\"{x:1596,y:501,t:1527272015218};\\\", \\\"{x:1595,y:502,t:1527272015238};\\\", \\\"{x:1593,y:502,t:1527272015287};\\\", \\\"{x:1593,y:503,t:1527272015301};\\\", \\\"{x:1592,y:503,t:1527272015408};\\\", \\\"{x:1590,y:505,t:1527272017328};\\\", \\\"{x:1580,y:516,t:1527272017336};\\\", \\\"{x:1558,y:539,t:1527272017353};\\\", \\\"{x:1530,y:564,t:1527272017370};\\\", \\\"{x:1503,y:591,t:1527272017387};\\\", \\\"{x:1474,y:620,t:1527272017403};\\\", \\\"{x:1450,y:644,t:1527272017420};\\\", \\\"{x:1433,y:662,t:1527272017436};\\\", \\\"{x:1422,y:674,t:1527272017453};\\\", \\\"{x:1410,y:686,t:1527272017470};\\\", \\\"{x:1398,y:702,t:1527272017486};\\\", \\\"{x:1380,y:722,t:1527272017503};\\\", \\\"{x:1369,y:734,t:1527272017519};\\\", \\\"{x:1361,y:743,t:1527272017535};\\\", \\\"{x:1355,y:749,t:1527272017553};\\\", \\\"{x:1349,y:757,t:1527272017569};\\\", \\\"{x:1343,y:765,t:1527272017586};\\\", \\\"{x:1341,y:768,t:1527272017604};\\\", \\\"{x:1339,y:771,t:1527272017619};\\\", \\\"{x:1337,y:774,t:1527272017636};\\\", \\\"{x:1336,y:776,t:1527272017653};\\\", \\\"{x:1335,y:778,t:1527272017670};\\\", \\\"{x:1335,y:777,t:1527272018024};\\\", \\\"{x:1335,y:775,t:1527272018040};\\\", \\\"{x:1336,y:775,t:1527272018063};\\\", \\\"{x:1336,y:773,t:1527272018136};\\\", \\\"{x:1337,y:772,t:1527272018168};\\\", \\\"{x:1338,y:770,t:1527272018199};\\\", \\\"{x:1338,y:769,t:1527272018208};\\\", \\\"{x:1339,y:769,t:1527272018231};\\\", \\\"{x:1339,y:767,t:1527272018264};\\\", \\\"{x:1339,y:766,t:1527272018296};\\\", \\\"{x:1339,y:764,t:1527272018320};\\\", \\\"{x:1339,y:763,t:1527272018338};\\\", \\\"{x:1339,y:761,t:1527272018384};\\\", \\\"{x:1343,y:761,t:1527272022872};\\\", \\\"{x:1348,y:767,t:1527272022890};\\\", \\\"{x:1351,y:770,t:1527272022909};\\\", \\\"{x:1353,y:772,t:1527272022925};\\\", \\\"{x:1355,y:774,t:1527272022940};\\\", \\\"{x:1355,y:775,t:1527272022958};\\\", \\\"{x:1355,y:776,t:1527272022975};\\\", \\\"{x:1355,y:778,t:1527272022990};\\\", \\\"{x:1355,y:779,t:1527272023007};\\\", \\\"{x:1355,y:781,t:1527272023024};\\\", \\\"{x:1355,y:782,t:1527272023119};\\\", \\\"{x:1354,y:782,t:1527272023135};\\\", \\\"{x:1352,y:782,t:1527272023143};\\\", \\\"{x:1349,y:782,t:1527272023157};\\\", \\\"{x:1332,y:773,t:1527272023174};\\\", \\\"{x:1318,y:763,t:1527272023190};\\\", \\\"{x:1232,y:718,t:1527272023208};\\\", \\\"{x:1152,y:670,t:1527272023224};\\\", \\\"{x:1106,y:634,t:1527272023240};\\\", \\\"{x:1092,y:616,t:1527272023257};\\\", \\\"{x:1083,y:601,t:1527272023274};\\\", \\\"{x:1081,y:596,t:1527272023291};\\\", \\\"{x:1081,y:589,t:1527272023308};\\\", \\\"{x:1083,y:587,t:1527272023324};\\\", \\\"{x:1090,y:585,t:1527272023340};\\\", \\\"{x:1094,y:584,t:1527272023358};\\\", \\\"{x:1103,y:581,t:1527272023374};\\\", \\\"{x:1113,y:578,t:1527272023391};\\\", \\\"{x:1124,y:572,t:1527272023407};\\\", \\\"{x:1130,y:569,t:1527272023424};\\\", \\\"{x:1136,y:567,t:1527272023441};\\\", \\\"{x:1143,y:562,t:1527272023458};\\\", \\\"{x:1148,y:560,t:1527272023474};\\\", \\\"{x:1154,y:557,t:1527272023492};\\\", \\\"{x:1165,y:553,t:1527272023507};\\\", \\\"{x:1179,y:548,t:1527272023525};\\\", \\\"{x:1194,y:541,t:1527272023542};\\\", \\\"{x:1209,y:533,t:1527272023558};\\\", \\\"{x:1223,y:523,t:1527272023575};\\\", \\\"{x:1242,y:510,t:1527272023591};\\\", \\\"{x:1248,y:505,t:1527272023608};\\\", \\\"{x:1250,y:503,t:1527272023625};\\\", \\\"{x:1251,y:503,t:1527272023726};\\\", \\\"{x:1252,y:503,t:1527272023743};\\\", \\\"{x:1253,y:503,t:1527272023758};\\\", \\\"{x:1255,y:504,t:1527272023774};\\\", \\\"{x:1256,y:516,t:1527272023791};\\\", \\\"{x:1258,y:527,t:1527272023808};\\\", \\\"{x:1258,y:540,t:1527272023825};\\\", \\\"{x:1258,y:549,t:1527272023841};\\\", \\\"{x:1258,y:561,t:1527272023858};\\\", \\\"{x:1258,y:569,t:1527272023874};\\\", \\\"{x:1258,y:575,t:1527272023891};\\\", \\\"{x:1258,y:583,t:1527272023908};\\\", \\\"{x:1258,y:586,t:1527272023924};\\\", \\\"{x:1257,y:589,t:1527272023941};\\\", \\\"{x:1257,y:590,t:1527272023959};\\\", \\\"{x:1257,y:593,t:1527272023974};\\\", \\\"{x:1255,y:596,t:1527272023991};\\\", \\\"{x:1254,y:600,t:1527272024008};\\\", \\\"{x:1253,y:606,t:1527272024024};\\\", \\\"{x:1250,y:612,t:1527272024041};\\\", \\\"{x:1247,y:619,t:1527272024058};\\\", \\\"{x:1245,y:628,t:1527272024074};\\\", \\\"{x:1242,y:638,t:1527272024091};\\\", \\\"{x:1239,y:650,t:1527272024108};\\\", \\\"{x:1235,y:658,t:1527272024124};\\\", \\\"{x:1231,y:667,t:1527272024141};\\\", \\\"{x:1229,y:676,t:1527272024158};\\\", \\\"{x:1227,y:683,t:1527272024174};\\\", \\\"{x:1226,y:689,t:1527272024192};\\\", \\\"{x:1224,y:691,t:1527272024209};\\\", \\\"{x:1224,y:693,t:1527272024225};\\\", \\\"{x:1224,y:694,t:1527272024241};\\\", \\\"{x:1224,y:695,t:1527272024350};\\\", \\\"{x:1224,y:692,t:1527272028400};\\\", \\\"{x:1225,y:689,t:1527272028412};\\\", \\\"{x:1226,y:686,t:1527272028429};\\\", \\\"{x:1229,y:680,t:1527272028445};\\\", \\\"{x:1231,y:677,t:1527272028462};\\\", \\\"{x:1235,y:669,t:1527272028479};\\\", \\\"{x:1237,y:664,t:1527272028494};\\\", \\\"{x:1239,y:660,t:1527272028512};\\\", \\\"{x:1241,y:656,t:1527272028528};\\\", \\\"{x:1242,y:653,t:1527272028546};\\\", \\\"{x:1244,y:649,t:1527272028562};\\\", \\\"{x:1244,y:648,t:1527272028578};\\\", \\\"{x:1245,y:646,t:1527272028596};\\\", \\\"{x:1247,y:643,t:1527272028612};\\\", \\\"{x:1248,y:640,t:1527272028628};\\\", \\\"{x:1249,y:636,t:1527272028645};\\\", \\\"{x:1251,y:633,t:1527272028661};\\\", \\\"{x:1256,y:626,t:1527272028678};\\\", \\\"{x:1257,y:621,t:1527272028695};\\\", \\\"{x:1261,y:613,t:1527272028712};\\\", \\\"{x:1264,y:610,t:1527272028729};\\\", \\\"{x:1267,y:606,t:1527272028746};\\\", \\\"{x:1269,y:601,t:1527272028762};\\\", \\\"{x:1272,y:597,t:1527272028779};\\\", \\\"{x:1275,y:592,t:1527272028795};\\\", \\\"{x:1276,y:591,t:1527272028811};\\\", \\\"{x:1277,y:589,t:1527272028828};\\\", \\\"{x:1278,y:587,t:1527272028845};\\\", \\\"{x:1279,y:585,t:1527272028861};\\\", \\\"{x:1279,y:584,t:1527272028879};\\\", \\\"{x:1280,y:584,t:1527272028896};\\\", \\\"{x:1281,y:582,t:1527272028911};\\\", \\\"{x:1282,y:579,t:1527272028928};\\\", \\\"{x:1282,y:578,t:1527272028946};\\\", \\\"{x:1282,y:577,t:1527272028962};\\\", \\\"{x:1282,y:576,t:1527272029223};\\\", \\\"{x:1282,y:575,t:1527272030047};\\\", \\\"{x:1279,y:573,t:1527272030062};\\\", \\\"{x:1275,y:573,t:1527272030080};\\\", \\\"{x:1270,y:573,t:1527272030096};\\\", \\\"{x:1264,y:573,t:1527272030112};\\\", \\\"{x:1249,y:573,t:1527272030130};\\\", \\\"{x:1230,y:573,t:1527272030146};\\\", \\\"{x:1204,y:573,t:1527272030163};\\\", \\\"{x:1164,y:576,t:1527272030179};\\\", \\\"{x:1114,y:581,t:1527272030196};\\\", \\\"{x:1065,y:584,t:1527272030212};\\\", \\\"{x:1021,y:584,t:1527272030230};\\\", \\\"{x:962,y:584,t:1527272030247};\\\", \\\"{x:930,y:584,t:1527272030263};\\\", \\\"{x:906,y:584,t:1527272030279};\\\", \\\"{x:883,y:584,t:1527272030296};\\\", \\\"{x:854,y:583,t:1527272030313};\\\", \\\"{x:819,y:578,t:1527272030331};\\\", \\\"{x:785,y:573,t:1527272030346};\\\", \\\"{x:762,y:570,t:1527272030364};\\\", \\\"{x:744,y:567,t:1527272030381};\\\", \\\"{x:739,y:566,t:1527272030396};\\\", \\\"{x:736,y:565,t:1527272030413};\\\", \\\"{x:734,y:564,t:1527272030430};\\\", \\\"{x:732,y:563,t:1527272030447};\\\", \\\"{x:730,y:562,t:1527272030464};\\\", \\\"{x:725,y:559,t:1527272030480};\\\", \\\"{x:721,y:555,t:1527272030498};\\\", \\\"{x:718,y:552,t:1527272030513};\\\", \\\"{x:713,y:548,t:1527272030531};\\\", \\\"{x:706,y:542,t:1527272030547};\\\", \\\"{x:698,y:538,t:1527272030563};\\\", \\\"{x:687,y:532,t:1527272030580};\\\", \\\"{x:675,y:527,t:1527272030598};\\\", \\\"{x:666,y:523,t:1527272030614};\\\", \\\"{x:653,y:519,t:1527272030630};\\\", \\\"{x:651,y:518,t:1527272030647};\\\", \\\"{x:649,y:518,t:1527272030665};\\\", \\\"{x:648,y:517,t:1527272030681};\\\", \\\"{x:647,y:517,t:1527272030710};\\\", \\\"{x:646,y:517,t:1527272030719};\\\", \\\"{x:645,y:517,t:1527272030731};\\\", \\\"{x:641,y:516,t:1527272030747};\\\", \\\"{x:634,y:514,t:1527272030764};\\\", \\\"{x:623,y:511,t:1527272030781};\\\", \\\"{x:619,y:509,t:1527272030798};\\\", \\\"{x:616,y:508,t:1527272030814};\\\", \\\"{x:615,y:508,t:1527272030831};\\\", \\\"{x:614,y:508,t:1527272031134};\\\", \\\"{x:612,y:508,t:1527272031148};\\\", \\\"{x:612,y:509,t:1527272031164};\\\", \\\"{x:611,y:511,t:1527272031180};\\\", \\\"{x:610,y:514,t:1527272031198};\\\", \\\"{x:608,y:519,t:1527272031215};\\\", \\\"{x:607,y:526,t:1527272031230};\\\", \\\"{x:598,y:539,t:1527272031247};\\\", \\\"{x:589,y:557,t:1527272031264};\\\", \\\"{x:577,y:576,t:1527272031281};\\\", \\\"{x:566,y:596,t:1527272031298};\\\", \\\"{x:558,y:613,t:1527272031315};\\\", \\\"{x:551,y:626,t:1527272031332};\\\", \\\"{x:549,y:635,t:1527272031348};\\\", \\\"{x:546,y:642,t:1527272031364};\\\", \\\"{x:544,y:646,t:1527272031382};\\\", \\\"{x:542,y:651,t:1527272031398};\\\", \\\"{x:540,y:657,t:1527272031414};\\\", \\\"{x:538,y:660,t:1527272031431};\\\", \\\"{x:537,y:662,t:1527272031448};\\\", \\\"{x:536,y:664,t:1527272031465};\\\", \\\"{x:535,y:668,t:1527272031481};\\\", \\\"{x:534,y:668,t:1527272031499};\\\", \\\"{x:534,y:671,t:1527272031515};\\\", \\\"{x:534,y:674,t:1527272031531};\\\", \\\"{x:534,y:676,t:1527272031549};\\\", \\\"{x:534,y:680,t:1527272031565};\\\", \\\"{x:534,y:684,t:1527272031581};\\\", \\\"{x:534,y:692,t:1527272031599};\\\", \\\"{x:534,y:700,t:1527272031615};\\\", \\\"{x:534,y:704,t:1527272031632};\\\", \\\"{x:534,y:706,t:1527272031648};\\\", \\\"{x:534,y:710,t:1527272031665};\\\", \\\"{x:533,y:714,t:1527272031681};\\\", \\\"{x:533,y:718,t:1527272031698};\\\", \\\"{x:531,y:723,t:1527272031716};\\\", \\\"{x:530,y:726,t:1527272031733};\\\", \\\"{x:530,y:727,t:1527272031747};\\\", \\\"{x:530,y:728,t:1527272031839};\\\", \\\"{x:530,y:729,t:1527272031847};\\\", \\\"{x:530,y:731,t:1527272031864};\\\", \\\"{x:530,y:732,t:1527272031881};\\\", \\\"{x:530,y:734,t:1527272031897};\\\" ] }, { \\\"rt\\\": 20918, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 286351, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"K8DJ0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:530,y:733,t:1527272034119};\\\", \\\"{x:530,y:732,t:1527272034150};\\\", \\\"{x:530,y:731,t:1527272034174};\\\", \\\"{x:530,y:730,t:1527272034206};\\\", \\\"{x:530,y:729,t:1527272034230};\\\", \\\"{x:529,y:728,t:1527272034262};\\\", \\\"{x:529,y:727,t:1527272034327};\\\", \\\"{x:529,y:726,t:1527272034367};\\\", \\\"{x:528,y:725,t:1527272034407};\\\", \\\"{x:528,y:724,t:1527272034463};\\\", \\\"{x:528,y:723,t:1527272036936};\\\", \\\"{x:530,y:723,t:1527272036943};\\\", \\\"{x:532,y:723,t:1527272036958};\\\", \\\"{x:538,y:723,t:1527272036974};\\\", \\\"{x:547,y:723,t:1527272036991};\\\", \\\"{x:568,y:728,t:1527272037009};\\\", \\\"{x:616,y:737,t:1527272037023};\\\", \\\"{x:678,y:745,t:1527272037040};\\\", \\\"{x:716,y:754,t:1527272037052};\\\", \\\"{x:788,y:763,t:1527272037070};\\\", \\\"{x:855,y:773,t:1527272037085};\\\", \\\"{x:947,y:788,t:1527272037103};\\\", \\\"{x:994,y:796,t:1527272037120};\\\", \\\"{x:1031,y:796,t:1527272037135};\\\", \\\"{x:1057,y:796,t:1527272037152};\\\", \\\"{x:1076,y:796,t:1527272037169};\\\", \\\"{x:1095,y:796,t:1527272037186};\\\", \\\"{x:1117,y:796,t:1527272037203};\\\", \\\"{x:1144,y:796,t:1527272037219};\\\", \\\"{x:1167,y:794,t:1527272037236};\\\", \\\"{x:1199,y:794,t:1527272037252};\\\", \\\"{x:1241,y:794,t:1527272037270};\\\", \\\"{x:1300,y:794,t:1527272037285};\\\", \\\"{x:1339,y:794,t:1527272037303};\\\", \\\"{x:1369,y:794,t:1527272037319};\\\", \\\"{x:1397,y:794,t:1527272037337};\\\", \\\"{x:1418,y:794,t:1527272037353};\\\", \\\"{x:1433,y:794,t:1527272037370};\\\", \\\"{x:1444,y:794,t:1527272037386};\\\", \\\"{x:1449,y:794,t:1527272037403};\\\", \\\"{x:1451,y:794,t:1527272037420};\\\", \\\"{x:1453,y:794,t:1527272037437};\\\", \\\"{x:1456,y:794,t:1527272037453};\\\", \\\"{x:1458,y:794,t:1527272037469};\\\", \\\"{x:1459,y:794,t:1527272037494};\\\", \\\"{x:1460,y:794,t:1527272037518};\\\", \\\"{x:1461,y:794,t:1527272037526};\\\", \\\"{x:1462,y:794,t:1527272037537};\\\", \\\"{x:1464,y:794,t:1527272037554};\\\", \\\"{x:1466,y:795,t:1527272037570};\\\", \\\"{x:1467,y:796,t:1527272037616};\\\", \\\"{x:1468,y:797,t:1527272037791};\\\", \\\"{x:1469,y:798,t:1527272037804};\\\", \\\"{x:1470,y:798,t:1527272037822};\\\", \\\"{x:1472,y:799,t:1527272037837};\\\", \\\"{x:1473,y:799,t:1527272037871};\\\", \\\"{x:1474,y:800,t:1527272037911};\\\", \\\"{x:1475,y:800,t:1527272037921};\\\", \\\"{x:1475,y:801,t:1527272037938};\\\", \\\"{x:1475,y:800,t:1527272038143};\\\", \\\"{x:1475,y:798,t:1527272038154};\\\", \\\"{x:1475,y:793,t:1527272038171};\\\", \\\"{x:1475,y:786,t:1527272038188};\\\", \\\"{x:1474,y:779,t:1527272038204};\\\", \\\"{x:1472,y:771,t:1527272038221};\\\", \\\"{x:1471,y:765,t:1527272038238};\\\", \\\"{x:1471,y:761,t:1527272038255};\\\", \\\"{x:1470,y:752,t:1527272038271};\\\", \\\"{x:1468,y:746,t:1527272038288};\\\", \\\"{x:1467,y:742,t:1527272038304};\\\", \\\"{x:1466,y:738,t:1527272038321};\\\", \\\"{x:1465,y:734,t:1527272038338};\\\", \\\"{x:1464,y:732,t:1527272038355};\\\", \\\"{x:1463,y:728,t:1527272038371};\\\", \\\"{x:1461,y:722,t:1527272038388};\\\", \\\"{x:1460,y:717,t:1527272038406};\\\", \\\"{x:1459,y:712,t:1527272038421};\\\", \\\"{x:1457,y:705,t:1527272038439};\\\", \\\"{x:1454,y:698,t:1527272038455};\\\", \\\"{x:1452,y:690,t:1527272038471};\\\", \\\"{x:1451,y:685,t:1527272038489};\\\", \\\"{x:1449,y:679,t:1527272038505};\\\", \\\"{x:1448,y:675,t:1527272038521};\\\", \\\"{x:1446,y:671,t:1527272038538};\\\", \\\"{x:1445,y:669,t:1527272038555};\\\", \\\"{x:1443,y:666,t:1527272038571};\\\", \\\"{x:1443,y:665,t:1527272038590};\\\", \\\"{x:1443,y:664,t:1527272038605};\\\", \\\"{x:1443,y:663,t:1527272038622};\\\", \\\"{x:1441,y:661,t:1527272038637};\\\", \\\"{x:1441,y:659,t:1527272038655};\\\", \\\"{x:1440,y:653,t:1527272038672};\\\", \\\"{x:1438,y:648,t:1527272038688};\\\", \\\"{x:1438,y:646,t:1527272038705};\\\", \\\"{x:1438,y:643,t:1527272038722};\\\", \\\"{x:1437,y:641,t:1527272038738};\\\", \\\"{x:1437,y:638,t:1527272038755};\\\", \\\"{x:1436,y:631,t:1527272038771};\\\", \\\"{x:1436,y:626,t:1527272038788};\\\", \\\"{x:1436,y:620,t:1527272038805};\\\", \\\"{x:1436,y:615,t:1527272038822};\\\", \\\"{x:1437,y:608,t:1527272038839};\\\", \\\"{x:1444,y:594,t:1527272038856};\\\", \\\"{x:1447,y:585,t:1527272038872};\\\", \\\"{x:1449,y:576,t:1527272038888};\\\", \\\"{x:1453,y:569,t:1527272038905};\\\", \\\"{x:1456,y:561,t:1527272038922};\\\", \\\"{x:1459,y:554,t:1527272038940};\\\", \\\"{x:1461,y:549,t:1527272038956};\\\", \\\"{x:1463,y:544,t:1527272038972};\\\", \\\"{x:1465,y:540,t:1527272038989};\\\", \\\"{x:1466,y:538,t:1527272039005};\\\", \\\"{x:1466,y:537,t:1527272039023};\\\", \\\"{x:1467,y:535,t:1527272039039};\\\", \\\"{x:1468,y:534,t:1527272039056};\\\", \\\"{x:1465,y:540,t:1527272039960};\\\", \\\"{x:1457,y:550,t:1527272039972};\\\", \\\"{x:1439,y:570,t:1527272039990};\\\", \\\"{x:1392,y:622,t:1527272040006};\\\", \\\"{x:1352,y:668,t:1527272040023};\\\", \\\"{x:1298,y:734,t:1527272040039};\\\", \\\"{x:1245,y:788,t:1527272040057};\\\", \\\"{x:1195,y:837,t:1527272040073};\\\", \\\"{x:1153,y:875,t:1527272040090};\\\", \\\"{x:1133,y:893,t:1527272040106};\\\", \\\"{x:1125,y:900,t:1527272040123};\\\", \\\"{x:1123,y:901,t:1527272040139};\\\", \\\"{x:1123,y:902,t:1527272040280};\\\", \\\"{x:1121,y:903,t:1527272040367};\\\", \\\"{x:1121,y:902,t:1527272041614};\\\", \\\"{x:1125,y:899,t:1527272041625};\\\", \\\"{x:1132,y:896,t:1527272041642};\\\", \\\"{x:1136,y:893,t:1527272041658};\\\", \\\"{x:1142,y:888,t:1527272041674};\\\", \\\"{x:1150,y:883,t:1527272041692};\\\", \\\"{x:1157,y:879,t:1527272041709};\\\", \\\"{x:1162,y:877,t:1527272041725};\\\", \\\"{x:1167,y:874,t:1527272041742};\\\", \\\"{x:1176,y:870,t:1527272041757};\\\", \\\"{x:1180,y:868,t:1527272041774};\\\", \\\"{x:1182,y:866,t:1527272041792};\\\", \\\"{x:1185,y:866,t:1527272041809};\\\", \\\"{x:1186,y:864,t:1527272041825};\\\", \\\"{x:1189,y:864,t:1527272041842};\\\", \\\"{x:1193,y:861,t:1527272041859};\\\", \\\"{x:1198,y:857,t:1527272041875};\\\", \\\"{x:1200,y:855,t:1527272041892};\\\", \\\"{x:1204,y:852,t:1527272041908};\\\", \\\"{x:1205,y:851,t:1527272041925};\\\", \\\"{x:1207,y:849,t:1527272041943};\\\", \\\"{x:1207,y:848,t:1527272041959};\\\", \\\"{x:1208,y:847,t:1527272041983};\\\", \\\"{x:1209,y:847,t:1527272042006};\\\", \\\"{x:1209,y:846,t:1527272042015};\\\", \\\"{x:1209,y:845,t:1527272042026};\\\", \\\"{x:1210,y:842,t:1527272042042};\\\", \\\"{x:1211,y:841,t:1527272042059};\\\", \\\"{x:1211,y:839,t:1527272042076};\\\", \\\"{x:1211,y:837,t:1527272042093};\\\", \\\"{x:1212,y:835,t:1527272042110};\\\", \\\"{x:1213,y:833,t:1527272042126};\\\", \\\"{x:1213,y:832,t:1527272042150};\\\", \\\"{x:1213,y:831,t:1527272042175};\\\", \\\"{x:1213,y:830,t:1527272044007};\\\", \\\"{x:1213,y:828,t:1527272051887};\\\", \\\"{x:1185,y:806,t:1527272051906};\\\", \\\"{x:1148,y:779,t:1527272051922};\\\", \\\"{x:1110,y:759,t:1527272051938};\\\", \\\"{x:1077,y:737,t:1527272051955};\\\", \\\"{x:1050,y:721,t:1527272051972};\\\", \\\"{x:1028,y:705,t:1527272051988};\\\", \\\"{x:999,y:686,t:1527272052004};\\\", \\\"{x:980,y:671,t:1527272052022};\\\", \\\"{x:965,y:660,t:1527272052037};\\\", \\\"{x:941,y:642,t:1527272052054};\\\", \\\"{x:926,y:634,t:1527272052072};\\\", \\\"{x:911,y:626,t:1527272052089};\\\", \\\"{x:894,y:617,t:1527272052104};\\\", \\\"{x:877,y:612,t:1527272052121};\\\", \\\"{x:864,y:610,t:1527272052132};\\\", \\\"{x:830,y:605,t:1527272052148};\\\", \\\"{x:799,y:597,t:1527272052165};\\\", \\\"{x:754,y:590,t:1527272052182};\\\", \\\"{x:729,y:586,t:1527272052198};\\\", \\\"{x:706,y:581,t:1527272052215};\\\", \\\"{x:680,y:577,t:1527272052232};\\\", \\\"{x:658,y:574,t:1527272052248};\\\", \\\"{x:639,y:571,t:1527272052265};\\\", \\\"{x:623,y:569,t:1527272052282};\\\", \\\"{x:605,y:568,t:1527272052298};\\\", \\\"{x:587,y:565,t:1527272052315};\\\", \\\"{x:571,y:563,t:1527272052332};\\\", \\\"{x:555,y:563,t:1527272052348};\\\", \\\"{x:543,y:561,t:1527272052366};\\\", \\\"{x:533,y:559,t:1527272052382};\\\", \\\"{x:529,y:559,t:1527272052398};\\\", \\\"{x:524,y:559,t:1527272052415};\\\", \\\"{x:518,y:559,t:1527272052432};\\\", \\\"{x:506,y:559,t:1527272052448};\\\", \\\"{x:494,y:559,t:1527272052465};\\\", \\\"{x:476,y:559,t:1527272052482};\\\", \\\"{x:458,y:559,t:1527272052498};\\\", \\\"{x:448,y:558,t:1527272052515};\\\", \\\"{x:446,y:558,t:1527272052532};\\\", \\\"{x:445,y:558,t:1527272052549};\\\", \\\"{x:444,y:558,t:1527272052583};\\\", \\\"{x:443,y:557,t:1527272052695};\\\", \\\"{x:443,y:556,t:1527272052710};\\\", \\\"{x:442,y:556,t:1527272052718};\\\", \\\"{x:439,y:554,t:1527272052734};\\\", \\\"{x:431,y:549,t:1527272052749};\\\", \\\"{x:421,y:547,t:1527272052765};\\\", \\\"{x:407,y:542,t:1527272052782};\\\", \\\"{x:401,y:541,t:1527272052799};\\\", \\\"{x:400,y:540,t:1527272052815};\\\", \\\"{x:400,y:539,t:1527272052832};\\\", \\\"{x:399,y:539,t:1527272052910};\\\", \\\"{x:398,y:539,t:1527272053031};\\\", \\\"{x:398,y:539,t:1527272053146};\\\", \\\"{x:398,y:540,t:1527272053221};\\\", \\\"{x:398,y:543,t:1527272053232};\\\", \\\"{x:400,y:548,t:1527272053249};\\\", \\\"{x:401,y:557,t:1527272053267};\\\", \\\"{x:405,y:571,t:1527272053283};\\\", \\\"{x:411,y:586,t:1527272053299};\\\", \\\"{x:421,y:604,t:1527272053317};\\\", \\\"{x:429,y:623,t:1527272053332};\\\", \\\"{x:435,y:636,t:1527272053349};\\\", \\\"{x:443,y:650,t:1527272053367};\\\", \\\"{x:449,y:657,t:1527272053382};\\\", \\\"{x:455,y:664,t:1527272053399};\\\", \\\"{x:461,y:670,t:1527272053417};\\\", \\\"{x:466,y:676,t:1527272053433};\\\", \\\"{x:469,y:678,t:1527272053449};\\\", \\\"{x:470,y:680,t:1527272053466};\\\", \\\"{x:471,y:682,t:1527272053483};\\\", \\\"{x:472,y:683,t:1527272053502};\\\", \\\"{x:473,y:685,t:1527272053533};\\\", \\\"{x:473,y:686,t:1527272053549};\\\", \\\"{x:482,y:695,t:1527272053566};\\\", \\\"{x:487,y:703,t:1527272053583};\\\", \\\"{x:493,y:713,t:1527272053600};\\\", \\\"{x:500,y:725,t:1527272053617};\\\", \\\"{x:505,y:737,t:1527272053633};\\\", \\\"{x:508,y:747,t:1527272053649};\\\", \\\"{x:509,y:756,t:1527272053666};\\\", \\\"{x:509,y:761,t:1527272053683};\\\", \\\"{x:509,y:766,t:1527272053699};\\\", \\\"{x:509,y:767,t:1527272053716};\\\", \\\"{x:510,y:767,t:1527272053758};\\\", \\\"{x:509,y:765,t:1527272053935};\\\", \\\"{x:506,y:761,t:1527272053951};\\\", \\\"{x:505,y:756,t:1527272053966};\\\", \\\"{x:503,y:753,t:1527272053983};\\\", \\\"{x:501,y:750,t:1527272054000};\\\", \\\"{x:500,y:748,t:1527272054016};\\\", \\\"{x:497,y:743,t:1527272054033};\\\", \\\"{x:494,y:739,t:1527272054050};\\\", \\\"{x:492,y:737,t:1527272054066};\\\", \\\"{x:490,y:732,t:1527272054083};\\\", \\\"{x:489,y:729,t:1527272054100};\\\", \\\"{x:488,y:727,t:1527272054116};\\\", \\\"{x:488,y:726,t:1527272054133};\\\", \\\"{x:488,y:724,t:1527272054150};\\\" ] }, { \\\"rt\\\": 53675, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 341250, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"K8DJ0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B -F -F -F -B -B -12 PM-12 PM-F -F -E -B -F -F -12 PM-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:490,y:724,t:1527272060551};\\\", \\\"{x:497,y:724,t:1527272060558};\\\", \\\"{x:514,y:724,t:1527272060575};\\\", \\\"{x:552,y:724,t:1527272060591};\\\", \\\"{x:636,y:724,t:1527272060611};\\\", \\\"{x:722,y:727,t:1527272060625};\\\", \\\"{x:815,y:728,t:1527272060641};\\\", \\\"{x:909,y:728,t:1527272060656};\\\", \\\"{x:984,y:728,t:1527272060672};\\\", \\\"{x:1048,y:728,t:1527272060689};\\\", \\\"{x:1096,y:728,t:1527272060705};\\\", \\\"{x:1129,y:728,t:1527272060722};\\\", \\\"{x:1151,y:728,t:1527272060739};\\\", \\\"{x:1171,y:728,t:1527272060755};\\\", \\\"{x:1189,y:728,t:1527272060772};\\\", \\\"{x:1210,y:728,t:1527272060789};\\\", \\\"{x:1241,y:728,t:1527272060806};\\\", \\\"{x:1265,y:728,t:1527272060822};\\\", \\\"{x:1289,y:728,t:1527272060838};\\\", \\\"{x:1313,y:725,t:1527272060856};\\\", \\\"{x:1330,y:723,t:1527272060872};\\\", \\\"{x:1339,y:719,t:1527272060889};\\\", \\\"{x:1341,y:719,t:1527272060906};\\\", \\\"{x:1342,y:719,t:1527272060923};\\\", \\\"{x:1343,y:717,t:1527272061375};\\\", \\\"{x:1343,y:714,t:1527272061391};\\\", \\\"{x:1344,y:712,t:1527272061407};\\\", \\\"{x:1346,y:708,t:1527272061422};\\\", \\\"{x:1346,y:706,t:1527272061440};\\\", \\\"{x:1347,y:704,t:1527272061457};\\\", \\\"{x:1347,y:703,t:1527272061473};\\\", \\\"{x:1347,y:702,t:1527272061492};\\\", \\\"{x:1347,y:700,t:1527272061523};\\\", \\\"{x:1348,y:700,t:1527272061539};\\\", \\\"{x:1348,y:699,t:1527272061557};\\\", \\\"{x:1348,y:698,t:1527272061572};\\\", \\\"{x:1348,y:697,t:1527272061597};\\\", \\\"{x:1349,y:696,t:1527272061622};\\\", \\\"{x:1349,y:698,t:1527272062607};\\\", \\\"{x:1347,y:705,t:1527272062625};\\\", \\\"{x:1345,y:715,t:1527272062641};\\\", \\\"{x:1344,y:721,t:1527272062657};\\\", \\\"{x:1342,y:728,t:1527272062674};\\\", \\\"{x:1341,y:733,t:1527272062691};\\\", \\\"{x:1341,y:738,t:1527272062707};\\\", \\\"{x:1341,y:745,t:1527272062724};\\\", \\\"{x:1342,y:750,t:1527272062741};\\\", \\\"{x:1343,y:760,t:1527272062758};\\\", \\\"{x:1344,y:765,t:1527272062774};\\\", \\\"{x:1344,y:769,t:1527272062792};\\\", \\\"{x:1345,y:775,t:1527272062808};\\\", \\\"{x:1345,y:780,t:1527272062823};\\\", \\\"{x:1345,y:784,t:1527272062841};\\\", \\\"{x:1345,y:788,t:1527272062857};\\\", \\\"{x:1345,y:794,t:1527272062873};\\\", \\\"{x:1345,y:799,t:1527272062890};\\\", \\\"{x:1345,y:805,t:1527272062907};\\\", \\\"{x:1345,y:810,t:1527272062923};\\\", \\\"{x:1345,y:817,t:1527272062940};\\\", \\\"{x:1347,y:825,t:1527272062957};\\\", \\\"{x:1347,y:830,t:1527272062974};\\\", \\\"{x:1348,y:837,t:1527272062990};\\\", \\\"{x:1348,y:842,t:1527272063007};\\\", \\\"{x:1349,y:849,t:1527272063023};\\\", \\\"{x:1350,y:858,t:1527272063040};\\\", \\\"{x:1350,y:865,t:1527272063058};\\\", \\\"{x:1350,y:872,t:1527272063074};\\\", \\\"{x:1353,y:882,t:1527272063091};\\\", \\\"{x:1353,y:891,t:1527272063108};\\\", \\\"{x:1354,y:899,t:1527272063124};\\\", \\\"{x:1354,y:906,t:1527272063141};\\\", \\\"{x:1355,y:915,t:1527272063157};\\\", \\\"{x:1355,y:919,t:1527272063174};\\\", \\\"{x:1357,y:925,t:1527272063190};\\\", \\\"{x:1358,y:931,t:1527272063208};\\\", \\\"{x:1358,y:937,t:1527272063225};\\\", \\\"{x:1358,y:943,t:1527272063241};\\\", \\\"{x:1358,y:950,t:1527272063258};\\\", \\\"{x:1358,y:954,t:1527272063275};\\\", \\\"{x:1358,y:958,t:1527272063290};\\\", \\\"{x:1358,y:960,t:1527272063308};\\\", \\\"{x:1358,y:961,t:1527272063324};\\\", \\\"{x:1358,y:963,t:1527272063479};\\\", \\\"{x:1358,y:962,t:1527272063639};\\\", \\\"{x:1358,y:957,t:1527272063647};\\\", \\\"{x:1358,y:951,t:1527272063658};\\\", \\\"{x:1358,y:935,t:1527272063675};\\\", \\\"{x:1358,y:922,t:1527272063692};\\\", \\\"{x:1358,y:904,t:1527272063707};\\\", \\\"{x:1358,y:883,t:1527272063725};\\\", \\\"{x:1358,y:850,t:1527272063742};\\\", \\\"{x:1358,y:828,t:1527272063758};\\\", \\\"{x:1358,y:805,t:1527272063775};\\\", \\\"{x:1359,y:784,t:1527272063792};\\\", \\\"{x:1359,y:766,t:1527272063808};\\\", \\\"{x:1359,y:755,t:1527272063825};\\\", \\\"{x:1359,y:748,t:1527272063842};\\\", \\\"{x:1361,y:743,t:1527272063858};\\\", \\\"{x:1361,y:738,t:1527272063875};\\\", \\\"{x:1361,y:735,t:1527272063892};\\\", \\\"{x:1361,y:731,t:1527272063908};\\\", \\\"{x:1361,y:728,t:1527272063925};\\\", \\\"{x:1361,y:722,t:1527272063942};\\\", \\\"{x:1361,y:721,t:1527272063958};\\\", \\\"{x:1361,y:719,t:1527272063975};\\\", \\\"{x:1361,y:718,t:1527272063992};\\\", \\\"{x:1361,y:717,t:1527272064008};\\\", \\\"{x:1361,y:716,t:1527272064026};\\\", \\\"{x:1361,y:715,t:1527272064042};\\\", \\\"{x:1361,y:714,t:1527272064062};\\\", \\\"{x:1361,y:713,t:1527272064095};\\\", \\\"{x:1360,y:712,t:1527272064175};\\\", \\\"{x:1360,y:711,t:1527272064198};\\\", \\\"{x:1360,y:710,t:1527272064214};\\\", \\\"{x:1359,y:710,t:1527272064263};\\\", \\\"{x:1359,y:709,t:1527272064279};\\\", \\\"{x:1358,y:709,t:1527272064310};\\\", \\\"{x:1357,y:709,t:1527272064325};\\\", \\\"{x:1356,y:708,t:1527272064342};\\\", \\\"{x:1355,y:708,t:1527272064383};\\\", \\\"{x:1354,y:708,t:1527272064630};\\\", \\\"{x:1352,y:705,t:1527272064643};\\\", \\\"{x:1348,y:702,t:1527272064660};\\\", \\\"{x:1345,y:699,t:1527272064676};\\\", \\\"{x:1343,y:697,t:1527272064692};\\\", \\\"{x:1342,y:696,t:1527272064709};\\\", \\\"{x:1341,y:694,t:1527272064727};\\\", \\\"{x:1341,y:693,t:1527272064959};\\\", \\\"{x:1341,y:692,t:1527272064976};\\\", \\\"{x:1341,y:691,t:1527272064993};\\\", \\\"{x:1342,y:691,t:1527272065010};\\\", \\\"{x:1343,y:691,t:1527272065027};\\\", \\\"{x:1343,y:690,t:1527272065043};\\\", \\\"{x:1343,y:691,t:1527272065485};\\\", \\\"{x:1343,y:696,t:1527272065494};\\\", \\\"{x:1343,y:706,t:1527272065510};\\\", \\\"{x:1343,y:713,t:1527272065526};\\\", \\\"{x:1343,y:720,t:1527272065542};\\\", \\\"{x:1343,y:729,t:1527272065559};\\\", \\\"{x:1343,y:739,t:1527272065575};\\\", \\\"{x:1343,y:752,t:1527272065593};\\\", \\\"{x:1343,y:765,t:1527272065610};\\\", \\\"{x:1343,y:779,t:1527272065626};\\\", \\\"{x:1343,y:794,t:1527272065643};\\\", \\\"{x:1346,y:807,t:1527272065660};\\\", \\\"{x:1347,y:822,t:1527272065676};\\\", \\\"{x:1350,y:837,t:1527272065692};\\\", \\\"{x:1353,y:865,t:1527272065709};\\\", \\\"{x:1357,y:882,t:1527272065726};\\\", \\\"{x:1358,y:893,t:1527272065743};\\\", \\\"{x:1359,y:903,t:1527272065760};\\\", \\\"{x:1360,y:910,t:1527272065777};\\\", \\\"{x:1360,y:915,t:1527272065793};\\\", \\\"{x:1360,y:919,t:1527272065810};\\\", \\\"{x:1360,y:923,t:1527272065827};\\\", \\\"{x:1361,y:926,t:1527272065843};\\\", \\\"{x:1361,y:929,t:1527272065860};\\\", \\\"{x:1361,y:932,t:1527272065878};\\\", \\\"{x:1361,y:937,t:1527272065894};\\\", \\\"{x:1361,y:950,t:1527272065911};\\\", \\\"{x:1361,y:957,t:1527272065926};\\\", \\\"{x:1361,y:962,t:1527272065943};\\\", \\\"{x:1361,y:967,t:1527272065960};\\\", \\\"{x:1361,y:972,t:1527272065977};\\\", \\\"{x:1360,y:976,t:1527272065993};\\\", \\\"{x:1360,y:980,t:1527272066009};\\\", \\\"{x:1359,y:983,t:1527272066027};\\\", \\\"{x:1358,y:984,t:1527272066047};\\\", \\\"{x:1358,y:985,t:1527272066063};\\\", \\\"{x:1357,y:986,t:1527272066175};\\\", \\\"{x:1357,y:985,t:1527272066262};\\\", \\\"{x:1357,y:978,t:1527272066277};\\\", \\\"{x:1357,y:957,t:1527272066295};\\\", \\\"{x:1357,y:937,t:1527272066310};\\\", \\\"{x:1357,y:912,t:1527272066327};\\\", \\\"{x:1357,y:885,t:1527272066344};\\\", \\\"{x:1357,y:859,t:1527272066360};\\\", \\\"{x:1357,y:836,t:1527272066377};\\\", \\\"{x:1357,y:815,t:1527272066394};\\\", \\\"{x:1357,y:796,t:1527272066410};\\\", \\\"{x:1357,y:779,t:1527272066426};\\\", \\\"{x:1357,y:767,t:1527272066444};\\\", \\\"{x:1357,y:754,t:1527272066460};\\\", \\\"{x:1357,y:746,t:1527272066477};\\\", \\\"{x:1356,y:736,t:1527272066494};\\\", \\\"{x:1352,y:729,t:1527272066510};\\\", \\\"{x:1350,y:722,t:1527272066527};\\\", \\\"{x:1349,y:716,t:1527272066543};\\\", \\\"{x:1349,y:709,t:1527272066559};\\\", \\\"{x:1348,y:700,t:1527272066577};\\\", \\\"{x:1347,y:692,t:1527272066593};\\\", \\\"{x:1347,y:684,t:1527272066610};\\\", \\\"{x:1345,y:678,t:1527272066627};\\\", \\\"{x:1344,y:672,t:1527272066644};\\\", \\\"{x:1344,y:667,t:1527272066660};\\\", \\\"{x:1343,y:663,t:1527272066677};\\\", \\\"{x:1343,y:658,t:1527272066694};\\\", \\\"{x:1342,y:658,t:1527272066974};\\\", \\\"{x:1341,y:658,t:1527272066981};\\\", \\\"{x:1341,y:659,t:1527272067006};\\\", \\\"{x:1341,y:660,t:1527272067014};\\\", \\\"{x:1341,y:661,t:1527272067030};\\\", \\\"{x:1341,y:662,t:1527272067044};\\\", \\\"{x:1340,y:665,t:1527272067061};\\\", \\\"{x:1339,y:670,t:1527272067077};\\\", \\\"{x:1337,y:674,t:1527272067094};\\\", \\\"{x:1334,y:678,t:1527272067111};\\\", \\\"{x:1332,y:681,t:1527272067128};\\\", \\\"{x:1330,y:683,t:1527272067144};\\\", \\\"{x:1329,y:684,t:1527272067161};\\\", \\\"{x:1328,y:685,t:1527272067699};\\\", \\\"{x:1325,y:682,t:1527272076691};\\\", \\\"{x:1315,y:667,t:1527272076706};\\\", \\\"{x:1302,y:650,t:1527272076723};\\\", \\\"{x:1299,y:645,t:1527272076740};\\\", \\\"{x:1295,y:640,t:1527272076756};\\\", \\\"{x:1293,y:637,t:1527272076773};\\\", \\\"{x:1293,y:636,t:1527272076789};\\\", \\\"{x:1292,y:635,t:1527272076807};\\\", \\\"{x:1292,y:634,t:1527272076823};\\\", \\\"{x:1290,y:629,t:1527272076839};\\\", \\\"{x:1288,y:622,t:1527272076856};\\\", \\\"{x:1286,y:617,t:1527272076872};\\\", \\\"{x:1284,y:608,t:1527272076890};\\\", \\\"{x:1280,y:598,t:1527272076906};\\\", \\\"{x:1276,y:589,t:1527272076922};\\\", \\\"{x:1275,y:585,t:1527272076940};\\\", \\\"{x:1273,y:579,t:1527272076957};\\\", \\\"{x:1272,y:575,t:1527272076973};\\\", \\\"{x:1272,y:573,t:1527272076990};\\\", \\\"{x:1272,y:571,t:1527272077006};\\\", \\\"{x:1271,y:571,t:1527272077023};\\\", \\\"{x:1271,y:570,t:1527272077204};\\\", \\\"{x:1272,y:569,t:1527272077442};\\\", \\\"{x:1273,y:569,t:1527272077456};\\\", \\\"{x:1274,y:568,t:1527272077482};\\\", \\\"{x:1275,y:568,t:1527272077498};\\\", \\\"{x:1275,y:567,t:1527272077506};\\\", \\\"{x:1276,y:567,t:1527272077524};\\\", \\\"{x:1277,y:567,t:1527272077539};\\\", \\\"{x:1278,y:566,t:1527272077556};\\\", \\\"{x:1279,y:566,t:1527272077602};\\\", \\\"{x:1281,y:565,t:1527272077626};\\\", \\\"{x:1282,y:565,t:1527272079290};\\\", \\\"{x:1282,y:566,t:1527272080097};\\\", \\\"{x:1281,y:567,t:1527272080108};\\\", \\\"{x:1281,y:571,t:1527272080126};\\\", \\\"{x:1281,y:577,t:1527272080141};\\\", \\\"{x:1283,y:584,t:1527272080158};\\\", \\\"{x:1287,y:594,t:1527272080175};\\\", \\\"{x:1289,y:603,t:1527272080192};\\\", \\\"{x:1293,y:618,t:1527272080208};\\\", \\\"{x:1304,y:648,t:1527272080225};\\\", \\\"{x:1313,y:669,t:1527272080242};\\\", \\\"{x:1321,y:689,t:1527272080258};\\\", \\\"{x:1329,y:708,t:1527272080275};\\\", \\\"{x:1336,y:722,t:1527272080292};\\\", \\\"{x:1340,y:733,t:1527272080308};\\\", \\\"{x:1342,y:740,t:1527272080326};\\\", \\\"{x:1344,y:745,t:1527272080342};\\\", \\\"{x:1344,y:751,t:1527272080359};\\\", \\\"{x:1344,y:755,t:1527272080375};\\\", \\\"{x:1343,y:758,t:1527272080392};\\\", \\\"{x:1341,y:760,t:1527272080408};\\\", \\\"{x:1339,y:762,t:1527272080425};\\\", \\\"{x:1338,y:762,t:1527272080450};\\\", \\\"{x:1337,y:762,t:1527272080523};\\\", \\\"{x:1334,y:754,t:1527272080530};\\\", \\\"{x:1333,y:749,t:1527272080543};\\\", \\\"{x:1328,y:738,t:1527272080559};\\\", \\\"{x:1325,y:726,t:1527272080576};\\\", \\\"{x:1320,y:717,t:1527272080592};\\\", \\\"{x:1318,y:711,t:1527272080608};\\\", \\\"{x:1311,y:703,t:1527272080626};\\\", \\\"{x:1306,y:697,t:1527272080642};\\\", \\\"{x:1304,y:695,t:1527272080658};\\\", \\\"{x:1303,y:695,t:1527272080675};\\\", \\\"{x:1301,y:694,t:1527272080692};\\\", \\\"{x:1299,y:694,t:1527272080713};\\\", \\\"{x:1298,y:694,t:1527272080725};\\\", \\\"{x:1296,y:694,t:1527272080742};\\\", \\\"{x:1293,y:694,t:1527272080759};\\\", \\\"{x:1292,y:694,t:1527272080809};\\\", \\\"{x:1290,y:694,t:1527272080826};\\\", \\\"{x:1290,y:695,t:1527272080906};\\\", \\\"{x:1290,y:697,t:1527272080922};\\\", \\\"{x:1290,y:698,t:1527272080930};\\\", \\\"{x:1290,y:699,t:1527272080954};\\\", \\\"{x:1290,y:700,t:1527272080962};\\\", \\\"{x:1290,y:701,t:1527272080975};\\\", \\\"{x:1290,y:704,t:1527272080993};\\\", \\\"{x:1290,y:709,t:1527272081011};\\\", \\\"{x:1290,y:714,t:1527272081026};\\\", \\\"{x:1285,y:723,t:1527272081042};\\\", \\\"{x:1280,y:734,t:1527272081060};\\\", \\\"{x:1275,y:746,t:1527272081076};\\\", \\\"{x:1270,y:760,t:1527272081093};\\\", \\\"{x:1265,y:775,t:1527272081110};\\\", \\\"{x:1260,y:790,t:1527272081126};\\\", \\\"{x:1259,y:799,t:1527272081143};\\\", \\\"{x:1257,y:806,t:1527272081159};\\\", \\\"{x:1257,y:811,t:1527272081176};\\\", \\\"{x:1257,y:814,t:1527272081193};\\\", \\\"{x:1257,y:815,t:1527272081211};\\\", \\\"{x:1258,y:818,t:1527272081226};\\\", \\\"{x:1259,y:818,t:1527272081243};\\\", \\\"{x:1260,y:818,t:1527272081260};\\\", \\\"{x:1261,y:818,t:1527272081282};\\\", \\\"{x:1262,y:819,t:1527272081293};\\\", \\\"{x:1263,y:819,t:1527272081310};\\\", \\\"{x:1264,y:819,t:1527272081327};\\\", \\\"{x:1266,y:820,t:1527272081343};\\\", \\\"{x:1268,y:821,t:1527272081360};\\\", \\\"{x:1269,y:822,t:1527272081377};\\\", \\\"{x:1271,y:822,t:1527272081393};\\\", \\\"{x:1273,y:824,t:1527272081410};\\\", \\\"{x:1273,y:825,t:1527272081434};\\\", \\\"{x:1273,y:827,t:1527272081442};\\\", \\\"{x:1273,y:828,t:1527272081460};\\\", \\\"{x:1273,y:829,t:1527272081476};\\\", \\\"{x:1273,y:830,t:1527272081493};\\\", \\\"{x:1273,y:831,t:1527272081755};\\\", \\\"{x:1273,y:832,t:1527272081778};\\\", \\\"{x:1274,y:833,t:1527272081794};\\\", \\\"{x:1275,y:833,t:1527272081810};\\\", \\\"{x:1276,y:834,t:1527272081850};\\\", \\\"{x:1277,y:835,t:1527272081882};\\\", \\\"{x:1278,y:836,t:1527272081906};\\\", \\\"{x:1278,y:837,t:1527272081922};\\\", \\\"{x:1279,y:837,t:1527272081930};\\\", \\\"{x:1280,y:839,t:1527272081944};\\\", \\\"{x:1280,y:841,t:1527272081961};\\\", \\\"{x:1281,y:843,t:1527272081977};\\\", \\\"{x:1282,y:847,t:1527272081994};\\\", \\\"{x:1282,y:851,t:1527272082010};\\\", \\\"{x:1282,y:856,t:1527272082026};\\\", \\\"{x:1282,y:860,t:1527272082043};\\\", \\\"{x:1282,y:867,t:1527272082060};\\\", \\\"{x:1282,y:872,t:1527272082077};\\\", \\\"{x:1282,y:875,t:1527272082093};\\\", \\\"{x:1282,y:879,t:1527272082110};\\\", \\\"{x:1282,y:883,t:1527272082127};\\\", \\\"{x:1283,y:887,t:1527272082144};\\\", \\\"{x:1285,y:891,t:1527272082161};\\\", \\\"{x:1285,y:894,t:1527272082177};\\\", \\\"{x:1285,y:898,t:1527272082194};\\\", \\\"{x:1285,y:901,t:1527272082210};\\\", \\\"{x:1286,y:905,t:1527272082227};\\\", \\\"{x:1286,y:909,t:1527272082244};\\\", \\\"{x:1286,y:912,t:1527272082261};\\\", \\\"{x:1286,y:917,t:1527272082277};\\\", \\\"{x:1286,y:922,t:1527272082294};\\\", \\\"{x:1286,y:926,t:1527272082310};\\\", \\\"{x:1286,y:929,t:1527272082327};\\\", \\\"{x:1286,y:933,t:1527272082344};\\\", \\\"{x:1286,y:937,t:1527272082360};\\\", \\\"{x:1286,y:941,t:1527272082376};\\\", \\\"{x:1287,y:946,t:1527272082393};\\\", \\\"{x:1287,y:947,t:1527272082411};\\\", \\\"{x:1288,y:947,t:1527272082433};\\\", \\\"{x:1288,y:949,t:1527272082489};\\\", \\\"{x:1288,y:950,t:1527272082521};\\\", \\\"{x:1288,y:952,t:1527272082569};\\\", \\\"{x:1288,y:953,t:1527272082658};\\\", \\\"{x:1288,y:954,t:1527272082665};\\\", \\\"{x:1288,y:955,t:1527272082682};\\\", \\\"{x:1288,y:956,t:1527272082694};\\\", \\\"{x:1288,y:957,t:1527272082711};\\\", \\\"{x:1287,y:958,t:1527272082727};\\\", \\\"{x:1286,y:959,t:1527272082770};\\\", \\\"{x:1285,y:959,t:1527272084435};\\\", \\\"{x:1283,y:959,t:1527272084499};\\\", \\\"{x:1282,y:959,t:1527272084531};\\\", \\\"{x:1282,y:960,t:1527272084546};\\\", \\\"{x:1281,y:960,t:1527272084570};\\\", \\\"{x:1279,y:960,t:1527272085314};\\\", \\\"{x:1278,y:960,t:1527272085395};\\\", \\\"{x:1277,y:960,t:1527272085417};\\\", \\\"{x:1277,y:959,t:1527272085465};\\\", \\\"{x:1277,y:958,t:1527272085529};\\\", \\\"{x:1276,y:958,t:1527272091107};\\\", \\\"{x:1274,y:958,t:1527272091118};\\\", \\\"{x:1270,y:958,t:1527272091134};\\\", \\\"{x:1267,y:959,t:1527272091151};\\\", \\\"{x:1266,y:959,t:1527272091168};\\\", \\\"{x:1264,y:960,t:1527272091184};\\\", \\\"{x:1262,y:963,t:1527272091203};\\\", \\\"{x:1259,y:965,t:1527272091218};\\\", \\\"{x:1258,y:966,t:1527272091234};\\\", \\\"{x:1256,y:969,t:1527272091251};\\\", \\\"{x:1253,y:972,t:1527272091268};\\\", \\\"{x:1252,y:974,t:1527272091284};\\\", \\\"{x:1248,y:978,t:1527272091301};\\\", \\\"{x:1245,y:982,t:1527272091318};\\\", \\\"{x:1241,y:988,t:1527272091334};\\\", \\\"{x:1237,y:993,t:1527272091351};\\\", \\\"{x:1232,y:999,t:1527272091369};\\\", \\\"{x:1227,y:1004,t:1527272091384};\\\", \\\"{x:1223,y:1009,t:1527272091401};\\\", \\\"{x:1215,y:1017,t:1527272091416};\\\", \\\"{x:1211,y:1020,t:1527272091433};\\\", \\\"{x:1206,y:1024,t:1527272091451};\\\", \\\"{x:1204,y:1026,t:1527272091467};\\\", \\\"{x:1202,y:1028,t:1527272091484};\\\", \\\"{x:1200,y:1030,t:1527272091500};\\\", \\\"{x:1199,y:1031,t:1527272091518};\\\", \\\"{x:1197,y:1032,t:1527272091534};\\\", \\\"{x:1196,y:1033,t:1527272091550};\\\", \\\"{x:1195,y:1034,t:1527272091568};\\\", \\\"{x:1194,y:1034,t:1527272091874};\\\", \\\"{x:1194,y:1035,t:1527272091884};\\\", \\\"{x:1193,y:1038,t:1527272091901};\\\", \\\"{x:1191,y:1039,t:1527272091918};\\\", \\\"{x:1189,y:1042,t:1527272091935};\\\", \\\"{x:1187,y:1044,t:1527272091952};\\\", \\\"{x:1184,y:1047,t:1527272091969};\\\", \\\"{x:1182,y:1051,t:1527272091985};\\\", \\\"{x:1179,y:1053,t:1527272092002};\\\", \\\"{x:1179,y:1054,t:1527272092442};\\\", \\\"{x:1178,y:1054,t:1527272092746};\\\", \\\"{x:1176,y:1052,t:1527272092753};\\\", \\\"{x:1174,y:1049,t:1527272092769};\\\", \\\"{x:1173,y:1047,t:1527272092786};\\\", \\\"{x:1172,y:1046,t:1527272092803};\\\", \\\"{x:1169,y:1046,t:1527272093274};\\\", \\\"{x:1167,y:1046,t:1527272093286};\\\", \\\"{x:1159,y:1049,t:1527272093303};\\\", \\\"{x:1156,y:1050,t:1527272093319};\\\", \\\"{x:1155,y:1051,t:1527272093336};\\\", \\\"{x:1155,y:1050,t:1527272093778};\\\", \\\"{x:1155,y:1045,t:1527272093786};\\\", \\\"{x:1159,y:1035,t:1527272093803};\\\", \\\"{x:1163,y:1024,t:1527272093820};\\\", \\\"{x:1168,y:1013,t:1527272093836};\\\", \\\"{x:1171,y:1005,t:1527272093853};\\\", \\\"{x:1176,y:996,t:1527272093870};\\\", \\\"{x:1178,y:991,t:1527272093886};\\\", \\\"{x:1184,y:981,t:1527272093902};\\\", \\\"{x:1188,y:973,t:1527272093920};\\\", \\\"{x:1195,y:964,t:1527272093936};\\\", \\\"{x:1201,y:953,t:1527272093953};\\\", \\\"{x:1206,y:943,t:1527272093969};\\\", \\\"{x:1210,y:936,t:1527272093986};\\\", \\\"{x:1215,y:929,t:1527272094003};\\\", \\\"{x:1220,y:918,t:1527272094019};\\\", \\\"{x:1227,y:907,t:1527272094035};\\\", \\\"{x:1235,y:895,t:1527272094053};\\\", \\\"{x:1243,y:883,t:1527272094069};\\\", \\\"{x:1249,y:868,t:1527272094086};\\\", \\\"{x:1262,y:845,t:1527272094103};\\\", \\\"{x:1276,y:819,t:1527272094120};\\\", \\\"{x:1289,y:791,t:1527272094137};\\\", \\\"{x:1305,y:760,t:1527272094153};\\\", \\\"{x:1322,y:729,t:1527272094170};\\\", \\\"{x:1330,y:711,t:1527272094186};\\\", \\\"{x:1337,y:697,t:1527272094203};\\\", \\\"{x:1344,y:682,t:1527272094220};\\\", \\\"{x:1351,y:671,t:1527272094237};\\\", \\\"{x:1355,y:664,t:1527272094253};\\\", \\\"{x:1360,y:657,t:1527272094270};\\\", \\\"{x:1366,y:650,t:1527272094287};\\\", \\\"{x:1378,y:644,t:1527272094303};\\\", \\\"{x:1388,y:638,t:1527272094320};\\\", \\\"{x:1398,y:632,t:1527272094337};\\\", \\\"{x:1409,y:625,t:1527272094353};\\\", \\\"{x:1426,y:616,t:1527272094369};\\\", \\\"{x:1437,y:614,t:1527272094387};\\\", \\\"{x:1447,y:609,t:1527272094404};\\\", \\\"{x:1453,y:606,t:1527272094420};\\\", \\\"{x:1456,y:606,t:1527272094438};\\\", \\\"{x:1459,y:605,t:1527272094453};\\\", \\\"{x:1460,y:605,t:1527272094471};\\\", \\\"{x:1461,y:605,t:1527272094488};\\\", \\\"{x:1462,y:605,t:1527272094503};\\\", \\\"{x:1464,y:605,t:1527272094520};\\\", \\\"{x:1465,y:605,t:1527272094537};\\\", \\\"{x:1467,y:605,t:1527272094553};\\\", \\\"{x:1468,y:605,t:1527272094570};\\\", \\\"{x:1469,y:605,t:1527272094594};\\\", \\\"{x:1470,y:605,t:1527272094650};\\\", \\\"{x:1471,y:605,t:1527272094698};\\\", \\\"{x:1471,y:606,t:1527272096923};\\\", \\\"{x:1471,y:615,t:1527272096962};\\\", \\\"{x:1471,y:626,t:1527272096972};\\\", \\\"{x:1469,y:645,t:1527272096989};\\\", \\\"{x:1467,y:656,t:1527272097005};\\\", \\\"{x:1460,y:671,t:1527272097022};\\\", \\\"{x:1457,y:687,t:1527272097039};\\\", \\\"{x:1454,y:703,t:1527272097055};\\\", \\\"{x:1453,y:716,t:1527272097072};\\\", \\\"{x:1449,y:731,t:1527272097089};\\\", \\\"{x:1448,y:738,t:1527272097105};\\\", \\\"{x:1443,y:747,t:1527272097123};\\\", \\\"{x:1441,y:750,t:1527272097139};\\\", \\\"{x:1441,y:751,t:1527272097156};\\\", \\\"{x:1439,y:753,t:1527272097172};\\\", \\\"{x:1435,y:756,t:1527272097190};\\\", \\\"{x:1430,y:758,t:1527272097205};\\\", \\\"{x:1429,y:759,t:1527272097222};\\\", \\\"{x:1427,y:760,t:1527272097239};\\\", \\\"{x:1422,y:764,t:1527272097256};\\\", \\\"{x:1413,y:767,t:1527272097272};\\\", \\\"{x:1409,y:769,t:1527272097288};\\\", \\\"{x:1408,y:769,t:1527272097305};\\\", \\\"{x:1407,y:769,t:1527272097392};\\\", \\\"{x:1407,y:770,t:1527272098426};\\\", \\\"{x:1409,y:771,t:1527272098626};\\\", \\\"{x:1410,y:772,t:1527272098666};\\\", \\\"{x:1411,y:772,t:1527272098754};\\\", \\\"{x:1413,y:773,t:1527272098794};\\\", \\\"{x:1413,y:771,t:1527272099043};\\\", \\\"{x:1413,y:769,t:1527272099058};\\\", \\\"{x:1412,y:767,t:1527272099075};\\\", \\\"{x:1411,y:764,t:1527272099090};\\\", \\\"{x:1410,y:761,t:1527272099108};\\\", \\\"{x:1408,y:757,t:1527272099125};\\\", \\\"{x:1407,y:755,t:1527272099140};\\\", \\\"{x:1407,y:754,t:1527272099158};\\\", \\\"{x:1407,y:752,t:1527272099175};\\\", \\\"{x:1407,y:751,t:1527272099190};\\\", \\\"{x:1407,y:749,t:1527272099208};\\\", \\\"{x:1407,y:748,t:1527272099224};\\\", \\\"{x:1407,y:747,t:1527272099242};\\\", \\\"{x:1407,y:746,t:1527272099338};\\\", \\\"{x:1406,y:745,t:1527272099346};\\\", \\\"{x:1404,y:744,t:1527272099357};\\\", \\\"{x:1400,y:740,t:1527272099374};\\\", \\\"{x:1396,y:737,t:1527272099391};\\\", \\\"{x:1391,y:733,t:1527272099407};\\\", \\\"{x:1386,y:728,t:1527272099424};\\\", \\\"{x:1373,y:718,t:1527272099442};\\\", \\\"{x:1366,y:711,t:1527272099457};\\\", \\\"{x:1362,y:706,t:1527272099474};\\\", \\\"{x:1357,y:702,t:1527272099492};\\\", \\\"{x:1351,y:698,t:1527272099507};\\\", \\\"{x:1351,y:697,t:1527272099524};\\\", \\\"{x:1350,y:696,t:1527272099541};\\\", \\\"{x:1349,y:696,t:1527272099778};\\\", \\\"{x:1347,y:698,t:1527272099791};\\\", \\\"{x:1343,y:707,t:1527272099808};\\\", \\\"{x:1342,y:716,t:1527272099824};\\\", \\\"{x:1337,y:734,t:1527272099841};\\\", \\\"{x:1334,y:747,t:1527272099857};\\\", \\\"{x:1331,y:758,t:1527272099874};\\\", \\\"{x:1328,y:771,t:1527272099890};\\\", \\\"{x:1325,y:783,t:1527272099908};\\\", \\\"{x:1324,y:795,t:1527272099924};\\\", \\\"{x:1322,y:807,t:1527272099941};\\\", \\\"{x:1322,y:818,t:1527272099958};\\\", \\\"{x:1322,y:828,t:1527272099973};\\\", \\\"{x:1322,y:836,t:1527272099990};\\\", \\\"{x:1322,y:842,t:1527272100007};\\\", \\\"{x:1322,y:847,t:1527272100024};\\\", \\\"{x:1322,y:853,t:1527272100040};\\\", \\\"{x:1322,y:860,t:1527272100058};\\\", \\\"{x:1323,y:866,t:1527272100074};\\\", \\\"{x:1324,y:872,t:1527272100091};\\\", \\\"{x:1325,y:881,t:1527272100108};\\\", \\\"{x:1325,y:889,t:1527272100124};\\\", \\\"{x:1325,y:901,t:1527272100140};\\\", \\\"{x:1325,y:910,t:1527272100158};\\\", \\\"{x:1326,y:919,t:1527272100174};\\\", \\\"{x:1326,y:924,t:1527272100191};\\\", \\\"{x:1326,y:930,t:1527272100208};\\\", \\\"{x:1328,y:935,t:1527272100224};\\\", \\\"{x:1329,y:941,t:1527272100241};\\\", \\\"{x:1330,y:943,t:1527272100258};\\\", \\\"{x:1331,y:945,t:1527272100275};\\\", \\\"{x:1332,y:946,t:1527272100291};\\\", \\\"{x:1332,y:947,t:1527272100308};\\\", \\\"{x:1332,y:948,t:1527272100353};\\\", \\\"{x:1332,y:949,t:1527272100394};\\\", \\\"{x:1333,y:951,t:1527272100408};\\\", \\\"{x:1336,y:956,t:1527272100426};\\\", \\\"{x:1341,y:962,t:1527272100442};\\\", \\\"{x:1346,y:967,t:1527272100458};\\\", \\\"{x:1351,y:971,t:1527272100475};\\\", \\\"{x:1356,y:974,t:1527272100491};\\\", \\\"{x:1358,y:976,t:1527272100509};\\\", \\\"{x:1359,y:977,t:1527272100525};\\\", \\\"{x:1360,y:978,t:1527272100541};\\\", \\\"{x:1361,y:978,t:1527272100674};\\\", \\\"{x:1361,y:977,t:1527272100761};\\\", \\\"{x:1361,y:976,t:1527272100818};\\\", \\\"{x:1361,y:975,t:1527272100841};\\\", \\\"{x:1360,y:974,t:1527272100865};\\\", \\\"{x:1359,y:974,t:1527272100875};\\\", \\\"{x:1358,y:974,t:1527272100986};\\\", \\\"{x:1356,y:974,t:1527272101258};\\\", \\\"{x:1355,y:974,t:1527272101265};\\\", \\\"{x:1353,y:974,t:1527272101386};\\\", \\\"{x:1352,y:974,t:1527272101514};\\\", \\\"{x:1350,y:974,t:1527272101538};\\\", \\\"{x:1348,y:974,t:1527272101634};\\\", \\\"{x:1347,y:974,t:1527272101786};\\\", \\\"{x:1346,y:973,t:1527272102761};\\\", \\\"{x:1346,y:972,t:1527272103034};\\\", \\\"{x:1346,y:971,t:1527272103073};\\\", \\\"{x:1346,y:970,t:1527272103578};\\\", \\\"{x:1345,y:969,t:1527272103594};\\\", \\\"{x:1345,y:968,t:1527272103611};\\\", \\\"{x:1345,y:967,t:1527272103627};\\\", \\\"{x:1343,y:964,t:1527272103645};\\\", \\\"{x:1343,y:962,t:1527272103661};\\\", \\\"{x:1341,y:956,t:1527272103677};\\\", \\\"{x:1341,y:942,t:1527272103695};\\\", \\\"{x:1338,y:920,t:1527272103711};\\\", \\\"{x:1334,y:895,t:1527272103728};\\\", \\\"{x:1328,y:865,t:1527272103744};\\\", \\\"{x:1318,y:813,t:1527272103762};\\\", \\\"{x:1314,y:785,t:1527272103778};\\\", \\\"{x:1310,y:755,t:1527272103795};\\\", \\\"{x:1308,y:733,t:1527272103812};\\\", \\\"{x:1308,y:717,t:1527272103827};\\\", \\\"{x:1308,y:705,t:1527272103844};\\\", \\\"{x:1308,y:700,t:1527272103862};\\\", \\\"{x:1308,y:697,t:1527272103877};\\\", \\\"{x:1308,y:694,t:1527272103895};\\\", \\\"{x:1308,y:691,t:1527272103912};\\\", \\\"{x:1309,y:689,t:1527272103928};\\\", \\\"{x:1309,y:688,t:1527272103944};\\\", \\\"{x:1313,y:686,t:1527272103962};\\\", \\\"{x:1315,y:685,t:1527272103977};\\\", \\\"{x:1319,y:683,t:1527272103995};\\\", \\\"{x:1322,y:682,t:1527272104012};\\\", \\\"{x:1325,y:680,t:1527272104028};\\\", \\\"{x:1328,y:680,t:1527272104044};\\\", \\\"{x:1335,y:676,t:1527272104061};\\\", \\\"{x:1338,y:676,t:1527272104077};\\\", \\\"{x:1341,y:675,t:1527272104095};\\\", \\\"{x:1345,y:675,t:1527272104112};\\\", \\\"{x:1347,y:675,t:1527272104127};\\\", \\\"{x:1348,y:675,t:1527272104153};\\\", \\\"{x:1349,y:675,t:1527272104185};\\\", \\\"{x:1350,y:675,t:1527272104203};\\\", \\\"{x:1351,y:675,t:1527272104226};\\\", \\\"{x:1351,y:676,t:1527272104233};\\\", \\\"{x:1353,y:676,t:1527272104245};\\\", \\\"{x:1353,y:679,t:1527272104262};\\\", \\\"{x:1353,y:680,t:1527272104279};\\\", \\\"{x:1353,y:683,t:1527272104294};\\\", \\\"{x:1353,y:687,t:1527272104311};\\\", \\\"{x:1353,y:690,t:1527272104329};\\\", \\\"{x:1353,y:692,t:1527272104345};\\\", \\\"{x:1353,y:695,t:1527272104362};\\\", \\\"{x:1352,y:695,t:1527272104378};\\\", \\\"{x:1352,y:696,t:1527272104530};\\\", \\\"{x:1352,y:698,t:1527272104698};\\\", \\\"{x:1352,y:700,t:1527272104711};\\\", \\\"{x:1356,y:708,t:1527272104729};\\\", \\\"{x:1366,y:726,t:1527272104746};\\\", \\\"{x:1377,y:745,t:1527272104761};\\\", \\\"{x:1394,y:763,t:1527272104779};\\\", \\\"{x:1412,y:786,t:1527272104796};\\\", \\\"{x:1425,y:804,t:1527272104811};\\\", \\\"{x:1438,y:823,t:1527272104829};\\\", \\\"{x:1449,y:836,t:1527272104845};\\\", \\\"{x:1459,y:849,t:1527272104862};\\\", \\\"{x:1467,y:858,t:1527272104879};\\\", \\\"{x:1471,y:862,t:1527272104896};\\\", \\\"{x:1472,y:863,t:1527272104911};\\\", \\\"{x:1473,y:865,t:1527272104929};\\\", \\\"{x:1475,y:867,t:1527272104946};\\\", \\\"{x:1477,y:869,t:1527272104961};\\\", \\\"{x:1483,y:873,t:1527272104978};\\\", \\\"{x:1489,y:874,t:1527272104996};\\\", \\\"{x:1495,y:878,t:1527272105011};\\\", \\\"{x:1505,y:882,t:1527272105028};\\\", \\\"{x:1515,y:886,t:1527272105046};\\\", \\\"{x:1525,y:892,t:1527272105062};\\\", \\\"{x:1532,y:898,t:1527272105079};\\\", \\\"{x:1537,y:906,t:1527272105096};\\\", \\\"{x:1539,y:915,t:1527272105113};\\\", \\\"{x:1541,y:922,t:1527272105128};\\\", \\\"{x:1543,y:928,t:1527272105146};\\\", \\\"{x:1545,y:929,t:1527272105163};\\\", \\\"{x:1546,y:930,t:1527272105178};\\\", \\\"{x:1548,y:932,t:1527272105196};\\\", \\\"{x:1550,y:933,t:1527272105212};\\\", \\\"{x:1551,y:934,t:1527272105228};\\\", \\\"{x:1554,y:934,t:1527272105245};\\\", \\\"{x:1557,y:936,t:1527272105263};\\\", \\\"{x:1562,y:939,t:1527272105279};\\\", \\\"{x:1569,y:940,t:1527272105296};\\\", \\\"{x:1575,y:944,t:1527272105313};\\\", \\\"{x:1588,y:947,t:1527272105328};\\\", \\\"{x:1608,y:954,t:1527272105345};\\\", \\\"{x:1619,y:956,t:1527272105363};\\\", \\\"{x:1626,y:958,t:1527272105378};\\\", \\\"{x:1630,y:959,t:1527272105395};\\\", \\\"{x:1631,y:959,t:1527272105411};\\\", \\\"{x:1633,y:960,t:1527272105428};\\\", \\\"{x:1633,y:961,t:1527272105569};\\\", \\\"{x:1632,y:962,t:1527272105593};\\\", \\\"{x:1631,y:962,t:1527272105617};\\\", \\\"{x:1630,y:962,t:1527272105629};\\\", \\\"{x:1628,y:963,t:1527272105645};\\\", \\\"{x:1627,y:963,t:1527272105689};\\\", \\\"{x:1626,y:963,t:1527272105713};\\\", \\\"{x:1624,y:963,t:1527272105729};\\\", \\\"{x:1621,y:963,t:1527272105746};\\\", \\\"{x:1619,y:963,t:1527272105763};\\\", \\\"{x:1618,y:963,t:1527272105780};\\\", \\\"{x:1617,y:963,t:1527272105834};\\\", \\\"{x:1616,y:963,t:1527272106082};\\\", \\\"{x:1615,y:963,t:1527272106131};\\\", \\\"{x:1613,y:964,t:1527272106258};\\\", \\\"{x:1612,y:964,t:1527272106994};\\\", \\\"{x:1611,y:964,t:1527272107002};\\\", \\\"{x:1608,y:964,t:1527272107013};\\\", \\\"{x:1593,y:962,t:1527272107031};\\\", \\\"{x:1572,y:959,t:1527272107046};\\\", \\\"{x:1545,y:954,t:1527272107063};\\\", \\\"{x:1521,y:953,t:1527272107081};\\\", \\\"{x:1503,y:953,t:1527272107096};\\\", \\\"{x:1491,y:953,t:1527272107113};\\\", \\\"{x:1493,y:953,t:1527272107250};\\\", \\\"{x:1495,y:954,t:1527272107264};\\\", \\\"{x:1497,y:955,t:1527272107280};\\\", \\\"{x:1498,y:956,t:1527272107297};\\\", \\\"{x:1495,y:957,t:1527272107409};\\\", \\\"{x:1493,y:957,t:1527272107425};\\\", \\\"{x:1492,y:957,t:1527272107434};\\\", \\\"{x:1489,y:958,t:1527272107448};\\\", \\\"{x:1486,y:960,t:1527272107464};\\\", \\\"{x:1481,y:961,t:1527272107480};\\\", \\\"{x:1474,y:965,t:1527272107497};\\\", \\\"{x:1470,y:965,t:1527272107513};\\\", \\\"{x:1461,y:965,t:1527272107531};\\\", \\\"{x:1444,y:960,t:1527272107548};\\\", \\\"{x:1418,y:950,t:1527272107564};\\\", \\\"{x:1354,y:919,t:1527272107581};\\\", \\\"{x:1259,y:888,t:1527272107598};\\\", \\\"{x:1159,y:860,t:1527272107614};\\\", \\\"{x:1049,y:833,t:1527272107630};\\\", \\\"{x:947,y:803,t:1527272107648};\\\", \\\"{x:839,y:775,t:1527272107663};\\\", \\\"{x:741,y:755,t:1527272107681};\\\", \\\"{x:645,y:724,t:1527272107698};\\\", \\\"{x:614,y:715,t:1527272107714};\\\", \\\"{x:601,y:707,t:1527272107731};\\\", \\\"{x:595,y:705,t:1527272107747};\\\", \\\"{x:590,y:701,t:1527272107764};\\\", \\\"{x:580,y:697,t:1527272107781};\\\", \\\"{x:566,y:691,t:1527272107797};\\\", \\\"{x:552,y:681,t:1527272107815};\\\", \\\"{x:538,y:673,t:1527272107831};\\\", \\\"{x:525,y:664,t:1527272107848};\\\", \\\"{x:516,y:656,t:1527272107865};\\\", \\\"{x:510,y:646,t:1527272107880};\\\", \\\"{x:505,y:629,t:1527272107899};\\\", \\\"{x:504,y:619,t:1527272107914};\\\", \\\"{x:504,y:610,t:1527272107930};\\\", \\\"{x:507,y:601,t:1527272107949};\\\", \\\"{x:514,y:593,t:1527272107966};\\\", \\\"{x:523,y:585,t:1527272107981};\\\", \\\"{x:533,y:579,t:1527272107999};\\\", \\\"{x:544,y:572,t:1527272108016};\\\", \\\"{x:554,y:567,t:1527272108032};\\\", \\\"{x:570,y:561,t:1527272108049};\\\", \\\"{x:580,y:558,t:1527272108066};\\\", \\\"{x:591,y:556,t:1527272108082};\\\", \\\"{x:600,y:556,t:1527272108099};\\\", \\\"{x:604,y:556,t:1527272108116};\\\", \\\"{x:606,y:556,t:1527272108132};\\\", \\\"{x:607,y:556,t:1527272108152};\\\", \\\"{x:609,y:556,t:1527272108177};\\\", \\\"{x:610,y:556,t:1527272108184};\\\", \\\"{x:611,y:556,t:1527272108198};\\\", \\\"{x:614,y:556,t:1527272108216};\\\", \\\"{x:615,y:557,t:1527272108232};\\\", \\\"{x:617,y:564,t:1527272108249};\\\", \\\"{x:617,y:571,t:1527272108266};\\\", \\\"{x:617,y:575,t:1527272108282};\\\", \\\"{x:617,y:578,t:1527272108299};\\\", \\\"{x:617,y:580,t:1527272108316};\\\", \\\"{x:617,y:582,t:1527272108332};\\\", \\\"{x:617,y:583,t:1527272108609};\\\", \\\"{x:613,y:586,t:1527272108617};\\\", \\\"{x:605,y:596,t:1527272108633};\\\", \\\"{x:592,y:610,t:1527272108649};\\\", \\\"{x:575,y:628,t:1527272108666};\\\", \\\"{x:561,y:646,t:1527272108684};\\\", \\\"{x:553,y:656,t:1527272108700};\\\", \\\"{x:540,y:673,t:1527272108715};\\\", \\\"{x:532,y:690,t:1527272108733};\\\", \\\"{x:526,y:702,t:1527272108750};\\\", \\\"{x:524,y:708,t:1527272108766};\\\", \\\"{x:521,y:714,t:1527272108783};\\\", \\\"{x:520,y:716,t:1527272108800};\\\", \\\"{x:519,y:717,t:1527272108816};\\\", \\\"{x:519,y:718,t:1527272108937};\\\", \\\"{x:518,y:721,t:1527272108961};\\\", \\\"{x:518,y:722,t:1527272108976};\\\", \\\"{x:518,y:723,t:1527272108984};\\\", \\\"{x:518,y:724,t:1527272109000};\\\", \\\"{x:517,y:725,t:1527272109016};\\\", \\\"{x:517,y:727,t:1527272109033};\\\", \\\"{x:517,y:728,t:1527272109056};\\\", \\\"{x:517,y:729,t:1527272109066};\\\", \\\"{x:517,y:730,t:1527272109083};\\\", \\\"{x:516,y:731,t:1527272109100};\\\" ] }, { \\\"rt\\\": 9623, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 352189, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"K8DJ0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:519,y:733,t:1527272113377};\\\", \\\"{x:524,y:737,t:1527272113386};\\\", \\\"{x:537,y:743,t:1527272113403};\\\", \\\"{x:556,y:753,t:1527272113420};\\\", \\\"{x:572,y:761,t:1527272113437};\\\", \\\"{x:592,y:770,t:1527272113453};\\\", \\\"{x:616,y:779,t:1527272113470};\\\", \\\"{x:641,y:786,t:1527272113487};\\\", \\\"{x:666,y:792,t:1527272113503};\\\", \\\"{x:697,y:801,t:1527272113520};\\\", \\\"{x:715,y:807,t:1527272113536};\\\", \\\"{x:728,y:810,t:1527272113553};\\\", \\\"{x:741,y:814,t:1527272113569};\\\", \\\"{x:755,y:818,t:1527272113587};\\\", \\\"{x:769,y:823,t:1527272113603};\\\", \\\"{x:784,y:827,t:1527272113620};\\\", \\\"{x:798,y:830,t:1527272113637};\\\", \\\"{x:814,y:834,t:1527272113652};\\\", \\\"{x:834,y:840,t:1527272113670};\\\", \\\"{x:858,y:847,t:1527272113687};\\\", \\\"{x:881,y:853,t:1527272113703};\\\", \\\"{x:916,y:862,t:1527272113720};\\\", \\\"{x:941,y:872,t:1527272113737};\\\", \\\"{x:977,y:881,t:1527272113753};\\\", \\\"{x:1011,y:892,t:1527272113770};\\\", \\\"{x:1048,y:902,t:1527272113788};\\\", \\\"{x:1073,y:909,t:1527272113803};\\\", \\\"{x:1098,y:918,t:1527272113820};\\\", \\\"{x:1121,y:928,t:1527272113838};\\\", \\\"{x:1143,y:934,t:1527272113853};\\\", \\\"{x:1162,y:941,t:1527272113870};\\\", \\\"{x:1185,y:946,t:1527272113887};\\\", \\\"{x:1202,y:951,t:1527272113903};\\\", \\\"{x:1217,y:954,t:1527272113921};\\\", \\\"{x:1235,y:958,t:1527272113937};\\\", \\\"{x:1243,y:959,t:1527272113953};\\\", \\\"{x:1253,y:960,t:1527272113970};\\\", \\\"{x:1267,y:962,t:1527272113988};\\\", \\\"{x:1277,y:962,t:1527272114003};\\\", \\\"{x:1287,y:964,t:1527272114020};\\\", \\\"{x:1301,y:964,t:1527272114038};\\\", \\\"{x:1318,y:965,t:1527272114054};\\\", \\\"{x:1334,y:965,t:1527272114070};\\\", \\\"{x:1347,y:965,t:1527272114087};\\\", \\\"{x:1354,y:965,t:1527272114104};\\\", \\\"{x:1356,y:965,t:1527272114120};\\\", \\\"{x:1357,y:965,t:1527272114137};\\\", \\\"{x:1358,y:965,t:1527272114241};\\\", \\\"{x:1358,y:962,t:1527272114401};\\\", \\\"{x:1358,y:959,t:1527272114409};\\\", \\\"{x:1358,y:958,t:1527272114421};\\\", \\\"{x:1358,y:953,t:1527272114438};\\\", \\\"{x:1356,y:945,t:1527272114454};\\\", \\\"{x:1353,y:939,t:1527272114471};\\\", \\\"{x:1350,y:930,t:1527272114488};\\\", \\\"{x:1345,y:917,t:1527272114505};\\\", \\\"{x:1344,y:908,t:1527272114522};\\\", \\\"{x:1341,y:898,t:1527272114539};\\\", \\\"{x:1339,y:887,t:1527272114554};\\\", \\\"{x:1335,y:873,t:1527272114572};\\\", \\\"{x:1333,y:865,t:1527272114588};\\\", \\\"{x:1331,y:851,t:1527272114605};\\\", \\\"{x:1329,y:842,t:1527272114622};\\\", \\\"{x:1328,y:833,t:1527272114638};\\\", \\\"{x:1327,y:826,t:1527272114655};\\\", \\\"{x:1326,y:819,t:1527272114672};\\\", \\\"{x:1326,y:815,t:1527272114688};\\\", \\\"{x:1326,y:810,t:1527272114705};\\\", \\\"{x:1326,y:804,t:1527272114722};\\\", \\\"{x:1326,y:800,t:1527272114738};\\\", \\\"{x:1326,y:795,t:1527272114755};\\\", \\\"{x:1326,y:791,t:1527272114772};\\\", \\\"{x:1326,y:786,t:1527272114789};\\\", \\\"{x:1328,y:779,t:1527272114805};\\\", \\\"{x:1330,y:774,t:1527272114822};\\\", \\\"{x:1334,y:766,t:1527272114838};\\\", \\\"{x:1336,y:761,t:1527272114855};\\\", \\\"{x:1338,y:756,t:1527272114872};\\\", \\\"{x:1339,y:755,t:1527272114888};\\\", \\\"{x:1340,y:753,t:1527272114905};\\\", \\\"{x:1341,y:751,t:1527272114921};\\\", \\\"{x:1342,y:750,t:1527272114954};\\\", \\\"{x:1342,y:749,t:1527272114961};\\\", \\\"{x:1342,y:748,t:1527272114972};\\\", \\\"{x:1342,y:747,t:1527272114988};\\\", \\\"{x:1342,y:746,t:1527272115005};\\\", \\\"{x:1343,y:745,t:1527272115022};\\\", \\\"{x:1344,y:744,t:1527272115039};\\\", \\\"{x:1345,y:742,t:1527272115056};\\\", \\\"{x:1345,y:741,t:1527272115072};\\\", \\\"{x:1345,y:738,t:1527272115089};\\\", \\\"{x:1346,y:737,t:1527272115105};\\\", \\\"{x:1346,y:734,t:1527272115121};\\\", \\\"{x:1347,y:731,t:1527272115139};\\\", \\\"{x:1347,y:729,t:1527272115155};\\\", \\\"{x:1347,y:726,t:1527272115171};\\\", \\\"{x:1348,y:723,t:1527272115189};\\\", \\\"{x:1349,y:718,t:1527272115205};\\\", \\\"{x:1350,y:709,t:1527272115222};\\\", \\\"{x:1352,y:700,t:1527272115242};\\\", \\\"{x:1353,y:692,t:1527272115254};\\\", \\\"{x:1353,y:688,t:1527272115271};\\\", \\\"{x:1353,y:684,t:1527272115288};\\\", \\\"{x:1353,y:682,t:1527272115304};\\\", \\\"{x:1353,y:681,t:1527272115321};\\\", \\\"{x:1353,y:679,t:1527272115339};\\\", \\\"{x:1354,y:677,t:1527272115385};\\\", \\\"{x:1354,y:676,t:1527272115632};\\\", \\\"{x:1354,y:675,t:1527272115656};\\\", \\\"{x:1354,y:674,t:1527272115671};\\\", \\\"{x:1345,y:674,t:1527272115689};\\\", \\\"{x:1329,y:674,t:1527272115705};\\\", \\\"{x:1306,y:674,t:1527272115722};\\\", \\\"{x:1278,y:674,t:1527272115739};\\\", \\\"{x:1248,y:674,t:1527272115755};\\\", \\\"{x:1212,y:674,t:1527272115771};\\\", \\\"{x:1182,y:674,t:1527272115788};\\\", \\\"{x:1146,y:674,t:1527272115805};\\\", \\\"{x:1122,y:674,t:1527272115822};\\\", \\\"{x:1096,y:674,t:1527272115839};\\\", \\\"{x:1071,y:674,t:1527272115855};\\\", \\\"{x:1048,y:673,t:1527272115872};\\\", \\\"{x:1015,y:665,t:1527272115889};\\\", \\\"{x:987,y:662,t:1527272115905};\\\", \\\"{x:952,y:653,t:1527272115922};\\\", \\\"{x:909,y:644,t:1527272115939};\\\", \\\"{x:874,y:638,t:1527272115955};\\\", \\\"{x:834,y:629,t:1527272115974};\\\", \\\"{x:805,y:625,t:1527272115988};\\\", \\\"{x:778,y:618,t:1527272116005};\\\", \\\"{x:759,y:613,t:1527272116022};\\\", \\\"{x:743,y:608,t:1527272116039};\\\", \\\"{x:731,y:606,t:1527272116055};\\\", \\\"{x:719,y:602,t:1527272116073};\\\", \\\"{x:713,y:599,t:1527272116089};\\\", \\\"{x:702,y:594,t:1527272116105};\\\", \\\"{x:694,y:593,t:1527272116123};\\\", \\\"{x:676,y:587,t:1527272116139};\\\", \\\"{x:657,y:582,t:1527272116155};\\\", \\\"{x:632,y:575,t:1527272116173};\\\", \\\"{x:605,y:567,t:1527272116189};\\\", \\\"{x:575,y:562,t:1527272116206};\\\", \\\"{x:547,y:556,t:1527272116222};\\\", \\\"{x:515,y:549,t:1527272116240};\\\", \\\"{x:492,y:542,t:1527272116256};\\\", \\\"{x:464,y:535,t:1527272116272};\\\", \\\"{x:453,y:532,t:1527272116289};\\\", \\\"{x:448,y:529,t:1527272116305};\\\", \\\"{x:447,y:529,t:1527272116322};\\\", \\\"{x:452,y:529,t:1527272116497};\\\", \\\"{x:459,y:529,t:1527272116506};\\\", \\\"{x:472,y:528,t:1527272116522};\\\", \\\"{x:487,y:526,t:1527272116539};\\\", \\\"{x:494,y:526,t:1527272116556};\\\", \\\"{x:501,y:526,t:1527272116573};\\\", \\\"{x:503,y:526,t:1527272116622};\\\", \\\"{x:505,y:526,t:1527272116638};\\\", \\\"{x:504,y:526,t:1527272116713};\\\", \\\"{x:503,y:525,t:1527272116722};\\\", \\\"{x:492,y:525,t:1527272116740};\\\", \\\"{x:477,y:525,t:1527272116755};\\\", \\\"{x:461,y:524,t:1527272116774};\\\", \\\"{x:445,y:524,t:1527272116789};\\\", \\\"{x:433,y:524,t:1527272116806};\\\", \\\"{x:417,y:524,t:1527272116823};\\\", \\\"{x:399,y:524,t:1527272116839};\\\", \\\"{x:376,y:522,t:1527272116856};\\\", \\\"{x:371,y:522,t:1527272116873};\\\", \\\"{x:367,y:520,t:1527272116889};\\\", \\\"{x:366,y:520,t:1527272116912};\\\", \\\"{x:365,y:520,t:1527272116936};\\\", \\\"{x:364,y:520,t:1527272116952};\\\", \\\"{x:363,y:520,t:1527272116960};\\\", \\\"{x:362,y:520,t:1527272116973};\\\", \\\"{x:355,y:520,t:1527272116989};\\\", \\\"{x:348,y:520,t:1527272117007};\\\", \\\"{x:341,y:520,t:1527272117023};\\\", \\\"{x:334,y:520,t:1527272117039};\\\", \\\"{x:323,y:520,t:1527272117056};\\\", \\\"{x:314,y:520,t:1527272117074};\\\", \\\"{x:299,y:521,t:1527272117089};\\\", \\\"{x:287,y:523,t:1527272117106};\\\", \\\"{x:273,y:527,t:1527272117124};\\\", \\\"{x:257,y:533,t:1527272117140};\\\", \\\"{x:241,y:538,t:1527272117156};\\\", \\\"{x:224,y:546,t:1527272117173};\\\", \\\"{x:208,y:555,t:1527272117190};\\\", \\\"{x:194,y:564,t:1527272117207};\\\", \\\"{x:188,y:570,t:1527272117224};\\\", \\\"{x:180,y:576,t:1527272117240};\\\", \\\"{x:179,y:579,t:1527272117256};\\\", \\\"{x:177,y:581,t:1527272117273};\\\", \\\"{x:176,y:581,t:1527272117290};\\\", \\\"{x:174,y:578,t:1527272117344};\\\", \\\"{x:174,y:575,t:1527272117356};\\\", \\\"{x:170,y:566,t:1527272117373};\\\", \\\"{x:168,y:558,t:1527272117391};\\\", \\\"{x:166,y:553,t:1527272117407};\\\", \\\"{x:165,y:549,t:1527272117424};\\\", \\\"{x:164,y:543,t:1527272117441};\\\", \\\"{x:164,y:542,t:1527272117457};\\\", \\\"{x:163,y:541,t:1527272117473};\\\", \\\"{x:163,y:540,t:1527272117490};\\\", \\\"{x:162,y:540,t:1527272117506};\\\", \\\"{x:163,y:540,t:1527272118080};\\\", \\\"{x:165,y:540,t:1527272118090};\\\", \\\"{x:169,y:540,t:1527272118107};\\\", \\\"{x:173,y:542,t:1527272118125};\\\", \\\"{x:180,y:543,t:1527272118140};\\\", \\\"{x:196,y:543,t:1527272118157};\\\", \\\"{x:211,y:543,t:1527272118174};\\\", \\\"{x:230,y:543,t:1527272118190};\\\", \\\"{x:242,y:543,t:1527272118208};\\\", \\\"{x:256,y:543,t:1527272118223};\\\", \\\"{x:267,y:543,t:1527272118241};\\\", \\\"{x:278,y:543,t:1527272118258};\\\", \\\"{x:292,y:543,t:1527272118273};\\\", \\\"{x:314,y:545,t:1527272118290};\\\", \\\"{x:334,y:545,t:1527272118308};\\\", \\\"{x:358,y:547,t:1527272118324};\\\", \\\"{x:378,y:550,t:1527272118341};\\\", \\\"{x:395,y:551,t:1527272118358};\\\", \\\"{x:405,y:551,t:1527272118374};\\\", \\\"{x:415,y:551,t:1527272118391};\\\", \\\"{x:428,y:551,t:1527272118407};\\\", \\\"{x:448,y:551,t:1527272118425};\\\", \\\"{x:457,y:551,t:1527272118441};\\\", \\\"{x:468,y:551,t:1527272118457};\\\", \\\"{x:477,y:551,t:1527272118475};\\\", \\\"{x:483,y:551,t:1527272118492};\\\", \\\"{x:493,y:551,t:1527272118508};\\\", \\\"{x:506,y:551,t:1527272118526};\\\", \\\"{x:521,y:551,t:1527272118542};\\\", \\\"{x:533,y:551,t:1527272118557};\\\", \\\"{x:546,y:552,t:1527272118574};\\\", \\\"{x:560,y:555,t:1527272118591};\\\", \\\"{x:573,y:555,t:1527272118608};\\\", \\\"{x:594,y:559,t:1527272118625};\\\", \\\"{x:609,y:561,t:1527272118640};\\\", \\\"{x:623,y:562,t:1527272118658};\\\", \\\"{x:635,y:564,t:1527272118674};\\\", \\\"{x:648,y:566,t:1527272118691};\\\", \\\"{x:657,y:566,t:1527272118708};\\\", \\\"{x:673,y:569,t:1527272118724};\\\", \\\"{x:686,y:570,t:1527272118741};\\\", \\\"{x:696,y:571,t:1527272118757};\\\", \\\"{x:707,y:572,t:1527272118774};\\\", \\\"{x:720,y:575,t:1527272118791};\\\", \\\"{x:731,y:575,t:1527272118808};\\\", \\\"{x:740,y:575,t:1527272118824};\\\", \\\"{x:742,y:575,t:1527272118841};\\\", \\\"{x:747,y:575,t:1527272118858};\\\", \\\"{x:751,y:575,t:1527272118875};\\\", \\\"{x:756,y:574,t:1527272118891};\\\", \\\"{x:762,y:571,t:1527272118908};\\\", \\\"{x:767,y:569,t:1527272118924};\\\", \\\"{x:775,y:565,t:1527272118941};\\\", \\\"{x:782,y:558,t:1527272118958};\\\", \\\"{x:790,y:552,t:1527272118975};\\\", \\\"{x:796,y:545,t:1527272118991};\\\", \\\"{x:807,y:529,t:1527272119008};\\\", \\\"{x:814,y:521,t:1527272119025};\\\", \\\"{x:819,y:514,t:1527272119042};\\\", \\\"{x:820,y:511,t:1527272119059};\\\", \\\"{x:822,y:510,t:1527272119074};\\\", \\\"{x:824,y:509,t:1527272119091};\\\", \\\"{x:825,y:508,t:1527272119108};\\\", \\\"{x:827,y:507,t:1527272119125};\\\", \\\"{x:831,y:507,t:1527272119141};\\\", \\\"{x:832,y:507,t:1527272119158};\\\", \\\"{x:836,y:505,t:1527272119174};\\\", \\\"{x:836,y:509,t:1527272119448};\\\", \\\"{x:833,y:514,t:1527272119459};\\\", \\\"{x:820,y:530,t:1527272119476};\\\", \\\"{x:796,y:549,t:1527272119492};\\\", \\\"{x:768,y:574,t:1527272119509};\\\", \\\"{x:738,y:601,t:1527272119526};\\\", \\\"{x:708,y:625,t:1527272119542};\\\", \\\"{x:690,y:641,t:1527272119558};\\\", \\\"{x:680,y:650,t:1527272119575};\\\", \\\"{x:671,y:658,t:1527272119592};\\\", \\\"{x:669,y:660,t:1527272119608};\\\", \\\"{x:666,y:663,t:1527272119625};\\\", \\\"{x:663,y:664,t:1527272119642};\\\", \\\"{x:659,y:669,t:1527272119658};\\\", \\\"{x:655,y:672,t:1527272119676};\\\", \\\"{x:652,y:674,t:1527272119691};\\\", \\\"{x:649,y:677,t:1527272119708};\\\", \\\"{x:646,y:680,t:1527272119725};\\\", \\\"{x:642,y:685,t:1527272119742};\\\", \\\"{x:634,y:691,t:1527272119759};\\\", \\\"{x:623,y:699,t:1527272119775};\\\", \\\"{x:602,y:709,t:1527272119792};\\\", \\\"{x:590,y:716,t:1527272119809};\\\", \\\"{x:579,y:723,t:1527272119826};\\\", \\\"{x:571,y:728,t:1527272119842};\\\", \\\"{x:568,y:730,t:1527272119859};\\\", \\\"{x:564,y:734,t:1527272119876};\\\", \\\"{x:561,y:736,t:1527272119892};\\\", \\\"{x:558,y:739,t:1527272119907};\\\", \\\"{x:552,y:741,t:1527272119925};\\\", \\\"{x:546,y:745,t:1527272119967};\\\" ] }, { \\\"rt\\\": 11901, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 365396, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"K8DJ0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:547,y:745,t:1527272123137};\\\", \\\"{x:548,y:746,t:1527272123146};\\\", \\\"{x:554,y:746,t:1527272123160};\\\", \\\"{x:569,y:746,t:1527272123177};\\\", \\\"{x:593,y:746,t:1527272123193};\\\", \\\"{x:628,y:746,t:1527272123210};\\\", \\\"{x:687,y:746,t:1527272123226};\\\", \\\"{x:748,y:746,t:1527272123245};\\\", \\\"{x:823,y:746,t:1527272123261};\\\", \\\"{x:907,y:746,t:1527272123278};\\\", \\\"{x:979,y:746,t:1527272123295};\\\", \\\"{x:1046,y:746,t:1527272123312};\\\", \\\"{x:1139,y:734,t:1527272123329};\\\", \\\"{x:1208,y:727,t:1527272123345};\\\", \\\"{x:1280,y:720,t:1527272123361};\\\", \\\"{x:1332,y:714,t:1527272123379};\\\", \\\"{x:1378,y:706,t:1527272123395};\\\", \\\"{x:1405,y:704,t:1527272123412};\\\", \\\"{x:1422,y:700,t:1527272123429};\\\", \\\"{x:1432,y:698,t:1527272123446};\\\", \\\"{x:1439,y:695,t:1527272123462};\\\", \\\"{x:1442,y:694,t:1527272123478};\\\", \\\"{x:1444,y:693,t:1527272123495};\\\", \\\"{x:1446,y:692,t:1527272123512};\\\", \\\"{x:1448,y:691,t:1527272123528};\\\", \\\"{x:1449,y:690,t:1527272123568};\\\", \\\"{x:1450,y:689,t:1527272123584};\\\", \\\"{x:1451,y:688,t:1527272123595};\\\", \\\"{x:1452,y:685,t:1527272123613};\\\", \\\"{x:1454,y:681,t:1527272123629};\\\", \\\"{x:1454,y:673,t:1527272123646};\\\", \\\"{x:1455,y:664,t:1527272123663};\\\", \\\"{x:1457,y:657,t:1527272123679};\\\", \\\"{x:1458,y:653,t:1527272123696};\\\", \\\"{x:1458,y:649,t:1527272123712};\\\", \\\"{x:1458,y:648,t:1527272123729};\\\", \\\"{x:1458,y:647,t:1527272123746};\\\", \\\"{x:1458,y:646,t:1527272123858};\\\", \\\"{x:1457,y:646,t:1527272123873};\\\", \\\"{x:1456,y:646,t:1527272123898};\\\", \\\"{x:1455,y:646,t:1527272123922};\\\", \\\"{x:1453,y:646,t:1527272123929};\\\", \\\"{x:1450,y:648,t:1527272123946};\\\", \\\"{x:1446,y:651,t:1527272123963};\\\", \\\"{x:1442,y:655,t:1527272123980};\\\", \\\"{x:1439,y:658,t:1527272123995};\\\", \\\"{x:1436,y:661,t:1527272124013};\\\", \\\"{x:1434,y:663,t:1527272124029};\\\", \\\"{x:1433,y:664,t:1527272124046};\\\", \\\"{x:1432,y:665,t:1527272124112};\\\", \\\"{x:1431,y:665,t:1527272124234};\\\", \\\"{x:1430,y:665,t:1527272124250};\\\", \\\"{x:1429,y:664,t:1527272124266};\\\", \\\"{x:1426,y:663,t:1527272124311};\\\", \\\"{x:1425,y:663,t:1527272124328};\\\", \\\"{x:1423,y:662,t:1527272124337};\\\", \\\"{x:1420,y:660,t:1527272124352};\\\", \\\"{x:1418,y:660,t:1527272124376};\\\", \\\"{x:1415,y:660,t:1527272124384};\\\", \\\"{x:1411,y:660,t:1527272124396};\\\", \\\"{x:1406,y:660,t:1527272124412};\\\", \\\"{x:1398,y:660,t:1527272124430};\\\", \\\"{x:1393,y:660,t:1527272124447};\\\", \\\"{x:1392,y:660,t:1527272124463};\\\", \\\"{x:1390,y:660,t:1527272124479};\\\", \\\"{x:1388,y:661,t:1527272124496};\\\", \\\"{x:1386,y:661,t:1527272124521};\\\", \\\"{x:1386,y:662,t:1527272124530};\\\", \\\"{x:1385,y:662,t:1527272124547};\\\", \\\"{x:1383,y:664,t:1527272124563};\\\", \\\"{x:1381,y:666,t:1527272124580};\\\", \\\"{x:1380,y:667,t:1527272124597};\\\", \\\"{x:1379,y:668,t:1527272124613};\\\", \\\"{x:1377,y:670,t:1527272124630};\\\", \\\"{x:1376,y:672,t:1527272124648};\\\", \\\"{x:1375,y:672,t:1527272124664};\\\", \\\"{x:1373,y:674,t:1527272124680};\\\", \\\"{x:1373,y:676,t:1527272124696};\\\", \\\"{x:1372,y:677,t:1527272124714};\\\", \\\"{x:1371,y:678,t:1527272124730};\\\", \\\"{x:1370,y:679,t:1527272124753};\\\", \\\"{x:1370,y:680,t:1527272124905};\\\", \\\"{x:1370,y:681,t:1527272124921};\\\", \\\"{x:1370,y:682,t:1527272124945};\\\", \\\"{x:1370,y:683,t:1527272124953};\\\", \\\"{x:1369,y:684,t:1527272124964};\\\", \\\"{x:1369,y:685,t:1527272125002};\\\", \\\"{x:1368,y:686,t:1527272125041};\\\", \\\"{x:1367,y:687,t:1527272125889};\\\", \\\"{x:1367,y:688,t:1527272125898};\\\", \\\"{x:1365,y:690,t:1527272125915};\\\", \\\"{x:1362,y:694,t:1527272125931};\\\", \\\"{x:1360,y:695,t:1527272125948};\\\", \\\"{x:1356,y:698,t:1527272125965};\\\", \\\"{x:1354,y:700,t:1527272125982};\\\", \\\"{x:1351,y:703,t:1527272125999};\\\", \\\"{x:1348,y:705,t:1527272126015};\\\", \\\"{x:1346,y:707,t:1527272126032};\\\", \\\"{x:1345,y:707,t:1527272126048};\\\", \\\"{x:1344,y:706,t:1527272127138};\\\", \\\"{x:1344,y:704,t:1527272127149};\\\", \\\"{x:1344,y:702,t:1527272127167};\\\", \\\"{x:1343,y:700,t:1527272127187};\\\", \\\"{x:1343,y:699,t:1527272127217};\\\", \\\"{x:1343,y:698,t:1527272127233};\\\", \\\"{x:1343,y:697,t:1527272127757};\\\", \\\"{x:1343,y:700,t:1527272129597};\\\", \\\"{x:1343,y:703,t:1527272129606};\\\", \\\"{x:1342,y:707,t:1527272129623};\\\", \\\"{x:1341,y:713,t:1527272129639};\\\", \\\"{x:1339,y:724,t:1527272129655};\\\", \\\"{x:1338,y:734,t:1527272129672};\\\", \\\"{x:1335,y:743,t:1527272129689};\\\", \\\"{x:1334,y:748,t:1527272129706};\\\", \\\"{x:1332,y:754,t:1527272129721};\\\", \\\"{x:1331,y:757,t:1527272129738};\\\", \\\"{x:1327,y:762,t:1527272129756};\\\", \\\"{x:1325,y:765,t:1527272129772};\\\", \\\"{x:1308,y:771,t:1527272129788};\\\", \\\"{x:1289,y:774,t:1527272129806};\\\", \\\"{x:1260,y:778,t:1527272129821};\\\", \\\"{x:1230,y:783,t:1527272129839};\\\", \\\"{x:1192,y:786,t:1527272129855};\\\", \\\"{x:1161,y:790,t:1527272129871};\\\", \\\"{x:1130,y:790,t:1527272129888};\\\", \\\"{x:1096,y:790,t:1527272129906};\\\", \\\"{x:1057,y:790,t:1527272129921};\\\", \\\"{x:1032,y:790,t:1527272129939};\\\", \\\"{x:1010,y:789,t:1527272129955};\\\", \\\"{x:985,y:784,t:1527272129972};\\\", \\\"{x:975,y:782,t:1527272129988};\\\", \\\"{x:959,y:774,t:1527272130006};\\\", \\\"{x:952,y:772,t:1527272130023};\\\", \\\"{x:945,y:768,t:1527272130039};\\\", \\\"{x:933,y:763,t:1527272130056};\\\", \\\"{x:923,y:758,t:1527272130073};\\\", \\\"{x:907,y:748,t:1527272130088};\\\", \\\"{x:894,y:738,t:1527272130106};\\\", \\\"{x:878,y:728,t:1527272130123};\\\", \\\"{x:860,y:714,t:1527272130139};\\\", \\\"{x:844,y:699,t:1527272130156};\\\", \\\"{x:820,y:674,t:1527272130172};\\\", \\\"{x:803,y:655,t:1527272130189};\\\", \\\"{x:787,y:638,t:1527272130206};\\\", \\\"{x:776,y:626,t:1527272130223};\\\", \\\"{x:764,y:614,t:1527272130239};\\\", \\\"{x:754,y:606,t:1527272130255};\\\", \\\"{x:743,y:601,t:1527272130271};\\\", \\\"{x:735,y:596,t:1527272130288};\\\", \\\"{x:731,y:593,t:1527272130304};\\\", \\\"{x:725,y:592,t:1527272130321};\\\", \\\"{x:715,y:589,t:1527272130338};\\\", \\\"{x:705,y:584,t:1527272130354};\\\", \\\"{x:685,y:578,t:1527272130371};\\\", \\\"{x:656,y:569,t:1527272130388};\\\", \\\"{x:634,y:563,t:1527272130404};\\\", \\\"{x:610,y:561,t:1527272130422};\\\", \\\"{x:582,y:556,t:1527272130438};\\\", \\\"{x:554,y:551,t:1527272130455};\\\", \\\"{x:526,y:547,t:1527272130471};\\\", \\\"{x:504,y:545,t:1527272130488};\\\", \\\"{x:481,y:545,t:1527272130505};\\\", \\\"{x:458,y:545,t:1527272130522};\\\", \\\"{x:432,y:545,t:1527272130538};\\\", \\\"{x:402,y:545,t:1527272130555};\\\", \\\"{x:370,y:545,t:1527272130572};\\\", \\\"{x:328,y:545,t:1527272130588};\\\", \\\"{x:305,y:545,t:1527272130604};\\\", \\\"{x:290,y:545,t:1527272130621};\\\", \\\"{x:273,y:545,t:1527272130638};\\\", \\\"{x:254,y:545,t:1527272130655};\\\", \\\"{x:234,y:545,t:1527272130671};\\\", \\\"{x:213,y:545,t:1527272130688};\\\", \\\"{x:189,y:545,t:1527272130705};\\\", \\\"{x:172,y:545,t:1527272130721};\\\", \\\"{x:157,y:541,t:1527272130738};\\\", \\\"{x:142,y:540,t:1527272130755};\\\", \\\"{x:133,y:539,t:1527272130772};\\\", \\\"{x:127,y:539,t:1527272130788};\\\", \\\"{x:125,y:537,t:1527272130805};\\\", \\\"{x:124,y:537,t:1527272130822};\\\", \\\"{x:123,y:537,t:1527272130844};\\\", \\\"{x:123,y:536,t:1527272130981};\\\", \\\"{x:124,y:535,t:1527272130989};\\\", \\\"{x:131,y:535,t:1527272131005};\\\", \\\"{x:134,y:535,t:1527272131022};\\\", \\\"{x:136,y:535,t:1527272131039};\\\", \\\"{x:140,y:535,t:1527272131056};\\\", \\\"{x:141,y:535,t:1527272131071};\\\", \\\"{x:142,y:535,t:1527272131088};\\\", \\\"{x:143,y:535,t:1527272131140};\\\", \\\"{x:144,y:536,t:1527272131164};\\\", \\\"{x:146,y:537,t:1527272131348};\\\", \\\"{x:146,y:537,t:1527272131350};\\\", \\\"{x:147,y:538,t:1527272131357};\\\", \\\"{x:152,y:540,t:1527272131373};\\\", \\\"{x:154,y:540,t:1527272131388};\\\", \\\"{x:154,y:541,t:1527272131405};\\\", \\\"{x:155,y:542,t:1527272131436};\\\", \\\"{x:156,y:542,t:1527272131444};\\\", \\\"{x:158,y:542,t:1527272131476};\\\", \\\"{x:159,y:543,t:1527272131492};\\\", \\\"{x:160,y:544,t:1527272131516};\\\", \\\"{x:161,y:544,t:1527272131548};\\\", \\\"{x:163,y:544,t:1527272131556};\\\", \\\"{x:163,y:545,t:1527272131571};\\\", \\\"{x:165,y:546,t:1527272131588};\\\", \\\"{x:165,y:547,t:1527272131605};\\\", \\\"{x:166,y:547,t:1527272131622};\\\", \\\"{x:167,y:547,t:1527272132149};\\\", \\\"{x:172,y:550,t:1527272132156};\\\", \\\"{x:176,y:552,t:1527272132172};\\\", \\\"{x:180,y:555,t:1527272132190};\\\", \\\"{x:186,y:557,t:1527272132206};\\\", \\\"{x:195,y:563,t:1527272132223};\\\", \\\"{x:206,y:569,t:1527272132239};\\\", \\\"{x:219,y:579,t:1527272132257};\\\", \\\"{x:233,y:586,t:1527272132273};\\\", \\\"{x:250,y:594,t:1527272132290};\\\", \\\"{x:265,y:601,t:1527272132308};\\\", \\\"{x:283,y:612,t:1527272132324};\\\", \\\"{x:309,y:624,t:1527272132340};\\\", \\\"{x:326,y:633,t:1527272132357};\\\", \\\"{x:337,y:639,t:1527272132374};\\\", \\\"{x:344,y:642,t:1527272132389};\\\", \\\"{x:353,y:647,t:1527272132406};\\\", \\\"{x:361,y:652,t:1527272132423};\\\", \\\"{x:366,y:655,t:1527272132440};\\\", \\\"{x:369,y:657,t:1527272132456};\\\", \\\"{x:371,y:658,t:1527272132473};\\\", \\\"{x:375,y:661,t:1527272132490};\\\", \\\"{x:380,y:665,t:1527272132506};\\\", \\\"{x:388,y:669,t:1527272132523};\\\", \\\"{x:407,y:683,t:1527272132540};\\\", \\\"{x:421,y:693,t:1527272132557};\\\", \\\"{x:433,y:699,t:1527272132574};\\\", \\\"{x:445,y:707,t:1527272132589};\\\", \\\"{x:451,y:711,t:1527272132607};\\\", \\\"{x:452,y:712,t:1527272132623};\\\", \\\"{x:454,y:714,t:1527272132640};\\\", \\\"{x:454,y:715,t:1527272132657};\\\", \\\"{x:456,y:716,t:1527272132674};\\\", \\\"{x:462,y:720,t:1527272132690};\\\", \\\"{x:472,y:726,t:1527272132707};\\\", \\\"{x:487,y:732,t:1527272132723};\\\", \\\"{x:493,y:734,t:1527272132739};\\\", \\\"{x:508,y:744,t:1527272132756};\\\", \\\"{x:518,y:749,t:1527272132774};\\\", \\\"{x:524,y:753,t:1527272132790};\\\", \\\"{x:527,y:755,t:1527272132807};\\\", \\\"{x:529,y:756,t:1527272132828};\\\", \\\"{x:530,y:756,t:1527272132940};\\\", \\\"{x:530,y:756,t:1527272133036};\\\", \\\"{x:531,y:756,t:1527272133077};\\\", \\\"{x:531,y:755,t:1527272133108};\\\", \\\"{x:531,y:753,t:1527272133142};\\\", \\\"{x:531,y:752,t:1527272133157};\\\", \\\"{x:527,y:746,t:1527272133174};\\\", \\\"{x:525,y:743,t:1527272133191};\\\", \\\"{x:523,y:741,t:1527272133207};\\\", \\\"{x:521,y:738,t:1527272133224};\\\", \\\"{x:519,y:734,t:1527272133240};\\\", \\\"{x:519,y:733,t:1527272133260};\\\", \\\"{x:518,y:732,t:1527272133274};\\\", \\\"{x:517,y:731,t:1527272133613};\\\" ] }, { \\\"rt\\\": 29678, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 396407, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"K8DJ0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:517,y:730,t:1527272142045};\\\", \\\"{x:526,y:730,t:1527272142059};\\\", \\\"{x:569,y:725,t:1527272142076};\\\", \\\"{x:686,y:725,t:1527272142091};\\\", \\\"{x:761,y:724,t:1527272142109};\\\", \\\"{x:827,y:720,t:1527272142131};\\\", \\\"{x:958,y:723,t:1527272142147};\\\", \\\"{x:1034,y:725,t:1527272142166};\\\", \\\"{x:1124,y:730,t:1527272142181};\\\", \\\"{x:1177,y:730,t:1527272142198};\\\", \\\"{x:1244,y:730,t:1527272142215};\\\", \\\"{x:1297,y:730,t:1527272142231};\\\", \\\"{x:1364,y:730,t:1527272142248};\\\", \\\"{x:1428,y:730,t:1527272142265};\\\", \\\"{x:1497,y:730,t:1527272142282};\\\", \\\"{x:1534,y:730,t:1527272142298};\\\", \\\"{x:1554,y:728,t:1527272142315};\\\", \\\"{x:1575,y:724,t:1527272142332};\\\", \\\"{x:1591,y:723,t:1527272142348};\\\", \\\"{x:1601,y:720,t:1527272142365};\\\", \\\"{x:1608,y:719,t:1527272142383};\\\", \\\"{x:1611,y:718,t:1527272142399};\\\", \\\"{x:1616,y:718,t:1527272142415};\\\", \\\"{x:1617,y:717,t:1527272142541};\\\", \\\"{x:1617,y:716,t:1527272142581};\\\", \\\"{x:1616,y:715,t:1527272142596};\\\", \\\"{x:1616,y:714,t:1527272142611};\\\", \\\"{x:1616,y:713,t:1527272142651};\\\", \\\"{x:1616,y:712,t:1527272142861};\\\", \\\"{x:1616,y:711,t:1527272142869};\\\", \\\"{x:1616,y:710,t:1527272142883};\\\", \\\"{x:1616,y:709,t:1527272142900};\\\", \\\"{x:1616,y:707,t:1527272142916};\\\", \\\"{x:1615,y:707,t:1527272142933};\\\", \\\"{x:1615,y:706,t:1527272142956};\\\", \\\"{x:1615,y:704,t:1527272142967};\\\", \\\"{x:1615,y:703,t:1527272142982};\\\", \\\"{x:1615,y:701,t:1527272143002};\\\", \\\"{x:1614,y:697,t:1527272143016};\\\", \\\"{x:1614,y:696,t:1527272143031};\\\", \\\"{x:1614,y:694,t:1527272143049};\\\", \\\"{x:1614,y:698,t:1527272143381};\\\", \\\"{x:1614,y:702,t:1527272143389};\\\", \\\"{x:1614,y:706,t:1527272143402};\\\", \\\"{x:1614,y:715,t:1527272143416};\\\", \\\"{x:1614,y:723,t:1527272143433};\\\", \\\"{x:1614,y:737,t:1527272143451};\\\", \\\"{x:1614,y:751,t:1527272143467};\\\", \\\"{x:1614,y:763,t:1527272143484};\\\", \\\"{x:1617,y:786,t:1527272143501};\\\", \\\"{x:1619,y:796,t:1527272143516};\\\", \\\"{x:1621,y:803,t:1527272143534};\\\", \\\"{x:1623,y:809,t:1527272143550};\\\", \\\"{x:1625,y:814,t:1527272143568};\\\", \\\"{x:1625,y:816,t:1527272143583};\\\", \\\"{x:1625,y:819,t:1527272143600};\\\", \\\"{x:1625,y:821,t:1527272143618};\\\", \\\"{x:1626,y:823,t:1527272143634};\\\", \\\"{x:1626,y:826,t:1527272143651};\\\", \\\"{x:1627,y:829,t:1527272143668};\\\", \\\"{x:1627,y:831,t:1527272143684};\\\", \\\"{x:1627,y:837,t:1527272143700};\\\", \\\"{x:1627,y:840,t:1527272143718};\\\", \\\"{x:1627,y:846,t:1527272143734};\\\", \\\"{x:1625,y:848,t:1527272143751};\\\", \\\"{x:1625,y:853,t:1527272143768};\\\", \\\"{x:1624,y:859,t:1527272143784};\\\", \\\"{x:1624,y:865,t:1527272143801};\\\", \\\"{x:1621,y:871,t:1527272143818};\\\", \\\"{x:1620,y:875,t:1527272143835};\\\", \\\"{x:1617,y:882,t:1527272143851};\\\", \\\"{x:1616,y:887,t:1527272143868};\\\", \\\"{x:1613,y:897,t:1527272143885};\\\", \\\"{x:1612,y:905,t:1527272143901};\\\", \\\"{x:1608,y:916,t:1527272143918};\\\", \\\"{x:1606,y:923,t:1527272143935};\\\", \\\"{x:1604,y:929,t:1527272143951};\\\", \\\"{x:1604,y:933,t:1527272143968};\\\", \\\"{x:1604,y:934,t:1527272143985};\\\", \\\"{x:1604,y:936,t:1527272144000};\\\", \\\"{x:1604,y:938,t:1527272144020};\\\", \\\"{x:1604,y:939,t:1527272144077};\\\", \\\"{x:1604,y:941,t:1527272144108};\\\", \\\"{x:1604,y:943,t:1527272144118};\\\", \\\"{x:1604,y:945,t:1527272144135};\\\", \\\"{x:1605,y:947,t:1527272144152};\\\", \\\"{x:1605,y:948,t:1527272144168};\\\", \\\"{x:1607,y:951,t:1527272144185};\\\", \\\"{x:1607,y:952,t:1527272144202};\\\", \\\"{x:1608,y:952,t:1527272144217};\\\", \\\"{x:1608,y:953,t:1527272144234};\\\", \\\"{x:1608,y:954,t:1527272144252};\\\", \\\"{x:1609,y:956,t:1527272144268};\\\", \\\"{x:1610,y:957,t:1527272144285};\\\", \\\"{x:1611,y:959,t:1527272144301};\\\", \\\"{x:1611,y:960,t:1527272144318};\\\", \\\"{x:1612,y:961,t:1527272144335};\\\", \\\"{x:1612,y:962,t:1527272144364};\\\", \\\"{x:1613,y:963,t:1527272144478};\\\", \\\"{x:1613,y:964,t:1527272144708};\\\", \\\"{x:1613,y:963,t:1527272149781};\\\", \\\"{x:1613,y:962,t:1527272149829};\\\", \\\"{x:1613,y:961,t:1527272149965};\\\", \\\"{x:1612,y:960,t:1527272150053};\\\", \\\"{x:1611,y:959,t:1527272150084};\\\", \\\"{x:1610,y:959,t:1527272150108};\\\", \\\"{x:1610,y:957,t:1527272150125};\\\", \\\"{x:1609,y:957,t:1527272150148};\\\", \\\"{x:1609,y:956,t:1527272150160};\\\", \\\"{x:1608,y:955,t:1527272150177};\\\", \\\"{x:1603,y:954,t:1527272150193};\\\", \\\"{x:1601,y:954,t:1527272150210};\\\", \\\"{x:1600,y:954,t:1527272150227};\\\", \\\"{x:1598,y:954,t:1527272150245};\\\", \\\"{x:1596,y:954,t:1527272150260};\\\", \\\"{x:1594,y:954,t:1527272150277};\\\", \\\"{x:1593,y:954,t:1527272150300};\\\", \\\"{x:1592,y:954,t:1527272150310};\\\", \\\"{x:1590,y:954,t:1527272150327};\\\", \\\"{x:1589,y:955,t:1527272150365};\\\", \\\"{x:1588,y:955,t:1527272150377};\\\", \\\"{x:1587,y:956,t:1527272150396};\\\", \\\"{x:1585,y:956,t:1527272150421};\\\", \\\"{x:1584,y:956,t:1527272150453};\\\", \\\"{x:1583,y:958,t:1527272150460};\\\", \\\"{x:1582,y:958,t:1527272150477};\\\", \\\"{x:1581,y:958,t:1527272150509};\\\", \\\"{x:1580,y:958,t:1527272150516};\\\", \\\"{x:1579,y:958,t:1527272150527};\\\", \\\"{x:1577,y:958,t:1527272150544};\\\", \\\"{x:1574,y:958,t:1527272150560};\\\", \\\"{x:1573,y:958,t:1527272150577};\\\", \\\"{x:1569,y:958,t:1527272150594};\\\", \\\"{x:1568,y:958,t:1527272150610};\\\", \\\"{x:1565,y:958,t:1527272150627};\\\", \\\"{x:1562,y:958,t:1527272150644};\\\", \\\"{x:1558,y:958,t:1527272150660};\\\", \\\"{x:1555,y:958,t:1527272150677};\\\", \\\"{x:1546,y:958,t:1527272150694};\\\", \\\"{x:1523,y:955,t:1527272150711};\\\", \\\"{x:1490,y:945,t:1527272150727};\\\", \\\"{x:1440,y:930,t:1527272150744};\\\", \\\"{x:1377,y:905,t:1527272150761};\\\", \\\"{x:1308,y:874,t:1527272150777};\\\", \\\"{x:1233,y:841,t:1527272150794};\\\", \\\"{x:1174,y:813,t:1527272150811};\\\", \\\"{x:1138,y:788,t:1527272150828};\\\", \\\"{x:1102,y:763,t:1527272150844};\\\", \\\"{x:1085,y:751,t:1527272150860};\\\", \\\"{x:1077,y:742,t:1527272150877};\\\", \\\"{x:1072,y:734,t:1527272150894};\\\", \\\"{x:1062,y:724,t:1527272150911};\\\", \\\"{x:1054,y:716,t:1527272150928};\\\", \\\"{x:1044,y:709,t:1527272150944};\\\", \\\"{x:1034,y:702,t:1527272150961};\\\", \\\"{x:1024,y:695,t:1527272150978};\\\", \\\"{x:1012,y:688,t:1527272150994};\\\", \\\"{x:1001,y:682,t:1527272151011};\\\", \\\"{x:982,y:671,t:1527272151029};\\\", \\\"{x:969,y:666,t:1527272151044};\\\", \\\"{x:955,y:659,t:1527272151061};\\\", \\\"{x:942,y:654,t:1527272151078};\\\", \\\"{x:933,y:649,t:1527272151094};\\\", \\\"{x:923,y:646,t:1527272151110};\\\", \\\"{x:909,y:642,t:1527272151127};\\\", \\\"{x:895,y:637,t:1527272151144};\\\", \\\"{x:875,y:635,t:1527272151160};\\\", \\\"{x:855,y:632,t:1527272151177};\\\", \\\"{x:834,y:629,t:1527272151197};\\\", \\\"{x:813,y:621,t:1527272151210};\\\", \\\"{x:780,y:613,t:1527272151227};\\\", \\\"{x:773,y:610,t:1527272151238};\\\", \\\"{x:756,y:605,t:1527272151256};\\\", \\\"{x:742,y:603,t:1527272151272};\\\", \\\"{x:726,y:599,t:1527272151289};\\\", \\\"{x:716,y:597,t:1527272151306};\\\", \\\"{x:706,y:595,t:1527272151322};\\\", \\\"{x:703,y:595,t:1527272151339};\\\", \\\"{x:699,y:594,t:1527272151355};\\\", \\\"{x:697,y:594,t:1527272151372};\\\", \\\"{x:696,y:594,t:1527272151389};\\\", \\\"{x:694,y:594,t:1527272151406};\\\", \\\"{x:693,y:594,t:1527272151422};\\\", \\\"{x:690,y:594,t:1527272151439};\\\", \\\"{x:687,y:594,t:1527272151455};\\\", \\\"{x:683,y:594,t:1527272151473};\\\", \\\"{x:677,y:594,t:1527272151489};\\\", \\\"{x:672,y:594,t:1527272151505};\\\", \\\"{x:666,y:594,t:1527272151523};\\\", \\\"{x:662,y:594,t:1527272151540};\\\", \\\"{x:659,y:594,t:1527272151555};\\\", \\\"{x:658,y:594,t:1527272151573};\\\", \\\"{x:657,y:593,t:1527272151591};\\\", \\\"{x:656,y:593,t:1527272151606};\\\", \\\"{x:652,y:593,t:1527272151622};\\\", \\\"{x:647,y:591,t:1527272151639};\\\", \\\"{x:640,y:590,t:1527272151655};\\\", \\\"{x:630,y:588,t:1527272151672};\\\", \\\"{x:620,y:585,t:1527272151689};\\\", \\\"{x:615,y:584,t:1527272151706};\\\", \\\"{x:611,y:582,t:1527272151722};\\\", \\\"{x:609,y:581,t:1527272151739};\\\", \\\"{x:608,y:581,t:1527272151763};\\\", \\\"{x:608,y:580,t:1527272151922};\\\", \\\"{x:608,y:580,t:1527272152017};\\\", \\\"{x:609,y:581,t:1527272152100};\\\", \\\"{x:614,y:583,t:1527272152108};\\\", \\\"{x:620,y:586,t:1527272152122};\\\", \\\"{x:641,y:602,t:1527272152140};\\\", \\\"{x:665,y:617,t:1527272152157};\\\", \\\"{x:703,y:633,t:1527272152174};\\\", \\\"{x:761,y:657,t:1527272152189};\\\", \\\"{x:828,y:676,t:1527272152206};\\\", \\\"{x:900,y:700,t:1527272152223};\\\", \\\"{x:975,y:718,t:1527272152239};\\\", \\\"{x:1050,y:740,t:1527272152256};\\\", \\\"{x:1117,y:763,t:1527272152273};\\\", \\\"{x:1177,y:783,t:1527272152290};\\\", \\\"{x:1217,y:796,t:1527272152307};\\\", \\\"{x:1257,y:817,t:1527272152324};\\\", \\\"{x:1302,y:831,t:1527272152339};\\\", \\\"{x:1339,y:843,t:1527272152356};\\\", \\\"{x:1365,y:850,t:1527272152373};\\\", \\\"{x:1394,y:858,t:1527272152389};\\\", \\\"{x:1416,y:865,t:1527272152406};\\\", \\\"{x:1424,y:869,t:1527272152424};\\\", \\\"{x:1428,y:870,t:1527272152439};\\\", \\\"{x:1436,y:874,t:1527272152457};\\\", \\\"{x:1446,y:878,t:1527272152474};\\\", \\\"{x:1456,y:883,t:1527272152489};\\\", \\\"{x:1475,y:889,t:1527272152506};\\\", \\\"{x:1497,y:893,t:1527272152523};\\\", \\\"{x:1514,y:895,t:1527272152540};\\\", \\\"{x:1528,y:896,t:1527272152556};\\\", \\\"{x:1537,y:896,t:1527272152573};\\\", \\\"{x:1539,y:896,t:1527272152590};\\\", \\\"{x:1540,y:896,t:1527272152607};\\\", \\\"{x:1541,y:896,t:1527272152636};\\\", \\\"{x:1542,y:896,t:1527272152644};\\\", \\\"{x:1544,y:896,t:1527272152659};\\\", \\\"{x:1548,y:895,t:1527272152676};\\\", \\\"{x:1549,y:894,t:1527272152689};\\\", \\\"{x:1553,y:891,t:1527272152706};\\\", \\\"{x:1556,y:887,t:1527272152724};\\\", \\\"{x:1560,y:879,t:1527272152739};\\\", \\\"{x:1560,y:868,t:1527272152756};\\\", \\\"{x:1561,y:853,t:1527272152774};\\\", \\\"{x:1559,y:832,t:1527272152790};\\\", \\\"{x:1558,y:811,t:1527272152806};\\\", \\\"{x:1557,y:790,t:1527272152824};\\\", \\\"{x:1557,y:769,t:1527272152840};\\\", \\\"{x:1557,y:751,t:1527272152856};\\\", \\\"{x:1557,y:735,t:1527272152874};\\\", \\\"{x:1560,y:722,t:1527272152889};\\\", \\\"{x:1564,y:713,t:1527272152907};\\\", \\\"{x:1569,y:705,t:1527272152924};\\\", \\\"{x:1572,y:702,t:1527272152940};\\\", \\\"{x:1575,y:700,t:1527272152957};\\\", \\\"{x:1578,y:700,t:1527272152974};\\\", \\\"{x:1582,y:698,t:1527272152990};\\\", \\\"{x:1587,y:696,t:1527272153007};\\\", \\\"{x:1590,y:695,t:1527272153024};\\\", \\\"{x:1591,y:694,t:1527272153040};\\\", \\\"{x:1592,y:694,t:1527272153109};\\\", \\\"{x:1593,y:694,t:1527272153124};\\\", \\\"{x:1595,y:694,t:1527272153140};\\\", \\\"{x:1597,y:694,t:1527272153157};\\\", \\\"{x:1598,y:694,t:1527272153213};\\\", \\\"{x:1599,y:694,t:1527272153236};\\\", \\\"{x:1600,y:694,t:1527272153260};\\\", \\\"{x:1601,y:694,t:1527272153274};\\\", \\\"{x:1604,y:695,t:1527272153291};\\\", \\\"{x:1609,y:696,t:1527272153308};\\\", \\\"{x:1613,y:697,t:1527272153325};\\\", \\\"{x:1614,y:698,t:1527272153341};\\\", \\\"{x:1615,y:698,t:1527272153493};\\\", \\\"{x:1616,y:698,t:1527272154780};\\\", \\\"{x:1616,y:699,t:1527272154791};\\\", \\\"{x:1616,y:700,t:1527272154807};\\\", \\\"{x:1616,y:703,t:1527272154825};\\\", \\\"{x:1616,y:706,t:1527272154842};\\\", \\\"{x:1616,y:710,t:1527272154858};\\\", \\\"{x:1615,y:714,t:1527272154874};\\\", \\\"{x:1615,y:717,t:1527272154891};\\\", \\\"{x:1615,y:726,t:1527272154908};\\\", \\\"{x:1615,y:731,t:1527272154924};\\\", \\\"{x:1615,y:735,t:1527272154941};\\\", \\\"{x:1615,y:738,t:1527272154957};\\\", \\\"{x:1615,y:742,t:1527272154973};\\\", \\\"{x:1615,y:745,t:1527272154990};\\\", \\\"{x:1615,y:749,t:1527272155008};\\\", \\\"{x:1613,y:751,t:1527272155023};\\\", \\\"{x:1613,y:754,t:1527272155041};\\\", \\\"{x:1613,y:757,t:1527272155058};\\\", \\\"{x:1613,y:759,t:1527272155074};\\\", \\\"{x:1613,y:763,t:1527272155090};\\\", \\\"{x:1613,y:766,t:1527272155108};\\\", \\\"{x:1613,y:768,t:1527272155123};\\\", \\\"{x:1613,y:772,t:1527272155140};\\\", \\\"{x:1613,y:774,t:1527272155158};\\\", \\\"{x:1613,y:777,t:1527272155174};\\\", \\\"{x:1614,y:782,t:1527272155191};\\\", \\\"{x:1614,y:787,t:1527272155207};\\\", \\\"{x:1615,y:791,t:1527272155225};\\\", \\\"{x:1615,y:796,t:1527272155242};\\\", \\\"{x:1617,y:802,t:1527272155258};\\\", \\\"{x:1617,y:807,t:1527272155275};\\\", \\\"{x:1617,y:813,t:1527272155291};\\\", \\\"{x:1617,y:821,t:1527272155307};\\\", \\\"{x:1617,y:826,t:1527272155324};\\\", \\\"{x:1617,y:831,t:1527272155341};\\\", \\\"{x:1617,y:836,t:1527272155357};\\\", \\\"{x:1617,y:839,t:1527272155375};\\\", \\\"{x:1617,y:844,t:1527272155391};\\\", \\\"{x:1617,y:847,t:1527272155407};\\\", \\\"{x:1617,y:852,t:1527272155424};\\\", \\\"{x:1617,y:858,t:1527272155442};\\\", \\\"{x:1617,y:863,t:1527272155458};\\\", \\\"{x:1617,y:870,t:1527272155475};\\\", \\\"{x:1617,y:876,t:1527272155491};\\\", \\\"{x:1617,y:886,t:1527272155507};\\\", \\\"{x:1617,y:893,t:1527272155525};\\\", \\\"{x:1618,y:897,t:1527272155540};\\\", \\\"{x:1618,y:904,t:1527272155558};\\\", \\\"{x:1618,y:909,t:1527272155575};\\\", \\\"{x:1618,y:915,t:1527272155591};\\\", \\\"{x:1618,y:919,t:1527272155608};\\\", \\\"{x:1618,y:922,t:1527272155624};\\\", \\\"{x:1618,y:924,t:1527272155642};\\\", \\\"{x:1618,y:925,t:1527272155658};\\\", \\\"{x:1618,y:926,t:1527272155675};\\\", \\\"{x:1618,y:927,t:1527272155692};\\\", \\\"{x:1618,y:928,t:1527272155797};\\\", \\\"{x:1618,y:930,t:1527272155837};\\\", \\\"{x:1617,y:933,t:1527272155853};\\\", \\\"{x:1617,y:935,t:1527272155869};\\\", \\\"{x:1617,y:936,t:1527272155884};\\\", \\\"{x:1617,y:938,t:1527272155900};\\\", \\\"{x:1617,y:939,t:1527272155909};\\\", \\\"{x:1617,y:940,t:1527272155924};\\\", \\\"{x:1617,y:941,t:1527272155941};\\\", \\\"{x:1617,y:942,t:1527272156051};\\\", \\\"{x:1617,y:944,t:1527272156067};\\\", \\\"{x:1617,y:945,t:1527272156099};\\\", \\\"{x:1617,y:947,t:1527272156116};\\\", \\\"{x:1618,y:947,t:1527272156908};\\\", \\\"{x:1619,y:947,t:1527272156925};\\\", \\\"{x:1619,y:948,t:1527272156948};\\\", \\\"{x:1620,y:949,t:1527272158828};\\\", \\\"{x:1621,y:949,t:1527272160589};\\\", \\\"{x:1622,y:949,t:1527272160819};\\\", \\\"{x:1622,y:950,t:1527272160900};\\\", \\\"{x:1622,y:951,t:1527272161245};\\\", \\\"{x:1622,y:952,t:1527272161341};\\\", \\\"{x:1620,y:952,t:1527272161757};\\\", \\\"{x:1617,y:952,t:1527272161773};\\\", \\\"{x:1613,y:952,t:1527272161780};\\\", \\\"{x:1609,y:952,t:1527272161794};\\\", \\\"{x:1599,y:951,t:1527272161811};\\\", \\\"{x:1586,y:950,t:1527272161828};\\\", \\\"{x:1573,y:950,t:1527272161843};\\\", \\\"{x:1549,y:949,t:1527272161860};\\\", \\\"{x:1525,y:944,t:1527272161877};\\\", \\\"{x:1503,y:943,t:1527272161893};\\\", \\\"{x:1485,y:942,t:1527272161910};\\\", \\\"{x:1469,y:939,t:1527272161928};\\\", \\\"{x:1459,y:938,t:1527272161945};\\\", \\\"{x:1455,y:937,t:1527272161961};\\\", \\\"{x:1453,y:937,t:1527272161977};\\\", \\\"{x:1449,y:937,t:1527272161995};\\\", \\\"{x:1443,y:937,t:1527272162011};\\\", \\\"{x:1432,y:940,t:1527272162028};\\\", \\\"{x:1417,y:942,t:1527272162044};\\\", \\\"{x:1411,y:944,t:1527272162060};\\\", \\\"{x:1407,y:945,t:1527272162077};\\\", \\\"{x:1405,y:946,t:1527272162094};\\\", \\\"{x:1403,y:949,t:1527272162111};\\\", \\\"{x:1402,y:953,t:1527272162128};\\\", \\\"{x:1398,y:965,t:1527272162145};\\\", \\\"{x:1393,y:978,t:1527272162161};\\\", \\\"{x:1385,y:990,t:1527272162177};\\\", \\\"{x:1376,y:1002,t:1527272162194};\\\", \\\"{x:1370,y:1006,t:1527272162211};\\\", \\\"{x:1367,y:1006,t:1527272162228};\\\", \\\"{x:1365,y:1006,t:1527272162260};\\\", \\\"{x:1364,y:1006,t:1527272162277};\\\", \\\"{x:1361,y:1003,t:1527272162294};\\\", \\\"{x:1361,y:990,t:1527272162310};\\\", \\\"{x:1361,y:961,t:1527272162327};\\\", \\\"{x:1361,y:938,t:1527272162344};\\\", \\\"{x:1361,y:911,t:1527272162360};\\\", \\\"{x:1361,y:884,t:1527272162378};\\\", \\\"{x:1361,y:856,t:1527272162395};\\\", \\\"{x:1359,y:834,t:1527272162411};\\\", \\\"{x:1355,y:811,t:1527272162428};\\\", \\\"{x:1350,y:786,t:1527272162444};\\\", \\\"{x:1347,y:776,t:1527272162460};\\\", \\\"{x:1344,y:768,t:1527272162478};\\\", \\\"{x:1343,y:763,t:1527272162495};\\\", \\\"{x:1340,y:757,t:1527272162512};\\\", \\\"{x:1336,y:752,t:1527272162527};\\\", \\\"{x:1334,y:748,t:1527272162544};\\\", \\\"{x:1332,y:744,t:1527272162560};\\\", \\\"{x:1329,y:742,t:1527272162578};\\\", \\\"{x:1328,y:740,t:1527272162595};\\\", \\\"{x:1326,y:737,t:1527272162611};\\\", \\\"{x:1323,y:733,t:1527272162628};\\\", \\\"{x:1317,y:720,t:1527272162643};\\\", \\\"{x:1316,y:710,t:1527272162660};\\\", \\\"{x:1312,y:697,t:1527272162677};\\\", \\\"{x:1309,y:688,t:1527272162694};\\\", \\\"{x:1308,y:679,t:1527272162710};\\\", \\\"{x:1308,y:672,t:1527272162727};\\\", \\\"{x:1308,y:670,t:1527272162744};\\\", \\\"{x:1308,y:668,t:1527272162760};\\\", \\\"{x:1307,y:668,t:1527272162804};\\\", \\\"{x:1306,y:668,t:1527272162812};\\\", \\\"{x:1304,y:668,t:1527272162826};\\\", \\\"{x:1287,y:668,t:1527272162844};\\\", \\\"{x:1267,y:669,t:1527272162861};\\\", \\\"{x:1236,y:674,t:1527272162877};\\\", \\\"{x:1205,y:675,t:1527272162894};\\\", \\\"{x:1163,y:675,t:1527272162911};\\\", \\\"{x:1113,y:675,t:1527272162927};\\\", \\\"{x:1071,y:675,t:1527272162944};\\\", \\\"{x:1022,y:671,t:1527272162961};\\\", \\\"{x:984,y:658,t:1527272162977};\\\", \\\"{x:952,y:644,t:1527272162994};\\\", \\\"{x:921,y:625,t:1527272163011};\\\", \\\"{x:894,y:600,t:1527272163027};\\\", \\\"{x:862,y:572,t:1527272163044};\\\", \\\"{x:842,y:554,t:1527272163066};\\\", \\\"{x:823,y:538,t:1527272163082};\\\", \\\"{x:804,y:521,t:1527272163099};\\\", \\\"{x:783,y:505,t:1527272163115};\\\", \\\"{x:770,y:498,t:1527272163131};\\\", \\\"{x:760,y:493,t:1527272163148};\\\", \\\"{x:752,y:491,t:1527272163165};\\\", \\\"{x:746,y:490,t:1527272163182};\\\", \\\"{x:745,y:490,t:1527272163199};\\\", \\\"{x:744,y:490,t:1527272163214};\\\", \\\"{x:747,y:490,t:1527272163276};\\\", \\\"{x:749,y:490,t:1527272163283};\\\", \\\"{x:753,y:492,t:1527272163298};\\\", \\\"{x:767,y:493,t:1527272163315};\\\", \\\"{x:787,y:493,t:1527272163332};\\\", \\\"{x:802,y:493,t:1527272163349};\\\", \\\"{x:817,y:493,t:1527272163365};\\\", \\\"{x:825,y:493,t:1527272163382};\\\", \\\"{x:832,y:493,t:1527272163399};\\\", \\\"{x:833,y:493,t:1527272163415};\\\", \\\"{x:836,y:493,t:1527272163432};\\\", \\\"{x:837,y:493,t:1527272163651};\\\", \\\"{x:837,y:493,t:1527272163687};\\\", \\\"{x:837,y:494,t:1527272163739};\\\", \\\"{x:833,y:497,t:1527272163749};\\\", \\\"{x:820,y:505,t:1527272163766};\\\", \\\"{x:804,y:512,t:1527272163782};\\\", \\\"{x:780,y:523,t:1527272163799};\\\", \\\"{x:751,y:532,t:1527272163816};\\\", \\\"{x:729,y:541,t:1527272163832};\\\", \\\"{x:709,y:552,t:1527272163850};\\\", \\\"{x:695,y:562,t:1527272163866};\\\", \\\"{x:684,y:571,t:1527272163883};\\\", \\\"{x:672,y:583,t:1527272163899};\\\", \\\"{x:664,y:594,t:1527272163917};\\\", \\\"{x:655,y:604,t:1527272163933};\\\", \\\"{x:647,y:617,t:1527272163949};\\\", \\\"{x:638,y:628,t:1527272163966};\\\", \\\"{x:628,y:640,t:1527272163983};\\\", \\\"{x:619,y:650,t:1527272163999};\\\", \\\"{x:610,y:662,t:1527272164016};\\\", \\\"{x:601,y:673,t:1527272164033};\\\", \\\"{x:591,y:684,t:1527272164050};\\\", \\\"{x:583,y:693,t:1527272164067};\\\", \\\"{x:574,y:708,t:1527272164082};\\\", \\\"{x:563,y:722,t:1527272164100};\\\", \\\"{x:553,y:732,t:1527272164117};\\\", \\\"{x:547,y:736,t:1527272164133};\\\", \\\"{x:542,y:742,t:1527272164150};\\\", \\\"{x:538,y:744,t:1527272164166};\\\", \\\"{x:535,y:744,t:1527272164183};\\\", \\\"{x:533,y:745,t:1527272164200};\\\", \\\"{x:532,y:745,t:1527272164219};\\\", \\\"{x:531,y:744,t:1527272164244};\\\", \\\"{x:530,y:743,t:1527272164251};\\\", \\\"{x:530,y:742,t:1527272164266};\\\", \\\"{x:529,y:741,t:1527272164652};\\\", \\\"{x:529,y:739,t:1527272164715};\\\", \\\"{x:529,y:738,t:1527272164908};\\\", \\\"{x:529,y:736,t:1527272164988};\\\", \\\"{x:529,y:735,t:1527272165044};\\\", \\\"{x:530,y:734,t:1527272165404};\\\", \\\"{x:531,y:732,t:1527272165461};\\\", \\\"{x:532,y:729,t:1527272165484};\\\", \\\"{x:533,y:728,t:1527272165500};\\\", \\\"{x:533,y:727,t:1527272165516};\\\", \\\"{x:533,y:726,t:1527272165547};\\\", \\\"{x:533,y:725,t:1527272165587};\\\" ] }, { \\\"rt\\\": 20655, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 418351, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"K8DJ0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:533,y:724,t:1527272166685};\\\", \\\"{x:534,y:723,t:1527272166820};\\\", \\\"{x:535,y:722,t:1527272166837};\\\", \\\"{x:536,y:722,t:1527272166876};\\\", \\\"{x:536,y:721,t:1527272167052};\\\", \\\"{x:536,y:720,t:1527272167181};\\\", \\\"{x:537,y:720,t:1527272167228};\\\", \\\"{x:537,y:719,t:1527272167373};\\\", \\\"{x:538,y:719,t:1527272167459};\\\", \\\"{x:538,y:718,t:1527272167507};\\\", \\\"{x:539,y:718,t:1527272167519};\\\", \\\"{x:539,y:717,t:1527272167604};\\\", \\\"{x:539,y:716,t:1527272168212};\\\", \\\"{x:539,y:715,t:1527272168220};\\\", \\\"{x:541,y:714,t:1527272168236};\\\", \\\"{x:541,y:712,t:1527272168253};\\\", \\\"{x:541,y:711,t:1527272168271};\\\", \\\"{x:542,y:709,t:1527272168300};\\\", \\\"{x:542,y:708,t:1527272168315};\\\", \\\"{x:542,y:707,t:1527272168347};\\\", \\\"{x:542,y:706,t:1527272168355};\\\", \\\"{x:542,y:705,t:1527272168372};\\\", \\\"{x:542,y:704,t:1527272168412};\\\", \\\"{x:542,y:703,t:1527272168460};\\\", \\\"{x:542,y:702,t:1527272168524};\\\", \\\"{x:542,y:701,t:1527272168581};\\\", \\\"{x:542,y:700,t:1527272168588};\\\", \\\"{x:542,y:699,t:1527272168604};\\\", \\\"{x:542,y:698,t:1527272168628};\\\", \\\"{x:542,y:697,t:1527272168652};\\\", \\\"{x:542,y:696,t:1527272168660};\\\", \\\"{x:542,y:695,t:1527272168772};\\\", \\\"{x:543,y:695,t:1527272171676};\\\", \\\"{x:545,y:695,t:1527272171691};\\\", \\\"{x:547,y:695,t:1527272171707};\\\", \\\"{x:553,y:696,t:1527272171723};\\\", \\\"{x:560,y:700,t:1527272171740};\\\", \\\"{x:572,y:701,t:1527272171756};\\\", \\\"{x:672,y:715,t:1527272171772};\\\", \\\"{x:835,y:742,t:1527272171790};\\\", \\\"{x:993,y:766,t:1527272171807};\\\", \\\"{x:1174,y:797,t:1527272171823};\\\", \\\"{x:1340,y:824,t:1527272171840};\\\", \\\"{x:1476,y:845,t:1527272171857};\\\", \\\"{x:1568,y:863,t:1527272171873};\\\", \\\"{x:1603,y:875,t:1527272171890};\\\", \\\"{x:1623,y:880,t:1527272171906};\\\", \\\"{x:1640,y:885,t:1527272171923};\\\", \\\"{x:1667,y:891,t:1527272171940};\\\", \\\"{x:1689,y:894,t:1527272171956};\\\", \\\"{x:1711,y:899,t:1527272171974};\\\", \\\"{x:1730,y:902,t:1527272171990};\\\", \\\"{x:1738,y:903,t:1527272172006};\\\", \\\"{x:1746,y:904,t:1527272172024};\\\", \\\"{x:1749,y:904,t:1527272172039};\\\", \\\"{x:1750,y:906,t:1527272172057};\\\", \\\"{x:1751,y:906,t:1527272172109};\\\", \\\"{x:1751,y:909,t:1527272172124};\\\", \\\"{x:1751,y:913,t:1527272172139};\\\", \\\"{x:1749,y:921,t:1527272172157};\\\", \\\"{x:1743,y:926,t:1527272172174};\\\", \\\"{x:1735,y:929,t:1527272172190};\\\", \\\"{x:1726,y:935,t:1527272172207};\\\", \\\"{x:1716,y:939,t:1527272172223};\\\", \\\"{x:1702,y:941,t:1527272172239};\\\", \\\"{x:1692,y:944,t:1527272172257};\\\", \\\"{x:1685,y:944,t:1527272172273};\\\", \\\"{x:1675,y:945,t:1527272172290};\\\", \\\"{x:1663,y:947,t:1527272172307};\\\", \\\"{x:1646,y:949,t:1527272172324};\\\", \\\"{x:1633,y:950,t:1527272172340};\\\", \\\"{x:1621,y:950,t:1527272172357};\\\", \\\"{x:1611,y:951,t:1527272172374};\\\", \\\"{x:1603,y:954,t:1527272172390};\\\", \\\"{x:1598,y:954,t:1527272172407};\\\", \\\"{x:1592,y:956,t:1527272172424};\\\", \\\"{x:1585,y:958,t:1527272172440};\\\", \\\"{x:1575,y:959,t:1527272172457};\\\", \\\"{x:1568,y:961,t:1527272172474};\\\", \\\"{x:1563,y:962,t:1527272172490};\\\", \\\"{x:1558,y:963,t:1527272172507};\\\", \\\"{x:1554,y:964,t:1527272172524};\\\", \\\"{x:1553,y:965,t:1527272172541};\\\", \\\"{x:1552,y:966,t:1527272172557};\\\", \\\"{x:1551,y:966,t:1527272172574};\\\", \\\"{x:1549,y:966,t:1527272172591};\\\", \\\"{x:1550,y:966,t:1527272172965};\\\", \\\"{x:1550,y:965,t:1527272172988};\\\", \\\"{x:1551,y:964,t:1527272173261};\\\", \\\"{x:1552,y:964,t:1527272173308};\\\", \\\"{x:1553,y:964,t:1527272173325};\\\", \\\"{x:1554,y:964,t:1527272173341};\\\", \\\"{x:1555,y:964,t:1527272173363};\\\", \\\"{x:1556,y:964,t:1527272173388};\\\", \\\"{x:1556,y:963,t:1527272173748};\\\", \\\"{x:1556,y:962,t:1527272173965};\\\", \\\"{x:1555,y:961,t:1527272174035};\\\", \\\"{x:1554,y:960,t:1527272174436};\\\", \\\"{x:1554,y:959,t:1527272174867};\\\", \\\"{x:1553,y:958,t:1527272174899};\\\", \\\"{x:1552,y:958,t:1527272174940};\\\", \\\"{x:1552,y:957,t:1527272175140};\\\", \\\"{x:1552,y:956,t:1527272175380};\\\", \\\"{x:1551,y:956,t:1527272175396};\\\", \\\"{x:1551,y:954,t:1527272175475};\\\", \\\"{x:1551,y:953,t:1527272175523};\\\", \\\"{x:1551,y:954,t:1527272176372};\\\", \\\"{x:1551,y:955,t:1527272176468};\\\", \\\"{x:1547,y:955,t:1527272182996};\\\", \\\"{x:1539,y:955,t:1527272183003};\\\", \\\"{x:1533,y:955,t:1527272183015};\\\", \\\"{x:1515,y:955,t:1527272183032};\\\", \\\"{x:1492,y:954,t:1527272183048};\\\", \\\"{x:1475,y:951,t:1527272183065};\\\", \\\"{x:1447,y:946,t:1527272183082};\\\", \\\"{x:1388,y:936,t:1527272183099};\\\", \\\"{x:1303,y:917,t:1527272183115};\\\", \\\"{x:1164,y:894,t:1527272183132};\\\", \\\"{x:1058,y:876,t:1527272183149};\\\", \\\"{x:959,y:864,t:1527272183165};\\\", \\\"{x:861,y:849,t:1527272183182};\\\", \\\"{x:770,y:835,t:1527272183198};\\\", \\\"{x:683,y:822,t:1527272183215};\\\", \\\"{x:613,y:810,t:1527272183231};\\\", \\\"{x:552,y:795,t:1527272183249};\\\", \\\"{x:496,y:779,t:1527272183265};\\\", \\\"{x:430,y:761,t:1527272183282};\\\", \\\"{x:310,y:726,t:1527272183300};\\\", \\\"{x:229,y:698,t:1527272183316};\\\", \\\"{x:150,y:667,t:1527272183333};\\\", \\\"{x:73,y:637,t:1527272183349};\\\", \\\"{x:21,y:605,t:1527272183366};\\\", \\\"{x:0,y:585,t:1527272183383};\\\", \\\"{x:0,y:569,t:1527272183399};\\\", \\\"{x:0,y:552,t:1527272183415};\\\", \\\"{x:0,y:536,t:1527272183432};\\\", \\\"{x:0,y:522,t:1527272183449};\\\", \\\"{x:0,y:514,t:1527272183466};\\\", \\\"{x:2,y:504,t:1527272183482};\\\", \\\"{x:29,y:484,t:1527272183499};\\\", \\\"{x:64,y:467,t:1527272183515};\\\", \\\"{x:105,y:452,t:1527272183533};\\\", \\\"{x:191,y:427,t:1527272183550};\\\", \\\"{x:302,y:394,t:1527272183566};\\\", \\\"{x:423,y:365,t:1527272183582};\\\", \\\"{x:561,y:348,t:1527272183600};\\\", \\\"{x:682,y:337,t:1527272183615};\\\", \\\"{x:730,y:337,t:1527272183632};\\\", \\\"{x:761,y:337,t:1527272183650};\\\", \\\"{x:779,y:337,t:1527272183665};\\\", \\\"{x:784,y:337,t:1527272183683};\\\", \\\"{x:785,y:339,t:1527272183698};\\\", \\\"{x:788,y:345,t:1527272183716};\\\", \\\"{x:788,y:352,t:1527272183733};\\\", \\\"{x:789,y:363,t:1527272183750};\\\", \\\"{x:789,y:375,t:1527272183765};\\\", \\\"{x:787,y:386,t:1527272183783};\\\", \\\"{x:783,y:392,t:1527272183800};\\\", \\\"{x:778,y:397,t:1527272183815};\\\", \\\"{x:776,y:399,t:1527272183833};\\\", \\\"{x:772,y:401,t:1527272183850};\\\", \\\"{x:767,y:406,t:1527272183866};\\\", \\\"{x:761,y:412,t:1527272183883};\\\", \\\"{x:756,y:417,t:1527272183899};\\\", \\\"{x:751,y:422,t:1527272183916};\\\", \\\"{x:747,y:426,t:1527272183932};\\\", \\\"{x:744,y:429,t:1527272183950};\\\", \\\"{x:741,y:433,t:1527272183967};\\\", \\\"{x:737,y:437,t:1527272183982};\\\", \\\"{x:735,y:439,t:1527272183999};\\\", \\\"{x:734,y:439,t:1527272184016};\\\", \\\"{x:733,y:440,t:1527272184033};\\\", \\\"{x:732,y:440,t:1527272184050};\\\", \\\"{x:729,y:442,t:1527272184067};\\\", \\\"{x:726,y:444,t:1527272184083};\\\", \\\"{x:721,y:449,t:1527272184099};\\\", \\\"{x:720,y:453,t:1527272184117};\\\", \\\"{x:720,y:456,t:1527272184133};\\\", \\\"{x:719,y:459,t:1527272184150};\\\", \\\"{x:719,y:461,t:1527272184167};\\\", \\\"{x:719,y:462,t:1527272184183};\\\", \\\"{x:719,y:464,t:1527272184200};\\\", \\\"{x:719,y:469,t:1527272184217};\\\", \\\"{x:719,y:473,t:1527272184233};\\\", \\\"{x:719,y:481,t:1527272184250};\\\", \\\"{x:719,y:490,t:1527272184268};\\\", \\\"{x:720,y:497,t:1527272184282};\\\", \\\"{x:721,y:506,t:1527272184299};\\\", \\\"{x:723,y:512,t:1527272184317};\\\", \\\"{x:723,y:522,t:1527272184334};\\\", \\\"{x:723,y:531,t:1527272184351};\\\", \\\"{x:723,y:536,t:1527272184367};\\\", \\\"{x:723,y:539,t:1527272184383};\\\", \\\"{x:722,y:543,t:1527272184400};\\\", \\\"{x:722,y:545,t:1527272184416};\\\", \\\"{x:720,y:547,t:1527272184433};\\\", \\\"{x:720,y:549,t:1527272184450};\\\", \\\"{x:717,y:553,t:1527272184467};\\\", \\\"{x:714,y:557,t:1527272184483};\\\", \\\"{x:703,y:565,t:1527272184500};\\\", \\\"{x:693,y:573,t:1527272184516};\\\", \\\"{x:685,y:582,t:1527272184533};\\\", \\\"{x:678,y:592,t:1527272184550};\\\", \\\"{x:675,y:596,t:1527272184567};\\\", \\\"{x:675,y:601,t:1527272184584};\\\", \\\"{x:674,y:603,t:1527272184600};\\\", \\\"{x:674,y:608,t:1527272184616};\\\", \\\"{x:674,y:612,t:1527272184634};\\\", \\\"{x:674,y:615,t:1527272184650};\\\", \\\"{x:673,y:615,t:1527272184740};\\\", \\\"{x:671,y:616,t:1527272184750};\\\", \\\"{x:654,y:618,t:1527272184767};\\\", \\\"{x:627,y:618,t:1527272184785};\\\", \\\"{x:586,y:618,t:1527272184801};\\\", \\\"{x:511,y:618,t:1527272184816};\\\", \\\"{x:428,y:618,t:1527272184834};\\\", \\\"{x:314,y:618,t:1527272184851};\\\", \\\"{x:258,y:618,t:1527272184867};\\\", \\\"{x:230,y:618,t:1527272184884};\\\", \\\"{x:213,y:616,t:1527272184900};\\\", \\\"{x:208,y:614,t:1527272184917};\\\", \\\"{x:206,y:614,t:1527272184933};\\\", \\\"{x:206,y:613,t:1527272184951};\\\", \\\"{x:205,y:613,t:1527272184966};\\\", \\\"{x:203,y:610,t:1527272184983};\\\", \\\"{x:202,y:606,t:1527272185001};\\\", \\\"{x:202,y:599,t:1527272185017};\\\", \\\"{x:202,y:586,t:1527272185034};\\\", \\\"{x:202,y:578,t:1527272185051};\\\", \\\"{x:202,y:561,t:1527272185067};\\\", \\\"{x:199,y:551,t:1527272185084};\\\", \\\"{x:196,y:541,t:1527272185100};\\\", \\\"{x:192,y:532,t:1527272185116};\\\", \\\"{x:186,y:524,t:1527272185134};\\\", \\\"{x:183,y:520,t:1527272185151};\\\", \\\"{x:182,y:518,t:1527272185167};\\\", \\\"{x:181,y:518,t:1527272185212};\\\", \\\"{x:180,y:518,t:1527272185219};\\\", \\\"{x:179,y:518,t:1527272185234};\\\", \\\"{x:178,y:518,t:1527272185251};\\\", \\\"{x:176,y:518,t:1527272185267};\\\", \\\"{x:174,y:519,t:1527272185283};\\\", \\\"{x:172,y:520,t:1527272185300};\\\", \\\"{x:169,y:523,t:1527272185317};\\\", \\\"{x:168,y:525,t:1527272185336};\\\", \\\"{x:166,y:528,t:1527272185349};\\\", \\\"{x:165,y:530,t:1527272185367};\\\", \\\"{x:164,y:532,t:1527272185384};\\\", \\\"{x:164,y:533,t:1527272185401};\\\", \\\"{x:162,y:535,t:1527272185417};\\\", \\\"{x:161,y:536,t:1527272185434};\\\", \\\"{x:160,y:538,t:1527272185667};\\\", \\\"{x:160,y:539,t:1527272185675};\\\", \\\"{x:160,y:540,t:1527272185684};\\\", \\\"{x:161,y:542,t:1527272185701};\\\", \\\"{x:164,y:545,t:1527272185718};\\\", \\\"{x:171,y:550,t:1527272185734};\\\", \\\"{x:178,y:556,t:1527272185751};\\\", \\\"{x:198,y:565,t:1527272185768};\\\", \\\"{x:230,y:577,t:1527272185785};\\\", \\\"{x:286,y:594,t:1527272185801};\\\", \\\"{x:361,y:614,t:1527272185818};\\\", \\\"{x:487,y:630,t:1527272185834};\\\", \\\"{x:549,y:640,t:1527272185851};\\\", \\\"{x:579,y:643,t:1527272185867};\\\", \\\"{x:592,y:648,t:1527272185885};\\\", \\\"{x:597,y:651,t:1527272185900};\\\", \\\"{x:597,y:656,t:1527272185917};\\\", \\\"{x:592,y:660,t:1527272185934};\\\", \\\"{x:592,y:666,t:1527272185950};\\\", \\\"{x:589,y:675,t:1527272185967};\\\", \\\"{x:586,y:680,t:1527272185985};\\\", \\\"{x:580,y:690,t:1527272186001};\\\", \\\"{x:571,y:700,t:1527272186018};\\\", \\\"{x:561,y:719,t:1527272186035};\\\", \\\"{x:559,y:728,t:1527272186051};\\\", \\\"{x:554,y:738,t:1527272186067};\\\", \\\"{x:552,y:743,t:1527272186084};\\\", \\\"{x:551,y:744,t:1527272186101};\\\", \\\"{x:551,y:745,t:1527272186117};\\\", \\\"{x:549,y:745,t:1527272186171};\\\", \\\"{x:549,y:741,t:1527272186587};\\\", \\\"{x:551,y:737,t:1527272186601};\\\", \\\"{x:554,y:729,t:1527272186618};\\\", \\\"{x:560,y:725,t:1527272186900};\\\", \\\"{x:581,y:691,t:1527272186907};\\\", \\\"{x:604,y:648,t:1527272186919};\\\", \\\"{x:637,y:565,t:1527272186936};\\\", \\\"{x:652,y:499,t:1527272186952};\\\", \\\"{x:667,y:441,t:1527272186969};\\\", \\\"{x:671,y:403,t:1527272186986};\\\", \\\"{x:673,y:374,t:1527272187002};\\\", \\\"{x:673,y:323,t:1527272187019};\\\", \\\"{x:673,y:281,t:1527272187036};\\\", \\\"{x:675,y:217,t:1527272187052};\\\", \\\"{x:684,y:131,t:1527272187069};\\\", \\\"{x:694,y:35,t:1527272187086};\\\", \\\"{x:712,y:0,t:1527272187102};\\\", \\\"{x:718,y:0,t:1527272187119};\\\", \\\"{x:726,y:0,t:1527272187136};\\\", \\\"{x:732,y:0,t:1527272187152};\\\", \\\"{x:734,y:0,t:1527272187169};\\\", \\\"{x:736,y:0,t:1527272187188};\\\", \\\"{x:738,y:0,t:1527272187202};\\\", \\\"{x:757,y:0,t:1527272187219};\\\", \\\"{x:779,y:0,t:1527272187235};\\\", \\\"{x:784,y:0,t:1527272187253};\\\" ] }, { \\\"rt\\\": 41804, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 461368, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"K8DJ0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -I -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:784,y:2,t:1527272188975};\\\", \\\"{x:784,y:4,t:1527272188991};\\\", \\\"{x:784,y:5,t:1527272189015};\\\", \\\"{x:784,y:6,t:1527272189032};\\\", \\\"{x:784,y:8,t:1527272189083};\\\", \\\"{x:783,y:8,t:1527272189928};\\\", \\\"{x:782,y:8,t:1527272189942};\\\", \\\"{x:780,y:5,t:1527272189959};\\\", \\\"{x:779,y:4,t:1527272189975};\\\", \\\"{x:779,y:3,t:1527272190447};\\\", \\\"{x:779,y:2,t:1527272190459};\\\", \\\"{x:779,y:1,t:1527272190476};\\\", \\\"{x:779,y:0,t:1527272190492};\\\", \\\"{x:780,y:0,t:1527272190519};\\\", \\\"{x:781,y:0,t:1527272190543};\\\", \\\"{x:782,y:0,t:1527272196192};\\\", \\\"{x:784,y:5,t:1527272196199};\\\", \\\"{x:785,y:10,t:1527272196214};\\\", \\\"{x:790,y:26,t:1527272196230};\\\", \\\"{x:797,y:52,t:1527272196247};\\\", \\\"{x:807,y:76,t:1527272196263};\\\", \\\"{x:840,y:123,t:1527272196280};\\\", \\\"{x:879,y:172,t:1527272196297};\\\", \\\"{x:927,y:227,t:1527272196314};\\\", \\\"{x:980,y:275,t:1527272196331};\\\", \\\"{x:1049,y:334,t:1527272196348};\\\", \\\"{x:1120,y:396,t:1527272196364};\\\", \\\"{x:1196,y:452,t:1527272196381};\\\", \\\"{x:1282,y:508,t:1527272196397};\\\", \\\"{x:1347,y:558,t:1527272196414};\\\", \\\"{x:1388,y:591,t:1527272196430};\\\", \\\"{x:1432,y:647,t:1527272196446};\\\", \\\"{x:1459,y:691,t:1527272196464};\\\", \\\"{x:1472,y:713,t:1527272196480};\\\", \\\"{x:1482,y:733,t:1527272196497};\\\", \\\"{x:1488,y:745,t:1527272196514};\\\", \\\"{x:1491,y:755,t:1527272196530};\\\", \\\"{x:1497,y:768,t:1527272196547};\\\", \\\"{x:1502,y:785,t:1527272196564};\\\", \\\"{x:1509,y:802,t:1527272196580};\\\", \\\"{x:1514,y:813,t:1527272196597};\\\", \\\"{x:1519,y:822,t:1527272196614};\\\", \\\"{x:1520,y:829,t:1527272196631};\\\", \\\"{x:1522,y:838,t:1527272196647};\\\", \\\"{x:1522,y:841,t:1527272196665};\\\", \\\"{x:1522,y:846,t:1527272196681};\\\", \\\"{x:1522,y:849,t:1527272196697};\\\", \\\"{x:1522,y:852,t:1527272196714};\\\", \\\"{x:1521,y:854,t:1527272196730};\\\", \\\"{x:1520,y:858,t:1527272196748};\\\", \\\"{x:1518,y:863,t:1527272196764};\\\", \\\"{x:1515,y:868,t:1527272196782};\\\", \\\"{x:1515,y:873,t:1527272196797};\\\", \\\"{x:1513,y:879,t:1527272196814};\\\", \\\"{x:1513,y:884,t:1527272196831};\\\", \\\"{x:1511,y:886,t:1527272196847};\\\", \\\"{x:1511,y:887,t:1527272196863};\\\", \\\"{x:1510,y:888,t:1527272196881};\\\", \\\"{x:1508,y:892,t:1527272196897};\\\", \\\"{x:1506,y:895,t:1527272196913};\\\", \\\"{x:1504,y:898,t:1527272196931};\\\", \\\"{x:1502,y:900,t:1527272196947};\\\", \\\"{x:1501,y:901,t:1527272196964};\\\", \\\"{x:1500,y:902,t:1527272196980};\\\", \\\"{x:1499,y:905,t:1527272196997};\\\", \\\"{x:1497,y:906,t:1527272197014};\\\", \\\"{x:1494,y:911,t:1527272197030};\\\", \\\"{x:1494,y:912,t:1527272197047};\\\", \\\"{x:1493,y:913,t:1527272197064};\\\", \\\"{x:1493,y:915,t:1527272197081};\\\", \\\"{x:1492,y:916,t:1527272197097};\\\", \\\"{x:1491,y:917,t:1527272197114};\\\", \\\"{x:1491,y:918,t:1527272197135};\\\", \\\"{x:1491,y:919,t:1527272197148};\\\", \\\"{x:1490,y:921,t:1527272197164};\\\", \\\"{x:1489,y:923,t:1527272197181};\\\", \\\"{x:1487,y:927,t:1527272197197};\\\", \\\"{x:1487,y:929,t:1527272197214};\\\", \\\"{x:1487,y:932,t:1527272197231};\\\", \\\"{x:1486,y:934,t:1527272197248};\\\", \\\"{x:1486,y:937,t:1527272197264};\\\", \\\"{x:1484,y:939,t:1527272197281};\\\", \\\"{x:1484,y:941,t:1527272197303};\\\", \\\"{x:1484,y:942,t:1527272197314};\\\", \\\"{x:1484,y:943,t:1527272197351};\\\", \\\"{x:1484,y:944,t:1527272197365};\\\", \\\"{x:1484,y:945,t:1527272197415};\\\", \\\"{x:1484,y:946,t:1527272197438};\\\", \\\"{x:1484,y:947,t:1527272197448};\\\", \\\"{x:1484,y:948,t:1527272197470};\\\", \\\"{x:1484,y:949,t:1527272197480};\\\", \\\"{x:1484,y:950,t:1527272197497};\\\", \\\"{x:1484,y:952,t:1527272197513};\\\", \\\"{x:1483,y:954,t:1527272197531};\\\", \\\"{x:1483,y:955,t:1527272197548};\\\", \\\"{x:1483,y:956,t:1527272197564};\\\", \\\"{x:1483,y:957,t:1527272197581};\\\", \\\"{x:1483,y:958,t:1527272197672};\\\", \\\"{x:1484,y:959,t:1527272197687};\\\", \\\"{x:1484,y:960,t:1527272197703};\\\", \\\"{x:1484,y:961,t:1527272197715};\\\", \\\"{x:1485,y:962,t:1527272197743};\\\", \\\"{x:1485,y:963,t:1527272197759};\\\", \\\"{x:1486,y:964,t:1527272198072};\\\", \\\"{x:1482,y:958,t:1527272213128};\\\", \\\"{x:1455,y:941,t:1527272213144};\\\", \\\"{x:1431,y:926,t:1527272213161};\\\", \\\"{x:1405,y:909,t:1527272213177};\\\", \\\"{x:1378,y:893,t:1527272213197};\\\", \\\"{x:1351,y:878,t:1527272213210};\\\", \\\"{x:1329,y:864,t:1527272213226};\\\", \\\"{x:1307,y:851,t:1527272213243};\\\", \\\"{x:1288,y:839,t:1527272213261};\\\", \\\"{x:1275,y:830,t:1527272213276};\\\", \\\"{x:1261,y:821,t:1527272213294};\\\", \\\"{x:1247,y:812,t:1527272213310};\\\", \\\"{x:1241,y:806,t:1527272213327};\\\", \\\"{x:1234,y:800,t:1527272213343};\\\", \\\"{x:1229,y:797,t:1527272213360};\\\", \\\"{x:1225,y:793,t:1527272213378};\\\", \\\"{x:1223,y:792,t:1527272213393};\\\", \\\"{x:1215,y:783,t:1527272213411};\\\", \\\"{x:1209,y:779,t:1527272213427};\\\", \\\"{x:1203,y:771,t:1527272213443};\\\", \\\"{x:1195,y:764,t:1527272213460};\\\", \\\"{x:1179,y:751,t:1527272213478};\\\", \\\"{x:1166,y:740,t:1527272213494};\\\", \\\"{x:1146,y:726,t:1527272213510};\\\", \\\"{x:1128,y:713,t:1527272213527};\\\", \\\"{x:1113,y:704,t:1527272213544};\\\", \\\"{x:1096,y:695,t:1527272213560};\\\", \\\"{x:1082,y:688,t:1527272213578};\\\", \\\"{x:1072,y:685,t:1527272213593};\\\", \\\"{x:1062,y:681,t:1527272213610};\\\", \\\"{x:1052,y:677,t:1527272213627};\\\", \\\"{x:1043,y:675,t:1527272213643};\\\", \\\"{x:1037,y:674,t:1527272213660};\\\", \\\"{x:1025,y:671,t:1527272213677};\\\", \\\"{x:1012,y:670,t:1527272213693};\\\", \\\"{x:994,y:666,t:1527272213711};\\\", \\\"{x:982,y:665,t:1527272213728};\\\", \\\"{x:968,y:663,t:1527272213744};\\\", \\\"{x:956,y:662,t:1527272213761};\\\", \\\"{x:941,y:660,t:1527272213778};\\\", \\\"{x:929,y:658,t:1527272213795};\\\", \\\"{x:915,y:656,t:1527272213811};\\\", \\\"{x:900,y:652,t:1527272213828};\\\", \\\"{x:894,y:652,t:1527272213845};\\\", \\\"{x:884,y:652,t:1527272213861};\\\", \\\"{x:871,y:652,t:1527272213877};\\\", \\\"{x:839,y:652,t:1527272213895};\\\", \\\"{x:816,y:652,t:1527272213911};\\\", \\\"{x:789,y:652,t:1527272213928};\\\", \\\"{x:759,y:652,t:1527272213945};\\\", \\\"{x:724,y:652,t:1527272213961};\\\", \\\"{x:689,y:652,t:1527272213978};\\\", \\\"{x:656,y:652,t:1527272213994};\\\", \\\"{x:624,y:652,t:1527272214011};\\\", \\\"{x:591,y:647,t:1527272214028};\\\", \\\"{x:538,y:639,t:1527272214046};\\\", \\\"{x:491,y:634,t:1527272214061};\\\", \\\"{x:455,y:627,t:1527272214078};\\\", \\\"{x:415,y:618,t:1527272214095};\\\", \\\"{x:390,y:612,t:1527272214112};\\\", \\\"{x:373,y:606,t:1527272214129};\\\", \\\"{x:362,y:602,t:1527272214145};\\\", \\\"{x:351,y:599,t:1527272214161};\\\", \\\"{x:341,y:597,t:1527272214178};\\\", \\\"{x:334,y:594,t:1527272214195};\\\", \\\"{x:321,y:591,t:1527272214211};\\\", \\\"{x:306,y:587,t:1527272214228};\\\", \\\"{x:291,y:584,t:1527272214245};\\\", \\\"{x:279,y:583,t:1527272214262};\\\", \\\"{x:260,y:577,t:1527272214279};\\\", \\\"{x:251,y:574,t:1527272214296};\\\", \\\"{x:246,y:573,t:1527272214312};\\\", \\\"{x:243,y:572,t:1527272214328};\\\", \\\"{x:242,y:571,t:1527272214345};\\\", \\\"{x:240,y:570,t:1527272214363};\\\", \\\"{x:237,y:570,t:1527272214378};\\\", \\\"{x:233,y:568,t:1527272214396};\\\", \\\"{x:229,y:567,t:1527272214413};\\\", \\\"{x:224,y:565,t:1527272214428};\\\", \\\"{x:217,y:563,t:1527272214445};\\\", \\\"{x:208,y:561,t:1527272214462};\\\", \\\"{x:204,y:560,t:1527272214479};\\\", \\\"{x:202,y:560,t:1527272214495};\\\", \\\"{x:200,y:559,t:1527272214512};\\\", \\\"{x:199,y:559,t:1527272214542};\\\", \\\"{x:198,y:559,t:1527272214550};\\\", \\\"{x:197,y:559,t:1527272214563};\\\", \\\"{x:192,y:558,t:1527272214580};\\\", \\\"{x:187,y:558,t:1527272214597};\\\", \\\"{x:180,y:556,t:1527272214614};\\\", \\\"{x:178,y:556,t:1527272214629};\\\", \\\"{x:174,y:556,t:1527272214646};\\\", \\\"{x:172,y:556,t:1527272214662};\\\", \\\"{x:169,y:556,t:1527272214679};\\\", \\\"{x:168,y:556,t:1527272214696};\\\", \\\"{x:167,y:555,t:1527272214734};\\\", \\\"{x:166,y:555,t:1527272214791};\\\", \\\"{x:165,y:555,t:1527272214806};\\\", \\\"{x:166,y:555,t:1527272215166};\\\", \\\"{x:174,y:554,t:1527272215180};\\\", \\\"{x:196,y:549,t:1527272215197};\\\", \\\"{x:221,y:545,t:1527272215212};\\\", \\\"{x:253,y:542,t:1527272215229};\\\", \\\"{x:330,y:538,t:1527272215247};\\\", \\\"{x:397,y:539,t:1527272215263};\\\", \\\"{x:472,y:548,t:1527272215279};\\\", \\\"{x:564,y:561,t:1527272215297};\\\", \\\"{x:651,y:576,t:1527272215313};\\\", \\\"{x:747,y:598,t:1527272215330};\\\", \\\"{x:836,y:611,t:1527272215347};\\\", \\\"{x:930,y:636,t:1527272215363};\\\", \\\"{x:1018,y:659,t:1527272215380};\\\", \\\"{x:1088,y:681,t:1527272215397};\\\", \\\"{x:1151,y:698,t:1527272215412};\\\", \\\"{x:1196,y:710,t:1527272215429};\\\", \\\"{x:1245,y:727,t:1527272215446};\\\", \\\"{x:1284,y:744,t:1527272215463};\\\", \\\"{x:1324,y:759,t:1527272215479};\\\", \\\"{x:1357,y:772,t:1527272215497};\\\", \\\"{x:1386,y:782,t:1527272215513};\\\", \\\"{x:1412,y:792,t:1527272215530};\\\", \\\"{x:1433,y:801,t:1527272215547};\\\", \\\"{x:1444,y:806,t:1527272215563};\\\", \\\"{x:1450,y:809,t:1527272215580};\\\", \\\"{x:1451,y:809,t:1527272215597};\\\", \\\"{x:1451,y:810,t:1527272215631};\\\", \\\"{x:1451,y:811,t:1527272215671};\\\", \\\"{x:1452,y:811,t:1527272215680};\\\", \\\"{x:1452,y:813,t:1527272215697};\\\", \\\"{x:1452,y:814,t:1527272215714};\\\", \\\"{x:1452,y:816,t:1527272215730};\\\", \\\"{x:1452,y:817,t:1527272215747};\\\", \\\"{x:1453,y:818,t:1527272215815};\\\", \\\"{x:1454,y:819,t:1527272215831};\\\", \\\"{x:1455,y:819,t:1527272215847};\\\", \\\"{x:1456,y:820,t:1527272215864};\\\", \\\"{x:1458,y:821,t:1527272215887};\\\", \\\"{x:1457,y:822,t:1527272215999};\\\", \\\"{x:1454,y:822,t:1527272216015};\\\", \\\"{x:1447,y:822,t:1527272216031};\\\", \\\"{x:1441,y:822,t:1527272216047};\\\", \\\"{x:1435,y:820,t:1527272216064};\\\", \\\"{x:1429,y:818,t:1527272216081};\\\", \\\"{x:1424,y:816,t:1527272216096};\\\", \\\"{x:1417,y:816,t:1527272216113};\\\", \\\"{x:1412,y:815,t:1527272216131};\\\", \\\"{x:1408,y:813,t:1527272216146};\\\", \\\"{x:1407,y:813,t:1527272216163};\\\", \\\"{x:1404,y:812,t:1527272216180};\\\", \\\"{x:1403,y:811,t:1527272216206};\\\", \\\"{x:1402,y:811,t:1527272216230};\\\", \\\"{x:1399,y:808,t:1527272216247};\\\", \\\"{x:1397,y:806,t:1527272216263};\\\", \\\"{x:1394,y:801,t:1527272216280};\\\", \\\"{x:1393,y:800,t:1527272216297};\\\", \\\"{x:1392,y:799,t:1527272216313};\\\", \\\"{x:1391,y:797,t:1527272216331};\\\", \\\"{x:1390,y:797,t:1527272216346};\\\", \\\"{x:1390,y:796,t:1527272216364};\\\", \\\"{x:1390,y:795,t:1527272216415};\\\", \\\"{x:1389,y:795,t:1527272216431};\\\", \\\"{x:1388,y:794,t:1527272216448};\\\", \\\"{x:1384,y:793,t:1527272216465};\\\", \\\"{x:1383,y:792,t:1527272216481};\\\", \\\"{x:1379,y:789,t:1527272216498};\\\", \\\"{x:1376,y:787,t:1527272216513};\\\", \\\"{x:1374,y:787,t:1527272216531};\\\", \\\"{x:1370,y:784,t:1527272216548};\\\", \\\"{x:1365,y:783,t:1527272216564};\\\", \\\"{x:1360,y:780,t:1527272216581};\\\", \\\"{x:1358,y:779,t:1527272216597};\\\", \\\"{x:1357,y:779,t:1527272216614};\\\", \\\"{x:1357,y:778,t:1527272216630};\\\", \\\"{x:1355,y:777,t:1527272216655};\\\", \\\"{x:1354,y:776,t:1527272216678};\\\", \\\"{x:1354,y:775,t:1527272216686};\\\", \\\"{x:1353,y:774,t:1527272216698};\\\", \\\"{x:1351,y:773,t:1527272216714};\\\", \\\"{x:1349,y:772,t:1527272216731};\\\", \\\"{x:1348,y:771,t:1527272216748};\\\", \\\"{x:1346,y:770,t:1527272216764};\\\", \\\"{x:1346,y:769,t:1527272216781};\\\", \\\"{x:1345,y:767,t:1527272216799};\\\", \\\"{x:1344,y:767,t:1527272216814};\\\", \\\"{x:1343,y:767,t:1527272216848};\\\", \\\"{x:1342,y:766,t:1527272216865};\\\", \\\"{x:1340,y:766,t:1527272224175};\\\", \\\"{x:1337,y:766,t:1527272224188};\\\", \\\"{x:1330,y:766,t:1527272224203};\\\", \\\"{x:1324,y:766,t:1527272224220};\\\", \\\"{x:1317,y:766,t:1527272224237};\\\", \\\"{x:1306,y:766,t:1527272224254};\\\", \\\"{x:1301,y:766,t:1527272224271};\\\", \\\"{x:1297,y:766,t:1527272224287};\\\", \\\"{x:1293,y:766,t:1527272224304};\\\", \\\"{x:1287,y:766,t:1527272224320};\\\", \\\"{x:1283,y:765,t:1527272224337};\\\", \\\"{x:1278,y:765,t:1527272224355};\\\", \\\"{x:1274,y:765,t:1527272224370};\\\", \\\"{x:1271,y:764,t:1527272224388};\\\", \\\"{x:1269,y:764,t:1527272224404};\\\", \\\"{x:1268,y:764,t:1527272224420};\\\", \\\"{x:1267,y:764,t:1527272224486};\\\", \\\"{x:1267,y:763,t:1527272224631};\\\", \\\"{x:1265,y:763,t:1527272224759};\\\", \\\"{x:1264,y:763,t:1527272224782};\\\", \\\"{x:1264,y:762,t:1527272224799};\\\", \\\"{x:1263,y:761,t:1527272224806};\\\", \\\"{x:1263,y:759,t:1527272224823};\\\", \\\"{x:1262,y:758,t:1527272224837};\\\", \\\"{x:1262,y:756,t:1527272224855};\\\", \\\"{x:1261,y:756,t:1527272224871};\\\", \\\"{x:1261,y:755,t:1527272224888};\\\", \\\"{x:1261,y:754,t:1527272224904};\\\", \\\"{x:1261,y:753,t:1527272224921};\\\", \\\"{x:1260,y:752,t:1527272224938};\\\", \\\"{x:1260,y:750,t:1527272224954};\\\", \\\"{x:1260,y:749,t:1527272224971};\\\", \\\"{x:1260,y:746,t:1527272224987};\\\", \\\"{x:1259,y:745,t:1527272225005};\\\", \\\"{x:1259,y:743,t:1527272225021};\\\", \\\"{x:1259,y:742,t:1527272225037};\\\", \\\"{x:1259,y:740,t:1527272225055};\\\", \\\"{x:1259,y:739,t:1527272225072};\\\", \\\"{x:1259,y:738,t:1527272225087};\\\", \\\"{x:1259,y:737,t:1527272225104};\\\", \\\"{x:1259,y:736,t:1527272225122};\\\", \\\"{x:1259,y:735,t:1527272225139};\\\", \\\"{x:1259,y:734,t:1527272225431};\\\", \\\"{x:1260,y:734,t:1527272225479};\\\", \\\"{x:1260,y:735,t:1527272225527};\\\", \\\"{x:1261,y:737,t:1527272225551};\\\", \\\"{x:1262,y:738,t:1527272225559};\\\", \\\"{x:1263,y:739,t:1527272225571};\\\", \\\"{x:1263,y:740,t:1527272225588};\\\", \\\"{x:1263,y:741,t:1527272225605};\\\", \\\"{x:1264,y:743,t:1527272225621};\\\", \\\"{x:1266,y:747,t:1527272225638};\\\", \\\"{x:1266,y:748,t:1527272225655};\\\", \\\"{x:1266,y:749,t:1527272225671};\\\", \\\"{x:1267,y:751,t:1527272225688};\\\", \\\"{x:1267,y:752,t:1527272225705};\\\", \\\"{x:1267,y:753,t:1527272225726};\\\", \\\"{x:1267,y:755,t:1527272225742};\\\", \\\"{x:1267,y:756,t:1527272225758};\\\", \\\"{x:1267,y:757,t:1527272225771};\\\", \\\"{x:1267,y:758,t:1527272225789};\\\", \\\"{x:1267,y:759,t:1527272225805};\\\", \\\"{x:1268,y:761,t:1527272225822};\\\", \\\"{x:1268,y:762,t:1527272225847};\\\", \\\"{x:1269,y:763,t:1527272225855};\\\", \\\"{x:1269,y:764,t:1527272225872};\\\", \\\"{x:1271,y:766,t:1527272225890};\\\", \\\"{x:1272,y:766,t:1527272225906};\\\", \\\"{x:1275,y:768,t:1527272225922};\\\", \\\"{x:1277,y:769,t:1527272225939};\\\", \\\"{x:1278,y:771,t:1527272225955};\\\", \\\"{x:1280,y:769,t:1527272226079};\\\", \\\"{x:1283,y:765,t:1527272226088};\\\", \\\"{x:1290,y:754,t:1527272226105};\\\", \\\"{x:1295,y:740,t:1527272226123};\\\", \\\"{x:1299,y:722,t:1527272226139};\\\", \\\"{x:1304,y:707,t:1527272226155};\\\", \\\"{x:1309,y:693,t:1527272226172};\\\", \\\"{x:1316,y:677,t:1527272226190};\\\", \\\"{x:1317,y:674,t:1527272226206};\\\", \\\"{x:1318,y:666,t:1527272226223};\\\", \\\"{x:1320,y:661,t:1527272226238};\\\", \\\"{x:1322,y:656,t:1527272226256};\\\", \\\"{x:1325,y:648,t:1527272226272};\\\", \\\"{x:1328,y:643,t:1527272226289};\\\", \\\"{x:1330,y:638,t:1527272226305};\\\", \\\"{x:1331,y:636,t:1527272226323};\\\", \\\"{x:1332,y:633,t:1527272226338};\\\", \\\"{x:1333,y:630,t:1527272226355};\\\", \\\"{x:1333,y:626,t:1527272226373};\\\", \\\"{x:1333,y:620,t:1527272226391};\\\", \\\"{x:1333,y:619,t:1527272226406};\\\", \\\"{x:1333,y:615,t:1527272226422};\\\", \\\"{x:1332,y:612,t:1527272226438};\\\", \\\"{x:1330,y:608,t:1527272226456};\\\", \\\"{x:1327,y:605,t:1527272226473};\\\", \\\"{x:1325,y:600,t:1527272226490};\\\", \\\"{x:1323,y:598,t:1527272226506};\\\", \\\"{x:1320,y:595,t:1527272226522};\\\", \\\"{x:1320,y:594,t:1527272226540};\\\", \\\"{x:1318,y:592,t:1527272226555};\\\", \\\"{x:1317,y:589,t:1527272226572};\\\", \\\"{x:1314,y:586,t:1527272226590};\\\", \\\"{x:1313,y:585,t:1527272226605};\\\", \\\"{x:1307,y:580,t:1527272226623};\\\", \\\"{x:1304,y:578,t:1527272226639};\\\", \\\"{x:1302,y:576,t:1527272226656};\\\", \\\"{x:1297,y:575,t:1527272226673};\\\", \\\"{x:1292,y:574,t:1527272226689};\\\", \\\"{x:1282,y:572,t:1527272226706};\\\", \\\"{x:1268,y:572,t:1527272226723};\\\", \\\"{x:1246,y:568,t:1527272226739};\\\", \\\"{x:1223,y:565,t:1527272226755};\\\", \\\"{x:1201,y:561,t:1527272226772};\\\", \\\"{x:1170,y:555,t:1527272226790};\\\", \\\"{x:1161,y:554,t:1527272226806};\\\", \\\"{x:1139,y:550,t:1527272226823};\\\", \\\"{x:1128,y:547,t:1527272226839};\\\", \\\"{x:1119,y:546,t:1527272226855};\\\", \\\"{x:1114,y:546,t:1527272226873};\\\", \\\"{x:1107,y:545,t:1527272226889};\\\", \\\"{x:1101,y:543,t:1527272226906};\\\", \\\"{x:1092,y:542,t:1527272226922};\\\", \\\"{x:1082,y:541,t:1527272226940};\\\", \\\"{x:1070,y:541,t:1527272226957};\\\", \\\"{x:1057,y:541,t:1527272226972};\\\", \\\"{x:1042,y:541,t:1527272226989};\\\", \\\"{x:1017,y:541,t:1527272227005};\\\", \\\"{x:1003,y:540,t:1527272227022};\\\", \\\"{x:992,y:540,t:1527272227038};\\\", \\\"{x:981,y:540,t:1527272227056};\\\", \\\"{x:975,y:540,t:1527272227072};\\\", \\\"{x:968,y:538,t:1527272227089};\\\", \\\"{x:960,y:537,t:1527272227106};\\\", \\\"{x:950,y:533,t:1527272227122};\\\", \\\"{x:945,y:532,t:1527272227138};\\\", \\\"{x:941,y:530,t:1527272227157};\\\", \\\"{x:937,y:528,t:1527272227173};\\\", \\\"{x:934,y:528,t:1527272227189};\\\", \\\"{x:924,y:525,t:1527272227205};\\\", \\\"{x:915,y:523,t:1527272227223};\\\", \\\"{x:905,y:520,t:1527272227239};\\\", \\\"{x:894,y:519,t:1527272227256};\\\", \\\"{x:879,y:515,t:1527272227273};\\\", \\\"{x:861,y:513,t:1527272227290};\\\", \\\"{x:844,y:510,t:1527272227306};\\\", \\\"{x:831,y:510,t:1527272227323};\\\", \\\"{x:819,y:508,t:1527272227340};\\\", \\\"{x:806,y:505,t:1527272227356};\\\", \\\"{x:799,y:504,t:1527272227373};\\\", \\\"{x:786,y:503,t:1527272227390};\\\", \\\"{x:778,y:502,t:1527272227406};\\\", \\\"{x:765,y:501,t:1527272227423};\\\", \\\"{x:750,y:501,t:1527272227439};\\\", \\\"{x:734,y:501,t:1527272227456};\\\", \\\"{x:716,y:501,t:1527272227474};\\\", \\\"{x:702,y:500,t:1527272227490};\\\", \\\"{x:688,y:499,t:1527272227506};\\\", \\\"{x:679,y:497,t:1527272227523};\\\", \\\"{x:670,y:495,t:1527272227539};\\\", \\\"{x:666,y:495,t:1527272227555};\\\", \\\"{x:663,y:495,t:1527272227573};\\\", \\\"{x:660,y:495,t:1527272227590};\\\", \\\"{x:658,y:495,t:1527272227702};\\\", \\\"{x:657,y:495,t:1527272227710};\\\", \\\"{x:656,y:495,t:1527272227723};\\\", \\\"{x:655,y:495,t:1527272227741};\\\", \\\"{x:653,y:495,t:1527272227758};\\\", \\\"{x:650,y:495,t:1527272227774};\\\", \\\"{x:649,y:495,t:1527272227807};\\\", \\\"{x:636,y:496,t:1527272227823};\\\", \\\"{x:625,y:496,t:1527272227840};\\\", \\\"{x:615,y:497,t:1527272227857};\\\", \\\"{x:608,y:497,t:1527272227873};\\\", \\\"{x:605,y:497,t:1527272227891};\\\", \\\"{x:603,y:497,t:1527272227908};\\\", \\\"{x:603,y:498,t:1527272227924};\\\", \\\"{x:601,y:498,t:1527272227942};\\\", \\\"{x:600,y:499,t:1527272227957};\\\", \\\"{x:599,y:500,t:1527272227974};\\\", \\\"{x:597,y:505,t:1527272227991};\\\", \\\"{x:596,y:507,t:1527272228007};\\\", \\\"{x:595,y:510,t:1527272228023};\\\", \\\"{x:595,y:512,t:1527272228039};\\\", \\\"{x:595,y:513,t:1527272228056};\\\", \\\"{x:595,y:515,t:1527272228072};\\\", \\\"{x:596,y:516,t:1527272228089};\\\", \\\"{x:598,y:517,t:1527272228106};\\\", \\\"{x:599,y:517,t:1527272228166};\\\", \\\"{x:600,y:517,t:1527272228175};\\\", \\\"{x:601,y:517,t:1527272228207};\\\", \\\"{x:601,y:518,t:1527272228430};\\\", \\\"{x:601,y:519,t:1527272228440};\\\", \\\"{x:598,y:526,t:1527272228457};\\\", \\\"{x:591,y:539,t:1527272228475};\\\", \\\"{x:583,y:554,t:1527272228490};\\\", \\\"{x:572,y:570,t:1527272228507};\\\", \\\"{x:563,y:588,t:1527272228525};\\\", \\\"{x:556,y:601,t:1527272228541};\\\", \\\"{x:549,y:614,t:1527272228557};\\\", \\\"{x:542,y:625,t:1527272228574};\\\", \\\"{x:538,y:632,t:1527272228591};\\\", \\\"{x:537,y:636,t:1527272228606};\\\", \\\"{x:534,y:640,t:1527272228624};\\\", \\\"{x:532,y:644,t:1527272228641};\\\", \\\"{x:530,y:647,t:1527272228658};\\\", \\\"{x:527,y:652,t:1527272228674};\\\", \\\"{x:524,y:659,t:1527272228691};\\\", \\\"{x:521,y:666,t:1527272228708};\\\", \\\"{x:519,y:675,t:1527272228723};\\\", \\\"{x:517,y:687,t:1527272228741};\\\", \\\"{x:510,y:707,t:1527272228758};\\\", \\\"{x:507,y:720,t:1527272228773};\\\", \\\"{x:501,y:736,t:1527272228792};\\\", \\\"{x:498,y:749,t:1527272228808};\\\", \\\"{x:494,y:761,t:1527272228824};\\\", \\\"{x:494,y:772,t:1527272228841};\\\", \\\"{x:490,y:781,t:1527272228857};\\\", \\\"{x:490,y:785,t:1527272228873};\\\", \\\"{x:489,y:786,t:1527272228891};\\\", \\\"{x:490,y:784,t:1527272229006};\\\", \\\"{x:490,y:779,t:1527272229013};\\\", \\\"{x:491,y:775,t:1527272229024};\\\", \\\"{x:494,y:766,t:1527272229041};\\\", \\\"{x:496,y:754,t:1527272229058};\\\", \\\"{x:497,y:746,t:1527272229073};\\\", \\\"{x:498,y:739,t:1527272229091};\\\", \\\"{x:498,y:736,t:1527272229108};\\\", \\\"{x:498,y:737,t:1527272229358};\\\", \\\"{x:498,y:740,t:1527272229375};\\\", \\\"{x:498,y:741,t:1527272229382};\\\", \\\"{x:499,y:743,t:1527272229398};\\\", \\\"{x:499,y:744,t:1527272229407};\\\", \\\"{x:500,y:744,t:1527272229424};\\\", \\\"{x:500,y:745,t:1527272230015};\\\", \\\"{x:501,y:745,t:1527272230119};\\\" ] }, { \\\"rt\\\": 32382, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 495070, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"K8DJ0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"I SEE WHICH POINTS HAVE 12 PM AS THEIR X COORDINATE\\\\n\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 7846, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 503922, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"K8DJ0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 14241, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Other\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Math or Computer Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 519187, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"K8DJ0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 17111, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 537386, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"K8DJ0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"K8DJ0\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 147, dom: 681, initialDom: 780",
  "javascriptErrors": []
}