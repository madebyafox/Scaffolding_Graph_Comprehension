var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "369cdae768e59e679ddda3cf187ba121",
  "created": "2018-05-29T10:13:18.6004287-07:00",
  "lastActivity": "2018-05-29T10:13:35.0104287-07:00",
  "pageViews": [
    {
      "id": "05291811a426f59ed800699d5fb985b3bd293d9c",
      "startTime": "2018-05-29T10:13:18.6004287-07:00",
      "endTime": "2018-05-29T10:13:35.0104287-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/12",
      "visitTime": 16410,
      "engagementTime": 16408,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 16410,
  "engagementTime": 16408,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=RRF03",
    "CONDITION=114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "8fc5ce4cf162d5ca1782a589832bd5ce",
  "gdpr": false
}