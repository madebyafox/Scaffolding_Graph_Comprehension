var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "ef4fcb8a2690064d03d414501821630e",
  "created": "2018-06-01T11:14:30.0133276-07:00",
  "lastActivity": "2018-06-01T11:14:45.0223453-07:00",
  "pageViews": [
    {
      "id": "060130262b67169dbd781dee7405cdbdeea0f2ab",
      "startTime": "2018-06-01T11:14:30.1833453-07:00",
      "endTime": "2018-06-01T11:14:45.0223453-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/11",
      "visitTime": 14839,
      "engagementTime": 14688,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 14839,
  "engagementTime": 14688,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=2ZXKM",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "451337430b16ed77bf3c16f405ffd25f",
  "gdpr": false
}