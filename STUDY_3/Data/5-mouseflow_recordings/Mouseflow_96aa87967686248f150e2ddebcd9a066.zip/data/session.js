var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "96aa87967686248f150e2ddebcd9a066",
  "created": "2018-05-22T13:05:52.7385502-07:00",
  "lastActivity": "2018-05-22T13:06:04.5452771-07:00",
  "pageViews": [
    {
      "id": "05225238ac9c346d01bde521930ae7531d6fa0bd",
      "startTime": "2018-05-22T13:05:52.7385502-07:00",
      "endTime": "2018-05-22T13:06:04.5452771-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 11858,
      "engagementTime": 11809,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 11858,
  "engagementTime": 11809,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.25",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=H1RGT",
    "CONDITION=121",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d6df7617e5fe1eb60cc160655877be74",
  "gdpr": false
}