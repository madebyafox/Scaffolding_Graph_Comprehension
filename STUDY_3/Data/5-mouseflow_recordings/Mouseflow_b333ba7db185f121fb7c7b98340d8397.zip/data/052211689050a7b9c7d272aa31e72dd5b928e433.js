var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052211689050a7b9c7d272aa31e72dd5b928e433"] = {
  "startTime": "2018-05-22T21:14:11.0369474Z",
  "websitePageUrl": "/16",
  "visitTime": 72845,
  "engagementTime": 71192,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "b333ba7db185f121fb7c7b98340d8397",
    "created": "2018-05-22T21:14:10.8466707+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=OZV09",
      "CONDITION=121"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "9ea82fbc2191aaae9cabfa04905336fb",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/b333ba7db185f121fb7c7b98340d8397/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 537,
      "y": 711
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 536,
      "y": 643
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 49337,
      "y": 35177,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1581,
      "e": 1581,
      "ty": 6,
      "x": 536,
      "y": 602,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1601,
      "e": 1601,
      "ty": 2,
      "x": 538,
      "y": 592
    },
    {
      "t": 1700,
      "e": 1700,
      "ty": 2,
      "x": 538,
      "y": 580
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 49674,
      "y": 43095,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 540,
      "y": 573
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 49787,
      "y": 40668,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2264,
      "e": 2264,
      "ty": 3,
      "x": 540,
      "y": 573,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2265,
      "e": 2265,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2439,
      "e": 2439,
      "ty": 4,
      "x": 49787,
      "y": 40668,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2439,
      "e": 2439,
      "ty": 5,
      "x": 540,
      "y": 573,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8612,
      "e": 7439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 8763,
      "e": 7590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 8834,
      "e": 7661,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 8835,
      "e": 7662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8971,
      "e": 7798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 8994,
      "e": 7821,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 9098,
      "e": 7925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 9163,
      "e": 7990,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 9163,
      "e": 7990,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9234,
      "e": 8061,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Lo"
    },
    {
      "t": 9315,
      "e": 8142,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 9315,
      "e": 8142,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9386,
      "e": 8213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Loo"
    },
    {
      "t": 9538,
      "e": 8365,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 9538,
      "e": 8365,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9642,
      "e": 8469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 9642,
      "e": 8469,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9698,
      "e": 8525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Looin"
    },
    {
      "t": 9779,
      "e": 8606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 9779,
      "e": 8606,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9786,
      "e": 8613,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 9867,
      "e": 8694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 9931,
      "e": 8758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 9931,
      "e": 8758,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9986,
      "e": 8813,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 9986,
      "e": 8813,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10001,
      "e": 8828,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10034,
      "e": 8861,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 10146,
      "e": 8973,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10146,
      "e": 8973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 10146,
      "e": 8973,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10250,
      "e": 9077,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 10355,
      "e": 9182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10355,
      "e": 9182,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10373,
      "e": 9200,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 10373,
      "e": 9200,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10434,
      "e": 9261,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 10587,
      "e": 9414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 10587,
      "e": 9414,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10610,
      "e": 9437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 10731,
      "e": 9558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 10731,
      "e": 9558,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10794,
      "e": 9621,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 10875,
      "e": 9702,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10875,
      "e": 9702,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10883,
      "e": 9710,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 10946,
      "e": 9773,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11859,
      "e": 10686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11914,
      "e": 10741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Looing at the"
    },
    {
      "t": 12011,
      "e": 10838,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12066,
      "e": 10893,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Looing at th"
    },
    {
      "t": 12162,
      "e": 10989,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12219,
      "e": 11046,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Looing at t"
    },
    {
      "t": 12298,
      "e": 11125,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12354,
      "e": 11181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Looing at "
    },
    {
      "t": 12434,
      "e": 11261,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12506,
      "e": 11333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Looing at"
    },
    {
      "t": 12579,
      "e": 11406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12643,
      "e": 11470,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Looing a"
    },
    {
      "t": 12723,
      "e": 11550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12786,
      "e": 11613,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Looing "
    },
    {
      "t": 12866,
      "e": 11693,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12946,
      "e": 11773,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Looing"
    },
    {
      "t": 13026,
      "e": 11853,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13099,
      "e": 11926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Looin"
    },
    {
      "t": 13179,
      "e": 12006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13259,
      "e": 12086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Looi"
    },
    {
      "t": 13347,
      "e": 12174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13442,
      "e": 12269,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Loo"
    },
    {
      "t": 13978,
      "e": 12805,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 13980,
      "e": 12807,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14050,
      "e": 12877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look"
    },
    {
      "t": 14074,
      "e": 12901,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14074,
      "e": 12901,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14138,
      "e": 12965,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 14139,
      "e": 12966,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14203,
      "e": 13030,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 14275,
      "e": 13102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14276,
      "e": 13103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14283,
      "e": 13110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 14371,
      "e": 13198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14411,
      "e": 13238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14411,
      "e": 13238,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14499,
      "e": 13326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14507,
      "e": 13334,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14508,
      "e": 13335,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14578,
      "e": 13405,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 14578,
      "e": 13405,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14667,
      "e": 13494,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 14674,
      "e": 13501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14675,
      "e": 13502,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14739,
      "e": 13566,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 14795,
      "e": 13622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14819,
      "e": 13646,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14819,
      "e": 13646,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14890,
      "e": 13717,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15003,
      "e": 13830,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the "
    },
    {
      "t": 15051,
      "e": 13878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 15051,
      "e": 13878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15194,
      "e": 14021,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 15194,
      "e": 14021,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15203,
      "e": 14030,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 15283,
      "e": 14110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15362,
      "e": 14189,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 15364,
      "e": 14191,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15482,
      "e": 14309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 15482,
      "e": 14309,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15522,
      "e": 14349,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 15626,
      "e": 14453,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15635,
      "e": 14462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 15635,
      "e": 14462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15706,
      "e": 14533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 15706,
      "e": 14533,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15770,
      "e": 14597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts"
    },
    {
      "t": 15834,
      "e": 14661,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15867,
      "e": 14694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15868,
      "e": 14695,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15954,
      "e": 14781,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16187,
      "e": 15014,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 16188,
      "e": 15015,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16298,
      "e": 15125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 16330,
      "e": 15157,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 16330,
      "e": 15157,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16443,
      "e": 15270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 16483,
      "e": 15310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 16484,
      "e": 15311,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16554,
      "e": 15381,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 16643,
      "e": 15470,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 16643,
      "e": 15470,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16755,
      "e": 15582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 16756,
      "e": 15583,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16794,
      "e": 15621,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 16882,
      "e": 15709,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 16883,
      "e": 15710,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16930,
      "e": 15757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 17050,
      "e": 15877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17059,
      "e": 15886,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 17060,
      "e": 15887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17202,
      "e": 16029,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the points corresp"
    },
    {
      "t": 17211,
      "e": 16038,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 17211,
      "e": 16038,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17226,
      "e": 16053,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 17323,
      "e": 16150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17779,
      "e": 16606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 17779,
      "e": 16606,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17907,
      "e": 16607,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 17979,
      "e": 16679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 17979,
      "e": 16679,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18074,
      "e": 16774,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 18123,
      "e": 16823,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 18123,
      "e": 16823,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18194,
      "e": 16894,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 18194,
      "e": 16894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18242,
      "e": 16942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 18314,
      "e": 17014,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 18315,
      "e": 17015,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18322,
      "e": 17022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 18411,
      "e": 17111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18491,
      "e": 17191,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18491,
      "e": 17191,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18570,
      "e": 17270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18626,
      "e": 17326,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18626,
      "e": 17326,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18699,
      "e": 17399,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 18803,
      "e": 17503,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the points corresponding t"
    },
    {
      "t": 18867,
      "e": 17567,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 18868,
      "e": 17568,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18994,
      "e": 17694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 19116,
      "e": 17816,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19116,
      "e": 17816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19211,
      "e": 17911,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19731,
      "e": 18431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 19732,
      "e": 18432,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19883,
      "e": 18583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 19883,
      "e": 18583,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19898,
      "e": 18598,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 20002,
      "e": 18702,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the points corresponding to 12"
    },
    {
      "t": 20002,
      "e": 18702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20058,
      "e": 18758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20058,
      "e": 18758,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20137,
      "e": 18837,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21562,
      "e": 20262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 21562,
      "e": 20262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21683,
      "e": 20383,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 21683,
      "e": 20383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21706,
      "e": 20406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p,"
    },
    {
      "t": 21850,
      "e": 20550,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22570,
      "e": 21270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22650,
      "e": 21350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the points corresponding to 12 p"
    },
    {
      "t": 23834,
      "e": 22534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 23834,
      "e": 22534,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23962,
      "e": 22662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 24474,
      "e": 23174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24476,
      "e": 23176,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24578,
      "e": 23278,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25962,
      "e": 24662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 25963,
      "e": 24663,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26130,
      "e": 24830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 26138,
      "e": 24838,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 26139,
      "e": 24839,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26146,
      "e": 24846,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26147,
      "e": 24847,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26194,
      "e": 24894,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 26201,
      "e": 24901,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26859,
      "e": 25559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26947,
      "e": 25647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the points corresponding to 12 pm fr"
    },
    {
      "t": 27131,
      "e": 25831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 27132,
      "e": 25832,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27282,
      "e": 25982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 27282,
      "e": 25982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27306,
      "e": 26006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||om"
    },
    {
      "t": 27387,
      "e": 26087,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27388,
      "e": 26088,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27418,
      "e": 26118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27498,
      "e": 26198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27514,
      "e": 26214,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27514,
      "e": 26214,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27611,
      "e": 26311,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 27611,
      "e": 26311,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27666,
      "e": 26366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 27731,
      "e": 26431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 27731,
      "e": 26431,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27786,
      "e": 26486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 27874,
      "e": 26574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27947,
      "e": 26647,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27947,
      "e": 26647,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28025,
      "e": 26725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28418,
      "e": 27118,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 28419,
      "e": 27119,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28555,
      "e": 27255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 29051,
      "e": 27751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 29052,
      "e": 27752,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29138,
      "e": 27838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 29326,
      "e": 28026,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 29328,
      "e": 28028,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29453,
      "e": 28153,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 29895,
      "e": 28595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "90"
    },
    {
      "t": 29895,
      "e": 28595,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30004,
      "e": 28704,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30005,
      "e": 28705,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the points corresponding to 12 pm from the x-az"
    },
    {
      "t": 30029,
      "e": 28729,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||z"
    },
    {
      "t": 30614,
      "e": 29314,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30693,
      "e": 29393,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the points corresponding to 12 pm from the x-a"
    },
    {
      "t": 30774,
      "e": 29474,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 30774,
      "e": 29474,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30925,
      "e": 29625,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 30989,
      "e": 29689,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 30989,
      "e": 29689,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31061,
      "e": 29761,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 31117,
      "e": 29817,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 31118,
      "e": 29818,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31229,
      "e": 29929,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 32404,
      "e": 31104,
      "ty": 2,
      "x": 547,
      "y": 575
    },
    {
      "t": 32425,
      "e": 31125,
      "ty": 7,
      "x": 672,
      "y": 621,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32504,
      "e": 31204,
      "ty": 2,
      "x": 1919,
      "y": 878
    },
    {
      "t": 32541,
      "e": 31241,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 32541,
      "e": 31241,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32604,
      "e": 31304,
      "ty": 2,
      "x": 1919,
      "y": 588
    },
    {
      "t": 32629,
      "e": 31329,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 32704,
      "e": 31404,
      "ty": 2,
      "x": 524,
      "y": 309
    },
    {
      "t": 32755,
      "e": 31455,
      "ty": 41,
      "x": 15052,
      "y": 24928,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 32759,
      "e": 31459,
      "ty": 6,
      "x": 192,
      "y": 544,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32776,
      "e": 31476,
      "ty": 7,
      "x": 163,
      "y": 633,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32804,
      "e": 31504,
      "ty": 2,
      "x": 152,
      "y": 668
    },
    {
      "t": 32904,
      "e": 31604,
      "ty": 2,
      "x": 185,
      "y": 885
    },
    {
      "t": 33004,
      "e": 31704,
      "ty": 2,
      "x": 321,
      "y": 819
    },
    {
      "t": 33004,
      "e": 31704,
      "ty": 41,
      "x": 25169,
      "y": 44927,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 33104,
      "e": 31804,
      "ty": 2,
      "x": 481,
      "y": 733
    },
    {
      "t": 33204,
      "e": 31904,
      "ty": 2,
      "x": 516,
      "y": 689
    },
    {
      "t": 33255,
      "e": 31955,
      "ty": 41,
      "x": 47089,
      "y": 37670,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 33305,
      "e": 32005,
      "ty": 2,
      "x": 468,
      "y": 680
    },
    {
      "t": 33344,
      "e": 32044,
      "ty": 6,
      "x": 452,
      "y": 680,
      "ta": "#strategyButton"
    },
    {
      "t": 33404,
      "e": 32104,
      "ty": 2,
      "x": 435,
      "y": 680
    },
    {
      "t": 33504,
      "e": 32204,
      "ty": 41,
      "x": 52649,
      "y": 48699,
      "ta": "#strategyButton"
    },
    {
      "t": 33554,
      "e": 32254,
      "ty": 3,
      "x": 428,
      "y": 679,
      "ta": "#strategyButton"
    },
    {
      "t": 33555,
      "e": 32255,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the points corresponding to 12 pm from the x-axis."
    },
    {
      "t": 33555,
      "e": 32255,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33556,
      "e": 32256,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 33604,
      "e": 32304,
      "ty": 2,
      "x": 428,
      "y": 679
    },
    {
      "t": 33657,
      "e": 32357,
      "ty": 4,
      "x": 48826,
      "y": 46771,
      "ta": "#strategyButton"
    },
    {
      "t": 33668,
      "e": 32368,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 33670,
      "e": 32370,
      "ty": 5,
      "x": 428,
      "y": 679,
      "ta": "#strategyButton"
    },
    {
      "t": 33679,
      "e": 32379,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 33754,
      "e": 32454,
      "ty": 41,
      "x": 14463,
      "y": 37171,
      "ta": "html > body"
    },
    {
      "t": 34677,
      "e": 33377,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 35254,
      "e": 33954,
      "ty": 41,
      "x": 17012,
      "y": 36229,
      "ta": "html > body"
    },
    {
      "t": 35303,
      "e": 34003,
      "ty": 2,
      "x": 628,
      "y": 651
    },
    {
      "t": 35403,
      "e": 34103,
      "ty": 2,
      "x": 744,
      "y": 611
    },
    {
      "t": 35495,
      "e": 34195,
      "ty": 6,
      "x": 817,
      "y": 570,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35503,
      "e": 34203,
      "ty": 2,
      "x": 817,
      "y": 570
    },
    {
      "t": 35504,
      "e": 34204,
      "ty": 41,
      "x": 1946,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35603,
      "e": 34303,
      "ty": 2,
      "x": 843,
      "y": 564
    },
    {
      "t": 35704,
      "e": 34404,
      "ty": 2,
      "x": 850,
      "y": 561
    },
    {
      "t": 35730,
      "e": 34430,
      "ty": 3,
      "x": 850,
      "y": 561,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35731,
      "e": 34431,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35753,
      "e": 34453,
      "ty": 41,
      "x": 9084,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35865,
      "e": 34565,
      "ty": 4,
      "x": 9084,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35865,
      "e": 34565,
      "ty": 5,
      "x": 850,
      "y": 561,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36389,
      "e": 35089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "97"
    },
    {
      "t": 36390,
      "e": 35090,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36533,
      "e": 35233,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "105"
    },
    {
      "t": 36533,
      "e": 35233,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36565,
      "e": 35265,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 36613,
      "e": 35313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 37104,
      "e": 35804,
      "ty": 2,
      "x": 851,
      "y": 564
    },
    {
      "t": 37129,
      "e": 35829,
      "ty": 7,
      "x": 851,
      "y": 586,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 37203,
      "e": 35903,
      "ty": 2,
      "x": 851,
      "y": 632
    },
    {
      "t": 37247,
      "e": 35947,
      "ty": 6,
      "x": 851,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37253,
      "e": 35953,
      "ty": 41,
      "x": 9300,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37303,
      "e": 36003,
      "ty": 2,
      "x": 851,
      "y": 647
    },
    {
      "t": 37618,
      "e": 36318,
      "ty": 3,
      "x": 851,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37619,
      "e": 36319,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 37620,
      "e": 36320,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 37620,
      "e": 36320,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37697,
      "e": 36397,
      "ty": 4,
      "x": 9300,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37697,
      "e": 36397,
      "ty": 5,
      "x": 851,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38374,
      "e": 37074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 38486,
      "e": 37186,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 38487,
      "e": 37187,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38493,
      "e": 37193,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "T"
    },
    {
      "t": 38582,
      "e": 37282,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 38646,
      "e": 37346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "T"
    },
    {
      "t": 38678,
      "e": 37378,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "T"
    },
    {
      "t": 38766,
      "e": 37466,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 38766,
      "e": 37466,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38877,
      "e": 37577,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 38877,
      "e": 37577,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38884,
      "e": 37584,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Tai"
    },
    {
      "t": 38949,
      "e": 37649,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Tai"
    },
    {
      "t": 39054,
      "e": 37754,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "87"
    },
    {
      "t": 39054,
      "e": 37754,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39117,
      "e": 37817,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 39117,
      "e": 37817,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39196,
      "e": 37896,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 39197,
      "e": 37897,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39204,
      "e": 37904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Taiwan"
    },
    {
      "t": 39245,
      "e": 37945,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 39277,
      "e": 37977,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 40003,
      "e": 38703,
      "ty": 2,
      "x": 857,
      "y": 648
    },
    {
      "t": 40003,
      "e": 38703,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40005,
      "e": 38705,
      "ty": 41,
      "x": 10598,
      "y": 3120,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40098,
      "e": 38798,
      "ty": 7,
      "x": 905,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40103,
      "e": 38803,
      "ty": 2,
      "x": 905,
      "y": 669
    },
    {
      "t": 40131,
      "e": 38831,
      "ty": 6,
      "x": 926,
      "y": 677,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40204,
      "e": 38904,
      "ty": 2,
      "x": 943,
      "y": 683
    },
    {
      "t": 40254,
      "e": 38954,
      "ty": 41,
      "x": 28386,
      "y": 19859,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40303,
      "e": 39003,
      "ty": 2,
      "x": 969,
      "y": 703
    },
    {
      "t": 40404,
      "e": 39104,
      "ty": 2,
      "x": 975,
      "y": 705
    },
    {
      "t": 40450,
      "e": 39150,
      "ty": 3,
      "x": 975,
      "y": 705,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40451,
      "e": 39151,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Taiwan"
    },
    {
      "t": 40452,
      "e": 39152,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40453,
      "e": 39153,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40504,
      "e": 39204,
      "ty": 41,
      "x": 40756,
      "y": 57591,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40594,
      "e": 39294,
      "ty": 4,
      "x": 40756,
      "y": 57591,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40596,
      "e": 39296,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40596,
      "e": 39296,
      "ty": 5,
      "x": 975,
      "y": 705,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40597,
      "e": 39297,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 41614,
      "e": 40314,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 42404,
      "e": 41104,
      "ty": 2,
      "x": 1111,
      "y": 645
    },
    {
      "t": 42503,
      "e": 41203,
      "ty": 2,
      "x": 1466,
      "y": 287
    },
    {
      "t": 42504,
      "e": 41204,
      "ty": 41,
      "x": 50210,
      "y": 15455,
      "ta": "html > body"
    },
    {
      "t": 42604,
      "e": 41304,
      "ty": 2,
      "x": 994,
      "y": 0
    },
    {
      "t": 42703,
      "e": 41403,
      "ty": 2,
      "x": 764,
      "y": 51
    },
    {
      "t": 42753,
      "e": 41453,
      "ty": 41,
      "x": 23830,
      "y": 6924,
      "ta": "html > body"
    },
    {
      "t": 42803,
      "e": 41503,
      "ty": 2,
      "x": 700,
      "y": 153
    },
    {
      "t": 42903,
      "e": 41603,
      "ty": 2,
      "x": 780,
      "y": 194
    },
    {
      "t": 43003,
      "e": 41703,
      "ty": 2,
      "x": 811,
      "y": 231
    },
    {
      "t": 43003,
      "e": 41703,
      "ty": 41,
      "x": 27653,
      "y": 12353,
      "ta": "html > body"
    },
    {
      "t": 43103,
      "e": 41803,
      "ty": 2,
      "x": 811,
      "y": 233
    },
    {
      "t": 43254,
      "e": 41954,
      "ty": 41,
      "x": 27791,
      "y": 12630,
      "ta": "html > body"
    },
    {
      "t": 43302,
      "e": 42002,
      "ty": 6,
      "x": 827,
      "y": 242,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 43303,
      "e": 42003,
      "ty": 2,
      "x": 827,
      "y": 242
    },
    {
      "t": 43317,
      "e": 42017,
      "ty": 7,
      "x": 842,
      "y": 248,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 43403,
      "e": 42103,
      "ty": 2,
      "x": 855,
      "y": 252
    },
    {
      "t": 43504,
      "e": 42204,
      "ty": 2,
      "x": 856,
      "y": 259
    },
    {
      "t": 43504,
      "e": 42204,
      "ty": 41,
      "x": 26335,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 43604,
      "e": 42304,
      "ty": 2,
      "x": 855,
      "y": 280
    },
    {
      "t": 43703,
      "e": 42403,
      "ty": 2,
      "x": 850,
      "y": 293
    },
    {
      "t": 43754,
      "e": 42454,
      "ty": 41,
      "x": 8016,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 43804,
      "e": 42504,
      "ty": 2,
      "x": 847,
      "y": 301
    },
    {
      "t": 43904,
      "e": 42604,
      "ty": 2,
      "x": 845,
      "y": 300
    },
    {
      "t": 44004,
      "e": 42704,
      "ty": 2,
      "x": 841,
      "y": 292
    },
    {
      "t": 44004,
      "e": 42704,
      "ty": 41,
      "x": 6135,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 44052,
      "e": 42752,
      "ty": 6,
      "x": 839,
      "y": 292,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 44103,
      "e": 42803,
      "ty": 2,
      "x": 838,
      "y": 292
    },
    {
      "t": 44203,
      "e": 42903,
      "ty": 2,
      "x": 837,
      "y": 293
    },
    {
      "t": 44234,
      "e": 42934,
      "ty": 3,
      "x": 837,
      "y": 293,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 44235,
      "e": 42935,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 44254,
      "e": 42954,
      "ty": 41,
      "x": 53325,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 44393,
      "e": 43093,
      "ty": 4,
      "x": 53325,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 44394,
      "e": 43094,
      "ty": 5,
      "x": 837,
      "y": 293,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 44394,
      "e": 43094,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf",
      "v": "Mandarin or Cantonese"
    },
    {
      "t": 45203,
      "e": 43903,
      "ty": 7,
      "x": 839,
      "y": 302,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 45205,
      "e": 43905,
      "ty": 2,
      "x": 839,
      "y": 302
    },
    {
      "t": 45253,
      "e": 43953,
      "ty": 41,
      "x": 4409,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 45303,
      "e": 44003,
      "ty": 2,
      "x": 842,
      "y": 311
    },
    {
      "t": 45404,
      "e": 44104,
      "ty": 2,
      "x": 845,
      "y": 324
    },
    {
      "t": 45504,
      "e": 44204,
      "ty": 2,
      "x": 847,
      "y": 336
    },
    {
      "t": 45504,
      "e": 44204,
      "ty": 41,
      "x": 6070,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 45604,
      "e": 44304,
      "ty": 2,
      "x": 847,
      "y": 346
    },
    {
      "t": 45704,
      "e": 44404,
      "ty": 2,
      "x": 845,
      "y": 370
    },
    {
      "t": 45755,
      "e": 44455,
      "ty": 41,
      "x": 5358,
      "y": 8124,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 45804,
      "e": 44504,
      "ty": 2,
      "x": 843,
      "y": 389
    },
    {
      "t": 45905,
      "e": 44605,
      "ty": 2,
      "x": 841,
      "y": 406
    },
    {
      "t": 46004,
      "e": 44704,
      "ty": 2,
      "x": 838,
      "y": 427
    },
    {
      "t": 46005,
      "e": 44705,
      "ty": 41,
      "x": 3934,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 46104,
      "e": 44804,
      "ty": 2,
      "x": 836,
      "y": 433
    },
    {
      "t": 46204,
      "e": 44904,
      "ty": 2,
      "x": 836,
      "y": 434
    },
    {
      "t": 46255,
      "e": 44905,
      "ty": 41,
      "x": 11644,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 46304,
      "e": 44954,
      "ty": 2,
      "x": 835,
      "y": 433
    },
    {
      "t": 46404,
      "e": 45054,
      "ty": 2,
      "x": 833,
      "y": 424
    },
    {
      "t": 46489,
      "e": 45139,
      "ty": 6,
      "x": 832,
      "y": 420,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 46504,
      "e": 45154,
      "ty": 2,
      "x": 832,
      "y": 420
    },
    {
      "t": 46504,
      "e": 45154,
      "ty": 41,
      "x": 28120,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 46604,
      "e": 45254,
      "ty": 2,
      "x": 832,
      "y": 418
    },
    {
      "t": 46642,
      "e": 45292,
      "ty": 3,
      "x": 832,
      "y": 418,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 46643,
      "e": 45293,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 46643,
      "e": 45293,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 46754,
      "e": 45404,
      "ty": 41,
      "x": 28120,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 46761,
      "e": 45411,
      "ty": 4,
      "x": 28120,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 46761,
      "e": 45411,
      "ty": 5,
      "x": 832,
      "y": 418,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 46761,
      "e": 45411,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 46882,
      "e": 45532,
      "ty": 7,
      "x": 832,
      "y": 422,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 46903,
      "e": 45553,
      "ty": 2,
      "x": 832,
      "y": 430
    },
    {
      "t": 46939,
      "e": 45589,
      "ty": 6,
      "x": 830,
      "y": 442,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 46970,
      "e": 45620,
      "ty": 7,
      "x": 830,
      "y": 449,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 47004,
      "e": 45654,
      "ty": 2,
      "x": 830,
      "y": 459
    },
    {
      "t": 47004,
      "e": 45654,
      "ty": 41,
      "x": 2035,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 47037,
      "e": 45687,
      "ty": 6,
      "x": 831,
      "y": 467,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 47104,
      "e": 45754,
      "ty": 2,
      "x": 831,
      "y": 473
    },
    {
      "t": 47104,
      "e": 45754,
      "ty": 7,
      "x": 832,
      "y": 482,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 47153,
      "e": 45803,
      "ty": 6,
      "x": 838,
      "y": 527,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 47170,
      "e": 45820,
      "ty": 7,
      "x": 838,
      "y": 537,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 47204,
      "e": 45854,
      "ty": 2,
      "x": 838,
      "y": 540
    },
    {
      "t": 47253,
      "e": 45903,
      "ty": 41,
      "x": 14040,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 47303,
      "e": 45953,
      "ty": 2,
      "x": 847,
      "y": 578
    },
    {
      "t": 47403,
      "e": 46053,
      "ty": 2,
      "x": 862,
      "y": 614
    },
    {
      "t": 47504,
      "e": 46154,
      "ty": 2,
      "x": 874,
      "y": 636
    },
    {
      "t": 47504,
      "e": 46154,
      "ty": 41,
      "x": 12478,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 47604,
      "e": 46254,
      "ty": 2,
      "x": 914,
      "y": 694
    },
    {
      "t": 47704,
      "e": 46354,
      "ty": 2,
      "x": 917,
      "y": 699
    },
    {
      "t": 47754,
      "e": 46404,
      "ty": 41,
      "x": 24083,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 47803,
      "e": 46453,
      "ty": 2,
      "x": 917,
      "y": 704
    },
    {
      "t": 47904,
      "e": 46554,
      "ty": 2,
      "x": 916,
      "y": 733
    },
    {
      "t": 48004,
      "e": 46654,
      "ty": 2,
      "x": 916,
      "y": 735
    },
    {
      "t": 48005,
      "e": 46655,
      "ty": 41,
      "x": 23737,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 48305,
      "e": 46656,
      "ty": 2,
      "x": 916,
      "y": 736
    },
    {
      "t": 48504,
      "e": 46855,
      "ty": 41,
      "x": 23235,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 48504,
      "e": 46855,
      "ty": 2,
      "x": 914,
      "y": 737
    },
    {
      "t": 48604,
      "e": 46955,
      "ty": 2,
      "x": 893,
      "y": 746
    },
    {
      "t": 48704,
      "e": 47055,
      "ty": 2,
      "x": 882,
      "y": 753
    },
    {
      "t": 48754,
      "e": 47105,
      "ty": 41,
      "x": 14845,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 48804,
      "e": 47155,
      "ty": 2,
      "x": 857,
      "y": 753
    },
    {
      "t": 48904,
      "e": 47255,
      "ty": 2,
      "x": 853,
      "y": 754
    },
    {
      "t": 49004,
      "e": 47355,
      "ty": 2,
      "x": 848,
      "y": 758
    },
    {
      "t": 49004,
      "e": 47355,
      "ty": 41,
      "x": 11089,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 49104,
      "e": 47455,
      "ty": 2,
      "x": 845,
      "y": 761
    },
    {
      "t": 49204,
      "e": 47555,
      "ty": 2,
      "x": 834,
      "y": 775
    },
    {
      "t": 49222,
      "e": 47573,
      "ty": 6,
      "x": 830,
      "y": 782,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 49253,
      "e": 47604,
      "ty": 41,
      "x": 0,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 49255,
      "e": 47606,
      "ty": 7,
      "x": 824,
      "y": 792,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 49304,
      "e": 47655,
      "ty": 2,
      "x": 822,
      "y": 801
    },
    {
      "t": 49404,
      "e": 47755,
      "ty": 2,
      "x": 821,
      "y": 814
    },
    {
      "t": 49504,
      "e": 47855,
      "ty": 2,
      "x": 821,
      "y": 820
    },
    {
      "t": 49504,
      "e": 47855,
      "ty": 41,
      "x": 0,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 49704,
      "e": 48055,
      "ty": 2,
      "x": 821,
      "y": 806
    },
    {
      "t": 49755,
      "e": 48106,
      "ty": 41,
      "x": 0,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 49804,
      "e": 48155,
      "ty": 2,
      "x": 821,
      "y": 798
    },
    {
      "t": 49904,
      "e": 48255,
      "ty": 2,
      "x": 823,
      "y": 784
    },
    {
      "t": 50004,
      "e": 48355,
      "ty": 2,
      "x": 823,
      "y": 781
    },
    {
      "t": 50004,
      "e": 48355,
      "ty": 41,
      "x": 883,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 51004,
      "e": 49355,
      "ty": 2,
      "x": 824,
      "y": 783
    },
    {
      "t": 51005,
      "e": 49356,
      "ty": 41,
      "x": 1443,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 51041,
      "e": 49392,
      "ty": 6,
      "x": 826,
      "y": 785,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 51104,
      "e": 49455,
      "ty": 2,
      "x": 826,
      "y": 786
    },
    {
      "t": 51204,
      "e": 49555,
      "ty": 2,
      "x": 827,
      "y": 787
    },
    {
      "t": 51254,
      "e": 49605,
      "ty": 41,
      "x": 2914,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 51804,
      "e": 50155,
      "ty": 2,
      "x": 827,
      "y": 786
    },
    {
      "t": 51904,
      "e": 50255,
      "ty": 2,
      "x": 827,
      "y": 785
    },
    {
      "t": 52004,
      "e": 50355,
      "ty": 2,
      "x": 827,
      "y": 784
    },
    {
      "t": 52004,
      "e": 50355,
      "ty": 41,
      "x": 2914,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 52104,
      "e": 50455,
      "ty": 2,
      "x": 827,
      "y": 783
    },
    {
      "t": 52254,
      "e": 50605,
      "ty": 41,
      "x": 2914,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 52904,
      "e": 51255,
      "ty": 2,
      "x": 827,
      "y": 782
    },
    {
      "t": 52959,
      "e": 51310,
      "ty": 7,
      "x": 847,
      "y": 785,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 53004,
      "e": 51355,
      "ty": 2,
      "x": 871,
      "y": 791
    },
    {
      "t": 53005,
      "e": 51356,
      "ty": 41,
      "x": 27755,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 53104,
      "e": 51455,
      "ty": 2,
      "x": 902,
      "y": 800
    },
    {
      "t": 53204,
      "e": 51555,
      "ty": 2,
      "x": 912,
      "y": 802
    },
    {
      "t": 53254,
      "e": 51605,
      "ty": 41,
      "x": 21496,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 53604,
      "e": 51955,
      "ty": 2,
      "x": 916,
      "y": 805
    },
    {
      "t": 53704,
      "e": 52055,
      "ty": 2,
      "x": 931,
      "y": 811
    },
    {
      "t": 53754,
      "e": 52105,
      "ty": 41,
      "x": 27192,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 53805,
      "e": 52156,
      "ty": 2,
      "x": 939,
      "y": 819
    },
    {
      "t": 53904,
      "e": 52255,
      "ty": 2,
      "x": 939,
      "y": 829
    },
    {
      "t": 54005,
      "e": 52356,
      "ty": 2,
      "x": 927,
      "y": 838
    },
    {
      "t": 54005,
      "e": 52356,
      "ty": 41,
      "x": 25056,
      "y": 21064,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 54104,
      "e": 52455,
      "ty": 2,
      "x": 907,
      "y": 841
    },
    {
      "t": 54204,
      "e": 52555,
      "ty": 2,
      "x": 878,
      "y": 840
    },
    {
      "t": 54254,
      "e": 52605,
      "ty": 41,
      "x": 29294,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 54304,
      "e": 52655,
      "ty": 2,
      "x": 863,
      "y": 839
    },
    {
      "t": 54604,
      "e": 52955,
      "ty": 2,
      "x": 860,
      "y": 839
    },
    {
      "t": 54704,
      "e": 53055,
      "ty": 2,
      "x": 851,
      "y": 839
    },
    {
      "t": 54755,
      "e": 53106,
      "ty": 41,
      "x": 18021,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 54794,
      "e": 53145,
      "ty": 6,
      "x": 838,
      "y": 836,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 54804,
      "e": 53155,
      "ty": 2,
      "x": 838,
      "y": 836
    },
    {
      "t": 54874,
      "e": 53225,
      "ty": 7,
      "x": 837,
      "y": 835,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 54905,
      "e": 53256,
      "ty": 2,
      "x": 836,
      "y": 835
    },
    {
      "t": 55004,
      "e": 53355,
      "ty": 2,
      "x": 829,
      "y": 826
    },
    {
      "t": 55005,
      "e": 53356,
      "ty": 41,
      "x": 1798,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 55104,
      "e": 53455,
      "ty": 2,
      "x": 828,
      "y": 821
    },
    {
      "t": 55254,
      "e": 53605,
      "ty": 41,
      "x": 3882,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 55259,
      "e": 53606,
      "ty": 6,
      "x": 828,
      "y": 820,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 55304,
      "e": 53651,
      "ty": 2,
      "x": 828,
      "y": 820
    },
    {
      "t": 55404,
      "e": 53751,
      "ty": 2,
      "x": 828,
      "y": 818
    },
    {
      "t": 55504,
      "e": 53851,
      "ty": 2,
      "x": 828,
      "y": 817
    },
    {
      "t": 55504,
      "e": 53851,
      "ty": 41,
      "x": 7955,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 55604,
      "e": 53951,
      "ty": 2,
      "x": 828,
      "y": 815
    },
    {
      "t": 55704,
      "e": 54051,
      "ty": 2,
      "x": 828,
      "y": 814
    },
    {
      "t": 55754,
      "e": 54101,
      "ty": 41,
      "x": 7955,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 55804,
      "e": 54151,
      "ty": 2,
      "x": 828,
      "y": 811
    },
    {
      "t": 55904,
      "e": 54251,
      "ty": 2,
      "x": 828,
      "y": 809
    },
    {
      "t": 56005,
      "e": 54352,
      "ty": 41,
      "x": 7955,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 56662,
      "e": 55009,
      "ty": 7,
      "x": 828,
      "y": 806,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 56704,
      "e": 55051,
      "ty": 2,
      "x": 830,
      "y": 798
    },
    {
      "t": 56755,
      "e": 55102,
      "ty": 41,
      "x": 2510,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 56762,
      "e": 55109,
      "ty": 6,
      "x": 832,
      "y": 754,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 56779,
      "e": 55126,
      "ty": 7,
      "x": 832,
      "y": 749,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 56804,
      "e": 55151,
      "ty": 2,
      "x": 832,
      "y": 746
    },
    {
      "t": 56905,
      "e": 55252,
      "ty": 2,
      "x": 832,
      "y": 742
    },
    {
      "t": 56962,
      "e": 55309,
      "ty": 6,
      "x": 833,
      "y": 736,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 57004,
      "e": 55351,
      "ty": 2,
      "x": 833,
      "y": 734
    },
    {
      "t": 57004,
      "e": 55351,
      "ty": 41,
      "x": 33161,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 57105,
      "e": 55452,
      "ty": 2,
      "x": 834,
      "y": 728
    },
    {
      "t": 57204,
      "e": 55551,
      "ty": 2,
      "x": 834,
      "y": 727
    },
    {
      "t": 57255,
      "e": 55602,
      "ty": 41,
      "x": 38202,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 57304,
      "e": 55651,
      "ty": 2,
      "x": 834,
      "y": 725
    },
    {
      "t": 57404,
      "e": 55751,
      "ty": 2,
      "x": 835,
      "y": 725
    },
    {
      "t": 57504,
      "e": 55851,
      "ty": 41,
      "x": 43243,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 57682,
      "e": 56029,
      "ty": 7,
      "x": 835,
      "y": 722,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 57704,
      "e": 56051,
      "ty": 2,
      "x": 835,
      "y": 722
    },
    {
      "t": 57754,
      "e": 56101,
      "ty": 41,
      "x": 3222,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 57804,
      "e": 56151,
      "ty": 2,
      "x": 837,
      "y": 713
    },
    {
      "t": 57845,
      "e": 56192,
      "ty": 6,
      "x": 837,
      "y": 707,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 57904,
      "e": 56251,
      "ty": 2,
      "x": 838,
      "y": 705
    },
    {
      "t": 58004,
      "e": 56351,
      "ty": 2,
      "x": 839,
      "y": 702
    },
    {
      "t": 58005,
      "e": 56352,
      "ty": 41,
      "x": 63408,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 58074,
      "e": 56421,
      "ty": 3,
      "x": 839,
      "y": 702,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 58076,
      "e": 56423,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 58076,
      "e": 56423,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 58265,
      "e": 56612,
      "ty": 4,
      "x": 63408,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 58265,
      "e": 56612,
      "ty": 5,
      "x": 839,
      "y": 702,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 58266,
      "e": 56613,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 58402,
      "e": 56749,
      "ty": 7,
      "x": 843,
      "y": 703,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 58403,
      "e": 56750,
      "ty": 2,
      "x": 843,
      "y": 703
    },
    {
      "t": 58503,
      "e": 56850,
      "ty": 2,
      "x": 983,
      "y": 753
    },
    {
      "t": 58503,
      "e": 56850,
      "ty": 41,
      "x": 38346,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 58604,
      "e": 56951,
      "ty": 2,
      "x": 1089,
      "y": 837
    },
    {
      "t": 58704,
      "e": 57051,
      "ty": 2,
      "x": 1120,
      "y": 1006
    },
    {
      "t": 58755,
      "e": 57102,
      "ty": 41,
      "x": 37709,
      "y": 56671,
      "ta": "html > body"
    },
    {
      "t": 58804,
      "e": 57151,
      "ty": 2,
      "x": 1052,
      "y": 1053
    },
    {
      "t": 58903,
      "e": 57250,
      "ty": 2,
      "x": 981,
      "y": 1060
    },
    {
      "t": 59004,
      "e": 57351,
      "ty": 2,
      "x": 965,
      "y": 1060
    },
    {
      "t": 59004,
      "e": 57351,
      "ty": 41,
      "x": 32956,
      "y": 58277,
      "ta": "html > body"
    },
    {
      "t": 59103,
      "e": 57450,
      "ty": 2,
      "x": 957,
      "y": 1060
    },
    {
      "t": 59203,
      "e": 57550,
      "ty": 2,
      "x": 954,
      "y": 1059
    },
    {
      "t": 59253,
      "e": 57600,
      "ty": 41,
      "x": 32509,
      "y": 58111,
      "ta": "html > body"
    },
    {
      "t": 59303,
      "e": 57650,
      "ty": 2,
      "x": 949,
      "y": 1054
    },
    {
      "t": 59404,
      "e": 57751,
      "ty": 2,
      "x": 947,
      "y": 1051
    },
    {
      "t": 59503,
      "e": 57850,
      "ty": 2,
      "x": 946,
      "y": 1050
    },
    {
      "t": 59503,
      "e": 57850,
      "ty": 41,
      "x": 32302,
      "y": 57723,
      "ta": "html > body"
    },
    {
      "t": 59603,
      "e": 57950,
      "ty": 2,
      "x": 944,
      "y": 1047
    },
    {
      "t": 59753,
      "e": 58100,
      "ty": 41,
      "x": 32233,
      "y": 57557,
      "ta": "html > body"
    },
    {
      "t": 59904,
      "e": 58251,
      "ty": 2,
      "x": 943,
      "y": 1045
    },
    {
      "t": 60004,
      "e": 58351,
      "ty": 2,
      "x": 942,
      "y": 1044
    },
    {
      "t": 60004,
      "e": 58351,
      "ty": 41,
      "x": 32164,
      "y": 57391,
      "ta": "html > body"
    },
    {
      "t": 60104,
      "e": 58451,
      "ty": 2,
      "x": 941,
      "y": 1041
    },
    {
      "t": 60203,
      "e": 58550,
      "ty": 2,
      "x": 939,
      "y": 1038
    },
    {
      "t": 60210,
      "e": 58557,
      "ty": 6,
      "x": 938,
      "y": 1037,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 60253,
      "e": 58600,
      "ty": 41,
      "x": 54413,
      "y": 63549,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 60304,
      "e": 58651,
      "ty": 2,
      "x": 933,
      "y": 1035
    },
    {
      "t": 60404,
      "e": 58751,
      "ty": 2,
      "x": 929,
      "y": 1033
    },
    {
      "t": 60504,
      "e": 58851,
      "ty": 41,
      "x": 51321,
      "y": 55605,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 60603,
      "e": 58950,
      "ty": 2,
      "x": 928,
      "y": 1032
    },
    {
      "t": 60754,
      "e": 59101,
      "ty": 41,
      "x": 49259,
      "y": 51633,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 60803,
      "e": 59150,
      "ty": 2,
      "x": 925,
      "y": 1031
    },
    {
      "t": 61104,
      "e": 59451,
      "ty": 2,
      "x": 925,
      "y": 1030
    },
    {
      "t": 61254,
      "e": 59601,
      "ty": 41,
      "x": 49259,
      "y": 49647,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 61703,
      "e": 60050,
      "ty": 2,
      "x": 925,
      "y": 1029
    },
    {
      "t": 61754,
      "e": 60101,
      "ty": 41,
      "x": 48744,
      "y": 45675,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 61803,
      "e": 60150,
      "ty": 2,
      "x": 924,
      "y": 1027
    },
    {
      "t": 61904,
      "e": 60251,
      "ty": 2,
      "x": 923,
      "y": 1026
    },
    {
      "t": 62004,
      "e": 60351,
      "ty": 2,
      "x": 922,
      "y": 1025
    },
    {
      "t": 62005,
      "e": 60352,
      "ty": 41,
      "x": 47713,
      "y": 39718,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 62104,
      "e": 60451,
      "ty": 2,
      "x": 922,
      "y": 1023
    },
    {
      "t": 62204,
      "e": 60551,
      "ty": 2,
      "x": 918,
      "y": 1019
    },
    {
      "t": 62254,
      "e": 60601,
      "ty": 41,
      "x": 45136,
      "y": 25816,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 62304,
      "e": 60651,
      "ty": 2,
      "x": 914,
      "y": 1016
    },
    {
      "t": 62401,
      "e": 60748,
      "ty": 7,
      "x": 904,
      "y": 1002,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 62403,
      "e": 60750,
      "ty": 2,
      "x": 904,
      "y": 1002
    },
    {
      "t": 62503,
      "e": 60850,
      "ty": 2,
      "x": 898,
      "y": 988
    },
    {
      "t": 62503,
      "e": 60850,
      "ty": 41,
      "x": 18173,
      "y": 25745,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 62603,
      "e": 60950,
      "ty": 2,
      "x": 896,
      "y": 974
    },
    {
      "t": 62704,
      "e": 61051,
      "ty": 2,
      "x": 896,
      "y": 968
    },
    {
      "t": 62754,
      "e": 61101,
      "ty": 41,
      "x": 60327,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 63104,
      "e": 61451,
      "ty": 2,
      "x": 890,
      "y": 967
    },
    {
      "t": 63203,
      "e": 61550,
      "ty": 2,
      "x": 873,
      "y": 963
    },
    {
      "t": 63254,
      "e": 61601,
      "ty": 41,
      "x": 38486,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 63303,
      "e": 61650,
      "ty": 2,
      "x": 854,
      "y": 960
    },
    {
      "t": 63404,
      "e": 61751,
      "ty": 2,
      "x": 840,
      "y": 960
    },
    {
      "t": 63418,
      "e": 61765,
      "ty": 6,
      "x": 836,
      "y": 960,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 63503,
      "e": 61850,
      "ty": 2,
      "x": 832,
      "y": 960
    },
    {
      "t": 63504,
      "e": 61851,
      "ty": 41,
      "x": 28120,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 64330,
      "e": 62677,
      "ty": 3,
      "x": 832,
      "y": 960,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 64331,
      "e": 62678,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 64332,
      "e": 62679,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 64641,
      "e": 62988,
      "ty": 4,
      "x": 28120,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 64642,
      "e": 62989,
      "ty": 5,
      "x": 832,
      "y": 960,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 64643,
      "e": 62990,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 65850,
      "e": 64197,
      "ty": 7,
      "x": 847,
      "y": 968,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 65904,
      "e": 64251,
      "ty": 2,
      "x": 885,
      "y": 979
    },
    {
      "t": 66003,
      "e": 64350,
      "ty": 2,
      "x": 912,
      "y": 988
    },
    {
      "t": 66003,
      "e": 64350,
      "ty": 41,
      "x": 21496,
      "y": 25745,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 66104,
      "e": 64451,
      "ty": 2,
      "x": 920,
      "y": 999
    },
    {
      "t": 66169,
      "e": 64516,
      "ty": 6,
      "x": 923,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66204,
      "e": 64551,
      "ty": 2,
      "x": 923,
      "y": 1010
    },
    {
      "t": 66253,
      "e": 64600,
      "ty": 41,
      "x": 47713,
      "y": 17873,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66303,
      "e": 64650,
      "ty": 2,
      "x": 921,
      "y": 1017
    },
    {
      "t": 66403,
      "e": 64750,
      "ty": 2,
      "x": 919,
      "y": 1019
    },
    {
      "t": 66504,
      "e": 64851,
      "ty": 41,
      "x": 46167,
      "y": 27802,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66954,
      "e": 65301,
      "ty": 3,
      "x": 919,
      "y": 1019,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66955,
      "e": 65302,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 66956,
      "e": 65303,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 67186,
      "e": 65533,
      "ty": 4,
      "x": 46167,
      "y": 27802,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 67186,
      "e": 65533,
      "ty": 5,
      "x": 919,
      "y": 1019,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 67193,
      "e": 65540,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 67195,
      "e": 65542,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 67199,
      "e": 65546,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 68518,
      "e": 66865,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 69804,
      "e": 68151,
      "ty": 2,
      "x": 924,
      "y": 1023
    },
    {
      "t": 69903,
      "e": 68250,
      "ty": 2,
      "x": 932,
      "y": 1032
    },
    {
      "t": 70004,
      "e": 68351,
      "ty": 2,
      "x": 977,
      "y": 1065
    },
    {
      "t": 70004,
      "e": 68351,
      "ty": 41,
      "x": 33628,
      "y": 65002,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 70004,
      "e": 68351,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70057,
      "e": 68404,
      "ty": 6,
      "x": 983,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 70104,
      "e": 68451,
      "ty": 2,
      "x": 985,
      "y": 1075
    },
    {
      "t": 70254,
      "e": 68601,
      "ty": 41,
      "x": 41232,
      "y": 8312,
      "ta": "#start"
    },
    {
      "t": 70303,
      "e": 68650,
      "ty": 2,
      "x": 985,
      "y": 1080
    },
    {
      "t": 70403,
      "e": 68750,
      "ty": 2,
      "x": 983,
      "y": 1085
    },
    {
      "t": 70504,
      "e": 68851,
      "ty": 2,
      "x": 981,
      "y": 1090
    },
    {
      "t": 70505,
      "e": 68852,
      "ty": 41,
      "x": 39047,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 70515,
      "e": 68862,
      "ty": 3,
      "x": 981,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 70516,
      "e": 68863,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 70641,
      "e": 68988,
      "ty": 4,
      "x": 39047,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 70641,
      "e": 68988,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 70642,
      "e": 68989,
      "ty": 5,
      "x": 981,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 70643,
      "e": 68990,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 71672,
      "e": 70019,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 72845,
      "e": 71192,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 53413, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 53419, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"OZV09\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 4857, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 59366, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"OZV09\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 10074, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"hotel\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"121\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 70446, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"OZV09\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 11501, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 83029, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"OZV09\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 9666, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 93699, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"OZV09\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 39053, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 133961, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"OZV09\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4-U -04 PM-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:991,y:1072,t:1527023239195};\\\", \\\"{x:991,y:1057,t:1527023239208};\\\", \\\"{x:991,y:1031,t:1527023239226};\\\", \\\"{x:991,y:990,t:1527023239242};\\\", \\\"{x:992,y:962,t:1527023239258};\\\", \\\"{x:997,y:933,t:1527023239275};\\\", \\\"{x:1002,y:898,t:1527023239293};\\\", \\\"{x:1004,y:869,t:1527023239310};\\\", \\\"{x:1007,y:844,t:1527023239326};\\\", \\\"{x:1007,y:824,t:1527023239342};\\\", \\\"{x:1004,y:802,t:1527023239359};\\\", \\\"{x:994,y:770,t:1527023239376};\\\", \\\"{x:977,y:719,t:1527023239392};\\\", \\\"{x:951,y:673,t:1527023239409};\\\", \\\"{x:921,y:635,t:1527023239425};\\\", \\\"{x:866,y:594,t:1527023239443};\\\", \\\"{x:823,y:569,t:1527023239461};\\\", \\\"{x:771,y:550,t:1527023239474};\\\", \\\"{x:713,y:526,t:1527023239492};\\\", \\\"{x:649,y:503,t:1527023239509};\\\", \\\"{x:586,y:479,t:1527023239525};\\\", \\\"{x:537,y:461,t:1527023239542};\\\", \\\"{x:504,y:457,t:1527023239559};\\\", \\\"{x:490,y:454,t:1527023239576};\\\", \\\"{x:485,y:454,t:1527023239591};\\\", \\\"{x:484,y:454,t:1527023239608};\\\", \\\"{x:480,y:455,t:1527023239625};\\\", \\\"{x:478,y:455,t:1527023239642};\\\", \\\"{x:474,y:457,t:1527023239658};\\\", \\\"{x:472,y:459,t:1527023239676};\\\", \\\"{x:470,y:461,t:1527023239692};\\\", \\\"{x:470,y:462,t:1527023239709};\\\", \\\"{x:470,y:465,t:1527023239725};\\\", \\\"{x:470,y:471,t:1527023239743};\\\", \\\"{x:470,y:475,t:1527023239759};\\\", \\\"{x:470,y:476,t:1527023239777};\\\", \\\"{x:470,y:477,t:1527023239825};\\\", \\\"{x:470,y:478,t:1527023239842};\\\", \\\"{x:470,y:479,t:1527023239858};\\\", \\\"{x:470,y:480,t:1527023239905};\\\", \\\"{x:470,y:481,t:1527023239921};\\\", \\\"{x:470,y:482,t:1527023239945};\\\", \\\"{x:470,y:483,t:1527023239958};\\\", \\\"{x:471,y:483,t:1527023240841};\\\", \\\"{x:472,y:483,t:1527023240857};\\\", \\\"{x:473,y:483,t:1527023240865};\\\", \\\"{x:474,y:483,t:1527023240877};\\\", \\\"{x:478,y:483,t:1527023240892};\\\", \\\"{x:486,y:483,t:1527023240910};\\\", \\\"{x:503,y:486,t:1527023240927};\\\", \\\"{x:530,y:493,t:1527023240943};\\\", \\\"{x:559,y:501,t:1527023240959};\\\", \\\"{x:585,y:509,t:1527023240977};\\\", \\\"{x:619,y:518,t:1527023240993};\\\", \\\"{x:702,y:550,t:1527023241011};\\\", \\\"{x:767,y:573,t:1527023241028};\\\", \\\"{x:829,y:595,t:1527023241044};\\\", \\\"{x:895,y:622,t:1527023241060};\\\", \\\"{x:948,y:645,t:1527023241077};\\\", \\\"{x:1003,y:668,t:1527023241093};\\\", \\\"{x:1061,y:694,t:1527023241109};\\\", \\\"{x:1119,y:720,t:1527023241127};\\\", \\\"{x:1178,y:747,t:1527023241145};\\\", \\\"{x:1232,y:778,t:1527023241160};\\\", \\\"{x:1281,y:806,t:1527023241177};\\\", \\\"{x:1351,y:844,t:1527023241194};\\\", \\\"{x:1375,y:857,t:1527023241211};\\\", \\\"{x:1399,y:868,t:1527023241227};\\\", \\\"{x:1420,y:877,t:1527023241245};\\\", \\\"{x:1434,y:883,t:1527023241261};\\\", \\\"{x:1453,y:894,t:1527023241280};\\\", \\\"{x:1487,y:910,t:1527023241296};\\\", \\\"{x:1518,y:928,t:1527023241311};\\\", \\\"{x:1563,y:947,t:1527023241327};\\\", \\\"{x:1590,y:961,t:1527023241344};\\\", \\\"{x:1612,y:972,t:1527023241361};\\\", \\\"{x:1642,y:984,t:1527023241378};\\\", \\\"{x:1651,y:993,t:1527023241393};\\\", \\\"{x:1672,y:1000,t:1527023241411};\\\", \\\"{x:1685,y:1003,t:1527023241428};\\\", \\\"{x:1698,y:1005,t:1527023241444};\\\", \\\"{x:1702,y:1007,t:1527023241461};\\\", \\\"{x:1703,y:1007,t:1527023241478};\\\", \\\"{x:1705,y:1008,t:1527023241494};\\\", \\\"{x:1706,y:1008,t:1527023241511};\\\", \\\"{x:1708,y:1008,t:1527023241528};\\\", \\\"{x:1709,y:1008,t:1527023241546};\\\", \\\"{x:1710,y:1008,t:1527023241570};\\\", \\\"{x:1711,y:1008,t:1527023241594};\\\", \\\"{x:1712,y:1009,t:1527023241611};\\\", \\\"{x:1712,y:1010,t:1527023241906};\\\", \\\"{x:1711,y:1010,t:1527023242147};\\\", \\\"{x:1705,y:1010,t:1527023242163};\\\", \\\"{x:1693,y:1009,t:1527023242180};\\\", \\\"{x:1667,y:1008,t:1527023242197};\\\", \\\"{x:1636,y:1008,t:1527023242213};\\\", \\\"{x:1583,y:1015,t:1527023242229};\\\", \\\"{x:1527,y:1025,t:1527023242246};\\\", \\\"{x:1485,y:1029,t:1527023242263};\\\", \\\"{x:1453,y:1031,t:1527023242279};\\\", \\\"{x:1438,y:1034,t:1527023242296};\\\", \\\"{x:1434,y:1034,t:1527023242313};\\\", \\\"{x:1432,y:1034,t:1527023242330};\\\", \\\"{x:1431,y:1034,t:1527023242362};\\\", \\\"{x:1429,y:1034,t:1527023242378};\\\", \\\"{x:1427,y:1034,t:1527023242393};\\\", \\\"{x:1424,y:1035,t:1527023242402};\\\", \\\"{x:1422,y:1035,t:1527023242413};\\\", \\\"{x:1420,y:1035,t:1527023242430};\\\", \\\"{x:1418,y:1035,t:1527023242447};\\\", \\\"{x:1417,y:1035,t:1527023242463};\\\", \\\"{x:1416,y:1035,t:1527023242874};\\\", \\\"{x:1414,y:1036,t:1527023242882};\\\", \\\"{x:1413,y:1037,t:1527023242898};\\\", \\\"{x:1412,y:1037,t:1527023242914};\\\", \\\"{x:1411,y:1037,t:1527023242937};\\\", \\\"{x:1408,y:1037,t:1527023242953};\\\", \\\"{x:1406,y:1037,t:1527023242965};\\\", \\\"{x:1401,y:1037,t:1527023242981};\\\", \\\"{x:1397,y:1037,t:1527023242997};\\\", \\\"{x:1394,y:1037,t:1527023243015};\\\", \\\"{x:1389,y:1037,t:1527023243031};\\\", \\\"{x:1386,y:1037,t:1527023243049};\\\", \\\"{x:1382,y:1037,t:1527023243065};\\\", \\\"{x:1379,y:1037,t:1527023243082};\\\", \\\"{x:1372,y:1034,t:1527023243099};\\\", \\\"{x:1369,y:1034,t:1527023243115};\\\", \\\"{x:1366,y:1033,t:1527023243132};\\\", \\\"{x:1364,y:1032,t:1527023243149};\\\", \\\"{x:1363,y:1032,t:1527023243169};\\\", \\\"{x:1362,y:1032,t:1527023243182};\\\", \\\"{x:1358,y:1031,t:1527023243198};\\\", \\\"{x:1351,y:1028,t:1527023243215};\\\", \\\"{x:1345,y:1026,t:1527023243232};\\\", \\\"{x:1343,y:1025,t:1527023243249};\\\", \\\"{x:1341,y:1025,t:1527023243265};\\\", \\\"{x:1338,y:1024,t:1527023243281};\\\", \\\"{x:1332,y:1022,t:1527023243299};\\\", \\\"{x:1324,y:1019,t:1527023243315};\\\", \\\"{x:1317,y:1017,t:1527023243332};\\\", \\\"{x:1314,y:1016,t:1527023243348};\\\", \\\"{x:1312,y:1015,t:1527023243365};\\\", \\\"{x:1310,y:1014,t:1527023243382};\\\", \\\"{x:1306,y:1011,t:1527023243399};\\\", \\\"{x:1297,y:1006,t:1527023243417};\\\", \\\"{x:1295,y:1005,t:1527023243432};\\\", \\\"{x:1295,y:1004,t:1527023243450};\\\", \\\"{x:1294,y:1004,t:1527023243498};\\\", \\\"{x:1294,y:1003,t:1527023243522};\\\", \\\"{x:1294,y:1002,t:1527023243698};\\\", \\\"{x:1294,y:1001,t:1527023243730};\\\", \\\"{x:1291,y:997,t:1527023248675};\\\", \\\"{x:1284,y:985,t:1527023248682};\\\", \\\"{x:1273,y:970,t:1527023248695};\\\", \\\"{x:1241,y:934,t:1527023248712};\\\", \\\"{x:1199,y:895,t:1527023248729};\\\", \\\"{x:1101,y:825,t:1527023248746};\\\", \\\"{x:1000,y:767,t:1527023248762};\\\", \\\"{x:889,y:712,t:1527023248778};\\\", \\\"{x:754,y:656,t:1527023248795};\\\", \\\"{x:625,y:607,t:1527023248813};\\\", \\\"{x:509,y:573,t:1527023248828};\\\", \\\"{x:423,y:548,t:1527023248845};\\\", \\\"{x:383,y:534,t:1527023248864};\\\", \\\"{x:370,y:528,t:1527023248880};\\\", \\\"{x:369,y:528,t:1527023248899};\\\", \\\"{x:369,y:527,t:1527023249017};\\\", \\\"{x:374,y:527,t:1527023249034};\\\", \\\"{x:389,y:525,t:1527023249049};\\\", \\\"{x:411,y:524,t:1527023249066};\\\", \\\"{x:441,y:524,t:1527023249084};\\\", \\\"{x:481,y:524,t:1527023249100};\\\", \\\"{x:531,y:524,t:1527023249116};\\\", \\\"{x:584,y:524,t:1527023249132};\\\", \\\"{x:640,y:524,t:1527023249149};\\\", \\\"{x:682,y:524,t:1527023249165};\\\", \\\"{x:710,y:524,t:1527023249183};\\\", \\\"{x:740,y:524,t:1527023249201};\\\", \\\"{x:759,y:524,t:1527023249216};\\\", \\\"{x:770,y:524,t:1527023249232};\\\", \\\"{x:772,y:524,t:1527023249249};\\\", \\\"{x:775,y:524,t:1527023249379};\\\", \\\"{x:777,y:524,t:1527023249385};\\\", \\\"{x:778,y:524,t:1527023249400};\\\", \\\"{x:779,y:523,t:1527023249417};\\\", \\\"{x:780,y:523,t:1527023249433};\\\", \\\"{x:781,y:523,t:1527023249450};\\\", \\\"{x:782,y:523,t:1527023249482};\\\", \\\"{x:783,y:523,t:1527023249489};\\\", \\\"{x:784,y:523,t:1527023249500};\\\", \\\"{x:786,y:521,t:1527023249517};\\\", \\\"{x:788,y:521,t:1527023249533};\\\", \\\"{x:789,y:521,t:1527023249551};\\\", \\\"{x:790,y:521,t:1527023249567};\\\", \\\"{x:792,y:520,t:1527023249584};\\\", \\\"{x:795,y:520,t:1527023249601};\\\", \\\"{x:800,y:518,t:1527023249618};\\\", \\\"{x:802,y:517,t:1527023249633};\\\", \\\"{x:808,y:516,t:1527023249651};\\\", \\\"{x:810,y:514,t:1527023249668};\\\", \\\"{x:813,y:514,t:1527023249684};\\\", \\\"{x:814,y:514,t:1527023249700};\\\", \\\"{x:815,y:514,t:1527023249722};\\\", \\\"{x:815,y:513,t:1527023249761};\\\", \\\"{x:817,y:513,t:1527023249794};\\\", \\\"{x:818,y:513,t:1527023249906};\\\", \\\"{x:819,y:513,t:1527023249921};\\\", \\\"{x:820,y:513,t:1527023249938};\\\", \\\"{x:821,y:513,t:1527023249950};\\\", \\\"{x:824,y:515,t:1527023249968};\\\", \\\"{x:832,y:516,t:1527023249984};\\\", \\\"{x:838,y:517,t:1527023249999};\\\", \\\"{x:839,y:517,t:1527023250016};\\\", \\\"{x:839,y:518,t:1527023250317};\\\", \\\"{x:839,y:518,t:1527023250414};\\\", \\\"{x:839,y:519,t:1527023250593};\\\", \\\"{x:838,y:519,t:1527023250601};\\\", \\\"{x:834,y:520,t:1527023250617};\\\", \\\"{x:828,y:525,t:1527023250634};\\\", \\\"{x:823,y:527,t:1527023250652};\\\", \\\"{x:819,y:528,t:1527023250667};\\\", \\\"{x:816,y:532,t:1527023250684};\\\", \\\"{x:809,y:541,t:1527023250702};\\\", \\\"{x:801,y:550,t:1527023250718};\\\", \\\"{x:793,y:563,t:1527023250734};\\\", \\\"{x:786,y:574,t:1527023250751};\\\", \\\"{x:776,y:587,t:1527023250769};\\\", \\\"{x:768,y:602,t:1527023250784};\\\", \\\"{x:755,y:626,t:1527023250801};\\\", \\\"{x:745,y:638,t:1527023250818};\\\", \\\"{x:736,y:648,t:1527023250834};\\\", \\\"{x:730,y:655,t:1527023250851};\\\", \\\"{x:721,y:666,t:1527023250868};\\\", \\\"{x:714,y:675,t:1527023250884};\\\", \\\"{x:702,y:689,t:1527023250901};\\\", \\\"{x:689,y:699,t:1527023250918};\\\", \\\"{x:676,y:708,t:1527023250933};\\\", \\\"{x:665,y:716,t:1527023250951};\\\", \\\"{x:659,y:720,t:1527023250968};\\\", \\\"{x:656,y:722,t:1527023250984};\\\", \\\"{x:652,y:725,t:1527023251002};\\\", \\\"{x:650,y:725,t:1527023251017};\\\", \\\"{x:647,y:726,t:1527023251034};\\\", \\\"{x:646,y:727,t:1527023251052};\\\", \\\"{x:643,y:727,t:1527023251068};\\\", \\\"{x:640,y:728,t:1527023251084};\\\", \\\"{x:635,y:729,t:1527023251101};\\\", \\\"{x:629,y:730,t:1527023251119};\\\", \\\"{x:625,y:731,t:1527023251135};\\\", \\\"{x:620,y:731,t:1527023251151};\\\", \\\"{x:618,y:731,t:1527023251168};\\\", \\\"{x:615,y:731,t:1527023251186};\\\", \\\"{x:613,y:731,t:1527023251202};\\\", \\\"{x:608,y:731,t:1527023251218};\\\", \\\"{x:603,y:731,t:1527023251235};\\\", \\\"{x:596,y:731,t:1527023251252};\\\", \\\"{x:591,y:731,t:1527023251269};\\\", \\\"{x:589,y:731,t:1527023251285};\\\", \\\"{x:588,y:731,t:1527023251301};\\\", \\\"{x:584,y:731,t:1527023251318};\\\", \\\"{x:581,y:731,t:1527023251335};\\\", \\\"{x:570,y:731,t:1527023251351};\\\", \\\"{x:560,y:730,t:1527023251371};\\\", \\\"{x:550,y:729,t:1527023251386};\\\", \\\"{x:546,y:728,t:1527023251401};\\\", \\\"{x:545,y:727,t:1527023251425};\\\", \\\"{x:543,y:727,t:1527023251882};\\\", \\\"{x:542,y:727,t:1527023251890};\\\", \\\"{x:540,y:726,t:1527023251902};\\\", \\\"{x:537,y:725,t:1527023251919};\\\", \\\"{x:536,y:725,t:1527023251936};\\\", \\\"{x:535,y:725,t:1527023251962};\\\", \\\"{x:535,y:724,t:1527023251986};\\\", \\\"{x:533,y:724,t:1527023252002};\\\", \\\"{x:530,y:723,t:1527023252019};\\\", \\\"{x:528,y:723,t:1527023252041};\\\", \\\"{x:527,y:723,t:1527023252066};\\\", \\\"{x:526,y:723,t:1527023252105};\\\", \\\"{x:526,y:722,t:1527023258466};\\\", \\\"{x:526,y:721,t:1527023262198};\\\", \\\"{x:528,y:716,t:1527023262214};\\\", \\\"{x:534,y:708,t:1527023262230};\\\", \\\"{x:543,y:693,t:1527023262248};\\\", \\\"{x:556,y:675,t:1527023262264};\\\", \\\"{x:566,y:659,t:1527023262279};\\\", \\\"{x:577,y:638,t:1527023262297};\\\", \\\"{x:588,y:615,t:1527023262314};\\\", \\\"{x:596,y:596,t:1527023262330};\\\", \\\"{x:599,y:586,t:1527023262347};\\\", \\\"{x:600,y:577,t:1527023262364};\\\", \\\"{x:600,y:571,t:1527023262380};\\\", \\\"{x:600,y:566,t:1527023262397};\\\", \\\"{x:600,y:560,t:1527023262413};\\\", \\\"{x:600,y:555,t:1527023262429};\\\", \\\"{x:597,y:548,t:1527023262446};\\\", \\\"{x:595,y:543,t:1527023262464};\\\", \\\"{x:594,y:541,t:1527023262480};\\\", \\\"{x:594,y:540,t:1527023262497};\\\", \\\"{x:594,y:539,t:1527023262516};\\\", \\\"{x:594,y:538,t:1527023262531};\\\", \\\"{x:594,y:537,t:1527023262548};\\\", \\\"{x:594,y:536,t:1527023262564};\\\", \\\"{x:597,y:535,t:1527023262579};\\\", \\\"{x:599,y:533,t:1527023262596};\\\", \\\"{x:601,y:533,t:1527023262614};\\\", \\\"{x:604,y:532,t:1527023262632};\\\", \\\"{x:605,y:531,t:1527023262648};\\\", \\\"{x:604,y:531,t:1527023262717};\\\", \\\"{x:598,y:532,t:1527023262732};\\\", \\\"{x:574,y:536,t:1527023262747};\\\", \\\"{x:544,y:539,t:1527023262764};\\\", \\\"{x:499,y:539,t:1527023262781};\\\", \\\"{x:477,y:539,t:1527023262796};\\\", \\\"{x:466,y:539,t:1527023262814};\\\", \\\"{x:462,y:540,t:1527023262830};\\\", \\\"{x:458,y:541,t:1527023262846};\\\", \\\"{x:449,y:543,t:1527023262863};\\\", \\\"{x:434,y:543,t:1527023262880};\\\", \\\"{x:412,y:543,t:1527023262896};\\\", \\\"{x:391,y:543,t:1527023262914};\\\", \\\"{x:370,y:540,t:1527023262931};\\\", \\\"{x:343,y:537,t:1527023262948};\\\", \\\"{x:312,y:532,t:1527023262964};\\\", \\\"{x:289,y:528,t:1527023262980};\\\", \\\"{x:283,y:527,t:1527023262998};\\\", \\\"{x:282,y:527,t:1527023263014};\\\", \\\"{x:279,y:527,t:1527023263031};\\\", \\\"{x:275,y:527,t:1527023263048};\\\", \\\"{x:268,y:527,t:1527023263066};\\\", \\\"{x:259,y:527,t:1527023263080};\\\", \\\"{x:265,y:524,t:1527023263148};\\\", \\\"{x:275,y:522,t:1527023263164};\\\", \\\"{x:308,y:516,t:1527023263180};\\\", \\\"{x:327,y:516,t:1527023263198};\\\", \\\"{x:344,y:516,t:1527023263213};\\\", \\\"{x:352,y:516,t:1527023263231};\\\", \\\"{x:356,y:516,t:1527023263247};\\\", \\\"{x:358,y:515,t:1527023263264};\\\", \\\"{x:365,y:515,t:1527023263280};\\\", \\\"{x:378,y:515,t:1527023263298};\\\", \\\"{x:384,y:515,t:1527023263315};\\\", \\\"{x:386,y:515,t:1527023263330};\\\", \\\"{x:386,y:518,t:1527023264334};\\\", \\\"{x:385,y:522,t:1527023264349};\\\", \\\"{x:385,y:528,t:1527023264365};\\\", \\\"{x:385,y:533,t:1527023264383};\\\", \\\"{x:385,y:536,t:1527023264398};\\\", \\\"{x:385,y:541,t:1527023264416};\\\", \\\"{x:385,y:543,t:1527023264432};\\\", \\\"{x:385,y:546,t:1527023264450};\\\", \\\"{x:385,y:549,t:1527023264465};\\\", \\\"{x:385,y:554,t:1527023264482};\\\", \\\"{x:385,y:557,t:1527023264499};\\\", \\\"{x:385,y:558,t:1527023264515};\\\", \\\"{x:385,y:560,t:1527023264532};\\\", \\\"{x:385,y:563,t:1527023264549};\\\", \\\"{x:385,y:570,t:1527023264565};\\\", \\\"{x:385,y:579,t:1527023264583};\\\", \\\"{x:386,y:587,t:1527023264599};\\\", \\\"{x:388,y:595,t:1527023264614};\\\", \\\"{x:389,y:600,t:1527023264632};\\\", \\\"{x:390,y:607,t:1527023264649};\\\", \\\"{x:394,y:618,t:1527023264666};\\\", \\\"{x:399,y:627,t:1527023264682};\\\", \\\"{x:403,y:634,t:1527023264699};\\\", \\\"{x:406,y:641,t:1527023264714};\\\", \\\"{x:410,y:650,t:1527023264732};\\\", \\\"{x:411,y:652,t:1527023264749};\\\", \\\"{x:414,y:657,t:1527023264765};\\\", \\\"{x:417,y:662,t:1527023264781};\\\", \\\"{x:421,y:668,t:1527023264798};\\\", \\\"{x:425,y:673,t:1527023264815};\\\", \\\"{x:427,y:678,t:1527023264832};\\\", \\\"{x:430,y:683,t:1527023264849};\\\", \\\"{x:432,y:687,t:1527023264865};\\\", \\\"{x:439,y:694,t:1527023264882};\\\", \\\"{x:444,y:703,t:1527023264898};\\\", \\\"{x:451,y:711,t:1527023264916};\\\", \\\"{x:459,y:722,t:1527023264932};\\\", \\\"{x:472,y:748,t:1527023264950};\\\", \\\"{x:483,y:776,t:1527023264966};\\\", \\\"{x:501,y:813,t:1527023264981};\\\", \\\"{x:522,y:853,t:1527023264999};\\\", \\\"{x:540,y:881,t:1527023265016};\\\", \\\"{x:554,y:899,t:1527023265032};\\\", \\\"{x:563,y:911,t:1527023265049};\\\", \\\"{x:572,y:921,t:1527023265066};\\\", \\\"{x:579,y:929,t:1527023265082};\\\", \\\"{x:582,y:932,t:1527023265099};\\\", \\\"{x:587,y:936,t:1527023265116};\\\", \\\"{x:589,y:937,t:1527023265132};\\\", \\\"{x:590,y:936,t:1527023265213};\\\", \\\"{x:590,y:934,t:1527023265221};\\\", \\\"{x:590,y:933,t:1527023265235};\\\", \\\"{x:590,y:929,t:1527023265249};\\\", \\\"{x:590,y:924,t:1527023265266};\\\", \\\"{x:590,y:919,t:1527023265283};\\\", \\\"{x:590,y:916,t:1527023265299};\\\", \\\"{x:590,y:913,t:1527023265316};\\\", \\\"{x:590,y:910,t:1527023265333};\\\", \\\"{x:590,y:904,t:1527023265349};\\\", \\\"{x:590,y:891,t:1527023265367};\\\", \\\"{x:590,y:875,t:1527023265383};\\\", \\\"{x:590,y:860,t:1527023265399};\\\", \\\"{x:590,y:845,t:1527023265416};\\\", \\\"{x:590,y:838,t:1527023265433};\\\", \\\"{x:590,y:830,t:1527023265449};\\\", \\\"{x:586,y:819,t:1527023265466};\\\", \\\"{x:581,y:804,t:1527023265483};\\\", \\\"{x:573,y:787,t:1527023265499};\\\", \\\"{x:567,y:772,t:1527023265516};\\\", \\\"{x:564,y:765,t:1527023265533};\\\", \\\"{x:563,y:762,t:1527023265549};\\\", \\\"{x:561,y:760,t:1527023265566};\\\", \\\"{x:560,y:757,t:1527023265584};\\\", \\\"{x:557,y:751,t:1527023265599};\\\", \\\"{x:555,y:746,t:1527023265616};\\\", \\\"{x:551,y:737,t:1527023265633};\\\", \\\"{x:548,y:732,t:1527023265650};\\\", \\\"{x:546,y:728,t:1527023265665};\\\", \\\"{x:545,y:727,t:1527023265682};\\\", \\\"{x:544,y:727,t:1527023265972};\\\", \\\"{x:543,y:727,t:1527023265988};\\\", \\\"{x:542,y:727,t:1527023266000};\\\", \\\"{x:541,y:727,t:1527023266076};\\\", \\\"{x:541,y:726,t:1527023270974};\\\", \\\"{x:542,y:724,t:1527023274309};\\\", \\\"{x:543,y:721,t:1527023274316};\\\", \\\"{x:546,y:716,t:1527023274331};\\\", \\\"{x:553,y:707,t:1527023274348};\\\", \\\"{x:555,y:702,t:1527023274365};\\\", \\\"{x:555,y:701,t:1527023274381};\\\", \\\"{x:555,y:702,t:1527023274597};\\\", \\\"{x:554,y:703,t:1527023274620};\\\", \\\"{x:553,y:703,t:1527023274632};\\\", \\\"{x:553,y:704,t:1527023274647};\\\", \\\"{x:552,y:705,t:1527023274664};\\\", \\\"{x:550,y:706,t:1527023274684};\\\", \\\"{x:550,y:707,t:1527023274701};\\\", \\\"{x:548,y:708,t:1527023274717};\\\", \\\"{x:548,y:709,t:1527023274731};\\\", \\\"{x:546,y:710,t:1527023274749};\\\", \\\"{x:545,y:711,t:1527023274765};\\\" ] }, { \\\"rt\\\": 16324, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 151541, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"OZV09\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:548,y:718,t:1527023278413};\\\", \\\"{x:561,y:727,t:1527023278427};\\\", \\\"{x:614,y:753,t:1527023278444};\\\", \\\"{x:676,y:785,t:1527023278459};\\\", \\\"{x:760,y:820,t:1527023278475};\\\", \\\"{x:798,y:842,t:1527023278493};\\\", \\\"{x:851,y:865,t:1527023278509};\\\", \\\"{x:920,y:894,t:1527023278526};\\\", \\\"{x:1016,y:932,t:1527023278543};\\\", \\\"{x:1116,y:967,t:1527023278559};\\\", \\\"{x:1217,y:1001,t:1527023278576};\\\", \\\"{x:1322,y:1033,t:1527023278593};\\\", \\\"{x:1433,y:1062,t:1527023278610};\\\", \\\"{x:1519,y:1087,t:1527023278627};\\\", \\\"{x:1591,y:1106,t:1527023278643};\\\", \\\"{x:1680,y:1125,t:1527023278660};\\\", \\\"{x:1720,y:1126,t:1527023278676};\\\", \\\"{x:1751,y:1126,t:1527023278693};\\\", \\\"{x:1773,y:1126,t:1527023278710};\\\", \\\"{x:1779,y:1126,t:1527023278726};\\\", \\\"{x:1781,y:1126,t:1527023278743};\\\", \\\"{x:1782,y:1122,t:1527023278760};\\\", \\\"{x:1782,y:1114,t:1527023278776};\\\", \\\"{x:1778,y:1103,t:1527023278793};\\\", \\\"{x:1769,y:1092,t:1527023278811};\\\", \\\"{x:1754,y:1082,t:1527023278827};\\\", \\\"{x:1735,y:1068,t:1527023278843};\\\", \\\"{x:1705,y:1050,t:1527023278861};\\\", \\\"{x:1684,y:1042,t:1527023278877};\\\", \\\"{x:1662,y:1034,t:1527023278894};\\\", \\\"{x:1647,y:1029,t:1527023278910};\\\", \\\"{x:1631,y:1023,t:1527023278927};\\\", \\\"{x:1617,y:1021,t:1527023278943};\\\", \\\"{x:1603,y:1017,t:1527023278961};\\\", \\\"{x:1594,y:1013,t:1527023278976};\\\", \\\"{x:1590,y:1012,t:1527023278993};\\\", \\\"{x:1589,y:1012,t:1527023279011};\\\", \\\"{x:1587,y:1011,t:1527023279026};\\\", \\\"{x:1585,y:1010,t:1527023279044};\\\", \\\"{x:1580,y:1009,t:1527023279060};\\\", \\\"{x:1576,y:1009,t:1527023279078};\\\", \\\"{x:1571,y:1006,t:1527023279093};\\\", \\\"{x:1567,y:1006,t:1527023279111};\\\", \\\"{x:1565,y:1005,t:1527023279127};\\\", \\\"{x:1563,y:1005,t:1527023279143};\\\", \\\"{x:1562,y:1005,t:1527023279161};\\\", \\\"{x:1560,y:1004,t:1527023279178};\\\", \\\"{x:1558,y:1003,t:1527023279194};\\\", \\\"{x:1555,y:1002,t:1527023279211};\\\", \\\"{x:1552,y:1000,t:1527023279228};\\\", \\\"{x:1546,y:988,t:1527023279244};\\\", \\\"{x:1532,y:898,t:1527023279260};\\\", \\\"{x:1516,y:806,t:1527023279278};\\\", \\\"{x:1503,y:745,t:1527023279294};\\\", \\\"{x:1496,y:705,t:1527023279311};\\\", \\\"{x:1494,y:677,t:1527023279327};\\\", \\\"{x:1494,y:657,t:1527023279344};\\\", \\\"{x:1494,y:634,t:1527023279360};\\\", \\\"{x:1489,y:616,t:1527023279378};\\\", \\\"{x:1489,y:603,t:1527023279393};\\\", \\\"{x:1487,y:595,t:1527023279410};\\\", \\\"{x:1485,y:590,t:1527023279428};\\\", \\\"{x:1483,y:585,t:1527023279443};\\\", \\\"{x:1476,y:582,t:1527023279461};\\\", \\\"{x:1470,y:581,t:1527023279477};\\\", \\\"{x:1456,y:581,t:1527023279495};\\\", \\\"{x:1452,y:581,t:1527023279510};\\\", \\\"{x:1450,y:581,t:1527023279527};\\\", \\\"{x:1450,y:579,t:1527023279693};\\\", \\\"{x:1457,y:567,t:1527023279701};\\\", \\\"{x:1471,y:551,t:1527023279710};\\\", \\\"{x:1490,y:534,t:1527023279727};\\\", \\\"{x:1508,y:517,t:1527023279745};\\\", \\\"{x:1521,y:507,t:1527023279761};\\\", \\\"{x:1534,y:492,t:1527023279778};\\\", \\\"{x:1540,y:484,t:1527023279795};\\\", \\\"{x:1545,y:476,t:1527023279810};\\\", \\\"{x:1549,y:468,t:1527023279828};\\\", \\\"{x:1552,y:461,t:1527023279844};\\\", \\\"{x:1553,y:458,t:1527023279860};\\\", \\\"{x:1554,y:454,t:1527023279877};\\\", \\\"{x:1555,y:451,t:1527023279895};\\\", \\\"{x:1556,y:450,t:1527023279911};\\\", \\\"{x:1556,y:449,t:1527023279928};\\\", \\\"{x:1558,y:447,t:1527023279945};\\\", \\\"{x:1560,y:445,t:1527023279961};\\\", \\\"{x:1562,y:443,t:1527023279978};\\\", \\\"{x:1566,y:440,t:1527023279995};\\\", \\\"{x:1569,y:440,t:1527023280011};\\\", \\\"{x:1570,y:438,t:1527023280028};\\\", \\\"{x:1573,y:436,t:1527023280045};\\\", \\\"{x:1574,y:436,t:1527023280069};\\\", \\\"{x:1576,y:435,t:1527023280078};\\\", \\\"{x:1577,y:434,t:1527023280095};\\\", \\\"{x:1578,y:434,t:1527023280133};\\\", \\\"{x:1579,y:434,t:1527023280165};\\\", \\\"{x:1579,y:433,t:1527023280178};\\\", \\\"{x:1580,y:433,t:1527023280196};\\\", \\\"{x:1581,y:432,t:1527023280213};\\\", \\\"{x:1582,y:432,t:1527023280228};\\\", \\\"{x:1582,y:431,t:1527023280244};\\\", \\\"{x:1583,y:431,t:1527023280269};\\\", \\\"{x:1583,y:430,t:1527023280278};\\\", \\\"{x:1584,y:430,t:1527023280295};\\\", \\\"{x:1585,y:430,t:1527023280541};\\\", \\\"{x:1585,y:431,t:1527023280549};\\\", \\\"{x:1586,y:434,t:1527023280563};\\\", \\\"{x:1587,y:435,t:1527023280588};\\\", \\\"{x:1587,y:436,t:1527023280620};\\\", \\\"{x:1588,y:437,t:1527023280708};\\\", \\\"{x:1589,y:437,t:1527023280804};\\\", \\\"{x:1590,y:437,t:1527023280813};\\\", \\\"{x:1591,y:437,t:1527023280829};\\\", \\\"{x:1592,y:437,t:1527023280860};\\\", \\\"{x:1594,y:437,t:1527023280879};\\\", \\\"{x:1595,y:437,t:1527023280896};\\\", \\\"{x:1597,y:437,t:1527023280916};\\\", \\\"{x:1599,y:436,t:1527023280957};\\\", \\\"{x:1600,y:436,t:1527023280981};\\\", \\\"{x:1601,y:435,t:1527023281005};\\\", \\\"{x:1602,y:435,t:1527023281020};\\\", \\\"{x:1602,y:434,t:1527023281044};\\\", \\\"{x:1601,y:435,t:1527023288476};\\\", \\\"{x:1600,y:435,t:1527023288637};\\\", \\\"{x:1599,y:435,t:1527023288748};\\\", \\\"{x:1598,y:436,t:1527023288781};\\\", \\\"{x:1597,y:436,t:1527023288813};\\\", \\\"{x:1596,y:437,t:1527023288821};\\\", \\\"{x:1595,y:438,t:1527023288835};\\\", \\\"{x:1593,y:438,t:1527023288852};\\\", \\\"{x:1592,y:439,t:1527023288868};\\\", \\\"{x:1590,y:440,t:1527023288885};\\\", \\\"{x:1586,y:442,t:1527023288902};\\\", \\\"{x:1579,y:446,t:1527023288919};\\\", \\\"{x:1563,y:456,t:1527023288935};\\\", \\\"{x:1537,y:468,t:1527023288952};\\\", \\\"{x:1491,y:490,t:1527023288968};\\\", \\\"{x:1444,y:504,t:1527023288986};\\\", \\\"{x:1402,y:515,t:1527023289003};\\\", \\\"{x:1349,y:531,t:1527023289019};\\\", \\\"{x:1282,y:553,t:1527023289035};\\\", \\\"{x:1157,y:587,t:1527023289052};\\\", \\\"{x:1070,y:604,t:1527023289068};\\\", \\\"{x:1003,y:614,t:1527023289086};\\\", \\\"{x:944,y:622,t:1527023289102};\\\", \\\"{x:908,y:628,t:1527023289118};\\\", \\\"{x:887,y:631,t:1527023289135};\\\", \\\"{x:874,y:634,t:1527023289152};\\\", \\\"{x:860,y:637,t:1527023289168};\\\", \\\"{x:847,y:638,t:1527023289185};\\\", \\\"{x:835,y:638,t:1527023289202};\\\", \\\"{x:822,y:638,t:1527023289219};\\\", \\\"{x:814,y:638,t:1527023289235};\\\", \\\"{x:789,y:638,t:1527023289253};\\\", \\\"{x:757,y:638,t:1527023289268};\\\", \\\"{x:703,y:636,t:1527023289286};\\\", \\\"{x:661,y:630,t:1527023289301};\\\", \\\"{x:630,y:625,t:1527023289319};\\\", \\\"{x:608,y:623,t:1527023289334};\\\", \\\"{x:583,y:620,t:1527023289352};\\\", \\\"{x:538,y:616,t:1527023289369};\\\", \\\"{x:477,y:609,t:1527023289386};\\\", \\\"{x:396,y:607,t:1527023289402};\\\", \\\"{x:324,y:600,t:1527023289418};\\\", \\\"{x:201,y:586,t:1527023289436};\\\", \\\"{x:125,y:573,t:1527023289452};\\\", \\\"{x:61,y:563,t:1527023289468};\\\", \\\"{x:13,y:555,t:1527023289486};\\\", \\\"{x:0,y:553,t:1527023289502};\\\", \\\"{x:0,y:550,t:1527023289519};\\\", \\\"{x:0,y:549,t:1527023289534};\\\", \\\"{x:0,y:548,t:1527023289637};\\\", \\\"{x:0,y:546,t:1527023289677};\\\", \\\"{x:0,y:544,t:1527023289685};\\\", \\\"{x:4,y:538,t:1527023289701};\\\", \\\"{x:19,y:531,t:1527023289719};\\\", \\\"{x:40,y:523,t:1527023289735};\\\", \\\"{x:67,y:516,t:1527023289754};\\\", \\\"{x:100,y:508,t:1527023289768};\\\", \\\"{x:167,y:500,t:1527023289785};\\\", \\\"{x:261,y:500,t:1527023289802};\\\", \\\"{x:358,y:500,t:1527023289819};\\\", \\\"{x:508,y:500,t:1527023289835};\\\", \\\"{x:593,y:506,t:1527023289852};\\\", \\\"{x:653,y:510,t:1527023289869};\\\", \\\"{x:703,y:510,t:1527023289886};\\\", \\\"{x:735,y:514,t:1527023289904};\\\", \\\"{x:747,y:515,t:1527023289918};\\\", \\\"{x:748,y:515,t:1527023289936};\\\", \\\"{x:749,y:515,t:1527023289971};\\\", \\\"{x:754,y:515,t:1527023289985};\\\", \\\"{x:777,y:515,t:1527023290002};\\\", \\\"{x:801,y:516,t:1527023290018};\\\", \\\"{x:827,y:529,t:1527023290036};\\\", \\\"{x:827,y:532,t:1527023290052};\\\", \\\"{x:824,y:543,t:1527023290069};\\\", \\\"{x:813,y:558,t:1527023290086};\\\", \\\"{x:804,y:565,t:1527023290102};\\\", \\\"{x:797,y:569,t:1527023290118};\\\", \\\"{x:788,y:573,t:1527023290135};\\\", \\\"{x:771,y:578,t:1527023290153};\\\", \\\"{x:751,y:583,t:1527023290169};\\\", \\\"{x:734,y:585,t:1527023290186};\\\", \\\"{x:719,y:589,t:1527023290204};\\\", \\\"{x:699,y:593,t:1527023290220};\\\", \\\"{x:690,y:593,t:1527023290235};\\\", \\\"{x:683,y:593,t:1527023290252};\\\", \\\"{x:678,y:593,t:1527023290270};\\\", \\\"{x:673,y:593,t:1527023290285};\\\", \\\"{x:670,y:593,t:1527023290303};\\\", \\\"{x:663,y:594,t:1527023290319};\\\", \\\"{x:654,y:594,t:1527023290336};\\\", \\\"{x:641,y:594,t:1527023290353};\\\", \\\"{x:626,y:594,t:1527023290370};\\\", \\\"{x:609,y:592,t:1527023290387};\\\", \\\"{x:592,y:590,t:1527023290403};\\\", \\\"{x:573,y:587,t:1527023290419};\\\", \\\"{x:524,y:580,t:1527023290436};\\\", \\\"{x:468,y:572,t:1527023290454};\\\", \\\"{x:417,y:565,t:1527023290469};\\\", \\\"{x:392,y:561,t:1527023290486};\\\", \\\"{x:381,y:559,t:1527023290503};\\\", \\\"{x:379,y:559,t:1527023290519};\\\", \\\"{x:378,y:559,t:1527023290539};\\\", \\\"{x:377,y:559,t:1527023290621};\\\", \\\"{x:374,y:561,t:1527023290638};\\\", \\\"{x:372,y:564,t:1527023290654};\\\", \\\"{x:371,y:566,t:1527023290669};\\\", \\\"{x:371,y:569,t:1527023290685};\\\", \\\"{x:371,y:572,t:1527023290703};\\\", \\\"{x:371,y:577,t:1527023290720};\\\", \\\"{x:371,y:583,t:1527023290736};\\\", \\\"{x:371,y:589,t:1527023290753};\\\", \\\"{x:373,y:596,t:1527023290770};\\\", \\\"{x:375,y:600,t:1527023290787};\\\", \\\"{x:375,y:601,t:1527023290802};\\\", \\\"{x:376,y:603,t:1527023290820};\\\", \\\"{x:378,y:607,t:1527023290836};\\\", \\\"{x:380,y:610,t:1527023290854};\\\", \\\"{x:382,y:615,t:1527023290871};\\\", \\\"{x:383,y:616,t:1527023290887};\\\", \\\"{x:383,y:617,t:1527023290902};\\\", \\\"{x:383,y:619,t:1527023290919};\\\", \\\"{x:384,y:620,t:1527023290938};\\\", \\\"{x:384,y:621,t:1527023290963};\\\", \\\"{x:386,y:623,t:1527023290972};\\\", \\\"{x:386,y:624,t:1527023290986};\\\", \\\"{x:389,y:628,t:1527023291003};\\\", \\\"{x:391,y:632,t:1527023291019};\\\", \\\"{x:391,y:633,t:1527023291037};\\\", \\\"{x:392,y:634,t:1527023291053};\\\", \\\"{x:392,y:635,t:1527023291070};\\\", \\\"{x:392,y:636,t:1527023291197};\\\", \\\"{x:392,y:637,t:1527023291612};\\\", \\\"{x:392,y:638,t:1527023291635};\\\", \\\"{x:392,y:640,t:1527023291780};\\\", \\\"{x:392,y:644,t:1527023291787};\\\", \\\"{x:392,y:652,t:1527023291805};\\\", \\\"{x:399,y:665,t:1527023291820};\\\", \\\"{x:401,y:670,t:1527023291837};\\\", \\\"{x:405,y:677,t:1527023291854};\\\", \\\"{x:410,y:684,t:1527023291871};\\\", \\\"{x:415,y:690,t:1527023291886};\\\", \\\"{x:419,y:694,t:1527023291904};\\\", \\\"{x:423,y:698,t:1527023291920};\\\", \\\"{x:429,y:701,t:1527023291937};\\\", \\\"{x:438,y:705,t:1527023291954};\\\", \\\"{x:446,y:706,t:1527023291972};\\\", \\\"{x:454,y:706,t:1527023291987};\\\", \\\"{x:457,y:706,t:1527023292003};\\\", \\\"{x:460,y:706,t:1527023292021};\\\", \\\"{x:463,y:706,t:1527023292037};\\\", \\\"{x:466,y:706,t:1527023292053};\\\", \\\"{x:467,y:706,t:1527023292071};\\\", \\\"{x:469,y:706,t:1527023292088};\\\", \\\"{x:471,y:706,t:1527023292104};\\\", \\\"{x:472,y:706,t:1527023292121};\\\", \\\"{x:473,y:706,t:1527023292136};\\\", \\\"{x:475,y:706,t:1527023292154};\\\", \\\"{x:477,y:706,t:1527023292171};\\\", \\\"{x:479,y:706,t:1527023292187};\\\", \\\"{x:482,y:708,t:1527023292203};\\\", \\\"{x:484,y:712,t:1527023292221};\\\", \\\"{x:485,y:713,t:1527023292238};\\\", \\\"{x:486,y:714,t:1527023292254};\\\", \\\"{x:487,y:715,t:1527023292271};\\\" ] }, { \\\"rt\\\": 12983, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 165745, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"OZV09\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-G \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:487,y:716,t:1527023295085};\\\", \\\"{x:487,y:719,t:1527023295092};\\\", \\\"{x:491,y:721,t:1527023295108};\\\", \\\"{x:508,y:726,t:1527023295125};\\\", \\\"{x:526,y:729,t:1527023295141};\\\", \\\"{x:543,y:733,t:1527023295158};\\\", \\\"{x:553,y:734,t:1527023295175};\\\", \\\"{x:565,y:736,t:1527023295193};\\\", \\\"{x:575,y:739,t:1527023295207};\\\", \\\"{x:595,y:744,t:1527023295223};\\\", \\\"{x:612,y:749,t:1527023295240};\\\", \\\"{x:633,y:754,t:1527023295257};\\\", \\\"{x:658,y:761,t:1527023295273};\\\", \\\"{x:680,y:768,t:1527023295290};\\\", \\\"{x:707,y:775,t:1527023295307};\\\", \\\"{x:741,y:784,t:1527023295323};\\\", \\\"{x:822,y:808,t:1527023295339};\\\", \\\"{x:883,y:825,t:1527023295357};\\\", \\\"{x:967,y:838,t:1527023295373};\\\", \\\"{x:1073,y:854,t:1527023295391};\\\", \\\"{x:1199,y:865,t:1527023295407};\\\", \\\"{x:1318,y:865,t:1527023295423};\\\", \\\"{x:1431,y:856,t:1527023295440};\\\", \\\"{x:1524,y:832,t:1527023295458};\\\", \\\"{x:1587,y:799,t:1527023295473};\\\", \\\"{x:1665,y:742,t:1527023295490};\\\", \\\"{x:1728,y:660,t:1527023295507};\\\", \\\"{x:1782,y:559,t:1527023295523};\\\", \\\"{x:1799,y:455,t:1527023295540};\\\", \\\"{x:1779,y:406,t:1527023295557};\\\", \\\"{x:1718,y:346,t:1527023295573};\\\", \\\"{x:1603,y:285,t:1527023295590};\\\", \\\"{x:1437,y:229,t:1527023295607};\\\", \\\"{x:1240,y:194,t:1527023295623};\\\", \\\"{x:1008,y:161,t:1527023295640};\\\", \\\"{x:786,y:150,t:1527023295657};\\\", \\\"{x:601,y:148,t:1527023295673};\\\", \\\"{x:481,y:165,t:1527023295690};\\\", \\\"{x:441,y:193,t:1527023295707};\\\", \\\"{x:425,y:265,t:1527023295723};\\\", \\\"{x:426,y:360,t:1527023295740};\\\", \\\"{x:472,y:475,t:1527023295757};\\\", \\\"{x:557,y:574,t:1527023295775};\\\", \\\"{x:670,y:651,t:1527023295790};\\\", \\\"{x:812,y:731,t:1527023295807};\\\", \\\"{x:983,y:807,t:1527023295824};\\\", \\\"{x:1170,y:880,t:1527023295840};\\\", \\\"{x:1372,y:948,t:1527023295857};\\\", \\\"{x:1582,y:1006,t:1527023295874};\\\", \\\"{x:1759,y:1056,t:1527023295890};\\\", \\\"{x:1916,y:1098,t:1527023295907};\\\", \\\"{x:1919,y:1130,t:1527023295924};\\\", \\\"{x:1919,y:1142,t:1527023295940};\\\", \\\"{x:1919,y:1144,t:1527023295957};\\\", \\\"{x:1919,y:1146,t:1527023295975};\\\", \\\"{x:1919,y:1147,t:1527023296029};\\\", \\\"{x:1919,y:1148,t:1527023296041};\\\", \\\"{x:1919,y:1149,t:1527023296057};\\\", \\\"{x:1919,y:1150,t:1527023296074};\\\", \\\"{x:1917,y:1152,t:1527023296091};\\\", \\\"{x:1912,y:1153,t:1527023296107};\\\", \\\"{x:1899,y:1153,t:1527023296124};\\\", \\\"{x:1893,y:1154,t:1527023296140};\\\", \\\"{x:1889,y:1156,t:1527023296157};\\\", \\\"{x:1883,y:1156,t:1527023296174};\\\", \\\"{x:1872,y:1156,t:1527023296191};\\\", \\\"{x:1846,y:1151,t:1527023296206};\\\", \\\"{x:1823,y:1149,t:1527023296224};\\\", \\\"{x:1809,y:1146,t:1527023296241};\\\", \\\"{x:1804,y:1145,t:1527023296256};\\\", \\\"{x:1803,y:1145,t:1527023296274};\\\", \\\"{x:1802,y:1145,t:1527023296291};\\\", \\\"{x:1801,y:1145,t:1527023296307};\\\", \\\"{x:1797,y:1145,t:1527023296323};\\\", \\\"{x:1795,y:1145,t:1527023296341};\\\", \\\"{x:1793,y:1144,t:1527023296357};\\\", \\\"{x:1789,y:1142,t:1527023296374};\\\", \\\"{x:1786,y:1142,t:1527023296391};\\\", \\\"{x:1784,y:1141,t:1527023296407};\\\", \\\"{x:1782,y:1141,t:1527023296424};\\\", \\\"{x:1781,y:1141,t:1527023296441};\\\", \\\"{x:1781,y:1140,t:1527023296457};\\\", \\\"{x:1780,y:1140,t:1527023296484};\\\", \\\"{x:1779,y:1140,t:1527023296597};\\\", \\\"{x:1778,y:1139,t:1527023296612};\\\", \\\"{x:1776,y:1138,t:1527023296692};\\\", \\\"{x:1774,y:1138,t:1527023296869};\\\", \\\"{x:1773,y:1138,t:1527023296876};\\\", \\\"{x:1773,y:1137,t:1527023296891};\\\", \\\"{x:1770,y:1135,t:1527023296908};\\\", \\\"{x:1769,y:1134,t:1527023296924};\\\", \\\"{x:1767,y:1133,t:1527023296942};\\\", \\\"{x:1766,y:1131,t:1527023296958};\\\", \\\"{x:1765,y:1131,t:1527023296996};\\\", \\\"{x:1763,y:1130,t:1527023298325};\\\", \\\"{x:1760,y:1124,t:1527023298343};\\\", \\\"{x:1755,y:1116,t:1527023298359};\\\", \\\"{x:1752,y:1111,t:1527023298375};\\\", \\\"{x:1750,y:1108,t:1527023298392};\\\", \\\"{x:1749,y:1107,t:1527023298409};\\\", \\\"{x:1748,y:1106,t:1527023298436};\\\", \\\"{x:1747,y:1106,t:1527023298476};\\\", \\\"{x:1743,y:1104,t:1527023298492};\\\", \\\"{x:1741,y:1104,t:1527023298509};\\\", \\\"{x:1739,y:1104,t:1527023298526};\\\", \\\"{x:1737,y:1102,t:1527023298542};\\\", \\\"{x:1733,y:1102,t:1527023298559};\\\", \\\"{x:1729,y:1101,t:1527023298576};\\\", \\\"{x:1720,y:1098,t:1527023298592};\\\", \\\"{x:1709,y:1095,t:1527023298610};\\\", \\\"{x:1699,y:1092,t:1527023298625};\\\", \\\"{x:1689,y:1086,t:1527023298642};\\\", \\\"{x:1682,y:1081,t:1527023298660};\\\", \\\"{x:1678,y:1077,t:1527023298675};\\\", \\\"{x:1674,y:1074,t:1527023298692};\\\", \\\"{x:1672,y:1070,t:1527023298710};\\\", \\\"{x:1668,y:1065,t:1527023298726};\\\", \\\"{x:1665,y:1060,t:1527023298743};\\\", \\\"{x:1661,y:1053,t:1527023298759};\\\", \\\"{x:1656,y:1044,t:1527023298776};\\\", \\\"{x:1651,y:1030,t:1527023298793};\\\", \\\"{x:1645,y:1015,t:1527023298810};\\\", \\\"{x:1641,y:1002,t:1527023298826};\\\", \\\"{x:1637,y:990,t:1527023298842};\\\", \\\"{x:1632,y:978,t:1527023298860};\\\", \\\"{x:1631,y:973,t:1527023298875};\\\", \\\"{x:1630,y:971,t:1527023298893};\\\", \\\"{x:1630,y:969,t:1527023299101};\\\", \\\"{x:1630,y:962,t:1527023299111};\\\", \\\"{x:1634,y:944,t:1527023299126};\\\", \\\"{x:1643,y:902,t:1527023299143};\\\", \\\"{x:1651,y:843,t:1527023299159};\\\", \\\"{x:1656,y:806,t:1527023299177};\\\", \\\"{x:1656,y:785,t:1527023299192};\\\", \\\"{x:1656,y:768,t:1527023299210};\\\", \\\"{x:1656,y:761,t:1527023299227};\\\", \\\"{x:1656,y:757,t:1527023299243};\\\", \\\"{x:1656,y:756,t:1527023299259};\\\", \\\"{x:1656,y:754,t:1527023299276};\\\", \\\"{x:1654,y:752,t:1527023299524};\\\", \\\"{x:1653,y:750,t:1527023299532};\\\", \\\"{x:1651,y:747,t:1527023299543};\\\", \\\"{x:1649,y:743,t:1527023299561};\\\", \\\"{x:1645,y:730,t:1527023299577};\\\", \\\"{x:1644,y:714,t:1527023299593};\\\", \\\"{x:1640,y:696,t:1527023299610};\\\", \\\"{x:1639,y:685,t:1527023299627};\\\", \\\"{x:1636,y:671,t:1527023299643};\\\", \\\"{x:1633,y:657,t:1527023299660};\\\", \\\"{x:1623,y:636,t:1527023299676};\\\", \\\"{x:1612,y:617,t:1527023299693};\\\", \\\"{x:1604,y:605,t:1527023299710};\\\", \\\"{x:1591,y:593,t:1527023299726};\\\", \\\"{x:1579,y:586,t:1527023299743};\\\", \\\"{x:1570,y:582,t:1527023299760};\\\", \\\"{x:1565,y:579,t:1527023299777};\\\", \\\"{x:1564,y:579,t:1527023299940};\\\", \\\"{x:1562,y:579,t:1527023299948};\\\", \\\"{x:1560,y:579,t:1527023299960};\\\", \\\"{x:1555,y:580,t:1527023299976};\\\", \\\"{x:1549,y:582,t:1527023299993};\\\", \\\"{x:1548,y:582,t:1527023300009};\\\", \\\"{x:1547,y:582,t:1527023300026};\\\", \\\"{x:1546,y:583,t:1527023300083};\\\", \\\"{x:1544,y:584,t:1527023300107};\\\", \\\"{x:1542,y:585,t:1527023300116};\\\", \\\"{x:1541,y:585,t:1527023300126};\\\", \\\"{x:1539,y:586,t:1527023300143};\\\", \\\"{x:1530,y:587,t:1527023300159};\\\", \\\"{x:1522,y:587,t:1527023300176};\\\", \\\"{x:1514,y:587,t:1527023300194};\\\", \\\"{x:1499,y:591,t:1527023300209};\\\", \\\"{x:1490,y:596,t:1527023300226};\\\", \\\"{x:1482,y:599,t:1527023300243};\\\", \\\"{x:1478,y:601,t:1527023300259};\\\", \\\"{x:1463,y:613,t:1527023300276};\\\", \\\"{x:1450,y:625,t:1527023300294};\\\", \\\"{x:1441,y:635,t:1527023300310};\\\", \\\"{x:1437,y:643,t:1527023300326};\\\", \\\"{x:1434,y:647,t:1527023300344};\\\", \\\"{x:1432,y:650,t:1527023300360};\\\", \\\"{x:1430,y:654,t:1527023300376};\\\", \\\"{x:1428,y:658,t:1527023300393};\\\", \\\"{x:1426,y:660,t:1527023300410};\\\", \\\"{x:1425,y:661,t:1527023300445};\\\", \\\"{x:1424,y:661,t:1527023300484};\\\", \\\"{x:1423,y:663,t:1527023300540};\\\", \\\"{x:1423,y:664,t:1527023300564};\\\", \\\"{x:1421,y:666,t:1527023300577};\\\", \\\"{x:1420,y:667,t:1527023300593};\\\", \\\"{x:1419,y:668,t:1527023300611};\\\", \\\"{x:1416,y:671,t:1527023300627};\\\", \\\"{x:1414,y:673,t:1527023300643};\\\", \\\"{x:1409,y:677,t:1527023300660};\\\", \\\"{x:1406,y:678,t:1527023300676};\\\", \\\"{x:1401,y:682,t:1527023300694};\\\", \\\"{x:1395,y:687,t:1527023300711};\\\", \\\"{x:1389,y:691,t:1527023300727};\\\", \\\"{x:1386,y:693,t:1527023300744};\\\", \\\"{x:1386,y:694,t:1527023300760};\\\", \\\"{x:1384,y:696,t:1527023300777};\\\", \\\"{x:1382,y:698,t:1527023300794};\\\", \\\"{x:1382,y:699,t:1527023300811};\\\", \\\"{x:1381,y:700,t:1527023300827};\\\", \\\"{x:1380,y:701,t:1527023300852};\\\", \\\"{x:1380,y:702,t:1527023300860};\\\", \\\"{x:1379,y:705,t:1527023300877};\\\", \\\"{x:1379,y:708,t:1527023300893};\\\", \\\"{x:1379,y:711,t:1527023300911};\\\", \\\"{x:1379,y:717,t:1527023300927};\\\", \\\"{x:1377,y:725,t:1527023300943};\\\", \\\"{x:1376,y:729,t:1527023300961};\\\", \\\"{x:1375,y:734,t:1527023300977};\\\", \\\"{x:1375,y:737,t:1527023300993};\\\", \\\"{x:1375,y:740,t:1527023301011};\\\", \\\"{x:1373,y:743,t:1527023301026};\\\", \\\"{x:1372,y:750,t:1527023301044};\\\", \\\"{x:1369,y:760,t:1527023301060};\\\", \\\"{x:1366,y:772,t:1527023301076};\\\", \\\"{x:1362,y:781,t:1527023301093};\\\", \\\"{x:1360,y:784,t:1527023301110};\\\", \\\"{x:1358,y:788,t:1527023301128};\\\", \\\"{x:1355,y:794,t:1527023301144};\\\", \\\"{x:1354,y:798,t:1527023301161};\\\", \\\"{x:1352,y:800,t:1527023301178};\\\", \\\"{x:1352,y:802,t:1527023301193};\\\", \\\"{x:1349,y:807,t:1527023301210};\\\", \\\"{x:1343,y:814,t:1527023301228};\\\", \\\"{x:1341,y:817,t:1527023301244};\\\", \\\"{x:1334,y:823,t:1527023301261};\\\", \\\"{x:1331,y:825,t:1527023301278};\\\", \\\"{x:1331,y:826,t:1527023301294};\\\", \\\"{x:1325,y:831,t:1527023301311};\\\", \\\"{x:1320,y:834,t:1527023301328};\\\", \\\"{x:1309,y:839,t:1527023301344};\\\", \\\"{x:1301,y:841,t:1527023301360};\\\", \\\"{x:1298,y:843,t:1527023301378};\\\", \\\"{x:1297,y:843,t:1527023301396};\\\", \\\"{x:1296,y:843,t:1527023301413};\\\", \\\"{x:1294,y:844,t:1527023301428};\\\", \\\"{x:1291,y:846,t:1527023301444};\\\", \\\"{x:1288,y:847,t:1527023301461};\\\", \\\"{x:1283,y:848,t:1527023301478};\\\", \\\"{x:1280,y:848,t:1527023301494};\\\", \\\"{x:1278,y:848,t:1527023301511};\\\", \\\"{x:1277,y:848,t:1527023301532};\\\", \\\"{x:1276,y:849,t:1527023301544};\\\", \\\"{x:1271,y:850,t:1527023301561};\\\", \\\"{x:1260,y:850,t:1527023301578};\\\", \\\"{x:1248,y:850,t:1527023301594};\\\", \\\"{x:1238,y:850,t:1527023301611};\\\", \\\"{x:1234,y:850,t:1527023301628};\\\", \\\"{x:1233,y:850,t:1527023304277};\\\", \\\"{x:1231,y:850,t:1527023304284};\\\", \\\"{x:1230,y:850,t:1527023304296};\\\", \\\"{x:1217,y:849,t:1527023304312};\\\", \\\"{x:1196,y:842,t:1527023304329};\\\", \\\"{x:1171,y:826,t:1527023304345};\\\", \\\"{x:1141,y:804,t:1527023304361};\\\", \\\"{x:1101,y:773,t:1527023304379};\\\", \\\"{x:1026,y:712,t:1527023304395};\\\", \\\"{x:990,y:677,t:1527023304412};\\\", \\\"{x:966,y:640,t:1527023304429};\\\", \\\"{x:952,y:609,t:1527023304446};\\\", \\\"{x:947,y:591,t:1527023304462};\\\", \\\"{x:947,y:574,t:1527023304479};\\\", \\\"{x:947,y:555,t:1527023304496};\\\", \\\"{x:949,y:533,t:1527023304515};\\\", \\\"{x:949,y:512,t:1527023304530};\\\", \\\"{x:947,y:488,t:1527023304548};\\\", \\\"{x:943,y:482,t:1527023304564};\\\", \\\"{x:940,y:477,t:1527023304580};\\\", \\\"{x:939,y:475,t:1527023304598};\\\", \\\"{x:938,y:474,t:1527023304614};\\\", \\\"{x:932,y:474,t:1527023304632};\\\", \\\"{x:919,y:474,t:1527023304647};\\\", \\\"{x:899,y:476,t:1527023304664};\\\", \\\"{x:889,y:477,t:1527023304681};\\\", \\\"{x:885,y:478,t:1527023304697};\\\", \\\"{x:884,y:479,t:1527023304714};\\\", \\\"{x:881,y:481,t:1527023304731};\\\", \\\"{x:878,y:483,t:1527023304747};\\\", \\\"{x:866,y:494,t:1527023304764};\\\", \\\"{x:858,y:501,t:1527023304781};\\\", \\\"{x:849,y:508,t:1527023304799};\\\", \\\"{x:843,y:512,t:1527023304815};\\\", \\\"{x:843,y:513,t:1527023304835};\\\", \\\"{x:843,y:514,t:1527023304847};\\\", \\\"{x:842,y:515,t:1527023304865};\\\", \\\"{x:841,y:516,t:1527023304881};\\\", \\\"{x:839,y:518,t:1527023304898};\\\", \\\"{x:837,y:521,t:1527023304914};\\\", \\\"{x:836,y:522,t:1527023304931};\\\", \\\"{x:835,y:523,t:1527023304947};\\\", \\\"{x:834,y:524,t:1527023304971};\\\", \\\"{x:829,y:529,t:1527023305572};\\\", \\\"{x:821,y:539,t:1527023305582};\\\", \\\"{x:805,y:557,t:1527023305599};\\\", \\\"{x:786,y:575,t:1527023305616};\\\", \\\"{x:770,y:588,t:1527023305632};\\\", \\\"{x:754,y:600,t:1527023305649};\\\", \\\"{x:746,y:609,t:1527023305666};\\\", \\\"{x:734,y:624,t:1527023305682};\\\", \\\"{x:721,y:639,t:1527023305699};\\\", \\\"{x:706,y:656,t:1527023305715};\\\", \\\"{x:684,y:673,t:1527023305731};\\\", \\\"{x:674,y:681,t:1527023305749};\\\", \\\"{x:660,y:689,t:1527023305766};\\\", \\\"{x:643,y:699,t:1527023305781};\\\", \\\"{x:625,y:708,t:1527023305799};\\\", \\\"{x:617,y:713,t:1527023305816};\\\", \\\"{x:613,y:715,t:1527023305831};\\\", \\\"{x:610,y:717,t:1527023305848};\\\", \\\"{x:604,y:719,t:1527023305866};\\\", \\\"{x:592,y:722,t:1527023305881};\\\", \\\"{x:580,y:724,t:1527023305899};\\\", \\\"{x:570,y:724,t:1527023305916};\\\", \\\"{x:569,y:724,t:1527023305931};\\\", \\\"{x:568,y:724,t:1527023305948};\\\", \\\"{x:566,y:723,t:1527023305972};\\\", \\\"{x:565,y:723,t:1527023305983};\\\", \\\"{x:561,y:719,t:1527023306000};\\\", \\\"{x:557,y:715,t:1527023306016};\\\", \\\"{x:555,y:714,t:1527023306032};\\\", \\\"{x:554,y:713,t:1527023306048};\\\", \\\"{x:553,y:713,t:1527023306066};\\\", \\\"{x:551,y:713,t:1527023306083};\\\", \\\"{x:549,y:713,t:1527023306099};\\\", \\\"{x:547,y:713,t:1527023306115};\\\", \\\"{x:546,y:713,t:1527023306139};\\\", \\\"{x:545,y:713,t:1527023306180};\\\", \\\"{x:544,y:713,t:1527023306187};\\\", \\\"{x:543,y:713,t:1527023306199};\\\", \\\"{x:542,y:713,t:1527023306219};\\\", \\\"{x:541,y:713,t:1527023306260};\\\", \\\"{x:540,y:714,t:1527023306276};\\\", \\\"{x:539,y:714,t:1527023306300};\\\", \\\"{x:538,y:715,t:1527023306316};\\\", \\\"{x:537,y:715,t:1527023306333};\\\", \\\"{x:536,y:716,t:1527023306397};\\\", \\\"{x:534,y:716,t:1527023306412};\\\", \\\"{x:533,y:717,t:1527023306428};\\\", \\\"{x:532,y:717,t:1527023306444};\\\", \\\"{x:531,y:718,t:1527023307501};\\\", \\\"{x:530,y:718,t:1527023307517};\\\", \\\"{x:529,y:718,t:1527023307534};\\\", \\\"{x:528,y:718,t:1527023307556};\\\" ] }, { \\\"rt\\\": 10430, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 177473, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"OZV09\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"D\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:531,y:718,t:1527023309660};\\\", \\\"{x:534,y:718,t:1527023309670};\\\", \\\"{x:542,y:716,t:1527023309685};\\\", \\\"{x:569,y:717,t:1527023309702};\\\", \\\"{x:631,y:729,t:1527023309719};\\\", \\\"{x:727,y:749,t:1527023309736};\\\", \\\"{x:848,y:780,t:1527023309751};\\\", \\\"{x:986,y:821,t:1527023309768};\\\", \\\"{x:1121,y:858,t:1527023309784};\\\", \\\"{x:1249,y:894,t:1527023309801};\\\", \\\"{x:1357,y:924,t:1527023309819};\\\", \\\"{x:1442,y:947,t:1527023309834};\\\", \\\"{x:1521,y:971,t:1527023309851};\\\", \\\"{x:1547,y:976,t:1527023309868};\\\", \\\"{x:1560,y:978,t:1527023309885};\\\", \\\"{x:1563,y:980,t:1527023309902};\\\", \\\"{x:1564,y:980,t:1527023309956};\\\", \\\"{x:1566,y:980,t:1527023309971};\\\", \\\"{x:1567,y:980,t:1527023310029};\\\", \\\"{x:1569,y:980,t:1527023310053};\\\", \\\"{x:1570,y:980,t:1527023310100};\\\", \\\"{x:1571,y:979,t:1527023310148};\\\", \\\"{x:1573,y:978,t:1527023310380};\\\", \\\"{x:1573,y:977,t:1527023310396};\\\", \\\"{x:1574,y:977,t:1527023310420};\\\", \\\"{x:1575,y:976,t:1527023310444};\\\", \\\"{x:1577,y:975,t:1527023310484};\\\", \\\"{x:1578,y:974,t:1527023310524};\\\", \\\"{x:1579,y:974,t:1527023310572};\\\", \\\"{x:1579,y:973,t:1527023310612};\\\", \\\"{x:1580,y:973,t:1527023310644};\\\", \\\"{x:1579,y:971,t:1527023312924};\\\", \\\"{x:1574,y:968,t:1527023312938};\\\", \\\"{x:1544,y:950,t:1527023312955};\\\", \\\"{x:1470,y:916,t:1527023312971};\\\", \\\"{x:1295,y:845,t:1527023312988};\\\", \\\"{x:1144,y:790,t:1527023313004};\\\", \\\"{x:1000,y:739,t:1527023313021};\\\", \\\"{x:884,y:691,t:1527023313037};\\\", \\\"{x:817,y:670,t:1527023313054};\\\", \\\"{x:793,y:662,t:1527023313071};\\\", \\\"{x:782,y:660,t:1527023313087};\\\", \\\"{x:769,y:657,t:1527023313103};\\\", \\\"{x:756,y:654,t:1527023313120};\\\", \\\"{x:734,y:646,t:1527023313137};\\\", \\\"{x:708,y:636,t:1527023313155};\\\", \\\"{x:687,y:625,t:1527023313170};\\\", \\\"{x:674,y:618,t:1527023313188};\\\", \\\"{x:670,y:616,t:1527023313204};\\\", \\\"{x:667,y:614,t:1527023313220};\\\", \\\"{x:662,y:610,t:1527023313238};\\\", \\\"{x:659,y:607,t:1527023313254};\\\", \\\"{x:658,y:600,t:1527023313271};\\\", \\\"{x:658,y:594,t:1527023313287};\\\", \\\"{x:658,y:591,t:1527023313304};\\\", \\\"{x:666,y:584,t:1527023313322};\\\", \\\"{x:681,y:576,t:1527023313338};\\\", \\\"{x:697,y:566,t:1527023313356};\\\", \\\"{x:705,y:562,t:1527023313371};\\\", \\\"{x:705,y:561,t:1527023313403};\\\", \\\"{x:698,y:560,t:1527023313412};\\\", \\\"{x:679,y:560,t:1527023313420};\\\", \\\"{x:609,y:560,t:1527023313438};\\\", \\\"{x:499,y:560,t:1527023313456};\\\", \\\"{x:396,y:560,t:1527023313472};\\\", \\\"{x:331,y:557,t:1527023313487};\\\", \\\"{x:310,y:556,t:1527023313505};\\\", \\\"{x:308,y:556,t:1527023313522};\\\", \\\"{x:306,y:557,t:1527023313537};\\\", \\\"{x:293,y:561,t:1527023313554};\\\", \\\"{x:278,y:568,t:1527023313571};\\\", \\\"{x:272,y:571,t:1527023313590};\\\", \\\"{x:268,y:572,t:1527023313605};\\\", \\\"{x:264,y:574,t:1527023313621};\\\", \\\"{x:259,y:575,t:1527023313638};\\\", \\\"{x:247,y:579,t:1527023313655};\\\", \\\"{x:231,y:580,t:1527023313671};\\\", \\\"{x:219,y:580,t:1527023313687};\\\", \\\"{x:212,y:580,t:1527023313704};\\\", \\\"{x:207,y:580,t:1527023313721};\\\", \\\"{x:201,y:582,t:1527023313738};\\\", \\\"{x:193,y:584,t:1527023313754};\\\", \\\"{x:178,y:589,t:1527023313771};\\\", \\\"{x:177,y:589,t:1527023313788};\\\", \\\"{x:176,y:589,t:1527023313811};\\\", \\\"{x:175,y:591,t:1527023313822};\\\", \\\"{x:171,y:597,t:1527023313838};\\\", \\\"{x:168,y:600,t:1527023313855};\\\", \\\"{x:166,y:606,t:1527023313871};\\\", \\\"{x:167,y:607,t:1527023313916};\\\", \\\"{x:172,y:605,t:1527023313925};\\\", \\\"{x:181,y:601,t:1527023313938};\\\", \\\"{x:201,y:590,t:1527023313956};\\\", \\\"{x:224,y:578,t:1527023313972};\\\", \\\"{x:233,y:572,t:1527023313989};\\\", \\\"{x:240,y:565,t:1527023314005};\\\", \\\"{x:254,y:555,t:1527023314022};\\\", \\\"{x:266,y:550,t:1527023314038};\\\", \\\"{x:279,y:543,t:1527023314055};\\\", \\\"{x:290,y:539,t:1527023314071};\\\", \\\"{x:292,y:538,t:1527023314089};\\\", \\\"{x:295,y:537,t:1527023314105};\\\", \\\"{x:300,y:534,t:1527023314123};\\\", \\\"{x:309,y:530,t:1527023314139};\\\", \\\"{x:325,y:525,t:1527023314155};\\\", \\\"{x:346,y:520,t:1527023314171};\\\", \\\"{x:361,y:515,t:1527023314188};\\\", \\\"{x:378,y:510,t:1527023314206};\\\", \\\"{x:399,y:508,t:1527023314222};\\\", \\\"{x:423,y:505,t:1527023314239};\\\", \\\"{x:448,y:505,t:1527023314256};\\\", \\\"{x:472,y:505,t:1527023314271};\\\", \\\"{x:506,y:505,t:1527023314289};\\\", \\\"{x:537,y:505,t:1527023314304};\\\", \\\"{x:579,y:505,t:1527023314322};\\\", \\\"{x:611,y:505,t:1527023314338};\\\", \\\"{x:627,y:505,t:1527023314356};\\\", \\\"{x:631,y:505,t:1527023314372};\\\", \\\"{x:633,y:505,t:1527023314444};\\\", \\\"{x:634,y:506,t:1527023314457};\\\", \\\"{x:637,y:512,t:1527023314472};\\\", \\\"{x:640,y:521,t:1527023314489};\\\", \\\"{x:642,y:536,t:1527023314506};\\\", \\\"{x:642,y:548,t:1527023314522};\\\", \\\"{x:642,y:557,t:1527023314539};\\\", \\\"{x:638,y:565,t:1527023314555};\\\", \\\"{x:637,y:569,t:1527023314572};\\\", \\\"{x:634,y:576,t:1527023314589};\\\", \\\"{x:626,y:587,t:1527023314606};\\\", \\\"{x:619,y:597,t:1527023314622};\\\", \\\"{x:615,y:602,t:1527023314638};\\\", \\\"{x:613,y:604,t:1527023314655};\\\", \\\"{x:612,y:606,t:1527023314671};\\\", \\\"{x:611,y:607,t:1527023314689};\\\", \\\"{x:608,y:608,t:1527023314706};\\\", \\\"{x:600,y:612,t:1527023314723};\\\", \\\"{x:590,y:614,t:1527023314740};\\\", \\\"{x:574,y:619,t:1527023314756};\\\", \\\"{x:556,y:621,t:1527023314774};\\\", \\\"{x:535,y:626,t:1527023314789};\\\", \\\"{x:518,y:627,t:1527023314806};\\\", \\\"{x:502,y:628,t:1527023314823};\\\", \\\"{x:486,y:630,t:1527023314840};\\\", \\\"{x:471,y:630,t:1527023314856};\\\", \\\"{x:459,y:632,t:1527023314872};\\\", \\\"{x:451,y:633,t:1527023314889};\\\", \\\"{x:445,y:633,t:1527023314906};\\\", \\\"{x:437,y:633,t:1527023314923};\\\", \\\"{x:421,y:633,t:1527023314939};\\\", \\\"{x:413,y:633,t:1527023314957};\\\", \\\"{x:412,y:633,t:1527023314973};\\\", \\\"{x:411,y:633,t:1527023315107};\\\", \\\"{x:411,y:632,t:1527023315122};\\\", \\\"{x:423,y:624,t:1527023315138};\\\", \\\"{x:452,y:615,t:1527023315156};\\\", \\\"{x:475,y:614,t:1527023315173};\\\", \\\"{x:501,y:613,t:1527023315190};\\\", \\\"{x:537,y:613,t:1527023315206};\\\", \\\"{x:583,y:610,t:1527023315223};\\\", \\\"{x:648,y:609,t:1527023315239};\\\", \\\"{x:709,y:609,t:1527023315256};\\\", \\\"{x:743,y:609,t:1527023315274};\\\", \\\"{x:772,y:609,t:1527023315289};\\\", \\\"{x:790,y:607,t:1527023315306};\\\", \\\"{x:799,y:605,t:1527023315322};\\\", \\\"{x:806,y:601,t:1527023315339};\\\", \\\"{x:817,y:595,t:1527023315356};\\\", \\\"{x:834,y:589,t:1527023315373};\\\", \\\"{x:857,y:582,t:1527023315390};\\\", \\\"{x:879,y:577,t:1527023315407};\\\", \\\"{x:888,y:576,t:1527023315423};\\\", \\\"{x:889,y:576,t:1527023315439};\\\", \\\"{x:884,y:578,t:1527023315572};\\\", \\\"{x:869,y:585,t:1527023315591};\\\", \\\"{x:859,y:590,t:1527023315607};\\\", \\\"{x:851,y:593,t:1527023315623};\\\", \\\"{x:850,y:593,t:1527023315640};\\\", \\\"{x:849,y:594,t:1527023315656};\\\", \\\"{x:848,y:594,t:1527023315673};\\\", \\\"{x:847,y:594,t:1527023315707};\\\", \\\"{x:846,y:595,t:1527023315723};\\\", \\\"{x:845,y:596,t:1527023315907};\\\", \\\"{x:845,y:596,t:1527023315995};\\\", \\\"{x:840,y:598,t:1527023316019};\\\", \\\"{x:829,y:603,t:1527023316027};\\\", \\\"{x:817,y:607,t:1527023316040};\\\", \\\"{x:796,y:616,t:1527023316058};\\\", \\\"{x:780,y:624,t:1527023316073};\\\", \\\"{x:773,y:627,t:1527023316090};\\\", \\\"{x:767,y:630,t:1527023316107};\\\", \\\"{x:746,y:642,t:1527023316123};\\\", \\\"{x:714,y:656,t:1527023316140};\\\", \\\"{x:670,y:672,t:1527023316157};\\\", \\\"{x:638,y:677,t:1527023316174};\\\", \\\"{x:627,y:679,t:1527023316190};\\\", \\\"{x:623,y:680,t:1527023316206};\\\", \\\"{x:619,y:681,t:1527023316224};\\\", \\\"{x:610,y:685,t:1527023316240};\\\", \\\"{x:594,y:688,t:1527023316256};\\\", \\\"{x:577,y:693,t:1527023316273};\\\", \\\"{x:565,y:694,t:1527023316290};\\\", \\\"{x:553,y:697,t:1527023316307};\\\", \\\"{x:545,y:698,t:1527023316324};\\\", \\\"{x:543,y:700,t:1527023316340};\\\", \\\"{x:540,y:700,t:1527023316357};\\\", \\\"{x:539,y:700,t:1527023316444};\\\", \\\"{x:538,y:700,t:1527023316459};\\\", \\\"{x:543,y:700,t:1527023316524};\\\", \\\"{x:575,y:684,t:1527023316542};\\\", \\\"{x:622,y:653,t:1527023316558};\\\", \\\"{x:651,y:633,t:1527023316575};\\\", \\\"{x:670,y:623,t:1527023316591};\\\", \\\"{x:677,y:619,t:1527023316607};\\\", \\\"{x:680,y:617,t:1527023316624};\\\", \\\"{x:684,y:614,t:1527023316641};\\\", \\\"{x:691,y:610,t:1527023316657};\\\", \\\"{x:696,y:608,t:1527023316673};\\\", \\\"{x:702,y:606,t:1527023316690};\\\", \\\"{x:710,y:604,t:1527023316706};\\\", \\\"{x:723,y:601,t:1527023316723};\\\", \\\"{x:738,y:598,t:1527023316742};\\\", \\\"{x:753,y:597,t:1527023316757};\\\", \\\"{x:767,y:597,t:1527023316774};\\\", \\\"{x:783,y:597,t:1527023316791};\\\", \\\"{x:809,y:597,t:1527023316808};\\\", \\\"{x:836,y:596,t:1527023316824};\\\", \\\"{x:859,y:596,t:1527023316841};\\\", \\\"{x:872,y:596,t:1527023316857};\\\", \\\"{x:874,y:596,t:1527023316873};\\\", \\\"{x:873,y:596,t:1527023317004};\\\", \\\"{x:870,y:597,t:1527023317011};\\\", \\\"{x:867,y:598,t:1527023317024};\\\", \\\"{x:861,y:601,t:1527023317041};\\\", \\\"{x:858,y:602,t:1527023317058};\\\", \\\"{x:855,y:603,t:1527023317073};\\\", \\\"{x:853,y:605,t:1527023317091};\\\", \\\"{x:852,y:605,t:1527023317107};\\\", \\\"{x:851,y:605,t:1527023317124};\\\", \\\"{x:849,y:606,t:1527023317141};\\\", \\\"{x:848,y:606,t:1527023317157};\\\", \\\"{x:846,y:606,t:1527023317174};\\\", \\\"{x:845,y:606,t:1527023317204};\\\", \\\"{x:843,y:606,t:1527023317227};\\\", \\\"{x:842,y:606,t:1527023317241};\\\", \\\"{x:839,y:606,t:1527023317258};\\\", \\\"{x:838,y:606,t:1527023317274};\\\", \\\"{x:837,y:606,t:1527023317291};\\\", \\\"{x:836,y:606,t:1527023317323};\\\", \\\"{x:835,y:606,t:1527023317341};\\\", \\\"{x:828,y:605,t:1527023317820};\\\", \\\"{x:816,y:607,t:1527023317828};\\\", \\\"{x:796,y:611,t:1527023317841};\\\", \\\"{x:754,y:614,t:1527023317858};\\\", \\\"{x:705,y:627,t:1527023317876};\\\", \\\"{x:653,y:639,t:1527023317890};\\\", \\\"{x:640,y:642,t:1527023317908};\\\", \\\"{x:630,y:647,t:1527023317925};\\\", \\\"{x:620,y:650,t:1527023317942};\\\", \\\"{x:612,y:654,t:1527023317958};\\\", \\\"{x:610,y:655,t:1527023317974};\\\", \\\"{x:607,y:657,t:1527023317992};\\\", \\\"{x:603,y:658,t:1527023318008};\\\", \\\"{x:597,y:662,t:1527023318025};\\\", \\\"{x:590,y:665,t:1527023318041};\\\", \\\"{x:584,y:669,t:1527023318059};\\\", \\\"{x:578,y:674,t:1527023318075};\\\", \\\"{x:571,y:682,t:1527023318092};\\\", \\\"{x:560,y:690,t:1527023318109};\\\", \\\"{x:547,y:699,t:1527023318125};\\\", \\\"{x:540,y:703,t:1527023318143};\\\", \\\"{x:539,y:704,t:1527023318159};\\\", \\\"{x:538,y:704,t:1527023318175};\\\", \\\"{x:538,y:705,t:1527023318192};\\\", \\\"{x:536,y:706,t:1527023318208};\\\", \\\"{x:535,y:707,t:1527023318225};\\\", \\\"{x:532,y:708,t:1527023318242};\\\", \\\"{x:530,y:709,t:1527023318259};\\\", \\\"{x:524,y:713,t:1527023318276};\\\", \\\"{x:523,y:715,t:1527023318292};\\\", \\\"{x:522,y:716,t:1527023318308};\\\" ] }, { \\\"rt\\\": 21673, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 200486, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"OZV09\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-05 PM-I -I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:522,y:710,t:1527023321594};\\\", \\\"{x:522,y:695,t:1527023321617};\\\", \\\"{x:522,y:687,t:1527023321633};\\\", \\\"{x:522,y:681,t:1527023321649};\\\", \\\"{x:522,y:674,t:1527023321665};\\\", \\\"{x:522,y:668,t:1527023321682};\\\", \\\"{x:522,y:663,t:1527023321698};\\\", \\\"{x:522,y:661,t:1527023321715};\\\", \\\"{x:522,y:660,t:1527023321732};\\\", \\\"{x:522,y:658,t:1527023321749};\\\", \\\"{x:522,y:654,t:1527023321765};\\\", \\\"{x:522,y:651,t:1527023321782};\\\", \\\"{x:521,y:646,t:1527023321799};\\\", \\\"{x:521,y:642,t:1527023321815};\\\", \\\"{x:521,y:638,t:1527023321832};\\\", \\\"{x:518,y:630,t:1527023321849};\\\", \\\"{x:517,y:626,t:1527023321866};\\\", \\\"{x:513,y:617,t:1527023321882};\\\", \\\"{x:508,y:605,t:1527023321899};\\\", \\\"{x:502,y:592,t:1527023321916};\\\", \\\"{x:493,y:576,t:1527023321933};\\\", \\\"{x:488,y:566,t:1527023321949};\\\", \\\"{x:481,y:554,t:1527023321967};\\\", \\\"{x:477,y:547,t:1527023321983};\\\", \\\"{x:473,y:538,t:1527023321999};\\\", \\\"{x:471,y:533,t:1527023322015};\\\", \\\"{x:468,y:528,t:1527023322033};\\\", \\\"{x:464,y:523,t:1527023322049};\\\", \\\"{x:463,y:521,t:1527023322066};\\\", \\\"{x:460,y:517,t:1527023322083};\\\", \\\"{x:459,y:515,t:1527023322099};\\\", \\\"{x:455,y:508,t:1527023322115};\\\", \\\"{x:454,y:503,t:1527023322132};\\\", \\\"{x:451,y:496,t:1527023322148};\\\", \\\"{x:449,y:493,t:1527023322166};\\\", \\\"{x:447,y:488,t:1527023322182};\\\", \\\"{x:445,y:483,t:1527023322198};\\\", \\\"{x:443,y:474,t:1527023322215};\\\", \\\"{x:442,y:461,t:1527023322231};\\\", \\\"{x:442,y:449,t:1527023322248};\\\", \\\"{x:442,y:440,t:1527023322265};\\\", \\\"{x:442,y:436,t:1527023322281};\\\", \\\"{x:442,y:433,t:1527023322299};\\\", \\\"{x:443,y:432,t:1527023322315};\\\", \\\"{x:444,y:431,t:1527023322336};\\\", \\\"{x:444,y:430,t:1527023322368};\\\", \\\"{x:446,y:430,t:1527023322400};\\\", \\\"{x:447,y:430,t:1527023322601};\\\", \\\"{x:447,y:431,t:1527023322615};\\\", \\\"{x:447,y:435,t:1527023322632};\\\", \\\"{x:446,y:439,t:1527023322647};\\\", \\\"{x:442,y:445,t:1527023322664};\\\", \\\"{x:436,y:450,t:1527023322682};\\\", \\\"{x:429,y:453,t:1527023322698};\\\", \\\"{x:427,y:455,t:1527023322715};\\\", \\\"{x:426,y:455,t:1527023322736};\\\", \\\"{x:425,y:456,t:1527023322759};\\\", \\\"{x:423,y:457,t:1527023322776};\\\", \\\"{x:422,y:457,t:1527023322784};\\\", \\\"{x:421,y:458,t:1527023322797};\\\", \\\"{x:419,y:459,t:1527023322815};\\\", \\\"{x:418,y:459,t:1527023322830};\\\", \\\"{x:416,y:461,t:1527023322848};\\\", \\\"{x:415,y:462,t:1527023322864};\\\", \\\"{x:414,y:462,t:1527023322881};\\\", \\\"{x:413,y:462,t:1527023322898};\\\", \\\"{x:412,y:464,t:1527023322915};\\\", \\\"{x:410,y:465,t:1527023322931};\\\", \\\"{x:409,y:467,t:1527023322948};\\\", \\\"{x:408,y:467,t:1527023322965};\\\", \\\"{x:407,y:468,t:1527023322980};\\\", \\\"{x:406,y:470,t:1527023322998};\\\", \\\"{x:405,y:471,t:1527023323016};\\\", \\\"{x:404,y:472,t:1527023323031};\\\", \\\"{x:404,y:473,t:1527023323047};\\\", \\\"{x:403,y:475,t:1527023323064};\\\", \\\"{x:403,y:476,t:1527023323080};\\\", \\\"{x:403,y:478,t:1527023323097};\\\", \\\"{x:403,y:480,t:1527023323113};\\\", \\\"{x:403,y:481,t:1527023323131};\\\", \\\"{x:403,y:483,t:1527023323147};\\\", \\\"{x:403,y:485,t:1527023323164};\\\", \\\"{x:404,y:489,t:1527023323181};\\\", \\\"{x:405,y:490,t:1527023323197};\\\", \\\"{x:410,y:492,t:1527023323214};\\\", \\\"{x:414,y:492,t:1527023323230};\\\", \\\"{x:415,y:492,t:1527023323247};\\\", \\\"{x:417,y:492,t:1527023323263};\\\", \\\"{x:418,y:492,t:1527023323312};\\\", \\\"{x:420,y:492,t:1527023323335};\\\", \\\"{x:420,y:491,t:1527023323346};\\\", \\\"{x:421,y:491,t:1527023323376};\\\", \\\"{x:423,y:491,t:1527023323416};\\\", \\\"{x:424,y:489,t:1527023323429};\\\", \\\"{x:426,y:489,t:1527023323446};\\\", \\\"{x:427,y:488,t:1527023323463};\\\", \\\"{x:428,y:488,t:1527023323480};\\\", \\\"{x:429,y:487,t:1527023323497};\\\", \\\"{x:431,y:487,t:1527023323513};\\\", \\\"{x:432,y:486,t:1527023323530};\\\", \\\"{x:433,y:486,t:1527023323568};\\\", \\\"{x:434,y:486,t:1527023323583};\\\", \\\"{x:435,y:486,t:1527023323597};\\\", \\\"{x:438,y:484,t:1527023323612};\\\", \\\"{x:441,y:483,t:1527023323629};\\\", \\\"{x:442,y:482,t:1527023323646};\\\", \\\"{x:443,y:482,t:1527023323662};\\\", \\\"{x:444,y:482,t:1527023323687};\\\", \\\"{x:445,y:482,t:1527023323703};\\\", \\\"{x:446,y:481,t:1527023323713};\\\", \\\"{x:447,y:481,t:1527023323751};\\\", \\\"{x:448,y:481,t:1527023323762};\\\", \\\"{x:450,y:481,t:1527023323779};\\\", \\\"{x:452,y:481,t:1527023323796};\\\", \\\"{x:453,y:481,t:1527023323812};\\\", \\\"{x:455,y:481,t:1527023323828};\\\", \\\"{x:456,y:481,t:1527023323856};\\\", \\\"{x:457,y:481,t:1527023323864};\\\", \\\"{x:459,y:482,t:1527023323878};\\\", \\\"{x:463,y:483,t:1527023323895};\\\", \\\"{x:466,y:484,t:1527023323912};\\\", \\\"{x:469,y:486,t:1527023323929};\\\", \\\"{x:472,y:486,t:1527023323945};\\\", \\\"{x:473,y:486,t:1527023323962};\\\", \\\"{x:475,y:486,t:1527023323979};\\\", \\\"{x:476,y:486,t:1527023324000};\\\", \\\"{x:477,y:486,t:1527023324012};\\\", \\\"{x:479,y:487,t:1527023324029};\\\", \\\"{x:482,y:487,t:1527023324046};\\\", \\\"{x:486,y:488,t:1527023324062};\\\", \\\"{x:488,y:488,t:1527023324079};\\\", \\\"{x:499,y:489,t:1527023324096};\\\", \\\"{x:512,y:491,t:1527023324112};\\\", \\\"{x:526,y:495,t:1527023324128};\\\", \\\"{x:543,y:499,t:1527023324145};\\\", \\\"{x:567,y:506,t:1527023324162};\\\", \\\"{x:593,y:513,t:1527023324179};\\\", \\\"{x:623,y:520,t:1527023324196};\\\", \\\"{x:675,y:533,t:1527023324211};\\\", \\\"{x:737,y:552,t:1527023324228};\\\", \\\"{x:837,y:580,t:1527023324251};\\\", \\\"{x:908,y:609,t:1527023324268};\\\", \\\"{x:980,y:640,t:1527023324285};\\\", \\\"{x:1062,y:673,t:1527023324300};\\\", \\\"{x:1156,y:713,t:1527023324318};\\\", \\\"{x:1252,y:753,t:1527023324334};\\\", \\\"{x:1347,y:787,t:1527023324350};\\\", \\\"{x:1462,y:824,t:1527023324367};\\\", \\\"{x:1515,y:847,t:1527023324384};\\\", \\\"{x:1551,y:863,t:1527023324400};\\\", \\\"{x:1574,y:873,t:1527023324417};\\\", \\\"{x:1599,y:892,t:1527023324433};\\\", \\\"{x:1616,y:906,t:1527023324450};\\\", \\\"{x:1635,y:922,t:1527023324468};\\\", \\\"{x:1649,y:932,t:1527023324484};\\\", \\\"{x:1661,y:941,t:1527023324501};\\\", \\\"{x:1665,y:943,t:1527023324518};\\\", \\\"{x:1666,y:945,t:1527023324534};\\\", \\\"{x:1667,y:948,t:1527023324551};\\\", \\\"{x:1670,y:957,t:1527023324568};\\\", \\\"{x:1670,y:964,t:1527023324584};\\\", \\\"{x:1671,y:971,t:1527023324601};\\\", \\\"{x:1671,y:978,t:1527023324616};\\\", \\\"{x:1671,y:985,t:1527023324634};\\\", \\\"{x:1669,y:994,t:1527023324650};\\\", \\\"{x:1665,y:1003,t:1527023324666};\\\", \\\"{x:1661,y:1009,t:1527023324684};\\\", \\\"{x:1658,y:1014,t:1527023324701};\\\", \\\"{x:1651,y:1021,t:1527023324717};\\\", \\\"{x:1641,y:1029,t:1527023324734};\\\", \\\"{x:1627,y:1035,t:1527023324751};\\\", \\\"{x:1618,y:1037,t:1527023324767};\\\", \\\"{x:1615,y:1038,t:1527023324784};\\\", \\\"{x:1614,y:1038,t:1527023324840};\\\", \\\"{x:1612,y:1038,t:1527023324856};\\\", \\\"{x:1610,y:1038,t:1527023324866};\\\", \\\"{x:1608,y:1036,t:1527023324884};\\\", \\\"{x:1606,y:1035,t:1527023324899};\\\", \\\"{x:1605,y:1034,t:1527023324917};\\\", \\\"{x:1604,y:1034,t:1527023324933};\\\", \\\"{x:1603,y:1033,t:1527023324950};\\\", \\\"{x:1600,y:1031,t:1527023324966};\\\", \\\"{x:1597,y:1031,t:1527023324983};\\\", \\\"{x:1587,y:1030,t:1527023324999};\\\", \\\"{x:1581,y:1030,t:1527023325017};\\\", \\\"{x:1573,y:1030,t:1527023325033};\\\", \\\"{x:1558,y:1027,t:1527023325050};\\\", \\\"{x:1542,y:1027,t:1527023325066};\\\", \\\"{x:1527,y:1025,t:1527023325083};\\\", \\\"{x:1511,y:1022,t:1527023325099};\\\", \\\"{x:1499,y:1020,t:1527023325117};\\\", \\\"{x:1487,y:1020,t:1527023325133};\\\", \\\"{x:1472,y:1016,t:1527023325150};\\\", \\\"{x:1454,y:1014,t:1527023325167};\\\", \\\"{x:1437,y:1012,t:1527023325183};\\\", \\\"{x:1422,y:1009,t:1527023325199};\\\", \\\"{x:1416,y:1008,t:1527023325215};\\\", \\\"{x:1410,y:1007,t:1527023325232};\\\", \\\"{x:1402,y:1006,t:1527023325249};\\\", \\\"{x:1388,y:1004,t:1527023325265};\\\", \\\"{x:1378,y:1001,t:1527023325283};\\\", \\\"{x:1375,y:1001,t:1527023325299};\\\", \\\"{x:1374,y:1000,t:1527023325315};\\\", \\\"{x:1373,y:999,t:1527023325359};\\\", \\\"{x:1372,y:999,t:1527023325624};\\\", \\\"{x:1371,y:999,t:1527023325640};\\\", \\\"{x:1370,y:999,t:1527023325656};\\\", \\\"{x:1369,y:999,t:1527023325666};\\\", \\\"{x:1368,y:999,t:1527023325681};\\\", \\\"{x:1367,y:998,t:1527023325699};\\\", \\\"{x:1367,y:996,t:1527023325776};\\\", \\\"{x:1367,y:994,t:1527023325800};\\\", \\\"{x:1367,y:992,t:1527023325815};\\\", \\\"{x:1370,y:985,t:1527023325832};\\\", \\\"{x:1376,y:973,t:1527023325848};\\\", \\\"{x:1386,y:952,t:1527023325865};\\\", \\\"{x:1401,y:917,t:1527023325882};\\\", \\\"{x:1427,y:856,t:1527023325898};\\\", \\\"{x:1456,y:767,t:1527023325916};\\\", \\\"{x:1486,y:667,t:1527023325931};\\\", \\\"{x:1497,y:573,t:1527023325948};\\\", \\\"{x:1510,y:494,t:1527023325965};\\\", \\\"{x:1512,y:446,t:1527023325982};\\\", \\\"{x:1512,y:414,t:1527023325998};\\\", \\\"{x:1517,y:371,t:1527023326015};\\\", \\\"{x:1527,y:304,t:1527023326032};\\\", \\\"{x:1532,y:270,t:1527023326048};\\\", \\\"{x:1535,y:246,t:1527023326065};\\\", \\\"{x:1538,y:224,t:1527023326081};\\\", \\\"{x:1539,y:210,t:1527023326098};\\\", \\\"{x:1539,y:201,t:1527023326115};\\\", \\\"{x:1539,y:196,t:1527023326131};\\\", \\\"{x:1539,y:194,t:1527023326148};\\\", \\\"{x:1539,y:197,t:1527023326273};\\\", \\\"{x:1537,y:203,t:1527023326281};\\\", \\\"{x:1534,y:212,t:1527023326298};\\\", \\\"{x:1534,y:214,t:1527023326314};\\\", \\\"{x:1533,y:214,t:1527023326331};\\\", \\\"{x:1533,y:216,t:1527023326348};\\\", \\\"{x:1533,y:218,t:1527023326364};\\\", \\\"{x:1533,y:223,t:1527023326381};\\\", \\\"{x:1534,y:230,t:1527023326398};\\\", \\\"{x:1534,y:237,t:1527023326414};\\\", \\\"{x:1535,y:240,t:1527023326431};\\\", \\\"{x:1537,y:244,t:1527023326447};\\\", \\\"{x:1537,y:247,t:1527023326463};\\\", \\\"{x:1538,y:250,t:1527023326481};\\\", \\\"{x:1538,y:256,t:1527023326497};\\\", \\\"{x:1539,y:264,t:1527023326513};\\\", \\\"{x:1541,y:270,t:1527023326531};\\\", \\\"{x:1541,y:272,t:1527023326547};\\\", \\\"{x:1541,y:274,t:1527023326563};\\\", \\\"{x:1542,y:277,t:1527023326580};\\\", \\\"{x:1542,y:280,t:1527023326596};\\\", \\\"{x:1542,y:287,t:1527023326613};\\\", \\\"{x:1542,y:296,t:1527023326630};\\\", \\\"{x:1541,y:306,t:1527023326647};\\\", \\\"{x:1538,y:316,t:1527023326663};\\\", \\\"{x:1536,y:322,t:1527023326679};\\\", \\\"{x:1533,y:327,t:1527023326697};\\\", \\\"{x:1529,y:341,t:1527023326714};\\\", \\\"{x:1526,y:351,t:1527023326729};\\\", \\\"{x:1521,y:365,t:1527023326746};\\\", \\\"{x:1515,y:377,t:1527023326764};\\\", \\\"{x:1511,y:391,t:1527023326780};\\\", \\\"{x:1506,y:401,t:1527023326797};\\\", \\\"{x:1502,y:410,t:1527023326813};\\\", \\\"{x:1498,y:420,t:1527023326830};\\\", \\\"{x:1496,y:428,t:1527023326847};\\\", \\\"{x:1492,y:438,t:1527023326863};\\\", \\\"{x:1483,y:458,t:1527023326880};\\\", \\\"{x:1477,y:473,t:1527023326897};\\\", \\\"{x:1473,y:484,t:1527023326912};\\\", \\\"{x:1471,y:494,t:1527023326930};\\\", \\\"{x:1467,y:508,t:1527023326947};\\\", \\\"{x:1464,y:520,t:1527023326962};\\\", \\\"{x:1463,y:530,t:1527023326980};\\\", \\\"{x:1462,y:536,t:1527023326996};\\\", \\\"{x:1461,y:543,t:1527023327012};\\\", \\\"{x:1460,y:550,t:1527023327030};\\\", \\\"{x:1458,y:560,t:1527023327046};\\\", \\\"{x:1454,y:569,t:1527023327062};\\\", \\\"{x:1449,y:584,t:1527023327080};\\\", \\\"{x:1446,y:597,t:1527023327095};\\\", \\\"{x:1443,y:609,t:1527023327113};\\\", \\\"{x:1440,y:623,t:1527023327129};\\\", \\\"{x:1438,y:633,t:1527023327146};\\\", \\\"{x:1437,y:647,t:1527023327163};\\\", \\\"{x:1433,y:664,t:1527023327179};\\\", \\\"{x:1429,y:686,t:1527023327195};\\\", \\\"{x:1427,y:708,t:1527023327213};\\\", \\\"{x:1426,y:726,t:1527023327229};\\\", \\\"{x:1426,y:740,t:1527023327245};\\\", \\\"{x:1426,y:754,t:1527023327263};\\\", \\\"{x:1426,y:769,t:1527023327279};\\\", \\\"{x:1437,y:793,t:1527023327295};\\\", \\\"{x:1445,y:813,t:1527023327312};\\\", \\\"{x:1450,y:825,t:1527023327329};\\\", \\\"{x:1453,y:835,t:1527023327346};\\\", \\\"{x:1457,y:842,t:1527023327361};\\\", \\\"{x:1459,y:844,t:1527023327379};\\\", \\\"{x:1464,y:848,t:1527023327396};\\\", \\\"{x:1469,y:851,t:1527023327412};\\\", \\\"{x:1480,y:859,t:1527023327429};\\\", \\\"{x:1495,y:863,t:1527023327446};\\\", \\\"{x:1510,y:866,t:1527023327461};\\\", \\\"{x:1530,y:868,t:1527023327479};\\\", \\\"{x:1560,y:868,t:1527023327496};\\\", \\\"{x:1576,y:868,t:1527023327512};\\\", \\\"{x:1589,y:864,t:1527023327529};\\\", \\\"{x:1595,y:862,t:1527023327545};\\\", \\\"{x:1600,y:859,t:1527023327562};\\\", \\\"{x:1605,y:855,t:1527023327579};\\\", \\\"{x:1608,y:853,t:1527023327595};\\\", \\\"{x:1611,y:850,t:1527023327612};\\\", \\\"{x:1613,y:848,t:1527023327629};\\\", \\\"{x:1617,y:837,t:1527023327645};\\\", \\\"{x:1618,y:817,t:1527023327662};\\\", \\\"{x:1617,y:796,t:1527023327679};\\\", \\\"{x:1612,y:772,t:1527023327695};\\\", \\\"{x:1599,y:733,t:1527023327711};\\\", \\\"{x:1595,y:717,t:1527023327729};\\\", \\\"{x:1587,y:696,t:1527023327745};\\\", \\\"{x:1575,y:670,t:1527023327762};\\\", \\\"{x:1550,y:635,t:1527023327778};\\\", \\\"{x:1526,y:616,t:1527023327794};\\\", \\\"{x:1497,y:604,t:1527023327812};\\\", \\\"{x:1474,y:595,t:1527023327828};\\\", \\\"{x:1462,y:589,t:1527023327845};\\\", \\\"{x:1452,y:581,t:1527023327861};\\\", \\\"{x:1444,y:574,t:1527023327878};\\\", \\\"{x:1425,y:561,t:1527023327895};\\\", \\\"{x:1401,y:555,t:1527023327911};\\\", \\\"{x:1362,y:551,t:1527023327927};\\\", \\\"{x:1341,y:549,t:1527023327945};\\\", \\\"{x:1333,y:549,t:1527023327961};\\\", \\\"{x:1331,y:549,t:1527023327977};\\\", \\\"{x:1330,y:548,t:1527023328039};\\\", \\\"{x:1329,y:547,t:1527023328047};\\\", \\\"{x:1327,y:545,t:1527023328061};\\\", \\\"{x:1324,y:541,t:1527023328077};\\\", \\\"{x:1322,y:537,t:1527023328094};\\\", \\\"{x:1318,y:530,t:1527023328111};\\\", \\\"{x:1315,y:523,t:1527023328127};\\\", \\\"{x:1313,y:517,t:1527023328144};\\\", \\\"{x:1310,y:512,t:1527023328161};\\\", \\\"{x:1309,y:508,t:1527023328177};\\\", \\\"{x:1307,y:506,t:1527023328194};\\\", \\\"{x:1307,y:505,t:1527023328210};\\\", \\\"{x:1307,y:503,t:1527023328227};\\\", \\\"{x:1306,y:500,t:1527023328244};\\\", \\\"{x:1306,y:499,t:1527023328260};\\\", \\\"{x:1305,y:497,t:1527023328276};\\\", \\\"{x:1305,y:496,t:1527023328293};\\\", \\\"{x:1304,y:497,t:1527023328769};\\\", \\\"{x:1303,y:498,t:1527023329232};\\\", \\\"{x:1302,y:498,t:1527023329256};\\\", \\\"{x:1301,y:499,t:1527023329288};\\\", \\\"{x:1301,y:500,t:1527023329393};\\\", \\\"{x:1302,y:500,t:1527023331864};\\\", \\\"{x:1304,y:500,t:1527023331896};\\\", \\\"{x:1305,y:500,t:1527023331928};\\\", \\\"{x:1305,y:499,t:1527023331968};\\\", \\\"{x:1306,y:499,t:1527023332016};\\\", \\\"{x:1307,y:498,t:1527023332048};\\\", \\\"{x:1308,y:497,t:1527023332112};\\\", \\\"{x:1309,y:497,t:1527023332131};\\\", \\\"{x:1310,y:496,t:1527023332159};\\\", \\\"{x:1311,y:496,t:1527023332191};\\\", \\\"{x:1313,y:495,t:1527023332368};\\\", \\\"{x:1313,y:494,t:1527023332384};\\\", \\\"{x:1314,y:494,t:1527023332391};\\\", \\\"{x:1314,y:493,t:1527023332496};\\\", \\\"{x:1316,y:493,t:1527023332512};\\\", \\\"{x:1317,y:493,t:1527023332519};\\\", \\\"{x:1318,y:492,t:1527023332536};\\\", \\\"{x:1319,y:492,t:1527023332555};\\\", \\\"{x:1319,y:491,t:1527023332575};\\\", \\\"{x:1320,y:491,t:1527023333007};\\\", \\\"{x:1318,y:491,t:1527023338343};\\\", \\\"{x:1314,y:491,t:1527023338359};\\\", \\\"{x:1307,y:494,t:1527023338377};\\\", \\\"{x:1302,y:496,t:1527023338392};\\\", \\\"{x:1295,y:500,t:1527023338409};\\\", \\\"{x:1286,y:504,t:1527023338426};\\\", \\\"{x:1267,y:512,t:1527023338442};\\\", \\\"{x:1249,y:520,t:1527023338459};\\\", \\\"{x:1201,y:542,t:1527023338476};\\\", \\\"{x:1160,y:558,t:1527023338492};\\\", \\\"{x:1112,y:573,t:1527023338509};\\\", \\\"{x:1074,y:587,t:1527023338525};\\\", \\\"{x:1050,y:599,t:1527023338542};\\\", \\\"{x:1018,y:618,t:1527023338559};\\\", \\\"{x:996,y:634,t:1527023338575};\\\", \\\"{x:975,y:651,t:1527023338592};\\\", \\\"{x:956,y:662,t:1527023338609};\\\", \\\"{x:939,y:672,t:1527023338625};\\\", \\\"{x:930,y:678,t:1527023338642};\\\", \\\"{x:922,y:683,t:1527023338659};\\\", \\\"{x:913,y:687,t:1527023338675};\\\", \\\"{x:898,y:692,t:1527023338692};\\\", \\\"{x:881,y:698,t:1527023338708};\\\", \\\"{x:864,y:703,t:1527023338725};\\\", \\\"{x:843,y:708,t:1527023338742};\\\", \\\"{x:828,y:708,t:1527023338758};\\\", \\\"{x:815,y:709,t:1527023338775};\\\", \\\"{x:802,y:709,t:1527023338791};\\\", \\\"{x:785,y:709,t:1527023338808};\\\", \\\"{x:763,y:709,t:1527023338825};\\\", \\\"{x:739,y:704,t:1527023338843};\\\", \\\"{x:715,y:693,t:1527023338858};\\\", \\\"{x:700,y:687,t:1527023338875};\\\", \\\"{x:683,y:679,t:1527023338891};\\\", \\\"{x:666,y:672,t:1527023338908};\\\", \\\"{x:648,y:663,t:1527023338926};\\\", \\\"{x:624,y:654,t:1527023338941};\\\", \\\"{x:601,y:644,t:1527023338958};\\\", \\\"{x:548,y:622,t:1527023338976};\\\", \\\"{x:524,y:611,t:1527023338993};\\\", \\\"{x:512,y:604,t:1527023339009};\\\", \\\"{x:507,y:600,t:1527023339026};\\\", \\\"{x:504,y:598,t:1527023339043};\\\", \\\"{x:502,y:597,t:1527023339060};\\\", \\\"{x:497,y:597,t:1527023339077};\\\", \\\"{x:490,y:596,t:1527023339093};\\\", \\\"{x:473,y:594,t:1527023339114};\\\", \\\"{x:467,y:591,t:1527023339130};\\\", \\\"{x:463,y:590,t:1527023339146};\\\", \\\"{x:462,y:590,t:1527023339163};\\\", \\\"{x:460,y:590,t:1527023339179};\\\", \\\"{x:447,y:591,t:1527023339196};\\\", \\\"{x:428,y:592,t:1527023339213};\\\", \\\"{x:402,y:592,t:1527023339230};\\\", \\\"{x:379,y:590,t:1527023339246};\\\", \\\"{x:349,y:585,t:1527023339264};\\\", \\\"{x:319,y:581,t:1527023339280};\\\", \\\"{x:265,y:573,t:1527023339298};\\\", \\\"{x:206,y:563,t:1527023339313};\\\", \\\"{x:157,y:552,t:1527023339331};\\\", \\\"{x:126,y:543,t:1527023339347};\\\", \\\"{x:114,y:541,t:1527023339363};\\\", \\\"{x:111,y:540,t:1527023339380};\\\", \\\"{x:113,y:539,t:1527023339455};\\\", \\\"{x:120,y:536,t:1527023339464};\\\", \\\"{x:138,y:529,t:1527023339479};\\\", \\\"{x:164,y:523,t:1527023339497};\\\", \\\"{x:193,y:522,t:1527023339513};\\\", \\\"{x:220,y:522,t:1527023339530};\\\", \\\"{x:251,y:522,t:1527023339546};\\\", \\\"{x:278,y:522,t:1527023339564};\\\", \\\"{x:299,y:521,t:1527023339580};\\\", \\\"{x:314,y:517,t:1527023339596};\\\", \\\"{x:321,y:517,t:1527023339612};\\\", \\\"{x:325,y:517,t:1527023339629};\\\", \\\"{x:330,y:517,t:1527023339646};\\\", \\\"{x:341,y:515,t:1527023339662};\\\", \\\"{x:350,y:513,t:1527023339680};\\\", \\\"{x:355,y:512,t:1527023339696};\\\", \\\"{x:356,y:512,t:1527023339712};\\\", \\\"{x:357,y:512,t:1527023339880};\\\", \\\"{x:359,y:512,t:1527023339896};\\\", \\\"{x:364,y:514,t:1527023339913};\\\", \\\"{x:367,y:516,t:1527023339930};\\\", \\\"{x:369,y:517,t:1527023339946};\\\", \\\"{x:370,y:519,t:1527023340024};\\\", \\\"{x:371,y:519,t:1527023340032};\\\", \\\"{x:372,y:520,t:1527023340047};\\\", \\\"{x:373,y:521,t:1527023340063};\\\", \\\"{x:374,y:522,t:1527023340102};\\\", \\\"{x:375,y:523,t:1527023340135};\\\", \\\"{x:375,y:524,t:1527023340150};\\\", \\\"{x:377,y:525,t:1527023340164};\\\", \\\"{x:377,y:526,t:1527023340180};\\\", \\\"{x:378,y:528,t:1527023340197};\\\", \\\"{x:380,y:530,t:1527023340214};\\\", \\\"{x:380,y:531,t:1527023340230};\\\", \\\"{x:381,y:531,t:1527023340247};\\\", \\\"{x:381,y:537,t:1527023340663};\\\", \\\"{x:386,y:557,t:1527023340671};\\\", \\\"{x:401,y:579,t:1527023340681};\\\", \\\"{x:430,y:621,t:1527023340698};\\\", \\\"{x:461,y:659,t:1527023340715};\\\", \\\"{x:489,y:692,t:1527023340731};\\\", \\\"{x:510,y:717,t:1527023340747};\\\", \\\"{x:528,y:738,t:1527023340764};\\\", \\\"{x:538,y:752,t:1527023340781};\\\", \\\"{x:542,y:759,t:1527023340798};\\\", \\\"{x:543,y:762,t:1527023340814};\\\", \\\"{x:544,y:762,t:1527023341008};\\\", \\\"{x:544,y:759,t:1527023341024};\\\", \\\"{x:544,y:757,t:1527023341031};\\\", \\\"{x:544,y:755,t:1527023341049};\\\", \\\"{x:542,y:752,t:1527023341065};\\\", \\\"{x:542,y:750,t:1527023341088};\\\", \\\"{x:541,y:748,t:1527023341099};\\\", \\\"{x:540,y:747,t:1527023341142};\\\", \\\"{x:540,y:746,t:1527023341175};\\\", \\\"{x:540,y:745,t:1527023341191};\\\", \\\"{x:540,y:744,t:1527023341215};\\\" ] }, { \\\"rt\\\": 8486, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 210283, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"OZV09\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:540,y:743,t:1527023343977};\\\", \\\"{x:542,y:744,t:1527023343993};\\\", \\\"{x:549,y:750,t:1527023343998};\\\", \\\"{x:558,y:756,t:1527023344015};\\\", \\\"{x:565,y:759,t:1527023344031};\\\", \\\"{x:567,y:761,t:1527023344050};\\\", \\\"{x:569,y:762,t:1527023344067};\\\", \\\"{x:571,y:762,t:1527023344087};\\\", \\\"{x:573,y:762,t:1527023344100};\\\", \\\"{x:578,y:764,t:1527023344118};\\\", \\\"{x:582,y:765,t:1527023344133};\\\", \\\"{x:591,y:766,t:1527023344150};\\\", \\\"{x:599,y:770,t:1527023344167};\\\", \\\"{x:604,y:770,t:1527023344184};\\\", \\\"{x:608,y:770,t:1527023344200};\\\", \\\"{x:612,y:770,t:1527023344217};\\\", \\\"{x:613,y:770,t:1527023344234};\\\", \\\"{x:617,y:770,t:1527023344250};\\\", \\\"{x:621,y:770,t:1527023344267};\\\", \\\"{x:631,y:772,t:1527023344284};\\\", \\\"{x:644,y:774,t:1527023344301};\\\", \\\"{x:655,y:774,t:1527023344317};\\\", \\\"{x:668,y:775,t:1527023344335};\\\", \\\"{x:677,y:777,t:1527023344350};\\\", \\\"{x:689,y:778,t:1527023344368};\\\", \\\"{x:699,y:779,t:1527023344384};\\\", \\\"{x:712,y:782,t:1527023344400};\\\", \\\"{x:730,y:783,t:1527023344417};\\\", \\\"{x:751,y:785,t:1527023344434};\\\", \\\"{x:772,y:788,t:1527023344450};\\\", \\\"{x:791,y:790,t:1527023344468};\\\", \\\"{x:808,y:795,t:1527023344485};\\\", \\\"{x:825,y:796,t:1527023344501};\\\", \\\"{x:839,y:798,t:1527023344517};\\\", \\\"{x:855,y:798,t:1527023344535};\\\", \\\"{x:881,y:798,t:1527023344551};\\\", \\\"{x:898,y:798,t:1527023344567};\\\", \\\"{x:907,y:798,t:1527023344584};\\\", \\\"{x:917,y:798,t:1527023344601};\\\", \\\"{x:923,y:798,t:1527023344617};\\\", \\\"{x:927,y:798,t:1527023344634};\\\", \\\"{x:930,y:798,t:1527023344652};\\\", \\\"{x:935,y:798,t:1527023344668};\\\", \\\"{x:939,y:798,t:1527023344684};\\\", \\\"{x:944,y:798,t:1527023344701};\\\", \\\"{x:948,y:798,t:1527023344717};\\\", \\\"{x:952,y:798,t:1527023344734};\\\", \\\"{x:959,y:798,t:1527023344751};\\\", \\\"{x:962,y:797,t:1527023344768};\\\", \\\"{x:968,y:793,t:1527023344785};\\\", \\\"{x:976,y:789,t:1527023344802};\\\", \\\"{x:982,y:786,t:1527023344819};\\\", \\\"{x:990,y:780,t:1527023344834};\\\", \\\"{x:1001,y:772,t:1527023344852};\\\", \\\"{x:1011,y:760,t:1527023344868};\\\", \\\"{x:1025,y:736,t:1527023344885};\\\", \\\"{x:1035,y:716,t:1527023344902};\\\", \\\"{x:1043,y:704,t:1527023344919};\\\", \\\"{x:1045,y:697,t:1527023344935};\\\", \\\"{x:1048,y:689,t:1527023344952};\\\", \\\"{x:1051,y:678,t:1527023344968};\\\", \\\"{x:1058,y:662,t:1527023344984};\\\", \\\"{x:1062,y:645,t:1527023345002};\\\", \\\"{x:1065,y:633,t:1527023345018};\\\", \\\"{x:1067,y:625,t:1527023345034};\\\", \\\"{x:1068,y:621,t:1527023345052};\\\", \\\"{x:1069,y:618,t:1527023345069};\\\", \\\"{x:1070,y:616,t:1527023345085};\\\", \\\"{x:1070,y:614,t:1527023345102};\\\", \\\"{x:1071,y:608,t:1527023345119};\\\", \\\"{x:1073,y:599,t:1527023345135};\\\", \\\"{x:1073,y:594,t:1527023345152};\\\", \\\"{x:1073,y:592,t:1527023345168};\\\", \\\"{x:1074,y:592,t:1527023345185};\\\", \\\"{x:1074,y:590,t:1527023345240};\\\", \\\"{x:1074,y:589,t:1527023345252};\\\", \\\"{x:1074,y:586,t:1527023345268};\\\", \\\"{x:1074,y:584,t:1527023345286};\\\", \\\"{x:1074,y:580,t:1527023345301};\\\", \\\"{x:1074,y:579,t:1527023345319};\\\", \\\"{x:1074,y:578,t:1527023345335};\\\", \\\"{x:1074,y:576,t:1527023345536};\\\", \\\"{x:1075,y:573,t:1527023345552};\\\", \\\"{x:1075,y:569,t:1527023345568};\\\", \\\"{x:1076,y:566,t:1527023345585};\\\", \\\"{x:1077,y:564,t:1527023345602};\\\", \\\"{x:1077,y:563,t:1527023345618};\\\", \\\"{x:1077,y:562,t:1527023345635};\\\", \\\"{x:1076,y:563,t:1527023347680};\\\", \\\"{x:1075,y:563,t:1527023347696};\\\", \\\"{x:1074,y:563,t:1527023347705};\\\", \\\"{x:1071,y:565,t:1527023347723};\\\", \\\"{x:1070,y:565,t:1527023347738};\\\", \\\"{x:1068,y:566,t:1527023347755};\\\", \\\"{x:1065,y:567,t:1527023347772};\\\", \\\"{x:1062,y:569,t:1527023347787};\\\", \\\"{x:1058,y:570,t:1527023347805};\\\", \\\"{x:1051,y:574,t:1527023347823};\\\", \\\"{x:1044,y:576,t:1527023347838};\\\", \\\"{x:1032,y:578,t:1527023347855};\\\", \\\"{x:1017,y:581,t:1527023347872};\\\", \\\"{x:1000,y:583,t:1527023347889};\\\", \\\"{x:971,y:588,t:1527023347905};\\\", \\\"{x:939,y:590,t:1527023347923};\\\", \\\"{x:903,y:590,t:1527023347938};\\\", \\\"{x:877,y:590,t:1527023347954};\\\", \\\"{x:858,y:590,t:1527023347970};\\\", \\\"{x:848,y:590,t:1527023347986};\\\", \\\"{x:847,y:590,t:1527023348003};\\\", \\\"{x:846,y:591,t:1527023348030};\\\", \\\"{x:845,y:592,t:1527023348038};\\\", \\\"{x:844,y:592,t:1527023348053};\\\", \\\"{x:836,y:592,t:1527023348070};\\\", \\\"{x:832,y:592,t:1527023348086};\\\", \\\"{x:830,y:592,t:1527023348104};\\\", \\\"{x:829,y:592,t:1527023348751};\\\", \\\"{x:828,y:592,t:1527023348759};\\\", \\\"{x:826,y:591,t:1527023348771};\\\", \\\"{x:824,y:586,t:1527023348789};\\\", \\\"{x:821,y:581,t:1527023348803};\\\", \\\"{x:818,y:577,t:1527023348821};\\\", \\\"{x:816,y:573,t:1527023348837};\\\", \\\"{x:813,y:569,t:1527023348854};\\\", \\\"{x:805,y:558,t:1527023348870};\\\", \\\"{x:796,y:545,t:1527023348888};\\\", \\\"{x:790,y:539,t:1527023348905};\\\", \\\"{x:786,y:536,t:1527023348920};\\\", \\\"{x:783,y:534,t:1527023348937};\\\", \\\"{x:782,y:533,t:1527023348954};\\\", \\\"{x:782,y:531,t:1527023348970};\\\", \\\"{x:778,y:527,t:1527023348988};\\\", \\\"{x:770,y:524,t:1527023349005};\\\", \\\"{x:754,y:521,t:1527023349020};\\\", \\\"{x:739,y:521,t:1527023349037};\\\", \\\"{x:731,y:521,t:1527023349055};\\\", \\\"{x:730,y:521,t:1527023349072};\\\", \\\"{x:729,y:521,t:1527023349119};\\\", \\\"{x:727,y:521,t:1527023349128};\\\", \\\"{x:724,y:521,t:1527023349138};\\\", \\\"{x:714,y:521,t:1527023349155};\\\", \\\"{x:702,y:520,t:1527023349172};\\\", \\\"{x:692,y:519,t:1527023349189};\\\", \\\"{x:687,y:519,t:1527023349205};\\\", \\\"{x:684,y:517,t:1527023349222};\\\", \\\"{x:674,y:515,t:1527023349238};\\\", \\\"{x:657,y:510,t:1527023349254};\\\", \\\"{x:630,y:502,t:1527023349271};\\\", \\\"{x:625,y:501,t:1527023349287};\\\", \\\"{x:624,y:500,t:1527023349351};\\\", \\\"{x:624,y:499,t:1527023349375};\\\", \\\"{x:623,y:498,t:1527023349392};\\\", \\\"{x:630,y:498,t:1527023349912};\\\", \\\"{x:642,y:498,t:1527023349922};\\\", \\\"{x:669,y:504,t:1527023349940};\\\", \\\"{x:702,y:508,t:1527023349955};\\\", \\\"{x:734,y:516,t:1527023349972};\\\", \\\"{x:750,y:519,t:1527023349989};\\\", \\\"{x:755,y:521,t:1527023350006};\\\", \\\"{x:757,y:521,t:1527023350047};\\\", \\\"{x:759,y:521,t:1527023350055};\\\", \\\"{x:763,y:521,t:1527023350072};\\\", \\\"{x:764,y:521,t:1527023350088};\\\", \\\"{x:767,y:521,t:1527023350105};\\\", \\\"{x:776,y:521,t:1527023350122};\\\", \\\"{x:794,y:523,t:1527023350138};\\\", \\\"{x:813,y:525,t:1527023350157};\\\", \\\"{x:821,y:527,t:1527023350171};\\\", \\\"{x:825,y:527,t:1527023350188};\\\", \\\"{x:826,y:528,t:1527023350205};\\\", \\\"{x:827,y:529,t:1527023350222};\\\", \\\"{x:828,y:529,t:1527023350239};\\\", \\\"{x:829,y:530,t:1527023350295};\\\", \\\"{x:829,y:531,t:1527023350305};\\\", \\\"{x:834,y:535,t:1527023350322};\\\", \\\"{x:840,y:538,t:1527023350339};\\\", \\\"{x:842,y:539,t:1527023350355};\\\", \\\"{x:843,y:539,t:1527023350371};\\\", \\\"{x:842,y:541,t:1527023350686};\\\", \\\"{x:839,y:542,t:1527023350694};\\\", \\\"{x:837,y:543,t:1527023350705};\\\", \\\"{x:823,y:547,t:1527023350723};\\\", \\\"{x:802,y:552,t:1527023350738};\\\", \\\"{x:769,y:564,t:1527023350756};\\\", \\\"{x:746,y:575,t:1527023350772};\\\", \\\"{x:731,y:584,t:1527023350788};\\\", \\\"{x:726,y:589,t:1527023350805};\\\", \\\"{x:717,y:598,t:1527023350823};\\\", \\\"{x:703,y:612,t:1527023350840};\\\", \\\"{x:663,y:644,t:1527023350856};\\\", \\\"{x:628,y:674,t:1527023350872};\\\", \\\"{x:597,y:700,t:1527023350889};\\\", \\\"{x:576,y:718,t:1527023350905};\\\", \\\"{x:557,y:731,t:1527023350922};\\\", \\\"{x:546,y:736,t:1527023350939};\\\", \\\"{x:545,y:736,t:1527023350955};\\\", \\\"{x:544,y:736,t:1527023350974};\\\", \\\"{x:543,y:736,t:1527023350998};\\\", \\\"{x:541,y:736,t:1527023351006};\\\", \\\"{x:540,y:736,t:1527023351022};\\\", \\\"{x:538,y:736,t:1527023351039};\\\", \\\"{x:541,y:733,t:1527023351415};\\\", \\\"{x:542,y:731,t:1527023351423};\\\", \\\"{x:547,y:727,t:1527023351439};\\\", \\\"{x:553,y:722,t:1527023351456};\\\", \\\"{x:561,y:718,t:1527023351472};\\\", \\\"{x:573,y:713,t:1527023351490};\\\", \\\"{x:593,y:705,t:1527023351507};\\\", \\\"{x:617,y:695,t:1527023351522};\\\", \\\"{x:646,y:688,t:1527023351539};\\\", \\\"{x:667,y:683,t:1527023351557};\\\", \\\"{x:686,y:682,t:1527023351572};\\\", \\\"{x:714,y:677,t:1527023351589};\\\", \\\"{x:741,y:673,t:1527023351606};\\\", \\\"{x:789,y:663,t:1527023351623};\\\", \\\"{x:824,y:658,t:1527023351639};\\\", \\\"{x:869,y:651,t:1527023351656};\\\", \\\"{x:922,y:643,t:1527023351673};\\\", \\\"{x:986,y:634,t:1527023351690};\\\", \\\"{x:1049,y:627,t:1527023351707};\\\", \\\"{x:1102,y:621,t:1527023351723};\\\", \\\"{x:1154,y:618,t:1527023351739};\\\", \\\"{x:1201,y:618,t:1527023351757};\\\", \\\"{x:1243,y:618,t:1527023351774};\\\", \\\"{x:1272,y:618,t:1527023351789};\\\", \\\"{x:1291,y:618,t:1527023351807};\\\", \\\"{x:1303,y:618,t:1527023351823};\\\", \\\"{x:1304,y:618,t:1527023351839};\\\", \\\"{x:1305,y:618,t:1527023351857};\\\" ] }, { \\\"rt\\\": 14423, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 225983, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"OZV09\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-5\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1304,y:618,t:1527023355321};\\\", \\\"{x:1303,y:618,t:1527023355346};\\\", \\\"{x:1302,y:618,t:1527023355383};\\\", \\\"{x:1302,y:619,t:1527023355463};\\\", \\\"{x:1301,y:619,t:1527023355479};\\\", \\\"{x:1300,y:620,t:1527023355552};\\\", \\\"{x:1299,y:621,t:1527023355567};\\\", \\\"{x:1299,y:622,t:1527023355591};\\\", \\\"{x:1299,y:624,t:1527023355607};\\\", \\\"{x:1299,y:625,t:1527023355632};\\\", \\\"{x:1299,y:627,t:1527023355644};\\\", \\\"{x:1297,y:629,t:1527023355660};\\\", \\\"{x:1297,y:631,t:1527023355676};\\\", \\\"{x:1297,y:633,t:1527023355693};\\\", \\\"{x:1297,y:634,t:1527023355711};\\\", \\\"{x:1297,y:636,t:1527023355726};\\\", \\\"{x:1297,y:637,t:1527023355743};\\\", \\\"{x:1297,y:639,t:1527023355760};\\\", \\\"{x:1297,y:642,t:1527023355778};\\\", \\\"{x:1297,y:644,t:1527023355794};\\\", \\\"{x:1297,y:646,t:1527023355810};\\\", \\\"{x:1297,y:648,t:1527023355827};\\\", \\\"{x:1297,y:649,t:1527023355843};\\\", \\\"{x:1297,y:651,t:1527023355861};\\\", \\\"{x:1297,y:653,t:1527023355877};\\\", \\\"{x:1297,y:658,t:1527023355893};\\\", \\\"{x:1297,y:664,t:1527023355911};\\\", \\\"{x:1297,y:667,t:1527023355927};\\\", \\\"{x:1297,y:670,t:1527023355944};\\\", \\\"{x:1296,y:674,t:1527023355960};\\\", \\\"{x:1296,y:678,t:1527023355977};\\\", \\\"{x:1296,y:684,t:1527023355994};\\\", \\\"{x:1293,y:690,t:1527023356011};\\\", \\\"{x:1293,y:696,t:1527023356027};\\\", \\\"{x:1293,y:701,t:1527023356044};\\\", \\\"{x:1292,y:704,t:1527023356060};\\\", \\\"{x:1292,y:706,t:1527023356078};\\\", \\\"{x:1291,y:711,t:1527023356093};\\\", \\\"{x:1291,y:713,t:1527023356110};\\\", \\\"{x:1290,y:716,t:1527023356128};\\\", \\\"{x:1289,y:721,t:1527023356144};\\\", \\\"{x:1288,y:724,t:1527023356160};\\\", \\\"{x:1286,y:727,t:1527023356178};\\\", \\\"{x:1286,y:728,t:1527023356193};\\\", \\\"{x:1285,y:731,t:1527023356210};\\\", \\\"{x:1285,y:732,t:1527023356227};\\\", \\\"{x:1285,y:734,t:1527023356244};\\\", \\\"{x:1283,y:735,t:1527023356260};\\\", \\\"{x:1283,y:737,t:1527023356287};\\\", \\\"{x:1282,y:739,t:1527023356304};\\\", \\\"{x:1281,y:740,t:1527023356328};\\\", \\\"{x:1281,y:741,t:1527023356344};\\\", \\\"{x:1280,y:741,t:1527023356375};\\\", \\\"{x:1279,y:742,t:1527023356432};\\\", \\\"{x:1279,y:743,t:1527023356448};\\\", \\\"{x:1278,y:743,t:1527023356464};\\\", \\\"{x:1278,y:744,t:1527023356479};\\\", \\\"{x:1277,y:745,t:1527023356528};\\\", \\\"{x:1276,y:746,t:1527023356567};\\\", \\\"{x:1275,y:747,t:1527023356577};\\\", \\\"{x:1274,y:748,t:1527023356608};\\\", \\\"{x:1274,y:749,t:1527023356624};\\\", \\\"{x:1273,y:750,t:1527023356640};\\\", \\\"{x:1272,y:751,t:1527023356656};\\\", \\\"{x:1271,y:752,t:1527023356671};\\\", \\\"{x:1269,y:754,t:1527023356679};\\\", \\\"{x:1269,y:755,t:1527023356696};\\\", \\\"{x:1269,y:756,t:1527023356710};\\\", \\\"{x:1267,y:758,t:1527023356727};\\\", \\\"{x:1266,y:760,t:1527023356744};\\\", \\\"{x:1264,y:762,t:1527023356761};\\\", \\\"{x:1262,y:764,t:1527023356777};\\\", \\\"{x:1260,y:766,t:1527023356794};\\\", \\\"{x:1258,y:770,t:1527023356811};\\\", \\\"{x:1256,y:771,t:1527023356828};\\\", \\\"{x:1255,y:772,t:1527023356845};\\\", \\\"{x:1254,y:773,t:1527023356861};\\\", \\\"{x:1253,y:774,t:1527023356878};\\\", \\\"{x:1251,y:775,t:1527023356895};\\\", \\\"{x:1248,y:777,t:1527023356911};\\\", \\\"{x:1247,y:777,t:1527023356928};\\\", \\\"{x:1244,y:779,t:1527023356944};\\\", \\\"{x:1243,y:780,t:1527023356961};\\\", \\\"{x:1242,y:781,t:1527023356978};\\\", \\\"{x:1240,y:781,t:1527023356994};\\\", \\\"{x:1238,y:783,t:1527023357011};\\\", \\\"{x:1237,y:784,t:1527023357028};\\\", \\\"{x:1233,y:786,t:1527023357044};\\\", \\\"{x:1229,y:788,t:1527023357061};\\\", \\\"{x:1221,y:790,t:1527023357078};\\\", \\\"{x:1214,y:792,t:1527023357094};\\\", \\\"{x:1203,y:795,t:1527023357111};\\\", \\\"{x:1201,y:796,t:1527023357128};\\\", \\\"{x:1199,y:796,t:1527023357145};\\\", \\\"{x:1196,y:796,t:1527023357161};\\\", \\\"{x:1192,y:796,t:1527023357178};\\\", \\\"{x:1184,y:796,t:1527023357194};\\\", \\\"{x:1175,y:796,t:1527023357210};\\\", \\\"{x:1170,y:796,t:1527023357228};\\\", \\\"{x:1168,y:796,t:1527023357278};\\\", \\\"{x:1167,y:795,t:1527023357294};\\\", \\\"{x:1162,y:789,t:1527023357311};\\\", \\\"{x:1157,y:787,t:1527023357327};\\\", \\\"{x:1151,y:784,t:1527023357344};\\\", \\\"{x:1148,y:782,t:1527023357361};\\\", \\\"{x:1145,y:782,t:1527023357378};\\\", \\\"{x:1140,y:780,t:1527023357393};\\\", \\\"{x:1138,y:779,t:1527023357411};\\\", \\\"{x:1134,y:777,t:1527023357428};\\\", \\\"{x:1132,y:775,t:1527023357444};\\\", \\\"{x:1128,y:772,t:1527023357461};\\\", \\\"{x:1123,y:770,t:1527023357478};\\\", \\\"{x:1118,y:766,t:1527023357495};\\\", \\\"{x:1115,y:763,t:1527023357511};\\\", \\\"{x:1111,y:760,t:1527023357528};\\\", \\\"{x:1109,y:757,t:1527023357545};\\\", \\\"{x:1108,y:754,t:1527023357561};\\\", \\\"{x:1106,y:751,t:1527023357578};\\\", \\\"{x:1103,y:746,t:1527023357595};\\\", \\\"{x:1101,y:741,t:1527023357611};\\\", \\\"{x:1099,y:736,t:1527023357628};\\\", \\\"{x:1097,y:732,t:1527023357645};\\\", \\\"{x:1096,y:730,t:1527023357661};\\\", \\\"{x:1096,y:728,t:1527023357678};\\\", \\\"{x:1095,y:727,t:1527023357696};\\\", \\\"{x:1095,y:726,t:1527023357711};\\\", \\\"{x:1094,y:725,t:1527023357728};\\\", \\\"{x:1093,y:723,t:1527023357745};\\\", \\\"{x:1092,y:719,t:1527023357761};\\\", \\\"{x:1091,y:718,t:1527023357778};\\\", \\\"{x:1091,y:716,t:1527023357795};\\\", \\\"{x:1090,y:716,t:1527023357811};\\\", \\\"{x:1090,y:715,t:1527023357840};\\\", \\\"{x:1090,y:714,t:1527023357847};\\\", \\\"{x:1088,y:712,t:1527023357861};\\\", \\\"{x:1087,y:710,t:1527023357879};\\\", \\\"{x:1084,y:703,t:1527023357895};\\\", \\\"{x:1080,y:697,t:1527023357912};\\\", \\\"{x:1079,y:694,t:1527023357928};\\\", \\\"{x:1076,y:686,t:1527023357946};\\\", \\\"{x:1071,y:674,t:1527023357962};\\\", \\\"{x:1067,y:661,t:1527023357978};\\\", \\\"{x:1065,y:652,t:1527023357995};\\\", \\\"{x:1064,y:648,t:1527023358012};\\\", \\\"{x:1063,y:646,t:1527023358028};\\\", \\\"{x:1063,y:644,t:1527023358045};\\\", \\\"{x:1062,y:641,t:1527023358063};\\\", \\\"{x:1062,y:638,t:1527023358078};\\\", \\\"{x:1062,y:631,t:1527023358095};\\\", \\\"{x:1061,y:628,t:1527023358111};\\\", \\\"{x:1061,y:627,t:1527023358128};\\\", \\\"{x:1061,y:632,t:1527023361039};\\\", \\\"{x:1061,y:636,t:1527023361047};\\\", \\\"{x:1061,y:639,t:1527023361065};\\\", \\\"{x:1061,y:643,t:1527023361081};\\\", \\\"{x:1062,y:647,t:1527023361097};\\\", \\\"{x:1063,y:650,t:1527023361114};\\\", \\\"{x:1064,y:653,t:1527023361130};\\\", \\\"{x:1064,y:657,t:1527023361147};\\\", \\\"{x:1064,y:662,t:1527023361164};\\\", \\\"{x:1067,y:667,t:1527023361181};\\\", \\\"{x:1068,y:672,t:1527023361197};\\\", \\\"{x:1071,y:678,t:1527023361214};\\\", \\\"{x:1071,y:683,t:1527023361231};\\\", \\\"{x:1072,y:687,t:1527023361247};\\\", \\\"{x:1074,y:689,t:1527023361264};\\\", \\\"{x:1074,y:690,t:1527023361281};\\\", \\\"{x:1074,y:691,t:1527023361297};\\\", \\\"{x:1074,y:692,t:1527023361314};\\\", \\\"{x:1074,y:693,t:1527023361332};\\\", \\\"{x:1075,y:693,t:1527023361348};\\\", \\\"{x:1075,y:694,t:1527023361365};\\\", \\\"{x:1075,y:695,t:1527023361384};\\\", \\\"{x:1075,y:693,t:1527023364616};\\\", \\\"{x:1073,y:687,t:1527023364623};\\\", \\\"{x:1071,y:683,t:1527023364634};\\\", \\\"{x:1066,y:674,t:1527023364650};\\\", \\\"{x:1059,y:666,t:1527023364668};\\\", \\\"{x:1055,y:659,t:1527023364684};\\\", \\\"{x:1053,y:652,t:1527023364701};\\\", \\\"{x:1048,y:638,t:1527023364717};\\\", \\\"{x:1039,y:615,t:1527023364733};\\\", \\\"{x:1028,y:594,t:1527023364750};\\\", \\\"{x:1008,y:566,t:1527023364767};\\\", \\\"{x:995,y:551,t:1527023364784};\\\", \\\"{x:979,y:534,t:1527023364801};\\\", \\\"{x:963,y:520,t:1527023364818};\\\", \\\"{x:944,y:507,t:1527023364835};\\\", \\\"{x:928,y:501,t:1527023364850};\\\", \\\"{x:918,y:496,t:1527023364867};\\\", \\\"{x:908,y:495,t:1527023364883};\\\", \\\"{x:906,y:495,t:1527023364900};\\\", \\\"{x:902,y:495,t:1527023364917};\\\", \\\"{x:900,y:495,t:1527023364933};\\\", \\\"{x:898,y:498,t:1527023364950};\\\", \\\"{x:892,y:502,t:1527023364967};\\\", \\\"{x:880,y:507,t:1527023364982};\\\", \\\"{x:864,y:511,t:1527023365000};\\\", \\\"{x:858,y:512,t:1527023365017};\\\", \\\"{x:856,y:512,t:1527023365033};\\\", \\\"{x:855,y:512,t:1527023365049};\\\", \\\"{x:854,y:512,t:1527023365067};\\\", \\\"{x:851,y:512,t:1527023365084};\\\", \\\"{x:843,y:513,t:1527023365100};\\\", \\\"{x:834,y:513,t:1527023365117};\\\", \\\"{x:831,y:513,t:1527023365134};\\\", \\\"{x:830,y:513,t:1527023365150};\\\", \\\"{x:829,y:516,t:1527023365751};\\\", \\\"{x:831,y:529,t:1527023365768};\\\", \\\"{x:833,y:540,t:1527023365784};\\\", \\\"{x:834,y:551,t:1527023365800};\\\", \\\"{x:837,y:567,t:1527023365819};\\\", \\\"{x:838,y:577,t:1527023365834};\\\", \\\"{x:839,y:584,t:1527023365851};\\\", \\\"{x:839,y:588,t:1527023365868};\\\", \\\"{x:841,y:591,t:1527023365884};\\\", \\\"{x:841,y:597,t:1527023365902};\\\", \\\"{x:842,y:604,t:1527023365919};\\\", \\\"{x:842,y:609,t:1527023365934};\\\", \\\"{x:844,y:613,t:1527023365950};\\\", \\\"{x:844,y:614,t:1527023365968};\\\", \\\"{x:844,y:615,t:1527023366286};\\\", \\\"{x:843,y:616,t:1527023366310};\\\", \\\"{x:840,y:617,t:1527023366318};\\\", \\\"{x:833,y:620,t:1527023366334};\\\", \\\"{x:813,y:625,t:1527023366351};\\\", \\\"{x:787,y:631,t:1527023366368};\\\", \\\"{x:757,y:636,t:1527023366386};\\\", \\\"{x:735,y:640,t:1527023366400};\\\", \\\"{x:710,y:646,t:1527023366418};\\\", \\\"{x:693,y:649,t:1527023366435};\\\", \\\"{x:673,y:658,t:1527023366452};\\\", \\\"{x:656,y:663,t:1527023366468};\\\", \\\"{x:638,y:671,t:1527023366485};\\\", \\\"{x:618,y:676,t:1527023366502};\\\", \\\"{x:598,y:684,t:1527023366518};\\\", \\\"{x:574,y:691,t:1527023366534};\\\", \\\"{x:563,y:696,t:1527023366551};\\\", \\\"{x:555,y:700,t:1527023366568};\\\", \\\"{x:551,y:704,t:1527023366586};\\\", \\\"{x:546,y:707,t:1527023366603};\\\", \\\"{x:542,y:712,t:1527023366618};\\\", \\\"{x:539,y:713,t:1527023366635};\\\", \\\"{x:536,y:716,t:1527023366653};\\\", \\\"{x:535,y:717,t:1527023366668};\\\", \\\"{x:531,y:719,t:1527023366685};\\\", \\\"{x:529,y:721,t:1527023366703};\\\", \\\"{x:524,y:725,t:1527023366718};\\\", \\\"{x:523,y:727,t:1527023366735};\\\", \\\"{x:522,y:727,t:1527023366752};\\\", \\\"{x:522,y:728,t:1527023366768};\\\", \\\"{x:522,y:729,t:1527023366785};\\\", \\\"{x:520,y:732,t:1527023366802};\\\", \\\"{x:519,y:733,t:1527023366818};\\\", \\\"{x:518,y:735,t:1527023366835};\\\", \\\"{x:521,y:734,t:1527023367183};\\\", \\\"{x:522,y:733,t:1527023367191};\\\", \\\"{x:525,y:731,t:1527023367202};\\\", \\\"{x:530,y:729,t:1527023367219};\\\", \\\"{x:537,y:726,t:1527023367235};\\\", \\\"{x:546,y:722,t:1527023367252};\\\", \\\"{x:561,y:715,t:1527023367269};\\\", \\\"{x:590,y:697,t:1527023367285};\\\", \\\"{x:612,y:681,t:1527023367302};\\\", \\\"{x:638,y:665,t:1527023367319};\\\", \\\"{x:649,y:658,t:1527023367336};\\\", \\\"{x:659,y:650,t:1527023367352};\\\", \\\"{x:676,y:638,t:1527023367369};\\\", \\\"{x:697,y:624,t:1527023367387};\\\", \\\"{x:706,y:620,t:1527023367403};\\\", \\\"{x:707,y:619,t:1527023367419};\\\" ] }, { \\\"rt\\\": 78355, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 305564, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"OZV09\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:708,y:619,t:1527023370231};\\\", \\\"{x:709,y:619,t:1527023370238};\\\", \\\"{x:713,y:619,t:1527023370255};\\\", \\\"{x:719,y:619,t:1527023370272};\\\", \\\"{x:726,y:620,t:1527023370288};\\\", \\\"{x:735,y:620,t:1527023370305};\\\", \\\"{x:743,y:621,t:1527023370322};\\\", \\\"{x:750,y:623,t:1527023370338};\\\", \\\"{x:755,y:623,t:1527023370354};\\\", \\\"{x:759,y:623,t:1527023370371};\\\", \\\"{x:761,y:623,t:1527023370388};\\\", \\\"{x:764,y:623,t:1527023370404};\\\", \\\"{x:765,y:623,t:1527023370421};\\\", \\\"{x:768,y:623,t:1527023370438};\\\", \\\"{x:772,y:623,t:1527023370455};\\\", \\\"{x:775,y:623,t:1527023370471};\\\", \\\"{x:779,y:623,t:1527023370488};\\\", \\\"{x:783,y:623,t:1527023370505};\\\", \\\"{x:789,y:624,t:1527023370521};\\\", \\\"{x:794,y:624,t:1527023370538};\\\", \\\"{x:802,y:625,t:1527023370555};\\\", \\\"{x:808,y:625,t:1527023370571};\\\", \\\"{x:812,y:625,t:1527023370588};\\\", \\\"{x:816,y:625,t:1527023370606};\\\", \\\"{x:817,y:625,t:1527023370622};\\\", \\\"{x:819,y:625,t:1527023370638};\\\", \\\"{x:821,y:625,t:1527023370655};\\\", \\\"{x:824,y:626,t:1527023370671};\\\", \\\"{x:827,y:626,t:1527023370689};\\\", \\\"{x:834,y:627,t:1527023370705};\\\", \\\"{x:842,y:628,t:1527023370721};\\\", \\\"{x:850,y:629,t:1527023370738};\\\", \\\"{x:857,y:631,t:1527023370755};\\\", \\\"{x:862,y:631,t:1527023370771};\\\", \\\"{x:866,y:632,t:1527023370789};\\\", \\\"{x:872,y:633,t:1527023370806};\\\", \\\"{x:878,y:633,t:1527023370821};\\\", \\\"{x:888,y:635,t:1527023370838};\\\", \\\"{x:896,y:635,t:1527023370855};\\\", \\\"{x:904,y:635,t:1527023370871};\\\", \\\"{x:911,y:635,t:1527023370889};\\\", \\\"{x:918,y:635,t:1527023370905};\\\", \\\"{x:924,y:636,t:1527023370922};\\\", \\\"{x:930,y:637,t:1527023370938};\\\", \\\"{x:939,y:639,t:1527023370955};\\\", \\\"{x:951,y:641,t:1527023370973};\\\", \\\"{x:962,y:642,t:1527023370989};\\\", \\\"{x:975,y:644,t:1527023371006};\\\", \\\"{x:980,y:644,t:1527023371022};\\\", \\\"{x:984,y:645,t:1527023371039};\\\", \\\"{x:988,y:645,t:1527023371056};\\\", \\\"{x:994,y:646,t:1527023371073};\\\", \\\"{x:1003,y:648,t:1527023371088};\\\", \\\"{x:1014,y:650,t:1527023371106};\\\", \\\"{x:1031,y:653,t:1527023371123};\\\", \\\"{x:1047,y:655,t:1527023371139};\\\", \\\"{x:1059,y:656,t:1527023371155};\\\", \\\"{x:1068,y:658,t:1527023371173};\\\", \\\"{x:1078,y:659,t:1527023371189};\\\", \\\"{x:1092,y:661,t:1527023371206};\\\", \\\"{x:1106,y:664,t:1527023371222};\\\", \\\"{x:1123,y:666,t:1527023371238};\\\", \\\"{x:1148,y:669,t:1527023371255};\\\", \\\"{x:1166,y:671,t:1527023371272};\\\", \\\"{x:1184,y:674,t:1527023371288};\\\", \\\"{x:1202,y:675,t:1527023371306};\\\", \\\"{x:1220,y:676,t:1527023371323};\\\", \\\"{x:1237,y:678,t:1527023371339};\\\", \\\"{x:1252,y:678,t:1527023371355};\\\", \\\"{x:1258,y:678,t:1527023371373};\\\", \\\"{x:1264,y:678,t:1527023371389};\\\", \\\"{x:1265,y:678,t:1527023371406};\\\", \\\"{x:1267,y:678,t:1527023371423};\\\", \\\"{x:1269,y:678,t:1527023371440};\\\", \\\"{x:1272,y:677,t:1527023371456};\\\", \\\"{x:1276,y:673,t:1527023371472};\\\", \\\"{x:1278,y:668,t:1527023371489};\\\", \\\"{x:1278,y:662,t:1527023371506};\\\", \\\"{x:1278,y:653,t:1527023371523};\\\", \\\"{x:1278,y:645,t:1527023371540};\\\", \\\"{x:1278,y:636,t:1527023371556};\\\", \\\"{x:1278,y:632,t:1527023371573};\\\", \\\"{x:1278,y:630,t:1527023371589};\\\", \\\"{x:1278,y:628,t:1527023371606};\\\", \\\"{x:1278,y:625,t:1527023371623};\\\", \\\"{x:1277,y:619,t:1527023371639};\\\", \\\"{x:1270,y:611,t:1527023371656};\\\", \\\"{x:1264,y:604,t:1527023371673};\\\", \\\"{x:1259,y:599,t:1527023371690};\\\", \\\"{x:1255,y:595,t:1527023371706};\\\", \\\"{x:1253,y:593,t:1527023371722};\\\", \\\"{x:1252,y:592,t:1527023371740};\\\", \\\"{x:1245,y:579,t:1527023371756};\\\", \\\"{x:1231,y:557,t:1527023371773};\\\", \\\"{x:1211,y:541,t:1527023371790};\\\", \\\"{x:1193,y:530,t:1527023371806};\\\", \\\"{x:1174,y:521,t:1527023371823};\\\", \\\"{x:1169,y:519,t:1527023371840};\\\", \\\"{x:1161,y:518,t:1527023371857};\\\", \\\"{x:1148,y:516,t:1527023371873};\\\", \\\"{x:1129,y:510,t:1527023371890};\\\", \\\"{x:1111,y:505,t:1527023371907};\\\", \\\"{x:1101,y:502,t:1527023371923};\\\", \\\"{x:1095,y:500,t:1527023371940};\\\", \\\"{x:1093,y:500,t:1527023371956};\\\", \\\"{x:1092,y:500,t:1527023371973};\\\", \\\"{x:1091,y:500,t:1527023372591};\\\", \\\"{x:1091,y:502,t:1527023382851};\\\", \\\"{x:1093,y:505,t:1527023382868};\\\", \\\"{x:1094,y:507,t:1527023382885};\\\", \\\"{x:1094,y:509,t:1527023382901};\\\", \\\"{x:1095,y:510,t:1527023382918};\\\", \\\"{x:1096,y:511,t:1527023382935};\\\", \\\"{x:1097,y:513,t:1527023382951};\\\", \\\"{x:1099,y:516,t:1527023382968};\\\", \\\"{x:1101,y:518,t:1527023382985};\\\", \\\"{x:1102,y:520,t:1527023383002};\\\", \\\"{x:1107,y:526,t:1527023383018};\\\", \\\"{x:1111,y:533,t:1527023383036};\\\", \\\"{x:1116,y:539,t:1527023383052};\\\", \\\"{x:1124,y:550,t:1527023383068};\\\", \\\"{x:1128,y:561,t:1527023383085};\\\", \\\"{x:1136,y:574,t:1527023383101};\\\", \\\"{x:1142,y:589,t:1527023383118};\\\", \\\"{x:1150,y:606,t:1527023383135};\\\", \\\"{x:1156,y:621,t:1527023383151};\\\", \\\"{x:1162,y:636,t:1527023383168};\\\", \\\"{x:1167,y:647,t:1527023383185};\\\", \\\"{x:1171,y:657,t:1527023383201};\\\", \\\"{x:1176,y:674,t:1527023383218};\\\", \\\"{x:1180,y:686,t:1527023383235};\\\", \\\"{x:1183,y:694,t:1527023383252};\\\", \\\"{x:1186,y:700,t:1527023383268};\\\", \\\"{x:1189,y:707,t:1527023383285};\\\", \\\"{x:1190,y:713,t:1527023383302};\\\", \\\"{x:1193,y:720,t:1527023383318};\\\", \\\"{x:1194,y:726,t:1527023383335};\\\", \\\"{x:1194,y:733,t:1527023383352};\\\", \\\"{x:1195,y:736,t:1527023383368};\\\", \\\"{x:1195,y:737,t:1527023383385};\\\", \\\"{x:1195,y:740,t:1527023383402};\\\", \\\"{x:1195,y:743,t:1527023383418};\\\", \\\"{x:1195,y:747,t:1527023383435};\\\", \\\"{x:1195,y:751,t:1527023383452};\\\", \\\"{x:1195,y:753,t:1527023383468};\\\", \\\"{x:1195,y:755,t:1527023383490};\\\", \\\"{x:1195,y:756,t:1527023383503};\\\", \\\"{x:1195,y:758,t:1527023383522};\\\", \\\"{x:1195,y:759,t:1527023383536};\\\", \\\"{x:1195,y:760,t:1527023383552};\\\", \\\"{x:1195,y:761,t:1527023383569};\\\", \\\"{x:1195,y:763,t:1527023383585};\\\", \\\"{x:1195,y:766,t:1527023383603};\\\", \\\"{x:1193,y:767,t:1527023383618};\\\", \\\"{x:1193,y:769,t:1527023383642};\\\", \\\"{x:1192,y:769,t:1527023383658};\\\", \\\"{x:1191,y:771,t:1527023383669};\\\", \\\"{x:1190,y:773,t:1527023383714};\\\", \\\"{x:1189,y:774,t:1527023383747};\\\", \\\"{x:1188,y:774,t:1527023383762};\\\", \\\"{x:1188,y:775,t:1527023387811};\\\", \\\"{x:1190,y:775,t:1527023387826};\\\", \\\"{x:1194,y:776,t:1527023387839};\\\", \\\"{x:1200,y:777,t:1527023387855};\\\", \\\"{x:1205,y:779,t:1527023387873};\\\", \\\"{x:1208,y:780,t:1527023387889};\\\", \\\"{x:1209,y:780,t:1527023387922};\\\", \\\"{x:1211,y:780,t:1527023387946};\\\", \\\"{x:1213,y:780,t:1527023387956};\\\", \\\"{x:1216,y:780,t:1527023387973};\\\", \\\"{x:1220,y:781,t:1527023387988};\\\", \\\"{x:1224,y:781,t:1527023388006};\\\", \\\"{x:1228,y:781,t:1527023388022};\\\", \\\"{x:1232,y:781,t:1527023388039};\\\", \\\"{x:1237,y:781,t:1527023388056};\\\", \\\"{x:1242,y:781,t:1527023388072};\\\", \\\"{x:1249,y:781,t:1527023388088};\\\", \\\"{x:1258,y:781,t:1527023388106};\\\", \\\"{x:1274,y:781,t:1527023388122};\\\", \\\"{x:1285,y:781,t:1527023388140};\\\", \\\"{x:1297,y:781,t:1527023388155};\\\", \\\"{x:1310,y:781,t:1527023388172};\\\", \\\"{x:1320,y:781,t:1527023388189};\\\", \\\"{x:1333,y:781,t:1527023388205};\\\", \\\"{x:1341,y:781,t:1527023388222};\\\", \\\"{x:1351,y:781,t:1527023388239};\\\", \\\"{x:1362,y:781,t:1527023388255};\\\", \\\"{x:1374,y:781,t:1527023388272};\\\", \\\"{x:1385,y:778,t:1527023388289};\\\", \\\"{x:1389,y:777,t:1527023388305};\\\", \\\"{x:1392,y:775,t:1527023388322};\\\", \\\"{x:1393,y:775,t:1527023388339};\\\", \\\"{x:1392,y:775,t:1527023388474};\\\", \\\"{x:1391,y:775,t:1527023388489};\\\", \\\"{x:1390,y:775,t:1527023388505};\\\", \\\"{x:1388,y:776,t:1527023388522};\\\", \\\"{x:1387,y:776,t:1527023388553};\\\", \\\"{x:1385,y:776,t:1527023388562};\\\", \\\"{x:1383,y:776,t:1527023388572};\\\", \\\"{x:1374,y:776,t:1527023388589};\\\", \\\"{x:1361,y:775,t:1527023388607};\\\", \\\"{x:1354,y:774,t:1527023388623};\\\", \\\"{x:1348,y:773,t:1527023388640};\\\", \\\"{x:1347,y:773,t:1527023388657};\\\", \\\"{x:1346,y:773,t:1527023388674};\\\", \\\"{x:1346,y:772,t:1527023388698};\\\", \\\"{x:1346,y:771,t:1527023389867};\\\", \\\"{x:1347,y:771,t:1527023391905};\\\", \\\"{x:1347,y:770,t:1527023392107};\\\", \\\"{x:1348,y:768,t:1527023392485};\\\", \\\"{x:1348,y:767,t:1527023392570};\\\", \\\"{x:1348,y:766,t:1527023392602};\\\", \\\"{x:1348,y:762,t:1527023396874};\\\", \\\"{x:1348,y:761,t:1527023396889};\\\", \\\"{x:1348,y:760,t:1527023396898};\\\", \\\"{x:1347,y:760,t:1527023399970};\\\", \\\"{x:1346,y:760,t:1527023399985};\\\", \\\"{x:1345,y:760,t:1527023399999};\\\", \\\"{x:1344,y:761,t:1527023400014};\\\", \\\"{x:1343,y:761,t:1527023400031};\\\", \\\"{x:1343,y:762,t:1527023400049};\\\", \\\"{x:1343,y:764,t:1527023400074};\\\", \\\"{x:1342,y:765,t:1527023400083};\\\", \\\"{x:1341,y:766,t:1527023400099};\\\", \\\"{x:1341,y:767,t:1527023400115};\\\", \\\"{x:1341,y:768,t:1527023400132};\\\", \\\"{x:1340,y:768,t:1527023400202};\\\", \\\"{x:1341,y:768,t:1527023400314};\\\", \\\"{x:1342,y:768,t:1527023400332};\\\", \\\"{x:1342,y:765,t:1527023401634};\\\", \\\"{x:1342,y:754,t:1527023401649};\\\", \\\"{x:1337,y:739,t:1527023401665};\\\", \\\"{x:1332,y:718,t:1527023401683};\\\", \\\"{x:1327,y:699,t:1527023401700};\\\", \\\"{x:1324,y:679,t:1527023401716};\\\", \\\"{x:1323,y:665,t:1527023401733};\\\", \\\"{x:1321,y:651,t:1527023401750};\\\", \\\"{x:1319,y:639,t:1527023401766};\\\", \\\"{x:1316,y:626,t:1527023401783};\\\", \\\"{x:1312,y:609,t:1527023401800};\\\", \\\"{x:1306,y:589,t:1527023401817};\\\", \\\"{x:1302,y:572,t:1527023401833};\\\", \\\"{x:1301,y:567,t:1527023401849};\\\", \\\"{x:1300,y:566,t:1527023401922};\\\", \\\"{x:1299,y:566,t:1527023402026};\\\", \\\"{x:1298,y:566,t:1527023402034};\\\", \\\"{x:1296,y:566,t:1527023402049};\\\", \\\"{x:1294,y:567,t:1527023402066};\\\", \\\"{x:1293,y:568,t:1527023402082};\\\", \\\"{x:1292,y:568,t:1527023402337};\\\", \\\"{x:1291,y:568,t:1527023402393};\\\", \\\"{x:1290,y:569,t:1527023402529};\\\", \\\"{x:1288,y:569,t:1527023402578};\\\", \\\"{x:1288,y:570,t:1527023402586};\\\", \\\"{x:1287,y:571,t:1527023402601};\\\", \\\"{x:1286,y:571,t:1527023402890};\\\", \\\"{x:1285,y:571,t:1527023404074};\\\", \\\"{x:1284,y:571,t:1527023404090};\\\", \\\"{x:1283,y:572,t:1527023404105};\\\", \\\"{x:1281,y:573,t:1527023404122};\\\", \\\"{x:1281,y:574,t:1527023404178};\\\", \\\"{x:1280,y:574,t:1527023404322};\\\", \\\"{x:1279,y:575,t:1527023404345};\\\", \\\"{x:1279,y:576,t:1527023404370};\\\", \\\"{x:1278,y:577,t:1527023404402};\\\", \\\"{x:1278,y:578,t:1527023404425};\\\", \\\"{x:1277,y:578,t:1527023404466};\\\", \\\"{x:1277,y:579,t:1527023404506};\\\", \\\"{x:1277,y:580,t:1527023404522};\\\", \\\"{x:1276,y:582,t:1527023404537};\\\", \\\"{x:1276,y:583,t:1527023404552};\\\", \\\"{x:1274,y:586,t:1527023404569};\\\", \\\"{x:1273,y:589,t:1527023404586};\\\", \\\"{x:1271,y:597,t:1527023404601};\\\", \\\"{x:1269,y:606,t:1527023404619};\\\", \\\"{x:1266,y:614,t:1527023404636};\\\", \\\"{x:1265,y:619,t:1527023404652};\\\", \\\"{x:1262,y:626,t:1527023404669};\\\", \\\"{x:1262,y:630,t:1527023404686};\\\", \\\"{x:1260,y:636,t:1527023404702};\\\", \\\"{x:1258,y:641,t:1527023404720};\\\", \\\"{x:1257,y:646,t:1527023404735};\\\", \\\"{x:1256,y:649,t:1527023404752};\\\", \\\"{x:1255,y:653,t:1527023404769};\\\", \\\"{x:1253,y:660,t:1527023404786};\\\", \\\"{x:1251,y:665,t:1527023404802};\\\", \\\"{x:1249,y:672,t:1527023404819};\\\", \\\"{x:1248,y:676,t:1527023404836};\\\", \\\"{x:1247,y:681,t:1527023404852};\\\", \\\"{x:1245,y:684,t:1527023404869};\\\", \\\"{x:1245,y:689,t:1527023404885};\\\", \\\"{x:1243,y:692,t:1527023404902};\\\", \\\"{x:1243,y:694,t:1527023404919};\\\", \\\"{x:1242,y:696,t:1527023404937};\\\", \\\"{x:1242,y:697,t:1527023404952};\\\", \\\"{x:1242,y:698,t:1527023404969};\\\", \\\"{x:1241,y:700,t:1527023404986};\\\", \\\"{x:1240,y:703,t:1527023405002};\\\", \\\"{x:1239,y:707,t:1527023405019};\\\", \\\"{x:1236,y:715,t:1527023405035};\\\", \\\"{x:1233,y:722,t:1527023405052};\\\", \\\"{x:1230,y:730,t:1527023405069};\\\", \\\"{x:1228,y:734,t:1527023405086};\\\", \\\"{x:1226,y:739,t:1527023405102};\\\", \\\"{x:1225,y:744,t:1527023405118};\\\", \\\"{x:1223,y:747,t:1527023405136};\\\", \\\"{x:1222,y:747,t:1527023405152};\\\", \\\"{x:1222,y:749,t:1527023405168};\\\", \\\"{x:1222,y:750,t:1527023405193};\\\", \\\"{x:1222,y:751,t:1527023405201};\\\", \\\"{x:1221,y:752,t:1527023405257};\\\", \\\"{x:1221,y:753,t:1527023405289};\\\", \\\"{x:1220,y:754,t:1527023405302};\\\", \\\"{x:1219,y:754,t:1527023405319};\\\", \\\"{x:1219,y:756,t:1527023405336};\\\", \\\"{x:1218,y:757,t:1527023405353};\\\", \\\"{x:1217,y:758,t:1527023405378};\\\", \\\"{x:1216,y:758,t:1527023405386};\\\", \\\"{x:1215,y:760,t:1527023405402};\\\", \\\"{x:1214,y:761,t:1527023405419};\\\", \\\"{x:1213,y:761,t:1527023405441};\\\", \\\"{x:1211,y:762,t:1527023405482};\\\", \\\"{x:1211,y:763,t:1527023405489};\\\", \\\"{x:1210,y:763,t:1527023405506};\\\", \\\"{x:1210,y:764,t:1527023405586};\\\", \\\"{x:1209,y:764,t:1527023405604};\\\", \\\"{x:1208,y:765,t:1527023405619};\\\", \\\"{x:1207,y:765,t:1527023405658};\\\", \\\"{x:1206,y:766,t:1527023405682};\\\", \\\"{x:1205,y:766,t:1527023405690};\\\", \\\"{x:1204,y:766,t:1527023405721};\\\", \\\"{x:1204,y:767,t:1527023405770};\\\", \\\"{x:1203,y:767,t:1527023405794};\\\", \\\"{x:1202,y:767,t:1527023405882};\\\", \\\"{x:1201,y:768,t:1527023405913};\\\", \\\"{x:1200,y:768,t:1527023405953};\\\", \\\"{x:1199,y:768,t:1527023405969};\\\", \\\"{x:1199,y:769,t:1527023405985};\\\", \\\"{x:1198,y:769,t:1527023406024};\\\", \\\"{x:1198,y:770,t:1527023406057};\\\", \\\"{x:1197,y:770,t:1527023406081};\\\", \\\"{x:1196,y:770,t:1527023412019};\\\", \\\"{x:1195,y:771,t:1527023412025};\\\", \\\"{x:1194,y:771,t:1527023412073};\\\", \\\"{x:1193,y:771,t:1527023412105};\\\", \\\"{x:1192,y:772,t:1527023412169};\\\", \\\"{x:1191,y:772,t:1527023412201};\\\", \\\"{x:1190,y:772,t:1527023412208};\\\", \\\"{x:1189,y:772,t:1527023412249};\\\", \\\"{x:1188,y:772,t:1527023412297};\\\", \\\"{x:1187,y:771,t:1527023412386};\\\", \\\"{x:1187,y:770,t:1527023417234};\\\", \\\"{x:1187,y:769,t:1527023417266};\\\", \\\"{x:1188,y:767,t:1527023417370};\\\", \\\"{x:1189,y:767,t:1527023417441};\\\", \\\"{x:1190,y:766,t:1527023417457};\\\", \\\"{x:1191,y:766,t:1527023417472};\\\", \\\"{x:1192,y:766,t:1527023417513};\\\", \\\"{x:1192,y:765,t:1527023417529};\\\", \\\"{x:1194,y:764,t:1527023417576};\\\", \\\"{x:1195,y:764,t:1527023417657};\\\", \\\"{x:1196,y:764,t:1527023419785};\\\", \\\"{x:1198,y:767,t:1527023419798};\\\", \\\"{x:1205,y:779,t:1527023419814};\\\", \\\"{x:1210,y:787,t:1527023419831};\\\", \\\"{x:1211,y:790,t:1527023419847};\\\", \\\"{x:1211,y:791,t:1527023419863};\\\", \\\"{x:1212,y:791,t:1527023419880};\\\", \\\"{x:1213,y:792,t:1527023419897};\\\", \\\"{x:1213,y:793,t:1527023419914};\\\", \\\"{x:1214,y:794,t:1527023419930};\\\", \\\"{x:1215,y:797,t:1527023419947};\\\", \\\"{x:1217,y:801,t:1527023419964};\\\", \\\"{x:1218,y:806,t:1527023419980};\\\", \\\"{x:1219,y:808,t:1527023419997};\\\", \\\"{x:1220,y:810,t:1527023420014};\\\", \\\"{x:1221,y:812,t:1527023420029};\\\", \\\"{x:1221,y:814,t:1527023420047};\\\", \\\"{x:1224,y:818,t:1527023420064};\\\", \\\"{x:1224,y:820,t:1527023420080};\\\", \\\"{x:1224,y:821,t:1527023420104};\\\", \\\"{x:1224,y:822,t:1527023420114};\\\", \\\"{x:1224,y:823,t:1527023420130};\\\", \\\"{x:1224,y:825,t:1527023420147};\\\", \\\"{x:1224,y:826,t:1527023420169};\\\", \\\"{x:1224,y:827,t:1527023420274};\\\", \\\"{x:1224,y:828,t:1527023420297};\\\", \\\"{x:1225,y:830,t:1527023420315};\\\", \\\"{x:1226,y:832,t:1527023420338};\\\", \\\"{x:1226,y:833,t:1527023420370};\\\", \\\"{x:1227,y:833,t:1527023420382};\\\", \\\"{x:1227,y:834,t:1527023420397};\\\", \\\"{x:1229,y:835,t:1527023420415};\\\", \\\"{x:1233,y:837,t:1527023420431};\\\", \\\"{x:1234,y:837,t:1527023420448};\\\", \\\"{x:1235,y:837,t:1527023420465};\\\", \\\"{x:1234,y:836,t:1527023420801};\\\", \\\"{x:1233,y:836,t:1527023420814};\\\", \\\"{x:1230,y:835,t:1527023420831};\\\", \\\"{x:1229,y:835,t:1527023420858};\\\", \\\"{x:1228,y:834,t:1527023420970};\\\", \\\"{x:1227,y:834,t:1527023421034};\\\", \\\"{x:1227,y:833,t:1527023421057};\\\", \\\"{x:1227,y:832,t:1527023421161};\\\", \\\"{x:1227,y:831,t:1527023423033};\\\", \\\"{x:1227,y:830,t:1527023423050};\\\", \\\"{x:1227,y:828,t:1527023427018};\\\", \\\"{x:1228,y:827,t:1527023427057};\\\", \\\"{x:1229,y:826,t:1527023427130};\\\", \\\"{x:1229,y:825,t:1527023427145};\\\", \\\"{x:1230,y:825,t:1527023427185};\\\", \\\"{x:1230,y:824,t:1527023427194};\\\", \\\"{x:1231,y:824,t:1527023427225};\\\", \\\"{x:1232,y:822,t:1527023427241};\\\", \\\"{x:1233,y:822,t:1527023427258};\\\", \\\"{x:1234,y:821,t:1527023427271};\\\", \\\"{x:1235,y:820,t:1527023427286};\\\", \\\"{x:1236,y:819,t:1527023427304};\\\", \\\"{x:1239,y:817,t:1527023427320};\\\", \\\"{x:1242,y:814,t:1527023427337};\\\", \\\"{x:1254,y:805,t:1527023427354};\\\", \\\"{x:1266,y:791,t:1527023427370};\\\", \\\"{x:1279,y:777,t:1527023427387};\\\", \\\"{x:1291,y:762,t:1527023427404};\\\", \\\"{x:1297,y:753,t:1527023427421};\\\", \\\"{x:1301,y:747,t:1527023427438};\\\", \\\"{x:1308,y:730,t:1527023427454};\\\", \\\"{x:1317,y:704,t:1527023427470};\\\", \\\"{x:1323,y:679,t:1527023427487};\\\", \\\"{x:1329,y:660,t:1527023427504};\\\", \\\"{x:1333,y:648,t:1527023427521};\\\", \\\"{x:1333,y:638,t:1527023427537};\\\", \\\"{x:1333,y:635,t:1527023427554};\\\", \\\"{x:1333,y:633,t:1527023427570};\\\", \\\"{x:1332,y:630,t:1527023427587};\\\", \\\"{x:1329,y:622,t:1527023427604};\\\", \\\"{x:1326,y:617,t:1527023427620};\\\", \\\"{x:1323,y:612,t:1527023427639};\\\", \\\"{x:1321,y:606,t:1527023427655};\\\", \\\"{x:1319,y:603,t:1527023427670};\\\", \\\"{x:1316,y:599,t:1527023427687};\\\", \\\"{x:1314,y:597,t:1527023427704};\\\", \\\"{x:1313,y:596,t:1527023427722};\\\", \\\"{x:1313,y:595,t:1527023427737};\\\", \\\"{x:1312,y:595,t:1527023427754};\\\", \\\"{x:1310,y:594,t:1527023427771};\\\", \\\"{x:1309,y:594,t:1527023427787};\\\", \\\"{x:1306,y:591,t:1527023427804};\\\", \\\"{x:1300,y:587,t:1527023427821};\\\", \\\"{x:1292,y:581,t:1527023427838};\\\", \\\"{x:1283,y:575,t:1527023427854};\\\", \\\"{x:1279,y:571,t:1527023427871};\\\", \\\"{x:1273,y:564,t:1527023427887};\\\", \\\"{x:1271,y:561,t:1527023427904};\\\", \\\"{x:1270,y:561,t:1527023427921};\\\", \\\"{x:1269,y:560,t:1527023427986};\\\", \\\"{x:1267,y:560,t:1527023443277};\\\", \\\"{x:1266,y:560,t:1527023443293};\\\", \\\"{x:1263,y:562,t:1527023444189};\\\", \\\"{x:1260,y:563,t:1527023444204};\\\", \\\"{x:1251,y:567,t:1527023444221};\\\", \\\"{x:1229,y:571,t:1527023444237};\\\", \\\"{x:1179,y:571,t:1527023444254};\\\", \\\"{x:1120,y:562,t:1527023444270};\\\", \\\"{x:1039,y:553,t:1527023444287};\\\", \\\"{x:953,y:540,t:1527023444304};\\\", \\\"{x:884,y:533,t:1527023444322};\\\", \\\"{x:845,y:529,t:1527023444336};\\\", \\\"{x:833,y:529,t:1527023444354};\\\", \\\"{x:828,y:529,t:1527023444370};\\\", \\\"{x:806,y:529,t:1527023444388};\\\", \\\"{x:772,y:529,t:1527023444404};\\\", \\\"{x:738,y:528,t:1527023444421};\\\", \\\"{x:704,y:522,t:1527023444438};\\\", \\\"{x:669,y:517,t:1527023444454};\\\", \\\"{x:651,y:514,t:1527023444471};\\\", \\\"{x:647,y:514,t:1527023444487};\\\", \\\"{x:641,y:514,t:1527023444548};\\\", \\\"{x:628,y:514,t:1527023444556};\\\", \\\"{x:613,y:514,t:1527023444570};\\\", \\\"{x:582,y:510,t:1527023444588};\\\", \\\"{x:579,y:509,t:1527023444605};\\\", \\\"{x:579,y:506,t:1527023444741};\\\", \\\"{x:585,y:502,t:1527023444754};\\\", \\\"{x:598,y:496,t:1527023444770};\\\", \\\"{x:606,y:491,t:1527023444788};\\\", \\\"{x:607,y:490,t:1527023444805};\\\", \\\"{x:609,y:490,t:1527023444821};\\\", \\\"{x:610,y:489,t:1527023444838};\\\", \\\"{x:612,y:488,t:1527023444869};\\\", \\\"{x:613,y:488,t:1527023444884};\\\", \\\"{x:614,y:488,t:1527023445260};\\\", \\\"{x:613,y:491,t:1527023445273};\\\", \\\"{x:611,y:499,t:1527023445287};\\\", \\\"{x:610,y:501,t:1527023445304};\\\", \\\"{x:610,y:503,t:1527023445322};\\\", \\\"{x:610,y:505,t:1527023445338};\\\", \\\"{x:609,y:505,t:1527023445355};\\\", \\\"{x:608,y:509,t:1527023445676};\\\", \\\"{x:603,y:516,t:1527023445688};\\\", \\\"{x:598,y:530,t:1527023445705};\\\", \\\"{x:595,y:543,t:1527023445722};\\\", \\\"{x:590,y:561,t:1527023445739};\\\", \\\"{x:582,y:585,t:1527023445755};\\\", \\\"{x:571,y:625,t:1527023445772};\\\", \\\"{x:564,y:646,t:1527023445789};\\\", \\\"{x:558,y:661,t:1527023445805};\\\", \\\"{x:555,y:671,t:1527023445822};\\\", \\\"{x:549,y:687,t:1527023445839};\\\", \\\"{x:543,y:704,t:1527023445855};\\\", \\\"{x:536,y:719,t:1527023445872};\\\", \\\"{x:531,y:731,t:1527023445889};\\\", \\\"{x:526,y:741,t:1527023445905};\\\", \\\"{x:522,y:748,t:1527023445922};\\\", \\\"{x:517,y:757,t:1527023445939};\\\", \\\"{x:508,y:767,t:1527023445956};\\\", \\\"{x:506,y:769,t:1527023445971};\\\", \\\"{x:506,y:765,t:1527023446220};\\\", \\\"{x:506,y:761,t:1527023446227};\\\", \\\"{x:506,y:758,t:1527023446238};\\\", \\\"{x:506,y:755,t:1527023446256};\\\", \\\"{x:506,y:754,t:1527023446273};\\\", \\\"{x:507,y:752,t:1527023446356};\\\", \\\"{x:507,y:751,t:1527023446380};\\\" ] }, { \\\"rt\\\": 24999, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 332119, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"OZV09\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-C -J -J -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:750,t:1527023449843};\\\", \\\"{x:510,y:750,t:1527023449859};\\\", \\\"{x:516,y:749,t:1527023449876};\\\", \\\"{x:520,y:747,t:1527023449893};\\\", \\\"{x:521,y:747,t:1527023449909};\\\", \\\"{x:530,y:747,t:1527023449926};\\\", \\\"{x:546,y:751,t:1527023449943};\\\", \\\"{x:568,y:754,t:1527023449959};\\\", \\\"{x:590,y:757,t:1527023449976};\\\", \\\"{x:611,y:760,t:1527023449993};\\\", \\\"{x:634,y:764,t:1527023450008};\\\", \\\"{x:684,y:773,t:1527023450024};\\\", \\\"{x:760,y:788,t:1527023450042};\\\", \\\"{x:860,y:799,t:1527023450059};\\\", \\\"{x:962,y:813,t:1527023450075};\\\", \\\"{x:1110,y:833,t:1527023450092};\\\", \\\"{x:1206,y:840,t:1527023450109};\\\", \\\"{x:1301,y:842,t:1527023450126};\\\", \\\"{x:1412,y:842,t:1527023450142};\\\", \\\"{x:1514,y:817,t:1527023450158};\\\", \\\"{x:1639,y:757,t:1527023450176};\\\", \\\"{x:1774,y:661,t:1527023450192};\\\", \\\"{x:1911,y:527,t:1527023450209};\\\", \\\"{x:1919,y:376,t:1527023450225};\\\", \\\"{x:1919,y:254,t:1527023450242};\\\", \\\"{x:1919,y:162,t:1527023450259};\\\", \\\"{x:1915,y:55,t:1527023450275};\\\", \\\"{x:1864,y:0,t:1527023450291};\\\", \\\"{x:1755,y:0,t:1527023450309};\\\", \\\"{x:1587,y:0,t:1527023450325};\\\", \\\"{x:1390,y:0,t:1527023450341};\\\", \\\"{x:1233,y:0,t:1527023450359};\\\", \\\"{x:1131,y:0,t:1527023450376};\\\", \\\"{x:1088,y:0,t:1527023450392};\\\", \\\"{x:1072,y:0,t:1527023450408};\\\", \\\"{x:1048,y:13,t:1527023450426};\\\", \\\"{x:1012,y:44,t:1527023450442};\\\", \\\"{x:969,y:111,t:1527023450459};\\\", \\\"{x:941,y:210,t:1527023450475};\\\", \\\"{x:940,y:272,t:1527023450492};\\\", \\\"{x:940,y:339,t:1527023450508};\\\", \\\"{x:969,y:424,t:1527023450526};\\\", \\\"{x:1033,y:518,t:1527023450542};\\\", \\\"{x:1127,y:618,t:1527023450558};\\\", \\\"{x:1252,y:712,t:1527023450576};\\\", \\\"{x:1418,y:790,t:1527023450592};\\\", \\\"{x:1595,y:846,t:1527023450609};\\\", \\\"{x:1772,y:894,t:1527023450626};\\\", \\\"{x:1910,y:937,t:1527023450642};\\\", \\\"{x:1919,y:968,t:1527023450659};\\\", \\\"{x:1919,y:1000,t:1527023450675};\\\", \\\"{x:1919,y:1009,t:1527023450692};\\\", \\\"{x:1919,y:1017,t:1527023450708};\\\", \\\"{x:1919,y:1026,t:1527023450726};\\\", \\\"{x:1919,y:1037,t:1527023450742};\\\", \\\"{x:1919,y:1052,t:1527023450759};\\\", \\\"{x:1919,y:1063,t:1527023450776};\\\", \\\"{x:1919,y:1075,t:1527023450792};\\\", \\\"{x:1919,y:1082,t:1527023450809};\\\", \\\"{x:1915,y:1091,t:1527023450826};\\\", \\\"{x:1905,y:1101,t:1527023450844};\\\", \\\"{x:1892,y:1109,t:1527023450859};\\\", \\\"{x:1872,y:1116,t:1527023450876};\\\", \\\"{x:1861,y:1119,t:1527023450893};\\\", \\\"{x:1846,y:1123,t:1527023450908};\\\", \\\"{x:1826,y:1125,t:1527023450926};\\\", \\\"{x:1810,y:1126,t:1527023450943};\\\", \\\"{x:1799,y:1126,t:1527023450959};\\\", \\\"{x:1791,y:1126,t:1527023450976};\\\", \\\"{x:1783,y:1126,t:1527023450993};\\\", \\\"{x:1762,y:1123,t:1527023451010};\\\", \\\"{x:1745,y:1122,t:1527023451026};\\\", \\\"{x:1735,y:1118,t:1527023451043};\\\", \\\"{x:1726,y:1114,t:1527023451060};\\\", \\\"{x:1723,y:1113,t:1527023451075};\\\", \\\"{x:1718,y:1112,t:1527023451093};\\\", \\\"{x:1709,y:1109,t:1527023451110};\\\", \\\"{x:1705,y:1107,t:1527023451126};\\\", \\\"{x:1702,y:1104,t:1527023451143};\\\", \\\"{x:1700,y:1103,t:1527023451160};\\\", \\\"{x:1700,y:1102,t:1527023451176};\\\", \\\"{x:1699,y:1099,t:1527023451193};\\\", \\\"{x:1697,y:1096,t:1527023451210};\\\", \\\"{x:1694,y:1093,t:1527023451226};\\\", \\\"{x:1693,y:1092,t:1527023451243};\\\", \\\"{x:1693,y:1089,t:1527023451259};\\\", \\\"{x:1692,y:1088,t:1527023451293};\\\", \\\"{x:1691,y:1087,t:1527023451311};\\\", \\\"{x:1690,y:1086,t:1527023451326};\\\", \\\"{x:1688,y:1084,t:1527023451348};\\\", \\\"{x:1688,y:1083,t:1527023451372};\\\", \\\"{x:1688,y:1082,t:1527023451397};\\\", \\\"{x:1687,y:1082,t:1527023451410};\\\", \\\"{x:1685,y:1080,t:1527023451427};\\\", \\\"{x:1681,y:1078,t:1527023451443};\\\", \\\"{x:1678,y:1077,t:1527023451461};\\\", \\\"{x:1677,y:1076,t:1527023451509};\\\", \\\"{x:1677,y:1075,t:1527023451565};\\\", \\\"{x:1677,y:1074,t:1527023451580};\\\", \\\"{x:1677,y:1073,t:1527023451629};\\\", \\\"{x:1677,y:1072,t:1527023451693};\\\", \\\"{x:1675,y:1070,t:1527023452253};\\\", \\\"{x:1674,y:1070,t:1527023452276};\\\", \\\"{x:1671,y:1070,t:1527023452294};\\\", \\\"{x:1667,y:1069,t:1527023452309};\\\", \\\"{x:1662,y:1068,t:1527023452327};\\\", \\\"{x:1661,y:1068,t:1527023452344};\\\", \\\"{x:1659,y:1067,t:1527023452361};\\\", \\\"{x:1655,y:1067,t:1527023452376};\\\", \\\"{x:1650,y:1067,t:1527023452394};\\\", \\\"{x:1645,y:1067,t:1527023452411};\\\", \\\"{x:1645,y:1066,t:1527023452427};\\\", \\\"{x:1642,y:1066,t:1527023452444};\\\", \\\"{x:1641,y:1066,t:1527023452461};\\\", \\\"{x:1638,y:1063,t:1527023452477};\\\", \\\"{x:1632,y:1061,t:1527023452494};\\\", \\\"{x:1620,y:1056,t:1527023452510};\\\", \\\"{x:1610,y:1051,t:1527023452527};\\\", \\\"{x:1592,y:1044,t:1527023452544};\\\", \\\"{x:1575,y:1038,t:1527023452561};\\\", \\\"{x:1557,y:1035,t:1527023452577};\\\", \\\"{x:1540,y:1032,t:1527023452594};\\\", \\\"{x:1530,y:1031,t:1527023452612};\\\", \\\"{x:1529,y:1030,t:1527023452709};\\\", \\\"{x:1529,y:1029,t:1527023452717};\\\", \\\"{x:1529,y:1026,t:1527023452728};\\\", \\\"{x:1529,y:1021,t:1527023452745};\\\", \\\"{x:1531,y:1016,t:1527023452761};\\\", \\\"{x:1533,y:1010,t:1527023452777};\\\", \\\"{x:1538,y:1000,t:1527023452794};\\\", \\\"{x:1545,y:981,t:1527023452812};\\\", \\\"{x:1548,y:972,t:1527023452827};\\\", \\\"{x:1554,y:959,t:1527023452845};\\\", \\\"{x:1557,y:953,t:1527023452862};\\\", \\\"{x:1559,y:946,t:1527023452878};\\\", \\\"{x:1566,y:936,t:1527023452895};\\\", \\\"{x:1570,y:928,t:1527023452911};\\\", \\\"{x:1577,y:914,t:1527023452928};\\\", \\\"{x:1584,y:896,t:1527023452945};\\\", \\\"{x:1593,y:868,t:1527023452962};\\\", \\\"{x:1601,y:828,t:1527023452978};\\\", \\\"{x:1603,y:802,t:1527023452994};\\\", \\\"{x:1603,y:771,t:1527023453013};\\\", \\\"{x:1603,y:753,t:1527023453029};\\\", \\\"{x:1603,y:736,t:1527023453044};\\\", \\\"{x:1603,y:724,t:1527023453062};\\\", \\\"{x:1601,y:711,t:1527023453078};\\\", \\\"{x:1599,y:702,t:1527023453094};\\\", \\\"{x:1595,y:695,t:1527023453112};\\\", \\\"{x:1592,y:689,t:1527023453128};\\\", \\\"{x:1589,y:685,t:1527023453144};\\\", \\\"{x:1587,y:682,t:1527023453161};\\\", \\\"{x:1583,y:678,t:1527023453179};\\\", \\\"{x:1581,y:677,t:1527023453195};\\\", \\\"{x:1579,y:677,t:1527023453236};\\\", \\\"{x:1578,y:677,t:1527023453261};\\\", \\\"{x:1577,y:677,t:1527023453317};\\\", \\\"{x:1575,y:678,t:1527023453579};\\\", \\\"{x:1574,y:678,t:1527023453595};\\\", \\\"{x:1572,y:679,t:1527023453612};\\\", \\\"{x:1572,y:680,t:1527023453781};\\\", \\\"{x:1572,y:682,t:1527023453796};\\\", \\\"{x:1580,y:696,t:1527023453813};\\\", \\\"{x:1587,y:705,t:1527023453828};\\\", \\\"{x:1597,y:715,t:1527023453846};\\\", \\\"{x:1605,y:723,t:1527023453862};\\\", \\\"{x:1607,y:727,t:1527023453878};\\\", \\\"{x:1609,y:731,t:1527023453895};\\\", \\\"{x:1609,y:733,t:1527023453912};\\\", \\\"{x:1610,y:735,t:1527023453928};\\\", \\\"{x:1610,y:738,t:1527023453945};\\\", \\\"{x:1610,y:740,t:1527023453962};\\\", \\\"{x:1609,y:742,t:1527023453978};\\\", \\\"{x:1607,y:745,t:1527023453995};\\\", \\\"{x:1600,y:752,t:1527023454012};\\\", \\\"{x:1597,y:754,t:1527023454028};\\\", \\\"{x:1594,y:756,t:1527023454045};\\\", \\\"{x:1592,y:757,t:1527023454062};\\\", \\\"{x:1581,y:762,t:1527023454078};\\\", \\\"{x:1567,y:766,t:1527023454095};\\\", \\\"{x:1553,y:769,t:1527023454112};\\\", \\\"{x:1540,y:770,t:1527023454128};\\\", \\\"{x:1525,y:771,t:1527023454145};\\\", \\\"{x:1507,y:771,t:1527023454162};\\\", \\\"{x:1489,y:771,t:1527023454179};\\\", \\\"{x:1473,y:771,t:1527023454195};\\\", \\\"{x:1460,y:771,t:1527023454212};\\\", \\\"{x:1459,y:771,t:1527023454229};\\\", \\\"{x:1458,y:771,t:1527023454309};\\\", \\\"{x:1457,y:771,t:1527023454316};\\\", \\\"{x:1457,y:765,t:1527023454330};\\\", \\\"{x:1454,y:745,t:1527023454346};\\\", \\\"{x:1454,y:722,t:1527023454363};\\\", \\\"{x:1454,y:698,t:1527023454379};\\\", \\\"{x:1456,y:669,t:1527023454394};\\\", \\\"{x:1472,y:617,t:1527023454412};\\\", \\\"{x:1483,y:575,t:1527023454429};\\\", \\\"{x:1499,y:519,t:1527023454445};\\\", \\\"{x:1509,y:481,t:1527023454462};\\\", \\\"{x:1512,y:462,t:1527023454479};\\\", \\\"{x:1518,y:441,t:1527023454495};\\\", \\\"{x:1523,y:420,t:1527023454512};\\\", \\\"{x:1526,y:410,t:1527023454529};\\\", \\\"{x:1527,y:399,t:1527023454545};\\\", \\\"{x:1530,y:387,t:1527023454562};\\\", \\\"{x:1530,y:376,t:1527023454579};\\\", \\\"{x:1530,y:358,t:1527023454596};\\\", \\\"{x:1530,y:349,t:1527023454612};\\\", \\\"{x:1528,y:344,t:1527023454629};\\\", \\\"{x:1526,y:340,t:1527023454646};\\\", \\\"{x:1525,y:337,t:1527023454663};\\\", \\\"{x:1524,y:336,t:1527023454680};\\\", \\\"{x:1523,y:334,t:1527023454697};\\\", \\\"{x:1522,y:333,t:1527023454713};\\\", \\\"{x:1521,y:331,t:1527023454730};\\\", \\\"{x:1517,y:331,t:1527023454745};\\\", \\\"{x:1514,y:331,t:1527023454763};\\\", \\\"{x:1510,y:331,t:1527023454780};\\\", \\\"{x:1506,y:333,t:1527023454796};\\\", \\\"{x:1502,y:337,t:1527023454812};\\\", \\\"{x:1495,y:350,t:1527023454829};\\\", \\\"{x:1486,y:370,t:1527023454846};\\\", \\\"{x:1479,y:389,t:1527023454862};\\\", \\\"{x:1473,y:407,t:1527023454880};\\\", \\\"{x:1469,y:424,t:1527023454897};\\\", \\\"{x:1468,y:438,t:1527023454912};\\\", \\\"{x:1467,y:447,t:1527023454930};\\\", \\\"{x:1467,y:458,t:1527023454946};\\\", \\\"{x:1467,y:473,t:1527023454963};\\\", \\\"{x:1467,y:492,t:1527023454979};\\\", \\\"{x:1465,y:516,t:1527023454997};\\\", \\\"{x:1465,y:527,t:1527023455013};\\\", \\\"{x:1465,y:533,t:1527023455030};\\\", \\\"{x:1465,y:542,t:1527023455047};\\\", \\\"{x:1465,y:549,t:1527023455063};\\\", \\\"{x:1465,y:553,t:1527023455080};\\\", \\\"{x:1465,y:559,t:1527023455096};\\\", \\\"{x:1465,y:560,t:1527023455113};\\\", \\\"{x:1465,y:562,t:1527023455130};\\\", \\\"{x:1465,y:563,t:1527023455147};\\\", \\\"{x:1465,y:565,t:1527023455164};\\\", \\\"{x:1465,y:566,t:1527023455253};\\\", \\\"{x:1465,y:567,t:1527023455605};\\\", \\\"{x:1467,y:568,t:1527023455613};\\\", \\\"{x:1470,y:569,t:1527023455631};\\\", \\\"{x:1474,y:570,t:1527023455647};\\\", \\\"{x:1480,y:572,t:1527023455664};\\\", \\\"{x:1483,y:572,t:1527023455681};\\\", \\\"{x:1486,y:573,t:1527023455697};\\\", \\\"{x:1487,y:573,t:1527023455714};\\\", \\\"{x:1487,y:574,t:1527023455748};\\\", \\\"{x:1489,y:574,t:1527023455764};\\\", \\\"{x:1489,y:576,t:1527023455781};\\\", \\\"{x:1492,y:576,t:1527023455796};\\\", \\\"{x:1493,y:577,t:1527023455813};\\\", \\\"{x:1495,y:577,t:1527023455861};\\\", \\\"{x:1496,y:577,t:1527023455892};\\\", \\\"{x:1497,y:577,t:1527023455901};\\\", \\\"{x:1499,y:576,t:1527023455914};\\\", \\\"{x:1502,y:575,t:1527023455931};\\\", \\\"{x:1503,y:574,t:1527023455946};\\\", \\\"{x:1504,y:574,t:1527023455963};\\\", \\\"{x:1504,y:573,t:1527023455988};\\\", \\\"{x:1505,y:572,t:1527023455998};\\\", \\\"{x:1509,y:569,t:1527023456013};\\\", \\\"{x:1511,y:563,t:1527023456031};\\\", \\\"{x:1515,y:556,t:1527023456048};\\\", \\\"{x:1520,y:544,t:1527023456063};\\\", \\\"{x:1524,y:534,t:1527023456081};\\\", \\\"{x:1529,y:518,t:1527023456097};\\\", \\\"{x:1530,y:508,t:1527023456114};\\\", \\\"{x:1530,y:502,t:1527023456131};\\\", \\\"{x:1530,y:498,t:1527023456148};\\\", \\\"{x:1530,y:496,t:1527023456164};\\\", \\\"{x:1530,y:493,t:1527023456180};\\\", \\\"{x:1530,y:491,t:1527023456198};\\\", \\\"{x:1527,y:492,t:1527023456541};\\\", \\\"{x:1524,y:495,t:1527023456548};\\\", \\\"{x:1514,y:501,t:1527023456565};\\\", \\\"{x:1508,y:505,t:1527023456580};\\\", \\\"{x:1505,y:508,t:1527023456598};\\\", \\\"{x:1502,y:511,t:1527023456614};\\\", \\\"{x:1501,y:512,t:1527023456631};\\\", \\\"{x:1500,y:514,t:1527023456648};\\\", \\\"{x:1498,y:516,t:1527023456664};\\\", \\\"{x:1497,y:519,t:1527023456681};\\\", \\\"{x:1493,y:525,t:1527023456698};\\\", \\\"{x:1488,y:533,t:1527023456715};\\\", \\\"{x:1485,y:540,t:1527023456731};\\\", \\\"{x:1481,y:548,t:1527023456747};\\\", \\\"{x:1475,y:564,t:1527023456765};\\\", \\\"{x:1470,y:574,t:1527023456782};\\\", \\\"{x:1464,y:588,t:1527023456798};\\\", \\\"{x:1456,y:604,t:1527023456815};\\\", \\\"{x:1449,y:618,t:1527023456831};\\\", \\\"{x:1438,y:636,t:1527023456849};\\\", \\\"{x:1431,y:653,t:1527023456865};\\\", \\\"{x:1424,y:673,t:1527023456882};\\\", \\\"{x:1414,y:693,t:1527023456898};\\\", \\\"{x:1407,y:710,t:1527023456915};\\\", \\\"{x:1389,y:739,t:1527023456933};\\\", \\\"{x:1374,y:757,t:1527023456948};\\\", \\\"{x:1363,y:772,t:1527023456964};\\\", \\\"{x:1355,y:781,t:1527023456982};\\\", \\\"{x:1350,y:787,t:1527023456998};\\\", \\\"{x:1341,y:796,t:1527023457015};\\\", \\\"{x:1333,y:803,t:1527023457032};\\\", \\\"{x:1320,y:814,t:1527023457048};\\\", \\\"{x:1305,y:821,t:1527023457065};\\\", \\\"{x:1301,y:824,t:1527023457082};\\\", \\\"{x:1299,y:824,t:1527023457098};\\\", \\\"{x:1298,y:824,t:1527023457125};\\\", \\\"{x:1297,y:825,t:1527023457132};\\\", \\\"{x:1296,y:825,t:1527023457148};\\\", \\\"{x:1294,y:826,t:1527023457164};\\\", \\\"{x:1293,y:826,t:1527023457182};\\\", \\\"{x:1293,y:827,t:1527023457198};\\\", \\\"{x:1291,y:827,t:1527023457215};\\\", \\\"{x:1285,y:830,t:1527023457232};\\\", \\\"{x:1274,y:830,t:1527023457249};\\\", \\\"{x:1264,y:833,t:1527023457265};\\\", \\\"{x:1258,y:833,t:1527023457281};\\\", \\\"{x:1255,y:834,t:1527023457299};\\\", \\\"{x:1251,y:836,t:1527023457315};\\\", \\\"{x:1248,y:837,t:1527023457332};\\\", \\\"{x:1244,y:838,t:1527023457349};\\\", \\\"{x:1243,y:838,t:1527023457372};\\\", \\\"{x:1242,y:840,t:1527023457389};\\\", \\\"{x:1241,y:840,t:1527023457486};\\\", \\\"{x:1240,y:840,t:1527023457499};\\\", \\\"{x:1236,y:841,t:1527023457514};\\\", \\\"{x:1230,y:841,t:1527023457532};\\\", \\\"{x:1225,y:841,t:1527023457549};\\\", \\\"{x:1224,y:841,t:1527023457597};\\\", \\\"{x:1223,y:840,t:1527023457627};\\\", \\\"{x:1222,y:839,t:1527023457652};\\\", \\\"{x:1221,y:837,t:1527023457667};\\\", \\\"{x:1221,y:836,t:1527023457684};\\\", \\\"{x:1220,y:836,t:1527023457698};\\\", \\\"{x:1220,y:835,t:1527023457715};\\\", \\\"{x:1220,y:834,t:1527023457731};\\\", \\\"{x:1219,y:833,t:1527023457749};\\\", \\\"{x:1218,y:829,t:1527023457765};\\\", \\\"{x:1214,y:823,t:1527023457781};\\\", \\\"{x:1211,y:817,t:1527023457798};\\\", \\\"{x:1209,y:813,t:1527023457815};\\\", \\\"{x:1207,y:807,t:1527023457831};\\\", \\\"{x:1203,y:800,t:1527023457848};\\\", \\\"{x:1202,y:796,t:1527023457866};\\\", \\\"{x:1201,y:794,t:1527023457881};\\\", \\\"{x:1199,y:792,t:1527023457898};\\\", \\\"{x:1199,y:791,t:1527023457915};\\\", \\\"{x:1198,y:790,t:1527023457931};\\\", \\\"{x:1197,y:789,t:1527023457948};\\\", \\\"{x:1196,y:788,t:1527023457972};\\\", \\\"{x:1196,y:787,t:1527023457982};\\\", \\\"{x:1194,y:783,t:1527023457999};\\\", \\\"{x:1193,y:782,t:1527023458015};\\\", \\\"{x:1193,y:781,t:1527023458031};\\\", \\\"{x:1193,y:780,t:1527023458996};\\\", \\\"{x:1193,y:779,t:1527023459004};\\\", \\\"{x:1193,y:778,t:1527023459020};\\\", \\\"{x:1193,y:777,t:1527023459109};\\\", \\\"{x:1192,y:776,t:1527023459245};\\\", \\\"{x:1192,y:775,t:1527023459293};\\\", \\\"{x:1192,y:774,t:1527023459308};\\\", \\\"{x:1192,y:773,t:1527023459332};\\\", \\\"{x:1192,y:772,t:1527023459669};\\\", \\\"{x:1192,y:771,t:1527023459684};\\\", \\\"{x:1192,y:770,t:1527023459700};\\\", \\\"{x:1192,y:769,t:1527023459716};\\\", \\\"{x:1192,y:767,t:1527023459734};\\\", \\\"{x:1191,y:766,t:1527023459750};\\\", \\\"{x:1190,y:764,t:1527023459773};\\\", \\\"{x:1190,y:763,t:1527023459861};\\\", \\\"{x:1189,y:762,t:1527023459924};\\\", \\\"{x:1188,y:762,t:1527023459939};\\\", \\\"{x:1187,y:762,t:1527023459963};\\\", \\\"{x:1186,y:762,t:1527023460532};\\\", \\\"{x:1185,y:762,t:1527023460572};\\\", \\\"{x:1184,y:762,t:1527023460595};\\\", \\\"{x:1183,y:762,t:1527023460651};\\\", \\\"{x:1182,y:762,t:1527023460692};\\\", \\\"{x:1181,y:762,t:1527023460772};\\\", \\\"{x:1180,y:762,t:1527023460829};\\\", \\\"{x:1179,y:762,t:1527023460836};\\\", \\\"{x:1178,y:762,t:1527023460884};\\\", \\\"{x:1177,y:763,t:1527023460908};\\\", \\\"{x:1176,y:763,t:1527023460932};\\\", \\\"{x:1175,y:763,t:1527023461004};\\\", \\\"{x:1175,y:764,t:1527023461018};\\\", \\\"{x:1174,y:764,t:1527023461077};\\\", \\\"{x:1174,y:766,t:1527023462844};\\\", \\\"{x:1173,y:766,t:1527023463309};\\\", \\\"{x:1172,y:767,t:1527023463372};\\\", \\\"{x:1169,y:767,t:1527023463837};\\\", \\\"{x:1150,y:746,t:1527023463853};\\\", \\\"{x:1119,y:718,t:1527023463870};\\\", \\\"{x:1079,y:689,t:1527023463887};\\\", \\\"{x:1028,y:663,t:1527023463903};\\\", \\\"{x:980,y:637,t:1527023463919};\\\", \\\"{x:950,y:621,t:1527023463938};\\\", \\\"{x:928,y:611,t:1527023463954};\\\", \\\"{x:919,y:605,t:1527023463970};\\\", \\\"{x:912,y:600,t:1527023463985};\\\", \\\"{x:908,y:598,t:1527023464002};\\\", \\\"{x:902,y:592,t:1527023464020};\\\", \\\"{x:894,y:587,t:1527023464037};\\\", \\\"{x:883,y:582,t:1527023464053};\\\", \\\"{x:870,y:578,t:1527023464069};\\\", \\\"{x:854,y:573,t:1527023464086};\\\", \\\"{x:835,y:568,t:1527023464104};\\\", \\\"{x:811,y:566,t:1527023464120};\\\", \\\"{x:784,y:562,t:1527023464137};\\\", \\\"{x:750,y:559,t:1527023464153};\\\", \\\"{x:693,y:556,t:1527023464170};\\\", \\\"{x:637,y:548,t:1527023464187};\\\", \\\"{x:572,y:541,t:1527023464203};\\\", \\\"{x:544,y:537,t:1527023464221};\\\", \\\"{x:529,y:535,t:1527023464236};\\\", \\\"{x:515,y:535,t:1527023464254};\\\", \\\"{x:498,y:533,t:1527023464271};\\\", \\\"{x:483,y:530,t:1527023464286};\\\", \\\"{x:470,y:527,t:1527023464304};\\\", \\\"{x:456,y:523,t:1527023464322};\\\", \\\"{x:442,y:519,t:1527023464338};\\\", \\\"{x:432,y:518,t:1527023464354};\\\", \\\"{x:425,y:518,t:1527023464371};\\\", \\\"{x:420,y:518,t:1527023464386};\\\", \\\"{x:416,y:518,t:1527023464403};\\\", \\\"{x:410,y:518,t:1527023464420};\\\", \\\"{x:391,y:521,t:1527023464436};\\\", \\\"{x:364,y:521,t:1527023464454};\\\", \\\"{x:341,y:521,t:1527023464471};\\\", \\\"{x:306,y:513,t:1527023464487};\\\", \\\"{x:286,y:508,t:1527023464504};\\\", \\\"{x:272,y:506,t:1527023464521};\\\", \\\"{x:256,y:505,t:1527023464538};\\\", \\\"{x:241,y:505,t:1527023464553};\\\", \\\"{x:222,y:505,t:1527023464570};\\\", \\\"{x:201,y:500,t:1527023464587};\\\", \\\"{x:179,y:496,t:1527023464604};\\\", \\\"{x:164,y:495,t:1527023464621};\\\", \\\"{x:159,y:494,t:1527023464637};\\\", \\\"{x:156,y:494,t:1527023464653};\\\", \\\"{x:155,y:494,t:1527023464741};\\\", \\\"{x:154,y:494,t:1527023464754};\\\", \\\"{x:153,y:494,t:1527023464771};\\\", \\\"{x:154,y:494,t:1527023471356};\\\", \\\"{x:154,y:493,t:1527023471372};\\\", \\\"{x:155,y:493,t:1527023471395};\\\", \\\"{x:155,y:492,t:1527023471409};\\\", \\\"{x:157,y:492,t:1527023471443};\\\", \\\"{x:160,y:491,t:1527023471459};\\\", \\\"{x:162,y:490,t:1527023471475};\\\", \\\"{x:165,y:490,t:1527023471493};\\\", \\\"{x:170,y:490,t:1527023471508};\\\", \\\"{x:180,y:499,t:1527023471526};\\\", \\\"{x:189,y:505,t:1527023471543};\\\", \\\"{x:198,y:510,t:1527023471560};\\\", \\\"{x:202,y:513,t:1527023471575};\\\", \\\"{x:203,y:514,t:1527023471593};\\\", \\\"{x:208,y:517,t:1527023471609};\\\", \\\"{x:213,y:522,t:1527023471626};\\\", \\\"{x:222,y:529,t:1527023471643};\\\", \\\"{x:232,y:536,t:1527023471658};\\\", \\\"{x:248,y:546,t:1527023471676};\\\", \\\"{x:256,y:553,t:1527023471693};\\\", \\\"{x:261,y:558,t:1527023471709};\\\", \\\"{x:266,y:565,t:1527023471726};\\\", \\\"{x:271,y:570,t:1527023471743};\\\", \\\"{x:281,y:579,t:1527023471761};\\\", \\\"{x:291,y:587,t:1527023471775};\\\", \\\"{x:304,y:601,t:1527023471793};\\\", \\\"{x:312,y:610,t:1527023471809};\\\", \\\"{x:320,y:622,t:1527023471826};\\\", \\\"{x:328,y:631,t:1527023471842};\\\", \\\"{x:338,y:645,t:1527023471860};\\\", \\\"{x:344,y:651,t:1527023471877};\\\", \\\"{x:350,y:657,t:1527023471893};\\\", \\\"{x:353,y:662,t:1527023471909};\\\", \\\"{x:358,y:670,t:1527023471927};\\\", \\\"{x:366,y:677,t:1527023471943};\\\", \\\"{x:375,y:685,t:1527023471960};\\\", \\\"{x:387,y:694,t:1527023471976};\\\", \\\"{x:395,y:701,t:1527023471992};\\\", \\\"{x:406,y:710,t:1527023472009};\\\", \\\"{x:414,y:716,t:1527023472026};\\\", \\\"{x:422,y:723,t:1527023472042};\\\", \\\"{x:439,y:733,t:1527023472060};\\\", \\\"{x:449,y:741,t:1527023472077};\\\", \\\"{x:463,y:750,t:1527023472093};\\\", \\\"{x:474,y:758,t:1527023472111};\\\", \\\"{x:478,y:762,t:1527023472127};\\\", \\\"{x:482,y:764,t:1527023472142};\\\", \\\"{x:489,y:766,t:1527023472160};\\\", \\\"{x:493,y:768,t:1527023472176};\\\", \\\"{x:498,y:770,t:1527023472193};\\\", \\\"{x:500,y:771,t:1527023472210};\\\", \\\"{x:504,y:772,t:1527023472227};\\\", \\\"{x:505,y:772,t:1527023472243};\\\", \\\"{x:512,y:774,t:1527023472260};\\\", \\\"{x:516,y:774,t:1527023472277};\\\", \\\"{x:522,y:775,t:1527023472293};\\\", \\\"{x:527,y:776,t:1527023472310};\\\", \\\"{x:533,y:776,t:1527023472327};\\\", \\\"{x:539,y:777,t:1527023472343};\\\", \\\"{x:547,y:777,t:1527023472361};\\\", \\\"{x:557,y:779,t:1527023472377};\\\", \\\"{x:568,y:779,t:1527023472393};\\\", \\\"{x:572,y:780,t:1527023472410};\\\", \\\"{x:573,y:780,t:1527023472427};\\\", \\\"{x:575,y:780,t:1527023472443};\\\", \\\"{x:577,y:779,t:1527023472460};\\\", \\\"{x:578,y:778,t:1527023472478};\\\", \\\"{x:580,y:776,t:1527023472494};\\\", \\\"{x:580,y:773,t:1527023472509};\\\", \\\"{x:580,y:770,t:1527023472527};\\\", \\\"{x:580,y:766,t:1527023472543};\\\", \\\"{x:580,y:761,t:1527023472560};\\\", \\\"{x:580,y:757,t:1527023472577};\\\", \\\"{x:580,y:754,t:1527023472594};\\\", \\\"{x:580,y:752,t:1527023472610};\\\", \\\"{x:579,y:750,t:1527023472627};\\\", \\\"{x:578,y:748,t:1527023472644};\\\", \\\"{x:577,y:747,t:1527023472660};\\\", \\\"{x:573,y:747,t:1527023472677};\\\", \\\"{x:564,y:745,t:1527023472695};\\\", \\\"{x:555,y:743,t:1527023472710};\\\", \\\"{x:551,y:743,t:1527023472727};\\\", \\\"{x:547,y:742,t:1527023472744};\\\", \\\"{x:544,y:741,t:1527023472759};\\\", \\\"{x:544,y:740,t:1527023472777};\\\", \\\"{x:543,y:740,t:1527023472795};\\\", \\\"{x:542,y:740,t:1527023472810};\\\", \\\"{x:541,y:740,t:1527023472836};\\\" ] }, { \\\"rt\\\": 55791, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 389126, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"OZV09\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -X -F -B -B -B -F -F -E -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:543,y:739,t:1527023475789};\\\", \\\"{x:544,y:739,t:1527023475797};\\\", \\\"{x:549,y:737,t:1527023475814};\\\", \\\"{x:551,y:737,t:1527023475830};\\\", \\\"{x:553,y:737,t:1527023475847};\\\", \\\"{x:560,y:737,t:1527023475864};\\\", \\\"{x:574,y:739,t:1527023475881};\\\", \\\"{x:596,y:743,t:1527023475897};\\\", \\\"{x:619,y:748,t:1527023475914};\\\", \\\"{x:641,y:750,t:1527023475930};\\\", \\\"{x:661,y:754,t:1527023475946};\\\", \\\"{x:678,y:756,t:1527023475963};\\\", \\\"{x:710,y:761,t:1527023475979};\\\", \\\"{x:734,y:762,t:1527023475996};\\\", \\\"{x:764,y:768,t:1527023476013};\\\", \\\"{x:793,y:772,t:1527023476030};\\\", \\\"{x:817,y:776,t:1527023476046};\\\", \\\"{x:841,y:779,t:1527023476063};\\\", \\\"{x:867,y:784,t:1527023476080};\\\", \\\"{x:898,y:784,t:1527023476096};\\\", \\\"{x:928,y:784,t:1527023476112};\\\", \\\"{x:960,y:788,t:1527023476130};\\\", \\\"{x:986,y:791,t:1527023476146};\\\", \\\"{x:1003,y:793,t:1527023476163};\\\", \\\"{x:1017,y:794,t:1527023476179};\\\", \\\"{x:1025,y:794,t:1527023476197};\\\", \\\"{x:1034,y:793,t:1527023476213};\\\", \\\"{x:1049,y:790,t:1527023476230};\\\", \\\"{x:1069,y:787,t:1527023476247};\\\", \\\"{x:1087,y:782,t:1527023476263};\\\", \\\"{x:1101,y:780,t:1527023476280};\\\", \\\"{x:1115,y:777,t:1527023476297};\\\", \\\"{x:1124,y:777,t:1527023476313};\\\", \\\"{x:1131,y:775,t:1527023476330};\\\", \\\"{x:1135,y:774,t:1527023476347};\\\", \\\"{x:1136,y:774,t:1527023476363};\\\", \\\"{x:1138,y:773,t:1527023476380};\\\", \\\"{x:1139,y:773,t:1527023476412};\\\", \\\"{x:1140,y:773,t:1527023476431};\\\", \\\"{x:1142,y:772,t:1527023476448};\\\", \\\"{x:1145,y:770,t:1527023476464};\\\", \\\"{x:1146,y:770,t:1527023476484};\\\", \\\"{x:1147,y:769,t:1527023476540};\\\", \\\"{x:1148,y:769,t:1527023476563};\\\", \\\"{x:1149,y:769,t:1527023476668};\\\", \\\"{x:1150,y:769,t:1527023476681};\\\", \\\"{x:1151,y:769,t:1527023476698};\\\", \\\"{x:1152,y:769,t:1527023476715};\\\", \\\"{x:1155,y:769,t:1527023476730};\\\", \\\"{x:1156,y:769,t:1527023476747};\\\", \\\"{x:1162,y:769,t:1527023476764};\\\", \\\"{x:1169,y:769,t:1527023476780};\\\", \\\"{x:1175,y:769,t:1527023476797};\\\", \\\"{x:1181,y:770,t:1527023476814};\\\", \\\"{x:1186,y:772,t:1527023476831};\\\", \\\"{x:1190,y:772,t:1527023476848};\\\", \\\"{x:1194,y:774,t:1527023476864};\\\", \\\"{x:1201,y:777,t:1527023476881};\\\", \\\"{x:1211,y:781,t:1527023476897};\\\", \\\"{x:1222,y:786,t:1527023476915};\\\", \\\"{x:1235,y:794,t:1527023476931};\\\", \\\"{x:1243,y:800,t:1527023476948};\\\", \\\"{x:1249,y:807,t:1527023476964};\\\", \\\"{x:1252,y:813,t:1527023476981};\\\", \\\"{x:1254,y:817,t:1527023476997};\\\", \\\"{x:1259,y:824,t:1527023477014};\\\", \\\"{x:1261,y:830,t:1527023477031};\\\", \\\"{x:1264,y:837,t:1527023477047};\\\", \\\"{x:1267,y:845,t:1527023477065};\\\", \\\"{x:1267,y:851,t:1527023477082};\\\", \\\"{x:1269,y:857,t:1527023477098};\\\", \\\"{x:1270,y:860,t:1527023477115};\\\", \\\"{x:1271,y:862,t:1527023477164};\\\", \\\"{x:1273,y:863,t:1527023477181};\\\", \\\"{x:1278,y:863,t:1527023477197};\\\", \\\"{x:1285,y:864,t:1527023477214};\\\", \\\"{x:1301,y:867,t:1527023477231};\\\", \\\"{x:1315,y:867,t:1527023477248};\\\", \\\"{x:1328,y:867,t:1527023477264};\\\", \\\"{x:1337,y:867,t:1527023477281};\\\", \\\"{x:1347,y:867,t:1527023477298};\\\", \\\"{x:1354,y:867,t:1527023477314};\\\", \\\"{x:1362,y:867,t:1527023477331};\\\", \\\"{x:1375,y:867,t:1527023477348};\\\", \\\"{x:1383,y:867,t:1527023477364};\\\", \\\"{x:1390,y:867,t:1527023477381};\\\", \\\"{x:1395,y:867,t:1527023477398};\\\", \\\"{x:1398,y:867,t:1527023477414};\\\", \\\"{x:1401,y:867,t:1527023477431};\\\", \\\"{x:1403,y:867,t:1527023477448};\\\", \\\"{x:1405,y:867,t:1527023477465};\\\", \\\"{x:1407,y:866,t:1527023477481};\\\", \\\"{x:1410,y:864,t:1527023477498};\\\", \\\"{x:1412,y:863,t:1527023477514};\\\", \\\"{x:1417,y:861,t:1527023477532};\\\", \\\"{x:1426,y:855,t:1527023477548};\\\", \\\"{x:1432,y:850,t:1527023477566};\\\", \\\"{x:1436,y:847,t:1527023477581};\\\", \\\"{x:1440,y:842,t:1527023477598};\\\", \\\"{x:1443,y:838,t:1527023477616};\\\", \\\"{x:1446,y:834,t:1527023477631};\\\", \\\"{x:1448,y:828,t:1527023477648};\\\", \\\"{x:1451,y:822,t:1527023477665};\\\", \\\"{x:1452,y:820,t:1527023477681};\\\", \\\"{x:1453,y:817,t:1527023477698};\\\", \\\"{x:1456,y:811,t:1527023477715};\\\", \\\"{x:1459,y:805,t:1527023477731};\\\", \\\"{x:1464,y:795,t:1527023477748};\\\", \\\"{x:1466,y:782,t:1527023477766};\\\", \\\"{x:1471,y:759,t:1527023477781};\\\", \\\"{x:1475,y:737,t:1527023477799};\\\", \\\"{x:1477,y:717,t:1527023477816};\\\", \\\"{x:1480,y:700,t:1527023477831};\\\", \\\"{x:1481,y:686,t:1527023477849};\\\", \\\"{x:1483,y:670,t:1527023477866};\\\", \\\"{x:1486,y:656,t:1527023477882};\\\", \\\"{x:1487,y:644,t:1527023477898};\\\", \\\"{x:1490,y:625,t:1527023477915};\\\", \\\"{x:1490,y:610,t:1527023477932};\\\", \\\"{x:1491,y:606,t:1527023477949};\\\", \\\"{x:1491,y:600,t:1527023477965};\\\", \\\"{x:1493,y:592,t:1527023477983};\\\", \\\"{x:1494,y:585,t:1527023477999};\\\", \\\"{x:1495,y:573,t:1527023478016};\\\", \\\"{x:1497,y:559,t:1527023478033};\\\", \\\"{x:1499,y:549,t:1527023478049};\\\", \\\"{x:1500,y:544,t:1527023478066};\\\", \\\"{x:1501,y:541,t:1527023478083};\\\", \\\"{x:1501,y:537,t:1527023478099};\\\", \\\"{x:1504,y:533,t:1527023478115};\\\", \\\"{x:1508,y:529,t:1527023478132};\\\", \\\"{x:1511,y:526,t:1527023478148};\\\", \\\"{x:1514,y:525,t:1527023478165};\\\", \\\"{x:1517,y:523,t:1527023478182};\\\", \\\"{x:1519,y:522,t:1527023478199};\\\", \\\"{x:1522,y:520,t:1527023478216};\\\", \\\"{x:1524,y:519,t:1527023478232};\\\", \\\"{x:1525,y:518,t:1527023478250};\\\", \\\"{x:1527,y:518,t:1527023478266};\\\", \\\"{x:1528,y:518,t:1527023478284};\\\", \\\"{x:1530,y:518,t:1527023478299};\\\", \\\"{x:1537,y:532,t:1527023478316};\\\", \\\"{x:1551,y:563,t:1527023478332};\\\", \\\"{x:1561,y:575,t:1527023478350};\\\", \\\"{x:1567,y:586,t:1527023478365};\\\", \\\"{x:1570,y:593,t:1527023478382};\\\", \\\"{x:1574,y:601,t:1527023478400};\\\", \\\"{x:1574,y:609,t:1527023478415};\\\", \\\"{x:1578,y:621,t:1527023478433};\\\", \\\"{x:1584,y:636,t:1527023478450};\\\", \\\"{x:1584,y:643,t:1527023478466};\\\", \\\"{x:1587,y:651,t:1527023478483};\\\", \\\"{x:1589,y:661,t:1527023478500};\\\", \\\"{x:1592,y:670,t:1527023478516};\\\", \\\"{x:1593,y:674,t:1527023478532};\\\", \\\"{x:1594,y:680,t:1527023478550};\\\", \\\"{x:1596,y:684,t:1527023478567};\\\", \\\"{x:1596,y:689,t:1527023478583};\\\", \\\"{x:1597,y:695,t:1527023478600};\\\", \\\"{x:1598,y:699,t:1527023478615};\\\", \\\"{x:1598,y:704,t:1527023478633};\\\", \\\"{x:1598,y:710,t:1527023478650};\\\", \\\"{x:1598,y:720,t:1527023478668};\\\", \\\"{x:1598,y:725,t:1527023478683};\\\", \\\"{x:1598,y:730,t:1527023478700};\\\", \\\"{x:1598,y:733,t:1527023478716};\\\", \\\"{x:1596,y:738,t:1527023478733};\\\", \\\"{x:1592,y:745,t:1527023478749};\\\", \\\"{x:1586,y:755,t:1527023478767};\\\", \\\"{x:1580,y:761,t:1527023478783};\\\", \\\"{x:1575,y:766,t:1527023478800};\\\", \\\"{x:1571,y:772,t:1527023478817};\\\", \\\"{x:1565,y:779,t:1527023478832};\\\", \\\"{x:1559,y:784,t:1527023478850};\\\", \\\"{x:1547,y:792,t:1527023478867};\\\", \\\"{x:1539,y:798,t:1527023478883};\\\", \\\"{x:1529,y:803,t:1527023478900};\\\", \\\"{x:1524,y:805,t:1527023478917};\\\", \\\"{x:1522,y:805,t:1527023478934};\\\", \\\"{x:1520,y:805,t:1527023478950};\\\", \\\"{x:1519,y:806,t:1527023478972};\\\", \\\"{x:1518,y:807,t:1527023479004};\\\", \\\"{x:1517,y:807,t:1527023479053};\\\", \\\"{x:1516,y:808,t:1527023479092};\\\", \\\"{x:1515,y:809,t:1527023479141};\\\", \\\"{x:1514,y:809,t:1527023479150};\\\", \\\"{x:1513,y:809,t:1527023479171};\\\", \\\"{x:1512,y:809,t:1527023479183};\\\", \\\"{x:1512,y:810,t:1527023479199};\\\", \\\"{x:1511,y:810,t:1527023479216};\\\", \\\"{x:1510,y:810,t:1527023479233};\\\", \\\"{x:1509,y:810,t:1527023479250};\\\", \\\"{x:1507,y:811,t:1527023479267};\\\", \\\"{x:1506,y:811,t:1527023479307};\\\", \\\"{x:1505,y:811,t:1527023479380};\\\", \\\"{x:1502,y:812,t:1527023479396};\\\", \\\"{x:1500,y:812,t:1527023479420};\\\", \\\"{x:1499,y:812,t:1527023479469};\\\", \\\"{x:1498,y:812,t:1527023479500};\\\", \\\"{x:1496,y:813,t:1527023479517};\\\", \\\"{x:1493,y:814,t:1527023479534};\\\", \\\"{x:1491,y:815,t:1527023479550};\\\", \\\"{x:1489,y:816,t:1527023479567};\\\", \\\"{x:1486,y:818,t:1527023479583};\\\", \\\"{x:1485,y:818,t:1527023479600};\\\", \\\"{x:1482,y:819,t:1527023479616};\\\", \\\"{x:1478,y:820,t:1527023479633};\\\", \\\"{x:1472,y:820,t:1527023479651};\\\", \\\"{x:1465,y:820,t:1527023479668};\\\", \\\"{x:1462,y:820,t:1527023479684};\\\", \\\"{x:1459,y:820,t:1527023479700};\\\", \\\"{x:1457,y:819,t:1527023479717};\\\", \\\"{x:1455,y:817,t:1527023479733};\\\", \\\"{x:1451,y:814,t:1527023479750};\\\", \\\"{x:1447,y:811,t:1527023479768};\\\", \\\"{x:1445,y:810,t:1527023479784};\\\", \\\"{x:1443,y:809,t:1527023479801};\\\", \\\"{x:1442,y:809,t:1527023479868};\\\", \\\"{x:1441,y:809,t:1527023479884};\\\", \\\"{x:1438,y:809,t:1527023479901};\\\", \\\"{x:1432,y:807,t:1527023479918};\\\", \\\"{x:1426,y:804,t:1527023479934};\\\", \\\"{x:1422,y:802,t:1527023479951};\\\", \\\"{x:1417,y:798,t:1527023479969};\\\", \\\"{x:1413,y:794,t:1527023479985};\\\", \\\"{x:1409,y:787,t:1527023480001};\\\", \\\"{x:1398,y:773,t:1527023480018};\\\", \\\"{x:1387,y:754,t:1527023480035};\\\", \\\"{x:1380,y:741,t:1527023480051};\\\", \\\"{x:1373,y:728,t:1527023480068};\\\", \\\"{x:1371,y:721,t:1527023480084};\\\", \\\"{x:1369,y:719,t:1527023480100};\\\", \\\"{x:1367,y:715,t:1527023480118};\\\", \\\"{x:1366,y:711,t:1527023480135};\\\", \\\"{x:1364,y:705,t:1527023480150};\\\", \\\"{x:1361,y:701,t:1527023480168};\\\", \\\"{x:1361,y:698,t:1527023480184};\\\", \\\"{x:1360,y:697,t:1527023480201};\\\", \\\"{x:1359,y:696,t:1527023480218};\\\", \\\"{x:1358,y:696,t:1527023480269};\\\", \\\"{x:1356,y:696,t:1527023480284};\\\", \\\"{x:1355,y:696,t:1527023480302};\\\", \\\"{x:1353,y:696,t:1527023480375};\\\", \\\"{x:1352,y:697,t:1527023480401};\\\", \\\"{x:1350,y:697,t:1527023481908};\\\", \\\"{x:1350,y:698,t:1527023482068};\\\", \\\"{x:1352,y:698,t:1527023486653};\\\", \\\"{x:1353,y:697,t:1527023486660};\\\", \\\"{x:1358,y:697,t:1527023486676};\\\", \\\"{x:1373,y:697,t:1527023486691};\\\", \\\"{x:1408,y:707,t:1527023486708};\\\", \\\"{x:1427,y:710,t:1527023486725};\\\", \\\"{x:1448,y:715,t:1527023486742};\\\", \\\"{x:1465,y:718,t:1527023486758};\\\", \\\"{x:1480,y:719,t:1527023486775};\\\", \\\"{x:1493,y:721,t:1527023486791};\\\", \\\"{x:1504,y:723,t:1527023486808};\\\", \\\"{x:1516,y:723,t:1527023486825};\\\", \\\"{x:1528,y:725,t:1527023486841};\\\", \\\"{x:1545,y:728,t:1527023486858};\\\", \\\"{x:1556,y:729,t:1527023486875};\\\", \\\"{x:1563,y:730,t:1527023486891};\\\", \\\"{x:1564,y:730,t:1527023486908};\\\", \\\"{x:1565,y:730,t:1527023486996};\\\", \\\"{x:1566,y:730,t:1527023487029};\\\", \\\"{x:1567,y:730,t:1527023487052};\\\", \\\"{x:1568,y:730,t:1527023487060};\\\", \\\"{x:1569,y:731,t:1527023487075};\\\", \\\"{x:1579,y:737,t:1527023487092};\\\", \\\"{x:1583,y:740,t:1527023487107};\\\", \\\"{x:1586,y:743,t:1527023487125};\\\", \\\"{x:1590,y:747,t:1527023487142};\\\", \\\"{x:1591,y:751,t:1527023487158};\\\", \\\"{x:1592,y:752,t:1527023487175};\\\", \\\"{x:1592,y:754,t:1527023487192};\\\", \\\"{x:1592,y:755,t:1527023487212};\\\", \\\"{x:1592,y:757,t:1527023487244};\\\", \\\"{x:1592,y:758,t:1527023487268};\\\", \\\"{x:1592,y:760,t:1527023487292};\\\", \\\"{x:1592,y:761,t:1527023487316};\\\", \\\"{x:1592,y:763,t:1527023487339};\\\", \\\"{x:1592,y:764,t:1527023487371};\\\", \\\"{x:1592,y:766,t:1527023487387};\\\", \\\"{x:1592,y:767,t:1527023487411};\\\", \\\"{x:1592,y:769,t:1527023487467};\\\", \\\"{x:1591,y:770,t:1527023487483};\\\", \\\"{x:1591,y:771,t:1527023487500};\\\", \\\"{x:1590,y:771,t:1527023487508};\\\", \\\"{x:1590,y:772,t:1527023487532};\\\", \\\"{x:1589,y:773,t:1527023487636};\\\", \\\"{x:1588,y:774,t:1527023487717};\\\", \\\"{x:1587,y:775,t:1527023487781};\\\", \\\"{x:1587,y:776,t:1527023487796};\\\", \\\"{x:1587,y:777,t:1527023487853};\\\", \\\"{x:1587,y:778,t:1527023487876};\\\", \\\"{x:1587,y:779,t:1527023487893};\\\", \\\"{x:1587,y:780,t:1527023487931};\\\", \\\"{x:1587,y:781,t:1527023487955};\\\", \\\"{x:1587,y:782,t:1527023487971};\\\", \\\"{x:1587,y:783,t:1527023487987};\\\", \\\"{x:1587,y:785,t:1527023487996};\\\", \\\"{x:1587,y:786,t:1527023488012};\\\", \\\"{x:1587,y:788,t:1527023488026};\\\", \\\"{x:1587,y:790,t:1527023488042};\\\", \\\"{x:1587,y:795,t:1527023488059};\\\", \\\"{x:1591,y:802,t:1527023488075};\\\", \\\"{x:1593,y:807,t:1527023488092};\\\", \\\"{x:1594,y:809,t:1527023488108};\\\", \\\"{x:1595,y:812,t:1527023488126};\\\", \\\"{x:1595,y:815,t:1527023488143};\\\", \\\"{x:1596,y:817,t:1527023488159};\\\", \\\"{x:1596,y:818,t:1527023488176};\\\", \\\"{x:1597,y:821,t:1527023488193};\\\", \\\"{x:1597,y:823,t:1527023488209};\\\", \\\"{x:1598,y:827,t:1527023488226};\\\", \\\"{x:1599,y:830,t:1527023488243};\\\", \\\"{x:1601,y:832,t:1527023488259};\\\", \\\"{x:1603,y:836,t:1527023488275};\\\", \\\"{x:1603,y:837,t:1527023488300};\\\", \\\"{x:1603,y:838,t:1527023488324};\\\", \\\"{x:1604,y:838,t:1527023488332};\\\", \\\"{x:1604,y:840,t:1527023488348};\\\", \\\"{x:1604,y:841,t:1527023488360};\\\", \\\"{x:1604,y:844,t:1527023488376};\\\", \\\"{x:1605,y:848,t:1527023488393};\\\", \\\"{x:1605,y:852,t:1527023488410};\\\", \\\"{x:1608,y:860,t:1527023488426};\\\", \\\"{x:1609,y:865,t:1527023488444};\\\", \\\"{x:1610,y:869,t:1527023488460};\\\", \\\"{x:1611,y:872,t:1527023488476};\\\", \\\"{x:1612,y:874,t:1527023488493};\\\", \\\"{x:1612,y:876,t:1527023488510};\\\", \\\"{x:1612,y:877,t:1527023488532};\\\", \\\"{x:1612,y:874,t:1527023488725};\\\", \\\"{x:1612,y:873,t:1527023488732};\\\", \\\"{x:1612,y:871,t:1527023488743};\\\", \\\"{x:1612,y:869,t:1527023488760};\\\", \\\"{x:1612,y:867,t:1527023488777};\\\", \\\"{x:1612,y:866,t:1527023488793};\\\", \\\"{x:1612,y:865,t:1527023488810};\\\", \\\"{x:1612,y:864,t:1527023488827};\\\", \\\"{x:1612,y:862,t:1527023488843};\\\", \\\"{x:1612,y:859,t:1527023488860};\\\", \\\"{x:1612,y:858,t:1527023488877};\\\", \\\"{x:1612,y:857,t:1527023488893};\\\", \\\"{x:1612,y:855,t:1527023488910};\\\", \\\"{x:1612,y:854,t:1527023488932};\\\", \\\"{x:1612,y:852,t:1527023488943};\\\", \\\"{x:1612,y:849,t:1527023488960};\\\", \\\"{x:1612,y:848,t:1527023488977};\\\", \\\"{x:1612,y:846,t:1527023488994};\\\", \\\"{x:1612,y:845,t:1527023489012};\\\", \\\"{x:1612,y:843,t:1527023489044};\\\", \\\"{x:1611,y:841,t:1527023489060};\\\", \\\"{x:1611,y:840,t:1527023489077};\\\", \\\"{x:1611,y:839,t:1527023489094};\\\", \\\"{x:1611,y:837,t:1527023489110};\\\", \\\"{x:1610,y:836,t:1527023489127};\\\", \\\"{x:1610,y:835,t:1527023489148};\\\", \\\"{x:1610,y:834,t:1527023489160};\\\", \\\"{x:1608,y:832,t:1527023489177};\\\", \\\"{x:1608,y:831,t:1527023489194};\\\", \\\"{x:1608,y:830,t:1527023489210};\\\", \\\"{x:1607,y:830,t:1527023489227};\\\", \\\"{x:1607,y:829,t:1527023489260};\\\", \\\"{x:1606,y:828,t:1527023489277};\\\", \\\"{x:1606,y:827,t:1527023489307};\\\", \\\"{x:1606,y:826,t:1527023489420};\\\", \\\"{x:1605,y:826,t:1527023490365};\\\", \\\"{x:1605,y:825,t:1527023498860};\\\", \\\"{x:1603,y:824,t:1527023499276};\\\", \\\"{x:1601,y:823,t:1527023499287};\\\", \\\"{x:1599,y:823,t:1527023499305};\\\", \\\"{x:1595,y:822,t:1527023499322};\\\", \\\"{x:1594,y:821,t:1527023499338};\\\", \\\"{x:1592,y:821,t:1527023499355};\\\", \\\"{x:1590,y:821,t:1527023499371};\\\", \\\"{x:1589,y:821,t:1527023499387};\\\", \\\"{x:1585,y:821,t:1527023499404};\\\", \\\"{x:1579,y:821,t:1527023499421};\\\", \\\"{x:1577,y:820,t:1527023499438};\\\", \\\"{x:1573,y:820,t:1527023499454};\\\", \\\"{x:1567,y:820,t:1527023499472};\\\", \\\"{x:1550,y:817,t:1527023499487};\\\", \\\"{x:1532,y:814,t:1527023499504};\\\", \\\"{x:1515,y:810,t:1527023499521};\\\", \\\"{x:1505,y:809,t:1527023499537};\\\", \\\"{x:1500,y:807,t:1527023499554};\\\", \\\"{x:1490,y:806,t:1527023499572};\\\", \\\"{x:1473,y:800,t:1527023499588};\\\", \\\"{x:1456,y:795,t:1527023499605};\\\", \\\"{x:1440,y:790,t:1527023499622};\\\", \\\"{x:1425,y:783,t:1527023499638};\\\", \\\"{x:1419,y:780,t:1527023499654};\\\", \\\"{x:1413,y:777,t:1527023499672};\\\", \\\"{x:1402,y:771,t:1527023499688};\\\", \\\"{x:1394,y:766,t:1527023499705};\\\", \\\"{x:1389,y:763,t:1527023499722};\\\", \\\"{x:1387,y:763,t:1527023499738};\\\", \\\"{x:1386,y:763,t:1527023499764};\\\", \\\"{x:1384,y:763,t:1527023499772};\\\", \\\"{x:1378,y:762,t:1527023499789};\\\", \\\"{x:1372,y:760,t:1527023499805};\\\", \\\"{x:1371,y:760,t:1527023499822};\\\", \\\"{x:1370,y:760,t:1527023499838};\\\", \\\"{x:1368,y:760,t:1527023499854};\\\", \\\"{x:1362,y:760,t:1527023499872};\\\", \\\"{x:1352,y:760,t:1527023499889};\\\", \\\"{x:1344,y:760,t:1527023499904};\\\", \\\"{x:1337,y:760,t:1527023499922};\\\", \\\"{x:1336,y:760,t:1527023499940};\\\", \\\"{x:1332,y:758,t:1527023500036};\\\", \\\"{x:1325,y:749,t:1527023500043};\\\", \\\"{x:1313,y:740,t:1527023500055};\\\", \\\"{x:1254,y:697,t:1527023500072};\\\", \\\"{x:1168,y:660,t:1527023500089};\\\", \\\"{x:1060,y:610,t:1527023500106};\\\", \\\"{x:950,y:565,t:1527023500123};\\\", \\\"{x:856,y:520,t:1527023500139};\\\", \\\"{x:735,y:477,t:1527023500154};\\\", \\\"{x:711,y:464,t:1527023500165};\\\", \\\"{x:683,y:452,t:1527023500182};\\\", \\\"{x:670,y:447,t:1527023500198};\\\", \\\"{x:655,y:443,t:1527023500215};\\\", \\\"{x:633,y:441,t:1527023500232};\\\", \\\"{x:593,y:435,t:1527023500253};\\\", \\\"{x:550,y:428,t:1527023500269};\\\", \\\"{x:527,y:426,t:1527023500286};\\\", \\\"{x:520,y:424,t:1527023500302};\\\", \\\"{x:517,y:425,t:1527023500335};\\\", \\\"{x:515,y:427,t:1527023500342};\\\", \\\"{x:512,y:433,t:1527023500353};\\\", \\\"{x:508,y:443,t:1527023500369};\\\", \\\"{x:505,y:456,t:1527023500386};\\\", \\\"{x:503,y:465,t:1527023500403};\\\", \\\"{x:503,y:470,t:1527023500419};\\\", \\\"{x:503,y:477,t:1527023500436};\\\", \\\"{x:503,y:485,t:1527023500453};\\\", \\\"{x:503,y:489,t:1527023500470};\\\", \\\"{x:503,y:491,t:1527023500486};\\\", \\\"{x:519,y:492,t:1527023500502};\\\", \\\"{x:542,y:492,t:1527023500520};\\\", \\\"{x:564,y:493,t:1527023500537};\\\", \\\"{x:585,y:497,t:1527023500554};\\\", \\\"{x:603,y:499,t:1527023500571};\\\", \\\"{x:617,y:502,t:1527023500587};\\\", \\\"{x:628,y:506,t:1527023500603};\\\", \\\"{x:631,y:509,t:1527023500619};\\\", \\\"{x:634,y:512,t:1527023500637};\\\", \\\"{x:635,y:517,t:1527023500653};\\\", \\\"{x:635,y:520,t:1527023500670};\\\", \\\"{x:632,y:528,t:1527023500687};\\\", \\\"{x:628,y:530,t:1527023500704};\\\", \\\"{x:623,y:533,t:1527023500719};\\\", \\\"{x:617,y:534,t:1527023500737};\\\", \\\"{x:598,y:538,t:1527023500754};\\\", \\\"{x:566,y:538,t:1527023500769};\\\", \\\"{x:496,y:538,t:1527023500788};\\\", \\\"{x:423,y:526,t:1527023500804};\\\", \\\"{x:391,y:518,t:1527023500820};\\\", \\\"{x:388,y:516,t:1527023500838};\\\", \\\"{x:387,y:516,t:1527023500853};\\\", \\\"{x:385,y:516,t:1527023500887};\\\", \\\"{x:381,y:517,t:1527023500903};\\\", \\\"{x:379,y:517,t:1527023500920};\\\", \\\"{x:377,y:519,t:1527023500938};\\\", \\\"{x:375,y:520,t:1527023500954};\\\", \\\"{x:369,y:523,t:1527023500970};\\\", \\\"{x:355,y:528,t:1527023500988};\\\", \\\"{x:332,y:534,t:1527023501004};\\\", \\\"{x:312,y:536,t:1527023501020};\\\", \\\"{x:295,y:538,t:1527023501037};\\\", \\\"{x:285,y:541,t:1527023501053};\\\", \\\"{x:280,y:543,t:1527023501069};\\\", \\\"{x:271,y:547,t:1527023501088};\\\", \\\"{x:253,y:549,t:1527023501104};\\\", \\\"{x:224,y:549,t:1527023501120};\\\", \\\"{x:195,y:549,t:1527023501136};\\\", \\\"{x:174,y:549,t:1527023501155};\\\", \\\"{x:166,y:549,t:1527023501171};\\\", \\\"{x:165,y:549,t:1527023501263};\\\", \\\"{x:164,y:549,t:1527023501327};\\\", \\\"{x:164,y:547,t:1527023503271};\\\", \\\"{x:171,y:544,t:1527023503290};\\\", \\\"{x:177,y:542,t:1527023503305};\\\", \\\"{x:203,y:542,t:1527023503323};\\\", \\\"{x:274,y:542,t:1527023503340};\\\", \\\"{x:396,y:542,t:1527023503355};\\\", \\\"{x:653,y:592,t:1527023503390};\\\", \\\"{x:766,y:620,t:1527023503406};\\\", \\\"{x:860,y:644,t:1527023503422};\\\", \\\"{x:955,y:675,t:1527023503439};\\\", \\\"{x:1007,y:696,t:1527023503456};\\\", \\\"{x:1049,y:714,t:1527023503472};\\\", \\\"{x:1088,y:733,t:1527023503489};\\\", \\\"{x:1126,y:755,t:1527023503506};\\\", \\\"{x:1159,y:774,t:1527023503522};\\\", \\\"{x:1184,y:787,t:1527023503539};\\\", \\\"{x:1201,y:797,t:1527023503556};\\\", \\\"{x:1212,y:806,t:1527023503573};\\\", \\\"{x:1218,y:810,t:1527023503588};\\\", \\\"{x:1222,y:813,t:1527023503606};\\\", \\\"{x:1236,y:819,t:1527023503622};\\\", \\\"{x:1248,y:821,t:1527023503639};\\\", \\\"{x:1267,y:821,t:1527023503656};\\\", \\\"{x:1285,y:821,t:1527023503673};\\\", \\\"{x:1302,y:821,t:1527023503690};\\\", \\\"{x:1312,y:818,t:1527023503706};\\\", \\\"{x:1320,y:814,t:1527023503723};\\\", \\\"{x:1327,y:807,t:1527023503740};\\\", \\\"{x:1331,y:799,t:1527023503756};\\\", \\\"{x:1336,y:794,t:1527023503773};\\\", \\\"{x:1336,y:793,t:1527023503790};\\\", \\\"{x:1337,y:791,t:1527023503807};\\\", \\\"{x:1337,y:790,t:1527023503823};\\\", \\\"{x:1337,y:788,t:1527023503841};\\\", \\\"{x:1337,y:787,t:1527023503858};\\\", \\\"{x:1337,y:786,t:1527023503879};\\\", \\\"{x:1337,y:785,t:1527023503891};\\\", \\\"{x:1337,y:784,t:1527023503907};\\\", \\\"{x:1337,y:783,t:1527023503936};\\\", \\\"{x:1337,y:782,t:1527023503951};\\\", \\\"{x:1337,y:781,t:1527023503959};\\\", \\\"{x:1337,y:780,t:1527023503975};\\\", \\\"{x:1337,y:779,t:1527023503990};\\\", \\\"{x:1337,y:775,t:1527023504008};\\\", \\\"{x:1337,y:774,t:1527023504025};\\\", \\\"{x:1338,y:771,t:1527023504041};\\\", \\\"{x:1339,y:769,t:1527023504057};\\\", \\\"{x:1339,y:768,t:1527023504075};\\\", \\\"{x:1340,y:765,t:1527023504092};\\\", \\\"{x:1341,y:762,t:1527023504108};\\\", \\\"{x:1343,y:761,t:1527023504125};\\\", \\\"{x:1344,y:758,t:1527023504142};\\\", \\\"{x:1345,y:756,t:1527023504168};\\\", \\\"{x:1345,y:755,t:1527023504182};\\\", \\\"{x:1346,y:755,t:1527023504190};\\\", \\\"{x:1346,y:754,t:1527023504223};\\\", \\\"{x:1347,y:753,t:1527023504247};\\\", \\\"{x:1348,y:751,t:1527023504286};\\\", \\\"{x:1349,y:747,t:1527023505511};\\\", \\\"{x:1349,y:731,t:1527023505528};\\\", \\\"{x:1349,y:717,t:1527023505545};\\\", \\\"{x:1349,y:706,t:1527023505562};\\\", \\\"{x:1349,y:695,t:1527023505579};\\\", \\\"{x:1349,y:681,t:1527023505596};\\\", \\\"{x:1349,y:671,t:1527023505612};\\\", \\\"{x:1346,y:654,t:1527023505628};\\\", \\\"{x:1343,y:639,t:1527023505645};\\\", \\\"{x:1341,y:625,t:1527023505662};\\\", \\\"{x:1338,y:612,t:1527023505679};\\\", \\\"{x:1337,y:609,t:1527023505695};\\\", \\\"{x:1336,y:607,t:1527023505712};\\\", \\\"{x:1335,y:601,t:1527023505729};\\\", \\\"{x:1332,y:596,t:1527023505746};\\\", \\\"{x:1329,y:591,t:1527023505763};\\\", \\\"{x:1326,y:586,t:1527023505780};\\\", \\\"{x:1326,y:585,t:1527023505797};\\\", \\\"{x:1324,y:584,t:1527023505813};\\\", \\\"{x:1322,y:584,t:1527023505829};\\\", \\\"{x:1316,y:583,t:1527023505846};\\\", \\\"{x:1310,y:582,t:1527023505863};\\\", \\\"{x:1306,y:580,t:1527023505879};\\\", \\\"{x:1305,y:579,t:1527023505896};\\\", \\\"{x:1304,y:578,t:1527023505913};\\\", \\\"{x:1302,y:577,t:1527023505929};\\\", \\\"{x:1301,y:576,t:1527023505946};\\\", \\\"{x:1298,y:574,t:1527023505963};\\\", \\\"{x:1297,y:573,t:1527023505979};\\\", \\\"{x:1295,y:573,t:1527023505997};\\\", \\\"{x:1295,y:572,t:1527023506023};\\\", \\\"{x:1294,y:571,t:1527023506031};\\\", \\\"{x:1293,y:570,t:1527023506055};\\\", \\\"{x:1292,y:570,t:1527023506071};\\\", \\\"{x:1291,y:570,t:1527023506087};\\\", \\\"{x:1291,y:569,t:1527023506097};\\\", \\\"{x:1290,y:568,t:1527023506114};\\\", \\\"{x:1289,y:567,t:1527023506131};\\\", \\\"{x:1287,y:567,t:1527023506147};\\\", \\\"{x:1285,y:566,t:1527023506167};\\\", \\\"{x:1285,y:565,t:1527023506196};\\\", \\\"{x:1284,y:565,t:1527023506212};\\\", \\\"{x:1283,y:565,t:1527023506230};\\\", \\\"{x:1282,y:565,t:1527023506254};\\\", \\\"{x:1281,y:565,t:1527023509008};\\\", \\\"{x:1280,y:565,t:1527023509056};\\\", \\\"{x:1279,y:566,t:1527023509072};\\\", \\\"{x:1278,y:568,t:1527023509807};\\\", \\\"{x:1276,y:577,t:1527023509826};\\\", \\\"{x:1272,y:586,t:1527023509840};\\\", \\\"{x:1267,y:602,t:1527023509858};\\\", \\\"{x:1261,y:618,t:1527023509874};\\\", \\\"{x:1256,y:636,t:1527023509891};\\\", \\\"{x:1249,y:657,t:1527023509908};\\\", \\\"{x:1240,y:676,t:1527023509925};\\\", \\\"{x:1235,y:693,t:1527023509941};\\\", \\\"{x:1229,y:709,t:1527023509958};\\\", \\\"{x:1226,y:718,t:1527023509974};\\\", \\\"{x:1221,y:726,t:1527023509992};\\\", \\\"{x:1217,y:733,t:1527023510009};\\\", \\\"{x:1215,y:738,t:1527023510025};\\\", \\\"{x:1211,y:743,t:1527023510042};\\\", \\\"{x:1211,y:745,t:1527023510059};\\\", \\\"{x:1210,y:746,t:1527023510075};\\\", \\\"{x:1209,y:747,t:1527023510092};\\\", \\\"{x:1209,y:748,t:1527023510108};\\\", \\\"{x:1208,y:748,t:1527023510127};\\\", \\\"{x:1208,y:749,t:1527023510159};\\\", \\\"{x:1208,y:751,t:1527023510207};\\\", \\\"{x:1208,y:752,t:1527023510225};\\\", \\\"{x:1208,y:755,t:1527023510243};\\\", \\\"{x:1208,y:759,t:1527023510259};\\\", \\\"{x:1208,y:761,t:1527023510276};\\\", \\\"{x:1208,y:762,t:1527023510292};\\\", \\\"{x:1208,y:764,t:1527023510309};\\\", \\\"{x:1208,y:766,t:1527023510326};\\\", \\\"{x:1208,y:768,t:1527023510342};\\\", \\\"{x:1208,y:771,t:1527023510359};\\\", \\\"{x:1208,y:772,t:1527023510375};\\\", \\\"{x:1208,y:773,t:1527023510392};\\\", \\\"{x:1208,y:774,t:1527023510409};\\\", \\\"{x:1208,y:775,t:1527023510426};\\\", \\\"{x:1208,y:776,t:1527023510447};\\\", \\\"{x:1208,y:777,t:1527023510459};\\\", \\\"{x:1208,y:778,t:1527023510479};\\\", \\\"{x:1207,y:778,t:1527023510504};\\\", \\\"{x:1206,y:779,t:1527023510511};\\\", \\\"{x:1206,y:780,t:1527023510559};\\\", \\\"{x:1205,y:781,t:1527023510655};\\\", \\\"{x:1205,y:780,t:1527023511240};\\\", \\\"{x:1205,y:778,t:1527023511248};\\\", \\\"{x:1205,y:777,t:1527023511263};\\\", \\\"{x:1205,y:776,t:1527023511278};\\\", \\\"{x:1205,y:775,t:1527023511295};\\\", \\\"{x:1205,y:774,t:1527023511472};\\\", \\\"{x:1205,y:773,t:1527023511495};\\\", \\\"{x:1205,y:772,t:1527023511535};\\\", \\\"{x:1205,y:771,t:1527023511592};\\\", \\\"{x:1205,y:770,t:1527023511623};\\\", \\\"{x:1205,y:769,t:1527023512088};\\\", \\\"{x:1206,y:768,t:1527023514016};\\\", \\\"{x:1207,y:768,t:1527023514103};\\\", \\\"{x:1209,y:768,t:1527023514120};\\\", \\\"{x:1214,y:768,t:1527023514137};\\\", \\\"{x:1221,y:769,t:1527023514154};\\\", \\\"{x:1234,y:773,t:1527023514170};\\\", \\\"{x:1246,y:778,t:1527023514186};\\\", \\\"{x:1264,y:783,t:1527023514203};\\\", \\\"{x:1289,y:791,t:1527023514221};\\\", \\\"{x:1314,y:798,t:1527023514236};\\\", \\\"{x:1338,y:808,t:1527023514253};\\\", \\\"{x:1372,y:822,t:1527023514270};\\\", \\\"{x:1387,y:829,t:1527023514286};\\\", \\\"{x:1400,y:834,t:1527023514304};\\\", \\\"{x:1412,y:838,t:1527023514320};\\\", \\\"{x:1416,y:840,t:1527023514337};\\\", \\\"{x:1416,y:841,t:1527023514359};\\\", \\\"{x:1417,y:841,t:1527023514382};\\\", \\\"{x:1418,y:842,t:1527023514391};\\\", \\\"{x:1419,y:844,t:1527023514403};\\\", \\\"{x:1422,y:847,t:1527023514420};\\\", \\\"{x:1424,y:852,t:1527023514437};\\\", \\\"{x:1426,y:860,t:1527023514454};\\\", \\\"{x:1426,y:865,t:1527023514470};\\\", \\\"{x:1426,y:869,t:1527023514487};\\\", \\\"{x:1426,y:873,t:1527023514505};\\\", \\\"{x:1426,y:875,t:1527023514520};\\\", \\\"{x:1427,y:877,t:1527023514537};\\\", \\\"{x:1427,y:878,t:1527023514672};\\\", \\\"{x:1427,y:879,t:1527023514689};\\\", \\\"{x:1427,y:880,t:1527023514705};\\\", \\\"{x:1425,y:882,t:1527023514722};\\\", \\\"{x:1425,y:883,t:1527023514739};\\\", \\\"{x:1424,y:883,t:1527023514839};\\\", \\\"{x:1424,y:884,t:1527023515304};\\\", \\\"{x:1423,y:884,t:1527023515392};\\\", \\\"{x:1422,y:885,t:1527023515407};\\\", \\\"{x:1421,y:885,t:1527023515423};\\\", \\\"{x:1420,y:886,t:1527023515441};\\\", \\\"{x:1417,y:887,t:1527023515458};\\\", \\\"{x:1412,y:887,t:1527023515474};\\\", \\\"{x:1392,y:887,t:1527023515491};\\\", \\\"{x:1365,y:885,t:1527023515508};\\\", \\\"{x:1320,y:879,t:1527023515524};\\\", \\\"{x:1295,y:874,t:1527023515541};\\\", \\\"{x:1280,y:872,t:1527023515558};\\\", \\\"{x:1260,y:869,t:1527023515575};\\\", \\\"{x:1247,y:867,t:1527023515591};\\\", \\\"{x:1237,y:866,t:1527023515607};\\\", \\\"{x:1232,y:864,t:1527023515625};\\\", \\\"{x:1231,y:864,t:1527023515640};\\\", \\\"{x:1230,y:863,t:1527023515658};\\\", \\\"{x:1230,y:862,t:1527023515752};\\\", \\\"{x:1230,y:861,t:1527023515767};\\\", \\\"{x:1230,y:860,t:1527023515775};\\\", \\\"{x:1229,y:859,t:1527023515791};\\\", \\\"{x:1229,y:858,t:1527023515808};\\\", \\\"{x:1229,y:857,t:1527023515825};\\\", \\\"{x:1228,y:855,t:1527023515842};\\\", \\\"{x:1228,y:854,t:1527023515859};\\\", \\\"{x:1227,y:852,t:1527023515875};\\\", \\\"{x:1227,y:850,t:1527023515892};\\\", \\\"{x:1227,y:849,t:1527023515911};\\\", \\\"{x:1227,y:847,t:1527023515943};\\\", \\\"{x:1227,y:846,t:1527023515967};\\\", \\\"{x:1227,y:844,t:1527023515991};\\\", \\\"{x:1226,y:843,t:1527023516009};\\\", \\\"{x:1226,y:841,t:1527023516055};\\\", \\\"{x:1226,y:840,t:1527023516119};\\\", \\\"{x:1226,y:838,t:1527023516400};\\\", \\\"{x:1226,y:837,t:1527023516432};\\\", \\\"{x:1225,y:836,t:1527023516444};\\\", \\\"{x:1225,y:835,t:1527023516479};\\\", \\\"{x:1224,y:835,t:1527023516511};\\\", \\\"{x:1224,y:834,t:1527023516839};\\\", \\\"{x:1225,y:833,t:1527023516871};\\\", \\\"{x:1226,y:833,t:1527023516887};\\\", \\\"{x:1227,y:833,t:1527023516903};\\\", \\\"{x:1228,y:832,t:1527023516919};\\\", \\\"{x:1229,y:831,t:1527023516968};\\\", \\\"{x:1230,y:831,t:1527023517031};\\\", \\\"{x:1231,y:831,t:1527023517071};\\\", \\\"{x:1231,y:830,t:1527023517079};\\\", \\\"{x:1234,y:828,t:1527023517095};\\\", \\\"{x:1236,y:828,t:1527023517112};\\\", \\\"{x:1239,y:827,t:1527023517129};\\\", \\\"{x:1243,y:827,t:1527023517146};\\\", \\\"{x:1247,y:827,t:1527023517162};\\\", \\\"{x:1252,y:827,t:1527023517179};\\\", \\\"{x:1255,y:827,t:1527023517196};\\\", \\\"{x:1259,y:827,t:1527023517212};\\\", \\\"{x:1261,y:827,t:1527023517229};\\\", \\\"{x:1262,y:827,t:1527023517246};\\\", \\\"{x:1265,y:827,t:1527023517263};\\\", \\\"{x:1271,y:827,t:1527023517280};\\\", \\\"{x:1278,y:827,t:1527023517296};\\\", \\\"{x:1290,y:827,t:1527023517313};\\\", \\\"{x:1297,y:827,t:1527023517329};\\\", \\\"{x:1304,y:827,t:1527023517346};\\\", \\\"{x:1307,y:827,t:1527023517363};\\\", \\\"{x:1309,y:827,t:1527023517380};\\\", \\\"{x:1311,y:827,t:1527023517396};\\\", \\\"{x:1313,y:827,t:1527023517413};\\\", \\\"{x:1314,y:827,t:1527023517430};\\\", \\\"{x:1318,y:827,t:1527023517446};\\\", \\\"{x:1324,y:827,t:1527023517463};\\\", \\\"{x:1330,y:827,t:1527023517480};\\\", \\\"{x:1335,y:828,t:1527023517497};\\\", \\\"{x:1342,y:828,t:1527023517513};\\\", \\\"{x:1345,y:828,t:1527023517529};\\\", \\\"{x:1352,y:829,t:1527023517547};\\\", \\\"{x:1358,y:829,t:1527023517563};\\\", \\\"{x:1361,y:829,t:1527023517580};\\\", \\\"{x:1365,y:829,t:1527023517597};\\\", \\\"{x:1366,y:829,t:1527023517614};\\\", \\\"{x:1370,y:830,t:1527023517631};\\\", \\\"{x:1379,y:830,t:1527023517647};\\\", \\\"{x:1390,y:832,t:1527023517664};\\\", \\\"{x:1404,y:834,t:1527023517680};\\\", \\\"{x:1414,y:835,t:1527023517697};\\\", \\\"{x:1425,y:837,t:1527023517713};\\\", \\\"{x:1434,y:838,t:1527023517731};\\\", \\\"{x:1440,y:839,t:1527023517747};\\\", \\\"{x:1448,y:839,t:1527023517764};\\\", \\\"{x:1461,y:839,t:1527023517781};\\\", \\\"{x:1476,y:839,t:1527023517797};\\\", \\\"{x:1493,y:842,t:1527023517815};\\\", \\\"{x:1514,y:844,t:1527023517831};\\\", \\\"{x:1519,y:844,t:1527023517847};\\\", \\\"{x:1520,y:844,t:1527023517904};\\\", \\\"{x:1521,y:844,t:1527023517914};\\\", \\\"{x:1522,y:844,t:1527023518207};\\\", \\\"{x:1522,y:843,t:1527023518215};\\\", \\\"{x:1522,y:842,t:1527023518279};\\\", \\\"{x:1522,y:841,t:1527023518335};\\\", \\\"{x:1522,y:840,t:1527023518663};\\\", \\\"{x:1520,y:840,t:1527023519783};\\\", \\\"{x:1519,y:840,t:1527023519791};\\\", \\\"{x:1518,y:840,t:1527023519803};\\\", \\\"{x:1514,y:840,t:1527023519820};\\\", \\\"{x:1512,y:840,t:1527023519837};\\\", \\\"{x:1509,y:841,t:1527023519854};\\\", \\\"{x:1503,y:841,t:1527023519870};\\\", \\\"{x:1489,y:846,t:1527023519888};\\\", \\\"{x:1486,y:846,t:1527023519904};\\\", \\\"{x:1485,y:846,t:1527023519920};\\\", \\\"{x:1484,y:846,t:1527023519951};\\\", \\\"{x:1483,y:846,t:1527023520080};\\\", \\\"{x:1482,y:846,t:1527023520120};\\\", \\\"{x:1482,y:845,t:1527023520135};\\\", \\\"{x:1482,y:842,t:1527023520143};\\\", \\\"{x:1482,y:841,t:1527023520160};\\\", \\\"{x:1482,y:839,t:1527023520174};\\\", \\\"{x:1481,y:837,t:1527023520188};\\\", \\\"{x:1481,y:835,t:1527023520204};\\\", \\\"{x:1481,y:833,t:1527023520220};\\\", \\\"{x:1479,y:832,t:1527023520270};\\\", \\\"{x:1470,y:832,t:1527023520288};\\\", \\\"{x:1451,y:832,t:1527023520304};\\\", \\\"{x:1400,y:832,t:1527023520321};\\\", \\\"{x:1328,y:832,t:1527023520338};\\\", \\\"{x:1234,y:822,t:1527023520355};\\\", \\\"{x:1146,y:799,t:1527023520372};\\\", \\\"{x:1076,y:776,t:1527023520388};\\\", \\\"{x:1009,y:757,t:1527023520405};\\\", \\\"{x:952,y:735,t:1527023520422};\\\", \\\"{x:911,y:719,t:1527023520438};\\\", \\\"{x:874,y:701,t:1527023520454};\\\", \\\"{x:854,y:691,t:1527023520472};\\\", \\\"{x:835,y:680,t:1527023520488};\\\", \\\"{x:818,y:673,t:1527023520504};\\\", \\\"{x:797,y:668,t:1527023520522};\\\", \\\"{x:776,y:661,t:1527023520539};\\\", \\\"{x:757,y:656,t:1527023520554};\\\", \\\"{x:748,y:652,t:1527023520571};\\\", \\\"{x:739,y:648,t:1527023520589};\\\", \\\"{x:734,y:645,t:1527023520605};\\\", \\\"{x:727,y:641,t:1527023520622};\\\", \\\"{x:699,y:627,t:1527023520640};\\\", \\\"{x:682,y:618,t:1527023520655};\\\", \\\"{x:667,y:610,t:1527023520671};\\\", \\\"{x:654,y:601,t:1527023520694};\\\", \\\"{x:649,y:598,t:1527023520712};\\\", \\\"{x:642,y:594,t:1527023520727};\\\", \\\"{x:634,y:588,t:1527023520753};\\\", \\\"{x:626,y:584,t:1527023520770};\\\", \\\"{x:619,y:579,t:1527023520786};\\\", \\\"{x:612,y:576,t:1527023520802};\\\", \\\"{x:605,y:574,t:1527023520820};\\\", \\\"{x:602,y:572,t:1527023520836};\\\", \\\"{x:601,y:572,t:1527023520862};\\\", \\\"{x:601,y:573,t:1527023528992};\\\", \\\"{x:602,y:578,t:1527023529009};\\\", \\\"{x:605,y:583,t:1527023529026};\\\", \\\"{x:605,y:585,t:1527023529042};\\\", \\\"{x:605,y:586,t:1527023529059};\\\", \\\"{x:605,y:588,t:1527023529076};\\\", \\\"{x:605,y:590,t:1527023529093};\\\", \\\"{x:606,y:593,t:1527023529109};\\\", \\\"{x:606,y:594,t:1527023529126};\\\", \\\"{x:606,y:597,t:1527023529143};\\\", \\\"{x:606,y:601,t:1527023529160};\\\", \\\"{x:606,y:605,t:1527023529176};\\\", \\\"{x:604,y:610,t:1527023529193};\\\", \\\"{x:602,y:615,t:1527023529210};\\\", \\\"{x:599,y:619,t:1527023529225};\\\", \\\"{x:597,y:622,t:1527023529243};\\\", \\\"{x:592,y:629,t:1527023529260};\\\", \\\"{x:590,y:636,t:1527023529276};\\\", \\\"{x:587,y:643,t:1527023529293};\\\", \\\"{x:583,y:651,t:1527023529310};\\\", \\\"{x:579,y:660,t:1527023529326};\\\", \\\"{x:571,y:674,t:1527023529342};\\\", \\\"{x:564,y:683,t:1527023529361};\\\", \\\"{x:559,y:691,t:1527023529376};\\\", \\\"{x:556,y:697,t:1527023529393};\\\", \\\"{x:555,y:699,t:1527023529411};\\\", \\\"{x:554,y:703,t:1527023529427};\\\", \\\"{x:552,y:705,t:1527023529443};\\\", \\\"{x:551,y:707,t:1527023529460};\\\", \\\"{x:548,y:713,t:1527023529478};\\\", \\\"{x:543,y:721,t:1527023529493};\\\", \\\"{x:540,y:729,t:1527023529510};\\\", \\\"{x:537,y:736,t:1527023529527};\\\", \\\"{x:537,y:737,t:1527023529543};\\\", \\\"{x:536,y:737,t:1527023529561};\\\", \\\"{x:535,y:739,t:1527023529577};\\\", \\\"{x:533,y:743,t:1527023529593};\\\", \\\"{x:531,y:748,t:1527023529610};\\\", \\\"{x:526,y:757,t:1527023529628};\\\", \\\"{x:524,y:760,t:1527023529643};\\\", \\\"{x:524,y:762,t:1527023529660};\\\", \\\"{x:523,y:763,t:1527023529677};\\\", \\\"{x:522,y:763,t:1527023529692};\\\", \\\"{x:521,y:763,t:1527023529709};\\\", \\\"{x:518,y:763,t:1527023529726};\\\", \\\"{x:517,y:763,t:1527023529743};\\\", \\\"{x:517,y:762,t:1527023529799};\\\", \\\"{x:515,y:758,t:1527023529810};\\\", \\\"{x:515,y:752,t:1527023529828};\\\", \\\"{x:515,y:747,t:1527023529843};\\\", \\\"{x:515,y:745,t:1527023529860};\\\", \\\"{x:515,y:743,t:1527023529877};\\\", \\\"{x:515,y:742,t:1527023529894};\\\", \\\"{x:515,y:741,t:1527023529910};\\\", \\\"{x:515,y:735,t:1527023529926};\\\", \\\"{x:516,y:731,t:1527023529944};\\\", \\\"{x:517,y:730,t:1527023529959};\\\" ] }, { \\\"rt\\\": 13922, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 404283, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"OZV09\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:519,y:728,t:1527023532575};\\\", \\\"{x:523,y:726,t:1527023532603};\\\", \\\"{x:526,y:725,t:1527023532613};\\\", \\\"{x:532,y:722,t:1527023532630};\\\", \\\"{x:544,y:722,t:1527023532646};\\\", \\\"{x:556,y:722,t:1527023532663};\\\", \\\"{x:574,y:722,t:1527023532681};\\\", \\\"{x:593,y:722,t:1527023532697};\\\", \\\"{x:609,y:722,t:1527023532711};\\\", \\\"{x:627,y:722,t:1527023532728};\\\", \\\"{x:640,y:722,t:1527023532745};\\\", \\\"{x:651,y:723,t:1527023532762};\\\", \\\"{x:658,y:725,t:1527023532778};\\\", \\\"{x:662,y:726,t:1527023532795};\\\", \\\"{x:665,y:726,t:1527023532812};\\\", \\\"{x:666,y:726,t:1527023532830};\\\", \\\"{x:667,y:726,t:1527023533183};\\\", \\\"{x:668,y:726,t:1527023533239};\\\", \\\"{x:669,y:726,t:1527023533271};\\\", \\\"{x:670,y:725,t:1527023533280};\\\", \\\"{x:672,y:725,t:1527023533296};\\\", \\\"{x:674,y:725,t:1527023533313};\\\", \\\"{x:678,y:725,t:1527023533330};\\\", \\\"{x:680,y:725,t:1527023533346};\\\", \\\"{x:686,y:724,t:1527023533362};\\\", \\\"{x:692,y:724,t:1527023533379};\\\", \\\"{x:697,y:724,t:1527023533396};\\\", \\\"{x:705,y:724,t:1527023533412};\\\", \\\"{x:717,y:724,t:1527023533430};\\\", \\\"{x:740,y:724,t:1527023533446};\\\", \\\"{x:764,y:724,t:1527023533463};\\\", \\\"{x:783,y:724,t:1527023533479};\\\", \\\"{x:797,y:724,t:1527023533496};\\\", \\\"{x:811,y:724,t:1527023533513};\\\", \\\"{x:822,y:724,t:1527023533529};\\\", \\\"{x:837,y:724,t:1527023533546};\\\", \\\"{x:860,y:724,t:1527023533564};\\\", \\\"{x:890,y:724,t:1527023533580};\\\", \\\"{x:920,y:724,t:1527023533596};\\\", \\\"{x:947,y:724,t:1527023533613};\\\", \\\"{x:970,y:724,t:1527023533630};\\\", \\\"{x:992,y:726,t:1527023533647};\\\", \\\"{x:1020,y:731,t:1527023533663};\\\", \\\"{x:1036,y:732,t:1527023533680};\\\", \\\"{x:1054,y:733,t:1527023533696};\\\", \\\"{x:1074,y:736,t:1527023533714};\\\", \\\"{x:1094,y:738,t:1527023533729};\\\", \\\"{x:1120,y:742,t:1527023533747};\\\", \\\"{x:1148,y:744,t:1527023533764};\\\", \\\"{x:1177,y:750,t:1527023533779};\\\", \\\"{x:1199,y:754,t:1527023533798};\\\", \\\"{x:1220,y:756,t:1527023533813};\\\", \\\"{x:1237,y:760,t:1527023533830};\\\", \\\"{x:1254,y:761,t:1527023533847};\\\", \\\"{x:1260,y:763,t:1527023533863};\\\", \\\"{x:1267,y:764,t:1527023533880};\\\", \\\"{x:1276,y:768,t:1527023533896};\\\", \\\"{x:1281,y:770,t:1527023533913};\\\", \\\"{x:1284,y:773,t:1527023533930};\\\", \\\"{x:1288,y:779,t:1527023533947};\\\", \\\"{x:1292,y:784,t:1527023533963};\\\", \\\"{x:1292,y:788,t:1527023533980};\\\", \\\"{x:1294,y:793,t:1527023533997};\\\", \\\"{x:1294,y:796,t:1527023534013};\\\", \\\"{x:1294,y:800,t:1527023534030};\\\", \\\"{x:1294,y:803,t:1527023534047};\\\", \\\"{x:1292,y:804,t:1527023534159};\\\", \\\"{x:1292,y:805,t:1527023534183};\\\", \\\"{x:1291,y:805,t:1527023534196};\\\", \\\"{x:1291,y:807,t:1527023534214};\\\", \\\"{x:1285,y:816,t:1527023534231};\\\", \\\"{x:1283,y:823,t:1527023534247};\\\", \\\"{x:1282,y:829,t:1527023534263};\\\", \\\"{x:1282,y:836,t:1527023534281};\\\", \\\"{x:1282,y:842,t:1527023534297};\\\", \\\"{x:1286,y:855,t:1527023534313};\\\", \\\"{x:1300,y:865,t:1527023534330};\\\", \\\"{x:1318,y:878,t:1527023534346};\\\", \\\"{x:1334,y:888,t:1527023534363};\\\", \\\"{x:1344,y:896,t:1527023534380};\\\", \\\"{x:1349,y:906,t:1527023534397};\\\", \\\"{x:1359,y:921,t:1527023534413};\\\", \\\"{x:1372,y:938,t:1527023534430};\\\", \\\"{x:1373,y:939,t:1527023534446};\\\", \\\"{x:1374,y:939,t:1527023534464};\\\", \\\"{x:1375,y:939,t:1527023534494};\\\", \\\"{x:1376,y:939,t:1527023534527};\\\", \\\"{x:1378,y:939,t:1527023534535};\\\", \\\"{x:1380,y:940,t:1527023534551};\\\", \\\"{x:1380,y:941,t:1527023534564};\\\", \\\"{x:1378,y:941,t:1527023534712};\\\", \\\"{x:1375,y:941,t:1527023534719};\\\", \\\"{x:1371,y:942,t:1527023534730};\\\", \\\"{x:1364,y:942,t:1527023534747};\\\", \\\"{x:1358,y:942,t:1527023534763};\\\", \\\"{x:1356,y:942,t:1527023534780};\\\", \\\"{x:1355,y:942,t:1527023534846};\\\", \\\"{x:1352,y:943,t:1527023534863};\\\", \\\"{x:1350,y:944,t:1527023534880};\\\", \\\"{x:1349,y:944,t:1527023534897};\\\", \\\"{x:1348,y:944,t:1527023535023};\\\", \\\"{x:1348,y:943,t:1527023535319};\\\", \\\"{x:1347,y:942,t:1527023535335};\\\", \\\"{x:1347,y:941,t:1527023535408};\\\", \\\"{x:1347,y:940,t:1527023535432};\\\", \\\"{x:1347,y:939,t:1527023535471};\\\", \\\"{x:1347,y:938,t:1527023535511};\\\", \\\"{x:1347,y:937,t:1527023535535};\\\", \\\"{x:1347,y:936,t:1527023535607};\\\", \\\"{x:1347,y:935,t:1527023535647};\\\", \\\"{x:1347,y:934,t:1527023535703};\\\", \\\"{x:1347,y:933,t:1527023535824};\\\", \\\"{x:1347,y:932,t:1527023535895};\\\", \\\"{x:1347,y:931,t:1527023535919};\\\", \\\"{x:1347,y:930,t:1527023536016};\\\", \\\"{x:1347,y:929,t:1527023536055};\\\", \\\"{x:1347,y:928,t:1527023536119};\\\", \\\"{x:1347,y:927,t:1527023536191};\\\", \\\"{x:1347,y:926,t:1527023536240};\\\", \\\"{x:1347,y:925,t:1527023536303};\\\", \\\"{x:1348,y:924,t:1527023536335};\\\", \\\"{x:1348,y:923,t:1527023536423};\\\", \\\"{x:1348,y:922,t:1527023536512};\\\", \\\"{x:1348,y:921,t:1527023536543};\\\", \\\"{x:1348,y:920,t:1527023536558};\\\", \\\"{x:1348,y:919,t:1527023536600};\\\", \\\"{x:1349,y:918,t:1527023536615};\\\", \\\"{x:1349,y:917,t:1527023536647};\\\", \\\"{x:1349,y:916,t:1527023536679};\\\", \\\"{x:1349,y:915,t:1527023536687};\\\", \\\"{x:1349,y:914,t:1527023536711};\\\", \\\"{x:1349,y:913,t:1527023536727};\\\", \\\"{x:1349,y:912,t:1527023536751};\\\", \\\"{x:1347,y:911,t:1527023537071};\\\", \\\"{x:1346,y:911,t:1527023537087};\\\", \\\"{x:1345,y:911,t:1527023537110};\\\", \\\"{x:1344,y:909,t:1527023537127};\\\", \\\"{x:1343,y:909,t:1527023537135};\\\", \\\"{x:1342,y:909,t:1527023537149};\\\", \\\"{x:1335,y:908,t:1527023537166};\\\", \\\"{x:1325,y:904,t:1527023537182};\\\", \\\"{x:1300,y:894,t:1527023537199};\\\", \\\"{x:1284,y:886,t:1527023537215};\\\", \\\"{x:1271,y:878,t:1527023537232};\\\", \\\"{x:1254,y:871,t:1527023537249};\\\", \\\"{x:1233,y:861,t:1527023537265};\\\", \\\"{x:1212,y:850,t:1527023537282};\\\", \\\"{x:1197,y:842,t:1527023537299};\\\", \\\"{x:1189,y:836,t:1527023537316};\\\", \\\"{x:1182,y:829,t:1527023537331};\\\", \\\"{x:1177,y:824,t:1527023537349};\\\", \\\"{x:1166,y:816,t:1527023537366};\\\", \\\"{x:1155,y:809,t:1527023537382};\\\", \\\"{x:1142,y:800,t:1527023537399};\\\", \\\"{x:1134,y:796,t:1527023537415};\\\", \\\"{x:1127,y:792,t:1527023537432};\\\", \\\"{x:1117,y:789,t:1527023537449};\\\", \\\"{x:1102,y:786,t:1527023537466};\\\", \\\"{x:1083,y:782,t:1527023537482};\\\", \\\"{x:1069,y:777,t:1527023537499};\\\", \\\"{x:1060,y:772,t:1527023537515};\\\", \\\"{x:1054,y:769,t:1527023537532};\\\", \\\"{x:1044,y:767,t:1527023537549};\\\", \\\"{x:1018,y:758,t:1527023537566};\\\", \\\"{x:979,y:745,t:1527023537583};\\\", \\\"{x:956,y:735,t:1527023537599};\\\", \\\"{x:944,y:728,t:1527023537616};\\\", \\\"{x:937,y:723,t:1527023537632};\\\", \\\"{x:930,y:720,t:1527023537648};\\\", \\\"{x:922,y:716,t:1527023537666};\\\", \\\"{x:917,y:712,t:1527023537683};\\\", \\\"{x:908,y:706,t:1527023537699};\\\", \\\"{x:901,y:700,t:1527023537716};\\\", \\\"{x:892,y:694,t:1527023537732};\\\", \\\"{x:886,y:688,t:1527023537749};\\\", \\\"{x:879,y:683,t:1527023537766};\\\", \\\"{x:873,y:678,t:1527023537782};\\\", \\\"{x:870,y:675,t:1527023537799};\\\", \\\"{x:869,y:673,t:1527023537815};\\\", \\\"{x:865,y:666,t:1527023537833};\\\", \\\"{x:862,y:661,t:1527023537848};\\\", \\\"{x:857,y:654,t:1527023537865};\\\", \\\"{x:852,y:648,t:1527023537883};\\\", \\\"{x:850,y:646,t:1527023537898};\\\", \\\"{x:848,y:641,t:1527023537915};\\\", \\\"{x:844,y:636,t:1527023537932};\\\", \\\"{x:833,y:624,t:1527023537950};\\\", \\\"{x:819,y:611,t:1527023537965};\\\", \\\"{x:797,y:595,t:1527023537982};\\\", \\\"{x:789,y:587,t:1527023538001};\\\", \\\"{x:784,y:581,t:1527023538016};\\\", \\\"{x:776,y:577,t:1527023538033};\\\", \\\"{x:762,y:571,t:1527023538050};\\\", \\\"{x:741,y:565,t:1527023538066};\\\", \\\"{x:719,y:557,t:1527023538083};\\\", \\\"{x:700,y:550,t:1527023538101};\\\", \\\"{x:689,y:544,t:1527023538116};\\\", \\\"{x:688,y:543,t:1527023538133};\\\", \\\"{x:687,y:543,t:1527023538150};\\\", \\\"{x:685,y:539,t:1527023538167};\\\", \\\"{x:679,y:527,t:1527023538184};\\\", \\\"{x:670,y:515,t:1527023538201};\\\", \\\"{x:667,y:511,t:1527023538217};\\\", \\\"{x:666,y:509,t:1527023538233};\\\", \\\"{x:665,y:508,t:1527023538250};\\\", \\\"{x:663,y:507,t:1527023538270};\\\", \\\"{x:662,y:505,t:1527023538283};\\\", \\\"{x:652,y:501,t:1527023538300};\\\", \\\"{x:645,y:498,t:1527023538317};\\\", \\\"{x:642,y:498,t:1527023538333};\\\", \\\"{x:642,y:497,t:1527023538382};\\\", \\\"{x:644,y:492,t:1527023538390};\\\", \\\"{x:654,y:489,t:1527023538400};\\\", \\\"{x:687,y:485,t:1527023538418};\\\", \\\"{x:717,y:485,t:1527023538433};\\\", \\\"{x:735,y:485,t:1527023538450};\\\", \\\"{x:741,y:485,t:1527023538468};\\\", \\\"{x:742,y:485,t:1527023538483};\\\", \\\"{x:744,y:485,t:1527023538503};\\\", \\\"{x:745,y:484,t:1527023538519};\\\", \\\"{x:749,y:482,t:1527023538533};\\\", \\\"{x:751,y:482,t:1527023538551};\\\", \\\"{x:752,y:482,t:1527023538583};\\\", \\\"{x:755,y:482,t:1527023538601};\\\", \\\"{x:762,y:482,t:1527023538617};\\\", \\\"{x:769,y:482,t:1527023538634};\\\", \\\"{x:774,y:482,t:1527023538650};\\\", \\\"{x:775,y:483,t:1527023538667};\\\", \\\"{x:777,y:483,t:1527023538684};\\\", \\\"{x:780,y:483,t:1527023538700};\\\", \\\"{x:784,y:485,t:1527023538718};\\\", \\\"{x:787,y:485,t:1527023538733};\\\", \\\"{x:791,y:486,t:1527023538750};\\\", \\\"{x:792,y:486,t:1527023538775};\\\", \\\"{x:793,y:486,t:1527023538785};\\\", \\\"{x:795,y:486,t:1527023538800};\\\", \\\"{x:799,y:486,t:1527023538817};\\\", \\\"{x:805,y:487,t:1527023538836};\\\", \\\"{x:810,y:490,t:1527023538851};\\\", \\\"{x:813,y:490,t:1527023538867};\\\", \\\"{x:817,y:493,t:1527023538884};\\\", \\\"{x:820,y:493,t:1527023538901};\\\", \\\"{x:822,y:494,t:1527023538917};\\\", \\\"{x:828,y:495,t:1527023538934};\\\", \\\"{x:830,y:496,t:1527023538951};\\\", \\\"{x:831,y:497,t:1527023538967};\\\", \\\"{x:833,y:497,t:1527023538984};\\\", \\\"{x:834,y:498,t:1527023539001};\\\", \\\"{x:838,y:499,t:1527023539017};\\\", \\\"{x:839,y:500,t:1527023539034};\\\", \\\"{x:840,y:500,t:1527023539050};\\\", \\\"{x:840,y:501,t:1527023539167};\\\", \\\"{x:838,y:505,t:1527023539534};\\\", \\\"{x:833,y:513,t:1527023539551};\\\", \\\"{x:830,y:519,t:1527023539568};\\\", \\\"{x:827,y:524,t:1527023539584};\\\", \\\"{x:825,y:527,t:1527023539602};\\\", \\\"{x:824,y:530,t:1527023539618};\\\", \\\"{x:820,y:535,t:1527023539634};\\\", \\\"{x:817,y:539,t:1527023539651};\\\", \\\"{x:816,y:540,t:1527023539668};\\\", \\\"{x:814,y:543,t:1527023539684};\\\", \\\"{x:812,y:544,t:1527023539701};\\\", \\\"{x:807,y:547,t:1527023539718};\\\", \\\"{x:802,y:551,t:1527023539734};\\\", \\\"{x:799,y:551,t:1527023539751};\\\", \\\"{x:797,y:553,t:1527023539790};\\\", \\\"{x:796,y:553,t:1527023539814};\\\", \\\"{x:795,y:554,t:1527023539823};\\\", \\\"{x:793,y:554,t:1527023539834};\\\", \\\"{x:792,y:554,t:1527023541919};\\\", \\\"{x:789,y:555,t:1527023541936};\\\", \\\"{x:788,y:556,t:1527023541955};\\\", \\\"{x:788,y:557,t:1527023541970};\\\", \\\"{x:787,y:557,t:1527023541986};\\\", \\\"{x:786,y:557,t:1527023542003};\\\", \\\"{x:784,y:558,t:1527023542020};\\\", \\\"{x:783,y:558,t:1527023542038};\\\", \\\"{x:781,y:558,t:1527023542053};\\\", \\\"{x:778,y:558,t:1527023542070};\\\", \\\"{x:776,y:558,t:1527023542086};\\\", \\\"{x:775,y:558,t:1527023542104};\\\", \\\"{x:773,y:558,t:1527023542121};\\\", \\\"{x:770,y:558,t:1527023542137};\\\", \\\"{x:768,y:559,t:1527023542154};\\\", \\\"{x:767,y:559,t:1527023542174};\\\", \\\"{x:765,y:559,t:1527023542207};\\\", \\\"{x:764,y:560,t:1527023542221};\\\", \\\"{x:763,y:560,t:1527023542239};\\\", \\\"{x:762,y:560,t:1527023542254};\\\", \\\"{x:761,y:560,t:1527023542294};\\\", \\\"{x:760,y:561,t:1527023542327};\\\", \\\"{x:758,y:561,t:1527023542337};\\\", \\\"{x:757,y:562,t:1527023542354};\\\", \\\"{x:754,y:563,t:1527023542372};\\\", \\\"{x:749,y:563,t:1527023542387};\\\", \\\"{x:744,y:563,t:1527023542403};\\\", \\\"{x:739,y:563,t:1527023542421};\\\", \\\"{x:735,y:564,t:1527023542436};\\\", \\\"{x:733,y:565,t:1527023542453};\\\", \\\"{x:732,y:565,t:1527023542470};\\\", \\\"{x:730,y:565,t:1527023542510};\\\", \\\"{x:727,y:565,t:1527023542520};\\\", \\\"{x:722,y:565,t:1527023542537};\\\", \\\"{x:717,y:565,t:1527023542553};\\\", \\\"{x:715,y:565,t:1527023542570};\\\", \\\"{x:714,y:565,t:1527023542587};\\\", \\\"{x:712,y:565,t:1527023542604};\\\", \\\"{x:709,y:566,t:1527023542620};\\\", \\\"{x:706,y:566,t:1527023542637};\\\", \\\"{x:702,y:566,t:1527023542654};\\\", \\\"{x:699,y:566,t:1527023542670};\\\", \\\"{x:697,y:567,t:1527023542687};\\\", \\\"{x:692,y:568,t:1527023542703};\\\", \\\"{x:679,y:571,t:1527023542720};\\\", \\\"{x:664,y:572,t:1527023542737};\\\", \\\"{x:650,y:573,t:1527023542753};\\\", \\\"{x:645,y:573,t:1527023542770};\\\", \\\"{x:640,y:574,t:1527023542788};\\\", \\\"{x:635,y:575,t:1527023542803};\\\", \\\"{x:613,y:577,t:1527023542821};\\\", \\\"{x:586,y:577,t:1527023542838};\\\", \\\"{x:566,y:577,t:1527023542854};\\\", \\\"{x:560,y:577,t:1527023542870};\\\", \\\"{x:558,y:577,t:1527023542887};\\\", \\\"{x:556,y:577,t:1527023542927};\\\", \\\"{x:553,y:577,t:1527023542937};\\\", \\\"{x:544,y:577,t:1527023542954};\\\", \\\"{x:530,y:577,t:1527023542971};\\\", \\\"{x:513,y:577,t:1527023542988};\\\", \\\"{x:495,y:577,t:1527023543006};\\\", \\\"{x:483,y:577,t:1527023543020};\\\", \\\"{x:475,y:575,t:1527023543037};\\\", \\\"{x:471,y:575,t:1527023543053};\\\", \\\"{x:469,y:573,t:1527023543070};\\\", \\\"{x:459,y:569,t:1527023543087};\\\", \\\"{x:438,y:559,t:1527023543105};\\\", \\\"{x:421,y:553,t:1527023543121};\\\", \\\"{x:407,y:548,t:1527023543138};\\\", \\\"{x:398,y:545,t:1527023543155};\\\", \\\"{x:390,y:545,t:1527023543171};\\\", \\\"{x:374,y:545,t:1527023543187};\\\", \\\"{x:344,y:542,t:1527023543205};\\\", \\\"{x:320,y:539,t:1527023543220};\\\", \\\"{x:302,y:537,t:1527023543238};\\\", \\\"{x:294,y:535,t:1527023543254};\\\", \\\"{x:289,y:535,t:1527023543272};\\\", \\\"{x:281,y:536,t:1527023543288};\\\", \\\"{x:270,y:536,t:1527023543306};\\\", \\\"{x:265,y:538,t:1527023543321};\\\", \\\"{x:261,y:538,t:1527023543337};\\\", \\\"{x:258,y:539,t:1527023543354};\\\", \\\"{x:250,y:543,t:1527023543371};\\\", \\\"{x:232,y:548,t:1527023543387};\\\", \\\"{x:214,y:550,t:1527023543405};\\\", \\\"{x:200,y:552,t:1527023543421};\\\", \\\"{x:196,y:552,t:1527023543437};\\\", \\\"{x:194,y:553,t:1527023543454};\\\", \\\"{x:192,y:553,t:1527023543471};\\\", \\\"{x:180,y:553,t:1527023543487};\\\", \\\"{x:165,y:553,t:1527023543504};\\\", \\\"{x:159,y:553,t:1527023543522};\\\", \\\"{x:156,y:552,t:1527023543537};\\\", \\\"{x:154,y:551,t:1527023543584};\\\", \\\"{x:153,y:551,t:1527023543598};\\\", \\\"{x:153,y:550,t:1527023543606};\\\", \\\"{x:151,y:550,t:1527023543621};\\\", \\\"{x:149,y:549,t:1527023543638};\\\", \\\"{x:145,y:548,t:1527023543655};\\\", \\\"{x:144,y:546,t:1527023543671};\\\", \\\"{x:144,y:545,t:1527023544039};\\\", \\\"{x:150,y:542,t:1527023544057};\\\", \\\"{x:151,y:541,t:1527023544071};\\\", \\\"{x:155,y:540,t:1527023544088};\\\", \\\"{x:157,y:539,t:1527023544105};\\\", \\\"{x:158,y:538,t:1527023544122};\\\", \\\"{x:160,y:538,t:1527023544139};\\\", \\\"{x:160,y:537,t:1527023544510};\\\", \\\"{x:161,y:536,t:1527023544522};\\\", \\\"{x:166,y:536,t:1527023544539};\\\", \\\"{x:174,y:541,t:1527023544556};\\\", \\\"{x:185,y:548,t:1527023544571};\\\", \\\"{x:199,y:557,t:1527023544589};\\\", \\\"{x:228,y:570,t:1527023544607};\\\", \\\"{x:239,y:575,t:1527023544621};\\\", \\\"{x:273,y:585,t:1527023544639};\\\", \\\"{x:294,y:593,t:1527023544656};\\\", \\\"{x:318,y:600,t:1527023544672};\\\", \\\"{x:340,y:607,t:1527023544689};\\\", \\\"{x:368,y:618,t:1527023544706};\\\", \\\"{x:391,y:631,t:1527023544722};\\\", \\\"{x:414,y:641,t:1527023544740};\\\", \\\"{x:434,y:646,t:1527023544755};\\\", \\\"{x:451,y:653,t:1527023544772};\\\", \\\"{x:460,y:655,t:1527023544789};\\\", \\\"{x:467,y:657,t:1527023544806};\\\", \\\"{x:472,y:659,t:1527023544822};\\\", \\\"{x:475,y:660,t:1527023544839};\\\", \\\"{x:475,y:661,t:1527023544855};\\\", \\\"{x:476,y:661,t:1527023544879};\\\", \\\"{x:477,y:662,t:1527023544890};\\\", \\\"{x:480,y:666,t:1527023544906};\\\", \\\"{x:484,y:673,t:1527023544923};\\\", \\\"{x:489,y:682,t:1527023544939};\\\", \\\"{x:492,y:692,t:1527023544955};\\\", \\\"{x:494,y:703,t:1527023544972};\\\", \\\"{x:497,y:715,t:1527023544988};\\\", \\\"{x:499,y:724,t:1527023545007};\\\", \\\"{x:499,y:730,t:1527023545021};\\\", \\\"{x:500,y:739,t:1527023545039};\\\", \\\"{x:501,y:743,t:1527023545055};\\\", \\\"{x:502,y:745,t:1527023545073};\\\", \\\"{x:503,y:743,t:1527023545767};\\\", \\\"{x:504,y:742,t:1527023545791};\\\", \\\"{x:505,y:742,t:1527023545814};\\\", \\\"{x:505,y:741,t:1527023545829};\\\", \\\"{x:506,y:740,t:1527023545846};\\\", \\\"{x:506,y:739,t:1527023546079};\\\", \\\"{x:507,y:739,t:1527023546089};\\\", \\\"{x:507,y:738,t:1527023546106};\\\", \\\"{x:508,y:737,t:1527023546231};\\\", \\\"{x:509,y:736,t:1527023546247};\\\", \\\"{x:510,y:735,t:1527023546262};\\\", \\\"{x:510,y:734,t:1527023546295};\\\", \\\"{x:511,y:734,t:1527023546333};\\\", \\\"{x:511,y:732,t:1527023546340};\\\", \\\"{x:512,y:731,t:1527023546356};\\\", \\\"{x:514,y:729,t:1527023546372};\\\", \\\"{x:515,y:728,t:1527023546398};\\\", \\\"{x:515,y:727,t:1527023546422};\\\", \\\"{x:516,y:727,t:1527023546430};\\\", \\\"{x:517,y:726,t:1527023546439};\\\", \\\"{x:519,y:724,t:1527023546457};\\\", \\\"{x:523,y:722,t:1527023546472};\\\", \\\"{x:526,y:720,t:1527023546489};\\\" ] }, { \\\"rt\\\": 8965, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 414560, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"OZV09\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:633,y:685,t:1527023546613};\\\", \\\"{x:649,y:678,t:1527023546623};\\\", \\\"{x:665,y:671,t:1527023546639};\\\", \\\"{x:679,y:666,t:1527023546657};\\\", \\\"{x:689,y:661,t:1527023546673};\\\", \\\"{x:695,y:659,t:1527023546690};\\\", \\\"{x:697,y:657,t:1527023546707};\\\", \\\"{x:701,y:656,t:1527023546727};\\\", \\\"{x:701,y:655,t:1527023546741};\\\", \\\"{x:703,y:654,t:1527023546757};\\\", \\\"{x:704,y:653,t:1527023546773};\\\", \\\"{x:705,y:653,t:1527023546790};\\\", \\\"{x:710,y:652,t:1527023547887};\\\", \\\"{x:717,y:652,t:1527023547895};\\\", \\\"{x:723,y:652,t:1527023547908};\\\", \\\"{x:739,y:652,t:1527023547925};\\\", \\\"{x:759,y:652,t:1527023547941};\\\", \\\"{x:796,y:658,t:1527023547958};\\\", \\\"{x:824,y:662,t:1527023547975};\\\", \\\"{x:857,y:667,t:1527023547991};\\\", \\\"{x:891,y:672,t:1527023548008};\\\", \\\"{x:922,y:676,t:1527023548025};\\\", \\\"{x:951,y:681,t:1527023548041};\\\", \\\"{x:981,y:688,t:1527023548058};\\\", \\\"{x:1007,y:696,t:1527023548074};\\\", \\\"{x:1032,y:703,t:1527023548092};\\\", \\\"{x:1059,y:711,t:1527023548107};\\\", \\\"{x:1083,y:719,t:1527023548125};\\\", \\\"{x:1105,y:725,t:1527023548142};\\\", \\\"{x:1135,y:733,t:1527023548158};\\\", \\\"{x:1149,y:738,t:1527023548175};\\\", \\\"{x:1165,y:744,t:1527023548192};\\\", \\\"{x:1182,y:753,t:1527023548208};\\\", \\\"{x:1195,y:763,t:1527023548226};\\\", \\\"{x:1208,y:772,t:1527023548243};\\\", \\\"{x:1226,y:784,t:1527023548258};\\\", \\\"{x:1242,y:794,t:1527023548275};\\\", \\\"{x:1256,y:804,t:1527023548292};\\\", \\\"{x:1272,y:813,t:1527023548308};\\\", \\\"{x:1284,y:824,t:1527023548325};\\\", \\\"{x:1291,y:833,t:1527023548343};\\\", \\\"{x:1298,y:844,t:1527023548359};\\\", \\\"{x:1302,y:852,t:1527023548375};\\\", \\\"{x:1304,y:859,t:1527023548392};\\\", \\\"{x:1310,y:871,t:1527023548408};\\\", \\\"{x:1316,y:880,t:1527023548426};\\\", \\\"{x:1321,y:884,t:1527023548443};\\\", \\\"{x:1325,y:888,t:1527023548459};\\\", \\\"{x:1332,y:890,t:1527023548475};\\\", \\\"{x:1343,y:893,t:1527023548492};\\\", \\\"{x:1358,y:893,t:1527023548509};\\\", \\\"{x:1377,y:893,t:1527023548526};\\\", \\\"{x:1407,y:893,t:1527023548542};\\\", \\\"{x:1423,y:893,t:1527023548558};\\\", \\\"{x:1431,y:893,t:1527023548574};\\\", \\\"{x:1435,y:893,t:1527023548592};\\\", \\\"{x:1437,y:893,t:1527023548609};\\\", \\\"{x:1439,y:893,t:1527023548625};\\\", \\\"{x:1440,y:893,t:1527023548662};\\\", \\\"{x:1440,y:892,t:1527023548767};\\\", \\\"{x:1441,y:891,t:1527023548807};\\\", \\\"{x:1441,y:890,t:1527023548823};\\\", \\\"{x:1441,y:887,t:1527023548831};\\\", \\\"{x:1442,y:886,t:1527023548842};\\\", \\\"{x:1443,y:882,t:1527023548859};\\\", \\\"{x:1446,y:877,t:1527023548875};\\\", \\\"{x:1449,y:870,t:1527023548893};\\\", \\\"{x:1455,y:862,t:1527023548909};\\\", \\\"{x:1458,y:856,t:1527023548925};\\\", \\\"{x:1463,y:848,t:1527023548942};\\\", \\\"{x:1470,y:830,t:1527023548959};\\\", \\\"{x:1475,y:818,t:1527023548977};\\\", \\\"{x:1478,y:812,t:1527023548992};\\\", \\\"{x:1481,y:806,t:1527023549010};\\\", \\\"{x:1483,y:800,t:1527023549026};\\\", \\\"{x:1485,y:794,t:1527023549043};\\\", \\\"{x:1489,y:780,t:1527023549059};\\\", \\\"{x:1492,y:766,t:1527023549076};\\\", \\\"{x:1496,y:751,t:1527023549092};\\\", \\\"{x:1496,y:741,t:1527023549109};\\\", \\\"{x:1496,y:730,t:1527023549126};\\\", \\\"{x:1495,y:721,t:1527023549143};\\\", \\\"{x:1491,y:716,t:1527023549159};\\\", \\\"{x:1487,y:714,t:1527023549177};\\\", \\\"{x:1483,y:712,t:1527023549192};\\\", \\\"{x:1474,y:712,t:1527023549209};\\\", \\\"{x:1463,y:712,t:1527023549226};\\\", \\\"{x:1452,y:714,t:1527023549242};\\\", \\\"{x:1441,y:718,t:1527023549259};\\\", \\\"{x:1429,y:722,t:1527023549277};\\\", \\\"{x:1424,y:723,t:1527023549293};\\\", \\\"{x:1420,y:724,t:1527023549309};\\\", \\\"{x:1419,y:726,t:1527023549326};\\\", \\\"{x:1418,y:726,t:1527023549343};\\\", \\\"{x:1416,y:726,t:1527023549366};\\\", \\\"{x:1415,y:727,t:1527023549375};\\\", \\\"{x:1410,y:730,t:1527023549392};\\\", \\\"{x:1407,y:733,t:1527023549408};\\\", \\\"{x:1405,y:735,t:1527023549426};\\\", \\\"{x:1402,y:736,t:1527023549443};\\\", \\\"{x:1401,y:737,t:1527023549459};\\\", \\\"{x:1400,y:738,t:1527023549475};\\\", \\\"{x:1399,y:738,t:1527023549583};\\\", \\\"{x:1398,y:737,t:1527023549655};\\\", \\\"{x:1395,y:736,t:1527023549671};\\\", \\\"{x:1391,y:736,t:1527023549678};\\\", \\\"{x:1382,y:735,t:1527023549693};\\\", \\\"{x:1364,y:730,t:1527023549709};\\\", \\\"{x:1339,y:723,t:1527023549726};\\\", \\\"{x:1335,y:721,t:1527023549743};\\\", \\\"{x:1334,y:720,t:1527023549759};\\\", \\\"{x:1332,y:719,t:1527023549847};\\\", \\\"{x:1332,y:718,t:1527023549863};\\\", \\\"{x:1332,y:717,t:1527023549876};\\\", \\\"{x:1332,y:716,t:1527023549894};\\\", \\\"{x:1330,y:716,t:1527023550127};\\\", \\\"{x:1320,y:716,t:1527023550143};\\\", \\\"{x:1309,y:716,t:1527023550160};\\\", \\\"{x:1300,y:716,t:1527023550176};\\\", \\\"{x:1293,y:716,t:1527023550194};\\\", \\\"{x:1285,y:716,t:1527023550210};\\\", \\\"{x:1278,y:716,t:1527023550226};\\\", \\\"{x:1270,y:716,t:1527023550243};\\\", \\\"{x:1266,y:716,t:1527023550261};\\\", \\\"{x:1263,y:716,t:1527023550276};\\\", \\\"{x:1262,y:716,t:1527023550295};\\\", \\\"{x:1260,y:716,t:1527023550311};\\\", \\\"{x:1251,y:716,t:1527023550327};\\\", \\\"{x:1234,y:716,t:1527023550343};\\\", \\\"{x:1215,y:716,t:1527023550360};\\\", \\\"{x:1203,y:716,t:1527023550376};\\\", \\\"{x:1195,y:716,t:1527023550393};\\\", \\\"{x:1186,y:715,t:1527023550410};\\\", \\\"{x:1171,y:712,t:1527023550428};\\\", \\\"{x:1141,y:708,t:1527023550443};\\\", \\\"{x:1116,y:700,t:1527023550460};\\\", \\\"{x:1100,y:696,t:1527023550477};\\\", \\\"{x:1091,y:693,t:1527023550493};\\\", \\\"{x:1083,y:690,t:1527023550510};\\\", \\\"{x:1061,y:688,t:1527023550527};\\\", \\\"{x:1028,y:683,t:1527023550543};\\\", \\\"{x:999,y:678,t:1527023550560};\\\", \\\"{x:978,y:673,t:1527023550578};\\\", \\\"{x:967,y:670,t:1527023550593};\\\", \\\"{x:961,y:669,t:1527023550610};\\\", \\\"{x:955,y:668,t:1527023550627};\\\", \\\"{x:937,y:664,t:1527023550643};\\\", \\\"{x:912,y:660,t:1527023550660};\\\", \\\"{x:895,y:655,t:1527023550678};\\\", \\\"{x:891,y:653,t:1527023550693};\\\", \\\"{x:889,y:653,t:1527023550710};\\\", \\\"{x:888,y:653,t:1527023550735};\\\", \\\"{x:885,y:653,t:1527023550743};\\\", \\\"{x:870,y:651,t:1527023550760};\\\", \\\"{x:851,y:647,t:1527023550777};\\\", \\\"{x:837,y:642,t:1527023550793};\\\", \\\"{x:830,y:641,t:1527023550811};\\\", \\\"{x:826,y:639,t:1527023550827};\\\", \\\"{x:823,y:639,t:1527023550843};\\\", \\\"{x:815,y:638,t:1527023550860};\\\", \\\"{x:798,y:633,t:1527023550877};\\\", \\\"{x:778,y:627,t:1527023550896};\\\", \\\"{x:770,y:622,t:1527023550909};\\\", \\\"{x:765,y:621,t:1527023550927};\\\", \\\"{x:762,y:619,t:1527023550943};\\\", \\\"{x:752,y:610,t:1527023550961};\\\", \\\"{x:734,y:597,t:1527023550977};\\\", \\\"{x:714,y:582,t:1527023550994};\\\", \\\"{x:698,y:575,t:1527023551011};\\\", \\\"{x:695,y:572,t:1527023551027};\\\", \\\"{x:693,y:571,t:1527023551044};\\\", \\\"{x:693,y:569,t:1527023551061};\\\", \\\"{x:689,y:562,t:1527023551077};\\\", \\\"{x:679,y:542,t:1527023551095};\\\", \\\"{x:673,y:530,t:1527023551111};\\\", \\\"{x:670,y:523,t:1527023551128};\\\", \\\"{x:669,y:521,t:1527023551143};\\\", \\\"{x:668,y:519,t:1527023551161};\\\", \\\"{x:667,y:516,t:1527023551179};\\\", \\\"{x:665,y:513,t:1527023551194};\\\", \\\"{x:663,y:511,t:1527023551211};\\\", \\\"{x:653,y:507,t:1527023551228};\\\", \\\"{x:631,y:505,t:1527023551245};\\\", \\\"{x:598,y:500,t:1527023551261};\\\", \\\"{x:569,y:498,t:1527023551277};\\\", \\\"{x:551,y:498,t:1527023551294};\\\", \\\"{x:545,y:498,t:1527023551311};\\\", \\\"{x:541,y:498,t:1527023551327};\\\", \\\"{x:532,y:501,t:1527023551344};\\\", \\\"{x:519,y:506,t:1527023551361};\\\", \\\"{x:508,y:509,t:1527023551378};\\\", \\\"{x:506,y:509,t:1527023551394};\\\", \\\"{x:503,y:510,t:1527023551410};\\\", \\\"{x:496,y:510,t:1527023551429};\\\", \\\"{x:482,y:511,t:1527023551444};\\\", \\\"{x:459,y:511,t:1527023551461};\\\", \\\"{x:425,y:511,t:1527023551477};\\\", \\\"{x:416,y:511,t:1527023551494};\\\", \\\"{x:403,y:512,t:1527023551511};\\\", \\\"{x:388,y:514,t:1527023551527};\\\", \\\"{x:364,y:514,t:1527023551543};\\\", \\\"{x:326,y:514,t:1527023551561};\\\", \\\"{x:307,y:514,t:1527023551578};\\\", \\\"{x:294,y:514,t:1527023551594};\\\", \\\"{x:287,y:515,t:1527023551611};\\\", \\\"{x:280,y:516,t:1527023551628};\\\", \\\"{x:265,y:519,t:1527023551644};\\\", \\\"{x:254,y:521,t:1527023551661};\\\", \\\"{x:248,y:523,t:1527023551678};\\\", \\\"{x:247,y:523,t:1527023551694};\\\", \\\"{x:247,y:524,t:1527023551711};\\\", \\\"{x:242,y:527,t:1527023551730};\\\", \\\"{x:233,y:533,t:1527023551744};\\\", \\\"{x:225,y:537,t:1527023551761};\\\", \\\"{x:217,y:541,t:1527023551778};\\\", \\\"{x:211,y:544,t:1527023551795};\\\", \\\"{x:201,y:548,t:1527023551810};\\\", \\\"{x:186,y:552,t:1527023551828};\\\", \\\"{x:171,y:554,t:1527023551845};\\\", \\\"{x:157,y:555,t:1527023551861};\\\", \\\"{x:141,y:556,t:1527023551879};\\\", \\\"{x:138,y:556,t:1527023551894};\\\", \\\"{x:136,y:556,t:1527023551911};\\\", \\\"{x:135,y:556,t:1527023551975};\\\", \\\"{x:132,y:556,t:1527023551990};\\\", \\\"{x:131,y:554,t:1527023552007};\\\", \\\"{x:130,y:549,t:1527023552028};\\\", \\\"{x:130,y:548,t:1527023552044};\\\", \\\"{x:130,y:545,t:1527023552061};\\\", \\\"{x:130,y:544,t:1527023552078};\\\", \\\"{x:131,y:541,t:1527023552094};\\\", \\\"{x:133,y:540,t:1527023552112};\\\", \\\"{x:135,y:540,t:1527023552127};\\\", \\\"{x:136,y:539,t:1527023552144};\\\", \\\"{x:137,y:538,t:1527023552182};\\\", \\\"{x:139,y:537,t:1527023552195};\\\", \\\"{x:141,y:537,t:1527023552212};\\\", \\\"{x:142,y:537,t:1527023552228};\\\", \\\"{x:144,y:535,t:1527023552245};\\\", \\\"{x:145,y:535,t:1527023552262};\\\", \\\"{x:147,y:534,t:1527023552279};\\\", \\\"{x:150,y:533,t:1527023552296};\\\", \\\"{x:151,y:532,t:1527023552312};\\\", \\\"{x:152,y:532,t:1527023552328};\\\", \\\"{x:153,y:532,t:1527023552350};\\\", \\\"{x:155,y:531,t:1527023552366};\\\", \\\"{x:156,y:531,t:1527023552726};\\\", \\\"{x:160,y:532,t:1527023552733};\\\", \\\"{x:167,y:535,t:1527023552745};\\\", \\\"{x:187,y:544,t:1527023552762};\\\", \\\"{x:222,y:558,t:1527023552778};\\\", \\\"{x:266,y:578,t:1527023552795};\\\", \\\"{x:302,y:595,t:1527023552813};\\\", \\\"{x:346,y:620,t:1527023552829};\\\", \\\"{x:392,y:647,t:1527023552845};\\\", \\\"{x:441,y:675,t:1527023552862};\\\", \\\"{x:466,y:692,t:1527023552878};\\\", \\\"{x:482,y:703,t:1527023552895};\\\", \\\"{x:491,y:710,t:1527023552911};\\\", \\\"{x:501,y:719,t:1527023552929};\\\", \\\"{x:507,y:724,t:1527023552945};\\\", \\\"{x:512,y:729,t:1527023552962};\\\", \\\"{x:515,y:732,t:1527023552978};\\\", \\\"{x:522,y:738,t:1527023552995};\\\", \\\"{x:530,y:743,t:1527023553012};\\\", \\\"{x:538,y:749,t:1527023553029};\\\", \\\"{x:548,y:757,t:1527023553046};\\\", \\\"{x:550,y:760,t:1527023553063};\\\", \\\"{x:552,y:762,t:1527023553078};\\\", \\\"{x:555,y:765,t:1527023553095};\\\", \\\"{x:561,y:768,t:1527023553112};\\\", \\\"{x:568,y:771,t:1527023553129};\\\", \\\"{x:571,y:773,t:1527023553146};\\\", \\\"{x:573,y:773,t:1527023553162};\\\", \\\"{x:574,y:774,t:1527023553179};\\\", \\\"{x:575,y:774,t:1527023553206};\\\", \\\"{x:576,y:775,t:1527023553214};\\\", \\\"{x:578,y:775,t:1527023553229};\\\", \\\"{x:582,y:776,t:1527023553246};\\\", \\\"{x:582,y:773,t:1527023553575};\\\", \\\"{x:580,y:771,t:1527023553583};\\\", \\\"{x:575,y:766,t:1527023553596};\\\", \\\"{x:568,y:759,t:1527023553613};\\\", \\\"{x:564,y:756,t:1527023553629};\\\", \\\"{x:562,y:755,t:1527023553646};\\\", \\\"{x:561,y:755,t:1527023553695};\\\", \\\"{x:561,y:754,t:1527023553703};\\\", \\\"{x:560,y:754,t:1527023553713};\\\", \\\"{x:559,y:753,t:1527023553730};\\\", \\\"{x:555,y:750,t:1527023553746};\\\", \\\"{x:554,y:750,t:1527023553765};\\\", \\\"{x:553,y:749,t:1527023553830};\\\", \\\"{x:550,y:747,t:1527023553845};\\\", \\\"{x:547,y:744,t:1527023553862};\\\", \\\"{x:545,y:742,t:1527023553880};\\\", \\\"{x:544,y:742,t:1527023553896};\\\", \\\"{x:543,y:741,t:1527023553925};\\\", \\\"{x:542,y:741,t:1527023553934};\\\", \\\"{x:541,y:740,t:1527023553946};\\\", \\\"{x:538,y:739,t:1527023553962};\\\", \\\"{x:535,y:737,t:1527023553980};\\\", \\\"{x:534,y:737,t:1527023553996};\\\", \\\"{x:533,y:737,t:1527023554054};\\\", \\\"{x:532,y:737,t:1527023554063};\\\", \\\"{x:530,y:736,t:1527023554080};\\\", \\\"{x:528,y:736,t:1527023554096};\\\", \\\"{x:526,y:736,t:1527023554543};\\\", \\\"{x:525,y:736,t:1527023554550};\\\" ] }, { \\\"rt\\\": 16980, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 432765, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"OZV09\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"L\\\", \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -N -H -L -L -P -Z -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:526,y:736,t:1527023558407};\\\", \\\"{x:535,y:736,t:1527023558440};\\\", \\\"{x:538,y:737,t:1527023558451};\\\", \\\"{x:545,y:738,t:1527023558467};\\\", \\\"{x:553,y:739,t:1527023558484};\\\", \\\"{x:559,y:741,t:1527023558501};\\\", \\\"{x:562,y:741,t:1527023558517};\\\", \\\"{x:568,y:741,t:1527023558534};\\\", \\\"{x:570,y:742,t:1527023558551};\\\", \\\"{x:575,y:742,t:1527023558568};\\\", \\\"{x:578,y:743,t:1527023558583};\\\", \\\"{x:582,y:743,t:1527023558600};\\\", \\\"{x:588,y:744,t:1527023558616};\\\", \\\"{x:593,y:745,t:1527023558632};\\\", \\\"{x:598,y:745,t:1527023558650};\\\", \\\"{x:605,y:746,t:1527023558666};\\\", \\\"{x:609,y:746,t:1527023558683};\\\", \\\"{x:615,y:746,t:1527023558700};\\\", \\\"{x:622,y:746,t:1527023558718};\\\", \\\"{x:629,y:747,t:1527023558734};\\\", \\\"{x:640,y:749,t:1527023558751};\\\", \\\"{x:653,y:750,t:1527023558766};\\\", \\\"{x:667,y:753,t:1527023558783};\\\", \\\"{x:687,y:756,t:1527023558801};\\\", \\\"{x:708,y:760,t:1527023558817};\\\", \\\"{x:726,y:762,t:1527023558833};\\\", \\\"{x:751,y:767,t:1527023558850};\\\", \\\"{x:779,y:771,t:1527023558867};\\\", \\\"{x:823,y:777,t:1527023558883};\\\", \\\"{x:881,y:785,t:1527023558900};\\\", \\\"{x:937,y:793,t:1527023558917};\\\", \\\"{x:988,y:801,t:1527023558933};\\\", \\\"{x:1046,y:811,t:1527023558951};\\\", \\\"{x:1079,y:818,t:1527023558967};\\\", \\\"{x:1118,y:824,t:1527023558983};\\\", \\\"{x:1158,y:832,t:1527023559000};\\\", \\\"{x:1192,y:841,t:1527023559017};\\\", \\\"{x:1225,y:849,t:1527023559033};\\\", \\\"{x:1261,y:854,t:1527023559050};\\\", \\\"{x:1290,y:857,t:1527023559067};\\\", \\\"{x:1318,y:862,t:1527023559083};\\\", \\\"{x:1344,y:866,t:1527023559101};\\\", \\\"{x:1375,y:871,t:1527023559117};\\\", \\\"{x:1399,y:873,t:1527023559133};\\\", \\\"{x:1424,y:878,t:1527023559150};\\\", \\\"{x:1436,y:879,t:1527023559167};\\\", \\\"{x:1439,y:879,t:1527023559185};\\\", \\\"{x:1445,y:881,t:1527023559201};\\\", \\\"{x:1451,y:881,t:1527023559218};\\\", \\\"{x:1457,y:882,t:1527023559235};\\\", \\\"{x:1462,y:883,t:1527023559251};\\\", \\\"{x:1464,y:885,t:1527023559268};\\\", \\\"{x:1465,y:885,t:1527023559284};\\\", \\\"{x:1466,y:886,t:1527023559359};\\\", \\\"{x:1466,y:887,t:1527023559368};\\\", \\\"{x:1466,y:888,t:1527023559384};\\\", \\\"{x:1464,y:892,t:1527023559400};\\\", \\\"{x:1461,y:896,t:1527023559418};\\\", \\\"{x:1459,y:900,t:1527023559434};\\\", \\\"{x:1456,y:902,t:1527023559451};\\\", \\\"{x:1455,y:903,t:1527023559467};\\\", \\\"{x:1454,y:903,t:1527023559486};\\\", \\\"{x:1453,y:904,t:1527023559500};\\\", \\\"{x:1448,y:906,t:1527023559517};\\\", \\\"{x:1441,y:908,t:1527023559535};\\\", \\\"{x:1440,y:908,t:1527023559631};\\\", \\\"{x:1438,y:908,t:1527023559703};\\\", \\\"{x:1437,y:907,t:1527023559719};\\\", \\\"{x:1436,y:906,t:1527023559734};\\\", \\\"{x:1433,y:902,t:1527023559752};\\\", \\\"{x:1432,y:901,t:1527023559767};\\\", \\\"{x:1431,y:900,t:1527023559785};\\\", \\\"{x:1431,y:899,t:1527023559801};\\\", \\\"{x:1431,y:898,t:1527023559823};\\\", \\\"{x:1430,y:897,t:1527023559834};\\\", \\\"{x:1429,y:896,t:1527023559863};\\\", \\\"{x:1429,y:895,t:1527023559911};\\\", \\\"{x:1429,y:894,t:1527023559959};\\\", \\\"{x:1428,y:894,t:1527023559975};\\\", \\\"{x:1427,y:894,t:1527023560086};\\\", \\\"{x:1426,y:894,t:1527023560118};\\\", \\\"{x:1425,y:894,t:1527023560142};\\\", \\\"{x:1424,y:894,t:1527023560151};\\\", \\\"{x:1420,y:894,t:1527023560169};\\\", \\\"{x:1417,y:895,t:1527023560184};\\\", \\\"{x:1414,y:895,t:1527023560202};\\\", \\\"{x:1412,y:895,t:1527023560218};\\\", \\\"{x:1411,y:895,t:1527023560283};\\\", \\\"{x:1410,y:897,t:1527023560307};\\\", \\\"{x:1408,y:897,t:1527023560321};\\\", \\\"{x:1406,y:897,t:1527023560338};\\\", \\\"{x:1404,y:897,t:1527023560355};\\\", \\\"{x:1402,y:897,t:1527023560373};\\\", \\\"{x:1401,y:897,t:1527023560388};\\\", \\\"{x:1398,y:897,t:1527023560406};\\\", \\\"{x:1394,y:897,t:1527023560422};\\\", \\\"{x:1389,y:897,t:1527023560438};\\\", \\\"{x:1388,y:897,t:1527023560455};\\\", \\\"{x:1385,y:897,t:1527023560475};\\\", \\\"{x:1382,y:897,t:1527023560488};\\\", \\\"{x:1377,y:897,t:1527023560504};\\\", \\\"{x:1364,y:896,t:1527023560522};\\\", \\\"{x:1349,y:892,t:1527023560539};\\\", \\\"{x:1334,y:887,t:1527023560555};\\\", \\\"{x:1328,y:885,t:1527023560571};\\\", \\\"{x:1325,y:883,t:1527023560588};\\\", \\\"{x:1324,y:883,t:1527023560604};\\\", \\\"{x:1320,y:881,t:1527023560622};\\\", \\\"{x:1310,y:877,t:1527023560639};\\\", \\\"{x:1296,y:872,t:1527023560655};\\\", \\\"{x:1287,y:868,t:1527023560672};\\\", \\\"{x:1284,y:865,t:1527023560689};\\\", \\\"{x:1283,y:865,t:1527023560705};\\\", \\\"{x:1280,y:864,t:1527023560721};\\\", \\\"{x:1277,y:864,t:1527023560739};\\\", \\\"{x:1270,y:860,t:1527023560756};\\\", \\\"{x:1265,y:859,t:1527023560772};\\\", \\\"{x:1263,y:859,t:1527023560789};\\\", \\\"{x:1263,y:858,t:1527023560810};\\\", \\\"{x:1262,y:858,t:1527023560826};\\\", \\\"{x:1261,y:858,t:1527023560843};\\\", \\\"{x:1260,y:858,t:1527023560874};\\\", \\\"{x:1259,y:858,t:1527023560914};\\\", \\\"{x:1258,y:858,t:1527023560930};\\\", \\\"{x:1257,y:858,t:1527023560963};\\\", \\\"{x:1256,y:858,t:1527023560978};\\\", \\\"{x:1255,y:858,t:1527023561059};\\\", \\\"{x:1255,y:857,t:1527023561074};\\\", \\\"{x:1255,y:856,t:1527023561090};\\\", \\\"{x:1259,y:851,t:1527023561106};\\\", \\\"{x:1267,y:848,t:1527023561122};\\\", \\\"{x:1275,y:842,t:1527023561140};\\\", \\\"{x:1289,y:835,t:1527023561156};\\\", \\\"{x:1305,y:829,t:1527023561172};\\\", \\\"{x:1319,y:825,t:1527023561189};\\\", \\\"{x:1329,y:824,t:1527023561206};\\\", \\\"{x:1340,y:821,t:1527023561222};\\\", \\\"{x:1344,y:821,t:1527023561239};\\\", \\\"{x:1348,y:819,t:1527023561256};\\\", \\\"{x:1354,y:816,t:1527023561272};\\\", \\\"{x:1367,y:806,t:1527023561290};\\\", \\\"{x:1391,y:788,t:1527023561306};\\\", \\\"{x:1408,y:777,t:1527023561323};\\\", \\\"{x:1421,y:767,t:1527023561339};\\\", \\\"{x:1433,y:757,t:1527023561356};\\\", \\\"{x:1439,y:749,t:1527023561372};\\\", \\\"{x:1445,y:733,t:1527023561389};\\\", \\\"{x:1454,y:711,t:1527023561406};\\\", \\\"{x:1466,y:680,t:1527023561423};\\\", \\\"{x:1480,y:637,t:1527023561439};\\\", \\\"{x:1494,y:592,t:1527023561456};\\\", \\\"{x:1501,y:568,t:1527023561474};\\\", \\\"{x:1506,y:551,t:1527023561489};\\\", \\\"{x:1511,y:518,t:1527023561506};\\\", \\\"{x:1518,y:477,t:1527023561523};\\\", \\\"{x:1520,y:456,t:1527023561540};\\\", \\\"{x:1528,y:434,t:1527023561556};\\\", \\\"{x:1534,y:413,t:1527023561573};\\\", \\\"{x:1537,y:397,t:1527023561589};\\\", \\\"{x:1540,y:382,t:1527023561607};\\\", \\\"{x:1542,y:366,t:1527023561623};\\\", \\\"{x:1544,y:362,t:1527023561640};\\\", \\\"{x:1544,y:360,t:1527023561657};\\\", \\\"{x:1544,y:358,t:1527023561673};\\\", \\\"{x:1544,y:352,t:1527023561689};\\\", \\\"{x:1544,y:338,t:1527023561706};\\\", \\\"{x:1544,y:329,t:1527023561724};\\\", \\\"{x:1540,y:323,t:1527023561739};\\\", \\\"{x:1537,y:320,t:1527023561756};\\\", \\\"{x:1530,y:317,t:1527023561774};\\\", \\\"{x:1527,y:316,t:1527023561790};\\\", \\\"{x:1525,y:314,t:1527023561806};\\\", \\\"{x:1524,y:313,t:1527023561823};\\\", \\\"{x:1524,y:312,t:1527023561840};\\\", \\\"{x:1523,y:311,t:1527023561856};\\\", \\\"{x:1521,y:312,t:1527023561914};\\\", \\\"{x:1521,y:316,t:1527023561924};\\\", \\\"{x:1520,y:335,t:1527023561941};\\\", \\\"{x:1520,y:358,t:1527023561956};\\\", \\\"{x:1520,y:385,t:1527023561974};\\\", \\\"{x:1524,y:409,t:1527023561990};\\\", \\\"{x:1531,y:430,t:1527023562007};\\\", \\\"{x:1542,y:454,t:1527023562024};\\\", \\\"{x:1551,y:474,t:1527023562041};\\\", \\\"{x:1561,y:493,t:1527023562056};\\\", \\\"{x:1569,y:511,t:1527023562074};\\\", \\\"{x:1581,y:541,t:1527023562089};\\\", \\\"{x:1590,y:560,t:1527023562106};\\\", \\\"{x:1596,y:576,t:1527023562123};\\\", \\\"{x:1606,y:592,t:1527023562141};\\\", \\\"{x:1619,y:610,t:1527023562156};\\\", \\\"{x:1630,y:625,t:1527023562174};\\\", \\\"{x:1640,y:637,t:1527023562191};\\\", \\\"{x:1653,y:655,t:1527023562207};\\\", \\\"{x:1666,y:674,t:1527023562224};\\\", \\\"{x:1676,y:694,t:1527023562240};\\\", \\\"{x:1682,y:711,t:1527023562257};\\\", \\\"{x:1690,y:730,t:1527023562274};\\\", \\\"{x:1703,y:760,t:1527023562290};\\\", \\\"{x:1706,y:772,t:1527023562307};\\\", \\\"{x:1708,y:779,t:1527023562324};\\\", \\\"{x:1709,y:785,t:1527023562340};\\\", \\\"{x:1709,y:791,t:1527023562357};\\\", \\\"{x:1709,y:795,t:1527023562374};\\\", \\\"{x:1704,y:802,t:1527023562390};\\\", \\\"{x:1700,y:806,t:1527023562407};\\\", \\\"{x:1697,y:810,t:1527023562424};\\\", \\\"{x:1695,y:811,t:1527023562440};\\\", \\\"{x:1692,y:814,t:1527023562457};\\\", \\\"{x:1689,y:815,t:1527023562473};\\\", \\\"{x:1676,y:819,t:1527023562490};\\\", \\\"{x:1666,y:822,t:1527023562508};\\\", \\\"{x:1659,y:822,t:1527023562524};\\\", \\\"{x:1655,y:822,t:1527023562540};\\\", \\\"{x:1651,y:821,t:1527023562558};\\\", \\\"{x:1646,y:816,t:1527023562574};\\\", \\\"{x:1640,y:802,t:1527023562591};\\\", \\\"{x:1631,y:784,t:1527023562608};\\\", \\\"{x:1618,y:762,t:1527023562623};\\\", \\\"{x:1602,y:739,t:1527023562641};\\\", \\\"{x:1595,y:722,t:1527023562657};\\\", \\\"{x:1589,y:706,t:1527023562673};\\\", \\\"{x:1582,y:681,t:1527023562690};\\\", \\\"{x:1579,y:668,t:1527023562707};\\\", \\\"{x:1577,y:659,t:1527023562723};\\\", \\\"{x:1575,y:654,t:1527023562741};\\\", \\\"{x:1573,y:652,t:1527023562758};\\\", \\\"{x:1573,y:651,t:1527023562891};\\\", \\\"{x:1573,y:648,t:1527023562908};\\\", \\\"{x:1575,y:644,t:1527023562924};\\\", \\\"{x:1577,y:642,t:1527023562941};\\\", \\\"{x:1580,y:639,t:1527023562957};\\\", \\\"{x:1581,y:638,t:1527023562974};\\\", \\\"{x:1583,y:637,t:1527023562990};\\\", \\\"{x:1584,y:634,t:1527023563007};\\\", \\\"{x:1591,y:623,t:1527023563024};\\\", \\\"{x:1603,y:607,t:1527023563040};\\\", \\\"{x:1611,y:590,t:1527023563057};\\\", \\\"{x:1617,y:560,t:1527023563073};\\\", \\\"{x:1620,y:534,t:1527023563090};\\\", \\\"{x:1620,y:499,t:1527023563107};\\\", \\\"{x:1621,y:476,t:1527023563124};\\\", \\\"{x:1621,y:457,t:1527023563140};\\\", \\\"{x:1621,y:441,t:1527023563157};\\\", \\\"{x:1621,y:425,t:1527023563174};\\\", \\\"{x:1621,y:411,t:1527023563191};\\\", \\\"{x:1620,y:400,t:1527023563207};\\\", \\\"{x:1618,y:391,t:1527023563224};\\\", \\\"{x:1616,y:382,t:1527023563241};\\\", \\\"{x:1615,y:379,t:1527023563257};\\\", \\\"{x:1614,y:376,t:1527023563273};\\\", \\\"{x:1610,y:379,t:1527023563451};\\\", \\\"{x:1610,y:384,t:1527023563458};\\\", \\\"{x:1606,y:394,t:1527023563475};\\\", \\\"{x:1602,y:404,t:1527023563491};\\\", \\\"{x:1601,y:410,t:1527023563508};\\\", \\\"{x:1597,y:420,t:1527023563524};\\\", \\\"{x:1594,y:432,t:1527023563542};\\\", \\\"{x:1591,y:443,t:1527023563558};\\\", \\\"{x:1589,y:452,t:1527023563575};\\\", \\\"{x:1587,y:462,t:1527023563592};\\\", \\\"{x:1583,y:473,t:1527023563609};\\\", \\\"{x:1581,y:481,t:1527023563625};\\\", \\\"{x:1577,y:492,t:1527023563642};\\\", \\\"{x:1571,y:517,t:1527023563659};\\\", \\\"{x:1567,y:528,t:1527023563675};\\\", \\\"{x:1563,y:545,t:1527023563691};\\\", \\\"{x:1557,y:564,t:1527023563709};\\\", \\\"{x:1552,y:581,t:1527023563724};\\\", \\\"{x:1548,y:596,t:1527023563741};\\\", \\\"{x:1542,y:620,t:1527023563758};\\\", \\\"{x:1540,y:649,t:1527023563774};\\\", \\\"{x:1539,y:673,t:1527023563791};\\\", \\\"{x:1539,y:696,t:1527023563809};\\\", \\\"{x:1539,y:719,t:1527023563825};\\\", \\\"{x:1539,y:742,t:1527023563842};\\\", \\\"{x:1541,y:775,t:1527023563858};\\\", \\\"{x:1547,y:796,t:1527023563874};\\\", \\\"{x:1553,y:812,t:1527023563892};\\\", \\\"{x:1556,y:818,t:1527023563909};\\\", \\\"{x:1560,y:824,t:1527023563925};\\\", \\\"{x:1561,y:827,t:1527023563942};\\\", \\\"{x:1562,y:831,t:1527023563958};\\\", \\\"{x:1564,y:836,t:1527023563974};\\\", \\\"{x:1565,y:838,t:1527023563991};\\\", \\\"{x:1565,y:839,t:1527023564008};\\\", \\\"{x:1565,y:841,t:1527023564024};\\\", \\\"{x:1564,y:843,t:1527023564041};\\\", \\\"{x:1557,y:851,t:1527023564058};\\\", \\\"{x:1553,y:855,t:1527023564075};\\\", \\\"{x:1543,y:864,t:1527023564091};\\\", \\\"{x:1530,y:871,t:1527023564109};\\\", \\\"{x:1514,y:881,t:1527023564126};\\\", \\\"{x:1497,y:887,t:1527023564141};\\\", \\\"{x:1490,y:891,t:1527023564158};\\\", \\\"{x:1487,y:892,t:1527023564176};\\\", \\\"{x:1484,y:894,t:1527023564191};\\\", \\\"{x:1477,y:897,t:1527023564208};\\\", \\\"{x:1472,y:899,t:1527023564226};\\\", \\\"{x:1467,y:899,t:1527023564242};\\\", \\\"{x:1465,y:899,t:1527023564259};\\\", \\\"{x:1464,y:899,t:1527023564275};\\\", \\\"{x:1463,y:899,t:1527023564291};\\\", \\\"{x:1462,y:899,t:1527023564308};\\\", \\\"{x:1461,y:899,t:1527023564401};\\\", \\\"{x:1459,y:899,t:1527023564409};\\\", \\\"{x:1457,y:898,t:1527023564425};\\\", \\\"{x:1450,y:887,t:1527023564441};\\\", \\\"{x:1439,y:874,t:1527023564458};\\\", \\\"{x:1429,y:864,t:1527023564475};\\\", \\\"{x:1425,y:861,t:1527023564492};\\\", \\\"{x:1424,y:860,t:1527023564508};\\\", \\\"{x:1422,y:858,t:1527023564525};\\\", \\\"{x:1421,y:856,t:1527023564542};\\\", \\\"{x:1418,y:852,t:1527023564558};\\\", \\\"{x:1412,y:847,t:1527023564576};\\\", \\\"{x:1397,y:841,t:1527023564592};\\\", \\\"{x:1384,y:839,t:1527023564608};\\\", \\\"{x:1381,y:838,t:1527023564625};\\\", \\\"{x:1375,y:838,t:1527023564641};\\\", \\\"{x:1372,y:837,t:1527023564658};\\\", \\\"{x:1367,y:837,t:1527023564675};\\\", \\\"{x:1357,y:835,t:1527023564692};\\\", \\\"{x:1344,y:834,t:1527023564708};\\\", \\\"{x:1339,y:834,t:1527023564725};\\\", \\\"{x:1335,y:834,t:1527023564743};\\\", \\\"{x:1330,y:834,t:1527023564758};\\\", \\\"{x:1326,y:834,t:1527023564776};\\\", \\\"{x:1321,y:834,t:1527023564793};\\\", \\\"{x:1316,y:838,t:1527023564808};\\\", \\\"{x:1311,y:839,t:1527023564826};\\\", \\\"{x:1309,y:840,t:1527023564842};\\\", \\\"{x:1306,y:842,t:1527023564858};\\\", \\\"{x:1299,y:848,t:1527023564875};\\\", \\\"{x:1291,y:855,t:1527023564892};\\\", \\\"{x:1287,y:858,t:1527023564908};\\\", \\\"{x:1285,y:859,t:1527023564925};\\\", \\\"{x:1283,y:860,t:1527023564942};\\\", \\\"{x:1282,y:860,t:1527023565003};\\\", \\\"{x:1282,y:859,t:1527023565034};\\\", \\\"{x:1282,y:855,t:1527023565042};\\\", \\\"{x:1289,y:841,t:1527023565059};\\\", \\\"{x:1295,y:833,t:1527023565076};\\\", \\\"{x:1301,y:826,t:1527023565092};\\\", \\\"{x:1306,y:820,t:1527023565110};\\\", \\\"{x:1313,y:814,t:1527023565125};\\\", \\\"{x:1320,y:810,t:1527023565143};\\\", \\\"{x:1330,y:804,t:1527023565159};\\\", \\\"{x:1334,y:801,t:1527023565176};\\\", \\\"{x:1344,y:796,t:1527023565193};\\\", \\\"{x:1352,y:790,t:1527023565209};\\\", \\\"{x:1363,y:784,t:1527023565226};\\\", \\\"{x:1374,y:777,t:1527023565243};\\\", \\\"{x:1382,y:772,t:1527023565259};\\\", \\\"{x:1387,y:770,t:1527023565275};\\\", \\\"{x:1395,y:764,t:1527023565292};\\\", \\\"{x:1400,y:760,t:1527023565309};\\\", \\\"{x:1408,y:753,t:1527023565326};\\\", \\\"{x:1414,y:747,t:1527023565343};\\\", \\\"{x:1419,y:740,t:1527023565359};\\\", \\\"{x:1426,y:730,t:1527023565376};\\\", \\\"{x:1436,y:720,t:1527023565393};\\\", \\\"{x:1453,y:700,t:1527023565410};\\\", \\\"{x:1480,y:671,t:1527023565426};\\\", \\\"{x:1493,y:654,t:1527023565443};\\\", \\\"{x:1506,y:635,t:1527023565459};\\\", \\\"{x:1514,y:611,t:1527023565477};\\\", \\\"{x:1520,y:591,t:1527023565493};\\\", \\\"{x:1525,y:569,t:1527023565510};\\\", \\\"{x:1528,y:540,t:1527023565526};\\\", \\\"{x:1532,y:504,t:1527023565543};\\\", \\\"{x:1536,y:469,t:1527023565559};\\\", \\\"{x:1536,y:445,t:1527023565577};\\\", \\\"{x:1536,y:430,t:1527023565592};\\\", \\\"{x:1536,y:402,t:1527023565610};\\\", \\\"{x:1536,y:389,t:1527023565626};\\\", \\\"{x:1536,y:380,t:1527023565641};\\\", \\\"{x:1536,y:367,t:1527023565659};\\\", \\\"{x:1536,y:354,t:1527023565676};\\\", \\\"{x:1536,y:339,t:1527023565692};\\\", \\\"{x:1536,y:318,t:1527023565709};\\\", \\\"{x:1536,y:300,t:1527023565726};\\\", \\\"{x:1536,y:283,t:1527023565742};\\\", \\\"{x:1536,y:268,t:1527023565759};\\\", \\\"{x:1536,y:256,t:1527023565776};\\\", \\\"{x:1536,y:238,t:1527023565792};\\\", \\\"{x:1536,y:228,t:1527023565809};\\\", \\\"{x:1536,y:224,t:1527023565825};\\\", \\\"{x:1536,y:223,t:1527023565843};\\\", \\\"{x:1537,y:226,t:1527023565923};\\\", \\\"{x:1538,y:237,t:1527023565930};\\\", \\\"{x:1543,y:251,t:1527023565943};\\\", \\\"{x:1551,y:278,t:1527023565959};\\\", \\\"{x:1560,y:302,t:1527023565977};\\\", \\\"{x:1571,y:326,t:1527023565993};\\\", \\\"{x:1582,y:356,t:1527023566010};\\\", \\\"{x:1588,y:372,t:1527023566026};\\\", \\\"{x:1592,y:384,t:1527023566044};\\\", \\\"{x:1594,y:398,t:1527023566060};\\\", \\\"{x:1599,y:414,t:1527023566076};\\\", \\\"{x:1604,y:435,t:1527023566093};\\\", \\\"{x:1610,y:452,t:1527023566110};\\\", \\\"{x:1614,y:466,t:1527023566127};\\\", \\\"{x:1618,y:483,t:1527023566144};\\\", \\\"{x:1622,y:497,t:1527023566159};\\\", \\\"{x:1627,y:511,t:1527023566176};\\\", \\\"{x:1630,y:520,t:1527023566193};\\\", \\\"{x:1633,y:525,t:1527023566210};\\\", \\\"{x:1636,y:530,t:1527023566227};\\\", \\\"{x:1642,y:540,t:1527023566244};\\\", \\\"{x:1648,y:555,t:1527023566260};\\\", \\\"{x:1658,y:573,t:1527023566276};\\\", \\\"{x:1667,y:591,t:1527023566294};\\\", \\\"{x:1676,y:608,t:1527023566311};\\\", \\\"{x:1688,y:624,t:1527023566326};\\\", \\\"{x:1696,y:636,t:1527023566344};\\\", \\\"{x:1702,y:648,t:1527023566361};\\\", \\\"{x:1708,y:660,t:1527023566377};\\\", \\\"{x:1717,y:675,t:1527023566394};\\\", \\\"{x:1724,y:691,t:1527023566410};\\\", \\\"{x:1729,y:701,t:1527023566427};\\\", \\\"{x:1734,y:716,t:1527023566444};\\\", \\\"{x:1735,y:729,t:1527023566461};\\\", \\\"{x:1735,y:745,t:1527023566476};\\\", \\\"{x:1735,y:763,t:1527023566493};\\\", \\\"{x:1727,y:783,t:1527023566511};\\\", \\\"{x:1721,y:793,t:1527023566526};\\\", \\\"{x:1720,y:794,t:1527023566543};\\\", \\\"{x:1719,y:794,t:1527023566578};\\\", \\\"{x:1715,y:794,t:1527023566594};\\\", \\\"{x:1707,y:793,t:1527023566610};\\\", \\\"{x:1700,y:790,t:1527023566627};\\\", \\\"{x:1696,y:787,t:1527023566643};\\\", \\\"{x:1692,y:784,t:1527023566660};\\\", \\\"{x:1689,y:781,t:1527023566677};\\\", \\\"{x:1686,y:778,t:1527023566693};\\\", \\\"{x:1684,y:776,t:1527023566710};\\\", \\\"{x:1680,y:772,t:1527023566727};\\\", \\\"{x:1674,y:768,t:1527023566743};\\\", \\\"{x:1669,y:763,t:1527023566760};\\\", \\\"{x:1659,y:750,t:1527023566777};\\\", \\\"{x:1655,y:745,t:1527023566794};\\\", \\\"{x:1646,y:733,t:1527023566810};\\\", \\\"{x:1640,y:727,t:1527023566827};\\\", \\\"{x:1636,y:725,t:1527023566843};\\\", \\\"{x:1634,y:723,t:1527023566861};\\\", \\\"{x:1631,y:722,t:1527023566877};\\\", \\\"{x:1629,y:721,t:1527023566894};\\\", \\\"{x:1623,y:718,t:1527023566910};\\\", \\\"{x:1618,y:716,t:1527023566927};\\\", \\\"{x:1618,y:715,t:1527023566943};\\\", \\\"{x:1617,y:715,t:1527023566960};\\\", \\\"{x:1617,y:714,t:1527023567138};\\\", \\\"{x:1617,y:712,t:1527023567146};\\\", \\\"{x:1617,y:711,t:1527023567162};\\\", \\\"{x:1617,y:709,t:1527023567177};\\\", \\\"{x:1617,y:707,t:1527023567194};\\\", \\\"{x:1617,y:706,t:1527023567210};\\\", \\\"{x:1617,y:704,t:1527023567227};\\\", \\\"{x:1617,y:703,t:1527023567245};\\\", \\\"{x:1617,y:702,t:1527023567261};\\\", \\\"{x:1617,y:699,t:1527023567278};\\\", \\\"{x:1617,y:695,t:1527023567294};\\\", \\\"{x:1617,y:693,t:1527023567310};\\\", \\\"{x:1617,y:691,t:1527023567327};\\\", \\\"{x:1617,y:690,t:1527023567345};\\\", \\\"{x:1618,y:689,t:1527023567360};\\\", \\\"{x:1618,y:688,t:1527023567418};\\\", \\\"{x:1618,y:687,t:1527023567427};\\\", \\\"{x:1618,y:686,t:1527023567450};\\\", \\\"{x:1618,y:685,t:1527023567465};\\\", \\\"{x:1617,y:684,t:1527023567882};\\\", \\\"{x:1617,y:683,t:1527023568554};\\\", \\\"{x:1616,y:683,t:1527023568586};\\\", \\\"{x:1616,y:682,t:1527023568596};\\\", \\\"{x:1616,y:681,t:1527023569338};\\\", \\\"{x:1615,y:681,t:1527023569378};\\\", \\\"{x:1615,y:679,t:1527023569386};\\\", \\\"{x:1614,y:679,t:1527023569395};\\\", \\\"{x:1607,y:677,t:1527023569413};\\\", \\\"{x:1587,y:672,t:1527023569430};\\\", \\\"{x:1562,y:670,t:1527023569446};\\\", \\\"{x:1537,y:665,t:1527023569463};\\\", \\\"{x:1520,y:663,t:1527023569480};\\\", \\\"{x:1505,y:663,t:1527023569496};\\\", \\\"{x:1494,y:661,t:1527023569512};\\\", \\\"{x:1469,y:661,t:1527023569530};\\\", \\\"{x:1452,y:659,t:1527023569546};\\\", \\\"{x:1437,y:658,t:1527023569563};\\\", \\\"{x:1423,y:655,t:1527023569580};\\\", \\\"{x:1413,y:654,t:1527023569596};\\\", \\\"{x:1403,y:653,t:1527023569614};\\\", \\\"{x:1388,y:651,t:1527023569629};\\\", \\\"{x:1359,y:649,t:1527023569646};\\\", \\\"{x:1311,y:641,t:1527023569662};\\\", \\\"{x:1263,y:635,t:1527023569679};\\\", \\\"{x:1225,y:626,t:1527023569696};\\\", \\\"{x:1203,y:621,t:1527023569713};\\\", \\\"{x:1181,y:613,t:1527023569730};\\\", \\\"{x:1169,y:610,t:1527023569746};\\\", \\\"{x:1155,y:606,t:1527023569763};\\\", \\\"{x:1135,y:599,t:1527023569780};\\\", \\\"{x:1118,y:592,t:1527023569796};\\\", \\\"{x:1100,y:584,t:1527023569813};\\\", \\\"{x:1079,y:575,t:1527023569830};\\\", \\\"{x:1064,y:568,t:1527023569846};\\\", \\\"{x:1054,y:563,t:1527023569863};\\\", \\\"{x:1044,y:559,t:1527023569880};\\\", \\\"{x:1038,y:558,t:1527023569897};\\\", \\\"{x:1033,y:555,t:1527023569913};\\\", \\\"{x:1029,y:554,t:1527023569930};\\\", \\\"{x:1028,y:554,t:1527023569946};\\\", \\\"{x:1027,y:554,t:1527023569962};\\\", \\\"{x:1022,y:554,t:1527023569980};\\\", \\\"{x:1012,y:551,t:1527023569997};\\\", \\\"{x:998,y:550,t:1527023570013};\\\", \\\"{x:988,y:547,t:1527023570030};\\\", \\\"{x:979,y:546,t:1527023570046};\\\", \\\"{x:973,y:546,t:1527023570063};\\\", \\\"{x:968,y:546,t:1527023570080};\\\", \\\"{x:959,y:545,t:1527023570096};\\\", \\\"{x:933,y:541,t:1527023570115};\\\", \\\"{x:914,y:537,t:1527023570128};\\\", \\\"{x:901,y:535,t:1527023570146};\\\", \\\"{x:895,y:534,t:1527023570163};\\\", \\\"{x:893,y:533,t:1527023570179};\\\", \\\"{x:892,y:533,t:1527023570196};\\\", \\\"{x:891,y:533,t:1527023570214};\\\", \\\"{x:888,y:533,t:1527023570229};\\\", \\\"{x:885,y:532,t:1527023570246};\\\", \\\"{x:880,y:532,t:1527023570263};\\\", \\\"{x:873,y:531,t:1527023570279};\\\", \\\"{x:868,y:529,t:1527023570297};\\\", \\\"{x:864,y:529,t:1527023570313};\\\", \\\"{x:863,y:529,t:1527023570402};\\\", \\\"{x:862,y:529,t:1527023570414};\\\", \\\"{x:860,y:529,t:1527023570430};\\\", \\\"{x:858,y:528,t:1527023570447};\\\", \\\"{x:855,y:528,t:1527023570463};\\\", \\\"{x:854,y:527,t:1527023570480};\\\", \\\"{x:853,y:527,t:1527023570514};\\\", \\\"{x:852,y:527,t:1527023570530};\\\", \\\"{x:850,y:527,t:1527023570547};\\\", \\\"{x:847,y:526,t:1527023570564};\\\", \\\"{x:846,y:526,t:1527023570580};\\\", \\\"{x:843,y:524,t:1527023570598};\\\", \\\"{x:842,y:524,t:1527023570613};\\\", \\\"{x:840,y:524,t:1527023570630};\\\", \\\"{x:838,y:523,t:1527023570646};\\\", \\\"{x:836,y:521,t:1527023570663};\\\", \\\"{x:833,y:518,t:1527023570681};\\\", \\\"{x:832,y:516,t:1527023570696};\\\", \\\"{x:831,y:513,t:1527023570713};\\\", \\\"{x:831,y:511,t:1527023570730};\\\", \\\"{x:830,y:510,t:1527023570746};\\\", \\\"{x:830,y:509,t:1527023570769};\\\", \\\"{x:830,y:507,t:1527023570785};\\\", \\\"{x:829,y:506,t:1527023570796};\\\", \\\"{x:829,y:504,t:1527023570814};\\\", \\\"{x:828,y:503,t:1527023570830};\\\", \\\"{x:828,y:502,t:1527023570913};\\\", \\\"{x:820,y:502,t:1527023570931};\\\", \\\"{x:795,y:502,t:1527023570946};\\\", \\\"{x:760,y:502,t:1527023570963};\\\", \\\"{x:733,y:501,t:1527023570980};\\\", \\\"{x:721,y:499,t:1527023570998};\\\", \\\"{x:719,y:499,t:1527023571014};\\\", \\\"{x:717,y:499,t:1527023571030};\\\", \\\"{x:709,y:501,t:1527023571047};\\\", \\\"{x:698,y:509,t:1527023571063};\\\", \\\"{x:677,y:521,t:1527023571081};\\\", \\\"{x:667,y:530,t:1527023571097};\\\", \\\"{x:667,y:533,t:1527023571113};\\\", \\\"{x:666,y:534,t:1527023571145};\\\", \\\"{x:665,y:536,t:1527023571153};\\\", \\\"{x:662,y:538,t:1527023571163};\\\", \\\"{x:659,y:542,t:1527023571180};\\\", \\\"{x:654,y:548,t:1527023571198};\\\", \\\"{x:650,y:553,t:1527023571213};\\\", \\\"{x:648,y:560,t:1527023571231};\\\", \\\"{x:646,y:564,t:1527023571248};\\\", \\\"{x:644,y:568,t:1527023571265};\\\", \\\"{x:643,y:572,t:1527023571280};\\\", \\\"{x:636,y:583,t:1527023571298};\\\", \\\"{x:629,y:593,t:1527023571315};\\\", \\\"{x:622,y:600,t:1527023571331};\\\", \\\"{x:619,y:602,t:1527023571348};\\\", \\\"{x:619,y:603,t:1527023571364};\\\", \\\"{x:618,y:604,t:1527023571386};\\\", \\\"{x:617,y:606,t:1527023571402};\\\", \\\"{x:616,y:608,t:1527023571414};\\\", \\\"{x:613,y:611,t:1527023571430};\\\", \\\"{x:613,y:613,t:1527023571447};\\\", \\\"{x:612,y:613,t:1527023571465};\\\", \\\"{x:608,y:613,t:1527023571785};\\\", \\\"{x:601,y:612,t:1527023571798};\\\", \\\"{x:572,y:596,t:1527023571814};\\\", \\\"{x:520,y:566,t:1527023571831};\\\", \\\"{x:491,y:552,t:1527023571848};\\\", \\\"{x:477,y:545,t:1527023571864};\\\", \\\"{x:473,y:542,t:1527023571881};\\\", \\\"{x:472,y:542,t:1527023571913};\\\", \\\"{x:467,y:542,t:1527023571922};\\\", \\\"{x:463,y:541,t:1527023571931};\\\", \\\"{x:449,y:541,t:1527023571947};\\\", \\\"{x:443,y:541,t:1527023571964};\\\", \\\"{x:441,y:541,t:1527023571981};\\\", \\\"{x:440,y:541,t:1527023571997};\\\", \\\"{x:432,y:549,t:1527023572014};\\\", \\\"{x:418,y:565,t:1527023572034};\\\", \\\"{x:403,y:580,t:1527023572048};\\\", \\\"{x:394,y:588,t:1527023572064};\\\", \\\"{x:389,y:591,t:1527023572081};\\\", \\\"{x:390,y:591,t:1527023572137};\\\", \\\"{x:394,y:590,t:1527023572148};\\\", \\\"{x:404,y:589,t:1527023572165};\\\", \\\"{x:411,y:589,t:1527023572181};\\\", \\\"{x:413,y:590,t:1527023572198};\\\", \\\"{x:412,y:592,t:1527023572233};\\\", \\\"{x:408,y:592,t:1527023572248};\\\", \\\"{x:397,y:597,t:1527023572265};\\\", \\\"{x:384,y:602,t:1527023572282};\\\", \\\"{x:378,y:603,t:1527023572297};\\\", \\\"{x:373,y:605,t:1527023572315};\\\", \\\"{x:368,y:606,t:1527023572332};\\\", \\\"{x:362,y:608,t:1527023572347};\\\", \\\"{x:358,y:610,t:1527023572364};\\\", \\\"{x:355,y:610,t:1527023572380};\\\", \\\"{x:355,y:611,t:1527023572397};\\\", \\\"{x:353,y:612,t:1527023572414};\\\", \\\"{x:347,y:613,t:1527023572430};\\\", \\\"{x:335,y:615,t:1527023572447};\\\", \\\"{x:329,y:615,t:1527023572465};\\\", \\\"{x:327,y:615,t:1527023572481};\\\", \\\"{x:328,y:615,t:1527023572570};\\\", \\\"{x:333,y:614,t:1527023572581};\\\", \\\"{x:336,y:611,t:1527023572598};\\\", \\\"{x:338,y:611,t:1527023572615};\\\", \\\"{x:340,y:610,t:1527023572630};\\\", \\\"{x:344,y:609,t:1527023572647};\\\", \\\"{x:347,y:608,t:1527023572665};\\\", \\\"{x:350,y:607,t:1527023572680};\\\", \\\"{x:353,y:607,t:1527023572698};\\\", \\\"{x:356,y:607,t:1527023572714};\\\", \\\"{x:363,y:607,t:1527023572731};\\\", \\\"{x:367,y:607,t:1527023572747};\\\", \\\"{x:368,y:607,t:1527023572810};\\\", \\\"{x:371,y:608,t:1527023572818};\\\", \\\"{x:375,y:609,t:1527023572832};\\\", \\\"{x:381,y:610,t:1527023572847};\\\", \\\"{x:384,y:612,t:1527023572865};\\\", \\\"{x:385,y:612,t:1527023573209};\\\", \\\"{x:391,y:617,t:1527023573217};\\\", \\\"{x:395,y:626,t:1527023573232};\\\", \\\"{x:415,y:652,t:1527023573249};\\\", \\\"{x:442,y:686,t:1527023573265};\\\", \\\"{x:453,y:701,t:1527023573282};\\\", \\\"{x:456,y:705,t:1527023573298};\\\", \\\"{x:457,y:707,t:1527023573315};\\\", \\\"{x:458,y:708,t:1527023573333};\\\", \\\"{x:459,y:709,t:1527023573354};\\\", \\\"{x:460,y:710,t:1527023573366};\\\", \\\"{x:462,y:712,t:1527023573382};\\\", \\\"{x:463,y:712,t:1527023573398};\\\", \\\"{x:465,y:714,t:1527023573415};\\\", \\\"{x:466,y:715,t:1527023573434};\\\", \\\"{x:467,y:716,t:1527023573448};\\\", \\\"{x:471,y:720,t:1527023573467};\\\", \\\"{x:476,y:725,t:1527023573482};\\\", \\\"{x:479,y:729,t:1527023573498};\\\", \\\"{x:480,y:730,t:1527023573515};\\\", \\\"{x:481,y:730,t:1527023573532};\\\", \\\"{x:481,y:731,t:1527023573569};\\\", \\\"{x:482,y:732,t:1527023573583};\\\", \\\"{x:483,y:733,t:1527023573599};\\\", \\\"{x:484,y:736,t:1527023573616};\\\", \\\"{x:487,y:739,t:1527023573633};\\\", \\\"{x:488,y:739,t:1527023574130};\\\", \\\"{x:489,y:739,t:1527023574138};\\\", \\\"{x:490,y:739,t:1527023574218};\\\", \\\"{x:491,y:739,t:1527023574233};\\\", \\\"{x:492,y:739,t:1527023574249};\\\", \\\"{x:494,y:738,t:1527023574266};\\\", \\\"{x:496,y:738,t:1527023574283};\\\", \\\"{x:498,y:737,t:1527023574300};\\\", \\\"{x:503,y:735,t:1527023574316};\\\", \\\"{x:512,y:733,t:1527023574333};\\\", \\\"{x:530,y:728,t:1527023574350};\\\", \\\"{x:561,y:719,t:1527023574366};\\\", \\\"{x:602,y:709,t:1527023574383};\\\", \\\"{x:662,y:696,t:1527023574400};\\\", \\\"{x:729,y:685,t:1527023574416};\\\", \\\"{x:785,y:677,t:1527023574432};\\\", \\\"{x:881,y:653,t:1527023574449};\\\", \\\"{x:937,y:638,t:1527023574466};\\\", \\\"{x:978,y:627,t:1527023574482};\\\", \\\"{x:1011,y:617,t:1527023574500};\\\", \\\"{x:1033,y:610,t:1527023574516};\\\", \\\"{x:1045,y:607,t:1527023574532};\\\", \\\"{x:1056,y:604,t:1527023574550};\\\", \\\"{x:1069,y:600,t:1527023574566};\\\", \\\"{x:1090,y:598,t:1527023574582};\\\", \\\"{x:1109,y:595,t:1527023574600};\\\", \\\"{x:1122,y:593,t:1527023574617};\\\", \\\"{x:1130,y:593,t:1527023574632};\\\", \\\"{x:1132,y:593,t:1527023574650};\\\" ] }, { \\\"rt\\\": 7485, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 441501, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"OZV09\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -O -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1133,y:593,t:1527023576026};\\\", \\\"{x:1140,y:593,t:1527023576035};\\\", \\\"{x:1163,y:593,t:1527023576051};\\\", \\\"{x:1204,y:603,t:1527023576068};\\\", \\\"{x:1243,y:614,t:1527023576085};\\\", \\\"{x:1285,y:627,t:1527023576101};\\\", \\\"{x:1315,y:640,t:1527023576118};\\\", \\\"{x:1343,y:653,t:1527023576135};\\\", \\\"{x:1359,y:666,t:1527023576151};\\\", \\\"{x:1371,y:684,t:1527023576168};\\\", \\\"{x:1382,y:704,t:1527023576185};\\\", \\\"{x:1398,y:725,t:1527023576202};\\\", \\\"{x:1402,y:732,t:1527023576218};\\\", \\\"{x:1405,y:741,t:1527023576235};\\\", \\\"{x:1410,y:753,t:1527023576252};\\\", \\\"{x:1414,y:762,t:1527023576268};\\\", \\\"{x:1415,y:771,t:1527023576285};\\\", \\\"{x:1417,y:781,t:1527023576302};\\\", \\\"{x:1420,y:790,t:1527023576318};\\\", \\\"{x:1420,y:797,t:1527023576335};\\\", \\\"{x:1420,y:804,t:1527023576352};\\\", \\\"{x:1420,y:811,t:1527023576368};\\\", \\\"{x:1420,y:815,t:1527023576385};\\\", \\\"{x:1420,y:818,t:1527023576402};\\\", \\\"{x:1420,y:820,t:1527023576418};\\\", \\\"{x:1420,y:823,t:1527023576435};\\\", \\\"{x:1418,y:827,t:1527023576452};\\\", \\\"{x:1418,y:830,t:1527023576468};\\\", \\\"{x:1413,y:835,t:1527023576485};\\\", \\\"{x:1402,y:839,t:1527023576502};\\\", \\\"{x:1393,y:841,t:1527023576518};\\\", \\\"{x:1383,y:845,t:1527023576535};\\\", \\\"{x:1375,y:846,t:1527023576551};\\\", \\\"{x:1369,y:848,t:1527023576568};\\\", \\\"{x:1361,y:851,t:1527023576584};\\\", \\\"{x:1346,y:859,t:1527023576602};\\\", \\\"{x:1335,y:863,t:1527023576618};\\\", \\\"{x:1330,y:865,t:1527023576635};\\\", \\\"{x:1327,y:868,t:1527023576653};\\\", \\\"{x:1326,y:869,t:1527023576669};\\\", \\\"{x:1324,y:871,t:1527023576685};\\\", \\\"{x:1323,y:879,t:1527023576703};\\\", \\\"{x:1322,y:889,t:1527023576718};\\\", \\\"{x:1322,y:896,t:1527023576734};\\\", \\\"{x:1329,y:906,t:1527023576752};\\\", \\\"{x:1345,y:913,t:1527023576769};\\\", \\\"{x:1359,y:917,t:1527023576785};\\\", \\\"{x:1373,y:920,t:1527023576801};\\\", \\\"{x:1383,y:920,t:1527023576818};\\\", \\\"{x:1397,y:919,t:1527023576834};\\\", \\\"{x:1411,y:915,t:1527023576852};\\\", \\\"{x:1420,y:913,t:1527023576869};\\\", \\\"{x:1431,y:910,t:1527023576884};\\\", \\\"{x:1450,y:909,t:1527023576902};\\\", \\\"{x:1474,y:909,t:1527023576918};\\\", \\\"{x:1499,y:909,t:1527023576934};\\\", \\\"{x:1527,y:905,t:1527023576952};\\\", \\\"{x:1548,y:905,t:1527023576969};\\\", \\\"{x:1563,y:905,t:1527023576985};\\\", \\\"{x:1580,y:905,t:1527023577001};\\\", \\\"{x:1585,y:905,t:1527023577019};\\\", \\\"{x:1588,y:905,t:1527023577035};\\\", \\\"{x:1589,y:905,t:1527023577051};\\\", \\\"{x:1590,y:905,t:1527023577069};\\\", \\\"{x:1591,y:905,t:1527023577086};\\\", \\\"{x:1591,y:906,t:1527023577101};\\\", \\\"{x:1590,y:907,t:1527023577217};\\\", \\\"{x:1589,y:908,t:1527023577233};\\\", \\\"{x:1588,y:908,t:1527023577241};\\\", \\\"{x:1587,y:908,t:1527023577252};\\\", \\\"{x:1586,y:908,t:1527023577269};\\\", \\\"{x:1584,y:909,t:1527023577285};\\\", \\\"{x:1581,y:910,t:1527023577301};\\\", \\\"{x:1579,y:911,t:1527023577318};\\\", \\\"{x:1577,y:911,t:1527023577335};\\\", \\\"{x:1574,y:911,t:1527023577352};\\\", \\\"{x:1568,y:911,t:1527023577369};\\\", \\\"{x:1564,y:911,t:1527023577386};\\\", \\\"{x:1563,y:911,t:1527023577402};\\\", \\\"{x:1560,y:910,t:1527023577419};\\\", \\\"{x:1559,y:909,t:1527023577466};\\\", \\\"{x:1558,y:909,t:1527023577474};\\\", \\\"{x:1557,y:908,t:1527023577485};\\\", \\\"{x:1554,y:905,t:1527023577502};\\\", \\\"{x:1550,y:901,t:1527023577519};\\\", \\\"{x:1546,y:898,t:1527023577535};\\\", \\\"{x:1546,y:896,t:1527023577552};\\\", \\\"{x:1545,y:894,t:1527023577569};\\\", \\\"{x:1543,y:892,t:1527023577586};\\\", \\\"{x:1542,y:890,t:1527023577603};\\\", \\\"{x:1541,y:886,t:1527023577619};\\\", \\\"{x:1540,y:884,t:1527023577636};\\\", \\\"{x:1539,y:883,t:1527023577658};\\\", \\\"{x:1539,y:882,t:1527023577669};\\\", \\\"{x:1539,y:881,t:1527023577686};\\\", \\\"{x:1539,y:878,t:1527023577703};\\\", \\\"{x:1539,y:877,t:1527023577718};\\\", \\\"{x:1538,y:875,t:1527023577736};\\\", \\\"{x:1538,y:873,t:1527023577753};\\\", \\\"{x:1538,y:871,t:1527023577769};\\\", \\\"{x:1537,y:868,t:1527023577786};\\\", \\\"{x:1536,y:865,t:1527023577803};\\\", \\\"{x:1536,y:862,t:1527023577819};\\\", \\\"{x:1536,y:861,t:1527023577836};\\\", \\\"{x:1536,y:859,t:1527023577853};\\\", \\\"{x:1535,y:855,t:1527023577869};\\\", \\\"{x:1535,y:854,t:1527023577886};\\\", \\\"{x:1533,y:851,t:1527023577904};\\\", \\\"{x:1533,y:849,t:1527023577919};\\\", \\\"{x:1533,y:847,t:1527023577936};\\\", \\\"{x:1533,y:846,t:1527023577953};\\\", \\\"{x:1532,y:843,t:1527023577970};\\\", \\\"{x:1532,y:839,t:1527023577986};\\\", \\\"{x:1531,y:837,t:1527023578003};\\\", \\\"{x:1531,y:836,t:1527023578021};\\\", \\\"{x:1531,y:835,t:1527023578036};\\\", \\\"{x:1530,y:833,t:1527023578053};\\\", \\\"{x:1530,y:832,t:1527023578070};\\\", \\\"{x:1530,y:829,t:1527023578086};\\\", \\\"{x:1530,y:827,t:1527023578103};\\\", \\\"{x:1529,y:824,t:1527023578120};\\\", \\\"{x:1529,y:822,t:1527023578136};\\\", \\\"{x:1529,y:820,t:1527023578153};\\\", \\\"{x:1529,y:818,t:1527023578170};\\\", \\\"{x:1529,y:816,t:1527023578186};\\\", \\\"{x:1529,y:814,t:1527023578204};\\\", \\\"{x:1529,y:812,t:1527023578220};\\\", \\\"{x:1529,y:810,t:1527023578236};\\\", \\\"{x:1528,y:809,t:1527023578253};\\\", \\\"{x:1528,y:807,t:1527023578271};\\\", \\\"{x:1528,y:806,t:1527023578286};\\\", \\\"{x:1528,y:804,t:1527023578303};\\\", \\\"{x:1528,y:800,t:1527023578320};\\\", \\\"{x:1527,y:798,t:1527023578336};\\\", \\\"{x:1527,y:794,t:1527023578353};\\\", \\\"{x:1526,y:790,t:1527023578370};\\\", \\\"{x:1526,y:788,t:1527023578387};\\\", \\\"{x:1525,y:783,t:1527023578403};\\\", \\\"{x:1525,y:780,t:1527023578420};\\\", \\\"{x:1525,y:777,t:1527023578437};\\\", \\\"{x:1524,y:775,t:1527023578453};\\\", \\\"{x:1523,y:774,t:1527023578470};\\\", \\\"{x:1523,y:773,t:1527023578487};\\\", \\\"{x:1523,y:771,t:1527023578503};\\\", \\\"{x:1523,y:770,t:1527023578520};\\\", \\\"{x:1522,y:769,t:1527023578537};\\\", \\\"{x:1522,y:768,t:1527023578553};\\\", \\\"{x:1521,y:766,t:1527023578570};\\\", \\\"{x:1521,y:765,t:1527023578594};\\\", \\\"{x:1521,y:764,t:1527023578611};\\\", \\\"{x:1521,y:763,t:1527023578626};\\\", \\\"{x:1520,y:763,t:1527023578640};\\\", \\\"{x:1520,y:762,t:1527023578652};\\\", \\\"{x:1520,y:761,t:1527023578670};\\\", \\\"{x:1520,y:760,t:1527023578689};\\\", \\\"{x:1519,y:759,t:1527023578730};\\\", \\\"{x:1519,y:758,t:1527023578761};\\\", \\\"{x:1519,y:757,t:1527023578785};\\\", \\\"{x:1519,y:756,t:1527023578801};\\\", \\\"{x:1519,y:755,t:1527023578826};\\\", \\\"{x:1519,y:754,t:1527023578874};\\\", \\\"{x:1517,y:753,t:1527023578891};\\\", \\\"{x:1517,y:752,t:1527023578905};\\\", \\\"{x:1517,y:751,t:1527023578920};\\\", \\\"{x:1517,y:750,t:1527023578946};\\\", \\\"{x:1517,y:749,t:1527023578970};\\\", \\\"{x:1516,y:748,t:1527023578987};\\\", \\\"{x:1516,y:746,t:1527023579004};\\\", \\\"{x:1515,y:745,t:1527023579020};\\\", \\\"{x:1515,y:742,t:1527023579037};\\\", \\\"{x:1514,y:740,t:1527023579054};\\\", \\\"{x:1513,y:738,t:1527023579070};\\\", \\\"{x:1512,y:737,t:1527023579087};\\\", \\\"{x:1510,y:734,t:1527023579104};\\\", \\\"{x:1508,y:731,t:1527023579120};\\\", \\\"{x:1506,y:729,t:1527023579137};\\\", \\\"{x:1502,y:726,t:1527023579154};\\\", \\\"{x:1501,y:725,t:1527023579170};\\\", \\\"{x:1499,y:724,t:1527023579188};\\\", \\\"{x:1494,y:721,t:1527023579204};\\\", \\\"{x:1487,y:720,t:1527023579220};\\\", \\\"{x:1478,y:717,t:1527023579237};\\\", \\\"{x:1471,y:715,t:1527023579254};\\\", \\\"{x:1467,y:714,t:1527023579271};\\\", \\\"{x:1462,y:712,t:1527023579287};\\\", \\\"{x:1457,y:712,t:1527023579304};\\\", \\\"{x:1451,y:712,t:1527023579321};\\\", \\\"{x:1439,y:710,t:1527023579337};\\\", \\\"{x:1425,y:708,t:1527023579354};\\\", \\\"{x:1419,y:707,t:1527023579371};\\\", \\\"{x:1415,y:705,t:1527023579388};\\\", \\\"{x:1409,y:705,t:1527023579404};\\\", \\\"{x:1403,y:705,t:1527023579422};\\\", \\\"{x:1383,y:705,t:1527023579437};\\\", \\\"{x:1363,y:703,t:1527023579454};\\\", \\\"{x:1346,y:699,t:1527023579472};\\\", \\\"{x:1330,y:697,t:1527023579489};\\\", \\\"{x:1317,y:696,t:1527023579504};\\\", \\\"{x:1307,y:695,t:1527023579522};\\\", \\\"{x:1288,y:694,t:1527023579537};\\\", \\\"{x:1231,y:686,t:1527023579554};\\\", \\\"{x:1203,y:681,t:1527023579571};\\\", \\\"{x:1192,y:679,t:1527023579587};\\\", \\\"{x:1189,y:678,t:1527023579604};\\\", \\\"{x:1188,y:677,t:1527023579634};\\\", \\\"{x:1186,y:677,t:1527023579650};\\\", \\\"{x:1182,y:676,t:1527023579658};\\\", \\\"{x:1178,y:676,t:1527023579671};\\\", \\\"{x:1170,y:674,t:1527023579688};\\\", \\\"{x:1165,y:672,t:1527023579704};\\\", \\\"{x:1163,y:672,t:1527023579721};\\\", \\\"{x:1161,y:671,t:1527023579738};\\\", \\\"{x:1159,y:671,t:1527023579754};\\\", \\\"{x:1150,y:671,t:1527023579772};\\\", \\\"{x:1134,y:668,t:1527023579788};\\\", \\\"{x:1119,y:666,t:1527023579804};\\\", \\\"{x:1113,y:665,t:1527023579821};\\\", \\\"{x:1112,y:665,t:1527023579838};\\\", \\\"{x:1111,y:665,t:1527023579889};\\\", \\\"{x:1110,y:665,t:1527023579905};\\\", \\\"{x:1108,y:665,t:1527023579920};\\\", \\\"{x:1106,y:664,t:1527023579937};\\\", \\\"{x:1105,y:664,t:1527023580122};\\\", \\\"{x:1102,y:664,t:1527023580138};\\\", \\\"{x:1098,y:664,t:1527023580155};\\\", \\\"{x:1097,y:664,t:1527023580171};\\\", \\\"{x:1094,y:664,t:1527023580188};\\\", \\\"{x:1091,y:663,t:1527023580205};\\\", \\\"{x:1085,y:662,t:1527023580221};\\\", \\\"{x:1073,y:660,t:1527023580237};\\\", \\\"{x:1058,y:658,t:1527023580255};\\\", \\\"{x:1042,y:655,t:1527023580270};\\\", \\\"{x:1035,y:654,t:1527023580287};\\\", \\\"{x:1032,y:654,t:1527023580305};\\\", \\\"{x:1029,y:654,t:1527023580320};\\\", \\\"{x:1024,y:654,t:1527023580337};\\\", \\\"{x:1015,y:654,t:1527023580355};\\\", \\\"{x:997,y:654,t:1527023580371};\\\", \\\"{x:985,y:653,t:1527023580387};\\\", \\\"{x:979,y:653,t:1527023580406};\\\", \\\"{x:978,y:653,t:1527023580421};\\\", \\\"{x:976,y:651,t:1527023580438};\\\", \\\"{x:972,y:651,t:1527023580454};\\\", \\\"{x:967,y:650,t:1527023580470};\\\", \\\"{x:953,y:648,t:1527023580488};\\\", \\\"{x:944,y:647,t:1527023580505};\\\", \\\"{x:926,y:645,t:1527023580521};\\\", \\\"{x:915,y:644,t:1527023580538};\\\", \\\"{x:906,y:641,t:1527023580555};\\\", \\\"{x:895,y:640,t:1527023580572};\\\", \\\"{x:883,y:637,t:1527023580587};\\\", \\\"{x:867,y:634,t:1527023580605};\\\", \\\"{x:849,y:631,t:1527023580622};\\\", \\\"{x:836,y:628,t:1527023580637};\\\", \\\"{x:831,y:627,t:1527023580655};\\\", \\\"{x:826,y:626,t:1527023580672};\\\", \\\"{x:823,y:625,t:1527023580688};\\\", \\\"{x:817,y:625,t:1527023580705};\\\", \\\"{x:803,y:620,t:1527023580721};\\\", \\\"{x:786,y:615,t:1527023580737};\\\", \\\"{x:765,y:610,t:1527023580754};\\\", \\\"{x:746,y:605,t:1527023580771};\\\", \\\"{x:744,y:604,t:1527023580788};\\\", \\\"{x:743,y:604,t:1527023580906};\\\", \\\"{x:741,y:601,t:1527023580922};\\\", \\\"{x:735,y:595,t:1527023580940};\\\", \\\"{x:725,y:588,t:1527023580956};\\\", \\\"{x:718,y:583,t:1527023580972};\\\", \\\"{x:714,y:579,t:1527023580989};\\\", \\\"{x:712,y:577,t:1527023581005};\\\", \\\"{x:709,y:574,t:1527023581021};\\\", \\\"{x:696,y:569,t:1527023581039};\\\", \\\"{x:675,y:566,t:1527023581054};\\\", \\\"{x:655,y:563,t:1527023581072};\\\", \\\"{x:649,y:562,t:1527023581090};\\\", \\\"{x:649,y:561,t:1527023581129};\\\", \\\"{x:654,y:558,t:1527023581138};\\\", \\\"{x:672,y:552,t:1527023581155};\\\", \\\"{x:694,y:551,t:1527023581171};\\\", \\\"{x:718,y:551,t:1527023581188};\\\", \\\"{x:742,y:551,t:1527023581206};\\\", \\\"{x:762,y:553,t:1527023581221};\\\", \\\"{x:781,y:554,t:1527023581238};\\\", \\\"{x:794,y:554,t:1527023581255};\\\", \\\"{x:798,y:555,t:1527023581272};\\\", \\\"{x:799,y:555,t:1527023581288};\\\", \\\"{x:799,y:556,t:1527023581331};\\\", \\\"{x:799,y:557,t:1527023581339};\\\", \\\"{x:801,y:561,t:1527023581354};\\\", \\\"{x:801,y:564,t:1527023581371};\\\", \\\"{x:803,y:568,t:1527023581388};\\\", \\\"{x:804,y:570,t:1527023581406};\\\", \\\"{x:805,y:572,t:1527023581457};\\\", \\\"{x:808,y:574,t:1527023581471};\\\", \\\"{x:812,y:577,t:1527023581488};\\\", \\\"{x:817,y:580,t:1527023581505};\\\", \\\"{x:818,y:580,t:1527023581521};\\\", \\\"{x:819,y:581,t:1527023581538};\\\", \\\"{x:820,y:581,t:1527023581556};\\\", \\\"{x:823,y:581,t:1527023581572};\\\", \\\"{x:827,y:581,t:1527023581590};\\\", \\\"{x:829,y:581,t:1527023581606};\\\", \\\"{x:833,y:581,t:1527023581621};\\\", \\\"{x:835,y:582,t:1527023581639};\\\", \\\"{x:835,y:585,t:1527023581873};\\\", \\\"{x:807,y:599,t:1527023581889};\\\", \\\"{x:788,y:610,t:1527023581906};\\\", \\\"{x:770,y:620,t:1527023581922};\\\", \\\"{x:754,y:629,t:1527023581939};\\\", \\\"{x:736,y:641,t:1527023581956};\\\", \\\"{x:723,y:651,t:1527023581973};\\\", \\\"{x:710,y:662,t:1527023581989};\\\", \\\"{x:698,y:669,t:1527023582005};\\\", \\\"{x:683,y:678,t:1527023582023};\\\", \\\"{x:660,y:686,t:1527023582040};\\\", \\\"{x:638,y:695,t:1527023582056};\\\", \\\"{x:610,y:701,t:1527023582073};\\\", \\\"{x:601,y:702,t:1527023582089};\\\", \\\"{x:592,y:705,t:1527023582107};\\\", \\\"{x:579,y:708,t:1527023582122};\\\", \\\"{x:569,y:710,t:1527023582140};\\\", \\\"{x:566,y:710,t:1527023582157};\\\", \\\"{x:562,y:710,t:1527023582211};\\\", \\\"{x:558,y:711,t:1527023582224};\\\", \\\"{x:549,y:714,t:1527023582240};\\\", \\\"{x:541,y:717,t:1527023582257};\\\", \\\"{x:525,y:723,t:1527023582275};\\\", \\\"{x:513,y:731,t:1527023582291};\\\", \\\"{x:505,y:736,t:1527023582306};\\\", \\\"{x:501,y:739,t:1527023582322};\\\", \\\"{x:500,y:740,t:1527023582339};\\\", \\\"{x:498,y:742,t:1527023582355};\\\", \\\"{x:497,y:743,t:1527023582401};\\\", \\\"{x:500,y:743,t:1527023582601};\\\", \\\"{x:504,y:741,t:1527023582608};\\\", \\\"{x:507,y:741,t:1527023582623};\\\", \\\"{x:511,y:739,t:1527023582639};\\\", \\\"{x:516,y:736,t:1527023582657};\\\", \\\"{x:547,y:719,t:1527023582673};\\\", \\\"{x:641,y:673,t:1527023582689};\\\", \\\"{x:672,y:657,t:1527023582706};\\\", \\\"{x:692,y:650,t:1527023582722};\\\", \\\"{x:705,y:647,t:1527023582740};\\\", \\\"{x:713,y:642,t:1527023582757};\\\", \\\"{x:725,y:635,t:1527023582772};\\\", \\\"{x:755,y:623,t:1527023582790};\\\", \\\"{x:809,y:601,t:1527023582807};\\\", \\\"{x:872,y:579,t:1527023582823};\\\", \\\"{x:908,y:572,t:1527023582840};\\\", \\\"{x:927,y:570,t:1527023582857};\\\", \\\"{x:931,y:568,t:1527023582873};\\\", \\\"{x:933,y:567,t:1527023582914};\\\", \\\"{x:935,y:567,t:1527023582923};\\\", \\\"{x:939,y:565,t:1527023582939};\\\", \\\"{x:948,y:562,t:1527023582957};\\\", \\\"{x:961,y:558,t:1527023582973};\\\", \\\"{x:968,y:557,t:1527023582990};\\\", \\\"{x:973,y:557,t:1527023583007};\\\", \\\"{x:974,y:555,t:1527023583023};\\\" ] }, { \\\"rt\\\": 66302, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 509026, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"OZV09\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -M -M -B -B -B -B -B -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:973,y:555,t:1527023584522};\\\", \\\"{x:969,y:556,t:1527023584530};\\\", \\\"{x:960,y:557,t:1527023584541};\\\", \\\"{x:929,y:561,t:1527023584560};\\\", \\\"{x:878,y:562,t:1527023584575};\\\", \\\"{x:800,y:562,t:1527023584591};\\\", \\\"{x:719,y:550,t:1527023584608};\\\", \\\"{x:576,y:515,t:1527023584626};\\\", \\\"{x:488,y:490,t:1527023584642};\\\", \\\"{x:405,y:467,t:1527023584658};\\\", \\\"{x:341,y:448,t:1527023584675};\\\", \\\"{x:301,y:437,t:1527023584691};\\\", \\\"{x:283,y:431,t:1527023584707};\\\", \\\"{x:275,y:429,t:1527023584725};\\\", \\\"{x:272,y:428,t:1527023584741};\\\", \\\"{x:271,y:428,t:1527023584757};\\\", \\\"{x:270,y:428,t:1527023584802};\\\", \\\"{x:269,y:427,t:1527023584842};\\\", \\\"{x:270,y:426,t:1527023584906};\\\", \\\"{x:270,y:425,t:1527023584912};\\\", \\\"{x:271,y:425,t:1527023584924};\\\", \\\"{x:273,y:425,t:1527023584977};\\\", \\\"{x:274,y:425,t:1527023584992};\\\", \\\"{x:280,y:425,t:1527023585008};\\\", \\\"{x:317,y:439,t:1527023585025};\\\", \\\"{x:353,y:452,t:1527023585041};\\\", \\\"{x:384,y:463,t:1527023585058};\\\", \\\"{x:405,y:473,t:1527023585075};\\\", \\\"{x:412,y:476,t:1527023585092};\\\", \\\"{x:413,y:476,t:1527023585107};\\\", \\\"{x:414,y:476,t:1527023585146};\\\", \\\"{x:415,y:476,t:1527023585162};\\\", \\\"{x:416,y:476,t:1527023585178};\\\", \\\"{x:417,y:476,t:1527023585192};\\\", \\\"{x:418,y:477,t:1527023585208};\\\", \\\"{x:420,y:477,t:1527023585225};\\\", \\\"{x:420,y:478,t:1527023585242};\\\", \\\"{x:420,y:479,t:1527023585385};\\\", \\\"{x:419,y:480,t:1527023585394};\\\", \\\"{x:418,y:481,t:1527023585417};\\\", \\\"{x:418,y:482,t:1527023585633};\\\", \\\"{x:421,y:482,t:1527023585642};\\\", \\\"{x:429,y:482,t:1527023585659};\\\", \\\"{x:440,y:482,t:1527023585675};\\\", \\\"{x:451,y:482,t:1527023585691};\\\", \\\"{x:456,y:484,t:1527023585709};\\\", \\\"{x:459,y:484,t:1527023585725};\\\", \\\"{x:462,y:484,t:1527023585742};\\\", \\\"{x:463,y:484,t:1527023585759};\\\", \\\"{x:469,y:484,t:1527023585775};\\\", \\\"{x:477,y:484,t:1527023585791};\\\", \\\"{x:491,y:484,t:1527023585808};\\\", \\\"{x:503,y:485,t:1527023585825};\\\", \\\"{x:509,y:486,t:1527023585841};\\\", \\\"{x:512,y:486,t:1527023585859};\\\", \\\"{x:513,y:486,t:1527023585875};\\\", \\\"{x:517,y:488,t:1527023585892};\\\", \\\"{x:520,y:488,t:1527023585909};\\\", \\\"{x:527,y:489,t:1527023585925};\\\", \\\"{x:532,y:489,t:1527023585942};\\\", \\\"{x:536,y:490,t:1527023585959};\\\", \\\"{x:537,y:490,t:1527023585976};\\\", \\\"{x:538,y:490,t:1527023585992};\\\", \\\"{x:539,y:491,t:1527023586218};\\\", \\\"{x:540,y:491,t:1527023586257};\\\", \\\"{x:542,y:491,t:1527023586265};\\\", \\\"{x:545,y:491,t:1527023586277};\\\", \\\"{x:553,y:492,t:1527023586293};\\\", \\\"{x:568,y:496,t:1527023586309};\\\", \\\"{x:593,y:504,t:1527023586327};\\\", \\\"{x:622,y:511,t:1527023586342};\\\", \\\"{x:653,y:521,t:1527023586360};\\\", \\\"{x:696,y:535,t:1527023586377};\\\", \\\"{x:757,y:558,t:1527023586394};\\\", \\\"{x:800,y:574,t:1527023586409};\\\", \\\"{x:835,y:594,t:1527023586426};\\\", \\\"{x:878,y:619,t:1527023586444};\\\", \\\"{x:928,y:650,t:1527023586459};\\\", \\\"{x:976,y:683,t:1527023586476};\\\", \\\"{x:1039,y:721,t:1527023586493};\\\", \\\"{x:1104,y:757,t:1527023586509};\\\", \\\"{x:1152,y:779,t:1527023586526};\\\", \\\"{x:1180,y:795,t:1527023586543};\\\", \\\"{x:1205,y:809,t:1527023586560};\\\", \\\"{x:1224,y:818,t:1527023586576};\\\", \\\"{x:1260,y:833,t:1527023586593};\\\", \\\"{x:1287,y:840,t:1527023586609};\\\", \\\"{x:1318,y:847,t:1527023586626};\\\", \\\"{x:1343,y:856,t:1527023586643};\\\", \\\"{x:1371,y:864,t:1527023586660};\\\", \\\"{x:1399,y:869,t:1527023586676};\\\", \\\"{x:1424,y:876,t:1527023586693};\\\", \\\"{x:1447,y:881,t:1527023586710};\\\", \\\"{x:1466,y:884,t:1527023586726};\\\", \\\"{x:1477,y:887,t:1527023586743};\\\", \\\"{x:1485,y:889,t:1527023586760};\\\", \\\"{x:1489,y:890,t:1527023586776};\\\", \\\"{x:1497,y:891,t:1527023586793};\\\", \\\"{x:1502,y:893,t:1527023586810};\\\", \\\"{x:1503,y:893,t:1527023586834};\\\", \\\"{x:1504,y:893,t:1527023586922};\\\", \\\"{x:1504,y:896,t:1527023586938};\\\", \\\"{x:1504,y:899,t:1527023586947};\\\", \\\"{x:1504,y:901,t:1527023586961};\\\", \\\"{x:1500,y:916,t:1527023586977};\\\", \\\"{x:1495,y:923,t:1527023586994};\\\", \\\"{x:1490,y:929,t:1527023587010};\\\", \\\"{x:1487,y:933,t:1527023587027};\\\", \\\"{x:1483,y:938,t:1527023587043};\\\", \\\"{x:1478,y:943,t:1527023587061};\\\", \\\"{x:1470,y:949,t:1527023587078};\\\", \\\"{x:1462,y:953,t:1527023587093};\\\", \\\"{x:1460,y:954,t:1527023587110};\\\", \\\"{x:1458,y:954,t:1527023587127};\\\", \\\"{x:1457,y:955,t:1527023587162};\\\", \\\"{x:1456,y:956,t:1527023587193};\\\", \\\"{x:1454,y:956,t:1527023587210};\\\", \\\"{x:1453,y:957,t:1527023587227};\\\", \\\"{x:1451,y:957,t:1527023587244};\\\", \\\"{x:1448,y:957,t:1527023587260};\\\", \\\"{x:1446,y:959,t:1527023587277};\\\", \\\"{x:1444,y:959,t:1527023587294};\\\", \\\"{x:1441,y:959,t:1527023587310};\\\", \\\"{x:1440,y:959,t:1527023587328};\\\", \\\"{x:1438,y:959,t:1527023587345};\\\", \\\"{x:1437,y:959,t:1527023587361};\\\", \\\"{x:1435,y:959,t:1527023587377};\\\", \\\"{x:1434,y:959,t:1527023587393};\\\", \\\"{x:1432,y:959,t:1527023587458};\\\", \\\"{x:1431,y:959,t:1527023587490};\\\", \\\"{x:1429,y:959,t:1527023587514};\\\", \\\"{x:1428,y:959,t:1527023587530};\\\", \\\"{x:1426,y:958,t:1527023587544};\\\", \\\"{x:1423,y:956,t:1527023587560};\\\", \\\"{x:1421,y:955,t:1527023587578};\\\", \\\"{x:1420,y:954,t:1527023587601};\\\", \\\"{x:1420,y:953,t:1527023587618};\\\", \\\"{x:1419,y:953,t:1527023587628};\\\", \\\"{x:1417,y:951,t:1527023587645};\\\", \\\"{x:1416,y:950,t:1527023587662};\\\", \\\"{x:1415,y:949,t:1527023587678};\\\", \\\"{x:1414,y:948,t:1527023587811};\\\", \\\"{x:1414,y:947,t:1527023587834};\\\", \\\"{x:1414,y:946,t:1527023587865};\\\", \\\"{x:1413,y:945,t:1527023587877};\\\", \\\"{x:1413,y:944,t:1527023587914};\\\", \\\"{x:1412,y:943,t:1527023587938};\\\", \\\"{x:1412,y:942,t:1527023587978};\\\", \\\"{x:1411,y:941,t:1527023588002};\\\", \\\"{x:1411,y:940,t:1527023588058};\\\", \\\"{x:1411,y:939,t:1527023588090};\\\", \\\"{x:1411,y:938,t:1527023588097};\\\", \\\"{x:1410,y:938,t:1527023588111};\\\", \\\"{x:1410,y:937,t:1527023588129};\\\", \\\"{x:1409,y:937,t:1527023588219};\\\", \\\"{x:1409,y:936,t:1527023588228};\\\", \\\"{x:1409,y:935,t:1527023588394};\\\", \\\"{x:1408,y:934,t:1527023588426};\\\", \\\"{x:1408,y:933,t:1527023588449};\\\", \\\"{x:1408,y:932,t:1527023588506};\\\", \\\"{x:1408,y:931,t:1527023588538};\\\", \\\"{x:1408,y:930,t:1527023588570};\\\", \\\"{x:1408,y:929,t:1527023588602};\\\", \\\"{x:1408,y:928,t:1527023588612};\\\", \\\"{x:1406,y:925,t:1527023588629};\\\", \\\"{x:1406,y:924,t:1527023588658};\\\", \\\"{x:1406,y:923,t:1527023588681};\\\", \\\"{x:1406,y:922,t:1527023588754};\\\", \\\"{x:1406,y:921,t:1527023588770};\\\", \\\"{x:1406,y:920,t:1527023588778};\\\", \\\"{x:1406,y:918,t:1527023588810};\\\", \\\"{x:1406,y:917,t:1527023588825};\\\", \\\"{x:1406,y:916,t:1527023588842};\\\", \\\"{x:1406,y:915,t:1527023588906};\\\", \\\"{x:1406,y:914,t:1527023588938};\\\", \\\"{x:1406,y:913,t:1527023588962};\\\", \\\"{x:1406,y:912,t:1527023589026};\\\", \\\"{x:1406,y:911,t:1527023589041};\\\", \\\"{x:1406,y:910,t:1527023589050};\\\", \\\"{x:1406,y:909,t:1527023589106};\\\", \\\"{x:1406,y:908,t:1527023589114};\\\", \\\"{x:1406,y:907,t:1527023589130};\\\", \\\"{x:1406,y:905,t:1527023589162};\\\", \\\"{x:1406,y:904,t:1527023589179};\\\", \\\"{x:1406,y:903,t:1527023589201};\\\", \\\"{x:1406,y:902,t:1527023589218};\\\", \\\"{x:1406,y:901,t:1527023589230};\\\", \\\"{x:1406,y:900,t:1527023589258};\\\", \\\"{x:1406,y:899,t:1527023589281};\\\", \\\"{x:1406,y:898,t:1527023589305};\\\", \\\"{x:1406,y:897,t:1527023589426};\\\", \\\"{x:1407,y:896,t:1527023589491};\\\", \\\"{x:1407,y:895,t:1527023589514};\\\", \\\"{x:1409,y:894,t:1527023589529};\\\", \\\"{x:1410,y:893,t:1527023589546};\\\", \\\"{x:1413,y:892,t:1527023589562};\\\", \\\"{x:1413,y:891,t:1527023589579};\\\", \\\"{x:1414,y:890,t:1527023589596};\\\", \\\"{x:1415,y:889,t:1527023589618};\\\", \\\"{x:1416,y:888,t:1527023589810};\\\", \\\"{x:1415,y:888,t:1527023590064};\\\", \\\"{x:1414,y:888,t:1527023590153};\\\", \\\"{x:1413,y:888,t:1527023590163};\\\", \\\"{x:1412,y:888,t:1527023590179};\\\", \\\"{x:1411,y:888,t:1527023590196};\\\", \\\"{x:1409,y:888,t:1527023590213};\\\", \\\"{x:1406,y:891,t:1527023590229};\\\", \\\"{x:1404,y:891,t:1527023590246};\\\", \\\"{x:1401,y:893,t:1527023590263};\\\", \\\"{x:1399,y:893,t:1527023590280};\\\", \\\"{x:1398,y:894,t:1527023590296};\\\", \\\"{x:1396,y:895,t:1527023590313};\\\", \\\"{x:1396,y:896,t:1527023590329};\\\", \\\"{x:1394,y:896,t:1527023590347};\\\", \\\"{x:1392,y:897,t:1527023590364};\\\", \\\"{x:1391,y:898,t:1527023590379};\\\", \\\"{x:1389,y:900,t:1527023590396};\\\", \\\"{x:1387,y:903,t:1527023590414};\\\", \\\"{x:1386,y:905,t:1527023590431};\\\", \\\"{x:1384,y:908,t:1527023590446};\\\", \\\"{x:1383,y:909,t:1527023590464};\\\", \\\"{x:1382,y:910,t:1527023590481};\\\", \\\"{x:1383,y:910,t:1527023590739};\\\", \\\"{x:1384,y:910,t:1527023590747};\\\", \\\"{x:1386,y:910,t:1527023590764};\\\", \\\"{x:1390,y:910,t:1527023590780};\\\", \\\"{x:1398,y:913,t:1527023590797};\\\", \\\"{x:1402,y:914,t:1527023590814};\\\", \\\"{x:1407,y:916,t:1527023590831};\\\", \\\"{x:1409,y:917,t:1527023590847};\\\", \\\"{x:1412,y:918,t:1527023590863};\\\", \\\"{x:1415,y:918,t:1527023590880};\\\", \\\"{x:1419,y:920,t:1527023590898};\\\", \\\"{x:1421,y:921,t:1527023590913};\\\", \\\"{x:1424,y:922,t:1527023590931};\\\", \\\"{x:1427,y:924,t:1527023590948};\\\", \\\"{x:1429,y:924,t:1527023590963};\\\", \\\"{x:1430,y:925,t:1527023590981};\\\", \\\"{x:1431,y:925,t:1527023591002};\\\", \\\"{x:1432,y:925,t:1527023591013};\\\", \\\"{x:1436,y:925,t:1527023591031};\\\", \\\"{x:1443,y:927,t:1527023591047};\\\", \\\"{x:1449,y:928,t:1527023591064};\\\", \\\"{x:1455,y:929,t:1527023591080};\\\", \\\"{x:1459,y:930,t:1527023591097};\\\", \\\"{x:1460,y:930,t:1527023591130};\\\", \\\"{x:1461,y:930,t:1527023591148};\\\", \\\"{x:1462,y:930,t:1527023591169};\\\", \\\"{x:1463,y:931,t:1527023591194};\\\", \\\"{x:1464,y:931,t:1527023591202};\\\", \\\"{x:1466,y:931,t:1527023591214};\\\", \\\"{x:1468,y:932,t:1527023591231};\\\", \\\"{x:1474,y:933,t:1527023591247};\\\", \\\"{x:1476,y:933,t:1527023591265};\\\", \\\"{x:1478,y:934,t:1527023591281};\\\", \\\"{x:1479,y:934,t:1527023591706};\\\", \\\"{x:1480,y:934,t:1527023591714};\\\", \\\"{x:1481,y:932,t:1527023591731};\\\", \\\"{x:1481,y:931,t:1527023591748};\\\", \\\"{x:1482,y:931,t:1527023591898};\\\", \\\"{x:1482,y:929,t:1527023591922};\\\", \\\"{x:1482,y:928,t:1527023591955};\\\", \\\"{x:1482,y:927,t:1527023591985};\\\", \\\"{x:1483,y:926,t:1527023591999};\\\", \\\"{x:1483,y:925,t:1527023592018};\\\", \\\"{x:1483,y:924,t:1527023592058};\\\", \\\"{x:1484,y:922,t:1527023592090};\\\", \\\"{x:1484,y:920,t:1527023592178};\\\", \\\"{x:1484,y:919,t:1527023592218};\\\", \\\"{x:1484,y:917,t:1527023592242};\\\", \\\"{x:1484,y:916,t:1527023592274};\\\", \\\"{x:1484,y:914,t:1527023592297};\\\", \\\"{x:1484,y:913,t:1527023592330};\\\", \\\"{x:1484,y:911,t:1527023592346};\\\", \\\"{x:1484,y:910,t:1527023592361};\\\", \\\"{x:1484,y:908,t:1527023592378};\\\", \\\"{x:1484,y:907,t:1527023592409};\\\", \\\"{x:1484,y:905,t:1527023592449};\\\", \\\"{x:1484,y:904,t:1527023592481};\\\", \\\"{x:1484,y:902,t:1527023592499};\\\", \\\"{x:1484,y:901,t:1527023592529};\\\", \\\"{x:1484,y:899,t:1527023592577};\\\", \\\"{x:1484,y:898,t:1527023592609};\\\", \\\"{x:1484,y:896,t:1527023593459};\\\", \\\"{x:1484,y:895,t:1527023593466};\\\", \\\"{x:1483,y:891,t:1527023593483};\\\", \\\"{x:1482,y:888,t:1527023593499};\\\", \\\"{x:1482,y:887,t:1527023593517};\\\", \\\"{x:1482,y:886,t:1527023593532};\\\", \\\"{x:1482,y:885,t:1527023593549};\\\", \\\"{x:1482,y:884,t:1527023593625};\\\", \\\"{x:1482,y:883,t:1527023593657};\\\", \\\"{x:1482,y:882,t:1527023593681};\\\", \\\"{x:1481,y:881,t:1527023593706};\\\", \\\"{x:1481,y:880,t:1527023593777};\\\", \\\"{x:1481,y:879,t:1527023593810};\\\", \\\"{x:1481,y:878,t:1527023593850};\\\", \\\"{x:1481,y:876,t:1527023593866};\\\", \\\"{x:1481,y:874,t:1527023593884};\\\", \\\"{x:1481,y:872,t:1527023593900};\\\", \\\"{x:1481,y:869,t:1527023593917};\\\", \\\"{x:1481,y:867,t:1527023593962};\\\", \\\"{x:1481,y:866,t:1527023594010};\\\", \\\"{x:1481,y:864,t:1527023594017};\\\", \\\"{x:1481,y:862,t:1527023594034};\\\", \\\"{x:1481,y:861,t:1527023594050};\\\", \\\"{x:1481,y:857,t:1527023594067};\\\", \\\"{x:1481,y:853,t:1527023594084};\\\", \\\"{x:1482,y:850,t:1527023594100};\\\", \\\"{x:1482,y:849,t:1527023594117};\\\", \\\"{x:1482,y:847,t:1527023594134};\\\", \\\"{x:1482,y:846,t:1527023594149};\\\", \\\"{x:1482,y:845,t:1527023594166};\\\", \\\"{x:1482,y:843,t:1527023594183};\\\", \\\"{x:1482,y:841,t:1527023594200};\\\", \\\"{x:1482,y:840,t:1527023594217};\\\", \\\"{x:1482,y:838,t:1527023594233};\\\", \\\"{x:1482,y:837,t:1527023594251};\\\", \\\"{x:1482,y:835,t:1527023594267};\\\", \\\"{x:1482,y:834,t:1527023594300};\\\", \\\"{x:1482,y:832,t:1527023594778};\\\", \\\"{x:1482,y:831,t:1527023594802};\\\", \\\"{x:1482,y:829,t:1527023594913};\\\", \\\"{x:1481,y:829,t:1527023600442};\\\", \\\"{x:1480,y:829,t:1527023600457};\\\", \\\"{x:1477,y:829,t:1527023600472};\\\", \\\"{x:1476,y:829,t:1527023600489};\\\", \\\"{x:1474,y:830,t:1527023600507};\\\", \\\"{x:1471,y:831,t:1527023600524};\\\", \\\"{x:1470,y:832,t:1527023600539};\\\", \\\"{x:1465,y:837,t:1527023600556};\\\", \\\"{x:1459,y:844,t:1527023600573};\\\", \\\"{x:1458,y:847,t:1527023600589};\\\", \\\"{x:1453,y:854,t:1527023600606};\\\", \\\"{x:1452,y:859,t:1527023600624};\\\", \\\"{x:1451,y:864,t:1527023600640};\\\", \\\"{x:1448,y:873,t:1527023600657};\\\", \\\"{x:1446,y:880,t:1527023600673};\\\", \\\"{x:1439,y:892,t:1527023600689};\\\", \\\"{x:1434,y:901,t:1527023600706};\\\", \\\"{x:1428,y:908,t:1527023600723};\\\", \\\"{x:1427,y:909,t:1527023600740};\\\", \\\"{x:1426,y:911,t:1527023600756};\\\", \\\"{x:1426,y:912,t:1527023600773};\\\", \\\"{x:1425,y:912,t:1527023600790};\\\", \\\"{x:1425,y:913,t:1527023600807};\\\", \\\"{x:1423,y:915,t:1527023600823};\\\", \\\"{x:1422,y:915,t:1527023600840};\\\", \\\"{x:1421,y:916,t:1527023600946};\\\", \\\"{x:1420,y:916,t:1527023600978};\\\", \\\"{x:1419,y:916,t:1527023601018};\\\", \\\"{x:1418,y:917,t:1527023601026};\\\", \\\"{x:1417,y:918,t:1527023601058};\\\", \\\"{x:1416,y:918,t:1527023601082};\\\", \\\"{x:1414,y:918,t:1527023601106};\\\", \\\"{x:1413,y:918,t:1527023601123};\\\", \\\"{x:1411,y:918,t:1527023601140};\\\", \\\"{x:1407,y:918,t:1527023601157};\\\", \\\"{x:1404,y:918,t:1527023601173};\\\", \\\"{x:1401,y:917,t:1527023601191};\\\", \\\"{x:1400,y:917,t:1527023601210};\\\", \\\"{x:1399,y:916,t:1527023601242};\\\", \\\"{x:1397,y:915,t:1527023601258};\\\", \\\"{x:1397,y:914,t:1527023601305};\\\", \\\"{x:1396,y:914,t:1527023601321};\\\", \\\"{x:1395,y:913,t:1527023601355};\\\", \\\"{x:1394,y:912,t:1527023601369};\\\", \\\"{x:1393,y:911,t:1527023601418};\\\", \\\"{x:1393,y:910,t:1527023601433};\\\", \\\"{x:1393,y:909,t:1527023601441};\\\", \\\"{x:1391,y:908,t:1527023601458};\\\", \\\"{x:1390,y:907,t:1527023601514};\\\", \\\"{x:1390,y:906,t:1527023601538};\\\", \\\"{x:1390,y:905,t:1527023601555};\\\", \\\"{x:1389,y:905,t:1527023601561};\\\", \\\"{x:1388,y:905,t:1527023601573};\\\", \\\"{x:1388,y:904,t:1527023601589};\\\", \\\"{x:1387,y:903,t:1527023601607};\\\", \\\"{x:1387,y:902,t:1527023601623};\\\", \\\"{x:1385,y:902,t:1527023601640};\\\", \\\"{x:1385,y:901,t:1527023601665};\\\", \\\"{x:1384,y:900,t:1527023601754};\\\", \\\"{x:1383,y:900,t:1527023601970};\\\", \\\"{x:1382,y:900,t:1527023602033};\\\", \\\"{x:1382,y:899,t:1527023604681};\\\", \\\"{x:1382,y:897,t:1527023604698};\\\", \\\"{x:1381,y:896,t:1527023605122};\\\", \\\"{x:1381,y:894,t:1527023605137};\\\", \\\"{x:1381,y:893,t:1527023605154};\\\", \\\"{x:1381,y:891,t:1527023605187};\\\", \\\"{x:1381,y:890,t:1527023605201};\\\", \\\"{x:1381,y:888,t:1527023607130};\\\", \\\"{x:1381,y:887,t:1527023607145};\\\", \\\"{x:1381,y:886,t:1527023607162};\\\", \\\"{x:1381,y:885,t:1527023607179};\\\", \\\"{x:1380,y:885,t:1527023607196};\\\", \\\"{x:1379,y:884,t:1527023607330};\\\", \\\"{x:1379,y:883,t:1527023607497};\\\", \\\"{x:1379,y:882,t:1527023607520};\\\", \\\"{x:1379,y:881,t:1527023607657};\\\", \\\"{x:1379,y:880,t:1527023607858};\\\", \\\"{x:1379,y:879,t:1527023607946};\\\", \\\"{x:1379,y:878,t:1527023608018};\\\", \\\"{x:1379,y:877,t:1527023608050};\\\", \\\"{x:1379,y:876,t:1527023608114};\\\", \\\"{x:1379,y:875,t:1527023608154};\\\", \\\"{x:1379,y:874,t:1527023608186};\\\", \\\"{x:1379,y:873,t:1527023608196};\\\", \\\"{x:1379,y:871,t:1527023608425};\\\", \\\"{x:1379,y:870,t:1527023608450};\\\", \\\"{x:1379,y:869,t:1527023608514};\\\", \\\"{x:1379,y:867,t:1527023608546};\\\", \\\"{x:1379,y:866,t:1527023608601};\\\", \\\"{x:1379,y:864,t:1527023608642};\\\", \\\"{x:1379,y:863,t:1527023608690};\\\", \\\"{x:1379,y:861,t:1527023608930};\\\", \\\"{x:1379,y:860,t:1527023609090};\\\", \\\"{x:1379,y:859,t:1527023609097};\\\", \\\"{x:1379,y:858,t:1527023609115};\\\", \\\"{x:1379,y:857,t:1527023609130};\\\", \\\"{x:1379,y:856,t:1527023609154};\\\", \\\"{x:1379,y:854,t:1527023609586};\\\", \\\"{x:1378,y:853,t:1527023609597};\\\", \\\"{x:1377,y:851,t:1527023609614};\\\", \\\"{x:1377,y:850,t:1527023609631};\\\", \\\"{x:1376,y:848,t:1527023609648};\\\", \\\"{x:1376,y:847,t:1527023609665};\\\", \\\"{x:1375,y:846,t:1527023609689};\\\", \\\"{x:1375,y:844,t:1527023613418};\\\", \\\"{x:1375,y:841,t:1527023613435};\\\", \\\"{x:1373,y:836,t:1527023613451};\\\", \\\"{x:1372,y:833,t:1527023613468};\\\", \\\"{x:1371,y:829,t:1527023613484};\\\", \\\"{x:1370,y:826,t:1527023613501};\\\", \\\"{x:1369,y:822,t:1527023613517};\\\", \\\"{x:1368,y:819,t:1527023613534};\\\", \\\"{x:1368,y:816,t:1527023613553};\\\", \\\"{x:1367,y:813,t:1527023613568};\\\", \\\"{x:1365,y:811,t:1527023613585};\\\", \\\"{x:1365,y:807,t:1527023613601};\\\", \\\"{x:1365,y:805,t:1527023613619};\\\", \\\"{x:1363,y:802,t:1527023613635};\\\", \\\"{x:1363,y:800,t:1527023613651};\\\", \\\"{x:1361,y:796,t:1527023613668};\\\", \\\"{x:1361,y:792,t:1527023613684};\\\", \\\"{x:1360,y:787,t:1527023613701};\\\", \\\"{x:1360,y:784,t:1527023613718};\\\", \\\"{x:1358,y:781,t:1527023613734};\\\", \\\"{x:1358,y:777,t:1527023613751};\\\", \\\"{x:1357,y:775,t:1527023613768};\\\", \\\"{x:1356,y:770,t:1527023613784};\\\", \\\"{x:1356,y:768,t:1527023613801};\\\", \\\"{x:1355,y:766,t:1527023613818};\\\", \\\"{x:1354,y:764,t:1527023613834};\\\", \\\"{x:1354,y:763,t:1527023613852};\\\", \\\"{x:1354,y:762,t:1527023613897};\\\", \\\"{x:1353,y:761,t:1527023613905};\\\", \\\"{x:1353,y:760,t:1527023613953};\\\", \\\"{x:1353,y:759,t:1527023613977};\\\", \\\"{x:1352,y:759,t:1527023617410};\\\", \\\"{x:1350,y:759,t:1527023617421};\\\", \\\"{x:1346,y:761,t:1527023617438};\\\", \\\"{x:1345,y:761,t:1527023617454};\\\", \\\"{x:1344,y:761,t:1527023617471};\\\", \\\"{x:1343,y:763,t:1527023617488};\\\", \\\"{x:1341,y:763,t:1527023617504};\\\", \\\"{x:1341,y:767,t:1527023617521};\\\", \\\"{x:1341,y:771,t:1527023617538};\\\", \\\"{x:1341,y:774,t:1527023617554};\\\", \\\"{x:1341,y:776,t:1527023617572};\\\", \\\"{x:1343,y:777,t:1527023617588};\\\", \\\"{x:1343,y:778,t:1527023617604};\\\", \\\"{x:1344,y:780,t:1527023617622};\\\", \\\"{x:1344,y:781,t:1527023617638};\\\", \\\"{x:1344,y:783,t:1527023617654};\\\", \\\"{x:1344,y:784,t:1527023617671};\\\", \\\"{x:1344,y:785,t:1527023617688};\\\", \\\"{x:1344,y:786,t:1527023617705};\\\", \\\"{x:1344,y:787,t:1527023617721};\\\", \\\"{x:1344,y:786,t:1527023618033};\\\", \\\"{x:1344,y:785,t:1527023618057};\\\", \\\"{x:1344,y:784,t:1527023618089};\\\", \\\"{x:1344,y:783,t:1527023618146};\\\", \\\"{x:1344,y:782,t:1527023618156};\\\", \\\"{x:1344,y:781,t:1527023618173};\\\", \\\"{x:1344,y:780,t:1527023618189};\\\", \\\"{x:1344,y:778,t:1527023618206};\\\", \\\"{x:1344,y:777,t:1527023618225};\\\", \\\"{x:1344,y:776,t:1527023618239};\\\", \\\"{x:1345,y:775,t:1527023618256};\\\", \\\"{x:1345,y:774,t:1527023618273};\\\", \\\"{x:1345,y:772,t:1527023618289};\\\", \\\"{x:1346,y:770,t:1527023618889};\\\", \\\"{x:1347,y:769,t:1527023618907};\\\", \\\"{x:1347,y:768,t:1527023618923};\\\", \\\"{x:1348,y:767,t:1527023618939};\\\", \\\"{x:1349,y:765,t:1527023618956};\\\", \\\"{x:1350,y:764,t:1527023618973};\\\", \\\"{x:1350,y:763,t:1527023619034};\\\", \\\"{x:1351,y:762,t:1527023619057};\\\", \\\"{x:1351,y:761,t:1527023619481};\\\", \\\"{x:1351,y:760,t:1527023619489};\\\", \\\"{x:1351,y:759,t:1527023619507};\\\", \\\"{x:1352,y:758,t:1527023619525};\\\", \\\"{x:1353,y:758,t:1527023619540};\\\", \\\"{x:1353,y:759,t:1527023623500};\\\", \\\"{x:1352,y:760,t:1527023623516};\\\", \\\"{x:1350,y:761,t:1527023623812};\\\", \\\"{x:1349,y:761,t:1527023623835};\\\", \\\"{x:1348,y:762,t:1527023623847};\\\", \\\"{x:1346,y:762,t:1527023623884};\\\", \\\"{x:1347,y:762,t:1527023629125};\\\", \\\"{x:1348,y:760,t:1527023629135};\\\", \\\"{x:1349,y:758,t:1527023629153};\\\", \\\"{x:1350,y:757,t:1527023629169};\\\", \\\"{x:1351,y:755,t:1527023629186};\\\", \\\"{x:1351,y:753,t:1527023629202};\\\", \\\"{x:1351,y:751,t:1527023629220};\\\", \\\"{x:1351,y:749,t:1527023629236};\\\", \\\"{x:1353,y:745,t:1527023629253};\\\", \\\"{x:1353,y:743,t:1527023629269};\\\", \\\"{x:1353,y:740,t:1527023629285};\\\", \\\"{x:1354,y:738,t:1527023629303};\\\", \\\"{x:1354,y:737,t:1527023629319};\\\", \\\"{x:1355,y:735,t:1527023629336};\\\", \\\"{x:1355,y:734,t:1527023629353};\\\", \\\"{x:1355,y:732,t:1527023629370};\\\", \\\"{x:1355,y:729,t:1527023629385};\\\", \\\"{x:1356,y:722,t:1527023629402};\\\", \\\"{x:1357,y:718,t:1527023629419};\\\", \\\"{x:1357,y:715,t:1527023629436};\\\", \\\"{x:1358,y:713,t:1527023629453};\\\", \\\"{x:1358,y:711,t:1527023629470};\\\", \\\"{x:1358,y:709,t:1527023629486};\\\", \\\"{x:1358,y:708,t:1527023629503};\\\", \\\"{x:1358,y:704,t:1527023629519};\\\", \\\"{x:1358,y:701,t:1527023629535};\\\", \\\"{x:1358,y:698,t:1527023629553};\\\", \\\"{x:1358,y:696,t:1527023629570};\\\", \\\"{x:1357,y:696,t:1527023633749};\\\", \\\"{x:1356,y:696,t:1527023633947};\\\", \\\"{x:1355,y:696,t:1527023633964};\\\", \\\"{x:1354,y:697,t:1527023633988};\\\", \\\"{x:1354,y:698,t:1527023633995};\\\", \\\"{x:1353,y:698,t:1527023635174};\\\", \\\"{x:1352,y:698,t:1527023635191};\\\", \\\"{x:1352,y:699,t:1527023635208};\\\", \\\"{x:1351,y:699,t:1527023635693};\\\", \\\"{x:1348,y:699,t:1527023639045};\\\", \\\"{x:1336,y:687,t:1527023639063};\\\", \\\"{x:1315,y:673,t:1527023639077};\\\", \\\"{x:1280,y:648,t:1527023639094};\\\", \\\"{x:1244,y:625,t:1527023639111};\\\", \\\"{x:1211,y:605,t:1527023639127};\\\", \\\"{x:1193,y:591,t:1527023639144};\\\", \\\"{x:1188,y:587,t:1527023639161};\\\", \\\"{x:1186,y:585,t:1527023639178};\\\", \\\"{x:1185,y:584,t:1527023639196};\\\", \\\"{x:1183,y:582,t:1527023639220};\\\", \\\"{x:1182,y:582,t:1527023639227};\\\", \\\"{x:1177,y:580,t:1527023639245};\\\", \\\"{x:1170,y:578,t:1527023639262};\\\", \\\"{x:1150,y:578,t:1527023639278};\\\", \\\"{x:1124,y:578,t:1527023639294};\\\", \\\"{x:1090,y:578,t:1527023639311};\\\", \\\"{x:1048,y:578,t:1527023639328};\\\", \\\"{x:1007,y:574,t:1527023639345};\\\", \\\"{x:964,y:567,t:1527023639361};\\\", \\\"{x:933,y:561,t:1527023639379};\\\", \\\"{x:906,y:551,t:1527023639394};\\\", \\\"{x:879,y:539,t:1527023639412};\\\", \\\"{x:861,y:531,t:1527023639436};\\\", \\\"{x:846,y:524,t:1527023639452};\\\", \\\"{x:842,y:521,t:1527023639472};\\\", \\\"{x:839,y:521,t:1527023639489};\\\", \\\"{x:839,y:520,t:1527023639505};\\\", \\\"{x:839,y:519,t:1527023639523};\\\", \\\"{x:839,y:518,t:1527023639540};\\\", \\\"{x:840,y:518,t:1527023640148};\\\", \\\"{x:845,y:518,t:1527023640158};\\\", \\\"{x:864,y:520,t:1527023640173};\\\", \\\"{x:896,y:533,t:1527023640191};\\\", \\\"{x:946,y:555,t:1527023640206};\\\", \\\"{x:999,y:576,t:1527023640222};\\\", \\\"{x:1054,y:600,t:1527023640240};\\\", \\\"{x:1099,y:622,t:1527023640256};\\\", \\\"{x:1137,y:637,t:1527023640273};\\\", \\\"{x:1164,y:647,t:1527023640290};\\\", \\\"{x:1186,y:653,t:1527023640306};\\\", \\\"{x:1204,y:659,t:1527023640323};\\\", \\\"{x:1230,y:666,t:1527023640340};\\\", \\\"{x:1250,y:674,t:1527023640357};\\\", \\\"{x:1269,y:681,t:1527023640372};\\\", \\\"{x:1286,y:688,t:1527023640389};\\\", \\\"{x:1303,y:695,t:1527023640407};\\\", \\\"{x:1322,y:699,t:1527023640422};\\\", \\\"{x:1339,y:703,t:1527023640439};\\\", \\\"{x:1354,y:709,t:1527023640457};\\\", \\\"{x:1371,y:713,t:1527023640473};\\\", \\\"{x:1384,y:715,t:1527023640490};\\\", \\\"{x:1394,y:716,t:1527023640507};\\\", \\\"{x:1401,y:717,t:1527023640522};\\\", \\\"{x:1409,y:718,t:1527023640539};\\\", \\\"{x:1416,y:719,t:1527023640556};\\\", \\\"{x:1422,y:721,t:1527023640572};\\\", \\\"{x:1425,y:721,t:1527023640590};\\\", \\\"{x:1429,y:721,t:1527023640607};\\\", \\\"{x:1432,y:721,t:1527023640624};\\\", \\\"{x:1432,y:720,t:1527023640806};\\\", \\\"{x:1429,y:717,t:1527023640824};\\\", \\\"{x:1425,y:715,t:1527023640840};\\\", \\\"{x:1424,y:713,t:1527023640858};\\\", \\\"{x:1422,y:712,t:1527023640875};\\\", \\\"{x:1421,y:711,t:1527023640891};\\\", \\\"{x:1419,y:710,t:1527023640907};\\\", \\\"{x:1417,y:710,t:1527023640924};\\\", \\\"{x:1416,y:710,t:1527023640940};\\\", \\\"{x:1414,y:710,t:1527023640958};\\\", \\\"{x:1412,y:708,t:1527023640974};\\\", \\\"{x:1411,y:708,t:1527023640990};\\\", \\\"{x:1409,y:708,t:1527023641008};\\\", \\\"{x:1407,y:708,t:1527023641024};\\\", \\\"{x:1403,y:708,t:1527023641040};\\\", \\\"{x:1400,y:707,t:1527023641057};\\\", \\\"{x:1398,y:707,t:1527023641075};\\\", \\\"{x:1396,y:707,t:1527023641092};\\\", \\\"{x:1394,y:707,t:1527023641108};\\\", \\\"{x:1393,y:707,t:1527023641124};\\\", \\\"{x:1392,y:706,t:1527023641141};\\\", \\\"{x:1391,y:706,t:1527023641158};\\\", \\\"{x:1389,y:705,t:1527023641196};\\\", \\\"{x:1387,y:704,t:1527023641221};\\\", \\\"{x:1386,y:703,t:1527023641236};\\\", \\\"{x:1384,y:701,t:1527023641244};\\\", \\\"{x:1384,y:700,t:1527023641257};\\\", \\\"{x:1383,y:695,t:1527023641273};\\\", \\\"{x:1380,y:687,t:1527023641290};\\\", \\\"{x:1377,y:674,t:1527023641306};\\\", \\\"{x:1368,y:644,t:1527023641324};\\\", \\\"{x:1359,y:619,t:1527023641340};\\\", \\\"{x:1351,y:601,t:1527023641357};\\\", \\\"{x:1345,y:588,t:1527023641374};\\\", \\\"{x:1343,y:583,t:1527023641391};\\\", \\\"{x:1340,y:578,t:1527023641406};\\\", \\\"{x:1339,y:577,t:1527023641428};\\\", \\\"{x:1339,y:576,t:1527023641441};\\\", \\\"{x:1338,y:575,t:1527023641457};\\\", \\\"{x:1338,y:574,t:1527023641476};\\\", \\\"{x:1337,y:573,t:1527023641491};\\\", \\\"{x:1336,y:573,t:1527023641507};\\\", \\\"{x:1336,y:572,t:1527023641524};\\\", \\\"{x:1334,y:572,t:1527023641541};\\\", \\\"{x:1333,y:571,t:1527023641558};\\\", \\\"{x:1330,y:570,t:1527023641574};\\\", \\\"{x:1326,y:569,t:1527023641591};\\\", \\\"{x:1325,y:568,t:1527023641608};\\\", \\\"{x:1323,y:567,t:1527023641624};\\\", \\\"{x:1322,y:566,t:1527023641641};\\\", \\\"{x:1320,y:565,t:1527023641658};\\\", \\\"{x:1317,y:564,t:1527023641674};\\\", \\\"{x:1315,y:563,t:1527023641691};\\\", \\\"{x:1313,y:562,t:1527023641709};\\\", \\\"{x:1312,y:562,t:1527023641724};\\\", \\\"{x:1311,y:562,t:1527023641741};\\\", \\\"{x:1309,y:562,t:1527023641781};\\\", \\\"{x:1308,y:562,t:1527023641792};\\\", \\\"{x:1306,y:562,t:1527023641808};\\\", \\\"{x:1304,y:562,t:1527023641824};\\\", \\\"{x:1303,y:562,t:1527023641844};\\\", \\\"{x:1301,y:562,t:1527023647709};\\\", \\\"{x:1300,y:562,t:1527023647741};\\\", \\\"{x:1299,y:562,t:1527023647758};\\\", \\\"{x:1298,y:562,t:1527023647772};\\\", \\\"{x:1297,y:562,t:1527023647805};\\\", \\\"{x:1296,y:563,t:1527023647821};\\\", \\\"{x:1295,y:563,t:1527023647972};\\\", \\\"{x:1294,y:564,t:1527023647980};\\\", \\\"{x:1293,y:564,t:1527023647996};\\\", \\\"{x:1291,y:565,t:1527023648012};\\\", \\\"{x:1289,y:566,t:1527023648029};\\\", \\\"{x:1283,y:569,t:1527023648046};\\\", \\\"{x:1263,y:574,t:1527023648063};\\\", \\\"{x:1224,y:578,t:1527023648080};\\\", \\\"{x:1171,y:578,t:1527023648096};\\\", \\\"{x:1115,y:578,t:1527023648114};\\\", \\\"{x:1067,y:578,t:1527023648129};\\\", \\\"{x:1036,y:578,t:1527023648147};\\\", \\\"{x:1011,y:578,t:1527023648164};\\\", \\\"{x:991,y:578,t:1527023648180};\\\", \\\"{x:969,y:578,t:1527023648197};\\\", \\\"{x:953,y:578,t:1527023648213};\\\", \\\"{x:943,y:578,t:1527023648230};\\\", \\\"{x:938,y:578,t:1527023648246};\\\", \\\"{x:935,y:578,t:1527023648263};\\\", \\\"{x:934,y:578,t:1527023648272};\\\", \\\"{x:930,y:578,t:1527023648289};\\\", \\\"{x:929,y:578,t:1527023648305};\\\", \\\"{x:927,y:579,t:1527023648322};\\\", \\\"{x:923,y:579,t:1527023648339};\\\", \\\"{x:898,y:579,t:1527023648355};\\\", \\\"{x:863,y:576,t:1527023648372};\\\", \\\"{x:809,y:566,t:1527023648389};\\\", \\\"{x:726,y:543,t:1527023648413};\\\", \\\"{x:696,y:536,t:1527023648429};\\\", \\\"{x:678,y:530,t:1527023648447};\\\", \\\"{x:660,y:526,t:1527023648463};\\\", \\\"{x:643,y:524,t:1527023648480};\\\", \\\"{x:627,y:518,t:1527023648497};\\\", \\\"{x:616,y:515,t:1527023648513};\\\", \\\"{x:602,y:509,t:1527023648529};\\\", \\\"{x:590,y:504,t:1527023648547};\\\", \\\"{x:585,y:501,t:1527023648562};\\\", \\\"{x:581,y:500,t:1527023648580};\\\", \\\"{x:582,y:501,t:1527023648854};\\\", \\\"{x:584,y:501,t:1527023648863};\\\", \\\"{x:590,y:502,t:1527023648880};\\\", \\\"{x:596,y:503,t:1527023648896};\\\", \\\"{x:600,y:505,t:1527023648914};\\\", \\\"{x:601,y:505,t:1527023648939};\\\", \\\"{x:602,y:506,t:1527023648964};\\\", \\\"{x:603,y:506,t:1527023648987};\\\", \\\"{x:604,y:506,t:1527023649028};\\\", \\\"{x:604,y:507,t:1527023649125};\\\", \\\"{x:604,y:517,t:1527023649532};\\\", \\\"{x:602,y:541,t:1527023649548};\\\", \\\"{x:578,y:658,t:1527023649564};\\\", \\\"{x:556,y:728,t:1527023649580};\\\", \\\"{x:551,y:750,t:1527023649598};\\\", \\\"{x:549,y:752,t:1527023649614};\\\", \\\"{x:549,y:753,t:1527023649659};\\\", \\\"{x:547,y:754,t:1527023649667};\\\", \\\"{x:544,y:756,t:1527023649681};\\\", \\\"{x:540,y:758,t:1527023649697};\\\", \\\"{x:539,y:758,t:1527023649714};\\\", \\\"{x:538,y:756,t:1527023649797};\\\", \\\"{x:538,y:754,t:1527023649814};\\\" ] }, { \\\"rt\\\": 33165, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 543710, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"OZV09\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Look at the points corresponding to 12 pm from the x-axis.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 5921, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Taiwan\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 550636, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"OZV09\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 25578, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Mandarin or Cantonese\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 577234, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"OZV09\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 2130, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 580682, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"OZV09\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"OZV09\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 239, dom: 1112, initialDom: 1191",
  "javascriptErrors": []
}