var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "e64f917d6c174f4698e48afc6158dba2",
  "created": "2018-05-21T09:09:01.7449918-07:00",
  "lastActivity": "2018-05-21T09:09:46.6539986-07:00",
  "pageViews": [
    {
      "id": "05210189eb7a83ccaeed6924ab75d821e0ce8c59",
      "startTime": "2018-05-21T09:09:01.7449918-07:00",
      "endTime": "2018-05-21T09:09:46.6539986-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 45079,
      "engagementTime": 21832,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 45079,
  "engagementTime": 21832,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "69.196.34.183",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.139",
  "os": "macOS",
  "osVersion": "10.12 Sierra",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1440x900",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=G72GB",
    "CONDITION=121",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "6ed6ef1a2da8aae96f91f294e13bbe6a",
  "gdpr": false
}