var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "9b8214af3bef348ef21b2772a8b256fd",
  "created": "2018-05-22T10:18:37.8948432-07:00",
  "lastActivity": "2018-05-22T10:19:28.1898432-07:00",
  "pageViews": [
    {
      "id": "0522380368b06b3bd922be522a6ede4487dfc6de",
      "startTime": "2018-05-22T10:18:37.8948432-07:00",
      "endTime": "2018-05-22T10:19:28.1898432-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 50295,
      "engagementTime": 38637,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 50295,
  "engagementTime": 38637,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=VSHHA",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "6016a1f289b543c06a83f0ba6086f2ca",
  "gdpr": false
}