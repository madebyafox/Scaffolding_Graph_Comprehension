var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052908889239390947bf03b942ceae975c7b09d5"] = {
  "startTime": "2018-05-29T23:17:08.2744675Z",
  "websitePageUrl": "/16",
  "visitTime": 103551,
  "engagementTime": 95075,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "c2f205795f872d8af58cf115c0f0b28f",
    "created": "2018-05-29T23:17:08.2744675+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=8FE87",
      "CONDITION=113"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "e37abd6118809aff06784a1271ae73b0",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/c2f205795f872d8af58cf115c0f0b28f/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 189,
      "e": 189,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 189,
      "e": 189,
      "ty": 2,
      "x": 669,
      "y": 440
    },
    {
      "t": 200,
      "e": 200,
      "ty": 2,
      "x": 670,
      "y": 440
    },
    {
      "t": 251,
      "e": 251,
      "ty": 41,
      "x": 64400,
      "y": 7143,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 400,
      "e": 400,
      "ty": 2,
      "x": 683,
      "y": 443
    },
    {
      "t": 501,
      "e": 501,
      "ty": 2,
      "x": 743,
      "y": 455
    },
    {
      "t": 501,
      "e": 501,
      "ty": 41,
      "x": 3610,
      "y": 26270,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 676,
      "e": 676,
      "ty": 6,
      "x": 668,
      "y": 507,
      "ta": "#strategyAnswer"
    },
    {
      "t": 684,
      "e": 684,
      "ty": 2,
      "x": 668,
      "y": 507
    },
    {
      "t": 701,
      "e": 701,
      "ty": 2,
      "x": 639,
      "y": 510
    },
    {
      "t": 751,
      "e": 751,
      "ty": 41,
      "x": 42368,
      "y": 40668,
      "ta": "#strategyAnswer"
    },
    {
      "t": 801,
      "e": 801,
      "ty": 2,
      "x": 432,
      "y": 520
    },
    {
      "t": 861,
      "e": 861,
      "ty": 3,
      "x": 430,
      "y": 520,
      "ta": "#strategyAnswer"
    },
    {
      "t": 861,
      "e": 861,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 901,
      "e": 901,
      "ty": 2,
      "x": 430,
      "y": 520
    },
    {
      "t": 931,
      "e": 931,
      "ty": 4,
      "x": 37421,
      "y": 40668,
      "ta": "#strategyAnswer"
    },
    {
      "t": 932,
      "e": 932,
      "ty": 5,
      "x": 430,
      "y": 520,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 37421,
      "y": 40668,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1100,
      "e": 1100,
      "ty": 2,
      "x": 435,
      "y": 509
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 475,
      "y": 477
    },
    {
      "t": 1226,
      "e": 1226,
      "ty": 7,
      "x": 499,
      "y": 466,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 46639,
      "y": 49772,
      "ta": "#.strategy > p"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 533,
      "y": 456
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 569,
      "y": 450
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 604,
      "y": 446
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 56981,
      "y": 9983,
      "ta": "#.strategy > p"
    },
    {
      "t": 1601,
      "e": 1601,
      "ty": 2,
      "x": 690,
      "y": 431
    },
    {
      "t": 1701,
      "e": 1701,
      "ty": 2,
      "x": 761,
      "y": 411
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 5447,
      "y": 22720,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 779,
      "y": 403
    },
    {
      "t": 1901,
      "e": 1901,
      "ty": 2,
      "x": 782,
      "y": 401
    },
    {
      "t": 2002,
      "e": 2002,
      "ty": 41,
      "x": 5849,
      "y": 22436,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 3751,
      "e": 3751,
      "ty": 41,
      "x": 282,
      "y": 22274,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3801,
      "e": 3801,
      "ty": 2,
      "x": 1080,
      "y": 350
    },
    {
      "t": 3901,
      "e": 3901,
      "ty": 2,
      "x": 1314,
      "y": 279
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 2,
      "x": 1315,
      "y": 278
    },
    {
      "t": 4002,
      "e": 4002,
      "ty": 41,
      "x": 37278,
      "y": 13823,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 2,
      "x": 1300,
      "y": 188
    },
    {
      "t": 4502,
      "e": 4502,
      "ty": 41,
      "x": 36221,
      "y": 7377,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4601,
      "e": 4601,
      "ty": 2,
      "x": 1290,
      "y": 143
    },
    {
      "t": 4701,
      "e": 4701,
      "ty": 2,
      "x": 1290,
      "y": 142
    },
    {
      "t": 4751,
      "e": 4751,
      "ty": 41,
      "x": 35516,
      "y": 3796,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4801,
      "e": 4801,
      "ty": 2,
      "x": 1290,
      "y": 133
    },
    {
      "t": 4901,
      "e": 4901,
      "ty": 2,
      "x": 1289,
      "y": 132
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 2,
      "x": 1288,
      "y": 129
    },
    {
      "t": 5002,
      "e": 5002,
      "ty": 41,
      "x": 35375,
      "y": 3151,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5601,
      "e": 5601,
      "ty": 2,
      "x": 1283,
      "y": 143
    },
    {
      "t": 5701,
      "e": 5701,
      "ty": 2,
      "x": 1286,
      "y": 186
    },
    {
      "t": 5752,
      "e": 5752,
      "ty": 41,
      "x": 35516,
      "y": 10456,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5802,
      "e": 5802,
      "ty": 2,
      "x": 1298,
      "y": 305
    },
    {
      "t": 5901,
      "e": 5901,
      "ty": 2,
      "x": 1325,
      "y": 500
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 2,
      "x": 1344,
      "y": 640
    },
    {
      "t": 6002,
      "e": 6002,
      "ty": 41,
      "x": 39322,
      "y": 39750,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6102,
      "e": 6102,
      "ty": 2,
      "x": 1350,
      "y": 754
    },
    {
      "t": 6201,
      "e": 6201,
      "ty": 2,
      "x": 1348,
      "y": 819
    },
    {
      "t": 6301,
      "e": 6301,
      "ty": 2,
      "x": 1335,
      "y": 865
    },
    {
      "t": 6401,
      "e": 6401,
      "ty": 2,
      "x": 1318,
      "y": 893
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 2,
      "x": 1315,
      "y": 899
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 41,
      "x": 37278,
      "y": 58301,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6601,
      "e": 6601,
      "ty": 2,
      "x": 1310,
      "y": 906
    },
    {
      "t": 6700,
      "e": 6700,
      "ty": 2,
      "x": 1296,
      "y": 917
    },
    {
      "t": 6752,
      "e": 6752,
      "ty": 41,
      "x": 36830,
      "y": 16639,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[13] > text"
    },
    {
      "t": 6802,
      "e": 6802,
      "ty": 2,
      "x": 1286,
      "y": 920
    },
    {
      "t": 6901,
      "e": 6901,
      "ty": 2,
      "x": 1285,
      "y": 921
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 2,
      "x": 1257,
      "y": 921
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 41,
      "x": 33191,
      "y": 59876,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7102,
      "e": 7102,
      "ty": 2,
      "x": 1214,
      "y": 920
    },
    {
      "t": 7201,
      "e": 7201,
      "ty": 2,
      "x": 1183,
      "y": 919
    },
    {
      "t": 7251,
      "e": 7251,
      "ty": 41,
      "x": 27765,
      "y": 59733,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7301,
      "e": 7301,
      "ty": 2,
      "x": 1180,
      "y": 919
    },
    {
      "t": 9301,
      "e": 9301,
      "ty": 2,
      "x": 1177,
      "y": 928
    },
    {
      "t": 9401,
      "e": 9401,
      "ty": 2,
      "x": 1175,
      "y": 932
    },
    {
      "t": 9501,
      "e": 9501,
      "ty": 2,
      "x": 1171,
      "y": 935
    },
    {
      "t": 9502,
      "e": 9502,
      "ty": 41,
      "x": 27131,
      "y": 60879,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9602,
      "e": 9602,
      "ty": 2,
      "x": 1169,
      "y": 935
    },
    {
      "t": 9701,
      "e": 9701,
      "ty": 2,
      "x": 1168,
      "y": 935
    },
    {
      "t": 9751,
      "e": 9751,
      "ty": 41,
      "x": 26849,
      "y": 60879,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9801,
      "e": 9801,
      "ty": 2,
      "x": 1167,
      "y": 935
    },
    {
      "t": 9901,
      "e": 9901,
      "ty": 2,
      "x": 1162,
      "y": 935
    },
    {
      "t": 10002,
      "e": 10002,
      "ty": 2,
      "x": 1160,
      "y": 935
    },
    {
      "t": 10002,
      "e": 10002,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10004,
      "e": 10004,
      "ty": 41,
      "x": 26356,
      "y": 60879,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10101,
      "e": 10101,
      "ty": 2,
      "x": 1155,
      "y": 929
    },
    {
      "t": 10202,
      "e": 10202,
      "ty": 2,
      "x": 1154,
      "y": 928
    },
    {
      "t": 10252,
      "e": 10252,
      "ty": 41,
      "x": 34130,
      "y": 49407,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 10500,
      "e": 10500,
      "ty": 2,
      "x": 1149,
      "y": 917
    },
    {
      "t": 10500,
      "e": 10500,
      "ty": 41,
      "x": 26030,
      "y": 4351,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 10600,
      "e": 10600,
      "ty": 2,
      "x": 1145,
      "y": 851
    },
    {
      "t": 10701,
      "e": 10701,
      "ty": 2,
      "x": 1164,
      "y": 722
    },
    {
      "t": 10751,
      "e": 10751,
      "ty": 41,
      "x": 27060,
      "y": 41827,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10800,
      "e": 10800,
      "ty": 2,
      "x": 1173,
      "y": 640
    },
    {
      "t": 10900,
      "e": 10900,
      "ty": 2,
      "x": 1173,
      "y": 618
    },
    {
      "t": 11002,
      "e": 11002,
      "ty": 2,
      "x": 1173,
      "y": 617
    },
    {
      "t": 11002,
      "e": 11002,
      "ty": 41,
      "x": 27272,
      "y": 38103,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 12569,
      "e": 12569,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12928,
      "e": 12928,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 12929,
      "e": 12929,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13007,
      "e": 13007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "W"
    },
    {
      "t": 13055,
      "e": 13055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "W"
    },
    {
      "t": 13136,
      "e": 13136,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 13137,
      "e": 13137,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13248,
      "e": 13248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 13249,
      "e": 13249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13271,
      "e": 13271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Wha"
    },
    {
      "t": 13375,
      "e": 13375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13375,
      "e": 13375,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13391,
      "e": 13391,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "What"
    },
    {
      "t": 13512,
      "e": 13512,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15344,
      "e": 15344,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 15345,
      "e": 15345,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15487,
      "e": 15487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 15576,
      "e": 15576,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 15576,
      "e": 15576,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15663,
      "e": 15663,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 15679,
      "e": 15679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 15679,
      "e": 15679,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15803,
      "e": 15803,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Whateve"
    },
    {
      "t": 15832,
      "e": 15832,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 15833,
      "e": 15833,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15848,
      "e": 15848,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 15975,
      "e": 15975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15975,
      "e": 15975,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15983,
      "e": 15983,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16119,
      "e": 16119,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18320,
      "e": 18320,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18819,
      "e": 18819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18853,
      "e": 18853,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18886,
      "e": 18886,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18918,
      "e": 18918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18951,
      "e": 18951,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18984,
      "e": 18984,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19017,
      "e": 19017,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19051,
      "e": 19051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19083,
      "e": 19083,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19117,
      "e": 19117,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19149,
      "e": 19149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19183,
      "e": 19183,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19216,
      "e": 19216,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19249,
      "e": 19249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19281,
      "e": 19281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19304,
      "e": 19304,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 19536,
      "e": 19536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "13"
    },
    {
      "t": 19537,
      "e": 19537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19616,
      "e": 19616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19672,
      "e": 19672,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "\n"
    },
    {
      "t": 19688,
      "e": 19688,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 19688,
      "e": 19688,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19759,
      "e": 19759,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "\ne"
    },
    {
      "t": 19784,
      "e": 19784,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "\ne"
    },
    {
      "t": 20001,
      "e": 20001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20071,
      "e": 20071,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 20152,
      "e": 20152,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "\n"
    },
    {
      "t": 20248,
      "e": 20248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 20335,
      "e": 20335,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 21240,
      "e": 21240,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 21464,
      "e": 21464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21465,
      "e": 21465,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21575,
      "e": 21575,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "E"
    },
    {
      "t": 21608,
      "e": 21608,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "E"
    },
    {
      "t": 21728,
      "e": 21728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 21729,
      "e": 21729,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21808,
      "e": 21808,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21809,
      "e": 21809,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21855,
      "e": 21855,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eve"
    },
    {
      "t": 21928,
      "e": 21928,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eve"
    },
    {
      "t": 21951,
      "e": 21951,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 21951,
      "e": 21951,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22056,
      "e": 22056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22057,
      "e": 22057,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22063,
      "e": 22063,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Event"
    },
    {
      "t": 22204,
      "e": 22204,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Event"
    },
    {
      "t": 22224,
      "e": 22224,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 22225,
      "e": 22225,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22263,
      "e": 22263,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 22375,
      "e": 22375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22376,
      "e": 22376,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22391,
      "e": 22391,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22511,
      "e": 22511,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22559,
      "e": 22559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22559,
      "e": 22559,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22688,
      "e": 22688,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 22737,
      "e": 22737,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 22738,
      "e": 22738,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22839,
      "e": 22839,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 25824,
      "e": 25824,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 25824,
      "e": 25824,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25976,
      "e": 25976,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25977,
      "e": 25977,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26047,
      "e": 26047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 26087,
      "e": 26087,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26088,
      "e": 26088,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26127,
      "e": 26127,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26271,
      "e": 26271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26456,
      "e": 26456,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 26457,
      "e": 26457,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26600,
      "e": 26600,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 26600,
      "e": 26600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26719,
      "e": 26719,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 26727,
      "e": 26727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26727,
      "e": 26727,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26767,
      "e": 26767,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 26928,
      "e": 26928,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26929,
      "e": 26929,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26935,
      "e": 26935,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27072,
      "e": 27072,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30001,
      "e": 30001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40247,
      "e": 32072,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 40247,
      "e": 32072,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40336,
      "e": 32161,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 40392,
      "e": 32217,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40393,
      "e": 32218,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40487,
      "e": 32312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 40487,
      "e": 32312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40511,
      "e": 32336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 40559,
      "e": 32384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40583,
      "e": 32408,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 40585,
      "e": 32410,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40631,
      "e": 32456,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 41160,
      "e": 32985,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41223,
      "e": 33048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that are ver"
    },
    {
      "t": 41735,
      "e": 33560,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41737,
      "e": 33562,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41831,
      "e": 33656,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 41839,
      "e": 33664,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 41839,
      "e": 33664,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41911,
      "e": 33736,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 41976,
      "e": 33801,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 41976,
      "e": 33801,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42075,
      "e": 33900,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 42091,
      "e": 33916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 42091,
      "e": 33916,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42171,
      "e": 33996,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 42171,
      "e": 33996,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42179,
      "e": 34004,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||le"
    },
    {
      "t": 42274,
      "e": 34099,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42275,
      "e": 34100,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42291,
      "e": 34116,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 42405,
      "e": 34230,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that are verticle "
    },
    {
      "t": 42426,
      "e": 34251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42515,
      "e": 34340,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42611,
      "e": 34436,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that are verticle"
    },
    {
      "t": 42731,
      "e": 34556,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42803,
      "e": 34628,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that are verticl"
    },
    {
      "t": 42892,
      "e": 34717,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42962,
      "e": 34787,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that are vertic"
    },
    {
      "t": 43026,
      "e": 34851,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 43027,
      "e": 34852,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43091,
      "e": 34916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 43091,
      "e": 34916,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43115,
      "e": 34940,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||al"
    },
    {
      "t": 43275,
      "e": 35100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43571,
      "e": 35396,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43572,
      "e": 35397,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43714,
      "e": 35539,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46323,
      "e": 38148,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46822,
      "e": 38647,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46855,
      "e": 38680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46887,
      "e": 38712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46921,
      "e": 38746,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46954,
      "e": 38779,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46987,
      "e": 38812,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 47019,
      "e": 38844,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 47053,
      "e": 38878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 47086,
      "e": 38911,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 47119,
      "e": 38944,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 47153,
      "e": 38978,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 47185,
      "e": 39010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 47218,
      "e": 39043,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 47251,
      "e": 39076,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 47284,
      "e": 39109,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 47317,
      "e": 39142,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 47339,
      "e": 39164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events t"
    },
    {
      "t": 47755,
      "e": 39580,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 47842,
      "e": 39667,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events "
    },
    {
      "t": 48475,
      "e": 40300,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 48476,
      "e": 40301,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48578,
      "e": 40403,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 48610,
      "e": 40435,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 48610,
      "e": 40435,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48683,
      "e": 40508,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 48684,
      "e": 40509,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48698,
      "e": 40523,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 48786,
      "e": 40611,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 48786,
      "e": 40611,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48835,
      "e": 40660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 48874,
      "e": 40699,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48876,
      "e": 40701,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48907,
      "e": 40732,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49008,
      "e": 40833,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that "
    },
    {
      "t": 49035,
      "e": 40860,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49251,
      "e": 41076,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 49252,
      "e": 41077,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49331,
      "e": 41156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 49331,
      "e": 41156,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49338,
      "e": 41163,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 49459,
      "e": 41284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49491,
      "e": 41316,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 49492,
      "e": 41317,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49554,
      "e": 41379,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 49554,
      "e": 41379,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49562,
      "e": 41387,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ve"
    },
    {
      "t": 49650,
      "e": 41475,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49651,
      "e": 41476,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49675,
      "e": 41500,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49747,
      "e": 41572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49756,
      "e": 41581,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 49756,
      "e": 41581,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49843,
      "e": 41668,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49843,
      "e": 41668,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49859,
      "e": 41684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a "
    },
    {
      "t": 49971,
      "e": 41796,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 49972,
      "e": 41797,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49978,
      "e": 41803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 50004,
      "e": 41829,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50082,
      "e": 41907,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50106,
      "e": 41931,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 50106,
      "e": 41931,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50219,
      "e": 42044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 50219,
      "e": 42044,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50227,
      "e": 42052,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ot"
    },
    {
      "t": 50330,
      "e": 42155,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50331,
      "e": 42156,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50347,
      "e": 42172,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 50459,
      "e": 42284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50523,
      "e": 42348,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 50524,
      "e": 42349,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50626,
      "e": 42451,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 50650,
      "e": 42475,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 50650,
      "e": 42475,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50739,
      "e": 42564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 50739,
      "e": 42564,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50747,
      "e": 42572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 50819,
      "e": 42644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 50820,
      "e": 42645,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50842,
      "e": 42667,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 50899,
      "e": 42724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50900,
      "e": 42725,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50914,
      "e": 42739,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 51019,
      "e": 42844,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51026,
      "e": 42851,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 51026,
      "e": 42851,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51083,
      "e": 42908,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 51083,
      "e": 42908,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51131,
      "e": 42956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||is"
    },
    {
      "t": 51147,
      "e": 42972,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51148,
      "e": 42973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51149,
      "e": 42974,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51275,
      "e": 43100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 51331,
      "e": 43156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 51332,
      "e": 43157,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51443,
      "e": 43268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 51443,
      "e": 43268,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 51443,
      "e": 43268,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51523,
      "e": 43348,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 51523,
      "e": 43348,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51547,
      "e": 43372,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ir"
    },
    {
      "t": 51579,
      "e": 43404,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 51579,
      "e": 43404,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51610,
      "e": 43435,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 51659,
      "e": 43484,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51747,
      "e": 43572,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 51747,
      "e": 43572,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51827,
      "e": 43652,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 51932,
      "e": 43757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 51932,
      "e": 43757,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51978,
      "e": 43803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 51986,
      "e": 43811,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 51986,
      "e": 43811,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52058,
      "e": 43883,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 52059,
      "e": 43884,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52091,
      "e": 43916,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ly"
    },
    {
      "t": 52138,
      "e": 43963,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52146,
      "e": 43971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52147,
      "e": 43972,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52266,
      "e": 44091,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 52643,
      "e": 44468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 52644,
      "e": 44469,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52707,
      "e": 44532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 52786,
      "e": 44611,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 52787,
      "e": 44612,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52875,
      "e": 44700,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 52876,
      "e": 44701,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52890,
      "e": 44715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 52923,
      "e": 44748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52978,
      "e": 44803,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 52978,
      "e": 44803,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53074,
      "e": 44899,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 53106,
      "e": 44931,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 53108,
      "e": 44933,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53162,
      "e": 44987,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 53219,
      "e": 45044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 53219,
      "e": 45044,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53323,
      "e": 45148,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 53323,
      "e": 45148,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 53323,
      "e": 45148,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53379,
      "e": 45204,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 53379,
      "e": 45204,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53419,
      "e": 45244,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||le"
    },
    {
      "t": 53483,
      "e": 45308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53483,
      "e": 45308,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53498,
      "e": 45323,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53606,
      "e": 45431,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that have a dot that is directly verticle "
    },
    {
      "t": 53650,
      "e": 45475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54019,
      "e": 45844,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 54082,
      "e": 45907,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that have a dot that is directly verticle"
    },
    {
      "t": 54187,
      "e": 46012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 54258,
      "e": 46083,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that have a dot that is directly verticl"
    },
    {
      "t": 54363,
      "e": 46188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 54442,
      "e": 46267,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that have a dot that is directly vertic"
    },
    {
      "t": 54939,
      "e": 46764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 54940,
      "e": 46765,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55034,
      "e": 46859,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 55034,
      "e": 46859,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55074,
      "e": 46899,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||al"
    },
    {
      "t": 55123,
      "e": 46948,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 55467,
      "e": 47292,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55468,
      "e": 47293,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55595,
      "e": 47420,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55827,
      "e": 47652,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 55828,
      "e": 47653,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55924,
      "e": 47749,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 55925,
      "e": 47750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55947,
      "e": 47751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 55986,
      "e": 47790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55986,
      "e": 47790,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56026,
      "e": 47830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 56122,
      "e": 47926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57274,
      "e": 49078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 57274,
      "e": 49078,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57362,
      "e": 49166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 57362,
      "e": 49166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57370,
      "e": 49174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 57451,
      "e": 49255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 57451,
      "e": 49255,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57474,
      "e": 49278,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 57539,
      "e": 49343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57540,
      "e": 49344,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57570,
      "e": 49374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57667,
      "e": 49471,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57971,
      "e": 49775,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 57972,
      "e": 49776,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58051,
      "e": 49855,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 58051,
      "e": 49855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58090,
      "e": 49894,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 58203,
      "e": 50007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58259,
      "e": 50063,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 58260,
      "e": 50064,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58403,
      "e": 50207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 59171,
      "e": 50975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59419,
      "e": 51223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 59419,
      "e": 51223,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59474,
      "e": 51278,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 59606,
      "e": 51410,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that have a dot that is directly vertical to the 12 M"
    },
    {
      "t": 59755,
      "e": 51559,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 60010,
      "e": 51814,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 60075,
      "e": 51879,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that have a dot that is directly vertical to the 12 "
    },
    {
      "t": 60155,
      "e": 51959,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 60250,
      "e": 52054,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that have a dot that is directly vertical to the 12"
    },
    {
      "t": 61260,
      "e": 53064,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 61260,
      "e": 53064,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61346,
      "e": 53150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 61346,
      "e": 53150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61370,
      "e": 53174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 61451,
      "e": 53255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 61459,
      "e": 53263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 61459,
      "e": 53263,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61562,
      "e": 53366,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 61562,
      "e": 53366,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61570,
      "e": 53374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| m"
    },
    {
      "t": 61634,
      "e": 53438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 61643,
      "e": 53447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 61643,
      "e": 53447,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61715,
      "e": 53519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 61715,
      "e": 53519,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61778,
      "e": 53582,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 61810,
      "e": 53614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 61810,
      "e": 53614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61834,
      "e": 53638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 61867,
      "e": 53671,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 61955,
      "e": 53759,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 61955,
      "e": 53759,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62098,
      "e": 53902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 63003,
      "e": 54807,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 63162,
      "e": 54966,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that have a dot that is directly vertical to the 12pm mark"
    },
    {
      "t": 64090,
      "e": 55894,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 64091,
      "e": 55895,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64162,
      "e": 55966,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 65005,
      "e": 56809,
      "ty": 2,
      "x": 1200,
      "y": 607
    },
    {
      "t": 65005,
      "e": 56809,
      "ty": 41,
      "x": 29174,
      "y": 37387,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 65105,
      "e": 56909,
      "ty": 2,
      "x": 1221,
      "y": 593
    },
    {
      "t": 65256,
      "e": 57060,
      "ty": 41,
      "x": 30654,
      "y": 36384,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 65405,
      "e": 57209,
      "ty": 2,
      "x": 1227,
      "y": 592
    },
    {
      "t": 65505,
      "e": 57309,
      "ty": 2,
      "x": 1513,
      "y": 551
    },
    {
      "t": 65505,
      "e": 57309,
      "ty": 41,
      "x": 51231,
      "y": 33376,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 65605,
      "e": 57409,
      "ty": 2,
      "x": 1641,
      "y": 507
    },
    {
      "t": 65705,
      "e": 57509,
      "ty": 2,
      "x": 1919,
      "y": 435
    },
    {
      "t": 66004,
      "e": 57808,
      "ty": 2,
      "x": 1406,
      "y": 459
    },
    {
      "t": 66005,
      "e": 57809,
      "ty": 41,
      "x": 43691,
      "y": 26786,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 66105,
      "e": 57909,
      "ty": 2,
      "x": 747,
      "y": 513
    },
    {
      "t": 66148,
      "e": 57952,
      "ty": 6,
      "x": 640,
      "y": 542,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66165,
      "e": 57969,
      "ty": 7,
      "x": 591,
      "y": 563,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66204,
      "e": 58008,
      "ty": 2,
      "x": 496,
      "y": 605
    },
    {
      "t": 66215,
      "e": 58019,
      "ty": 6,
      "x": 420,
      "y": 623,
      "ta": "#strategyButton"
    },
    {
      "t": 66255,
      "e": 58059,
      "ty": 41,
      "x": 25343,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 66305,
      "e": 58109,
      "ty": 2,
      "x": 385,
      "y": 629
    },
    {
      "t": 66455,
      "e": 58259,
      "ty": 3,
      "x": 385,
      "y": 629,
      "ta": "#strategyButton"
    },
    {
      "t": 66457,
      "e": 58261,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that have a dot that is directly vertical to the 12pm mark."
    },
    {
      "t": 66460,
      "e": 58264,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66460,
      "e": 58264,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 66574,
      "e": 58378,
      "ty": 4,
      "x": 25343,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 66585,
      "e": 58389,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 66586,
      "e": 58390,
      "ty": 5,
      "x": 385,
      "y": 629,
      "ta": "#strategyButton"
    },
    {
      "t": 66591,
      "e": 58395,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 67592,
      "e": 59396,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 68104,
      "e": 59908,
      "ty": 2,
      "x": 414,
      "y": 619
    },
    {
      "t": 68200,
      "e": 59908,
      "ty": 6,
      "x": 1003,
      "y": 518,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 68204,
      "e": 59912,
      "ty": 2,
      "x": 1003,
      "y": 518
    },
    {
      "t": 68254,
      "e": 59962,
      "ty": 41,
      "x": 51692,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 68304,
      "e": 60012,
      "ty": 2,
      "x": 1050,
      "y": 513
    },
    {
      "t": 68404,
      "e": 60112,
      "ty": 2,
      "x": 1058,
      "y": 503
    },
    {
      "t": 68505,
      "e": 60213,
      "ty": 41,
      "x": 54071,
      "y": 6241,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 68655,
      "e": 60363,
      "ty": 3,
      "x": 1058,
      "y": 503,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 68656,
      "e": 60364,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 68798,
      "e": 60506,
      "ty": 4,
      "x": 54071,
      "y": 6241,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 68798,
      "e": 60506,
      "ty": 5,
      "x": 1058,
      "y": 503,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 69427,
      "e": 61135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 69427,
      "e": 61135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 69489,
      "e": 61197,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 69608,
      "e": 61316,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 69666,
      "e": 61374,
      "ty": 7,
      "x": 1053,
      "y": 522,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 69704,
      "e": 61412,
      "ty": 2,
      "x": 1052,
      "y": 530
    },
    {
      "t": 69723,
      "e": 61431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 69723,
      "e": 61431,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 69755,
      "e": 61463,
      "ty": 41,
      "x": 52774,
      "y": 2818,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 69786,
      "e": 61494,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 69804,
      "e": 61512,
      "ty": 2,
      "x": 1052,
      "y": 537
    },
    {
      "t": 69904,
      "e": 61612,
      "ty": 2,
      "x": 1049,
      "y": 551
    },
    {
      "t": 70004,
      "e": 61712,
      "ty": 2,
      "x": 1027,
      "y": 593
    },
    {
      "t": 70005,
      "e": 61713,
      "ty": 41,
      "x": 47366,
      "y": 44394,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 70018,
      "e": 61726,
      "ty": 6,
      "x": 1026,
      "y": 594,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70104,
      "e": 61812,
      "ty": 2,
      "x": 1026,
      "y": 597
    },
    {
      "t": 70111,
      "e": 61819,
      "ty": 3,
      "x": 1025,
      "y": 600,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70113,
      "e": 61821,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 70114,
      "e": 61822,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70114,
      "e": 61822,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70204,
      "e": 61912,
      "ty": 2,
      "x": 1024,
      "y": 605
    },
    {
      "t": 70238,
      "e": 61946,
      "ty": 4,
      "x": 46718,
      "y": 34327,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70239,
      "e": 61947,
      "ty": 5,
      "x": 1024,
      "y": 605,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70254,
      "e": 61962,
      "ty": 41,
      "x": 46718,
      "y": 34327,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 71364,
      "e": 63072,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 71539,
      "e": 63247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 71539,
      "e": 63247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 71658,
      "e": 63366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 71682,
      "e": 63390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 71683,
      "e": 63391,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 71754,
      "e": 63462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 71755,
      "e": 63463,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 71794,
      "e": 63502,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 71866,
      "e": 63574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 71915,
      "e": 63623,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 72669,
      "e": 64377,
      "ty": 7,
      "x": 1022,
      "y": 618,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 72686,
      "e": 64394,
      "ty": 6,
      "x": 1019,
      "y": 626,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 72704,
      "e": 64412,
      "ty": 2,
      "x": 1014,
      "y": 639
    },
    {
      "t": 72755,
      "e": 64463,
      "ty": 41,
      "x": 58794,
      "y": 39718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 72804,
      "e": 64512,
      "ty": 2,
      "x": 1009,
      "y": 644
    },
    {
      "t": 72905,
      "e": 64613,
      "ty": 2,
      "x": 1008,
      "y": 644
    },
    {
      "t": 73005,
      "e": 64713,
      "ty": 41,
      "x": 57763,
      "y": 41704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 73159,
      "e": 64867,
      "ty": 3,
      "x": 1008,
      "y": 644,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 73160,
      "e": 64868,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 73161,
      "e": 64869,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 73161,
      "e": 64869,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 73254,
      "e": 64962,
      "ty": 4,
      "x": 57763,
      "y": 41704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 73254,
      "e": 64962,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 73255,
      "e": 64963,
      "ty": 5,
      "x": 1008,
      "y": 644,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 73255,
      "e": 64963,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 73754,
      "e": 65462,
      "ty": 41,
      "x": 34437,
      "y": 38943,
      "ta": "html > body"
    },
    {
      "t": 73804,
      "e": 65512,
      "ty": 2,
      "x": 1020,
      "y": 674
    },
    {
      "t": 73904,
      "e": 65612,
      "ty": 2,
      "x": 1026,
      "y": 720
    },
    {
      "t": 74005,
      "e": 65713,
      "ty": 2,
      "x": 1022,
      "y": 727
    },
    {
      "t": 74005,
      "e": 65713,
      "ty": 41,
      "x": 34919,
      "y": 43750,
      "ta": "html > body"
    },
    {
      "t": 74104,
      "e": 65812,
      "ty": 2,
      "x": 926,
      "y": 693
    },
    {
      "t": 74204,
      "e": 65912,
      "ty": 2,
      "x": 848,
      "y": 623
    },
    {
      "t": 74254,
      "e": 65962,
      "ty": 41,
      "x": 28927,
      "y": 37422,
      "ta": "html > body"
    },
    {
      "t": 74272,
      "e": 65980,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 74304,
      "e": 66012,
      "ty": 2,
      "x": 851,
      "y": 622
    },
    {
      "t": 74404,
      "e": 66112,
      "ty": 2,
      "x": 851,
      "y": 621
    },
    {
      "t": 74505,
      "e": 66213,
      "ty": 41,
      "x": 7941,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 74755,
      "e": 66463,
      "ty": 41,
      "x": 8478,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 74804,
      "e": 66512,
      "ty": 2,
      "x": 853,
      "y": 620
    },
    {
      "t": 74904,
      "e": 66612,
      "ty": 2,
      "x": 860,
      "y": 365
    },
    {
      "t": 75005,
      "e": 66713,
      "ty": 2,
      "x": 860,
      "y": 216
    },
    {
      "t": 75005,
      "e": 66713,
      "ty": 41,
      "x": 29381,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 75105,
      "e": 66813,
      "ty": 2,
      "x": 863,
      "y": 185
    },
    {
      "t": 75204,
      "e": 66912,
      "ty": 2,
      "x": 863,
      "y": 184
    },
    {
      "t": 75255,
      "e": 66963,
      "ty": 41,
      "x": 29133,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 75304,
      "e": 67012,
      "ty": 2,
      "x": 847,
      "y": 184
    },
    {
      "t": 75338,
      "e": 67046,
      "ty": 6,
      "x": 838,
      "y": 184,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 75404,
      "e": 67112,
      "ty": 2,
      "x": 836,
      "y": 184
    },
    {
      "t": 75448,
      "e": 67113,
      "ty": 3,
      "x": 836,
      "y": 184,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 75449,
      "e": 67114,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 75505,
      "e": 67170,
      "ty": 41,
      "x": 48284,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 75558,
      "e": 67223,
      "ty": 4,
      "x": 48284,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 75560,
      "e": 67225,
      "ty": 5,
      "x": 836,
      "y": 184,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 75561,
      "e": 67226,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 75855,
      "e": 67520,
      "ty": 7,
      "x": 835,
      "y": 207,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 75855,
      "e": 67520,
      "ty": 6,
      "x": 835,
      "y": 207,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 75872,
      "e": 67537,
      "ty": 7,
      "x": 833,
      "y": 230,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 75904,
      "e": 67569,
      "ty": 2,
      "x": 830,
      "y": 255
    },
    {
      "t": 76005,
      "e": 67670,
      "ty": 2,
      "x": 830,
      "y": 345
    },
    {
      "t": 76005,
      "e": 67670,
      "ty": 41,
      "x": 2035,
      "y": 11644,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 76072,
      "e": 67737,
      "ty": 6,
      "x": 831,
      "y": 355,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 76105,
      "e": 67770,
      "ty": 2,
      "x": 831,
      "y": 357
    },
    {
      "t": 76205,
      "e": 67870,
      "ty": 2,
      "x": 830,
      "y": 362
    },
    {
      "t": 76255,
      "e": 67920,
      "ty": 41,
      "x": 18037,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 76574,
      "e": 68239,
      "ty": 7,
      "x": 830,
      "y": 372,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 76589,
      "e": 68254,
      "ty": 6,
      "x": 831,
      "y": 392,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 76604,
      "e": 68269,
      "ty": 2,
      "x": 831,
      "y": 392
    },
    {
      "t": 76605,
      "e": 68270,
      "ty": 7,
      "x": 834,
      "y": 414,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 76606,
      "e": 68271,
      "ty": 6,
      "x": 834,
      "y": 414,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 76622,
      "e": 68287,
      "ty": 7,
      "x": 837,
      "y": 435,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 76639,
      "e": 68304,
      "ty": 6,
      "x": 838,
      "y": 448,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 76655,
      "e": 68320,
      "ty": 7,
      "x": 838,
      "y": 456,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 76704,
      "e": 68369,
      "ty": 2,
      "x": 838,
      "y": 464
    },
    {
      "t": 76705,
      "e": 68370,
      "ty": 6,
      "x": 838,
      "y": 467,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 76755,
      "e": 68420,
      "ty": 41,
      "x": 58367,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 76773,
      "e": 68438,
      "ty": 7,
      "x": 838,
      "y": 481,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 76804,
      "e": 68469,
      "ty": 2,
      "x": 838,
      "y": 484
    },
    {
      "t": 76839,
      "e": 68504,
      "ty": 6,
      "x": 838,
      "y": 499,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 76872,
      "e": 68537,
      "ty": 7,
      "x": 839,
      "y": 511,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 76904,
      "e": 68569,
      "ty": 2,
      "x": 840,
      "y": 522
    },
    {
      "t": 77005,
      "e": 68670,
      "ty": 2,
      "x": 845,
      "y": 550
    },
    {
      "t": 77005,
      "e": 68670,
      "ty": 41,
      "x": 5595,
      "y": 33029,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 77104,
      "e": 68769,
      "ty": 2,
      "x": 846,
      "y": 551
    },
    {
      "t": 77204,
      "e": 68869,
      "ty": 2,
      "x": 848,
      "y": 550
    },
    {
      "t": 77255,
      "e": 68920,
      "ty": 41,
      "x": 24399,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-6 > label"
    },
    {
      "t": 77304,
      "e": 68969,
      "ty": 2,
      "x": 845,
      "y": 532
    },
    {
      "t": 77404,
      "e": 69069,
      "ty": 2,
      "x": 844,
      "y": 525
    },
    {
      "t": 77505,
      "e": 69070,
      "ty": 2,
      "x": 842,
      "y": 521
    },
    {
      "t": 77506,
      "e": 69071,
      "ty": 41,
      "x": 20428,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-6 > label"
    },
    {
      "t": 77604,
      "e": 69169,
      "ty": 2,
      "x": 842,
      "y": 520
    },
    {
      "t": 77754,
      "e": 69319,
      "ty": 41,
      "x": 20428,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-6 > label"
    },
    {
      "t": 77905,
      "e": 69470,
      "ty": 2,
      "x": 834,
      "y": 515
    },
    {
      "t": 78004,
      "e": 69569,
      "ty": 2,
      "x": 822,
      "y": 490
    },
    {
      "t": 78004,
      "e": 69569,
      "ty": 41,
      "x": 137,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-5"
    },
    {
      "t": 78104,
      "e": 69669,
      "ty": 2,
      "x": 821,
      "y": 474
    },
    {
      "t": 78204,
      "e": 69769,
      "ty": 2,
      "x": 823,
      "y": 425
    },
    {
      "t": 78255,
      "e": 69820,
      "ty": 41,
      "x": 1668,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 78304,
      "e": 69869,
      "ty": 2,
      "x": 823,
      "y": 415
    },
    {
      "t": 78405,
      "e": 69970,
      "ty": 2,
      "x": 823,
      "y": 378
    },
    {
      "t": 78505,
      "e": 70070,
      "ty": 2,
      "x": 824,
      "y": 373
    },
    {
      "t": 78505,
      "e": 70070,
      "ty": 41,
      "x": 611,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 78573,
      "e": 70138,
      "ty": 6,
      "x": 827,
      "y": 367,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 78604,
      "e": 70169,
      "ty": 2,
      "x": 830,
      "y": 362
    },
    {
      "t": 78705,
      "e": 70270,
      "ty": 2,
      "x": 832,
      "y": 357
    },
    {
      "t": 78711,
      "e": 70276,
      "ty": 3,
      "x": 832,
      "y": 357,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 78711,
      "e": 70276,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 78711,
      "e": 70276,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 78754,
      "e": 70319,
      "ty": 41,
      "x": 28120,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 78807,
      "e": 70372,
      "ty": 4,
      "x": 28120,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 78808,
      "e": 70373,
      "ty": 5,
      "x": 832,
      "y": 357,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 78808,
      "e": 70373,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 79404,
      "e": 70969,
      "ty": 2,
      "x": 832,
      "y": 365
    },
    {
      "t": 79425,
      "e": 70990,
      "ty": 7,
      "x": 832,
      "y": 371,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 79504,
      "e": 71069,
      "ty": 2,
      "x": 832,
      "y": 426
    },
    {
      "t": 79504,
      "e": 71069,
      "ty": 41,
      "x": 11181,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 79508,
      "e": 71073,
      "ty": 6,
      "x": 832,
      "y": 442,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 79525,
      "e": 71090,
      "ty": 7,
      "x": 832,
      "y": 459,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 79540,
      "e": 71105,
      "ty": 6,
      "x": 832,
      "y": 467,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 79558,
      "e": 71123,
      "ty": 7,
      "x": 832,
      "y": 492,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 79591,
      "e": 71156,
      "ty": 6,
      "x": 832,
      "y": 528,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 79604,
      "e": 71169,
      "ty": 2,
      "x": 832,
      "y": 528
    },
    {
      "t": 79625,
      "e": 71190,
      "ty": 7,
      "x": 830,
      "y": 547,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 79705,
      "e": 71270,
      "ty": 2,
      "x": 836,
      "y": 612
    },
    {
      "t": 79708,
      "e": 71273,
      "ty": 6,
      "x": 837,
      "y": 625,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 79725,
      "e": 71290,
      "ty": 7,
      "x": 840,
      "y": 640,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 79754,
      "e": 71319,
      "ty": 41,
      "x": 4883,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 79804,
      "e": 71369,
      "ty": 2,
      "x": 846,
      "y": 682
    },
    {
      "t": 79905,
      "e": 71470,
      "ty": 2,
      "x": 856,
      "y": 726
    },
    {
      "t": 80005,
      "e": 71570,
      "ty": 2,
      "x": 860,
      "y": 728
    },
    {
      "t": 80005,
      "e": 71570,
      "ty": 41,
      "x": 21597,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 80104,
      "e": 71669,
      "ty": 2,
      "x": 855,
      "y": 695
    },
    {
      "t": 80204,
      "e": 71769,
      "ty": 2,
      "x": 845,
      "y": 668
    },
    {
      "t": 80255,
      "e": 71820,
      "ty": 41,
      "x": 4933,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 80275,
      "e": 71840,
      "ty": 6,
      "x": 839,
      "y": 646,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 80304,
      "e": 71869,
      "ty": 2,
      "x": 838,
      "y": 644
    },
    {
      "t": 80405,
      "e": 71970,
      "ty": 2,
      "x": 838,
      "y": 643
    },
    {
      "t": 80505,
      "e": 72070,
      "ty": 41,
      "x": 58367,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 80543,
      "e": 72108,
      "ty": 7,
      "x": 835,
      "y": 670,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 80560,
      "e": 72109,
      "ty": 6,
      "x": 835,
      "y": 676,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 80604,
      "e": 72153,
      "ty": 2,
      "x": 834,
      "y": 679
    },
    {
      "t": 80676,
      "e": 72225,
      "ty": 7,
      "x": 830,
      "y": 684,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 80704,
      "e": 72253,
      "ty": 2,
      "x": 829,
      "y": 684
    },
    {
      "t": 80755,
      "e": 72304,
      "ty": 41,
      "x": 1902,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 80767,
      "e": 72316,
      "ty": 3,
      "x": 829,
      "y": 687,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 80767,
      "e": 72316,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 80804,
      "e": 72353,
      "ty": 2,
      "x": 829,
      "y": 687
    },
    {
      "t": 80854,
      "e": 72403,
      "ty": 4,
      "x": 1902,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 80854,
      "e": 72403,
      "ty": 5,
      "x": 829,
      "y": 687,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 80854,
      "e": 72403,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 80854,
      "e": 72403,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 81255,
      "e": 72804,
      "ty": 41,
      "x": 2152,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 81305,
      "e": 72854,
      "ty": 2,
      "x": 831,
      "y": 685
    },
    {
      "t": 81506,
      "e": 73055,
      "ty": 41,
      "x": 2403,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 82205,
      "e": 73754,
      "ty": 2,
      "x": 878,
      "y": 704
    },
    {
      "t": 82254,
      "e": 73803,
      "ty": 41,
      "x": 27904,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 82305,
      "e": 73854,
      "ty": 2,
      "x": 967,
      "y": 756
    },
    {
      "t": 82405,
      "e": 73954,
      "ty": 2,
      "x": 1007,
      "y": 797
    },
    {
      "t": 82505,
      "e": 74054,
      "ty": 2,
      "x": 1001,
      "y": 828
    },
    {
      "t": 82505,
      "e": 74054,
      "ty": 41,
      "x": 42618,
      "y": 14043,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 82605,
      "e": 74154,
      "ty": 2,
      "x": 957,
      "y": 872
    },
    {
      "t": 82705,
      "e": 74254,
      "ty": 2,
      "x": 904,
      "y": 886
    },
    {
      "t": 82755,
      "e": 74304,
      "ty": 41,
      "x": 15325,
      "y": 25745,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 82804,
      "e": 74353,
      "ty": 2,
      "x": 861,
      "y": 868
    },
    {
      "t": 82905,
      "e": 74454,
      "ty": 2,
      "x": 860,
      "y": 868
    },
    {
      "t": 83004,
      "e": 74553,
      "ty": 2,
      "x": 858,
      "y": 868
    },
    {
      "t": 83005,
      "e": 74554,
      "ty": 41,
      "x": 8680,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 83104,
      "e": 74653,
      "ty": 2,
      "x": 849,
      "y": 872
    },
    {
      "t": 83199,
      "e": 74748,
      "ty": 3,
      "x": 841,
      "y": 875,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 83201,
      "e": 74750,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 83205,
      "e": 74754,
      "ty": 2,
      "x": 841,
      "y": 875
    },
    {
      "t": 83255,
      "e": 74804,
      "ty": 41,
      "x": 21384,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 83286,
      "e": 74835,
      "ty": 6,
      "x": 839,
      "y": 878,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 83287,
      "e": 74836,
      "ty": 4,
      "x": 63408,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 83305,
      "e": 74854,
      "ty": 2,
      "x": 839,
      "y": 879
    },
    {
      "t": 83405,
      "e": 74954,
      "ty": 2,
      "x": 838,
      "y": 880
    },
    {
      "t": 83504,
      "e": 75053,
      "ty": 2,
      "x": 838,
      "y": 881
    },
    {
      "t": 83505,
      "e": 75054,
      "ty": 41,
      "x": 58367,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 83595,
      "e": 75144,
      "ty": 7,
      "x": 837,
      "y": 889,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 83604,
      "e": 75153,
      "ty": 2,
      "x": 837,
      "y": 889
    },
    {
      "t": 83704,
      "e": 75253,
      "ty": 2,
      "x": 845,
      "y": 923
    },
    {
      "t": 83754,
      "e": 75303,
      "ty": 41,
      "x": 5832,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 83805,
      "e": 75354,
      "ty": 2,
      "x": 844,
      "y": 897
    },
    {
      "t": 83862,
      "e": 75411,
      "ty": 6,
      "x": 839,
      "y": 887,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 83904,
      "e": 75453,
      "ty": 2,
      "x": 839,
      "y": 886
    },
    {
      "t": 84005,
      "e": 75554,
      "ty": 2,
      "x": 838,
      "y": 885
    },
    {
      "t": 84005,
      "e": 75554,
      "ty": 41,
      "x": 58367,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 84039,
      "e": 75588,
      "ty": 3,
      "x": 838,
      "y": 885,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 84040,
      "e": 75589,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 84126,
      "e": 75675,
      "ty": 4,
      "x": 58367,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 84126,
      "e": 75675,
      "ty": 5,
      "x": 838,
      "y": 885,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 84126,
      "e": 75675,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 84463,
      "e": 76012,
      "ty": 7,
      "x": 842,
      "y": 888,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 84505,
      "e": 76054,
      "ty": 2,
      "x": 853,
      "y": 909
    },
    {
      "t": 84505,
      "e": 76054,
      "ty": 41,
      "x": 25544,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 84605,
      "e": 76154,
      "ty": 2,
      "x": 868,
      "y": 940
    },
    {
      "t": 84631,
      "e": 76155,
      "ty": 6,
      "x": 874,
      "y": 952,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 84705,
      "e": 76229,
      "ty": 2,
      "x": 881,
      "y": 967
    },
    {
      "t": 84755,
      "e": 76279,
      "ty": 41,
      "x": 29675,
      "y": 43690,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 84805,
      "e": 76329,
      "ty": 2,
      "x": 888,
      "y": 976
    },
    {
      "t": 84905,
      "e": 76429,
      "ty": 2,
      "x": 888,
      "y": 977
    },
    {
      "t": 85005,
      "e": 76529,
      "ty": 41,
      "x": 30190,
      "y": 49647,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 85351,
      "e": 76875,
      "ty": 3,
      "x": 888,
      "y": 977,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 85352,
      "e": 76876,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 85353,
      "e": 76877,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 85397,
      "e": 76921,
      "ty": 4,
      "x": 30190,
      "y": 49647,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 85398,
      "e": 76922,
      "ty": 5,
      "x": 888,
      "y": 977,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 85399,
      "e": 76923,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 85401,
      "e": 76925,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 85401,
      "e": 76925,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 86733,
      "e": 78257,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 87705,
      "e": 79229,
      "ty": 2,
      "x": 887,
      "y": 978
    },
    {
      "t": 87756,
      "e": 79280,
      "ty": 41,
      "x": 30270,
      "y": 59084,
      "ta": "> div.masterdiv"
    },
    {
      "t": 87805,
      "e": 79329,
      "ty": 2,
      "x": 886,
      "y": 979
    },
    {
      "t": 87905,
      "e": 79429,
      "ty": 2,
      "x": 885,
      "y": 979
    },
    {
      "t": 88005,
      "e": 79529,
      "ty": 41,
      "x": 30201,
      "y": 59084,
      "ta": "> div.masterdiv"
    },
    {
      "t": 88504,
      "e": 80028,
      "ty": 2,
      "x": 858,
      "y": 975
    },
    {
      "t": 88506,
      "e": 80030,
      "ty": 41,
      "x": 27774,
      "y": 65360,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 88605,
      "e": 80129,
      "ty": 2,
      "x": 836,
      "y": 967
    },
    {
      "t": 88705,
      "e": 80229,
      "ty": 2,
      "x": 832,
      "y": 967
    },
    {
      "t": 88756,
      "e": 80280,
      "ty": 41,
      "x": 26494,
      "y": 64751,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 90005,
      "e": 81529,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 91005,
      "e": 82529,
      "ty": 2,
      "x": 795,
      "y": 951
    },
    {
      "t": 91005,
      "e": 82529,
      "ty": 41,
      "x": 24674,
      "y": 63534,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 91105,
      "e": 82629,
      "ty": 2,
      "x": 775,
      "y": 942
    },
    {
      "t": 91205,
      "e": 82729,
      "ty": 2,
      "x": 766,
      "y": 937
    },
    {
      "t": 91256,
      "e": 82780,
      "ty": 41,
      "x": 23247,
      "y": 62469,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 91305,
      "e": 82829,
      "ty": 2,
      "x": 765,
      "y": 937
    },
    {
      "t": 91506,
      "e": 83030,
      "ty": 41,
      "x": 23198,
      "y": 62469,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 93104,
      "e": 84628,
      "ty": 2,
      "x": 764,
      "y": 936
    },
    {
      "t": 93204,
      "e": 84728,
      "ty": 2,
      "x": 741,
      "y": 920
    },
    {
      "t": 93256,
      "e": 84780,
      "ty": 41,
      "x": 21034,
      "y": 60264,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 93305,
      "e": 84829,
      "ty": 2,
      "x": 711,
      "y": 893
    },
    {
      "t": 93405,
      "e": 84929,
      "ty": 2,
      "x": 650,
      "y": 713
    },
    {
      "t": 93504,
      "e": 85028,
      "ty": 2,
      "x": 597,
      "y": 478
    },
    {
      "t": 93504,
      "e": 85028,
      "ty": 41,
      "x": 14933,
      "y": 18919,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 93604,
      "e": 85128,
      "ty": 2,
      "x": 592,
      "y": 418
    },
    {
      "t": 93705,
      "e": 85229,
      "ty": 2,
      "x": 592,
      "y": 413
    },
    {
      "t": 93755,
      "e": 85279,
      "ty": 41,
      "x": 14687,
      "y": 15225,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 95305,
      "e": 86829,
      "ty": 2,
      "x": 591,
      "y": 413
    },
    {
      "t": 95404,
      "e": 86928,
      "ty": 2,
      "x": 583,
      "y": 433
    },
    {
      "t": 95504,
      "e": 87028,
      "ty": 2,
      "x": 577,
      "y": 445
    },
    {
      "t": 95505,
      "e": 87029,
      "ty": 41,
      "x": 13949,
      "y": 6046,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 95604,
      "e": 87128,
      "ty": 2,
      "x": 570,
      "y": 455
    },
    {
      "t": 95704,
      "e": 87228,
      "ty": 2,
      "x": 566,
      "y": 462
    },
    {
      "t": 95755,
      "e": 87279,
      "ty": 41,
      "x": 13260,
      "y": 14628,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 95805,
      "e": 87329,
      "ty": 2,
      "x": 563,
      "y": 468
    },
    {
      "t": 95904,
      "e": 87428,
      "ty": 2,
      "x": 563,
      "y": 469
    },
    {
      "t": 96004,
      "e": 87528,
      "ty": 2,
      "x": 561,
      "y": 470
    },
    {
      "t": 96005,
      "e": 87529,
      "ty": 41,
      "x": 13162,
      "y": 15798,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 96105,
      "e": 87629,
      "ty": 2,
      "x": 578,
      "y": 476
    },
    {
      "t": 96204,
      "e": 87728,
      "ty": 2,
      "x": 629,
      "y": 476
    },
    {
      "t": 96255,
      "e": 87779,
      "ty": 41,
      "x": 18426,
      "y": 17358,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 96305,
      "e": 87829,
      "ty": 2,
      "x": 760,
      "y": 473
    },
    {
      "t": 96404,
      "e": 87928,
      "ty": 2,
      "x": 851,
      "y": 469
    },
    {
      "t": 96504,
      "e": 88028,
      "ty": 2,
      "x": 951,
      "y": 468
    },
    {
      "t": 96504,
      "e": 88028,
      "ty": 41,
      "x": 32349,
      "y": 15018,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 96604,
      "e": 88128,
      "ty": 2,
      "x": 1020,
      "y": 457
    },
    {
      "t": 96704,
      "e": 88228,
      "ty": 2,
      "x": 1043,
      "y": 454
    },
    {
      "t": 96755,
      "e": 88279,
      "ty": 41,
      "x": 36924,
      "y": 9557,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 96805,
      "e": 88329,
      "ty": 2,
      "x": 1044,
      "y": 454
    },
    {
      "t": 97504,
      "e": 89028,
      "ty": 2,
      "x": 1038,
      "y": 451
    },
    {
      "t": 97505,
      "e": 89029,
      "ty": 41,
      "x": 36629,
      "y": 8386,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 97604,
      "e": 89128,
      "ty": 2,
      "x": 881,
      "y": 429
    },
    {
      "t": 97704,
      "e": 89228,
      "ty": 2,
      "x": 823,
      "y": 428
    },
    {
      "t": 97755,
      "e": 89279,
      "ty": 41,
      "x": 24379,
      "y": 4486,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 97804,
      "e": 89328,
      "ty": 2,
      "x": 744,
      "y": 464
    },
    {
      "t": 97904,
      "e": 89428,
      "ty": 2,
      "x": 675,
      "y": 529
    },
    {
      "t": 98005,
      "e": 89529,
      "ty": 2,
      "x": 643,
      "y": 587
    },
    {
      "t": 98005,
      "e": 89529,
      "ty": 41,
      "x": 17196,
      "y": 61439,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 98104,
      "e": 89628,
      "ty": 2,
      "x": 626,
      "y": 642
    },
    {
      "t": 98204,
      "e": 89728,
      "ty": 2,
      "x": 629,
      "y": 655
    },
    {
      "t": 98254,
      "e": 89778,
      "ty": 41,
      "x": 17590,
      "y": 39496,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 98304,
      "e": 89828,
      "ty": 2,
      "x": 672,
      "y": 697
    },
    {
      "t": 98405,
      "e": 89929,
      "ty": 2,
      "x": 674,
      "y": 700
    },
    {
      "t": 98505,
      "e": 90029,
      "ty": 41,
      "x": 18721,
      "y": 49443,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 99304,
      "e": 90828,
      "ty": 2,
      "x": 678,
      "y": 700
    },
    {
      "t": 99405,
      "e": 90929,
      "ty": 2,
      "x": 774,
      "y": 686
    },
    {
      "t": 99504,
      "e": 91028,
      "ty": 2,
      "x": 992,
      "y": 714
    },
    {
      "t": 99505,
      "e": 91029,
      "ty": 41,
      "x": 34366,
      "y": 57635,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 99604,
      "e": 91128,
      "ty": 2,
      "x": 1009,
      "y": 726
    },
    {
      "t": 99705,
      "e": 91229,
      "ty": 2,
      "x": 1021,
      "y": 741
    },
    {
      "t": 99755,
      "e": 91279,
      "ty": 41,
      "x": 36186,
      "y": 15798,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 99804,
      "e": 91328,
      "ty": 2,
      "x": 1039,
      "y": 798
    },
    {
      "t": 99905,
      "e": 91429,
      "ty": 2,
      "x": 1044,
      "y": 871
    },
    {
      "t": 100004,
      "e": 91528,
      "ty": 2,
      "x": 1026,
      "y": 952
    },
    {
      "t": 100004,
      "e": 91528,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 100006,
      "e": 91530,
      "ty": 41,
      "x": 36039,
      "y": 63610,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 100040,
      "e": 91564,
      "ty": 6,
      "x": 1016,
      "y": 978,
      "ta": "#start"
    },
    {
      "t": 100104,
      "e": 91628,
      "ty": 2,
      "x": 1010,
      "y": 990
    },
    {
      "t": 100204,
      "e": 91728,
      "ty": 2,
      "x": 990,
      "y": 1000
    },
    {
      "t": 100254,
      "e": 91778,
      "ty": 41,
      "x": 41778,
      "y": 47615,
      "ta": "#start"
    },
    {
      "t": 100304,
      "e": 91828,
      "ty": 2,
      "x": 986,
      "y": 1002
    },
    {
      "t": 100383,
      "e": 91907,
      "ty": 3,
      "x": 986,
      "y": 1002,
      "ta": "#start"
    },
    {
      "t": 100385,
      "e": 91909,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 100453,
      "e": 91977,
      "ty": 4,
      "x": 41778,
      "y": 47615,
      "ta": "#start"
    },
    {
      "t": 100453,
      "e": 91977,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 100454,
      "e": 91978,
      "ty": 5,
      "x": 986,
      "y": 1002,
      "ta": "#start"
    },
    {
      "t": 100454,
      "e": 91978,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 100605,
      "e": 92129,
      "ty": 2,
      "x": 992,
      "y": 995
    },
    {
      "t": 100704,
      "e": 92228,
      "ty": 2,
      "x": 1083,
      "y": 905
    },
    {
      "t": 100755,
      "e": 92279,
      "ty": 41,
      "x": 39706,
      "y": 49166,
      "ta": "html > body"
    },
    {
      "t": 100804,
      "e": 92328,
      "ty": 2,
      "x": 1192,
      "y": 751
    },
    {
      "t": 100904,
      "e": 92428,
      "ty": 2,
      "x": 1209,
      "y": 634
    },
    {
      "t": 101005,
      "e": 92529,
      "ty": 2,
      "x": 1198,
      "y": 601
    },
    {
      "t": 101005,
      "e": 92529,
      "ty": 41,
      "x": 40980,
      "y": 36083,
      "ta": "html > body"
    },
    {
      "t": 101104,
      "e": 92628,
      "ty": 2,
      "x": 1181,
      "y": 593
    },
    {
      "t": 101205,
      "e": 92729,
      "ty": 2,
      "x": 1153,
      "y": 597
    },
    {
      "t": 101255,
      "e": 92779,
      "ty": 41,
      "x": 39190,
      "y": 35962,
      "ta": "html > body"
    },
    {
      "t": 101305,
      "e": 92829,
      "ty": 2,
      "x": 1146,
      "y": 599
    },
    {
      "t": 101405,
      "e": 92929,
      "ty": 2,
      "x": 1145,
      "y": 600
    },
    {
      "t": 101508,
      "e": 93032,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 102651,
      "e": 94175,
      "ty": 2,
      "x": 776,
      "y": 571
    },
    {
      "t": 102651,
      "e": 94175,
      "ty": 41,
      "x": 23766,
      "y": 32771,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 102728,
      "e": 94252,
      "ty": 2,
      "x": 774,
      "y": 571
    },
    {
      "t": 102758,
      "e": 94282,
      "ty": 41,
      "x": 23619,
      "y": 32771,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 102811,
      "e": 94335,
      "ty": 2,
      "x": 771,
      "y": 570
    },
    {
      "t": 102908,
      "e": 94432,
      "ty": 2,
      "x": 770,
      "y": 570
    },
    {
      "t": 103008,
      "e": 94532,
      "ty": 41,
      "x": 23472,
      "y": 32771,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 103408,
      "e": 94932,
      "ty": 1,
      "x": 0,
      "y": 1
    },
    {
      "t": 103508,
      "e": 95032,
      "ty": 1,
      "x": 0,
      "y": 393
    },
    {
      "t": 103551,
      "e": 95075,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"id\":2593},{\"id\":2594},{\"id\":2595},{\"id\":2596},{\"id\":2597},{\"id\":2598},{\"id\":2599},{\"id\":2600},{\"nodeType\":3,\"id\":2604,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2601},{\"id\":2602},{\"nodeType\":3,\"id\":2605,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2603}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2606,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2607,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2606},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2608,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2607},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2609,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2608},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2607}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2607}},{\"nodeType\":3,\"id\":2612,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2608}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2608}},{\"nodeType\":3,\"id\":2615,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2616,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2609}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2606},{\"id\":2607},{\"id\":2610},{\"id\":2612},{\"id\":2611},{\"id\":2608},{\"id\":2613},{\"id\":2615},{\"id\":2614},{\"id\":2609},{\"id\":2616}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2617,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2621,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2620},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2622},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2625,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2625},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2626},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2628,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2619}},{\"nodeType\":3,\"id\":2629,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2629},\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2631,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2625}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2631}},{\"nodeType\":3,\"id\":2633,\"textContent\":\"English\",\"previousSibling\":{\"id\":2632},\"parentNode\":{\"id\":2631}},{\"nodeType\":1,\"id\":2634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2635,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2634}},{\"nodeType\":3,\"id\":2636,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2635},\"parentNode\":{\"id\":2634}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2627}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":3,\"id\":2639,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2628}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":3,\"id\":2642,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2640}},{\"nodeType\":3,\"id\":2643,\"textContent\":\"*\",\"parentNode\":{\"id\":2630}},{\"nodeType\":1,\"id\":2644,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2645},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2646},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2648,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2648},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2649},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2651,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2620}},{\"nodeType\":3,\"id\":2652,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2652},\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2654,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2654}},{\"nodeType\":3,\"id\":2656,\"textContent\":\"First\",\"previousSibling\":{\"id\":2655},\"parentNode\":{\"id\":2654}},{\"nodeType\":1,\"id\":2657,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2657}},{\"nodeType\":3,\"id\":2659,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2658},\"parentNode\":{\"id\":2657}},{\"nodeType\":1,\"id\":2660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2647}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2660}},{\"nodeType\":3,\"id\":2662,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2661},\"parentNode\":{\"id\":2660}},{\"nodeType\":1,\"id\":2663,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2648}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2663}},{\"nodeType\":3,\"id\":2665,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2664},\"parentNode\":{\"id\":2663}},{\"nodeType\":1,\"id\":2666,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2667,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2666}},{\"nodeType\":3,\"id\":2668,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2667},\"parentNode\":{\"id\":2666}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2650}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":3,\"id\":2671,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2651}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":3,\"id\":2674,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2672}},{\"nodeType\":3,\"id\":2675,\"textContent\":\"*\",\"parentNode\":{\"id\":2653}},{\"nodeType\":1,\"id\":2676,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2677},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2678},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2680,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2680},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2681},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2683,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2621}},{\"nodeType\":3,\"id\":2684,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2684},\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2686,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2686}},{\"nodeType\":3,\"id\":2688,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2687},\"parentNode\":{\"id\":2686}},{\"nodeType\":1,\"id\":2689,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2689}},{\"nodeType\":3,\"id\":2691,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2690},\"parentNode\":{\"id\":2689}},{\"nodeType\":1,\"id\":2692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2679}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2692}},{\"nodeType\":3,\"id\":2694,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2693},\"parentNode\":{\"id\":2692}},{\"nodeType\":1,\"id\":2695,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2680}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2695}},{\"nodeType\":3,\"id\":2697,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2696},\"parentNode\":{\"id\":2695}},{\"nodeType\":1,\"id\":2698,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2699,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2698}},{\"nodeType\":3,\"id\":2700,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2699},\"parentNode\":{\"id\":2698}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2682}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":3,\"id\":2703,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2704,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2683}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2704}},{\"nodeType\":3,\"id\":2706,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2705},\"parentNode\":{\"id\":2704}},{\"nodeType\":3,\"id\":2707,\"textContent\":\"*\",\"parentNode\":{\"id\":2685}},{\"nodeType\":1,\"id\":2708,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2708},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2709},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2711,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2622}},{\"nodeType\":3,\"id\":2712,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2712},\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2714,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2715,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2714}},{\"nodeType\":3,\"id\":2716,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2715},\"parentNode\":{\"id\":2714}},{\"nodeType\":1,\"id\":2717,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2710}},{\"nodeType\":1,\"id\":2718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2717}},{\"nodeType\":3,\"id\":2719,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2717}},{\"nodeType\":1,\"id\":2720,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2711}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2722,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2723,\"textContent\":\"*\",\"parentNode\":{\"id\":2713}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2617},{\"id\":2618},{\"id\":2619},{\"id\":2624},{\"id\":2629},{\"id\":2630},{\"id\":2643},{\"id\":2625},{\"id\":2631},{\"id\":2632},{\"id\":2633},{\"id\":2626},{\"id\":2634},{\"id\":2635},{\"id\":2636},{\"id\":2627},{\"id\":2637},{\"id\":2638},{\"id\":2639},{\"id\":2628},{\"id\":2640},{\"id\":2641},{\"id\":2642},{\"id\":2620},{\"id\":2644},{\"id\":2652},{\"id\":2653},{\"id\":2675},{\"id\":2645},{\"id\":2654},{\"id\":2655},{\"id\":2656},{\"id\":2646},{\"id\":2657},{\"id\":2658},{\"id\":2659},{\"id\":2647},{\"id\":2660},{\"id\":2661},{\"id\":2662},{\"id\":2648},{\"id\":2663},{\"id\":2664},{\"id\":2665},{\"id\":2649},{\"id\":2666},{\"id\":2667},{\"id\":2668},{\"id\":2650},{\"id\":2669},{\"id\":2670},{\"id\":2671},{\"id\":2651},{\"id\":2672},{\"id\":2673},{\"id\":2674},{\"id\":2621},{\"id\":2676},{\"id\":2684},{\"id\":2685},{\"id\":2707},{\"id\":2677},{\"id\":2686},{\"id\":2687},{\"id\":2688},{\"id\":2678},{\"id\":2689},{\"id\":2690},{\"id\":2691},{\"id\":2679},{\"id\":2692},{\"id\":2693},{\"id\":2694},{\"id\":2680},{\"id\":2695},{\"id\":2696},{\"id\":2697},{\"id\":2681},{\"id\":2698},{\"id\":2699},{\"id\":2700},{\"id\":2682},{\"id\":2701},{\"id\":2702},{\"id\":2703},{\"id\":2683},{\"id\":2704},{\"id\":2705},{\"id\":2706},{\"id\":2622},{\"id\":2708},{\"id\":2712},{\"id\":2713},{\"id\":2723},{\"id\":2709},{\"id\":2714},{\"id\":2715},{\"id\":2716},{\"id\":2710},{\"id\":2717},{\"id\":2718},{\"id\":2719},{\"id\":2711},{\"id\":2720},{\"id\":2721},{\"id\":2722},{\"id\":2623}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2724,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"previousSibling\":{\"id\":2724},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2726,\"textContent\":\" \",\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"previousSibling\":{\"id\":2727},\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2731,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2730},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"previousSibling\":{\"id\":2731},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2733,\"textContent\":\" \",\"parentNode\":{\"id\":2727}},{\"nodeType\":1,\"id\":2734,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"previousSibling\":{\"id\":2734},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2736,\"textContent\":\" \",\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2739,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"parentNode\":{\"id\":2729}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2743,\"textContent\":\" \",\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2744,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2747,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2746},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"previousSibling\":{\"id\":2747},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" \",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2751,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2750},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"previousSibling\":{\"id\":2751},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2744}},{\"nodeType\":3,\"id\":2756,\"textContent\":\" \",\"parentNode\":{\"id\":2745}},{\"nodeType\":1,\"id\":2757,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2758,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2757},\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2757}},{\"nodeType\":3,\"id\":2760,\"textContent\":\" \",\"parentNode\":{\"id\":2747}},{\"nodeType\":1,\"id\":2761,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2760},\"parentNode\":{\"id\":2747}},{\"nodeType\":3,\"id\":2762,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2747}},{\"nodeType\":3,\"id\":2763,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2761}},{\"nodeType\":1,\"id\":2764,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2765,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2764},\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2764}},{\"nodeType\":3,\"id\":2767,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2751}},{\"nodeType\":3,\"id\":2768,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2753}},{\"nodeType\":3,\"id\":2769,\"textContent\":\" \",\"parentNode\":{\"id\":2731}},{\"nodeType\":1,\"id\":2770,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2769},\"parentNode\":{\"id\":2731}},{\"nodeType\":3,\"id\":2771,\"textContent\":\" \",\"previousSibling\":{\"id\":2770},\"parentNode\":{\"id\":2731}},{\"nodeType\":3,\"id\":2772,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2770}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2724},{\"id\":2726},{\"id\":2727},{\"id\":2733},{\"id\":2734},{\"id\":2736},{\"id\":2737},{\"id\":2739},{\"id\":2738},{\"id\":2735},{\"id\":2728},{\"id\":2729},{\"id\":2740},{\"id\":2741},{\"id\":2743},{\"id\":2744},{\"id\":2755},{\"id\":2745},{\"id\":2756},{\"id\":2757},{\"id\":2759},{\"id\":2758},{\"id\":2746},{\"id\":2747},{\"id\":2760},{\"id\":2761},{\"id\":2763},{\"id\":2762},{\"id\":2748},{\"id\":2749},{\"id\":2764},{\"id\":2766},{\"id\":2765},{\"id\":2750},{\"id\":2751},{\"id\":2767},{\"id\":2752},{\"id\":2753},{\"id\":2768},{\"id\":2754},{\"id\":2742},{\"id\":2730},{\"id\":2731},{\"id\":2769},{\"id\":2770},{\"id\":2772},{\"id\":2771},{\"id\":2732},{\"id\":2725}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2773,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2774,\"textContent\":\"[ { \\\"rt\\\": 52224, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 52229, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"8FE87\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 3337, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 56654, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"8FE87\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 7103, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"tango\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"113\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 64766, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"8FE87\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 24420, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 90277, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"8FE87\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 13171, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 104450, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"8FE87\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 48589, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 154323, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"8FE87\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-10-X -K -08 AM-C -10 AM-O -A -11 AM-11 AM-A -A -A -A -A -A -A -A -5-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:973,y:674,t:1527635198481};\\\", \\\"{x:974,y:674,t:1527635198488};\\\", \\\"{x:979,y:674,t:1527635198504};\\\", \\\"{x:987,y:677,t:1527635198522};\\\", \\\"{x:987,y:678,t:1527635198538};\\\", \\\"{x:990,y:679,t:1527635198554};\\\", \\\"{x:992,y:679,t:1527635199080};\\\", \\\"{x:993,y:679,t:1527635199088};\\\", \\\"{x:997,y:678,t:1527635199105};\\\", \\\"{x:1003,y:676,t:1527635199121};\\\", \\\"{x:1007,y:675,t:1527635199139};\\\", \\\"{x:1015,y:671,t:1527635199155};\\\", \\\"{x:1029,y:669,t:1527635199172};\\\", \\\"{x:1046,y:666,t:1527635199188};\\\", \\\"{x:1060,y:665,t:1527635199205};\\\", \\\"{x:1074,y:664,t:1527635199221};\\\", \\\"{x:1088,y:664,t:1527635199239};\\\", \\\"{x:1115,y:664,t:1527635199255};\\\", \\\"{x:1168,y:669,t:1527635199271};\\\", \\\"{x:1245,y:688,t:1527635199288};\\\", \\\"{x:1340,y:705,t:1527635199305};\\\", \\\"{x:1416,y:718,t:1527635199321};\\\", \\\"{x:1466,y:732,t:1527635199338};\\\", \\\"{x:1483,y:738,t:1527635199356};\\\", \\\"{x:1496,y:743,t:1527635199371};\\\", \\\"{x:1499,y:745,t:1527635199388};\\\", \\\"{x:1501,y:746,t:1527635199405};\\\", \\\"{x:1501,y:747,t:1527635199422};\\\", \\\"{x:1506,y:753,t:1527635199439};\\\", \\\"{x:1506,y:754,t:1527635199464};\\\", \\\"{x:1506,y:755,t:1527635199472};\\\", \\\"{x:1506,y:756,t:1527635199488};\\\", \\\"{x:1504,y:756,t:1527635199912};\\\", \\\"{x:1497,y:756,t:1527635199923};\\\", \\\"{x:1464,y:756,t:1527635199939};\\\", \\\"{x:1425,y:756,t:1527635199956};\\\", \\\"{x:1317,y:756,t:1527635199973};\\\", \\\"{x:1200,y:755,t:1527635199989};\\\", \\\"{x:1063,y:744,t:1527635200006};\\\", \\\"{x:911,y:722,t:1527635200022};\\\", \\\"{x:664,y:698,t:1527635200039};\\\", \\\"{x:487,y:694,t:1527635200055};\\\", \\\"{x:324,y:694,t:1527635200072};\\\", \\\"{x:199,y:695,t:1527635200089};\\\", \\\"{x:120,y:692,t:1527635200105};\\\", \\\"{x:89,y:684,t:1527635200122};\\\", \\\"{x:67,y:679,t:1527635200141};\\\", \\\"{x:56,y:676,t:1527635200155};\\\", \\\"{x:53,y:673,t:1527635200172};\\\", \\\"{x:47,y:670,t:1527635200189};\\\", \\\"{x:46,y:670,t:1527635200205};\\\", \\\"{x:46,y:669,t:1527635200584};\\\", \\\"{x:50,y:667,t:1527635200599};\\\", \\\"{x:56,y:666,t:1527635200607};\\\", \\\"{x:61,y:663,t:1527635200622};\\\", \\\"{x:87,y:660,t:1527635200639};\\\", \\\"{x:127,y:656,t:1527635200655};\\\", \\\"{x:178,y:654,t:1527635200672};\\\", \\\"{x:240,y:644,t:1527635200689};\\\", \\\"{x:318,y:632,t:1527635200706};\\\", \\\"{x:406,y:622,t:1527635200722};\\\", \\\"{x:500,y:613,t:1527635200739};\\\", \\\"{x:583,y:601,t:1527635200756};\\\", \\\"{x:671,y:606,t:1527635200772};\\\", \\\"{x:760,y:606,t:1527635200789};\\\", \\\"{x:851,y:606,t:1527635200806};\\\", \\\"{x:948,y:606,t:1527635200822};\\\", \\\"{x:1090,y:608,t:1527635200840};\\\", \\\"{x:1170,y:617,t:1527635200856};\\\", \\\"{x:1231,y:632,t:1527635200872};\\\", \\\"{x:1244,y:636,t:1527635200890};\\\", \\\"{x:1245,y:637,t:1527635200907};\\\", \\\"{x:1245,y:638,t:1527635201335};\\\", \\\"{x:1245,y:640,t:1527635201367};\\\", \\\"{x:1245,y:641,t:1527635201375};\\\", \\\"{x:1245,y:642,t:1527635201390};\\\", \\\"{x:1244,y:648,t:1527635201406};\\\", \\\"{x:1244,y:661,t:1527635201423};\\\", \\\"{x:1244,y:665,t:1527635201439};\\\", \\\"{x:1249,y:676,t:1527635201457};\\\", \\\"{x:1260,y:695,t:1527635201474};\\\", \\\"{x:1277,y:719,t:1527635201489};\\\", \\\"{x:1298,y:748,t:1527635201507};\\\", \\\"{x:1323,y:776,t:1527635201523};\\\", \\\"{x:1349,y:801,t:1527635201540};\\\", \\\"{x:1370,y:820,t:1527635201557};\\\", \\\"{x:1383,y:837,t:1527635201573};\\\", \\\"{x:1401,y:854,t:1527635201589};\\\", \\\"{x:1415,y:869,t:1527635201607};\\\", \\\"{x:1438,y:895,t:1527635201624};\\\", \\\"{x:1455,y:912,t:1527635201639};\\\", \\\"{x:1469,y:927,t:1527635201657};\\\", \\\"{x:1477,y:937,t:1527635201674};\\\", \\\"{x:1483,y:945,t:1527635201691};\\\", \\\"{x:1489,y:951,t:1527635201707};\\\", \\\"{x:1493,y:956,t:1527635201724};\\\", \\\"{x:1493,y:957,t:1527635201740};\\\", \\\"{x:1494,y:959,t:1527635201757};\\\", \\\"{x:1494,y:960,t:1527635201774};\\\", \\\"{x:1494,y:963,t:1527635201791};\\\", \\\"{x:1494,y:966,t:1527635201808};\\\", \\\"{x:1488,y:968,t:1527635201824};\\\", \\\"{x:1482,y:968,t:1527635201840};\\\", \\\"{x:1475,y:970,t:1527635201857};\\\", \\\"{x:1462,y:972,t:1527635201874};\\\", \\\"{x:1445,y:972,t:1527635201891};\\\", \\\"{x:1424,y:972,t:1527635201906};\\\", \\\"{x:1402,y:972,t:1527635201924};\\\", \\\"{x:1381,y:972,t:1527635201940};\\\", \\\"{x:1366,y:972,t:1527635201957};\\\", \\\"{x:1351,y:971,t:1527635201974};\\\", \\\"{x:1335,y:968,t:1527635201991};\\\", \\\"{x:1314,y:964,t:1527635202007};\\\", \\\"{x:1287,y:960,t:1527635202024};\\\", \\\"{x:1267,y:958,t:1527635202040};\\\", \\\"{x:1247,y:955,t:1527635202057};\\\", \\\"{x:1218,y:951,t:1527635202074};\\\", \\\"{x:1179,y:945,t:1527635202091};\\\", \\\"{x:1148,y:940,t:1527635202107};\\\", \\\"{x:1127,y:935,t:1527635202124};\\\", \\\"{x:1113,y:934,t:1527635202141};\\\", \\\"{x:1108,y:934,t:1527635202157};\\\", \\\"{x:1106,y:933,t:1527635202174};\\\", \\\"{x:1106,y:932,t:1527635202376};\\\", \\\"{x:1106,y:931,t:1527635202391};\\\", \\\"{x:1106,y:925,t:1527635202408};\\\", \\\"{x:1108,y:921,t:1527635202424};\\\", \\\"{x:1110,y:916,t:1527635202441};\\\", \\\"{x:1114,y:908,t:1527635202458};\\\", \\\"{x:1117,y:900,t:1527635202474};\\\", \\\"{x:1122,y:890,t:1527635202491};\\\", \\\"{x:1125,y:881,t:1527635202508};\\\", \\\"{x:1131,y:869,t:1527635202524};\\\", \\\"{x:1137,y:855,t:1527635202541};\\\", \\\"{x:1146,y:842,t:1527635202558};\\\", \\\"{x:1152,y:825,t:1527635202574};\\\", \\\"{x:1160,y:801,t:1527635202591};\\\", \\\"{x:1171,y:772,t:1527635202608};\\\", \\\"{x:1177,y:747,t:1527635202624};\\\", \\\"{x:1191,y:701,t:1527635202641};\\\", \\\"{x:1204,y:661,t:1527635202658};\\\", \\\"{x:1214,y:620,t:1527635202674};\\\", \\\"{x:1223,y:578,t:1527635202691};\\\", \\\"{x:1231,y:538,t:1527635202708};\\\", \\\"{x:1235,y:499,t:1527635202725};\\\", \\\"{x:1243,y:461,t:1527635202741};\\\", \\\"{x:1248,y:424,t:1527635202758};\\\", \\\"{x:1250,y:401,t:1527635202775};\\\", \\\"{x:1251,y:389,t:1527635202791};\\\", \\\"{x:1252,y:377,t:1527635202808};\\\", \\\"{x:1255,y:370,t:1527635202824};\\\", \\\"{x:1257,y:365,t:1527635202841};\\\", \\\"{x:1260,y:356,t:1527635202859};\\\", \\\"{x:1269,y:342,t:1527635202875};\\\", \\\"{x:1278,y:327,t:1527635202890};\\\", \\\"{x:1291,y:312,t:1527635202908};\\\", \\\"{x:1301,y:303,t:1527635202925};\\\", \\\"{x:1312,y:295,t:1527635202941};\\\", \\\"{x:1322,y:287,t:1527635202958};\\\", \\\"{x:1332,y:280,t:1527635202975};\\\", \\\"{x:1338,y:276,t:1527635202991};\\\", \\\"{x:1345,y:269,t:1527635203008};\\\", \\\"{x:1347,y:267,t:1527635203025};\\\", \\\"{x:1351,y:265,t:1527635203041};\\\", \\\"{x:1353,y:264,t:1527635203058};\\\", \\\"{x:1354,y:264,t:1527635203536};\\\", \\\"{x:1367,y:256,t:1527635203544};\\\", \\\"{x:1390,y:247,t:1527635203558};\\\", \\\"{x:1414,y:232,t:1527635203576};\\\", \\\"{x:1423,y:215,t:1527635203592};\\\", \\\"{x:1432,y:197,t:1527635203607};\\\", \\\"{x:1446,y:174,t:1527635203625};\\\", \\\"{x:1454,y:159,t:1527635203642};\\\", \\\"{x:1457,y:153,t:1527635203658};\\\", \\\"{x:1461,y:143,t:1527635203675};\\\", \\\"{x:1461,y:141,t:1527635203692};\\\", \\\"{x:1463,y:137,t:1527635203708};\\\", \\\"{x:1464,y:135,t:1527635203725};\\\", \\\"{x:1465,y:133,t:1527635203743};\\\", \\\"{x:1465,y:132,t:1527635203758};\\\", \\\"{x:1466,y:130,t:1527635203775};\\\", \\\"{x:1468,y:127,t:1527635203792};\\\", \\\"{x:1470,y:125,t:1527635203808};\\\", \\\"{x:1472,y:123,t:1527635203824};\\\", \\\"{x:1472,y:122,t:1527635203842};\\\", \\\"{x:1474,y:121,t:1527635203859};\\\", \\\"{x:1479,y:117,t:1527635203874};\\\", \\\"{x:1484,y:113,t:1527635203894};\\\", \\\"{x:1486,y:111,t:1527635203909};\\\", \\\"{x:1488,y:110,t:1527635203924};\\\", \\\"{x:1489,y:110,t:1527635204383};\\\", \\\"{x:1489,y:112,t:1527635204392};\\\", \\\"{x:1487,y:123,t:1527635204409};\\\", \\\"{x:1484,y:134,t:1527635204426};\\\", \\\"{x:1480,y:151,t:1527635204441};\\\", \\\"{x:1477,y:173,t:1527635204459};\\\", \\\"{x:1472,y:197,t:1527635204475};\\\", \\\"{x:1471,y:220,t:1527635204492};\\\", \\\"{x:1471,y:248,t:1527635204509};\\\", \\\"{x:1471,y:277,t:1527635204526};\\\", \\\"{x:1476,y:302,t:1527635204542};\\\", \\\"{x:1480,y:326,t:1527635204558};\\\", \\\"{x:1486,y:362,t:1527635204576};\\\", \\\"{x:1487,y:382,t:1527635204591};\\\", \\\"{x:1487,y:403,t:1527635204609};\\\", \\\"{x:1487,y:421,t:1527635204626};\\\", \\\"{x:1490,y:438,t:1527635204642};\\\", \\\"{x:1492,y:456,t:1527635204659};\\\", \\\"{x:1495,y:473,t:1527635204675};\\\", \\\"{x:1499,y:495,t:1527635204691};\\\", \\\"{x:1503,y:512,t:1527635204709};\\\", \\\"{x:1507,y:535,t:1527635204725};\\\", \\\"{x:1515,y:558,t:1527635204741};\\\", \\\"{x:1523,y:579,t:1527635204759};\\\", \\\"{x:1537,y:612,t:1527635204775};\\\", \\\"{x:1546,y:633,t:1527635204793};\\\", \\\"{x:1556,y:660,t:1527635204809};\\\", \\\"{x:1567,y:685,t:1527635204826};\\\", \\\"{x:1578,y:711,t:1527635204843};\\\", \\\"{x:1594,y:733,t:1527635204858};\\\", \\\"{x:1605,y:756,t:1527635204875};\\\", \\\"{x:1618,y:778,t:1527635204893};\\\", \\\"{x:1637,y:807,t:1527635204909};\\\", \\\"{x:1661,y:836,t:1527635204926};\\\", \\\"{x:1685,y:868,t:1527635204943};\\\", \\\"{x:1699,y:888,t:1527635204958};\\\", \\\"{x:1711,y:908,t:1527635204975};\\\", \\\"{x:1716,y:916,t:1527635204993};\\\", \\\"{x:1718,y:920,t:1527635205009};\\\", \\\"{x:1719,y:922,t:1527635205025};\\\", \\\"{x:1720,y:924,t:1527635205063};\\\", \\\"{x:1721,y:924,t:1527635205076};\\\", \\\"{x:1723,y:927,t:1527635205093};\\\", \\\"{x:1722,y:930,t:1527635205112};\\\", \\\"{x:1721,y:932,t:1527635205126};\\\", \\\"{x:1715,y:935,t:1527635205143};\\\", \\\"{x:1707,y:938,t:1527635205159};\\\", \\\"{x:1700,y:938,t:1527635205177};\\\", \\\"{x:1687,y:940,t:1527635205193};\\\", \\\"{x:1671,y:944,t:1527635205209};\\\", \\\"{x:1658,y:948,t:1527635205226};\\\", \\\"{x:1643,y:950,t:1527635205243};\\\", \\\"{x:1633,y:950,t:1527635205264};\\\", \\\"{x:1629,y:952,t:1527635205276};\\\", \\\"{x:1622,y:952,t:1527635205292};\\\", \\\"{x:1609,y:953,t:1527635205309};\\\", \\\"{x:1597,y:953,t:1527635205326};\\\", \\\"{x:1584,y:953,t:1527635205342};\\\", \\\"{x:1562,y:954,t:1527635205359};\\\", \\\"{x:1540,y:954,t:1527635205375};\\\", \\\"{x:1518,y:954,t:1527635205393};\\\", \\\"{x:1493,y:954,t:1527635205409};\\\", \\\"{x:1464,y:954,t:1527635205426};\\\", \\\"{x:1422,y:954,t:1527635205442};\\\", \\\"{x:1395,y:954,t:1527635205460};\\\", \\\"{x:1374,y:954,t:1527635205475};\\\", \\\"{x:1355,y:954,t:1527635205492};\\\", \\\"{x:1340,y:953,t:1527635205509};\\\", \\\"{x:1321,y:951,t:1527635205525};\\\", \\\"{x:1299,y:950,t:1527635205543};\\\", \\\"{x:1268,y:948,t:1527635205560};\\\", \\\"{x:1251,y:948,t:1527635205576};\\\", \\\"{x:1229,y:948,t:1527635205592};\\\", \\\"{x:1211,y:947,t:1527635205610};\\\", \\\"{x:1189,y:944,t:1527635205625};\\\", \\\"{x:1175,y:941,t:1527635205643};\\\", \\\"{x:1166,y:941,t:1527635205659};\\\", \\\"{x:1163,y:941,t:1527635205675};\\\", \\\"{x:1162,y:941,t:1527635205704};\\\", \\\"{x:1159,y:941,t:1527635205720};\\\", \\\"{x:1156,y:941,t:1527635205735};\\\", \\\"{x:1152,y:941,t:1527635205744};\\\", \\\"{x:1142,y:941,t:1527635205759};\\\", \\\"{x:1130,y:941,t:1527635205776};\\\", \\\"{x:1118,y:940,t:1527635205793};\\\", \\\"{x:1108,y:937,t:1527635205810};\\\", \\\"{x:1101,y:936,t:1527635205827};\\\", \\\"{x:1092,y:934,t:1527635205843};\\\", \\\"{x:1085,y:933,t:1527635205860};\\\", \\\"{x:1080,y:932,t:1527635205877};\\\", \\\"{x:1077,y:932,t:1527635205893};\\\", \\\"{x:1076,y:932,t:1527635205910};\\\", \\\"{x:1075,y:932,t:1527635205928};\\\", \\\"{x:1075,y:931,t:1527635206047};\\\", \\\"{x:1075,y:930,t:1527635206063};\\\", \\\"{x:1075,y:929,t:1527635206076};\\\", \\\"{x:1075,y:927,t:1527635206092};\\\", \\\"{x:1075,y:926,t:1527635206109};\\\", \\\"{x:1075,y:924,t:1527635206135};\\\", \\\"{x:1075,y:923,t:1527635206151};\\\", \\\"{x:1075,y:922,t:1527635206167};\\\", \\\"{x:1075,y:921,t:1527635206176};\\\", \\\"{x:1076,y:920,t:1527635206193};\\\", \\\"{x:1077,y:920,t:1527635206210};\\\", \\\"{x:1077,y:919,t:1527635206231};\\\", \\\"{x:1078,y:919,t:1527635206247};\\\", \\\"{x:1081,y:918,t:1527635206260};\\\", \\\"{x:1081,y:917,t:1527635206276};\\\", \\\"{x:1083,y:916,t:1527635206292};\\\", \\\"{x:1084,y:916,t:1527635206310};\\\", \\\"{x:1086,y:915,t:1527635206328};\\\", \\\"{x:1088,y:913,t:1527635206343};\\\", \\\"{x:1089,y:913,t:1527635206360};\\\", \\\"{x:1091,y:913,t:1527635206377};\\\", \\\"{x:1093,y:911,t:1527635206394};\\\", \\\"{x:1094,y:911,t:1527635206448};\\\", \\\"{x:1095,y:911,t:1527635206464};\\\", \\\"{x:1096,y:910,t:1527635206477};\\\", \\\"{x:1098,y:910,t:1527635206493};\\\", \\\"{x:1100,y:909,t:1527635206510};\\\", \\\"{x:1102,y:908,t:1527635206527};\\\", \\\"{x:1106,y:908,t:1527635206544};\\\", \\\"{x:1109,y:907,t:1527635206559};\\\", \\\"{x:1112,y:907,t:1527635206577};\\\", \\\"{x:1115,y:907,t:1527635206594};\\\", \\\"{x:1118,y:906,t:1527635206610};\\\", \\\"{x:1121,y:906,t:1527635206627};\\\", \\\"{x:1123,y:905,t:1527635206644};\\\", \\\"{x:1125,y:905,t:1527635206660};\\\", \\\"{x:1126,y:905,t:1527635206677};\\\", \\\"{x:1128,y:905,t:1527635206694};\\\", \\\"{x:1129,y:905,t:1527635206710};\\\", \\\"{x:1131,y:905,t:1527635206727};\\\", \\\"{x:1131,y:904,t:1527635206744};\\\", \\\"{x:1132,y:904,t:1527635206977};\\\", \\\"{x:1131,y:905,t:1527635207000};\\\", \\\"{x:1130,y:905,t:1527635207012};\\\", \\\"{x:1128,y:906,t:1527635207027};\\\", \\\"{x:1127,y:907,t:1527635207044};\\\", \\\"{x:1125,y:908,t:1527635207061};\\\", \\\"{x:1124,y:908,t:1527635207077};\\\", \\\"{x:1122,y:908,t:1527635207093};\\\", \\\"{x:1120,y:908,t:1527635207111};\\\", \\\"{x:1117,y:908,t:1527635207126};\\\", \\\"{x:1113,y:908,t:1527635207143};\\\", \\\"{x:1109,y:908,t:1527635207160};\\\", \\\"{x:1105,y:908,t:1527635207176};\\\", \\\"{x:1102,y:908,t:1527635207194};\\\", \\\"{x:1099,y:908,t:1527635207210};\\\", \\\"{x:1098,y:908,t:1527635207226};\\\", \\\"{x:1096,y:908,t:1527635207244};\\\", \\\"{x:1095,y:908,t:1527635207261};\\\", \\\"{x:1092,y:908,t:1527635207276};\\\", \\\"{x:1094,y:908,t:1527635208009};\\\", \\\"{x:1096,y:908,t:1527635208016};\\\", \\\"{x:1100,y:908,t:1527635208028};\\\", \\\"{x:1109,y:908,t:1527635208045};\\\", \\\"{x:1127,y:910,t:1527635208061};\\\", \\\"{x:1145,y:910,t:1527635208078};\\\", \\\"{x:1167,y:910,t:1527635208095};\\\", \\\"{x:1185,y:911,t:1527635208111};\\\", \\\"{x:1214,y:913,t:1527635208128};\\\", \\\"{x:1237,y:913,t:1527635208145};\\\", \\\"{x:1261,y:913,t:1527635208161};\\\", \\\"{x:1284,y:913,t:1527635208178};\\\", \\\"{x:1305,y:913,t:1527635208195};\\\", \\\"{x:1329,y:913,t:1527635208212};\\\", \\\"{x:1356,y:913,t:1527635208228};\\\", \\\"{x:1379,y:913,t:1527635208245};\\\", \\\"{x:1400,y:913,t:1527635208261};\\\", \\\"{x:1416,y:911,t:1527635208279};\\\", \\\"{x:1429,y:910,t:1527635208294};\\\", \\\"{x:1442,y:910,t:1527635208310};\\\", \\\"{x:1459,y:910,t:1527635208327};\\\", \\\"{x:1464,y:907,t:1527635208344};\\\", \\\"{x:1468,y:906,t:1527635208360};\\\", \\\"{x:1470,y:906,t:1527635208378};\\\", \\\"{x:1472,y:906,t:1527635208395};\\\", \\\"{x:1474,y:905,t:1527635208411};\\\", \\\"{x:1475,y:904,t:1527635208428};\\\", \\\"{x:1477,y:904,t:1527635208463};\\\", \\\"{x:1478,y:903,t:1527635208520};\\\", \\\"{x:1480,y:903,t:1527635208528};\\\", \\\"{x:1481,y:903,t:1527635208552};\\\", \\\"{x:1482,y:902,t:1527635208584};\\\", \\\"{x:1483,y:901,t:1527635208600};\\\", \\\"{x:1484,y:901,t:1527635208616};\\\", \\\"{x:1485,y:901,t:1527635208641};\\\", \\\"{x:1486,y:901,t:1527635208648};\\\", \\\"{x:1487,y:901,t:1527635208663};\\\", \\\"{x:1491,y:901,t:1527635208678};\\\", \\\"{x:1497,y:901,t:1527635208695};\\\", \\\"{x:1505,y:901,t:1527635208712};\\\", \\\"{x:1507,y:901,t:1527635208728};\\\", \\\"{x:1508,y:901,t:1527635208745};\\\", \\\"{x:1509,y:901,t:1527635208848};\\\", \\\"{x:1510,y:901,t:1527635208929};\\\", \\\"{x:1509,y:901,t:1527635209367};\\\", \\\"{x:1508,y:901,t:1527635209379};\\\", \\\"{x:1508,y:903,t:1527635209395};\\\", \\\"{x:1507,y:903,t:1527635209412};\\\", \\\"{x:1506,y:904,t:1527635209429};\\\", \\\"{x:1505,y:904,t:1527635209445};\\\", \\\"{x:1502,y:906,t:1527635209461};\\\", \\\"{x:1498,y:907,t:1527635209479};\\\", \\\"{x:1485,y:907,t:1527635209496};\\\", \\\"{x:1469,y:907,t:1527635209512};\\\", \\\"{x:1450,y:907,t:1527635209528};\\\", \\\"{x:1428,y:907,t:1527635209546};\\\", \\\"{x:1404,y:904,t:1527635209562};\\\", \\\"{x:1377,y:900,t:1527635209579};\\\", \\\"{x:1356,y:896,t:1527635209596};\\\", \\\"{x:1332,y:893,t:1527635209612};\\\", \\\"{x:1311,y:889,t:1527635209629};\\\", \\\"{x:1296,y:886,t:1527635209646};\\\", \\\"{x:1287,y:884,t:1527635209662};\\\", \\\"{x:1284,y:883,t:1527635209679};\\\", \\\"{x:1282,y:881,t:1527635209697};\\\", \\\"{x:1280,y:881,t:1527635209712};\\\", \\\"{x:1279,y:879,t:1527635209729};\\\", \\\"{x:1275,y:874,t:1527635209746};\\\", \\\"{x:1272,y:868,t:1527635209762};\\\", \\\"{x:1266,y:859,t:1527635209780};\\\", \\\"{x:1255,y:841,t:1527635209796};\\\", \\\"{x:1250,y:829,t:1527635209813};\\\", \\\"{x:1246,y:821,t:1527635209830};\\\", \\\"{x:1241,y:810,t:1527635209846};\\\", \\\"{x:1238,y:802,t:1527635209862};\\\", \\\"{x:1235,y:793,t:1527635209883};\\\", \\\"{x:1228,y:780,t:1527635209900};\\\", \\\"{x:1226,y:776,t:1527635209918};\\\", \\\"{x:1223,y:772,t:1527635209933};\\\", \\\"{x:1222,y:771,t:1527635209950};\\\", \\\"{x:1221,y:769,t:1527635209968};\\\", \\\"{x:1220,y:769,t:1527635209983};\\\", \\\"{x:1220,y:768,t:1527635210003};\\\", \\\"{x:1218,y:767,t:1527635210020};\\\", \\\"{x:1217,y:767,t:1527635210044};\\\", \\\"{x:1215,y:767,t:1527635210099};\\\", \\\"{x:1214,y:767,t:1527635210131};\\\", \\\"{x:1212,y:767,t:1527635210147};\\\", \\\"{x:1210,y:767,t:1527635210171};\\\", \\\"{x:1209,y:767,t:1527635210183};\\\", \\\"{x:1208,y:767,t:1527635210199};\\\", \\\"{x:1206,y:767,t:1527635210216};\\\", \\\"{x:1205,y:767,t:1527635210233};\\\", \\\"{x:1204,y:767,t:1527635210276};\\\", \\\"{x:1204,y:768,t:1527635210291};\\\", \\\"{x:1203,y:768,t:1527635210300};\\\", \\\"{x:1202,y:770,t:1527635210338};\\\", \\\"{x:1202,y:771,t:1527635210355};\\\", \\\"{x:1202,y:773,t:1527635210370};\\\", \\\"{x:1202,y:774,t:1527635210387};\\\", \\\"{x:1202,y:776,t:1527635210399};\\\", \\\"{x:1202,y:778,t:1527635210416};\\\", \\\"{x:1202,y:780,t:1527635210433};\\\", \\\"{x:1202,y:781,t:1527635210451};\\\", \\\"{x:1202,y:782,t:1527635210467};\\\", \\\"{x:1202,y:783,t:1527635210484};\\\", \\\"{x:1202,y:785,t:1527635210499};\\\", \\\"{x:1201,y:786,t:1527635210516};\\\", \\\"{x:1201,y:787,t:1527635210540};\\\", \\\"{x:1201,y:788,t:1527635210555};\\\", \\\"{x:1201,y:789,t:1527635210567};\\\", \\\"{x:1201,y:792,t:1527635210583};\\\", \\\"{x:1201,y:796,t:1527635210600};\\\", \\\"{x:1201,y:800,t:1527635210616};\\\", \\\"{x:1201,y:807,t:1527635210634};\\\", \\\"{x:1201,y:812,t:1527635210650};\\\", \\\"{x:1201,y:815,t:1527635210667};\\\", \\\"{x:1201,y:818,t:1527635210684};\\\", \\\"{x:1201,y:822,t:1527635210700};\\\", \\\"{x:1201,y:828,t:1527635210717};\\\", \\\"{x:1202,y:836,t:1527635210734};\\\", \\\"{x:1203,y:842,t:1527635210750};\\\", \\\"{x:1206,y:848,t:1527635210767};\\\", \\\"{x:1207,y:854,t:1527635210784};\\\", \\\"{x:1209,y:859,t:1527635210800};\\\", \\\"{x:1212,y:865,t:1527635210817};\\\", \\\"{x:1215,y:871,t:1527635210833};\\\", \\\"{x:1219,y:878,t:1527635210850};\\\", \\\"{x:1221,y:887,t:1527635210867};\\\", \\\"{x:1228,y:900,t:1527635210884};\\\", \\\"{x:1229,y:905,t:1527635210900};\\\", \\\"{x:1232,y:909,t:1527635210917};\\\", \\\"{x:1233,y:912,t:1527635210934};\\\", \\\"{x:1234,y:913,t:1527635210949};\\\", \\\"{x:1235,y:914,t:1527635210968};\\\", \\\"{x:1235,y:915,t:1527635210996};\\\", \\\"{x:1235,y:917,t:1527635211020};\\\", \\\"{x:1236,y:918,t:1527635211059};\\\", \\\"{x:1237,y:918,t:1527635211147};\\\", \\\"{x:1238,y:918,t:1527635211154};\\\", \\\"{x:1239,y:918,t:1527635211167};\\\", \\\"{x:1242,y:918,t:1527635211184};\\\", \\\"{x:1244,y:918,t:1527635211201};\\\", \\\"{x:1247,y:918,t:1527635211217};\\\", \\\"{x:1249,y:918,t:1527635211235};\\\", \\\"{x:1250,y:918,t:1527635211259};\\\", \\\"{x:1251,y:918,t:1527635211275};\\\", \\\"{x:1253,y:918,t:1527635211299};\\\", \\\"{x:1254,y:918,t:1527635211308};\\\", \\\"{x:1256,y:917,t:1527635211323};\\\", \\\"{x:1258,y:916,t:1527635211364};\\\", \\\"{x:1260,y:915,t:1527635211404};\\\", \\\"{x:1261,y:915,t:1527635211436};\\\", \\\"{x:1262,y:914,t:1527635211460};\\\", \\\"{x:1263,y:914,t:1527635211476};\\\", \\\"{x:1264,y:914,t:1527635211491};\\\", \\\"{x:1264,y:913,t:1527635211515};\\\", \\\"{x:1265,y:913,t:1527635211572};\\\", \\\"{x:1265,y:912,t:1527635211584};\\\", \\\"{x:1266,y:912,t:1527635211612};\\\", \\\"{x:1267,y:912,t:1527635211652};\\\", \\\"{x:1269,y:911,t:1527635211692};\\\", \\\"{x:1269,y:910,t:1527635211708};\\\", \\\"{x:1270,y:910,t:1527635211740};\\\", \\\"{x:1271,y:910,t:1527635211788};\\\", \\\"{x:1272,y:910,t:1527635211804};\\\", \\\"{x:1273,y:910,t:1527635211820};\\\", \\\"{x:1273,y:909,t:1527635211836};\\\", \\\"{x:1274,y:909,t:1527635213084};\\\", \\\"{x:1281,y:907,t:1527635213103};\\\", \\\"{x:1292,y:907,t:1527635213119};\\\", \\\"{x:1301,y:907,t:1527635213136};\\\", \\\"{x:1312,y:907,t:1527635213152};\\\", \\\"{x:1315,y:907,t:1527635213169};\\\", \\\"{x:1316,y:907,t:1527635213185};\\\", \\\"{x:1315,y:907,t:1527635213308};\\\", \\\"{x:1314,y:908,t:1527635213320};\\\", \\\"{x:1313,y:908,t:1527635213335};\\\", \\\"{x:1311,y:909,t:1527635213352};\\\", \\\"{x:1309,y:909,t:1527635213369};\\\", \\\"{x:1308,y:910,t:1527635213412};\\\", \\\"{x:1307,y:910,t:1527635213427};\\\", \\\"{x:1306,y:910,t:1527635213452};\\\", \\\"{x:1306,y:912,t:1527635213469};\\\", \\\"{x:1305,y:912,t:1527635213500};\\\", \\\"{x:1304,y:912,t:1527635213516};\\\", \\\"{x:1303,y:912,t:1527635213556};\\\", \\\"{x:1302,y:911,t:1527635214149};\\\", \\\"{x:1301,y:909,t:1527635214156};\\\", \\\"{x:1300,y:908,t:1527635214169};\\\", \\\"{x:1298,y:905,t:1527635214187};\\\", \\\"{x:1297,y:900,t:1527635214203};\\\", \\\"{x:1295,y:897,t:1527635214220};\\\", \\\"{x:1294,y:894,t:1527635214236};\\\", \\\"{x:1293,y:893,t:1527635214253};\\\", \\\"{x:1292,y:891,t:1527635214269};\\\", \\\"{x:1292,y:890,t:1527635214286};\\\", \\\"{x:1291,y:886,t:1527635214303};\\\", \\\"{x:1288,y:881,t:1527635214319};\\\", \\\"{x:1288,y:875,t:1527635214336};\\\", \\\"{x:1285,y:869,t:1527635214352};\\\", \\\"{x:1282,y:858,t:1527635214369};\\\", \\\"{x:1280,y:849,t:1527635214385};\\\", \\\"{x:1279,y:832,t:1527635214403};\\\", \\\"{x:1278,y:820,t:1527635214418};\\\", \\\"{x:1274,y:798,t:1527635214436};\\\", \\\"{x:1273,y:778,t:1527635214452};\\\", \\\"{x:1272,y:766,t:1527635214469};\\\", \\\"{x:1272,y:745,t:1527635214486};\\\", \\\"{x:1272,y:726,t:1527635214502};\\\", \\\"{x:1272,y:706,t:1527635214519};\\\", \\\"{x:1272,y:688,t:1527635214536};\\\", \\\"{x:1274,y:678,t:1527635214553};\\\", \\\"{x:1276,y:670,t:1527635214569};\\\", \\\"{x:1276,y:669,t:1527635214587};\\\", \\\"{x:1276,y:668,t:1527635214860};\\\", \\\"{x:1275,y:668,t:1527635214870};\\\", \\\"{x:1268,y:670,t:1527635214886};\\\", \\\"{x:1258,y:672,t:1527635214903};\\\", \\\"{x:1233,y:676,t:1527635214921};\\\", \\\"{x:1203,y:678,t:1527635214937};\\\", \\\"{x:1173,y:678,t:1527635214954};\\\", \\\"{x:1151,y:678,t:1527635214970};\\\", \\\"{x:1135,y:679,t:1527635214986};\\\", \\\"{x:1110,y:679,t:1527635215004};\\\", \\\"{x:1099,y:679,t:1527635215019};\\\", \\\"{x:1094,y:679,t:1527635215036};\\\", \\\"{x:1083,y:679,t:1527635215053};\\\", \\\"{x:1066,y:679,t:1527635215071};\\\", \\\"{x:1038,y:675,t:1527635215086};\\\", \\\"{x:1012,y:671,t:1527635215103};\\\", \\\"{x:963,y:666,t:1527635215121};\\\", \\\"{x:911,y:655,t:1527635215136};\\\", \\\"{x:858,y:648,t:1527635215153};\\\", \\\"{x:809,y:638,t:1527635215170};\\\", \\\"{x:742,y:625,t:1527635215187};\\\", \\\"{x:699,y:616,t:1527635215203};\\\", \\\"{x:670,y:612,t:1527635215220};\\\", \\\"{x:657,y:609,t:1527635215237};\\\", \\\"{x:655,y:608,t:1527635215253};\\\", \\\"{x:658,y:605,t:1527635215270};\\\", \\\"{x:664,y:601,t:1527635215287};\\\", \\\"{x:661,y:599,t:1527635215780};\\\", \\\"{x:654,y:598,t:1527635215787};\\\", \\\"{x:634,y:594,t:1527635215805};\\\", \\\"{x:610,y:593,t:1527635215820};\\\", \\\"{x:586,y:587,t:1527635215837};\\\", \\\"{x:561,y:583,t:1527635215856};\\\", \\\"{x:536,y:576,t:1527635215872};\\\", \\\"{x:514,y:568,t:1527635215888};\\\", \\\"{x:493,y:562,t:1527635215906};\\\", \\\"{x:464,y:551,t:1527635215924};\\\", \\\"{x:445,y:542,t:1527635215939};\\\", \\\"{x:425,y:532,t:1527635215955};\\\", \\\"{x:400,y:520,t:1527635215974};\\\", \\\"{x:374,y:508,t:1527635215989};\\\", \\\"{x:350,y:498,t:1527635216005};\\\", \\\"{x:329,y:492,t:1527635216022};\\\", \\\"{x:312,y:487,t:1527635216041};\\\", \\\"{x:299,y:484,t:1527635216055};\\\", \\\"{x:283,y:480,t:1527635216073};\\\", \\\"{x:266,y:477,t:1527635216089};\\\", \\\"{x:244,y:475,t:1527635216105};\\\", \\\"{x:213,y:475,t:1527635216122};\\\", \\\"{x:191,y:475,t:1527635216139};\\\", \\\"{x:177,y:475,t:1527635216156};\\\", \\\"{x:164,y:478,t:1527635216172};\\\", \\\"{x:160,y:480,t:1527635216189};\\\", \\\"{x:157,y:482,t:1527635216205};\\\", \\\"{x:155,y:484,t:1527635216223};\\\", \\\"{x:153,y:486,t:1527635216240};\\\", \\\"{x:151,y:490,t:1527635216256};\\\", \\\"{x:150,y:493,t:1527635216274};\\\", \\\"{x:148,y:497,t:1527635216290};\\\", \\\"{x:148,y:500,t:1527635216305};\\\", \\\"{x:148,y:502,t:1527635216323};\\\", \\\"{x:148,y:505,t:1527635216338};\\\", \\\"{x:160,y:507,t:1527635216356};\\\", \\\"{x:179,y:507,t:1527635216372};\\\", \\\"{x:205,y:507,t:1527635216390};\\\", \\\"{x:231,y:507,t:1527635216405};\\\", \\\"{x:254,y:502,t:1527635216423};\\\", \\\"{x:286,y:495,t:1527635216441};\\\", \\\"{x:307,y:487,t:1527635216456};\\\", \\\"{x:317,y:481,t:1527635216473};\\\", \\\"{x:318,y:480,t:1527635216490};\\\", \\\"{x:320,y:478,t:1527635216505};\\\", \\\"{x:320,y:475,t:1527635216522};\\\", \\\"{x:322,y:472,t:1527635216541};\\\", \\\"{x:323,y:471,t:1527635216556};\\\", \\\"{x:325,y:469,t:1527635216573};\\\", \\\"{x:326,y:468,t:1527635216589};\\\", \\\"{x:327,y:465,t:1527635216606};\\\", \\\"{x:329,y:463,t:1527635216622};\\\", \\\"{x:332,y:461,t:1527635216640};\\\", \\\"{x:334,y:461,t:1527635216656};\\\", \\\"{x:337,y:460,t:1527635216672};\\\", \\\"{x:342,y:458,t:1527635216690};\\\", \\\"{x:359,y:458,t:1527635216707};\\\", \\\"{x:365,y:458,t:1527635216723};\\\", \\\"{x:368,y:458,t:1527635216739};\\\", \\\"{x:369,y:458,t:1527635216757};\\\", \\\"{x:370,y:459,t:1527635216773};\\\", \\\"{x:371,y:459,t:1527635216795};\\\", \\\"{x:372,y:459,t:1527635216811};\\\", \\\"{x:373,y:459,t:1527635216827};\\\", \\\"{x:374,y:460,t:1527635216893};\\\", \\\"{x:375,y:460,t:1527635216906};\\\", \\\"{x:376,y:461,t:1527635216923};\\\", \\\"{x:376,y:462,t:1527635216970};\\\", \\\"{x:377,y:462,t:1527635216979};\\\", \\\"{x:378,y:463,t:1527635216990};\\\", \\\"{x:379,y:464,t:1527635217006};\\\", \\\"{x:382,y:466,t:1527635217024};\\\", \\\"{x:384,y:466,t:1527635217040};\\\", \\\"{x:384,y:467,t:1527635217056};\\\", \\\"{x:385,y:468,t:1527635217074};\\\", \\\"{x:386,y:468,t:1527635217090};\\\", \\\"{x:387,y:468,t:1527635217115};\\\", \\\"{x:388,y:468,t:1527635217139};\\\", \\\"{x:390,y:469,t:1527635217612};\\\", \\\"{x:390,y:470,t:1527635217624};\\\", \\\"{x:391,y:471,t:1527635217642};\\\", \\\"{x:392,y:472,t:1527635217667};\\\", \\\"{x:392,y:473,t:1527635217732};\\\", \\\"{x:393,y:474,t:1527635217828};\\\", \\\"{x:395,y:474,t:1527635217842};\\\", \\\"{x:406,y:477,t:1527635217857};\\\", \\\"{x:427,y:479,t:1527635217875};\\\", \\\"{x:478,y:483,t:1527635217890};\\\", \\\"{x:538,y:488,t:1527635217908};\\\", \\\"{x:612,y:492,t:1527635217924};\\\", \\\"{x:707,y:496,t:1527635217941};\\\", \\\"{x:802,y:501,t:1527635217958};\\\", \\\"{x:903,y:507,t:1527635217973};\\\", \\\"{x:999,y:515,t:1527635217991};\\\", \\\"{x:1072,y:517,t:1527635218006};\\\", \\\"{x:1117,y:524,t:1527635218023};\\\", \\\"{x:1151,y:528,t:1527635218040};\\\", \\\"{x:1177,y:534,t:1527635218058};\\\", \\\"{x:1208,y:541,t:1527635218074};\\\", \\\"{x:1245,y:552,t:1527635218090};\\\", \\\"{x:1273,y:556,t:1527635218108};\\\", \\\"{x:1297,y:561,t:1527635218125};\\\", \\\"{x:1323,y:563,t:1527635218140};\\\", \\\"{x:1341,y:566,t:1527635218157};\\\", \\\"{x:1354,y:568,t:1527635218175};\\\", \\\"{x:1358,y:569,t:1527635218191};\\\", \\\"{x:1360,y:571,t:1527635218207};\\\", \\\"{x:1361,y:572,t:1527635218308};\\\", \\\"{x:1359,y:574,t:1527635218516};\\\", \\\"{x:1358,y:574,t:1527635218526};\\\", \\\"{x:1356,y:575,t:1527635218543};\\\", \\\"{x:1353,y:575,t:1527635218560};\\\", \\\"{x:1351,y:577,t:1527635218577};\\\", \\\"{x:1348,y:578,t:1527635218593};\\\", \\\"{x:1345,y:579,t:1527635218609};\\\", \\\"{x:1342,y:580,t:1527635218627};\\\", \\\"{x:1341,y:581,t:1527635218652};\\\", \\\"{x:1339,y:581,t:1527635218676};\\\", \\\"{x:1335,y:581,t:1527635218692};\\\", \\\"{x:1333,y:581,t:1527635218710};\\\", \\\"{x:1331,y:581,t:1527635218727};\\\", \\\"{x:1330,y:581,t:1527635218744};\\\", \\\"{x:1328,y:581,t:1527635218759};\\\", \\\"{x:1325,y:581,t:1527635218776};\\\", \\\"{x:1323,y:581,t:1527635218793};\\\", \\\"{x:1319,y:581,t:1527635218810};\\\", \\\"{x:1316,y:581,t:1527635218827};\\\", \\\"{x:1315,y:581,t:1527635218844};\\\", \\\"{x:1313,y:581,t:1527635218908};\\\", \\\"{x:1312,y:581,t:1527635218940};\\\", \\\"{x:1309,y:581,t:1527635218948};\\\", \\\"{x:1309,y:582,t:1527635218961};\\\", \\\"{x:1307,y:585,t:1527635218976};\\\", \\\"{x:1303,y:591,t:1527635218994};\\\", \\\"{x:1296,y:603,t:1527635219010};\\\", \\\"{x:1285,y:633,t:1527635219027};\\\", \\\"{x:1280,y:654,t:1527635219044};\\\", \\\"{x:1272,y:670,t:1527635219060};\\\", \\\"{x:1272,y:692,t:1527635219077};\\\", \\\"{x:1271,y:717,t:1527635219093};\\\", \\\"{x:1274,y:742,t:1527635219110};\\\", \\\"{x:1279,y:767,t:1527635219128};\\\", \\\"{x:1281,y:784,t:1527635219144};\\\", \\\"{x:1285,y:796,t:1527635219161};\\\", \\\"{x:1285,y:803,t:1527635219177};\\\", \\\"{x:1285,y:812,t:1527635219194};\\\", \\\"{x:1284,y:825,t:1527635219211};\\\", \\\"{x:1282,y:843,t:1527635219228};\\\", \\\"{x:1282,y:848,t:1527635219244};\\\", \\\"{x:1282,y:852,t:1527635219260};\\\", \\\"{x:1282,y:856,t:1527635219276};\\\", \\\"{x:1282,y:857,t:1527635219323};\\\", \\\"{x:1281,y:857,t:1527635219443};\\\", \\\"{x:1280,y:857,t:1527635219475};\\\", \\\"{x:1279,y:857,t:1527635219507};\\\", \\\"{x:1278,y:857,t:1527635219531};\\\", \\\"{x:1279,y:858,t:1527635219900};\\\", \\\"{x:1280,y:858,t:1527635219912};\\\", \\\"{x:1281,y:859,t:1527635219929};\\\", \\\"{x:1283,y:859,t:1527635219956};\\\", \\\"{x:1284,y:859,t:1527635219963};\\\", \\\"{x:1284,y:860,t:1527635220372};\\\", \\\"{x:1284,y:861,t:1527635220452};\\\", \\\"{x:1284,y:862,t:1527635220463};\\\", \\\"{x:1283,y:863,t:1527635220481};\\\", \\\"{x:1282,y:864,t:1527635220497};\\\", \\\"{x:1279,y:866,t:1527635220513};\\\", \\\"{x:1278,y:867,t:1527635220530};\\\", \\\"{x:1275,y:869,t:1527635220548};\\\", \\\"{x:1272,y:872,t:1527635220571};\\\", \\\"{x:1271,y:873,t:1527635220596};\\\", \\\"{x:1270,y:874,t:1527635220604};\\\", \\\"{x:1270,y:876,t:1527635220620};\\\", \\\"{x:1270,y:877,t:1527635220636};\\\", \\\"{x:1269,y:879,t:1527635220648};\\\", \\\"{x:1268,y:880,t:1527635220664};\\\", \\\"{x:1267,y:882,t:1527635220681};\\\", \\\"{x:1266,y:885,t:1527635220698};\\\", \\\"{x:1266,y:887,t:1527635220715};\\\", \\\"{x:1266,y:889,t:1527635220731};\\\", \\\"{x:1263,y:893,t:1527635220747};\\\", \\\"{x:1263,y:897,t:1527635220764};\\\", \\\"{x:1263,y:900,t:1527635220782};\\\", \\\"{x:1263,y:904,t:1527635220797};\\\", \\\"{x:1263,y:907,t:1527635220815};\\\", \\\"{x:1263,y:910,t:1527635220832};\\\", \\\"{x:1263,y:913,t:1527635220848};\\\", \\\"{x:1263,y:919,t:1527635220865};\\\", \\\"{x:1264,y:923,t:1527635220881};\\\", \\\"{x:1265,y:928,t:1527635220898};\\\", \\\"{x:1265,y:930,t:1527635220914};\\\", \\\"{x:1267,y:932,t:1527635220932};\\\", \\\"{x:1268,y:933,t:1527635220949};\\\", \\\"{x:1268,y:935,t:1527635220965};\\\", \\\"{x:1269,y:935,t:1527635220981};\\\", \\\"{x:1270,y:936,t:1527635220999};\\\", \\\"{x:1271,y:936,t:1527635221076};\\\", \\\"{x:1272,y:936,t:1527635221092};\\\", \\\"{x:1273,y:936,t:1527635221196};\\\", \\\"{x:1274,y:936,t:1527635221228};\\\", \\\"{x:1275,y:936,t:1527635221244};\\\", \\\"{x:1276,y:935,t:1527635221252};\\\", \\\"{x:1277,y:933,t:1527635221266};\\\", \\\"{x:1279,y:930,t:1527635221283};\\\", \\\"{x:1280,y:928,t:1527635221299};\\\", \\\"{x:1281,y:920,t:1527635221316};\\\", \\\"{x:1283,y:915,t:1527635221333};\\\", \\\"{x:1284,y:908,t:1527635221349};\\\", \\\"{x:1284,y:904,t:1527635221366};\\\", \\\"{x:1285,y:895,t:1527635221383};\\\", \\\"{x:1285,y:883,t:1527635221400};\\\", \\\"{x:1286,y:870,t:1527635221416};\\\", \\\"{x:1286,y:855,t:1527635221433};\\\", \\\"{x:1286,y:835,t:1527635221449};\\\", \\\"{x:1284,y:818,t:1527635221466};\\\", \\\"{x:1283,y:805,t:1527635221482};\\\", \\\"{x:1281,y:787,t:1527635221499};\\\", \\\"{x:1278,y:775,t:1527635221516};\\\", \\\"{x:1276,y:766,t:1527635221533};\\\", \\\"{x:1273,y:759,t:1527635221550};\\\", \\\"{x:1272,y:754,t:1527635221566};\\\", \\\"{x:1272,y:752,t:1527635221583};\\\", \\\"{x:1272,y:751,t:1527635221603};\\\", \\\"{x:1272,y:752,t:1527635221764};\\\", \\\"{x:1272,y:756,t:1527635221772};\\\", \\\"{x:1274,y:761,t:1527635221784};\\\", \\\"{x:1278,y:770,t:1527635221799};\\\", \\\"{x:1279,y:772,t:1527635221816};\\\", \\\"{x:1280,y:777,t:1527635221832};\\\", \\\"{x:1282,y:780,t:1527635221850};\\\", \\\"{x:1282,y:781,t:1527635221865};\\\", \\\"{x:1282,y:782,t:1527635221883};\\\", \\\"{x:1282,y:783,t:1527635221915};\\\", \\\"{x:1282,y:780,t:1527635222556};\\\", \\\"{x:1282,y:778,t:1527635222568};\\\", \\\"{x:1282,y:776,t:1527635222585};\\\", \\\"{x:1282,y:773,t:1527635222602};\\\", \\\"{x:1282,y:769,t:1527635222620};\\\", \\\"{x:1282,y:758,t:1527635222636};\\\", \\\"{x:1282,y:749,t:1527635222652};\\\", \\\"{x:1281,y:741,t:1527635222668};\\\", \\\"{x:1280,y:731,t:1527635222685};\\\", \\\"{x:1277,y:722,t:1527635222702};\\\", \\\"{x:1276,y:713,t:1527635222719};\\\", \\\"{x:1275,y:706,t:1527635222735};\\\", \\\"{x:1274,y:697,t:1527635222753};\\\", \\\"{x:1273,y:692,t:1527635222768};\\\", \\\"{x:1272,y:683,t:1527635222785};\\\", \\\"{x:1272,y:677,t:1527635222803};\\\", \\\"{x:1271,y:671,t:1527635222819};\\\", \\\"{x:1270,y:662,t:1527635222836};\\\", \\\"{x:1270,y:655,t:1527635222852};\\\", \\\"{x:1270,y:648,t:1527635222869};\\\", \\\"{x:1270,y:634,t:1527635222886};\\\", \\\"{x:1270,y:619,t:1527635222903};\\\", \\\"{x:1270,y:603,t:1527635222920};\\\", \\\"{x:1269,y:590,t:1527635222936};\\\", \\\"{x:1268,y:575,t:1527635222952};\\\", \\\"{x:1267,y:561,t:1527635222970};\\\", \\\"{x:1267,y:541,t:1527635222986};\\\", \\\"{x:1267,y:525,t:1527635223002};\\\", \\\"{x:1267,y:510,t:1527635223020};\\\", \\\"{x:1265,y:504,t:1527635223036};\\\", \\\"{x:1264,y:500,t:1527635223053};\\\", \\\"{x:1264,y:499,t:1527635223069};\\\", \\\"{x:1264,y:497,t:1527635223087};\\\", \\\"{x:1264,y:498,t:1527635223330};\\\", \\\"{x:1264,y:505,t:1527635223337};\\\", \\\"{x:1263,y:515,t:1527635223353};\\\", \\\"{x:1260,y:534,t:1527635223369};\\\", \\\"{x:1260,y:553,t:1527635223385};\\\", \\\"{x:1260,y:577,t:1527635223402};\\\", \\\"{x:1260,y:594,t:1527635223420};\\\", \\\"{x:1258,y:611,t:1527635223437};\\\", \\\"{x:1255,y:633,t:1527635223452};\\\", \\\"{x:1251,y:655,t:1527635223470};\\\", \\\"{x:1247,y:680,t:1527635223487};\\\", \\\"{x:1240,y:701,t:1527635223503};\\\", \\\"{x:1233,y:719,t:1527635223520};\\\", \\\"{x:1223,y:735,t:1527635223537};\\\", \\\"{x:1211,y:745,t:1527635223553};\\\", \\\"{x:1199,y:753,t:1527635223570};\\\", \\\"{x:1175,y:764,t:1527635223587};\\\", \\\"{x:1152,y:772,t:1527635223604};\\\", \\\"{x:1126,y:779,t:1527635223620};\\\", \\\"{x:1090,y:785,t:1527635223637};\\\", \\\"{x:1050,y:788,t:1527635223654};\\\", \\\"{x:996,y:788,t:1527635223670};\\\", \\\"{x:943,y:788,t:1527635223687};\\\", \\\"{x:860,y:788,t:1527635223704};\\\", \\\"{x:785,y:788,t:1527635223721};\\\", \\\"{x:718,y:787,t:1527635223737};\\\", \\\"{x:689,y:785,t:1527635223754};\\\", \\\"{x:620,y:773,t:1527635223772};\\\", \\\"{x:598,y:771,t:1527635223788};\\\", \\\"{x:593,y:768,t:1527635223805};\\\", \\\"{x:590,y:768,t:1527635223822};\\\", \\\"{x:589,y:767,t:1527635223837};\\\", \\\"{x:586,y:765,t:1527635223854};\\\", \\\"{x:579,y:760,t:1527635223871};\\\", \\\"{x:565,y:752,t:1527635223887};\\\", \\\"{x:546,y:742,t:1527635223905};\\\", \\\"{x:522,y:732,t:1527635223921};\\\", \\\"{x:494,y:721,t:1527635223939};\\\", \\\"{x:474,y:716,t:1527635223954};\\\", \\\"{x:451,y:710,t:1527635223970};\\\", \\\"{x:444,y:707,t:1527635223988};\\\", \\\"{x:442,y:706,t:1527635224003};\\\", \\\"{x:441,y:705,t:1527635224021};\\\", \\\"{x:440,y:705,t:1527635224038};\\\", \\\"{x:438,y:704,t:1527635224055};\\\", \\\"{x:437,y:703,t:1527635224071};\\\", \\\"{x:435,y:701,t:1527635224091};\\\", \\\"{x:435,y:700,t:1527635224114};\\\", \\\"{x:435,y:699,t:1527635224131};\\\", \\\"{x:434,y:699,t:1527635224154};\\\", \\\"{x:434,y:697,t:1527635224187};\\\", \\\"{x:434,y:696,t:1527635224211};\\\", \\\"{x:434,y:694,t:1527635224235};\\\", \\\"{x:434,y:693,t:1527635224252};\\\", \\\"{x:434,y:691,t:1527635224275};\\\", \\\"{x:434,y:690,t:1527635224299};\\\", \\\"{x:434,y:688,t:1527635224338};\\\", \\\"{x:434,y:687,t:1527635224355};\\\", \\\"{x:434,y:685,t:1527635224372};\\\", \\\"{x:434,y:684,t:1527635224389};\\\", \\\"{x:434,y:683,t:1527635224405};\\\", \\\"{x:436,y:681,t:1527635224422};\\\", \\\"{x:436,y:680,t:1527635224439};\\\", \\\"{x:437,y:680,t:1527635224455};\\\", \\\"{x:440,y:677,t:1527635224472};\\\", \\\"{x:442,y:675,t:1527635224489};\\\", \\\"{x:446,y:672,t:1527635224506};\\\", \\\"{x:452,y:666,t:1527635224522};\\\", \\\"{x:457,y:662,t:1527635224539};\\\", \\\"{x:462,y:660,t:1527635224562};\\\", \\\"{x:467,y:655,t:1527635224579};\\\", \\\"{x:477,y:650,t:1527635224596};\\\", \\\"{x:486,y:644,t:1527635224613};\\\", \\\"{x:497,y:637,t:1527635224629};\\\", \\\"{x:504,y:631,t:1527635224646};\\\", \\\"{x:510,y:626,t:1527635224663};\\\", \\\"{x:516,y:624,t:1527635224679};\\\", \\\"{x:520,y:621,t:1527635224696};\\\", \\\"{x:523,y:619,t:1527635224713};\\\", \\\"{x:531,y:615,t:1527635224729};\\\", \\\"{x:543,y:608,t:1527635224746};\\\", \\\"{x:553,y:600,t:1527635224763};\\\", \\\"{x:558,y:597,t:1527635224780};\\\", \\\"{x:563,y:595,t:1527635224796};\\\", \\\"{x:572,y:591,t:1527635224813};\\\", \\\"{x:580,y:587,t:1527635224829};\\\", \\\"{x:595,y:583,t:1527635224846};\\\", \\\"{x:613,y:580,t:1527635224864};\\\", \\\"{x:638,y:577,t:1527635224879};\\\", \\\"{x:668,y:575,t:1527635224896};\\\", \\\"{x:694,y:574,t:1527635224913};\\\", \\\"{x:719,y:574,t:1527635224929};\\\", \\\"{x:755,y:574,t:1527635224946};\\\", \\\"{x:804,y:574,t:1527635224962};\\\", \\\"{x:835,y:575,t:1527635224980};\\\", \\\"{x:861,y:579,t:1527635224996};\\\", \\\"{x:882,y:582,t:1527635225013};\\\", \\\"{x:900,y:585,t:1527635225030};\\\", \\\"{x:922,y:591,t:1527635225046};\\\", \\\"{x:947,y:596,t:1527635225062};\\\", \\\"{x:977,y:603,t:1527635225080};\\\", \\\"{x:1009,y:613,t:1527635225096};\\\", \\\"{x:1049,y:620,t:1527635225113};\\\", \\\"{x:1103,y:631,t:1527635225130};\\\", \\\"{x:1152,y:642,t:1527635225146};\\\", \\\"{x:1196,y:658,t:1527635225164};\\\", \\\"{x:1219,y:663,t:1527635225180};\\\", \\\"{x:1246,y:674,t:1527635225196};\\\", \\\"{x:1273,y:685,t:1527635225213};\\\", \\\"{x:1299,y:695,t:1527635225230};\\\", \\\"{x:1326,y:704,t:1527635225246};\\\", \\\"{x:1355,y:716,t:1527635225263};\\\", \\\"{x:1378,y:725,t:1527635225280};\\\", \\\"{x:1398,y:736,t:1527635225296};\\\", \\\"{x:1419,y:743,t:1527635225313};\\\", \\\"{x:1432,y:748,t:1527635225330};\\\", \\\"{x:1449,y:755,t:1527635225347};\\\", \\\"{x:1456,y:758,t:1527635225363};\\\", \\\"{x:1457,y:758,t:1527635225387};\\\", \\\"{x:1457,y:759,t:1527635225404};\\\", \\\"{x:1456,y:761,t:1527635226092};\\\", \\\"{x:1453,y:762,t:1527635226100};\\\", \\\"{x:1449,y:764,t:1527635226115};\\\", \\\"{x:1439,y:766,t:1527635226131};\\\", \\\"{x:1424,y:767,t:1527635226148};\\\", \\\"{x:1412,y:771,t:1527635226164};\\\", \\\"{x:1408,y:771,t:1527635226180};\\\", \\\"{x:1402,y:772,t:1527635226197};\\\", \\\"{x:1399,y:772,t:1527635226213};\\\", \\\"{x:1396,y:773,t:1527635226231};\\\", \\\"{x:1391,y:774,t:1527635226247};\\\", \\\"{x:1386,y:774,t:1527635226264};\\\", \\\"{x:1381,y:775,t:1527635226281};\\\", \\\"{x:1372,y:777,t:1527635226297};\\\", \\\"{x:1362,y:778,t:1527635226314};\\\", \\\"{x:1351,y:779,t:1527635226330};\\\", \\\"{x:1344,y:781,t:1527635226347};\\\", \\\"{x:1340,y:781,t:1527635226364};\\\", \\\"{x:1339,y:782,t:1527635226381};\\\", \\\"{x:1337,y:782,t:1527635226403};\\\", \\\"{x:1336,y:783,t:1527635226427};\\\", \\\"{x:1335,y:783,t:1527635226435};\\\", \\\"{x:1334,y:784,t:1527635226447};\\\", \\\"{x:1333,y:785,t:1527635226464};\\\", \\\"{x:1330,y:786,t:1527635226481};\\\", \\\"{x:1326,y:789,t:1527635226498};\\\", \\\"{x:1321,y:794,t:1527635226514};\\\", \\\"{x:1316,y:803,t:1527635226531};\\\", \\\"{x:1313,y:809,t:1527635226548};\\\", \\\"{x:1312,y:815,t:1527635226565};\\\", \\\"{x:1309,y:822,t:1527635226582};\\\", \\\"{x:1308,y:827,t:1527635226598};\\\", \\\"{x:1308,y:833,t:1527635226615};\\\", \\\"{x:1306,y:836,t:1527635226632};\\\", \\\"{x:1305,y:839,t:1527635226648};\\\", \\\"{x:1305,y:842,t:1527635226665};\\\", \\\"{x:1305,y:846,t:1527635226681};\\\", \\\"{x:1305,y:847,t:1527635226698};\\\", \\\"{x:1305,y:849,t:1527635226715};\\\", \\\"{x:1305,y:855,t:1527635226731};\\\", \\\"{x:1305,y:857,t:1527635226748};\\\", \\\"{x:1305,y:858,t:1527635226764};\\\", \\\"{x:1305,y:859,t:1527635226782};\\\", \\\"{x:1305,y:860,t:1527635226803};\\\", \\\"{x:1305,y:861,t:1527635226815};\\\", \\\"{x:1305,y:862,t:1527635226832};\\\", \\\"{x:1305,y:863,t:1527635226850};\\\", \\\"{x:1305,y:864,t:1527635226864};\\\", \\\"{x:1305,y:865,t:1527635226881};\\\", \\\"{x:1304,y:865,t:1527635226907};\\\", \\\"{x:1304,y:866,t:1527635226987};\\\", \\\"{x:1302,y:869,t:1527635227340};\\\", \\\"{x:1297,y:871,t:1527635227349};\\\", \\\"{x:1277,y:874,t:1527635227366};\\\", \\\"{x:1247,y:874,t:1527635227382};\\\", \\\"{x:1200,y:874,t:1527635227399};\\\", \\\"{x:1113,y:874,t:1527635227415};\\\", \\\"{x:1029,y:870,t:1527635227432};\\\", \\\"{x:944,y:862,t:1527635227449};\\\", \\\"{x:875,y:856,t:1527635227465};\\\", \\\"{x:823,y:853,t:1527635227482};\\\", \\\"{x:795,y:853,t:1527635227498};\\\", \\\"{x:767,y:850,t:1527635227514};\\\", \\\"{x:763,y:850,t:1527635227532};\\\", \\\"{x:762,y:850,t:1527635227548};\\\", \\\"{x:761,y:850,t:1527635227643};\\\", \\\"{x:760,y:849,t:1527635227674};\\\", \\\"{x:759,y:849,t:1527635227714};\\\", \\\"{x:758,y:849,t:1527635227723};\\\", \\\"{x:758,y:848,t:1527635227739};\\\", \\\"{x:757,y:848,t:1527635227770};\\\", \\\"{x:756,y:848,t:1527635227827};\\\", \\\"{x:755,y:848,t:1527635227843};\\\", \\\"{x:755,y:847,t:1527635231972};\\\", \\\"{x:759,y:844,t:1527635231985};\\\", \\\"{x:780,y:840,t:1527635232003};\\\", \\\"{x:806,y:841,t:1527635232019};\\\", \\\"{x:831,y:841,t:1527635232035};\\\", \\\"{x:857,y:841,t:1527635232052};\\\", \\\"{x:880,y:841,t:1527635232069};\\\", \\\"{x:905,y:841,t:1527635232086};\\\", \\\"{x:934,y:841,t:1527635232103};\\\", \\\"{x:975,y:839,t:1527635232119};\\\", \\\"{x:1011,y:835,t:1527635232137};\\\", \\\"{x:1059,y:828,t:1527635232153};\\\", \\\"{x:1095,y:825,t:1527635232170};\\\", \\\"{x:1134,y:825,t:1527635232185};\\\", \\\"{x:1162,y:824,t:1527635232202};\\\", \\\"{x:1183,y:819,t:1527635232219};\\\", \\\"{x:1192,y:816,t:1527635232236};\\\", \\\"{x:1199,y:814,t:1527635232253};\\\", \\\"{x:1207,y:811,t:1527635232270};\\\", \\\"{x:1219,y:807,t:1527635232287};\\\", \\\"{x:1228,y:803,t:1527635232303};\\\", \\\"{x:1237,y:800,t:1527635232320};\\\", \\\"{x:1245,y:798,t:1527635232337};\\\", \\\"{x:1248,y:797,t:1527635232353};\\\", \\\"{x:1249,y:797,t:1527635232370};\\\", \\\"{x:1250,y:795,t:1527635232396};\\\", \\\"{x:1251,y:795,t:1527635232403};\\\", \\\"{x:1252,y:793,t:1527635232420};\\\", \\\"{x:1253,y:793,t:1527635232437};\\\", \\\"{x:1253,y:792,t:1527635232453};\\\", \\\"{x:1255,y:791,t:1527635232470};\\\", \\\"{x:1257,y:789,t:1527635232486};\\\", \\\"{x:1259,y:787,t:1527635232502};\\\", \\\"{x:1264,y:783,t:1527635232520};\\\", \\\"{x:1267,y:780,t:1527635232537};\\\", \\\"{x:1268,y:779,t:1527635232553};\\\", \\\"{x:1269,y:777,t:1527635232570};\\\", \\\"{x:1271,y:774,t:1527635232587};\\\", \\\"{x:1272,y:773,t:1527635232603};\\\", \\\"{x:1273,y:772,t:1527635232620};\\\", \\\"{x:1274,y:772,t:1527635232637};\\\", \\\"{x:1274,y:771,t:1527635232653};\\\", \\\"{x:1275,y:770,t:1527635232748};\\\", \\\"{x:1276,y:769,t:1527635233124};\\\", \\\"{x:1277,y:768,t:1527635233139};\\\", \\\"{x:1279,y:768,t:1527635233188};\\\", \\\"{x:1279,y:767,t:1527635233427};\\\", \\\"{x:1280,y:767,t:1527635233522};\\\", \\\"{x:1281,y:767,t:1527635234651};\\\", \\\"{x:1281,y:768,t:1527635234660};\\\", \\\"{x:1281,y:769,t:1527635234672};\\\", \\\"{x:1281,y:770,t:1527635234707};\\\", \\\"{x:1281,y:771,t:1527635234722};\\\", \\\"{x:1281,y:772,t:1527635234740};\\\", \\\"{x:1281,y:773,t:1527635234803};\\\", \\\"{x:1281,y:774,t:1527635234844};\\\", \\\"{x:1281,y:775,t:1527635234859};\\\", \\\"{x:1281,y:776,t:1527635234916};\\\", \\\"{x:1281,y:777,t:1527635234931};\\\", \\\"{x:1281,y:778,t:1527635234939};\\\", \\\"{x:1281,y:779,t:1527635235060};\\\", \\\"{x:1281,y:780,t:1527635235099};\\\", \\\"{x:1275,y:785,t:1527635237373};\\\", \\\"{x:1222,y:802,t:1527635237392};\\\", \\\"{x:1111,y:804,t:1527635237407};\\\", \\\"{x:981,y:804,t:1527635237424};\\\", \\\"{x:845,y:804,t:1527635237441};\\\", \\\"{x:720,y:803,t:1527635237457};\\\", \\\"{x:628,y:799,t:1527635237474};\\\", \\\"{x:559,y:796,t:1527635237492};\\\", \\\"{x:531,y:795,t:1527635237507};\\\", \\\"{x:521,y:794,t:1527635237524};\\\", \\\"{x:520,y:794,t:1527635237540};\\\", \\\"{x:518,y:793,t:1527635237579};\\\", \\\"{x:516,y:790,t:1527635237595};\\\", \\\"{x:515,y:785,t:1527635237608};\\\", \\\"{x:511,y:775,t:1527635237624};\\\", \\\"{x:505,y:765,t:1527635237641};\\\", \\\"{x:497,y:749,t:1527635237658};\\\", \\\"{x:488,y:730,t:1527635237674};\\\", \\\"{x:483,y:709,t:1527635237691};\\\", \\\"{x:480,y:700,t:1527635237707};\\\", \\\"{x:479,y:693,t:1527635237724};\\\", \\\"{x:479,y:688,t:1527635237742};\\\", \\\"{x:479,y:683,t:1527635237758};\\\", \\\"{x:479,y:678,t:1527635237775};\\\", \\\"{x:479,y:674,t:1527635237790};\\\", \\\"{x:479,y:671,t:1527635237807};\\\", \\\"{x:479,y:669,t:1527635237823};\\\", \\\"{x:479,y:667,t:1527635237839};\\\", \\\"{x:479,y:666,t:1527635237857};\\\", \\\"{x:479,y:665,t:1527635237874};\\\", \\\"{x:479,y:663,t:1527635237889};\\\", \\\"{x:482,y:659,t:1527635237907};\\\", \\\"{x:482,y:658,t:1527635237924};\\\", \\\"{x:484,y:656,t:1527635237939};\\\", \\\"{x:485,y:656,t:1527635237957};\\\", \\\"{x:485,y:655,t:1527635237974};\\\", \\\"{x:486,y:655,t:1527635237990};\\\", \\\"{x:487,y:654,t:1527635238027};\\\", \\\"{x:487,y:653,t:1527635238067};\\\", \\\"{x:486,y:653,t:1527635238780};\\\", \\\"{x:485,y:654,t:1527635238811};\\\", \\\"{x:483,y:655,t:1527635238835};\\\", \\\"{x:482,y:655,t:1527635238876};\\\", \\\"{x:482,y:656,t:1527635238891};\\\", \\\"{x:481,y:656,t:1527635238908};\\\", \\\"{x:480,y:658,t:1527635238925};\\\", \\\"{x:479,y:659,t:1527635238941};\\\", \\\"{x:478,y:660,t:1527635238958};\\\", \\\"{x:477,y:661,t:1527635238987};\\\", \\\"{x:477,y:662,t:1527635238995};\\\", \\\"{x:476,y:662,t:1527635239019};\\\", \\\"{x:476,y:663,t:1527635239076};\\\", \\\"{x:475,y:664,t:1527635239132};\\\", \\\"{x:475,y:665,t:1527635239252};\\\", \\\"{x:478,y:666,t:1527635239371};\\\", \\\"{x:481,y:666,t:1527635239378};\\\", \\\"{x:483,y:666,t:1527635239391};\\\", \\\"{x:486,y:667,t:1527635239407};\\\", \\\"{x:493,y:667,t:1527635239425};\\\", \\\"{x:501,y:667,t:1527635239442};\\\", \\\"{x:515,y:667,t:1527635239457};\\\", \\\"{x:535,y:667,t:1527635239474};\\\", \\\"{x:549,y:667,t:1527635239491};\\\", \\\"{x:563,y:667,t:1527635239508};\\\", \\\"{x:579,y:667,t:1527635239525};\\\", \\\"{x:604,y:667,t:1527635239541};\\\", \\\"{x:628,y:666,t:1527635239557};\\\", \\\"{x:656,y:666,t:1527635239574};\\\", \\\"{x:690,y:666,t:1527635239591};\\\", \\\"{x:722,y:663,t:1527635239607};\\\", \\\"{x:764,y:657,t:1527635239625};\\\", \\\"{x:803,y:652,t:1527635239641};\\\", \\\"{x:846,y:645,t:1527635239658};\\\", \\\"{x:929,y:632,t:1527635239674};\\\", \\\"{x:979,y:624,t:1527635239691};\\\", \\\"{x:1021,y:615,t:1527635239708};\\\", \\\"{x:1059,y:607,t:1527635239725};\\\", \\\"{x:1086,y:600,t:1527635239742};\\\", \\\"{x:1109,y:595,t:1527635239757};\\\", \\\"{x:1127,y:590,t:1527635239775};\\\", \\\"{x:1153,y:589,t:1527635239792};\\\", \\\"{x:1183,y:584,t:1527635239807};\\\", \\\"{x:1209,y:579,t:1527635239825};\\\", \\\"{x:1238,y:577,t:1527635239842};\\\", \\\"{x:1263,y:572,t:1527635239858};\\\", \\\"{x:1286,y:570,t:1527635239875};\\\", \\\"{x:1293,y:570,t:1527635239892};\\\", \\\"{x:1296,y:569,t:1527635239909};\\\", \\\"{x:1298,y:569,t:1527635239925};\\\", \\\"{x:1300,y:568,t:1527635239942};\\\", \\\"{x:1294,y:568,t:1527635240332};\\\", \\\"{x:1290,y:569,t:1527635240343};\\\", \\\"{x:1280,y:570,t:1527635240359};\\\", \\\"{x:1270,y:571,t:1527635240375};\\\", \\\"{x:1259,y:573,t:1527635240392};\\\", \\\"{x:1246,y:575,t:1527635240409};\\\", \\\"{x:1233,y:578,t:1527635240425};\\\", \\\"{x:1216,y:579,t:1527635240445};\\\", \\\"{x:1211,y:580,t:1527635240459};\\\", \\\"{x:1205,y:580,t:1527635240476};\\\", \\\"{x:1197,y:582,t:1527635240491};\\\", \\\"{x:1192,y:583,t:1527635240508};\\\", \\\"{x:1186,y:584,t:1527635240525};\\\", \\\"{x:1180,y:585,t:1527635240542};\\\", \\\"{x:1174,y:587,t:1527635240559};\\\", \\\"{x:1170,y:588,t:1527635240576};\\\", \\\"{x:1164,y:590,t:1527635240591};\\\", \\\"{x:1161,y:591,t:1527635240608};\\\", \\\"{x:1157,y:592,t:1527635240626};\\\", \\\"{x:1151,y:594,t:1527635240642};\\\", \\\"{x:1145,y:596,t:1527635240659};\\\", \\\"{x:1139,y:599,t:1527635240676};\\\", \\\"{x:1132,y:602,t:1527635240692};\\\", \\\"{x:1126,y:605,t:1527635240709};\\\", \\\"{x:1118,y:608,t:1527635240726};\\\", \\\"{x:1114,y:610,t:1527635240742};\\\", \\\"{x:1110,y:612,t:1527635240759};\\\", \\\"{x:1107,y:615,t:1527635240776};\\\", \\\"{x:1103,y:616,t:1527635240792};\\\", \\\"{x:1100,y:619,t:1527635240809};\\\", \\\"{x:1097,y:622,t:1527635240827};\\\", \\\"{x:1090,y:627,t:1527635240843};\\\", \\\"{x:1087,y:630,t:1527635240858};\\\", \\\"{x:1084,y:634,t:1527635240877};\\\", \\\"{x:1082,y:637,t:1527635240891};\\\", \\\"{x:1079,y:641,t:1527635240909};\\\", \\\"{x:1074,y:649,t:1527635240926};\\\", \\\"{x:1072,y:653,t:1527635240942};\\\", \\\"{x:1070,y:661,t:1527635240959};\\\", \\\"{x:1070,y:665,t:1527635240976};\\\", \\\"{x:1070,y:669,t:1527635240993};\\\", \\\"{x:1068,y:673,t:1527635241009};\\\", \\\"{x:1068,y:679,t:1527635241026};\\\", \\\"{x:1068,y:692,t:1527635241043};\\\", \\\"{x:1072,y:699,t:1527635241059};\\\", \\\"{x:1076,y:707,t:1527635241076};\\\", \\\"{x:1078,y:713,t:1527635241093};\\\", \\\"{x:1082,y:718,t:1527635241109};\\\", \\\"{x:1089,y:728,t:1527635241126};\\\", \\\"{x:1096,y:738,t:1527635241143};\\\", \\\"{x:1105,y:750,t:1527635241159};\\\", \\\"{x:1112,y:762,t:1527635241176};\\\", \\\"{x:1122,y:775,t:1527635241193};\\\", \\\"{x:1130,y:785,t:1527635241210};\\\", \\\"{x:1138,y:796,t:1527635241226};\\\", \\\"{x:1152,y:811,t:1527635241244};\\\", \\\"{x:1163,y:821,t:1527635241259};\\\", \\\"{x:1176,y:833,t:1527635241277};\\\", \\\"{x:1192,y:846,t:1527635241293};\\\", \\\"{x:1210,y:862,t:1527635241309};\\\", \\\"{x:1224,y:872,t:1527635241326};\\\", \\\"{x:1240,y:883,t:1527635241343};\\\", \\\"{x:1251,y:891,t:1527635241360};\\\", \\\"{x:1264,y:902,t:1527635241376};\\\", \\\"{x:1275,y:910,t:1527635241394};\\\", \\\"{x:1287,y:920,t:1527635241410};\\\", \\\"{x:1295,y:928,t:1527635241426};\\\", \\\"{x:1311,y:942,t:1527635241444};\\\", \\\"{x:1321,y:951,t:1527635241459};\\\", \\\"{x:1330,y:959,t:1527635241477};\\\", \\\"{x:1334,y:964,t:1527635241493};\\\", \\\"{x:1336,y:968,t:1527635241510};\\\", \\\"{x:1337,y:968,t:1527635241526};\\\", \\\"{x:1339,y:969,t:1527635241543};\\\", \\\"{x:1337,y:969,t:1527635242363};\\\", \\\"{x:1335,y:969,t:1527635242377};\\\", \\\"{x:1332,y:969,t:1527635242395};\\\", \\\"{x:1325,y:969,t:1527635242410};\\\", \\\"{x:1317,y:966,t:1527635242427};\\\", \\\"{x:1310,y:966,t:1527635242444};\\\", \\\"{x:1307,y:964,t:1527635242461};\\\", \\\"{x:1301,y:963,t:1527635242477};\\\", \\\"{x:1293,y:962,t:1527635242494};\\\", \\\"{x:1289,y:961,t:1527635242510};\\\", \\\"{x:1287,y:960,t:1527635242528};\\\", \\\"{x:1286,y:960,t:1527635242544};\\\", \\\"{x:1285,y:960,t:1527635242560};\\\", \\\"{x:1284,y:960,t:1527635242588};\\\", \\\"{x:1283,y:960,t:1527635242603};\\\", \\\"{x:1283,y:959,t:1527635242620};\\\", \\\"{x:1282,y:959,t:1527635242627};\\\", \\\"{x:1280,y:959,t:1527635242644};\\\", \\\"{x:1280,y:958,t:1527635242660};\\\", \\\"{x:1278,y:958,t:1527635242691};\\\", \\\"{x:1277,y:958,t:1527635242699};\\\", \\\"{x:1275,y:957,t:1527635242710};\\\", \\\"{x:1273,y:953,t:1527635242727};\\\", \\\"{x:1270,y:949,t:1527635242744};\\\", \\\"{x:1265,y:939,t:1527635242760};\\\", \\\"{x:1261,y:930,t:1527635242777};\\\", \\\"{x:1260,y:920,t:1527635242794};\\\", \\\"{x:1255,y:905,t:1527635242811};\\\", \\\"{x:1251,y:883,t:1527635242828};\\\", \\\"{x:1249,y:870,t:1527635242845};\\\", \\\"{x:1245,y:860,t:1527635242861};\\\", \\\"{x:1244,y:848,t:1527635242877};\\\", \\\"{x:1244,y:840,t:1527635242895};\\\", \\\"{x:1246,y:830,t:1527635242911};\\\", \\\"{x:1246,y:825,t:1527635242927};\\\", \\\"{x:1248,y:817,t:1527635242944};\\\", \\\"{x:1250,y:813,t:1527635242962};\\\", \\\"{x:1254,y:808,t:1527635242977};\\\", \\\"{x:1256,y:804,t:1527635242995};\\\", \\\"{x:1258,y:801,t:1527635243011};\\\", \\\"{x:1260,y:799,t:1527635243035};\\\", \\\"{x:1261,y:799,t:1527635243044};\\\", \\\"{x:1261,y:798,t:1527635243062};\\\", \\\"{x:1265,y:795,t:1527635243078};\\\", \\\"{x:1268,y:793,t:1527635243095};\\\", \\\"{x:1268,y:792,t:1527635243112};\\\", \\\"{x:1269,y:791,t:1527635243127};\\\", \\\"{x:1270,y:791,t:1527635243144};\\\", \\\"{x:1271,y:790,t:1527635243187};\\\", \\\"{x:1271,y:789,t:1527635243195};\\\", \\\"{x:1272,y:788,t:1527635243212};\\\", \\\"{x:1273,y:786,t:1527635243235};\\\", \\\"{x:1274,y:785,t:1527635243268};\\\", \\\"{x:1274,y:784,t:1527635243308};\\\", \\\"{x:1274,y:783,t:1527635243323};\\\", \\\"{x:1267,y:782,t:1527635243828};\\\", \\\"{x:1177,y:782,t:1527635243845};\\\", \\\"{x:1003,y:782,t:1527635243861};\\\", \\\"{x:768,y:778,t:1527635243878};\\\", \\\"{x:550,y:778,t:1527635243895};\\\", \\\"{x:389,y:773,t:1527635243911};\\\", \\\"{x:299,y:768,t:1527635243928};\\\", \\\"{x:264,y:763,t:1527635243945};\\\", \\\"{x:255,y:760,t:1527635243962};\\\", \\\"{x:254,y:759,t:1527635243979};\\\", \\\"{x:254,y:757,t:1527635244051};\\\", \\\"{x:258,y:751,t:1527635244061};\\\", \\\"{x:272,y:738,t:1527635244079};\\\", \\\"{x:289,y:725,t:1527635244095};\\\", \\\"{x:310,y:713,t:1527635244111};\\\", \\\"{x:333,y:695,t:1527635244128};\\\", \\\"{x:360,y:686,t:1527635244146};\\\", \\\"{x:382,y:672,t:1527635244161};\\\", \\\"{x:410,y:664,t:1527635244178};\\\", \\\"{x:444,y:648,t:1527635244195};\\\", \\\"{x:467,y:638,t:1527635244211};\\\", \\\"{x:488,y:633,t:1527635244228};\\\", \\\"{x:507,y:630,t:1527635244245};\\\", \\\"{x:518,y:628,t:1527635244262};\\\", \\\"{x:523,y:627,t:1527635244277};\\\", \\\"{x:526,y:627,t:1527635244295};\\\", \\\"{x:527,y:627,t:1527635244312};\\\", \\\"{x:530,y:627,t:1527635244328};\\\", \\\"{x:531,y:627,t:1527635244345};\\\", \\\"{x:533,y:627,t:1527635244361};\\\", \\\"{x:537,y:627,t:1527635244377};\\\", \\\"{x:542,y:630,t:1527635244394};\\\", \\\"{x:544,y:631,t:1527635244411};\\\", \\\"{x:545,y:635,t:1527635244428};\\\", \\\"{x:546,y:638,t:1527635244445};\\\", \\\"{x:546,y:640,t:1527635244462};\\\", \\\"{x:546,y:642,t:1527635244478};\\\", \\\"{x:546,y:644,t:1527635244495};\\\", \\\"{x:546,y:645,t:1527635244515};\\\", \\\"{x:546,y:647,t:1527635244531};\\\", \\\"{x:545,y:648,t:1527635244546};\\\", \\\"{x:545,y:650,t:1527635244561};\\\", \\\"{x:543,y:652,t:1527635244578};\\\", \\\"{x:542,y:654,t:1527635244594};\\\", \\\"{x:541,y:655,t:1527635244626};\\\", \\\"{x:540,y:655,t:1527635244634};\\\", \\\"{x:539,y:657,t:1527635244650};\\\", \\\"{x:538,y:659,t:1527635244674};\\\", \\\"{x:537,y:660,t:1527635244683};\\\", \\\"{x:536,y:661,t:1527635244706};\\\", \\\"{x:537,y:662,t:1527635244979};\\\", \\\"{x:544,y:661,t:1527635244996};\\\", \\\"{x:561,y:653,t:1527635245012};\\\", \\\"{x:595,y:646,t:1527635245029};\\\", \\\"{x:634,y:635,t:1527635245046};\\\", \\\"{x:688,y:628,t:1527635245061};\\\", \\\"{x:747,y:620,t:1527635245078};\\\", \\\"{x:781,y:613,t:1527635245096};\\\", \\\"{x:805,y:611,t:1527635245112};\\\", \\\"{x:820,y:611,t:1527635245129};\\\", \\\"{x:828,y:608,t:1527635245146};\\\", \\\"{x:829,y:608,t:1527635245162};\\\", \\\"{x:830,y:608,t:1527635245195};\\\", \\\"{x:831,y:608,t:1527635245555};\\\" ] }, { \\\"rt\\\": 9661, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 165398, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"8FE87\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -E -E -D -E -E -E -E -E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:831,y:609,t:1527635246939};\\\", \\\"{x:828,y:611,t:1527635246953};\\\", \\\"{x:825,y:617,t:1527635246963};\\\", \\\"{x:819,y:627,t:1527635246980};\\\", \\\"{x:814,y:631,t:1527635246997};\\\", \\\"{x:799,y:637,t:1527635247014};\\\", \\\"{x:783,y:644,t:1527635247030};\\\", \\\"{x:768,y:649,t:1527635247047};\\\", \\\"{x:758,y:654,t:1527635247064};\\\", \\\"{x:751,y:655,t:1527635247080};\\\", \\\"{x:745,y:656,t:1527635247097};\\\", \\\"{x:742,y:658,t:1527635247113};\\\", \\\"{x:739,y:658,t:1527635247130};\\\", \\\"{x:735,y:658,t:1527635247146};\\\", \\\"{x:729,y:658,t:1527635247164};\\\", \\\"{x:722,y:658,t:1527635247181};\\\", \\\"{x:718,y:658,t:1527635247197};\\\", \\\"{x:709,y:658,t:1527635247213};\\\", \\\"{x:704,y:658,t:1527635247231};\\\", \\\"{x:696,y:658,t:1527635247247};\\\", \\\"{x:690,y:658,t:1527635247264};\\\", \\\"{x:687,y:658,t:1527635247281};\\\", \\\"{x:685,y:658,t:1527635247298};\\\", \\\"{x:683,y:657,t:1527635247315};\\\", \\\"{x:681,y:653,t:1527635247331};\\\", \\\"{x:666,y:645,t:1527635247347};\\\", \\\"{x:660,y:639,t:1527635247364};\\\", \\\"{x:660,y:640,t:1527635247779};\\\", \\\"{x:661,y:641,t:1527635247811};\\\", \\\"{x:661,y:642,t:1527635247827};\\\", \\\"{x:661,y:643,t:1527635247843};\\\", \\\"{x:662,y:643,t:1527635247859};\\\", \\\"{x:662,y:644,t:1527635247883};\\\", \\\"{x:663,y:644,t:1527635247899};\\\", \\\"{x:666,y:646,t:1527635248171};\\\", \\\"{x:673,y:646,t:1527635248181};\\\", \\\"{x:684,y:646,t:1527635248198};\\\", \\\"{x:692,y:646,t:1527635248215};\\\", \\\"{x:695,y:646,t:1527635248231};\\\", \\\"{x:696,y:646,t:1527635248258};\\\", \\\"{x:696,y:645,t:1527635248595};\\\", \\\"{x:699,y:645,t:1527635248603};\\\", \\\"{x:700,y:645,t:1527635248615};\\\", \\\"{x:703,y:645,t:1527635248632};\\\", \\\"{x:704,y:645,t:1527635248648};\\\", \\\"{x:709,y:645,t:1527635248665};\\\", \\\"{x:714,y:645,t:1527635248682};\\\", \\\"{x:720,y:645,t:1527635248698};\\\", \\\"{x:730,y:645,t:1527635248714};\\\", \\\"{x:734,y:645,t:1527635248732};\\\", \\\"{x:739,y:645,t:1527635248749};\\\", \\\"{x:741,y:645,t:1527635248765};\\\", \\\"{x:746,y:645,t:1527635248782};\\\", \\\"{x:752,y:646,t:1527635248798};\\\", \\\"{x:757,y:647,t:1527635248815};\\\", \\\"{x:763,y:647,t:1527635248832};\\\", \\\"{x:771,y:648,t:1527635248848};\\\", \\\"{x:776,y:648,t:1527635248865};\\\", \\\"{x:785,y:650,t:1527635248883};\\\", \\\"{x:797,y:652,t:1527635248899};\\\", \\\"{x:804,y:653,t:1527635248915};\\\", \\\"{x:810,y:654,t:1527635248933};\\\", \\\"{x:817,y:656,t:1527635248949};\\\", \\\"{x:823,y:656,t:1527635248965};\\\", \\\"{x:829,y:658,t:1527635248982};\\\", \\\"{x:836,y:659,t:1527635248999};\\\", \\\"{x:845,y:660,t:1527635249015};\\\", \\\"{x:859,y:663,t:1527635249032};\\\", \\\"{x:869,y:665,t:1527635249049};\\\", \\\"{x:880,y:668,t:1527635249065};\\\", \\\"{x:900,y:673,t:1527635249083};\\\", \\\"{x:915,y:675,t:1527635249099};\\\", \\\"{x:934,y:678,t:1527635249115};\\\", \\\"{x:954,y:682,t:1527635249132};\\\", \\\"{x:975,y:685,t:1527635249149};\\\", \\\"{x:998,y:688,t:1527635249166};\\\", \\\"{x:1020,y:693,t:1527635249183};\\\", \\\"{x:1049,y:697,t:1527635249200};\\\", \\\"{x:1072,y:701,t:1527635249216};\\\", \\\"{x:1099,y:704,t:1527635249232};\\\", \\\"{x:1129,y:707,t:1527635249250};\\\", \\\"{x:1158,y:709,t:1527635249266};\\\", \\\"{x:1186,y:713,t:1527635249283};\\\", \\\"{x:1237,y:716,t:1527635249299};\\\", \\\"{x:1279,y:722,t:1527635249316};\\\", \\\"{x:1324,y:722,t:1527635249332};\\\", \\\"{x:1367,y:724,t:1527635249350};\\\", \\\"{x:1400,y:727,t:1527635249366};\\\", \\\"{x:1427,y:728,t:1527635249382};\\\", \\\"{x:1453,y:728,t:1527635249399};\\\", \\\"{x:1471,y:729,t:1527635249416};\\\", \\\"{x:1491,y:732,t:1527635249433};\\\", \\\"{x:1509,y:734,t:1527635249449};\\\", \\\"{x:1535,y:737,t:1527635249466};\\\", \\\"{x:1577,y:741,t:1527635249482};\\\", \\\"{x:1680,y:750,t:1527635249499};\\\", \\\"{x:1718,y:753,t:1527635249516};\\\", \\\"{x:1729,y:753,t:1527635249532};\\\", \\\"{x:1731,y:753,t:1527635250019};\\\", \\\"{x:1731,y:754,t:1527635250123};\\\", \\\"{x:1731,y:756,t:1527635250133};\\\", \\\"{x:1730,y:757,t:1527635250155};\\\", \\\"{x:1728,y:757,t:1527635250166};\\\", \\\"{x:1728,y:758,t:1527635250183};\\\", \\\"{x:1726,y:761,t:1527635250199};\\\", \\\"{x:1724,y:761,t:1527635250216};\\\", \\\"{x:1721,y:761,t:1527635250234};\\\", \\\"{x:1718,y:763,t:1527635250250};\\\", \\\"{x:1711,y:763,t:1527635250266};\\\", \\\"{x:1704,y:765,t:1527635250283};\\\", \\\"{x:1697,y:767,t:1527635250300};\\\", \\\"{x:1696,y:767,t:1527635250316};\\\", \\\"{x:1694,y:768,t:1527635250333};\\\", \\\"{x:1692,y:769,t:1527635250349};\\\", \\\"{x:1687,y:771,t:1527635250366};\\\", \\\"{x:1684,y:771,t:1527635250384};\\\", \\\"{x:1683,y:771,t:1527635250400};\\\", \\\"{x:1681,y:771,t:1527635250416};\\\", \\\"{x:1677,y:771,t:1527635250433};\\\", \\\"{x:1669,y:771,t:1527635250452};\\\", \\\"{x:1667,y:771,t:1527635250467};\\\", \\\"{x:1663,y:770,t:1527635250483};\\\", \\\"{x:1658,y:769,t:1527635250501};\\\", \\\"{x:1648,y:767,t:1527635250516};\\\", \\\"{x:1647,y:767,t:1527635250533};\\\", \\\"{x:1646,y:766,t:1527635250551};\\\", \\\"{x:1645,y:765,t:1527635250566};\\\", \\\"{x:1644,y:761,t:1527635250583};\\\", \\\"{x:1643,y:750,t:1527635250600};\\\", \\\"{x:1642,y:720,t:1527635250616};\\\", \\\"{x:1640,y:688,t:1527635250634};\\\", \\\"{x:1633,y:617,t:1527635250651};\\\", \\\"{x:1633,y:573,t:1527635250667};\\\", \\\"{x:1633,y:525,t:1527635250684};\\\", \\\"{x:1630,y:473,t:1527635250701};\\\", \\\"{x:1626,y:435,t:1527635250716};\\\", \\\"{x:1619,y:416,t:1527635250733};\\\", \\\"{x:1615,y:403,t:1527635250750};\\\", \\\"{x:1612,y:395,t:1527635250766};\\\", \\\"{x:1612,y:392,t:1527635250783};\\\", \\\"{x:1611,y:390,t:1527635250801};\\\", \\\"{x:1610,y:388,t:1527635250817};\\\", \\\"{x:1610,y:387,t:1527635250834};\\\", \\\"{x:1609,y:386,t:1527635250875};\\\", \\\"{x:1609,y:385,t:1527635250891};\\\", \\\"{x:1609,y:384,t:1527635250900};\\\", \\\"{x:1609,y:382,t:1527635250923};\\\", \\\"{x:1609,y:381,t:1527635251315};\\\", \\\"{x:1609,y:384,t:1527635251331};\\\", \\\"{x:1609,y:389,t:1527635251339};\\\", \\\"{x:1609,y:396,t:1527635251351};\\\", \\\"{x:1609,y:414,t:1527635251367};\\\", \\\"{x:1609,y:426,t:1527635251385};\\\", \\\"{x:1609,y:435,t:1527635251400};\\\", \\\"{x:1609,y:447,t:1527635251418};\\\", \\\"{x:1610,y:462,t:1527635251434};\\\", \\\"{x:1612,y:478,t:1527635251451};\\\", \\\"{x:1615,y:494,t:1527635251467};\\\", \\\"{x:1618,y:513,t:1527635251487};\\\", \\\"{x:1621,y:532,t:1527635251501};\\\", \\\"{x:1624,y:545,t:1527635251517};\\\", \\\"{x:1627,y:559,t:1527635251534};\\\", \\\"{x:1630,y:578,t:1527635251550};\\\", \\\"{x:1633,y:600,t:1527635251566};\\\", \\\"{x:1640,y:629,t:1527635251584};\\\", \\\"{x:1644,y:649,t:1527635251600};\\\", \\\"{x:1653,y:671,t:1527635251617};\\\", \\\"{x:1658,y:692,t:1527635251634};\\\", \\\"{x:1663,y:705,t:1527635251650};\\\", \\\"{x:1666,y:713,t:1527635251667};\\\", \\\"{x:1673,y:724,t:1527635251683};\\\", \\\"{x:1676,y:732,t:1527635251700};\\\", \\\"{x:1677,y:737,t:1527635251717};\\\", \\\"{x:1681,y:744,t:1527635251734};\\\", \\\"{x:1682,y:746,t:1527635251750};\\\", \\\"{x:1683,y:749,t:1527635251768};\\\", \\\"{x:1686,y:755,t:1527635251784};\\\", \\\"{x:1686,y:758,t:1527635251801};\\\", \\\"{x:1689,y:762,t:1527635251817};\\\", \\\"{x:1689,y:764,t:1527635251834};\\\", \\\"{x:1690,y:767,t:1527635251850};\\\", \\\"{x:1688,y:762,t:1527635251939};\\\", \\\"{x:1682,y:747,t:1527635251952};\\\", \\\"{x:1667,y:709,t:1527635251967};\\\", \\\"{x:1656,y:666,t:1527635251984};\\\", \\\"{x:1649,y:635,t:1527635252001};\\\", \\\"{x:1644,y:609,t:1527635252017};\\\", \\\"{x:1640,y:578,t:1527635252035};\\\", \\\"{x:1636,y:557,t:1527635252051};\\\", \\\"{x:1627,y:528,t:1527635252067};\\\", \\\"{x:1618,y:498,t:1527635252084};\\\", \\\"{x:1613,y:477,t:1527635252102};\\\", \\\"{x:1607,y:462,t:1527635252117};\\\", \\\"{x:1605,y:451,t:1527635252134};\\\", \\\"{x:1602,y:443,t:1527635252152};\\\", \\\"{x:1599,y:435,t:1527635252168};\\\", \\\"{x:1599,y:431,t:1527635252184};\\\", \\\"{x:1598,y:427,t:1527635252202};\\\", \\\"{x:1598,y:424,t:1527635252218};\\\", \\\"{x:1596,y:420,t:1527635252234};\\\", \\\"{x:1596,y:416,t:1527635252251};\\\", \\\"{x:1596,y:414,t:1527635252268};\\\", \\\"{x:1596,y:412,t:1527635252285};\\\", \\\"{x:1596,y:409,t:1527635252302};\\\", \\\"{x:1596,y:404,t:1527635252319};\\\", \\\"{x:1597,y:400,t:1527635252335};\\\", \\\"{x:1600,y:395,t:1527635252352};\\\", \\\"{x:1601,y:392,t:1527635252368};\\\", \\\"{x:1604,y:388,t:1527635252385};\\\", \\\"{x:1606,y:386,t:1527635252401};\\\", \\\"{x:1608,y:384,t:1527635252418};\\\", \\\"{x:1608,y:383,t:1527635252564};\\\", \\\"{x:1609,y:381,t:1527635252579};\\\", \\\"{x:1610,y:381,t:1527635252586};\\\", \\\"{x:1611,y:380,t:1527635252602};\\\", \\\"{x:1611,y:377,t:1527635252618};\\\", \\\"{x:1613,y:375,t:1527635252635};\\\", \\\"{x:1614,y:375,t:1527635252715};\\\", \\\"{x:1615,y:380,t:1527635252723};\\\", \\\"{x:1616,y:385,t:1527635252736};\\\", \\\"{x:1617,y:399,t:1527635252751};\\\", \\\"{x:1617,y:414,t:1527635252768};\\\", \\\"{x:1617,y:433,t:1527635252785};\\\", \\\"{x:1617,y:449,t:1527635252801};\\\", \\\"{x:1617,y:469,t:1527635252818};\\\", \\\"{x:1617,y:478,t:1527635252834};\\\", \\\"{x:1617,y:491,t:1527635252852};\\\", \\\"{x:1617,y:499,t:1527635252868};\\\", \\\"{x:1617,y:510,t:1527635252886};\\\", \\\"{x:1617,y:519,t:1527635252903};\\\", \\\"{x:1617,y:527,t:1527635252919};\\\", \\\"{x:1617,y:528,t:1527635252947};\\\", \\\"{x:1617,y:529,t:1527635252955};\\\", \\\"{x:1617,y:526,t:1527635253187};\\\", \\\"{x:1617,y:523,t:1527635253201};\\\", \\\"{x:1618,y:514,t:1527635253219};\\\", \\\"{x:1618,y:506,t:1527635253235};\\\", \\\"{x:1618,y:497,t:1527635253254};\\\", \\\"{x:1621,y:489,t:1527635253269};\\\", \\\"{x:1621,y:485,t:1527635253285};\\\", \\\"{x:1621,y:481,t:1527635253302};\\\", \\\"{x:1621,y:477,t:1527635253319};\\\", \\\"{x:1621,y:474,t:1527635253335};\\\", \\\"{x:1621,y:473,t:1527635253353};\\\", \\\"{x:1621,y:474,t:1527635253443};\\\", \\\"{x:1621,y:480,t:1527635253452};\\\", \\\"{x:1620,y:490,t:1527635253469};\\\", \\\"{x:1616,y:502,t:1527635253486};\\\", \\\"{x:1616,y:507,t:1527635253503};\\\", \\\"{x:1613,y:513,t:1527635253518};\\\", \\\"{x:1612,y:516,t:1527635253536};\\\", \\\"{x:1612,y:518,t:1527635253552};\\\", \\\"{x:1609,y:522,t:1527635253568};\\\", \\\"{x:1604,y:529,t:1527635253585};\\\", \\\"{x:1592,y:538,t:1527635253602};\\\", \\\"{x:1577,y:545,t:1527635253618};\\\", \\\"{x:1547,y:554,t:1527635253635};\\\", \\\"{x:1502,y:564,t:1527635253652};\\\", \\\"{x:1434,y:587,t:1527635253669};\\\", \\\"{x:1338,y:611,t:1527635253685};\\\", \\\"{x:1228,y:623,t:1527635253702};\\\", \\\"{x:1092,y:644,t:1527635253719};\\\", \\\"{x:981,y:660,t:1527635253735};\\\", \\\"{x:926,y:663,t:1527635253752};\\\", \\\"{x:899,y:663,t:1527635253768};\\\", \\\"{x:868,y:659,t:1527635253786};\\\", \\\"{x:824,y:651,t:1527635253802};\\\", \\\"{x:801,y:647,t:1527635253818};\\\", \\\"{x:782,y:641,t:1527635253835};\\\", \\\"{x:755,y:634,t:1527635253852};\\\", \\\"{x:716,y:626,t:1527635253869};\\\", \\\"{x:659,y:613,t:1527635253885};\\\", \\\"{x:617,y:607,t:1527635253902};\\\", \\\"{x:579,y:601,t:1527635253919};\\\", \\\"{x:546,y:594,t:1527635253936};\\\", \\\"{x:520,y:588,t:1527635253952};\\\", \\\"{x:492,y:580,t:1527635253970};\\\", \\\"{x:431,y:573,t:1527635253985};\\\", \\\"{x:403,y:569,t:1527635254003};\\\", \\\"{x:393,y:567,t:1527635254018};\\\", \\\"{x:384,y:565,t:1527635254036};\\\", \\\"{x:379,y:560,t:1527635254053};\\\", \\\"{x:375,y:557,t:1527635254070};\\\", \\\"{x:373,y:554,t:1527635254086};\\\", \\\"{x:372,y:553,t:1527635254103};\\\", \\\"{x:369,y:549,t:1527635254119};\\\", \\\"{x:367,y:540,t:1527635254136};\\\", \\\"{x:365,y:532,t:1527635254153};\\\", \\\"{x:365,y:528,t:1527635254169};\\\", \\\"{x:365,y:522,t:1527635254185};\\\", \\\"{x:366,y:518,t:1527635254202};\\\", \\\"{x:368,y:513,t:1527635254218};\\\", \\\"{x:368,y:510,t:1527635254236};\\\", \\\"{x:368,y:508,t:1527635254253};\\\", \\\"{x:368,y:507,t:1527635254281};\\\", \\\"{x:365,y:507,t:1527635254297};\\\", \\\"{x:362,y:507,t:1527635254306};\\\", \\\"{x:359,y:507,t:1527635254319};\\\", \\\"{x:352,y:507,t:1527635254336};\\\", \\\"{x:341,y:508,t:1527635254353};\\\", \\\"{x:319,y:511,t:1527635254369};\\\", \\\"{x:277,y:517,t:1527635254386};\\\", \\\"{x:239,y:524,t:1527635254403};\\\", \\\"{x:213,y:527,t:1527635254419};\\\", \\\"{x:188,y:532,t:1527635254438};\\\", \\\"{x:180,y:532,t:1527635254453};\\\", \\\"{x:176,y:532,t:1527635254470};\\\", \\\"{x:175,y:533,t:1527635254602};\\\", \\\"{x:175,y:540,t:1527635254620};\\\", \\\"{x:175,y:552,t:1527635254636};\\\", \\\"{x:178,y:565,t:1527635254653};\\\", \\\"{x:184,y:576,t:1527635254670};\\\", \\\"{x:186,y:579,t:1527635254686};\\\", \\\"{x:186,y:580,t:1527635254703};\\\", \\\"{x:186,y:581,t:1527635254738};\\\", \\\"{x:185,y:581,t:1527635254761};\\\", \\\"{x:185,y:582,t:1527635254769};\\\", \\\"{x:183,y:583,t:1527635254786};\\\", \\\"{x:182,y:584,t:1527635254803};\\\", \\\"{x:177,y:585,t:1527635254819};\\\", \\\"{x:173,y:585,t:1527635254836};\\\", \\\"{x:170,y:585,t:1527635254853};\\\", \\\"{x:168,y:586,t:1527635254869};\\\", \\\"{x:166,y:586,t:1527635255210};\\\", \\\"{x:165,y:586,t:1527635255220};\\\", \\\"{x:162,y:588,t:1527635255237};\\\", \\\"{x:160,y:588,t:1527635255253};\\\", \\\"{x:155,y:588,t:1527635255270};\\\", \\\"{x:153,y:589,t:1527635255287};\\\", \\\"{x:152,y:589,t:1527635255306};\\\", \\\"{x:151,y:591,t:1527635255363};\\\", \\\"{x:151,y:593,t:1527635255370};\\\", \\\"{x:175,y:598,t:1527635255389};\\\", \\\"{x:239,y:608,t:1527635255404};\\\", \\\"{x:343,y:626,t:1527635255420};\\\", \\\"{x:468,y:645,t:1527635255437};\\\", \\\"{x:582,y:663,t:1527635255454};\\\", \\\"{x:660,y:676,t:1527635255470};\\\", \\\"{x:696,y:687,t:1527635255486};\\\", \\\"{x:699,y:687,t:1527635255504};\\\", \\\"{x:700,y:688,t:1527635255520};\\\", \\\"{x:700,y:689,t:1527635255537};\\\", \\\"{x:695,y:689,t:1527635255553};\\\", \\\"{x:689,y:689,t:1527635255570};\\\", \\\"{x:683,y:689,t:1527635255587};\\\", \\\"{x:670,y:689,t:1527635255605};\\\", \\\"{x:649,y:689,t:1527635255620};\\\", \\\"{x:637,y:691,t:1527635255637};\\\", \\\"{x:629,y:691,t:1527635255655};\\\", \\\"{x:614,y:692,t:1527635255671};\\\", \\\"{x:599,y:692,t:1527635255687};\\\", \\\"{x:594,y:692,t:1527635255704};\\\", \\\"{x:590,y:690,t:1527635255720};\\\", \\\"{x:577,y:687,t:1527635255737};\\\", \\\"{x:554,y:684,t:1527635255755};\\\", \\\"{x:545,y:682,t:1527635255772};\\\", \\\"{x:540,y:680,t:1527635255787};\\\", \\\"{x:536,y:680,t:1527635255804};\\\", \\\"{x:533,y:678,t:1527635255820};\\\", \\\"{x:532,y:678,t:1527635255837};\\\", \\\"{x:533,y:677,t:1527635256997};\\\", \\\"{x:534,y:677,t:1527635257005};\\\", \\\"{x:536,y:677,t:1527635257025};\\\", \\\"{x:537,y:677,t:1527635257038};\\\", \\\"{x:541,y:677,t:1527635257055};\\\", \\\"{x:543,y:678,t:1527635257070};\\\" ] }, { \\\"rt\\\": 56693, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 223323, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"8FE87\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -C -A -Z -Z -Z -Z -O -11 AM-12 PM-Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:557,y:684,t:1527635257191};\\\", \\\"{x:559,y:684,t:1527635257221};\\\", \\\"{x:569,y:684,t:1527635293575};\\\", \\\"{x:704,y:610,t:1527635293591};\\\", \\\"{x:785,y:576,t:1527635293601};\\\", \\\"{x:925,y:541,t:1527635293619};\\\", \\\"{x:999,y:537,t:1527635293636};\\\", \\\"{x:1042,y:536,t:1527635293654};\\\", \\\"{x:1047,y:536,t:1527635293671};\\\", \\\"{x:1048,y:537,t:1527635293688};\\\", \\\"{x:1053,y:538,t:1527635293703};\\\", \\\"{x:1056,y:541,t:1527635293721};\\\", \\\"{x:1057,y:541,t:1527635294206};\\\", \\\"{x:1068,y:545,t:1527635294222};\\\", \\\"{x:1097,y:550,t:1527635294238};\\\", \\\"{x:1103,y:549,t:1527635294256};\\\", \\\"{x:1104,y:549,t:1527635294271};\\\", \\\"{x:1105,y:549,t:1527635294302};\\\", \\\"{x:1105,y:553,t:1527635294317};\\\", \\\"{x:1107,y:561,t:1527635294325};\\\", \\\"{x:1110,y:566,t:1527635294339};\\\", \\\"{x:1114,y:568,t:1527635294356};\\\", \\\"{x:1116,y:571,t:1527635295382};\\\", \\\"{x:1121,y:577,t:1527635295389};\\\", \\\"{x:1131,y:587,t:1527635295406};\\\", \\\"{x:1146,y:599,t:1527635295422};\\\", \\\"{x:1153,y:606,t:1527635295439};\\\", \\\"{x:1158,y:612,t:1527635295457};\\\", \\\"{x:1159,y:620,t:1527635295473};\\\", \\\"{x:1164,y:637,t:1527635295489};\\\", \\\"{x:1195,y:685,t:1527635295506};\\\", \\\"{x:1231,y:740,t:1527635295522};\\\", \\\"{x:1263,y:783,t:1527635295539};\\\", \\\"{x:1273,y:808,t:1527635295556};\\\", \\\"{x:1288,y:838,t:1527635295573};\\\", \\\"{x:1292,y:849,t:1527635295588};\\\", \\\"{x:1292,y:851,t:1527635295606};\\\", \\\"{x:1291,y:851,t:1527635295742};\\\", \\\"{x:1286,y:848,t:1527635295757};\\\", \\\"{x:1262,y:816,t:1527635295774};\\\", \\\"{x:1246,y:798,t:1527635295789};\\\", \\\"{x:1231,y:783,t:1527635295806};\\\", \\\"{x:1215,y:765,t:1527635295823};\\\", \\\"{x:1200,y:745,t:1527635295840};\\\", \\\"{x:1191,y:734,t:1527635295856};\\\", \\\"{x:1190,y:731,t:1527635295873};\\\", \\\"{x:1189,y:730,t:1527635295890};\\\", \\\"{x:1189,y:731,t:1527635295997};\\\", \\\"{x:1192,y:735,t:1527635296006};\\\", \\\"{x:1201,y:746,t:1527635296024};\\\", \\\"{x:1210,y:754,t:1527635296041};\\\", \\\"{x:1216,y:763,t:1527635296056};\\\", \\\"{x:1219,y:768,t:1527635296073};\\\", \\\"{x:1220,y:771,t:1527635296091};\\\", \\\"{x:1221,y:774,t:1527635296106};\\\", \\\"{x:1220,y:774,t:1527635296286};\\\", \\\"{x:1219,y:775,t:1527635296368};\\\", \\\"{x:1222,y:774,t:1527635299263};\\\", \\\"{x:1224,y:773,t:1527635299277};\\\", \\\"{x:1235,y:771,t:1527635299293};\\\", \\\"{x:1256,y:769,t:1527635299309};\\\", \\\"{x:1279,y:766,t:1527635299327};\\\", \\\"{x:1297,y:766,t:1527635299344};\\\", \\\"{x:1310,y:766,t:1527635299360};\\\", \\\"{x:1313,y:766,t:1527635299376};\\\", \\\"{x:1316,y:766,t:1527635299394};\\\", \\\"{x:1317,y:766,t:1527635299409};\\\", \\\"{x:1319,y:766,t:1527635299426};\\\", \\\"{x:1320,y:766,t:1527635299443};\\\", \\\"{x:1321,y:766,t:1527635299492};\\\", \\\"{x:1322,y:766,t:1527635299621};\\\", \\\"{x:1323,y:766,t:1527635299629};\\\", \\\"{x:1326,y:766,t:1527635299644};\\\", \\\"{x:1330,y:767,t:1527635299661};\\\", \\\"{x:1331,y:768,t:1527635299676};\\\", \\\"{x:1333,y:768,t:1527635299693};\\\", \\\"{x:1333,y:769,t:1527635299717};\\\", \\\"{x:1335,y:770,t:1527635299757};\\\", \\\"{x:1335,y:771,t:1527635299765};\\\", \\\"{x:1336,y:772,t:1527635299777};\\\", \\\"{x:1337,y:773,t:1527635299794};\\\", \\\"{x:1338,y:775,t:1527635299810};\\\", \\\"{x:1340,y:778,t:1527635299826};\\\", \\\"{x:1341,y:781,t:1527635299843};\\\", \\\"{x:1342,y:784,t:1527635299860};\\\", \\\"{x:1344,y:788,t:1527635299875};\\\", \\\"{x:1345,y:794,t:1527635299892};\\\", \\\"{x:1347,y:798,t:1527635299910};\\\", \\\"{x:1347,y:800,t:1527635299926};\\\", \\\"{x:1347,y:801,t:1527635299949};\\\", \\\"{x:1348,y:801,t:1527635299960};\\\", \\\"{x:1348,y:803,t:1527635299976};\\\", \\\"{x:1348,y:804,t:1527635300005};\\\", \\\"{x:1348,y:806,t:1527635300012};\\\", \\\"{x:1348,y:808,t:1527635300028};\\\", \\\"{x:1348,y:809,t:1527635300044};\\\", \\\"{x:1348,y:810,t:1527635300060};\\\", \\\"{x:1348,y:811,t:1527635300078};\\\", \\\"{x:1348,y:812,t:1527635300101};\\\", \\\"{x:1348,y:815,t:1527635300111};\\\", \\\"{x:1348,y:823,t:1527635300127};\\\", \\\"{x:1347,y:832,t:1527635300143};\\\", \\\"{x:1345,y:837,t:1527635300161};\\\", \\\"{x:1344,y:841,t:1527635300177};\\\", \\\"{x:1343,y:842,t:1527635300194};\\\", \\\"{x:1342,y:844,t:1527635300246};\\\", \\\"{x:1342,y:846,t:1527635300278};\\\", \\\"{x:1342,y:847,t:1527635300293};\\\", \\\"{x:1342,y:848,t:1527635300311};\\\", \\\"{x:1342,y:849,t:1527635300328};\\\", \\\"{x:1340,y:851,t:1527635300344};\\\", \\\"{x:1340,y:852,t:1527635300361};\\\", \\\"{x:1340,y:856,t:1527635300378};\\\", \\\"{x:1340,y:858,t:1527635300395};\\\", \\\"{x:1339,y:861,t:1527635300411};\\\", \\\"{x:1338,y:862,t:1527635300428};\\\", \\\"{x:1338,y:863,t:1527635300445};\\\", \\\"{x:1338,y:864,t:1527635300460};\\\", \\\"{x:1336,y:866,t:1527635300477};\\\", \\\"{x:1327,y:872,t:1527635300495};\\\", \\\"{x:1306,y:878,t:1527635300511};\\\", \\\"{x:1281,y:883,t:1527635300527};\\\", \\\"{x:1254,y:885,t:1527635300545};\\\", \\\"{x:1230,y:887,t:1527635300560};\\\", \\\"{x:1204,y:887,t:1527635300578};\\\", \\\"{x:1176,y:887,t:1527635300595};\\\", \\\"{x:1153,y:887,t:1527635300610};\\\", \\\"{x:1118,y:890,t:1527635300627};\\\", \\\"{x:1062,y:891,t:1527635300645};\\\", \\\"{x:981,y:891,t:1527635300661};\\\", \\\"{x:885,y:879,t:1527635300678};\\\", \\\"{x:825,y:859,t:1527635300694};\\\", \\\"{x:783,y:837,t:1527635300711};\\\", \\\"{x:742,y:821,t:1527635300727};\\\", \\\"{x:690,y:798,t:1527635300744};\\\", \\\"{x:651,y:774,t:1527635300762};\\\", \\\"{x:631,y:760,t:1527635300777};\\\", \\\"{x:606,y:741,t:1527635300795};\\\", \\\"{x:587,y:723,t:1527635300811};\\\", \\\"{x:570,y:704,t:1527635300827};\\\", \\\"{x:558,y:691,t:1527635300844};\\\", \\\"{x:551,y:677,t:1527635300862};\\\", \\\"{x:550,y:669,t:1527635300877};\\\", \\\"{x:550,y:663,t:1527635300894};\\\", \\\"{x:550,y:659,t:1527635300903};\\\", \\\"{x:548,y:652,t:1527635300920};\\\", \\\"{x:548,y:650,t:1527635300937};\\\", \\\"{x:548,y:646,t:1527635300954};\\\", \\\"{x:548,y:643,t:1527635300970};\\\", \\\"{x:546,y:633,t:1527635300993};\\\", \\\"{x:537,y:626,t:1527635301009};\\\", \\\"{x:518,y:616,t:1527635301025};\\\", \\\"{x:502,y:607,t:1527635301043};\\\", \\\"{x:485,y:602,t:1527635301059};\\\", \\\"{x:449,y:590,t:1527635301076};\\\", \\\"{x:396,y:576,t:1527635301093};\\\", \\\"{x:366,y:569,t:1527635301110};\\\", \\\"{x:338,y:566,t:1527635301128};\\\", \\\"{x:309,y:566,t:1527635301142};\\\", \\\"{x:290,y:563,t:1527635301160};\\\", \\\"{x:271,y:563,t:1527635301176};\\\", \\\"{x:250,y:563,t:1527635301193};\\\", \\\"{x:219,y:563,t:1527635301210};\\\", \\\"{x:186,y:563,t:1527635301226};\\\", \\\"{x:162,y:563,t:1527635301242};\\\", \\\"{x:153,y:563,t:1527635301260};\\\", \\\"{x:152,y:563,t:1527635301405};\\\", \\\"{x:151,y:562,t:1527635301420};\\\", \\\"{x:151,y:559,t:1527635301463};\\\", \\\"{x:151,y:555,t:1527635301476};\\\", \\\"{x:151,y:546,t:1527635301494};\\\", \\\"{x:151,y:536,t:1527635301509};\\\", \\\"{x:151,y:527,t:1527635301527};\\\", \\\"{x:150,y:518,t:1527635301545};\\\", \\\"{x:150,y:515,t:1527635301560};\\\", \\\"{x:148,y:510,t:1527635301577};\\\", \\\"{x:147,y:506,t:1527635301594};\\\", \\\"{x:147,y:504,t:1527635301610};\\\", \\\"{x:147,y:501,t:1527635301627};\\\", \\\"{x:146,y:500,t:1527635301644};\\\", \\\"{x:146,y:499,t:1527635302365};\\\", \\\"{x:156,y:499,t:1527635302379};\\\", \\\"{x:237,y:507,t:1527635302394};\\\", \\\"{x:394,y:525,t:1527635302411};\\\", \\\"{x:669,y:534,t:1527635302429};\\\", \\\"{x:828,y:549,t:1527635302444};\\\", \\\"{x:966,y:562,t:1527635302461};\\\", \\\"{x:1063,y:577,t:1527635302478};\\\", \\\"{x:1110,y:594,t:1527635302494};\\\", \\\"{x:1130,y:606,t:1527635302511};\\\", \\\"{x:1144,y:617,t:1527635302527};\\\", \\\"{x:1148,y:623,t:1527635302544};\\\", \\\"{x:1152,y:629,t:1527635302561};\\\", \\\"{x:1161,y:643,t:1527635302577};\\\", \\\"{x:1169,y:660,t:1527635302594};\\\", \\\"{x:1186,y:685,t:1527635302611};\\\", \\\"{x:1202,y:708,t:1527635302628};\\\", \\\"{x:1210,y:729,t:1527635302644};\\\", \\\"{x:1224,y:759,t:1527635302661};\\\", \\\"{x:1231,y:778,t:1527635302677};\\\", \\\"{x:1237,y:794,t:1527635302694};\\\", \\\"{x:1244,y:810,t:1527635302711};\\\", \\\"{x:1255,y:826,t:1527635302727};\\\", \\\"{x:1262,y:836,t:1527635302744};\\\", \\\"{x:1273,y:848,t:1527635302761};\\\", \\\"{x:1288,y:863,t:1527635302777};\\\", \\\"{x:1304,y:871,t:1527635302794};\\\", \\\"{x:1311,y:875,t:1527635302810};\\\", \\\"{x:1314,y:875,t:1527635302827};\\\", \\\"{x:1318,y:876,t:1527635302844};\\\", \\\"{x:1323,y:876,t:1527635302860};\\\", \\\"{x:1328,y:876,t:1527635302878};\\\", \\\"{x:1334,y:876,t:1527635302894};\\\", \\\"{x:1337,y:875,t:1527635302911};\\\", \\\"{x:1338,y:875,t:1527635302928};\\\", \\\"{x:1339,y:875,t:1527635302974};\\\", \\\"{x:1341,y:875,t:1527635302981};\\\", \\\"{x:1345,y:875,t:1527635302995};\\\", \\\"{x:1352,y:875,t:1527635303010};\\\", \\\"{x:1354,y:875,t:1527635303027};\\\", \\\"{x:1355,y:875,t:1527635303043};\\\", \\\"{x:1355,y:877,t:1527635303406};\\\", \\\"{x:1355,y:880,t:1527635303413};\\\", \\\"{x:1355,y:883,t:1527635303427};\\\", \\\"{x:1354,y:892,t:1527635303444};\\\", \\\"{x:1353,y:898,t:1527635303461};\\\", \\\"{x:1352,y:903,t:1527635303477};\\\", \\\"{x:1352,y:901,t:1527635303708};\\\", \\\"{x:1352,y:899,t:1527635303725};\\\", \\\"{x:1352,y:897,t:1527635303733};\\\", \\\"{x:1352,y:895,t:1527635303748};\\\", \\\"{x:1352,y:891,t:1527635303759};\\\", \\\"{x:1352,y:882,t:1527635303776};\\\", \\\"{x:1352,y:877,t:1527635303793};\\\", \\\"{x:1352,y:869,t:1527635303809};\\\", \\\"{x:1352,y:862,t:1527635303826};\\\", \\\"{x:1352,y:857,t:1527635303844};\\\", \\\"{x:1352,y:851,t:1527635303859};\\\", \\\"{x:1349,y:840,t:1527635303877};\\\", \\\"{x:1348,y:835,t:1527635303892};\\\", \\\"{x:1348,y:829,t:1527635303909};\\\", \\\"{x:1348,y:823,t:1527635303927};\\\", \\\"{x:1348,y:818,t:1527635303944};\\\", \\\"{x:1348,y:810,t:1527635303959};\\\", \\\"{x:1347,y:799,t:1527635303976};\\\", \\\"{x:1345,y:791,t:1527635303993};\\\", \\\"{x:1345,y:782,t:1527635304009};\\\", \\\"{x:1343,y:770,t:1527635304026};\\\", \\\"{x:1343,y:756,t:1527635304043};\\\", \\\"{x:1342,y:744,t:1527635304059};\\\", \\\"{x:1340,y:724,t:1527635304076};\\\", \\\"{x:1340,y:710,t:1527635304093};\\\", \\\"{x:1340,y:694,t:1527635304110};\\\", \\\"{x:1340,y:679,t:1527635304127};\\\", \\\"{x:1339,y:661,t:1527635304142};\\\", \\\"{x:1337,y:642,t:1527635304160};\\\", \\\"{x:1337,y:624,t:1527635304176};\\\", \\\"{x:1337,y:606,t:1527635304192};\\\", \\\"{x:1337,y:591,t:1527635304209};\\\", \\\"{x:1337,y:577,t:1527635304227};\\\", \\\"{x:1337,y:567,t:1527635304243};\\\", \\\"{x:1335,y:561,t:1527635304260};\\\", \\\"{x:1334,y:553,t:1527635304277};\\\", \\\"{x:1333,y:547,t:1527635304293};\\\", \\\"{x:1333,y:539,t:1527635304309};\\\", \\\"{x:1333,y:531,t:1527635304327};\\\", \\\"{x:1333,y:524,t:1527635304343};\\\", \\\"{x:1333,y:521,t:1527635304359};\\\", \\\"{x:1333,y:516,t:1527635304376};\\\", \\\"{x:1333,y:514,t:1527635304392};\\\", \\\"{x:1334,y:509,t:1527635304409};\\\", \\\"{x:1335,y:505,t:1527635304426};\\\", \\\"{x:1335,y:500,t:1527635304442};\\\", \\\"{x:1337,y:497,t:1527635304459};\\\", \\\"{x:1339,y:495,t:1527635304475};\\\", \\\"{x:1339,y:492,t:1527635304492};\\\", \\\"{x:1339,y:489,t:1527635304509};\\\", \\\"{x:1341,y:486,t:1527635304525};\\\", \\\"{x:1341,y:484,t:1527635304542};\\\", \\\"{x:1343,y:481,t:1527635304560};\\\", \\\"{x:1344,y:479,t:1527635304575};\\\", \\\"{x:1345,y:478,t:1527635304592};\\\", \\\"{x:1345,y:477,t:1527635304645};\\\", \\\"{x:1346,y:476,t:1527635304659};\\\", \\\"{x:1347,y:474,t:1527635304701};\\\", \\\"{x:1348,y:474,t:1527635304717};\\\", \\\"{x:1348,y:473,t:1527635304734};\\\", \\\"{x:1349,y:472,t:1527635304742};\\\", \\\"{x:1350,y:471,t:1527635304765};\\\", \\\"{x:1350,y:470,t:1527635304829};\\\", \\\"{x:1351,y:470,t:1527635304842};\\\", \\\"{x:1352,y:468,t:1527635304877};\\\", \\\"{x:1352,y:466,t:1527635304893};\\\", \\\"{x:1352,y:465,t:1527635304909};\\\", \\\"{x:1355,y:462,t:1527635304925};\\\", \\\"{x:1355,y:461,t:1527635304942};\\\", \\\"{x:1355,y:459,t:1527635304959};\\\", \\\"{x:1355,y:461,t:1527635305229};\\\", \\\"{x:1354,y:469,t:1527635305242};\\\", \\\"{x:1351,y:489,t:1527635305258};\\\", \\\"{x:1351,y:506,t:1527635305275};\\\", \\\"{x:1351,y:521,t:1527635305291};\\\", \\\"{x:1351,y:541,t:1527635305309};\\\", \\\"{x:1349,y:555,t:1527635305325};\\\", \\\"{x:1349,y:573,t:1527635305341};\\\", \\\"{x:1349,y:596,t:1527635305359};\\\", \\\"{x:1349,y:622,t:1527635305375};\\\", \\\"{x:1349,y:641,t:1527635305391};\\\", \\\"{x:1349,y:657,t:1527635305408};\\\", \\\"{x:1349,y:667,t:1527635305424};\\\", \\\"{x:1349,y:678,t:1527635305442};\\\", \\\"{x:1348,y:689,t:1527635305459};\\\", \\\"{x:1348,y:697,t:1527635305474};\\\", \\\"{x:1348,y:706,t:1527635305491};\\\", \\\"{x:1348,y:724,t:1527635305509};\\\", \\\"{x:1348,y:731,t:1527635305524};\\\", \\\"{x:1348,y:736,t:1527635305541};\\\", \\\"{x:1348,y:739,t:1527635305559};\\\", \\\"{x:1347,y:741,t:1527635305575};\\\", \\\"{x:1347,y:739,t:1527635305765};\\\", \\\"{x:1344,y:729,t:1527635305775};\\\", \\\"{x:1341,y:704,t:1527635305792};\\\", \\\"{x:1339,y:686,t:1527635305808};\\\", \\\"{x:1339,y:666,t:1527635305825};\\\", \\\"{x:1339,y:649,t:1527635305842};\\\", \\\"{x:1339,y:637,t:1527635305858};\\\", \\\"{x:1339,y:623,t:1527635305875};\\\", \\\"{x:1339,y:607,t:1527635305892};\\\", \\\"{x:1339,y:592,t:1527635305908};\\\", \\\"{x:1340,y:578,t:1527635305925};\\\", \\\"{x:1340,y:569,t:1527635305942};\\\", \\\"{x:1342,y:565,t:1527635305958};\\\", \\\"{x:1342,y:560,t:1527635305975};\\\", \\\"{x:1342,y:558,t:1527635305991};\\\", \\\"{x:1342,y:557,t:1527635306008};\\\", \\\"{x:1341,y:562,t:1527635306118};\\\", \\\"{x:1338,y:571,t:1527635306126};\\\", \\\"{x:1335,y:577,t:1527635306141};\\\", \\\"{x:1335,y:578,t:1527635306158};\\\", \\\"{x:1334,y:578,t:1527635306517};\\\", \\\"{x:1330,y:580,t:1527635306525};\\\", \\\"{x:1326,y:580,t:1527635306541};\\\", \\\"{x:1314,y:580,t:1527635306557};\\\", \\\"{x:1297,y:580,t:1527635306574};\\\", \\\"{x:1289,y:581,t:1527635306590};\\\", \\\"{x:1276,y:585,t:1527635306608};\\\", \\\"{x:1246,y:585,t:1527635306624};\\\", \\\"{x:1190,y:585,t:1527635306641};\\\", \\\"{x:1115,y:585,t:1527635306657};\\\", \\\"{x:1023,y:585,t:1527635306674};\\\", \\\"{x:921,y:585,t:1527635306691};\\\", \\\"{x:846,y:585,t:1527635306707};\\\", \\\"{x:798,y:585,t:1527635306723};\\\", \\\"{x:775,y:585,t:1527635306741};\\\", \\\"{x:773,y:585,t:1527635306757};\\\", \\\"{x:771,y:585,t:1527635306813};\\\", \\\"{x:766,y:585,t:1527635306824};\\\", \\\"{x:738,y:592,t:1527635306841};\\\", \\\"{x:655,y:601,t:1527635306856};\\\", \\\"{x:548,y:609,t:1527635306873};\\\", \\\"{x:438,y:609,t:1527635306890};\\\", \\\"{x:307,y:616,t:1527635306907};\\\", \\\"{x:229,y:616,t:1527635306924};\\\", \\\"{x:208,y:616,t:1527635306940};\\\", \\\"{x:203,y:615,t:1527635306957};\\\", \\\"{x:201,y:614,t:1527635306973};\\\", \\\"{x:200,y:612,t:1527635307005};\\\", \\\"{x:200,y:610,t:1527635307012};\\\", \\\"{x:199,y:607,t:1527635307023};\\\", \\\"{x:195,y:596,t:1527635307040};\\\", \\\"{x:186,y:583,t:1527635307056};\\\", \\\"{x:182,y:572,t:1527635307073};\\\", \\\"{x:179,y:559,t:1527635307096};\\\", \\\"{x:175,y:546,t:1527635307113};\\\", \\\"{x:167,y:530,t:1527635307129};\\\", \\\"{x:157,y:512,t:1527635307149};\\\", \\\"{x:155,y:510,t:1527635307165};\\\", \\\"{x:155,y:509,t:1527635307181};\\\", \\\"{x:155,y:508,t:1527635307220};\\\", \\\"{x:154,y:505,t:1527635307231};\\\", \\\"{x:152,y:502,t:1527635307248};\\\", \\\"{x:151,y:497,t:1527635307265};\\\", \\\"{x:148,y:493,t:1527635307282};\\\", \\\"{x:148,y:495,t:1527635307405};\\\", \\\"{x:148,y:496,t:1527635307415};\\\", \\\"{x:149,y:499,t:1527635307433};\\\", \\\"{x:151,y:501,t:1527635307449};\\\", \\\"{x:151,y:502,t:1527635307466};\\\", \\\"{x:152,y:503,t:1527635307589};\\\", \\\"{x:152,y:503,t:1527635307629};\\\", \\\"{x:154,y:503,t:1527635307764};\\\", \\\"{x:160,y:504,t:1527635307772};\\\", \\\"{x:170,y:505,t:1527635307783};\\\", \\\"{x:197,y:508,t:1527635307799};\\\", \\\"{x:232,y:509,t:1527635307815};\\\", \\\"{x:279,y:509,t:1527635307833};\\\", \\\"{x:311,y:509,t:1527635307848};\\\", \\\"{x:343,y:511,t:1527635307866};\\\", \\\"{x:367,y:511,t:1527635307882};\\\", \\\"{x:400,y:513,t:1527635307898};\\\", \\\"{x:464,y:513,t:1527635307916};\\\", \\\"{x:556,y:513,t:1527635307933};\\\", \\\"{x:632,y:511,t:1527635307949};\\\", \\\"{x:715,y:501,t:1527635307966};\\\", \\\"{x:780,y:488,t:1527635307982};\\\", \\\"{x:861,y:477,t:1527635308000};\\\", \\\"{x:917,y:475,t:1527635308016};\\\", \\\"{x:950,y:474,t:1527635308032};\\\", \\\"{x:970,y:474,t:1527635308049};\\\", \\\"{x:976,y:474,t:1527635308065};\\\", \\\"{x:982,y:480,t:1527635308083};\\\", \\\"{x:995,y:497,t:1527635308099};\\\", \\\"{x:1017,y:523,t:1527635308115};\\\", \\\"{x:1054,y:562,t:1527635308133};\\\", \\\"{x:1069,y:579,t:1527635308149};\\\", \\\"{x:1080,y:602,t:1527635308165};\\\", \\\"{x:1099,y:641,t:1527635308183};\\\", \\\"{x:1115,y:680,t:1527635308200};\\\", \\\"{x:1131,y:723,t:1527635308215};\\\", \\\"{x:1143,y:758,t:1527635308232};\\\", \\\"{x:1155,y:781,t:1527635308250};\\\", \\\"{x:1168,y:803,t:1527635308266};\\\", \\\"{x:1195,y:837,t:1527635308283};\\\", \\\"{x:1218,y:866,t:1527635308300};\\\", \\\"{x:1234,y:886,t:1527635308316};\\\", \\\"{x:1256,y:909,t:1527635308333};\\\", \\\"{x:1264,y:915,t:1527635308349};\\\", \\\"{x:1271,y:920,t:1527635308367};\\\", \\\"{x:1274,y:923,t:1527635308383};\\\", \\\"{x:1275,y:923,t:1527635308400};\\\", \\\"{x:1276,y:923,t:1527635308417};\\\", \\\"{x:1278,y:923,t:1527635308433};\\\", \\\"{x:1284,y:923,t:1527635308450};\\\", \\\"{x:1302,y:923,t:1527635308467};\\\", \\\"{x:1320,y:922,t:1527635308483};\\\", \\\"{x:1336,y:920,t:1527635308500};\\\", \\\"{x:1355,y:912,t:1527635308517};\\\", \\\"{x:1361,y:907,t:1527635308533};\\\", \\\"{x:1363,y:905,t:1527635308550};\\\", \\\"{x:1363,y:903,t:1527635308567};\\\", \\\"{x:1364,y:898,t:1527635308583};\\\", \\\"{x:1364,y:893,t:1527635308599};\\\", \\\"{x:1362,y:882,t:1527635308617};\\\", \\\"{x:1360,y:872,t:1527635308634};\\\", \\\"{x:1360,y:870,t:1527635308649};\\\", \\\"{x:1359,y:868,t:1527635308667};\\\", \\\"{x:1358,y:867,t:1527635308684};\\\", \\\"{x:1357,y:864,t:1527635308902};\\\", \\\"{x:1354,y:858,t:1527635308917};\\\", \\\"{x:1354,y:855,t:1527635308934};\\\", \\\"{x:1353,y:852,t:1527635308951};\\\", \\\"{x:1352,y:848,t:1527635308967};\\\", \\\"{x:1351,y:843,t:1527635308984};\\\", \\\"{x:1351,y:841,t:1527635309002};\\\", \\\"{x:1350,y:837,t:1527635309018};\\\", \\\"{x:1350,y:832,t:1527635309034};\\\", \\\"{x:1350,y:827,t:1527635309051};\\\", \\\"{x:1350,y:818,t:1527635309067};\\\", \\\"{x:1350,y:810,t:1527635309084};\\\", \\\"{x:1350,y:797,t:1527635309101};\\\", \\\"{x:1349,y:790,t:1527635309118};\\\", \\\"{x:1346,y:777,t:1527635309135};\\\", \\\"{x:1346,y:765,t:1527635309151};\\\", \\\"{x:1345,y:752,t:1527635309167};\\\", \\\"{x:1345,y:751,t:1527635309184};\\\", \\\"{x:1345,y:748,t:1527635309203};\\\", \\\"{x:1345,y:747,t:1527635309221};\\\", \\\"{x:1345,y:745,t:1527635309237};\\\", \\\"{x:1345,y:744,t:1527635309250};\\\", \\\"{x:1345,y:739,t:1527635309268};\\\", \\\"{x:1345,y:733,t:1527635309284};\\\", \\\"{x:1346,y:726,t:1527635309301};\\\", \\\"{x:1347,y:721,t:1527635309317};\\\", \\\"{x:1347,y:714,t:1527635309334};\\\", \\\"{x:1351,y:705,t:1527635309351};\\\", \\\"{x:1355,y:694,t:1527635309368};\\\", \\\"{x:1357,y:685,t:1527635309384};\\\", \\\"{x:1358,y:676,t:1527635309403};\\\", \\\"{x:1360,y:670,t:1527635309417};\\\", \\\"{x:1361,y:666,t:1527635309435};\\\", \\\"{x:1361,y:660,t:1527635309450};\\\", \\\"{x:1361,y:654,t:1527635309467};\\\", \\\"{x:1361,y:650,t:1527635309484};\\\", \\\"{x:1361,y:649,t:1527635309500};\\\", \\\"{x:1360,y:648,t:1527635309589};\\\", \\\"{x:1358,y:654,t:1527635309601};\\\", \\\"{x:1356,y:674,t:1527635309618};\\\", \\\"{x:1351,y:695,t:1527635309635};\\\", \\\"{x:1347,y:719,t:1527635309650};\\\", \\\"{x:1344,y:738,t:1527635309668};\\\", \\\"{x:1342,y:759,t:1527635309684};\\\", \\\"{x:1342,y:764,t:1527635309700};\\\", \\\"{x:1342,y:767,t:1527635309717};\\\", \\\"{x:1342,y:770,t:1527635309734};\\\", \\\"{x:1342,y:771,t:1527635309752};\\\", \\\"{x:1342,y:774,t:1527635309767};\\\", \\\"{x:1342,y:765,t:1527635309910};\\\", \\\"{x:1342,y:752,t:1527635309918};\\\", \\\"{x:1342,y:731,t:1527635309935};\\\", \\\"{x:1342,y:709,t:1527635309952};\\\", \\\"{x:1342,y:692,t:1527635309968};\\\", \\\"{x:1342,y:680,t:1527635309984};\\\", \\\"{x:1342,y:669,t:1527635310001};\\\", \\\"{x:1342,y:663,t:1527635310018};\\\", \\\"{x:1342,y:658,t:1527635310035};\\\", \\\"{x:1342,y:655,t:1527635310051};\\\", \\\"{x:1342,y:652,t:1527635310069};\\\", \\\"{x:1342,y:651,t:1527635310085};\\\", \\\"{x:1342,y:650,t:1527635310102};\\\", \\\"{x:1342,y:649,t:1527635310119};\\\", \\\"{x:1342,y:648,t:1527635310135};\\\", \\\"{x:1342,y:646,t:1527635310151};\\\", \\\"{x:1342,y:644,t:1527635310169};\\\", \\\"{x:1343,y:641,t:1527635310185};\\\", \\\"{x:1344,y:638,t:1527635310202};\\\", \\\"{x:1344,y:635,t:1527635310219};\\\", \\\"{x:1347,y:631,t:1527635310235};\\\", \\\"{x:1348,y:625,t:1527635310252};\\\", \\\"{x:1352,y:617,t:1527635310269};\\\", \\\"{x:1354,y:613,t:1527635310285};\\\", \\\"{x:1355,y:611,t:1527635310301};\\\", \\\"{x:1355,y:609,t:1527635310319};\\\", \\\"{x:1356,y:607,t:1527635310336};\\\", \\\"{x:1358,y:603,t:1527635310352};\\\", \\\"{x:1359,y:598,t:1527635310369};\\\", \\\"{x:1359,y:596,t:1527635310385};\\\", \\\"{x:1359,y:595,t:1527635310402};\\\", \\\"{x:1360,y:593,t:1527635310430};\\\", \\\"{x:1360,y:591,t:1527635310461};\\\", \\\"{x:1360,y:589,t:1527635310478};\\\", \\\"{x:1360,y:588,t:1527635310566};\\\", \\\"{x:1360,y:586,t:1527635310581};\\\", \\\"{x:1360,y:585,t:1527635310589};\\\", \\\"{x:1360,y:584,t:1527635310603};\\\", \\\"{x:1359,y:581,t:1527635310619};\\\", \\\"{x:1358,y:579,t:1527635310636};\\\", \\\"{x:1357,y:576,t:1527635310653};\\\", \\\"{x:1356,y:575,t:1527635310709};\\\", \\\"{x:1356,y:574,t:1527635310719};\\\", \\\"{x:1354,y:569,t:1527635310736};\\\", \\\"{x:1351,y:560,t:1527635310753};\\\", \\\"{x:1350,y:549,t:1527635310769};\\\", \\\"{x:1350,y:532,t:1527635310786};\\\", \\\"{x:1350,y:519,t:1527635310803};\\\", \\\"{x:1350,y:505,t:1527635310820};\\\", \\\"{x:1351,y:490,t:1527635310836};\\\", \\\"{x:1351,y:476,t:1527635310853};\\\", \\\"{x:1351,y:463,t:1527635310869};\\\", \\\"{x:1351,y:448,t:1527635310886};\\\", \\\"{x:1350,y:425,t:1527635310903};\\\", \\\"{x:1348,y:409,t:1527635310920};\\\", \\\"{x:1345,y:399,t:1527635310937};\\\", \\\"{x:1341,y:383,t:1527635310954};\\\", \\\"{x:1339,y:376,t:1527635310970};\\\", \\\"{x:1336,y:368,t:1527635310987};\\\", \\\"{x:1332,y:362,t:1527635311004};\\\", \\\"{x:1332,y:360,t:1527635311020};\\\", \\\"{x:1331,y:358,t:1527635311036};\\\", \\\"{x:1329,y:356,t:1527635311053};\\\", \\\"{x:1321,y:356,t:1527635311070};\\\", \\\"{x:1310,y:356,t:1527635311087};\\\", \\\"{x:1296,y:356,t:1527635311103};\\\", \\\"{x:1271,y:356,t:1527635311120};\\\", \\\"{x:1243,y:356,t:1527635311137};\\\", \\\"{x:1171,y:362,t:1527635311152};\\\", \\\"{x:1092,y:377,t:1527635311169};\\\", \\\"{x:1011,y:394,t:1527635311187};\\\", \\\"{x:925,y:415,t:1527635311202};\\\", \\\"{x:856,y:434,t:1527635311219};\\\", \\\"{x:791,y:455,t:1527635311236};\\\", \\\"{x:764,y:467,t:1527635311252};\\\", \\\"{x:752,y:471,t:1527635311267};\\\", \\\"{x:725,y:484,t:1527635311285};\\\", \\\"{x:717,y:490,t:1527635311301};\\\", \\\"{x:712,y:497,t:1527635311318};\\\", \\\"{x:708,y:504,t:1527635311335};\\\", \\\"{x:702,y:511,t:1527635311352};\\\", \\\"{x:696,y:525,t:1527635311369};\\\", \\\"{x:683,y:541,t:1527635311384};\\\", \\\"{x:671,y:559,t:1527635311401};\\\", \\\"{x:660,y:576,t:1527635311419};\\\", \\\"{x:651,y:592,t:1527635311434};\\\", \\\"{x:643,y:611,t:1527635311452};\\\", \\\"{x:634,y:636,t:1527635311468};\\\", \\\"{x:629,y:649,t:1527635311485};\\\", \\\"{x:623,y:660,t:1527635311501};\\\", \\\"{x:616,y:672,t:1527635311518};\\\", \\\"{x:610,y:683,t:1527635311535};\\\", \\\"{x:603,y:691,t:1527635311552};\\\", \\\"{x:599,y:695,t:1527635311568};\\\", \\\"{x:595,y:697,t:1527635311585};\\\", \\\"{x:593,y:698,t:1527635311601};\\\", \\\"{x:591,y:698,t:1527635311661};\\\", \\\"{x:586,y:697,t:1527635311668};\\\", \\\"{x:577,y:691,t:1527635311686};\\\", \\\"{x:563,y:684,t:1527635311702};\\\", \\\"{x:550,y:674,t:1527635311723};\\\", \\\"{x:539,y:670,t:1527635311736};\\\", \\\"{x:530,y:667,t:1527635311752};\\\", \\\"{x:527,y:666,t:1527635311768};\\\", \\\"{x:526,y:666,t:1527635311784};\\\", \\\"{x:530,y:666,t:1527635314165};\\\", \\\"{x:549,y:666,t:1527635314173};\\\", \\\"{x:571,y:666,t:1527635314187};\\\", \\\"{x:602,y:666,t:1527635314204};\\\", \\\"{x:661,y:666,t:1527635314220};\\\", \\\"{x:701,y:666,t:1527635314237};\\\", \\\"{x:738,y:666,t:1527635314253};\\\", \\\"{x:770,y:666,t:1527635314271};\\\", \\\"{x:818,y:666,t:1527635314287};\\\", \\\"{x:846,y:666,t:1527635314303};\\\", \\\"{x:872,y:666,t:1527635314320};\\\", \\\"{x:889,y:666,t:1527635314337};\\\", \\\"{x:911,y:666,t:1527635314354};\\\", \\\"{x:924,y:666,t:1527635314371};\\\", \\\"{x:934,y:668,t:1527635314387};\\\", \\\"{x:941,y:671,t:1527635314403};\\\", \\\"{x:943,y:674,t:1527635314420};\\\", \\\"{x:942,y:676,t:1527635314733};\\\", \\\"{x:942,y:680,t:1527635314741};\\\", \\\"{x:938,y:685,t:1527635314754};\\\", \\\"{x:933,y:692,t:1527635314770};\\\", \\\"{x:926,y:695,t:1527635314788};\\\", \\\"{x:921,y:697,t:1527635314804};\\\", \\\"{x:901,y:700,t:1527635314820};\\\", \\\"{x:867,y:701,t:1527635314838};\\\", \\\"{x:783,y:697,t:1527635314854};\\\", \\\"{x:700,y:687,t:1527635314871};\\\", \\\"{x:626,y:673,t:1527635314888};\\\", \\\"{x:512,y:649,t:1527635314916};\\\", \\\"{x:494,y:642,t:1527635314924};\\\", \\\"{x:484,y:636,t:1527635314937};\\\", \\\"{x:465,y:622,t:1527635314954};\\\", \\\"{x:458,y:608,t:1527635314970};\\\", \\\"{x:449,y:586,t:1527635314986};\\\" ] }, { \\\"rt\\\": 72107, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 296655, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"8FE87\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-I -H -H -H -H -H -05 PM-04 PM-04 PM-4-04 PM-04 PM-03 PM-03 PM-04 PM-U -U -U -U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:605,y:333,t:1527635315109};\\\", \\\"{x:641,y:332,t:1527635315120};\\\", \\\"{x:715,y:334,t:1527635315138};\\\", \\\"{x:789,y:364,t:1527635315155};\\\", \\\"{x:854,y:412,t:1527635315171};\\\", \\\"{x:895,y:454,t:1527635315187};\\\", \\\"{x:919,y:496,t:1527635315204};\\\", \\\"{x:920,y:512,t:1527635315222};\\\", \\\"{x:911,y:534,t:1527635315252};\\\", \\\"{x:895,y:543,t:1527635315272};\\\", \\\"{x:866,y:550,t:1527635315288};\\\", \\\"{x:836,y:551,t:1527635315305};\\\", \\\"{x:806,y:551,t:1527635315322};\\\", \\\"{x:781,y:546,t:1527635315338};\\\", \\\"{x:761,y:536,t:1527635315355};\\\", \\\"{x:753,y:531,t:1527635315371};\\\", \\\"{x:748,y:526,t:1527635315387};\\\", \\\"{x:743,y:518,t:1527635315404};\\\", \\\"{x:738,y:510,t:1527635315421};\\\", \\\"{x:735,y:506,t:1527635315438};\\\", \\\"{x:732,y:503,t:1527635315454};\\\", \\\"{x:731,y:502,t:1527635315476};\\\", \\\"{x:678,y:499,t:1527635315580};\\\", \\\"{x:653,y:499,t:1527635315591};\\\", \\\"{x:632,y:499,t:1527635315605};\\\", \\\"{x:614,y:499,t:1527635315622};\\\", \\\"{x:599,y:499,t:1527635315637};\\\", \\\"{x:588,y:499,t:1527635315655};\\\", \\\"{x:574,y:499,t:1527635315672};\\\", \\\"{x:559,y:499,t:1527635315688};\\\", \\\"{x:543,y:497,t:1527635315705};\\\", \\\"{x:527,y:497,t:1527635315721};\\\", \\\"{x:506,y:495,t:1527635315739};\\\", \\\"{x:489,y:492,t:1527635315755};\\\", \\\"{x:474,y:489,t:1527635315772};\\\", \\\"{x:459,y:487,t:1527635315788};\\\", \\\"{x:454,y:487,t:1527635315805};\\\", \\\"{x:451,y:486,t:1527635315822};\\\", \\\"{x:450,y:486,t:1527635315838};\\\", \\\"{x:449,y:485,t:1527635315855};\\\", \\\"{x:446,y:484,t:1527635315871};\\\", \\\"{x:444,y:483,t:1527635315889};\\\", \\\"{x:443,y:482,t:1527635315905};\\\", \\\"{x:442,y:481,t:1527635315921};\\\", \\\"{x:439,y:478,t:1527635315938};\\\", \\\"{x:438,y:474,t:1527635315955};\\\", \\\"{x:435,y:463,t:1527635315972};\\\", \\\"{x:435,y:456,t:1527635315989};\\\", \\\"{x:437,y:447,t:1527635316007};\\\", \\\"{x:445,y:431,t:1527635316022};\\\", \\\"{x:452,y:413,t:1527635316038};\\\", \\\"{x:457,y:398,t:1527635316054};\\\", \\\"{x:462,y:386,t:1527635316072};\\\", \\\"{x:468,y:382,t:1527635316088};\\\", \\\"{x:472,y:378,t:1527635316105};\\\", \\\"{x:477,y:374,t:1527635316121};\\\", \\\"{x:483,y:370,t:1527635316138};\\\", \\\"{x:491,y:366,t:1527635316156};\\\", \\\"{x:496,y:363,t:1527635316172};\\\", \\\"{x:500,y:363,t:1527635316188};\\\", \\\"{x:504,y:363,t:1527635316205};\\\", \\\"{x:505,y:363,t:1527635316221};\\\", \\\"{x:507,y:363,t:1527635316239};\\\", \\\"{x:511,y:364,t:1527635316365};\\\", \\\"{x:515,y:365,t:1527635316373};\\\", \\\"{x:527,y:368,t:1527635316389};\\\", \\\"{x:537,y:369,t:1527635316405};\\\", \\\"{x:548,y:369,t:1527635316422};\\\", \\\"{x:563,y:372,t:1527635316439};\\\", \\\"{x:582,y:372,t:1527635316456};\\\", \\\"{x:610,y:373,t:1527635316472};\\\", \\\"{x:636,y:374,t:1527635316489};\\\", \\\"{x:684,y:379,t:1527635316506};\\\", \\\"{x:765,y:379,t:1527635316522};\\\", \\\"{x:854,y:379,t:1527635316538};\\\", \\\"{x:951,y:379,t:1527635316556};\\\", \\\"{x:1031,y:379,t:1527635316572};\\\", \\\"{x:1142,y:379,t:1527635316589};\\\", \\\"{x:1210,y:380,t:1527635316606};\\\", \\\"{x:1267,y:391,t:1527635316623};\\\", \\\"{x:1338,y:406,t:1527635316638};\\\", \\\"{x:1413,y:416,t:1527635316656};\\\", \\\"{x:1492,y:435,t:1527635316673};\\\", \\\"{x:1580,y:452,t:1527635316689};\\\", \\\"{x:1689,y:476,t:1527635316706};\\\", \\\"{x:1774,y:495,t:1527635316722};\\\", \\\"{x:1826,y:515,t:1527635316739};\\\", \\\"{x:1857,y:530,t:1527635316756};\\\", \\\"{x:1868,y:541,t:1527635316773};\\\", \\\"{x:1869,y:542,t:1527635317149};\\\", \\\"{x:1869,y:543,t:1527635317293};\\\", \\\"{x:1869,y:545,t:1527635317308};\\\", \\\"{x:1868,y:545,t:1527635317325};\\\", \\\"{x:1865,y:545,t:1527635317340};\\\", \\\"{x:1855,y:545,t:1527635317357};\\\", \\\"{x:1831,y:545,t:1527635317373};\\\", \\\"{x:1812,y:545,t:1527635317390};\\\", \\\"{x:1792,y:545,t:1527635317406};\\\", \\\"{x:1767,y:545,t:1527635317423};\\\", \\\"{x:1742,y:548,t:1527635317440};\\\", \\\"{x:1715,y:548,t:1527635317456};\\\", \\\"{x:1692,y:548,t:1527635317473};\\\", \\\"{x:1667,y:548,t:1527635317490};\\\", \\\"{x:1646,y:548,t:1527635317507};\\\", \\\"{x:1629,y:548,t:1527635317523};\\\", \\\"{x:1612,y:548,t:1527635317540};\\\", \\\"{x:1579,y:548,t:1527635317557};\\\", \\\"{x:1556,y:548,t:1527635317573};\\\", \\\"{x:1527,y:548,t:1527635317591};\\\", \\\"{x:1484,y:548,t:1527635317607};\\\", \\\"{x:1429,y:553,t:1527635317623};\\\", \\\"{x:1353,y:565,t:1527635317640};\\\", \\\"{x:1295,y:582,t:1527635317658};\\\", \\\"{x:1226,y:602,t:1527635317673};\\\", \\\"{x:1191,y:611,t:1527635317690};\\\", \\\"{x:1165,y:616,t:1527635317707};\\\", \\\"{x:1152,y:617,t:1527635317723};\\\", \\\"{x:1144,y:618,t:1527635317740};\\\", \\\"{x:1141,y:619,t:1527635317758};\\\", \\\"{x:1140,y:619,t:1527635317805};\\\", \\\"{x:1138,y:619,t:1527635317812};\\\", \\\"{x:1136,y:620,t:1527635317823};\\\", \\\"{x:1132,y:625,t:1527635317839};\\\", \\\"{x:1131,y:626,t:1527635317857};\\\", \\\"{x:1130,y:626,t:1527635317872};\\\", \\\"{x:1131,y:626,t:1527635318445};\\\", \\\"{x:1132,y:626,t:1527635318457};\\\", \\\"{x:1133,y:626,t:1527635318474};\\\", \\\"{x:1134,y:626,t:1527635318491};\\\", \\\"{x:1135,y:626,t:1527635318557};\\\", \\\"{x:1139,y:625,t:1527635318574};\\\", \\\"{x:1142,y:624,t:1527635318591};\\\", \\\"{x:1149,y:624,t:1527635318607};\\\", \\\"{x:1164,y:623,t:1527635318625};\\\", \\\"{x:1194,y:620,t:1527635318641};\\\", \\\"{x:1216,y:618,t:1527635318657};\\\", \\\"{x:1238,y:612,t:1527635318675};\\\", \\\"{x:1250,y:608,t:1527635318691};\\\", \\\"{x:1256,y:605,t:1527635318708};\\\", \\\"{x:1264,y:602,t:1527635318724};\\\", \\\"{x:1278,y:602,t:1527635318741};\\\", \\\"{x:1297,y:602,t:1527635318758};\\\", \\\"{x:1315,y:607,t:1527635318774};\\\", \\\"{x:1343,y:611,t:1527635318791};\\\", \\\"{x:1369,y:617,t:1527635318807};\\\", \\\"{x:1394,y:623,t:1527635318825};\\\", \\\"{x:1417,y:624,t:1527635318841};\\\", \\\"{x:1443,y:625,t:1527635318857};\\\", \\\"{x:1469,y:629,t:1527635318874};\\\", \\\"{x:1494,y:635,t:1527635318891};\\\", \\\"{x:1529,y:648,t:1527635318908};\\\", \\\"{x:1556,y:658,t:1527635318925};\\\", \\\"{x:1595,y:674,t:1527635318941};\\\", \\\"{x:1619,y:687,t:1527635318959};\\\", \\\"{x:1640,y:695,t:1527635318974};\\\", \\\"{x:1652,y:700,t:1527635318992};\\\", \\\"{x:1658,y:701,t:1527635319008};\\\", \\\"{x:1659,y:701,t:1527635319024};\\\", \\\"{x:1660,y:703,t:1527635319094};\\\", \\\"{x:1662,y:704,t:1527635319109};\\\", \\\"{x:1666,y:709,t:1527635319124};\\\", \\\"{x:1671,y:718,t:1527635319142};\\\", \\\"{x:1671,y:721,t:1527635319158};\\\", \\\"{x:1674,y:726,t:1527635319174};\\\", \\\"{x:1674,y:728,t:1527635319192};\\\", \\\"{x:1674,y:731,t:1527635319208};\\\", \\\"{x:1674,y:732,t:1527635319224};\\\", \\\"{x:1674,y:734,t:1527635319241};\\\", \\\"{x:1672,y:738,t:1527635319258};\\\", \\\"{x:1668,y:746,t:1527635319275};\\\", \\\"{x:1662,y:756,t:1527635319291};\\\", \\\"{x:1653,y:778,t:1527635319309};\\\", \\\"{x:1649,y:785,t:1527635319325};\\\", \\\"{x:1638,y:811,t:1527635319341};\\\", \\\"{x:1633,y:822,t:1527635319358};\\\", \\\"{x:1630,y:828,t:1527635319375};\\\", \\\"{x:1627,y:831,t:1527635319391};\\\", \\\"{x:1627,y:832,t:1527635319409};\\\", \\\"{x:1626,y:832,t:1527635319436};\\\", \\\"{x:1625,y:833,t:1527635319451};\\\", \\\"{x:1624,y:836,t:1527635319460};\\\", \\\"{x:1623,y:841,t:1527635319475};\\\", \\\"{x:1621,y:849,t:1527635319490};\\\", \\\"{x:1617,y:865,t:1527635319507};\\\", \\\"{x:1616,y:872,t:1527635319524};\\\", \\\"{x:1615,y:878,t:1527635319541};\\\", \\\"{x:1615,y:880,t:1527635319558};\\\", \\\"{x:1615,y:881,t:1527635319575};\\\", \\\"{x:1614,y:882,t:1527635319591};\\\", \\\"{x:1614,y:883,t:1527635319620};\\\", \\\"{x:1614,y:885,t:1527635319629};\\\", \\\"{x:1614,y:887,t:1527635319641};\\\", \\\"{x:1614,y:893,t:1527635319658};\\\", \\\"{x:1614,y:900,t:1527635319675};\\\", \\\"{x:1614,y:904,t:1527635319691};\\\", \\\"{x:1614,y:909,t:1527635319708};\\\", \\\"{x:1614,y:911,t:1527635319725};\\\", \\\"{x:1614,y:912,t:1527635319885};\\\", \\\"{x:1614,y:913,t:1527635320086};\\\", \\\"{x:1614,y:914,t:1527635320413};\\\", \\\"{x:1614,y:915,t:1527635320557};\\\", \\\"{x:1615,y:917,t:1527635320565};\\\", \\\"{x:1615,y:918,t:1527635320581};\\\", \\\"{x:1615,y:919,t:1527635320765};\\\", \\\"{x:1616,y:919,t:1527635320775};\\\", \\\"{x:1616,y:920,t:1527635320792};\\\", \\\"{x:1616,y:921,t:1527635320932};\\\", \\\"{x:1616,y:923,t:1527635320942};\\\", \\\"{x:1616,y:924,t:1527635320958};\\\", \\\"{x:1616,y:925,t:1527635320976};\\\", \\\"{x:1617,y:925,t:1527635321021};\\\", \\\"{x:1618,y:925,t:1527635321028};\\\", \\\"{x:1619,y:925,t:1527635321229};\\\", \\\"{x:1619,y:924,t:1527635321242};\\\", \\\"{x:1619,y:923,t:1527635321309};\\\", \\\"{x:1620,y:921,t:1527635321405};\\\", \\\"{x:1620,y:920,t:1527635321413};\\\", \\\"{x:1620,y:919,t:1527635321426};\\\", \\\"{x:1620,y:918,t:1527635321443};\\\", \\\"{x:1619,y:918,t:1527635322213};\\\", \\\"{x:1618,y:918,t:1527635322429};\\\", \\\"{x:1617,y:918,t:1527635322662};\\\", \\\"{x:1615,y:918,t:1527635325293};\\\", \\\"{x:1613,y:918,t:1527635325301};\\\", \\\"{x:1612,y:918,t:1527635325312};\\\", \\\"{x:1610,y:918,t:1527635325329};\\\", \\\"{x:1609,y:918,t:1527635325346};\\\", \\\"{x:1608,y:918,t:1527635325453};\\\", \\\"{x:1607,y:918,t:1527635325462};\\\", \\\"{x:1607,y:917,t:1527635325781};\\\", \\\"{x:1609,y:915,t:1527635325798};\\\", \\\"{x:1610,y:915,t:1527635325829};\\\", \\\"{x:1611,y:914,t:1527635326198};\\\", \\\"{x:1612,y:913,t:1527635326214};\\\", \\\"{x:1612,y:912,t:1527635326230};\\\", \\\"{x:1613,y:912,t:1527635326429};\\\", \\\"{x:1613,y:911,t:1527635326669};\\\", \\\"{x:1613,y:909,t:1527635326725};\\\", \\\"{x:1615,y:907,t:1527635326733};\\\", \\\"{x:1616,y:905,t:1527635326756};\\\", \\\"{x:1617,y:905,t:1527635327133};\\\", \\\"{x:1617,y:906,t:1527635327165};\\\", \\\"{x:1617,y:908,t:1527635327181};\\\", \\\"{x:1617,y:910,t:1527635327198};\\\", \\\"{x:1617,y:911,t:1527635327214};\\\", \\\"{x:1617,y:913,t:1527635327237};\\\", \\\"{x:1617,y:914,t:1527635327277};\\\", \\\"{x:1616,y:914,t:1527635327662};\\\", \\\"{x:1615,y:913,t:1527635327669};\\\", \\\"{x:1615,y:912,t:1527635327701};\\\", \\\"{x:1615,y:911,t:1527635327733};\\\", \\\"{x:1614,y:910,t:1527635327766};\\\", \\\"{x:1613,y:909,t:1527635327838};\\\", \\\"{x:1612,y:908,t:1527635327909};\\\", \\\"{x:1611,y:907,t:1527635327932};\\\", \\\"{x:1610,y:905,t:1527635328020};\\\", \\\"{x:1609,y:904,t:1527635328060};\\\", \\\"{x:1610,y:905,t:1527635328404};\\\", \\\"{x:1611,y:907,t:1527635328414};\\\", \\\"{x:1613,y:909,t:1527635328431};\\\", \\\"{x:1614,y:910,t:1527635328453};\\\", \\\"{x:1615,y:911,t:1527635328485};\\\", \\\"{x:1616,y:911,t:1527635328550};\\\", \\\"{x:1617,y:911,t:1527635328997};\\\", \\\"{x:1617,y:910,t:1527635329125};\\\", \\\"{x:1616,y:909,t:1527635329149};\\\", \\\"{x:1616,y:908,t:1527635329167};\\\", \\\"{x:1615,y:908,t:1527635329182};\\\", \\\"{x:1614,y:907,t:1527635329213};\\\", \\\"{x:1613,y:907,t:1527635329237};\\\", \\\"{x:1612,y:905,t:1527635329277};\\\", \\\"{x:1610,y:903,t:1527635329293};\\\", \\\"{x:1610,y:902,t:1527635329301};\\\", \\\"{x:1610,y:901,t:1527635329315};\\\", \\\"{x:1608,y:899,t:1527635329332};\\\", \\\"{x:1606,y:897,t:1527635329348};\\\", \\\"{x:1606,y:895,t:1527635329372};\\\", \\\"{x:1604,y:894,t:1527635329382};\\\", \\\"{x:1604,y:890,t:1527635329399};\\\", \\\"{x:1599,y:887,t:1527635329417};\\\", \\\"{x:1597,y:881,t:1527635329433};\\\", \\\"{x:1592,y:874,t:1527635329448};\\\", \\\"{x:1585,y:863,t:1527635329465};\\\", \\\"{x:1582,y:854,t:1527635329482};\\\", \\\"{x:1570,y:834,t:1527635329498};\\\", \\\"{x:1543,y:796,t:1527635329515};\\\", \\\"{x:1490,y:741,t:1527635329532};\\\", \\\"{x:1451,y:707,t:1527635329548};\\\", \\\"{x:1422,y:671,t:1527635329565};\\\", \\\"{x:1402,y:644,t:1527635329582};\\\", \\\"{x:1382,y:617,t:1527635329598};\\\", \\\"{x:1368,y:589,t:1527635329615};\\\", \\\"{x:1356,y:569,t:1527635329632};\\\", \\\"{x:1349,y:557,t:1527635329648};\\\", \\\"{x:1339,y:534,t:1527635329665};\\\", \\\"{x:1330,y:516,t:1527635329683};\\\", \\\"{x:1323,y:499,t:1527635329698};\\\", \\\"{x:1319,y:487,t:1527635329715};\\\", \\\"{x:1316,y:474,t:1527635329732};\\\", \\\"{x:1314,y:469,t:1527635329749};\\\", \\\"{x:1314,y:463,t:1527635329765};\\\", \\\"{x:1313,y:457,t:1527635329782};\\\", \\\"{x:1313,y:451,t:1527635329798};\\\", \\\"{x:1313,y:446,t:1527635329818};\\\", \\\"{x:1313,y:441,t:1527635329833};\\\", \\\"{x:1313,y:435,t:1527635329850};\\\", \\\"{x:1315,y:430,t:1527635329865};\\\", \\\"{x:1318,y:425,t:1527635329883};\\\", \\\"{x:1319,y:419,t:1527635329900};\\\", \\\"{x:1323,y:411,t:1527635329916};\\\", \\\"{x:1326,y:408,t:1527635329932};\\\", \\\"{x:1327,y:405,t:1527635329949};\\\", \\\"{x:1328,y:404,t:1527635329965};\\\", \\\"{x:1329,y:403,t:1527635329983};\\\", \\\"{x:1329,y:401,t:1527635329999};\\\", \\\"{x:1331,y:400,t:1527635330025};\\\", \\\"{x:1331,y:398,t:1527635330040};\\\", \\\"{x:1332,y:395,t:1527635330054};\\\", \\\"{x:1333,y:394,t:1527635330070};\\\", \\\"{x:1334,y:393,t:1527635330087};\\\", \\\"{x:1334,y:391,t:1527635330104};\\\", \\\"{x:1336,y:391,t:1527635330617};\\\", \\\"{x:1339,y:397,t:1527635330625};\\\", \\\"{x:1345,y:404,t:1527635330637};\\\", \\\"{x:1350,y:412,t:1527635330654};\\\", \\\"{x:1355,y:422,t:1527635330671};\\\", \\\"{x:1365,y:436,t:1527635330687};\\\", \\\"{x:1377,y:450,t:1527635330704};\\\", \\\"{x:1387,y:460,t:1527635330722};\\\", \\\"{x:1392,y:467,t:1527635330737};\\\", \\\"{x:1396,y:474,t:1527635330754};\\\", \\\"{x:1400,y:482,t:1527635330771};\\\", \\\"{x:1405,y:490,t:1527635330787};\\\", \\\"{x:1409,y:496,t:1527635330804};\\\", \\\"{x:1410,y:501,t:1527635330822};\\\", \\\"{x:1417,y:510,t:1527635330838};\\\", \\\"{x:1424,y:522,t:1527635330855};\\\", \\\"{x:1429,y:531,t:1527635330871};\\\", \\\"{x:1434,y:538,t:1527635330888};\\\", \\\"{x:1437,y:548,t:1527635330904};\\\", \\\"{x:1443,y:559,t:1527635330920};\\\", \\\"{x:1450,y:569,t:1527635330937};\\\", \\\"{x:1461,y:583,t:1527635330954};\\\", \\\"{x:1474,y:603,t:1527635330971};\\\", \\\"{x:1490,y:625,t:1527635330988};\\\", \\\"{x:1509,y:646,t:1527635331004};\\\", \\\"{x:1525,y:668,t:1527635331022};\\\", \\\"{x:1536,y:687,t:1527635331039};\\\", \\\"{x:1547,y:702,t:1527635331054};\\\", \\\"{x:1551,y:714,t:1527635331071};\\\", \\\"{x:1558,y:729,t:1527635331088};\\\", \\\"{x:1564,y:749,t:1527635331104};\\\", \\\"{x:1577,y:777,t:1527635331120};\\\", \\\"{x:1582,y:784,t:1527635331137};\\\", \\\"{x:1585,y:797,t:1527635331153};\\\", \\\"{x:1588,y:813,t:1527635331170};\\\", \\\"{x:1590,y:826,t:1527635331187};\\\", \\\"{x:1592,y:831,t:1527635331204};\\\", \\\"{x:1592,y:838,t:1527635331221};\\\", \\\"{x:1592,y:844,t:1527635331238};\\\", \\\"{x:1592,y:847,t:1527635331253};\\\", \\\"{x:1592,y:850,t:1527635331271};\\\", \\\"{x:1591,y:854,t:1527635331288};\\\", \\\"{x:1591,y:858,t:1527635331304};\\\", \\\"{x:1587,y:863,t:1527635331322};\\\", \\\"{x:1585,y:867,t:1527635331337};\\\", \\\"{x:1583,y:870,t:1527635331354};\\\", \\\"{x:1581,y:871,t:1527635331371};\\\", \\\"{x:1578,y:871,t:1527635331388};\\\", \\\"{x:1573,y:871,t:1527635331405};\\\", \\\"{x:1567,y:873,t:1527635331421};\\\", \\\"{x:1564,y:873,t:1527635331437};\\\", \\\"{x:1563,y:875,t:1527635331454};\\\", \\\"{x:1562,y:876,t:1527635331473};\\\", \\\"{x:1561,y:876,t:1527635331488};\\\", \\\"{x:1559,y:878,t:1527635331505};\\\", \\\"{x:1556,y:879,t:1527635331523};\\\", \\\"{x:1554,y:882,t:1527635331538};\\\", \\\"{x:1553,y:883,t:1527635331561};\\\", \\\"{x:1552,y:884,t:1527635331576};\\\", \\\"{x:1552,y:885,t:1527635331593};\\\", \\\"{x:1551,y:886,t:1527635331605};\\\", \\\"{x:1550,y:886,t:1527635331621};\\\", \\\"{x:1549,y:887,t:1527635331638};\\\", \\\"{x:1549,y:889,t:1527635331655};\\\", \\\"{x:1547,y:891,t:1527635331671};\\\", \\\"{x:1546,y:894,t:1527635331688};\\\", \\\"{x:1546,y:897,t:1527635331705};\\\", \\\"{x:1545,y:900,t:1527635331722};\\\", \\\"{x:1545,y:901,t:1527635331745};\\\", \\\"{x:1545,y:902,t:1527635331761};\\\", \\\"{x:1545,y:904,t:1527635331777};\\\", \\\"{x:1544,y:904,t:1527635331788};\\\", \\\"{x:1544,y:906,t:1527635331817};\\\", \\\"{x:1543,y:907,t:1527635331825};\\\", \\\"{x:1543,y:908,t:1527635331841};\\\", \\\"{x:1543,y:910,t:1527635331865};\\\", \\\"{x:1543,y:911,t:1527635331889};\\\", \\\"{x:1543,y:912,t:1527635332170};\\\", \\\"{x:1546,y:913,t:1527635332177};\\\", \\\"{x:1548,y:913,t:1527635332188};\\\", \\\"{x:1556,y:913,t:1527635332205};\\\", \\\"{x:1568,y:911,t:1527635332222};\\\", \\\"{x:1574,y:908,t:1527635332239};\\\", \\\"{x:1581,y:905,t:1527635332255};\\\", \\\"{x:1584,y:904,t:1527635332272};\\\", \\\"{x:1589,y:904,t:1527635332288};\\\", \\\"{x:1596,y:901,t:1527635332305};\\\", \\\"{x:1600,y:901,t:1527635332322};\\\", \\\"{x:1605,y:900,t:1527635332339};\\\", \\\"{x:1607,y:900,t:1527635332355};\\\", \\\"{x:1608,y:900,t:1527635332433};\\\", \\\"{x:1611,y:900,t:1527635332481};\\\", \\\"{x:1613,y:901,t:1527635332497};\\\", \\\"{x:1615,y:901,t:1527635332505};\\\", \\\"{x:1615,y:902,t:1527635332657};\\\", \\\"{x:1615,y:903,t:1527635332673};\\\", \\\"{x:1615,y:904,t:1527635332697};\\\", \\\"{x:1615,y:905,t:1527635332729};\\\", \\\"{x:1615,y:906,t:1527635332778};\\\", \\\"{x:1614,y:906,t:1527635333786};\\\", \\\"{x:1613,y:906,t:1527635333930};\\\", \\\"{x:1612,y:906,t:1527635334185};\\\", \\\"{x:1612,y:905,t:1527635334192};\\\", \\\"{x:1612,y:903,t:1527635334207};\\\", \\\"{x:1611,y:902,t:1527635334223};\\\", \\\"{x:1610,y:901,t:1527635334240};\\\", \\\"{x:1609,y:900,t:1527635334257};\\\", \\\"{x:1609,y:898,t:1527635334313};\\\", \\\"{x:1608,y:898,t:1527635334337};\\\", \\\"{x:1608,y:897,t:1527635334360};\\\", \\\"{x:1607,y:896,t:1527635334373};\\\", \\\"{x:1606,y:894,t:1527635334390};\\\", \\\"{x:1604,y:891,t:1527635334408};\\\", \\\"{x:1602,y:888,t:1527635334423};\\\", \\\"{x:1599,y:883,t:1527635334440};\\\", \\\"{x:1597,y:873,t:1527635334455};\\\", \\\"{x:1595,y:870,t:1527635334472};\\\", \\\"{x:1593,y:865,t:1527635334490};\\\", \\\"{x:1592,y:863,t:1527635334507};\\\", \\\"{x:1591,y:860,t:1527635334522};\\\", \\\"{x:1591,y:858,t:1527635334539};\\\", \\\"{x:1590,y:856,t:1527635334557};\\\", \\\"{x:1590,y:854,t:1527635334572};\\\", \\\"{x:1588,y:852,t:1527635334590};\\\", \\\"{x:1588,y:851,t:1527635334606};\\\", \\\"{x:1588,y:850,t:1527635334632};\\\", \\\"{x:1587,y:849,t:1527635334640};\\\", \\\"{x:1587,y:848,t:1527635334697};\\\", \\\"{x:1586,y:847,t:1527635334721};\\\", \\\"{x:1586,y:846,t:1527635334736};\\\", \\\"{x:1586,y:844,t:1527635334745};\\\", \\\"{x:1585,y:843,t:1527635334757};\\\", \\\"{x:1584,y:842,t:1527635334774};\\\", \\\"{x:1584,y:841,t:1527635334790};\\\", \\\"{x:1584,y:839,t:1527635334824};\\\", \\\"{x:1583,y:839,t:1527635334840};\\\", \\\"{x:1583,y:838,t:1527635334889};\\\", \\\"{x:1582,y:837,t:1527635334952};\\\", \\\"{x:1582,y:836,t:1527635334968};\\\", \\\"{x:1582,y:835,t:1527635334976};\\\", \\\"{x:1581,y:835,t:1527635334991};\\\", \\\"{x:1581,y:833,t:1527635335006};\\\", \\\"{x:1579,y:831,t:1527635335024};\\\", \\\"{x:1575,y:822,t:1527635335040};\\\", \\\"{x:1573,y:815,t:1527635335056};\\\", \\\"{x:1567,y:807,t:1527635335073};\\\", \\\"{x:1560,y:796,t:1527635335090};\\\", \\\"{x:1556,y:790,t:1527635335107};\\\", \\\"{x:1552,y:785,t:1527635335123};\\\", \\\"{x:1550,y:781,t:1527635335140};\\\", \\\"{x:1548,y:778,t:1527635335157};\\\", \\\"{x:1547,y:777,t:1527635335173};\\\", \\\"{x:1544,y:773,t:1527635335191};\\\", \\\"{x:1544,y:772,t:1527635335206};\\\", \\\"{x:1543,y:770,t:1527635335224};\\\", \\\"{x:1542,y:770,t:1527635335257};\\\", \\\"{x:1542,y:769,t:1527635335274};\\\", \\\"{x:1542,y:770,t:1527635335561};\\\", \\\"{x:1542,y:771,t:1527635335574};\\\", \\\"{x:1542,y:774,t:1527635335591};\\\", \\\"{x:1543,y:776,t:1527635335609};\\\", \\\"{x:1543,y:778,t:1527635335624};\\\", \\\"{x:1544,y:778,t:1527635335641};\\\", \\\"{x:1545,y:780,t:1527635335705};\\\", \\\"{x:1546,y:781,t:1527635335786};\\\", \\\"{x:1546,y:783,t:1527635335866};\\\", \\\"{x:1546,y:780,t:1527635336457};\\\", \\\"{x:1544,y:775,t:1527635336475};\\\", \\\"{x:1543,y:772,t:1527635336491};\\\", \\\"{x:1541,y:767,t:1527635336508};\\\", \\\"{x:1540,y:761,t:1527635336526};\\\", \\\"{x:1540,y:757,t:1527635336542};\\\", \\\"{x:1537,y:751,t:1527635336559};\\\", \\\"{x:1533,y:745,t:1527635336575};\\\", \\\"{x:1528,y:739,t:1527635336593};\\\", \\\"{x:1527,y:737,t:1527635336608};\\\", \\\"{x:1521,y:729,t:1527635336625};\\\", \\\"{x:1515,y:719,t:1527635336642};\\\", \\\"{x:1508,y:708,t:1527635336658};\\\", \\\"{x:1503,y:700,t:1527635336675};\\\", \\\"{x:1496,y:689,t:1527635336692};\\\", \\\"{x:1491,y:681,t:1527635336709};\\\", \\\"{x:1479,y:667,t:1527635336725};\\\", \\\"{x:1464,y:644,t:1527635336742};\\\", \\\"{x:1451,y:625,t:1527635336758};\\\", \\\"{x:1441,y:609,t:1527635336775};\\\", \\\"{x:1432,y:596,t:1527635336792};\\\", \\\"{x:1424,y:579,t:1527635336809};\\\", \\\"{x:1416,y:568,t:1527635336825};\\\", \\\"{x:1405,y:550,t:1527635336842};\\\", \\\"{x:1399,y:539,t:1527635336859};\\\", \\\"{x:1395,y:532,t:1527635336875};\\\", \\\"{x:1391,y:526,t:1527635336892};\\\", \\\"{x:1390,y:522,t:1527635336908};\\\", \\\"{x:1389,y:520,t:1527635336925};\\\", \\\"{x:1388,y:517,t:1527635336942};\\\", \\\"{x:1388,y:515,t:1527635336958};\\\", \\\"{x:1387,y:512,t:1527635336975};\\\", \\\"{x:1385,y:508,t:1527635336992};\\\", \\\"{x:1384,y:501,t:1527635337009};\\\", \\\"{x:1383,y:496,t:1527635337025};\\\", \\\"{x:1383,y:493,t:1527635337042};\\\", \\\"{x:1381,y:488,t:1527635337059};\\\", \\\"{x:1381,y:483,t:1527635337075};\\\", \\\"{x:1381,y:480,t:1527635337091};\\\", \\\"{x:1380,y:478,t:1527635337109};\\\", \\\"{x:1380,y:475,t:1527635337124};\\\", \\\"{x:1379,y:475,t:1527635337141};\\\", \\\"{x:1380,y:474,t:1527635337329};\\\", \\\"{x:1383,y:476,t:1527635337342};\\\", \\\"{x:1390,y:483,t:1527635337360};\\\", \\\"{x:1394,y:487,t:1527635337376};\\\", \\\"{x:1397,y:490,t:1527635337392};\\\", \\\"{x:1402,y:493,t:1527635337409};\\\", \\\"{x:1404,y:496,t:1527635337425};\\\", \\\"{x:1406,y:499,t:1527635337443};\\\", \\\"{x:1408,y:500,t:1527635337459};\\\", \\\"{x:1409,y:501,t:1527635337475};\\\", \\\"{x:1412,y:504,t:1527635337492};\\\", \\\"{x:1413,y:505,t:1527635337510};\\\", \\\"{x:1414,y:507,t:1527635337525};\\\", \\\"{x:1415,y:508,t:1527635337544};\\\", \\\"{x:1415,y:509,t:1527635337568};\\\", \\\"{x:1416,y:510,t:1527635337576};\\\", \\\"{x:1417,y:510,t:1527635337608};\\\", \\\"{x:1417,y:511,t:1527635337641};\\\", \\\"{x:1418,y:511,t:1527635337705};\\\", \\\"{x:1416,y:511,t:1527635337935};\\\", \\\"{x:1414,y:511,t:1527635337944};\\\", \\\"{x:1411,y:508,t:1527635337959};\\\", \\\"{x:1405,y:506,t:1527635337976};\\\", \\\"{x:1403,y:506,t:1527635337992};\\\", \\\"{x:1403,y:505,t:1527635338009};\\\", \\\"{x:1405,y:505,t:1527635339529};\\\", \\\"{x:1407,y:505,t:1527635339544};\\\", \\\"{x:1409,y:506,t:1527635339577};\\\", \\\"{x:1410,y:506,t:1527635339601};\\\", \\\"{x:1411,y:507,t:1527635339627};\\\", \\\"{x:1411,y:511,t:1527635346361};\\\", \\\"{x:1411,y:521,t:1527635346369};\\\", \\\"{x:1411,y:528,t:1527635346383};\\\", \\\"{x:1411,y:544,t:1527635346398};\\\", \\\"{x:1411,y:558,t:1527635346416};\\\", \\\"{x:1412,y:577,t:1527635346433};\\\", \\\"{x:1416,y:586,t:1527635346449};\\\", \\\"{x:1418,y:600,t:1527635346465};\\\", \\\"{x:1421,y:612,t:1527635346483};\\\", \\\"{x:1424,y:625,t:1527635346499};\\\", \\\"{x:1430,y:638,t:1527635346516};\\\", \\\"{x:1434,y:650,t:1527635346533};\\\", \\\"{x:1441,y:665,t:1527635346549};\\\", \\\"{x:1448,y:681,t:1527635346566};\\\", \\\"{x:1453,y:695,t:1527635346582};\\\", \\\"{x:1458,y:715,t:1527635346600};\\\", \\\"{x:1461,y:731,t:1527635346616};\\\", \\\"{x:1466,y:764,t:1527635346633};\\\", \\\"{x:1470,y:778,t:1527635346649};\\\", \\\"{x:1476,y:793,t:1527635346666};\\\", \\\"{x:1476,y:799,t:1527635346682};\\\", \\\"{x:1476,y:802,t:1527635346699};\\\", \\\"{x:1476,y:803,t:1527635346723};\\\", \\\"{x:1477,y:803,t:1527635346745};\\\", \\\"{x:1478,y:803,t:1527635346753};\\\", \\\"{x:1482,y:803,t:1527635347257};\\\", \\\"{x:1485,y:803,t:1527635347266};\\\", \\\"{x:1492,y:799,t:1527635347283};\\\", \\\"{x:1495,y:796,t:1527635347300};\\\", \\\"{x:1497,y:794,t:1527635347317};\\\", \\\"{x:1499,y:792,t:1527635347332};\\\", \\\"{x:1501,y:791,t:1527635347361};\\\", \\\"{x:1501,y:790,t:1527635347369};\\\", \\\"{x:1502,y:789,t:1527635347383};\\\", \\\"{x:1504,y:786,t:1527635347400};\\\", \\\"{x:1507,y:782,t:1527635347417};\\\", \\\"{x:1509,y:780,t:1527635347433};\\\", \\\"{x:1509,y:776,t:1527635347450};\\\", \\\"{x:1509,y:773,t:1527635347467};\\\", \\\"{x:1510,y:771,t:1527635347483};\\\", \\\"{x:1511,y:769,t:1527635347500};\\\", \\\"{x:1511,y:767,t:1527635347517};\\\", \\\"{x:1511,y:764,t:1527635347533};\\\", \\\"{x:1507,y:761,t:1527635347550};\\\", \\\"{x:1500,y:757,t:1527635347567};\\\", \\\"{x:1484,y:753,t:1527635347584};\\\", \\\"{x:1463,y:747,t:1527635347600};\\\", \\\"{x:1427,y:740,t:1527635347617};\\\", \\\"{x:1406,y:736,t:1527635347633};\\\", \\\"{x:1389,y:735,t:1527635347649};\\\", \\\"{x:1370,y:735,t:1527635347667};\\\", \\\"{x:1353,y:735,t:1527635347684};\\\", \\\"{x:1332,y:737,t:1527635347700};\\\", \\\"{x:1313,y:744,t:1527635347717};\\\", \\\"{x:1283,y:749,t:1527635347733};\\\", \\\"{x:1256,y:754,t:1527635347749};\\\", \\\"{x:1238,y:761,t:1527635347767};\\\", \\\"{x:1226,y:766,t:1527635347784};\\\", \\\"{x:1220,y:769,t:1527635347800};\\\", \\\"{x:1208,y:778,t:1527635347817};\\\", \\\"{x:1202,y:787,t:1527635347833};\\\", \\\"{x:1193,y:798,t:1527635347849};\\\", \\\"{x:1185,y:813,t:1527635347866};\\\", \\\"{x:1175,y:828,t:1527635347883};\\\", \\\"{x:1166,y:839,t:1527635347899};\\\", \\\"{x:1161,y:847,t:1527635347915};\\\", \\\"{x:1155,y:855,t:1527635347933};\\\", \\\"{x:1151,y:859,t:1527635347950};\\\", \\\"{x:1149,y:862,t:1527635347966};\\\", \\\"{x:1148,y:863,t:1527635348000};\\\", \\\"{x:1145,y:864,t:1527635348016};\\\", \\\"{x:1141,y:866,t:1527635348033};\\\", \\\"{x:1137,y:868,t:1527635348050};\\\", \\\"{x:1136,y:869,t:1527635348066};\\\", \\\"{x:1134,y:869,t:1527635348121};\\\", \\\"{x:1133,y:867,t:1527635348133};\\\", \\\"{x:1130,y:862,t:1527635348150};\\\", \\\"{x:1128,y:860,t:1527635348166};\\\", \\\"{x:1126,y:858,t:1527635348183};\\\", \\\"{x:1124,y:853,t:1527635348200};\\\", \\\"{x:1123,y:852,t:1527635348216};\\\", \\\"{x:1123,y:851,t:1527635348257};\\\", \\\"{x:1123,y:850,t:1527635348273};\\\", \\\"{x:1123,y:849,t:1527635348283};\\\", \\\"{x:1123,y:847,t:1527635348300};\\\", \\\"{x:1123,y:843,t:1527635348317};\\\", \\\"{x:1129,y:839,t:1527635348333};\\\", \\\"{x:1139,y:835,t:1527635348350};\\\", \\\"{x:1152,y:828,t:1527635348368};\\\", \\\"{x:1176,y:823,t:1527635348383};\\\", \\\"{x:1220,y:818,t:1527635348400};\\\", \\\"{x:1257,y:818,t:1527635348418};\\\", \\\"{x:1313,y:817,t:1527635348433};\\\", \\\"{x:1380,y:817,t:1527635348450};\\\", \\\"{x:1426,y:820,t:1527635348468};\\\", \\\"{x:1469,y:824,t:1527635348483};\\\", \\\"{x:1497,y:829,t:1527635348501};\\\", \\\"{x:1512,y:830,t:1527635348517};\\\", \\\"{x:1523,y:832,t:1527635348533};\\\", \\\"{x:1533,y:835,t:1527635348550};\\\", \\\"{x:1552,y:843,t:1527635348568};\\\", \\\"{x:1576,y:853,t:1527635348584};\\\", \\\"{x:1623,y:881,t:1527635348600};\\\", \\\"{x:1641,y:892,t:1527635348617};\\\", \\\"{x:1653,y:899,t:1527635348633};\\\", \\\"{x:1659,y:905,t:1527635348650};\\\", \\\"{x:1662,y:907,t:1527635348667};\\\", \\\"{x:1662,y:908,t:1527635348684};\\\", \\\"{x:1663,y:909,t:1527635348704};\\\", \\\"{x:1663,y:910,t:1527635348722};\\\", \\\"{x:1665,y:911,t:1527635348734};\\\", \\\"{x:1665,y:915,t:1527635348751};\\\", \\\"{x:1665,y:918,t:1527635348768};\\\", \\\"{x:1665,y:920,t:1527635348784};\\\", \\\"{x:1660,y:928,t:1527635348800};\\\", \\\"{x:1651,y:929,t:1527635348817};\\\", \\\"{x:1642,y:933,t:1527635348833};\\\", \\\"{x:1641,y:933,t:1527635348850};\\\", \\\"{x:1632,y:934,t:1527635348867};\\\", \\\"{x:1626,y:934,t:1527635348883};\\\", \\\"{x:1620,y:934,t:1527635348901};\\\", \\\"{x:1617,y:932,t:1527635348917};\\\", \\\"{x:1616,y:932,t:1527635348934};\\\", \\\"{x:1615,y:931,t:1527635348951};\\\", \\\"{x:1614,y:931,t:1527635348984};\\\", \\\"{x:1613,y:931,t:1527635349337};\\\", \\\"{x:1612,y:931,t:1527635349409};\\\", \\\"{x:1612,y:929,t:1527635349417};\\\", \\\"{x:1612,y:927,t:1527635349435};\\\", \\\"{x:1610,y:923,t:1527635349452};\\\", \\\"{x:1610,y:921,t:1527635349467};\\\", \\\"{x:1609,y:918,t:1527635349484};\\\", \\\"{x:1609,y:917,t:1527635349501};\\\", \\\"{x:1608,y:916,t:1527635349544};\\\", \\\"{x:1608,y:915,t:1527635349600};\\\", \\\"{x:1608,y:912,t:1527635349618};\\\", \\\"{x:1608,y:910,t:1527635349635};\\\", \\\"{x:1609,y:909,t:1527635349664};\\\", \\\"{x:1610,y:909,t:1527635349680};\\\", \\\"{x:1611,y:909,t:1527635349712};\\\", \\\"{x:1613,y:908,t:1527635349728};\\\", \\\"{x:1613,y:907,t:1527635349945};\\\", \\\"{x:1613,y:903,t:1527635349952};\\\", \\\"{x:1612,y:894,t:1527635349969};\\\", \\\"{x:1608,y:886,t:1527635349985};\\\", \\\"{x:1604,y:879,t:1527635350002};\\\", \\\"{x:1601,y:874,t:1527635350019};\\\", \\\"{x:1598,y:870,t:1527635350035};\\\", \\\"{x:1596,y:865,t:1527635350052};\\\", \\\"{x:1595,y:864,t:1527635350068};\\\", \\\"{x:1594,y:863,t:1527635350085};\\\", \\\"{x:1592,y:861,t:1527635350102};\\\", \\\"{x:1591,y:859,t:1527635350119};\\\", \\\"{x:1590,y:857,t:1527635350135};\\\", \\\"{x:1589,y:856,t:1527635350152};\\\", \\\"{x:1588,y:851,t:1527635350168};\\\", \\\"{x:1586,y:848,t:1527635350185};\\\", \\\"{x:1586,y:846,t:1527635350201};\\\", \\\"{x:1585,y:845,t:1527635350219};\\\", \\\"{x:1585,y:843,t:1527635350235};\\\", \\\"{x:1584,y:842,t:1527635350257};\\\", \\\"{x:1584,y:840,t:1527635350280};\\\", \\\"{x:1583,y:839,t:1527635350337};\\\", \\\"{x:1583,y:837,t:1527635350385};\\\", \\\"{x:1582,y:836,t:1527635350425};\\\", \\\"{x:1581,y:836,t:1527635351065};\\\", \\\"{x:1579,y:835,t:1527635351073};\\\", \\\"{x:1578,y:833,t:1527635351086};\\\", \\\"{x:1575,y:829,t:1527635351102};\\\", \\\"{x:1570,y:822,t:1527635351118};\\\", \\\"{x:1563,y:812,t:1527635351136};\\\", \\\"{x:1558,y:802,t:1527635351152};\\\", \\\"{x:1556,y:800,t:1527635351168};\\\", \\\"{x:1555,y:798,t:1527635351185};\\\", \\\"{x:1554,y:797,t:1527635351202};\\\", \\\"{x:1554,y:795,t:1527635351219};\\\", \\\"{x:1553,y:794,t:1527635351236};\\\", \\\"{x:1552,y:792,t:1527635351252};\\\", \\\"{x:1551,y:789,t:1527635351270};\\\", \\\"{x:1551,y:787,t:1527635351286};\\\", \\\"{x:1551,y:786,t:1527635351302};\\\", \\\"{x:1551,y:784,t:1527635351320};\\\", \\\"{x:1551,y:783,t:1527635351335};\\\", \\\"{x:1550,y:780,t:1527635351352};\\\", \\\"{x:1550,y:779,t:1527635351369};\\\", \\\"{x:1550,y:776,t:1527635351385};\\\", \\\"{x:1548,y:774,t:1527635351403};\\\", \\\"{x:1548,y:773,t:1527635351424};\\\", \\\"{x:1548,y:772,t:1527635351481};\\\", \\\"{x:1547,y:772,t:1527635355329};\\\", \\\"{x:1547,y:773,t:1527635355339};\\\", \\\"{x:1547,y:777,t:1527635355356};\\\", \\\"{x:1547,y:780,t:1527635355372};\\\", \\\"{x:1547,y:784,t:1527635355389};\\\", \\\"{x:1549,y:788,t:1527635355406};\\\", \\\"{x:1556,y:800,t:1527635355422};\\\", \\\"{x:1563,y:812,t:1527635355439};\\\", \\\"{x:1574,y:828,t:1527635355456};\\\", \\\"{x:1591,y:849,t:1527635355472};\\\", \\\"{x:1599,y:862,t:1527635355489};\\\", \\\"{x:1605,y:874,t:1527635355506};\\\", \\\"{x:1611,y:886,t:1527635355523};\\\", \\\"{x:1615,y:892,t:1527635355538};\\\", \\\"{x:1618,y:900,t:1527635355556};\\\", \\\"{x:1623,y:907,t:1527635355573};\\\", \\\"{x:1627,y:915,t:1527635355589};\\\", \\\"{x:1629,y:919,t:1527635355606};\\\", \\\"{x:1631,y:922,t:1527635355623};\\\", \\\"{x:1632,y:923,t:1527635355640};\\\", \\\"{x:1631,y:923,t:1527635355793};\\\", \\\"{x:1627,y:921,t:1527635355806};\\\", \\\"{x:1622,y:917,t:1527635355823};\\\", \\\"{x:1617,y:913,t:1527635355840};\\\", \\\"{x:1614,y:911,t:1527635355857};\\\", \\\"{x:1613,y:911,t:1527635355873};\\\", \\\"{x:1612,y:910,t:1527635355889};\\\", \\\"{x:1611,y:908,t:1527635355906};\\\", \\\"{x:1609,y:907,t:1527635355923};\\\", \\\"{x:1608,y:905,t:1527635355939};\\\", \\\"{x:1605,y:902,t:1527635355956};\\\", \\\"{x:1602,y:898,t:1527635355973};\\\", \\\"{x:1599,y:892,t:1527635355989};\\\", \\\"{x:1596,y:886,t:1527635356006};\\\", \\\"{x:1592,y:879,t:1527635356023};\\\", \\\"{x:1587,y:869,t:1527635356041};\\\", \\\"{x:1582,y:860,t:1527635356056};\\\", \\\"{x:1573,y:839,t:1527635356073};\\\", \\\"{x:1567,y:827,t:1527635356090};\\\", \\\"{x:1563,y:821,t:1527635356106};\\\", \\\"{x:1557,y:811,t:1527635356123};\\\", \\\"{x:1546,y:792,t:1527635356140};\\\", \\\"{x:1537,y:776,t:1527635356156};\\\", \\\"{x:1532,y:768,t:1527635356172};\\\", \\\"{x:1530,y:766,t:1527635356190};\\\", \\\"{x:1530,y:765,t:1527635356206};\\\", \\\"{x:1529,y:764,t:1527635356223};\\\", \\\"{x:1530,y:764,t:1527635356377};\\\", \\\"{x:1533,y:764,t:1527635356389};\\\", \\\"{x:1538,y:765,t:1527635356406};\\\", \\\"{x:1543,y:767,t:1527635356423};\\\", \\\"{x:1548,y:770,t:1527635356440};\\\", \\\"{x:1551,y:773,t:1527635356456};\\\", \\\"{x:1555,y:776,t:1527635356472};\\\", \\\"{x:1557,y:778,t:1527635356490};\\\", \\\"{x:1561,y:781,t:1527635356507};\\\", \\\"{x:1563,y:785,t:1527635356522};\\\", \\\"{x:1564,y:786,t:1527635356540};\\\", \\\"{x:1565,y:788,t:1527635356557};\\\", \\\"{x:1567,y:790,t:1527635356573};\\\", \\\"{x:1567,y:792,t:1527635356590};\\\", \\\"{x:1568,y:794,t:1527635356607};\\\", \\\"{x:1570,y:798,t:1527635356624};\\\", \\\"{x:1570,y:803,t:1527635356640};\\\", \\\"{x:1574,y:810,t:1527635356657};\\\", \\\"{x:1575,y:812,t:1527635356674};\\\", \\\"{x:1577,y:816,t:1527635356690};\\\", \\\"{x:1579,y:818,t:1527635356712};\\\", \\\"{x:1579,y:819,t:1527635356723};\\\", \\\"{x:1582,y:823,t:1527635356740};\\\", \\\"{x:1583,y:831,t:1527635356756};\\\", \\\"{x:1590,y:842,t:1527635356772};\\\", \\\"{x:1592,y:850,t:1527635356790};\\\", \\\"{x:1595,y:858,t:1527635356806};\\\", \\\"{x:1597,y:863,t:1527635356822};\\\", \\\"{x:1599,y:868,t:1527635356840};\\\", \\\"{x:1601,y:870,t:1527635356856};\\\", \\\"{x:1601,y:872,t:1527635356872};\\\", \\\"{x:1603,y:874,t:1527635356889};\\\", \\\"{x:1606,y:879,t:1527635356907};\\\", \\\"{x:1607,y:882,t:1527635356923};\\\", \\\"{x:1607,y:886,t:1527635356940};\\\", \\\"{x:1607,y:889,t:1527635356956};\\\", \\\"{x:1608,y:890,t:1527635356972};\\\", \\\"{x:1608,y:892,t:1527635356992};\\\", \\\"{x:1609,y:893,t:1527635357007};\\\", \\\"{x:1609,y:895,t:1527635357023};\\\", \\\"{x:1610,y:896,t:1527635357040};\\\", \\\"{x:1610,y:898,t:1527635357056};\\\", \\\"{x:1610,y:899,t:1527635357122};\\\", \\\"{x:1610,y:901,t:1527635357153};\\\", \\\"{x:1610,y:902,t:1527635357160};\\\", \\\"{x:1610,y:903,t:1527635357217};\\\", \\\"{x:1610,y:904,t:1527635357249};\\\", \\\"{x:1610,y:905,t:1527635357281};\\\", \\\"{x:1610,y:906,t:1527635357290};\\\", \\\"{x:1610,y:907,t:1527635358305};\\\", \\\"{x:1609,y:907,t:1527635358322};\\\", \\\"{x:1608,y:907,t:1527635358401};\\\", \\\"{x:1609,y:907,t:1527635358737};\\\", \\\"{x:1610,y:907,t:1527635358744};\\\", \\\"{x:1611,y:908,t:1527635358758};\\\", \\\"{x:1611,y:909,t:1527635358775};\\\", \\\"{x:1615,y:909,t:1527635359009};\\\", \\\"{x:1624,y:910,t:1527635359025};\\\", \\\"{x:1628,y:912,t:1527635359043};\\\", \\\"{x:1631,y:912,t:1527635359058};\\\", \\\"{x:1632,y:912,t:1527635359185};\\\", \\\"{x:1632,y:911,t:1527635359241};\\\", \\\"{x:1631,y:911,t:1527635359264};\\\", \\\"{x:1630,y:910,t:1527635359275};\\\", \\\"{x:1629,y:909,t:1527635359297};\\\", \\\"{x:1628,y:908,t:1527635359433};\\\", \\\"{x:1627,y:908,t:1527635359722};\\\", \\\"{x:1625,y:907,t:1527635359728};\\\", \\\"{x:1624,y:906,t:1527635359753};\\\", \\\"{x:1622,y:906,t:1527635359825};\\\", \\\"{x:1620,y:905,t:1527635359952};\\\", \\\"{x:1619,y:905,t:1527635360344};\\\", \\\"{x:1617,y:905,t:1527635360441};\\\", \\\"{x:1616,y:905,t:1527635360577};\\\", \\\"{x:1614,y:905,t:1527635360592};\\\", \\\"{x:1612,y:905,t:1527635360624};\\\", \\\"{x:1610,y:905,t:1527635360632};\\\", \\\"{x:1607,y:903,t:1527635360643};\\\", \\\"{x:1598,y:900,t:1527635360659};\\\", \\\"{x:1585,y:896,t:1527635360676};\\\", \\\"{x:1572,y:891,t:1527635360694};\\\", \\\"{x:1561,y:886,t:1527635360709};\\\", \\\"{x:1552,y:881,t:1527635360726};\\\", \\\"{x:1547,y:879,t:1527635360743};\\\", \\\"{x:1542,y:875,t:1527635360759};\\\", \\\"{x:1533,y:871,t:1527635360776};\\\", \\\"{x:1527,y:869,t:1527635360793};\\\", \\\"{x:1524,y:868,t:1527635360810};\\\", \\\"{x:1523,y:867,t:1527635360826};\\\", \\\"{x:1522,y:867,t:1527635360848};\\\", \\\"{x:1521,y:866,t:1527635360881};\\\", \\\"{x:1520,y:864,t:1527635360961};\\\", \\\"{x:1519,y:863,t:1527635360977};\\\", \\\"{x:1517,y:861,t:1527635361033};\\\", \\\"{x:1516,y:860,t:1527635361057};\\\", \\\"{x:1515,y:859,t:1527635361064};\\\", \\\"{x:1515,y:858,t:1527635361076};\\\", \\\"{x:1513,y:855,t:1527635361093};\\\", \\\"{x:1511,y:851,t:1527635361109};\\\", \\\"{x:1511,y:850,t:1527635361152};\\\", \\\"{x:1509,y:849,t:1527635361449};\\\", \\\"{x:1502,y:845,t:1527635361461};\\\", \\\"{x:1485,y:837,t:1527635361477};\\\", \\\"{x:1476,y:834,t:1527635361493};\\\", \\\"{x:1472,y:832,t:1527635361510};\\\", \\\"{x:1470,y:831,t:1527635361527};\\\", \\\"{x:1469,y:829,t:1527635361544};\\\", \\\"{x:1463,y:825,t:1527635361560};\\\", \\\"{x:1454,y:821,t:1527635361577};\\\", \\\"{x:1444,y:816,t:1527635361593};\\\", \\\"{x:1435,y:811,t:1527635361610};\\\", \\\"{x:1426,y:808,t:1527635361627};\\\", \\\"{x:1423,y:807,t:1527635361643};\\\", \\\"{x:1420,y:806,t:1527635361660};\\\", \\\"{x:1418,y:804,t:1527635361677};\\\", \\\"{x:1414,y:803,t:1527635361693};\\\", \\\"{x:1407,y:799,t:1527635361710};\\\", \\\"{x:1402,y:795,t:1527635361727};\\\", \\\"{x:1392,y:790,t:1527635361743};\\\", \\\"{x:1374,y:783,t:1527635361760};\\\", \\\"{x:1361,y:777,t:1527635361777};\\\", \\\"{x:1342,y:767,t:1527635361795};\\\", \\\"{x:1319,y:756,t:1527635361811};\\\", \\\"{x:1302,y:748,t:1527635361827};\\\", \\\"{x:1288,y:742,t:1527635361844};\\\", \\\"{x:1275,y:732,t:1527635361860};\\\", \\\"{x:1264,y:724,t:1527635361877};\\\", \\\"{x:1250,y:712,t:1527635361894};\\\", \\\"{x:1237,y:698,t:1527635361910};\\\", \\\"{x:1226,y:688,t:1527635361927};\\\", \\\"{x:1213,y:675,t:1527635361944};\\\", \\\"{x:1207,y:669,t:1527635361960};\\\", \\\"{x:1201,y:663,t:1527635361978};\\\", \\\"{x:1197,y:659,t:1527635361994};\\\", \\\"{x:1191,y:651,t:1527635362011};\\\", \\\"{x:1182,y:642,t:1527635362028};\\\", \\\"{x:1168,y:632,t:1527635362045};\\\", \\\"{x:1162,y:628,t:1527635362060};\\\", \\\"{x:1155,y:623,t:1527635362077};\\\", \\\"{x:1149,y:619,t:1527635362095};\\\", \\\"{x:1147,y:617,t:1527635362110};\\\", \\\"{x:1146,y:617,t:1527635362127};\\\", \\\"{x:1145,y:616,t:1527635362145};\\\", \\\"{x:1144,y:615,t:1527635362185};\\\", \\\"{x:1142,y:615,t:1527635362473};\\\", \\\"{x:1131,y:617,t:1527635362480};\\\", \\\"{x:1112,y:619,t:1527635362494};\\\", \\\"{x:1054,y:625,t:1527635362511};\\\", \\\"{x:984,y:625,t:1527635362528};\\\", \\\"{x:914,y:625,t:1527635362544};\\\", \\\"{x:878,y:625,t:1527635362560};\\\", \\\"{x:862,y:625,t:1527635362577};\\\", \\\"{x:834,y:625,t:1527635362594};\\\", \\\"{x:802,y:625,t:1527635362610};\\\", \\\"{x:768,y:625,t:1527635362626};\\\", \\\"{x:734,y:625,t:1527635362644};\\\", \\\"{x:691,y:625,t:1527635362661};\\\", \\\"{x:666,y:626,t:1527635362678};\\\", \\\"{x:647,y:628,t:1527635362694};\\\", \\\"{x:636,y:632,t:1527635362711};\\\", \\\"{x:619,y:640,t:1527635362728};\\\", \\\"{x:601,y:648,t:1527635362744};\\\", \\\"{x:580,y:654,t:1527635362761};\\\", \\\"{x:560,y:662,t:1527635362779};\\\", \\\"{x:544,y:667,t:1527635362794};\\\", \\\"{x:531,y:673,t:1527635362810};\\\", \\\"{x:525,y:675,t:1527635362830};\\\", \\\"{x:521,y:677,t:1527635362846};\\\", \\\"{x:519,y:677,t:1527635362862};\\\", \\\"{x:512,y:679,t:1527635362880};\\\", \\\"{x:506,y:681,t:1527635362896};\\\", \\\"{x:504,y:681,t:1527635362913};\\\", \\\"{x:517,y:681,t:1527635362967};\\\", \\\"{x:532,y:681,t:1527635362980};\\\", \\\"{x:636,y:683,t:1527635362997};\\\", \\\"{x:814,y:697,t:1527635363013};\\\", \\\"{x:1030,y:706,t:1527635363030};\\\", \\\"{x:1251,y:736,t:1527635363047};\\\", \\\"{x:1556,y:777,t:1527635363064};\\\", \\\"{x:1695,y:799,t:1527635363080};\\\", \\\"{x:1759,y:816,t:1527635363097};\\\", \\\"{x:1781,y:825,t:1527635363114};\\\", \\\"{x:1790,y:830,t:1527635363131};\\\", \\\"{x:1796,y:835,t:1527635363147};\\\", \\\"{x:1800,y:843,t:1527635363164};\\\", \\\"{x:1805,y:851,t:1527635363180};\\\", \\\"{x:1808,y:859,t:1527635363197};\\\", \\\"{x:1810,y:863,t:1527635363213};\\\", \\\"{x:1811,y:865,t:1527635363231};\\\", \\\"{x:1811,y:867,t:1527635363247};\\\", \\\"{x:1811,y:869,t:1527635363264};\\\", \\\"{x:1810,y:872,t:1527635363280};\\\", \\\"{x:1801,y:878,t:1527635363297};\\\", \\\"{x:1788,y:884,t:1527635363314};\\\", \\\"{x:1770,y:891,t:1527635363331};\\\", \\\"{x:1740,y:900,t:1527635363347};\\\", \\\"{x:1697,y:907,t:1527635363364};\\\", \\\"{x:1663,y:914,t:1527635363381};\\\", \\\"{x:1631,y:919,t:1527635363398};\\\", \\\"{x:1608,y:919,t:1527635363414};\\\", \\\"{x:1603,y:919,t:1527635363431};\\\", \\\"{x:1602,y:919,t:1527635363447};\\\", \\\"{x:1601,y:919,t:1527635363513};\\\", \\\"{x:1600,y:919,t:1527635363522};\\\", \\\"{x:1599,y:919,t:1527635363568};\\\", \\\"{x:1597,y:919,t:1527635363608};\\\", \\\"{x:1594,y:919,t:1527635363617};\\\", \\\"{x:1593,y:918,t:1527635363631};\\\", \\\"{x:1592,y:917,t:1527635363647};\\\", \\\"{x:1592,y:916,t:1527635363953};\\\", \\\"{x:1594,y:916,t:1527635363992};\\\", \\\"{x:1595,y:916,t:1527635364041};\\\", \\\"{x:1596,y:916,t:1527635364048};\\\", \\\"{x:1596,y:915,t:1527635364065};\\\", \\\"{x:1598,y:915,t:1527635364096};\\\", \\\"{x:1600,y:915,t:1527635364105};\\\", \\\"{x:1601,y:914,t:1527635364115};\\\", \\\"{x:1604,y:913,t:1527635364131};\\\", \\\"{x:1606,y:912,t:1527635364148};\\\", \\\"{x:1610,y:912,t:1527635364165};\\\", \\\"{x:1613,y:912,t:1527635364182};\\\", \\\"{x:1616,y:912,t:1527635364199};\\\", \\\"{x:1618,y:912,t:1527635364215};\\\", \\\"{x:1619,y:912,t:1527635364231};\\\", \\\"{x:1622,y:912,t:1527635364248};\\\", \\\"{x:1623,y:912,t:1527635364575};\\\", \\\"{x:1623,y:910,t:1527635364592};\\\", \\\"{x:1621,y:910,t:1527635364608};\\\", \\\"{x:1620,y:910,t:1527635364632};\\\", \\\"{x:1619,y:910,t:1527635364681};\\\", \\\"{x:1618,y:909,t:1527635364689};\\\", \\\"{x:1617,y:909,t:1527635364905};\\\", \\\"{x:1616,y:909,t:1527635364951};\\\", \\\"{x:1615,y:909,t:1527635364965};\\\", \\\"{x:1614,y:909,t:1527635364981};\\\", \\\"{x:1613,y:909,t:1527635366009};\\\", \\\"{x:1612,y:909,t:1527635366777};\\\", \\\"{x:1611,y:909,t:1527635366784};\\\", \\\"{x:1610,y:909,t:1527635366800};\\\", \\\"{x:1609,y:909,t:1527635366824};\\\", \\\"{x:1607,y:910,t:1527635367185};\\\", \\\"{x:1600,y:910,t:1527635367201};\\\", \\\"{x:1595,y:909,t:1527635367218};\\\", \\\"{x:1593,y:908,t:1527635367233};\\\", \\\"{x:1592,y:908,t:1527635367251};\\\", \\\"{x:1591,y:908,t:1527635367268};\\\", \\\"{x:1590,y:907,t:1527635367283};\\\", \\\"{x:1589,y:907,t:1527635367300};\\\", \\\"{x:1587,y:906,t:1527635367317};\\\", \\\"{x:1586,y:906,t:1527635367333};\\\", \\\"{x:1585,y:906,t:1527635367368};\\\", \\\"{x:1584,y:905,t:1527635367384};\\\", \\\"{x:1583,y:905,t:1527635367551};\\\", \\\"{x:1580,y:905,t:1527635367566};\\\", \\\"{x:1573,y:905,t:1527635367583};\\\", \\\"{x:1568,y:907,t:1527635367599};\\\", \\\"{x:1565,y:908,t:1527635367616};\\\", \\\"{x:1561,y:909,t:1527635367634};\\\", \\\"{x:1556,y:912,t:1527635367650};\\\", \\\"{x:1547,y:913,t:1527635367666};\\\", \\\"{x:1537,y:916,t:1527635367684};\\\", \\\"{x:1528,y:917,t:1527635367700};\\\", \\\"{x:1523,y:917,t:1527635367717};\\\", \\\"{x:1520,y:919,t:1527635367734};\\\", \\\"{x:1521,y:919,t:1527635367984};\\\", \\\"{x:1525,y:918,t:1527635368001};\\\", \\\"{x:1527,y:917,t:1527635368018};\\\", \\\"{x:1533,y:917,t:1527635368035};\\\", \\\"{x:1539,y:916,t:1527635368052};\\\", \\\"{x:1549,y:916,t:1527635368067};\\\", \\\"{x:1559,y:916,t:1527635368084};\\\", \\\"{x:1569,y:916,t:1527635368101};\\\", \\\"{x:1577,y:916,t:1527635368117};\\\", \\\"{x:1580,y:916,t:1527635368133};\\\", \\\"{x:1582,y:916,t:1527635368151};\\\", \\\"{x:1583,y:916,t:1527635368166};\\\", \\\"{x:1588,y:916,t:1527635368184};\\\", \\\"{x:1593,y:916,t:1527635368201};\\\", \\\"{x:1594,y:916,t:1527635368216};\\\", \\\"{x:1595,y:916,t:1527635368234};\\\", \\\"{x:1596,y:916,t:1527635368263};\\\", \\\"{x:1597,y:916,t:1527635368279};\\\", \\\"{x:1598,y:916,t:1527635368295};\\\", \\\"{x:1600,y:916,t:1527635368303};\\\", \\\"{x:1602,y:916,t:1527635368335};\\\", \\\"{x:1603,y:916,t:1527635368400};\\\", \\\"{x:1605,y:916,t:1527635368705};\\\", \\\"{x:1606,y:915,t:1527635368729};\\\", \\\"{x:1608,y:913,t:1527635368752};\\\", \\\"{x:1609,y:912,t:1527635368784};\\\", \\\"{x:1610,y:912,t:1527635368808};\\\", \\\"{x:1610,y:911,t:1527635368833};\\\", \\\"{x:1611,y:910,t:1527635368849};\\\", \\\"{x:1611,y:909,t:1527635368929};\\\", \\\"{x:1612,y:909,t:1527635369344};\\\", \\\"{x:1613,y:909,t:1527635369409};\\\", \\\"{x:1614,y:909,t:1527635369419};\\\", \\\"{x:1615,y:908,t:1527635369436};\\\", \\\"{x:1615,y:907,t:1527635369496};\\\", \\\"{x:1616,y:907,t:1527635369537};\\\", \\\"{x:1617,y:907,t:1527635369553};\\\", \\\"{x:1618,y:907,t:1527635369577};\\\", \\\"{x:1616,y:907,t:1527635369922};\\\", \\\"{x:1615,y:907,t:1527635369944};\\\", \\\"{x:1613,y:907,t:1527635369960};\\\", \\\"{x:1612,y:907,t:1527635369977};\\\", \\\"{x:1611,y:907,t:1527635369986};\\\", \\\"{x:1610,y:907,t:1527635370002};\\\", \\\"{x:1609,y:907,t:1527635370019};\\\", \\\"{x:1607,y:907,t:1527635370036};\\\", \\\"{x:1606,y:907,t:1527635370056};\\\", \\\"{x:1604,y:907,t:1527635370112};\\\", \\\"{x:1603,y:907,t:1527635370263};\\\", \\\"{x:1602,y:903,t:1527635370799};\\\", \\\"{x:1602,y:901,t:1527635370815};\\\", \\\"{x:1599,y:899,t:1527635370823};\\\", \\\"{x:1599,y:898,t:1527635370836};\\\", \\\"{x:1598,y:894,t:1527635370853};\\\", \\\"{x:1595,y:890,t:1527635370869};\\\", \\\"{x:1593,y:885,t:1527635370886};\\\", \\\"{x:1588,y:878,t:1527635370903};\\\", \\\"{x:1580,y:861,t:1527635370919};\\\", \\\"{x:1572,y:849,t:1527635370936};\\\", \\\"{x:1565,y:831,t:1527635370953};\\\", \\\"{x:1554,y:813,t:1527635370969};\\\", \\\"{x:1545,y:801,t:1527635370985};\\\", \\\"{x:1539,y:791,t:1527635371003};\\\", \\\"{x:1535,y:785,t:1527635371019};\\\", \\\"{x:1535,y:784,t:1527635371036};\\\", \\\"{x:1534,y:783,t:1527635371053};\\\", \\\"{x:1534,y:782,t:1527635371068};\\\", \\\"{x:1533,y:782,t:1527635371085};\\\", \\\"{x:1529,y:781,t:1527635371297};\\\", \\\"{x:1525,y:781,t:1527635371304};\\\", \\\"{x:1512,y:778,t:1527635371319};\\\", \\\"{x:1500,y:777,t:1527635371336};\\\", \\\"{x:1491,y:776,t:1527635371353};\\\", \\\"{x:1488,y:776,t:1527635371370};\\\", \\\"{x:1487,y:776,t:1527635371760};\\\", \\\"{x:1485,y:776,t:1527635371771};\\\", \\\"{x:1483,y:776,t:1527635371788};\\\", \\\"{x:1479,y:776,t:1527635371803};\\\", \\\"{x:1477,y:776,t:1527635371820};\\\", \\\"{x:1476,y:776,t:1527635371837};\\\", \\\"{x:1475,y:776,t:1527635371881};\\\", \\\"{x:1474,y:776,t:1527635371896};\\\", \\\"{x:1473,y:776,t:1527635371953};\\\", \\\"{x:1475,y:776,t:1527635372744};\\\", \\\"{x:1476,y:776,t:1527635372760};\\\", \\\"{x:1477,y:776,t:1527635372787};\\\", \\\"{x:1478,y:776,t:1527635372805};\\\", \\\"{x:1484,y:776,t:1527635373801};\\\", \\\"{x:1496,y:776,t:1527635373810};\\\", \\\"{x:1511,y:778,t:1527635373822};\\\", \\\"{x:1535,y:779,t:1527635373838};\\\", \\\"{x:1559,y:783,t:1527635373856};\\\", \\\"{x:1567,y:784,t:1527635373873};\\\", \\\"{x:1580,y:788,t:1527635373889};\\\", \\\"{x:1597,y:794,t:1527635373905};\\\", \\\"{x:1613,y:803,t:1527635373921};\\\", \\\"{x:1626,y:811,t:1527635373938};\\\", \\\"{x:1634,y:820,t:1527635373955};\\\", \\\"{x:1641,y:829,t:1527635373971};\\\", \\\"{x:1644,y:838,t:1527635373988};\\\", \\\"{x:1647,y:847,t:1527635374004};\\\", \\\"{x:1648,y:855,t:1527635374021};\\\", \\\"{x:1650,y:866,t:1527635374037};\\\", \\\"{x:1652,y:880,t:1527635374055};\\\", \\\"{x:1652,y:887,t:1527635374071};\\\", \\\"{x:1652,y:893,t:1527635374088};\\\", \\\"{x:1652,y:898,t:1527635374105};\\\", \\\"{x:1651,y:902,t:1527635374122};\\\", \\\"{x:1651,y:905,t:1527635374138};\\\", \\\"{x:1648,y:908,t:1527635374155};\\\", \\\"{x:1647,y:909,t:1527635374172};\\\", \\\"{x:1645,y:911,t:1527635374188};\\\", \\\"{x:1641,y:913,t:1527635374205};\\\", \\\"{x:1639,y:913,t:1527635374222};\\\", \\\"{x:1637,y:915,t:1527635374239};\\\", \\\"{x:1635,y:915,t:1527635374256};\\\", \\\"{x:1634,y:915,t:1527635374345};\\\", \\\"{x:1633,y:915,t:1527635374356};\\\", \\\"{x:1632,y:915,t:1527635374372};\\\", \\\"{x:1631,y:915,t:1527635374389};\\\", \\\"{x:1630,y:915,t:1527635374406};\\\", \\\"{x:1629,y:915,t:1527635374423};\\\", \\\"{x:1626,y:915,t:1527635374438};\\\", \\\"{x:1625,y:915,t:1527635374456};\\\", \\\"{x:1622,y:914,t:1527635374473};\\\", \\\"{x:1619,y:914,t:1527635374488};\\\", \\\"{x:1616,y:913,t:1527635374505};\\\", \\\"{x:1615,y:912,t:1527635374523};\\\", \\\"{x:1613,y:912,t:1527635374543};\\\", \\\"{x:1612,y:911,t:1527635374560};\\\", \\\"{x:1611,y:910,t:1527635374608};\\\", \\\"{x:1610,y:910,t:1527635374745};\\\", \\\"{x:1609,y:908,t:1527635375023};\\\", \\\"{x:1609,y:900,t:1527635375039};\\\", \\\"{x:1609,y:895,t:1527635375055};\\\", \\\"{x:1609,y:892,t:1527635375072};\\\", \\\"{x:1609,y:888,t:1527635375089};\\\", \\\"{x:1609,y:883,t:1527635375106};\\\", \\\"{x:1609,y:877,t:1527635375122};\\\", \\\"{x:1609,y:869,t:1527635375140};\\\", \\\"{x:1609,y:860,t:1527635375156};\\\", \\\"{x:1609,y:849,t:1527635375172};\\\", \\\"{x:1609,y:841,t:1527635375189};\\\", \\\"{x:1609,y:839,t:1527635375206};\\\", \\\"{x:1609,y:835,t:1527635375222};\\\", \\\"{x:1609,y:826,t:1527635375240};\\\", \\\"{x:1609,y:821,t:1527635375256};\\\", \\\"{x:1607,y:813,t:1527635375273};\\\", \\\"{x:1607,y:809,t:1527635375290};\\\", \\\"{x:1606,y:806,t:1527635375307};\\\", \\\"{x:1606,y:803,t:1527635375322};\\\", \\\"{x:1605,y:802,t:1527635375340};\\\", \\\"{x:1605,y:800,t:1527635375369};\\\", \\\"{x:1605,y:799,t:1527635375377};\\\", \\\"{x:1605,y:798,t:1527635375390};\\\", \\\"{x:1604,y:796,t:1527635375407};\\\", \\\"{x:1604,y:795,t:1527635375423};\\\", \\\"{x:1604,y:793,t:1527635375439};\\\", \\\"{x:1604,y:792,t:1527635375457};\\\", \\\"{x:1604,y:790,t:1527635375481};\\\", \\\"{x:1605,y:788,t:1527635375504};\\\", \\\"{x:1605,y:787,t:1527635375511};\\\", \\\"{x:1606,y:786,t:1527635375528};\\\", \\\"{x:1607,y:785,t:1527635375539};\\\", \\\"{x:1607,y:784,t:1527635375584};\\\", \\\"{x:1608,y:783,t:1527635375616};\\\", \\\"{x:1608,y:782,t:1527635375632};\\\", \\\"{x:1609,y:782,t:1527635375640};\\\", \\\"{x:1609,y:781,t:1527635375656};\\\", \\\"{x:1610,y:781,t:1527635375673};\\\", \\\"{x:1611,y:779,t:1527635375696};\\\", \\\"{x:1611,y:780,t:1527635375913};\\\", \\\"{x:1611,y:788,t:1527635375923};\\\", \\\"{x:1611,y:805,t:1527635375939};\\\", \\\"{x:1611,y:821,t:1527635375956};\\\", \\\"{x:1611,y:842,t:1527635375973};\\\", \\\"{x:1613,y:857,t:1527635375990};\\\", \\\"{x:1616,y:867,t:1527635376006};\\\", \\\"{x:1619,y:881,t:1527635376023};\\\", \\\"{x:1621,y:886,t:1527635376039};\\\", \\\"{x:1623,y:892,t:1527635376056};\\\", \\\"{x:1625,y:899,t:1527635376074};\\\", \\\"{x:1626,y:903,t:1527635376091};\\\", \\\"{x:1627,y:905,t:1527635376106};\\\", \\\"{x:1627,y:906,t:1527635376124};\\\", \\\"{x:1627,y:907,t:1527635376141};\\\", \\\"{x:1627,y:908,t:1527635376488};\\\", \\\"{x:1626,y:908,t:1527635376512};\\\", \\\"{x:1625,y:908,t:1527635376568};\\\", \\\"{x:1623,y:907,t:1527635376584};\\\", \\\"{x:1621,y:907,t:1527635376592};\\\", \\\"{x:1616,y:902,t:1527635376608};\\\", \\\"{x:1610,y:892,t:1527635376624};\\\", \\\"{x:1601,y:880,t:1527635376641};\\\", \\\"{x:1593,y:866,t:1527635376658};\\\", \\\"{x:1587,y:854,t:1527635376674};\\\", \\\"{x:1582,y:842,t:1527635376691};\\\", \\\"{x:1578,y:834,t:1527635376708};\\\", \\\"{x:1574,y:822,t:1527635376724};\\\", \\\"{x:1573,y:816,t:1527635376741};\\\", \\\"{x:1570,y:811,t:1527635376757};\\\", \\\"{x:1569,y:804,t:1527635376773};\\\", \\\"{x:1568,y:799,t:1527635376791};\\\", \\\"{x:1564,y:791,t:1527635376808};\\\", \\\"{x:1563,y:790,t:1527635376823};\\\", \\\"{x:1562,y:788,t:1527635376840};\\\", \\\"{x:1562,y:786,t:1527635376857};\\\", \\\"{x:1561,y:785,t:1527635376880};\\\", \\\"{x:1560,y:785,t:1527635376904};\\\", \\\"{x:1560,y:784,t:1527635376912};\\\", \\\"{x:1559,y:783,t:1527635376924};\\\", \\\"{x:1557,y:782,t:1527635376940};\\\", \\\"{x:1555,y:781,t:1527635376958};\\\", \\\"{x:1553,y:779,t:1527635376974};\\\", \\\"{x:1552,y:778,t:1527635376991};\\\", \\\"{x:1551,y:778,t:1527635377007};\\\", \\\"{x:1550,y:778,t:1527635377024};\\\", \\\"{x:1549,y:778,t:1527635377063};\\\", \\\"{x:1547,y:777,t:1527635377095};\\\", \\\"{x:1547,y:776,t:1527635377144};\\\", \\\"{x:1545,y:776,t:1527635377160};\\\", \\\"{x:1542,y:776,t:1527635377175};\\\", \\\"{x:1530,y:776,t:1527635377191};\\\", \\\"{x:1497,y:779,t:1527635377208};\\\", \\\"{x:1477,y:779,t:1527635377225};\\\", \\\"{x:1469,y:781,t:1527635377241};\\\", \\\"{x:1466,y:781,t:1527635377257};\\\", \\\"{x:1467,y:781,t:1527635377463};\\\", \\\"{x:1468,y:781,t:1527635377474};\\\", \\\"{x:1471,y:780,t:1527635377491};\\\", \\\"{x:1473,y:778,t:1527635377512};\\\", \\\"{x:1475,y:777,t:1527635377527};\\\", \\\"{x:1476,y:777,t:1527635377542};\\\", \\\"{x:1477,y:777,t:1527635377557};\\\", \\\"{x:1475,y:771,t:1527635379962};\\\", \\\"{x:1468,y:762,t:1527635379976};\\\", \\\"{x:1458,y:748,t:1527635379993};\\\", \\\"{x:1449,y:728,t:1527635380010};\\\", \\\"{x:1445,y:722,t:1527635380026};\\\", \\\"{x:1438,y:713,t:1527635380043};\\\", \\\"{x:1432,y:699,t:1527635380059};\\\", \\\"{x:1428,y:693,t:1527635380077};\\\", \\\"{x:1426,y:686,t:1527635380092};\\\", \\\"{x:1423,y:678,t:1527635380110};\\\", \\\"{x:1421,y:673,t:1527635380126};\\\", \\\"{x:1420,y:670,t:1527635380143};\\\", \\\"{x:1417,y:665,t:1527635380159};\\\", \\\"{x:1415,y:663,t:1527635380177};\\\", \\\"{x:1414,y:660,t:1527635380192};\\\", \\\"{x:1412,y:657,t:1527635380209};\\\", \\\"{x:1411,y:656,t:1527635380228};\\\", \\\"{x:1410,y:655,t:1527635380243};\\\", \\\"{x:1409,y:654,t:1527635380260};\\\", \\\"{x:1408,y:652,t:1527635380288};\\\", \\\"{x:1407,y:652,t:1527635380296};\\\", \\\"{x:1406,y:650,t:1527635380312};\\\", \\\"{x:1405,y:649,t:1527635380327};\\\", \\\"{x:1404,y:647,t:1527635380344};\\\", \\\"{x:1403,y:646,t:1527635380360};\\\", \\\"{x:1402,y:645,t:1527635380392};\\\", \\\"{x:1400,y:645,t:1527635380408};\\\", \\\"{x:1398,y:644,t:1527635380416};\\\", \\\"{x:1395,y:644,t:1527635380427};\\\", \\\"{x:1389,y:644,t:1527635380444};\\\", \\\"{x:1376,y:644,t:1527635380460};\\\", \\\"{x:1359,y:644,t:1527635380477};\\\", \\\"{x:1348,y:644,t:1527635380495};\\\", \\\"{x:1345,y:644,t:1527635380510};\\\", \\\"{x:1343,y:644,t:1527635380527};\\\", \\\"{x:1342,y:644,t:1527635380568};\\\", \\\"{x:1341,y:643,t:1527635380577};\\\", \\\"{x:1340,y:643,t:1527635380594};\\\", \\\"{x:1343,y:640,t:1527635381801};\\\", \\\"{x:1345,y:640,t:1527635381811};\\\", \\\"{x:1346,y:640,t:1527635381828};\\\", \\\"{x:1347,y:639,t:1527635381845};\\\", \\\"{x:1348,y:638,t:1527635381861};\\\", \\\"{x:1349,y:638,t:1527635381896};\\\", \\\"{x:1349,y:639,t:1527635382585};\\\", \\\"{x:1348,y:640,t:1527635382640};\\\", \\\"{x:1347,y:641,t:1527635383497};\\\", \\\"{x:1345,y:643,t:1527635383512};\\\", \\\"{x:1342,y:645,t:1527635383529};\\\", \\\"{x:1341,y:646,t:1527635383576};\\\", \\\"{x:1337,y:641,t:1527635384305};\\\", \\\"{x:1328,y:626,t:1527635384319};\\\", \\\"{x:1328,y:622,t:1527635384330};\\\", \\\"{x:1319,y:605,t:1527635384346};\\\", \\\"{x:1301,y:582,t:1527635384362};\\\", \\\"{x:1293,y:571,t:1527635384379};\\\", \\\"{x:1289,y:563,t:1527635384395};\\\", \\\"{x:1287,y:561,t:1527635384413};\\\", \\\"{x:1287,y:560,t:1527635384429};\\\", \\\"{x:1286,y:559,t:1527635384712};\\\", \\\"{x:1288,y:563,t:1527635384730};\\\", \\\"{x:1305,y:577,t:1527635384747};\\\", \\\"{x:1324,y:594,t:1527635384763};\\\", \\\"{x:1350,y:608,t:1527635384781};\\\", \\\"{x:1374,y:623,t:1527635384797};\\\", \\\"{x:1394,y:636,t:1527635384813};\\\", \\\"{x:1412,y:650,t:1527635384830};\\\", \\\"{x:1428,y:662,t:1527635384847};\\\", \\\"{x:1438,y:672,t:1527635384863};\\\", \\\"{x:1444,y:680,t:1527635384880};\\\", \\\"{x:1446,y:684,t:1527635384898};\\\", \\\"{x:1446,y:686,t:1527635384913};\\\", \\\"{x:1447,y:688,t:1527635384929};\\\", \\\"{x:1447,y:690,t:1527635384946};\\\", \\\"{x:1447,y:692,t:1527635384963};\\\", \\\"{x:1448,y:697,t:1527635384979};\\\", \\\"{x:1450,y:700,t:1527635384996};\\\", \\\"{x:1451,y:703,t:1527635385013};\\\", \\\"{x:1452,y:706,t:1527635385029};\\\", \\\"{x:1452,y:708,t:1527635385047};\\\", \\\"{x:1452,y:710,t:1527635385063};\\\", \\\"{x:1452,y:711,t:1527635385079};\\\", \\\"{x:1452,y:713,t:1527635385097};\\\", \\\"{x:1444,y:720,t:1527635385113};\\\", \\\"{x:1424,y:725,t:1527635385129};\\\", \\\"{x:1402,y:726,t:1527635385147};\\\", \\\"{x:1387,y:726,t:1527635385164};\\\", \\\"{x:1365,y:728,t:1527635385180};\\\", \\\"{x:1342,y:728,t:1527635385197};\\\", \\\"{x:1313,y:728,t:1527635385213};\\\", \\\"{x:1285,y:728,t:1527635385230};\\\", \\\"{x:1256,y:728,t:1527635385247};\\\", \\\"{x:1216,y:728,t:1527635385264};\\\", \\\"{x:1196,y:728,t:1527635385279};\\\", \\\"{x:1189,y:728,t:1527635385297};\\\", \\\"{x:1188,y:728,t:1527635385313};\\\", \\\"{x:1184,y:721,t:1527635385330};\\\", \\\"{x:1173,y:712,t:1527635385346};\\\", \\\"{x:1172,y:712,t:1527635385363};\\\", \\\"{x:1172,y:711,t:1527635385380};\\\", \\\"{x:1171,y:711,t:1527635385640};\\\", \\\"{x:1170,y:711,t:1527635385656};\\\", \\\"{x:1162,y:711,t:1527635385663};\\\", \\\"{x:1139,y:711,t:1527635385681};\\\", \\\"{x:1099,y:711,t:1527635385697};\\\", \\\"{x:1018,y:711,t:1527635385714};\\\", \\\"{x:924,y:711,t:1527635385732};\\\", \\\"{x:818,y:707,t:1527635385747};\\\", \\\"{x:737,y:707,t:1527635385764};\\\", \\\"{x:695,y:706,t:1527635385781};\\\", \\\"{x:672,y:702,t:1527635385797};\\\", \\\"{x:664,y:701,t:1527635385813};\\\", \\\"{x:661,y:699,t:1527635385831};\\\", \\\"{x:656,y:696,t:1527635385847};\\\", \\\"{x:644,y:678,t:1527635385864};\\\", \\\"{x:629,y:659,t:1527635385881};\\\", \\\"{x:618,y:644,t:1527635385896};\\\", \\\"{x:610,y:629,t:1527635385914};\\\", \\\"{x:607,y:610,t:1527635385932};\\\", \\\"{x:605,y:589,t:1527635385949};\\\", \\\"{x:604,y:575,t:1527635385963};\\\", \\\"{x:603,y:564,t:1527635385981};\\\", \\\"{x:600,y:557,t:1527635385999};\\\", \\\"{x:598,y:551,t:1527635386014};\\\", \\\"{x:594,y:544,t:1527635386032};\\\", \\\"{x:588,y:538,t:1527635386048};\\\", \\\"{x:582,y:537,t:1527635386065};\\\", \\\"{x:575,y:537,t:1527635386082};\\\", \\\"{x:567,y:537,t:1527635386098};\\\", \\\"{x:562,y:539,t:1527635386116};\\\", \\\"{x:559,y:540,t:1527635386132};\\\", \\\"{x:556,y:540,t:1527635386148};\\\", \\\"{x:559,y:540,t:1527635386224};\\\", \\\"{x:563,y:542,t:1527635386232};\\\", \\\"{x:575,y:542,t:1527635386249};\\\", \\\"{x:589,y:543,t:1527635386266};\\\", \\\"{x:606,y:543,t:1527635386282};\\\", \\\"{x:625,y:543,t:1527635386298};\\\", \\\"{x:635,y:543,t:1527635386314};\\\", \\\"{x:637,y:543,t:1527635386332};\\\", \\\"{x:635,y:544,t:1527635386464};\\\", \\\"{x:634,y:544,t:1527635386471};\\\", \\\"{x:630,y:544,t:1527635386482};\\\", \\\"{x:622,y:544,t:1527635386499};\\\", \\\"{x:615,y:544,t:1527635386515};\\\", \\\"{x:613,y:544,t:1527635386532};\\\", \\\"{x:612,y:544,t:1527635386549};\\\", \\\"{x:605,y:548,t:1527635386735};\\\", \\\"{x:600,y:553,t:1527635386748};\\\", \\\"{x:584,y:568,t:1527635386766};\\\", \\\"{x:567,y:582,t:1527635386782};\\\", \\\"{x:552,y:596,t:1527635386798};\\\", \\\"{x:537,y:607,t:1527635386816};\\\", \\\"{x:532,y:612,t:1527635386833};\\\", \\\"{x:526,y:618,t:1527635386848};\\\", \\\"{x:517,y:630,t:1527635386866};\\\", \\\"{x:510,y:643,t:1527635386883};\\\", \\\"{x:503,y:655,t:1527635386900};\\\", \\\"{x:497,y:667,t:1527635386916};\\\", \\\"{x:494,y:671,t:1527635386933};\\\", \\\"{x:493,y:672,t:1527635386950};\\\", \\\"{x:493,y:671,t:1527635387056};\\\", \\\"{x:493,y:670,t:1527635387066};\\\", \\\"{x:493,y:667,t:1527635387083};\\\", \\\"{x:494,y:664,t:1527635387100};\\\", \\\"{x:494,y:663,t:1527635387116};\\\", \\\"{x:495,y:662,t:1527635387133};\\\", \\\"{x:496,y:662,t:1527635387512};\\\", \\\"{x:498,y:661,t:1527635387520};\\\", \\\"{x:501,y:659,t:1527635387533};\\\", \\\"{x:502,y:659,t:1527635387550};\\\", \\\"{x:504,y:659,t:1527635387566};\\\", \\\"{x:505,y:659,t:1527635387582};\\\", \\\"{x:505,y:658,t:1527635387599};\\\", \\\"{x:507,y:658,t:1527635387760};\\\", \\\"{x:517,y:663,t:1527635387767};\\\", \\\"{x:524,y:665,t:1527635387783};\\\", \\\"{x:566,y:696,t:1527635387799};\\\", \\\"{x:593,y:712,t:1527635387817};\\\", \\\"{x:616,y:728,t:1527635387833};\\\", \\\"{x:632,y:743,t:1527635387849};\\\", \\\"{x:638,y:756,t:1527635387867};\\\", \\\"{x:638,y:765,t:1527635387884};\\\", \\\"{x:633,y:775,t:1527635387900};\\\", \\\"{x:607,y:782,t:1527635387916};\\\", \\\"{x:565,y:780,t:1527635387934};\\\", \\\"{x:494,y:752,t:1527635387950};\\\", \\\"{x:427,y:706,t:1527635387967};\\\", \\\"{x:376,y:628,t:1527635387983};\\\", \\\"{x:363,y:550,t:1527635387999};\\\", \\\"{x:372,y:485,t:1527635388017};\\\", \\\"{x:408,y:442,t:1527635388034};\\\", \\\"{x:436,y:426,t:1527635388050};\\\", \\\"{x:469,y:422,t:1527635388067};\\\", \\\"{x:543,y:440,t:1527635388084};\\\", \\\"{x:628,y:475,t:1527635388100};\\\", \\\"{x:701,y:529,t:1527635388117};\\\", \\\"{x:760,y:586,t:1527635388134};\\\", \\\"{x:806,y:648,t:1527635388150};\\\", \\\"{x:823,y:697,t:1527635388167};\\\", \\\"{x:811,y:725,t:1527635388184};\\\", \\\"{x:792,y:728,t:1527635388200};\\\", \\\"{x:754,y:728,t:1527635388217};\\\", \\\"{x:578,y:670,t:1527635388251};\\\", \\\"{x:485,y:573,t:1527635388281};\\\", \\\"{x:466,y:547,t:1527635388287};\\\", \\\"{x:459,y:530,t:1527635388300};\\\", \\\"{x:453,y:493,t:1527635388317};\\\", \\\"{x:457,y:465,t:1527635388334};\\\", \\\"{x:471,y:451,t:1527635388350};\\\", \\\"{x:488,y:442,t:1527635388367};\\\", \\\"{x:533,y:444,t:1527635388383};\\\", \\\"{x:586,y:469,t:1527635388401};\\\", \\\"{x:660,y:517,t:1527635388416};\\\", \\\"{x:707,y:559,t:1527635388433};\\\", \\\"{x:740,y:593,t:1527635388450};\\\", \\\"{x:752,y:610,t:1527635388466};\\\", \\\"{x:754,y:619,t:1527635388483};\\\", \\\"{x:754,y:623,t:1527635388500};\\\", \\\"{x:753,y:627,t:1527635388517};\\\", \\\"{x:741,y:629,t:1527635388534};\\\", \\\"{x:724,y:631,t:1527635388550};\\\", \\\"{x:706,y:632,t:1527635388567};\\\", \\\"{x:673,y:633,t:1527635388583};\\\" ] }, { \\\"rt\\\": 73135, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 371346, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"8FE87\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -I -I -I -I -03 PM-03 PM-03 PM-U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:640,y:633,t:1527635388768};\\\", \\\"{x:638,y:633,t:1527635389152};\\\", \\\"{x:604,y:602,t:1527635389168};\\\", \\\"{x:558,y:570,t:1527635389186};\\\", \\\"{x:502,y:543,t:1527635389201};\\\", \\\"{x:450,y:520,t:1527635389218};\\\", \\\"{x:416,y:504,t:1527635389234};\\\", \\\"{x:401,y:495,t:1527635389251};\\\", \\\"{x:395,y:491,t:1527635389267};\\\", \\\"{x:389,y:487,t:1527635389285};\\\", \\\"{x:385,y:484,t:1527635389300};\\\", \\\"{x:383,y:483,t:1527635389318};\\\", \\\"{x:381,y:482,t:1527635389335};\\\", \\\"{x:378,y:481,t:1527635389351};\\\", \\\"{x:376,y:481,t:1527635389367};\\\", \\\"{x:375,y:481,t:1527635389385};\\\", \\\"{x:378,y:481,t:1527635389663};\\\", \\\"{x:381,y:481,t:1527635389671};\\\", \\\"{x:389,y:481,t:1527635389684};\\\", \\\"{x:393,y:482,t:1527635389702};\\\", \\\"{x:396,y:484,t:1527635389719};\\\", \\\"{x:397,y:484,t:1527635389735};\\\", \\\"{x:398,y:484,t:1527635389752};\\\", \\\"{x:399,y:484,t:1527635389768};\\\", \\\"{x:400,y:486,t:1527635389785};\\\", \\\"{x:401,y:488,t:1527635389802};\\\", \\\"{x:403,y:489,t:1527635389818};\\\", \\\"{x:407,y:491,t:1527635389835};\\\", \\\"{x:411,y:494,t:1527635389854};\\\", \\\"{x:414,y:496,t:1527635389868};\\\", \\\"{x:417,y:496,t:1527635389884};\\\", \\\"{x:419,y:498,t:1527635389902};\\\", \\\"{x:420,y:498,t:1527635389926};\\\", \\\"{x:422,y:499,t:1527635389967};\\\", \\\"{x:423,y:499,t:1527635389974};\\\", \\\"{x:424,y:500,t:1527635389991};\\\", \\\"{x:425,y:500,t:1527635390002};\\\", \\\"{x:427,y:501,t:1527635390018};\\\", \\\"{x:430,y:502,t:1527635390038};\\\", \\\"{x:432,y:502,t:1527635390056};\\\", \\\"{x:434,y:503,t:1527635390072};\\\", \\\"{x:437,y:504,t:1527635390088};\\\", \\\"{x:440,y:504,t:1527635390106};\\\", \\\"{x:442,y:505,t:1527635390123};\\\", \\\"{x:444,y:505,t:1527635390138};\\\", \\\"{x:447,y:506,t:1527635390155};\\\", \\\"{x:449,y:506,t:1527635390173};\\\", \\\"{x:451,y:507,t:1527635390188};\\\", \\\"{x:452,y:507,t:1527635390205};\\\", \\\"{x:455,y:508,t:1527635390222};\\\", \\\"{x:459,y:508,t:1527635390238};\\\", \\\"{x:467,y:508,t:1527635390255};\\\", \\\"{x:475,y:508,t:1527635390272};\\\", \\\"{x:480,y:508,t:1527635390288};\\\", \\\"{x:483,y:508,t:1527635390305};\\\", \\\"{x:488,y:508,t:1527635390322};\\\", \\\"{x:493,y:506,t:1527635390339};\\\", \\\"{x:495,y:504,t:1527635390356};\\\", \\\"{x:500,y:503,t:1527635390372};\\\", \\\"{x:503,y:500,t:1527635390389};\\\", \\\"{x:505,y:499,t:1527635390405};\\\", \\\"{x:506,y:499,t:1527635390441};\\\", \\\"{x:506,y:498,t:1527635390455};\\\", \\\"{x:508,y:493,t:1527635395171};\\\", \\\"{x:512,y:487,t:1527635395178};\\\", \\\"{x:518,y:483,t:1527635395191};\\\", \\\"{x:522,y:478,t:1527635395208};\\\", \\\"{x:524,y:476,t:1527635395226};\\\", \\\"{x:526,y:474,t:1527635395242};\\\", \\\"{x:527,y:472,t:1527635395259};\\\", \\\"{x:529,y:469,t:1527635395276};\\\", \\\"{x:530,y:466,t:1527635395293};\\\", \\\"{x:532,y:464,t:1527635395310};\\\", \\\"{x:532,y:463,t:1527635395331};\\\", \\\"{x:533,y:462,t:1527635395343};\\\", \\\"{x:534,y:461,t:1527635395359};\\\", \\\"{x:534,y:460,t:1527635395376};\\\", \\\"{x:536,y:460,t:1527635397468};\\\", \\\"{x:544,y:460,t:1527635397478};\\\", \\\"{x:561,y:462,t:1527635397495};\\\", \\\"{x:574,y:464,t:1527635397510};\\\", \\\"{x:578,y:465,t:1527635397528};\\\", \\\"{x:582,y:466,t:1527635397544};\\\", \\\"{x:584,y:466,t:1527635397579};\\\", \\\"{x:591,y:467,t:1527635397596};\\\", \\\"{x:599,y:469,t:1527635397611};\\\", \\\"{x:608,y:469,t:1527635397627};\\\", \\\"{x:615,y:469,t:1527635397644};\\\", \\\"{x:626,y:470,t:1527635397661};\\\", \\\"{x:638,y:473,t:1527635397678};\\\", \\\"{x:653,y:473,t:1527635397695};\\\", \\\"{x:665,y:474,t:1527635397712};\\\", \\\"{x:687,y:479,t:1527635397727};\\\", \\\"{x:713,y:480,t:1527635397744};\\\", \\\"{x:751,y:480,t:1527635397762};\\\", \\\"{x:823,y:480,t:1527635397777};\\\", \\\"{x:851,y:480,t:1527635397794};\\\", \\\"{x:852,y:480,t:1527635397811};\\\", \\\"{x:852,y:481,t:1527635398283};\\\", \\\"{x:852,y:482,t:1527635398306};\\\", \\\"{x:854,y:483,t:1527635398314};\\\", \\\"{x:865,y:486,t:1527635398329};\\\", \\\"{x:896,y:490,t:1527635398345};\\\", \\\"{x:922,y:490,t:1527635398361};\\\", \\\"{x:937,y:490,t:1527635398378};\\\", \\\"{x:942,y:490,t:1527635398396};\\\", \\\"{x:950,y:490,t:1527635398411};\\\", \\\"{x:989,y:495,t:1527635398429};\\\", \\\"{x:1066,y:503,t:1527635398446};\\\", \\\"{x:1158,y:503,t:1527635398461};\\\", \\\"{x:1241,y:503,t:1527635398478};\\\", \\\"{x:1298,y:504,t:1527635398495};\\\", \\\"{x:1329,y:504,t:1527635398511};\\\", \\\"{x:1353,y:502,t:1527635398528};\\\", \\\"{x:1371,y:496,t:1527635398546};\\\", \\\"{x:1392,y:489,t:1527635398561};\\\", \\\"{x:1424,y:475,t:1527635398579};\\\", \\\"{x:1441,y:468,t:1527635398595};\\\", \\\"{x:1454,y:459,t:1527635398612};\\\", \\\"{x:1457,y:456,t:1527635398629};\\\", \\\"{x:1458,y:455,t:1527635398646};\\\", \\\"{x:1458,y:452,t:1527635398662};\\\", \\\"{x:1460,y:448,t:1527635398679};\\\", \\\"{x:1460,y:445,t:1527635398696};\\\", \\\"{x:1460,y:441,t:1527635398712};\\\", \\\"{x:1460,y:439,t:1527635398729};\\\", \\\"{x:1460,y:436,t:1527635398746};\\\", \\\"{x:1460,y:432,t:1527635398762};\\\", \\\"{x:1450,y:422,t:1527635398780};\\\", \\\"{x:1442,y:416,t:1527635398797};\\\", \\\"{x:1425,y:409,t:1527635398813};\\\", \\\"{x:1406,y:405,t:1527635398829};\\\", \\\"{x:1380,y:404,t:1527635398845};\\\", \\\"{x:1362,y:400,t:1527635398863};\\\", \\\"{x:1343,y:397,t:1527635398879};\\\", \\\"{x:1330,y:397,t:1527635398896};\\\", \\\"{x:1322,y:397,t:1527635398913};\\\", \\\"{x:1320,y:397,t:1527635398929};\\\", \\\"{x:1317,y:397,t:1527635398946};\\\", \\\"{x:1316,y:397,t:1527635398979};\\\", \\\"{x:1314,y:398,t:1527635398996};\\\", \\\"{x:1313,y:399,t:1527635399013};\\\", \\\"{x:1311,y:400,t:1527635399030};\\\", \\\"{x:1310,y:401,t:1527635399046};\\\", \\\"{x:1309,y:407,t:1527635399063};\\\", \\\"{x:1309,y:411,t:1527635399079};\\\", \\\"{x:1309,y:416,t:1527635399096};\\\", \\\"{x:1309,y:421,t:1527635399113};\\\", \\\"{x:1309,y:424,t:1527635399129};\\\", \\\"{x:1309,y:425,t:1527635399146};\\\", \\\"{x:1311,y:427,t:1527635399163};\\\", \\\"{x:1313,y:433,t:1527635399180};\\\", \\\"{x:1316,y:439,t:1527635399199};\\\", \\\"{x:1319,y:442,t:1527635399213};\\\", \\\"{x:1319,y:443,t:1527635399228};\\\", \\\"{x:1320,y:444,t:1527635399298};\\\", \\\"{x:1317,y:444,t:1527635399795};\\\", \\\"{x:1315,y:444,t:1527635399803};\\\", \\\"{x:1313,y:443,t:1527635399813};\\\", \\\"{x:1309,y:443,t:1527635399830};\\\", \\\"{x:1308,y:443,t:1527635399849};\\\", \\\"{x:1307,y:442,t:1527635400276};\\\", \\\"{x:1308,y:442,t:1527635400307};\\\", \\\"{x:1309,y:440,t:1527635400315};\\\", \\\"{x:1310,y:440,t:1527635400331};\\\", \\\"{x:1311,y:440,t:1527635405043};\\\", \\\"{x:1311,y:441,t:1527635405852};\\\", \\\"{x:1311,y:442,t:1527635405867};\\\", \\\"{x:1312,y:443,t:1527635405899};\\\", \\\"{x:1313,y:444,t:1527635405906};\\\", \\\"{x:1314,y:444,t:1527635408042};\\\", \\\"{x:1317,y:445,t:1527635408051};\\\", \\\"{x:1327,y:447,t:1527635408069};\\\", \\\"{x:1335,y:448,t:1527635408085};\\\", \\\"{x:1340,y:450,t:1527635408102};\\\", \\\"{x:1342,y:450,t:1527635408118};\\\", \\\"{x:1346,y:450,t:1527635408136};\\\", \\\"{x:1351,y:450,t:1527635408151};\\\", \\\"{x:1356,y:450,t:1527635408169};\\\", \\\"{x:1364,y:450,t:1527635408185};\\\", \\\"{x:1368,y:450,t:1527635408202};\\\", \\\"{x:1375,y:450,t:1527635408219};\\\", \\\"{x:1377,y:450,t:1527635408235};\\\", \\\"{x:1380,y:451,t:1527635408252};\\\", \\\"{x:1381,y:451,t:1527635408306};\\\", \\\"{x:1382,y:451,t:1527635408322};\\\", \\\"{x:1383,y:451,t:1527635408636};\\\", \\\"{x:1383,y:450,t:1527635408700};\\\", \\\"{x:1383,y:448,t:1527635408708};\\\", \\\"{x:1383,y:447,t:1527635408731};\\\", \\\"{x:1383,y:446,t:1527635408739};\\\", \\\"{x:1383,y:444,t:1527635408763};\\\", \\\"{x:1382,y:444,t:1527635408827};\\\", \\\"{x:1382,y:443,t:1527635408851};\\\", \\\"{x:1382,y:442,t:1527635408916};\\\", \\\"{x:1382,y:441,t:1527635408956};\\\", \\\"{x:1382,y:440,t:1527635409012};\\\", \\\"{x:1382,y:439,t:1527635409060};\\\", \\\"{x:1381,y:438,t:1527635409107};\\\", \\\"{x:1380,y:437,t:1527635409538};\\\", \\\"{x:1379,y:437,t:1527635409553};\\\", \\\"{x:1373,y:437,t:1527635409570};\\\", \\\"{x:1371,y:437,t:1527635409586};\\\", \\\"{x:1370,y:437,t:1527635409603};\\\", \\\"{x:1369,y:437,t:1527635409620};\\\", \\\"{x:1367,y:438,t:1527635409650};\\\", \\\"{x:1366,y:439,t:1527635409667};\\\", \\\"{x:1364,y:439,t:1527635409691};\\\", \\\"{x:1363,y:439,t:1527635409706};\\\", \\\"{x:1360,y:439,t:1527635409720};\\\", \\\"{x:1357,y:440,t:1527635409737};\\\", \\\"{x:1354,y:440,t:1527635409753};\\\", \\\"{x:1349,y:440,t:1527635409770};\\\", \\\"{x:1347,y:440,t:1527635409787};\\\", \\\"{x:1344,y:440,t:1527635409804};\\\", \\\"{x:1343,y:440,t:1527635409820};\\\", \\\"{x:1339,y:440,t:1527635409837};\\\", \\\"{x:1336,y:440,t:1527635409853};\\\", \\\"{x:1333,y:441,t:1527635409870};\\\", \\\"{x:1330,y:441,t:1527635409887};\\\", \\\"{x:1329,y:442,t:1527635409904};\\\", \\\"{x:1327,y:442,t:1527635409921};\\\", \\\"{x:1326,y:442,t:1527635409939};\\\", \\\"{x:1325,y:442,t:1527635409954};\\\", \\\"{x:1324,y:442,t:1527635409971};\\\", \\\"{x:1322,y:443,t:1527635409987};\\\", \\\"{x:1321,y:443,t:1527635410019};\\\", \\\"{x:1320,y:443,t:1527635410124};\\\", \\\"{x:1318,y:444,t:1527635414052};\\\", \\\"{x:1318,y:445,t:1527635414067};\\\", \\\"{x:1317,y:445,t:1527635414075};\\\", \\\"{x:1316,y:445,t:1527635414515};\\\", \\\"{x:1315,y:444,t:1527635414602};\\\", \\\"{x:1315,y:448,t:1527635414739};\\\", \\\"{x:1315,y:454,t:1527635414748};\\\", \\\"{x:1315,y:459,t:1527635414758};\\\", \\\"{x:1319,y:472,t:1527635414775};\\\", \\\"{x:1324,y:480,t:1527635414790};\\\", \\\"{x:1327,y:487,t:1527635414808};\\\", \\\"{x:1328,y:496,t:1527635414825};\\\", \\\"{x:1332,y:510,t:1527635414840};\\\", \\\"{x:1336,y:519,t:1527635414857};\\\", \\\"{x:1341,y:541,t:1527635414875};\\\", \\\"{x:1342,y:556,t:1527635414891};\\\", \\\"{x:1342,y:570,t:1527635414908};\\\", \\\"{x:1341,y:580,t:1527635414925};\\\", \\\"{x:1340,y:588,t:1527635414941};\\\", \\\"{x:1340,y:596,t:1527635414958};\\\", \\\"{x:1338,y:604,t:1527635414975};\\\", \\\"{x:1335,y:612,t:1527635414992};\\\", \\\"{x:1333,y:618,t:1527635415007};\\\", \\\"{x:1330,y:625,t:1527635415025};\\\", \\\"{x:1328,y:629,t:1527635415041};\\\", \\\"{x:1326,y:632,t:1527635415058};\\\", \\\"{x:1325,y:636,t:1527635415075};\\\", \\\"{x:1325,y:637,t:1527635415107};\\\", \\\"{x:1324,y:637,t:1527635415124};\\\", \\\"{x:1322,y:636,t:1527635415161};\\\", \\\"{x:1317,y:631,t:1527635415174};\\\", \\\"{x:1310,y:619,t:1527635415190};\\\", \\\"{x:1305,y:603,t:1527635415207};\\\", \\\"{x:1302,y:585,t:1527635415224};\\\", \\\"{x:1300,y:570,t:1527635415241};\\\", \\\"{x:1297,y:557,t:1527635415256};\\\", \\\"{x:1295,y:539,t:1527635415273};\\\", \\\"{x:1295,y:530,t:1527635415291};\\\", \\\"{x:1295,y:516,t:1527635415307};\\\", \\\"{x:1295,y:509,t:1527635415324};\\\", \\\"{x:1295,y:502,t:1527635415341};\\\", \\\"{x:1295,y:496,t:1527635415357};\\\", \\\"{x:1295,y:491,t:1527635415374};\\\", \\\"{x:1295,y:488,t:1527635415391};\\\", \\\"{x:1297,y:483,t:1527635415407};\\\", \\\"{x:1297,y:481,t:1527635415424};\\\", \\\"{x:1298,y:476,t:1527635415441};\\\", \\\"{x:1298,y:471,t:1527635415459};\\\", \\\"{x:1298,y:467,t:1527635415474};\\\", \\\"{x:1301,y:463,t:1527635415491};\\\", \\\"{x:1302,y:459,t:1527635415508};\\\", \\\"{x:1304,y:457,t:1527635415525};\\\", \\\"{x:1304,y:454,t:1527635415542};\\\", \\\"{x:1306,y:452,t:1527635415559};\\\", \\\"{x:1309,y:449,t:1527635415574};\\\", \\\"{x:1312,y:445,t:1527635415592};\\\", \\\"{x:1315,y:442,t:1527635415608};\\\", \\\"{x:1316,y:442,t:1527635415625};\\\", \\\"{x:1316,y:441,t:1527635415642};\\\", \\\"{x:1317,y:441,t:1527635415659};\\\", \\\"{x:1318,y:440,t:1527635415683};\\\", \\\"{x:1319,y:440,t:1527635415692};\\\", \\\"{x:1319,y:439,t:1527635415710};\\\", \\\"{x:1319,y:440,t:1527635415908};\\\", \\\"{x:1319,y:442,t:1527635415925};\\\", \\\"{x:1319,y:443,t:1527635416083};\\\", \\\"{x:1319,y:445,t:1527635416099};\\\", \\\"{x:1319,y:446,t:1527635416115};\\\", \\\"{x:1319,y:449,t:1527635416127};\\\", \\\"{x:1318,y:453,t:1527635416142};\\\", \\\"{x:1318,y:458,t:1527635416159};\\\", \\\"{x:1318,y:465,t:1527635416176};\\\", \\\"{x:1318,y:472,t:1527635416191};\\\", \\\"{x:1318,y:479,t:1527635416209};\\\", \\\"{x:1318,y:487,t:1527635416226};\\\", \\\"{x:1318,y:496,t:1527635416242};\\\", \\\"{x:1319,y:509,t:1527635416259};\\\", \\\"{x:1323,y:518,t:1527635416275};\\\", \\\"{x:1325,y:528,t:1527635416292};\\\", \\\"{x:1325,y:534,t:1527635416309};\\\", \\\"{x:1329,y:543,t:1527635416326};\\\", \\\"{x:1329,y:545,t:1527635416342};\\\", \\\"{x:1331,y:548,t:1527635416359};\\\", \\\"{x:1331,y:555,t:1527635416375};\\\", \\\"{x:1331,y:561,t:1527635416392};\\\", \\\"{x:1331,y:569,t:1527635416409};\\\", \\\"{x:1333,y:573,t:1527635416426};\\\", \\\"{x:1334,y:582,t:1527635416443};\\\", \\\"{x:1335,y:587,t:1527635416458};\\\", \\\"{x:1334,y:592,t:1527635416475};\\\", \\\"{x:1332,y:595,t:1527635416493};\\\", \\\"{x:1331,y:600,t:1527635416509};\\\", \\\"{x:1328,y:606,t:1527635416526};\\\", \\\"{x:1327,y:609,t:1527635416543};\\\", \\\"{x:1326,y:611,t:1527635416559};\\\", \\\"{x:1324,y:614,t:1527635416576};\\\", \\\"{x:1324,y:615,t:1527635416593};\\\", \\\"{x:1324,y:616,t:1527635416619};\\\", \\\"{x:1322,y:617,t:1527635416627};\\\", \\\"{x:1322,y:619,t:1527635416643};\\\", \\\"{x:1321,y:621,t:1527635416659};\\\", \\\"{x:1320,y:623,t:1527635416676};\\\", \\\"{x:1320,y:624,t:1527635416693};\\\", \\\"{x:1320,y:625,t:1527635416709};\\\", \\\"{x:1319,y:627,t:1527635416726};\\\", \\\"{x:1319,y:629,t:1527635416747};\\\", \\\"{x:1319,y:630,t:1527635416763};\\\", \\\"{x:1319,y:631,t:1527635416779};\\\", \\\"{x:1320,y:633,t:1527635416793};\\\", \\\"{x:1322,y:634,t:1527635416810};\\\", \\\"{x:1322,y:636,t:1527635416826};\\\", \\\"{x:1322,y:637,t:1527635416851};\\\", \\\"{x:1322,y:639,t:1527635416875};\\\", \\\"{x:1322,y:640,t:1527635416907};\\\", \\\"{x:1322,y:642,t:1527635416947};\\\", \\\"{x:1322,y:643,t:1527635416963};\\\", \\\"{x:1322,y:645,t:1527635416979};\\\", \\\"{x:1322,y:646,t:1527635416993};\\\", \\\"{x:1322,y:648,t:1527635417010};\\\", \\\"{x:1322,y:649,t:1527635417026};\\\", \\\"{x:1322,y:651,t:1527635417043};\\\", \\\"{x:1323,y:654,t:1527635417059};\\\", \\\"{x:1324,y:657,t:1527635417076};\\\", \\\"{x:1324,y:659,t:1527635417093};\\\", \\\"{x:1324,y:664,t:1527635417110};\\\", \\\"{x:1325,y:667,t:1527635417126};\\\", \\\"{x:1328,y:673,t:1527635417142};\\\", \\\"{x:1328,y:676,t:1527635417160};\\\", \\\"{x:1328,y:680,t:1527635417176};\\\", \\\"{x:1329,y:685,t:1527635417193};\\\", \\\"{x:1329,y:690,t:1527635417210};\\\", \\\"{x:1331,y:696,t:1527635417226};\\\", \\\"{x:1331,y:703,t:1527635417243};\\\", \\\"{x:1331,y:709,t:1527635417259};\\\", \\\"{x:1331,y:717,t:1527635417275};\\\", \\\"{x:1331,y:729,t:1527635417292};\\\", \\\"{x:1331,y:737,t:1527635417309};\\\", \\\"{x:1331,y:745,t:1527635417325};\\\", \\\"{x:1331,y:749,t:1527635417342};\\\", \\\"{x:1331,y:755,t:1527635417359};\\\", \\\"{x:1331,y:760,t:1527635417376};\\\", \\\"{x:1329,y:768,t:1527635417392};\\\", \\\"{x:1326,y:776,t:1527635417409};\\\", \\\"{x:1323,y:784,t:1527635417426};\\\", \\\"{x:1319,y:792,t:1527635417443};\\\", \\\"{x:1318,y:794,t:1527635417459};\\\", \\\"{x:1317,y:798,t:1527635417476};\\\", \\\"{x:1314,y:800,t:1527635417493};\\\", \\\"{x:1313,y:803,t:1527635417510};\\\", \\\"{x:1313,y:808,t:1527635417526};\\\", \\\"{x:1313,y:811,t:1527635417542};\\\", \\\"{x:1313,y:817,t:1527635417560};\\\", \\\"{x:1313,y:821,t:1527635417576};\\\", \\\"{x:1313,y:825,t:1527635417593};\\\", \\\"{x:1313,y:826,t:1527635417610};\\\", \\\"{x:1313,y:834,t:1527635417627};\\\", \\\"{x:1313,y:841,t:1527635417643};\\\", \\\"{x:1313,y:849,t:1527635417660};\\\", \\\"{x:1313,y:861,t:1527635417676};\\\", \\\"{x:1315,y:872,t:1527635417693};\\\", \\\"{x:1317,y:878,t:1527635417709};\\\", \\\"{x:1318,y:882,t:1527635417727};\\\", \\\"{x:1318,y:883,t:1527635417743};\\\", \\\"{x:1319,y:887,t:1527635417760};\\\", \\\"{x:1319,y:888,t:1527635417777};\\\", \\\"{x:1319,y:891,t:1527635417792};\\\", \\\"{x:1320,y:895,t:1527635417810};\\\", \\\"{x:1320,y:897,t:1527635417827};\\\", \\\"{x:1320,y:898,t:1527635417867};\\\", \\\"{x:1320,y:899,t:1527635417883};\\\", \\\"{x:1320,y:900,t:1527635417894};\\\", \\\"{x:1320,y:902,t:1527635417931};\\\", \\\"{x:1320,y:903,t:1527635417979};\\\", \\\"{x:1320,y:904,t:1527635417994};\\\", \\\"{x:1320,y:906,t:1527635418019};\\\", \\\"{x:1320,y:907,t:1527635418067};\\\", \\\"{x:1320,y:909,t:1527635418077};\\\", \\\"{x:1320,y:911,t:1527635418107};\\\", \\\"{x:1320,y:912,t:1527635418155};\\\", \\\"{x:1319,y:913,t:1527635418163};\\\", \\\"{x:1320,y:913,t:1527635418739};\\\", \\\"{x:1322,y:913,t:1527635418747};\\\", \\\"{x:1323,y:913,t:1527635418763};\\\", \\\"{x:1324,y:913,t:1527635418778};\\\", \\\"{x:1330,y:913,t:1527635418794};\\\", \\\"{x:1341,y:913,t:1527635418811};\\\", \\\"{x:1350,y:913,t:1527635418827};\\\", \\\"{x:1357,y:913,t:1527635418844};\\\", \\\"{x:1362,y:913,t:1527635418861};\\\", \\\"{x:1362,y:914,t:1527635418878};\\\", \\\"{x:1363,y:914,t:1527635418899};\\\", \\\"{x:1362,y:914,t:1527635419115};\\\", \\\"{x:1360,y:914,t:1527635419128};\\\", \\\"{x:1356,y:914,t:1527635419144};\\\", \\\"{x:1352,y:914,t:1527635419161};\\\", \\\"{x:1350,y:914,t:1527635419178};\\\", \\\"{x:1346,y:914,t:1527635419195};\\\", \\\"{x:1345,y:914,t:1527635419211};\\\", \\\"{x:1343,y:914,t:1527635419242};\\\", \\\"{x:1342,y:914,t:1527635419259};\\\", \\\"{x:1343,y:914,t:1527635419819};\\\", \\\"{x:1347,y:914,t:1527635419828};\\\", \\\"{x:1354,y:912,t:1527635419845};\\\", \\\"{x:1365,y:910,t:1527635419862};\\\", \\\"{x:1369,y:910,t:1527635419878};\\\", \\\"{x:1375,y:908,t:1527635419895};\\\", \\\"{x:1389,y:907,t:1527635419912};\\\", \\\"{x:1412,y:907,t:1527635419928};\\\", \\\"{x:1437,y:906,t:1527635419945};\\\", \\\"{x:1459,y:903,t:1527635419962};\\\", \\\"{x:1473,y:901,t:1527635419978};\\\", \\\"{x:1481,y:899,t:1527635419995};\\\", \\\"{x:1485,y:898,t:1527635420012};\\\", \\\"{x:1488,y:898,t:1527635420028};\\\", \\\"{x:1492,y:897,t:1527635420045};\\\", \\\"{x:1495,y:897,t:1527635420062};\\\", \\\"{x:1498,y:896,t:1527635420078};\\\", \\\"{x:1500,y:896,t:1527635420095};\\\", \\\"{x:1504,y:896,t:1527635420112};\\\", \\\"{x:1506,y:896,t:1527635420128};\\\", \\\"{x:1507,y:896,t:1527635420145};\\\", \\\"{x:1508,y:896,t:1527635420161};\\\", \\\"{x:1509,y:896,t:1527635420186};\\\", \\\"{x:1511,y:896,t:1527635420194};\\\", \\\"{x:1515,y:896,t:1527635420212};\\\", \\\"{x:1523,y:898,t:1527635420229};\\\", \\\"{x:1526,y:899,t:1527635420245};\\\", \\\"{x:1527,y:900,t:1527635420261};\\\", \\\"{x:1528,y:901,t:1527635420282};\\\", \\\"{x:1529,y:901,t:1527635420295};\\\", \\\"{x:1531,y:903,t:1527635420312};\\\", \\\"{x:1533,y:907,t:1527635420329};\\\", \\\"{x:1536,y:909,t:1527635420345};\\\", \\\"{x:1537,y:911,t:1527635420362};\\\", \\\"{x:1537,y:912,t:1527635420379};\\\", \\\"{x:1539,y:913,t:1527635420395};\\\", \\\"{x:1539,y:914,t:1527635420412};\\\", \\\"{x:1540,y:915,t:1527635420429};\\\", \\\"{x:1540,y:916,t:1527635420445};\\\", \\\"{x:1540,y:918,t:1527635420462};\\\", \\\"{x:1541,y:918,t:1527635420795};\\\", \\\"{x:1541,y:916,t:1527635420852};\\\", \\\"{x:1541,y:915,t:1527635420924};\\\", \\\"{x:1541,y:913,t:1527635420939};\\\", \\\"{x:1541,y:912,t:1527635420963};\\\", \\\"{x:1542,y:910,t:1527635420979};\\\", \\\"{x:1542,y:908,t:1527635420996};\\\", \\\"{x:1542,y:906,t:1527635421012};\\\", \\\"{x:1543,y:905,t:1527635421029};\\\", \\\"{x:1543,y:902,t:1527635421046};\\\", \\\"{x:1544,y:899,t:1527635421062};\\\", \\\"{x:1544,y:898,t:1527635421079};\\\", \\\"{x:1544,y:896,t:1527635421096};\\\", \\\"{x:1544,y:891,t:1527635421111};\\\", \\\"{x:1543,y:886,t:1527635421129};\\\", \\\"{x:1542,y:881,t:1527635421145};\\\", \\\"{x:1542,y:877,t:1527635421162};\\\", \\\"{x:1541,y:869,t:1527635421178};\\\", \\\"{x:1538,y:862,t:1527635421196};\\\", \\\"{x:1537,y:854,t:1527635421212};\\\", \\\"{x:1534,y:842,t:1527635421229};\\\", \\\"{x:1533,y:831,t:1527635421246};\\\", \\\"{x:1533,y:824,t:1527635421262};\\\", \\\"{x:1533,y:817,t:1527635421279};\\\", \\\"{x:1532,y:809,t:1527635421296};\\\", \\\"{x:1532,y:803,t:1527635421313};\\\", \\\"{x:1532,y:793,t:1527635421328};\\\", \\\"{x:1532,y:783,t:1527635421346};\\\", \\\"{x:1532,y:772,t:1527635421363};\\\", \\\"{x:1532,y:769,t:1527635421379};\\\", \\\"{x:1532,y:768,t:1527635421396};\\\", \\\"{x:1532,y:765,t:1527635421413};\\\", \\\"{x:1532,y:764,t:1527635421429};\\\", \\\"{x:1532,y:762,t:1527635421446};\\\", \\\"{x:1532,y:760,t:1527635421463};\\\", \\\"{x:1532,y:758,t:1527635421479};\\\", \\\"{x:1532,y:757,t:1527635421507};\\\", \\\"{x:1532,y:756,t:1527635421523};\\\", \\\"{x:1532,y:755,t:1527635421531};\\\", \\\"{x:1532,y:753,t:1527635421546};\\\", \\\"{x:1533,y:750,t:1527635421562};\\\", \\\"{x:1533,y:748,t:1527635421579};\\\", \\\"{x:1533,y:743,t:1527635421597};\\\", \\\"{x:1533,y:739,t:1527635421613};\\\", \\\"{x:1534,y:736,t:1527635421629};\\\", \\\"{x:1534,y:731,t:1527635421645};\\\", \\\"{x:1534,y:727,t:1527635421663};\\\", \\\"{x:1535,y:721,t:1527635421679};\\\", \\\"{x:1537,y:712,t:1527635421696};\\\", \\\"{x:1537,y:702,t:1527635421713};\\\", \\\"{x:1538,y:695,t:1527635421730};\\\", \\\"{x:1538,y:689,t:1527635421746};\\\", \\\"{x:1538,y:677,t:1527635421763};\\\", \\\"{x:1538,y:673,t:1527635421781};\\\", \\\"{x:1538,y:670,t:1527635421797};\\\", \\\"{x:1538,y:664,t:1527635421814};\\\", \\\"{x:1538,y:660,t:1527635421830};\\\", \\\"{x:1538,y:655,t:1527635421846};\\\", \\\"{x:1539,y:651,t:1527635421863};\\\", \\\"{x:1539,y:648,t:1527635421880};\\\", \\\"{x:1540,y:646,t:1527635421896};\\\", \\\"{x:1540,y:645,t:1527635421913};\\\", \\\"{x:1540,y:643,t:1527635421939};\\\", \\\"{x:1540,y:642,t:1527635421956};\\\", \\\"{x:1540,y:641,t:1527635421963};\\\", \\\"{x:1540,y:640,t:1527635421980};\\\", \\\"{x:1540,y:639,t:1527635421996};\\\", \\\"{x:1540,y:638,t:1527635422013};\\\", \\\"{x:1540,y:637,t:1527635422076};\\\", \\\"{x:1541,y:637,t:1527635422083};\\\", \\\"{x:1541,y:641,t:1527635422187};\\\", \\\"{x:1541,y:645,t:1527635422197};\\\", \\\"{x:1541,y:654,t:1527635422213};\\\", \\\"{x:1541,y:666,t:1527635422230};\\\", \\\"{x:1541,y:679,t:1527635422247};\\\", \\\"{x:1540,y:690,t:1527635422263};\\\", \\\"{x:1539,y:701,t:1527635422280};\\\", \\\"{x:1538,y:719,t:1527635422297};\\\", \\\"{x:1538,y:736,t:1527635422313};\\\", \\\"{x:1537,y:746,t:1527635422330};\\\", \\\"{x:1536,y:764,t:1527635422347};\\\", \\\"{x:1536,y:778,t:1527635422363};\\\", \\\"{x:1536,y:790,t:1527635422380};\\\", \\\"{x:1538,y:804,t:1527635422398};\\\", \\\"{x:1538,y:814,t:1527635422413};\\\", \\\"{x:1540,y:823,t:1527635422430};\\\", \\\"{x:1542,y:831,t:1527635422447};\\\", \\\"{x:1542,y:837,t:1527635422463};\\\", \\\"{x:1542,y:839,t:1527635422480};\\\", \\\"{x:1545,y:845,t:1527635422497};\\\", \\\"{x:1546,y:848,t:1527635422513};\\\", \\\"{x:1546,y:849,t:1527635422530};\\\", \\\"{x:1548,y:854,t:1527635422547};\\\", \\\"{x:1549,y:856,t:1527635422563};\\\", \\\"{x:1549,y:857,t:1527635422580};\\\", \\\"{x:1551,y:858,t:1527635422603};\\\", \\\"{x:1551,y:859,t:1527635422614};\\\", \\\"{x:1551,y:860,t:1527635422756};\\\", \\\"{x:1553,y:861,t:1527635422771};\\\", \\\"{x:1553,y:862,t:1527635422780};\\\", \\\"{x:1553,y:863,t:1527635422907};\\\", \\\"{x:1553,y:864,t:1527635422964};\\\", \\\"{x:1551,y:867,t:1527635422980};\\\", \\\"{x:1551,y:871,t:1527635422997};\\\", \\\"{x:1550,y:874,t:1527635423014};\\\", \\\"{x:1550,y:875,t:1527635423031};\\\", \\\"{x:1550,y:876,t:1527635423051};\\\", \\\"{x:1549,y:877,t:1527635423067};\\\", \\\"{x:1549,y:878,t:1527635423090};\\\", \\\"{x:1549,y:879,t:1527635423099};\\\", \\\"{x:1548,y:882,t:1527635423114};\\\", \\\"{x:1546,y:888,t:1527635423131};\\\", \\\"{x:1546,y:893,t:1527635423147};\\\", \\\"{x:1546,y:901,t:1527635423164};\\\", \\\"{x:1546,y:909,t:1527635423181};\\\", \\\"{x:1546,y:914,t:1527635423197};\\\", \\\"{x:1546,y:917,t:1527635423214};\\\", \\\"{x:1546,y:921,t:1527635423231};\\\", \\\"{x:1546,y:924,t:1527635423247};\\\", \\\"{x:1546,y:928,t:1527635423264};\\\", \\\"{x:1546,y:932,t:1527635423280};\\\", \\\"{x:1547,y:933,t:1527635423297};\\\", \\\"{x:1547,y:931,t:1527635423403};\\\", \\\"{x:1547,y:927,t:1527635423414};\\\", \\\"{x:1547,y:921,t:1527635423430};\\\", \\\"{x:1547,y:914,t:1527635423447};\\\", \\\"{x:1547,y:907,t:1527635423464};\\\", \\\"{x:1548,y:902,t:1527635423481};\\\", \\\"{x:1548,y:898,t:1527635423497};\\\", \\\"{x:1550,y:894,t:1527635423514};\\\", \\\"{x:1550,y:889,t:1527635423530};\\\", \\\"{x:1551,y:886,t:1527635423548};\\\", \\\"{x:1551,y:884,t:1527635423564};\\\", \\\"{x:1551,y:879,t:1527635423581};\\\", \\\"{x:1552,y:877,t:1527635423598};\\\", \\\"{x:1552,y:874,t:1527635423614};\\\", \\\"{x:1553,y:871,t:1527635423631};\\\", \\\"{x:1555,y:867,t:1527635423648};\\\", \\\"{x:1555,y:864,t:1527635423664};\\\", \\\"{x:1556,y:860,t:1527635423681};\\\", \\\"{x:1556,y:858,t:1527635423698};\\\", \\\"{x:1556,y:854,t:1527635423715};\\\", \\\"{x:1556,y:850,t:1527635423731};\\\", \\\"{x:1556,y:847,t:1527635423748};\\\", \\\"{x:1556,y:844,t:1527635423764};\\\", \\\"{x:1555,y:839,t:1527635423781};\\\", \\\"{x:1555,y:833,t:1527635423798};\\\", \\\"{x:1554,y:832,t:1527635423814};\\\", \\\"{x:1554,y:829,t:1527635423831};\\\", \\\"{x:1553,y:827,t:1527635423849};\\\", \\\"{x:1552,y:822,t:1527635423864};\\\", \\\"{x:1552,y:814,t:1527635423881};\\\", \\\"{x:1551,y:812,t:1527635423898};\\\", \\\"{x:1550,y:808,t:1527635423914};\\\", \\\"{x:1550,y:807,t:1527635423931};\\\", \\\"{x:1550,y:805,t:1527635423948};\\\", \\\"{x:1550,y:803,t:1527635423964};\\\", \\\"{x:1550,y:802,t:1527635423982};\\\", \\\"{x:1550,y:799,t:1527635423998};\\\", \\\"{x:1549,y:794,t:1527635424015};\\\", \\\"{x:1549,y:788,t:1527635424031};\\\", \\\"{x:1549,y:784,t:1527635424048};\\\", \\\"{x:1549,y:781,t:1527635424065};\\\", \\\"{x:1547,y:776,t:1527635424082};\\\", \\\"{x:1546,y:768,t:1527635424099};\\\", \\\"{x:1546,y:757,t:1527635424114};\\\", \\\"{x:1543,y:751,t:1527635424131};\\\", \\\"{x:1540,y:742,t:1527635424148};\\\", \\\"{x:1539,y:733,t:1527635424165};\\\", \\\"{x:1537,y:726,t:1527635424181};\\\", \\\"{x:1536,y:717,t:1527635424198};\\\", \\\"{x:1536,y:712,t:1527635424216};\\\", \\\"{x:1534,y:704,t:1527635424231};\\\", \\\"{x:1534,y:698,t:1527635424248};\\\", \\\"{x:1534,y:693,t:1527635424265};\\\", \\\"{x:1534,y:686,t:1527635424281};\\\", \\\"{x:1534,y:681,t:1527635424299};\\\", \\\"{x:1534,y:673,t:1527635424314};\\\", \\\"{x:1536,y:666,t:1527635424331};\\\", \\\"{x:1538,y:663,t:1527635424348};\\\", \\\"{x:1539,y:660,t:1527635424365};\\\", \\\"{x:1541,y:657,t:1527635424381};\\\", \\\"{x:1542,y:653,t:1527635424398};\\\", \\\"{x:1545,y:650,t:1527635424415};\\\", \\\"{x:1546,y:647,t:1527635424431};\\\", \\\"{x:1548,y:645,t:1527635424448};\\\", \\\"{x:1550,y:642,t:1527635424466};\\\", \\\"{x:1551,y:640,t:1527635424481};\\\", \\\"{x:1552,y:638,t:1527635424498};\\\", \\\"{x:1554,y:633,t:1527635424514};\\\", \\\"{x:1555,y:631,t:1527635424532};\\\", \\\"{x:1556,y:628,t:1527635424547};\\\", \\\"{x:1556,y:626,t:1527635424565};\\\", \\\"{x:1557,y:623,t:1527635424581};\\\", \\\"{x:1558,y:621,t:1527635424598};\\\", \\\"{x:1558,y:618,t:1527635424615};\\\", \\\"{x:1558,y:614,t:1527635424631};\\\", \\\"{x:1557,y:608,t:1527635424648};\\\", \\\"{x:1557,y:605,t:1527635424664};\\\", \\\"{x:1554,y:601,t:1527635424681};\\\", \\\"{x:1554,y:597,t:1527635424698};\\\", \\\"{x:1553,y:591,t:1527635424714};\\\", \\\"{x:1553,y:588,t:1527635424732};\\\", \\\"{x:1551,y:585,t:1527635424748};\\\", \\\"{x:1551,y:584,t:1527635424770};\\\", \\\"{x:1551,y:583,t:1527635424782};\\\", \\\"{x:1551,y:582,t:1527635424798};\\\", \\\"{x:1551,y:581,t:1527635424815};\\\", \\\"{x:1550,y:580,t:1527635424832};\\\", \\\"{x:1550,y:579,t:1527635424848};\\\", \\\"{x:1550,y:578,t:1527635425395};\\\", \\\"{x:1550,y:575,t:1527635425403};\\\", \\\"{x:1550,y:572,t:1527635425415};\\\", \\\"{x:1550,y:570,t:1527635425432};\\\", \\\"{x:1550,y:567,t:1527635425449};\\\", \\\"{x:1550,y:565,t:1527635425465};\\\", \\\"{x:1550,y:561,t:1527635425482};\\\", \\\"{x:1550,y:556,t:1527635425499};\\\", \\\"{x:1548,y:552,t:1527635425516};\\\", \\\"{x:1548,y:545,t:1527635425532};\\\", \\\"{x:1547,y:540,t:1527635425549};\\\", \\\"{x:1547,y:536,t:1527635425566};\\\", \\\"{x:1547,y:534,t:1527635425583};\\\", \\\"{x:1547,y:532,t:1527635425599};\\\", \\\"{x:1547,y:531,t:1527635425616};\\\", \\\"{x:1546,y:529,t:1527635425633};\\\", \\\"{x:1546,y:526,t:1527635425649};\\\", \\\"{x:1546,y:525,t:1527635425666};\\\", \\\"{x:1545,y:521,t:1527635425682};\\\", \\\"{x:1545,y:520,t:1527635425731};\\\", \\\"{x:1545,y:518,t:1527635425762};\\\", \\\"{x:1545,y:516,t:1527635425779};\\\", \\\"{x:1545,y:515,t:1527635425827};\\\", \\\"{x:1545,y:514,t:1527635425867};\\\", \\\"{x:1546,y:513,t:1527635425883};\\\", \\\"{x:1546,y:512,t:1527635425907};\\\", \\\"{x:1546,y:511,t:1527635425916};\\\", \\\"{x:1547,y:511,t:1527635425933};\\\", \\\"{x:1548,y:510,t:1527635425962};\\\", \\\"{x:1548,y:508,t:1527635426020};\\\", \\\"{x:1548,y:507,t:1527635426155};\\\", \\\"{x:1549,y:506,t:1527635426284};\\\", \\\"{x:1549,y:507,t:1527635429427};\\\", \\\"{x:1549,y:508,t:1527635429451};\\\", \\\"{x:1549,y:509,t:1527635429459};\\\", \\\"{x:1549,y:510,t:1527635429474};\\\", \\\"{x:1549,y:512,t:1527635429514};\\\", \\\"{x:1548,y:513,t:1527635429530};\\\", \\\"{x:1548,y:512,t:1527635430099};\\\", \\\"{x:1549,y:512,t:1527635430107};\\\", \\\"{x:1549,y:511,t:1527635432210};\\\", \\\"{x:1549,y:507,t:1527635432226};\\\", \\\"{x:1548,y:504,t:1527635432237};\\\", \\\"{x:1546,y:501,t:1527635432254};\\\", \\\"{x:1546,y:500,t:1527635432270};\\\", \\\"{x:1546,y:499,t:1527635432290};\\\", \\\"{x:1545,y:498,t:1527635432411};\\\", \\\"{x:1543,y:499,t:1527635432539};\\\", \\\"{x:1542,y:502,t:1527635432555};\\\", \\\"{x:1542,y:504,t:1527635432571};\\\", \\\"{x:1541,y:506,t:1527635432587};\\\", \\\"{x:1541,y:508,t:1527635432605};\\\", \\\"{x:1541,y:511,t:1527635432622};\\\", \\\"{x:1541,y:512,t:1527635432651};\\\", \\\"{x:1542,y:512,t:1527635432883};\\\", \\\"{x:1544,y:512,t:1527635432898};\\\", \\\"{x:1547,y:512,t:1527635432931};\\\", \\\"{x:1548,y:512,t:1527635432947};\\\", \\\"{x:1548,y:511,t:1527635433715};\\\", \\\"{x:1548,y:510,t:1527635433971};\\\", \\\"{x:1547,y:512,t:1527635441611};\\\", \\\"{x:1528,y:527,t:1527635441628};\\\", \\\"{x:1513,y:536,t:1527635441644};\\\", \\\"{x:1496,y:545,t:1527635441660};\\\", \\\"{x:1487,y:550,t:1527635441677};\\\", \\\"{x:1472,y:555,t:1527635441694};\\\", \\\"{x:1456,y:561,t:1527635441710};\\\", \\\"{x:1425,y:572,t:1527635441728};\\\", \\\"{x:1330,y:588,t:1527635441744};\\\", \\\"{x:1210,y:606,t:1527635441760};\\\", \\\"{x:1062,y:639,t:1527635441778};\\\", \\\"{x:891,y:667,t:1527635441794};\\\", \\\"{x:816,y:689,t:1527635441810};\\\", \\\"{x:781,y:701,t:1527635441827};\\\", \\\"{x:760,y:714,t:1527635441845};\\\", \\\"{x:735,y:724,t:1527635441860};\\\", \\\"{x:701,y:731,t:1527635441877};\\\", \\\"{x:661,y:738,t:1527635441894};\\\", \\\"{x:620,y:736,t:1527635441910};\\\", \\\"{x:583,y:729,t:1527635441928};\\\", \\\"{x:561,y:722,t:1527635441945};\\\", \\\"{x:542,y:715,t:1527635441961};\\\", \\\"{x:534,y:710,t:1527635441977};\\\", \\\"{x:532,y:707,t:1527635441994};\\\", \\\"{x:530,y:701,t:1527635442010};\\\", \\\"{x:527,y:685,t:1527635442029};\\\", \\\"{x:517,y:667,t:1527635442044};\\\", \\\"{x:501,y:646,t:1527635442061};\\\", \\\"{x:486,y:630,t:1527635442079};\\\", \\\"{x:471,y:616,t:1527635442096};\\\", \\\"{x:456,y:606,t:1527635442112};\\\", \\\"{x:445,y:598,t:1527635442129};\\\", \\\"{x:441,y:594,t:1527635442146};\\\", \\\"{x:439,y:594,t:1527635442163};\\\", \\\"{x:438,y:592,t:1527635442186};\\\", \\\"{x:438,y:590,t:1527635442197};\\\", \\\"{x:443,y:584,t:1527635442214};\\\", \\\"{x:457,y:575,t:1527635442230};\\\", \\\"{x:486,y:564,t:1527635442251};\\\", \\\"{x:520,y:559,t:1527635442263};\\\", \\\"{x:537,y:553,t:1527635442280};\\\", \\\"{x:552,y:552,t:1527635442296};\\\", \\\"{x:556,y:552,t:1527635442313};\\\", \\\"{x:564,y:550,t:1527635442329};\\\", \\\"{x:577,y:549,t:1527635442346};\\\", \\\"{x:587,y:549,t:1527635442363};\\\", \\\"{x:594,y:548,t:1527635442380};\\\", \\\"{x:595,y:548,t:1527635442396};\\\", \\\"{x:597,y:548,t:1527635442426};\\\", \\\"{x:598,y:548,t:1527635442433};\\\", \\\"{x:599,y:548,t:1527635442446};\\\", \\\"{x:600,y:548,t:1527635442464};\\\", \\\"{x:601,y:548,t:1527635442480};\\\", \\\"{x:602,y:548,t:1527635442522};\\\", \\\"{x:603,y:548,t:1527635442530};\\\", \\\"{x:604,y:548,t:1527635442547};\\\", \\\"{x:605,y:549,t:1527635442563};\\\", \\\"{x:605,y:550,t:1527635442658};\\\", \\\"{x:607,y:552,t:1527635442954};\\\", \\\"{x:609,y:553,t:1527635442970};\\\", \\\"{x:613,y:554,t:1527635442980};\\\", \\\"{x:636,y:557,t:1527635442998};\\\", \\\"{x:701,y:567,t:1527635443015};\\\", \\\"{x:795,y:576,t:1527635443031};\\\", \\\"{x:890,y:578,t:1527635443047};\\\", \\\"{x:980,y:584,t:1527635443064};\\\", \\\"{x:1047,y:586,t:1527635443080};\\\", \\\"{x:1105,y:594,t:1527635443097};\\\", \\\"{x:1122,y:599,t:1527635443114};\\\", \\\"{x:1142,y:602,t:1527635443130};\\\", \\\"{x:1166,y:609,t:1527635443148};\\\", \\\"{x:1191,y:615,t:1527635443165};\\\", \\\"{x:1215,y:627,t:1527635443180};\\\", \\\"{x:1241,y:638,t:1527635443198};\\\", \\\"{x:1259,y:650,t:1527635443214};\\\", \\\"{x:1280,y:661,t:1527635443230};\\\", \\\"{x:1288,y:666,t:1527635443248};\\\", \\\"{x:1291,y:670,t:1527635443264};\\\", \\\"{x:1293,y:673,t:1527635443281};\\\", \\\"{x:1296,y:679,t:1527635443298};\\\", \\\"{x:1303,y:690,t:1527635443314};\\\", \\\"{x:1308,y:699,t:1527635443331};\\\", \\\"{x:1314,y:708,t:1527635443348};\\\", \\\"{x:1323,y:720,t:1527635443365};\\\", \\\"{x:1333,y:734,t:1527635443381};\\\", \\\"{x:1350,y:747,t:1527635443397};\\\", \\\"{x:1370,y:760,t:1527635443415};\\\", \\\"{x:1396,y:773,t:1527635443432};\\\", \\\"{x:1416,y:780,t:1527635443447};\\\", \\\"{x:1437,y:785,t:1527635443465};\\\", \\\"{x:1457,y:791,t:1527635443481};\\\", \\\"{x:1478,y:794,t:1527635443497};\\\", \\\"{x:1491,y:794,t:1527635443515};\\\", \\\"{x:1492,y:794,t:1527635443531};\\\", \\\"{x:1493,y:794,t:1527635443554};\\\", \\\"{x:1493,y:793,t:1527635443565};\\\", \\\"{x:1493,y:787,t:1527635443581};\\\", \\\"{x:1493,y:784,t:1527635443598};\\\", \\\"{x:1493,y:779,t:1527635443615};\\\", \\\"{x:1493,y:777,t:1527635443632};\\\", \\\"{x:1493,y:772,t:1527635443648};\\\", \\\"{x:1491,y:765,t:1527635443664};\\\", \\\"{x:1487,y:761,t:1527635443682};\\\", \\\"{x:1486,y:760,t:1527635443698};\\\", \\\"{x:1484,y:757,t:1527635443715};\\\", \\\"{x:1483,y:756,t:1527635443732};\\\", \\\"{x:1481,y:756,t:1527635443771};\\\", \\\"{x:1481,y:755,t:1527635443795};\\\", \\\"{x:1480,y:755,t:1527635443938};\\\", \\\"{x:1478,y:755,t:1527635443954};\\\", \\\"{x:1477,y:755,t:1527635443969};\\\", \\\"{x:1476,y:756,t:1527635443986};\\\", \\\"{x:1475,y:756,t:1527635443998};\\\", \\\"{x:1475,y:758,t:1527635444014};\\\", \\\"{x:1475,y:759,t:1527635444031};\\\", \\\"{x:1474,y:760,t:1527635444048};\\\", \\\"{x:1474,y:761,t:1527635444065};\\\", \\\"{x:1474,y:762,t:1527635444082};\\\", \\\"{x:1474,y:763,t:1527635444114};\\\", \\\"{x:1473,y:764,t:1527635444146};\\\", \\\"{x:1472,y:765,t:1527635444154};\\\", \\\"{x:1472,y:766,t:1527635444219};\\\", \\\"{x:1471,y:767,t:1527635444234};\\\", \\\"{x:1470,y:768,t:1527635444291};\\\", \\\"{x:1469,y:768,t:1527635444298};\\\", \\\"{x:1469,y:769,t:1527635444316};\\\", \\\"{x:1469,y:770,t:1527635444371};\\\", \\\"{x:1469,y:771,t:1527635444411};\\\", \\\"{x:1469,y:772,t:1527635444418};\\\", \\\"{x:1468,y:773,t:1527635444434};\\\", \\\"{x:1468,y:774,t:1527635444450};\\\", \\\"{x:1468,y:775,t:1527635444475};\\\", \\\"{x:1468,y:776,t:1527635444523};\\\", \\\"{x:1469,y:776,t:1527635446010};\\\", \\\"{x:1471,y:776,t:1527635446026};\\\", \\\"{x:1472,y:776,t:1527635446034};\\\", \\\"{x:1473,y:776,t:1527635446050};\\\", \\\"{x:1476,y:776,t:1527635446066};\\\", \\\"{x:1476,y:775,t:1527635456486};\\\", \\\"{x:1476,y:773,t:1527635458951};\\\", \\\"{x:1472,y:770,t:1527635458962};\\\", \\\"{x:1464,y:761,t:1527635458979};\\\", \\\"{x:1457,y:758,t:1527635458996};\\\", \\\"{x:1453,y:755,t:1527635459012};\\\", \\\"{x:1451,y:753,t:1527635459028};\\\", \\\"{x:1449,y:751,t:1527635459086};\\\", \\\"{x:1448,y:750,t:1527635459096};\\\", \\\"{x:1447,y:750,t:1527635459112};\\\", \\\"{x:1446,y:749,t:1527635459129};\\\", \\\"{x:1445,y:748,t:1527635459165};\\\", \\\"{x:1444,y:747,t:1527635459188};\\\", \\\"{x:1443,y:746,t:1527635459196};\\\", \\\"{x:1443,y:745,t:1527635459211};\\\", \\\"{x:1442,y:744,t:1527635459228};\\\", \\\"{x:1441,y:741,t:1527635459245};\\\", \\\"{x:1440,y:740,t:1527635459261};\\\", \\\"{x:1440,y:739,t:1527635459341};\\\", \\\"{x:1439,y:738,t:1527635459357};\\\", \\\"{x:1438,y:737,t:1527635459380};\\\", \\\"{x:1438,y:736,t:1527635459396};\\\", \\\"{x:1437,y:734,t:1527635459411};\\\", \\\"{x:1433,y:729,t:1527635459428};\\\", \\\"{x:1424,y:719,t:1527635459445};\\\", \\\"{x:1418,y:712,t:1527635459463};\\\", \\\"{x:1409,y:703,t:1527635459479};\\\", \\\"{x:1402,y:693,t:1527635459495};\\\", \\\"{x:1389,y:681,t:1527635459512};\\\", \\\"{x:1377,y:670,t:1527635459529};\\\", \\\"{x:1369,y:660,t:1527635459545};\\\", \\\"{x:1361,y:652,t:1527635459562};\\\", \\\"{x:1355,y:646,t:1527635459578};\\\", \\\"{x:1352,y:642,t:1527635459595};\\\", \\\"{x:1350,y:640,t:1527635459612};\\\", \\\"{x:1349,y:638,t:1527635459628};\\\", \\\"{x:1347,y:637,t:1527635459645};\\\", \\\"{x:1347,y:636,t:1527635459662};\\\", \\\"{x:1346,y:635,t:1527635459679};\\\", \\\"{x:1345,y:635,t:1527635461286};\\\", \\\"{x:1337,y:635,t:1527635461297};\\\", \\\"{x:1277,y:646,t:1527635461314};\\\", \\\"{x:1157,y:654,t:1527635461330};\\\", \\\"{x:982,y:653,t:1527635461347};\\\", \\\"{x:791,y:657,t:1527635461363};\\\", \\\"{x:639,y:653,t:1527635461379};\\\", \\\"{x:524,y:656,t:1527635461396};\\\", \\\"{x:460,y:656,t:1527635461413};\\\", \\\"{x:457,y:656,t:1527635461429};\\\", \\\"{x:455,y:656,t:1527635461502};\\\", \\\"{x:454,y:656,t:1527635461514};\\\", \\\"{x:450,y:657,t:1527635461529};\\\", \\\"{x:450,y:658,t:1527635461546};\\\", \\\"{x:450,y:659,t:1527635461564};\\\", \\\"{x:450,y:660,t:1527635461581};\\\", \\\"{x:450,y:664,t:1527635461598};\\\", \\\"{x:457,y:672,t:1527635461613};\\\", \\\"{x:477,y:677,t:1527635461630};\\\", \\\"{x:499,y:681,t:1527635461648};\\\", \\\"{x:514,y:685,t:1527635461665};\\\", \\\"{x:530,y:687,t:1527635461682};\\\", \\\"{x:534,y:687,t:1527635461698};\\\", \\\"{x:535,y:687,t:1527635461715};\\\", \\\"{x:535,y:688,t:1527635462222};\\\", \\\"{x:539,y:688,t:1527635462270};\\\", \\\"{x:545,y:685,t:1527635462282};\\\", \\\"{x:567,y:673,t:1527635462300};\\\", \\\"{x:604,y:655,t:1527635462317};\\\", \\\"{x:615,y:651,t:1527635462332};\\\", \\\"{x:641,y:639,t:1527635462349};\\\", \\\"{x:653,y:633,t:1527635462367};\\\", \\\"{x:665,y:625,t:1527635462382};\\\", \\\"{x:679,y:616,t:1527635462399};\\\", \\\"{x:691,y:606,t:1527635462417};\\\", \\\"{x:704,y:598,t:1527635462432};\\\", \\\"{x:718,y:589,t:1527635462450};\\\", \\\"{x:726,y:582,t:1527635462466};\\\", \\\"{x:735,y:577,t:1527635462482};\\\", \\\"{x:740,y:573,t:1527635462499};\\\", \\\"{x:745,y:569,t:1527635462516};\\\", \\\"{x:749,y:565,t:1527635462532};\\\", \\\"{x:755,y:561,t:1527635462550};\\\", \\\"{x:759,y:559,t:1527635462566};\\\", \\\"{x:761,y:558,t:1527635462583};\\\", \\\"{x:766,y:557,t:1527635462600};\\\", \\\"{x:771,y:554,t:1527635462617};\\\", \\\"{x:781,y:549,t:1527635462633};\\\", \\\"{x:789,y:545,t:1527635462649};\\\", \\\"{x:792,y:544,t:1527635462666};\\\" ] }, { \\\"rt\\\": 7616, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 380470, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"8FE87\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:759,y:546,t:1527635463413};\\\", \\\"{x:756,y:546,t:1527635463438};\\\", \\\"{x:755,y:546,t:1527635463453};\\\", \\\"{x:753,y:546,t:1527635463467};\\\", \\\"{x:752,y:546,t:1527635463485};\\\", \\\"{x:751,y:546,t:1527635463500};\\\", \\\"{x:750,y:546,t:1527635463517};\\\", \\\"{x:749,y:546,t:1527635463534};\\\", \\\"{x:748,y:546,t:1527635463664};\\\", \\\"{x:747,y:546,t:1527635463845};\\\", \\\"{x:743,y:546,t:1527635463853};\\\", \\\"{x:737,y:544,t:1527635463868};\\\", \\\"{x:719,y:544,t:1527635463883};\\\", \\\"{x:684,y:544,t:1527635463900};\\\", \\\"{x:659,y:544,t:1527635463917};\\\", \\\"{x:636,y:544,t:1527635463933};\\\", \\\"{x:609,y:544,t:1527635463950};\\\", \\\"{x:582,y:544,t:1527635463967};\\\", \\\"{x:561,y:544,t:1527635463984};\\\", \\\"{x:544,y:544,t:1527635464000};\\\", \\\"{x:531,y:544,t:1527635464017};\\\", \\\"{x:521,y:544,t:1527635464034};\\\", \\\"{x:513,y:544,t:1527635464051};\\\", \\\"{x:503,y:544,t:1527635464067};\\\", \\\"{x:502,y:544,t:1527635464093};\\\", \\\"{x:501,y:544,t:1527635464134};\\\", \\\"{x:494,y:544,t:1527635464151};\\\", \\\"{x:489,y:544,t:1527635464168};\\\", \\\"{x:482,y:544,t:1527635464184};\\\", \\\"{x:473,y:545,t:1527635464201};\\\", \\\"{x:461,y:546,t:1527635464218};\\\", \\\"{x:441,y:548,t:1527635464236};\\\", \\\"{x:439,y:549,t:1527635464250};\\\", \\\"{x:437,y:549,t:1527635464267};\\\", \\\"{x:436,y:549,t:1527635464822};\\\", \\\"{x:434,y:549,t:1527635464834};\\\", \\\"{x:428,y:549,t:1527635464852};\\\", \\\"{x:408,y:549,t:1527635464869};\\\", \\\"{x:401,y:549,t:1527635464884};\\\", \\\"{x:370,y:549,t:1527635464901};\\\", \\\"{x:356,y:549,t:1527635464918};\\\", \\\"{x:347,y:549,t:1527635464935};\\\", \\\"{x:344,y:549,t:1527635464951};\\\", \\\"{x:340,y:547,t:1527635464970};\\\", \\\"{x:331,y:547,t:1527635464985};\\\", \\\"{x:322,y:547,t:1527635465001};\\\", \\\"{x:313,y:546,t:1527635465019};\\\", \\\"{x:294,y:546,t:1527635465034};\\\", \\\"{x:278,y:547,t:1527635465052};\\\", \\\"{x:259,y:547,t:1527635465069};\\\", \\\"{x:255,y:547,t:1527635465085};\\\", \\\"{x:252,y:547,t:1527635465101};\\\", \\\"{x:251,y:547,t:1527635465118};\\\", \\\"{x:258,y:544,t:1527635465237};\\\", \\\"{x:288,y:536,t:1527635465252};\\\", \\\"{x:516,y:486,t:1527635465269};\\\", \\\"{x:737,y:451,t:1527635465286};\\\", \\\"{x:980,y:423,t:1527635465301};\\\", \\\"{x:1193,y:390,t:1527635465319};\\\", \\\"{x:1356,y:364,t:1527635465336};\\\", \\\"{x:1455,y:356,t:1527635465351};\\\", \\\"{x:1504,y:349,t:1527635465369};\\\", \\\"{x:1525,y:349,t:1527635465385};\\\", \\\"{x:1532,y:349,t:1527635465402};\\\", \\\"{x:1534,y:349,t:1527635465419};\\\", \\\"{x:1538,y:349,t:1527635465436};\\\", \\\"{x:1547,y:353,t:1527635465452};\\\", \\\"{x:1555,y:358,t:1527635465469};\\\", \\\"{x:1564,y:364,t:1527635465486};\\\", \\\"{x:1568,y:368,t:1527635465503};\\\", \\\"{x:1568,y:371,t:1527635465519};\\\", \\\"{x:1568,y:379,t:1527635465535};\\\", \\\"{x:1568,y:386,t:1527635465552};\\\", \\\"{x:1564,y:396,t:1527635465570};\\\", \\\"{x:1553,y:408,t:1527635465587};\\\", \\\"{x:1543,y:420,t:1527635465603};\\\", \\\"{x:1526,y:434,t:1527635465619};\\\", \\\"{x:1501,y:452,t:1527635465637};\\\", \\\"{x:1477,y:467,t:1527635465652};\\\", \\\"{x:1456,y:478,t:1527635465670};\\\", \\\"{x:1431,y:486,t:1527635465687};\\\", \\\"{x:1406,y:492,t:1527635465704};\\\", \\\"{x:1373,y:498,t:1527635465720};\\\", \\\"{x:1347,y:507,t:1527635465737};\\\", \\\"{x:1326,y:513,t:1527635465754};\\\", \\\"{x:1303,y:518,t:1527635465770};\\\", \\\"{x:1275,y:523,t:1527635465787};\\\", \\\"{x:1244,y:529,t:1527635465804};\\\", \\\"{x:1156,y:534,t:1527635465821};\\\", \\\"{x:1089,y:534,t:1527635465838};\\\", \\\"{x:1031,y:534,t:1527635465854};\\\", \\\"{x:981,y:534,t:1527635465871};\\\", \\\"{x:956,y:534,t:1527635465888};\\\", \\\"{x:933,y:534,t:1527635465905};\\\", \\\"{x:921,y:531,t:1527635465920};\\\", \\\"{x:917,y:528,t:1527635465935};\\\", \\\"{x:909,y:519,t:1527635465953};\\\", \\\"{x:904,y:510,t:1527635465968};\\\", \\\"{x:897,y:503,t:1527635465985};\\\", \\\"{x:896,y:503,t:1527635466002};\\\", \\\"{x:899,y:503,t:1527635466284};\\\", \\\"{x:908,y:503,t:1527635466292};\\\", \\\"{x:914,y:503,t:1527635466303};\\\", \\\"{x:920,y:503,t:1527635466319};\\\", \\\"{x:921,y:503,t:1527635466349};\\\", \\\"{x:922,y:503,t:1527635466357};\\\", \\\"{x:923,y:503,t:1527635466370};\\\", \\\"{x:926,y:503,t:1527635466385};\\\", \\\"{x:930,y:504,t:1527635466402};\\\", \\\"{x:945,y:509,t:1527635466419};\\\", \\\"{x:960,y:511,t:1527635466435};\\\", \\\"{x:984,y:515,t:1527635466453};\\\", \\\"{x:1009,y:521,t:1527635466469};\\\", \\\"{x:1035,y:522,t:1527635466486};\\\", \\\"{x:1060,y:528,t:1527635466503};\\\", \\\"{x:1083,y:531,t:1527635466520};\\\", \\\"{x:1117,y:531,t:1527635466537};\\\", \\\"{x:1174,y:534,t:1527635466553};\\\", \\\"{x:1235,y:541,t:1527635466570};\\\", \\\"{x:1306,y:546,t:1527635466587};\\\", \\\"{x:1349,y:552,t:1527635466603};\\\", \\\"{x:1372,y:552,t:1527635466620};\\\", \\\"{x:1392,y:551,t:1527635466637};\\\", \\\"{x:1394,y:551,t:1527635466653};\\\", \\\"{x:1392,y:550,t:1527635466806};\\\", \\\"{x:1392,y:549,t:1527635466820};\\\", \\\"{x:1389,y:548,t:1527635466837};\\\", \\\"{x:1387,y:547,t:1527635466853};\\\", \\\"{x:1386,y:547,t:1527635466871};\\\", \\\"{x:1384,y:546,t:1527635466887};\\\", \\\"{x:1378,y:543,t:1527635466903};\\\", \\\"{x:1372,y:539,t:1527635466920};\\\", \\\"{x:1357,y:531,t:1527635466937};\\\", \\\"{x:1337,y:522,t:1527635466953};\\\", \\\"{x:1324,y:517,t:1527635466970};\\\", \\\"{x:1313,y:515,t:1527635466987};\\\", \\\"{x:1302,y:511,t:1527635467004};\\\", \\\"{x:1290,y:509,t:1527635467020};\\\", \\\"{x:1268,y:505,t:1527635467037};\\\", \\\"{x:1255,y:502,t:1527635467053};\\\", \\\"{x:1243,y:497,t:1527635467070};\\\", \\\"{x:1228,y:497,t:1527635467088};\\\", \\\"{x:1219,y:496,t:1527635467103};\\\", \\\"{x:1216,y:496,t:1527635467120};\\\", \\\"{x:1215,y:496,t:1527635467158};\\\", \\\"{x:1220,y:496,t:1527635467254};\\\", \\\"{x:1227,y:496,t:1527635467270};\\\", \\\"{x:1239,y:496,t:1527635467287};\\\", \\\"{x:1259,y:498,t:1527635467304};\\\", \\\"{x:1283,y:500,t:1527635467320};\\\", \\\"{x:1309,y:502,t:1527635467337};\\\", \\\"{x:1332,y:503,t:1527635467354};\\\", \\\"{x:1349,y:504,t:1527635467371};\\\", \\\"{x:1358,y:505,t:1527635467387};\\\", \\\"{x:1363,y:507,t:1527635467404};\\\", \\\"{x:1364,y:507,t:1527635467421};\\\", \\\"{x:1361,y:507,t:1527635467486};\\\", \\\"{x:1338,y:507,t:1527635467504};\\\", \\\"{x:1289,y:507,t:1527635467520};\\\", \\\"{x:1192,y:507,t:1527635467537};\\\", \\\"{x:1070,y:508,t:1527635467555};\\\", \\\"{x:945,y:510,t:1527635467572};\\\", \\\"{x:845,y:514,t:1527635467587};\\\", \\\"{x:792,y:514,t:1527635467603};\\\", \\\"{x:761,y:516,t:1527635467620};\\\", \\\"{x:754,y:517,t:1527635467637};\\\", \\\"{x:753,y:517,t:1527635467653};\\\", \\\"{x:751,y:517,t:1527635467676};\\\", \\\"{x:749,y:517,t:1527635467686};\\\", \\\"{x:746,y:517,t:1527635467703};\\\", \\\"{x:744,y:518,t:1527635467720};\\\", \\\"{x:742,y:518,t:1527635467781};\\\", \\\"{x:739,y:517,t:1527635467788};\\\", \\\"{x:734,y:515,t:1527635467803};\\\", \\\"{x:708,y:503,t:1527635467821};\\\", \\\"{x:676,y:498,t:1527635467838};\\\", \\\"{x:636,y:490,t:1527635467853};\\\", \\\"{x:611,y:485,t:1527635467869};\\\", \\\"{x:599,y:483,t:1527635467886};\\\", \\\"{x:598,y:482,t:1527635467903};\\\", \\\"{x:597,y:480,t:1527635467921};\\\", \\\"{x:597,y:475,t:1527635467938};\\\", \\\"{x:597,y:474,t:1527635467957};\\\", \\\"{x:597,y:473,t:1527635467981};\\\", \\\"{x:597,y:472,t:1527635468004};\\\", \\\"{x:597,y:471,t:1527635468028};\\\", \\\"{x:597,y:470,t:1527635468037};\\\", \\\"{x:598,y:467,t:1527635468054};\\\", \\\"{x:600,y:465,t:1527635468070};\\\", \\\"{x:602,y:464,t:1527635468088};\\\", \\\"{x:603,y:463,t:1527635468140};\\\", \\\"{x:604,y:461,t:1527635468156};\\\", \\\"{x:604,y:460,t:1527635468172};\\\", \\\"{x:605,y:459,t:1527635468187};\\\", \\\"{x:606,y:458,t:1527635468445};\\\", \\\"{x:609,y:459,t:1527635468455};\\\", \\\"{x:618,y:472,t:1527635468471};\\\", \\\"{x:637,y:487,t:1527635468488};\\\", \\\"{x:664,y:497,t:1527635468505};\\\", \\\"{x:690,y:501,t:1527635468521};\\\", \\\"{x:715,y:505,t:1527635468539};\\\", \\\"{x:764,y:509,t:1527635468555};\\\", \\\"{x:792,y:510,t:1527635468571};\\\", \\\"{x:808,y:509,t:1527635468588};\\\", \\\"{x:826,y:505,t:1527635468605};\\\", \\\"{x:830,y:505,t:1527635468621};\\\", \\\"{x:834,y:504,t:1527635468638};\\\", \\\"{x:835,y:504,t:1527635468655};\\\", \\\"{x:836,y:503,t:1527635468671};\\\", \\\"{x:836,y:502,t:1527635468695};\\\", \\\"{x:836,y:501,t:1527635468705};\\\", \\\"{x:836,y:499,t:1527635468721};\\\", \\\"{x:831,y:496,t:1527635468737};\\\", \\\"{x:827,y:494,t:1527635468753};\\\", \\\"{x:824,y:493,t:1527635468772};\\\", \\\"{x:823,y:491,t:1527635468788};\\\", \\\"{x:823,y:490,t:1527635468837};\\\", \\\"{x:822,y:490,t:1527635468973};\\\", \\\"{x:821,y:490,t:1527635468988};\\\", \\\"{x:802,y:501,t:1527635469005};\\\", \\\"{x:780,y:513,t:1527635469023};\\\", \\\"{x:755,y:524,t:1527635469038};\\\", \\\"{x:726,y:537,t:1527635469055};\\\", \\\"{x:694,y:550,t:1527635469072};\\\", \\\"{x:647,y:569,t:1527635469088};\\\", \\\"{x:590,y:589,t:1527635469105};\\\", \\\"{x:526,y:621,t:1527635469122};\\\", \\\"{x:485,y:645,t:1527635469137};\\\", \\\"{x:467,y:662,t:1527635469154};\\\", \\\"{x:457,y:671,t:1527635469172};\\\", \\\"{x:455,y:674,t:1527635469188};\\\", \\\"{x:458,y:674,t:1527635469348};\\\", \\\"{x:466,y:672,t:1527635469357};\\\", \\\"{x:469,y:671,t:1527635469371};\\\", \\\"{x:483,y:663,t:1527635469389};\\\", \\\"{x:505,y:651,t:1527635469405};\\\", \\\"{x:526,y:637,t:1527635469421};\\\", \\\"{x:553,y:624,t:1527635469439};\\\", \\\"{x:572,y:608,t:1527635469455};\\\", \\\"{x:582,y:603,t:1527635469471};\\\", \\\"{x:588,y:601,t:1527635469488};\\\", \\\"{x:589,y:600,t:1527635469504};\\\", \\\"{x:590,y:600,t:1527635469522};\\\", \\\"{x:590,y:599,t:1527635469538};\\\", \\\"{x:592,y:599,t:1527635469555};\\\", \\\"{x:594,y:599,t:1527635469572};\\\", \\\"{x:595,y:599,t:1527635469588};\\\", \\\"{x:598,y:599,t:1527635469678};\\\", \\\"{x:600,y:599,t:1527635469689};\\\", \\\"{x:601,y:599,t:1527635469706};\\\", \\\"{x:604,y:598,t:1527635469722};\\\", \\\"{x:608,y:595,t:1527635469739};\\\", \\\"{x:620,y:591,t:1527635469756};\\\", \\\"{x:655,y:580,t:1527635469771};\\\", \\\"{x:688,y:568,t:1527635469789};\\\", \\\"{x:702,y:564,t:1527635469806};\\\", \\\"{x:708,y:561,t:1527635469821};\\\", \\\"{x:712,y:559,t:1527635469838};\\\", \\\"{x:720,y:555,t:1527635469856};\\\", \\\"{x:735,y:550,t:1527635469872};\\\", \\\"{x:759,y:540,t:1527635469890};\\\", \\\"{x:781,y:533,t:1527635469905};\\\", \\\"{x:806,y:521,t:1527635469921};\\\", \\\"{x:827,y:514,t:1527635469939};\\\", \\\"{x:831,y:512,t:1527635469956};\\\", \\\"{x:831,y:511,t:1527635470029};\\\", \\\"{x:833,y:511,t:1527635470045};\\\", \\\"{x:835,y:508,t:1527635470057};\\\", \\\"{x:836,y:508,t:1527635470072};\\\", \\\"{x:836,y:506,t:1527635470149};\\\", \\\"{x:836,y:505,t:1527635470157};\\\", \\\"{x:836,y:499,t:1527635470173};\\\", \\\"{x:836,y:497,t:1527635470188};\\\", \\\"{x:836,y:496,t:1527635470205};\\\", \\\"{x:836,y:494,t:1527635470228};\\\", \\\"{x:837,y:493,t:1527635470261};\\\", \\\"{x:837,y:491,t:1527635470285};\\\", \\\"{x:834,y:491,t:1527635470492};\\\", \\\"{x:825,y:496,t:1527635470505};\\\", \\\"{x:805,y:511,t:1527635470524};\\\", \\\"{x:781,y:529,t:1527635470540};\\\", \\\"{x:757,y:543,t:1527635470556};\\\", \\\"{x:721,y:561,t:1527635470573};\\\", \\\"{x:699,y:577,t:1527635470589};\\\", \\\"{x:676,y:590,t:1527635470606};\\\", \\\"{x:660,y:600,t:1527635470623};\\\", \\\"{x:642,y:611,t:1527635470640};\\\", \\\"{x:626,y:619,t:1527635470656};\\\", \\\"{x:610,y:626,t:1527635470673};\\\", \\\"{x:596,y:635,t:1527635470690};\\\", \\\"{x:591,y:638,t:1527635470706};\\\", \\\"{x:583,y:641,t:1527635470723};\\\", \\\"{x:573,y:643,t:1527635470739};\\\", \\\"{x:548,y:644,t:1527635470757};\\\", \\\"{x:533,y:644,t:1527635470773};\\\", \\\"{x:513,y:646,t:1527635470790};\\\", \\\"{x:490,y:650,t:1527635470807};\\\", \\\"{x:476,y:656,t:1527635470823};\\\", \\\"{x:465,y:671,t:1527635470841};\\\", \\\"{x:459,y:678,t:1527635470856};\\\", \\\"{x:458,y:682,t:1527635470873};\\\", \\\"{x:456,y:683,t:1527635470889};\\\", \\\"{x:456,y:685,t:1527635471092};\\\", \\\"{x:459,y:682,t:1527635471349};\\\", \\\"{x:463,y:681,t:1527635471357};\\\", \\\"{x:473,y:675,t:1527635471373};\\\", \\\"{x:488,y:665,t:1527635471390};\\\", \\\"{x:507,y:653,t:1527635471407};\\\", \\\"{x:540,y:628,t:1527635471422};\\\", \\\"{x:595,y:596,t:1527635471440};\\\", \\\"{x:656,y:566,t:1527635471457};\\\", \\\"{x:703,y:545,t:1527635471473};\\\", \\\"{x:747,y:527,t:1527635471489};\\\", \\\"{x:779,y:516,t:1527635471507};\\\", \\\"{x:816,y:506,t:1527635471523};\\\", \\\"{x:851,y:499,t:1527635471540};\\\", \\\"{x:912,y:488,t:1527635471557};\\\", \\\"{x:942,y:487,t:1527635471573};\\\", \\\"{x:961,y:486,t:1527635471590};\\\", \\\"{x:968,y:484,t:1527635471606};\\\", \\\"{x:972,y:484,t:1527635471623};\\\", \\\"{x:973,y:484,t:1527635471653};\\\", \\\"{x:973,y:485,t:1527635471661};\\\", \\\"{x:973,y:486,t:1527635471673};\\\", \\\"{x:974,y:486,t:1527635472140};\\\" ] }, { \\\"rt\\\": 21159, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 402859, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"8FE87\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:975,y:486,t:1527635472262};\\\", \\\"{x:973,y:485,t:1527635472274};\\\", \\\"{x:958,y:481,t:1527635472291};\\\", \\\"{x:939,y:476,t:1527635472307};\\\", \\\"{x:899,y:470,t:1527635472324};\\\", \\\"{x:713,y:457,t:1527635472353};\\\", \\\"{x:680,y:451,t:1527635472358};\\\", \\\"{x:575,y:449,t:1527635472374};\\\", \\\"{x:455,y:449,t:1527635472390};\\\", \\\"{x:367,y:449,t:1527635472408};\\\", \\\"{x:293,y:449,t:1527635472429};\\\", \\\"{x:280,y:449,t:1527635472441};\\\", \\\"{x:276,y:449,t:1527635472458};\\\", \\\"{x:278,y:449,t:1527635472516};\\\", \\\"{x:283,y:450,t:1527635472524};\\\", \\\"{x:304,y:457,t:1527635472541};\\\", \\\"{x:337,y:462,t:1527635472557};\\\", \\\"{x:384,y:468,t:1527635472575};\\\", \\\"{x:458,y:473,t:1527635472591};\\\", \\\"{x:522,y:480,t:1527635472607};\\\", \\\"{x:560,y:483,t:1527635472623};\\\", \\\"{x:584,y:486,t:1527635472640};\\\", \\\"{x:598,y:489,t:1527635472657};\\\", \\\"{x:607,y:489,t:1527635472674};\\\", \\\"{x:613,y:490,t:1527635472691};\\\", \\\"{x:621,y:493,t:1527635472708};\\\", \\\"{x:626,y:495,t:1527635472724};\\\", \\\"{x:640,y:499,t:1527635472741};\\\", \\\"{x:650,y:503,t:1527635472758};\\\", \\\"{x:890,y:615,t:1527635472894};\\\", \\\"{x:914,y:626,t:1527635472907};\\\", \\\"{x:949,y:641,t:1527635472924};\\\", \\\"{x:962,y:651,t:1527635472941};\\\", \\\"{x:973,y:658,t:1527635472957};\\\", \\\"{x:982,y:662,t:1527635472974};\\\", \\\"{x:983,y:664,t:1527635472991};\\\", \\\"{x:984,y:664,t:1527635473013};\\\", \\\"{x:982,y:664,t:1527635478158};\\\", \\\"{x:980,y:663,t:1527635478166};\\\", \\\"{x:977,y:662,t:1527635478179};\\\", \\\"{x:969,y:661,t:1527635478196};\\\", \\\"{x:958,y:658,t:1527635478213};\\\", \\\"{x:933,y:653,t:1527635478229};\\\", \\\"{x:917,y:652,t:1527635478246};\\\", \\\"{x:903,y:649,t:1527635478262};\\\", \\\"{x:892,y:647,t:1527635478279};\\\", \\\"{x:888,y:646,t:1527635478297};\\\", \\\"{x:885,y:646,t:1527635478313};\\\", \\\"{x:884,y:645,t:1527635478329};\\\", \\\"{x:882,y:644,t:1527635478346};\\\", \\\"{x:881,y:644,t:1527635478725};\\\", \\\"{x:890,y:644,t:1527635482893};\\\", \\\"{x:910,y:639,t:1527635482900};\\\", \\\"{x:984,y:636,t:1527635482917};\\\", \\\"{x:1046,y:632,t:1527635482933};\\\", \\\"{x:1094,y:630,t:1527635482951};\\\", \\\"{x:1122,y:628,t:1527635482967};\\\", \\\"{x:1145,y:625,t:1527635482983};\\\", \\\"{x:1156,y:623,t:1527635483001};\\\", \\\"{x:1158,y:622,t:1527635483017};\\\", \\\"{x:1160,y:621,t:1527635483033};\\\", \\\"{x:1160,y:620,t:1527635483051};\\\", \\\"{x:1163,y:617,t:1527635483533};\\\", \\\"{x:1185,y:602,t:1527635483551};\\\", \\\"{x:1201,y:589,t:1527635483568};\\\", \\\"{x:1211,y:580,t:1527635483584};\\\", \\\"{x:1224,y:567,t:1527635483601};\\\", \\\"{x:1237,y:559,t:1527635483618};\\\", \\\"{x:1243,y:553,t:1527635483634};\\\", \\\"{x:1248,y:551,t:1527635483651};\\\", \\\"{x:1249,y:550,t:1527635483668};\\\", \\\"{x:1250,y:550,t:1527635483685};\\\", \\\"{x:1251,y:550,t:1527635483886};\\\", \\\"{x:1251,y:553,t:1527635483909};\\\", \\\"{x:1251,y:555,t:1527635483917};\\\", \\\"{x:1251,y:562,t:1527635483935};\\\", \\\"{x:1249,y:567,t:1527635483951};\\\", \\\"{x:1249,y:572,t:1527635483968};\\\", \\\"{x:1249,y:574,t:1527635483986};\\\", \\\"{x:1249,y:576,t:1527635484001};\\\", \\\"{x:1249,y:577,t:1527635484021};\\\", \\\"{x:1249,y:578,t:1527635484117};\\\", \\\"{x:1248,y:579,t:1527635484197};\\\", \\\"{x:1247,y:581,t:1527635484285};\\\", \\\"{x:1246,y:582,t:1527635484366};\\\", \\\"{x:1245,y:583,t:1527635484405};\\\", \\\"{x:1243,y:584,t:1527635484437};\\\", \\\"{x:1242,y:586,t:1527635484452};\\\", \\\"{x:1240,y:588,t:1527635484468};\\\", \\\"{x:1238,y:590,t:1527635484485};\\\", \\\"{x:1236,y:593,t:1527635484501};\\\", \\\"{x:1235,y:595,t:1527635484519};\\\", \\\"{x:1233,y:596,t:1527635484535};\\\", \\\"{x:1232,y:598,t:1527635484552};\\\", \\\"{x:1231,y:600,t:1527635484568};\\\", \\\"{x:1229,y:601,t:1527635484585};\\\", \\\"{x:1229,y:603,t:1527635484601};\\\", \\\"{x:1228,y:605,t:1527635484618};\\\", \\\"{x:1226,y:608,t:1527635484634};\\\", \\\"{x:1225,y:610,t:1527635484651};\\\", \\\"{x:1223,y:613,t:1527635484668};\\\", \\\"{x:1222,y:615,t:1527635484684};\\\", \\\"{x:1222,y:616,t:1527635484701};\\\", \\\"{x:1221,y:619,t:1527635484719};\\\", \\\"{x:1220,y:621,t:1527635484734};\\\", \\\"{x:1219,y:623,t:1527635484751};\\\", \\\"{x:1219,y:625,t:1527635484768};\\\", \\\"{x:1218,y:627,t:1527635484784};\\\", \\\"{x:1217,y:631,t:1527635484802};\\\", \\\"{x:1215,y:633,t:1527635484818};\\\", \\\"{x:1213,y:637,t:1527635484835};\\\", \\\"{x:1212,y:641,t:1527635484852};\\\", \\\"{x:1209,y:646,t:1527635484869};\\\", \\\"{x:1208,y:650,t:1527635484885};\\\", \\\"{x:1207,y:653,t:1527635484902};\\\", \\\"{x:1206,y:655,t:1527635484919};\\\", \\\"{x:1205,y:657,t:1527635484935};\\\", \\\"{x:1205,y:659,t:1527635484952};\\\", \\\"{x:1202,y:665,t:1527635484969};\\\", \\\"{x:1202,y:669,t:1527635484986};\\\", \\\"{x:1200,y:673,t:1527635485002};\\\", \\\"{x:1200,y:675,t:1527635485019};\\\", \\\"{x:1199,y:678,t:1527635485036};\\\", \\\"{x:1199,y:679,t:1527635485052};\\\", \\\"{x:1198,y:682,t:1527635485069};\\\", \\\"{x:1197,y:684,t:1527635485085};\\\", \\\"{x:1197,y:685,t:1527635485101};\\\", \\\"{x:1197,y:688,t:1527635485119};\\\", \\\"{x:1195,y:692,t:1527635485135};\\\", \\\"{x:1195,y:694,t:1527635485152};\\\", \\\"{x:1194,y:695,t:1527635485169};\\\", \\\"{x:1193,y:699,t:1527635485186};\\\", \\\"{x:1193,y:701,t:1527635485202};\\\", \\\"{x:1192,y:703,t:1527635485219};\\\", \\\"{x:1192,y:704,t:1527635485236};\\\", \\\"{x:1190,y:708,t:1527635485252};\\\", \\\"{x:1188,y:712,t:1527635485269};\\\", \\\"{x:1187,y:715,t:1527635485285};\\\", \\\"{x:1185,y:718,t:1527635485303};\\\", \\\"{x:1185,y:720,t:1527635485320};\\\", \\\"{x:1184,y:722,t:1527635485336};\\\", \\\"{x:1183,y:724,t:1527635485353};\\\", \\\"{x:1183,y:725,t:1527635485369};\\\", \\\"{x:1182,y:725,t:1527635485397};\\\", \\\"{x:1181,y:726,t:1527635485405};\\\", \\\"{x:1181,y:727,t:1527635485422};\\\", \\\"{x:1181,y:728,t:1527635485436};\\\", \\\"{x:1180,y:728,t:1527635485453};\\\", \\\"{x:1184,y:725,t:1527635486470};\\\", \\\"{x:1193,y:715,t:1527635486488};\\\", \\\"{x:1199,y:708,t:1527635486504};\\\", \\\"{x:1205,y:703,t:1527635486520};\\\", \\\"{x:1208,y:700,t:1527635486537};\\\", \\\"{x:1210,y:696,t:1527635486554};\\\", \\\"{x:1216,y:690,t:1527635486570};\\\", \\\"{x:1221,y:684,t:1527635486587};\\\", \\\"{x:1227,y:679,t:1527635486604};\\\", \\\"{x:1239,y:671,t:1527635486620};\\\", \\\"{x:1261,y:661,t:1527635486637};\\\", \\\"{x:1276,y:654,t:1527635486653};\\\", \\\"{x:1287,y:649,t:1527635486669};\\\", \\\"{x:1300,y:644,t:1527635486687};\\\", \\\"{x:1309,y:640,t:1527635486704};\\\", \\\"{x:1320,y:637,t:1527635486719};\\\", \\\"{x:1328,y:634,t:1527635486736};\\\", \\\"{x:1337,y:629,t:1527635486753};\\\", \\\"{x:1348,y:625,t:1527635486770};\\\", \\\"{x:1355,y:623,t:1527635486786};\\\", \\\"{x:1359,y:622,t:1527635486803};\\\", \\\"{x:1361,y:621,t:1527635486820};\\\", \\\"{x:1365,y:621,t:1527635486837};\\\", \\\"{x:1369,y:620,t:1527635486854};\\\", \\\"{x:1371,y:620,t:1527635486869};\\\", \\\"{x:1373,y:620,t:1527635486888};\\\", \\\"{x:1374,y:620,t:1527635486903};\\\", \\\"{x:1375,y:620,t:1527635486949};\\\", \\\"{x:1376,y:620,t:1527635487253};\\\", \\\"{x:1376,y:621,t:1527635487271};\\\", \\\"{x:1376,y:622,t:1527635487288};\\\", \\\"{x:1375,y:623,t:1527635487304};\\\", \\\"{x:1375,y:624,t:1527635487321};\\\", \\\"{x:1374,y:624,t:1527635487338};\\\", \\\"{x:1373,y:625,t:1527635487354};\\\", \\\"{x:1372,y:626,t:1527635487373};\\\", \\\"{x:1372,y:627,t:1527635487388};\\\", \\\"{x:1371,y:627,t:1527635487404};\\\", \\\"{x:1370,y:628,t:1527635487421};\\\", \\\"{x:1368,y:630,t:1527635487534};\\\", \\\"{x:1367,y:630,t:1527635487557};\\\", \\\"{x:1367,y:631,t:1527635487614};\\\", \\\"{x:1365,y:631,t:1527635487661};\\\", \\\"{x:1364,y:633,t:1527635487685};\\\", \\\"{x:1362,y:635,t:1527635487709};\\\", \\\"{x:1361,y:635,t:1527635487741};\\\", \\\"{x:1361,y:636,t:1527635487757};\\\", \\\"{x:1359,y:637,t:1527635487781};\\\", \\\"{x:1358,y:638,t:1527635487821};\\\", \\\"{x:1357,y:638,t:1527635487838};\\\", \\\"{x:1354,y:641,t:1527635487855};\\\", \\\"{x:1352,y:642,t:1527635487879};\\\", \\\"{x:1351,y:643,t:1527635487904};\\\", \\\"{x:1350,y:644,t:1527635487920};\\\", \\\"{x:1350,y:645,t:1527635487988};\\\", \\\"{x:1350,y:647,t:1527635488004};\\\", \\\"{x:1349,y:648,t:1527635488029};\\\", \\\"{x:1349,y:649,t:1527635488052};\\\", \\\"{x:1348,y:650,t:1527635488061};\\\", \\\"{x:1347,y:655,t:1527635488534};\\\", \\\"{x:1346,y:658,t:1527635488541};\\\", \\\"{x:1346,y:661,t:1527635488555};\\\", \\\"{x:1346,y:664,t:1527635488572};\\\", \\\"{x:1345,y:671,t:1527635488588};\\\", \\\"{x:1344,y:674,t:1527635488605};\\\", \\\"{x:1344,y:677,t:1527635488622};\\\", \\\"{x:1344,y:679,t:1527635488639};\\\", \\\"{x:1344,y:681,t:1527635488655};\\\", \\\"{x:1344,y:684,t:1527635488672};\\\", \\\"{x:1344,y:685,t:1527635488689};\\\", \\\"{x:1344,y:687,t:1527635488705};\\\", \\\"{x:1344,y:688,t:1527635488722};\\\", \\\"{x:1344,y:689,t:1527635488773};\\\", \\\"{x:1343,y:690,t:1527635488805};\\\", \\\"{x:1342,y:691,t:1527635488829};\\\", \\\"{x:1341,y:692,t:1527635488861};\\\", \\\"{x:1340,y:692,t:1527635488877};\\\", \\\"{x:1340,y:693,t:1527635488889};\\\", \\\"{x:1335,y:695,t:1527635488905};\\\", \\\"{x:1327,y:698,t:1527635488922};\\\", \\\"{x:1310,y:701,t:1527635488939};\\\", \\\"{x:1275,y:703,t:1527635488956};\\\", \\\"{x:1238,y:705,t:1527635488971};\\\", \\\"{x:1164,y:708,t:1527635488988};\\\", \\\"{x:1111,y:708,t:1527635489005};\\\", \\\"{x:1047,y:708,t:1527635489022};\\\", \\\"{x:988,y:708,t:1527635489038};\\\", \\\"{x:951,y:708,t:1527635489055};\\\", \\\"{x:908,y:701,t:1527635489071};\\\", \\\"{x:878,y:696,t:1527635489088};\\\", \\\"{x:849,y:691,t:1527635489105};\\\", \\\"{x:825,y:689,t:1527635489121};\\\", \\\"{x:806,y:686,t:1527635489138};\\\", \\\"{x:792,y:684,t:1527635489156};\\\", \\\"{x:788,y:681,t:1527635489171};\\\", \\\"{x:787,y:679,t:1527635489188};\\\", \\\"{x:787,y:677,t:1527635489206};\\\", \\\"{x:785,y:677,t:1527635489445};\\\", \\\"{x:782,y:677,t:1527635489461};\\\", \\\"{x:781,y:677,t:1527635489473};\\\", \\\"{x:771,y:675,t:1527635489489};\\\", \\\"{x:751,y:672,t:1527635489506};\\\", \\\"{x:733,y:670,t:1527635489522};\\\", \\\"{x:708,y:664,t:1527635489538};\\\", \\\"{x:683,y:656,t:1527635489555};\\\", \\\"{x:646,y:639,t:1527635489571};\\\", \\\"{x:603,y:622,t:1527635489589};\\\", \\\"{x:560,y:607,t:1527635489605};\\\", \\\"{x:535,y:596,t:1527635489622};\\\", \\\"{x:514,y:585,t:1527635489639};\\\", \\\"{x:494,y:573,t:1527635489656};\\\", \\\"{x:480,y:564,t:1527635489672};\\\", \\\"{x:470,y:556,t:1527635489688};\\\", \\\"{x:463,y:550,t:1527635489703};\\\", \\\"{x:457,y:546,t:1527635489720};\\\", \\\"{x:451,y:543,t:1527635489737};\\\", \\\"{x:446,y:542,t:1527635489754};\\\", \\\"{x:437,y:541,t:1527635489771};\\\", \\\"{x:432,y:539,t:1527635489788};\\\", \\\"{x:429,y:539,t:1527635489804};\\\", \\\"{x:427,y:539,t:1527635489821};\\\", \\\"{x:426,y:539,t:1527635489845};\\\", \\\"{x:424,y:539,t:1527635489854};\\\", \\\"{x:422,y:539,t:1527635489871};\\\", \\\"{x:420,y:539,t:1527635489889};\\\", \\\"{x:417,y:538,t:1527635489905};\\\", \\\"{x:417,y:536,t:1527635489932};\\\", \\\"{x:417,y:534,t:1527635489941};\\\", \\\"{x:416,y:532,t:1527635489955};\\\", \\\"{x:415,y:527,t:1527635489971};\\\", \\\"{x:413,y:522,t:1527635489988};\\\", \\\"{x:411,y:516,t:1527635490005};\\\", \\\"{x:407,y:508,t:1527635490022};\\\", \\\"{x:404,y:499,t:1527635490039};\\\", \\\"{x:401,y:486,t:1527635490054};\\\", \\\"{x:401,y:481,t:1527635490071};\\\", \\\"{x:401,y:477,t:1527635490088};\\\", \\\"{x:401,y:472,t:1527635490105};\\\", \\\"{x:409,y:467,t:1527635490122};\\\", \\\"{x:426,y:459,t:1527635490139};\\\", \\\"{x:440,y:454,t:1527635490155};\\\", \\\"{x:462,y:449,t:1527635490172};\\\", \\\"{x:493,y:448,t:1527635490188};\\\", \\\"{x:519,y:448,t:1527635490205};\\\", \\\"{x:553,y:448,t:1527635490222};\\\", \\\"{x:586,y:448,t:1527635490239};\\\", \\\"{x:609,y:451,t:1527635490256};\\\", \\\"{x:623,y:454,t:1527635490271};\\\", \\\"{x:630,y:454,t:1527635490289};\\\", \\\"{x:635,y:456,t:1527635490306};\\\", \\\"{x:641,y:456,t:1527635490321};\\\", \\\"{x:650,y:459,t:1527635490339};\\\", \\\"{x:668,y:461,t:1527635490356};\\\", \\\"{x:690,y:465,t:1527635490372};\\\", \\\"{x:728,y:465,t:1527635490388};\\\", \\\"{x:770,y:467,t:1527635490405};\\\", \\\"{x:809,y:470,t:1527635490422};\\\", \\\"{x:845,y:471,t:1527635490439};\\\", \\\"{x:871,y:471,t:1527635490456};\\\", \\\"{x:881,y:471,t:1527635490472};\\\", \\\"{x:882,y:471,t:1527635490488};\\\", \\\"{x:883,y:471,t:1527635490542};\\\", \\\"{x:884,y:471,t:1527635490556};\\\", \\\"{x:884,y:467,t:1527635490573};\\\", \\\"{x:882,y:464,t:1527635490590};\\\", \\\"{x:882,y:461,t:1527635490605};\\\", \\\"{x:882,y:460,t:1527635490622};\\\", \\\"{x:880,y:456,t:1527635490638};\\\", \\\"{x:879,y:454,t:1527635490654};\\\", \\\"{x:877,y:452,t:1527635490671};\\\", \\\"{x:870,y:449,t:1527635490689};\\\", \\\"{x:864,y:446,t:1527635490705};\\\", \\\"{x:860,y:445,t:1527635490721};\\\", \\\"{x:856,y:444,t:1527635490738};\\\", \\\"{x:852,y:442,t:1527635490756};\\\", \\\"{x:849,y:442,t:1527635490772};\\\", \\\"{x:846,y:442,t:1527635490789};\\\", \\\"{x:843,y:442,t:1527635490806};\\\", \\\"{x:842,y:442,t:1527635490837};\\\", \\\"{x:840,y:442,t:1527635490980};\\\", \\\"{x:838,y:442,t:1527635490989};\\\", \\\"{x:828,y:444,t:1527635491005};\\\", \\\"{x:818,y:449,t:1527635491022};\\\", \\\"{x:800,y:454,t:1527635491038};\\\", \\\"{x:778,y:462,t:1527635491055};\\\", \\\"{x:748,y:470,t:1527635491073};\\\", \\\"{x:711,y:479,t:1527635491089};\\\", \\\"{x:679,y:485,t:1527635491105};\\\", \\\"{x:653,y:493,t:1527635491123};\\\", \\\"{x:629,y:499,t:1527635491139};\\\", \\\"{x:604,y:505,t:1527635491156};\\\", \\\"{x:578,y:513,t:1527635491172};\\\", \\\"{x:563,y:517,t:1527635491188};\\\", \\\"{x:554,y:521,t:1527635491205};\\\", \\\"{x:547,y:526,t:1527635491222};\\\", \\\"{x:545,y:527,t:1527635491240};\\\", \\\"{x:544,y:528,t:1527635491255};\\\", \\\"{x:544,y:529,t:1527635491273};\\\", \\\"{x:543,y:529,t:1527635491290};\\\", \\\"{x:541,y:530,t:1527635491308};\\\", \\\"{x:538,y:529,t:1527635491461};\\\", \\\"{x:530,y:529,t:1527635491473};\\\", \\\"{x:508,y:529,t:1527635491489};\\\", \\\"{x:477,y:525,t:1527635491507};\\\", \\\"{x:444,y:525,t:1527635491522};\\\", \\\"{x:412,y:521,t:1527635491540};\\\", \\\"{x:376,y:516,t:1527635491557};\\\", \\\"{x:366,y:514,t:1527635491573};\\\", \\\"{x:359,y:514,t:1527635491589};\\\", \\\"{x:354,y:512,t:1527635491605};\\\", \\\"{x:348,y:511,t:1527635491622};\\\", \\\"{x:344,y:511,t:1527635491639};\\\", \\\"{x:340,y:511,t:1527635491656};\\\", \\\"{x:333,y:510,t:1527635491673};\\\", \\\"{x:322,y:508,t:1527635491690};\\\", \\\"{x:305,y:508,t:1527635491706};\\\", \\\"{x:286,y:508,t:1527635491722};\\\", \\\"{x:267,y:507,t:1527635491739};\\\", \\\"{x:238,y:506,t:1527635491756};\\\", \\\"{x:223,y:505,t:1527635491773};\\\", \\\"{x:208,y:502,t:1527635491790};\\\", \\\"{x:202,y:501,t:1527635491806};\\\", \\\"{x:198,y:500,t:1527635491822};\\\", \\\"{x:196,y:500,t:1527635491840};\\\", \\\"{x:195,y:499,t:1527635491856};\\\", \\\"{x:193,y:499,t:1527635491873};\\\", \\\"{x:191,y:497,t:1527635491890};\\\", \\\"{x:189,y:497,t:1527635491906};\\\", \\\"{x:188,y:496,t:1527635491922};\\\", \\\"{x:184,y:494,t:1527635491940};\\\", \\\"{x:178,y:493,t:1527635491956};\\\", \\\"{x:176,y:492,t:1527635491972};\\\", \\\"{x:175,y:492,t:1527635491996};\\\", \\\"{x:175,y:491,t:1527635492020};\\\", \\\"{x:180,y:492,t:1527635492164};\\\", \\\"{x:185,y:493,t:1527635492173};\\\", \\\"{x:199,y:499,t:1527635492190};\\\", \\\"{x:218,y:506,t:1527635492207};\\\", \\\"{x:233,y:514,t:1527635492224};\\\", \\\"{x:255,y:527,t:1527635492239};\\\", \\\"{x:278,y:542,t:1527635492257};\\\", \\\"{x:298,y:557,t:1527635492274};\\\", \\\"{x:318,y:569,t:1527635492289};\\\", \\\"{x:339,y:581,t:1527635492307};\\\", \\\"{x:341,y:584,t:1527635492323};\\\", \\\"{x:343,y:586,t:1527635492340};\\\", \\\"{x:352,y:596,t:1527635492357};\\\", \\\"{x:362,y:607,t:1527635492373};\\\", \\\"{x:377,y:624,t:1527635492390};\\\", \\\"{x:397,y:639,t:1527635492406};\\\", \\\"{x:400,y:641,t:1527635492424};\\\", \\\"{x:402,y:641,t:1527635492439};\\\", \\\"{x:404,y:641,t:1527635492460};\\\", \\\"{x:406,y:642,t:1527635492473};\\\", \\\"{x:407,y:644,t:1527635492490};\\\", \\\"{x:408,y:644,t:1527635492565};\\\", \\\"{x:409,y:643,t:1527635492685};\\\", \\\"{x:410,y:643,t:1527635492701};\\\", \\\"{x:409,y:643,t:1527635492933};\\\", \\\"{x:410,y:643,t:1527635492940};\\\", \\\"{x:431,y:652,t:1527635492958};\\\", \\\"{x:443,y:655,t:1527635492973};\\\", \\\"{x:450,y:658,t:1527635492991};\\\", \\\"{x:452,y:658,t:1527635493008};\\\", \\\"{x:453,y:658,t:1527635493024};\\\", \\\"{x:456,y:658,t:1527635493093};\\\", \\\"{x:457,y:659,t:1527635493108};\\\", \\\"{x:458,y:660,t:1527635493123};\\\", \\\"{x:461,y:662,t:1527635493140};\\\", \\\"{x:462,y:663,t:1527635493158};\\\", \\\"{x:464,y:664,t:1527635493180};\\\", \\\"{x:466,y:665,t:1527635493190};\\\", \\\"{x:477,y:672,t:1527635493208};\\\", \\\"{x:493,y:681,t:1527635493223};\\\", \\\"{x:509,y:689,t:1527635493241};\\\", \\\"{x:520,y:693,t:1527635493258};\\\", \\\"{x:528,y:697,t:1527635493274};\\\", \\\"{x:530,y:698,t:1527635493291};\\\", \\\"{x:533,y:700,t:1527635493307};\\\", \\\"{x:534,y:700,t:1527635493324};\\\", \\\"{x:535,y:700,t:1527635493628};\\\", \\\"{x:535,y:698,t:1527635493644};\\\", \\\"{x:536,y:698,t:1527635493660};\\\", \\\"{x:536,y:697,t:1527635493684};\\\", \\\"{x:536,y:696,t:1527635493708};\\\", \\\"{x:536,y:695,t:1527635493724};\\\", \\\"{x:538,y:693,t:1527635493741};\\\", \\\"{x:540,y:691,t:1527635493758};\\\", \\\"{x:542,y:689,t:1527635493774};\\\", \\\"{x:546,y:687,t:1527635493791};\\\", \\\"{x:550,y:684,t:1527635493808};\\\", \\\"{x:562,y:678,t:1527635493825};\\\", \\\"{x:580,y:670,t:1527635493841};\\\", \\\"{x:609,y:657,t:1527635493857};\\\", \\\"{x:645,y:648,t:1527635493875};\\\", \\\"{x:682,y:637,t:1527635493891};\\\", \\\"{x:716,y:630,t:1527635493907};\\\", \\\"{x:750,y:623,t:1527635493924};\\\", \\\"{x:771,y:617,t:1527635493942};\\\", \\\"{x:790,y:611,t:1527635493957};\\\", \\\"{x:805,y:605,t:1527635493974};\\\", \\\"{x:828,y:597,t:1527635493992};\\\", \\\"{x:843,y:592,t:1527635494007};\\\", \\\"{x:852,y:589,t:1527635494025};\\\", \\\"{x:854,y:589,t:1527635494042};\\\", \\\"{x:855,y:587,t:1527635494058};\\\" ] }, { \\\"rt\\\": 128177, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 532256, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"8FE87\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 7, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B -B -B -B -B -B -B -E -A -X -X -X -X -B -B -B -B -L -X -X -N -Z -X -B -I -I -B -B -I -B -F -E -J -E -G -6-E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:848,y:589,t:1527635495141};\\\", \\\"{x:840,y:593,t:1527635495159};\\\", \\\"{x:833,y:597,t:1527635495175};\\\", \\\"{x:826,y:598,t:1527635495192};\\\", \\\"{x:805,y:603,t:1527635495208};\\\", \\\"{x:779,y:607,t:1527635495225};\\\", \\\"{x:746,y:612,t:1527635495242};\\\", \\\"{x:712,y:616,t:1527635495259};\\\", \\\"{x:684,y:620,t:1527635495275};\\\", \\\"{x:648,y:620,t:1527635495292};\\\", \\\"{x:630,y:621,t:1527635495308};\\\", \\\"{x:613,y:621,t:1527635495326};\\\", \\\"{x:594,y:621,t:1527635495343};\\\", \\\"{x:582,y:621,t:1527635495358};\\\", \\\"{x:573,y:621,t:1527635495376};\\\", \\\"{x:570,y:621,t:1527635495393};\\\", \\\"{x:568,y:621,t:1527635495408};\\\", \\\"{x:565,y:621,t:1527635495426};\\\", \\\"{x:562,y:620,t:1527635495443};\\\", \\\"{x:561,y:620,t:1527635495459};\\\", \\\"{x:559,y:620,t:1527635495476};\\\", \\\"{x:558,y:620,t:1527635496285};\\\", \\\"{x:557,y:620,t:1527635497925};\\\", \\\"{x:555,y:620,t:1527635497933};\\\", \\\"{x:554,y:620,t:1527635497944};\\\", \\\"{x:552,y:620,t:1527635497961};\\\", \\\"{x:550,y:620,t:1527635497978};\\\", \\\"{x:549,y:620,t:1527635497995};\\\", \\\"{x:547,y:619,t:1527635498011};\\\", \\\"{x:545,y:619,t:1527635498028};\\\", \\\"{x:544,y:617,t:1527635498044};\\\", \\\"{x:542,y:617,t:1527635498061};\\\", \\\"{x:539,y:616,t:1527635498078};\\\", \\\"{x:538,y:616,t:1527635498094};\\\", \\\"{x:535,y:616,t:1527635498111};\\\", \\\"{x:533,y:615,t:1527635498128};\\\", \\\"{x:531,y:614,t:1527635498145};\\\", \\\"{x:528,y:613,t:1527635498161};\\\", \\\"{x:527,y:613,t:1527635498178};\\\", \\\"{x:525,y:613,t:1527635498195};\\\", \\\"{x:524,y:612,t:1527635498211};\\\", \\\"{x:523,y:612,t:1527635498229};\\\", \\\"{x:522,y:612,t:1527635498244};\\\", \\\"{x:520,y:611,t:1527635498261};\\\", \\\"{x:519,y:610,t:1527635498278};\\\", \\\"{x:517,y:609,t:1527635498295};\\\", \\\"{x:516,y:609,t:1527635498311};\\\", \\\"{x:514,y:608,t:1527635498328};\\\", \\\"{x:512,y:605,t:1527635498345};\\\", \\\"{x:510,y:604,t:1527635498362};\\\", \\\"{x:509,y:603,t:1527635498378};\\\", \\\"{x:507,y:600,t:1527635498395};\\\", \\\"{x:506,y:599,t:1527635498411};\\\", \\\"{x:506,y:597,t:1527635498428};\\\", \\\"{x:503,y:592,t:1527635498444};\\\", \\\"{x:503,y:589,t:1527635498461};\\\", \\\"{x:500,y:580,t:1527635498478};\\\", \\\"{x:498,y:573,t:1527635498497};\\\", \\\"{x:497,y:560,t:1527635498511};\\\", \\\"{x:493,y:545,t:1527635498528};\\\", \\\"{x:490,y:536,t:1527635498545};\\\", \\\"{x:490,y:528,t:1527635498562};\\\", \\\"{x:490,y:519,t:1527635498579};\\\", \\\"{x:489,y:511,t:1527635498594};\\\", \\\"{x:486,y:499,t:1527635498613};\\\", \\\"{x:486,y:493,t:1527635498628};\\\", \\\"{x:486,y:489,t:1527635498645};\\\", \\\"{x:486,y:485,t:1527635498662};\\\", \\\"{x:486,y:481,t:1527635498678};\\\", \\\"{x:487,y:478,t:1527635498695};\\\", \\\"{x:488,y:474,t:1527635498711};\\\", \\\"{x:488,y:472,t:1527635498728};\\\", \\\"{x:490,y:472,t:1527635499084};\\\", \\\"{x:492,y:472,t:1527635499157};\\\", \\\"{x:493,y:472,t:1527635499188};\\\", \\\"{x:494,y:472,t:1527635499213};\\\", \\\"{x:495,y:472,t:1527635499269};\\\", \\\"{x:499,y:472,t:1527635501743};\\\", \\\"{x:562,y:472,t:1527635501763};\\\", \\\"{x:634,y:472,t:1527635501781};\\\", \\\"{x:725,y:472,t:1527635501798};\\\", \\\"{x:809,y:472,t:1527635501813};\\\", \\\"{x:871,y:471,t:1527635501831};\\\", \\\"{x:913,y:469,t:1527635501847};\\\", \\\"{x:967,y:468,t:1527635501864};\\\", \\\"{x:1015,y:466,t:1527635501881};\\\", \\\"{x:1078,y:463,t:1527635501898};\\\", \\\"{x:1150,y:463,t:1527635501914};\\\", \\\"{x:1233,y:463,t:1527635501931};\\\", \\\"{x:1372,y:463,t:1527635501948};\\\", \\\"{x:1434,y:461,t:1527635501965};\\\", \\\"{x:1461,y:461,t:1527635501981};\\\", \\\"{x:1471,y:462,t:1527635501998};\\\", \\\"{x:1473,y:463,t:1527635502015};\\\", \\\"{x:1474,y:463,t:1527635502053};\\\", \\\"{x:1475,y:464,t:1527635502533};\\\", \\\"{x:1477,y:464,t:1527635502549};\\\", \\\"{x:1478,y:459,t:1527635502566};\\\", \\\"{x:1480,y:450,t:1527635502583};\\\", \\\"{x:1482,y:440,t:1527635502599};\\\", \\\"{x:1485,y:426,t:1527635502616};\\\", \\\"{x:1495,y:400,t:1527635502633};\\\", \\\"{x:1508,y:360,t:1527635502649};\\\", \\\"{x:1524,y:317,t:1527635502665};\\\", \\\"{x:1537,y:286,t:1527635502682};\\\", \\\"{x:1548,y:267,t:1527635502699};\\\", \\\"{x:1557,y:254,t:1527635502715};\\\", \\\"{x:1558,y:251,t:1527635502733};\\\", \\\"{x:1559,y:248,t:1527635502750};\\\", \\\"{x:1560,y:247,t:1527635502766};\\\", \\\"{x:1560,y:246,t:1527635502783};\\\", \\\"{x:1559,y:245,t:1527635503077};\\\", \\\"{x:1554,y:246,t:1527635503085};\\\", \\\"{x:1541,y:251,t:1527635503100};\\\", \\\"{x:1525,y:256,t:1527635503117};\\\", \\\"{x:1512,y:259,t:1527635503134};\\\", \\\"{x:1503,y:262,t:1527635503150};\\\", \\\"{x:1495,y:263,t:1527635503167};\\\", \\\"{x:1491,y:267,t:1527635503184};\\\", \\\"{x:1485,y:269,t:1527635503201};\\\", \\\"{x:1482,y:270,t:1527635503217};\\\", \\\"{x:1480,y:271,t:1527635503234};\\\", \\\"{x:1477,y:273,t:1527635503252};\\\", \\\"{x:1474,y:274,t:1527635503268};\\\", \\\"{x:1469,y:278,t:1527635503285};\\\", \\\"{x:1462,y:281,t:1527635503301};\\\", \\\"{x:1455,y:285,t:1527635503318};\\\", \\\"{x:1448,y:290,t:1527635503335};\\\", \\\"{x:1440,y:295,t:1527635503352};\\\", \\\"{x:1433,y:300,t:1527635503369};\\\", \\\"{x:1424,y:307,t:1527635503385};\\\", \\\"{x:1416,y:315,t:1527635503401};\\\", \\\"{x:1399,y:328,t:1527635503419};\\\", \\\"{x:1377,y:348,t:1527635503435};\\\", \\\"{x:1352,y:372,t:1527635503452};\\\", \\\"{x:1322,y:399,t:1527635503469};\\\", \\\"{x:1307,y:416,t:1527635503485};\\\", \\\"{x:1298,y:429,t:1527635503501};\\\", \\\"{x:1289,y:443,t:1527635503518};\\\", \\\"{x:1282,y:455,t:1527635503536};\\\", \\\"{x:1274,y:469,t:1527635503552};\\\", \\\"{x:1267,y:487,t:1527635503569};\\\", \\\"{x:1262,y:501,t:1527635503585};\\\", \\\"{x:1254,y:518,t:1527635503602};\\\", \\\"{x:1249,y:532,t:1527635503618};\\\", \\\"{x:1249,y:551,t:1527635503636};\\\", \\\"{x:1249,y:575,t:1527635503653};\\\", \\\"{x:1254,y:589,t:1527635503669};\\\", \\\"{x:1256,y:600,t:1527635503686};\\\", \\\"{x:1263,y:612,t:1527635503703};\\\", \\\"{x:1266,y:618,t:1527635503718};\\\", \\\"{x:1270,y:626,t:1527635503736};\\\", \\\"{x:1273,y:631,t:1527635503753};\\\", \\\"{x:1276,y:637,t:1527635503769};\\\", \\\"{x:1280,y:642,t:1527635503785};\\\", \\\"{x:1282,y:647,t:1527635503802};\\\", \\\"{x:1287,y:654,t:1527635503819};\\\", \\\"{x:1293,y:658,t:1527635503835};\\\", \\\"{x:1306,y:668,t:1527635503852};\\\", \\\"{x:1322,y:676,t:1527635503869};\\\", \\\"{x:1337,y:685,t:1527635503885};\\\", \\\"{x:1347,y:690,t:1527635503902};\\\", \\\"{x:1352,y:690,t:1527635503918};\\\", \\\"{x:1354,y:691,t:1527635503936};\\\", \\\"{x:1354,y:692,t:1527635504157};\\\", \\\"{x:1354,y:694,t:1527635504173};\\\", \\\"{x:1353,y:695,t:1527635504187};\\\", \\\"{x:1353,y:696,t:1527635504204};\\\", \\\"{x:1352,y:696,t:1527635504219};\\\", \\\"{x:1352,y:697,t:1527635504244};\\\", \\\"{x:1351,y:697,t:1527635504269};\\\", \\\"{x:1350,y:699,t:1527635504309};\\\", \\\"{x:1348,y:700,t:1527635504356};\\\", \\\"{x:1345,y:702,t:1527635504381};\\\", \\\"{x:1344,y:702,t:1527635504388};\\\", \\\"{x:1344,y:703,t:1527635504404};\\\", \\\"{x:1341,y:705,t:1527635504422};\\\", \\\"{x:1340,y:706,t:1527635504436};\\\", \\\"{x:1339,y:707,t:1527635504454};\\\", \\\"{x:1338,y:708,t:1527635504469};\\\", \\\"{x:1339,y:709,t:1527635504861};\\\", \\\"{x:1340,y:709,t:1527635504892};\\\", \\\"{x:1342,y:710,t:1527635504904};\\\", \\\"{x:1343,y:709,t:1527635506701};\\\", \\\"{x:1350,y:676,t:1527635506710};\\\", \\\"{x:1360,y:614,t:1527635506725};\\\", \\\"{x:1374,y:567,t:1527635506743};\\\", \\\"{x:1378,y:538,t:1527635506759};\\\", \\\"{x:1378,y:512,t:1527635506776};\\\", \\\"{x:1379,y:489,t:1527635506792};\\\", \\\"{x:1380,y:471,t:1527635506809};\\\", \\\"{x:1380,y:461,t:1527635506825};\\\", \\\"{x:1380,y:454,t:1527635506843};\\\", \\\"{x:1380,y:449,t:1527635506860};\\\", \\\"{x:1380,y:446,t:1527635506875};\\\", \\\"{x:1380,y:444,t:1527635506892};\\\", \\\"{x:1380,y:443,t:1527635507333};\\\", \\\"{x:1379,y:443,t:1527635507373};\\\", \\\"{x:1378,y:442,t:1527635507381};\\\", \\\"{x:1378,y:441,t:1527635507437};\\\", \\\"{x:1377,y:441,t:1527635507541};\\\", \\\"{x:1376,y:440,t:1527635507573};\\\", \\\"{x:1375,y:440,t:1527635507588};\\\", \\\"{x:1374,y:440,t:1527635507596};\\\", \\\"{x:1373,y:440,t:1527635507621};\\\", \\\"{x:1371,y:440,t:1527635507629};\\\", \\\"{x:1369,y:440,t:1527635507644};\\\", \\\"{x:1368,y:440,t:1527635507661};\\\", \\\"{x:1367,y:439,t:1527635507678};\\\", \\\"{x:1366,y:439,t:1527635507725};\\\", \\\"{x:1365,y:439,t:1527635507748};\\\", \\\"{x:1364,y:439,t:1527635507805};\\\", \\\"{x:1363,y:439,t:1527635507893};\\\", \\\"{x:1362,y:439,t:1527635507901};\\\", \\\"{x:1361,y:441,t:1527635507911};\\\", \\\"{x:1360,y:450,t:1527635507929};\\\", \\\"{x:1357,y:462,t:1527635507945};\\\", \\\"{x:1356,y:478,t:1527635507961};\\\", \\\"{x:1356,y:495,t:1527635507978};\\\", \\\"{x:1356,y:516,t:1527635507995};\\\", \\\"{x:1356,y:535,t:1527635508012};\\\", \\\"{x:1357,y:562,t:1527635508029};\\\", \\\"{x:1357,y:574,t:1527635508045};\\\", \\\"{x:1358,y:591,t:1527635508062};\\\", \\\"{x:1358,y:607,t:1527635508079};\\\", \\\"{x:1358,y:618,t:1527635508095};\\\", \\\"{x:1358,y:631,t:1527635508112};\\\", \\\"{x:1358,y:639,t:1527635508129};\\\", \\\"{x:1358,y:648,t:1527635508146};\\\", \\\"{x:1359,y:658,t:1527635508161};\\\", \\\"{x:1363,y:667,t:1527635508178};\\\", \\\"{x:1363,y:671,t:1527635508195};\\\", \\\"{x:1364,y:675,t:1527635508213};\\\", \\\"{x:1364,y:676,t:1527635508228};\\\", \\\"{x:1364,y:678,t:1527635508261};\\\", \\\"{x:1364,y:679,t:1527635508269};\\\", \\\"{x:1364,y:681,t:1527635508279};\\\", \\\"{x:1364,y:686,t:1527635508296};\\\", \\\"{x:1364,y:692,t:1527635508312};\\\", \\\"{x:1364,y:696,t:1527635508329};\\\", \\\"{x:1364,y:698,t:1527635508346};\\\", \\\"{x:1364,y:699,t:1527635508365};\\\", \\\"{x:1364,y:700,t:1527635508379};\\\", \\\"{x:1364,y:701,t:1527635508397};\\\", \\\"{x:1363,y:704,t:1527635508412};\\\", \\\"{x:1362,y:706,t:1527635508429};\\\", \\\"{x:1361,y:707,t:1527635508461};\\\", \\\"{x:1360,y:707,t:1527635508493};\\\", \\\"{x:1359,y:709,t:1527635508509};\\\", \\\"{x:1358,y:709,t:1527635508515};\\\", \\\"{x:1357,y:710,t:1527635508540};\\\", \\\"{x:1356,y:710,t:1527635508548};\\\", \\\"{x:1355,y:711,t:1527635508588};\\\", \\\"{x:1354,y:712,t:1527635508620};\\\", \\\"{x:1353,y:712,t:1527635509254};\\\", \\\"{x:1351,y:712,t:1527635511207};\\\", \\\"{x:1345,y:712,t:1527635511222};\\\", \\\"{x:1330,y:712,t:1527635511240};\\\", \\\"{x:1290,y:712,t:1527635511255};\\\", \\\"{x:1254,y:712,t:1527635511272};\\\", \\\"{x:1202,y:710,t:1527635511289};\\\", \\\"{x:1157,y:703,t:1527635511306};\\\", \\\"{x:1087,y:692,t:1527635511322};\\\", \\\"{x:998,y:681,t:1527635511339};\\\", \\\"{x:904,y:667,t:1527635511356};\\\", \\\"{x:813,y:656,t:1527635511373};\\\", \\\"{x:738,y:645,t:1527635511389};\\\", \\\"{x:668,y:636,t:1527635511406};\\\", \\\"{x:600,y:622,t:1527635511423};\\\", \\\"{x:559,y:618,t:1527635511439};\\\", \\\"{x:537,y:609,t:1527635511456};\\\", \\\"{x:531,y:605,t:1527635511473};\\\", \\\"{x:529,y:602,t:1527635511489};\\\", \\\"{x:528,y:594,t:1527635511506};\\\", \\\"{x:528,y:580,t:1527635511523};\\\", \\\"{x:528,y:574,t:1527635511541};\\\", \\\"{x:535,y:563,t:1527635511556};\\\", \\\"{x:537,y:563,t:1527635511573};\\\", \\\"{x:538,y:563,t:1527635511592};\\\", \\\"{x:543,y:560,t:1527635512896};\\\", \\\"{x:562,y:554,t:1527635512909};\\\", \\\"{x:659,y:525,t:1527635512927};\\\", \\\"{x:775,y:470,t:1527635512944};\\\", \\\"{x:949,y:378,t:1527635512960};\\\", \\\"{x:1045,y:328,t:1527635512977};\\\", \\\"{x:1107,y:292,t:1527635512993};\\\", \\\"{x:1140,y:275,t:1527635513010};\\\", \\\"{x:1155,y:267,t:1527635513027};\\\", \\\"{x:1165,y:261,t:1527635513043};\\\", \\\"{x:1175,y:255,t:1527635513061};\\\", \\\"{x:1186,y:249,t:1527635513077};\\\", \\\"{x:1190,y:247,t:1527635513093};\\\", \\\"{x:1191,y:248,t:1527635513224};\\\", \\\"{x:1195,y:266,t:1527635513231};\\\", \\\"{x:1201,y:288,t:1527635513243};\\\", \\\"{x:1215,y:333,t:1527635513261};\\\", \\\"{x:1237,y:381,t:1527635513277};\\\", \\\"{x:1251,y:400,t:1527635513294};\\\", \\\"{x:1265,y:417,t:1527635513310};\\\", \\\"{x:1276,y:433,t:1527635513327};\\\", \\\"{x:1294,y:453,t:1527635513343};\\\", \\\"{x:1305,y:464,t:1527635513360};\\\", \\\"{x:1319,y:477,t:1527635513377};\\\", \\\"{x:1333,y:486,t:1527635513394};\\\", \\\"{x:1347,y:494,t:1527635513410};\\\", \\\"{x:1355,y:498,t:1527635513427};\\\", \\\"{x:1365,y:503,t:1527635513444};\\\", \\\"{x:1377,y:510,t:1527635513460};\\\", \\\"{x:1389,y:518,t:1527635513477};\\\", \\\"{x:1398,y:521,t:1527635513494};\\\", \\\"{x:1403,y:525,t:1527635513510};\\\", \\\"{x:1405,y:527,t:1527635513527};\\\", \\\"{x:1409,y:541,t:1527635513543};\\\", \\\"{x:1410,y:555,t:1527635513560};\\\", \\\"{x:1413,y:565,t:1527635513577};\\\", \\\"{x:1413,y:571,t:1527635513593};\\\", \\\"{x:1413,y:581,t:1527635513610};\\\", \\\"{x:1413,y:596,t:1527635513627};\\\", \\\"{x:1413,y:605,t:1527635513644};\\\", \\\"{x:1413,y:612,t:1527635513660};\\\", \\\"{x:1407,y:623,t:1527635513677};\\\", \\\"{x:1402,y:632,t:1527635513694};\\\", \\\"{x:1395,y:646,t:1527635513711};\\\", \\\"{x:1394,y:649,t:1527635513727};\\\", \\\"{x:1391,y:655,t:1527635513744};\\\", \\\"{x:1389,y:656,t:1527635513761};\\\", \\\"{x:1386,y:660,t:1527635513776};\\\", \\\"{x:1383,y:662,t:1527635513794};\\\", \\\"{x:1380,y:665,t:1527635513811};\\\", \\\"{x:1379,y:666,t:1527635513827};\\\", \\\"{x:1373,y:668,t:1527635513844};\\\", \\\"{x:1368,y:669,t:1527635513861};\\\", \\\"{x:1366,y:672,t:1527635513877};\\\", \\\"{x:1362,y:672,t:1527635513894};\\\", \\\"{x:1360,y:673,t:1527635513911};\\\", \\\"{x:1359,y:673,t:1527635513927};\\\", \\\"{x:1359,y:674,t:1527635513944};\\\", \\\"{x:1358,y:675,t:1527635513961};\\\", \\\"{x:1357,y:677,t:1527635513977};\\\", \\\"{x:1357,y:678,t:1527635513994};\\\", \\\"{x:1356,y:678,t:1527635514010};\\\", \\\"{x:1356,y:680,t:1527635514027};\\\", \\\"{x:1355,y:683,t:1527635514044};\\\", \\\"{x:1355,y:687,t:1527635514061};\\\", \\\"{x:1354,y:691,t:1527635514077};\\\", \\\"{x:1354,y:693,t:1527635514094};\\\", \\\"{x:1354,y:697,t:1527635514111};\\\", \\\"{x:1353,y:699,t:1527635514127};\\\", \\\"{x:1353,y:700,t:1527635514159};\\\", \\\"{x:1353,y:701,t:1527635514166};\\\", \\\"{x:1353,y:702,t:1527635514215};\\\", \\\"{x:1353,y:703,t:1527635514231};\\\", \\\"{x:1353,y:704,t:1527635514247};\\\", \\\"{x:1353,y:705,t:1527635514383};\\\", \\\"{x:1353,y:706,t:1527635514399};\\\", \\\"{x:1352,y:707,t:1527635514415};\\\", \\\"{x:1352,y:708,t:1527635514444};\\\", \\\"{x:1352,y:710,t:1527635514460};\\\", \\\"{x:1353,y:712,t:1527635514478};\\\", \\\"{x:1353,y:713,t:1527635515144};\\\", \\\"{x:1352,y:712,t:1527635515191};\\\", \\\"{x:1351,y:705,t:1527635515212};\\\", \\\"{x:1349,y:695,t:1527635515228};\\\", \\\"{x:1346,y:676,t:1527635515245};\\\", \\\"{x:1342,y:661,t:1527635515262};\\\", \\\"{x:1339,y:646,t:1527635515278};\\\", \\\"{x:1336,y:621,t:1527635515296};\\\", \\\"{x:1334,y:609,t:1527635515312};\\\", \\\"{x:1333,y:601,t:1527635515328};\\\", \\\"{x:1332,y:593,t:1527635515345};\\\", \\\"{x:1331,y:581,t:1527635515362};\\\", \\\"{x:1329,y:572,t:1527635515378};\\\", \\\"{x:1328,y:564,t:1527635515395};\\\", \\\"{x:1328,y:557,t:1527635515412};\\\", \\\"{x:1328,y:551,t:1527635515428};\\\", \\\"{x:1328,y:544,t:1527635515445};\\\", \\\"{x:1330,y:538,t:1527635515462};\\\", \\\"{x:1330,y:528,t:1527635515478};\\\", \\\"{x:1333,y:516,t:1527635515495};\\\", \\\"{x:1334,y:509,t:1527635515512};\\\", \\\"{x:1335,y:504,t:1527635515529};\\\", \\\"{x:1335,y:500,t:1527635515545};\\\", \\\"{x:1335,y:497,t:1527635515562};\\\", \\\"{x:1335,y:495,t:1527635515579};\\\", \\\"{x:1337,y:489,t:1527635515595};\\\", \\\"{x:1337,y:484,t:1527635515612};\\\", \\\"{x:1337,y:477,t:1527635515629};\\\", \\\"{x:1338,y:472,t:1527635515645};\\\", \\\"{x:1339,y:465,t:1527635515662};\\\", \\\"{x:1341,y:459,t:1527635515680};\\\", \\\"{x:1341,y:455,t:1527635515696};\\\", \\\"{x:1342,y:453,t:1527635515712};\\\", \\\"{x:1342,y:451,t:1527635515729};\\\", \\\"{x:1342,y:449,t:1527635515745};\\\", \\\"{x:1343,y:447,t:1527635515761};\\\", \\\"{x:1343,y:445,t:1527635515783};\\\", \\\"{x:1343,y:444,t:1527635515815};\\\", \\\"{x:1343,y:449,t:1527635519039};\\\", \\\"{x:1343,y:462,t:1527635519048};\\\", \\\"{x:1343,y:491,t:1527635519065};\\\", \\\"{x:1343,y:512,t:1527635519082};\\\", \\\"{x:1347,y:539,t:1527635519098};\\\", \\\"{x:1351,y:562,t:1527635519114};\\\", \\\"{x:1353,y:581,t:1527635519131};\\\", \\\"{x:1356,y:596,t:1527635519148};\\\", \\\"{x:1358,y:607,t:1527635519164};\\\", \\\"{x:1359,y:620,t:1527635519181};\\\", \\\"{x:1363,y:629,t:1527635519198};\\\", \\\"{x:1366,y:639,t:1527635519214};\\\", \\\"{x:1368,y:654,t:1527635519231};\\\", \\\"{x:1368,y:658,t:1527635519248};\\\", \\\"{x:1368,y:660,t:1527635519264};\\\", \\\"{x:1368,y:662,t:1527635519281};\\\", \\\"{x:1369,y:664,t:1527635519298};\\\", \\\"{x:1369,y:665,t:1527635519314};\\\", \\\"{x:1369,y:667,t:1527635519331};\\\", \\\"{x:1368,y:667,t:1527635519368};\\\", \\\"{x:1368,y:668,t:1527635519391};\\\", \\\"{x:1368,y:669,t:1527635519439};\\\", \\\"{x:1368,y:670,t:1527635519519};\\\", \\\"{x:1368,y:671,t:1527635519696};\\\", \\\"{x:1368,y:672,t:1527635519703};\\\", \\\"{x:1368,y:673,t:1527635519727};\\\", \\\"{x:1368,y:674,t:1527635519743};\\\", \\\"{x:1367,y:674,t:1527635519751};\\\", \\\"{x:1367,y:675,t:1527635519765};\\\", \\\"{x:1366,y:676,t:1527635519781};\\\", \\\"{x:1364,y:677,t:1527635519798};\\\", \\\"{x:1362,y:680,t:1527635519815};\\\", \\\"{x:1360,y:681,t:1527635519832};\\\", \\\"{x:1359,y:682,t:1527635519848};\\\", \\\"{x:1359,y:683,t:1527635519865};\\\", \\\"{x:1358,y:683,t:1527635519882};\\\", \\\"{x:1357,y:684,t:1527635519898};\\\", \\\"{x:1356,y:686,t:1527635519915};\\\", \\\"{x:1354,y:686,t:1527635519932};\\\", \\\"{x:1351,y:687,t:1527635519948};\\\", \\\"{x:1346,y:689,t:1527635519965};\\\", \\\"{x:1340,y:689,t:1527635519983};\\\", \\\"{x:1333,y:693,t:1527635519998};\\\", \\\"{x:1328,y:695,t:1527635520015};\\\", \\\"{x:1324,y:697,t:1527635520033};\\\", \\\"{x:1322,y:699,t:1527635520048};\\\", \\\"{x:1320,y:703,t:1527635520065};\\\", \\\"{x:1319,y:707,t:1527635520082};\\\", \\\"{x:1319,y:712,t:1527635520099};\\\", \\\"{x:1319,y:716,t:1527635520115};\\\", \\\"{x:1319,y:721,t:1527635520132};\\\", \\\"{x:1319,y:725,t:1527635520148};\\\", \\\"{x:1319,y:727,t:1527635520165};\\\", \\\"{x:1320,y:732,t:1527635520182};\\\", \\\"{x:1322,y:736,t:1527635520199};\\\", \\\"{x:1325,y:741,t:1527635520215};\\\", \\\"{x:1329,y:745,t:1527635520232};\\\", \\\"{x:1336,y:750,t:1527635520248};\\\", \\\"{x:1343,y:752,t:1527635520265};\\\", \\\"{x:1352,y:754,t:1527635520282};\\\", \\\"{x:1355,y:754,t:1527635520299};\\\", \\\"{x:1356,y:755,t:1527635520315};\\\", \\\"{x:1357,y:755,t:1527635520332};\\\", \\\"{x:1360,y:754,t:1527635520349};\\\", \\\"{x:1363,y:752,t:1527635520365};\\\", \\\"{x:1367,y:750,t:1527635520382};\\\", \\\"{x:1369,y:748,t:1527635520399};\\\", \\\"{x:1370,y:746,t:1527635520415};\\\", \\\"{x:1370,y:742,t:1527635520432};\\\", \\\"{x:1370,y:736,t:1527635520449};\\\", \\\"{x:1370,y:733,t:1527635520466};\\\", \\\"{x:1370,y:728,t:1527635520483};\\\", \\\"{x:1370,y:726,t:1527635520499};\\\", \\\"{x:1370,y:723,t:1527635520516};\\\", \\\"{x:1370,y:721,t:1527635520532};\\\", \\\"{x:1369,y:719,t:1527635520549};\\\", \\\"{x:1366,y:713,t:1527635520565};\\\", \\\"{x:1366,y:711,t:1527635520582};\\\", \\\"{x:1364,y:708,t:1527635520599};\\\", \\\"{x:1364,y:707,t:1527635520615};\\\", \\\"{x:1363,y:704,t:1527635520632};\\\", \\\"{x:1362,y:702,t:1527635520655};\\\", \\\"{x:1361,y:700,t:1527635520671};\\\", \\\"{x:1360,y:698,t:1527635520682};\\\", \\\"{x:1359,y:697,t:1527635520699};\\\", \\\"{x:1359,y:696,t:1527635520715};\\\", \\\"{x:1359,y:695,t:1527635520732};\\\", \\\"{x:1358,y:694,t:1527635520749};\\\", \\\"{x:1356,y:692,t:1527635520766};\\\", \\\"{x:1355,y:689,t:1527635520782};\\\", \\\"{x:1353,y:687,t:1527635520799};\\\", \\\"{x:1352,y:685,t:1527635520816};\\\", \\\"{x:1351,y:684,t:1527635520833};\\\", \\\"{x:1349,y:680,t:1527635520849};\\\", \\\"{x:1348,y:678,t:1527635520866};\\\", \\\"{x:1345,y:676,t:1527635520882};\\\", \\\"{x:1344,y:674,t:1527635520903};\\\", \\\"{x:1343,y:674,t:1527635520919};\\\", \\\"{x:1342,y:673,t:1527635520943};\\\", \\\"{x:1340,y:672,t:1527635520959};\\\", \\\"{x:1339,y:672,t:1527635520967};\\\", \\\"{x:1337,y:672,t:1527635521047};\\\", \\\"{x:1335,y:672,t:1527635521055};\\\", \\\"{x:1335,y:676,t:1527635521066};\\\", \\\"{x:1334,y:686,t:1527635521082};\\\", \\\"{x:1333,y:694,t:1527635521100};\\\", \\\"{x:1333,y:702,t:1527635521116};\\\", \\\"{x:1334,y:709,t:1527635521132};\\\", \\\"{x:1336,y:715,t:1527635521149};\\\", \\\"{x:1337,y:718,t:1527635521166};\\\", \\\"{x:1337,y:721,t:1527635521183};\\\", \\\"{x:1338,y:724,t:1527635521200};\\\", \\\"{x:1339,y:727,t:1527635521216};\\\", \\\"{x:1340,y:731,t:1527635521233};\\\", \\\"{x:1340,y:732,t:1527635521250};\\\", \\\"{x:1341,y:734,t:1527635521267};\\\", \\\"{x:1342,y:735,t:1527635521400};\\\", \\\"{x:1346,y:735,t:1527635521417};\\\", \\\"{x:1350,y:735,t:1527635521434};\\\", \\\"{x:1354,y:734,t:1527635521449};\\\", \\\"{x:1355,y:734,t:1527635521466};\\\", \\\"{x:1355,y:733,t:1527635521483};\\\", \\\"{x:1357,y:733,t:1527635521499};\\\", \\\"{x:1357,y:732,t:1527635521516};\\\", \\\"{x:1357,y:728,t:1527635521534};\\\", \\\"{x:1358,y:724,t:1527635521549};\\\", \\\"{x:1359,y:719,t:1527635521566};\\\", \\\"{x:1360,y:707,t:1527635521583};\\\", \\\"{x:1361,y:699,t:1527635521599};\\\", \\\"{x:1362,y:695,t:1527635521617};\\\", \\\"{x:1363,y:691,t:1527635521634};\\\", \\\"{x:1363,y:688,t:1527635521649};\\\", \\\"{x:1363,y:687,t:1527635521667};\\\", \\\"{x:1364,y:686,t:1527635521687};\\\", \\\"{x:1364,y:685,t:1527635521807};\\\", \\\"{x:1363,y:683,t:1527635521823};\\\", \\\"{x:1358,y:681,t:1527635521833};\\\", \\\"{x:1346,y:676,t:1527635521850};\\\", \\\"{x:1335,y:671,t:1527635521866};\\\", \\\"{x:1330,y:670,t:1527635521883};\\\", \\\"{x:1329,y:669,t:1527635521900};\\\", \\\"{x:1331,y:669,t:1527635522055};\\\", \\\"{x:1333,y:670,t:1527635522071};\\\", \\\"{x:1335,y:670,t:1527635522083};\\\", \\\"{x:1336,y:672,t:1527635522100};\\\", \\\"{x:1338,y:672,t:1527635522117};\\\", \\\"{x:1339,y:673,t:1527635522151};\\\", \\\"{x:1340,y:673,t:1527635522166};\\\", \\\"{x:1341,y:676,t:1527635522183};\\\", \\\"{x:1342,y:682,t:1527635522201};\\\", \\\"{x:1343,y:691,t:1527635522217};\\\", \\\"{x:1343,y:698,t:1527635522233};\\\", \\\"{x:1345,y:705,t:1527635522250};\\\", \\\"{x:1347,y:710,t:1527635522267};\\\", \\\"{x:1347,y:713,t:1527635522283};\\\", \\\"{x:1349,y:713,t:1527635522300};\\\", \\\"{x:1349,y:715,t:1527635522317};\\\", \\\"{x:1350,y:716,t:1527635522335};\\\", \\\"{x:1350,y:713,t:1527635522623};\\\", \\\"{x:1349,y:710,t:1527635522650};\\\", \\\"{x:1348,y:709,t:1527635522667};\\\", \\\"{x:1348,y:708,t:1527635522684};\\\", \\\"{x:1347,y:706,t:1527635522743};\\\", \\\"{x:1340,y:706,t:1527635523360};\\\", \\\"{x:1320,y:702,t:1527635523368};\\\", \\\"{x:1264,y:698,t:1527635523385};\\\", \\\"{x:1180,y:685,t:1527635523401};\\\", \\\"{x:1083,y:674,t:1527635523417};\\\", \\\"{x:951,y:661,t:1527635523434};\\\", \\\"{x:823,y:640,t:1527635523451};\\\", \\\"{x:731,y:623,t:1527635523467};\\\", \\\"{x:665,y:607,t:1527635523484};\\\", \\\"{x:638,y:600,t:1527635523502};\\\", \\\"{x:610,y:594,t:1527635523517};\\\", \\\"{x:589,y:589,t:1527635523534};\\\", \\\"{x:561,y:581,t:1527635523551};\\\", \\\"{x:537,y:573,t:1527635523568};\\\", \\\"{x:517,y:566,t:1527635523584};\\\", \\\"{x:503,y:559,t:1527635523602};\\\", \\\"{x:484,y:554,t:1527635523618};\\\", \\\"{x:467,y:545,t:1527635523636};\\\", \\\"{x:443,y:537,t:1527635523651};\\\", \\\"{x:410,y:527,t:1527635523669};\\\", \\\"{x:369,y:512,t:1527635523685};\\\", \\\"{x:331,y:499,t:1527635523701};\\\", \\\"{x:300,y:490,t:1527635523718};\\\", \\\"{x:282,y:482,t:1527635523735};\\\", \\\"{x:272,y:481,t:1527635523752};\\\", \\\"{x:266,y:479,t:1527635523768};\\\", \\\"{x:260,y:477,t:1527635523785};\\\", \\\"{x:246,y:474,t:1527635523801};\\\", \\\"{x:236,y:472,t:1527635523818};\\\", \\\"{x:231,y:472,t:1527635523835};\\\", \\\"{x:225,y:471,t:1527635523852};\\\", \\\"{x:220,y:471,t:1527635523868};\\\", \\\"{x:215,y:471,t:1527635523886};\\\", \\\"{x:211,y:471,t:1527635523902};\\\", \\\"{x:208,y:471,t:1527635523918};\\\", \\\"{x:202,y:473,t:1527635523935};\\\", \\\"{x:198,y:475,t:1527635523953};\\\", \\\"{x:193,y:477,t:1527635523968};\\\", \\\"{x:187,y:480,t:1527635523986};\\\", \\\"{x:185,y:482,t:1527635524003};\\\", \\\"{x:182,y:484,t:1527635524019};\\\", \\\"{x:180,y:485,t:1527635524036};\\\", \\\"{x:178,y:485,t:1527635524052};\\\", \\\"{x:177,y:486,t:1527635524071};\\\", \\\"{x:173,y:487,t:1527635524095};\\\", \\\"{x:172,y:488,t:1527635524119};\\\", \\\"{x:170,y:489,t:1527635524135};\\\", \\\"{x:168,y:489,t:1527635524152};\\\", \\\"{x:166,y:491,t:1527635524168};\\\", \\\"{x:164,y:492,t:1527635524199};\\\", \\\"{x:163,y:492,t:1527635524215};\\\", \\\"{x:162,y:492,t:1527635524247};\\\", \\\"{x:160,y:493,t:1527635524255};\\\", \\\"{x:160,y:494,t:1527635524270};\\\", \\\"{x:160,y:494,t:1527635524464};\\\", \\\"{x:161,y:494,t:1527635526352};\\\", \\\"{x:162,y:494,t:1527635526407};\\\", \\\"{x:163,y:493,t:1527635526421};\\\", \\\"{x:164,y:492,t:1527635526438};\\\", \\\"{x:166,y:491,t:1527635526543};\\\", \\\"{x:167,y:490,t:1527635526567};\\\", \\\"{x:168,y:489,t:1527635526599};\\\", \\\"{x:169,y:489,t:1527635526607};\\\", \\\"{x:169,y:488,t:1527635526620};\\\", \\\"{x:170,y:488,t:1527635526638};\\\", \\\"{x:172,y:486,t:1527635526654};\\\", \\\"{x:174,y:485,t:1527635526671};\\\", \\\"{x:178,y:482,t:1527635526687};\\\", \\\"{x:182,y:478,t:1527635526704};\\\", \\\"{x:188,y:474,t:1527635526720};\\\", \\\"{x:195,y:469,t:1527635526738};\\\", \\\"{x:206,y:462,t:1527635526755};\\\", \\\"{x:218,y:450,t:1527635526771};\\\", \\\"{x:228,y:439,t:1527635526788};\\\", \\\"{x:232,y:434,t:1527635526805};\\\", \\\"{x:237,y:428,t:1527635526821};\\\", \\\"{x:241,y:424,t:1527635526837};\\\", \\\"{x:244,y:421,t:1527635526855};\\\", \\\"{x:248,y:419,t:1527635526871};\\\", \\\"{x:250,y:417,t:1527635526888};\\\", \\\"{x:251,y:416,t:1527635526904};\\\", \\\"{x:253,y:415,t:1527635526921};\\\", \\\"{x:255,y:413,t:1527635526938};\\\", \\\"{x:257,y:412,t:1527635526954};\\\", \\\"{x:258,y:411,t:1527635526972};\\\", \\\"{x:260,y:410,t:1527635526987};\\\", \\\"{x:261,y:410,t:1527635527007};\\\", \\\"{x:261,y:409,t:1527635527021};\\\", \\\"{x:262,y:409,t:1527635527037};\\\", \\\"{x:263,y:409,t:1527635527055};\\\", \\\"{x:264,y:409,t:1527635527071};\\\", \\\"{x:267,y:408,t:1527635527088};\\\", \\\"{x:268,y:407,t:1527635527199};\\\", \\\"{x:270,y:406,t:1527635527391};\\\", \\\"{x:271,y:406,t:1527635527406};\\\", \\\"{x:273,y:405,t:1527635527422};\\\", \\\"{x:274,y:405,t:1527635527438};\\\", \\\"{x:278,y:404,t:1527635527454};\\\", \\\"{x:289,y:404,t:1527635527471};\\\", \\\"{x:303,y:404,t:1527635527488};\\\", \\\"{x:318,y:404,t:1527635527504};\\\", \\\"{x:338,y:404,t:1527635527521};\\\", \\\"{x:356,y:404,t:1527635527538};\\\", \\\"{x:375,y:404,t:1527635527555};\\\", \\\"{x:385,y:407,t:1527635527571};\\\", \\\"{x:395,y:408,t:1527635527589};\\\", \\\"{x:402,y:409,t:1527635527606};\\\", \\\"{x:403,y:409,t:1527635527621};\\\", \\\"{x:404,y:410,t:1527635527638};\\\", \\\"{x:405,y:410,t:1527635527656};\\\", \\\"{x:406,y:411,t:1527635527703};\\\", \\\"{x:408,y:411,t:1527635528183};\\\", \\\"{x:412,y:411,t:1527635528191};\\\", \\\"{x:418,y:410,t:1527635528205};\\\", \\\"{x:429,y:410,t:1527635528222};\\\", \\\"{x:448,y:410,t:1527635528238};\\\", \\\"{x:465,y:410,t:1527635528256};\\\", \\\"{x:470,y:409,t:1527635528273};\\\", \\\"{x:476,y:409,t:1527635528288};\\\", \\\"{x:480,y:407,t:1527635528306};\\\", \\\"{x:483,y:406,t:1527635528323};\\\", \\\"{x:487,y:405,t:1527635528340};\\\", \\\"{x:494,y:404,t:1527635528355};\\\", \\\"{x:498,y:402,t:1527635528373};\\\", \\\"{x:502,y:401,t:1527635528390};\\\", \\\"{x:506,y:399,t:1527635528405};\\\", \\\"{x:511,y:398,t:1527635528422};\\\", \\\"{x:516,y:396,t:1527635528438};\\\", \\\"{x:518,y:396,t:1527635528455};\\\", \\\"{x:520,y:395,t:1527635528472};\\\", \\\"{x:525,y:394,t:1527635528489};\\\", \\\"{x:527,y:394,t:1527635528506};\\\", \\\"{x:532,y:392,t:1527635528522};\\\", \\\"{x:537,y:392,t:1527635528540};\\\", \\\"{x:541,y:391,t:1527635528556};\\\", \\\"{x:547,y:391,t:1527635528572};\\\", \\\"{x:554,y:390,t:1527635528589};\\\", \\\"{x:559,y:388,t:1527635528605};\\\", \\\"{x:564,y:388,t:1527635528622};\\\", \\\"{x:573,y:388,t:1527635528639};\\\", \\\"{x:580,y:388,t:1527635528656};\\\", \\\"{x:589,y:388,t:1527635528672};\\\", \\\"{x:597,y:388,t:1527635528689};\\\", \\\"{x:610,y:389,t:1527635528707};\\\", \\\"{x:625,y:392,t:1527635528723};\\\", \\\"{x:636,y:395,t:1527635528739};\\\", \\\"{x:645,y:398,t:1527635528756};\\\", \\\"{x:652,y:399,t:1527635528772};\\\", \\\"{x:658,y:402,t:1527635528789};\\\", \\\"{x:663,y:403,t:1527635528806};\\\", \\\"{x:669,y:406,t:1527635528822};\\\", \\\"{x:676,y:409,t:1527635528840};\\\", \\\"{x:678,y:410,t:1527635528857};\\\", \\\"{x:680,y:411,t:1527635528873};\\\", \\\"{x:681,y:412,t:1527635528889};\\\", \\\"{x:683,y:413,t:1527635528906};\\\", \\\"{x:684,y:414,t:1527635528927};\\\", \\\"{x:685,y:414,t:1527635528939};\\\", \\\"{x:686,y:415,t:1527635528957};\\\", \\\"{x:687,y:416,t:1527635528974};\\\", \\\"{x:688,y:416,t:1527635528999};\\\", \\\"{x:689,y:416,t:1527635529015};\\\", \\\"{x:690,y:416,t:1527635529142};\\\", \\\"{x:691,y:416,t:1527635529166};\\\", \\\"{x:692,y:416,t:1527635529175};\\\", \\\"{x:693,y:416,t:1527635529189};\\\", \\\"{x:698,y:416,t:1527635529207};\\\", \\\"{x:707,y:416,t:1527635529222};\\\", \\\"{x:723,y:413,t:1527635529240};\\\", \\\"{x:737,y:411,t:1527635529256};\\\", \\\"{x:754,y:408,t:1527635529274};\\\", \\\"{x:777,y:407,t:1527635529290};\\\", \\\"{x:797,y:404,t:1527635529306};\\\", \\\"{x:820,y:402,t:1527635529324};\\\", \\\"{x:839,y:393,t:1527635529339};\\\", \\\"{x:862,y:386,t:1527635529356};\\\", \\\"{x:881,y:381,t:1527635529373};\\\", \\\"{x:897,y:375,t:1527635529390};\\\", \\\"{x:915,y:371,t:1527635529406};\\\", \\\"{x:946,y:364,t:1527635529424};\\\", \\\"{x:989,y:359,t:1527635529440};\\\", \\\"{x:1043,y:351,t:1527635529457};\\\", \\\"{x:1087,y:351,t:1527635529474};\\\", \\\"{x:1168,y:351,t:1527635529490};\\\", \\\"{x:1262,y:351,t:1527635529506};\\\", \\\"{x:1384,y:352,t:1527635529524};\\\", \\\"{x:1507,y:371,t:1527635529540};\\\", \\\"{x:1612,y:386,t:1527635529556};\\\", \\\"{x:1688,y:412,t:1527635529573};\\\", \\\"{x:1723,y:425,t:1527635529591};\\\", \\\"{x:1738,y:432,t:1527635529607};\\\", \\\"{x:1746,y:439,t:1527635529624};\\\", \\\"{x:1749,y:447,t:1527635529640};\\\", \\\"{x:1755,y:461,t:1527635529657};\\\", \\\"{x:1758,y:470,t:1527635529673};\\\", \\\"{x:1760,y:475,t:1527635529691};\\\", \\\"{x:1760,y:482,t:1527635529707};\\\", \\\"{x:1759,y:482,t:1527635529723};\\\", \\\"{x:1745,y:483,t:1527635529740};\\\", \\\"{x:1742,y:483,t:1527635530255};\\\", \\\"{x:1741,y:483,t:1527635530263};\\\", \\\"{x:1738,y:483,t:1527635530275};\\\", \\\"{x:1728,y:485,t:1527635530291};\\\", \\\"{x:1710,y:489,t:1527635530308};\\\", \\\"{x:1686,y:495,t:1527635530325};\\\", \\\"{x:1656,y:504,t:1527635530340};\\\", \\\"{x:1607,y:515,t:1527635530357};\\\", \\\"{x:1551,y:525,t:1527635530374};\\\", \\\"{x:1489,y:533,t:1527635530391};\\\", \\\"{x:1426,y:543,t:1527635530408};\\\", \\\"{x:1387,y:547,t:1527635530425};\\\", \\\"{x:1351,y:552,t:1527635530440};\\\", \\\"{x:1320,y:557,t:1527635530457};\\\", \\\"{x:1297,y:563,t:1527635530474};\\\", \\\"{x:1280,y:568,t:1527635530491};\\\", \\\"{x:1265,y:574,t:1527635530508};\\\", \\\"{x:1255,y:579,t:1527635530524};\\\", \\\"{x:1250,y:580,t:1527635530540};\\\", \\\"{x:1247,y:581,t:1527635530557};\\\", \\\"{x:1245,y:582,t:1527635530575};\\\", \\\"{x:1242,y:583,t:1527635530591};\\\", \\\"{x:1241,y:585,t:1527635530607};\\\", \\\"{x:1240,y:585,t:1527635530631};\\\", \\\"{x:1239,y:585,t:1527635530646};\\\", \\\"{x:1236,y:585,t:1527635530658};\\\", \\\"{x:1231,y:584,t:1527635530674};\\\", \\\"{x:1230,y:580,t:1527635530691};\\\", \\\"{x:1230,y:578,t:1527635530710};\\\", \\\"{x:1230,y:577,t:1527635530991};\\\", \\\"{x:1232,y:570,t:1527635531009};\\\", \\\"{x:1237,y:560,t:1527635531025};\\\", \\\"{x:1245,y:552,t:1527635531042};\\\", \\\"{x:1253,y:539,t:1527635531058};\\\", \\\"{x:1265,y:523,t:1527635531075};\\\", \\\"{x:1279,y:506,t:1527635531092};\\\", \\\"{x:1295,y:488,t:1527635531108};\\\", \\\"{x:1306,y:471,t:1527635531124};\\\", \\\"{x:1319,y:454,t:1527635531141};\\\", \\\"{x:1328,y:443,t:1527635531158};\\\", \\\"{x:1339,y:433,t:1527635531175};\\\", \\\"{x:1360,y:414,t:1527635531192};\\\", \\\"{x:1378,y:401,t:1527635531208};\\\", \\\"{x:1394,y:392,t:1527635531225};\\\", \\\"{x:1407,y:384,t:1527635531241};\\\", \\\"{x:1418,y:380,t:1527635531258};\\\", \\\"{x:1429,y:375,t:1527635531274};\\\", \\\"{x:1435,y:372,t:1527635531291};\\\", \\\"{x:1442,y:369,t:1527635531309};\\\", \\\"{x:1447,y:367,t:1527635531325};\\\", \\\"{x:1450,y:366,t:1527635531341};\\\", \\\"{x:1453,y:366,t:1527635531358};\\\", \\\"{x:1454,y:365,t:1527635531375};\\\", \\\"{x:1455,y:365,t:1527635531391};\\\", \\\"{x:1456,y:365,t:1527635531408};\\\", \\\"{x:1457,y:365,t:1527635531425};\\\", \\\"{x:1458,y:365,t:1527635531463};\\\", \\\"{x:1459,y:365,t:1527635531511};\\\", \\\"{x:1461,y:365,t:1527635531542};\\\", \\\"{x:1461,y:366,t:1527635531566};\\\", \\\"{x:1462,y:367,t:1527635531599};\\\", \\\"{x:1463,y:368,t:1527635531615};\\\", \\\"{x:1464,y:370,t:1527635531625};\\\", \\\"{x:1467,y:375,t:1527635531642};\\\", \\\"{x:1469,y:381,t:1527635531658};\\\", \\\"{x:1474,y:386,t:1527635531675};\\\", \\\"{x:1480,y:395,t:1527635531691};\\\", \\\"{x:1484,y:401,t:1527635531709};\\\", \\\"{x:1489,y:408,t:1527635531725};\\\", \\\"{x:1499,y:421,t:1527635531742};\\\", \\\"{x:1503,y:428,t:1527635531758};\\\", \\\"{x:1511,y:440,t:1527635531775};\\\", \\\"{x:1520,y:454,t:1527635531793};\\\", \\\"{x:1531,y:470,t:1527635531809};\\\", \\\"{x:1544,y:487,t:1527635531826};\\\", \\\"{x:1558,y:506,t:1527635531843};\\\", \\\"{x:1564,y:517,t:1527635531858};\\\", \\\"{x:1575,y:530,t:1527635531876};\\\", \\\"{x:1583,y:544,t:1527635531892};\\\", \\\"{x:1590,y:560,t:1527635531908};\\\", \\\"{x:1593,y:577,t:1527635531925};\\\", \\\"{x:1597,y:588,t:1527635531943};\\\", \\\"{x:1597,y:592,t:1527635531958};\\\", \\\"{x:1596,y:593,t:1527635531976};\\\", \\\"{x:1592,y:593,t:1527635531992};\\\", \\\"{x:1591,y:593,t:1527635532009};\\\", \\\"{x:1589,y:595,t:1527635532319};\\\", \\\"{x:1588,y:596,t:1527635532327};\\\", \\\"{x:1584,y:598,t:1527635532343};\\\", \\\"{x:1579,y:602,t:1527635532360};\\\", \\\"{x:1574,y:612,t:1527635532375};\\\", \\\"{x:1570,y:623,t:1527635532392};\\\", \\\"{x:1563,y:636,t:1527635532409};\\\", \\\"{x:1556,y:647,t:1527635532425};\\\", \\\"{x:1549,y:658,t:1527635532443};\\\", \\\"{x:1541,y:669,t:1527635532460};\\\", \\\"{x:1533,y:682,t:1527635532476};\\\", \\\"{x:1527,y:694,t:1527635532493};\\\", \\\"{x:1523,y:703,t:1527635532510};\\\", \\\"{x:1519,y:715,t:1527635532527};\\\", \\\"{x:1514,y:725,t:1527635532543};\\\", \\\"{x:1512,y:732,t:1527635532560};\\\", \\\"{x:1511,y:738,t:1527635532577};\\\", \\\"{x:1510,y:741,t:1527635532593};\\\", \\\"{x:1509,y:744,t:1527635532609};\\\", \\\"{x:1509,y:745,t:1527635532627};\\\", \\\"{x:1509,y:747,t:1527635532642};\\\", \\\"{x:1509,y:749,t:1527635532660};\\\", \\\"{x:1509,y:751,t:1527635532677};\\\", \\\"{x:1509,y:753,t:1527635532692};\\\", \\\"{x:1509,y:754,t:1527635532710};\\\", \\\"{x:1508,y:758,t:1527635532726};\\\", \\\"{x:1506,y:761,t:1527635532743};\\\", \\\"{x:1502,y:764,t:1527635532760};\\\", \\\"{x:1498,y:766,t:1527635532777};\\\", \\\"{x:1494,y:767,t:1527635532792};\\\", \\\"{x:1491,y:768,t:1527635532810};\\\", \\\"{x:1488,y:769,t:1527635532826};\\\", \\\"{x:1486,y:770,t:1527635532843};\\\", \\\"{x:1483,y:771,t:1527635532859};\\\", \\\"{x:1480,y:772,t:1527635532877};\\\", \\\"{x:1475,y:774,t:1527635532894};\\\", \\\"{x:1470,y:775,t:1527635532909};\\\", \\\"{x:1464,y:777,t:1527635532927};\\\", \\\"{x:1459,y:778,t:1527635532944};\\\", \\\"{x:1457,y:779,t:1527635532960};\\\", \\\"{x:1454,y:779,t:1527635532977};\\\", \\\"{x:1451,y:781,t:1527635532994};\\\", \\\"{x:1450,y:781,t:1527635533015};\\\", \\\"{x:1448,y:781,t:1527635533027};\\\", \\\"{x:1447,y:783,t:1527635533044};\\\", \\\"{x:1445,y:784,t:1527635533060};\\\", \\\"{x:1443,y:784,t:1527635533076};\\\", \\\"{x:1442,y:784,t:1527635533103};\\\", \\\"{x:1441,y:785,t:1527635533167};\\\", \\\"{x:1441,y:786,t:1527635533927};\\\", \\\"{x:1441,y:787,t:1527635533967};\\\", \\\"{x:1441,y:791,t:1527635533978};\\\", \\\"{x:1444,y:793,t:1527635533994};\\\", \\\"{x:1447,y:794,t:1527635534010};\\\", \\\"{x:1448,y:795,t:1527635534027};\\\", \\\"{x:1450,y:795,t:1527635534044};\\\", \\\"{x:1451,y:795,t:1527635534103};\\\", \\\"{x:1452,y:795,t:1527635537991};\\\", \\\"{x:1455,y:793,t:1527635537998};\\\", \\\"{x:1460,y:790,t:1527635538015};\\\", \\\"{x:1466,y:787,t:1527635538031};\\\", \\\"{x:1482,y:785,t:1527635538048};\\\", \\\"{x:1489,y:783,t:1527635538065};\\\", \\\"{x:1491,y:783,t:1527635538081};\\\", \\\"{x:1493,y:781,t:1527635538097};\\\", \\\"{x:1494,y:781,t:1527635538127};\\\", \\\"{x:1495,y:781,t:1527635538142};\\\", \\\"{x:1496,y:781,t:1527635538151};\\\", \\\"{x:1497,y:781,t:1527635538165};\\\", \\\"{x:1498,y:781,t:1527635538182};\\\", \\\"{x:1497,y:781,t:1527635538414};\\\", \\\"{x:1496,y:780,t:1527635539326};\\\", \\\"{x:1495,y:779,t:1527635539351};\\\", \\\"{x:1494,y:779,t:1527635539431};\\\", \\\"{x:1494,y:778,t:1527635539439};\\\", \\\"{x:1492,y:778,t:1527635539455};\\\", \\\"{x:1490,y:776,t:1527635539470};\\\", \\\"{x:1489,y:775,t:1527635539494};\\\", \\\"{x:1488,y:775,t:1527635539510};\\\", \\\"{x:1488,y:774,t:1527635539526};\\\", \\\"{x:1486,y:773,t:1527635539542};\\\", \\\"{x:1485,y:772,t:1527635539575};\\\", \\\"{x:1484,y:771,t:1527635539582};\\\", \\\"{x:1482,y:770,t:1527635539622};\\\", \\\"{x:1481,y:770,t:1527635539639};\\\", \\\"{x:1481,y:769,t:1527635539662};\\\", \\\"{x:1479,y:768,t:1527635539678};\\\", \\\"{x:1478,y:768,t:1527635539710};\\\", \\\"{x:1477,y:768,t:1527635539814};\\\", \\\"{x:1477,y:767,t:1527635539822};\\\", \\\"{x:1476,y:767,t:1527635540310};\\\", \\\"{x:1475,y:767,t:1527635540326};\\\", \\\"{x:1474,y:767,t:1527635540351};\\\", \\\"{x:1472,y:767,t:1527635540366};\\\", \\\"{x:1471,y:768,t:1527635541166};\\\", \\\"{x:1474,y:778,t:1527635541184};\\\", \\\"{x:1479,y:784,t:1527635541200};\\\", \\\"{x:1484,y:790,t:1527635541218};\\\", \\\"{x:1488,y:793,t:1527635541234};\\\", \\\"{x:1490,y:795,t:1527635541251};\\\", \\\"{x:1491,y:795,t:1527635541268};\\\", \\\"{x:1490,y:795,t:1527635541527};\\\", \\\"{x:1487,y:795,t:1527635541534};\\\", \\\"{x:1483,y:795,t:1527635541551};\\\", \\\"{x:1481,y:795,t:1527635541568};\\\", \\\"{x:1481,y:793,t:1527635541863};\\\", \\\"{x:1481,y:792,t:1527635541871};\\\", \\\"{x:1481,y:789,t:1527635541885};\\\", \\\"{x:1481,y:786,t:1527635541901};\\\", \\\"{x:1482,y:784,t:1527635541918};\\\", \\\"{x:1484,y:779,t:1527635541934};\\\", \\\"{x:1486,y:775,t:1527635541952};\\\", \\\"{x:1486,y:773,t:1527635541969};\\\", \\\"{x:1486,y:771,t:1527635541985};\\\", \\\"{x:1487,y:770,t:1527635542002};\\\", \\\"{x:1487,y:769,t:1527635542018};\\\", \\\"{x:1487,y:768,t:1527635542035};\\\", \\\"{x:1490,y:766,t:1527635542782};\\\", \\\"{x:1492,y:766,t:1527635542791};\\\", \\\"{x:1493,y:765,t:1527635542802};\\\", \\\"{x:1496,y:765,t:1527635542819};\\\", \\\"{x:1501,y:765,t:1527635542836};\\\", \\\"{x:1510,y:765,t:1527635542852};\\\", \\\"{x:1516,y:765,t:1527635542868};\\\", \\\"{x:1527,y:765,t:1527635542886};\\\", \\\"{x:1537,y:765,t:1527635542902};\\\", \\\"{x:1549,y:765,t:1527635542919};\\\", \\\"{x:1556,y:765,t:1527635542936};\\\", \\\"{x:1558,y:765,t:1527635542952};\\\", \\\"{x:1560,y:765,t:1527635542969};\\\", \\\"{x:1565,y:765,t:1527635542986};\\\", \\\"{x:1569,y:765,t:1527635543002};\\\", \\\"{x:1576,y:765,t:1527635543019};\\\", \\\"{x:1583,y:765,t:1527635543036};\\\", \\\"{x:1589,y:765,t:1527635543052};\\\", \\\"{x:1593,y:765,t:1527635543069};\\\", \\\"{x:1595,y:767,t:1527635543086};\\\", \\\"{x:1598,y:768,t:1527635543102};\\\", \\\"{x:1600,y:770,t:1527635543119};\\\", \\\"{x:1601,y:771,t:1527635543136};\\\", \\\"{x:1603,y:772,t:1527635543153};\\\", \\\"{x:1605,y:772,t:1527635543169};\\\", \\\"{x:1606,y:774,t:1527635543186};\\\", \\\"{x:1607,y:774,t:1527635543203};\\\", \\\"{x:1607,y:775,t:1527635543219};\\\", \\\"{x:1609,y:775,t:1527635543255};\\\", \\\"{x:1609,y:776,t:1527635543278};\\\", \\\"{x:1609,y:777,t:1527635543687};\\\", \\\"{x:1607,y:777,t:1527635550974};\\\", \\\"{x:1604,y:777,t:1527635550983};\\\", \\\"{x:1598,y:777,t:1527635550993};\\\", \\\"{x:1581,y:775,t:1527635551009};\\\", \\\"{x:1566,y:770,t:1527635551027};\\\", \\\"{x:1549,y:766,t:1527635551044};\\\", \\\"{x:1532,y:765,t:1527635551061};\\\", \\\"{x:1516,y:759,t:1527635551076};\\\", \\\"{x:1498,y:756,t:1527635551094};\\\", \\\"{x:1476,y:750,t:1527635551110};\\\", \\\"{x:1466,y:748,t:1527635551126};\\\", \\\"{x:1456,y:744,t:1527635551143};\\\", \\\"{x:1449,y:742,t:1527635551160};\\\", \\\"{x:1445,y:741,t:1527635551176};\\\", \\\"{x:1439,y:740,t:1527635551193};\\\", \\\"{x:1438,y:739,t:1527635551210};\\\", \\\"{x:1436,y:738,t:1527635551226};\\\", \\\"{x:1433,y:737,t:1527635551243};\\\", \\\"{x:1429,y:734,t:1527635551260};\\\", \\\"{x:1422,y:732,t:1527635551276};\\\", \\\"{x:1413,y:729,t:1527635551294};\\\", \\\"{x:1398,y:724,t:1527635551310};\\\", \\\"{x:1390,y:723,t:1527635551326};\\\", \\\"{x:1384,y:719,t:1527635551343};\\\", \\\"{x:1380,y:719,t:1527635551360};\\\", \\\"{x:1377,y:718,t:1527635551376};\\\", \\\"{x:1375,y:717,t:1527635551394};\\\", \\\"{x:1373,y:717,t:1527635551411};\\\", \\\"{x:1371,y:716,t:1527635551427};\\\", \\\"{x:1368,y:716,t:1527635551443};\\\", \\\"{x:1365,y:715,t:1527635551461};\\\", \\\"{x:1363,y:714,t:1527635551477};\\\", \\\"{x:1361,y:714,t:1527635551493};\\\", \\\"{x:1357,y:713,t:1527635551510};\\\", \\\"{x:1353,y:713,t:1527635551527};\\\", \\\"{x:1351,y:713,t:1527635551543};\\\", \\\"{x:1348,y:712,t:1527635551560};\\\", \\\"{x:1345,y:712,t:1527635551577};\\\", \\\"{x:1342,y:711,t:1527635551593};\\\", \\\"{x:1339,y:711,t:1527635551611};\\\", \\\"{x:1338,y:711,t:1527635551627};\\\", \\\"{x:1336,y:710,t:1527635551643};\\\", \\\"{x:1332,y:709,t:1527635551660};\\\", \\\"{x:1331,y:709,t:1527635551678};\\\", \\\"{x:1328,y:709,t:1527635551693};\\\", \\\"{x:1326,y:709,t:1527635551710};\\\", \\\"{x:1328,y:709,t:1527635552231};\\\", \\\"{x:1333,y:709,t:1527635552244};\\\", \\\"{x:1346,y:709,t:1527635552261};\\\", \\\"{x:1362,y:712,t:1527635552278};\\\", \\\"{x:1401,y:720,t:1527635552295};\\\", \\\"{x:1431,y:731,t:1527635552311};\\\", \\\"{x:1483,y:746,t:1527635552327};\\\", \\\"{x:1536,y:760,t:1527635552344};\\\", \\\"{x:1564,y:766,t:1527635552361};\\\", \\\"{x:1579,y:769,t:1527635552377};\\\", \\\"{x:1588,y:773,t:1527635552394};\\\", \\\"{x:1591,y:774,t:1527635552411};\\\", \\\"{x:1593,y:776,t:1527635552427};\\\", \\\"{x:1596,y:776,t:1527635552444};\\\", \\\"{x:1598,y:777,t:1527635552462};\\\", \\\"{x:1599,y:778,t:1527635552477};\\\", \\\"{x:1602,y:779,t:1527635552495};\\\", \\\"{x:1605,y:781,t:1527635552511};\\\", \\\"{x:1609,y:784,t:1527635552528};\\\", \\\"{x:1612,y:785,t:1527635552544};\\\", \\\"{x:1613,y:786,t:1527635552561};\\\", \\\"{x:1614,y:786,t:1527635552579};\\\", \\\"{x:1614,y:785,t:1527635552727};\\\", \\\"{x:1612,y:784,t:1527635552743};\\\", \\\"{x:1611,y:783,t:1527635552751};\\\", \\\"{x:1611,y:782,t:1527635552775};\\\", \\\"{x:1610,y:781,t:1527635552807};\\\", \\\"{x:1609,y:781,t:1527635552838};\\\", \\\"{x:1608,y:780,t:1527635552934};\\\", \\\"{x:1604,y:778,t:1527635552946};\\\", \\\"{x:1583,y:771,t:1527635552961};\\\", \\\"{x:1553,y:759,t:1527635552978};\\\", \\\"{x:1506,y:747,t:1527635552995};\\\", \\\"{x:1462,y:736,t:1527635553011};\\\", \\\"{x:1434,y:729,t:1527635553028};\\\", \\\"{x:1419,y:723,t:1527635553045};\\\", \\\"{x:1413,y:722,t:1527635553061};\\\", \\\"{x:1411,y:721,t:1527635553078};\\\", \\\"{x:1410,y:721,t:1527635553142};\\\", \\\"{x:1409,y:721,t:1527635553174};\\\", \\\"{x:1409,y:720,t:1527635553206};\\\", \\\"{x:1406,y:719,t:1527635553222};\\\", \\\"{x:1403,y:718,t:1527635553230};\\\", \\\"{x:1398,y:717,t:1527635553245};\\\", \\\"{x:1388,y:714,t:1527635553261};\\\", \\\"{x:1370,y:712,t:1527635553279};\\\", \\\"{x:1362,y:710,t:1527635553296};\\\", \\\"{x:1358,y:710,t:1527635553312};\\\", \\\"{x:1356,y:710,t:1527635553329};\\\", \\\"{x:1354,y:710,t:1527635553535};\\\", \\\"{x:1353,y:710,t:1527635553750};\\\", \\\"{x:1353,y:709,t:1527635553779};\\\", \\\"{x:1350,y:709,t:1527635553795};\\\", \\\"{x:1348,y:709,t:1527635553813};\\\", \\\"{x:1347,y:709,t:1527635553829};\\\", \\\"{x:1344,y:709,t:1527635553846};\\\", \\\"{x:1342,y:709,t:1527635553862};\\\", \\\"{x:1341,y:709,t:1527635553879};\\\", \\\"{x:1339,y:709,t:1527635553895};\\\", \\\"{x:1337,y:709,t:1527635553912};\\\", \\\"{x:1336,y:709,t:1527635553990};\\\", \\\"{x:1335,y:709,t:1527635554478};\\\", \\\"{x:1337,y:709,t:1527635554887};\\\", \\\"{x:1339,y:709,t:1527635554902};\\\", \\\"{x:1340,y:709,t:1527635554918};\\\", \\\"{x:1341,y:709,t:1527635554943};\\\", \\\"{x:1342,y:709,t:1527635557694};\\\", \\\"{x:1344,y:708,t:1527635557716};\\\", \\\"{x:1345,y:708,t:1527635557733};\\\", \\\"{x:1346,y:707,t:1527635557749};\\\", \\\"{x:1347,y:707,t:1527635557766};\\\", \\\"{x:1345,y:707,t:1527635558319};\\\", \\\"{x:1346,y:707,t:1527635558702};\\\", \\\"{x:1350,y:705,t:1527635558717};\\\", \\\"{x:1353,y:680,t:1527635558733};\\\", \\\"{x:1354,y:650,t:1527635558750};\\\", \\\"{x:1355,y:636,t:1527635558767};\\\", \\\"{x:1355,y:619,t:1527635558783};\\\", \\\"{x:1355,y:602,t:1527635558801};\\\", \\\"{x:1355,y:594,t:1527635558816};\\\", \\\"{x:1357,y:588,t:1527635558834};\\\", \\\"{x:1357,y:582,t:1527635558851};\\\", \\\"{x:1361,y:570,t:1527635558866};\\\", \\\"{x:1363,y:565,t:1527635558883};\\\", \\\"{x:1366,y:558,t:1527635558901};\\\", \\\"{x:1371,y:548,t:1527635558917};\\\", \\\"{x:1375,y:541,t:1527635558934};\\\", \\\"{x:1377,y:536,t:1527635558950};\\\", \\\"{x:1378,y:534,t:1527635558968};\\\", \\\"{x:1378,y:533,t:1527635558984};\\\", \\\"{x:1381,y:524,t:1527635559001};\\\", \\\"{x:1384,y:515,t:1527635559017};\\\", \\\"{x:1390,y:505,t:1527635559033};\\\", \\\"{x:1393,y:496,t:1527635559051};\\\", \\\"{x:1398,y:488,t:1527635559067};\\\", \\\"{x:1404,y:478,t:1527635559083};\\\", \\\"{x:1411,y:469,t:1527635559100};\\\", \\\"{x:1418,y:461,t:1527635559117};\\\", \\\"{x:1434,y:451,t:1527635559134};\\\", \\\"{x:1465,y:436,t:1527635559150};\\\", \\\"{x:1490,y:426,t:1527635559167};\\\", \\\"{x:1505,y:418,t:1527635559183};\\\", \\\"{x:1527,y:413,t:1527635559200};\\\", \\\"{x:1543,y:407,t:1527635559217};\\\", \\\"{x:1553,y:404,t:1527635559233};\\\", \\\"{x:1560,y:403,t:1527635559251};\\\", \\\"{x:1564,y:403,t:1527635559267};\\\", \\\"{x:1565,y:403,t:1527635559284};\\\", \\\"{x:1568,y:402,t:1527635559301};\\\", \\\"{x:1569,y:402,t:1527635559622};\\\", \\\"{x:1569,y:404,t:1527635559702};\\\", \\\"{x:1571,y:408,t:1527635559717};\\\", \\\"{x:1574,y:423,t:1527635559734};\\\", \\\"{x:1578,y:438,t:1527635559752};\\\", \\\"{x:1579,y:450,t:1527635559768};\\\", \\\"{x:1583,y:463,t:1527635559785};\\\", \\\"{x:1586,y:477,t:1527635559802};\\\", \\\"{x:1589,y:499,t:1527635559817};\\\", \\\"{x:1590,y:522,t:1527635559835};\\\", \\\"{x:1592,y:551,t:1527635559852};\\\", \\\"{x:1593,y:581,t:1527635559868};\\\", \\\"{x:1596,y:613,t:1527635559885};\\\", \\\"{x:1598,y:644,t:1527635559902};\\\", \\\"{x:1598,y:667,t:1527635559917};\\\", \\\"{x:1598,y:698,t:1527635559934};\\\", \\\"{x:1598,y:714,t:1527635559951};\\\", \\\"{x:1598,y:729,t:1527635559968};\\\", \\\"{x:1598,y:742,t:1527635559984};\\\", \\\"{x:1594,y:751,t:1527635560002};\\\", \\\"{x:1593,y:758,t:1527635560017};\\\", \\\"{x:1592,y:764,t:1527635560035};\\\", \\\"{x:1589,y:770,t:1527635560051};\\\", \\\"{x:1587,y:779,t:1527635560068};\\\", \\\"{x:1583,y:786,t:1527635560085};\\\", \\\"{x:1579,y:791,t:1527635560102};\\\", \\\"{x:1567,y:800,t:1527635560118};\\\", \\\"{x:1559,y:803,t:1527635560135};\\\", \\\"{x:1548,y:805,t:1527635560152};\\\", \\\"{x:1537,y:805,t:1527635560169};\\\", \\\"{x:1532,y:805,t:1527635560184};\\\", \\\"{x:1521,y:804,t:1527635560202};\\\", \\\"{x:1507,y:801,t:1527635560219};\\\", \\\"{x:1492,y:796,t:1527635560235};\\\", \\\"{x:1482,y:794,t:1527635560251};\\\", \\\"{x:1477,y:793,t:1527635560269};\\\", \\\"{x:1473,y:790,t:1527635560284};\\\", \\\"{x:1472,y:789,t:1527635560302};\\\", \\\"{x:1471,y:786,t:1527635560318};\\\", \\\"{x:1471,y:784,t:1527635560334};\\\", \\\"{x:1471,y:779,t:1527635560351};\\\", \\\"{x:1471,y:774,t:1527635560369};\\\", \\\"{x:1475,y:769,t:1527635560385};\\\", \\\"{x:1479,y:765,t:1527635560401};\\\", \\\"{x:1483,y:764,t:1527635560419};\\\", \\\"{x:1486,y:763,t:1527635560435};\\\", \\\"{x:1486,y:762,t:1527635560452};\\\", \\\"{x:1488,y:761,t:1527635560469};\\\", \\\"{x:1488,y:762,t:1527635560662};\\\", \\\"{x:1488,y:767,t:1527635560670};\\\", \\\"{x:1488,y:770,t:1527635560686};\\\", \\\"{x:1488,y:773,t:1527635560702};\\\", \\\"{x:1488,y:776,t:1527635560718};\\\", \\\"{x:1488,y:777,t:1527635560785};\\\", \\\"{x:1488,y:778,t:1527635560798};\\\", \\\"{x:1488,y:779,t:1527635560815};\\\", \\\"{x:1487,y:780,t:1527635560831};\\\", \\\"{x:1485,y:781,t:1527635560846};\\\", \\\"{x:1485,y:781,t:1527635560847};\\\", \\\"{x:1483,y:781,t:1527635560864};\\\", \\\"{x:1482,y:781,t:1527635560882};\\\", \\\"{x:1481,y:782,t:1527635560898};\\\", \\\"{x:1480,y:782,t:1527635560918};\\\", \\\"{x:1479,y:782,t:1527635560958};\\\", \\\"{x:1479,y:783,t:1527635561367};\\\", \\\"{x:1482,y:788,t:1527635561382};\\\", \\\"{x:1489,y:793,t:1527635561398};\\\", \\\"{x:1492,y:796,t:1527635561414};\\\", \\\"{x:1492,y:798,t:1527635561432};\\\", \\\"{x:1492,y:800,t:1527635561455};\\\", \\\"{x:1492,y:802,t:1527635561465};\\\", \\\"{x:1485,y:808,t:1527635561482};\\\", \\\"{x:1462,y:817,t:1527635561499};\\\", \\\"{x:1423,y:824,t:1527635561515};\\\", \\\"{x:1363,y:835,t:1527635561532};\\\", \\\"{x:1268,y:841,t:1527635561548};\\\", \\\"{x:1162,y:841,t:1527635561565};\\\", \\\"{x:1032,y:841,t:1527635561582};\\\", \\\"{x:776,y:804,t:1527635561599};\\\", \\\"{x:622,y:785,t:1527635561616};\\\", \\\"{x:493,y:758,t:1527635561631};\\\", \\\"{x:440,y:743,t:1527635561649};\\\", \\\"{x:430,y:741,t:1527635561665};\\\", \\\"{x:428,y:740,t:1527635561681};\\\", \\\"{x:426,y:739,t:1527635561702};\\\", \\\"{x:422,y:734,t:1527635561715};\\\", \\\"{x:399,y:723,t:1527635561731};\\\", \\\"{x:361,y:700,t:1527635561749};\\\", \\\"{x:321,y:687,t:1527635561766};\\\", \\\"{x:312,y:683,t:1527635561781};\\\", \\\"{x:310,y:683,t:1527635561798};\\\", \\\"{x:310,y:682,t:1527635561815};\\\", \\\"{x:312,y:677,t:1527635561832};\\\", \\\"{x:320,y:670,t:1527635561849};\\\", \\\"{x:329,y:662,t:1527635561866};\\\", \\\"{x:333,y:659,t:1527635561883};\\\", \\\"{x:339,y:655,t:1527635561899};\\\", \\\"{x:343,y:653,t:1527635561915};\\\", \\\"{x:350,y:650,t:1527635561933};\\\", \\\"{x:354,y:647,t:1527635561949};\\\", \\\"{x:356,y:645,t:1527635561965};\\\", \\\"{x:361,y:642,t:1527635561982};\\\", \\\"{x:363,y:640,t:1527635561999};\\\", \\\"{x:366,y:637,t:1527635562016};\\\", \\\"{x:368,y:635,t:1527635562033};\\\", \\\"{x:369,y:633,t:1527635562048};\\\", \\\"{x:370,y:629,t:1527635562065};\\\", \\\"{x:373,y:622,t:1527635562083};\\\", \\\"{x:374,y:617,t:1527635562099};\\\", \\\"{x:378,y:610,t:1527635562116};\\\", \\\"{x:378,y:608,t:1527635562132};\\\", \\\"{x:378,y:606,t:1527635562148};\\\", \\\"{x:380,y:602,t:1527635562166};\\\", \\\"{x:380,y:599,t:1527635562182};\\\", \\\"{x:381,y:597,t:1527635562198};\\\", \\\"{x:383,y:596,t:1527635562894};\\\", \\\"{x:385,y:595,t:1527635562901};\\\", \\\"{x:391,y:592,t:1527635562916};\\\", \\\"{x:398,y:591,t:1527635562933};\\\", \\\"{x:407,y:586,t:1527635562949};\\\", \\\"{x:448,y:575,t:1527635562967};\\\", \\\"{x:534,y:562,t:1527635562984};\\\", \\\"{x:631,y:539,t:1527635563000};\\\", \\\"{x:717,y:524,t:1527635563017};\\\", \\\"{x:816,y:504,t:1527635563033};\\\", \\\"{x:898,y:483,t:1527635563050};\\\", \\\"{x:958,y:472,t:1527635563067};\\\", \\\"{x:986,y:470,t:1527635563083};\\\", \\\"{x:1015,y:465,t:1527635563100};\\\", \\\"{x:1029,y:461,t:1527635563116};\\\", \\\"{x:1034,y:461,t:1527635563133};\\\", \\\"{x:1040,y:459,t:1527635563149};\\\", \\\"{x:1045,y:457,t:1527635563166};\\\", \\\"{x:1048,y:456,t:1527635563183};\\\", \\\"{x:1051,y:455,t:1527635563199};\\\", \\\"{x:1055,y:454,t:1527635563217};\\\", \\\"{x:1063,y:453,t:1527635563232};\\\", \\\"{x:1071,y:452,t:1527635563250};\\\", \\\"{x:1081,y:450,t:1527635563266};\\\", \\\"{x:1086,y:447,t:1527635563282};\\\", \\\"{x:1089,y:446,t:1527635563299};\\\", \\\"{x:1091,y:444,t:1527635563317};\\\", \\\"{x:1093,y:444,t:1527635563334};\\\", \\\"{x:1094,y:444,t:1527635563350};\\\", \\\"{x:1095,y:444,t:1527635563638};\\\", \\\"{x:1096,y:444,t:1527635564142};\\\", \\\"{x:1098,y:444,t:1527635564199};\\\", \\\"{x:1099,y:442,t:1527635564206};\\\", \\\"{x:1101,y:442,t:1527635564230};\\\", \\\"{x:1102,y:442,t:1527635564246};\\\", \\\"{x:1104,y:442,t:1527635564270};\\\", \\\"{x:1105,y:442,t:1527635564302};\\\", \\\"{x:1107,y:442,t:1527635564326};\\\", \\\"{x:1108,y:442,t:1527635564342};\\\", \\\"{x:1110,y:442,t:1527635564351};\\\", \\\"{x:1112,y:442,t:1527635564368};\\\", \\\"{x:1113,y:442,t:1527635564384};\\\", \\\"{x:1115,y:443,t:1527635564400};\\\", \\\"{x:1115,y:444,t:1527635564417};\\\", \\\"{x:1117,y:445,t:1527635564434};\\\", \\\"{x:1119,y:446,t:1527635564450};\\\", \\\"{x:1123,y:450,t:1527635564467};\\\", \\\"{x:1129,y:454,t:1527635564484};\\\", \\\"{x:1132,y:457,t:1527635564501};\\\", \\\"{x:1135,y:460,t:1527635564517};\\\", \\\"{x:1138,y:463,t:1527635564534};\\\", \\\"{x:1139,y:464,t:1527635564550};\\\", \\\"{x:1140,y:464,t:1527635564568};\\\", \\\"{x:1142,y:464,t:1527635564831};\\\", \\\"{x:1143,y:464,t:1527635564838};\\\", \\\"{x:1146,y:464,t:1527635564850};\\\", \\\"{x:1150,y:464,t:1527635564868};\\\", \\\"{x:1155,y:464,t:1527635564885};\\\", \\\"{x:1161,y:465,t:1527635564901};\\\", \\\"{x:1182,y:469,t:1527635564918};\\\", \\\"{x:1269,y:480,t:1527635564935};\\\", \\\"{x:1360,y:490,t:1527635564950};\\\", \\\"{x:1455,y:505,t:1527635564968};\\\", \\\"{x:1529,y:514,t:1527635564985};\\\", \\\"{x:1564,y:520,t:1527635565001};\\\", \\\"{x:1574,y:521,t:1527635565018};\\\", \\\"{x:1578,y:523,t:1527635565035};\\\", \\\"{x:1583,y:526,t:1527635565052};\\\", \\\"{x:1594,y:531,t:1527635565068};\\\", \\\"{x:1608,y:538,t:1527635565085};\\\", \\\"{x:1622,y:550,t:1527635565102};\\\", \\\"{x:1626,y:553,t:1527635565118};\\\", \\\"{x:1633,y:561,t:1527635565134};\\\", \\\"{x:1634,y:562,t:1527635565152};\\\", \\\"{x:1634,y:564,t:1527635565168};\\\", \\\"{x:1634,y:568,t:1527635565185};\\\", \\\"{x:1635,y:578,t:1527635565202};\\\", \\\"{x:1632,y:593,t:1527635565217};\\\", \\\"{x:1623,y:600,t:1527635565235};\\\", \\\"{x:1619,y:601,t:1527635565252};\\\", \\\"{x:1619,y:602,t:1527635565550};\\\", \\\"{x:1619,y:606,t:1527635565735};\\\", \\\"{x:1619,y:617,t:1527635565742};\\\", \\\"{x:1619,y:627,t:1527635565752};\\\", \\\"{x:1625,y:647,t:1527635565769};\\\", \\\"{x:1633,y:670,t:1527635565786};\\\", \\\"{x:1642,y:696,t:1527635565802};\\\", \\\"{x:1649,y:718,t:1527635565819};\\\", \\\"{x:1654,y:744,t:1527635565836};\\\", \\\"{x:1654,y:774,t:1527635565852};\\\", \\\"{x:1655,y:788,t:1527635565868};\\\", \\\"{x:1655,y:789,t:1527635565886};\\\", \\\"{x:1655,y:788,t:1527635566254};\\\", \\\"{x:1652,y:788,t:1527635566269};\\\", \\\"{x:1606,y:772,t:1527635566286};\\\", \\\"{x:1520,y:747,t:1527635566302};\\\", \\\"{x:1379,y:706,t:1527635566319};\\\", \\\"{x:1202,y:651,t:1527635566336};\\\", \\\"{x:1024,y:617,t:1527635566353};\\\", \\\"{x:833,y:590,t:1527635566369};\\\", \\\"{x:663,y:572,t:1527635566386};\\\", \\\"{x:529,y:549,t:1527635566403};\\\", \\\"{x:468,y:541,t:1527635566419};\\\", \\\"{x:460,y:540,t:1527635566437};\\\", \\\"{x:465,y:537,t:1527635566550};\\\", \\\"{x:475,y:532,t:1527635566558};\\\", \\\"{x:485,y:528,t:1527635566569};\\\", \\\"{x:510,y:516,t:1527635566586};\\\", \\\"{x:532,y:507,t:1527635566603};\\\", \\\"{x:556,y:498,t:1527635566620};\\\", \\\"{x:575,y:491,t:1527635566636};\\\", \\\"{x:582,y:487,t:1527635566653};\\\", \\\"{x:585,y:487,t:1527635566669};\\\", \\\"{x:586,y:486,t:1527635566974};\\\", \\\"{x:589,y:484,t:1527635566986};\\\", \\\"{x:594,y:483,t:1527635567003};\\\", \\\"{x:599,y:484,t:1527635567020};\\\", \\\"{x:606,y:489,t:1527635567036};\\\", \\\"{x:608,y:489,t:1527635567053};\\\", \\\"{x:609,y:489,t:1527635567086};\\\", \\\"{x:632,y:489,t:1527635567102};\\\", \\\"{x:731,y:476,t:1527635567121};\\\", \\\"{x:851,y:472,t:1527635567135};\\\", \\\"{x:974,y:468,t:1527635567153};\\\", \\\"{x:1099,y:469,t:1527635567170};\\\", \\\"{x:1236,y:481,t:1527635567186};\\\", \\\"{x:1385,y:499,t:1527635567202};\\\", \\\"{x:1532,y:520,t:1527635567220};\\\", \\\"{x:1643,y:536,t:1527635567236};\\\", \\\"{x:1710,y:558,t:1527635567253};\\\", \\\"{x:1777,y:583,t:1527635567270};\\\", \\\"{x:1817,y:604,t:1527635567286};\\\", \\\"{x:1852,y:630,t:1527635567303};\\\", \\\"{x:1872,y:654,t:1527635567319};\\\", \\\"{x:1887,y:668,t:1527635567337};\\\", \\\"{x:1896,y:683,t:1527635567353};\\\", \\\"{x:1897,y:692,t:1527635567370};\\\", \\\"{x:1898,y:702,t:1527635567387};\\\", \\\"{x:1898,y:719,t:1527635567403};\\\", \\\"{x:1896,y:731,t:1527635567420};\\\", \\\"{x:1891,y:738,t:1527635567437};\\\", \\\"{x:1885,y:746,t:1527635567453};\\\", \\\"{x:1867,y:756,t:1527635567470};\\\", \\\"{x:1852,y:761,t:1527635567487};\\\", \\\"{x:1835,y:764,t:1527635567503};\\\", \\\"{x:1820,y:764,t:1527635567519};\\\", \\\"{x:1796,y:764,t:1527635567537};\\\", \\\"{x:1774,y:764,t:1527635567553};\\\", \\\"{x:1752,y:764,t:1527635567570};\\\", \\\"{x:1736,y:764,t:1527635567586};\\\", \\\"{x:1725,y:764,t:1527635567603};\\\", \\\"{x:1721,y:764,t:1527635567620};\\\", \\\"{x:1719,y:764,t:1527635567637};\\\", \\\"{x:1716,y:764,t:1527635567653};\\\", \\\"{x:1709,y:764,t:1527635567670};\\\", \\\"{x:1702,y:763,t:1527635567687};\\\", \\\"{x:1695,y:763,t:1527635567703};\\\", \\\"{x:1686,y:763,t:1527635567720};\\\", \\\"{x:1676,y:763,t:1527635567737};\\\", \\\"{x:1666,y:763,t:1527635567753};\\\", \\\"{x:1654,y:763,t:1527635567770};\\\", \\\"{x:1636,y:763,t:1527635567787};\\\", \\\"{x:1600,y:763,t:1527635567804};\\\", \\\"{x:1570,y:763,t:1527635567820};\\\", \\\"{x:1497,y:763,t:1527635567837};\\\", \\\"{x:1410,y:763,t:1527635567854};\\\", \\\"{x:1330,y:754,t:1527635567870};\\\", \\\"{x:1281,y:754,t:1527635567887};\\\", \\\"{x:1247,y:750,t:1527635567904};\\\", \\\"{x:1225,y:751,t:1527635567920};\\\", \\\"{x:1218,y:751,t:1527635567937};\\\", \\\"{x:1208,y:751,t:1527635567954};\\\", \\\"{x:1205,y:751,t:1527635567970};\\\", \\\"{x:1201,y:752,t:1527635567987};\\\", \\\"{x:1196,y:755,t:1527635568004};\\\", \\\"{x:1191,y:759,t:1527635568020};\\\", \\\"{x:1186,y:763,t:1527635568037};\\\", \\\"{x:1186,y:764,t:1527635568054};\\\", \\\"{x:1185,y:765,t:1527635568070};\\\", \\\"{x:1185,y:770,t:1527635568087};\\\", \\\"{x:1187,y:774,t:1527635568103};\\\", \\\"{x:1190,y:779,t:1527635568120};\\\", \\\"{x:1193,y:783,t:1527635568137};\\\", \\\"{x:1197,y:787,t:1527635568153};\\\", \\\"{x:1202,y:792,t:1527635568170};\\\", \\\"{x:1207,y:796,t:1527635568187};\\\", \\\"{x:1214,y:800,t:1527635568203};\\\", \\\"{x:1218,y:805,t:1527635568220};\\\", \\\"{x:1224,y:810,t:1527635568237};\\\", \\\"{x:1230,y:814,t:1527635568254};\\\", \\\"{x:1231,y:814,t:1527635568574};\\\", \\\"{x:1233,y:814,t:1527635568598};\\\", \\\"{x:1234,y:814,t:1527635568614};\\\", \\\"{x:1236,y:814,t:1527635568622};\\\", \\\"{x:1238,y:813,t:1527635568638};\\\", \\\"{x:1245,y:813,t:1527635568654};\\\", \\\"{x:1252,y:813,t:1527635568671};\\\", \\\"{x:1262,y:813,t:1527635568687};\\\", \\\"{x:1271,y:813,t:1527635568704};\\\", \\\"{x:1284,y:813,t:1527635568720};\\\", \\\"{x:1296,y:813,t:1527635568736};\\\", \\\"{x:1310,y:811,t:1527635568754};\\\", \\\"{x:1324,y:811,t:1527635568771};\\\", \\\"{x:1328,y:811,t:1527635568788};\\\", \\\"{x:1338,y:809,t:1527635568804};\\\", \\\"{x:1344,y:808,t:1527635568821};\\\", \\\"{x:1357,y:804,t:1527635568838};\\\", \\\"{x:1369,y:799,t:1527635568854};\\\", \\\"{x:1378,y:796,t:1527635568871};\\\", \\\"{x:1387,y:792,t:1527635568888};\\\", \\\"{x:1392,y:789,t:1527635568904};\\\", \\\"{x:1397,y:785,t:1527635568921};\\\", \\\"{x:1403,y:781,t:1527635568938};\\\", \\\"{x:1409,y:776,t:1527635568954};\\\", \\\"{x:1419,y:771,t:1527635568971};\\\", \\\"{x:1431,y:762,t:1527635568988};\\\", \\\"{x:1443,y:753,t:1527635569003};\\\", \\\"{x:1455,y:746,t:1527635569021};\\\", \\\"{x:1464,y:740,t:1527635569038};\\\", \\\"{x:1466,y:739,t:1527635569054};\\\", \\\"{x:1467,y:739,t:1527635569071};\\\", \\\"{x:1468,y:737,t:1527635569102};\\\", \\\"{x:1469,y:736,t:1527635569125};\\\", \\\"{x:1470,y:735,t:1527635569138};\\\", \\\"{x:1472,y:734,t:1527635569154};\\\", \\\"{x:1473,y:733,t:1527635569171};\\\", \\\"{x:1474,y:732,t:1527635569188};\\\", \\\"{x:1475,y:732,t:1527635569222};\\\", \\\"{x:1470,y:732,t:1527635569359};\\\", \\\"{x:1465,y:733,t:1527635569371};\\\", \\\"{x:1447,y:741,t:1527635569388};\\\", \\\"{x:1396,y:737,t:1527635569405};\\\", \\\"{x:1300,y:725,t:1527635569421};\\\", \\\"{x:1162,y:706,t:1527635569438};\\\", \\\"{x:1071,y:695,t:1527635569455};\\\", \\\"{x:983,y:685,t:1527635569471};\\\", \\\"{x:895,y:666,t:1527635569488};\\\", \\\"{x:814,y:638,t:1527635569505};\\\", \\\"{x:757,y:619,t:1527635569521};\\\", \\\"{x:712,y:604,t:1527635569538};\\\", \\\"{x:688,y:594,t:1527635569555};\\\", \\\"{x:667,y:585,t:1527635569571};\\\", \\\"{x:653,y:577,t:1527635569588};\\\", \\\"{x:640,y:568,t:1527635569604};\\\", \\\"{x:623,y:560,t:1527635569621};\\\", \\\"{x:598,y:552,t:1527635569638};\\\", \\\"{x:583,y:546,t:1527635569655};\\\", \\\"{x:578,y:543,t:1527635569672};\\\", \\\"{x:580,y:543,t:1527635569934};\\\", \\\"{x:580,y:542,t:1527635569990};\\\", \\\"{x:575,y:539,t:1527635570005};\\\", \\\"{x:531,y:532,t:1527635570021};\\\", \\\"{x:456,y:523,t:1527635570039};\\\", \\\"{x:346,y:511,t:1527635570055};\\\", \\\"{x:232,y:495,t:1527635570072};\\\", \\\"{x:138,y:481,t:1527635570089};\\\", \\\"{x:75,y:468,t:1527635570105};\\\", \\\"{x:34,y:459,t:1527635570122};\\\", \\\"{x:16,y:453,t:1527635570139};\\\", \\\"{x:8,y:450,t:1527635570155};\\\", \\\"{x:2,y:447,t:1527635570172};\\\", \\\"{x:0,y:445,t:1527635570189};\\\", \\\"{x:0,y:443,t:1527635570205};\\\", \\\"{x:0,y:441,t:1527635570222};\\\", \\\"{x:0,y:440,t:1527635570239};\\\", \\\"{x:0,y:439,t:1527635570298};\\\", \\\"{x:0,y:438,t:1527635570309};\\\", \\\"{x:7,y:434,t:1527635570325};\\\", \\\"{x:23,y:426,t:1527635570343};\\\", \\\"{x:39,y:421,t:1527635570359};\\\", \\\"{x:56,y:421,t:1527635570376};\\\", \\\"{x:82,y:421,t:1527635570392};\\\", \\\"{x:110,y:421,t:1527635570409};\\\", \\\"{x:166,y:421,t:1527635570426};\\\", \\\"{x:202,y:424,t:1527635570443};\\\", \\\"{x:226,y:428,t:1527635570460};\\\", \\\"{x:243,y:431,t:1527635570476};\\\", \\\"{x:248,y:433,t:1527635570493};\\\", \\\"{x:251,y:434,t:1527635570510};\\\", \\\"{x:254,y:435,t:1527635570526};\\\", \\\"{x:257,y:436,t:1527635570543};\\\", \\\"{x:260,y:437,t:1527635570560};\\\", \\\"{x:266,y:437,t:1527635570575};\\\", \\\"{x:273,y:440,t:1527635570594};\\\", \\\"{x:286,y:444,t:1527635570610};\\\", \\\"{x:304,y:449,t:1527635570626};\\\", \\\"{x:323,y:452,t:1527635570643};\\\", \\\"{x:343,y:456,t:1527635570660};\\\", \\\"{x:368,y:460,t:1527635570676};\\\", \\\"{x:397,y:463,t:1527635570693};\\\", \\\"{x:440,y:470,t:1527635570710};\\\", \\\"{x:480,y:473,t:1527635570726};\\\", \\\"{x:512,y:474,t:1527635570744};\\\", \\\"{x:541,y:474,t:1527635570760};\\\", \\\"{x:565,y:474,t:1527635570776};\\\", \\\"{x:582,y:475,t:1527635570793};\\\", \\\"{x:597,y:475,t:1527635570810};\\\", \\\"{x:606,y:475,t:1527635570827};\\\", \\\"{x:614,y:475,t:1527635570843};\\\", \\\"{x:617,y:475,t:1527635570860};\\\", \\\"{x:618,y:475,t:1527635570877};\\\", \\\"{x:618,y:476,t:1527635571195};\\\", \\\"{x:619,y:476,t:1527635571210};\\\", \\\"{x:634,y:483,t:1527635571227};\\\", \\\"{x:664,y:491,t:1527635571243};\\\", \\\"{x:699,y:503,t:1527635571261};\\\", \\\"{x:746,y:509,t:1527635571277};\\\", \\\"{x:808,y:519,t:1527635571294};\\\", \\\"{x:840,y:525,t:1527635571310};\\\", \\\"{x:856,y:531,t:1527635571327};\\\", \\\"{x:864,y:532,t:1527635571344};\\\", \\\"{x:866,y:532,t:1527635571360};\\\", \\\"{x:864,y:532,t:1527635571578};\\\", \\\"{x:860,y:532,t:1527635571594};\\\", \\\"{x:858,y:531,t:1527635571611};\\\", \\\"{x:857,y:531,t:1527635571627};\\\", \\\"{x:856,y:530,t:1527635571644};\\\", \\\"{x:855,y:530,t:1527635571713};\\\", \\\"{x:853,y:530,t:1527635571737};\\\", \\\"{x:851,y:529,t:1527635571745};\\\", \\\"{x:850,y:529,t:1527635571761};\\\", \\\"{x:842,y:528,t:1527635571777};\\\", \\\"{x:821,y:527,t:1527635571794};\\\", \\\"{x:813,y:525,t:1527635571810};\\\", \\\"{x:804,y:525,t:1527635571827};\\\", \\\"{x:797,y:523,t:1527635571844};\\\", \\\"{x:791,y:522,t:1527635571861};\\\", \\\"{x:788,y:521,t:1527635571877};\\\", \\\"{x:783,y:519,t:1527635571894};\\\", \\\"{x:779,y:519,t:1527635571910};\\\", \\\"{x:778,y:519,t:1527635571927};\\\", \\\"{x:777,y:519,t:1527635571945};\\\", \\\"{x:783,y:520,t:1527635572018};\\\", \\\"{x:802,y:520,t:1527635572027};\\\", \\\"{x:907,y:520,t:1527635572044};\\\", \\\"{x:1057,y:525,t:1527635572062};\\\", \\\"{x:1238,y:538,t:1527635572077};\\\", \\\"{x:1408,y:569,t:1527635572094};\\\", \\\"{x:1529,y:596,t:1527635572111};\\\", \\\"{x:1592,y:622,t:1527635572127};\\\", \\\"{x:1617,y:639,t:1527635572144};\\\", \\\"{x:1627,y:648,t:1527635572162};\\\", \\\"{x:1641,y:667,t:1527635572178};\\\", \\\"{x:1646,y:675,t:1527635572194};\\\", \\\"{x:1656,y:687,t:1527635572211};\\\", \\\"{x:1659,y:698,t:1527635572228};\\\", \\\"{x:1662,y:705,t:1527635572244};\\\", \\\"{x:1663,y:713,t:1527635572261};\\\", \\\"{x:1663,y:719,t:1527635572278};\\\", \\\"{x:1661,y:725,t:1527635572294};\\\", \\\"{x:1655,y:731,t:1527635572311};\\\", \\\"{x:1640,y:741,t:1527635572328};\\\", \\\"{x:1619,y:752,t:1527635572344};\\\", \\\"{x:1604,y:763,t:1527635572361};\\\", \\\"{x:1579,y:770,t:1527635572378};\\\", \\\"{x:1570,y:773,t:1527635572394};\\\", \\\"{x:1564,y:774,t:1527635572411};\\\", \\\"{x:1555,y:775,t:1527635572428};\\\", \\\"{x:1552,y:775,t:1527635572444};\\\", \\\"{x:1548,y:775,t:1527635572461};\\\", \\\"{x:1544,y:775,t:1527635572478};\\\", \\\"{x:1542,y:775,t:1527635572494};\\\", \\\"{x:1540,y:775,t:1527635572511};\\\", \\\"{x:1538,y:775,t:1527635572528};\\\", \\\"{x:1537,y:775,t:1527635572610};\\\", \\\"{x:1536,y:775,t:1527635572658};\\\", \\\"{x:1534,y:775,t:1527635572666};\\\", \\\"{x:1532,y:775,t:1527635572678};\\\", \\\"{x:1530,y:776,t:1527635572695};\\\", \\\"{x:1525,y:777,t:1527635572712};\\\", \\\"{x:1523,y:778,t:1527635572728};\\\", \\\"{x:1519,y:778,t:1527635572745};\\\", \\\"{x:1517,y:779,t:1527635572770};\\\", \\\"{x:1512,y:781,t:1527635572778};\\\", \\\"{x:1511,y:782,t:1527635572795};\\\", \\\"{x:1510,y:782,t:1527635572811};\\\", \\\"{x:1509,y:782,t:1527635572828};\\\", \\\"{x:1507,y:782,t:1527635572845};\\\", \\\"{x:1506,y:782,t:1527635572861};\\\", \\\"{x:1505,y:783,t:1527635572882};\\\", \\\"{x:1502,y:784,t:1527635572906};\\\", \\\"{x:1501,y:784,t:1527635572954};\\\", \\\"{x:1499,y:784,t:1527635572961};\\\", \\\"{x:1497,y:784,t:1527635572978};\\\", \\\"{x:1492,y:784,t:1527635572995};\\\", \\\"{x:1485,y:784,t:1527635573011};\\\", \\\"{x:1482,y:783,t:1527635573028};\\\", \\\"{x:1481,y:783,t:1527635573045};\\\", \\\"{x:1480,y:783,t:1527635573060};\\\", \\\"{x:1479,y:783,t:1527635573146};\\\", \\\"{x:1478,y:782,t:1527635573162};\\\", \\\"{x:1478,y:781,t:1527635574547};\\\", \\\"{x:1478,y:779,t:1527635574579};\\\", \\\"{x:1478,y:778,t:1527635574618};\\\", \\\"{x:1478,y:777,t:1527635574739};\\\", \\\"{x:1470,y:773,t:1527635575083};\\\", \\\"{x:1457,y:770,t:1527635575097};\\\", \\\"{x:1425,y:767,t:1527635575113};\\\", \\\"{x:1322,y:742,t:1527635575130};\\\", \\\"{x:1261,y:726,t:1527635575146};\\\", \\\"{x:1207,y:715,t:1527635575163};\\\", \\\"{x:1159,y:700,t:1527635575180};\\\", \\\"{x:1111,y:684,t:1527635575196};\\\", \\\"{x:1064,y:664,t:1527635575214};\\\", \\\"{x:1011,y:641,t:1527635575230};\\\", \\\"{x:961,y:618,t:1527635575247};\\\", \\\"{x:934,y:605,t:1527635575263};\\\", \\\"{x:910,y:594,t:1527635575280};\\\", \\\"{x:889,y:583,t:1527635575297};\\\", \\\"{x:874,y:578,t:1527635575314};\\\", \\\"{x:854,y:565,t:1527635575330};\\\", \\\"{x:840,y:558,t:1527635575346};\\\", \\\"{x:820,y:549,t:1527635575364};\\\", \\\"{x:796,y:539,t:1527635575381};\\\", \\\"{x:769,y:528,t:1527635575397};\\\", \\\"{x:752,y:523,t:1527635575413};\\\", \\\"{x:737,y:516,t:1527635575430};\\\", \\\"{x:725,y:513,t:1527635575447};\\\", \\\"{x:720,y:510,t:1527635575464};\\\", \\\"{x:709,y:508,t:1527635575481};\\\", \\\"{x:694,y:504,t:1527635575497};\\\", \\\"{x:674,y:501,t:1527635575514};\\\", \\\"{x:639,y:498,t:1527635575530};\\\", \\\"{x:623,y:494,t:1527635575548};\\\", \\\"{x:610,y:493,t:1527635575564};\\\", \\\"{x:601,y:493,t:1527635575580};\\\", \\\"{x:597,y:493,t:1527635575598};\\\", \\\"{x:594,y:493,t:1527635575613};\\\", \\\"{x:593,y:493,t:1527635575634};\\\", \\\"{x:592,y:494,t:1527635575666};\\\", \\\"{x:591,y:496,t:1527635575690};\\\", \\\"{x:591,y:497,t:1527635575698};\\\", \\\"{x:591,y:500,t:1527635575714};\\\", \\\"{x:591,y:502,t:1527635575730};\\\", \\\"{x:591,y:503,t:1527635575754};\\\", \\\"{x:591,y:504,t:1527635575764};\\\", \\\"{x:595,y:508,t:1527635575780};\\\", \\\"{x:598,y:511,t:1527635575797};\\\", \\\"{x:604,y:516,t:1527635575815};\\\", \\\"{x:611,y:520,t:1527635575831};\\\", \\\"{x:615,y:521,t:1527635575847};\\\", \\\"{x:616,y:521,t:1527635575865};\\\", \\\"{x:617,y:521,t:1527635575880};\\\", \\\"{x:617,y:522,t:1527635575897};\\\", \\\"{x:618,y:523,t:1527635575971};\\\", \\\"{x:617,y:523,t:1527635577235};\\\", \\\"{x:613,y:523,t:1527635577249};\\\", \\\"{x:606,y:522,t:1527635577265};\\\", \\\"{x:604,y:521,t:1527635577282};\\\", \\\"{x:603,y:521,t:1527635577299};\\\", \\\"{x:602,y:520,t:1527635577315};\\\", \\\"{x:601,y:520,t:1527635579058};\\\", \\\"{x:600,y:521,t:1527635579067};\\\", \\\"{x:599,y:524,t:1527635579084};\\\", \\\"{x:598,y:526,t:1527635579099};\\\", \\\"{x:598,y:527,t:1527635579130};\\\", \\\"{x:598,y:528,t:1527635579162};\\\", \\\"{x:597,y:529,t:1527635579170};\\\", \\\"{x:597,y:530,t:1527635579202};\\\", \\\"{x:596,y:530,t:1527635579216};\\\", \\\"{x:595,y:532,t:1527635579233};\\\", \\\"{x:592,y:534,t:1527635579249};\\\", \\\"{x:586,y:537,t:1527635579266};\\\", \\\"{x:581,y:539,t:1527635579284};\\\", \\\"{x:577,y:539,t:1527635579299};\\\", \\\"{x:573,y:540,t:1527635579316};\\\", \\\"{x:570,y:540,t:1527635579333};\\\", \\\"{x:566,y:541,t:1527635579350};\\\", \\\"{x:556,y:541,t:1527635579366};\\\", \\\"{x:538,y:541,t:1527635579383};\\\", \\\"{x:515,y:541,t:1527635579399};\\\", \\\"{x:490,y:536,t:1527635579417};\\\", \\\"{x:464,y:533,t:1527635579434};\\\", \\\"{x:449,y:526,t:1527635579450};\\\", \\\"{x:445,y:524,t:1527635579466};\\\", \\\"{x:444,y:523,t:1527635579483};\\\", \\\"{x:442,y:521,t:1527635579500};\\\", \\\"{x:438,y:517,t:1527635579516};\\\", \\\"{x:431,y:513,t:1527635579534};\\\", \\\"{x:427,y:510,t:1527635579550};\\\", \\\"{x:426,y:508,t:1527635579568};\\\", \\\"{x:425,y:508,t:1527635579583};\\\", \\\"{x:424,y:508,t:1527635579600};\\\", \\\"{x:423,y:508,t:1527635579626};\\\", \\\"{x:422,y:507,t:1527635579634};\\\", \\\"{x:421,y:507,t:1527635579650};\\\", \\\"{x:418,y:505,t:1527635579667};\\\", \\\"{x:417,y:505,t:1527635579683};\\\", \\\"{x:416,y:505,t:1527635579700};\\\", \\\"{x:415,y:505,t:1527635579717};\\\", \\\"{x:413,y:505,t:1527635579754};\\\", \\\"{x:413,y:504,t:1527635579834};\\\", \\\"{x:413,y:503,t:1527635579850};\\\", \\\"{x:413,y:502,t:1527635579874};\\\", \\\"{x:412,y:501,t:1527635579884};\\\", \\\"{x:412,y:499,t:1527635579900};\\\", \\\"{x:412,y:494,t:1527635579918};\\\", \\\"{x:411,y:490,t:1527635579934};\\\", \\\"{x:411,y:485,t:1527635579951};\\\", \\\"{x:411,y:482,t:1527635579968};\\\", \\\"{x:411,y:478,t:1527635579984};\\\", \\\"{x:411,y:475,t:1527635580000};\\\", \\\"{x:411,y:468,t:1527635580019};\\\", \\\"{x:411,y:463,t:1527635580034};\\\", \\\"{x:411,y:456,t:1527635580050};\\\", \\\"{x:411,y:449,t:1527635580068};\\\", \\\"{x:414,y:440,t:1527635580083};\\\", \\\"{x:416,y:434,t:1527635580101};\\\", \\\"{x:417,y:429,t:1527635580118};\\\", \\\"{x:417,y:427,t:1527635580134};\\\", \\\"{x:420,y:422,t:1527635580150};\\\", \\\"{x:423,y:418,t:1527635580167};\\\", \\\"{x:425,y:416,t:1527635580184};\\\", \\\"{x:426,y:414,t:1527635580200};\\\", \\\"{x:428,y:412,t:1527635580218};\\\", \\\"{x:428,y:411,t:1527635580234};\\\", \\\"{x:429,y:410,t:1527635580258};\\\", \\\"{x:428,y:410,t:1527635580947};\\\", \\\"{x:427,y:410,t:1527635580953};\\\", \\\"{x:426,y:410,t:1527635580978};\\\", \\\"{x:426,y:411,t:1527635580986};\\\", \\\"{x:425,y:411,t:1527635580999};\\\", \\\"{x:424,y:411,t:1527635581015};\\\", \\\"{x:423,y:412,t:1527635581032};\\\", \\\"{x:422,y:412,t:1527635581048};\\\", \\\"{x:421,y:413,t:1527635581066};\\\", \\\"{x:419,y:414,t:1527635581082};\\\", \\\"{x:418,y:414,t:1527635581098};\\\", \\\"{x:417,y:414,t:1527635581115};\\\", \\\"{x:416,y:414,t:1527635581132};\\\", \\\"{x:415,y:415,t:1527635581148};\\\", \\\"{x:414,y:415,t:1527635581186};\\\", \\\"{x:413,y:415,t:1527635581202};\\\", \\\"{x:412,y:415,t:1527635581216};\\\", \\\"{x:411,y:416,t:1527635581232};\\\", \\\"{x:408,y:417,t:1527635581248};\\\", \\\"{x:406,y:417,t:1527635581266};\\\", \\\"{x:405,y:417,t:1527635581290};\\\", \\\"{x:404,y:417,t:1527635581355};\\\", \\\"{x:403,y:417,t:1527635581370};\\\", \\\"{x:402,y:417,t:1527635581386};\\\", \\\"{x:402,y:416,t:1527635582130};\\\", \\\"{x:406,y:415,t:1527635582147};\\\", \\\"{x:411,y:412,t:1527635582164};\\\", \\\"{x:415,y:411,t:1527635582181};\\\", \\\"{x:418,y:410,t:1527635582197};\\\", \\\"{x:418,y:409,t:1527635582234};\\\", \\\"{x:419,y:409,t:1527635582249};\\\", \\\"{x:420,y:408,t:1527635582264};\\\", \\\"{x:421,y:408,t:1527635582280};\\\", \\\"{x:423,y:407,t:1527635582296};\\\", \\\"{x:424,y:407,t:1527635582313};\\\", \\\"{x:426,y:406,t:1527635582329};\\\", \\\"{x:428,y:405,t:1527635582346};\\\", \\\"{x:431,y:404,t:1527635582363};\\\", \\\"{x:434,y:403,t:1527635582380};\\\", \\\"{x:435,y:402,t:1527635582397};\\\", \\\"{x:437,y:401,t:1527635582414};\\\", \\\"{x:440,y:401,t:1527635582429};\\\", \\\"{x:441,y:399,t:1527635582447};\\\", \\\"{x:445,y:398,t:1527635582464};\\\", \\\"{x:448,y:398,t:1527635582479};\\\", \\\"{x:451,y:397,t:1527635582497};\\\", \\\"{x:454,y:397,t:1527635582513};\\\", \\\"{x:458,y:396,t:1527635582530};\\\", \\\"{x:460,y:396,t:1527635582546};\\\", \\\"{x:462,y:395,t:1527635582562};\\\", \\\"{x:465,y:395,t:1527635582580};\\\", \\\"{x:469,y:395,t:1527635582596};\\\", \\\"{x:474,y:395,t:1527635582612};\\\", \\\"{x:480,y:393,t:1527635582630};\\\", \\\"{x:484,y:393,t:1527635582646};\\\", \\\"{x:493,y:393,t:1527635582663};\\\", \\\"{x:499,y:393,t:1527635582680};\\\", \\\"{x:506,y:393,t:1527635582695};\\\", \\\"{x:516,y:393,t:1527635582713};\\\", \\\"{x:535,y:393,t:1527635582730};\\\", \\\"{x:542,y:393,t:1527635582746};\\\", \\\"{x:561,y:393,t:1527635582762};\\\", \\\"{x:570,y:393,t:1527635582779};\\\", \\\"{x:575,y:393,t:1527635582796};\\\", \\\"{x:581,y:393,t:1527635582813};\\\", \\\"{x:587,y:393,t:1527635582829};\\\", \\\"{x:599,y:393,t:1527635582845};\\\", \\\"{x:611,y:393,t:1527635582862};\\\", \\\"{x:624,y:393,t:1527635582879};\\\", \\\"{x:636,y:393,t:1527635582896};\\\", \\\"{x:645,y:393,t:1527635582912};\\\", \\\"{x:655,y:393,t:1527635582929};\\\", \\\"{x:674,y:394,t:1527635582946};\\\", \\\"{x:719,y:401,t:1527635582962};\\\", \\\"{x:800,y:416,t:1527635582979};\\\", \\\"{x:909,y:436,t:1527635582995};\\\", \\\"{x:1069,y:472,t:1527635583013};\\\", \\\"{x:1281,y:525,t:1527635583029};\\\", \\\"{x:1631,y:589,t:1527635583053};\\\", \\\"{x:1815,y:632,t:1527635583070};\\\", \\\"{x:1916,y:671,t:1527635583087};\\\", \\\"{x:1919,y:692,t:1527635583102};\\\", \\\"{x:1919,y:707,t:1527635583120};\\\", \\\"{x:1919,y:715,t:1527635583136};\\\", \\\"{x:1919,y:724,t:1527635583153};\\\", \\\"{x:1919,y:732,t:1527635583170};\\\", \\\"{x:1919,y:738,t:1527635583186};\\\", \\\"{x:1919,y:739,t:1527635583203};\\\", \\\"{x:1919,y:741,t:1527635583219};\\\", \\\"{x:1919,y:743,t:1527635583236};\\\", \\\"{x:1919,y:744,t:1527635583253};\\\", \\\"{x:1919,y:745,t:1527635583270};\\\", \\\"{x:1919,y:746,t:1527635583287};\\\", \\\"{x:1918,y:746,t:1527635583303};\\\", \\\"{x:1916,y:748,t:1527635583320};\\\", \\\"{x:1914,y:749,t:1527635583337};\\\", \\\"{x:1913,y:750,t:1527635583353};\\\", \\\"{x:1910,y:751,t:1527635583369};\\\", \\\"{x:1906,y:753,t:1527635583387};\\\", \\\"{x:1904,y:754,t:1527635583403};\\\", \\\"{x:1902,y:754,t:1527635583420};\\\", \\\"{x:1900,y:755,t:1527635583437};\\\", \\\"{x:1895,y:755,t:1527635583454};\\\", \\\"{x:1885,y:755,t:1527635583470};\\\", \\\"{x:1873,y:755,t:1527635583486};\\\", \\\"{x:1862,y:752,t:1527635583503};\\\", \\\"{x:1849,y:748,t:1527635583520};\\\", \\\"{x:1838,y:744,t:1527635583537};\\\", \\\"{x:1829,y:740,t:1527635583554};\\\", \\\"{x:1813,y:733,t:1527635583570};\\\", \\\"{x:1770,y:717,t:1527635583586};\\\", \\\"{x:1737,y:706,t:1527635583604};\\\", \\\"{x:1701,y:698,t:1527635583620};\\\", \\\"{x:1645,y:690,t:1527635583637};\\\", \\\"{x:1614,y:685,t:1527635583654};\\\", \\\"{x:1576,y:685,t:1527635583670};\\\", \\\"{x:1506,y:685,t:1527635583686};\\\", \\\"{x:1437,y:685,t:1527635583703};\\\", \\\"{x:1377,y:694,t:1527635583720};\\\", \\\"{x:1345,y:705,t:1527635583737};\\\", \\\"{x:1326,y:714,t:1527635583754};\\\", \\\"{x:1317,y:722,t:1527635583770};\\\", \\\"{x:1312,y:732,t:1527635583787};\\\", \\\"{x:1312,y:734,t:1527635583804};\\\", \\\"{x:1311,y:736,t:1527635583820};\\\", \\\"{x:1310,y:737,t:1527635583850};\\\", \\\"{x:1309,y:737,t:1527635583930};\\\", \\\"{x:1308,y:738,t:1527635583938};\\\", \\\"{x:1307,y:738,t:1527635583953};\\\", \\\"{x:1305,y:739,t:1527635583969};\\\", \\\"{x:1295,y:740,t:1527635583987};\\\", \\\"{x:1284,y:741,t:1527635584003};\\\", \\\"{x:1274,y:741,t:1527635584020};\\\", \\\"{x:1269,y:741,t:1527635584036};\\\", \\\"{x:1265,y:741,t:1527635584053};\\\", \\\"{x:1264,y:740,t:1527635584070};\\\", \\\"{x:1264,y:738,t:1527635584122};\\\", \\\"{x:1263,y:738,t:1527635584136};\\\", \\\"{x:1261,y:735,t:1527635584153};\\\", \\\"{x:1260,y:732,t:1527635584170};\\\", \\\"{x:1259,y:731,t:1527635584186};\\\", \\\"{x:1258,y:728,t:1527635584204};\\\", \\\"{x:1258,y:725,t:1527635584221};\\\", \\\"{x:1257,y:722,t:1527635584237};\\\", \\\"{x:1257,y:719,t:1527635584253};\\\", \\\"{x:1257,y:717,t:1527635584270};\\\", \\\"{x:1256,y:716,t:1527635584286};\\\", \\\"{x:1256,y:714,t:1527635584304};\\\", \\\"{x:1255,y:714,t:1527635584321};\\\", \\\"{x:1255,y:712,t:1527635584336};\\\", \\\"{x:1254,y:712,t:1527635584353};\\\", \\\"{x:1254,y:711,t:1527635584370};\\\", \\\"{x:1254,y:710,t:1527635584394};\\\", \\\"{x:1253,y:709,t:1527635584498};\\\", \\\"{x:1252,y:709,t:1527635584691};\\\", \\\"{x:1250,y:709,t:1527635584714};\\\", \\\"{x:1249,y:709,t:1527635584722};\\\", \\\"{x:1248,y:708,t:1527635584736};\\\", \\\"{x:1246,y:708,t:1527635584761};\\\", \\\"{x:1245,y:708,t:1527635584778};\\\", \\\"{x:1244,y:708,t:1527635584794};\\\", \\\"{x:1243,y:708,t:1527635584803};\\\", \\\"{x:1242,y:707,t:1527635584850};\\\", \\\"{x:1243,y:704,t:1527635585362};\\\", \\\"{x:1245,y:703,t:1527635585370};\\\", \\\"{x:1251,y:700,t:1527635585388};\\\", \\\"{x:1255,y:698,t:1527635585404};\\\", \\\"{x:1260,y:697,t:1527635585421};\\\", \\\"{x:1263,y:696,t:1527635585438};\\\", \\\"{x:1265,y:695,t:1527635585453};\\\", \\\"{x:1268,y:694,t:1527635585471};\\\", \\\"{x:1269,y:693,t:1527635585488};\\\", \\\"{x:1271,y:693,t:1527635585504};\\\", \\\"{x:1272,y:693,t:1527635585521};\\\", \\\"{x:1275,y:691,t:1527635585538};\\\", \\\"{x:1278,y:691,t:1527635585554};\\\", \\\"{x:1283,y:691,t:1527635585571};\\\", \\\"{x:1290,y:693,t:1527635585587};\\\", \\\"{x:1297,y:698,t:1527635585604};\\\", \\\"{x:1305,y:703,t:1527635585621};\\\", \\\"{x:1310,y:706,t:1527635585638};\\\", \\\"{x:1315,y:710,t:1527635585654};\\\", \\\"{x:1319,y:712,t:1527635585671};\\\", \\\"{x:1321,y:713,t:1527635585688};\\\", \\\"{x:1323,y:714,t:1527635585703};\\\", \\\"{x:1324,y:715,t:1527635585721};\\\", \\\"{x:1325,y:716,t:1527635585778};\\\", \\\"{x:1325,y:717,t:1527635585818};\\\", \\\"{x:1325,y:718,t:1527635585826};\\\", \\\"{x:1322,y:720,t:1527635585838};\\\", \\\"{x:1310,y:721,t:1527635585853};\\\", \\\"{x:1286,y:721,t:1527635585871};\\\", \\\"{x:1262,y:719,t:1527635585888};\\\", \\\"{x:1239,y:716,t:1527635585904};\\\", \\\"{x:1216,y:711,t:1527635585921};\\\", \\\"{x:1184,y:707,t:1527635585938};\\\", \\\"{x:1167,y:705,t:1527635585954};\\\", \\\"{x:1158,y:703,t:1527635585971};\\\", \\\"{x:1156,y:703,t:1527635585988};\\\", \\\"{x:1163,y:703,t:1527635586082};\\\", \\\"{x:1176,y:703,t:1527635586090};\\\", \\\"{x:1193,y:703,t:1527635586104};\\\", \\\"{x:1234,y:706,t:1527635586121};\\\", \\\"{x:1306,y:711,t:1527635586138};\\\", \\\"{x:1341,y:712,t:1527635586154};\\\", \\\"{x:1355,y:713,t:1527635586171};\\\", \\\"{x:1362,y:715,t:1527635586188};\\\", \\\"{x:1353,y:715,t:1527635586290};\\\", \\\"{x:1336,y:712,t:1527635586304};\\\", \\\"{x:1281,y:708,t:1527635586321};\\\", \\\"{x:1206,y:701,t:1527635586337};\\\", \\\"{x:1157,y:697,t:1527635586353};\\\", \\\"{x:1143,y:697,t:1527635586371};\\\", \\\"{x:1141,y:697,t:1527635586387};\\\", \\\"{x:1143,y:697,t:1527635586442};\\\", \\\"{x:1149,y:697,t:1527635586455};\\\", \\\"{x:1173,y:697,t:1527635586471};\\\", \\\"{x:1202,y:701,t:1527635586488};\\\", \\\"{x:1234,y:703,t:1527635586504};\\\", \\\"{x:1263,y:706,t:1527635586521};\\\", \\\"{x:1289,y:707,t:1527635586538};\\\", \\\"{x:1292,y:707,t:1527635586554};\\\", \\\"{x:1293,y:707,t:1527635586570};\\\", \\\"{x:1290,y:707,t:1527635586650};\\\", \\\"{x:1280,y:706,t:1527635586658};\\\", \\\"{x:1267,y:705,t:1527635586671};\\\", \\\"{x:1247,y:701,t:1527635586688};\\\", \\\"{x:1230,y:700,t:1527635586704};\\\", \\\"{x:1222,y:699,t:1527635586721};\\\", \\\"{x:1221,y:698,t:1527635586738};\\\", \\\"{x:1222,y:698,t:1527635586810};\\\", \\\"{x:1229,y:698,t:1527635586820};\\\", \\\"{x:1246,y:701,t:1527635586838};\\\", \\\"{x:1266,y:703,t:1527635586854};\\\", \\\"{x:1283,y:706,t:1527635586871};\\\", \\\"{x:1289,y:707,t:1527635586888};\\\", \\\"{x:1292,y:707,t:1527635586904};\\\", \\\"{x:1288,y:707,t:1527635586994};\\\", \\\"{x:1277,y:705,t:1527635587005};\\\", \\\"{x:1259,y:701,t:1527635587021};\\\", \\\"{x:1228,y:699,t:1527635587038};\\\", \\\"{x:1206,y:699,t:1527635587055};\\\", \\\"{x:1199,y:699,t:1527635587071};\\\", \\\"{x:1197,y:699,t:1527635587088};\\\", \\\"{x:1198,y:699,t:1527635587146};\\\", \\\"{x:1205,y:699,t:1527635587155};\\\", \\\"{x:1224,y:702,t:1527635587172};\\\", \\\"{x:1258,y:703,t:1527635587187};\\\", \\\"{x:1281,y:705,t:1527635587205};\\\", \\\"{x:1309,y:707,t:1527635587222};\\\", \\\"{x:1325,y:707,t:1527635587237};\\\", \\\"{x:1338,y:707,t:1527635587255};\\\", \\\"{x:1345,y:707,t:1527635587272};\\\", \\\"{x:1350,y:707,t:1527635587287};\\\", \\\"{x:1353,y:707,t:1527635587305};\\\", \\\"{x:1354,y:707,t:1527635587322};\\\", \\\"{x:1350,y:707,t:1527635587370};\\\", \\\"{x:1333,y:705,t:1527635587388};\\\", \\\"{x:1303,y:704,t:1527635587405};\\\", \\\"{x:1275,y:704,t:1527635587422};\\\", \\\"{x:1264,y:704,t:1527635587438};\\\", \\\"{x:1249,y:704,t:1527635587455};\\\", \\\"{x:1244,y:704,t:1527635587472};\\\", \\\"{x:1248,y:704,t:1527635587546};\\\", \\\"{x:1252,y:705,t:1527635587555};\\\", \\\"{x:1269,y:706,t:1527635587572};\\\", \\\"{x:1294,y:708,t:1527635587588};\\\", \\\"{x:1316,y:708,t:1527635587605};\\\", \\\"{x:1331,y:710,t:1527635587622};\\\", \\\"{x:1336,y:710,t:1527635587637};\\\", \\\"{x:1337,y:710,t:1527635587655};\\\", \\\"{x:1330,y:710,t:1527635587779};\\\", \\\"{x:1318,y:709,t:1527635587789};\\\", \\\"{x:1271,y:708,t:1527635587805};\\\", \\\"{x:1233,y:708,t:1527635587823};\\\", \\\"{x:1202,y:707,t:1527635587838};\\\", \\\"{x:1178,y:707,t:1527635587855};\\\", \\\"{x:1167,y:707,t:1527635587872};\\\", \\\"{x:1166,y:707,t:1527635587888};\\\", \\\"{x:1164,y:708,t:1527635587905};\\\", \\\"{x:1163,y:709,t:1527635587938};\\\", \\\"{x:1163,y:711,t:1527635587955};\\\", \\\"{x:1163,y:715,t:1527635587972};\\\", \\\"{x:1164,y:723,t:1527635587989};\\\", \\\"{x:1172,y:735,t:1527635588005};\\\", \\\"{x:1182,y:750,t:1527635588022};\\\", \\\"{x:1194,y:768,t:1527635588038};\\\", \\\"{x:1216,y:785,t:1527635588055};\\\", \\\"{x:1233,y:801,t:1527635588072};\\\", \\\"{x:1246,y:808,t:1527635588088};\\\", \\\"{x:1252,y:814,t:1527635588105};\\\", \\\"{x:1261,y:819,t:1527635588122};\\\", \\\"{x:1264,y:822,t:1527635588138};\\\", \\\"{x:1268,y:824,t:1527635588155};\\\", \\\"{x:1272,y:825,t:1527635588171};\\\", \\\"{x:1276,y:825,t:1527635588189};\\\", \\\"{x:1277,y:825,t:1527635588205};\\\", \\\"{x:1277,y:824,t:1527635588226};\\\", \\\"{x:1277,y:821,t:1527635588238};\\\", \\\"{x:1277,y:818,t:1527635588255};\\\", \\\"{x:1277,y:815,t:1527635588272};\\\", \\\"{x:1278,y:813,t:1527635588289};\\\", \\\"{x:1278,y:812,t:1527635588305};\\\", \\\"{x:1279,y:811,t:1527635588354};\\\", \\\"{x:1280,y:811,t:1527635588362};\\\", \\\"{x:1284,y:811,t:1527635588372};\\\", \\\"{x:1289,y:811,t:1527635588389};\\\", \\\"{x:1298,y:811,t:1527635588405};\\\", \\\"{x:1307,y:815,t:1527635588422};\\\", \\\"{x:1317,y:820,t:1527635588439};\\\", \\\"{x:1329,y:824,t:1527635588455};\\\", \\\"{x:1336,y:825,t:1527635588471};\\\", \\\"{x:1338,y:825,t:1527635588489};\\\", \\\"{x:1339,y:825,t:1527635588562};\\\", \\\"{x:1340,y:825,t:1527635588594};\\\", \\\"{x:1340,y:824,t:1527635588605};\\\", \\\"{x:1340,y:820,t:1527635588622};\\\", \\\"{x:1340,y:816,t:1527635588639};\\\", \\\"{x:1340,y:813,t:1527635588655};\\\", \\\"{x:1340,y:806,t:1527635588672};\\\", \\\"{x:1342,y:800,t:1527635588689};\\\", \\\"{x:1342,y:789,t:1527635588705};\\\", \\\"{x:1342,y:773,t:1527635588722};\\\", \\\"{x:1342,y:758,t:1527635588738};\\\", \\\"{x:1342,y:743,t:1527635588754};\\\", \\\"{x:1342,y:725,t:1527635588771};\\\", \\\"{x:1343,y:700,t:1527635588789};\\\", \\\"{x:1343,y:669,t:1527635588805};\\\", \\\"{x:1344,y:648,t:1527635588822};\\\", \\\"{x:1344,y:622,t:1527635588839};\\\", \\\"{x:1344,y:605,t:1527635588855};\\\", \\\"{x:1344,y:590,t:1527635588872};\\\", \\\"{x:1344,y:578,t:1527635588889};\\\", \\\"{x:1344,y:571,t:1527635588905};\\\", \\\"{x:1344,y:562,t:1527635588922};\\\", \\\"{x:1344,y:559,t:1527635588939};\\\", \\\"{x:1344,y:555,t:1527635588955};\\\", \\\"{x:1344,y:553,t:1527635588972};\\\", \\\"{x:1343,y:551,t:1527635588989};\\\", \\\"{x:1343,y:550,t:1527635589010};\\\", \\\"{x:1342,y:548,t:1527635589026};\\\", \\\"{x:1342,y:547,t:1527635589042};\\\", \\\"{x:1341,y:547,t:1527635589055};\\\", \\\"{x:1340,y:545,t:1527635589072};\\\", \\\"{x:1339,y:543,t:1527635589089};\\\", \\\"{x:1337,y:541,t:1527635589106};\\\", \\\"{x:1334,y:538,t:1527635589122};\\\", \\\"{x:1330,y:536,t:1527635589139};\\\", \\\"{x:1325,y:534,t:1527635589155};\\\", \\\"{x:1316,y:530,t:1527635589172};\\\", \\\"{x:1308,y:527,t:1527635589189};\\\", \\\"{x:1304,y:525,t:1527635589205};\\\", \\\"{x:1298,y:521,t:1527635589222};\\\", \\\"{x:1295,y:521,t:1527635589239};\\\", \\\"{x:1293,y:520,t:1527635589256};\\\", \\\"{x:1292,y:519,t:1527635589272};\\\", \\\"{x:1291,y:518,t:1527635589289};\\\", \\\"{x:1290,y:517,t:1527635589306};\\\", \\\"{x:1289,y:516,t:1527635589337};\\\", \\\"{x:1289,y:515,t:1527635589378};\\\", \\\"{x:1289,y:514,t:1527635589389};\\\", \\\"{x:1288,y:513,t:1527635589417};\\\", \\\"{x:1288,y:512,t:1527635589450};\\\", \\\"{x:1288,y:511,t:1527635589458};\\\", \\\"{x:1287,y:511,t:1527635589474};\\\", \\\"{x:1286,y:510,t:1527635589498};\\\", \\\"{x:1285,y:509,t:1527635589570};\\\", \\\"{x:1285,y:508,t:1527635589675};\\\", \\\"{x:1284,y:507,t:1527635589731};\\\", \\\"{x:1283,y:507,t:1527635589754};\\\", \\\"{x:1282,y:507,t:1527635595122};\\\", \\\"{x:1280,y:508,t:1527635595130};\\\", \\\"{x:1278,y:509,t:1527635595141};\\\", \\\"{x:1274,y:511,t:1527635595158};\\\", \\\"{x:1272,y:511,t:1527635595174};\\\", \\\"{x:1269,y:513,t:1527635595191};\\\", \\\"{x:1267,y:515,t:1527635595208};\\\", \\\"{x:1262,y:518,t:1527635595224};\\\", \\\"{x:1256,y:549,t:1527635595241};\\\", \\\"{x:1248,y:585,t:1527635595258};\\\", \\\"{x:1244,y:600,t:1527635595274};\\\", \\\"{x:1241,y:610,t:1527635595291};\\\", \\\"{x:1241,y:615,t:1527635595308};\\\", \\\"{x:1240,y:621,t:1527635595324};\\\", \\\"{x:1237,y:627,t:1527635595341};\\\", \\\"{x:1237,y:629,t:1527635595358};\\\", \\\"{x:1237,y:635,t:1527635595373};\\\", \\\"{x:1236,y:638,t:1527635595391};\\\", \\\"{x:1236,y:644,t:1527635595408};\\\", \\\"{x:1236,y:648,t:1527635595424};\\\", \\\"{x:1239,y:657,t:1527635595441};\\\", \\\"{x:1248,y:680,t:1527635595457};\\\", \\\"{x:1257,y:693,t:1527635595474};\\\", \\\"{x:1265,y:706,t:1527635595491};\\\", \\\"{x:1270,y:713,t:1527635595508};\\\", \\\"{x:1276,y:718,t:1527635595524};\\\", \\\"{x:1281,y:726,t:1527635595541};\\\", \\\"{x:1290,y:737,t:1527635595558};\\\", \\\"{x:1302,y:750,t:1527635595574};\\\", \\\"{x:1313,y:757,t:1527635595591};\\\", \\\"{x:1319,y:762,t:1527635595608};\\\", \\\"{x:1322,y:764,t:1527635595623};\\\", \\\"{x:1322,y:761,t:1527635595722};\\\", \\\"{x:1322,y:755,t:1527635595730};\\\", \\\"{x:1322,y:752,t:1527635595742};\\\", \\\"{x:1322,y:743,t:1527635595758};\\\", \\\"{x:1322,y:736,t:1527635595774};\\\", \\\"{x:1320,y:733,t:1527635595791};\\\", \\\"{x:1320,y:729,t:1527635595808};\\\", \\\"{x:1320,y:727,t:1527635595824};\\\", \\\"{x:1320,y:725,t:1527635595841};\\\", \\\"{x:1320,y:721,t:1527635595858};\\\", \\\"{x:1320,y:720,t:1527635595874};\\\", \\\"{x:1320,y:719,t:1527635595891};\\\", \\\"{x:1320,y:718,t:1527635595914};\\\", \\\"{x:1320,y:717,t:1527635595930};\\\", \\\"{x:1320,y:716,t:1527635595962};\\\", \\\"{x:1321,y:716,t:1527635595978};\\\", \\\"{x:1321,y:714,t:1527635596602};\\\", \\\"{x:1321,y:700,t:1527635596610};\\\", \\\"{x:1321,y:678,t:1527635596625};\\\", \\\"{x:1321,y:636,t:1527635596641};\\\", \\\"{x:1321,y:607,t:1527635596658};\\\", \\\"{x:1319,y:597,t:1527635596675};\\\", \\\"{x:1317,y:581,t:1527635596692};\\\", \\\"{x:1317,y:571,t:1527635596708};\\\", \\\"{x:1316,y:564,t:1527635596725};\\\", \\\"{x:1316,y:558,t:1527635596741};\\\", \\\"{x:1316,y:552,t:1527635596759};\\\", \\\"{x:1316,y:546,t:1527635596775};\\\", \\\"{x:1318,y:544,t:1527635596791};\\\", \\\"{x:1318,y:541,t:1527635596808};\\\", \\\"{x:1318,y:536,t:1527635596825};\\\", \\\"{x:1318,y:530,t:1527635596841};\\\", \\\"{x:1318,y:519,t:1527635596858};\\\", \\\"{x:1318,y:515,t:1527635596875};\\\", \\\"{x:1318,y:512,t:1527635596892};\\\", \\\"{x:1317,y:510,t:1527635596908};\\\", \\\"{x:1314,y:507,t:1527635596926};\\\", \\\"{x:1311,y:503,t:1527635596942};\\\", \\\"{x:1308,y:499,t:1527635596958};\\\", \\\"{x:1304,y:495,t:1527635596975};\\\", \\\"{x:1298,y:491,t:1527635596992};\\\", \\\"{x:1292,y:489,t:1527635597009};\\\", \\\"{x:1291,y:488,t:1527635597025};\\\", \\\"{x:1289,y:488,t:1527635597042};\\\", \\\"{x:1287,y:486,t:1527635597058};\\\", \\\"{x:1285,y:485,t:1527635597075};\\\", \\\"{x:1284,y:485,t:1527635597106};\\\", \\\"{x:1282,y:485,t:1527635598186};\\\", \\\"{x:1279,y:486,t:1527635598194};\\\", \\\"{x:1278,y:487,t:1527635598209};\\\", \\\"{x:1277,y:487,t:1527635598226};\\\", \\\"{x:1277,y:488,t:1527635598243};\\\", \\\"{x:1276,y:488,t:1527635598259};\\\", \\\"{x:1275,y:489,t:1527635598276};\\\", \\\"{x:1274,y:495,t:1527635598292};\\\", \\\"{x:1273,y:499,t:1527635598310};\\\", \\\"{x:1272,y:501,t:1527635598325};\\\", \\\"{x:1272,y:504,t:1527635598342};\\\", \\\"{x:1271,y:506,t:1527635598359};\\\", \\\"{x:1271,y:507,t:1527635598377};\\\", \\\"{x:1270,y:507,t:1527635598392};\\\", \\\"{x:1270,y:510,t:1527635598409};\\\", \\\"{x:1270,y:513,t:1527635598425};\\\", \\\"{x:1270,y:517,t:1527635598442};\\\", \\\"{x:1268,y:521,t:1527635598459};\\\", \\\"{x:1268,y:523,t:1527635598475};\\\", \\\"{x:1267,y:525,t:1527635598492};\\\", \\\"{x:1267,y:527,t:1527635598509};\\\", \\\"{x:1267,y:530,t:1527635598525};\\\", \\\"{x:1267,y:532,t:1527635598542};\\\", \\\"{x:1267,y:535,t:1527635598559};\\\", \\\"{x:1267,y:538,t:1527635598575};\\\", \\\"{x:1267,y:541,t:1527635598593};\\\", \\\"{x:1267,y:543,t:1527635598609};\\\", \\\"{x:1267,y:547,t:1527635598625};\\\", \\\"{x:1267,y:554,t:1527635598642};\\\", \\\"{x:1267,y:558,t:1527635598659};\\\", \\\"{x:1269,y:567,t:1527635598675};\\\", \\\"{x:1273,y:575,t:1527635598692};\\\", \\\"{x:1275,y:583,t:1527635598709};\\\", \\\"{x:1277,y:594,t:1527635598725};\\\", \\\"{x:1278,y:603,t:1527635598742};\\\", \\\"{x:1281,y:613,t:1527635598759};\\\", \\\"{x:1283,y:619,t:1527635598775};\\\", \\\"{x:1283,y:625,t:1527635598793};\\\", \\\"{x:1286,y:635,t:1527635598809};\\\", \\\"{x:1286,y:643,t:1527635598826};\\\", \\\"{x:1290,y:651,t:1527635598842};\\\", \\\"{x:1290,y:658,t:1527635598859};\\\", \\\"{x:1291,y:667,t:1527635598876};\\\", \\\"{x:1291,y:674,t:1527635598893};\\\", \\\"{x:1291,y:685,t:1527635598910};\\\", \\\"{x:1292,y:691,t:1527635598926};\\\", \\\"{x:1292,y:696,t:1527635598942};\\\", \\\"{x:1292,y:703,t:1527635598960};\\\", \\\"{x:1292,y:708,t:1527635598977};\\\", \\\"{x:1292,y:715,t:1527635598993};\\\", \\\"{x:1292,y:719,t:1527635599009};\\\", \\\"{x:1292,y:726,t:1527635599025};\\\", \\\"{x:1292,y:729,t:1527635599042};\\\", \\\"{x:1292,y:730,t:1527635599059};\\\", \\\"{x:1291,y:731,t:1527635599076};\\\", \\\"{x:1291,y:732,t:1527635599092};\\\", \\\"{x:1290,y:734,t:1527635599113};\\\", \\\"{x:1290,y:735,t:1527635599129};\\\", \\\"{x:1288,y:736,t:1527635599146};\\\", \\\"{x:1288,y:737,t:1527635599162};\\\", \\\"{x:1286,y:737,t:1527635599185};\\\", \\\"{x:1285,y:739,t:1527635599193};\\\", \\\"{x:1284,y:739,t:1527635599209};\\\", \\\"{x:1275,y:742,t:1527635599225};\\\", \\\"{x:1261,y:742,t:1527635599242};\\\", \\\"{x:1249,y:743,t:1527635599259};\\\", \\\"{x:1245,y:743,t:1527635599276};\\\", \\\"{x:1244,y:743,t:1527635599292};\\\", \\\"{x:1243,y:743,t:1527635599369};\\\", \\\"{x:1242,y:744,t:1527635599385};\\\", \\\"{x:1242,y:745,t:1527635599418};\\\", \\\"{x:1241,y:745,t:1527635599425};\\\", \\\"{x:1241,y:746,t:1527635599521};\\\", \\\"{x:1241,y:748,t:1527635599546};\\\", \\\"{x:1241,y:749,t:1527635599562};\\\", \\\"{x:1241,y:751,t:1527635599577};\\\", \\\"{x:1241,y:752,t:1527635599592};\\\", \\\"{x:1241,y:754,t:1527635599609};\\\", \\\"{x:1241,y:758,t:1527635599625};\\\", \\\"{x:1241,y:761,t:1527635599642};\\\", \\\"{x:1240,y:765,t:1527635599659};\\\", \\\"{x:1237,y:769,t:1527635599676};\\\", \\\"{x:1234,y:772,t:1527635599692};\\\", \\\"{x:1233,y:774,t:1527635599709};\\\", \\\"{x:1231,y:777,t:1527635599726};\\\", \\\"{x:1229,y:779,t:1527635599744};\\\", \\\"{x:1227,y:780,t:1527635599759};\\\", \\\"{x:1225,y:782,t:1527635599776};\\\", \\\"{x:1224,y:782,t:1527635599794};\\\", \\\"{x:1224,y:783,t:1527635599857};\\\", \\\"{x:1224,y:784,t:1527635599882};\\\", \\\"{x:1222,y:786,t:1527635599892};\\\", \\\"{x:1220,y:786,t:1527635599922};\\\", \\\"{x:1219,y:787,t:1527635599946};\\\", \\\"{x:1215,y:789,t:1527635599986};\\\", \\\"{x:1214,y:789,t:1527635600001};\\\", \\\"{x:1213,y:790,t:1527635600009};\\\", \\\"{x:1211,y:790,t:1527635600026};\\\", \\\"{x:1209,y:791,t:1527635600044};\\\", \\\"{x:1208,y:792,t:1527635600059};\\\", \\\"{x:1206,y:793,t:1527635600077};\\\", \\\"{x:1205,y:793,t:1527635600093};\\\", \\\"{x:1204,y:794,t:1527635600109};\\\", \\\"{x:1203,y:795,t:1527635600153};\\\", \\\"{x:1201,y:795,t:1527635600210};\\\", \\\"{x:1200,y:795,t:1527635600282};\\\", \\\"{x:1198,y:794,t:1527635600293};\\\", \\\"{x:1195,y:791,t:1527635600309};\\\", \\\"{x:1192,y:788,t:1527635600326};\\\", \\\"{x:1190,y:785,t:1527635600343};\\\", \\\"{x:1189,y:784,t:1527635600359};\\\", \\\"{x:1188,y:783,t:1527635600385};\\\", \\\"{x:1188,y:782,t:1527635600401};\\\", \\\"{x:1188,y:781,t:1527635600417};\\\", \\\"{x:1188,y:779,t:1527635600450};\\\", \\\"{x:1188,y:778,t:1527635600474};\\\", \\\"{x:1189,y:778,t:1527635600498};\\\", \\\"{x:1190,y:777,t:1527635600521};\\\", \\\"{x:1191,y:776,t:1527635600529};\\\", \\\"{x:1193,y:775,t:1527635600562};\\\", \\\"{x:1195,y:775,t:1527635600586};\\\", \\\"{x:1195,y:774,t:1527635600593};\\\", \\\"{x:1196,y:773,t:1527635600642};\\\", \\\"{x:1197,y:773,t:1527635600665};\\\", \\\"{x:1198,y:772,t:1527635600676};\\\", \\\"{x:1200,y:772,t:1527635600693};\\\", \\\"{x:1201,y:771,t:1527635600709};\\\", \\\"{x:1203,y:770,t:1527635600729};\\\", \\\"{x:1204,y:770,t:1527635600785};\\\", \\\"{x:1205,y:770,t:1527635600801};\\\", \\\"{x:1206,y:770,t:1527635600817};\\\", \\\"{x:1206,y:769,t:1527635600826};\\\", \\\"{x:1208,y:769,t:1527635600844};\\\", \\\"{x:1209,y:768,t:1527635600860};\\\", \\\"{x:1210,y:768,t:1527635600877};\\\", \\\"{x:1212,y:768,t:1527635600893};\\\", \\\"{x:1213,y:768,t:1527635600910};\\\", \\\"{x:1214,y:768,t:1527635600926};\\\", \\\"{x:1216,y:768,t:1527635600943};\\\", \\\"{x:1218,y:768,t:1527635600960};\\\", \\\"{x:1220,y:768,t:1527635600976};\\\", \\\"{x:1225,y:768,t:1527635600993};\\\", \\\"{x:1234,y:768,t:1527635601010};\\\", \\\"{x:1239,y:768,t:1527635601026};\\\", \\\"{x:1242,y:768,t:1527635601043};\\\", \\\"{x:1243,y:768,t:1527635601073};\\\", \\\"{x:1244,y:768,t:1527635601138};\\\", \\\"{x:1245,y:768,t:1527635601162};\\\", \\\"{x:1245,y:767,t:1527635601210};\\\", \\\"{x:1246,y:767,t:1527635601362};\\\", \\\"{x:1248,y:765,t:1527635603290};\\\", \\\"{x:1250,y:765,t:1527635603298};\\\", \\\"{x:1251,y:765,t:1527635603310};\\\", \\\"{x:1252,y:763,t:1527635603327};\\\", \\\"{x:1254,y:761,t:1527635603345};\\\", \\\"{x:1259,y:756,t:1527635603360};\\\", \\\"{x:1265,y:735,t:1527635603377};\\\", \\\"{x:1271,y:717,t:1527635603394};\\\", \\\"{x:1279,y:691,t:1527635603410};\\\", \\\"{x:1286,y:666,t:1527635603428};\\\", \\\"{x:1288,y:646,t:1527635603445};\\\", \\\"{x:1290,y:631,t:1527635603460};\\\", \\\"{x:1292,y:619,t:1527635603478};\\\", \\\"{x:1292,y:604,t:1527635603494};\\\", \\\"{x:1295,y:590,t:1527635603510};\\\", \\\"{x:1296,y:579,t:1527635603527};\\\", \\\"{x:1296,y:573,t:1527635603544};\\\", \\\"{x:1296,y:566,t:1527635603560};\\\", \\\"{x:1297,y:559,t:1527635603577};\\\", \\\"{x:1297,y:555,t:1527635603594};\\\", \\\"{x:1297,y:552,t:1527635603611};\\\", \\\"{x:1297,y:548,t:1527635603627};\\\", \\\"{x:1297,y:547,t:1527635603644};\\\", \\\"{x:1297,y:541,t:1527635603662};\\\", \\\"{x:1295,y:536,t:1527635603677};\\\", \\\"{x:1295,y:534,t:1527635603694};\\\", \\\"{x:1295,y:532,t:1527635603712};\\\", \\\"{x:1294,y:530,t:1527635603727};\\\", \\\"{x:1293,y:529,t:1527635603744};\\\", \\\"{x:1293,y:524,t:1527635603761};\\\", \\\"{x:1292,y:519,t:1527635603777};\\\", \\\"{x:1292,y:516,t:1527635603794};\\\", \\\"{x:1289,y:512,t:1527635603811};\\\", \\\"{x:1289,y:510,t:1527635603828};\\\", \\\"{x:1287,y:509,t:1527635603845};\\\", \\\"{x:1287,y:507,t:1527635603862};\\\", \\\"{x:1286,y:505,t:1527635603877};\\\", \\\"{x:1286,y:504,t:1527635603894};\\\", \\\"{x:1285,y:503,t:1527635603913};\\\", \\\"{x:1284,y:502,t:1527635603930};\\\", \\\"{x:1284,y:501,t:1527635603954};\\\", \\\"{x:1283,y:500,t:1527635604009};\\\", \\\"{x:1285,y:499,t:1527635607274};\\\", \\\"{x:1287,y:497,t:1527635607281};\\\", \\\"{x:1290,y:495,t:1527635607296};\\\", \\\"{x:1291,y:495,t:1527635607312};\\\", \\\"{x:1292,y:495,t:1527635607328};\\\", \\\"{x:1294,y:494,t:1527635607345};\\\", \\\"{x:1295,y:494,t:1527635607434};\\\", \\\"{x:1296,y:494,t:1527635607449};\\\", \\\"{x:1297,y:493,t:1527635607462};\\\", \\\"{x:1298,y:492,t:1527635607479};\\\", \\\"{x:1299,y:492,t:1527635607497};\\\", \\\"{x:1300,y:492,t:1527635607512};\\\", \\\"{x:1301,y:492,t:1527635607538};\\\", \\\"{x:1302,y:492,t:1527635607545};\\\", \\\"{x:1305,y:492,t:1527635607562};\\\", \\\"{x:1323,y:496,t:1527635607578};\\\", \\\"{x:1337,y:501,t:1527635607595};\\\", \\\"{x:1354,y:508,t:1527635607612};\\\", \\\"{x:1369,y:512,t:1527635607628};\\\", \\\"{x:1375,y:513,t:1527635607646};\\\", \\\"{x:1377,y:514,t:1527635607662};\\\", \\\"{x:1378,y:514,t:1527635607682};\\\", \\\"{x:1378,y:515,t:1527635607833};\\\", \\\"{x:1376,y:515,t:1527635607846};\\\", \\\"{x:1374,y:515,t:1527635607862};\\\", \\\"{x:1373,y:515,t:1527635607880};\\\", \\\"{x:1370,y:515,t:1527635607896};\\\", \\\"{x:1369,y:515,t:1527635607921};\\\", \\\"{x:1368,y:515,t:1527635607970};\\\", \\\"{x:1367,y:515,t:1527635608026};\\\", \\\"{x:1368,y:514,t:1527635608186};\\\", \\\"{x:1371,y:514,t:1527635608195};\\\", \\\"{x:1375,y:512,t:1527635608213};\\\", \\\"{x:1377,y:511,t:1527635608229};\\\", \\\"{x:1379,y:510,t:1527635608246};\\\", \\\"{x:1381,y:510,t:1527635608263};\\\", \\\"{x:1383,y:510,t:1527635608289};\\\", \\\"{x:1385,y:509,t:1527635608305};\\\", \\\"{x:1385,y:508,t:1527635608321};\\\", \\\"{x:1386,y:508,t:1527635608329};\\\", \\\"{x:1389,y:508,t:1527635608345};\\\", \\\"{x:1394,y:508,t:1527635608363};\\\", \\\"{x:1396,y:508,t:1527635608380};\\\", \\\"{x:1398,y:508,t:1527635608395};\\\", \\\"{x:1399,y:508,t:1527635608594};\\\", \\\"{x:1401,y:508,t:1527635608618};\\\", \\\"{x:1403,y:508,t:1527635608633};\\\", \\\"{x:1404,y:508,t:1527635608666};\\\", \\\"{x:1406,y:508,t:1527635608680};\\\", \\\"{x:1407,y:508,t:1527635608698};\\\", \\\"{x:1409,y:508,t:1527635608714};\\\", \\\"{x:1411,y:506,t:1527635608730};\\\", \\\"{x:1412,y:506,t:1527635608753};\\\", \\\"{x:1413,y:506,t:1527635608762};\\\", \\\"{x:1414,y:506,t:1527635608779};\\\", \\\"{x:1416,y:505,t:1527635608797};\\\", \\\"{x:1420,y:505,t:1527635608813};\\\", \\\"{x:1426,y:505,t:1527635608830};\\\", \\\"{x:1431,y:505,t:1527635608846};\\\", \\\"{x:1436,y:505,t:1527635608863};\\\", \\\"{x:1446,y:505,t:1527635608880};\\\", \\\"{x:1458,y:505,t:1527635608897};\\\", \\\"{x:1466,y:503,t:1527635608912};\\\", \\\"{x:1475,y:503,t:1527635608930};\\\", \\\"{x:1480,y:501,t:1527635608947};\\\", \\\"{x:1484,y:501,t:1527635608963};\\\", \\\"{x:1485,y:501,t:1527635608979};\\\", \\\"{x:1486,y:501,t:1527635609010};\\\", \\\"{x:1487,y:501,t:1527635609034};\\\", \\\"{x:1488,y:501,t:1527635609090};\\\", \\\"{x:1488,y:504,t:1527635609306};\\\", \\\"{x:1488,y:505,t:1527635609313};\\\", \\\"{x:1489,y:505,t:1527635609330};\\\", \\\"{x:1489,y:506,t:1527635609347};\\\", \\\"{x:1489,y:507,t:1527635609377};\\\", \\\"{x:1491,y:508,t:1527635609394};\\\", \\\"{x:1493,y:509,t:1527635609409};\\\", \\\"{x:1497,y:511,t:1527635609418};\\\", \\\"{x:1498,y:511,t:1527635609429};\\\", \\\"{x:1507,y:513,t:1527635609447};\\\", \\\"{x:1517,y:513,t:1527635609463};\\\", \\\"{x:1524,y:513,t:1527635609480};\\\", \\\"{x:1528,y:513,t:1527635609497};\\\", \\\"{x:1531,y:513,t:1527635609513};\\\", \\\"{x:1532,y:513,t:1527635609530};\\\", \\\"{x:1534,y:513,t:1527635609547};\\\", \\\"{x:1535,y:513,t:1527635609563};\\\", \\\"{x:1537,y:513,t:1527635609609};\\\", \\\"{x:1538,y:512,t:1527635609642};\\\", \\\"{x:1539,y:512,t:1527635609689};\\\", \\\"{x:1539,y:511,t:1527635609826};\\\", \\\"{x:1540,y:511,t:1527635609841};\\\", \\\"{x:1541,y:510,t:1527635609881};\\\", \\\"{x:1543,y:510,t:1527635610370};\\\", \\\"{x:1544,y:510,t:1527635610379};\\\", \\\"{x:1548,y:508,t:1527635610397};\\\", \\\"{x:1551,y:507,t:1527635610414};\\\", \\\"{x:1553,y:507,t:1527635610430};\\\", \\\"{x:1559,y:507,t:1527635610446};\\\", \\\"{x:1563,y:507,t:1527635610463};\\\", \\\"{x:1565,y:507,t:1527635610479};\\\", \\\"{x:1569,y:507,t:1527635610496};\\\", \\\"{x:1575,y:507,t:1527635610513};\\\", \\\"{x:1578,y:507,t:1527635610529};\\\", \\\"{x:1581,y:507,t:1527635610547};\\\", \\\"{x:1583,y:507,t:1527635610564};\\\", \\\"{x:1584,y:507,t:1527635610580};\\\", \\\"{x:1585,y:507,t:1527635610596};\\\", \\\"{x:1586,y:507,t:1527635610614};\\\", \\\"{x:1587,y:507,t:1527635610630};\\\", \\\"{x:1591,y:507,t:1527635610647};\\\", \\\"{x:1592,y:507,t:1527635610664};\\\", \\\"{x:1595,y:506,t:1527635610681};\\\", \\\"{x:1596,y:505,t:1527635610697};\\\", \\\"{x:1598,y:505,t:1527635610714};\\\", \\\"{x:1599,y:505,t:1527635610731};\\\", \\\"{x:1600,y:505,t:1527635610747};\\\", \\\"{x:1601,y:505,t:1527635610763};\\\", \\\"{x:1602,y:505,t:1527635611729};\\\", \\\"{x:1603,y:505,t:1527635611737};\\\", \\\"{x:1606,y:505,t:1527635611748};\\\", \\\"{x:1606,y:504,t:1527635611769};\\\", \\\"{x:1607,y:503,t:1527635611786};\\\", \\\"{x:1609,y:503,t:1527635611809};\\\", \\\"{x:1610,y:503,t:1527635611817};\\\", \\\"{x:1611,y:503,t:1527635611830};\\\", \\\"{x:1616,y:503,t:1527635611848};\\\", \\\"{x:1624,y:503,t:1527635611864};\\\", \\\"{x:1629,y:505,t:1527635611881};\\\", \\\"{x:1639,y:506,t:1527635611898};\\\", \\\"{x:1642,y:507,t:1527635611914};\\\", \\\"{x:1645,y:507,t:1527635611931};\\\", \\\"{x:1647,y:508,t:1527635611948};\\\", \\\"{x:1648,y:508,t:1527635611969};\\\", \\\"{x:1649,y:508,t:1527635611980};\\\", \\\"{x:1651,y:508,t:1527635611998};\\\", \\\"{x:1654,y:509,t:1527635612014};\\\", \\\"{x:1656,y:509,t:1527635612033};\\\", \\\"{x:1657,y:509,t:1527635612047};\\\", \\\"{x:1659,y:510,t:1527635612065};\\\", \\\"{x:1661,y:510,t:1527635612080};\\\", \\\"{x:1666,y:510,t:1527635612097};\\\", \\\"{x:1668,y:510,t:1527635612114};\\\", \\\"{x:1671,y:510,t:1527635612130};\\\", \\\"{x:1673,y:512,t:1527635612148};\\\", \\\"{x:1674,y:512,t:1527635612164};\\\", \\\"{x:1675,y:512,t:1527635612181};\\\", \\\"{x:1676,y:512,t:1527635612198};\\\", \\\"{x:1678,y:512,t:1527635612218};\\\", \\\"{x:1678,y:513,t:1527635612762};\\\", \\\"{x:1671,y:517,t:1527635612769};\\\", \\\"{x:1663,y:519,t:1527635612781};\\\", \\\"{x:1646,y:525,t:1527635612798};\\\", \\\"{x:1623,y:533,t:1527635612815};\\\", \\\"{x:1595,y:538,t:1527635612831};\\\", \\\"{x:1553,y:542,t:1527635612847};\\\", \\\"{x:1493,y:547,t:1527635612864};\\\", \\\"{x:1404,y:547,t:1527635612881};\\\", \\\"{x:1240,y:549,t:1527635612897};\\\", \\\"{x:1138,y:549,t:1527635612915};\\\", \\\"{x:1020,y:555,t:1527635612931};\\\", \\\"{x:923,y:557,t:1527635612948};\\\", \\\"{x:861,y:557,t:1527635612965};\\\", \\\"{x:848,y:557,t:1527635612981};\\\", \\\"{x:847,y:557,t:1527635612993};\\\", \\\"{x:851,y:557,t:1527635613058};\\\", \\\"{x:860,y:557,t:1527635613065};\\\", \\\"{x:871,y:557,t:1527635613077};\\\", \\\"{x:889,y:557,t:1527635613093};\\\", \\\"{x:911,y:557,t:1527635613110};\\\", \\\"{x:939,y:557,t:1527635613127};\\\", \\\"{x:972,y:557,t:1527635613144};\\\", \\\"{x:1003,y:555,t:1527635613161};\\\", \\\"{x:1034,y:550,t:1527635613177};\\\", \\\"{x:1065,y:545,t:1527635613193};\\\", \\\"{x:1083,y:542,t:1527635613210};\\\", \\\"{x:1107,y:540,t:1527635613227};\\\", \\\"{x:1137,y:538,t:1527635613243};\\\", \\\"{x:1167,y:532,t:1527635613260};\\\", \\\"{x:1200,y:527,t:1527635613277};\\\", \\\"{x:1225,y:520,t:1527635613294};\\\", \\\"{x:1247,y:517,t:1527635613310};\\\", \\\"{x:1261,y:514,t:1527635613328};\\\", \\\"{x:1269,y:512,t:1527635613344};\\\", \\\"{x:1276,y:510,t:1527635613360};\\\", \\\"{x:1281,y:508,t:1527635613377};\\\", \\\"{x:1289,y:507,t:1527635613393};\\\", \\\"{x:1291,y:506,t:1527635613409};\\\", \\\"{x:1295,y:504,t:1527635613427};\\\", \\\"{x:1292,y:504,t:1527635613642};\\\", \\\"{x:1290,y:504,t:1527635613649};\\\", \\\"{x:1286,y:504,t:1527635613660};\\\", \\\"{x:1282,y:505,t:1527635613677};\\\", \\\"{x:1279,y:506,t:1527635613693};\\\", \\\"{x:1277,y:506,t:1527635613710};\\\", \\\"{x:1273,y:507,t:1527635613727};\\\", \\\"{x:1269,y:509,t:1527635613744};\\\", \\\"{x:1260,y:511,t:1527635613760};\\\", \\\"{x:1240,y:514,t:1527635613777};\\\", \\\"{x:1199,y:521,t:1527635613794};\\\", \\\"{x:1151,y:528,t:1527635613810};\\\", \\\"{x:1090,y:528,t:1527635613827};\\\", \\\"{x:1011,y:532,t:1527635613844};\\\", \\\"{x:933,y:532,t:1527635613860};\\\", \\\"{x:865,y:528,t:1527635613877};\\\", \\\"{x:783,y:522,t:1527635613895};\\\", \\\"{x:733,y:516,t:1527635613911};\\\", \\\"{x:706,y:516,t:1527635613929};\\\", \\\"{x:689,y:516,t:1527635613945};\\\", \\\"{x:679,y:516,t:1527635613961};\\\", \\\"{x:650,y:513,t:1527635613978};\\\", \\\"{x:624,y:509,t:1527635613994};\\\", \\\"{x:594,y:506,t:1527635614011};\\\", \\\"{x:568,y:502,t:1527635614028};\\\", \\\"{x:529,y:496,t:1527635614044};\\\", \\\"{x:477,y:491,t:1527635614062};\\\", \\\"{x:435,y:489,t:1527635614077};\\\", \\\"{x:379,y:483,t:1527635614095};\\\", \\\"{x:330,y:480,t:1527635614111};\\\", \\\"{x:308,y:474,t:1527635614127};\\\", \\\"{x:288,y:473,t:1527635614145};\\\", \\\"{x:282,y:473,t:1527635614161};\\\", \\\"{x:280,y:473,t:1527635614177};\\\", \\\"{x:280,y:471,t:1527635614258};\\\", \\\"{x:288,y:467,t:1527635614266};\\\", \\\"{x:293,y:466,t:1527635614277};\\\", \\\"{x:312,y:460,t:1527635614295};\\\", \\\"{x:324,y:456,t:1527635614311};\\\", \\\"{x:332,y:454,t:1527635614328};\\\", \\\"{x:340,y:454,t:1527635614345};\\\", \\\"{x:361,y:454,t:1527635614362};\\\", \\\"{x:378,y:454,t:1527635614378};\\\", \\\"{x:396,y:454,t:1527635614395};\\\", \\\"{x:414,y:452,t:1527635614411};\\\", \\\"{x:431,y:452,t:1527635614428};\\\", \\\"{x:454,y:452,t:1527635614445};\\\", \\\"{x:480,y:452,t:1527635614461};\\\", \\\"{x:509,y:451,t:1527635614479};\\\", \\\"{x:529,y:450,t:1527635614495};\\\", \\\"{x:549,y:446,t:1527635614512};\\\", \\\"{x:559,y:445,t:1527635614527};\\\", \\\"{x:569,y:444,t:1527635614545};\\\", \\\"{x:573,y:444,t:1527635614562};\\\", \\\"{x:575,y:444,t:1527635614625};\\\", \\\"{x:576,y:444,t:1527635614641};\\\", \\\"{x:577,y:444,t:1527635614649};\\\", \\\"{x:579,y:444,t:1527635614662};\\\", \\\"{x:586,y:444,t:1527635614677};\\\", \\\"{x:594,y:444,t:1527635614695};\\\", \\\"{x:600,y:444,t:1527635614712};\\\", \\\"{x:607,y:444,t:1527635614728};\\\", \\\"{x:614,y:445,t:1527635614745};\\\", \\\"{x:628,y:447,t:1527635614762};\\\", \\\"{x:633,y:447,t:1527635614778};\\\", \\\"{x:636,y:447,t:1527635614795};\\\", \\\"{x:638,y:447,t:1527635614929};\\\", \\\"{x:637,y:447,t:1527635614961};\\\", \\\"{x:632,y:447,t:1527635614977};\\\", \\\"{x:629,y:447,t:1527635614995};\\\", \\\"{x:627,y:447,t:1527635615012};\\\", \\\"{x:624,y:447,t:1527635615028};\\\", \\\"{x:623,y:446,t:1527635615513};\\\", \\\"{x:622,y:446,t:1527635616073};\\\", \\\"{x:624,y:446,t:1527635616106};\\\", \\\"{x:625,y:445,t:1527635616114};\\\", \\\"{x:627,y:445,t:1527635616153};\\\", \\\"{x:628,y:445,t:1527635616178};\\\", \\\"{x:630,y:445,t:1527635616193};\\\", \\\"{x:630,y:446,t:1527635616481};\\\", \\\"{x:630,y:455,t:1527635616496};\\\", \\\"{x:624,y:473,t:1527635616514};\\\", \\\"{x:613,y:492,t:1527635616529};\\\", \\\"{x:608,y:500,t:1527635616546};\\\", \\\"{x:602,y:508,t:1527635616563};\\\", \\\"{x:599,y:511,t:1527635616581};\\\", \\\"{x:594,y:514,t:1527635616596};\\\", \\\"{x:591,y:516,t:1527635616613};\\\", \\\"{x:588,y:519,t:1527635616630};\\\", \\\"{x:587,y:519,t:1527635616646};\\\", \\\"{x:585,y:521,t:1527635616663};\\\", \\\"{x:584,y:522,t:1527635616690};\\\", \\\"{x:583,y:523,t:1527635616713};\\\", \\\"{x:590,y:521,t:1527635617649};\\\", \\\"{x:608,y:514,t:1527635617663};\\\", \\\"{x:678,y:515,t:1527635617680};\\\", \\\"{x:769,y:525,t:1527635617697};\\\", \\\"{x:885,y:533,t:1527635617714};\\\", \\\"{x:933,y:541,t:1527635617732};\\\", \\\"{x:977,y:550,t:1527635617747};\\\", \\\"{x:1007,y:555,t:1527635617765};\\\", \\\"{x:1035,y:556,t:1527635617781};\\\", \\\"{x:1061,y:556,t:1527635617798};\\\", \\\"{x:1084,y:557,t:1527635617814};\\\", \\\"{x:1104,y:561,t:1527635617832};\\\", \\\"{x:1122,y:567,t:1527635617848};\\\", \\\"{x:1135,y:572,t:1527635617864};\\\", \\\"{x:1141,y:574,t:1527635617882};\\\", \\\"{x:1145,y:575,t:1527635617898};\\\", \\\"{x:1147,y:575,t:1527635618090};\\\", \\\"{x:1148,y:575,t:1527635618106};\\\", \\\"{x:1149,y:575,t:1527635618121};\\\", \\\"{x:1151,y:575,t:1527635618131};\\\", \\\"{x:1153,y:574,t:1527635618148};\\\", \\\"{x:1155,y:573,t:1527635618165};\\\", \\\"{x:1158,y:572,t:1527635618182};\\\", \\\"{x:1159,y:571,t:1527635618209};\\\", \\\"{x:1157,y:572,t:1527635618266};\\\", \\\"{x:1144,y:576,t:1527635618282};\\\", \\\"{x:1134,y:576,t:1527635618299};\\\", \\\"{x:1133,y:577,t:1527635618498};\\\", \\\"{x:1132,y:578,t:1527635618538};\\\", \\\"{x:1131,y:578,t:1527635618562};\\\", \\\"{x:1130,y:579,t:1527635618569};\\\", \\\"{x:1127,y:580,t:1527635618582};\\\", \\\"{x:1124,y:581,t:1527635618599};\\\", \\\"{x:1122,y:581,t:1527635618616};\\\", \\\"{x:1118,y:585,t:1527635618633};\\\", \\\"{x:1117,y:585,t:1527635618649};\\\", \\\"{x:1113,y:587,t:1527635618666};\\\", \\\"{x:1109,y:589,t:1527635618683};\\\", \\\"{x:1104,y:591,t:1527635618698};\\\", \\\"{x:1097,y:594,t:1527635618715};\\\", \\\"{x:1088,y:596,t:1527635618733};\\\", \\\"{x:1074,y:600,t:1527635618749};\\\", \\\"{x:1063,y:602,t:1527635618766};\\\", \\\"{x:1054,y:605,t:1527635618783};\\\", \\\"{x:1037,y:606,t:1527635618800};\\\", \\\"{x:1000,y:614,t:1527635618816};\\\", \\\"{x:922,y:627,t:1527635618833};\\\", \\\"{x:809,y:641,t:1527635618849};\\\", \\\"{x:762,y:649,t:1527635618866};\\\", \\\"{x:736,y:653,t:1527635618883};\\\", \\\"{x:730,y:653,t:1527635618900};\\\", \\\"{x:728,y:653,t:1527635618916};\\\", \\\"{x:727,y:653,t:1527635618937};\\\", \\\"{x:725,y:653,t:1527635619042};\\\", \\\"{x:721,y:654,t:1527635619050};\\\", \\\"{x:712,y:658,t:1527635619067};\\\", \\\"{x:698,y:669,t:1527635619083};\\\", \\\"{x:680,y:680,t:1527635619100};\\\", \\\"{x:662,y:686,t:1527635619117};\\\", \\\"{x:639,y:697,t:1527635619133};\\\", \\\"{x:620,y:701,t:1527635619150};\\\", \\\"{x:601,y:706,t:1527635619167};\\\", \\\"{x:588,y:708,t:1527635619184};\\\", \\\"{x:580,y:711,t:1527635619200};\\\", \\\"{x:577,y:712,t:1527635619217};\\\", \\\"{x:575,y:712,t:1527635619305};\\\", \\\"{x:574,y:712,t:1527635619317};\\\", \\\"{x:568,y:711,t:1527635619334};\\\", \\\"{x:560,y:706,t:1527635619351};\\\", \\\"{x:546,y:702,t:1527635619367};\\\", \\\"{x:525,y:699,t:1527635619385};\\\", \\\"{x:499,y:689,t:1527635619401};\\\", \\\"{x:489,y:684,t:1527635619416};\\\", \\\"{x:486,y:681,t:1527635619431};\\\", \\\"{x:482,y:679,t:1527635619449};\\\", \\\"{x:480,y:678,t:1527635619466};\\\", \\\"{x:479,y:677,t:1527635619529};\\\" ] }, { \\\"rt\\\": 40956, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 574732, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"8FE87\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -03 PM-B -I -I -I -I -I -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:479,y:673,t:1527635626569};\\\", \\\"{x:498,y:662,t:1527635626578};\\\", \\\"{x:509,y:658,t:1527635626587};\\\", \\\"{x:525,y:653,t:1527635626604};\\\", \\\"{x:531,y:650,t:1527635626621};\\\", \\\"{x:536,y:649,t:1527635626639};\\\", \\\"{x:540,y:647,t:1527635626654};\\\", \\\"{x:542,y:647,t:1527635626671};\\\", \\\"{x:543,y:647,t:1527635626688};\\\", \\\"{x:546,y:646,t:1527635626704};\\\", \\\"{x:554,y:643,t:1527635626721};\\\", \\\"{x:558,y:641,t:1527635626738};\\\", \\\"{x:562,y:639,t:1527635626754};\\\", \\\"{x:566,y:635,t:1527635626771};\\\", \\\"{x:569,y:632,t:1527635626788};\\\", \\\"{x:570,y:631,t:1527635626805};\\\", \\\"{x:570,y:630,t:1527635626833};\\\", \\\"{x:570,y:629,t:1527635626849};\\\", \\\"{x:571,y:629,t:1527635626857};\\\", \\\"{x:573,y:628,t:1527635626872};\\\", \\\"{x:576,y:627,t:1527635626888};\\\", \\\"{x:579,y:624,t:1527635626904};\\\", \\\"{x:581,y:622,t:1527635626921};\\\", \\\"{x:582,y:622,t:1527635626938};\\\", \\\"{x:583,y:621,t:1527635626955};\\\", \\\"{x:584,y:621,t:1527635626971};\\\", \\\"{x:589,y:617,t:1527635626988};\\\", \\\"{x:595,y:614,t:1527635627005};\\\", \\\"{x:604,y:612,t:1527635627021};\\\", \\\"{x:609,y:610,t:1527635627038};\\\", \\\"{x:614,y:609,t:1527635627055};\\\", \\\"{x:619,y:608,t:1527635627071};\\\", \\\"{x:632,y:606,t:1527635627089};\\\", \\\"{x:647,y:605,t:1527635627105};\\\", \\\"{x:656,y:604,t:1527635627122};\\\", \\\"{x:660,y:604,t:1527635627138};\\\", \\\"{x:661,y:604,t:1527635627156};\\\", \\\"{x:662,y:604,t:1527635627171};\\\", \\\"{x:664,y:604,t:1527635627188};\\\", \\\"{x:665,y:604,t:1527635627206};\\\", \\\"{x:666,y:604,t:1527635627233};\\\", \\\"{x:668,y:604,t:1527635627258};\\\", \\\"{x:669,y:605,t:1527635627281};\\\", \\\"{x:670,y:608,t:1527635627289};\\\", \\\"{x:671,y:612,t:1527635627305};\\\", \\\"{x:672,y:613,t:1527635627322};\\\", \\\"{x:672,y:614,t:1527635627338};\\\", \\\"{x:672,y:617,t:1527635627355};\\\", \\\"{x:673,y:617,t:1527635627745};\\\", \\\"{x:673,y:618,t:1527635627761};\\\", \\\"{x:673,y:619,t:1527635627825};\\\", \\\"{x:671,y:620,t:1527635627857};\\\", \\\"{x:670,y:620,t:1527635627872};\\\", \\\"{x:668,y:621,t:1527635627889};\\\", \\\"{x:667,y:622,t:1527635627913};\\\", \\\"{x:665,y:623,t:1527635627945};\\\", \\\"{x:664,y:623,t:1527635627961};\\\", \\\"{x:662,y:625,t:1527635627972};\\\", \\\"{x:660,y:626,t:1527635627989};\\\", \\\"{x:656,y:628,t:1527635628005};\\\", \\\"{x:652,y:629,t:1527635628022};\\\", \\\"{x:650,y:630,t:1527635628039};\\\", \\\"{x:647,y:632,t:1527635628057};\\\", \\\"{x:644,y:633,t:1527635628072};\\\", \\\"{x:632,y:638,t:1527635628089};\\\", \\\"{x:625,y:642,t:1527635628107};\\\", \\\"{x:619,y:644,t:1527635628122};\\\", \\\"{x:615,y:646,t:1527635628139};\\\", \\\"{x:614,y:646,t:1527635628169};\\\", \\\"{x:613,y:646,t:1527635628362};\\\", \\\"{x:612,y:646,t:1527635629443};\\\", \\\"{x:610,y:645,t:1527635629586};\\\", \\\"{x:608,y:645,t:1527635629594};\\\", \\\"{x:604,y:644,t:1527635629608};\\\", \\\"{x:597,y:640,t:1527635629625};\\\", \\\"{x:594,y:640,t:1527635629640};\\\", \\\"{x:589,y:637,t:1527635629658};\\\", \\\"{x:586,y:635,t:1527635629675};\\\", \\\"{x:584,y:633,t:1527635629691};\\\", \\\"{x:582,y:632,t:1527635629707};\\\", \\\"{x:578,y:628,t:1527635629724};\\\", \\\"{x:575,y:626,t:1527635629741};\\\", \\\"{x:571,y:624,t:1527635629758};\\\", \\\"{x:568,y:622,t:1527635629774};\\\", \\\"{x:561,y:617,t:1527635629790};\\\", \\\"{x:546,y:609,t:1527635629807};\\\", \\\"{x:527,y:601,t:1527635629824};\\\", \\\"{x:511,y:593,t:1527635629840};\\\", \\\"{x:492,y:581,t:1527635629858};\\\", \\\"{x:474,y:569,t:1527635629875};\\\", \\\"{x:456,y:559,t:1527635629891};\\\", \\\"{x:437,y:544,t:1527635629908};\\\", \\\"{x:420,y:533,t:1527635629924};\\\", \\\"{x:408,y:526,t:1527635629940};\\\", \\\"{x:397,y:520,t:1527635629957};\\\", \\\"{x:394,y:518,t:1527635629974};\\\", \\\"{x:391,y:516,t:1527635629990};\\\", \\\"{x:391,y:514,t:1527635630009};\\\", \\\"{x:391,y:512,t:1527635630023};\\\", \\\"{x:391,y:504,t:1527635630041};\\\", \\\"{x:396,y:491,t:1527635630057};\\\", \\\"{x:398,y:480,t:1527635630074};\\\", \\\"{x:401,y:472,t:1527635630091};\\\", \\\"{x:403,y:468,t:1527635630107};\\\", \\\"{x:404,y:465,t:1527635630123};\\\", \\\"{x:406,y:462,t:1527635630140};\\\", \\\"{x:409,y:458,t:1527635630158};\\\", \\\"{x:414,y:455,t:1527635630174};\\\", \\\"{x:421,y:451,t:1527635630191};\\\", \\\"{x:427,y:448,t:1527635630208};\\\", \\\"{x:430,y:446,t:1527635630224};\\\", \\\"{x:433,y:444,t:1527635630240};\\\", \\\"{x:435,y:444,t:1527635630257};\\\", \\\"{x:439,y:442,t:1527635630278};\\\", \\\"{x:442,y:439,t:1527635630294};\\\", \\\"{x:447,y:435,t:1527635630311};\\\", \\\"{x:450,y:433,t:1527635630328};\\\", \\\"{x:454,y:432,t:1527635630343};\\\", \\\"{x:457,y:431,t:1527635630361};\\\", \\\"{x:461,y:429,t:1527635630378};\\\", \\\"{x:468,y:426,t:1527635630394};\\\", \\\"{x:473,y:424,t:1527635630411};\\\", \\\"{x:480,y:421,t:1527635630428};\\\", \\\"{x:491,y:415,t:1527635630445};\\\", \\\"{x:508,y:411,t:1527635630460};\\\", \\\"{x:542,y:410,t:1527635630477};\\\", \\\"{x:560,y:407,t:1527635630495};\\\", \\\"{x:582,y:407,t:1527635630512};\\\", \\\"{x:604,y:407,t:1527635630528};\\\", \\\"{x:628,y:405,t:1527635630545};\\\", \\\"{x:646,y:405,t:1527635630562};\\\", \\\"{x:660,y:404,t:1527635630578};\\\", \\\"{x:667,y:404,t:1527635630594};\\\", \\\"{x:673,y:404,t:1527635630612};\\\", \\\"{x:691,y:404,t:1527635630627};\\\", \\\"{x:726,y:414,t:1527635630645};\\\", \\\"{x:750,y:422,t:1527635630662};\\\", \\\"{x:774,y:431,t:1527635630679};\\\", \\\"{x:795,y:441,t:1527635630695};\\\", \\\"{x:815,y:449,t:1527635630712};\\\", \\\"{x:827,y:455,t:1527635630729};\\\", \\\"{x:838,y:464,t:1527635630745};\\\", \\\"{x:849,y:472,t:1527635630761};\\\", \\\"{x:854,y:479,t:1527635630778};\\\", \\\"{x:854,y:482,t:1527635630794};\\\", \\\"{x:854,y:484,t:1527635630811};\\\", \\\"{x:853,y:484,t:1527635631045};\\\", \\\"{x:843,y:484,t:1527635631061};\\\", \\\"{x:828,y:484,t:1527635631078};\\\", \\\"{x:813,y:484,t:1527635631095};\\\", \\\"{x:794,y:484,t:1527635631111};\\\", \\\"{x:772,y:482,t:1527635631128};\\\", \\\"{x:750,y:478,t:1527635631145};\\\", \\\"{x:723,y:474,t:1527635631163};\\\", \\\"{x:671,y:462,t:1527635631179};\\\", \\\"{x:630,y:452,t:1527635631195};\\\", \\\"{x:592,y:445,t:1527635631212};\\\", \\\"{x:562,y:434,t:1527635631228};\\\", \\\"{x:543,y:424,t:1527635631245};\\\", \\\"{x:541,y:421,t:1527635631262};\\\", \\\"{x:539,y:420,t:1527635631277};\\\", \\\"{x:539,y:419,t:1527635631295};\\\", \\\"{x:538,y:418,t:1527635631312};\\\", \\\"{x:538,y:417,t:1527635631328};\\\", \\\"{x:538,y:416,t:1527635631345};\\\", \\\"{x:536,y:414,t:1527635631373};\\\", \\\"{x:536,y:412,t:1527635631452};\\\", \\\"{x:537,y:411,t:1527635631997};\\\", \\\"{x:539,y:410,t:1527635632012};\\\", \\\"{x:544,y:408,t:1527635632029};\\\", \\\"{x:550,y:407,t:1527635632045};\\\", \\\"{x:552,y:406,t:1527635632062};\\\", \\\"{x:557,y:406,t:1527635632079};\\\", \\\"{x:565,y:404,t:1527635632095};\\\", \\\"{x:575,y:404,t:1527635632112};\\\", \\\"{x:584,y:404,t:1527635632129};\\\", \\\"{x:599,y:407,t:1527635632145};\\\", \\\"{x:614,y:410,t:1527635632162};\\\", \\\"{x:627,y:411,t:1527635632179};\\\", \\\"{x:640,y:416,t:1527635632195};\\\", \\\"{x:651,y:418,t:1527635632212};\\\", \\\"{x:664,y:422,t:1527635632228};\\\", \\\"{x:671,y:425,t:1527635632245};\\\", \\\"{x:676,y:429,t:1527635632262};\\\", \\\"{x:681,y:433,t:1527635632279};\\\", \\\"{x:685,y:437,t:1527635632295};\\\", \\\"{x:685,y:438,t:1527635632312};\\\", \\\"{x:685,y:441,t:1527635632329};\\\", \\\"{x:685,y:442,t:1527635632345};\\\", \\\"{x:691,y:442,t:1527635633309};\\\", \\\"{x:710,y:445,t:1527635633317};\\\", \\\"{x:743,y:445,t:1527635633329};\\\", \\\"{x:828,y:450,t:1527635633346};\\\", \\\"{x:934,y:452,t:1527635633364};\\\", \\\"{x:1046,y:460,t:1527635633381};\\\", \\\"{x:1233,y:468,t:1527635633396};\\\", \\\"{x:1339,y:472,t:1527635633413};\\\", \\\"{x:1439,y:488,t:1527635633430};\\\", \\\"{x:1548,y:504,t:1527635633448};\\\", \\\"{x:1645,y:534,t:1527635633462};\\\", \\\"{x:1712,y:554,t:1527635633480};\\\", \\\"{x:1744,y:564,t:1527635633497};\\\", \\\"{x:1758,y:569,t:1527635633513};\\\", \\\"{x:1765,y:572,t:1527635633530};\\\", \\\"{x:1767,y:574,t:1527635633547};\\\", \\\"{x:1769,y:576,t:1527635633564};\\\", \\\"{x:1770,y:577,t:1527635633605};\\\", \\\"{x:1770,y:579,t:1527635633628};\\\", \\\"{x:1770,y:581,t:1527635633645};\\\", \\\"{x:1770,y:582,t:1527635633652};\\\", \\\"{x:1768,y:587,t:1527635633663};\\\", \\\"{x:1760,y:592,t:1527635633680};\\\", \\\"{x:1750,y:600,t:1527635633697};\\\", \\\"{x:1737,y:607,t:1527635633714};\\\", \\\"{x:1716,y:613,t:1527635633730};\\\", \\\"{x:1677,y:624,t:1527635633747};\\\", \\\"{x:1639,y:629,t:1527635633764};\\\", \\\"{x:1608,y:631,t:1527635633781};\\\", \\\"{x:1531,y:636,t:1527635633797};\\\", \\\"{x:1494,y:638,t:1527635633814};\\\", \\\"{x:1476,y:639,t:1527635633830};\\\", \\\"{x:1463,y:640,t:1527635633848};\\\", \\\"{x:1454,y:641,t:1527635633864};\\\", \\\"{x:1450,y:643,t:1527635633880};\\\", \\\"{x:1448,y:643,t:1527635633897};\\\", \\\"{x:1446,y:644,t:1527635633914};\\\", \\\"{x:1436,y:647,t:1527635633930};\\\", \\\"{x:1420,y:652,t:1527635633947};\\\", \\\"{x:1399,y:657,t:1527635633964};\\\", \\\"{x:1384,y:659,t:1527635633980};\\\", \\\"{x:1374,y:663,t:1527635633997};\\\", \\\"{x:1369,y:665,t:1527635634014};\\\", \\\"{x:1369,y:666,t:1527635634036};\\\", \\\"{x:1369,y:667,t:1527635634048};\\\", \\\"{x:1369,y:668,t:1527635634064};\\\", \\\"{x:1368,y:671,t:1527635634081};\\\", \\\"{x:1368,y:672,t:1527635634097};\\\", \\\"{x:1367,y:674,t:1527635634114};\\\", \\\"{x:1366,y:680,t:1527635634131};\\\", \\\"{x:1366,y:683,t:1527635634147};\\\", \\\"{x:1366,y:686,t:1527635634164};\\\", \\\"{x:1365,y:689,t:1527635634181};\\\", \\\"{x:1364,y:693,t:1527635634196};\\\", \\\"{x:1364,y:695,t:1527635634214};\\\", \\\"{x:1364,y:697,t:1527635634231};\\\", \\\"{x:1363,y:701,t:1527635634247};\\\", \\\"{x:1362,y:703,t:1527635634264};\\\", \\\"{x:1361,y:705,t:1527635634281};\\\", \\\"{x:1360,y:705,t:1527635634309};\\\", \\\"{x:1360,y:706,t:1527635634316};\\\", \\\"{x:1359,y:707,t:1527635634333};\\\", \\\"{x:1358,y:708,t:1527635634380};\\\", \\\"{x:1357,y:709,t:1527635634398};\\\", \\\"{x:1355,y:709,t:1527635634445};\\\", \\\"{x:1353,y:709,t:1527635634453};\\\", \\\"{x:1351,y:710,t:1527635634463};\\\", \\\"{x:1350,y:710,t:1527635634481};\\\", \\\"{x:1348,y:710,t:1527635634498};\\\", \\\"{x:1346,y:710,t:1527635634514};\\\", \\\"{x:1345,y:710,t:1527635634531};\\\", \\\"{x:1345,y:715,t:1527635637701};\\\", \\\"{x:1345,y:722,t:1527635637718};\\\", \\\"{x:1344,y:726,t:1527635637735};\\\", \\\"{x:1344,y:729,t:1527635637751};\\\", \\\"{x:1344,y:732,t:1527635637768};\\\", \\\"{x:1344,y:734,t:1527635637785};\\\", \\\"{x:1344,y:737,t:1527635637801};\\\", \\\"{x:1344,y:741,t:1527635637817};\\\", \\\"{x:1344,y:744,t:1527635637835};\\\", \\\"{x:1344,y:748,t:1527635637851};\\\", \\\"{x:1344,y:752,t:1527635637867};\\\", \\\"{x:1344,y:755,t:1527635637884};\\\", \\\"{x:1344,y:759,t:1527635637901};\\\", \\\"{x:1344,y:763,t:1527635637918};\\\", \\\"{x:1344,y:771,t:1527635637934};\\\", \\\"{x:1346,y:785,t:1527635637952};\\\", \\\"{x:1349,y:795,t:1527635637967};\\\", \\\"{x:1354,y:806,t:1527635637985};\\\", \\\"{x:1357,y:815,t:1527635638001};\\\", \\\"{x:1360,y:824,t:1527635638019};\\\", \\\"{x:1365,y:836,t:1527635638035};\\\", \\\"{x:1368,y:847,t:1527635638051};\\\", \\\"{x:1370,y:857,t:1527635638069};\\\", \\\"{x:1371,y:861,t:1527635638084};\\\", \\\"{x:1371,y:862,t:1527635638101};\\\", \\\"{x:1370,y:862,t:1527635638366};\\\", \\\"{x:1367,y:860,t:1527635638485};\\\", \\\"{x:1366,y:855,t:1527635638501};\\\", \\\"{x:1365,y:851,t:1527635638518};\\\", \\\"{x:1364,y:846,t:1527635638536};\\\", \\\"{x:1364,y:844,t:1527635638551};\\\", \\\"{x:1364,y:838,t:1527635638568};\\\", \\\"{x:1363,y:833,t:1527635638585};\\\", \\\"{x:1363,y:826,t:1527635638601};\\\", \\\"{x:1363,y:818,t:1527635638618};\\\", \\\"{x:1363,y:809,t:1527635638636};\\\", \\\"{x:1363,y:802,t:1527635638651};\\\", \\\"{x:1362,y:797,t:1527635638668};\\\", \\\"{x:1361,y:791,t:1527635638685};\\\", \\\"{x:1361,y:783,t:1527635638703};\\\", \\\"{x:1361,y:777,t:1527635638718};\\\", \\\"{x:1359,y:770,t:1527635638735};\\\", \\\"{x:1359,y:765,t:1527635638752};\\\", \\\"{x:1358,y:761,t:1527635638768};\\\", \\\"{x:1355,y:757,t:1527635638786};\\\", \\\"{x:1354,y:753,t:1527635638803};\\\", \\\"{x:1352,y:749,t:1527635638818};\\\", \\\"{x:1350,y:743,t:1527635638835};\\\", \\\"{x:1346,y:734,t:1527635638853};\\\", \\\"{x:1344,y:729,t:1527635638868};\\\", \\\"{x:1342,y:726,t:1527635638885};\\\", \\\"{x:1340,y:725,t:1527635638902};\\\", \\\"{x:1340,y:723,t:1527635638919};\\\", \\\"{x:1339,y:722,t:1527635638935};\\\", \\\"{x:1339,y:720,t:1527635638952};\\\", \\\"{x:1337,y:717,t:1527635638968};\\\", \\\"{x:1337,y:716,t:1527635638985};\\\", \\\"{x:1337,y:714,t:1527635639004};\\\", \\\"{x:1337,y:712,t:1527635639044};\\\", \\\"{x:1338,y:711,t:1527635639060};\\\", \\\"{x:1339,y:711,t:1527635639069};\\\", \\\"{x:1341,y:711,t:1527635639086};\\\", \\\"{x:1343,y:710,t:1527635639102};\\\", \\\"{x:1344,y:710,t:1527635639119};\\\", \\\"{x:1344,y:709,t:1527635639140};\\\", \\\"{x:1345,y:709,t:1527635639476};\\\", \\\"{x:1346,y:708,t:1527635639492};\\\", \\\"{x:1348,y:707,t:1527635639557};\\\", \\\"{x:1349,y:707,t:1527635641781};\\\", \\\"{x:1350,y:707,t:1527635641829};\\\", \\\"{x:1351,y:707,t:1527635641844};\\\", \\\"{x:1352,y:707,t:1527635642013};\\\", \\\"{x:1354,y:706,t:1527635642061};\\\", \\\"{x:1355,y:706,t:1527635642197};\\\", \\\"{x:1356,y:705,t:1527635642205};\\\", \\\"{x:1357,y:705,t:1527635642222};\\\", \\\"{x:1358,y:704,t:1527635642239};\\\", \\\"{x:1361,y:704,t:1527635642255};\\\", \\\"{x:1362,y:703,t:1527635642273};\\\", \\\"{x:1365,y:702,t:1527635642289};\\\", \\\"{x:1377,y:703,t:1527635642306};\\\", \\\"{x:1393,y:707,t:1527635642322};\\\", \\\"{x:1411,y:711,t:1527635642338};\\\", \\\"{x:1425,y:713,t:1527635642355};\\\", \\\"{x:1440,y:715,t:1527635642372};\\\", \\\"{x:1447,y:717,t:1527635642389};\\\", \\\"{x:1451,y:717,t:1527635642405};\\\", \\\"{x:1452,y:717,t:1527635642429};\\\", \\\"{x:1452,y:716,t:1527635642605};\\\", \\\"{x:1450,y:716,t:1527635642613};\\\", \\\"{x:1448,y:716,t:1527635642622};\\\", \\\"{x:1444,y:713,t:1527635642640};\\\", \\\"{x:1440,y:712,t:1527635642655};\\\", \\\"{x:1438,y:710,t:1527635642673};\\\", \\\"{x:1437,y:710,t:1527635642689};\\\", \\\"{x:1435,y:708,t:1527635642706};\\\", \\\"{x:1434,y:708,t:1527635642722};\\\", \\\"{x:1433,y:708,t:1527635642740};\\\", \\\"{x:1432,y:707,t:1527635642755};\\\", \\\"{x:1430,y:706,t:1527635642773};\\\", \\\"{x:1429,y:706,t:1527635642790};\\\", \\\"{x:1428,y:706,t:1527635642813};\\\", \\\"{x:1428,y:705,t:1527635642823};\\\", \\\"{x:1427,y:705,t:1527635642839};\\\", \\\"{x:1425,y:704,t:1527635642855};\\\", \\\"{x:1424,y:704,t:1527635642892};\\\", \\\"{x:1421,y:704,t:1527635642989};\\\", \\\"{x:1419,y:706,t:1527635643012};\\\", \\\"{x:1419,y:707,t:1527635643022};\\\", \\\"{x:1415,y:709,t:1527635643039};\\\", \\\"{x:1414,y:713,t:1527635643056};\\\", \\\"{x:1412,y:714,t:1527635643073};\\\", \\\"{x:1412,y:715,t:1527635643090};\\\", \\\"{x:1411,y:715,t:1527635643106};\\\", \\\"{x:1411,y:716,t:1527635643123};\\\", \\\"{x:1410,y:716,t:1527635643139};\\\", \\\"{x:1412,y:716,t:1527635643557};\\\", \\\"{x:1415,y:715,t:1527635643574};\\\", \\\"{x:1417,y:713,t:1527635643589};\\\", \\\"{x:1419,y:712,t:1527635643607};\\\", \\\"{x:1419,y:711,t:1527635643628};\\\", \\\"{x:1421,y:710,t:1527635644957};\\\", \\\"{x:1426,y:708,t:1527635644965};\\\", \\\"{x:1432,y:705,t:1527635644975};\\\", \\\"{x:1441,y:701,t:1527635644992};\\\", \\\"{x:1456,y:701,t:1527635645007};\\\", \\\"{x:1465,y:701,t:1527635645024};\\\", \\\"{x:1467,y:701,t:1527635645041};\\\", \\\"{x:1471,y:701,t:1527635645058};\\\", \\\"{x:1475,y:701,t:1527635645074};\\\", \\\"{x:1478,y:701,t:1527635645092};\\\", \\\"{x:1486,y:701,t:1527635645108};\\\", \\\"{x:1488,y:701,t:1527635645125};\\\", \\\"{x:1491,y:701,t:1527635645142};\\\", \\\"{x:1492,y:701,t:1527635645213};\\\", \\\"{x:1493,y:700,t:1527635645341};\\\", \\\"{x:1492,y:700,t:1527635645372};\\\", \\\"{x:1491,y:700,t:1527635645380};\\\", \\\"{x:1495,y:700,t:1527635645701};\\\", \\\"{x:1500,y:701,t:1527635645708};\\\", \\\"{x:1508,y:702,t:1527635645725};\\\", \\\"{x:1521,y:704,t:1527635645742};\\\", \\\"{x:1530,y:706,t:1527635645759};\\\", \\\"{x:1538,y:707,t:1527635645775};\\\", \\\"{x:1551,y:710,t:1527635645793};\\\", \\\"{x:1563,y:711,t:1527635645809};\\\", \\\"{x:1570,y:713,t:1527635645826};\\\", \\\"{x:1571,y:713,t:1527635645843};\\\", \\\"{x:1570,y:711,t:1527635645989};\\\", \\\"{x:1565,y:710,t:1527635645996};\\\", \\\"{x:1557,y:709,t:1527635646009};\\\", \\\"{x:1551,y:705,t:1527635646026};\\\", \\\"{x:1549,y:705,t:1527635646043};\\\", \\\"{x:1548,y:705,t:1527635646058};\\\", \\\"{x:1547,y:705,t:1527635646852};\\\", \\\"{x:1547,y:706,t:1527635646861};\\\", \\\"{x:1547,y:708,t:1527635646877};\\\", \\\"{x:1548,y:710,t:1527635646893};\\\", \\\"{x:1548,y:719,t:1527635647613};\\\", \\\"{x:1548,y:731,t:1527635647628};\\\", \\\"{x:1546,y:753,t:1527635647644};\\\", \\\"{x:1541,y:784,t:1527635647661};\\\", \\\"{x:1541,y:800,t:1527635647678};\\\", \\\"{x:1541,y:815,t:1527635647694};\\\", \\\"{x:1541,y:830,t:1527635647710};\\\", \\\"{x:1537,y:845,t:1527635647728};\\\", \\\"{x:1531,y:855,t:1527635647744};\\\", \\\"{x:1526,y:863,t:1527635647760};\\\", \\\"{x:1522,y:873,t:1527635647778};\\\", \\\"{x:1522,y:880,t:1527635647793};\\\", \\\"{x:1522,y:887,t:1527635647811};\\\", \\\"{x:1522,y:891,t:1527635647828};\\\", \\\"{x:1522,y:899,t:1527635647843};\\\", \\\"{x:1524,y:904,t:1527635647860};\\\", \\\"{x:1526,y:907,t:1527635647877};\\\", \\\"{x:1527,y:908,t:1527635647894};\\\", \\\"{x:1528,y:909,t:1527635647911};\\\", \\\"{x:1529,y:910,t:1527635647927};\\\", \\\"{x:1531,y:911,t:1527635647944};\\\", \\\"{x:1533,y:912,t:1527635647961};\\\", \\\"{x:1536,y:914,t:1527635647977};\\\", \\\"{x:1538,y:915,t:1527635647995};\\\", \\\"{x:1541,y:917,t:1527635648010};\\\", \\\"{x:1543,y:918,t:1527635648028};\\\", \\\"{x:1545,y:919,t:1527635648044};\\\", \\\"{x:1546,y:919,t:1527635648060};\\\", \\\"{x:1547,y:919,t:1527635648092};\\\", \\\"{x:1548,y:918,t:1527635648244};\\\", \\\"{x:1549,y:913,t:1527635648261};\\\", \\\"{x:1550,y:904,t:1527635648278};\\\", \\\"{x:1551,y:896,t:1527635648295};\\\", \\\"{x:1553,y:888,t:1527635648311};\\\", \\\"{x:1553,y:884,t:1527635648327};\\\", \\\"{x:1553,y:878,t:1527635648345};\\\", \\\"{x:1553,y:872,t:1527635648361};\\\", \\\"{x:1553,y:860,t:1527635648378};\\\", \\\"{x:1553,y:851,t:1527635648395};\\\", \\\"{x:1553,y:842,t:1527635648412};\\\", \\\"{x:1553,y:839,t:1527635648428};\\\", \\\"{x:1555,y:830,t:1527635648444};\\\", \\\"{x:1555,y:828,t:1527635648462};\\\", \\\"{x:1555,y:824,t:1527635648477};\\\", \\\"{x:1555,y:819,t:1527635648495};\\\", \\\"{x:1553,y:810,t:1527635648511};\\\", \\\"{x:1551,y:801,t:1527635648528};\\\", \\\"{x:1551,y:796,t:1527635648545};\\\", \\\"{x:1550,y:791,t:1527635648561};\\\", \\\"{x:1549,y:787,t:1527635648578};\\\", \\\"{x:1547,y:783,t:1527635648595};\\\", \\\"{x:1547,y:779,t:1527635648612};\\\", \\\"{x:1547,y:769,t:1527635648629};\\\", \\\"{x:1545,y:765,t:1527635648644};\\\", \\\"{x:1545,y:764,t:1527635648662};\\\", \\\"{x:1545,y:761,t:1527635648678};\\\", \\\"{x:1545,y:759,t:1527635648694};\\\", \\\"{x:1545,y:758,t:1527635648712};\\\", \\\"{x:1545,y:755,t:1527635648729};\\\", \\\"{x:1545,y:752,t:1527635648744};\\\", \\\"{x:1545,y:751,t:1527635648764};\\\", \\\"{x:1545,y:749,t:1527635648780};\\\", \\\"{x:1545,y:748,t:1527635649125};\\\", \\\"{x:1545,y:746,t:1527635649260};\\\", \\\"{x:1544,y:745,t:1527635649725};\\\", \\\"{x:1540,y:743,t:1527635649732};\\\", \\\"{x:1537,y:743,t:1527635649746};\\\", \\\"{x:1529,y:741,t:1527635649763};\\\", \\\"{x:1517,y:737,t:1527635649779};\\\", \\\"{x:1504,y:736,t:1527635649796};\\\", \\\"{x:1495,y:734,t:1527635649812};\\\", \\\"{x:1490,y:732,t:1527635649829};\\\", \\\"{x:1485,y:732,t:1527635649846};\\\", \\\"{x:1479,y:731,t:1527635649862};\\\", \\\"{x:1469,y:730,t:1527635649880};\\\", \\\"{x:1456,y:728,t:1527635649896};\\\", \\\"{x:1442,y:726,t:1527635649912};\\\", \\\"{x:1426,y:723,t:1527635649930};\\\", \\\"{x:1412,y:722,t:1527635649945};\\\", \\\"{x:1399,y:720,t:1527635649963};\\\", \\\"{x:1388,y:718,t:1527635649980};\\\", \\\"{x:1376,y:717,t:1527635649996};\\\", \\\"{x:1370,y:717,t:1527635650012};\\\", \\\"{x:1363,y:717,t:1527635650029};\\\", \\\"{x:1358,y:717,t:1527635650047};\\\", \\\"{x:1356,y:717,t:1527635650063};\\\", \\\"{x:1354,y:717,t:1527635650079};\\\", \\\"{x:1353,y:717,t:1527635650097};\\\", \\\"{x:1351,y:716,t:1527635650180};\\\", \\\"{x:1350,y:716,t:1527635650220};\\\", \\\"{x:1349,y:716,t:1527635650300};\\\", \\\"{x:1349,y:715,t:1527635650324};\\\", \\\"{x:1349,y:714,t:1527635650405};\\\", \\\"{x:1349,y:713,t:1527635650428};\\\", \\\"{x:1349,y:712,t:1527635650443};\\\", \\\"{x:1350,y:712,t:1527635650451};\\\", \\\"{x:1350,y:711,t:1527635650532};\\\", \\\"{x:1349,y:711,t:1527635656004};\\\", \\\"{x:1345,y:711,t:1527635656019};\\\", \\\"{x:1336,y:713,t:1527635656036};\\\", \\\"{x:1332,y:716,t:1527635656052};\\\", \\\"{x:1320,y:717,t:1527635656069};\\\", \\\"{x:1305,y:718,t:1527635656086};\\\", \\\"{x:1293,y:718,t:1527635656102};\\\", \\\"{x:1284,y:718,t:1527635656119};\\\", \\\"{x:1279,y:718,t:1527635656136};\\\", \\\"{x:1278,y:718,t:1527635656221};\\\", \\\"{x:1277,y:719,t:1527635656236};\\\", \\\"{x:1275,y:719,t:1527635656252};\\\", \\\"{x:1269,y:720,t:1527635656269};\\\", \\\"{x:1264,y:720,t:1527635656285};\\\", \\\"{x:1259,y:721,t:1527635656301};\\\", \\\"{x:1252,y:721,t:1527635656319};\\\", \\\"{x:1246,y:721,t:1527635656336};\\\", \\\"{x:1239,y:721,t:1527635656352};\\\", \\\"{x:1229,y:721,t:1527635656368};\\\", \\\"{x:1223,y:721,t:1527635656386};\\\", \\\"{x:1219,y:721,t:1527635656402};\\\", \\\"{x:1217,y:721,t:1527635656419};\\\", \\\"{x:1216,y:721,t:1527635656436};\\\", \\\"{x:1215,y:721,t:1527635656700};\\\", \\\"{x:1214,y:721,t:1527635656749};\\\", \\\"{x:1213,y:720,t:1527635656756};\\\", \\\"{x:1211,y:720,t:1527635656769};\\\", \\\"{x:1207,y:718,t:1527635656786};\\\", \\\"{x:1203,y:718,t:1527635656803};\\\", \\\"{x:1197,y:716,t:1527635656821};\\\", \\\"{x:1190,y:716,t:1527635656836};\\\", \\\"{x:1180,y:715,t:1527635656853};\\\", \\\"{x:1176,y:714,t:1527635656871};\\\", \\\"{x:1173,y:712,t:1527635656886};\\\", \\\"{x:1172,y:712,t:1527635656903};\\\", \\\"{x:1171,y:712,t:1527635656941};\\\", \\\"{x:1170,y:711,t:1527635656954};\\\", \\\"{x:1169,y:711,t:1527635657132};\\\", \\\"{x:1169,y:710,t:1527635657148};\\\", \\\"{x:1169,y:709,t:1527635657220};\\\", \\\"{x:1171,y:708,t:1527635657245};\\\", \\\"{x:1172,y:708,t:1527635657267};\\\", \\\"{x:1174,y:707,t:1527635657309};\\\", \\\"{x:1175,y:706,t:1527635657324};\\\", \\\"{x:1176,y:706,t:1527635657340};\\\", \\\"{x:1176,y:705,t:1527635657353};\\\", \\\"{x:1177,y:705,t:1527635657370};\\\", \\\"{x:1179,y:705,t:1527635657387};\\\", \\\"{x:1180,y:705,t:1527635657403};\\\", \\\"{x:1182,y:703,t:1527635657420};\\\", \\\"{x:1183,y:703,t:1527635657468};\\\", \\\"{x:1184,y:703,t:1527635657516};\\\", \\\"{x:1185,y:702,t:1527635657532};\\\", \\\"{x:1187,y:702,t:1527635657557};\\\", \\\"{x:1188,y:701,t:1527635657589};\\\", \\\"{x:1189,y:700,t:1527635657604};\\\", \\\"{x:1190,y:699,t:1527635657620};\\\", \\\"{x:1193,y:698,t:1527635657637};\\\", \\\"{x:1195,y:696,t:1527635657654};\\\", \\\"{x:1197,y:696,t:1527635657670};\\\", \\\"{x:1201,y:690,t:1527635657687};\\\", \\\"{x:1207,y:671,t:1527635657704};\\\", \\\"{x:1218,y:649,t:1527635657720};\\\", \\\"{x:1225,y:634,t:1527635657737};\\\", \\\"{x:1235,y:619,t:1527635657754};\\\", \\\"{x:1240,y:608,t:1527635657770};\\\", \\\"{x:1244,y:599,t:1527635657787};\\\", \\\"{x:1250,y:589,t:1527635657804};\\\", \\\"{x:1253,y:582,t:1527635657820};\\\", \\\"{x:1257,y:575,t:1527635657837};\\\", \\\"{x:1257,y:573,t:1527635657854};\\\", \\\"{x:1257,y:572,t:1527635657877};\\\", \\\"{x:1254,y:572,t:1527635658084};\\\", \\\"{x:1252,y:572,t:1527635658092};\\\", \\\"{x:1249,y:574,t:1527635658104};\\\", \\\"{x:1245,y:576,t:1527635658121};\\\", \\\"{x:1240,y:588,t:1527635658138};\\\", \\\"{x:1236,y:598,t:1527635658154};\\\", \\\"{x:1231,y:611,t:1527635658171};\\\", \\\"{x:1224,y:627,t:1527635658188};\\\", \\\"{x:1221,y:631,t:1527635658204};\\\", \\\"{x:1220,y:636,t:1527635658222};\\\", \\\"{x:1219,y:640,t:1527635658238};\\\", \\\"{x:1218,y:645,t:1527635658254};\\\", \\\"{x:1218,y:649,t:1527635658272};\\\", \\\"{x:1218,y:654,t:1527635658288};\\\", \\\"{x:1218,y:658,t:1527635658304};\\\", \\\"{x:1218,y:660,t:1527635658322};\\\", \\\"{x:1219,y:660,t:1527635658597};\\\", \\\"{x:1219,y:661,t:1527635658620};\\\", \\\"{x:1219,y:662,t:1527635658668};\\\", \\\"{x:1217,y:664,t:1527635658677};\\\", \\\"{x:1212,y:665,t:1527635658688};\\\", \\\"{x:1202,y:670,t:1527635658706};\\\", \\\"{x:1190,y:675,t:1527635658721};\\\", \\\"{x:1179,y:678,t:1527635658739};\\\", \\\"{x:1166,y:679,t:1527635658755};\\\", \\\"{x:1154,y:683,t:1527635658771};\\\", \\\"{x:1145,y:685,t:1527635658788};\\\", \\\"{x:1143,y:687,t:1527635658805};\\\", \\\"{x:1141,y:688,t:1527635658821};\\\", \\\"{x:1140,y:688,t:1527635658892};\\\", \\\"{x:1139,y:688,t:1527635659013};\\\", \\\"{x:1139,y:691,t:1527635659022};\\\", \\\"{x:1153,y:701,t:1527635659038};\\\", \\\"{x:1168,y:707,t:1527635659055};\\\", \\\"{x:1181,y:712,t:1527635659072};\\\", \\\"{x:1187,y:714,t:1527635659088};\\\", \\\"{x:1189,y:716,t:1527635659106};\\\", \\\"{x:1190,y:717,t:1527635659122};\\\", \\\"{x:1190,y:715,t:1527635659332};\\\", \\\"{x:1188,y:713,t:1527635659340};\\\", \\\"{x:1186,y:711,t:1527635659356};\\\", \\\"{x:1179,y:706,t:1527635659372};\\\", \\\"{x:1176,y:704,t:1527635659389};\\\", \\\"{x:1175,y:703,t:1527635659406};\\\", \\\"{x:1172,y:703,t:1527635659820};\\\", \\\"{x:1170,y:703,t:1527635659828};\\\", \\\"{x:1170,y:704,t:1527635659839};\\\", \\\"{x:1169,y:706,t:1527635659860};\\\", \\\"{x:1169,y:707,t:1527635660173};\\\", \\\"{x:1169,y:708,t:1527635660228};\\\", \\\"{x:1169,y:709,t:1527635660239};\\\", \\\"{x:1169,y:710,t:1527635660333};\\\", \\\"{x:1169,y:711,t:1527635660364};\\\", \\\"{x:1170,y:711,t:1527635660420};\\\", \\\"{x:1170,y:712,t:1527635660445};\\\", \\\"{x:1171,y:712,t:1527635660876};\\\", \\\"{x:1172,y:712,t:1527635660890};\\\", \\\"{x:1173,y:712,t:1527635660907};\\\", \\\"{x:1174,y:712,t:1527635660923};\\\", \\\"{x:1175,y:712,t:1527635660941};\\\", \\\"{x:1177,y:711,t:1527635660958};\\\", \\\"{x:1177,y:710,t:1527635660973};\\\", \\\"{x:1179,y:709,t:1527635662028};\\\", \\\"{x:1183,y:708,t:1527635662041};\\\", \\\"{x:1185,y:707,t:1527635662059};\\\", \\\"{x:1187,y:705,t:1527635662075};\\\", \\\"{x:1190,y:705,t:1527635662092};\\\", \\\"{x:1192,y:703,t:1527635662109};\\\", \\\"{x:1197,y:703,t:1527635662125};\\\", \\\"{x:1206,y:703,t:1527635662141};\\\", \\\"{x:1219,y:703,t:1527635662158};\\\", \\\"{x:1231,y:703,t:1527635662176};\\\", \\\"{x:1244,y:703,t:1527635662191};\\\", \\\"{x:1249,y:703,t:1527635662208};\\\", \\\"{x:1252,y:703,t:1527635662225};\\\", \\\"{x:1253,y:703,t:1527635662241};\\\", \\\"{x:1255,y:703,t:1527635662258};\\\", \\\"{x:1256,y:703,t:1527635662444};\\\", \\\"{x:1255,y:705,t:1527635662458};\\\", \\\"{x:1254,y:706,t:1527635662476};\\\", \\\"{x:1251,y:707,t:1527635662492};\\\", \\\"{x:1249,y:707,t:1527635662508};\\\", \\\"{x:1252,y:707,t:1527635662716};\\\", \\\"{x:1258,y:707,t:1527635662726};\\\", \\\"{x:1268,y:707,t:1527635662742};\\\", \\\"{x:1273,y:707,t:1527635662758};\\\", \\\"{x:1277,y:707,t:1527635662775};\\\", \\\"{x:1280,y:707,t:1527635662793};\\\", \\\"{x:1283,y:707,t:1527635662809};\\\", \\\"{x:1285,y:707,t:1527635662825};\\\", \\\"{x:1289,y:707,t:1527635662843};\\\", \\\"{x:1293,y:707,t:1527635662859};\\\", \\\"{x:1298,y:707,t:1527635662875};\\\", \\\"{x:1305,y:707,t:1527635662892};\\\", \\\"{x:1309,y:707,t:1527635662910};\\\", \\\"{x:1312,y:708,t:1527635662925};\\\", \\\"{x:1313,y:708,t:1527635662943};\\\", \\\"{x:1315,y:708,t:1527635662980};\\\", \\\"{x:1316,y:708,t:1527635662993};\\\", \\\"{x:1318,y:708,t:1527635663009};\\\", \\\"{x:1321,y:709,t:1527635663025};\\\", \\\"{x:1322,y:709,t:1527635663069};\\\", \\\"{x:1324,y:709,t:1527635663292};\\\", \\\"{x:1326,y:709,t:1527635663310};\\\", \\\"{x:1328,y:709,t:1527635663327};\\\", \\\"{x:1327,y:709,t:1527635663428};\\\", \\\"{x:1326,y:709,t:1527635663443};\\\", \\\"{x:1322,y:709,t:1527635663460};\\\", \\\"{x:1310,y:709,t:1527635663477};\\\", \\\"{x:1292,y:707,t:1527635663494};\\\", \\\"{x:1263,y:703,t:1527635663509};\\\", \\\"{x:1226,y:702,t:1527635663527};\\\", \\\"{x:1204,y:699,t:1527635663544};\\\", \\\"{x:1186,y:697,t:1527635663559};\\\", \\\"{x:1168,y:693,t:1527635663577};\\\", \\\"{x:1156,y:692,t:1527635663594};\\\", \\\"{x:1141,y:688,t:1527635663610};\\\", \\\"{x:1118,y:683,t:1527635663627};\\\", \\\"{x:1086,y:680,t:1527635663644};\\\", \\\"{x:1058,y:677,t:1527635663659};\\\", \\\"{x:967,y:666,t:1527635663677};\\\", \\\"{x:911,y:656,t:1527635663694};\\\", \\\"{x:839,y:647,t:1527635663709};\\\", \\\"{x:788,y:639,t:1527635663727};\\\", \\\"{x:740,y:630,t:1527635663743};\\\", \\\"{x:713,y:621,t:1527635663759};\\\", \\\"{x:689,y:615,t:1527635663776};\\\", \\\"{x:669,y:610,t:1527635663793};\\\", \\\"{x:650,y:600,t:1527635663809};\\\", \\\"{x:628,y:592,t:1527635663826};\\\", \\\"{x:609,y:581,t:1527635663843};\\\", \\\"{x:592,y:570,t:1527635663860};\\\", \\\"{x:584,y:561,t:1527635663876};\\\", \\\"{x:577,y:550,t:1527635663893};\\\", \\\"{x:573,y:543,t:1527635663904};\\\", \\\"{x:568,y:531,t:1527635663921};\\\", \\\"{x:562,y:522,t:1527635663937};\\\", \\\"{x:557,y:516,t:1527635663955};\\\", \\\"{x:552,y:509,t:1527635663972};\\\", \\\"{x:541,y:501,t:1527635663988};\\\", \\\"{x:512,y:489,t:1527635664004};\\\", \\\"{x:494,y:483,t:1527635664021};\\\", \\\"{x:461,y:474,t:1527635664038};\\\", \\\"{x:433,y:467,t:1527635664055};\\\", \\\"{x:397,y:457,t:1527635664071};\\\", \\\"{x:368,y:450,t:1527635664088};\\\", \\\"{x:342,y:445,t:1527635664104};\\\", \\\"{x:320,y:442,t:1527635664121};\\\", \\\"{x:297,y:440,t:1527635664137};\\\", \\\"{x:265,y:434,t:1527635664155};\\\", \\\"{x:220,y:427,t:1527635664172};\\\", \\\"{x:180,y:418,t:1527635664188};\\\", \\\"{x:175,y:416,t:1527635664204};\\\", \\\"{x:172,y:416,t:1527635664244};\\\", \\\"{x:171,y:415,t:1527635664255};\\\", \\\"{x:170,y:417,t:1527635664300};\\\", \\\"{x:170,y:418,t:1527635664324};\\\", \\\"{x:170,y:420,t:1527635664338};\\\", \\\"{x:170,y:422,t:1527635664354};\\\", \\\"{x:170,y:427,t:1527635664371};\\\", \\\"{x:170,y:434,t:1527635664389};\\\", \\\"{x:171,y:436,t:1527635664404};\\\", \\\"{x:172,y:438,t:1527635664422};\\\", \\\"{x:172,y:439,t:1527635664476};\\\", \\\"{x:172,y:440,t:1527635664489};\\\", \\\"{x:172,y:441,t:1527635664508};\\\", \\\"{x:172,y:442,t:1527635664531};\\\", \\\"{x:170,y:444,t:1527635664548};\\\", \\\"{x:170,y:445,t:1527635664579};\\\", \\\"{x:170,y:445,t:1527635664631};\\\", \\\"{x:170,y:446,t:1527635664644};\\\", \\\"{x:170,y:447,t:1527635664660};\\\", \\\"{x:170,y:449,t:1527635664671};\\\", \\\"{x:177,y:451,t:1527635664688};\\\", \\\"{x:198,y:457,t:1527635664706};\\\", \\\"{x:232,y:469,t:1527635664721};\\\", \\\"{x:282,y:493,t:1527635664739};\\\", \\\"{x:347,y:525,t:1527635664756};\\\", \\\"{x:419,y:573,t:1527635664772};\\\", \\\"{x:505,y:644,t:1527635664788};\\\", \\\"{x:550,y:686,t:1527635664805};\\\", \\\"{x:568,y:701,t:1527635664821};\\\", \\\"{x:588,y:721,t:1527635664838};\\\", \\\"{x:598,y:733,t:1527635664855};\\\", \\\"{x:609,y:744,t:1527635664871};\\\", \\\"{x:612,y:750,t:1527635664888};\\\", \\\"{x:614,y:752,t:1527635664905};\\\", \\\"{x:614,y:753,t:1527635664921};\\\", \\\"{x:615,y:753,t:1527635664938};\\\", \\\"{x:611,y:753,t:1527635665004};\\\", \\\"{x:601,y:745,t:1527635665012};\\\", \\\"{x:589,y:737,t:1527635665021};\\\", \\\"{x:561,y:724,t:1527635665038};\\\", \\\"{x:536,y:715,t:1527635665055};\\\", \\\"{x:525,y:709,t:1527635665072};\\\", \\\"{x:518,y:702,t:1527635665088};\\\", \\\"{x:517,y:698,t:1527635665105};\\\", \\\"{x:517,y:695,t:1527635665123};\\\", \\\"{x:516,y:692,t:1527635665139};\\\", \\\"{x:516,y:691,t:1527635665156};\\\", \\\"{x:515,y:689,t:1527635665173};\\\", \\\"{x:515,y:688,t:1527635665709};\\\", \\\"{x:517,y:687,t:1527635665722};\\\", \\\"{x:527,y:682,t:1527635665739};\\\", \\\"{x:535,y:677,t:1527635665755};\\\", \\\"{x:540,y:675,t:1527635665772};\\\", \\\"{x:542,y:674,t:1527635665789};\\\", \\\"{x:546,y:673,t:1527635665805};\\\", \\\"{x:555,y:669,t:1527635665822};\\\", \\\"{x:563,y:667,t:1527635665839};\\\", \\\"{x:569,y:665,t:1527635665855};\\\", \\\"{x:573,y:663,t:1527635665872};\\\", \\\"{x:577,y:659,t:1527635665889};\\\", \\\"{x:577,y:658,t:1527635665905};\\\", \\\"{x:578,y:658,t:1527635666363};\\\" ] }, { \\\"rt\\\": 23783, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 599726, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"8FE87\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -F -Z -04 PM-X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:577,y:658,t:1527635667628};\\\", \\\"{x:574,y:659,t:1527635667644};\\\", \\\"{x:573,y:659,t:1527635667658};\\\", \\\"{x:572,y:660,t:1527635667673};\\\", \\\"{x:567,y:660,t:1527635667948};\\\", \\\"{x:558,y:656,t:1527635667958};\\\", \\\"{x:544,y:641,t:1527635667975};\\\", \\\"{x:520,y:622,t:1527635667990};\\\", \\\"{x:484,y:593,t:1527635668008};\\\", \\\"{x:459,y:572,t:1527635668025};\\\", \\\"{x:436,y:552,t:1527635668040};\\\", \\\"{x:419,y:532,t:1527635668057};\\\", \\\"{x:412,y:514,t:1527635668074};\\\", \\\"{x:409,y:500,t:1527635668091};\\\", \\\"{x:409,y:480,t:1527635668107};\\\", \\\"{x:410,y:457,t:1527635668125};\\\", \\\"{x:412,y:447,t:1527635668142};\\\", \\\"{x:416,y:440,t:1527635668158};\\\", \\\"{x:421,y:434,t:1527635668174};\\\", \\\"{x:427,y:427,t:1527635668191};\\\", \\\"{x:431,y:422,t:1527635668207};\\\", \\\"{x:435,y:418,t:1527635668225};\\\", \\\"{x:441,y:414,t:1527635668241};\\\", \\\"{x:446,y:411,t:1527635668257};\\\", \\\"{x:453,y:408,t:1527635668275};\\\", \\\"{x:458,y:406,t:1527635668291};\\\", \\\"{x:466,y:401,t:1527635668307};\\\", \\\"{x:479,y:394,t:1527635668324};\\\", \\\"{x:489,y:391,t:1527635668342};\\\", \\\"{x:504,y:384,t:1527635668357};\\\", \\\"{x:525,y:379,t:1527635668375};\\\", \\\"{x:546,y:374,t:1527635668391};\\\", \\\"{x:563,y:369,t:1527635668408};\\\", \\\"{x:586,y:366,t:1527635668425};\\\", \\\"{x:615,y:356,t:1527635668441};\\\", \\\"{x:640,y:355,t:1527635668457};\\\", \\\"{x:663,y:351,t:1527635668474};\\\", \\\"{x:681,y:351,t:1527635668491};\\\", \\\"{x:695,y:350,t:1527635668507};\\\", \\\"{x:722,y:350,t:1527635668524};\\\", \\\"{x:740,y:350,t:1527635668541};\\\", \\\"{x:767,y:350,t:1527635668559};\\\", \\\"{x:785,y:352,t:1527635668574};\\\", \\\"{x:809,y:354,t:1527635668591};\\\", \\\"{x:823,y:358,t:1527635668608};\\\", \\\"{x:848,y:363,t:1527635668625};\\\", \\\"{x:882,y:370,t:1527635668642};\\\", \\\"{x:928,y:385,t:1527635668659};\\\", \\\"{x:994,y:405,t:1527635668675};\\\", \\\"{x:1060,y:421,t:1527635668692};\\\", \\\"{x:1178,y:446,t:1527635668708};\\\", \\\"{x:1247,y:464,t:1527635668725};\\\", \\\"{x:1308,y:483,t:1527635668741};\\\", \\\"{x:1364,y:499,t:1527635668758};\\\", \\\"{x:1410,y:514,t:1527635668776};\\\", \\\"{x:1452,y:536,t:1527635668792};\\\", \\\"{x:1477,y:552,t:1527635668809};\\\", \\\"{x:1507,y:575,t:1527635668825};\\\", \\\"{x:1534,y:599,t:1527635668841};\\\", \\\"{x:1556,y:618,t:1527635668859};\\\", \\\"{x:1571,y:632,t:1527635668874};\\\", \\\"{x:1578,y:639,t:1527635668892};\\\", \\\"{x:1586,y:652,t:1527635668908};\\\", \\\"{x:1590,y:664,t:1527635668925};\\\", \\\"{x:1590,y:672,t:1527635668941};\\\", \\\"{x:1590,y:676,t:1527635668958};\\\", \\\"{x:1586,y:676,t:1527635669285};\\\", \\\"{x:1577,y:674,t:1527635669292};\\\", \\\"{x:1547,y:670,t:1527635669309};\\\", \\\"{x:1502,y:663,t:1527635669325};\\\", \\\"{x:1456,y:662,t:1527635669342};\\\", \\\"{x:1409,y:656,t:1527635669359};\\\", \\\"{x:1361,y:656,t:1527635669376};\\\", \\\"{x:1322,y:656,t:1527635669391};\\\", \\\"{x:1304,y:656,t:1527635669408};\\\", \\\"{x:1293,y:656,t:1527635669426};\\\", \\\"{x:1289,y:656,t:1527635669441};\\\", \\\"{x:1287,y:656,t:1527635669459};\\\", \\\"{x:1290,y:654,t:1527635669581};\\\", \\\"{x:1296,y:651,t:1527635669592};\\\", \\\"{x:1312,y:645,t:1527635669608};\\\", \\\"{x:1323,y:640,t:1527635669626};\\\", \\\"{x:1332,y:637,t:1527635669643};\\\", \\\"{x:1334,y:636,t:1527635669659};\\\", \\\"{x:1336,y:635,t:1527635669675};\\\", \\\"{x:1337,y:635,t:1527635669693};\\\", \\\"{x:1337,y:637,t:1527635670100};\\\", \\\"{x:1337,y:639,t:1527635670110};\\\", \\\"{x:1337,y:642,t:1527635670125};\\\", \\\"{x:1337,y:645,t:1527635670143};\\\", \\\"{x:1337,y:646,t:1527635670159};\\\", \\\"{x:1337,y:647,t:1527635670276};\\\", \\\"{x:1344,y:647,t:1527635670293};\\\", \\\"{x:1356,y:647,t:1527635670310};\\\", \\\"{x:1371,y:647,t:1527635670326};\\\", \\\"{x:1388,y:647,t:1527635670342};\\\", \\\"{x:1403,y:647,t:1527635670360};\\\", \\\"{x:1416,y:649,t:1527635670376};\\\", \\\"{x:1427,y:649,t:1527635670393};\\\", \\\"{x:1434,y:649,t:1527635670410};\\\", \\\"{x:1437,y:649,t:1527635670425};\\\", \\\"{x:1438,y:649,t:1527635670443};\\\", \\\"{x:1436,y:649,t:1527635670589};\\\", \\\"{x:1435,y:649,t:1527635670596};\\\", \\\"{x:1434,y:649,t:1527635670610};\\\", \\\"{x:1438,y:647,t:1527635670780};\\\", \\\"{x:1444,y:647,t:1527635670792};\\\", \\\"{x:1453,y:646,t:1527635670810};\\\", \\\"{x:1461,y:647,t:1527635670827};\\\", \\\"{x:1464,y:647,t:1527635670843};\\\", \\\"{x:1468,y:647,t:1527635670860};\\\", \\\"{x:1470,y:647,t:1527635670876};\\\", \\\"{x:1471,y:647,t:1527635670916};\\\", \\\"{x:1472,y:647,t:1527635670932};\\\", \\\"{x:1473,y:647,t:1527635670948};\\\", \\\"{x:1474,y:647,t:1527635670959};\\\", \\\"{x:1475,y:647,t:1527635670977};\\\", \\\"{x:1476,y:647,t:1527635671020};\\\", \\\"{x:1478,y:647,t:1527635671028};\\\", \\\"{x:1481,y:647,t:1527635671043};\\\", \\\"{x:1485,y:647,t:1527635671060};\\\", \\\"{x:1491,y:648,t:1527635671076};\\\", \\\"{x:1496,y:648,t:1527635671094};\\\", \\\"{x:1502,y:648,t:1527635671110};\\\", \\\"{x:1509,y:648,t:1527635671127};\\\", \\\"{x:1517,y:648,t:1527635671143};\\\", \\\"{x:1526,y:648,t:1527635671160};\\\", \\\"{x:1529,y:648,t:1527635671177};\\\", \\\"{x:1532,y:648,t:1527635671194};\\\", \\\"{x:1535,y:648,t:1527635671210};\\\", \\\"{x:1536,y:648,t:1527635671227};\\\", \\\"{x:1537,y:648,t:1527635671244};\\\", \\\"{x:1542,y:648,t:1527635671444};\\\", \\\"{x:1549,y:648,t:1527635671460};\\\", \\\"{x:1558,y:648,t:1527635671476};\\\", \\\"{x:1567,y:648,t:1527635671494};\\\", \\\"{x:1573,y:648,t:1527635671510};\\\", \\\"{x:1575,y:648,t:1527635671527};\\\", \\\"{x:1576,y:648,t:1527635671548};\\\", \\\"{x:1577,y:648,t:1527635671572};\\\", \\\"{x:1578,y:648,t:1527635671580};\\\", \\\"{x:1579,y:648,t:1527635671594};\\\", \\\"{x:1582,y:648,t:1527635671610};\\\", \\\"{x:1585,y:648,t:1527635671627};\\\", \\\"{x:1587,y:648,t:1527635671644};\\\", \\\"{x:1588,y:648,t:1527635671675};\\\", \\\"{x:1590,y:648,t:1527635671724};\\\", \\\"{x:1592,y:648,t:1527635671732};\\\", \\\"{x:1593,y:648,t:1527635671744};\\\", \\\"{x:1597,y:647,t:1527635671761};\\\", \\\"{x:1598,y:647,t:1527635671780};\\\", \\\"{x:1598,y:646,t:1527635671794};\\\", \\\"{x:1599,y:646,t:1527635671820};\\\", \\\"{x:1601,y:646,t:1527635671828};\\\", \\\"{x:1602,y:646,t:1527635671844};\\\", \\\"{x:1604,y:646,t:1527635671861};\\\", \\\"{x:1605,y:646,t:1527635671877};\\\", \\\"{x:1606,y:645,t:1527635671894};\\\", \\\"{x:1607,y:645,t:1527635672124};\\\", \\\"{x:1608,y:645,t:1527635672132};\\\", \\\"{x:1609,y:644,t:1527635672148};\\\", \\\"{x:1609,y:643,t:1527635672178};\\\", \\\"{x:1610,y:643,t:1527635672195};\\\", \\\"{x:1611,y:643,t:1527635672210};\\\", \\\"{x:1611,y:642,t:1527635672236};\\\", \\\"{x:1612,y:642,t:1527635672276};\\\", \\\"{x:1614,y:641,t:1527635672307};\\\", \\\"{x:1615,y:641,t:1527635674485};\\\", \\\"{x:1614,y:643,t:1527635674500};\\\", \\\"{x:1613,y:645,t:1527635674513};\\\", \\\"{x:1613,y:646,t:1527635674528};\\\", \\\"{x:1613,y:647,t:1527635674548};\\\", \\\"{x:1613,y:648,t:1527635674563};\\\", \\\"{x:1613,y:653,t:1527635674579};\\\", \\\"{x:1613,y:661,t:1527635674596};\\\", \\\"{x:1613,y:675,t:1527635674612};\\\", \\\"{x:1613,y:683,t:1527635674629};\\\", \\\"{x:1614,y:693,t:1527635674645};\\\", \\\"{x:1616,y:704,t:1527635674663};\\\", \\\"{x:1620,y:718,t:1527635674679};\\\", \\\"{x:1621,y:738,t:1527635674696};\\\", \\\"{x:1625,y:757,t:1527635674712};\\\", \\\"{x:1627,y:776,t:1527635674729};\\\", \\\"{x:1627,y:794,t:1527635674746};\\\", \\\"{x:1621,y:815,t:1527635674763};\\\", \\\"{x:1611,y:835,t:1527635674779};\\\", \\\"{x:1606,y:855,t:1527635674796};\\\", \\\"{x:1605,y:868,t:1527635674813};\\\", \\\"{x:1605,y:879,t:1527635674830};\\\", \\\"{x:1605,y:886,t:1527635674845};\\\", \\\"{x:1605,y:889,t:1527635674863};\\\", \\\"{x:1605,y:895,t:1527635674880};\\\", \\\"{x:1605,y:900,t:1527635674896};\\\", \\\"{x:1606,y:906,t:1527635674912};\\\", \\\"{x:1609,y:912,t:1527635674930};\\\", \\\"{x:1610,y:915,t:1527635674946};\\\", \\\"{x:1611,y:915,t:1527635674963};\\\", \\\"{x:1612,y:917,t:1527635674980};\\\", \\\"{x:1613,y:918,t:1527635674996};\\\", \\\"{x:1614,y:918,t:1527635675013};\\\", \\\"{x:1615,y:918,t:1527635675556};\\\", \\\"{x:1615,y:916,t:1527635675588};\\\", \\\"{x:1615,y:915,t:1527635675605};\\\", \\\"{x:1615,y:914,t:1527635675636};\\\", \\\"{x:1615,y:913,t:1527635675668};\\\", \\\"{x:1615,y:912,t:1527635675748};\\\", \\\"{x:1614,y:911,t:1527635677628};\\\", \\\"{x:1613,y:911,t:1527635677700};\\\", \\\"{x:1612,y:910,t:1527635677716};\\\", \\\"{x:1611,y:909,t:1527635677732};\\\", \\\"{x:1610,y:909,t:1527635677780};\\\", \\\"{x:1609,y:908,t:1527635677788};\\\", \\\"{x:1607,y:907,t:1527635678300};\\\", \\\"{x:1605,y:906,t:1527635678324};\\\", \\\"{x:1604,y:905,t:1527635678332};\\\", \\\"{x:1601,y:902,t:1527635678349};\\\", \\\"{x:1600,y:902,t:1527635678365};\\\", \\\"{x:1599,y:900,t:1527635678382};\\\", \\\"{x:1598,y:899,t:1527635678399};\\\", \\\"{x:1597,y:896,t:1527635678415};\\\", \\\"{x:1595,y:892,t:1527635678432};\\\", \\\"{x:1591,y:886,t:1527635678449};\\\", \\\"{x:1589,y:882,t:1527635678465};\\\", \\\"{x:1587,y:876,t:1527635678482};\\\", \\\"{x:1583,y:867,t:1527635678498};\\\", \\\"{x:1581,y:863,t:1527635678515};\\\", \\\"{x:1578,y:855,t:1527635678532};\\\", \\\"{x:1576,y:851,t:1527635678549};\\\", \\\"{x:1575,y:848,t:1527635678565};\\\", \\\"{x:1574,y:846,t:1527635678582};\\\", \\\"{x:1574,y:844,t:1527635678598};\\\", \\\"{x:1571,y:839,t:1527635678616};\\\", \\\"{x:1570,y:836,t:1527635678632};\\\", \\\"{x:1568,y:832,t:1527635678649};\\\", \\\"{x:1566,y:827,t:1527635678666};\\\", \\\"{x:1564,y:823,t:1527635678682};\\\", \\\"{x:1563,y:821,t:1527635678698};\\\", \\\"{x:1563,y:819,t:1527635678716};\\\", \\\"{x:1562,y:817,t:1527635678732};\\\", \\\"{x:1561,y:815,t:1527635678749};\\\", \\\"{x:1560,y:814,t:1527635678766};\\\", \\\"{x:1560,y:813,t:1527635678782};\\\", \\\"{x:1559,y:811,t:1527635678799};\\\", \\\"{x:1559,y:810,t:1527635678828};\\\", \\\"{x:1559,y:809,t:1527635678836};\\\", \\\"{x:1558,y:807,t:1527635678860};\\\", \\\"{x:1561,y:811,t:1527635679076};\\\", \\\"{x:1568,y:820,t:1527635679084};\\\", \\\"{x:1575,y:830,t:1527635679099};\\\", \\\"{x:1590,y:852,t:1527635679116};\\\", \\\"{x:1599,y:862,t:1527635679133};\\\", \\\"{x:1604,y:868,t:1527635679149};\\\", \\\"{x:1608,y:874,t:1527635679166};\\\", \\\"{x:1613,y:883,t:1527635679183};\\\", \\\"{x:1617,y:890,t:1527635679199};\\\", \\\"{x:1618,y:896,t:1527635679215};\\\", \\\"{x:1619,y:899,t:1527635679233};\\\", \\\"{x:1619,y:900,t:1527635679540};\\\", \\\"{x:1618,y:900,t:1527635679550};\\\", \\\"{x:1617,y:901,t:1527635679566};\\\", \\\"{x:1617,y:902,t:1527635679583};\\\", \\\"{x:1616,y:902,t:1527635679600};\\\", \\\"{x:1616,y:903,t:1527635679616};\\\", \\\"{x:1614,y:904,t:1527635679633};\\\", \\\"{x:1614,y:905,t:1527635679649};\\\", \\\"{x:1614,y:907,t:1527635679666};\\\", \\\"{x:1613,y:907,t:1527635679684};\\\", \\\"{x:1613,y:908,t:1527635679708};\\\", \\\"{x:1611,y:908,t:1527635679844};\\\", \\\"{x:1609,y:907,t:1527635679852};\\\", \\\"{x:1605,y:902,t:1527635679866};\\\", \\\"{x:1600,y:893,t:1527635679883};\\\", \\\"{x:1589,y:873,t:1527635679900};\\\", \\\"{x:1578,y:857,t:1527635679915};\\\", \\\"{x:1571,y:845,t:1527635679933};\\\", \\\"{x:1565,y:831,t:1527635679950};\\\", \\\"{x:1560,y:820,t:1527635679967};\\\", \\\"{x:1558,y:813,t:1527635679983};\\\", \\\"{x:1556,y:807,t:1527635680000};\\\", \\\"{x:1554,y:802,t:1527635680017};\\\", \\\"{x:1553,y:799,t:1527635680033};\\\", \\\"{x:1552,y:797,t:1527635680050};\\\", \\\"{x:1551,y:793,t:1527635680067};\\\", \\\"{x:1551,y:791,t:1527635680083};\\\", \\\"{x:1551,y:788,t:1527635680100};\\\", \\\"{x:1550,y:786,t:1527635680117};\\\", \\\"{x:1550,y:785,t:1527635680133};\\\", \\\"{x:1549,y:785,t:1527635680150};\\\", \\\"{x:1549,y:783,t:1527635680167};\\\", \\\"{x:1548,y:782,t:1527635680184};\\\", \\\"{x:1548,y:780,t:1527635680200};\\\", \\\"{x:1548,y:779,t:1527635680217};\\\", \\\"{x:1548,y:778,t:1527635680233};\\\", \\\"{x:1548,y:777,t:1527635680252};\\\", \\\"{x:1547,y:777,t:1527635680276};\\\", \\\"{x:1547,y:776,t:1527635680324};\\\", \\\"{x:1546,y:775,t:1527635680468};\\\", \\\"{x:1544,y:775,t:1527635680491};\\\", \\\"{x:1543,y:775,t:1527635680500};\\\", \\\"{x:1540,y:775,t:1527635680517};\\\", \\\"{x:1537,y:775,t:1527635680534};\\\", \\\"{x:1534,y:775,t:1527635680550};\\\", \\\"{x:1532,y:775,t:1527635680567};\\\", \\\"{x:1529,y:775,t:1527635680583};\\\", \\\"{x:1522,y:775,t:1527635680600};\\\", \\\"{x:1517,y:775,t:1527635680617};\\\", \\\"{x:1509,y:775,t:1527635680634};\\\", \\\"{x:1503,y:775,t:1527635680650};\\\", \\\"{x:1498,y:775,t:1527635680666};\\\", \\\"{x:1494,y:776,t:1527635680683};\\\", \\\"{x:1491,y:776,t:1527635680700};\\\", \\\"{x:1489,y:777,t:1527635680717};\\\", \\\"{x:1488,y:777,t:1527635680733};\\\", \\\"{x:1486,y:777,t:1527635680750};\\\", \\\"{x:1485,y:777,t:1527635680796};\\\", \\\"{x:1484,y:778,t:1527635680803};\\\", \\\"{x:1483,y:778,t:1527635680868};\\\", \\\"{x:1482,y:778,t:1527635681076};\\\", \\\"{x:1481,y:778,t:1527635681108};\\\", \\\"{x:1480,y:778,t:1527635681132};\\\", \\\"{x:1479,y:778,t:1527635681148};\\\", \\\"{x:1478,y:778,t:1527635681180};\\\", \\\"{x:1477,y:778,t:1527635681220};\\\", \\\"{x:1476,y:778,t:1527635681260};\\\", \\\"{x:1475,y:778,t:1527635681309};\\\", \\\"{x:1476,y:778,t:1527635681852};\\\", \\\"{x:1461,y:777,t:1527635687268};\\\", \\\"{x:1431,y:768,t:1527635687276};\\\", \\\"{x:1379,y:760,t:1527635687288};\\\", \\\"{x:1259,y:738,t:1527635687305};\\\", \\\"{x:1115,y:714,t:1527635687322};\\\", \\\"{x:975,y:686,t:1527635687338};\\\", \\\"{x:860,y:657,t:1527635687355};\\\", \\\"{x:725,y:624,t:1527635687372};\\\", \\\"{x:669,y:608,t:1527635687388};\\\", \\\"{x:632,y:589,t:1527635687405};\\\", \\\"{x:604,y:576,t:1527635687423};\\\", \\\"{x:584,y:562,t:1527635687438};\\\", \\\"{x:563,y:549,t:1527635687455};\\\", \\\"{x:555,y:546,t:1527635687467};\\\", \\\"{x:535,y:536,t:1527635687484};\\\", \\\"{x:507,y:529,t:1527635687499};\\\", \\\"{x:452,y:511,t:1527635687524};\\\", \\\"{x:417,y:501,t:1527635687540};\\\", \\\"{x:403,y:499,t:1527635687556};\\\", \\\"{x:395,y:499,t:1527635687573};\\\", \\\"{x:394,y:498,t:1527635687590};\\\", \\\"{x:392,y:498,t:1527635687606};\\\", \\\"{x:391,y:498,t:1527635687668};\\\", \\\"{x:389,y:498,t:1527635687772};\\\", \\\"{x:388,y:497,t:1527635687812};\\\", \\\"{x:385,y:496,t:1527635687836};\\\", \\\"{x:383,y:495,t:1527635687844};\\\", \\\"{x:380,y:495,t:1527635687856};\\\", \\\"{x:373,y:493,t:1527635687873};\\\", \\\"{x:366,y:492,t:1527635687890};\\\", \\\"{x:365,y:491,t:1527635687906};\\\", \\\"{x:365,y:490,t:1527635687955};\\\", \\\"{x:368,y:488,t:1527635687964};\\\", \\\"{x:377,y:485,t:1527635687973};\\\", \\\"{x:396,y:480,t:1527635687990};\\\", \\\"{x:423,y:474,t:1527635688008};\\\", \\\"{x:446,y:474,t:1527635688024};\\\", \\\"{x:472,y:474,t:1527635688040};\\\", \\\"{x:503,y:474,t:1527635688058};\\\", \\\"{x:530,y:474,t:1527635688073};\\\", \\\"{x:557,y:474,t:1527635688090};\\\", \\\"{x:578,y:474,t:1527635688107};\\\", \\\"{x:590,y:474,t:1527635688124};\\\", \\\"{x:595,y:474,t:1527635688140};\\\", \\\"{x:597,y:474,t:1527635688158};\\\", \\\"{x:598,y:474,t:1527635688180};\\\", \\\"{x:600,y:474,t:1527635688196};\\\", \\\"{x:603,y:474,t:1527635688207};\\\", \\\"{x:614,y:474,t:1527635688224};\\\", \\\"{x:634,y:475,t:1527635688241};\\\", \\\"{x:658,y:475,t:1527635688257};\\\", \\\"{x:688,y:475,t:1527635688273};\\\", \\\"{x:714,y:475,t:1527635688290};\\\", \\\"{x:744,y:475,t:1527635688307};\\\", \\\"{x:768,y:474,t:1527635688323};\\\", \\\"{x:787,y:469,t:1527635688341};\\\", \\\"{x:794,y:467,t:1527635688357};\\\", \\\"{x:796,y:466,t:1527635688374};\\\", \\\"{x:801,y:464,t:1527635688391};\\\", \\\"{x:806,y:460,t:1527635688407};\\\", \\\"{x:811,y:457,t:1527635688424};\\\", \\\"{x:814,y:456,t:1527635688441};\\\", \\\"{x:817,y:455,t:1527635688457};\\\", \\\"{x:819,y:454,t:1527635688474};\\\", \\\"{x:820,y:453,t:1527635688490};\\\", \\\"{x:823,y:453,t:1527635688508};\\\", \\\"{x:826,y:450,t:1527635688524};\\\", \\\"{x:827,y:450,t:1527635688540};\\\", \\\"{x:828,y:450,t:1527635688580};\\\", \\\"{x:829,y:450,t:1527635688628};\\\", \\\"{x:830,y:449,t:1527635688668};\\\", \\\"{x:830,y:449,t:1527635688727};\\\", \\\"{x:828,y:449,t:1527635688779};\\\", \\\"{x:824,y:449,t:1527635688790};\\\", \\\"{x:813,y:453,t:1527635688808};\\\", \\\"{x:807,y:457,t:1527635688824};\\\", \\\"{x:801,y:460,t:1527635688841};\\\", \\\"{x:786,y:465,t:1527635688858};\\\", \\\"{x:766,y:474,t:1527635688875};\\\", \\\"{x:744,y:483,t:1527635688892};\\\", \\\"{x:709,y:496,t:1527635688908};\\\", \\\"{x:635,y:519,t:1527635688924};\\\", \\\"{x:576,y:529,t:1527635688941};\\\", \\\"{x:523,y:537,t:1527635688958};\\\", \\\"{x:478,y:543,t:1527635688975};\\\", \\\"{x:447,y:544,t:1527635688991};\\\", \\\"{x:428,y:544,t:1527635689007};\\\", \\\"{x:424,y:546,t:1527635689024};\\\", \\\"{x:430,y:546,t:1527635689076};\\\", \\\"{x:441,y:546,t:1527635689091};\\\", \\\"{x:479,y:538,t:1527635689107};\\\", \\\"{x:512,y:533,t:1527635689124};\\\", \\\"{x:540,y:529,t:1527635689141};\\\", \\\"{x:558,y:527,t:1527635689157};\\\", \\\"{x:564,y:527,t:1527635689174};\\\", \\\"{x:565,y:527,t:1527635689191};\\\", \\\"{x:567,y:527,t:1527635689260};\\\", \\\"{x:568,y:527,t:1527635689275};\\\", \\\"{x:572,y:526,t:1527635689290};\\\", \\\"{x:576,y:526,t:1527635689307};\\\", \\\"{x:577,y:526,t:1527635689323};\\\", \\\"{x:578,y:525,t:1527635689340};\\\", \\\"{x:580,y:525,t:1527635689363};\\\", \\\"{x:583,y:525,t:1527635689374};\\\", \\\"{x:587,y:523,t:1527635689390};\\\", \\\"{x:595,y:520,t:1527635689407};\\\", \\\"{x:600,y:519,t:1527635689424};\\\", \\\"{x:603,y:519,t:1527635689440};\\\", \\\"{x:604,y:518,t:1527635689459};\\\", \\\"{x:605,y:518,t:1527635689483};\\\", \\\"{x:606,y:518,t:1527635689596};\\\", \\\"{x:607,y:518,t:1527635689608};\\\", \\\"{x:607,y:521,t:1527635689660};\\\", \\\"{x:607,y:524,t:1527635689674};\\\", \\\"{x:606,y:533,t:1527635689691};\\\", \\\"{x:600,y:548,t:1527635689709};\\\", \\\"{x:596,y:558,t:1527635689725};\\\", \\\"{x:591,y:569,t:1527635689742};\\\", \\\"{x:588,y:583,t:1527635689759};\\\", \\\"{x:584,y:603,t:1527635689775};\\\", \\\"{x:575,y:624,t:1527635689791};\\\", \\\"{x:569,y:640,t:1527635689808};\\\", \\\"{x:561,y:655,t:1527635689825};\\\", \\\"{x:558,y:662,t:1527635689841};\\\", \\\"{x:556,y:666,t:1527635689858};\\\", \\\"{x:552,y:670,t:1527635689876};\\\", \\\"{x:554,y:670,t:1527635690639};\\\", \\\"{x:559,y:668,t:1527635690647};\\\", \\\"{x:570,y:665,t:1527635690662};\\\", \\\"{x:591,y:659,t:1527635690678};\\\", \\\"{x:627,y:655,t:1527635690695};\\\", \\\"{x:649,y:647,t:1527635690713};\\\", \\\"{x:697,y:639,t:1527635690729};\\\", \\\"{x:734,y:630,t:1527635690746};\\\", \\\"{x:769,y:618,t:1527635690763};\\\", \\\"{x:798,y:611,t:1527635690779};\\\", \\\"{x:825,y:601,t:1527635690795};\\\", \\\"{x:847,y:596,t:1527635690813};\\\", \\\"{x:868,y:591,t:1527635690829};\\\", \\\"{x:885,y:590,t:1527635690846};\\\", \\\"{x:896,y:588,t:1527635690863};\\\", \\\"{x:909,y:584,t:1527635690878};\\\", \\\"{x:921,y:581,t:1527635690896};\\\", \\\"{x:928,y:581,t:1527635690912};\\\", \\\"{x:931,y:581,t:1527635690928};\\\", \\\"{x:934,y:580,t:1527635690946};\\\", \\\"{x:935,y:580,t:1527635690967};\\\", \\\"{x:936,y:580,t:1527635690979};\\\", \\\"{x:937,y:580,t:1527635691088};\\\" ] }, { \\\"rt\\\": 12380, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 613381, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"8FE87\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11-P -01 PM-12 PM-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:936,y:580,t:1527635692039};\\\", \\\"{x:932,y:581,t:1527635692047};\\\", \\\"{x:907,y:583,t:1527635692063};\\\", \\\"{x:873,y:578,t:1527635692080};\\\", \\\"{x:831,y:574,t:1527635692097};\\\", \\\"{x:788,y:571,t:1527635692115};\\\", \\\"{x:767,y:565,t:1527635692131};\\\", \\\"{x:743,y:562,t:1527635692147};\\\", \\\"{x:728,y:560,t:1527635692164};\\\", \\\"{x:713,y:559,t:1527635692181};\\\", \\\"{x:704,y:557,t:1527635692197};\\\", \\\"{x:689,y:557,t:1527635692214};\\\", \\\"{x:674,y:556,t:1527635692231};\\\", \\\"{x:650,y:552,t:1527635692247};\\\", \\\"{x:636,y:550,t:1527635692264};\\\", \\\"{x:619,y:549,t:1527635692281};\\\", \\\"{x:612,y:549,t:1527635692297};\\\", \\\"{x:600,y:547,t:1527635692314};\\\", \\\"{x:597,y:547,t:1527635692331};\\\", \\\"{x:594,y:547,t:1527635692347};\\\", \\\"{x:593,y:547,t:1527635692408};\\\", \\\"{x:593,y:548,t:1527635692528};\\\", \\\"{x:595,y:550,t:1527635692535};\\\", \\\"{x:598,y:551,t:1527635692547};\\\", \\\"{x:606,y:554,t:1527635692565};\\\", \\\"{x:621,y:561,t:1527635692581};\\\", \\\"{x:638,y:565,t:1527635692596};\\\", \\\"{x:654,y:568,t:1527635692614};\\\", \\\"{x:662,y:571,t:1527635692632};\\\", \\\"{x:666,y:571,t:1527635692647};\\\", \\\"{x:669,y:574,t:1527635692664};\\\", \\\"{x:670,y:574,t:1527635692681};\\\", \\\"{x:674,y:576,t:1527635692697};\\\", \\\"{x:676,y:578,t:1527635692714};\\\", \\\"{x:680,y:580,t:1527635692732};\\\", \\\"{x:685,y:583,t:1527635692747};\\\", \\\"{x:692,y:585,t:1527635692764};\\\", \\\"{x:702,y:589,t:1527635692781};\\\", \\\"{x:711,y:591,t:1527635692797};\\\", \\\"{x:726,y:595,t:1527635692814};\\\", \\\"{x:745,y:599,t:1527635692831};\\\", \\\"{x:751,y:600,t:1527635692847};\\\", \\\"{x:752,y:600,t:1527635692864};\\\", \\\"{x:756,y:602,t:1527635692881};\\\", \\\"{x:761,y:603,t:1527635692897};\\\", \\\"{x:766,y:604,t:1527635692914};\\\", \\\"{x:769,y:604,t:1527635692931};\\\", \\\"{x:772,y:604,t:1527635692947};\\\", \\\"{x:779,y:605,t:1527635692964};\\\", \\\"{x:794,y:607,t:1527635692981};\\\", \\\"{x:812,y:610,t:1527635692997};\\\", \\\"{x:834,y:612,t:1527635693014};\\\", \\\"{x:870,y:618,t:1527635693031};\\\", \\\"{x:897,y:620,t:1527635693047};\\\", \\\"{x:920,y:623,t:1527635693064};\\\", \\\"{x:941,y:625,t:1527635693081};\\\", \\\"{x:955,y:625,t:1527635693097};\\\", \\\"{x:958,y:625,t:1527635693114};\\\", \\\"{x:960,y:624,t:1527635693616};\\\", \\\"{x:961,y:623,t:1527635693630};\\\", \\\"{x:962,y:623,t:1527635693647};\\\", \\\"{x:963,y:623,t:1527635693664};\\\", \\\"{x:966,y:620,t:1527635694264};\\\", \\\"{x:966,y:614,t:1527635694280};\\\", \\\"{x:969,y:609,t:1527635694297};\\\", \\\"{x:972,y:603,t:1527635694314};\\\", \\\"{x:973,y:601,t:1527635694330};\\\", \\\"{x:974,y:597,t:1527635694347};\\\", \\\"{x:974,y:594,t:1527635694365};\\\", \\\"{x:974,y:589,t:1527635694380};\\\", \\\"{x:974,y:587,t:1527635694397};\\\", \\\"{x:967,y:583,t:1527635694414};\\\", \\\"{x:959,y:579,t:1527635694430};\\\", \\\"{x:947,y:575,t:1527635694447};\\\", \\\"{x:938,y:573,t:1527635694465};\\\", \\\"{x:928,y:572,t:1527635694482};\\\", \\\"{x:917,y:569,t:1527635694499};\\\", \\\"{x:899,y:566,t:1527635694516};\\\", \\\"{x:883,y:564,t:1527635694532};\\\", \\\"{x:865,y:561,t:1527635694550};\\\", \\\"{x:848,y:557,t:1527635694566};\\\", \\\"{x:829,y:553,t:1527635694582};\\\", \\\"{x:802,y:549,t:1527635694600};\\\", \\\"{x:777,y:544,t:1527635694616};\\\", \\\"{x:754,y:541,t:1527635694632};\\\", \\\"{x:729,y:536,t:1527635694649};\\\", \\\"{x:710,y:530,t:1527635694667};\\\", \\\"{x:684,y:525,t:1527635694682};\\\", \\\"{x:651,y:512,t:1527635694699};\\\", \\\"{x:616,y:500,t:1527635694716};\\\", \\\"{x:592,y:488,t:1527635694732};\\\", \\\"{x:577,y:477,t:1527635694749};\\\", \\\"{x:564,y:462,t:1527635694767};\\\", \\\"{x:556,y:448,t:1527635694783};\\\", \\\"{x:550,y:438,t:1527635694799};\\\", \\\"{x:546,y:431,t:1527635694816};\\\", \\\"{x:543,y:424,t:1527635694832};\\\", \\\"{x:542,y:418,t:1527635694849};\\\", \\\"{x:542,y:414,t:1527635694866};\\\", \\\"{x:542,y:413,t:1527635694882};\\\", \\\"{x:542,y:410,t:1527635694899};\\\", \\\"{x:542,y:408,t:1527635694916};\\\", \\\"{x:542,y:406,t:1527635694933};\\\", \\\"{x:542,y:404,t:1527635694949};\\\", \\\"{x:543,y:401,t:1527635694966};\\\", \\\"{x:548,y:397,t:1527635694983};\\\", \\\"{x:553,y:393,t:1527635694999};\\\", \\\"{x:559,y:391,t:1527635695016};\\\", \\\"{x:564,y:388,t:1527635695033};\\\", \\\"{x:574,y:382,t:1527635695050};\\\", \\\"{x:586,y:377,t:1527635695066};\\\", \\\"{x:598,y:370,t:1527635695083};\\\", \\\"{x:604,y:368,t:1527635695100};\\\", \\\"{x:613,y:364,t:1527635695116};\\\", \\\"{x:626,y:358,t:1527635695133};\\\", \\\"{x:651,y:349,t:1527635695150};\\\", \\\"{x:705,y:331,t:1527635695166};\\\", \\\"{x:835,y:292,t:1527635695183};\\\", \\\"{x:923,y:273,t:1527635695200};\\\", \\\"{x:998,y:263,t:1527635695217};\\\", \\\"{x:1076,y:250,t:1527635695233};\\\", \\\"{x:1128,y:239,t:1527635695250};\\\", \\\"{x:1179,y:229,t:1527635695268};\\\", \\\"{x:1223,y:219,t:1527635695283};\\\", \\\"{x:1243,y:214,t:1527635695300};\\\", \\\"{x:1261,y:208,t:1527635695317};\\\", \\\"{x:1274,y:205,t:1527635695333};\\\", \\\"{x:1285,y:201,t:1527635695350};\\\", \\\"{x:1301,y:194,t:1527635695367};\\\", \\\"{x:1309,y:191,t:1527635695384};\\\", \\\"{x:1315,y:188,t:1527635695400};\\\", \\\"{x:1328,y:182,t:1527635695417};\\\", \\\"{x:1336,y:179,t:1527635695434};\\\", \\\"{x:1346,y:177,t:1527635695450};\\\", \\\"{x:1346,y:176,t:1527635695467};\\\", \\\"{x:1347,y:176,t:1527635695519};\\\", \\\"{x:1348,y:175,t:1527635695592};\\\", \\\"{x:1352,y:176,t:1527635695601};\\\", \\\"{x:1357,y:176,t:1527635695617};\\\", \\\"{x:1361,y:176,t:1527635695634};\\\", \\\"{x:1369,y:176,t:1527635695655};\\\", \\\"{x:1370,y:176,t:1527635695667};\\\", \\\"{x:1391,y:177,t:1527635695684};\\\", \\\"{x:1398,y:177,t:1527635695701};\\\", \\\"{x:1415,y:177,t:1527635695717};\\\", \\\"{x:1441,y:177,t:1527635695734};\\\", \\\"{x:1459,y:171,t:1527635695751};\\\", \\\"{x:1462,y:171,t:1527635695768};\\\", \\\"{x:1464,y:171,t:1527635695784};\\\", \\\"{x:1469,y:169,t:1527635695801};\\\", \\\"{x:1471,y:168,t:1527635695817};\\\", \\\"{x:1473,y:168,t:1527635695834};\\\", \\\"{x:1480,y:164,t:1527635695851};\\\", \\\"{x:1487,y:160,t:1527635695868};\\\", \\\"{x:1490,y:158,t:1527635695884};\\\", \\\"{x:1491,y:158,t:1527635695901};\\\", \\\"{x:1492,y:157,t:1527635695918};\\\", \\\"{x:1493,y:157,t:1527635695959};\\\", \\\"{x:1494,y:157,t:1527635695983};\\\", \\\"{x:1498,y:157,t:1527635695991};\\\", \\\"{x:1501,y:157,t:1527635696001};\\\", \\\"{x:1512,y:166,t:1527635696018};\\\", \\\"{x:1524,y:178,t:1527635696035};\\\", \\\"{x:1539,y:201,t:1527635696051};\\\", \\\"{x:1556,y:228,t:1527635696068};\\\", \\\"{x:1566,y:260,t:1527635696085};\\\", \\\"{x:1581,y:306,t:1527635696103};\\\", \\\"{x:1591,y:350,t:1527635696118};\\\", \\\"{x:1605,y:413,t:1527635696135};\\\", \\\"{x:1613,y:463,t:1527635696152};\\\", \\\"{x:1616,y:515,t:1527635696168};\\\", \\\"{x:1618,y:571,t:1527635696185};\\\", \\\"{x:1629,y:628,t:1527635696202};\\\", \\\"{x:1632,y:657,t:1527635696218};\\\", \\\"{x:1632,y:684,t:1527635696235};\\\", \\\"{x:1632,y:710,t:1527635696252};\\\", \\\"{x:1633,y:737,t:1527635696269};\\\", \\\"{x:1635,y:761,t:1527635696285};\\\", \\\"{x:1637,y:783,t:1527635696302};\\\", \\\"{x:1641,y:816,t:1527635696319};\\\", \\\"{x:1646,y:841,t:1527635696335};\\\", \\\"{x:1653,y:860,t:1527635696352};\\\", \\\"{x:1659,y:877,t:1527635696369};\\\", \\\"{x:1665,y:885,t:1527635696385};\\\", \\\"{x:1667,y:888,t:1527635696402};\\\", \\\"{x:1670,y:890,t:1527635696419};\\\", \\\"{x:1672,y:892,t:1527635696436};\\\", \\\"{x:1672,y:893,t:1527635696452};\\\", \\\"{x:1673,y:894,t:1527635696469};\\\", \\\"{x:1674,y:894,t:1527635696543};\\\", \\\"{x:1674,y:895,t:1527635696552};\\\", \\\"{x:1664,y:900,t:1527635696569};\\\", \\\"{x:1653,y:902,t:1527635696586};\\\", \\\"{x:1631,y:905,t:1527635696602};\\\", \\\"{x:1601,y:905,t:1527635696620};\\\", \\\"{x:1563,y:905,t:1527635696636};\\\", \\\"{x:1524,y:905,t:1527635696652};\\\", \\\"{x:1505,y:907,t:1527635696670};\\\", \\\"{x:1487,y:907,t:1527635696686};\\\", \\\"{x:1469,y:908,t:1527635696704};\\\", \\\"{x:1456,y:912,t:1527635696719};\\\", \\\"{x:1444,y:914,t:1527635696736};\\\", \\\"{x:1429,y:916,t:1527635696753};\\\", \\\"{x:1419,y:917,t:1527635696769};\\\", \\\"{x:1412,y:917,t:1527635696786};\\\", \\\"{x:1406,y:918,t:1527635696803};\\\", \\\"{x:1401,y:918,t:1527635696819};\\\", \\\"{x:1397,y:918,t:1527635696836};\\\", \\\"{x:1396,y:918,t:1527635696853};\\\", \\\"{x:1395,y:918,t:1527635696870};\\\", \\\"{x:1394,y:919,t:1527635696904};\\\", \\\"{x:1393,y:919,t:1527635696920};\\\", \\\"{x:1390,y:919,t:1527635696936};\\\", \\\"{x:1388,y:920,t:1527635696953};\\\", \\\"{x:1385,y:920,t:1527635696970};\\\", \\\"{x:1384,y:921,t:1527635696986};\\\", \\\"{x:1382,y:921,t:1527635697003};\\\", \\\"{x:1381,y:921,t:1527635697020};\\\", \\\"{x:1379,y:921,t:1527635697037};\\\", \\\"{x:1375,y:923,t:1527635697053};\\\", \\\"{x:1372,y:923,t:1527635697070};\\\", \\\"{x:1367,y:924,t:1527635697087};\\\", \\\"{x:1364,y:925,t:1527635697103};\\\", \\\"{x:1363,y:925,t:1527635697263};\\\", \\\"{x:1362,y:925,t:1527635697287};\\\", \\\"{x:1361,y:925,t:1527635697311};\\\", \\\"{x:1360,y:925,t:1527635697343};\\\", \\\"{x:1359,y:925,t:1527635697354};\\\", \\\"{x:1358,y:925,t:1527635697371};\\\", \\\"{x:1357,y:925,t:1527635697387};\\\", \\\"{x:1356,y:925,t:1527635697404};\\\", \\\"{x:1355,y:925,t:1527635697421};\\\", \\\"{x:1354,y:925,t:1527635697437};\\\", \\\"{x:1353,y:925,t:1527635697454};\\\", \\\"{x:1352,y:925,t:1527635697471};\\\", \\\"{x:1351,y:925,t:1527635697511};\\\", \\\"{x:1350,y:925,t:1527635697623};\\\", \\\"{x:1349,y:924,t:1527635697880};\\\", \\\"{x:1349,y:922,t:1527635697889};\\\", \\\"{x:1350,y:921,t:1527635697905};\\\", \\\"{x:1350,y:919,t:1527635697921};\\\", \\\"{x:1350,y:918,t:1527635697938};\\\", \\\"{x:1350,y:917,t:1527635697955};\\\", \\\"{x:1351,y:917,t:1527635697991};\\\", \\\"{x:1351,y:916,t:1527635698006};\\\", \\\"{x:1351,y:915,t:1527635698119};\\\", \\\"{x:1351,y:914,t:1527635698127};\\\", \\\"{x:1351,y:912,t:1527635698139};\\\", \\\"{x:1352,y:908,t:1527635698155};\\\", \\\"{x:1354,y:903,t:1527635698172};\\\", \\\"{x:1355,y:899,t:1527635698190};\\\", \\\"{x:1356,y:890,t:1527635698206};\\\", \\\"{x:1358,y:883,t:1527635698222};\\\", \\\"{x:1360,y:873,t:1527635698238};\\\", \\\"{x:1360,y:865,t:1527635698255};\\\", \\\"{x:1360,y:856,t:1527635698272};\\\", \\\"{x:1360,y:844,t:1527635698289};\\\", \\\"{x:1360,y:835,t:1527635698306};\\\", \\\"{x:1360,y:825,t:1527635698322};\\\", \\\"{x:1359,y:812,t:1527635698340};\\\", \\\"{x:1356,y:800,t:1527635698356};\\\", \\\"{x:1354,y:786,t:1527635698373};\\\", \\\"{x:1351,y:766,t:1527635698389};\\\", \\\"{x:1348,y:749,t:1527635698406};\\\", \\\"{x:1348,y:739,t:1527635698423};\\\", \\\"{x:1347,y:726,t:1527635698439};\\\", \\\"{x:1346,y:720,t:1527635698457};\\\", \\\"{x:1343,y:710,t:1527635698473};\\\", \\\"{x:1343,y:706,t:1527635698489};\\\", \\\"{x:1341,y:699,t:1527635698507};\\\", \\\"{x:1339,y:694,t:1527635698523};\\\", \\\"{x:1336,y:687,t:1527635698539};\\\", \\\"{x:1335,y:680,t:1527635698556};\\\", \\\"{x:1333,y:677,t:1527635698574};\\\", \\\"{x:1332,y:674,t:1527635698590};\\\", \\\"{x:1331,y:671,t:1527635698606};\\\", \\\"{x:1331,y:668,t:1527635698623};\\\", \\\"{x:1331,y:667,t:1527635698647};\\\", \\\"{x:1331,y:666,t:1527635698695};\\\", \\\"{x:1332,y:663,t:1527635698719};\\\", \\\"{x:1334,y:663,t:1527635698727};\\\", \\\"{x:1337,y:662,t:1527635698740};\\\", \\\"{x:1341,y:660,t:1527635698757};\\\", \\\"{x:1344,y:658,t:1527635698773};\\\", \\\"{x:1345,y:657,t:1527635698791};\\\", \\\"{x:1346,y:657,t:1527635698815};\\\", \\\"{x:1347,y:657,t:1527635698823};\\\", \\\"{x:1343,y:657,t:1527635699159};\\\", \\\"{x:1340,y:659,t:1527635699175};\\\", \\\"{x:1324,y:663,t:1527635699191};\\\", \\\"{x:1280,y:668,t:1527635699207};\\\", \\\"{x:1247,y:668,t:1527635699224};\\\", \\\"{x:1175,y:668,t:1527635699241};\\\", \\\"{x:1091,y:668,t:1527635699258};\\\", \\\"{x:986,y:668,t:1527635699274};\\\", \\\"{x:902,y:667,t:1527635699291};\\\", \\\"{x:821,y:654,t:1527635699307};\\\", \\\"{x:779,y:645,t:1527635699324};\\\", \\\"{x:753,y:640,t:1527635699341};\\\", \\\"{x:739,y:635,t:1527635699358};\\\", \\\"{x:731,y:633,t:1527635699374};\\\", \\\"{x:727,y:632,t:1527635699391};\\\", \\\"{x:718,y:624,t:1527635699408};\\\", \\\"{x:703,y:614,t:1527635699424};\\\", \\\"{x:686,y:602,t:1527635699441};\\\", \\\"{x:677,y:596,t:1527635699458};\\\", \\\"{x:672,y:592,t:1527635699474};\\\", \\\"{x:668,y:589,t:1527635699491};\\\", \\\"{x:666,y:588,t:1527635699508};\\\", \\\"{x:664,y:585,t:1527635699524};\\\", \\\"{x:660,y:581,t:1527635699541};\\\", \\\"{x:653,y:575,t:1527635699559};\\\", \\\"{x:628,y:560,t:1527635699575};\\\", \\\"{x:620,y:556,t:1527635699586};\\\", \\\"{x:593,y:548,t:1527635699603};\\\", \\\"{x:566,y:540,t:1527635699620};\\\", \\\"{x:517,y:529,t:1527635699636};\\\", \\\"{x:474,y:520,t:1527635699653};\\\", \\\"{x:448,y:515,t:1527635699669};\\\", \\\"{x:430,y:512,t:1527635699687};\\\", \\\"{x:410,y:507,t:1527635699703};\\\", \\\"{x:400,y:505,t:1527635699719};\\\", \\\"{x:384,y:502,t:1527635699737};\\\", \\\"{x:370,y:499,t:1527635699753};\\\", \\\"{x:354,y:496,t:1527635699770};\\\", \\\"{x:345,y:494,t:1527635699786};\\\", \\\"{x:342,y:494,t:1527635699804};\\\", \\\"{x:345,y:494,t:1527635699887};\\\", \\\"{x:356,y:491,t:1527635699903};\\\", \\\"{x:370,y:485,t:1527635699921};\\\", \\\"{x:383,y:477,t:1527635699936};\\\", \\\"{x:414,y:470,t:1527635699954};\\\", \\\"{x:489,y:463,t:1527635699970};\\\", \\\"{x:602,y:463,t:1527635699987};\\\", \\\"{x:722,y:459,t:1527635700003};\\\", \\\"{x:816,y:459,t:1527635700021};\\\", \\\"{x:865,y:457,t:1527635700036};\\\", \\\"{x:876,y:457,t:1527635700053};\\\", \\\"{x:878,y:457,t:1527635700070};\\\", \\\"{x:879,y:457,t:1527635700207};\\\", \\\"{x:878,y:455,t:1527635700220};\\\", \\\"{x:867,y:451,t:1527635700236};\\\", \\\"{x:855,y:447,t:1527635700253};\\\", \\\"{x:851,y:445,t:1527635700270};\\\", \\\"{x:848,y:444,t:1527635700287};\\\", \\\"{x:847,y:444,t:1527635700647};\\\", \\\"{x:845,y:444,t:1527635700792};\\\", \\\"{x:844,y:444,t:1527635700831};\\\", \\\"{x:843,y:444,t:1527635700863};\\\", \\\"{x:841,y:445,t:1527635700871};\\\", \\\"{x:838,y:449,t:1527635700887};\\\", \\\"{x:836,y:451,t:1527635700904};\\\", \\\"{x:834,y:454,t:1527635700920};\\\", \\\"{x:832,y:454,t:1527635700937};\\\", \\\"{x:832,y:455,t:1527635701031};\\\", \\\"{x:831,y:455,t:1527635701039};\\\", \\\"{x:830,y:455,t:1527635701055};\\\", \\\"{x:824,y:458,t:1527635701071};\\\", \\\"{x:812,y:465,t:1527635701088};\\\", \\\"{x:798,y:469,t:1527635701104};\\\", \\\"{x:788,y:475,t:1527635701122};\\\", \\\"{x:774,y:483,t:1527635701138};\\\", \\\"{x:760,y:489,t:1527635701154};\\\", \\\"{x:742,y:496,t:1527635701171};\\\", \\\"{x:726,y:503,t:1527635701188};\\\", \\\"{x:710,y:505,t:1527635701204};\\\", \\\"{x:690,y:510,t:1527635701221};\\\", \\\"{x:676,y:512,t:1527635701237};\\\", \\\"{x:662,y:512,t:1527635701254};\\\", \\\"{x:645,y:512,t:1527635701271};\\\", \\\"{x:630,y:512,t:1527635701287};\\\", \\\"{x:614,y:512,t:1527635701305};\\\", \\\"{x:604,y:512,t:1527635701321};\\\", \\\"{x:596,y:512,t:1527635701338};\\\", \\\"{x:592,y:511,t:1527635701354};\\\", \\\"{x:588,y:509,t:1527635701371};\\\", \\\"{x:580,y:507,t:1527635701388};\\\", \\\"{x:563,y:503,t:1527635701405};\\\", \\\"{x:539,y:498,t:1527635701422};\\\", \\\"{x:514,y:498,t:1527635701439};\\\", \\\"{x:483,y:497,t:1527635701455};\\\", \\\"{x:423,y:492,t:1527635701471};\\\", \\\"{x:395,y:490,t:1527635701488};\\\", \\\"{x:375,y:489,t:1527635701504};\\\", \\\"{x:370,y:487,t:1527635701521};\\\", \\\"{x:363,y:486,t:1527635701537};\\\", \\\"{x:348,y:485,t:1527635701554};\\\", \\\"{x:333,y:485,t:1527635701571};\\\", \\\"{x:320,y:485,t:1527635701588};\\\", \\\"{x:308,y:485,t:1527635701604};\\\", \\\"{x:299,y:485,t:1527635701621};\\\", \\\"{x:289,y:485,t:1527635701638};\\\", \\\"{x:274,y:485,t:1527635701654};\\\", \\\"{x:239,y:485,t:1527635701672};\\\", \\\"{x:199,y:491,t:1527635701687};\\\", \\\"{x:143,y:499,t:1527635701704};\\\", \\\"{x:81,y:503,t:1527635701723};\\\", \\\"{x:22,y:502,t:1527635701739};\\\", \\\"{x:0,y:501,t:1527635701754};\\\", \\\"{x:1,y:501,t:1527635701847};\\\", \\\"{x:5,y:501,t:1527635701863};\\\", \\\"{x:11,y:498,t:1527635701872};\\\", \\\"{x:25,y:495,t:1527635701889};\\\", \\\"{x:46,y:495,t:1527635701905};\\\", \\\"{x:61,y:492,t:1527635701922};\\\", \\\"{x:68,y:492,t:1527635701939};\\\", \\\"{x:77,y:492,t:1527635701954};\\\", \\\"{x:82,y:492,t:1527635701972};\\\", \\\"{x:88,y:492,t:1527635701989};\\\", \\\"{x:93,y:492,t:1527635702006};\\\", \\\"{x:99,y:492,t:1527635702021};\\\", \\\"{x:102,y:492,t:1527635702039};\\\", \\\"{x:103,y:491,t:1527635702056};\\\", \\\"{x:105,y:491,t:1527635702136};\\\", \\\"{x:107,y:491,t:1527635702143};\\\", \\\"{x:111,y:491,t:1527635702156};\\\", \\\"{x:121,y:490,t:1527635702171};\\\", \\\"{x:132,y:486,t:1527635702188};\\\", \\\"{x:139,y:482,t:1527635702205};\\\", \\\"{x:143,y:481,t:1527635702222};\\\", \\\"{x:144,y:481,t:1527635702247};\\\", \\\"{x:145,y:481,t:1527635702359};\\\", \\\"{x:145,y:481,t:1527635702359};\\\", \\\"{x:146,y:481,t:1527635702372};\\\", \\\"{x:147,y:481,t:1527635702389};\\\", \\\"{x:148,y:481,t:1527635702406};\\\", \\\"{x:151,y:481,t:1527635702423};\\\", \\\"{x:155,y:482,t:1527635702438};\\\", \\\"{x:177,y:489,t:1527635702456};\\\", \\\"{x:209,y:496,t:1527635702472};\\\", \\\"{x:245,y:507,t:1527635702489};\\\", \\\"{x:265,y:510,t:1527635702506};\\\", \\\"{x:282,y:515,t:1527635702523};\\\", \\\"{x:290,y:519,t:1527635702539};\\\", \\\"{x:306,y:529,t:1527635702556};\\\", \\\"{x:326,y:542,t:1527635702572};\\\", \\\"{x:358,y:562,t:1527635702588};\\\", \\\"{x:377,y:572,t:1527635702606};\\\", \\\"{x:390,y:575,t:1527635702622};\\\", \\\"{x:391,y:575,t:1527635702647};\\\", \\\"{x:383,y:575,t:1527635702679};\\\", \\\"{x:372,y:574,t:1527635702690};\\\", \\\"{x:330,y:561,t:1527635702705};\\\", \\\"{x:294,y:546,t:1527635702723};\\\", \\\"{x:268,y:539,t:1527635702739};\\\", \\\"{x:249,y:534,t:1527635702756};\\\", \\\"{x:240,y:529,t:1527635702772};\\\", \\\"{x:238,y:528,t:1527635702790};\\\", \\\"{x:238,y:526,t:1527635702815};\\\", \\\"{x:236,y:525,t:1527635702831};\\\", \\\"{x:236,y:524,t:1527635702839};\\\", \\\"{x:236,y:522,t:1527635702855};\\\", \\\"{x:234,y:517,t:1527635702873};\\\", \\\"{x:233,y:512,t:1527635702889};\\\", \\\"{x:231,y:507,t:1527635702906};\\\", \\\"{x:226,y:502,t:1527635702924};\\\", \\\"{x:220,y:499,t:1527635702940};\\\", \\\"{x:210,y:494,t:1527635702955};\\\", \\\"{x:204,y:491,t:1527635702973};\\\", \\\"{x:198,y:489,t:1527635702989};\\\", \\\"{x:194,y:487,t:1527635703007};\\\", \\\"{x:190,y:486,t:1527635703023};\\\", \\\"{x:175,y:483,t:1527635703039};\\\", \\\"{x:164,y:480,t:1527635703055};\\\", \\\"{x:154,y:479,t:1527635703072};\\\", \\\"{x:153,y:479,t:1527635703089};\\\", \\\"{x:152,y:479,t:1527635703106};\\\", \\\"{x:154,y:479,t:1527635703239};\\\", \\\"{x:158,y:482,t:1527635703255};\\\", \\\"{x:168,y:487,t:1527635703272};\\\", \\\"{x:181,y:493,t:1527635703289};\\\", \\\"{x:201,y:502,t:1527635703306};\\\", \\\"{x:233,y:521,t:1527635703322};\\\", \\\"{x:272,y:545,t:1527635703340};\\\", \\\"{x:339,y:575,t:1527635703355};\\\", \\\"{x:391,y:605,t:1527635703373};\\\", \\\"{x:425,y:622,t:1527635703390};\\\", \\\"{x:451,y:637,t:1527635703407};\\\", \\\"{x:460,y:640,t:1527635703422};\\\", \\\"{x:470,y:651,t:1527635703439};\\\", \\\"{x:477,y:663,t:1527635703456};\\\", \\\"{x:488,y:675,t:1527635703472};\\\", \\\"{x:498,y:693,t:1527635703489};\\\", \\\"{x:502,y:698,t:1527635703505};\\\", \\\"{x:507,y:699,t:1527635703523};\\\", \\\"{x:507,y:700,t:1527635703539};\\\", \\\"{x:509,y:700,t:1527635703591};\\\", \\\"{x:510,y:699,t:1527635703615};\\\", \\\"{x:512,y:699,t:1527635703735};\\\", \\\"{x:514,y:698,t:1527635703751};\\\", \\\"{x:514,y:697,t:1527635703767};\\\", \\\"{x:514,y:693,t:1527635703775};\\\", \\\"{x:514,y:690,t:1527635703790};\\\", \\\"{x:516,y:688,t:1527635703806};\\\", \\\"{x:516,y:686,t:1527635703822};\\\", \\\"{x:516,y:685,t:1527635703879};\\\", \\\"{x:516,y:685,t:1527635703959};\\\" ] }, { \\\"rt\\\": 41646, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 656270, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"8FE87\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:517,y:678,t:1527635732376};\\\", \\\"{x:554,y:602,t:1527635732385};\\\", \\\"{x:642,y:443,t:1527635732400};\\\", \\\"{x:654,y:424,t:1527635732416};\\\", \\\"{x:655,y:424,t:1527635732455};\\\", \\\"{x:656,y:424,t:1527635732462};\\\", \\\"{x:657,y:423,t:1527635732479};\\\", \\\"{x:642,y:423,t:1527635732895};\\\", \\\"{x:579,y:413,t:1527635732903};\\\", \\\"{x:541,y:404,t:1527635732913};\\\", \\\"{x:526,y:402,t:1527635732930};\\\", \\\"{x:525,y:394,t:1527635732945};\\\", \\\"{x:533,y:384,t:1527635732962};\\\", \\\"{x:533,y:383,t:1527635732982};\\\", \\\"{x:534,y:383,t:1527635733623};\\\", \\\"{x:535,y:382,t:1527635733630};\\\", \\\"{x:537,y:382,t:1527635733671};\\\", \\\"{x:543,y:382,t:1527635733702};\\\", \\\"{x:562,y:382,t:1527635733712};\\\", \\\"{x:597,y:382,t:1527635733730};\\\", \\\"{x:618,y:381,t:1527635733746};\\\", \\\"{x:629,y:378,t:1527635733762};\\\", \\\"{x:634,y:378,t:1527635733779};\\\", \\\"{x:635,y:378,t:1527635733796};\\\", \\\"{x:636,y:378,t:1527635733870};\\\", \\\"{x:637,y:377,t:1527635737662};\\\", \\\"{x:638,y:377,t:1527635737671};\\\", \\\"{x:639,y:377,t:1527635737682};\\\", \\\"{x:640,y:377,t:1527635737699};\\\", \\\"{x:641,y:377,t:1527635737716};\\\", \\\"{x:642,y:377,t:1527635737733};\\\", \\\"{x:649,y:377,t:1527635737749};\\\", \\\"{x:658,y:377,t:1527635737765};\\\", \\\"{x:674,y:377,t:1527635737783};\\\", \\\"{x:685,y:377,t:1527635737800};\\\", \\\"{x:700,y:377,t:1527635737816};\\\", \\\"{x:716,y:377,t:1527635737833};\\\", \\\"{x:731,y:377,t:1527635737849};\\\", \\\"{x:740,y:377,t:1527635737866};\\\", \\\"{x:746,y:377,t:1527635737882};\\\", \\\"{x:752,y:377,t:1527635737899};\\\", \\\"{x:762,y:377,t:1527635737915};\\\", \\\"{x:776,y:377,t:1527635737932};\\\", \\\"{x:784,y:377,t:1527635737950};\\\", \\\"{x:790,y:377,t:1527635737966};\\\", \\\"{x:799,y:377,t:1527635737983};\\\", \\\"{x:800,y:377,t:1527635738014};\\\", \\\"{x:809,y:382,t:1527635738487};\\\", \\\"{x:819,y:389,t:1527635738500};\\\", \\\"{x:832,y:399,t:1527635738517};\\\", \\\"{x:845,y:405,t:1527635738533};\\\", \\\"{x:850,y:409,t:1527635738550};\\\", \\\"{x:863,y:416,t:1527635738567};\\\", \\\"{x:870,y:420,t:1527635738583};\\\", \\\"{x:877,y:427,t:1527635738600};\\\", \\\"{x:883,y:430,t:1527635738617};\\\", \\\"{x:888,y:435,t:1527635738634};\\\", \\\"{x:890,y:437,t:1527635738650};\\\", \\\"{x:890,y:438,t:1527635738667};\\\", \\\"{x:891,y:439,t:1527635738684};\\\", \\\"{x:891,y:440,t:1527635738750};\\\", \\\"{x:891,y:441,t:1527635738822};\\\", \\\"{x:890,y:441,t:1527635738834};\\\", \\\"{x:884,y:441,t:1527635738850};\\\", \\\"{x:880,y:441,t:1527635738867};\\\", \\\"{x:875,y:441,t:1527635738884};\\\", \\\"{x:874,y:441,t:1527635738901};\\\", \\\"{x:873,y:441,t:1527635738918};\\\", \\\"{x:875,y:439,t:1527635739103};\\\", \\\"{x:891,y:431,t:1527635739119};\\\", \\\"{x:927,y:417,t:1527635739134};\\\", \\\"{x:953,y:413,t:1527635739151};\\\", \\\"{x:1002,y:412,t:1527635739168};\\\", \\\"{x:1066,y:412,t:1527635739185};\\\", \\\"{x:1130,y:419,t:1527635739201};\\\", \\\"{x:1179,y:430,t:1527635739218};\\\", \\\"{x:1225,y:440,t:1527635739235};\\\", \\\"{x:1260,y:451,t:1527635739251};\\\", \\\"{x:1296,y:469,t:1527635739267};\\\", \\\"{x:1338,y:489,t:1527635739284};\\\", \\\"{x:1380,y:508,t:1527635739301};\\\", \\\"{x:1418,y:530,t:1527635739318};\\\", \\\"{x:1446,y:553,t:1527635739334};\\\", \\\"{x:1460,y:567,t:1527635739351};\\\", \\\"{x:1472,y:582,t:1527635739368};\\\", \\\"{x:1483,y:599,t:1527635739385};\\\", \\\"{x:1488,y:612,t:1527635739401};\\\", \\\"{x:1490,y:618,t:1527635739418};\\\", \\\"{x:1491,y:620,t:1527635739435};\\\", \\\"{x:1491,y:622,t:1527635739452};\\\", \\\"{x:1490,y:626,t:1527635739471};\\\", \\\"{x:1486,y:626,t:1527635739484};\\\", \\\"{x:1481,y:626,t:1527635739502};\\\", \\\"{x:1481,y:627,t:1527635739670};\\\", \\\"{x:1479,y:626,t:1527635739687};\\\", \\\"{x:1478,y:626,t:1527635739702};\\\", \\\"{x:1476,y:626,t:1527635739718};\\\", \\\"{x:1474,y:625,t:1527635739735};\\\", \\\"{x:1473,y:625,t:1527635739752};\\\", \\\"{x:1472,y:625,t:1527635739768};\\\", \\\"{x:1466,y:624,t:1527635739785};\\\", \\\"{x:1456,y:623,t:1527635739802};\\\", \\\"{x:1442,y:623,t:1527635739817};\\\", \\\"{x:1426,y:623,t:1527635739835};\\\", \\\"{x:1409,y:623,t:1527635739852};\\\", \\\"{x:1389,y:623,t:1527635739868};\\\", \\\"{x:1371,y:623,t:1527635739885};\\\", \\\"{x:1359,y:623,t:1527635739902};\\\", \\\"{x:1349,y:623,t:1527635739918};\\\", \\\"{x:1346,y:623,t:1527635739935};\\\", \\\"{x:1344,y:623,t:1527635739952};\\\", \\\"{x:1343,y:622,t:1527635739969};\\\", \\\"{x:1341,y:622,t:1527635739985};\\\", \\\"{x:1335,y:621,t:1527635740002};\\\", \\\"{x:1321,y:621,t:1527635740019};\\\", \\\"{x:1296,y:621,t:1527635740035};\\\", \\\"{x:1252,y:621,t:1527635740052};\\\", \\\"{x:1182,y:624,t:1527635740069};\\\", \\\"{x:1112,y:623,t:1527635740084};\\\", \\\"{x:1027,y:604,t:1527635740102};\\\", \\\"{x:888,y:591,t:1527635740118};\\\", \\\"{x:800,y:583,t:1527635740134};\\\", \\\"{x:719,y:581,t:1527635740151};\\\", \\\"{x:669,y:575,t:1527635740169};\\\", \\\"{x:647,y:573,t:1527635740185};\\\", \\\"{x:632,y:570,t:1527635740202};\\\", \\\"{x:623,y:566,t:1527635740218};\\\", \\\"{x:616,y:564,t:1527635740235};\\\", \\\"{x:608,y:560,t:1527635740251};\\\", \\\"{x:604,y:557,t:1527635740269};\\\", \\\"{x:599,y:554,t:1527635740286};\\\", \\\"{x:597,y:551,t:1527635740302};\\\", \\\"{x:591,y:547,t:1527635740319};\\\", \\\"{x:588,y:542,t:1527635740336};\\\", \\\"{x:578,y:528,t:1527635740352};\\\", \\\"{x:573,y:520,t:1527635740368};\\\", \\\"{x:572,y:514,t:1527635740385};\\\", \\\"{x:568,y:504,t:1527635740402};\\\", \\\"{x:564,y:493,t:1527635740419};\\\", \\\"{x:561,y:480,t:1527635740436};\\\", \\\"{x:559,y:471,t:1527635740452};\\\", \\\"{x:558,y:467,t:1527635740469};\\\", \\\"{x:558,y:465,t:1527635740486};\\\", \\\"{x:558,y:463,t:1527635740502};\\\", \\\"{x:558,y:459,t:1527635740519};\\\", \\\"{x:558,y:453,t:1527635740536};\\\", \\\"{x:558,y:447,t:1527635740552};\\\", \\\"{x:558,y:441,t:1527635740569};\\\", \\\"{x:558,y:432,t:1527635740586};\\\", \\\"{x:558,y:427,t:1527635740602};\\\", \\\"{x:558,y:424,t:1527635740619};\\\", \\\"{x:558,y:422,t:1527635740636};\\\", \\\"{x:558,y:420,t:1527635740652};\\\", \\\"{x:558,y:419,t:1527635740669};\\\", \\\"{x:558,y:416,t:1527635740686};\\\", \\\"{x:558,y:414,t:1527635740702};\\\", \\\"{x:558,y:410,t:1527635740719};\\\", \\\"{x:559,y:409,t:1527635740736};\\\", \\\"{x:562,y:405,t:1527635740752};\\\", \\\"{x:565,y:404,t:1527635740769};\\\", \\\"{x:566,y:403,t:1527635740785};\\\", \\\"{x:569,y:401,t:1527635740802};\\\", \\\"{x:572,y:399,t:1527635740819};\\\", \\\"{x:576,y:398,t:1527635740836};\\\", \\\"{x:579,y:396,t:1527635740852};\\\", \\\"{x:581,y:396,t:1527635740868};\\\", \\\"{x:584,y:395,t:1527635740886};\\\", \\\"{x:587,y:393,t:1527635740902};\\\", \\\"{x:593,y:391,t:1527635740918};\\\", \\\"{x:596,y:389,t:1527635740936};\\\", \\\"{x:600,y:387,t:1527635740951};\\\", \\\"{x:605,y:386,t:1527635740969};\\\", \\\"{x:614,y:385,t:1527635740985};\\\", \\\"{x:644,y:385,t:1527635741002};\\\", \\\"{x:697,y:385,t:1527635741019};\\\", \\\"{x:774,y:385,t:1527635741036};\\\", \\\"{x:830,y:385,t:1527635741052};\\\", \\\"{x:883,y:385,t:1527635741068};\\\", \\\"{x:923,y:385,t:1527635741086};\\\", \\\"{x:959,y:385,t:1527635741102};\\\", \\\"{x:1019,y:387,t:1527635741118};\\\", \\\"{x:1072,y:401,t:1527635741136};\\\", \\\"{x:1125,y:416,t:1527635741152};\\\", \\\"{x:1162,y:426,t:1527635741169};\\\", \\\"{x:1202,y:443,t:1527635741185};\\\", \\\"{x:1239,y:454,t:1527635741202};\\\", \\\"{x:1267,y:467,t:1527635741219};\\\", \\\"{x:1294,y:483,t:1527635741236};\\\", \\\"{x:1313,y:497,t:1527635741252};\\\", \\\"{x:1330,y:509,t:1527635741268};\\\", \\\"{x:1340,y:523,t:1527635741286};\\\", \\\"{x:1346,y:533,t:1527635741302};\\\", \\\"{x:1358,y:552,t:1527635741319};\\\", \\\"{x:1364,y:562,t:1527635741336};\\\", \\\"{x:1366,y:570,t:1527635741352};\\\", \\\"{x:1369,y:577,t:1527635741369};\\\", \\\"{x:1370,y:586,t:1527635741385};\\\", \\\"{x:1371,y:595,t:1527635741402};\\\", \\\"{x:1371,y:600,t:1527635741419};\\\", \\\"{x:1371,y:605,t:1527635741435};\\\", \\\"{x:1371,y:610,t:1527635741452};\\\", \\\"{x:1371,y:613,t:1527635741469};\\\", \\\"{x:1371,y:615,t:1527635741484};\\\", \\\"{x:1371,y:616,t:1527635741502};\\\", \\\"{x:1370,y:616,t:1527635741518};\\\", \\\"{x:1370,y:617,t:1527635741559};\\\", \\\"{x:1370,y:618,t:1527635741591};\\\", \\\"{x:1369,y:619,t:1527635741703};\\\", \\\"{x:1368,y:620,t:1527635741719};\\\", \\\"{x:1368,y:621,t:1527635741734};\\\", \\\"{x:1367,y:621,t:1527635741752};\\\", \\\"{x:1366,y:622,t:1527635741774};\\\", \\\"{x:1365,y:623,t:1527635741790};\\\", \\\"{x:1363,y:624,t:1527635741802};\\\", \\\"{x:1361,y:625,t:1527635741838};\\\", \\\"{x:1359,y:625,t:1527635741852};\\\", \\\"{x:1351,y:626,t:1527635741869};\\\", \\\"{x:1341,y:628,t:1527635741885};\\\", \\\"{x:1322,y:628,t:1527635741902};\\\", \\\"{x:1296,y:628,t:1527635741918};\\\", \\\"{x:1279,y:628,t:1527635741935};\\\", \\\"{x:1264,y:628,t:1527635741952};\\\", \\\"{x:1251,y:627,t:1527635741969};\\\", \\\"{x:1235,y:625,t:1527635741985};\\\", \\\"{x:1218,y:622,t:1527635742001};\\\", \\\"{x:1201,y:620,t:1527635742019};\\\", \\\"{x:1186,y:617,t:1527635742035};\\\", \\\"{x:1166,y:615,t:1527635742051};\\\", \\\"{x:1149,y:612,t:1527635742069};\\\", \\\"{x:1135,y:609,t:1527635742085};\\\", \\\"{x:1131,y:608,t:1527635742102};\\\", \\\"{x:1124,y:606,t:1527635742118};\\\", \\\"{x:1118,y:604,t:1527635742135};\\\", \\\"{x:1107,y:602,t:1527635742152};\\\", \\\"{x:1090,y:597,t:1527635742169};\\\", \\\"{x:1067,y:592,t:1527635742185};\\\", \\\"{x:1046,y:586,t:1527635742202};\\\", \\\"{x:1023,y:579,t:1527635742219};\\\", \\\"{x:1003,y:570,t:1527635742235};\\\", \\\"{x:983,y:562,t:1527635742252};\\\", \\\"{x:969,y:557,t:1527635742269};\\\", \\\"{x:958,y:549,t:1527635742284};\\\", \\\"{x:947,y:542,t:1527635742301};\\\", \\\"{x:936,y:534,t:1527635742318};\\\", \\\"{x:928,y:527,t:1527635742335};\\\", \\\"{x:918,y:521,t:1527635742352};\\\", \\\"{x:917,y:519,t:1527635742370};\\\", \\\"{x:917,y:518,t:1527635742390};\\\", \\\"{x:916,y:518,t:1527635742694};\\\", \\\"{x:914,y:518,t:1527635742704};\\\", \\\"{x:911,y:517,t:1527635742721};\\\", \\\"{x:902,y:511,t:1527635742738};\\\", \\\"{x:890,y:503,t:1527635742754};\\\", \\\"{x:878,y:497,t:1527635742771};\\\", \\\"{x:862,y:493,t:1527635742788};\\\", \\\"{x:849,y:486,t:1527635742803};\\\", \\\"{x:841,y:483,t:1527635742821};\\\", \\\"{x:837,y:481,t:1527635742837};\\\", \\\"{x:835,y:479,t:1527635742854};\\\", \\\"{x:831,y:474,t:1527635742870};\\\", \\\"{x:829,y:471,t:1527635742887};\\\", \\\"{x:828,y:469,t:1527635742904};\\\", \\\"{x:827,y:468,t:1527635742921};\\\", \\\"{x:827,y:467,t:1527635742937};\\\", \\\"{x:827,y:466,t:1527635742954};\\\", \\\"{x:826,y:465,t:1527635742971};\\\", \\\"{x:826,y:464,t:1527635742987};\\\", \\\"{x:826,y:463,t:1527635743004};\\\", \\\"{x:826,y:461,t:1527635743021};\\\", \\\"{x:826,y:460,t:1527635743038};\\\", \\\"{x:826,y:459,t:1527635743054};\\\", \\\"{x:826,y:458,t:1527635743071};\\\", \\\"{x:828,y:457,t:1527635743088};\\\", \\\"{x:829,y:457,t:1527635743104};\\\", \\\"{x:827,y:457,t:1527635743271};\\\", \\\"{x:819,y:460,t:1527635743288};\\\", \\\"{x:811,y:464,t:1527635743305};\\\", \\\"{x:802,y:467,t:1527635743322};\\\", \\\"{x:785,y:473,t:1527635743338};\\\", \\\"{x:760,y:478,t:1527635743354};\\\", \\\"{x:714,y:488,t:1527635743372};\\\", \\\"{x:645,y:495,t:1527635743387};\\\", \\\"{x:546,y:509,t:1527635743405};\\\", \\\"{x:460,y:520,t:1527635743421};\\\", \\\"{x:379,y:529,t:1527635743438};\\\", \\\"{x:318,y:529,t:1527635743454};\\\", \\\"{x:254,y:529,t:1527635743472};\\\", \\\"{x:221,y:532,t:1527635743488};\\\", \\\"{x:206,y:535,t:1527635743505};\\\", \\\"{x:193,y:538,t:1527635743521};\\\", \\\"{x:189,y:538,t:1527635743538};\\\", \\\"{x:188,y:538,t:1527635743662};\\\", \\\"{x:187,y:538,t:1527635743671};\\\", \\\"{x:184,y:537,t:1527635743688};\\\", \\\"{x:178,y:533,t:1527635743705};\\\", \\\"{x:175,y:530,t:1527635743721};\\\", \\\"{x:171,y:527,t:1527635743738};\\\", \\\"{x:170,y:525,t:1527635743755};\\\", \\\"{x:168,y:522,t:1527635743772};\\\", \\\"{x:167,y:517,t:1527635743788};\\\", \\\"{x:164,y:511,t:1527635743805};\\\", \\\"{x:164,y:502,t:1527635743822};\\\", \\\"{x:163,y:500,t:1527635743838};\\\", \\\"{x:162,y:495,t:1527635743855};\\\", \\\"{x:161,y:494,t:1527635743872};\\\", \\\"{x:160,y:491,t:1527635743888};\\\", \\\"{x:160,y:490,t:1527635743951};\\\", \\\"{x:160,y:489,t:1527635744302};\\\", \\\"{x:161,y:488,t:1527635744310};\\\", \\\"{x:163,y:487,t:1527635744326};\\\", \\\"{x:169,y:485,t:1527635744607};\\\", \\\"{x:178,y:483,t:1527635744622};\\\", \\\"{x:282,y:508,t:1527635744639};\\\", \\\"{x:375,y:528,t:1527635744655};\\\", \\\"{x:477,y:539,t:1527635744672};\\\", \\\"{x:547,y:552,t:1527635744689};\\\", \\\"{x:596,y:562,t:1527635744706};\\\", \\\"{x:624,y:568,t:1527635744722};\\\", \\\"{x:639,y:574,t:1527635744740};\\\", \\\"{x:645,y:579,t:1527635744756};\\\", \\\"{x:650,y:584,t:1527635744772};\\\", \\\"{x:656,y:588,t:1527635744789};\\\", \\\"{x:660,y:592,t:1527635744805};\\\", \\\"{x:665,y:595,t:1527635744823};\\\", \\\"{x:666,y:598,t:1527635744839};\\\", \\\"{x:672,y:606,t:1527635744856};\\\", \\\"{x:678,y:618,t:1527635744872};\\\", \\\"{x:683,y:628,t:1527635744889};\\\", \\\"{x:687,y:634,t:1527635744906};\\\", \\\"{x:688,y:636,t:1527635744923};\\\", \\\"{x:689,y:639,t:1527635744939};\\\", \\\"{x:690,y:644,t:1527635744956};\\\", \\\"{x:690,y:650,t:1527635744972};\\\", \\\"{x:690,y:657,t:1527635744989};\\\", \\\"{x:688,y:660,t:1527635745005};\\\", \\\"{x:678,y:666,t:1527635745022};\\\", \\\"{x:648,y:676,t:1527635745039};\\\", \\\"{x:634,y:678,t:1527635745055};\\\", \\\"{x:627,y:681,t:1527635745073};\\\", \\\"{x:608,y:682,t:1527635745089};\\\", \\\"{x:591,y:686,t:1527635745106};\\\", \\\"{x:585,y:686,t:1527635745122};\\\", \\\"{x:584,y:686,t:1527635745139};\\\", \\\"{x:583,y:686,t:1527635745156};\\\", \\\"{x:582,y:686,t:1527635745352};\\\", \\\"{x:578,y:686,t:1527635745359};\\\", \\\"{x:573,y:686,t:1527635745372};\\\", \\\"{x:570,y:685,t:1527635745389};\\\", \\\"{x:561,y:683,t:1527635745407};\\\", \\\"{x:548,y:680,t:1527635745422};\\\", \\\"{x:547,y:680,t:1527635745439};\\\", \\\"{x:546,y:680,t:1527635745542};\\\", \\\"{x:546,y:679,t:1527635745574};\\\", \\\"{x:545,y:679,t:1527635745615};\\\", \\\"{x:544,y:679,t:1527635745647};\\\", \\\"{x:541,y:678,t:1527635745657};\\\", \\\"{x:540,y:678,t:1527635746262};\\\", \\\"{x:539,y:677,t:1527635747191};\\\", \\\"{x:538,y:677,t:1527635747215};\\\", \\\"{x:537,y:677,t:1527635747304};\\\", \\\"{x:536,y:677,t:1527635747311};\\\", \\\"{x:536,y:676,t:1527635747862};\\\", \\\"{x:536,y:675,t:1527635747878};\\\", \\\"{x:537,y:673,t:1527635747891};\\\", \\\"{x:540,y:671,t:1527635747908};\\\", \\\"{x:543,y:670,t:1527635747925};\\\", \\\"{x:551,y:667,t:1527635747941};\\\" ] }, { \\\"rt\\\": 17655, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 675145, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"8FE87\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -X -04 PM-04 PM-X -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:702,y:671,t:1527635748051};\\\", \\\"{x:711,y:671,t:1527635748058};\\\", \\\"{x:746,y:676,t:1527635748076};\\\", \\\"{x:763,y:678,t:1527635748091};\\\", \\\"{x:779,y:683,t:1527635748109};\\\", \\\"{x:785,y:687,t:1527635748125};\\\", \\\"{x:788,y:689,t:1527635748143};\\\", \\\"{x:789,y:690,t:1527635748158};\\\", \\\"{x:790,y:692,t:1527635748175};\\\", \\\"{x:791,y:693,t:1527635748192};\\\", \\\"{x:791,y:698,t:1527635748208};\\\", \\\"{x:791,y:704,t:1527635748225};\\\", \\\"{x:791,y:706,t:1527635748242};\\\", \\\"{x:788,y:709,t:1527635748258};\\\", \\\"{x:787,y:713,t:1527635748275};\\\", \\\"{x:785,y:715,t:1527635748292};\\\", \\\"{x:783,y:716,t:1527635748309};\\\", \\\"{x:782,y:718,t:1527635748326};\\\", \\\"{x:774,y:722,t:1527635748343};\\\", \\\"{x:772,y:723,t:1527635748359};\\\", \\\"{x:765,y:728,t:1527635748375};\\\", \\\"{x:758,y:731,t:1527635748392};\\\", \\\"{x:750,y:735,t:1527635748409};\\\", \\\"{x:740,y:740,t:1527635748426};\\\", \\\"{x:725,y:741,t:1527635748443};\\\", \\\"{x:653,y:742,t:1527635748532};\\\", \\\"{x:646,y:742,t:1527635748542};\\\", \\\"{x:641,y:741,t:1527635748558};\\\", \\\"{x:639,y:740,t:1527635748575};\\\", \\\"{x:638,y:740,t:1527635748679};\\\", \\\"{x:637,y:738,t:1527635748692};\\\", \\\"{x:635,y:735,t:1527635748709};\\\", \\\"{x:633,y:730,t:1527635748725};\\\", \\\"{x:630,y:720,t:1527635748742};\\\", \\\"{x:626,y:709,t:1527635748758};\\\", \\\"{x:623,y:694,t:1527635748775};\\\", \\\"{x:613,y:676,t:1527635748792};\\\", \\\"{x:604,y:661,t:1527635748809};\\\", \\\"{x:595,y:645,t:1527635748825};\\\", \\\"{x:580,y:624,t:1527635748843};\\\", \\\"{x:567,y:605,t:1527635748859};\\\", \\\"{x:558,y:591,t:1527635748875};\\\", \\\"{x:543,y:572,t:1527635748894};\\\", \\\"{x:523,y:546,t:1527635748910};\\\", \\\"{x:505,y:529,t:1527635748926};\\\", \\\"{x:486,y:506,t:1527635748943};\\\", \\\"{x:474,y:495,t:1527635748959};\\\", \\\"{x:458,y:482,t:1527635748975};\\\", \\\"{x:448,y:469,t:1527635748993};\\\", \\\"{x:442,y:461,t:1527635749010};\\\", \\\"{x:440,y:456,t:1527635749025};\\\", \\\"{x:435,y:447,t:1527635749042};\\\", \\\"{x:433,y:441,t:1527635749060};\\\", \\\"{x:428,y:430,t:1527635749077};\\\", \\\"{x:424,y:423,t:1527635749092};\\\", \\\"{x:423,y:420,t:1527635749109};\\\", \\\"{x:423,y:417,t:1527635749127};\\\", \\\"{x:422,y:416,t:1527635749143};\\\", \\\"{x:421,y:414,t:1527635749159};\\\", \\\"{x:421,y:411,t:1527635749177};\\\", \\\"{x:421,y:410,t:1527635749193};\\\", \\\"{x:421,y:409,t:1527635749209};\\\", \\\"{x:420,y:408,t:1527635749227};\\\", \\\"{x:420,y:407,t:1527635749263};\\\", \\\"{x:420,y:406,t:1527635749320};\\\", \\\"{x:420,y:405,t:1527635749535};\\\", \\\"{x:420,y:404,t:1527635749591};\\\", \\\"{x:422,y:401,t:1527635749935};\\\", \\\"{x:425,y:401,t:1527635749943};\\\", \\\"{x:431,y:397,t:1527635749960};\\\", \\\"{x:435,y:396,t:1527635749977};\\\", \\\"{x:436,y:396,t:1527635749993};\\\", \\\"{x:438,y:394,t:1527635750010};\\\", \\\"{x:439,y:394,t:1527635750047};\\\", \\\"{x:440,y:394,t:1527635750060};\\\", \\\"{x:441,y:394,t:1527635750079};\\\", \\\"{x:443,y:394,t:1527635750094};\\\", \\\"{x:444,y:394,t:1527635750152};\\\", \\\"{x:445,y:393,t:1527635750167};\\\", \\\"{x:446,y:393,t:1527635750191};\\\", \\\"{x:447,y:393,t:1527635750215};\\\", \\\"{x:448,y:391,t:1527635750226};\\\", \\\"{x:450,y:391,t:1527635750244};\\\", \\\"{x:456,y:391,t:1527635750261};\\\", \\\"{x:468,y:391,t:1527635750276};\\\", \\\"{x:481,y:391,t:1527635750297};\\\", \\\"{x:495,y:391,t:1527635750314};\\\", \\\"{x:498,y:390,t:1527635750330};\\\", \\\"{x:501,y:390,t:1527635750347};\\\", \\\"{x:502,y:390,t:1527635750364};\\\", \\\"{x:504,y:390,t:1527635750380};\\\", \\\"{x:505,y:390,t:1527635750397};\\\", \\\"{x:507,y:390,t:1527635750435};\\\", \\\"{x:508,y:390,t:1527635750451};\\\", \\\"{x:510,y:390,t:1527635750464};\\\", \\\"{x:511,y:390,t:1527635750481};\\\", \\\"{x:513,y:390,t:1527635750523};\\\", \\\"{x:514,y:390,t:1527635750555};\\\", \\\"{x:516,y:390,t:1527635750643};\\\", \\\"{x:517,y:390,t:1527635750675};\\\", \\\"{x:524,y:390,t:1527635750715};\\\", \\\"{x:536,y:390,t:1527635750731};\\\", \\\"{x:547,y:392,t:1527635750747};\\\", \\\"{x:552,y:392,t:1527635750764};\\\", \\\"{x:557,y:393,t:1527635750782};\\\", \\\"{x:560,y:393,t:1527635750797};\\\", \\\"{x:563,y:393,t:1527635750815};\\\", \\\"{x:568,y:395,t:1527635750832};\\\", \\\"{x:571,y:395,t:1527635750848};\\\", \\\"{x:572,y:395,t:1527635750864};\\\", \\\"{x:573,y:395,t:1527635750882};\\\", \\\"{x:574,y:395,t:1527635750899};\\\", \\\"{x:574,y:396,t:1527635750915};\\\", \\\"{x:575,y:396,t:1527635750939};\\\", \\\"{x:576,y:396,t:1527635750954};\\\", \\\"{x:576,y:397,t:1527635750965};\\\", \\\"{x:578,y:398,t:1527635750981};\\\", \\\"{x:580,y:399,t:1527635750997};\\\", \\\"{x:583,y:400,t:1527635751014};\\\", \\\"{x:587,y:402,t:1527635751031};\\\", \\\"{x:590,y:403,t:1527635751048};\\\", \\\"{x:597,y:407,t:1527635751065};\\\", \\\"{x:605,y:410,t:1527635751082};\\\", \\\"{x:611,y:414,t:1527635751098};\\\", \\\"{x:628,y:417,t:1527635751116};\\\", \\\"{x:638,y:420,t:1527635751131};\\\", \\\"{x:645,y:423,t:1527635751149};\\\", \\\"{x:648,y:424,t:1527635751164};\\\", \\\"{x:649,y:424,t:1527635751181};\\\", \\\"{x:649,y:425,t:1527635751199};\\\", \\\"{x:650,y:425,t:1527635751214};\\\", \\\"{x:651,y:425,t:1527635751580};\\\", \\\"{x:651,y:426,t:1527635751587};\\\", \\\"{x:647,y:426,t:1527635751599};\\\", \\\"{x:635,y:426,t:1527635751615};\\\", \\\"{x:628,y:426,t:1527635751631};\\\", \\\"{x:619,y:426,t:1527635751649};\\\", \\\"{x:612,y:423,t:1527635751666};\\\", \\\"{x:608,y:423,t:1527635751681};\\\", \\\"{x:604,y:423,t:1527635751698};\\\", \\\"{x:602,y:423,t:1527635751716};\\\", \\\"{x:601,y:423,t:1527635751732};\\\", \\\"{x:600,y:423,t:1527635751851};\\\", \\\"{x:601,y:423,t:1527635751899};\\\", \\\"{x:617,y:416,t:1527635751916};\\\", \\\"{x:634,y:412,t:1527635751932};\\\", \\\"{x:671,y:411,t:1527635751948};\\\", \\\"{x:718,y:411,t:1527635751965};\\\", \\\"{x:782,y:411,t:1527635751982};\\\", \\\"{x:874,y:412,t:1527635751999};\\\", \\\"{x:979,y:422,t:1527635752016};\\\", \\\"{x:1094,y:432,t:1527635752033};\\\", \\\"{x:1199,y:446,t:1527635752049};\\\", \\\"{x:1291,y:457,t:1527635752066};\\\", \\\"{x:1389,y:475,t:1527635752082};\\\", \\\"{x:1492,y:494,t:1527635752099};\\\", \\\"{x:1528,y:503,t:1527635752115};\\\", \\\"{x:1550,y:510,t:1527635752132};\\\", \\\"{x:1563,y:515,t:1527635752150};\\\", \\\"{x:1582,y:526,t:1527635752166};\\\", \\\"{x:1598,y:537,t:1527635752183};\\\", \\\"{x:1607,y:543,t:1527635752199};\\\", \\\"{x:1611,y:547,t:1527635752216};\\\", \\\"{x:1615,y:551,t:1527635752233};\\\", \\\"{x:1619,y:557,t:1527635752249};\\\", \\\"{x:1627,y:565,t:1527635752266};\\\", \\\"{x:1628,y:569,t:1527635752283};\\\", \\\"{x:1629,y:571,t:1527635752299};\\\", \\\"{x:1630,y:574,t:1527635752316};\\\", \\\"{x:1630,y:578,t:1527635752333};\\\", \\\"{x:1630,y:582,t:1527635752349};\\\", \\\"{x:1630,y:584,t:1527635752366};\\\", \\\"{x:1631,y:584,t:1527635752731};\\\", \\\"{x:1631,y:585,t:1527635752750};\\\", \\\"{x:1631,y:586,t:1527635752766};\\\", \\\"{x:1631,y:587,t:1527635752787};\\\", \\\"{x:1631,y:590,t:1527635752827};\\\", \\\"{x:1631,y:591,t:1527635752835};\\\", \\\"{x:1631,y:594,t:1527635752850};\\\", \\\"{x:1628,y:601,t:1527635752867};\\\", \\\"{x:1627,y:605,t:1527635752883};\\\", \\\"{x:1626,y:606,t:1527635752900};\\\", \\\"{x:1625,y:609,t:1527635752916};\\\", \\\"{x:1623,y:615,t:1527635752933};\\\", \\\"{x:1620,y:622,t:1527635752950};\\\", \\\"{x:1620,y:625,t:1527635752966};\\\", \\\"{x:1619,y:631,t:1527635752983};\\\", \\\"{x:1618,y:633,t:1527635753000};\\\", \\\"{x:1618,y:634,t:1527635753016};\\\", \\\"{x:1618,y:635,t:1527635753033};\\\", \\\"{x:1618,y:637,t:1527635753049};\\\", \\\"{x:1617,y:638,t:1527635753068};\\\", \\\"{x:1617,y:639,t:1527635753082};\\\", \\\"{x:1617,y:641,t:1527635753154};\\\", \\\"{x:1617,y:644,t:1527635753165};\\\", \\\"{x:1617,y:645,t:1527635753182};\\\", \\\"{x:1618,y:649,t:1527635753200};\\\", \\\"{x:1618,y:652,t:1527635753216};\\\", \\\"{x:1618,y:656,t:1527635753233};\\\", \\\"{x:1618,y:662,t:1527635753250};\\\", \\\"{x:1618,y:670,t:1527635753266};\\\", \\\"{x:1618,y:673,t:1527635753283};\\\", \\\"{x:1617,y:675,t:1527635753299};\\\", \\\"{x:1616,y:675,t:1527635753316};\\\", \\\"{x:1615,y:676,t:1527635753332};\\\", \\\"{x:1614,y:676,t:1527635753363};\\\", \\\"{x:1613,y:676,t:1527635753411};\\\", \\\"{x:1612,y:676,t:1527635753460};\\\", \\\"{x:1612,y:677,t:1527635753475};\\\", \\\"{x:1611,y:677,t:1527635753540};\\\", \\\"{x:1610,y:677,t:1527635753556};\\\", \\\"{x:1609,y:677,t:1527635753579};\\\", \\\"{x:1608,y:677,t:1527635753588};\\\", \\\"{x:1607,y:677,t:1527635753600};\\\", \\\"{x:1606,y:677,t:1527635753617};\\\", \\\"{x:1605,y:677,t:1527635753633};\\\", \\\"{x:1603,y:677,t:1527635753650};\\\", \\\"{x:1602,y:677,t:1527635753667};\\\", \\\"{x:1601,y:677,t:1527635753811};\\\", \\\"{x:1600,y:676,t:1527635753819};\\\", \\\"{x:1599,y:676,t:1527635753835};\\\", \\\"{x:1597,y:676,t:1527635753851};\\\", \\\"{x:1587,y:675,t:1527635753867};\\\", \\\"{x:1578,y:673,t:1527635753884};\\\", \\\"{x:1570,y:670,t:1527635753900};\\\", \\\"{x:1567,y:668,t:1527635753917};\\\", \\\"{x:1563,y:667,t:1527635753935};\\\", \\\"{x:1561,y:666,t:1527635753950};\\\", \\\"{x:1557,y:666,t:1527635753967};\\\", \\\"{x:1552,y:666,t:1527635753984};\\\", \\\"{x:1548,y:666,t:1527635754000};\\\", \\\"{x:1542,y:666,t:1527635754017};\\\", \\\"{x:1535,y:666,t:1527635754034};\\\", \\\"{x:1524,y:666,t:1527635754050};\\\", \\\"{x:1504,y:665,t:1527635754067};\\\", \\\"{x:1489,y:664,t:1527635754084};\\\", \\\"{x:1474,y:663,t:1527635754099};\\\", \\\"{x:1450,y:663,t:1527635754116};\\\", \\\"{x:1422,y:663,t:1527635754133};\\\", \\\"{x:1399,y:663,t:1527635754150};\\\", \\\"{x:1381,y:663,t:1527635754166};\\\", \\\"{x:1373,y:663,t:1527635754183};\\\", \\\"{x:1369,y:663,t:1527635754199};\\\", \\\"{x:1368,y:663,t:1527635754216};\\\", \\\"{x:1366,y:663,t:1527635754234};\\\", \\\"{x:1365,y:663,t:1527635754250};\\\", \\\"{x:1364,y:664,t:1527635754267};\\\", \\\"{x:1362,y:664,t:1527635754283};\\\", \\\"{x:1358,y:666,t:1527635754315};\\\", \\\"{x:1355,y:667,t:1527635754323};\\\", \\\"{x:1351,y:668,t:1527635754334};\\\", \\\"{x:1339,y:673,t:1527635754351};\\\", \\\"{x:1326,y:679,t:1527635754367};\\\", \\\"{x:1315,y:684,t:1527635754383};\\\", \\\"{x:1306,y:690,t:1527635754401};\\\", \\\"{x:1301,y:692,t:1527635754416};\\\", \\\"{x:1299,y:695,t:1527635754434};\\\", \\\"{x:1291,y:707,t:1527635754450};\\\", \\\"{x:1288,y:711,t:1527635754467};\\\", \\\"{x:1286,y:713,t:1527635754483};\\\", \\\"{x:1285,y:714,t:1527635754501};\\\", \\\"{x:1285,y:715,t:1527635754546};\\\", \\\"{x:1285,y:716,t:1527635754562};\\\", \\\"{x:1286,y:719,t:1527635754570};\\\", \\\"{x:1287,y:722,t:1527635754583};\\\", \\\"{x:1295,y:731,t:1527635754601};\\\", \\\"{x:1302,y:739,t:1527635754617};\\\", \\\"{x:1310,y:746,t:1527635754633};\\\", \\\"{x:1331,y:759,t:1527635754651};\\\", \\\"{x:1354,y:769,t:1527635754666};\\\", \\\"{x:1374,y:777,t:1527635754683};\\\", \\\"{x:1393,y:785,t:1527635754701};\\\", \\\"{x:1414,y:791,t:1527635754717};\\\", \\\"{x:1426,y:796,t:1527635754734};\\\", \\\"{x:1436,y:799,t:1527635754750};\\\", \\\"{x:1441,y:801,t:1527635754767};\\\", \\\"{x:1443,y:803,t:1527635754783};\\\", \\\"{x:1447,y:805,t:1527635754801};\\\", \\\"{x:1455,y:809,t:1527635754818};\\\", \\\"{x:1463,y:816,t:1527635754834};\\\", \\\"{x:1474,y:825,t:1527635754851};\\\", \\\"{x:1477,y:827,t:1527635754867};\\\", \\\"{x:1480,y:829,t:1527635754884};\\\", \\\"{x:1480,y:831,t:1527635754901};\\\", \\\"{x:1481,y:831,t:1527635754918};\\\", \\\"{x:1482,y:832,t:1527635754935};\\\", \\\"{x:1482,y:824,t:1527635755116};\\\", \\\"{x:1482,y:807,t:1527635755123};\\\", \\\"{x:1481,y:796,t:1527635755134};\\\", \\\"{x:1481,y:769,t:1527635755151};\\\", \\\"{x:1482,y:742,t:1527635755169};\\\", \\\"{x:1491,y:713,t:1527635755185};\\\", \\\"{x:1497,y:689,t:1527635755201};\\\", \\\"{x:1503,y:673,t:1527635755219};\\\", \\\"{x:1508,y:653,t:1527635755235};\\\", \\\"{x:1523,y:616,t:1527635755251};\\\", \\\"{x:1531,y:593,t:1527635755268};\\\", \\\"{x:1538,y:563,t:1527635755285};\\\", \\\"{x:1545,y:542,t:1527635755302};\\\", \\\"{x:1548,y:522,t:1527635755319};\\\", \\\"{x:1551,y:513,t:1527635755335};\\\", \\\"{x:1552,y:507,t:1527635755351};\\\", \\\"{x:1552,y:503,t:1527635755368};\\\", \\\"{x:1552,y:495,t:1527635755385};\\\", \\\"{x:1553,y:483,t:1527635755402};\\\", \\\"{x:1555,y:468,t:1527635755419};\\\", \\\"{x:1558,y:447,t:1527635755435};\\\", \\\"{x:1560,y:437,t:1527635755451};\\\", \\\"{x:1561,y:428,t:1527635755468};\\\", \\\"{x:1561,y:422,t:1527635755485};\\\", \\\"{x:1561,y:415,t:1527635755502};\\\", \\\"{x:1561,y:406,t:1527635755518};\\\", \\\"{x:1563,y:397,t:1527635755535};\\\", \\\"{x:1563,y:390,t:1527635755551};\\\", \\\"{x:1563,y:386,t:1527635755568};\\\", \\\"{x:1563,y:377,t:1527635755585};\\\", \\\"{x:1564,y:373,t:1527635755601};\\\", \\\"{x:1565,y:368,t:1527635755618};\\\", \\\"{x:1565,y:363,t:1527635755635};\\\", \\\"{x:1565,y:359,t:1527635755651};\\\", \\\"{x:1565,y:357,t:1527635755669};\\\", \\\"{x:1565,y:356,t:1527635755686};\\\", \\\"{x:1565,y:353,t:1527635755702};\\\", \\\"{x:1563,y:352,t:1527635755718};\\\", \\\"{x:1562,y:352,t:1527635755736};\\\", \\\"{x:1561,y:352,t:1527635755771};\\\", \\\"{x:1560,y:352,t:1527635755804};\\\", \\\"{x:1559,y:352,t:1527635756115};\\\", \\\"{x:1559,y:353,t:1527635756140};\\\", \\\"{x:1559,y:354,t:1527635756152};\\\", \\\"{x:1558,y:356,t:1527635756168};\\\", \\\"{x:1556,y:357,t:1527635756184};\\\", \\\"{x:1555,y:358,t:1527635756202};\\\", \\\"{x:1555,y:359,t:1527635756282};\\\", \\\"{x:1553,y:359,t:1527635756331};\\\", \\\"{x:1549,y:361,t:1527635756346};\\\", \\\"{x:1547,y:363,t:1527635756355};\\\", \\\"{x:1544,y:365,t:1527635756369};\\\", \\\"{x:1536,y:369,t:1527635756385};\\\", \\\"{x:1530,y:374,t:1527635756402};\\\", \\\"{x:1509,y:386,t:1527635756419};\\\", \\\"{x:1495,y:392,t:1527635756435};\\\", \\\"{x:1481,y:399,t:1527635756452};\\\", \\\"{x:1468,y:404,t:1527635756469};\\\", \\\"{x:1453,y:409,t:1527635756485};\\\", \\\"{x:1436,y:416,t:1527635756502};\\\", \\\"{x:1422,y:420,t:1527635756519};\\\", \\\"{x:1403,y:429,t:1527635756535};\\\", \\\"{x:1384,y:436,t:1527635756552};\\\", \\\"{x:1370,y:440,t:1527635756569};\\\", \\\"{x:1364,y:443,t:1527635756585};\\\", \\\"{x:1362,y:444,t:1527635756602};\\\", \\\"{x:1360,y:445,t:1527635756619};\\\", \\\"{x:1357,y:447,t:1527635756635};\\\", \\\"{x:1354,y:449,t:1527635756652};\\\", \\\"{x:1352,y:455,t:1527635756670};\\\", \\\"{x:1346,y:461,t:1527635756686};\\\", \\\"{x:1342,y:466,t:1527635756702};\\\", \\\"{x:1340,y:469,t:1527635756719};\\\", \\\"{x:1339,y:473,t:1527635756735};\\\", \\\"{x:1338,y:477,t:1527635756752};\\\", \\\"{x:1338,y:478,t:1527635756769};\\\", \\\"{x:1338,y:487,t:1527635756785};\\\", \\\"{x:1339,y:496,t:1527635756802};\\\", \\\"{x:1343,y:512,t:1527635756819};\\\", \\\"{x:1345,y:517,t:1527635756835};\\\", \\\"{x:1347,y:524,t:1527635756852};\\\", \\\"{x:1349,y:527,t:1527635756870};\\\", \\\"{x:1350,y:529,t:1527635756885};\\\", \\\"{x:1351,y:530,t:1527635756901};\\\", \\\"{x:1352,y:531,t:1527635756919};\\\", \\\"{x:1352,y:535,t:1527635756935};\\\", \\\"{x:1354,y:538,t:1527635756951};\\\", \\\"{x:1354,y:543,t:1527635756968};\\\", \\\"{x:1356,y:547,t:1527635756986};\\\", \\\"{x:1359,y:555,t:1527635757002};\\\", \\\"{x:1363,y:564,t:1527635757019};\\\", \\\"{x:1366,y:569,t:1527635757036};\\\", \\\"{x:1369,y:575,t:1527635757051};\\\", \\\"{x:1373,y:584,t:1527635757069};\\\", \\\"{x:1378,y:595,t:1527635757085};\\\", \\\"{x:1383,y:606,t:1527635757102};\\\", \\\"{x:1387,y:614,t:1527635757119};\\\", \\\"{x:1389,y:618,t:1527635757135};\\\", \\\"{x:1394,y:628,t:1527635757152};\\\", \\\"{x:1399,y:643,t:1527635757170};\\\", \\\"{x:1404,y:660,t:1527635757186};\\\", \\\"{x:1406,y:674,t:1527635757202};\\\", \\\"{x:1410,y:692,t:1527635757218};\\\", \\\"{x:1412,y:697,t:1527635757235};\\\", \\\"{x:1413,y:704,t:1527635757252};\\\", \\\"{x:1414,y:711,t:1527635757268};\\\", \\\"{x:1414,y:721,t:1527635757286};\\\", \\\"{x:1414,y:731,t:1527635757302};\\\", \\\"{x:1414,y:738,t:1527635757318};\\\", \\\"{x:1414,y:748,t:1527635757335};\\\", \\\"{x:1413,y:764,t:1527635757353};\\\", \\\"{x:1410,y:779,t:1527635757369};\\\", \\\"{x:1409,y:786,t:1527635757386};\\\", \\\"{x:1408,y:793,t:1527635757403};\\\", \\\"{x:1407,y:797,t:1527635757419};\\\", \\\"{x:1406,y:804,t:1527635757436};\\\", \\\"{x:1406,y:811,t:1527635757453};\\\", \\\"{x:1406,y:818,t:1527635757469};\\\", \\\"{x:1406,y:825,t:1527635757486};\\\", \\\"{x:1406,y:830,t:1527635757502};\\\", \\\"{x:1406,y:831,t:1527635757519};\\\", \\\"{x:1406,y:832,t:1527635757536};\\\", \\\"{x:1406,y:833,t:1527635757555};\\\", \\\"{x:1407,y:835,t:1527635757579};\\\", \\\"{x:1408,y:837,t:1527635757587};\\\", \\\"{x:1411,y:839,t:1527635757603};\\\", \\\"{x:1418,y:841,t:1527635757619};\\\", \\\"{x:1426,y:841,t:1527635757636};\\\", \\\"{x:1436,y:841,t:1527635757653};\\\", \\\"{x:1443,y:841,t:1527635757670};\\\", \\\"{x:1446,y:841,t:1527635757686};\\\", \\\"{x:1454,y:841,t:1527635757703};\\\", \\\"{x:1462,y:838,t:1527635757719};\\\", \\\"{x:1466,y:836,t:1527635757736};\\\", \\\"{x:1466,y:835,t:1527635757754};\\\", \\\"{x:1467,y:835,t:1527635757884};\\\", \\\"{x:1467,y:833,t:1527635757898};\\\", \\\"{x:1467,y:832,t:1527635757922};\\\", \\\"{x:1467,y:830,t:1527635757946};\\\", \\\"{x:1468,y:826,t:1527635757962};\\\", \\\"{x:1468,y:822,t:1527635757970};\\\", \\\"{x:1468,y:818,t:1527635757986};\\\", \\\"{x:1468,y:807,t:1527635758002};\\\", \\\"{x:1467,y:800,t:1527635758020};\\\", \\\"{x:1463,y:795,t:1527635758035};\\\", \\\"{x:1459,y:791,t:1527635758052};\\\", \\\"{x:1457,y:787,t:1527635758069};\\\", \\\"{x:1453,y:784,t:1527635758085};\\\", \\\"{x:1450,y:783,t:1527635758102};\\\", \\\"{x:1448,y:780,t:1527635758119};\\\", \\\"{x:1447,y:779,t:1527635758135};\\\", \\\"{x:1446,y:778,t:1527635758153};\\\", \\\"{x:1445,y:776,t:1527635758170};\\\", \\\"{x:1444,y:774,t:1527635758185};\\\", \\\"{x:1444,y:773,t:1527635758538};\\\", \\\"{x:1445,y:770,t:1527635758552};\\\", \\\"{x:1450,y:769,t:1527635758569};\\\", \\\"{x:1456,y:766,t:1527635758586};\\\", \\\"{x:1461,y:762,t:1527635758602};\\\", \\\"{x:1465,y:759,t:1527635758619};\\\", \\\"{x:1470,y:757,t:1527635758637};\\\", \\\"{x:1475,y:753,t:1527635758652};\\\", \\\"{x:1487,y:743,t:1527635758670};\\\", \\\"{x:1500,y:730,t:1527635758686};\\\", \\\"{x:1515,y:719,t:1527635758702};\\\", \\\"{x:1527,y:709,t:1527635758719};\\\", \\\"{x:1531,y:705,t:1527635758736};\\\", \\\"{x:1535,y:702,t:1527635758752};\\\", \\\"{x:1538,y:698,t:1527635758770};\\\", \\\"{x:1545,y:686,t:1527635758786};\\\", \\\"{x:1551,y:677,t:1527635758803};\\\", \\\"{x:1558,y:670,t:1527635758819};\\\", \\\"{x:1565,y:664,t:1527635758837};\\\", \\\"{x:1571,y:660,t:1527635758854};\\\", \\\"{x:1575,y:657,t:1527635758870};\\\", \\\"{x:1577,y:656,t:1527635758886};\\\", \\\"{x:1577,y:655,t:1527635758914};\\\", \\\"{x:1578,y:654,t:1527635758929};\\\", \\\"{x:1580,y:654,t:1527635758937};\\\", \\\"{x:1584,y:652,t:1527635758954};\\\", \\\"{x:1589,y:648,t:1527635758969};\\\", \\\"{x:1593,y:644,t:1527635758986};\\\", \\\"{x:1594,y:643,t:1527635759003};\\\", \\\"{x:1596,y:642,t:1527635759058};\\\", \\\"{x:1597,y:641,t:1527635759069};\\\", \\\"{x:1601,y:637,t:1527635759086};\\\", \\\"{x:1602,y:634,t:1527635759103};\\\", \\\"{x:1604,y:633,t:1527635759119};\\\", \\\"{x:1604,y:632,t:1527635759136};\\\", \\\"{x:1605,y:632,t:1527635759178};\\\", \\\"{x:1606,y:632,t:1527635759258};\\\", \\\"{x:1606,y:638,t:1527635759269};\\\", \\\"{x:1604,y:662,t:1527635759286};\\\", \\\"{x:1603,y:683,t:1527635759303};\\\", \\\"{x:1603,y:695,t:1527635759320};\\\", \\\"{x:1605,y:703,t:1527635759336};\\\", \\\"{x:1605,y:707,t:1527635759353};\\\", \\\"{x:1606,y:710,t:1527635759369};\\\", \\\"{x:1606,y:716,t:1527635759386};\\\", \\\"{x:1606,y:718,t:1527635759404};\\\", \\\"{x:1607,y:721,t:1527635759420};\\\", \\\"{x:1607,y:727,t:1527635759437};\\\", \\\"{x:1610,y:736,t:1527635759453};\\\", \\\"{x:1610,y:745,t:1527635759471};\\\", \\\"{x:1613,y:753,t:1527635759486};\\\", \\\"{x:1614,y:755,t:1527635759504};\\\", \\\"{x:1615,y:758,t:1527635759520};\\\", \\\"{x:1617,y:764,t:1527635759537};\\\", \\\"{x:1619,y:775,t:1527635759554};\\\", \\\"{x:1622,y:796,t:1527635759570};\\\", \\\"{x:1628,y:807,t:1527635759587};\\\", \\\"{x:1630,y:820,t:1527635759603};\\\", \\\"{x:1633,y:830,t:1527635759620};\\\", \\\"{x:1636,y:842,t:1527635759636};\\\", \\\"{x:1638,y:853,t:1527635759653};\\\", \\\"{x:1642,y:866,t:1527635759671};\\\", \\\"{x:1642,y:876,t:1527635759686};\\\", \\\"{x:1642,y:886,t:1527635759703};\\\", \\\"{x:1642,y:894,t:1527635759720};\\\", \\\"{x:1642,y:902,t:1527635759737};\\\", \\\"{x:1642,y:907,t:1527635759754};\\\", \\\"{x:1640,y:915,t:1527635759771};\\\", \\\"{x:1637,y:921,t:1527635759787};\\\", \\\"{x:1633,y:926,t:1527635759803};\\\", \\\"{x:1628,y:928,t:1527635759820};\\\", \\\"{x:1623,y:931,t:1527635759836};\\\", \\\"{x:1623,y:932,t:1527635759854};\\\", \\\"{x:1622,y:933,t:1527635759870};\\\", \\\"{x:1620,y:933,t:1527635760114};\\\", \\\"{x:1618,y:930,t:1527635760122};\\\", \\\"{x:1617,y:926,t:1527635760138};\\\", \\\"{x:1616,y:924,t:1527635760153};\\\", \\\"{x:1612,y:918,t:1527635760171};\\\", \\\"{x:1612,y:917,t:1527635761922};\\\", \\\"{x:1611,y:914,t:1527635762338};\\\", \\\"{x:1607,y:907,t:1527635762355};\\\", \\\"{x:1603,y:899,t:1527635762371};\\\", \\\"{x:1598,y:888,t:1527635762389};\\\", \\\"{x:1591,y:871,t:1527635762406};\\\", \\\"{x:1587,y:860,t:1527635762422};\\\", \\\"{x:1580,y:842,t:1527635762439};\\\", \\\"{x:1575,y:826,t:1527635762455};\\\", \\\"{x:1568,y:809,t:1527635762472};\\\", \\\"{x:1561,y:798,t:1527635762489};\\\", \\\"{x:1558,y:790,t:1527635762505};\\\", \\\"{x:1554,y:784,t:1527635762522};\\\", \\\"{x:1553,y:782,t:1527635762539};\\\", \\\"{x:1549,y:778,t:1527635762556};\\\", \\\"{x:1544,y:775,t:1527635762572};\\\", \\\"{x:1532,y:773,t:1527635762589};\\\", \\\"{x:1515,y:767,t:1527635762606};\\\", \\\"{x:1496,y:764,t:1527635762623};\\\", \\\"{x:1480,y:762,t:1527635762638};\\\", \\\"{x:1470,y:762,t:1527635762656};\\\", \\\"{x:1464,y:762,t:1527635762672};\\\", \\\"{x:1463,y:762,t:1527635762690};\\\", \\\"{x:1462,y:761,t:1527635762994};\\\", \\\"{x:1462,y:760,t:1527635763005};\\\", \\\"{x:1462,y:755,t:1527635763023};\\\", \\\"{x:1463,y:747,t:1527635763039};\\\", \\\"{x:1463,y:740,t:1527635763056};\\\", \\\"{x:1463,y:729,t:1527635763073};\\\", \\\"{x:1453,y:706,t:1527635763090};\\\", \\\"{x:1447,y:695,t:1527635763106};\\\", \\\"{x:1442,y:688,t:1527635763123};\\\", \\\"{x:1437,y:682,t:1527635763139};\\\", \\\"{x:1433,y:679,t:1527635763155};\\\", \\\"{x:1427,y:675,t:1527635763172};\\\", \\\"{x:1417,y:668,t:1527635763190};\\\", \\\"{x:1396,y:655,t:1527635763205};\\\", \\\"{x:1373,y:644,t:1527635763223};\\\", \\\"{x:1344,y:633,t:1527635763240};\\\", \\\"{x:1298,y:624,t:1527635763256};\\\", \\\"{x:1254,y:620,t:1527635763273};\\\", \\\"{x:1202,y:617,t:1527635763290};\\\", \\\"{x:1176,y:617,t:1527635763306};\\\", \\\"{x:1152,y:620,t:1527635763323};\\\", \\\"{x:1135,y:626,t:1527635763339};\\\", \\\"{x:1121,y:631,t:1527635763356};\\\", \\\"{x:1110,y:635,t:1527635763373};\\\", \\\"{x:1105,y:635,t:1527635763390};\\\", \\\"{x:1095,y:636,t:1527635763406};\\\", \\\"{x:1078,y:638,t:1527635763423};\\\", \\\"{x:1053,y:638,t:1527635763440};\\\", \\\"{x:1011,y:638,t:1527635763455};\\\", \\\"{x:952,y:638,t:1527635763473};\\\", \\\"{x:853,y:622,t:1527635763489};\\\", \\\"{x:791,y:612,t:1527635763506};\\\", \\\"{x:741,y:605,t:1527635763523};\\\", \\\"{x:709,y:595,t:1527635763539};\\\", \\\"{x:688,y:587,t:1527635763556};\\\", \\\"{x:674,y:577,t:1527635763574};\\\", \\\"{x:662,y:568,t:1527635763590};\\\", \\\"{x:651,y:559,t:1527635763606};\\\", \\\"{x:637,y:547,t:1527635763625};\\\", \\\"{x:618,y:533,t:1527635763641};\\\", \\\"{x:584,y:513,t:1527635763657};\\\", \\\"{x:560,y:500,t:1527635763675};\\\", \\\"{x:531,y:490,t:1527635763691};\\\", \\\"{x:504,y:483,t:1527635763708};\\\", \\\"{x:483,y:481,t:1527635763725};\\\", \\\"{x:474,y:479,t:1527635763742};\\\", \\\"{x:471,y:479,t:1527635763758};\\\", \\\"{x:470,y:479,t:1527635763774};\\\", \\\"{x:473,y:479,t:1527635763858};\\\", \\\"{x:485,y:483,t:1527635763874};\\\", \\\"{x:505,y:486,t:1527635763891};\\\", \\\"{x:522,y:491,t:1527635763908};\\\", \\\"{x:536,y:497,t:1527635763924};\\\", \\\"{x:553,y:501,t:1527635763941};\\\", \\\"{x:577,y:508,t:1527635763958};\\\", \\\"{x:598,y:512,t:1527635763974};\\\", \\\"{x:614,y:516,t:1527635763992};\\\", \\\"{x:621,y:520,t:1527635764008};\\\", \\\"{x:623,y:521,t:1527635764024};\\\", \\\"{x:625,y:521,t:1527635764041};\\\", \\\"{x:626,y:522,t:1527635764081};\\\", \\\"{x:626,y:521,t:1527635764530};\\\", \\\"{x:631,y:516,t:1527635764542};\\\", \\\"{x:656,y:501,t:1527635764559};\\\", \\\"{x:679,y:485,t:1527635764575};\\\", \\\"{x:709,y:471,t:1527635764592};\\\", \\\"{x:745,y:460,t:1527635764609};\\\", \\\"{x:778,y:448,t:1527635764626};\\\", \\\"{x:788,y:444,t:1527635764641};\\\", \\\"{x:790,y:444,t:1527635764659};\\\", \\\"{x:791,y:442,t:1527635764676};\\\", \\\"{x:795,y:440,t:1527635764692};\\\", \\\"{x:799,y:437,t:1527635764709};\\\", \\\"{x:801,y:437,t:1527635764726};\\\", \\\"{x:802,y:436,t:1527635764770};\\\", \\\"{x:803,y:436,t:1527635764786};\\\", \\\"{x:804,y:436,t:1527635764802};\\\", \\\"{x:805,y:436,t:1527635764825};\\\", \\\"{x:809,y:438,t:1527635764857};\\\", \\\"{x:810,y:440,t:1527635764866};\\\", \\\"{x:814,y:442,t:1527635764875};\\\", \\\"{x:817,y:445,t:1527635764892};\\\", \\\"{x:819,y:445,t:1527635764908};\\\", \\\"{x:823,y:445,t:1527635764925};\\\", \\\"{x:826,y:445,t:1527635764942};\\\", \\\"{x:830,y:445,t:1527635764959};\\\", \\\"{x:836,y:445,t:1527635764976};\\\", \\\"{x:838,y:445,t:1527635764992};\\\", \\\"{x:840,y:445,t:1527635765008};\\\", \\\"{x:840,y:445,t:1527635765077};\\\", \\\"{x:837,y:449,t:1527635765129};\\\", \\\"{x:831,y:453,t:1527635765142};\\\", \\\"{x:821,y:463,t:1527635765158};\\\", \\\"{x:804,y:476,t:1527635765176};\\\", \\\"{x:788,y:489,t:1527635765193};\\\", \\\"{x:764,y:508,t:1527635765209};\\\", \\\"{x:711,y:551,t:1527635765226};\\\", \\\"{x:679,y:574,t:1527635765243};\\\", \\\"{x:656,y:593,t:1527635765259};\\\", \\\"{x:637,y:609,t:1527635765276};\\\", \\\"{x:626,y:622,t:1527635765293};\\\", \\\"{x:616,y:632,t:1527635765308};\\\", \\\"{x:605,y:640,t:1527635765326};\\\", \\\"{x:592,y:647,t:1527635765343};\\\", \\\"{x:578,y:655,t:1527635765360};\\\", \\\"{x:565,y:661,t:1527635765376};\\\", \\\"{x:553,y:668,t:1527635765394};\\\", \\\"{x:536,y:671,t:1527635765410};\\\", \\\"{x:528,y:672,t:1527635765426};\\\", \\\"{x:517,y:673,t:1527635765442};\\\", \\\"{x:504,y:678,t:1527635765460};\\\", \\\"{x:498,y:680,t:1527635765477};\\\", \\\"{x:497,y:680,t:1527635765492};\\\", \\\"{x:497,y:681,t:1527635765682};\\\", \\\"{x:497,y:681,t:1527635765723};\\\", \\\"{x:500,y:681,t:1527635765930};\\\", \\\"{x:506,y:681,t:1527635765943};\\\", \\\"{x:519,y:678,t:1527635765960};\\\", \\\"{x:535,y:673,t:1527635765977};\\\", \\\"{x:549,y:668,t:1527635765993};\\\", \\\"{x:571,y:659,t:1527635766009};\\\", \\\"{x:585,y:649,t:1527635766026};\\\", \\\"{x:604,y:633,t:1527635766043};\\\", \\\"{x:626,y:618,t:1527635766060};\\\", \\\"{x:654,y:599,t:1527635766076};\\\", \\\"{x:694,y:576,t:1527635766093};\\\", \\\"{x:737,y:555,t:1527635766110};\\\", \\\"{x:770,y:543,t:1527635766126};\\\", \\\"{x:788,y:535,t:1527635766142};\\\", \\\"{x:800,y:531,t:1527635766160};\\\", \\\"{x:808,y:529,t:1527635766176};\\\", \\\"{x:817,y:526,t:1527635766193};\\\", \\\"{x:823,y:522,t:1527635766209};\\\", \\\"{x:826,y:520,t:1527635766227};\\\", \\\"{x:826,y:517,t:1527635766409};\\\", \\\"{x:858,y:518,t:1527635766426};\\\", \\\"{x:914,y:522,t:1527635766443};\\\", \\\"{x:948,y:524,t:1527635766460};\\\", \\\"{x:967,y:525,t:1527635766477};\\\", \\\"{x:992,y:530,t:1527635766493};\\\", \\\"{x:1022,y:536,t:1527635766510};\\\", \\\"{x:1048,y:543,t:1527635766527};\\\", \\\"{x:1067,y:549,t:1527635766543};\\\", \\\"{x:1087,y:557,t:1527635766560};\\\", \\\"{x:1103,y:565,t:1527635766576};\\\", \\\"{x:1121,y:576,t:1527635766593};\\\", \\\"{x:1129,y:584,t:1527635766610};\\\", \\\"{x:1135,y:592,t:1527635766627};\\\", \\\"{x:1136,y:602,t:1527635766643};\\\", \\\"{x:1138,y:616,t:1527635766660};\\\", \\\"{x:1136,y:632,t:1527635766676};\\\", \\\"{x:1124,y:645,t:1527635766694};\\\", \\\"{x:1105,y:659,t:1527635766709};\\\", \\\"{x:1063,y:677,t:1527635766726};\\\", \\\"{x:995,y:699,t:1527635766744};\\\", \\\"{x:891,y:719,t:1527635766760};\\\", \\\"{x:789,y:719,t:1527635766776};\\\", \\\"{x:619,y:683,t:1527635766793};\\\", \\\"{x:528,y:646,t:1527635766811};\\\", \\\"{x:473,y:610,t:1527635766827};\\\" ] }, { \\\"rt\\\": 30954, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 707321, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"8FE87\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 0, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-06 PM-03 PM-03 PM-X -X -X -X -F -03 PM-03 PM-03 PM-F -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:430,y:463,t:1527635766929};\\\", \\\"{x:448,y:454,t:1527635766944};\\\", \\\"{x:467,y:444,t:1527635766960};\\\", \\\"{x:489,y:431,t:1527635766977};\\\", \\\"{x:530,y:424,t:1527635766994};\\\", \\\"{x:570,y:426,t:1527635767018};\\\", \\\"{x:649,y:454,t:1527635767027};\\\", \\\"{x:763,y:507,t:1527635767044};\\\", \\\"{x:868,y:581,t:1527635767061};\\\", \\\"{x:946,y:630,t:1527635767076};\\\", \\\"{x:964,y:653,t:1527635767094};\\\", \\\"{x:970,y:669,t:1527635767111};\\\", \\\"{x:970,y:680,t:1527635767126};\\\", \\\"{x:963,y:690,t:1527635767144};\\\", \\\"{x:949,y:699,t:1527635767161};\\\", \\\"{x:925,y:702,t:1527635767177};\\\", \\\"{x:868,y:703,t:1527635767194};\\\", \\\"{x:809,y:696,t:1527635767211};\\\", \\\"{x:728,y:683,t:1527635767227};\\\", \\\"{x:670,y:675,t:1527635767243};\\\", \\\"{x:635,y:669,t:1527635767261};\\\", \\\"{x:613,y:666,t:1527635767277};\\\", \\\"{x:601,y:662,t:1527635767294};\\\", \\\"{x:583,y:652,t:1527635767384};\\\", \\\"{x:581,y:650,t:1527635767395};\\\", \\\"{x:580,y:649,t:1527635767411};\\\", \\\"{x:579,y:648,t:1527635767426};\\\", \\\"{x:577,y:647,t:1527635767458};\\\", \\\"{x:575,y:645,t:1527635767466};\\\", \\\"{x:572,y:642,t:1527635767482};\\\", \\\"{x:571,y:640,t:1527635767493};\\\", \\\"{x:569,y:639,t:1527635767510};\\\", \\\"{x:565,y:636,t:1527635767527};\\\", \\\"{x:562,y:634,t:1527635767544};\\\", \\\"{x:561,y:634,t:1527635767561};\\\", \\\"{x:561,y:632,t:1527635767826};\\\", \\\"{x:564,y:630,t:1527635767833};\\\", \\\"{x:568,y:629,t:1527635767844};\\\", \\\"{x:585,y:624,t:1527635767860};\\\", \\\"{x:616,y:614,t:1527635767876};\\\", \\\"{x:657,y:605,t:1527635767894};\\\", \\\"{x:694,y:594,t:1527635767909};\\\", \\\"{x:723,y:585,t:1527635767927};\\\", \\\"{x:746,y:576,t:1527635767944};\\\", \\\"{x:763,y:568,t:1527635767960};\\\", \\\"{x:785,y:558,t:1527635767978};\\\", \\\"{x:798,y:553,t:1527635767994};\\\", \\\"{x:802,y:550,t:1527635768011};\\\", \\\"{x:804,y:550,t:1527635768028};\\\", \\\"{x:806,y:550,t:1527635768044};\\\", \\\"{x:807,y:550,t:1527635768062};\\\", \\\"{x:815,y:545,t:1527635768275};\\\", \\\"{x:845,y:545,t:1527635768281};\\\", \\\"{x:912,y:545,t:1527635768295};\\\", \\\"{x:1042,y:545,t:1527635768312};\\\", \\\"{x:1186,y:543,t:1527635768328};\\\", \\\"{x:1341,y:543,t:1527635768345};\\\", \\\"{x:1521,y:543,t:1527635768361};\\\", \\\"{x:1599,y:543,t:1527635768378};\\\", \\\"{x:1650,y:553,t:1527635768395};\\\", \\\"{x:1700,y:573,t:1527635768411};\\\", \\\"{x:1737,y:602,t:1527635768428};\\\", \\\"{x:1780,y:641,t:1527635768445};\\\", \\\"{x:1813,y:684,t:1527635768462};\\\", \\\"{x:1855,y:738,t:1527635768479};\\\", \\\"{x:1888,y:783,t:1527635768495};\\\", \\\"{x:1900,y:808,t:1527635768512};\\\", \\\"{x:1904,y:827,t:1527635768529};\\\", \\\"{x:1903,y:846,t:1527635768545};\\\", \\\"{x:1879,y:872,t:1527635768562};\\\", \\\"{x:1852,y:888,t:1527635768579};\\\", \\\"{x:1818,y:906,t:1527635768594};\\\", \\\"{x:1794,y:916,t:1527635768612};\\\", \\\"{x:1763,y:926,t:1527635768629};\\\", \\\"{x:1730,y:932,t:1527635768645};\\\", \\\"{x:1666,y:932,t:1527635768662};\\\", \\\"{x:1619,y:932,t:1527635768679};\\\", \\\"{x:1578,y:928,t:1527635768695};\\\", \\\"{x:1557,y:925,t:1527635768712};\\\", \\\"{x:1549,y:925,t:1527635768728};\\\", \\\"{x:1543,y:921,t:1527635768745};\\\", \\\"{x:1543,y:920,t:1527635768786};\\\", \\\"{x:1543,y:918,t:1527635768810};\\\", \\\"{x:1543,y:916,t:1527635768817};\\\", \\\"{x:1543,y:915,t:1527635768834};\\\", \\\"{x:1543,y:914,t:1527635768850};\\\", \\\"{x:1543,y:913,t:1527635768922};\\\", \\\"{x:1543,y:912,t:1527635768985};\\\", \\\"{x:1544,y:912,t:1527635769025};\\\", \\\"{x:1545,y:912,t:1527635769130};\\\", \\\"{x:1546,y:912,t:1527635769146};\\\", \\\"{x:1548,y:912,t:1527635769210};\\\", \\\"{x:1549,y:912,t:1527635769217};\\\", \\\"{x:1551,y:912,t:1527635769234};\\\", \\\"{x:1552,y:912,t:1527635769258};\\\", \\\"{x:1552,y:913,t:1527635769642};\\\", \\\"{x:1552,y:915,t:1527635769666};\\\", \\\"{x:1552,y:916,t:1527635769680};\\\", \\\"{x:1552,y:919,t:1527635769696};\\\", \\\"{x:1550,y:923,t:1527635769713};\\\", \\\"{x:1550,y:924,t:1527635769730};\\\", \\\"{x:1550,y:925,t:1527635769746};\\\", \\\"{x:1549,y:923,t:1527635770322};\\\", \\\"{x:1549,y:921,t:1527635770338};\\\", \\\"{x:1549,y:920,t:1527635770347};\\\", \\\"{x:1549,y:919,t:1527635770378};\\\", \\\"{x:1548,y:918,t:1527635770418};\\\", \\\"{x:1548,y:917,t:1527635770458};\\\", \\\"{x:1548,y:916,t:1527635771194};\\\", \\\"{x:1547,y:915,t:1527635771202};\\\", \\\"{x:1545,y:913,t:1527635773234};\\\", \\\"{x:1541,y:907,t:1527635773248};\\\", \\\"{x:1534,y:889,t:1527635773266};\\\", \\\"{x:1527,y:873,t:1527635773283};\\\", \\\"{x:1522,y:864,t:1527635773299};\\\", \\\"{x:1518,y:854,t:1527635773316};\\\", \\\"{x:1513,y:840,t:1527635773333};\\\", \\\"{x:1508,y:830,t:1527635773349};\\\", \\\"{x:1505,y:824,t:1527635773366};\\\", \\\"{x:1499,y:815,t:1527635773383};\\\", \\\"{x:1494,y:803,t:1527635773399};\\\", \\\"{x:1488,y:795,t:1527635773416};\\\", \\\"{x:1482,y:787,t:1527635773433};\\\", \\\"{x:1480,y:781,t:1527635773450};\\\", \\\"{x:1478,y:774,t:1527635773466};\\\", \\\"{x:1476,y:768,t:1527635773483};\\\", \\\"{x:1474,y:765,t:1527635773499};\\\", \\\"{x:1473,y:762,t:1527635773516};\\\", \\\"{x:1471,y:759,t:1527635773532};\\\", \\\"{x:1471,y:758,t:1527635773549};\\\", \\\"{x:1471,y:757,t:1527635773618};\\\", \\\"{x:1470,y:757,t:1527635773738};\\\", \\\"{x:1468,y:757,t:1527635773750};\\\", \\\"{x:1466,y:758,t:1527635773766};\\\", \\\"{x:1466,y:760,t:1527635773785};\\\", \\\"{x:1465,y:760,t:1527635773800};\\\", \\\"{x:1464,y:764,t:1527635773816};\\\", \\\"{x:1464,y:765,t:1527635773833};\\\", \\\"{x:1464,y:766,t:1527635773850};\\\", \\\"{x:1464,y:768,t:1527635773866};\\\", \\\"{x:1463,y:769,t:1527635773905};\\\", \\\"{x:1462,y:771,t:1527635773922};\\\", \\\"{x:1461,y:772,t:1527635773937};\\\", \\\"{x:1460,y:775,t:1527635773953};\\\", \\\"{x:1459,y:775,t:1527635773970};\\\", \\\"{x:1458,y:775,t:1527635773983};\\\", \\\"{x:1457,y:776,t:1527635774002};\\\", \\\"{x:1456,y:777,t:1527635774016};\\\", \\\"{x:1455,y:778,t:1527635774034};\\\", \\\"{x:1453,y:778,t:1527635774049};\\\", \\\"{x:1452,y:779,t:1527635774067};\\\", \\\"{x:1450,y:779,t:1527635774083};\\\", \\\"{x:1448,y:779,t:1527635774100};\\\", \\\"{x:1447,y:779,t:1527635774117};\\\", \\\"{x:1445,y:779,t:1527635774133};\\\", \\\"{x:1444,y:779,t:1527635774153};\\\", \\\"{x:1443,y:779,t:1527635774169};\\\", \\\"{x:1442,y:780,t:1527635774186};\\\", \\\"{x:1441,y:781,t:1527635774209};\\\", \\\"{x:1440,y:781,t:1527635774233};\\\", \\\"{x:1439,y:781,t:1527635774250};\\\", \\\"{x:1437,y:781,t:1527635774281};\\\", \\\"{x:1436,y:781,t:1527635774314};\\\", \\\"{x:1435,y:781,t:1527635774370};\\\", \\\"{x:1434,y:781,t:1527635774383};\\\", \\\"{x:1433,y:781,t:1527635774401};\\\", \\\"{x:1431,y:780,t:1527635774417};\\\", \\\"{x:1430,y:780,t:1527635774434};\\\", \\\"{x:1428,y:780,t:1527635774457};\\\", \\\"{x:1426,y:778,t:1527635774467};\\\", \\\"{x:1425,y:778,t:1527635774483};\\\", \\\"{x:1423,y:777,t:1527635774500};\\\", \\\"{x:1421,y:777,t:1527635774517};\\\", \\\"{x:1420,y:777,t:1527635774534};\\\", \\\"{x:1419,y:776,t:1527635774551};\\\", \\\"{x:1418,y:774,t:1527635774567};\\\", \\\"{x:1417,y:774,t:1527635774593};\\\", \\\"{x:1415,y:774,t:1527635774618};\\\", \\\"{x:1414,y:773,t:1527635774641};\\\", \\\"{x:1412,y:773,t:1527635775346};\\\", \\\"{x:1411,y:773,t:1527635775371};\\\", \\\"{x:1411,y:775,t:1527635776898};\\\", \\\"{x:1411,y:779,t:1527635776906};\\\", \\\"{x:1411,y:781,t:1527635776919};\\\", \\\"{x:1411,y:785,t:1527635776935};\\\", \\\"{x:1411,y:788,t:1527635776952};\\\", \\\"{x:1411,y:791,t:1527635776969};\\\", \\\"{x:1411,y:793,t:1527635776987};\\\", \\\"{x:1411,y:792,t:1527635777298};\\\", \\\"{x:1411,y:790,t:1527635777530};\\\", \\\"{x:1411,y:789,t:1527635777682};\\\", \\\"{x:1412,y:787,t:1527635777689};\\\", \\\"{x:1412,y:786,t:1527635777714};\\\", \\\"{x:1413,y:784,t:1527635777786};\\\", \\\"{x:1413,y:783,t:1527635778738};\\\", \\\"{x:1413,y:782,t:1527635778761};\\\", \\\"{x:1413,y:781,t:1527635778770};\\\", \\\"{x:1413,y:780,t:1527635778801};\\\", \\\"{x:1413,y:779,t:1527635778809};\\\", \\\"{x:1413,y:778,t:1527635778820};\\\", \\\"{x:1413,y:777,t:1527635778865};\\\", \\\"{x:1413,y:776,t:1527635779202};\\\", \\\"{x:1413,y:775,t:1527635779210};\\\", \\\"{x:1414,y:774,t:1527635779222};\\\", \\\"{x:1415,y:774,t:1527635779237};\\\", \\\"{x:1415,y:773,t:1527635779254};\\\", \\\"{x:1417,y:773,t:1527635779271};\\\", \\\"{x:1418,y:773,t:1527635779287};\\\", \\\"{x:1423,y:770,t:1527635779304};\\\", \\\"{x:1426,y:769,t:1527635779321};\\\", \\\"{x:1429,y:769,t:1527635779337};\\\", \\\"{x:1436,y:769,t:1527635779354};\\\", \\\"{x:1445,y:771,t:1527635779371};\\\", \\\"{x:1456,y:772,t:1527635779387};\\\", \\\"{x:1469,y:776,t:1527635779404};\\\", \\\"{x:1476,y:777,t:1527635779421};\\\", \\\"{x:1481,y:777,t:1527635779438};\\\", \\\"{x:1481,y:778,t:1527635779454};\\\", \\\"{x:1482,y:778,t:1527635779506};\\\", \\\"{x:1483,y:778,t:1527635779602};\\\", \\\"{x:1484,y:778,t:1527635779618};\\\", \\\"{x:1485,y:778,t:1527635779658};\\\", \\\"{x:1486,y:778,t:1527635779671};\\\", \\\"{x:1488,y:779,t:1527635779689};\\\", \\\"{x:1489,y:779,t:1527635779704};\\\", \\\"{x:1494,y:780,t:1527635779721};\\\", \\\"{x:1498,y:780,t:1527635779738};\\\", \\\"{x:1501,y:781,t:1527635779755};\\\", \\\"{x:1504,y:781,t:1527635779771};\\\", \\\"{x:1505,y:781,t:1527635779789};\\\", \\\"{x:1507,y:781,t:1527635779805};\\\", \\\"{x:1508,y:781,t:1527635779938};\\\", \\\"{x:1509,y:781,t:1527635779986};\\\", \\\"{x:1510,y:781,t:1527635779994};\\\", \\\"{x:1511,y:781,t:1527635780009};\\\", \\\"{x:1513,y:781,t:1527635780022};\\\", \\\"{x:1514,y:781,t:1527635780038};\\\", \\\"{x:1517,y:781,t:1527635780056};\\\", \\\"{x:1519,y:781,t:1527635780071};\\\", \\\"{x:1524,y:781,t:1527635780088};\\\", \\\"{x:1533,y:781,t:1527635780105};\\\", \\\"{x:1539,y:781,t:1527635780121};\\\", \\\"{x:1541,y:781,t:1527635780138};\\\", \\\"{x:1543,y:781,t:1527635780155};\\\", \\\"{x:1544,y:781,t:1527635780633};\\\", \\\"{x:1543,y:779,t:1527635780641};\\\", \\\"{x:1540,y:779,t:1527635780655};\\\", \\\"{x:1535,y:779,t:1527635780672};\\\", \\\"{x:1528,y:779,t:1527635780689};\\\", \\\"{x:1521,y:779,t:1527635780706};\\\", \\\"{x:1511,y:779,t:1527635780722};\\\", \\\"{x:1496,y:779,t:1527635780739};\\\", \\\"{x:1479,y:779,t:1527635780755};\\\", \\\"{x:1464,y:779,t:1527635780772};\\\", \\\"{x:1451,y:779,t:1527635780789};\\\", \\\"{x:1437,y:779,t:1527635780805};\\\", \\\"{x:1426,y:779,t:1527635780822};\\\", \\\"{x:1415,y:779,t:1527635780840};\\\", \\\"{x:1409,y:779,t:1527635780855};\\\", \\\"{x:1403,y:779,t:1527635780872};\\\", \\\"{x:1401,y:779,t:1527635780889};\\\", \\\"{x:1403,y:779,t:1527635781130};\\\", \\\"{x:1404,y:778,t:1527635781139};\\\", \\\"{x:1406,y:776,t:1527635781157};\\\", \\\"{x:1409,y:776,t:1527635781172};\\\", \\\"{x:1411,y:776,t:1527635781314};\\\", \\\"{x:1412,y:776,t:1527635781506};\\\", \\\"{x:1413,y:776,t:1527635781524};\\\", \\\"{x:1414,y:776,t:1527635781539};\\\", \\\"{x:1416,y:775,t:1527635781753};\\\", \\\"{x:1418,y:774,t:1527635781761};\\\", \\\"{x:1419,y:774,t:1527635781785};\\\", \\\"{x:1420,y:774,t:1527635781874};\\\", \\\"{x:1421,y:774,t:1527635781898};\\\", \\\"{x:1422,y:774,t:1527635781929};\\\", \\\"{x:1421,y:775,t:1527635782234};\\\", \\\"{x:1419,y:776,t:1527635782242};\\\", \\\"{x:1418,y:776,t:1527635782257};\\\", \\\"{x:1417,y:776,t:1527635782562};\\\", \\\"{x:1415,y:776,t:1527635782650};\\\", \\\"{x:1412,y:773,t:1527635782953};\\\", \\\"{x:1412,y:769,t:1527635782961};\\\", \\\"{x:1410,y:764,t:1527635782975};\\\", \\\"{x:1407,y:752,t:1527635782990};\\\", \\\"{x:1403,y:741,t:1527635783007};\\\", \\\"{x:1397,y:727,t:1527635783025};\\\", \\\"{x:1389,y:708,t:1527635783042};\\\", \\\"{x:1378,y:685,t:1527635783057};\\\", \\\"{x:1373,y:668,t:1527635783075};\\\", \\\"{x:1369,y:657,t:1527635783091};\\\", \\\"{x:1368,y:650,t:1527635783107};\\\", \\\"{x:1365,y:645,t:1527635783125};\\\", \\\"{x:1364,y:640,t:1527635783141};\\\", \\\"{x:1362,y:639,t:1527635783157};\\\", \\\"{x:1361,y:637,t:1527635783175};\\\", \\\"{x:1361,y:636,t:1527635783192};\\\", \\\"{x:1361,y:635,t:1527635783207};\\\", \\\"{x:1360,y:635,t:1527635783234};\\\", \\\"{x:1358,y:635,t:1527635783249};\\\", \\\"{x:1355,y:635,t:1527635783257};\\\", \\\"{x:1347,y:635,t:1527635783274};\\\", \\\"{x:1330,y:635,t:1527635783292};\\\", \\\"{x:1315,y:635,t:1527635783308};\\\", \\\"{x:1308,y:635,t:1527635783324};\\\", \\\"{x:1304,y:635,t:1527635783342};\\\", \\\"{x:1302,y:635,t:1527635783357};\\\", \\\"{x:1301,y:635,t:1527635783374};\\\", \\\"{x:1300,y:635,t:1527635783401};\\\", \\\"{x:1299,y:635,t:1527635783417};\\\", \\\"{x:1298,y:635,t:1527635783434};\\\", \\\"{x:1297,y:635,t:1527635783441};\\\", \\\"{x:1295,y:635,t:1527635783458};\\\", \\\"{x:1293,y:635,t:1527635783474};\\\", \\\"{x:1292,y:635,t:1527635783506};\\\", \\\"{x:1291,y:635,t:1527635783522};\\\", \\\"{x:1290,y:636,t:1527635783545};\\\", \\\"{x:1289,y:636,t:1527635783569};\\\", \\\"{x:1288,y:636,t:1527635783585};\\\", \\\"{x:1287,y:636,t:1527635783625};\\\", \\\"{x:1286,y:637,t:1527635783674};\\\", \\\"{x:1285,y:639,t:1527635783690};\\\", \\\"{x:1286,y:643,t:1527635783697};\\\", \\\"{x:1291,y:647,t:1527635783709};\\\", \\\"{x:1306,y:656,t:1527635783725};\\\", \\\"{x:1329,y:671,t:1527635783742};\\\", \\\"{x:1394,y:705,t:1527635783759};\\\", \\\"{x:1484,y:738,t:1527635783775};\\\", \\\"{x:1553,y:767,t:1527635783791};\\\", \\\"{x:1600,y:789,t:1527635783808};\\\", \\\"{x:1625,y:803,t:1527635783825};\\\", \\\"{x:1643,y:822,t:1527635783841};\\\", \\\"{x:1646,y:830,t:1527635783858};\\\", \\\"{x:1649,y:839,t:1527635783876};\\\", \\\"{x:1652,y:852,t:1527635783892};\\\", \\\"{x:1654,y:859,t:1527635783908};\\\", \\\"{x:1654,y:865,t:1527635783926};\\\", \\\"{x:1654,y:870,t:1527635783941};\\\", \\\"{x:1651,y:878,t:1527635783958};\\\", \\\"{x:1642,y:884,t:1527635783976};\\\", \\\"{x:1630,y:895,t:1527635783991};\\\", \\\"{x:1620,y:903,t:1527635784009};\\\", \\\"{x:1610,y:909,t:1527635784026};\\\", \\\"{x:1604,y:910,t:1527635784042};\\\", \\\"{x:1599,y:911,t:1527635784059};\\\", \\\"{x:1592,y:913,t:1527635784075};\\\", \\\"{x:1587,y:915,t:1527635784091};\\\", \\\"{x:1584,y:916,t:1527635784108};\\\", \\\"{x:1583,y:916,t:1527635784125};\\\", \\\"{x:1581,y:916,t:1527635784145};\\\", \\\"{x:1580,y:916,t:1527635784158};\\\", \\\"{x:1574,y:916,t:1527635784175};\\\", \\\"{x:1570,y:918,t:1527635784192};\\\", \\\"{x:1563,y:918,t:1527635784209};\\\", \\\"{x:1553,y:915,t:1527635784226};\\\", \\\"{x:1550,y:914,t:1527635784242};\\\", \\\"{x:1549,y:914,t:1527635784265};\\\", \\\"{x:1549,y:913,t:1527635785298};\\\", \\\"{x:1550,y:912,t:1527635785309};\\\", \\\"{x:1550,y:911,t:1527635785327};\\\", \\\"{x:1550,y:912,t:1527635785762};\\\", \\\"{x:1550,y:913,t:1527635785905};\\\", \\\"{x:1550,y:914,t:1527635785937};\\\", \\\"{x:1550,y:910,t:1527635786729};\\\", \\\"{x:1550,y:901,t:1527635786745};\\\", \\\"{x:1550,y:886,t:1527635786760};\\\", \\\"{x:1550,y:879,t:1527635786777};\\\", \\\"{x:1550,y:875,t:1527635786794};\\\", \\\"{x:1550,y:872,t:1527635786810};\\\", \\\"{x:1550,y:866,t:1527635786827};\\\", \\\"{x:1550,y:856,t:1527635786845};\\\", \\\"{x:1550,y:849,t:1527635786860};\\\", \\\"{x:1550,y:844,t:1527635786877};\\\", \\\"{x:1550,y:840,t:1527635786895};\\\", \\\"{x:1550,y:838,t:1527635786910};\\\", \\\"{x:1550,y:837,t:1527635786927};\\\", \\\"{x:1550,y:836,t:1527635786954};\\\", \\\"{x:1549,y:836,t:1527635787042};\\\", \\\"{x:1548,y:836,t:1527635787050};\\\", \\\"{x:1543,y:837,t:1527635787062};\\\", \\\"{x:1533,y:866,t:1527635787078};\\\", \\\"{x:1529,y:900,t:1527635787094};\\\", \\\"{x:1528,y:916,t:1527635787112};\\\", \\\"{x:1528,y:921,t:1527635787127};\\\", \\\"{x:1528,y:925,t:1527635787145};\\\", \\\"{x:1530,y:930,t:1527635787161};\\\", \\\"{x:1530,y:932,t:1527635787186};\\\", \\\"{x:1531,y:932,t:1527635787201};\\\", \\\"{x:1533,y:931,t:1527635787346};\\\", \\\"{x:1537,y:925,t:1527635787361};\\\", \\\"{x:1540,y:922,t:1527635787377};\\\", \\\"{x:1543,y:918,t:1527635787395};\\\", \\\"{x:1543,y:917,t:1527635787418};\\\", \\\"{x:1543,y:915,t:1527635787450};\\\", \\\"{x:1543,y:914,t:1527635787546};\\\", \\\"{x:1543,y:908,t:1527635787562};\\\", \\\"{x:1543,y:903,t:1527635787578};\\\", \\\"{x:1540,y:892,t:1527635787595};\\\", \\\"{x:1532,y:876,t:1527635787612};\\\", \\\"{x:1525,y:861,t:1527635787629};\\\", \\\"{x:1519,y:845,t:1527635787644};\\\", \\\"{x:1510,y:826,t:1527635787662};\\\", \\\"{x:1504,y:809,t:1527635787678};\\\", \\\"{x:1500,y:787,t:1527635787695};\\\", \\\"{x:1496,y:769,t:1527635787711};\\\", \\\"{x:1492,y:755,t:1527635787729};\\\", \\\"{x:1489,y:750,t:1527635787745};\\\", \\\"{x:1486,y:744,t:1527635787761};\\\", \\\"{x:1484,y:742,t:1527635787778};\\\", \\\"{x:1483,y:742,t:1527635787795};\\\", \\\"{x:1481,y:741,t:1527635787812};\\\", \\\"{x:1480,y:740,t:1527635787833};\\\", \\\"{x:1479,y:740,t:1527635787845};\\\", \\\"{x:1478,y:740,t:1527635787861};\\\", \\\"{x:1477,y:740,t:1527635787879};\\\", \\\"{x:1474,y:741,t:1527635787895};\\\", \\\"{x:1468,y:748,t:1527635787912};\\\", \\\"{x:1465,y:757,t:1527635787928};\\\", \\\"{x:1460,y:772,t:1527635787945};\\\", \\\"{x:1457,y:778,t:1527635787961};\\\", \\\"{x:1455,y:781,t:1527635787979};\\\", \\\"{x:1453,y:782,t:1527635787995};\\\", \\\"{x:1451,y:782,t:1527635788011};\\\", \\\"{x:1450,y:783,t:1527635788028};\\\", \\\"{x:1446,y:784,t:1527635788045};\\\", \\\"{x:1440,y:786,t:1527635788062};\\\", \\\"{x:1432,y:786,t:1527635788079};\\\", \\\"{x:1423,y:786,t:1527635788095};\\\", \\\"{x:1418,y:786,t:1527635788111};\\\", \\\"{x:1414,y:786,t:1527635788129};\\\", \\\"{x:1411,y:786,t:1527635788145};\\\", \\\"{x:1410,y:786,t:1527635788186};\\\", \\\"{x:1410,y:783,t:1527635788314};\\\", \\\"{x:1410,y:780,t:1527635788328};\\\", \\\"{x:1410,y:775,t:1527635788346};\\\", \\\"{x:1413,y:772,t:1527635788363};\\\", \\\"{x:1414,y:771,t:1527635788402};\\\", \\\"{x:1414,y:772,t:1527635791121};\\\", \\\"{x:1414,y:773,t:1527635791131};\\\", \\\"{x:1413,y:777,t:1527635791148};\\\", \\\"{x:1413,y:778,t:1527635791186};\\\", \\\"{x:1412,y:780,t:1527635791218};\\\", \\\"{x:1412,y:781,t:1527635791531};\\\", \\\"{x:1412,y:782,t:1527635791549};\\\", \\\"{x:1411,y:783,t:1527635791579};\\\", \\\"{x:1411,y:785,t:1527635791644};\\\", \\\"{x:1410,y:782,t:1527635792251};\\\", \\\"{x:1404,y:768,t:1527635792267};\\\", \\\"{x:1396,y:753,t:1527635792282};\\\", \\\"{x:1389,y:742,t:1527635792299};\\\", \\\"{x:1381,y:729,t:1527635792317};\\\", \\\"{x:1371,y:712,t:1527635792332};\\\", \\\"{x:1365,y:703,t:1527635792350};\\\", \\\"{x:1361,y:695,t:1527635792367};\\\", \\\"{x:1357,y:689,t:1527635792383};\\\", \\\"{x:1356,y:684,t:1527635792400};\\\", \\\"{x:1354,y:680,t:1527635792416};\\\", \\\"{x:1353,y:679,t:1527635792433};\\\", \\\"{x:1353,y:677,t:1527635792449};\\\", \\\"{x:1352,y:675,t:1527635792467};\\\", \\\"{x:1351,y:675,t:1527635792483};\\\", \\\"{x:1351,y:674,t:1527635792500};\\\", \\\"{x:1350,y:674,t:1527635792517};\\\", \\\"{x:1349,y:672,t:1527635792539};\\\", \\\"{x:1348,y:672,t:1527635792554};\\\", \\\"{x:1347,y:672,t:1527635792567};\\\", \\\"{x:1345,y:669,t:1527635792584};\\\", \\\"{x:1341,y:666,t:1527635792600};\\\", \\\"{x:1339,y:665,t:1527635792617};\\\", \\\"{x:1337,y:663,t:1527635792633};\\\", \\\"{x:1335,y:662,t:1527635792650};\\\", \\\"{x:1332,y:659,t:1527635792667};\\\", \\\"{x:1329,y:657,t:1527635792683};\\\", \\\"{x:1326,y:656,t:1527635792699};\\\", \\\"{x:1324,y:655,t:1527635792717};\\\", \\\"{x:1322,y:653,t:1527635792734};\\\", \\\"{x:1316,y:653,t:1527635792750};\\\", \\\"{x:1312,y:652,t:1527635792766};\\\", \\\"{x:1306,y:650,t:1527635792784};\\\", \\\"{x:1299,y:649,t:1527635792800};\\\", \\\"{x:1296,y:648,t:1527635792816};\\\", \\\"{x:1294,y:647,t:1527635792834};\\\", \\\"{x:1289,y:647,t:1527635792851};\\\", \\\"{x:1287,y:646,t:1527635792867};\\\", \\\"{x:1283,y:645,t:1527635792884};\\\", \\\"{x:1277,y:645,t:1527635792900};\\\", \\\"{x:1274,y:645,t:1527635792917};\\\", \\\"{x:1271,y:644,t:1527635792933};\\\", \\\"{x:1269,y:644,t:1527635792950};\\\", \\\"{x:1267,y:643,t:1527635792966};\\\", \\\"{x:1269,y:641,t:1527635793315};\\\", \\\"{x:1272,y:641,t:1527635793322};\\\", \\\"{x:1273,y:640,t:1527635793333};\\\", \\\"{x:1279,y:639,t:1527635793351};\\\", \\\"{x:1283,y:637,t:1527635793368};\\\", \\\"{x:1287,y:637,t:1527635793383};\\\", \\\"{x:1291,y:635,t:1527635793400};\\\", \\\"{x:1295,y:634,t:1527635793417};\\\", \\\"{x:1298,y:633,t:1527635793433};\\\", \\\"{x:1304,y:633,t:1527635793450};\\\", \\\"{x:1312,y:634,t:1527635793467};\\\", \\\"{x:1317,y:634,t:1527635793484};\\\", \\\"{x:1320,y:635,t:1527635793501};\\\", \\\"{x:1321,y:635,t:1527635793518};\\\", \\\"{x:1323,y:635,t:1527635793533};\\\", \\\"{x:1325,y:636,t:1527635793550};\\\", \\\"{x:1327,y:636,t:1527635793567};\\\", \\\"{x:1329,y:637,t:1527635793583};\\\", \\\"{x:1329,y:638,t:1527635793600};\\\", \\\"{x:1330,y:638,t:1527635793617};\\\", \\\"{x:1333,y:639,t:1527635793634};\\\", \\\"{x:1334,y:639,t:1527635793650};\\\", \\\"{x:1336,y:640,t:1527635793667};\\\", \\\"{x:1337,y:640,t:1527635793684};\\\", \\\"{x:1337,y:641,t:1527635793700};\\\", \\\"{x:1339,y:641,t:1527635793738};\\\", \\\"{x:1340,y:641,t:1527635793754};\\\", \\\"{x:1342,y:641,t:1527635793835};\\\", \\\"{x:1344,y:641,t:1527635794507};\\\", \\\"{x:1348,y:640,t:1527635794518};\\\", \\\"{x:1355,y:638,t:1527635794535};\\\", \\\"{x:1359,y:636,t:1527635794552};\\\", \\\"{x:1363,y:635,t:1527635794569};\\\", \\\"{x:1368,y:634,t:1527635794584};\\\", \\\"{x:1371,y:634,t:1527635794602};\\\", \\\"{x:1381,y:634,t:1527635794618};\\\", \\\"{x:1385,y:633,t:1527635794635};\\\", \\\"{x:1390,y:633,t:1527635794652};\\\", \\\"{x:1393,y:633,t:1527635794669};\\\", \\\"{x:1394,y:633,t:1527635794684};\\\", \\\"{x:1396,y:634,t:1527635794707};\\\", \\\"{x:1397,y:634,t:1527635794770};\\\", \\\"{x:1399,y:634,t:1527635794811};\\\", \\\"{x:1400,y:634,t:1527635794818};\\\", \\\"{x:1402,y:635,t:1527635794843};\\\", \\\"{x:1403,y:635,t:1527635794866};\\\", \\\"{x:1405,y:636,t:1527635794883};\\\", \\\"{x:1406,y:636,t:1527635794890};\\\", \\\"{x:1410,y:637,t:1527635794902};\\\", \\\"{x:1414,y:638,t:1527635794919};\\\", \\\"{x:1419,y:639,t:1527635794936};\\\", \\\"{x:1426,y:640,t:1527635794952};\\\", \\\"{x:1436,y:641,t:1527635794969};\\\", \\\"{x:1447,y:642,t:1527635794986};\\\", \\\"{x:1457,y:643,t:1527635795002};\\\", \\\"{x:1470,y:646,t:1527635795019};\\\", \\\"{x:1476,y:647,t:1527635795035};\\\", \\\"{x:1479,y:647,t:1527635795051};\\\", \\\"{x:1482,y:647,t:1527635795069};\\\", \\\"{x:1484,y:647,t:1527635795086};\\\", \\\"{x:1485,y:647,t:1527635795106};\\\", \\\"{x:1486,y:647,t:1527635795122};\\\", \\\"{x:1487,y:647,t:1527635795136};\\\", \\\"{x:1488,y:647,t:1527635795266};\\\", \\\"{x:1490,y:647,t:1527635795274};\\\", \\\"{x:1491,y:647,t:1527635795286};\\\", \\\"{x:1495,y:647,t:1527635795301};\\\", \\\"{x:1502,y:647,t:1527635795318};\\\", \\\"{x:1506,y:647,t:1527635795336};\\\", \\\"{x:1510,y:647,t:1527635795353};\\\", \\\"{x:1513,y:647,t:1527635795369};\\\", \\\"{x:1518,y:647,t:1527635795386};\\\", \\\"{x:1526,y:646,t:1527635795402};\\\", \\\"{x:1529,y:646,t:1527635795419};\\\", \\\"{x:1532,y:645,t:1527635795436};\\\", \\\"{x:1535,y:645,t:1527635795452};\\\", \\\"{x:1537,y:645,t:1527635795468};\\\", \\\"{x:1540,y:645,t:1527635795486};\\\", \\\"{x:1544,y:645,t:1527635795503};\\\", \\\"{x:1549,y:645,t:1527635795519};\\\", \\\"{x:1556,y:644,t:1527635795535};\\\", \\\"{x:1559,y:644,t:1527635795552};\\\", \\\"{x:1565,y:644,t:1527635795568};\\\", \\\"{x:1571,y:644,t:1527635795585};\\\", \\\"{x:1583,y:644,t:1527635795601};\\\", \\\"{x:1588,y:644,t:1527635795618};\\\", \\\"{x:1591,y:644,t:1527635795635};\\\", \\\"{x:1594,y:644,t:1527635795652};\\\", \\\"{x:1597,y:644,t:1527635795668};\\\", \\\"{x:1598,y:644,t:1527635795685};\\\", \\\"{x:1601,y:644,t:1527635795703};\\\", \\\"{x:1603,y:644,t:1527635795719};\\\", \\\"{x:1606,y:644,t:1527635795735};\\\", \\\"{x:1608,y:644,t:1527635795752};\\\", \\\"{x:1610,y:644,t:1527635795769};\\\", \\\"{x:1611,y:644,t:1527635795785};\\\", \\\"{x:1612,y:648,t:1527635796019};\\\", \\\"{x:1610,y:660,t:1527635796037};\\\", \\\"{x:1609,y:669,t:1527635796053};\\\", \\\"{x:1609,y:679,t:1527635796069};\\\", \\\"{x:1609,y:692,t:1527635796086};\\\", \\\"{x:1609,y:709,t:1527635796103};\\\", \\\"{x:1609,y:728,t:1527635796120};\\\", \\\"{x:1609,y:744,t:1527635796137};\\\", \\\"{x:1609,y:767,t:1527635796152};\\\", \\\"{x:1613,y:799,t:1527635796169};\\\", \\\"{x:1616,y:823,t:1527635796185};\\\", \\\"{x:1617,y:837,t:1527635796202};\\\", \\\"{x:1618,y:853,t:1527635796219};\\\", \\\"{x:1616,y:867,t:1527635796236};\\\", \\\"{x:1616,y:877,t:1527635796252};\\\", \\\"{x:1616,y:881,t:1527635796269};\\\", \\\"{x:1616,y:883,t:1527635796287};\\\", \\\"{x:1616,y:887,t:1527635796302};\\\", \\\"{x:1616,y:890,t:1527635796319};\\\", \\\"{x:1616,y:891,t:1527635796336};\\\", \\\"{x:1616,y:892,t:1527635796352};\\\", \\\"{x:1616,y:893,t:1527635796370};\\\", \\\"{x:1614,y:893,t:1527635796443};\\\", \\\"{x:1611,y:892,t:1527635796453};\\\", \\\"{x:1603,y:888,t:1527635796469};\\\", \\\"{x:1596,y:883,t:1527635796486};\\\", \\\"{x:1588,y:880,t:1527635796503};\\\", \\\"{x:1569,y:870,t:1527635796520};\\\", \\\"{x:1536,y:859,t:1527635796536};\\\", \\\"{x:1499,y:850,t:1527635796553};\\\", \\\"{x:1452,y:840,t:1527635796570};\\\", \\\"{x:1363,y:823,t:1527635796586};\\\", \\\"{x:1288,y:813,t:1527635796603};\\\", \\\"{x:1204,y:800,t:1527635796619};\\\", \\\"{x:1107,y:788,t:1527635796637};\\\", \\\"{x:1006,y:768,t:1527635796653};\\\", \\\"{x:920,y:755,t:1527635796669};\\\", \\\"{x:815,y:727,t:1527635796686};\\\", \\\"{x:709,y:707,t:1527635796703};\\\", \\\"{x:617,y:695,t:1527635796719};\\\", \\\"{x:531,y:682,t:1527635796737};\\\", \\\"{x:468,y:669,t:1527635796753};\\\", \\\"{x:404,y:651,t:1527635796769};\\\", \\\"{x:385,y:647,t:1527635796783};\\\", \\\"{x:366,y:643,t:1527635796800};\\\", \\\"{x:354,y:640,t:1527635796817};\\\", \\\"{x:345,y:638,t:1527635796833};\\\", \\\"{x:337,y:635,t:1527635796850};\\\", \\\"{x:333,y:632,t:1527635796867};\\\", \\\"{x:329,y:629,t:1527635796883};\\\", \\\"{x:329,y:627,t:1527635796900};\\\", \\\"{x:329,y:626,t:1527635796917};\\\", \\\"{x:329,y:625,t:1527635796937};\\\", \\\"{x:333,y:625,t:1527635797114};\\\", \\\"{x:337,y:625,t:1527635797122};\\\", \\\"{x:342,y:625,t:1527635797135};\\\", \\\"{x:343,y:625,t:1527635797150};\\\", \\\"{x:345,y:624,t:1527635797167};\\\", \\\"{x:348,y:623,t:1527635797186};\\\", \\\"{x:349,y:623,t:1527635797200};\\\", \\\"{x:357,y:619,t:1527635797218};\\\", \\\"{x:379,y:614,t:1527635797236};\\\", \\\"{x:393,y:610,t:1527635797251};\\\", \\\"{x:412,y:605,t:1527635797267};\\\", \\\"{x:432,y:600,t:1527635797284};\\\", \\\"{x:456,y:595,t:1527635797301};\\\", \\\"{x:484,y:589,t:1527635797318};\\\", \\\"{x:508,y:583,t:1527635797336};\\\", \\\"{x:527,y:578,t:1527635797352};\\\", \\\"{x:532,y:576,t:1527635797368};\\\", \\\"{x:533,y:575,t:1527635797409};\\\", \\\"{x:533,y:576,t:1527635797482};\\\", \\\"{x:534,y:591,t:1527635797491};\\\", \\\"{x:536,y:607,t:1527635797502};\\\", \\\"{x:543,y:647,t:1527635797518};\\\", \\\"{x:549,y:672,t:1527635797536};\\\", \\\"{x:554,y:685,t:1527635797552};\\\", \\\"{x:555,y:689,t:1527635797568};\\\", \\\"{x:556,y:691,t:1527635797585};\\\", \\\"{x:568,y:686,t:1527635798187};\\\", \\\"{x:598,y:668,t:1527635798201};\\\", \\\"{x:638,y:647,t:1527635798219};\\\", \\\"{x:688,y:625,t:1527635798236};\\\", \\\"{x:728,y:604,t:1527635798252};\\\", \\\"{x:773,y:582,t:1527635798269};\\\", \\\"{x:799,y:564,t:1527635798285};\\\", \\\"{x:820,y:549,t:1527635798302};\\\", \\\"{x:840,y:539,t:1527635798319};\\\", \\\"{x:862,y:530,t:1527635798336};\\\", \\\"{x:874,y:524,t:1527635798352};\\\", \\\"{x:886,y:519,t:1527635798369};\\\", \\\"{x:892,y:517,t:1527635798386};\\\", \\\"{x:893,y:516,t:1527635798402};\\\", \\\"{x:894,y:516,t:1527635798426};\\\", \\\"{x:895,y:517,t:1527635798706};\\\", \\\"{x:896,y:538,t:1527635798719};\\\", \\\"{x:894,y:562,t:1527635798736};\\\", \\\"{x:871,y:576,t:1527635798752};\\\", \\\"{x:850,y:589,t:1527635798769};\\\", \\\"{x:788,y:604,t:1527635798786};\\\", \\\"{x:713,y:604,t:1527635798802};\\\", \\\"{x:613,y:579,t:1527635798819};\\\", \\\"{x:507,y:538,t:1527635798836};\\\", \\\"{x:435,y:495,t:1527635798853};\\\", \\\"{x:401,y:463,t:1527635798869};\\\", \\\"{x:395,y:439,t:1527635798886};\\\", \\\"{x:406,y:416,t:1527635798904};\\\", \\\"{x:454,y:376,t:1527635798919};\\\", \\\"{x:504,y:342,t:1527635798936};\\\", \\\"{x:593,y:306,t:1527635798953};\\\", \\\"{x:643,y:305,t:1527635798969};\\\" ] }, { \\\"rt\\\": 28166, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 736702, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"8FE87\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-X -X -02 PM-02 PM-X -02 PM-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:913,y:626,t:1527635799098};\\\", \\\"{x:862,y:620,t:1527635799105};\\\", \\\"{x:774,y:603,t:1527635799123};\\\", \\\"{x:754,y:594,t:1527635799136};\\\", \\\"{x:721,y:569,t:1527635799153};\\\", \\\"{x:716,y:552,t:1527635799169};\\\", \\\"{x:718,y:522,t:1527635799194};\\\", \\\"{x:725,y:514,t:1527635799204};\\\", \\\"{x:743,y:505,t:1527635799219};\\\", \\\"{x:760,y:500,t:1527635799236};\\\", \\\"{x:796,y:512,t:1527635799253};\\\", \\\"{x:890,y:576,t:1527635799271};\\\", \\\"{x:971,y:652,t:1527635799286};\\\", \\\"{x:1023,y:718,t:1527635799303};\\\", \\\"{x:1042,y:752,t:1527635799319};\\\", \\\"{x:1044,y:759,t:1527635799336};\\\", \\\"{x:1013,y:774,t:1527635799353};\\\", \\\"{x:968,y:774,t:1527635799369};\\\", \\\"{x:871,y:774,t:1527635799386};\\\", \\\"{x:769,y:761,t:1527635799403};\\\", \\\"{x:668,y:743,t:1527635799420};\\\", \\\"{x:591,y:723,t:1527635799436};\\\", \\\"{x:547,y:713,t:1527635799453};\\\", \\\"{x:531,y:707,t:1527635799470};\\\", \\\"{x:528,y:706,t:1527635799486};\\\", \\\"{x:528,y:705,t:1527635799513};\\\", \\\"{x:528,y:702,t:1527635799521};\\\", \\\"{x:526,y:696,t:1527635799536};\\\", \\\"{x:520,y:685,t:1527635799553};\\\", \\\"{x:518,y:681,t:1527635799570};\\\", \\\"{x:515,y:675,t:1527635799587};\\\", \\\"{x:511,y:648,t:1527635799689};\\\", \\\"{x:515,y:644,t:1527635799704};\\\", \\\"{x:518,y:642,t:1527635799720};\\\", \\\"{x:519,y:637,t:1527635799737};\\\", \\\"{x:519,y:636,t:1527635800434};\\\", \\\"{x:519,y:634,t:1527635800442};\\\", \\\"{x:519,y:632,t:1527635800458};\\\", \\\"{x:520,y:631,t:1527635800472};\\\", \\\"{x:524,y:627,t:1527635800859};\\\", \\\"{x:525,y:625,t:1527635800871};\\\", \\\"{x:529,y:623,t:1527635800889};\\\", \\\"{x:532,y:622,t:1527635800905};\\\", \\\"{x:533,y:621,t:1527635800922};\\\", \\\"{x:534,y:621,t:1527635800971};\\\", \\\"{x:537,y:618,t:1527635800978};\\\", \\\"{x:541,y:616,t:1527635800989};\\\", \\\"{x:547,y:614,t:1527635801006};\\\", \\\"{x:550,y:613,t:1527635801021};\\\", \\\"{x:551,y:613,t:1527635801039};\\\", \\\"{x:552,y:612,t:1527635802339};\\\", \\\"{x:549,y:605,t:1527635802356};\\\", \\\"{x:540,y:593,t:1527635802373};\\\", \\\"{x:527,y:582,t:1527635802392};\\\", \\\"{x:503,y:572,t:1527635802406};\\\", \\\"{x:480,y:563,t:1527635802424};\\\", \\\"{x:462,y:554,t:1527635802439};\\\", \\\"{x:452,y:547,t:1527635802454};\\\", \\\"{x:446,y:539,t:1527635802470};\\\", \\\"{x:440,y:527,t:1527635802488};\\\", \\\"{x:435,y:512,t:1527635802505};\\\", \\\"{x:431,y:503,t:1527635802520};\\\", \\\"{x:428,y:490,t:1527635802539};\\\", \\\"{x:426,y:481,t:1527635802556};\\\", \\\"{x:425,y:470,t:1527635802572};\\\", \\\"{x:424,y:458,t:1527635802590};\\\", \\\"{x:422,y:447,t:1527635802605};\\\", \\\"{x:422,y:434,t:1527635802622};\\\", \\\"{x:421,y:426,t:1527635802639};\\\", \\\"{x:419,y:415,t:1527635802655};\\\", \\\"{x:419,y:407,t:1527635802673};\\\", \\\"{x:417,y:397,t:1527635802689};\\\", \\\"{x:417,y:394,t:1527635802705};\\\", \\\"{x:417,y:393,t:1527635802729};\\\", \\\"{x:417,y:391,t:1527635802843};\\\", \\\"{x:419,y:388,t:1527635802857};\\\", \\\"{x:426,y:385,t:1527635802873};\\\", \\\"{x:439,y:381,t:1527635802889};\\\", \\\"{x:447,y:376,t:1527635802906};\\\", \\\"{x:451,y:376,t:1527635802923};\\\", \\\"{x:463,y:379,t:1527635802939};\\\", \\\"{x:466,y:380,t:1527635802956};\\\", \\\"{x:470,y:381,t:1527635802973};\\\", \\\"{x:471,y:381,t:1527635802994};\\\", \\\"{x:471,y:382,t:1527635803042};\\\", \\\"{x:472,y:383,t:1527635803074};\\\", \\\"{x:473,y:383,t:1527635803139};\\\", \\\"{x:474,y:384,t:1527635803156};\\\", \\\"{x:476,y:386,t:1527635803173};\\\", \\\"{x:478,y:387,t:1527635803189};\\\", \\\"{x:483,y:389,t:1527635803207};\\\", \\\"{x:485,y:390,t:1527635803223};\\\", \\\"{x:487,y:391,t:1527635803239};\\\", \\\"{x:494,y:392,t:1527635803256};\\\", \\\"{x:512,y:397,t:1527635803274};\\\", \\\"{x:526,y:400,t:1527635803290};\\\", \\\"{x:540,y:403,t:1527635803306};\\\", \\\"{x:558,y:403,t:1527635803324};\\\", \\\"{x:576,y:404,t:1527635803339};\\\", \\\"{x:591,y:405,t:1527635803357};\\\", \\\"{x:607,y:405,t:1527635803373};\\\", \\\"{x:619,y:405,t:1527635803390};\\\", \\\"{x:630,y:405,t:1527635803406};\\\", \\\"{x:639,y:405,t:1527635803424};\\\", \\\"{x:653,y:405,t:1527635803440};\\\", \\\"{x:670,y:405,t:1527635803456};\\\", \\\"{x:706,y:405,t:1527635803474};\\\", \\\"{x:733,y:407,t:1527635803490};\\\", \\\"{x:767,y:411,t:1527635803507};\\\", \\\"{x:814,y:414,t:1527635803524};\\\", \\\"{x:870,y:422,t:1527635803540};\\\", \\\"{x:921,y:423,t:1527635803557};\\\", \\\"{x:971,y:429,t:1527635803574};\\\", \\\"{x:1009,y:432,t:1527635803591};\\\", \\\"{x:1038,y:437,t:1527635803607};\\\", \\\"{x:1065,y:443,t:1527635803624};\\\", \\\"{x:1080,y:445,t:1527635803641};\\\", \\\"{x:1084,y:447,t:1527635803657};\\\", \\\"{x:1086,y:447,t:1527635803674};\\\", \\\"{x:1085,y:448,t:1527635804011};\\\", \\\"{x:1082,y:448,t:1527635804034};\\\", \\\"{x:1077,y:451,t:1527635804043};\\\", \\\"{x:1070,y:452,t:1527635804057};\\\", \\\"{x:1034,y:452,t:1527635804074};\\\", \\\"{x:996,y:452,t:1527635804090};\\\", \\\"{x:913,y:452,t:1527635804110};\\\", \\\"{x:830,y:452,t:1527635804124};\\\", \\\"{x:735,y:452,t:1527635804140};\\\", \\\"{x:655,y:452,t:1527635804157};\\\", \\\"{x:588,y:452,t:1527635804173};\\\", \\\"{x:541,y:452,t:1527635804190};\\\", \\\"{x:511,y:452,t:1527635804207};\\\", \\\"{x:495,y:452,t:1527635804223};\\\", \\\"{x:484,y:452,t:1527635804240};\\\", \\\"{x:474,y:452,t:1527635804257};\\\", \\\"{x:466,y:452,t:1527635804273};\\\", \\\"{x:454,y:452,t:1527635804291};\\\", \\\"{x:443,y:452,t:1527635804307};\\\", \\\"{x:434,y:452,t:1527635804323};\\\", \\\"{x:431,y:452,t:1527635804340};\\\", \\\"{x:430,y:452,t:1527635804499};\\\", \\\"{x:430,y:451,t:1527635804508};\\\", \\\"{x:436,y:448,t:1527635804524};\\\", \\\"{x:439,y:446,t:1527635804541};\\\", \\\"{x:441,y:445,t:1527635804561};\\\", \\\"{x:441,y:444,t:1527635804574};\\\", \\\"{x:445,y:444,t:1527635804590};\\\", \\\"{x:447,y:443,t:1527635804608};\\\", \\\"{x:452,y:439,t:1527635804623};\\\", \\\"{x:456,y:439,t:1527635804640};\\\", \\\"{x:460,y:436,t:1527635804657};\\\", \\\"{x:461,y:436,t:1527635804673};\\\", \\\"{x:463,y:434,t:1527635804690};\\\", \\\"{x:466,y:432,t:1527635804707};\\\", \\\"{x:470,y:430,t:1527635804723};\\\", \\\"{x:473,y:429,t:1527635804740};\\\", \\\"{x:485,y:429,t:1527635804757};\\\", \\\"{x:506,y:429,t:1527635804774};\\\", \\\"{x:527,y:429,t:1527635804791};\\\", \\\"{x:547,y:429,t:1527635804807};\\\", \\\"{x:555,y:428,t:1527635804823};\\\", \\\"{x:559,y:428,t:1527635804841};\\\", \\\"{x:563,y:425,t:1527635805891};\\\", \\\"{x:570,y:424,t:1527635805908};\\\", \\\"{x:574,y:421,t:1527635805925};\\\", \\\"{x:583,y:421,t:1527635805941};\\\", \\\"{x:594,y:421,t:1527635805957};\\\", \\\"{x:604,y:420,t:1527635805974};\\\", \\\"{x:619,y:420,t:1527635805991};\\\", \\\"{x:648,y:420,t:1527635806008};\\\", \\\"{x:703,y:415,t:1527635806026};\\\", \\\"{x:775,y:415,t:1527635806041};\\\", \\\"{x:895,y:413,t:1527635806058};\\\", \\\"{x:992,y:411,t:1527635806075};\\\", \\\"{x:1101,y:411,t:1527635806091};\\\", \\\"{x:1211,y:411,t:1527635806108};\\\", \\\"{x:1290,y:425,t:1527635806125};\\\", \\\"{x:1338,y:440,t:1527635806141};\\\", \\\"{x:1377,y:456,t:1527635806158};\\\", \\\"{x:1396,y:475,t:1527635806175};\\\", \\\"{x:1438,y:510,t:1527635806191};\\\", \\\"{x:1479,y:545,t:1527635806208};\\\", \\\"{x:1502,y:567,t:1527635806225};\\\", \\\"{x:1518,y:587,t:1527635806241};\\\", \\\"{x:1542,y:623,t:1527635806259};\\\", \\\"{x:1555,y:652,t:1527635806274};\\\", \\\"{x:1562,y:671,t:1527635806291};\\\", \\\"{x:1564,y:687,t:1527635806309};\\\", \\\"{x:1564,y:701,t:1527635806325};\\\", \\\"{x:1564,y:714,t:1527635806341};\\\", \\\"{x:1563,y:732,t:1527635806358};\\\", \\\"{x:1559,y:742,t:1527635806375};\\\", \\\"{x:1553,y:756,t:1527635806391};\\\", \\\"{x:1543,y:771,t:1527635806408};\\\", \\\"{x:1530,y:786,t:1527635806426};\\\", \\\"{x:1516,y:798,t:1527635806441};\\\", \\\"{x:1495,y:812,t:1527635806458};\\\", \\\"{x:1487,y:819,t:1527635806474};\\\", \\\"{x:1475,y:826,t:1527635806491};\\\", \\\"{x:1461,y:832,t:1527635806508};\\\", \\\"{x:1450,y:842,t:1527635806524};\\\", \\\"{x:1445,y:851,t:1527635806540};\\\", \\\"{x:1439,y:859,t:1527635806557};\\\", \\\"{x:1437,y:865,t:1527635806575};\\\", \\\"{x:1436,y:868,t:1527635806590};\\\", \\\"{x:1436,y:869,t:1527635806690};\\\", \\\"{x:1436,y:871,t:1527635806698};\\\", \\\"{x:1438,y:873,t:1527635806708};\\\", \\\"{x:1445,y:878,t:1527635806725};\\\", \\\"{x:1450,y:882,t:1527635806741};\\\", \\\"{x:1454,y:884,t:1527635806758};\\\", \\\"{x:1458,y:887,t:1527635806775};\\\", \\\"{x:1461,y:888,t:1527635806791};\\\", \\\"{x:1465,y:889,t:1527635806808};\\\", \\\"{x:1467,y:890,t:1527635806825};\\\", \\\"{x:1469,y:892,t:1527635806841};\\\", \\\"{x:1472,y:894,t:1527635806858};\\\", \\\"{x:1474,y:896,t:1527635806875};\\\", \\\"{x:1476,y:897,t:1527635806891};\\\", \\\"{x:1476,y:898,t:1527635806908};\\\", \\\"{x:1478,y:900,t:1527635806954};\\\", \\\"{x:1480,y:901,t:1527635806963};\\\", \\\"{x:1480,y:904,t:1527635806975};\\\", \\\"{x:1483,y:907,t:1527635806993};\\\", \\\"{x:1486,y:912,t:1527635807009};\\\", \\\"{x:1487,y:913,t:1527635807025};\\\", \\\"{x:1488,y:915,t:1527635807042};\\\", \\\"{x:1489,y:922,t:1527635807058};\\\", \\\"{x:1489,y:926,t:1527635807074};\\\", \\\"{x:1490,y:929,t:1527635807092};\\\", \\\"{x:1491,y:929,t:1527635807315};\\\", \\\"{x:1491,y:928,t:1527635807354};\\\", \\\"{x:1490,y:927,t:1527635807362};\\\", \\\"{x:1490,y:924,t:1527635807459};\\\", \\\"{x:1490,y:922,t:1527635807475};\\\", \\\"{x:1490,y:920,t:1527635807492};\\\", \\\"{x:1490,y:918,t:1527635807508};\\\", \\\"{x:1490,y:917,t:1527635807525};\\\", \\\"{x:1492,y:913,t:1527635807543};\\\", \\\"{x:1492,y:910,t:1527635807558};\\\", \\\"{x:1492,y:907,t:1527635807576};\\\", \\\"{x:1495,y:902,t:1527635807593};\\\", \\\"{x:1497,y:893,t:1527635807608};\\\", \\\"{x:1500,y:880,t:1527635807625};\\\", \\\"{x:1501,y:864,t:1527635807641};\\\", \\\"{x:1501,y:853,t:1527635807658};\\\", \\\"{x:1502,y:843,t:1527635807674};\\\", \\\"{x:1502,y:837,t:1527635807691};\\\", \\\"{x:1502,y:830,t:1527635807707};\\\", \\\"{x:1502,y:824,t:1527635807725};\\\", \\\"{x:1502,y:817,t:1527635807741};\\\", \\\"{x:1502,y:812,t:1527635807757};\\\", \\\"{x:1502,y:809,t:1527635807774};\\\", \\\"{x:1502,y:806,t:1527635807792};\\\", \\\"{x:1502,y:805,t:1527635807810};\\\", \\\"{x:1502,y:803,t:1527635807825};\\\", \\\"{x:1502,y:802,t:1527635807842};\\\", \\\"{x:1502,y:801,t:1527635807865};\\\", \\\"{x:1502,y:800,t:1527635807875};\\\", \\\"{x:1501,y:798,t:1527635807892};\\\", \\\"{x:1501,y:796,t:1527635807914};\\\", \\\"{x:1500,y:794,t:1527635807930};\\\", \\\"{x:1500,y:793,t:1527635807942};\\\", \\\"{x:1499,y:792,t:1527635807958};\\\", \\\"{x:1499,y:791,t:1527635807975};\\\", \\\"{x:1497,y:789,t:1527635807992};\\\", \\\"{x:1496,y:788,t:1527635808007};\\\", \\\"{x:1495,y:788,t:1527635808025};\\\", \\\"{x:1492,y:785,t:1527635808042};\\\", \\\"{x:1489,y:783,t:1527635808058};\\\", \\\"{x:1489,y:782,t:1527635808075};\\\", \\\"{x:1488,y:782,t:1527635808092};\\\", \\\"{x:1487,y:781,t:1527635808108};\\\", \\\"{x:1486,y:781,t:1527635808125};\\\", \\\"{x:1485,y:780,t:1527635808144};\\\", \\\"{x:1485,y:779,t:1527635808157};\\\", \\\"{x:1484,y:779,t:1527635808185};\\\", \\\"{x:1483,y:778,t:1527635808217};\\\", \\\"{x:1482,y:777,t:1527635808249};\\\", \\\"{x:1481,y:776,t:1527635808289};\\\", \\\"{x:1476,y:776,t:1527635809722};\\\", \\\"{x:1473,y:776,t:1527635809729};\\\", \\\"{x:1469,y:779,t:1527635809741};\\\", \\\"{x:1463,y:804,t:1527635809758};\\\", \\\"{x:1462,y:820,t:1527635809775};\\\", \\\"{x:1460,y:829,t:1527635809792};\\\", \\\"{x:1460,y:833,t:1527635809808};\\\", \\\"{x:1460,y:836,t:1527635809825};\\\", \\\"{x:1460,y:839,t:1527635809841};\\\", \\\"{x:1460,y:845,t:1527635809858};\\\", \\\"{x:1462,y:851,t:1527635809876};\\\", \\\"{x:1463,y:856,t:1527635809891};\\\", \\\"{x:1464,y:860,t:1527635809908};\\\", \\\"{x:1464,y:864,t:1527635809926};\\\", \\\"{x:1465,y:866,t:1527635809941};\\\", \\\"{x:1465,y:870,t:1527635809959};\\\", \\\"{x:1469,y:879,t:1527635809976};\\\", \\\"{x:1472,y:892,t:1527635809992};\\\", \\\"{x:1475,y:901,t:1527635810009};\\\", \\\"{x:1477,y:908,t:1527635810025};\\\", \\\"{x:1478,y:909,t:1527635810042};\\\", \\\"{x:1478,y:910,t:1527635810075};\\\", \\\"{x:1478,y:911,t:1527635810226};\\\", \\\"{x:1477,y:911,t:1527635810242};\\\", \\\"{x:1477,y:909,t:1527635810260};\\\", \\\"{x:1477,y:906,t:1527635810276};\\\", \\\"{x:1476,y:902,t:1527635810293};\\\", \\\"{x:1476,y:898,t:1527635810313};\\\", \\\"{x:1476,y:893,t:1527635810330};\\\", \\\"{x:1476,y:890,t:1527635810347};\\\", \\\"{x:1476,y:889,t:1527635810363};\\\", \\\"{x:1476,y:885,t:1527635810381};\\\", \\\"{x:1476,y:881,t:1527635810396};\\\", \\\"{x:1476,y:875,t:1527635810413};\\\", \\\"{x:1476,y:870,t:1527635810430};\\\", \\\"{x:1476,y:867,t:1527635810446};\\\", \\\"{x:1477,y:864,t:1527635810463};\\\", \\\"{x:1478,y:862,t:1527635810486};\\\", \\\"{x:1478,y:861,t:1527635810502};\\\", \\\"{x:1478,y:860,t:1527635810518};\\\", \\\"{x:1478,y:859,t:1527635810530};\\\", \\\"{x:1478,y:858,t:1527635810546};\\\", \\\"{x:1478,y:855,t:1527635810564};\\\", \\\"{x:1478,y:854,t:1527635810580};\\\", \\\"{x:1478,y:853,t:1527635810606};\\\", \\\"{x:1478,y:852,t:1527635810613};\\\", \\\"{x:1478,y:849,t:1527635810638};\\\", \\\"{x:1478,y:847,t:1527635810654};\\\", \\\"{x:1478,y:846,t:1527635810670};\\\", \\\"{x:1477,y:845,t:1527635810686};\\\", \\\"{x:1477,y:844,t:1527635810696};\\\", \\\"{x:1477,y:843,t:1527635810712};\\\", \\\"{x:1477,y:841,t:1527635810729};\\\", \\\"{x:1477,y:839,t:1527635810745};\\\", \\\"{x:1477,y:837,t:1527635810762};\\\", \\\"{x:1477,y:833,t:1527635810780};\\\", \\\"{x:1477,y:829,t:1527635810796};\\\", \\\"{x:1477,y:828,t:1527635810812};\\\", \\\"{x:1477,y:826,t:1527635810829};\\\", \\\"{x:1478,y:824,t:1527635810845};\\\", \\\"{x:1478,y:822,t:1527635810869};\\\", \\\"{x:1478,y:821,t:1527635810880};\\\", \\\"{x:1479,y:818,t:1527635810896};\\\", \\\"{x:1479,y:817,t:1527635810913};\\\", \\\"{x:1479,y:815,t:1527635810929};\\\", \\\"{x:1481,y:813,t:1527635810946};\\\", \\\"{x:1481,y:812,t:1527635810963};\\\", \\\"{x:1481,y:810,t:1527635810980};\\\", \\\"{x:1481,y:808,t:1527635810996};\\\", \\\"{x:1482,y:805,t:1527635811013};\\\", \\\"{x:1483,y:801,t:1527635811030};\\\", \\\"{x:1484,y:800,t:1527635811046};\\\", \\\"{x:1484,y:798,t:1527635811064};\\\", \\\"{x:1485,y:797,t:1527635811080};\\\", \\\"{x:1485,y:796,t:1527635811096};\\\", \\\"{x:1485,y:795,t:1527635811113};\\\", \\\"{x:1485,y:793,t:1527635811129};\\\", \\\"{x:1485,y:792,t:1527635811146};\\\", \\\"{x:1485,y:790,t:1527635811163};\\\", \\\"{x:1485,y:789,t:1527635811197};\\\", \\\"{x:1485,y:787,t:1527635811237};\\\", \\\"{x:1485,y:786,t:1527635811269};\\\", \\\"{x:1485,y:784,t:1527635811293};\\\", \\\"{x:1485,y:783,t:1527635811342};\\\", \\\"{x:1485,y:781,t:1527635811366};\\\", \\\"{x:1484,y:779,t:1527635811397};\\\", \\\"{x:1484,y:778,t:1527635811430};\\\", \\\"{x:1484,y:777,t:1527635811469};\\\", \\\"{x:1483,y:776,t:1527635811767};\\\", \\\"{x:1479,y:788,t:1527635813647};\\\", \\\"{x:1469,y:831,t:1527635813664};\\\", \\\"{x:1462,y:859,t:1527635813680};\\\", \\\"{x:1462,y:874,t:1527635813697};\\\", \\\"{x:1462,y:889,t:1527635813714};\\\", \\\"{x:1463,y:898,t:1527635813731};\\\", \\\"{x:1467,y:907,t:1527635813747};\\\", \\\"{x:1469,y:916,t:1527635813764};\\\", \\\"{x:1473,y:930,t:1527635813780};\\\", \\\"{x:1476,y:940,t:1527635813798};\\\", \\\"{x:1477,y:945,t:1527635813814};\\\", \\\"{x:1477,y:946,t:1527635813830};\\\", \\\"{x:1477,y:947,t:1527635813862};\\\", \\\"{x:1477,y:945,t:1527635814031};\\\", \\\"{x:1476,y:936,t:1527635814047};\\\", \\\"{x:1475,y:925,t:1527635814065};\\\", \\\"{x:1473,y:918,t:1527635814080};\\\", \\\"{x:1472,y:914,t:1527635814098};\\\", \\\"{x:1471,y:910,t:1527635814114};\\\", \\\"{x:1471,y:906,t:1527635814131};\\\", \\\"{x:1469,y:900,t:1527635814148};\\\", \\\"{x:1468,y:895,t:1527635814164};\\\", \\\"{x:1467,y:890,t:1527635814181};\\\", \\\"{x:1467,y:885,t:1527635814198};\\\", \\\"{x:1464,y:877,t:1527635814214};\\\", \\\"{x:1464,y:872,t:1527635814231};\\\", \\\"{x:1463,y:863,t:1527635814248};\\\", \\\"{x:1462,y:857,t:1527635814264};\\\", \\\"{x:1462,y:852,t:1527635814281};\\\", \\\"{x:1462,y:848,t:1527635814297};\\\", \\\"{x:1462,y:846,t:1527635814315};\\\", \\\"{x:1462,y:843,t:1527635814331};\\\", \\\"{x:1462,y:842,t:1527635814348};\\\", \\\"{x:1462,y:838,t:1527635814364};\\\", \\\"{x:1464,y:833,t:1527635814382};\\\", \\\"{x:1465,y:828,t:1527635814397};\\\", \\\"{x:1465,y:821,t:1527635814414};\\\", \\\"{x:1466,y:817,t:1527635814432};\\\", \\\"{x:1468,y:813,t:1527635814447};\\\", \\\"{x:1469,y:809,t:1527635814464};\\\", \\\"{x:1470,y:806,t:1527635814482};\\\", \\\"{x:1471,y:803,t:1527635814497};\\\", \\\"{x:1471,y:802,t:1527635814515};\\\", \\\"{x:1471,y:799,t:1527635814532};\\\", \\\"{x:1471,y:798,t:1527635814547};\\\", \\\"{x:1471,y:795,t:1527635814564};\\\", \\\"{x:1472,y:792,t:1527635814581};\\\", \\\"{x:1472,y:791,t:1527635814597};\\\", \\\"{x:1472,y:789,t:1527635814614};\\\", \\\"{x:1472,y:788,t:1527635814630};\\\", \\\"{x:1472,y:787,t:1527635814646};\\\", \\\"{x:1472,y:786,t:1527635814669};\\\", \\\"{x:1472,y:785,t:1527635814710};\\\", \\\"{x:1472,y:784,t:1527635814717};\\\", \\\"{x:1472,y:783,t:1527635814731};\\\", \\\"{x:1472,y:782,t:1527635814746};\\\", \\\"{x:1472,y:781,t:1527635814764};\\\", \\\"{x:1472,y:780,t:1527635815438};\\\", \\\"{x:1474,y:779,t:1527635815447};\\\", \\\"{x:1474,y:778,t:1527635815465};\\\", \\\"{x:1476,y:777,t:1527635815481};\\\", \\\"{x:1477,y:777,t:1527635815526};\\\", \\\"{x:1476,y:777,t:1527635815790};\\\", \\\"{x:1475,y:778,t:1527635815799};\\\", \\\"{x:1470,y:785,t:1527635815815};\\\", \\\"{x:1468,y:819,t:1527635815831};\\\", \\\"{x:1464,y:842,t:1527635815848};\\\", \\\"{x:1463,y:858,t:1527635815864};\\\", \\\"{x:1460,y:868,t:1527635815882};\\\", \\\"{x:1460,y:874,t:1527635815898};\\\", \\\"{x:1459,y:879,t:1527635815914};\\\", \\\"{x:1459,y:882,t:1527635815931};\\\", \\\"{x:1458,y:887,t:1527635815948};\\\", \\\"{x:1458,y:891,t:1527635815964};\\\", \\\"{x:1458,y:896,t:1527635815981};\\\", \\\"{x:1458,y:901,t:1527635815998};\\\", \\\"{x:1458,y:904,t:1527635816014};\\\", \\\"{x:1458,y:905,t:1527635816038};\\\", \\\"{x:1458,y:906,t:1527635816048};\\\", \\\"{x:1459,y:909,t:1527635816064};\\\", \\\"{x:1462,y:913,t:1527635816082};\\\", \\\"{x:1465,y:915,t:1527635816098};\\\", \\\"{x:1468,y:918,t:1527635816115};\\\", \\\"{x:1470,y:918,t:1527635816131};\\\", \\\"{x:1471,y:919,t:1527635816148};\\\", \\\"{x:1472,y:919,t:1527635816164};\\\", \\\"{x:1473,y:919,t:1527635816181};\\\", \\\"{x:1474,y:919,t:1527635816198};\\\", \\\"{x:1475,y:919,t:1527635816230};\\\", \\\"{x:1477,y:919,t:1527635816238};\\\", \\\"{x:1477,y:915,t:1527635817775};\\\", \\\"{x:1477,y:909,t:1527635817782};\\\", \\\"{x:1472,y:899,t:1527635817797};\\\", \\\"{x:1468,y:885,t:1527635817815};\\\", \\\"{x:1464,y:876,t:1527635817832};\\\", \\\"{x:1461,y:867,t:1527635817849};\\\", \\\"{x:1457,y:858,t:1527635817865};\\\", \\\"{x:1453,y:848,t:1527635817881};\\\", \\\"{x:1448,y:838,t:1527635817898};\\\", \\\"{x:1447,y:833,t:1527635817915};\\\", \\\"{x:1443,y:826,t:1527635817931};\\\", \\\"{x:1442,y:822,t:1527635817948};\\\", \\\"{x:1440,y:816,t:1527635817966};\\\", \\\"{x:1439,y:814,t:1527635817982};\\\", \\\"{x:1438,y:811,t:1527635817998};\\\", \\\"{x:1436,y:808,t:1527635818015};\\\", \\\"{x:1435,y:805,t:1527635818031};\\\", \\\"{x:1433,y:800,t:1527635818048};\\\", \\\"{x:1433,y:799,t:1527635818065};\\\", \\\"{x:1432,y:796,t:1527635818081};\\\", \\\"{x:1432,y:794,t:1527635818098};\\\", \\\"{x:1431,y:791,t:1527635818115};\\\", \\\"{x:1430,y:790,t:1527635818132};\\\", \\\"{x:1429,y:787,t:1527635818148};\\\", \\\"{x:1427,y:783,t:1527635818166};\\\", \\\"{x:1426,y:781,t:1527635818181};\\\", \\\"{x:1424,y:779,t:1527635818198};\\\", \\\"{x:1423,y:778,t:1527635818222};\\\", \\\"{x:1422,y:777,t:1527635818232};\\\", \\\"{x:1421,y:776,t:1527635818271};\\\", \\\"{x:1420,y:774,t:1527635818294};\\\", \\\"{x:1419,y:774,t:1527635818335};\\\", \\\"{x:1418,y:773,t:1527635818503};\\\", \\\"{x:1417,y:773,t:1527635818726};\\\", \\\"{x:1416,y:773,t:1527635818750};\\\", \\\"{x:1415,y:773,t:1527635818791};\\\", \\\"{x:1414,y:774,t:1527635818847};\\\", \\\"{x:1413,y:774,t:1527635822143};\\\", \\\"{x:1412,y:770,t:1527635823007};\\\", \\\"{x:1392,y:744,t:1527635823017};\\\", \\\"{x:1373,y:722,t:1527635823033};\\\", \\\"{x:1358,y:711,t:1527635823050};\\\", \\\"{x:1347,y:704,t:1527635823067};\\\", \\\"{x:1335,y:699,t:1527635823083};\\\", \\\"{x:1323,y:693,t:1527635823099};\\\", \\\"{x:1292,y:683,t:1527635823117};\\\", \\\"{x:1229,y:668,t:1527635823133};\\\", \\\"{x:1095,y:640,t:1527635823150};\\\", \\\"{x:1017,y:631,t:1527635823166};\\\", \\\"{x:953,y:622,t:1527635823183};\\\", \\\"{x:919,y:616,t:1527635823199};\\\", \\\"{x:890,y:616,t:1527635823216};\\\", \\\"{x:861,y:616,t:1527635823232};\\\", \\\"{x:835,y:616,t:1527635823249};\\\", \\\"{x:809,y:616,t:1527635823267};\\\", \\\"{x:783,y:615,t:1527635823283};\\\", \\\"{x:762,y:610,t:1527635823299};\\\", \\\"{x:738,y:607,t:1527635823316};\\\", \\\"{x:715,y:604,t:1527635823333};\\\", \\\"{x:690,y:598,t:1527635823350};\\\", \\\"{x:674,y:593,t:1527635823366};\\\", \\\"{x:668,y:592,t:1527635823384};\\\", \\\"{x:667,y:592,t:1527635823399};\\\", \\\"{x:666,y:591,t:1527635823416};\\\", \\\"{x:664,y:590,t:1527635823426};\\\", \\\"{x:659,y:586,t:1527635823443};\\\", \\\"{x:648,y:579,t:1527635823460};\\\", \\\"{x:635,y:573,t:1527635823476};\\\", \\\"{x:618,y:565,t:1527635823493};\\\", \\\"{x:616,y:564,t:1527635823510};\\\", \\\"{x:614,y:562,t:1527635823525};\\\", \\\"{x:612,y:559,t:1527635823543};\\\", \\\"{x:600,y:552,t:1527635823561};\\\", \\\"{x:591,y:546,t:1527635823576};\\\", \\\"{x:582,y:540,t:1527635823593};\\\", \\\"{x:577,y:539,t:1527635823610};\\\", \\\"{x:576,y:537,t:1527635823626};\\\", \\\"{x:575,y:537,t:1527635823643};\\\", \\\"{x:575,y:536,t:1527635823660};\\\", \\\"{x:575,y:533,t:1527635823677};\\\", \\\"{x:575,y:532,t:1527635823693};\\\", \\\"{x:575,y:530,t:1527635823710};\\\", \\\"{x:575,y:526,t:1527635823727};\\\", \\\"{x:579,y:521,t:1527635823745};\\\", \\\"{x:589,y:514,t:1527635823760};\\\", \\\"{x:602,y:506,t:1527635823777};\\\", \\\"{x:630,y:494,t:1527635823793};\\\", \\\"{x:659,y:485,t:1527635823810};\\\", \\\"{x:696,y:474,t:1527635823827};\\\", \\\"{x:756,y:462,t:1527635823843};\\\", \\\"{x:815,y:452,t:1527635823860};\\\", \\\"{x:863,y:445,t:1527635823877};\\\", \\\"{x:884,y:440,t:1527635823893};\\\", \\\"{x:888,y:439,t:1527635823909};\\\", \\\"{x:889,y:439,t:1527635823956};\\\", \\\"{x:890,y:439,t:1527635824006};\\\", \\\"{x:886,y:439,t:1527635824030};\\\", \\\"{x:883,y:439,t:1527635824043};\\\", \\\"{x:879,y:441,t:1527635824061};\\\", \\\"{x:870,y:444,t:1527635824076};\\\", \\\"{x:859,y:449,t:1527635824095};\\\", \\\"{x:850,y:451,t:1527635824110};\\\", \\\"{x:840,y:455,t:1527635824127};\\\", \\\"{x:833,y:459,t:1527635824143};\\\", \\\"{x:831,y:460,t:1527635824160};\\\", \\\"{x:830,y:460,t:1527635824177};\\\", \\\"{x:830,y:461,t:1527635824196};\\\", \\\"{x:818,y:463,t:1527635824344};\\\", \\\"{x:785,y:469,t:1527635824359};\\\", \\\"{x:734,y:469,t:1527635824377};\\\", \\\"{x:667,y:469,t:1527635824394};\\\", \\\"{x:634,y:469,t:1527635824410};\\\", \\\"{x:613,y:469,t:1527635824427};\\\", \\\"{x:607,y:469,t:1527635824444};\\\", \\\"{x:603,y:469,t:1527635824460};\\\", \\\"{x:601,y:469,t:1527635824476};\\\", \\\"{x:600,y:469,t:1527635824494};\\\", \\\"{x:599,y:469,t:1527635824517};\\\", \\\"{x:597,y:471,t:1527635824711};\\\", \\\"{x:593,y:489,t:1527635824727};\\\", \\\"{x:585,y:521,t:1527635824745};\\\", \\\"{x:579,y:552,t:1527635824761};\\\", \\\"{x:573,y:577,t:1527635824778};\\\", \\\"{x:569,y:595,t:1527635824794};\\\", \\\"{x:566,y:615,t:1527635824811};\\\", \\\"{x:564,y:632,t:1527635824827};\\\", \\\"{x:562,y:647,t:1527635824844};\\\", \\\"{x:558,y:667,t:1527635824861};\\\", \\\"{x:557,y:674,t:1527635824877};\\\", \\\"{x:557,y:675,t:1527635824894};\\\", \\\"{x:557,y:677,t:1527635824941};\\\", \\\"{x:557,y:679,t:1527635824950};\\\", \\\"{x:557,y:682,t:1527635824962};\\\", \\\"{x:557,y:689,t:1527635824977};\\\", \\\"{x:557,y:694,t:1527635824994};\\\", \\\"{x:557,y:697,t:1527635825011};\\\", \\\"{x:556,y:697,t:1527635825061};\\\", \\\"{x:555,y:697,t:1527635825078};\\\", \\\"{x:555,y:678,t:1527635825096};\\\", \\\"{x:556,y:651,t:1527635825111};\\\", \\\"{x:574,y:599,t:1527635825127};\\\", \\\"{x:603,y:538,t:1527635825145};\\\", \\\"{x:625,y:486,t:1527635825162};\\\", \\\"{x:641,y:452,t:1527635825179};\\\", \\\"{x:643,y:440,t:1527635825194};\\\", \\\"{x:643,y:434,t:1527635825211};\\\", \\\"{x:643,y:431,t:1527635825228};\\\", \\\"{x:643,y:429,t:1527635825253};\\\", \\\"{x:641,y:429,t:1527635825326};\\\", \\\"{x:638,y:429,t:1527635825341};\\\", \\\"{x:636,y:429,t:1527635825349};\\\", \\\"{x:635,y:429,t:1527635825362};\\\", \\\"{x:630,y:430,t:1527635825379};\\\", \\\"{x:626,y:434,t:1527635825394};\\\", \\\"{x:623,y:439,t:1527635825411};\\\", \\\"{x:618,y:445,t:1527635825429};\\\", \\\"{x:615,y:448,t:1527635825446};\\\", \\\"{x:614,y:452,t:1527635825461};\\\", \\\"{x:613,y:453,t:1527635825476};\\\", \\\"{x:613,y:454,t:1527635825628};\\\", \\\"{x:613,y:457,t:1527635825644};\\\", \\\"{x:613,y:459,t:1527635825661};\\\", \\\"{x:613,y:461,t:1527635825678};\\\", \\\"{x:613,y:462,t:1527635825694};\\\", \\\"{x:612,y:464,t:1527635825711};\\\", \\\"{x:611,y:469,t:1527635825728};\\\", \\\"{x:608,y:480,t:1527635825745};\\\", \\\"{x:607,y:492,t:1527635825761};\\\", \\\"{x:606,y:495,t:1527635825778};\\\", \\\"{x:604,y:499,t:1527635825795};\\\", \\\"{x:604,y:505,t:1527635825811};\\\", \\\"{x:604,y:513,t:1527635825829};\\\", \\\"{x:604,y:527,t:1527635825846};\\\", \\\"{x:604,y:542,t:1527635825861};\\\", \\\"{x:602,y:560,t:1527635825879};\\\", \\\"{x:599,y:588,t:1527635825895};\\\", \\\"{x:593,y:619,t:1527635825912};\\\", \\\"{x:585,y:635,t:1527635825928};\\\", \\\"{x:584,y:648,t:1527635825945};\\\", \\\"{x:581,y:653,t:1527635825961};\\\", \\\"{x:578,y:656,t:1527635825978};\\\", \\\"{x:575,y:660,t:1527635825995};\\\", \\\"{x:573,y:670,t:1527635826011};\\\", \\\"{x:570,y:678,t:1527635826028};\\\", \\\"{x:569,y:680,t:1527635826045};\\\", \\\"{x:568,y:680,t:1527635826534};\\\", \\\"{x:567,y:680,t:1527635826966};\\\", \\\"{x:566,y:680,t:1527635826981};\\\", \\\"{x:563,y:680,t:1527635826998};\\\", \\\"{x:561,y:682,t:1527635827015};\\\", \\\"{x:557,y:683,t:1527635827031};\\\", \\\"{x:551,y:685,t:1527635827046};\\\", \\\"{x:546,y:686,t:1527635827062};\\\", \\\"{x:542,y:689,t:1527635827079};\\\", \\\"{x:536,y:691,t:1527635827096};\\\", \\\"{x:531,y:693,t:1527635827112};\\\", \\\"{x:526,y:695,t:1527635827129};\\\", \\\"{x:523,y:697,t:1527635827146};\\\", \\\"{x:520,y:698,t:1527635827162};\\\", \\\"{x:519,y:698,t:1527635827164};\\\", \\\"{x:518,y:699,t:1527635827196};\\\", \\\"{x:517,y:699,t:1527635827261};\\\", \\\"{x:515,y:699,t:1527635827280};\\\", \\\"{x:514,y:698,t:1527635827296};\\\", \\\"{x:513,y:697,t:1527635827312};\\\", \\\"{x:513,y:696,t:1527635827329};\\\", \\\"{x:513,y:692,t:1527635827346};\\\", \\\"{x:520,y:684,t:1527635827362};\\\", \\\"{x:533,y:673,t:1527635827379};\\\", \\\"{x:550,y:659,t:1527635827396};\\\", \\\"{x:580,y:638,t:1527635827413};\\\", \\\"{x:609,y:621,t:1527635827429};\\\", \\\"{x:639,y:602,t:1527635827446};\\\", \\\"{x:658,y:591,t:1527635827463};\\\", \\\"{x:677,y:580,t:1527635827479};\\\", \\\"{x:691,y:571,t:1527635827497};\\\", \\\"{x:704,y:562,t:1527635827513};\\\", \\\"{x:718,y:553,t:1527635827529};\\\", \\\"{x:738,y:543,t:1527635827546};\\\", \\\"{x:757,y:534,t:1527635827563};\\\", \\\"{x:777,y:524,t:1527635827579};\\\", \\\"{x:799,y:508,t:1527635827596};\\\", \\\"{x:823,y:490,t:1527635827613};\\\", \\\"{x:830,y:483,t:1527635827629};\\\", \\\"{x:833,y:480,t:1527635827646};\\\", \\\"{x:835,y:476,t:1527635827663};\\\", \\\"{x:836,y:473,t:1527635827680};\\\", \\\"{x:840,y:468,t:1527635827696};\\\", \\\"{x:842,y:465,t:1527635827713};\\\", \\\"{x:843,y:460,t:1527635827730};\\\", \\\"{x:845,y:456,t:1527635827746};\\\", \\\"{x:846,y:454,t:1527635827763};\\\", \\\"{x:847,y:451,t:1527635827781};\\\", \\\"{x:847,y:450,t:1527635827796};\\\", \\\"{x:849,y:447,t:1527635827813};\\\", \\\"{x:849,y:444,t:1527635827830};\\\", \\\"{x:851,y:442,t:1527635827846};\\\", \\\"{x:852,y:438,t:1527635827864};\\\", \\\"{x:852,y:437,t:1527635827881};\\\", \\\"{x:844,y:437,t:1527635828166};\\\", \\\"{x:835,y:438,t:1527635828180};\\\", \\\"{x:806,y:441,t:1527635828198};\\\", \\\"{x:768,y:445,t:1527635828213};\\\", \\\"{x:715,y:452,t:1527635828230};\\\", \\\"{x:680,y:452,t:1527635828248};\\\", \\\"{x:655,y:452,t:1527635828263};\\\", \\\"{x:640,y:452,t:1527635828291};\\\", \\\"{x:637,y:452,t:1527635828296};\\\", \\\"{x:636,y:452,t:1527635828313};\\\", \\\"{x:635,y:452,t:1527635828333};\\\" ] }, { \\\"rt\\\": 66388, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 804304, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"8FE87\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Events that have a dot that is directly vertical to the 12pm mark.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 5663, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 810972, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"8FE87\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 11129, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Biomedical & Health Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 823118, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"8FE87\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 13726, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 838172, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"8FE87\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\" } ]\",\"parentNode\":{\"id\":2773}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"8FE87\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"line\",\"attributes\":{\"x1\":\"400\",\"x2\":\"0\",\"y1\":\"0\",\"y2\":\"800\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-65) translate(-200,280)\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2412,\"textContent\":\"DURATION (in hours)\"}]}]},{\"nodeType\":1,\"id\":2413,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2414,\"tagName\":\"text\",\"attributes\":{\"x\":\"-1.6666666666666714\",\"y\":\"738.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2415,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2416,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2417,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"33.33333333333333\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"text\",\"attributes\":{\"x\":\"31.666666666666657\",\"y\":\"671.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2420,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2421,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2422,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"66.66666666666666\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"x\":\"65\",\"y\":\"605\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"100\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2429,\"tagName\":\"text\",\"attributes\":{\"x\":\"98.33333333333331\",\"y\":\"538.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2430,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2432,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"133.33333333333331\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2434,\"tagName\":\"text\",\"attributes\":{\"x\":\"131.66666666666669\",\"y\":\"471.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2435,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2436,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2437,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"166.66666666666669\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"text\",\"attributes\":{\"x\":\"165\",\"y\":\"405\"},\"childNodes\":[{\"nodeType\":3,\"id\":2440,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2441,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2442,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"200\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2443,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"x\":\"198.33333333333334\",\"y\":\"338.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"233.33333333333334\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2448,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2449,\"tagName\":\"text\",\"attributes\":{\"x\":\"231.66666666666663\",\"y\":\"271.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2450,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2451,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2452,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"266.66666666666663\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2453,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2454,\"tagName\":\"text\",\"attributes\":{\"x\":\"265\",\"y\":\"205\"},\"childNodes\":[{\"nodeType\":3,\"id\":2455,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2456,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2457,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"300\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"text\",\"attributes\":{\"x\":\"298.33333333333337\",\"y\":\"138.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2460,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2461,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2462,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"333.33333333333337\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2463,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2464,\"tagName\":\"text\",\"attributes\":{\"x\":\"331.66666666666663\",\"y\":\"71.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2465,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"366.66666666666663\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"text\",\"attributes\":{\"x\":\"365\",\"y\":\"5\"},\"childNodes\":[{\"nodeType\":3,\"id\":2470,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2471,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2472,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2473,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2492,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2494,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2496,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2498,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2523,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2588,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2589,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2590,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2591,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2592,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2593,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2594,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2595,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2596,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2597,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2598},{\"nodeType\":3,\"id\":2599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2600,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2601,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2602,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2603,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 234, dom: 629, initialDom: 699",
  "javascriptErrors": []
}