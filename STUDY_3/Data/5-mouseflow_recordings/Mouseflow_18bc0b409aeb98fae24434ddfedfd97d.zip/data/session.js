var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "18bc0b409aeb98fae24434ddfedfd97d",
  "created": "2018-05-15T17:11:49.7670772-07:00",
  "lastActivity": "2018-05-15T17:12:28.313475-07:00",
  "pageViews": [
    {
      "id": "0515499528802adc085249447b9a3b198ea2f212",
      "startTime": "2018-05-15T17:11:49.807475-07:00",
      "endTime": "2018-05-15T17:12:28.313475-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 38506,
      "engagementTime": 36199,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 38506,
  "engagementTime": 36199,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.34",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=6MWHZ",
    "CONDITION=121",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "6626af6257e526041bda88a28b2e19b4",
  "gdpr": false
}