var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "b6f270e8a634efa81fb35775eb3ff6e1",
  "created": "2018-06-04T12:12:26.8589349-07:00",
  "lastActivity": "2018-06-04T12:12:48.9892346-07:00",
  "pageViews": [
    {
      "id": "06042685ffe705f1e3370d80c8097daf0fe5f966",
      "startTime": "2018-06-04T12:12:26.8589349-07:00",
      "endTime": "2018-06-04T12:12:49.2014222-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 22507,
      "engagementTime": 22507,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 22507,
  "engagementTime": 22507,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=8EQOW",
    "CONDITION=311"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "0889846c2ab92a0a774c7204ed6ca55d",
  "gdpr": false
}