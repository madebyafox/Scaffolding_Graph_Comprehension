var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "cfcf750c18dae4a7a7488304a604270e",
  "created": "2018-06-04T13:24:44.0635971-07:00",
  "lastActivity": "2018-06-04T13:26:14.0685971-07:00",
  "pageViews": [
    {
      "id": "06044429cc016a2be0b0e6bcda21a332bdf09867",
      "startTime": "2018-06-04T13:24:44.0635971-07:00",
      "endTime": "2018-06-04T13:26:14.0685971-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 90005,
      "engagementTime": 74772,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 90005,
  "engagementTime": 74772,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.34",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=CWE2H",
    "CONDITION=211"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "ab53fc73e6ee39b13f915b51d02d39d4",
  "gdpr": false
}