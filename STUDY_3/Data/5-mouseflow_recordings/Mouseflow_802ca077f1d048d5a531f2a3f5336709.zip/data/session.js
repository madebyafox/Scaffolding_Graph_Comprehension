var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "802ca077f1d048d5a531f2a3f5336709",
  "created": "2018-06-01T11:18:18.2785984-07:00",
  "lastActivity": "2018-06-01T11:18:37.2455984-07:00",
  "pageViews": [
    {
      "id": "060118553059acacdd9aab4856a1b0fa187ee100",
      "startTime": "2018-06-01T11:18:18.2785984-07:00",
      "endTime": "2018-06-01T11:18:37.2455984-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 18967,
      "engagementTime": 18967,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 18967,
  "engagementTime": 18967,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.49",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=X9225",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "8b8212a0abe66bdcd54113a5a94ac0d5",
  "gdpr": false
}