var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "0967e24e2aea5f5b896d48d257d145cc",
  "created": "2018-06-01T11:18:24.3028157-07:00",
  "lastActivity": "2018-06-01T11:18:54.1478157-07:00",
  "pageViews": [
    {
      "id": "060124932233a3849501e8edcadd4fa1d18091d9",
      "startTime": "2018-06-01T11:18:24.3028157-07:00",
      "endTime": "2018-06-01T11:18:54.1478157-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 29845,
      "engagementTime": 25995,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 29845,
  "engagementTime": 25995,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.41",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=5KWEX",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "c844cd0dbd7dadfa5d9642957d39600f",
  "gdpr": false
}