var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05220879bdab94f3641551cac2085158871ae11d"] = {
  "startTime": "2018-05-22T21:12:08.4073304Z",
  "websitePageUrl": "/16",
  "visitTime": 115966,
  "engagementTime": 76888,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "e21afe2e800f993ff053fbd077a8b78e",
    "created": "2018-05-22T21:12:08.4073304+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=JYZGH",
      "CONDITION=121"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "c601a764134544409d40608babe0c0b4",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/e21afe2e800f993ff053fbd077a8b78e/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 263,
      "e": 263,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 263,
      "e": 263,
      "ty": 2,
      "x": 486,
      "y": 697
    },
    {
      "t": 263,
      "e": 263,
      "ty": 41,
      "x": 43716,
      "y": 41925,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 501,
      "e": 501,
      "ty": 2,
      "x": 486,
      "y": 696
    },
    {
      "t": 501,
      "e": 501,
      "ty": 41,
      "x": 43716,
      "y": 41864,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 641,
      "e": 641,
      "ty": 2,
      "x": 477,
      "y": 677
    },
    {
      "t": 701,
      "e": 701,
      "ty": 2,
      "x": 475,
      "y": 674
    },
    {
      "t": 751,
      "e": 751,
      "ty": 41,
      "x": 42368,
      "y": 40404,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 801,
      "e": 801,
      "ty": 2,
      "x": 474,
      "y": 672
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 473,
      "y": 669
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 468,
      "y": 657
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 41,
      "x": 41693,
      "y": 39491,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1601,
      "e": 1601,
      "ty": 2,
      "x": 459,
      "y": 633
    },
    {
      "t": 1603,
      "e": 1603,
      "ty": 6,
      "x": 457,
      "y": 629,
      "ta": "#strategyButton"
    },
    {
      "t": 1701,
      "e": 1701,
      "ty": 2,
      "x": 449,
      "y": 608
    },
    {
      "t": 1719,
      "e": 1719,
      "ty": 7,
      "x": 448,
      "y": 600,
      "ta": "#strategyButton"
    },
    {
      "t": 1752,
      "e": 1752,
      "ty": 41,
      "x": 59171,
      "y": 15902,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 444,
      "y": 582
    },
    {
      "t": 1901,
      "e": 1901,
      "ty": 2,
      "x": 438,
      "y": 558
    },
    {
      "t": 1936,
      "e": 1936,
      "ty": 6,
      "x": 437,
      "y": 550,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 2,
      "x": 435,
      "y": 544
    },
    {
      "t": 2002,
      "e": 2002,
      "ty": 41,
      "x": 37984,
      "y": 60086,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2101,
      "e": 2101,
      "ty": 2,
      "x": 435,
      "y": 536
    },
    {
      "t": 2201,
      "e": 2201,
      "ty": 2,
      "x": 434,
      "y": 529
    },
    {
      "t": 2251,
      "e": 2251,
      "ty": 41,
      "x": 37871,
      "y": 46332,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2301,
      "e": 2301,
      "ty": 2,
      "x": 434,
      "y": 526
    },
    {
      "t": 2502,
      "e": 2502,
      "ty": 41,
      "x": 37871,
      "y": 45523,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4369,
      "e": 4369,
      "ty": 3,
      "x": 434,
      "y": 526,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4371,
      "e": 4371,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4487,
      "e": 4487,
      "ty": 4,
      "x": 37871,
      "y": 45523,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4488,
      "e": 4488,
      "ty": 5,
      "x": 434,
      "y": 526,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9973,
      "e": 9488,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 10001,
      "e": 9516,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10115,
      "e": 9630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 10115,
      "e": 9630,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10219,
      "e": 9734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I"
    },
    {
      "t": 10235,
      "e": 9750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I"
    },
    {
      "t": 10291,
      "e": 9806,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10292,
      "e": 9807,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10395,
      "e": 9910,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I "
    },
    {
      "t": 10467,
      "e": 9982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 10467,
      "e": 9982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10571,
      "e": 10086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I l"
    },
    {
      "t": 10764,
      "e": 10279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 10765,
      "e": 10280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10875,
      "e": 10390,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I lo"
    },
    {
      "t": 11036,
      "e": 10551,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 11037,
      "e": 10552,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11147,
      "e": 10662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 11332,
      "e": 10847,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 11333,
      "e": 10848,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11427,
      "e": 10942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 11588,
      "e": 11103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11588,
      "e": 11103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11683,
      "e": 11198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11755,
      "e": 11270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 11755,
      "e": 11270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12036,
      "e": 11551,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 12044,
      "e": 11559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12044,
      "e": 11559,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12204,
      "e": 11719,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at"
    },
    {
      "t": 12219,
      "e": 11734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 12267,
      "e": 11782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12267,
      "e": 11782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12348,
      "e": 11863,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12405,
      "e": 11920,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12405,
      "e": 11920,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12556,
      "e": 12071,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 12564,
      "e": 12079,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 12565,
      "e": 12080,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12651,
      "e": 12166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 12715,
      "e": 12230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 12715,
      "e": 12230,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12860,
      "e": 12375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 12916,
      "e": 12431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12916,
      "e": 12431,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13004,
      "e": 12519,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13212,
      "e": 12727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 13212,
      "e": 12727,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13323,
      "e": 12838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 13395,
      "e": 12910,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13396,
      "e": 12911,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13475,
      "e": 12990,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 13564,
      "e": 13079,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13565,
      "e": 13080,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13635,
      "e": 13150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 13715,
      "e": 13230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13715,
      "e": 13230,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13812,
      "e": 13327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 13916,
      "e": 13431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13917,
      "e": 13432,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14003,
      "e": 13518,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 14282,
      "e": 13797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 14283,
      "e": 13798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14393,
      "e": 13908,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 15250,
      "e": 14765,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15251,
      "e": 14766,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15345,
      "e": 14860,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15458,
      "e": 14973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 15458,
      "e": 14973,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15585,
      "e": 15100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 15650,
      "e": 15165,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 15650,
      "e": 15165,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15729,
      "e": 15244,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 15761,
      "e": 15276,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 15762,
      "e": 15277,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15865,
      "e": 15380,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 15866,
      "e": 15381,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15913,
      "e": 15428,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 16034,
      "e": 15549,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 16034,
      "e": 15549,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16057,
      "e": 15572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 16154,
      "e": 15669,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16217,
      "e": 15732,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16218,
      "e": 15733,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16329,
      "e": 15844,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17074,
      "e": 16589,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 17074,
      "e": 16589,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17169,
      "e": 16684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 17306,
      "e": 16821,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 17306,
      "e": 16821,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17393,
      "e": 16908,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 17538,
      "e": 17053,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17539,
      "e": 17054,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17665,
      "e": 17180,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17986,
      "e": 17501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 17986,
      "e": 17501,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18120,
      "e": 17635,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 19234,
      "e": 18749,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 19235,
      "e": 18750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19352,
      "e": 18867,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 19674,
      "e": 19189,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19674,
      "e": 19189,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19777,
      "e": 19292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19999,
      "e": 19514,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 23556,
      "e": 23071,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 23556,
      "e": 23071,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23721,
      "e": 23236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 23970,
      "e": 23485,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 23970,
      "e": 23485,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24082,
      "e": 23597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 24154,
      "e": 23669,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 24154,
      "e": 23669,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24249,
      "e": 23764,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 24345,
      "e": 23860,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 24346,
      "e": 23861,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24473,
      "e": 23988,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 24497,
      "e": 24012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24497,
      "e": 24012,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24603,
      "e": 24118,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the bottom where 12 pm says "
    },
    {
      "t": 24603,
      "e": 24118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24809,
      "e": 24324,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 24810,
      "e": 24325,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24937,
      "e": 24452,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 25130,
      "e": 24645,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25131,
      "e": 24646,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25216,
      "e": 24731,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 25257,
      "e": 24772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 25258,
      "e": 24773,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25403,
      "e": 24918,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the bottom where 12 pm says sta"
    },
    {
      "t": 25403,
      "e": 24918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 25404,
      "e": 24919,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25416,
      "e": 24931,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 25489,
      "e": 25004,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25602,
      "e": 25117,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the bottom where 12 pm says star"
    },
    {
      "t": 25633,
      "e": 25148,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25633,
      "e": 25148,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25746,
      "e": 25261,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 25833,
      "e": 25348,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25833,
      "e": 25348,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25929,
      "e": 25444,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 26025,
      "e": 25540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 26025,
      "e": 25540,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26169,
      "e": 25684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 26225,
      "e": 25740,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26226,
      "e": 25741,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26304,
      "e": 25819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29999,
      "e": 29514,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 32248,
      "e": 30819,
      "ty": 41,
      "x": 37871,
      "y": 48759,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32298,
      "e": 30869,
      "ty": 2,
      "x": 436,
      "y": 540
    },
    {
      "t": 32398,
      "e": 30969,
      "ty": 2,
      "x": 436,
      "y": 550
    },
    {
      "t": 32409,
      "e": 30980,
      "ty": 7,
      "x": 434,
      "y": 558,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32499,
      "e": 31070,
      "ty": 2,
      "x": 431,
      "y": 597
    },
    {
      "t": 32499,
      "e": 31070,
      "ty": 41,
      "x": 52618,
      "y": 18523,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 32509,
      "e": 31080,
      "ty": 6,
      "x": 431,
      "y": 609,
      "ta": "#strategyButton"
    },
    {
      "t": 32592,
      "e": 31163,
      "ty": 7,
      "x": 427,
      "y": 641,
      "ta": "#strategyButton"
    },
    {
      "t": 32598,
      "e": 31169,
      "ty": 2,
      "x": 427,
      "y": 641
    },
    {
      "t": 32699,
      "e": 31270,
      "ty": 2,
      "x": 423,
      "y": 646
    },
    {
      "t": 32749,
      "e": 31320,
      "ty": 41,
      "x": 47000,
      "y": 50636,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 32798,
      "e": 31369,
      "ty": 2,
      "x": 415,
      "y": 641
    },
    {
      "t": 32898,
      "e": 31469,
      "ty": 2,
      "x": 413,
      "y": 636
    },
    {
      "t": 32910,
      "e": 31481,
      "ty": 6,
      "x": 413,
      "y": 635,
      "ta": "#strategyButton"
    },
    {
      "t": 32998,
      "e": 31569,
      "ty": 2,
      "x": 411,
      "y": 628
    },
    {
      "t": 32999,
      "e": 31570,
      "ty": 41,
      "x": 39542,
      "y": 50626,
      "ta": "#strategyButton"
    },
    {
      "t": 33098,
      "e": 31669,
      "ty": 2,
      "x": 408,
      "y": 623
    },
    {
      "t": 33174,
      "e": 31745,
      "ty": 3,
      "x": 408,
      "y": 623,
      "ta": "#strategyButton"
    },
    {
      "t": 33175,
      "e": 31746,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the bottom where 12 pm says started "
    },
    {
      "t": 33176,
      "e": 31747,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33176,
      "e": 31747,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 33248,
      "e": 31819,
      "ty": 41,
      "x": 37904,
      "y": 40989,
      "ta": "#strategyButton"
    },
    {
      "t": 33269,
      "e": 31840,
      "ty": 4,
      "x": 37904,
      "y": 40989,
      "ta": "#strategyButton"
    },
    {
      "t": 33279,
      "e": 31850,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 33282,
      "e": 31853,
      "ty": 5,
      "x": 408,
      "y": 623,
      "ta": "#strategyButton"
    },
    {
      "t": 33287,
      "e": 31858,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 34289,
      "e": 32860,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 34801,
      "e": 33372,
      "ty": 2,
      "x": 408,
      "y": 620
    },
    {
      "t": 34898,
      "e": 33469,
      "ty": 2,
      "x": 557,
      "y": 603
    },
    {
      "t": 34998,
      "e": 33569,
      "ty": 2,
      "x": 821,
      "y": 555
    },
    {
      "t": 34999,
      "e": 33570,
      "ty": 41,
      "x": 2811,
      "y": 16383,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 35099,
      "e": 33670,
      "ty": 2,
      "x": 919,
      "y": 531
    },
    {
      "t": 35199,
      "e": 33770,
      "ty": 2,
      "x": 925,
      "y": 529
    },
    {
      "t": 35248,
      "e": 33819,
      "ty": 41,
      "x": 25521,
      "y": 64125,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 35298,
      "e": 33869,
      "ty": 2,
      "x": 928,
      "y": 522
    },
    {
      "t": 35334,
      "e": 33905,
      "ty": 6,
      "x": 929,
      "y": 520,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35398,
      "e": 33969,
      "ty": 2,
      "x": 929,
      "y": 518
    },
    {
      "t": 35498,
      "e": 34069,
      "ty": 2,
      "x": 929,
      "y": 517
    },
    {
      "t": 35499,
      "e": 34070,
      "ty": 41,
      "x": 26170,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35639,
      "e": 34210,
      "ty": 3,
      "x": 929,
      "y": 517,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35640,
      "e": 34211,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35758,
      "e": 34329,
      "ty": 4,
      "x": 26170,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35758,
      "e": 34329,
      "ty": 5,
      "x": 929,
      "y": 517,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 37457,
      "e": 36028,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 37458,
      "e": 36029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 37576,
      "e": 36147,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 37994,
      "e": 36565,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "96"
    },
    {
      "t": 37994,
      "e": 36565,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38073,
      "e": 36644,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 38898,
      "e": 37469,
      "ty": 2,
      "x": 929,
      "y": 521
    },
    {
      "t": 38914,
      "e": 37485,
      "ty": 7,
      "x": 928,
      "y": 523,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38998,
      "e": 37569,
      "ty": 2,
      "x": 928,
      "y": 535
    },
    {
      "t": 38998,
      "e": 37569,
      "ty": 41,
      "x": 25954,
      "y": 3523,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 39099,
      "e": 37670,
      "ty": 2,
      "x": 929,
      "y": 557
    },
    {
      "t": 39198,
      "e": 37769,
      "ty": 2,
      "x": 933,
      "y": 588
    },
    {
      "t": 39248,
      "e": 37819,
      "ty": 41,
      "x": 27035,
      "y": 40871,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 39299,
      "e": 37870,
      "ty": 6,
      "x": 933,
      "y": 594,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39300,
      "e": 37871,
      "ty": 2,
      "x": 933,
      "y": 594
    },
    {
      "t": 39399,
      "e": 37970,
      "ty": 2,
      "x": 933,
      "y": 605
    },
    {
      "t": 39499,
      "e": 38070,
      "ty": 2,
      "x": 933,
      "y": 611
    },
    {
      "t": 39499,
      "e": 38070,
      "ty": 41,
      "x": 27035,
      "y": 53052,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39589,
      "e": 38160,
      "ty": 3,
      "x": 933,
      "y": 611,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39591,
      "e": 38162,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 39592,
      "e": 38163,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39592,
      "e": 38163,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39732,
      "e": 38303,
      "ty": 4,
      "x": 27035,
      "y": 53052,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39733,
      "e": 38304,
      "ty": 5,
      "x": 933,
      "y": 611,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39999,
      "e": 38570,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40817,
      "e": 39388,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 40962,
      "e": 39533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 40962,
      "e": 39533,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41009,
      "e": 39580,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 41033,
      "e": 39604,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 41193,
      "e": 39764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 41193,
      "e": 39764,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41305,
      "e": 39876,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un"
    },
    {
      "t": 41369,
      "e": 39940,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 41369,
      "e": 39940,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41466,
      "e": 40037,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 41497,
      "e": 40068,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 41498,
      "e": 40069,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41601,
      "e": 40172,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 41673,
      "e": 40244,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 41673,
      "e": 40244,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41769,
      "e": 40340,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 41857,
      "e": 40428,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 41857,
      "e": 40428,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42000,
      "e": 40571,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 42017,
      "e": 40588,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 42017,
      "e": 40588,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42129,
      "e": 40700,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 42193,
      "e": 40764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 42194,
      "e": 40765,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42305,
      "e": 40876,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 42417,
      "e": 40988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 42417,
      "e": 40988,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42521,
      "e": 41092,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 42809,
      "e": 41380,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 42865,
      "e": 41436,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United s"
    },
    {
      "t": 42953,
      "e": 41524,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 43034,
      "e": 41605,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United "
    },
    {
      "t": 43145,
      "e": 41716,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 43265,
      "e": 41836,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 43266,
      "e": 41837,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43401,
      "e": 41972,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United S"
    },
    {
      "t": 43433,
      "e": 42004,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 43489,
      "e": 42060,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 43490,
      "e": 42061,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43529,
      "e": 42100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||T"
    },
    {
      "t": 43640,
      "e": 42211,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 43713,
      "e": 42284,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 43713,
      "e": 42284,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43825,
      "e": 42396,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 43881,
      "e": 42452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 43882,
      "e": 42453,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43969,
      "e": 42540,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 44201,
      "e": 42772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 44273,
      "e": 42844,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United STa"
    },
    {
      "t": 44369,
      "e": 42940,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 44449,
      "e": 43020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United ST"
    },
    {
      "t": 44545,
      "e": 43116,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 44625,
      "e": 43196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United S"
    },
    {
      "t": 44672,
      "e": 43243,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 44672,
      "e": 43243,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44760,
      "e": 43331,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 44801,
      "e": 43372,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 44802,
      "e": 43373,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44912,
      "e": 43483,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 44913,
      "e": 43484,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44929,
      "e": 43500,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||at"
    },
    {
      "t": 45041,
      "e": 43612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 45097,
      "e": 43668,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 45098,
      "e": 43669,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45185,
      "e": 43756,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 45273,
      "e": 43844,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 45274,
      "e": 43845,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45369,
      "e": 43940,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 45417,
      "e": 43988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 45418,
      "e": 43989,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45528,
      "e": 44099,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 45617,
      "e": 44188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "79"
    },
    {
      "t": 45617,
      "e": 44188,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45697,
      "e": 44268,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "70"
    },
    {
      "t": 45697,
      "e": 44268,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45704,
      "e": 44275,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||of"
    },
    {
      "t": 45809,
      "e": 44380,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 45848,
      "e": 44419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 45848,
      "e": 44419,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45929,
      "e": 44500,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 45985,
      "e": 44556,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 46114,
      "e": 44685,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 46114,
      "e": 44685,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46248,
      "e": 44819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||A"
    },
    {
      "t": 46264,
      "e": 44835,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 46377,
      "e": 44948,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "77"
    },
    {
      "t": 46378,
      "e": 44949,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46449,
      "e": 45020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||m"
    },
    {
      "t": 46521,
      "e": 45092,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 46521,
      "e": 45092,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46616,
      "e": 45187,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "82"
    },
    {
      "t": 46616,
      "e": 45187,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46664,
      "e": 45235,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||er"
    },
    {
      "t": 46729,
      "e": 45300,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 46817,
      "e": 45388,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 46818,
      "e": 45389,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46912,
      "e": 45483,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||i"
    },
    {
      "t": 47329,
      "e": 45900,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 47329,
      "e": 45900,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47416,
      "e": 45987,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||c"
    },
    {
      "t": 47457,
      "e": 46028,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 47457,
      "e": 46028,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47577,
      "e": 46148,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 48372,
      "e": 46943,
      "ty": 7,
      "x": 933,
      "y": 616,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48399,
      "e": 46970,
      "ty": 2,
      "x": 933,
      "y": 618
    },
    {
      "t": 48440,
      "e": 47011,
      "ty": 6,
      "x": 937,
      "y": 623,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 48499,
      "e": 47070,
      "ty": 2,
      "x": 939,
      "y": 629
    },
    {
      "t": 48499,
      "e": 47070,
      "ty": 41,
      "x": 22202,
      "y": 11915,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 48599,
      "e": 47170,
      "ty": 2,
      "x": 941,
      "y": 635
    },
    {
      "t": 48694,
      "e": 47265,
      "ty": 3,
      "x": 941,
      "y": 635,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 48694,
      "e": 47265,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States of America"
    },
    {
      "t": 48696,
      "e": 47267,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48696,
      "e": 47267,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 48749,
      "e": 47320,
      "ty": 41,
      "x": 23232,
      "y": 23830,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 48805,
      "e": 47376,
      "ty": 4,
      "x": 23232,
      "y": 23830,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 48805,
      "e": 47376,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 48805,
      "e": 47376,
      "ty": 5,
      "x": 941,
      "y": 635,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 48806,
      "e": 47377,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 49198,
      "e": 47769,
      "ty": 2,
      "x": 940,
      "y": 636
    },
    {
      "t": 49249,
      "e": 47820,
      "ty": 41,
      "x": 32027,
      "y": 38274,
      "ta": "html > body"
    },
    {
      "t": 49300,
      "e": 47821,
      "ty": 2,
      "x": 938,
      "y": 637
    },
    {
      "t": 49398,
      "e": 47919,
      "ty": 2,
      "x": 938,
      "y": 638
    },
    {
      "t": 49499,
      "e": 48020,
      "ty": 41,
      "x": 32027,
      "y": 38335,
      "ta": "html > body"
    },
    {
      "t": 49821,
      "e": 48342,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 50099,
      "e": 48620,
      "ty": 2,
      "x": 937,
      "y": 638
    },
    {
      "t": 50199,
      "e": 48720,
      "ty": 2,
      "x": 933,
      "y": 596
    },
    {
      "t": 50249,
      "e": 48770,
      "ty": 41,
      "x": 26480,
      "y": 8394,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 50299,
      "e": 48820,
      "ty": 2,
      "x": 933,
      "y": 593
    },
    {
      "t": 50599,
      "e": 49120,
      "ty": 2,
      "x": 940,
      "y": 286
    },
    {
      "t": 50699,
      "e": 49220,
      "ty": 2,
      "x": 920,
      "y": 188
    },
    {
      "t": 50749,
      "e": 49270,
      "ty": 41,
      "x": 23395,
      "y": 37448,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 50799,
      "e": 49320,
      "ty": 2,
      "x": 911,
      "y": 192
    },
    {
      "t": 50899,
      "e": 49420,
      "ty": 2,
      "x": 900,
      "y": 205
    },
    {
      "t": 50999,
      "e": 49520,
      "ty": 2,
      "x": 883,
      "y": 208
    },
    {
      "t": 51000,
      "e": 49521,
      "ty": 41,
      "x": 46899,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 51099,
      "e": 49620,
      "ty": 2,
      "x": 862,
      "y": 199
    },
    {
      "t": 51158,
      "e": 49679,
      "ty": 6,
      "x": 836,
      "y": 183,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 51190,
      "e": 49711,
      "ty": 7,
      "x": 828,
      "y": 178,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 51199,
      "e": 49720,
      "ty": 2,
      "x": 828,
      "y": 178
    },
    {
      "t": 51249,
      "e": 49770,
      "ty": 41,
      "x": 5386,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 51437,
      "e": 49958,
      "ty": 3,
      "x": 828,
      "y": 178,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 51541,
      "e": 50062,
      "ty": 4,
      "x": 5386,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 51542,
      "e": 50063,
      "ty": 5,
      "x": 828,
      "y": 178,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 51542,
      "e": 50063,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 51544,
      "e": 50065,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 51776,
      "e": 50297,
      "ty": 6,
      "x": 828,
      "y": 180,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 51799,
      "e": 50320,
      "ty": 2,
      "x": 829,
      "y": 182
    },
    {
      "t": 51874,
      "e": 50395,
      "ty": 7,
      "x": 832,
      "y": 193,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 51899,
      "e": 50420,
      "ty": 2,
      "x": 832,
      "y": 197
    },
    {
      "t": 51924,
      "e": 50445,
      "ty": 6,
      "x": 833,
      "y": 211,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 51957,
      "e": 50478,
      "ty": 7,
      "x": 838,
      "y": 223,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 51999,
      "e": 50520,
      "ty": 2,
      "x": 839,
      "y": 231
    },
    {
      "t": 51999,
      "e": 50520,
      "ty": 41,
      "x": 4171,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 52007,
      "e": 50528,
      "ty": 6,
      "x": 839,
      "y": 236,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 52041,
      "e": 50562,
      "ty": 7,
      "x": 840,
      "y": 247,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 52099,
      "e": 50620,
      "ty": 2,
      "x": 845,
      "y": 279
    },
    {
      "t": 52199,
      "e": 50720,
      "ty": 2,
      "x": 846,
      "y": 293
    },
    {
      "t": 52249,
      "e": 50770,
      "ty": 41,
      "x": 5832,
      "y": 13899,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 52299,
      "e": 50820,
      "ty": 2,
      "x": 846,
      "y": 294
    },
    {
      "t": 52399,
      "e": 50920,
      "ty": 2,
      "x": 846,
      "y": 295
    },
    {
      "t": 52442,
      "e": 50963,
      "ty": 6,
      "x": 837,
      "y": 241,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 52459,
      "e": 50980,
      "ty": 7,
      "x": 833,
      "y": 228,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 52476,
      "e": 50997,
      "ty": 6,
      "x": 832,
      "y": 218,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 52499,
      "e": 51020,
      "ty": 2,
      "x": 830,
      "y": 211
    },
    {
      "t": 52499,
      "e": 51020,
      "ty": 41,
      "x": 18037,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 52509,
      "e": 51030,
      "ty": 7,
      "x": 829,
      "y": 204,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 52599,
      "e": 51120,
      "ty": 2,
      "x": 828,
      "y": 198
    },
    {
      "t": 52749,
      "e": 51270,
      "ty": 41,
      "x": 1561,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 52799,
      "e": 51320,
      "ty": 2,
      "x": 828,
      "y": 202
    },
    {
      "t": 52825,
      "e": 51346,
      "ty": 6,
      "x": 830,
      "y": 219,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 52842,
      "e": 51363,
      "ty": 7,
      "x": 833,
      "y": 237,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 52842,
      "e": 51363,
      "ty": 6,
      "x": 833,
      "y": 237,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 52858,
      "e": 51379,
      "ty": 7,
      "x": 835,
      "y": 255,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 52899,
      "e": 51420,
      "ty": 2,
      "x": 842,
      "y": 305
    },
    {
      "t": 52999,
      "e": 51520,
      "ty": 2,
      "x": 850,
      "y": 360
    },
    {
      "t": 53000,
      "e": 51521,
      "ty": 41,
      "x": 33453,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 53099,
      "e": 51620,
      "ty": 2,
      "x": 854,
      "y": 389
    },
    {
      "t": 53199,
      "e": 51720,
      "ty": 2,
      "x": 858,
      "y": 417
    },
    {
      "t": 53249,
      "e": 51770,
      "ty": 41,
      "x": 38663,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 53299,
      "e": 51820,
      "ty": 2,
      "x": 858,
      "y": 418
    },
    {
      "t": 53398,
      "e": 51919,
      "ty": 2,
      "x": 847,
      "y": 407
    },
    {
      "t": 53499,
      "e": 52020,
      "ty": 2,
      "x": 848,
      "y": 410
    },
    {
      "t": 53499,
      "e": 52020,
      "ty": 41,
      "x": 28093,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 53599,
      "e": 52120,
      "ty": 2,
      "x": 861,
      "y": 439
    },
    {
      "t": 53748,
      "e": 52269,
      "ty": 41,
      "x": 35523,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 53799,
      "e": 52320,
      "ty": 2,
      "x": 856,
      "y": 447
    },
    {
      "t": 53876,
      "e": 52397,
      "ty": 6,
      "x": 838,
      "y": 446,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 53899,
      "e": 52420,
      "ty": 2,
      "x": 837,
      "y": 443
    },
    {
      "t": 53942,
      "e": 52463,
      "ty": 7,
      "x": 835,
      "y": 437,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 53999,
      "e": 52520,
      "ty": 2,
      "x": 834,
      "y": 429
    },
    {
      "t": 53999,
      "e": 52520,
      "ty": 41,
      "x": 2985,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 54099,
      "e": 52620,
      "ty": 2,
      "x": 833,
      "y": 425
    },
    {
      "t": 54117,
      "e": 52638,
      "ty": 6,
      "x": 832,
      "y": 423,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 54199,
      "e": 52720,
      "ty": 2,
      "x": 832,
      "y": 417
    },
    {
      "t": 54249,
      "e": 52770,
      "ty": 41,
      "x": 28120,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 54373,
      "e": 52894,
      "ty": 3,
      "x": 832,
      "y": 417,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 54374,
      "e": 52895,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 54376,
      "e": 52897,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 54468,
      "e": 52989,
      "ty": 4,
      "x": 28120,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 54469,
      "e": 52990,
      "ty": 5,
      "x": 832,
      "y": 417,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 54469,
      "e": 52990,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 54677,
      "e": 53198,
      "ty": 7,
      "x": 837,
      "y": 434,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 54699,
      "e": 53220,
      "ty": 2,
      "x": 841,
      "y": 446
    },
    {
      "t": 54749,
      "e": 53270,
      "ty": 41,
      "x": 7256,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-5"
    },
    {
      "t": 54799,
      "e": 53320,
      "ty": 2,
      "x": 857,
      "y": 522
    },
    {
      "t": 54899,
      "e": 53420,
      "ty": 2,
      "x": 872,
      "y": 599
    },
    {
      "t": 54999,
      "e": 53520,
      "ty": 2,
      "x": 858,
      "y": 630
    },
    {
      "t": 54999,
      "e": 53520,
      "ty": 41,
      "x": 9821,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 55099,
      "e": 53620,
      "ty": 2,
      "x": 850,
      "y": 632
    },
    {
      "t": 55199,
      "e": 53720,
      "ty": 2,
      "x": 866,
      "y": 515
    },
    {
      "t": 55249,
      "e": 53770,
      "ty": 41,
      "x": 33828,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 55299,
      "e": 53820,
      "ty": 2,
      "x": 871,
      "y": 489
    },
    {
      "t": 55399,
      "e": 53920,
      "ty": 2,
      "x": 883,
      "y": 520
    },
    {
      "t": 55499,
      "e": 54020,
      "ty": 2,
      "x": 896,
      "y": 580
    },
    {
      "t": 55499,
      "e": 54020,
      "ty": 41,
      "x": 17699,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 55599,
      "e": 54120,
      "ty": 2,
      "x": 894,
      "y": 587
    },
    {
      "t": 55699,
      "e": 54220,
      "ty": 2,
      "x": 870,
      "y": 587
    },
    {
      "t": 55750,
      "e": 54271,
      "ty": 41,
      "x": 11528,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 55799,
      "e": 54320,
      "ty": 2,
      "x": 867,
      "y": 587
    },
    {
      "t": 55900,
      "e": 54421,
      "ty": 2,
      "x": 865,
      "y": 597
    },
    {
      "t": 55999,
      "e": 54421,
      "ty": 2,
      "x": 870,
      "y": 610
    },
    {
      "t": 56001,
      "e": 54423,
      "ty": 41,
      "x": 11528,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 56199,
      "e": 54621,
      "ty": 2,
      "x": 866,
      "y": 610
    },
    {
      "t": 56249,
      "e": 54671,
      "ty": 41,
      "x": 9155,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 56299,
      "e": 54721,
      "ty": 2,
      "x": 859,
      "y": 608
    },
    {
      "t": 56399,
      "e": 54821,
      "ty": 2,
      "x": 854,
      "y": 606
    },
    {
      "t": 56499,
      "e": 54921,
      "ty": 2,
      "x": 845,
      "y": 617
    },
    {
      "t": 56500,
      "e": 54922,
      "ty": 41,
      "x": 6330,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 56599,
      "e": 55021,
      "ty": 2,
      "x": 845,
      "y": 625
    },
    {
      "t": 56749,
      "e": 55171,
      "ty": 41,
      "x": 6062,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 56799,
      "e": 55221,
      "ty": 2,
      "x": 843,
      "y": 617
    },
    {
      "t": 56899,
      "e": 55321,
      "ty": 2,
      "x": 843,
      "y": 613
    },
    {
      "t": 57000,
      "e": 55422,
      "ty": 41,
      "x": 5793,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 57399,
      "e": 55821,
      "ty": 2,
      "x": 841,
      "y": 612
    },
    {
      "t": 57499,
      "e": 55921,
      "ty": 2,
      "x": 845,
      "y": 610
    },
    {
      "t": 57499,
      "e": 55921,
      "ty": 41,
      "x": 5595,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 57599,
      "e": 56021,
      "ty": 2,
      "x": 870,
      "y": 614
    },
    {
      "t": 57700,
      "e": 56122,
      "ty": 2,
      "x": 901,
      "y": 630
    },
    {
      "t": 57748,
      "e": 56170,
      "ty": 41,
      "x": 20072,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 57799,
      "e": 56221,
      "ty": 2,
      "x": 910,
      "y": 639
    },
    {
      "t": 57900,
      "e": 56322,
      "ty": 2,
      "x": 906,
      "y": 648
    },
    {
      "t": 57999,
      "e": 56421,
      "ty": 2,
      "x": 873,
      "y": 651
    },
    {
      "t": 57999,
      "e": 56421,
      "ty": 41,
      "x": 12996,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 58099,
      "e": 56521,
      "ty": 2,
      "x": 859,
      "y": 653
    },
    {
      "t": 58180,
      "e": 56602,
      "ty": 6,
      "x": 836,
      "y": 644,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 58197,
      "e": 56619,
      "ty": 7,
      "x": 834,
      "y": 642,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 58199,
      "e": 56621,
      "ty": 2,
      "x": 834,
      "y": 642
    },
    {
      "t": 58249,
      "e": 56671,
      "ty": 41,
      "x": 2917,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 58299,
      "e": 56721,
      "ty": 2,
      "x": 832,
      "y": 641
    },
    {
      "t": 58302,
      "e": 56724,
      "ty": 6,
      "x": 832,
      "y": 643,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 58348,
      "e": 56770,
      "ty": 7,
      "x": 837,
      "y": 661,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 58399,
      "e": 56821,
      "ty": 2,
      "x": 844,
      "y": 672
    },
    {
      "t": 58499,
      "e": 56921,
      "ty": 2,
      "x": 844,
      "y": 673
    },
    {
      "t": 58500,
      "e": 56922,
      "ty": 41,
      "x": 5666,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 58598,
      "e": 57020,
      "ty": 6,
      "x": 836,
      "y": 675,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 58598,
      "e": 57020,
      "ty": 2,
      "x": 836,
      "y": 675
    },
    {
      "t": 58630,
      "e": 57052,
      "ty": 7,
      "x": 825,
      "y": 670,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 58699,
      "e": 57121,
      "ty": 2,
      "x": 824,
      "y": 664
    },
    {
      "t": 58749,
      "e": 57171,
      "ty": 41,
      "x": 649,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 58780,
      "e": 57202,
      "ty": 6,
      "x": 828,
      "y": 650,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 58799,
      "e": 57221,
      "ty": 2,
      "x": 828,
      "y": 650
    },
    {
      "t": 58846,
      "e": 57268,
      "ty": 7,
      "x": 832,
      "y": 639,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 58898,
      "e": 57320,
      "ty": 2,
      "x": 834,
      "y": 635
    },
    {
      "t": 58999,
      "e": 57421,
      "ty": 41,
      "x": 2985,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 59063,
      "e": 57485,
      "ty": 6,
      "x": 839,
      "y": 649,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 59081,
      "e": 57503,
      "ty": 7,
      "x": 843,
      "y": 657,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 59099,
      "e": 57521,
      "ty": 2,
      "x": 845,
      "y": 663
    },
    {
      "t": 59198,
      "e": 57620,
      "ty": 2,
      "x": 854,
      "y": 700
    },
    {
      "t": 59249,
      "e": 57671,
      "ty": 41,
      "x": 7731,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 59298,
      "e": 57720,
      "ty": 2,
      "x": 854,
      "y": 741
    },
    {
      "t": 59399,
      "e": 57821,
      "ty": 2,
      "x": 850,
      "y": 753
    },
    {
      "t": 59448,
      "e": 57870,
      "ty": 6,
      "x": 837,
      "y": 759,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 59499,
      "e": 57921,
      "ty": 2,
      "x": 832,
      "y": 765
    },
    {
      "t": 59499,
      "e": 57921,
      "ty": 41,
      "x": 28120,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 59530,
      "e": 57952,
      "ty": 7,
      "x": 830,
      "y": 768,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 59599,
      "e": 58021,
      "ty": 2,
      "x": 830,
      "y": 779
    },
    {
      "t": 59693,
      "e": 58115,
      "ty": 6,
      "x": 831,
      "y": 784,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 59698,
      "e": 58120,
      "ty": 2,
      "x": 831,
      "y": 784
    },
    {
      "t": 59749,
      "e": 58171,
      "ty": 41,
      "x": 23079,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 59798,
      "e": 58220,
      "ty": 2,
      "x": 829,
      "y": 791
    },
    {
      "t": 59898,
      "e": 58320,
      "ty": 2,
      "x": 827,
      "y": 794
    },
    {
      "t": 59998,
      "e": 58420,
      "ty": 2,
      "x": 828,
      "y": 790
    },
    {
      "t": 59998,
      "e": 58420,
      "ty": 41,
      "x": 7955,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 60031,
      "e": 58453,
      "ty": 7,
      "x": 830,
      "y": 779,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 60098,
      "e": 58520,
      "ty": 2,
      "x": 827,
      "y": 769
    },
    {
      "t": 60131,
      "e": 58553,
      "ty": 6,
      "x": 827,
      "y": 766,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 60198,
      "e": 58620,
      "ty": 2,
      "x": 827,
      "y": 760
    },
    {
      "t": 60249,
      "e": 58620,
      "ty": 41,
      "x": 2914,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 60299,
      "e": 58670,
      "ty": 2,
      "x": 827,
      "y": 759
    },
    {
      "t": 60428,
      "e": 58799,
      "ty": 3,
      "x": 827,
      "y": 759,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 60429,
      "e": 58800,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 60429,
      "e": 58800,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 60556,
      "e": 58927,
      "ty": 4,
      "x": 2914,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 60557,
      "e": 58928,
      "ty": 5,
      "x": 827,
      "y": 759,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 60558,
      "e": 58929,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf",
      "v": "Humanities"
    },
    {
      "t": 60799,
      "e": 59170,
      "ty": 2,
      "x": 827,
      "y": 757
    },
    {
      "t": 60832,
      "e": 59203,
      "ty": 7,
      "x": 830,
      "y": 753,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 60866,
      "e": 59237,
      "ty": 6,
      "x": 836,
      "y": 737,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 60882,
      "e": 59253,
      "ty": 7,
      "x": 840,
      "y": 721,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 60898,
      "e": 59269,
      "ty": 2,
      "x": 840,
      "y": 721
    },
    {
      "t": 60998,
      "e": 59369,
      "ty": 2,
      "x": 850,
      "y": 658
    },
    {
      "t": 60998,
      "e": 59369,
      "ty": 41,
      "x": 7201,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 61098,
      "e": 59469,
      "ty": 2,
      "x": 851,
      "y": 620
    },
    {
      "t": 61198,
      "e": 59569,
      "ty": 2,
      "x": 854,
      "y": 581
    },
    {
      "t": 61248,
      "e": 59619,
      "ty": 41,
      "x": 7731,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 61298,
      "e": 59669,
      "ty": 2,
      "x": 854,
      "y": 579
    },
    {
      "t": 61398,
      "e": 59769,
      "ty": 2,
      "x": 853,
      "y": 606
    },
    {
      "t": 61498,
      "e": 59869,
      "ty": 2,
      "x": 853,
      "y": 649
    },
    {
      "t": 61499,
      "e": 59870,
      "ty": 41,
      "x": 7957,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 61598,
      "e": 59969,
      "ty": 2,
      "x": 864,
      "y": 722
    },
    {
      "t": 61698,
      "e": 60069,
      "ty": 2,
      "x": 887,
      "y": 776
    },
    {
      "t": 61748,
      "e": 60119,
      "ty": 41,
      "x": 20309,
      "y": 52009,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 61798,
      "e": 60169,
      "ty": 2,
      "x": 932,
      "y": 836
    },
    {
      "t": 61898,
      "e": 60269,
      "ty": 2,
      "x": 970,
      "y": 872
    },
    {
      "t": 61998,
      "e": 60369,
      "ty": 2,
      "x": 1004,
      "y": 892
    },
    {
      "t": 61999,
      "e": 60370,
      "ty": 41,
      "x": 43330,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 62098,
      "e": 60469,
      "ty": 2,
      "x": 1013,
      "y": 896
    },
    {
      "t": 62198,
      "e": 60569,
      "ty": 2,
      "x": 1014,
      "y": 896
    },
    {
      "t": 62248,
      "e": 60619,
      "ty": 41,
      "x": 45703,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 62298,
      "e": 60669,
      "ty": 2,
      "x": 998,
      "y": 903
    },
    {
      "t": 62399,
      "e": 60770,
      "ty": 2,
      "x": 982,
      "y": 908
    },
    {
      "t": 62498,
      "e": 60869,
      "ty": 2,
      "x": 979,
      "y": 909
    },
    {
      "t": 62498,
      "e": 60869,
      "ty": 41,
      "x": 37397,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 62598,
      "e": 60969,
      "ty": 2,
      "x": 871,
      "y": 915
    },
    {
      "t": 62698,
      "e": 61069,
      "ty": 2,
      "x": 784,
      "y": 925
    },
    {
      "t": 62748,
      "e": 61119,
      "ty": 41,
      "x": 26413,
      "y": 55068,
      "ta": "html > body"
    },
    {
      "t": 62798,
      "e": 61169,
      "ty": 2,
      "x": 783,
      "y": 880
    },
    {
      "t": 62898,
      "e": 61269,
      "ty": 2,
      "x": 821,
      "y": 851
    },
    {
      "t": 62998,
      "e": 61369,
      "ty": 2,
      "x": 828,
      "y": 866
    },
    {
      "t": 62998,
      "e": 61369,
      "ty": 41,
      "x": 1561,
      "y": 22181,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 63050,
      "e": 61421,
      "ty": 6,
      "x": 829,
      "y": 876,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 63098,
      "e": 61469,
      "ty": 2,
      "x": 829,
      "y": 883
    },
    {
      "t": 63100,
      "e": 61471,
      "ty": 7,
      "x": 829,
      "y": 888,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 63198,
      "e": 61569,
      "ty": 2,
      "x": 834,
      "y": 899
    },
    {
      "t": 63248,
      "e": 61619,
      "ty": 41,
      "x": 10174,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 63298,
      "e": 61669,
      "ty": 2,
      "x": 834,
      "y": 901
    },
    {
      "t": 63364,
      "e": 61735,
      "ty": 6,
      "x": 835,
      "y": 904,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 63396,
      "e": 61767,
      "ty": 3,
      "x": 835,
      "y": 906,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 63397,
      "e": 61768,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 63397,
      "e": 61768,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 63398,
      "e": 61769,
      "ty": 2,
      "x": 835,
      "y": 906
    },
    {
      "t": 63498,
      "e": 61869,
      "ty": 2,
      "x": 835,
      "y": 907
    },
    {
      "t": 63499,
      "e": 61870,
      "ty": 41,
      "x": 43243,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 63540,
      "e": 61911,
      "ty": 4,
      "x": 43243,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 63542,
      "e": 61913,
      "ty": 5,
      "x": 835,
      "y": 907,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 63543,
      "e": 61914,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 63748,
      "e": 62119,
      "ty": 41,
      "x": 43243,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 63768,
      "e": 62139,
      "ty": 7,
      "x": 843,
      "y": 920,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 63798,
      "e": 62169,
      "ty": 2,
      "x": 845,
      "y": 923
    },
    {
      "t": 63898,
      "e": 62269,
      "ty": 2,
      "x": 860,
      "y": 943
    },
    {
      "t": 63935,
      "e": 62306,
      "ty": 6,
      "x": 870,
      "y": 955,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63998,
      "e": 62369,
      "ty": 2,
      "x": 880,
      "y": 969
    },
    {
      "t": 63998,
      "e": 62369,
      "ty": 41,
      "x": 26067,
      "y": 33760,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64099,
      "e": 62470,
      "ty": 2,
      "x": 880,
      "y": 970
    },
    {
      "t": 64157,
      "e": 62528,
      "ty": 3,
      "x": 880,
      "y": 970,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64158,
      "e": 62529,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 64159,
      "e": 62530,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64244,
      "e": 62615,
      "ty": 4,
      "x": 26067,
      "y": 35746,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64244,
      "e": 62615,
      "ty": 5,
      "x": 880,
      "y": 970,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64246,
      "e": 62617,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64248,
      "e": 62619,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 64249,
      "e": 62620,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 64250,
      "e": 62621,
      "ty": 41,
      "x": 30029,
      "y": 58537,
      "ta": "html > body"
    },
    {
      "t": 64598,
      "e": 62969,
      "ty": 2,
      "x": 911,
      "y": 897
    },
    {
      "t": 64698,
      "e": 63069,
      "ty": 2,
      "x": 977,
      "y": 549
    },
    {
      "t": 64750,
      "e": 63070,
      "ty": 41,
      "x": 29375,
      "y": 19593,
      "ta": "html > body"
    },
    {
      "t": 64798,
      "e": 63118,
      "ty": 2,
      "x": 784,
      "y": 247
    },
    {
      "t": 64899,
      "e": 63219,
      "ty": 2,
      "x": 767,
      "y": 232
    },
    {
      "t": 64999,
      "e": 63319,
      "ty": 41,
      "x": 26138,
      "y": 13630,
      "ta": "html > body"
    },
    {
      "t": 65600,
      "e": 63920,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 67898,
      "e": 66218,
      "ty": 2,
      "x": 765,
      "y": 235
    },
    {
      "t": 67999,
      "e": 66319,
      "ty": 2,
      "x": 764,
      "y": 236
    },
    {
      "t": 67999,
      "e": 66319,
      "ty": 41,
      "x": 23149,
      "y": 9150,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 68098,
      "e": 66418,
      "ty": 2,
      "x": 763,
      "y": 238
    },
    {
      "t": 68249,
      "e": 66569,
      "ty": 41,
      "x": 23100,
      "y": 9302,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 68399,
      "e": 66719,
      "ty": 2,
      "x": 763,
      "y": 239
    },
    {
      "t": 68499,
      "e": 66819,
      "ty": 2,
      "x": 763,
      "y": 248
    },
    {
      "t": 68499,
      "e": 66819,
      "ty": 41,
      "x": 23100,
      "y": 10062,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 68599,
      "e": 66919,
      "ty": 2,
      "x": 763,
      "y": 268
    },
    {
      "t": 68699,
      "e": 67019,
      "ty": 2,
      "x": 818,
      "y": 391
    },
    {
      "t": 68749,
      "e": 67069,
      "ty": 41,
      "x": 27823,
      "y": 11117,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 68798,
      "e": 67118,
      "ty": 2,
      "x": 894,
      "y": 507
    },
    {
      "t": 68899,
      "e": 67219,
      "ty": 2,
      "x": 942,
      "y": 573
    },
    {
      "t": 68998,
      "e": 67318,
      "ty": 2,
      "x": 956,
      "y": 603
    },
    {
      "t": 68999,
      "e": 67319,
      "ty": 41,
      "x": 32595,
      "y": 37225,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 69099,
      "e": 67419,
      "ty": 2,
      "x": 966,
      "y": 639
    },
    {
      "t": 69199,
      "e": 67519,
      "ty": 2,
      "x": 983,
      "y": 700
    },
    {
      "t": 69249,
      "e": 67569,
      "ty": 41,
      "x": 34710,
      "y": 52277,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 69299,
      "e": 67619,
      "ty": 2,
      "x": 1006,
      "y": 747
    },
    {
      "t": 69399,
      "e": 67719,
      "ty": 2,
      "x": 1027,
      "y": 784
    },
    {
      "t": 69499,
      "e": 67819,
      "ty": 2,
      "x": 1034,
      "y": 818
    },
    {
      "t": 69499,
      "e": 67819,
      "ty": 41,
      "x": 36432,
      "y": 62119,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 69598,
      "e": 67918,
      "ty": 2,
      "x": 1038,
      "y": 842
    },
    {
      "t": 69699,
      "e": 68019,
      "ty": 2,
      "x": 1040,
      "y": 848
    },
    {
      "t": 69749,
      "e": 68069,
      "ty": 41,
      "x": 36727,
      "y": 55700,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 69998,
      "e": 68318,
      "ty": 2,
      "x": 1041,
      "y": 848
    },
    {
      "t": 69999,
      "e": 68319,
      "ty": 41,
      "x": 36777,
      "y": 55700,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 69999,
      "e": 68319,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 112397,
      "e": 73319,
      "ty": 2,
      "x": 1002,
      "y": 933
    },
    {
      "t": 112481,
      "e": 73403,
      "ty": 6,
      "x": 993,
      "y": 980,
      "ta": "#start"
    },
    {
      "t": 112497,
      "e": 73419,
      "ty": 2,
      "x": 992,
      "y": 986
    },
    {
      "t": 112497,
      "e": 73419,
      "ty": 41,
      "x": 45055,
      "y": 16775,
      "ta": "#start"
    },
    {
      "t": 112597,
      "e": 73519,
      "ty": 2,
      "x": 1007,
      "y": 1007
    },
    {
      "t": 112623,
      "e": 73545,
      "ty": 7,
      "x": 1008,
      "y": 1012,
      "ta": "#start"
    },
    {
      "t": 112698,
      "e": 73620,
      "ty": 2,
      "x": 1007,
      "y": 1015
    },
    {
      "t": 112748,
      "e": 73670,
      "ty": 41,
      "x": 55002,
      "y": 22944,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 112797,
      "e": 73719,
      "ty": 2,
      "x": 1006,
      "y": 1015
    },
    {
      "t": 112998,
      "e": 73920,
      "ty": 2,
      "x": 1001,
      "y": 1014
    },
    {
      "t": 112998,
      "e": 73920,
      "ty": 41,
      "x": 52193,
      "y": 22336,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 113024,
      "e": 73946,
      "ty": 6,
      "x": 998,
      "y": 1011,
      "ta": "#start"
    },
    {
      "t": 113097,
      "e": 74019,
      "ty": 2,
      "x": 996,
      "y": 1010
    },
    {
      "t": 113198,
      "e": 74120,
      "ty": 2,
      "x": 986,
      "y": 1003
    },
    {
      "t": 113247,
      "e": 74169,
      "ty": 41,
      "x": 41778,
      "y": 45687,
      "ta": "#start"
    },
    {
      "t": 113297,
      "e": 74219,
      "ty": 2,
      "x": 986,
      "y": 1001
    },
    {
      "t": 113716,
      "e": 74638,
      "ty": 3,
      "x": 986,
      "y": 1001,
      "ta": "#start"
    },
    {
      "t": 113716,
      "e": 74638,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 113850,
      "e": 74772,
      "ty": 4,
      "x": 41778,
      "y": 45687,
      "ta": "#start"
    },
    {
      "t": 113850,
      "e": 74772,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 113851,
      "e": 74773,
      "ty": 5,
      "x": 986,
      "y": 1001,
      "ta": "#start"
    },
    {
      "t": 113851,
      "e": 74773,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 114883,
      "e": 75805,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 115966,
      "e": 76888,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 251054, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 251060, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"JYZGH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 3552, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 255999, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"JYZGH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 8730, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"hotel\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"121\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 265734, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"JYZGH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 8678, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 275502, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"JYZGH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 11385, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 287891, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"JYZGH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 44342, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 335684, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"JYZGH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-C -C -C -11 AM-11 AM-11 AM-11 AM-11 AM-01 PM-12 PM-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:938,y:963,t:1527023235570};\\\", \\\"{x:935,y:955,t:1527023235578};\\\", \\\"{x:926,y:943,t:1527023235594};\\\", \\\"{x:926,y:938,t:1527023235608};\\\", \\\"{x:918,y:920,t:1527023235625};\\\", \\\"{x:915,y:914,t:1527023235642};\\\", \\\"{x:911,y:907,t:1527023235658};\\\", \\\"{x:907,y:893,t:1527023235675};\\\", \\\"{x:901,y:879,t:1527023235692};\\\", \\\"{x:895,y:865,t:1527023235708};\\\", \\\"{x:885,y:846,t:1527023235726};\\\", \\\"{x:879,y:828,t:1527023235742};\\\", \\\"{x:870,y:806,t:1527023235759};\\\", \\\"{x:864,y:791,t:1527023235775};\\\", \\\"{x:855,y:774,t:1527023235792};\\\", \\\"{x:841,y:752,t:1527023235809};\\\", \\\"{x:830,y:737,t:1527023235825};\\\", \\\"{x:818,y:720,t:1527023235842};\\\", \\\"{x:807,y:706,t:1527023235860};\\\", \\\"{x:791,y:692,t:1527023235876};\\\", \\\"{x:776,y:681,t:1527023235892};\\\", \\\"{x:765,y:671,t:1527023235909};\\\", \\\"{x:760,y:668,t:1527023235925};\\\", \\\"{x:758,y:666,t:1527023235943};\\\", \\\"{x:757,y:665,t:1527023235959};\\\", \\\"{x:749,y:660,t:1527023236033};\\\", \\\"{x:747,y:659,t:1527023236049};\\\", \\\"{x:747,y:658,t:1527023236185};\\\", \\\"{x:750,y:652,t:1527023236192};\\\", \\\"{x:772,y:636,t:1527023236209};\\\", \\\"{x:797,y:622,t:1527023236225};\\\", \\\"{x:830,y:614,t:1527023236243};\\\", \\\"{x:855,y:614,t:1527023236260};\\\", \\\"{x:860,y:617,t:1527023236275};\\\", \\\"{x:860,y:619,t:1527023236292};\\\", \\\"{x:862,y:622,t:1527023236310};\\\", \\\"{x:863,y:622,t:1527023236938};\\\", \\\"{x:864,y:622,t:1527023236945};\\\", \\\"{x:864,y:621,t:1527023236960};\\\", \\\"{x:867,y:615,t:1527023236977};\\\", \\\"{x:872,y:603,t:1527023236993};\\\", \\\"{x:875,y:596,t:1527023237009};\\\", \\\"{x:879,y:588,t:1527023237026};\\\", \\\"{x:883,y:578,t:1527023237043};\\\", \\\"{x:891,y:568,t:1527023237059};\\\", \\\"{x:902,y:553,t:1527023237077};\\\", \\\"{x:917,y:536,t:1527023237093};\\\", \\\"{x:932,y:525,t:1527023237110};\\\", \\\"{x:951,y:509,t:1527023237126};\\\", \\\"{x:973,y:494,t:1527023237142};\\\", \\\"{x:996,y:476,t:1527023237159};\\\", \\\"{x:1024,y:458,t:1527023237177};\\\", \\\"{x:1058,y:434,t:1527023237192};\\\", \\\"{x:1120,y:407,t:1527023237209};\\\", \\\"{x:1170,y:384,t:1527023237226};\\\", \\\"{x:1203,y:371,t:1527023237242};\\\", \\\"{x:1227,y:361,t:1527023237259};\\\", \\\"{x:1252,y:347,t:1527023237276};\\\", \\\"{x:1273,y:333,t:1527023237293};\\\", \\\"{x:1293,y:324,t:1527023237310};\\\", \\\"{x:1316,y:311,t:1527023237327};\\\", \\\"{x:1353,y:295,t:1527023237343};\\\", \\\"{x:1401,y:273,t:1527023237360};\\\", \\\"{x:1444,y:257,t:1527023237377};\\\", \\\"{x:1483,y:247,t:1527023237393};\\\", \\\"{x:1530,y:229,t:1527023237426};\\\", \\\"{x:1539,y:227,t:1527023237442};\\\", \\\"{x:1541,y:226,t:1527023237459};\\\", \\\"{x:1543,y:225,t:1527023237476};\\\", \\\"{x:1550,y:218,t:1527023237493};\\\", \\\"{x:1555,y:214,t:1527023237510};\\\", \\\"{x:1556,y:214,t:1527023237526};\\\", \\\"{x:1557,y:213,t:1527023237784};\\\", \\\"{x:1557,y:212,t:1527023237801};\\\", \\\"{x:1557,y:210,t:1527023237817};\\\", \\\"{x:1556,y:210,t:1527023237826};\\\", \\\"{x:1551,y:207,t:1527023237843};\\\", \\\"{x:1544,y:205,t:1527023237859};\\\", \\\"{x:1533,y:201,t:1527023237876};\\\", \\\"{x:1523,y:198,t:1527023237893};\\\", \\\"{x:1518,y:194,t:1527023237909};\\\", \\\"{x:1516,y:193,t:1527023237926};\\\", \\\"{x:1515,y:193,t:1527023237984};\\\", \\\"{x:1514,y:193,t:1527023238000};\\\", \\\"{x:1513,y:193,t:1527023238040};\\\", \\\"{x:1512,y:193,t:1527023238338};\\\", \\\"{x:1511,y:193,t:1527023238370};\\\", \\\"{x:1510,y:193,t:1527023240553};\\\", \\\"{x:1509,y:194,t:1527023240569};\\\", \\\"{x:1508,y:194,t:1527023240585};\\\", \\\"{x:1507,y:194,t:1527023240641};\\\", \\\"{x:1505,y:195,t:1527023240681};\\\", \\\"{x:1504,y:195,t:1527023240730};\\\", \\\"{x:1499,y:193,t:1527023241818};\\\", \\\"{x:1493,y:188,t:1527023241829};\\\", \\\"{x:1481,y:179,t:1527023241846};\\\", \\\"{x:1471,y:171,t:1527023241862};\\\", \\\"{x:1462,y:165,t:1527023241879};\\\", \\\"{x:1459,y:164,t:1527023241896};\\\", \\\"{x:1458,y:162,t:1527023241912};\\\", \\\"{x:1456,y:162,t:1527023242266};\\\", \\\"{x:1455,y:162,t:1527023242282};\\\", \\\"{x:1453,y:162,t:1527023242296};\\\", \\\"{x:1448,y:162,t:1527023242313};\\\", \\\"{x:1444,y:160,t:1527023242329};\\\", \\\"{x:1431,y:156,t:1527023242346};\\\", \\\"{x:1417,y:154,t:1527023242362};\\\", \\\"{x:1405,y:151,t:1527023242379};\\\", \\\"{x:1397,y:150,t:1527023242396};\\\", \\\"{x:1392,y:149,t:1527023242412};\\\", \\\"{x:1390,y:149,t:1527023242910};\\\", \\\"{x:1389,y:149,t:1527023243606};\\\", \\\"{x:1384,y:151,t:1527023243617};\\\", \\\"{x:1377,y:156,t:1527023243634};\\\", \\\"{x:1372,y:159,t:1527023243651};\\\", \\\"{x:1367,y:164,t:1527023243667};\\\", \\\"{x:1361,y:169,t:1527023243684};\\\", \\\"{x:1348,y:184,t:1527023243701};\\\", \\\"{x:1340,y:195,t:1527023243717};\\\", \\\"{x:1331,y:208,t:1527023243734};\\\", \\\"{x:1324,y:220,t:1527023243751};\\\", \\\"{x:1321,y:227,t:1527023243767};\\\", \\\"{x:1317,y:238,t:1527023243784};\\\", \\\"{x:1315,y:244,t:1527023243801};\\\", \\\"{x:1312,y:253,t:1527023243817};\\\", \\\"{x:1310,y:261,t:1527023243834};\\\", \\\"{x:1308,y:271,t:1527023243854};\\\", \\\"{x:1308,y:274,t:1527023243867};\\\", \\\"{x:1307,y:282,t:1527023243883};\\\", \\\"{x:1305,y:292,t:1527023243901};\\\", \\\"{x:1305,y:298,t:1527023243916};\\\", \\\"{x:1305,y:308,t:1527023243933};\\\", \\\"{x:1305,y:314,t:1527023243950};\\\", \\\"{x:1305,y:322,t:1527023243967};\\\", \\\"{x:1305,y:332,t:1527023243983};\\\", \\\"{x:1305,y:345,t:1527023244001};\\\", \\\"{x:1306,y:356,t:1527023244017};\\\", \\\"{x:1309,y:367,t:1527023244033};\\\", \\\"{x:1311,y:374,t:1527023244050};\\\", \\\"{x:1313,y:379,t:1527023244068};\\\", \\\"{x:1313,y:380,t:1527023244084};\\\", \\\"{x:1313,y:391,t:1527023245342};\\\", \\\"{x:1319,y:417,t:1527023245352};\\\", \\\"{x:1330,y:474,t:1527023245368};\\\", \\\"{x:1349,y:553,t:1527023245385};\\\", \\\"{x:1375,y:614,t:1527023245403};\\\", \\\"{x:1394,y:649,t:1527023245418};\\\", \\\"{x:1419,y:692,t:1527023245435};\\\", \\\"{x:1452,y:749,t:1527023245452};\\\", \\\"{x:1474,y:787,t:1527023245468};\\\", \\\"{x:1481,y:799,t:1527023245485};\\\", \\\"{x:1481,y:798,t:1527023245661};\\\", \\\"{x:1481,y:794,t:1527023245668};\\\", \\\"{x:1481,y:791,t:1527023245684};\\\", \\\"{x:1481,y:788,t:1527023245702};\\\", \\\"{x:1480,y:787,t:1527023245733};\\\", \\\"{x:1480,y:791,t:1527023245934};\\\", \\\"{x:1480,y:817,t:1527023245952};\\\", \\\"{x:1481,y:848,t:1527023245969};\\\", \\\"{x:1481,y:880,t:1527023245985};\\\", \\\"{x:1479,y:912,t:1527023246002};\\\", \\\"{x:1475,y:935,t:1527023246019};\\\", \\\"{x:1475,y:943,t:1527023246035};\\\", \\\"{x:1475,y:945,t:1527023246051};\\\", \\\"{x:1475,y:946,t:1527023246068};\\\", \\\"{x:1475,y:947,t:1527023246084};\\\", \\\"{x:1474,y:947,t:1527023246116};\\\", \\\"{x:1473,y:948,t:1527023246124};\\\", \\\"{x:1472,y:948,t:1527023246156};\\\", \\\"{x:1470,y:948,t:1527023246181};\\\", \\\"{x:1467,y:948,t:1527023246189};\\\", \\\"{x:1463,y:948,t:1527023246201};\\\", \\\"{x:1453,y:950,t:1527023246219};\\\", \\\"{x:1447,y:951,t:1527023246235};\\\", \\\"{x:1436,y:953,t:1527023246252};\\\", \\\"{x:1416,y:964,t:1527023246269};\\\", \\\"{x:1396,y:968,t:1527023246285};\\\", \\\"{x:1375,y:974,t:1527023246302};\\\", \\\"{x:1347,y:978,t:1527023246318};\\\", \\\"{x:1321,y:981,t:1527023246335};\\\", \\\"{x:1290,y:984,t:1527023246352};\\\", \\\"{x:1258,y:987,t:1527023246368};\\\", \\\"{x:1240,y:989,t:1527023246385};\\\", \\\"{x:1230,y:989,t:1527023246402};\\\", \\\"{x:1226,y:989,t:1527023246418};\\\", \\\"{x:1222,y:985,t:1527023246436};\\\", \\\"{x:1219,y:982,t:1527023246452};\\\", \\\"{x:1213,y:968,t:1527023246468};\\\", \\\"{x:1207,y:952,t:1527023246485};\\\", \\\"{x:1203,y:941,t:1527023246501};\\\", \\\"{x:1202,y:934,t:1527023246519};\\\", \\\"{x:1201,y:930,t:1527023246536};\\\", \\\"{x:1201,y:924,t:1527023246552};\\\", \\\"{x:1201,y:921,t:1527023246569};\\\", \\\"{x:1201,y:917,t:1527023246585};\\\", \\\"{x:1201,y:913,t:1527023246603};\\\", \\\"{x:1204,y:908,t:1527023246619};\\\", \\\"{x:1206,y:906,t:1527023246636};\\\", \\\"{x:1208,y:904,t:1527023246652};\\\", \\\"{x:1210,y:901,t:1527023246670};\\\", \\\"{x:1211,y:901,t:1527023246694};\\\", \\\"{x:1212,y:901,t:1527023246702};\\\", \\\"{x:1214,y:901,t:1527023246719};\\\", \\\"{x:1219,y:901,t:1527023246736};\\\", \\\"{x:1225,y:901,t:1527023246752};\\\", \\\"{x:1233,y:901,t:1527023246769};\\\", \\\"{x:1241,y:901,t:1527023246787};\\\", \\\"{x:1248,y:903,t:1527023246802};\\\", \\\"{x:1253,y:903,t:1527023246819};\\\", \\\"{x:1255,y:903,t:1527023246836};\\\", \\\"{x:1256,y:903,t:1527023246852};\\\", \\\"{x:1256,y:904,t:1527023246886};\\\", \\\"{x:1258,y:904,t:1527023246925};\\\", \\\"{x:1259,y:905,t:1527023246936};\\\", \\\"{x:1261,y:905,t:1527023246952};\\\", \\\"{x:1262,y:905,t:1527023246969};\\\", \\\"{x:1265,y:905,t:1527023246986};\\\", \\\"{x:1266,y:905,t:1527023247002};\\\", \\\"{x:1268,y:905,t:1527023247019};\\\", \\\"{x:1269,y:905,t:1527023247036};\\\", \\\"{x:1271,y:905,t:1527023247052};\\\", \\\"{x:1273,y:905,t:1527023247069};\\\", \\\"{x:1274,y:905,t:1527023247093};\\\", \\\"{x:1275,y:905,t:1527023247103};\\\", \\\"{x:1276,y:905,t:1527023247119};\\\", \\\"{x:1277,y:905,t:1527023247136};\\\", \\\"{x:1279,y:905,t:1527023247153};\\\", \\\"{x:1281,y:905,t:1527023247302};\\\", \\\"{x:1282,y:905,t:1527023247341};\\\", \\\"{x:1283,y:905,t:1527023247354};\\\", \\\"{x:1284,y:905,t:1527023247373};\\\", \\\"{x:1284,y:903,t:1527023247614};\\\", \\\"{x:1284,y:902,t:1527023247669};\\\", \\\"{x:1284,y:901,t:1527023247685};\\\", \\\"{x:1284,y:900,t:1527023247702};\\\", \\\"{x:1284,y:896,t:1527023247720};\\\", \\\"{x:1284,y:895,t:1527023247735};\\\", \\\"{x:1284,y:893,t:1527023247753};\\\", \\\"{x:1284,y:892,t:1527023247769};\\\", \\\"{x:1284,y:891,t:1527023247786};\\\", \\\"{x:1284,y:890,t:1527023247802};\\\", \\\"{x:1284,y:891,t:1527023248750};\\\", \\\"{x:1284,y:892,t:1527023248773};\\\", \\\"{x:1284,y:893,t:1527023248787};\\\", \\\"{x:1283,y:893,t:1527023248830};\\\", \\\"{x:1283,y:892,t:1527023251093};\\\", \\\"{x:1283,y:891,t:1527023251510};\\\", \\\"{x:1283,y:890,t:1527023251557};\\\", \\\"{x:1283,y:889,t:1527023251598};\\\", \\\"{x:1283,y:888,t:1527023251678};\\\", \\\"{x:1282,y:887,t:1527023251782};\\\", \\\"{x:1282,y:886,t:1527023251838};\\\", \\\"{x:1282,y:885,t:1527023251855};\\\", \\\"{x:1281,y:884,t:1527023251877};\\\", \\\"{x:1281,y:883,t:1527023251909};\\\", \\\"{x:1281,y:882,t:1527023251925};\\\", \\\"{x:1280,y:881,t:1527023251941};\\\", \\\"{x:1280,y:880,t:1527023251981};\\\", \\\"{x:1280,y:879,t:1527023251997};\\\", \\\"{x:1280,y:878,t:1527023252012};\\\", \\\"{x:1279,y:877,t:1527023252068};\\\", \\\"{x:1279,y:876,t:1527023252085};\\\", \\\"{x:1279,y:875,t:1527023252117};\\\", \\\"{x:1278,y:873,t:1527023252132};\\\", \\\"{x:1278,y:872,t:1527023252206};\\\", \\\"{x:1277,y:872,t:1527023252222};\\\", \\\"{x:1277,y:871,t:1527023252239};\\\", \\\"{x:1277,y:870,t:1527023252256};\\\", \\\"{x:1276,y:869,t:1527023252272};\\\", \\\"{x:1276,y:868,t:1527023252289};\\\", \\\"{x:1275,y:865,t:1527023252305};\\\", \\\"{x:1275,y:864,t:1527023252322};\\\", \\\"{x:1275,y:863,t:1527023253046};\\\", \\\"{x:1275,y:862,t:1527023253056};\\\", \\\"{x:1275,y:860,t:1527023253073};\\\", \\\"{x:1275,y:859,t:1527023253090};\\\", \\\"{x:1275,y:857,t:1527023253125};\\\", \\\"{x:1275,y:856,t:1527023253165};\\\", \\\"{x:1276,y:855,t:1527023253181};\\\", \\\"{x:1276,y:854,t:1527023253205};\\\", \\\"{x:1276,y:853,t:1527023253245};\\\", \\\"{x:1275,y:854,t:1527023253494};\\\", \\\"{x:1274,y:856,t:1527023253507};\\\", \\\"{x:1273,y:859,t:1527023253523};\\\", \\\"{x:1271,y:863,t:1527023253540};\\\", \\\"{x:1270,y:866,t:1527023253557};\\\", \\\"{x:1270,y:868,t:1527023253573};\\\", \\\"{x:1270,y:871,t:1527023253589};\\\", \\\"{x:1270,y:874,t:1527023253607};\\\", \\\"{x:1269,y:877,t:1527023253624};\\\", \\\"{x:1269,y:881,t:1527023253640};\\\", \\\"{x:1269,y:883,t:1527023253657};\\\", \\\"{x:1269,y:885,t:1527023253674};\\\", \\\"{x:1269,y:890,t:1527023253689};\\\", \\\"{x:1269,y:892,t:1527023253707};\\\", \\\"{x:1269,y:895,t:1527023253723};\\\", \\\"{x:1269,y:898,t:1527023253740};\\\", \\\"{x:1271,y:901,t:1527023253756};\\\", \\\"{x:1272,y:904,t:1527023253773};\\\", \\\"{x:1272,y:906,t:1527023253789};\\\", \\\"{x:1273,y:906,t:1527023253814};\\\", \\\"{x:1274,y:906,t:1527023253823};\\\", \\\"{x:1274,y:907,t:1527023253878};\\\", \\\"{x:1276,y:907,t:1527023254244};\\\", \\\"{x:1277,y:907,t:1527023254268};\\\", \\\"{x:1277,y:905,t:1527023254277};\\\", \\\"{x:1278,y:905,t:1527023254292};\\\", \\\"{x:1279,y:903,t:1527023254309};\\\", \\\"{x:1280,y:902,t:1527023254333};\\\", \\\"{x:1281,y:902,t:1527023255141};\\\", \\\"{x:1281,y:901,t:1527023255157};\\\", \\\"{x:1281,y:900,t:1527023255173};\\\", \\\"{x:1282,y:899,t:1527023255190};\\\", \\\"{x:1281,y:897,t:1527023255572};\\\", \\\"{x:1280,y:895,t:1527023255580};\\\", \\\"{x:1277,y:894,t:1527023255590};\\\", \\\"{x:1270,y:889,t:1527023255607};\\\", \\\"{x:1263,y:886,t:1527023255624};\\\", \\\"{x:1260,y:885,t:1527023255640};\\\", \\\"{x:1259,y:884,t:1527023255656};\\\", \\\"{x:1258,y:883,t:1527023255674};\\\", \\\"{x:1256,y:881,t:1527023255690};\\\", \\\"{x:1255,y:880,t:1527023255709};\\\", \\\"{x:1254,y:880,t:1527023255732};\\\", \\\"{x:1253,y:879,t:1527023255748};\\\", \\\"{x:1251,y:877,t:1527023255788};\\\", \\\"{x:1250,y:877,t:1527023255797};\\\", \\\"{x:1249,y:876,t:1527023255807};\\\", \\\"{x:1248,y:874,t:1527023255824};\\\", \\\"{x:1246,y:873,t:1527023255840};\\\", \\\"{x:1246,y:871,t:1527023255857};\\\", \\\"{x:1244,y:869,t:1527023255875};\\\", \\\"{x:1243,y:867,t:1527023255890};\\\", \\\"{x:1242,y:865,t:1527023255907};\\\", \\\"{x:1241,y:863,t:1527023255924};\\\", \\\"{x:1239,y:860,t:1527023255940};\\\", \\\"{x:1238,y:857,t:1527023255957};\\\", \\\"{x:1237,y:855,t:1527023255974};\\\", \\\"{x:1237,y:852,t:1527023255991};\\\", \\\"{x:1236,y:849,t:1527023256007};\\\", \\\"{x:1235,y:844,t:1527023256024};\\\", \\\"{x:1235,y:840,t:1527023256041};\\\", \\\"{x:1234,y:837,t:1527023256057};\\\", \\\"{x:1233,y:829,t:1527023256074};\\\", \\\"{x:1233,y:826,t:1527023256091};\\\", \\\"{x:1232,y:818,t:1527023256107};\\\", \\\"{x:1231,y:810,t:1527023256124};\\\", \\\"{x:1229,y:802,t:1527023256141};\\\", \\\"{x:1226,y:796,t:1527023256156};\\\", \\\"{x:1223,y:791,t:1527023256174};\\\", \\\"{x:1221,y:788,t:1527023256190};\\\", \\\"{x:1221,y:786,t:1527023256207};\\\", \\\"{x:1220,y:784,t:1527023256228};\\\", \\\"{x:1220,y:783,t:1527023256241};\\\", \\\"{x:1219,y:780,t:1527023256258};\\\", \\\"{x:1218,y:777,t:1527023256274};\\\", \\\"{x:1216,y:775,t:1527023256291};\\\", \\\"{x:1215,y:773,t:1527023256307};\\\", \\\"{x:1215,y:772,t:1527023256324};\\\", \\\"{x:1215,y:771,t:1527023256342};\\\", \\\"{x:1214,y:771,t:1527023257341};\\\", \\\"{x:1216,y:777,t:1527023257358};\\\", \\\"{x:1232,y:798,t:1527023257376};\\\", \\\"{x:1257,y:820,t:1527023257391};\\\", \\\"{x:1279,y:839,t:1527023257408};\\\", \\\"{x:1293,y:853,t:1527023257425};\\\", \\\"{x:1305,y:865,t:1527023257441};\\\", \\\"{x:1312,y:874,t:1527023257458};\\\", \\\"{x:1317,y:881,t:1527023257475};\\\", \\\"{x:1317,y:886,t:1527023257491};\\\", \\\"{x:1318,y:889,t:1527023257508};\\\", \\\"{x:1320,y:895,t:1527023257525};\\\", \\\"{x:1320,y:900,t:1527023257541};\\\", \\\"{x:1320,y:903,t:1527023257558};\\\", \\\"{x:1321,y:906,t:1527023257575};\\\", \\\"{x:1321,y:907,t:1527023257598};\\\", \\\"{x:1321,y:908,t:1527023257686};\\\", \\\"{x:1321,y:909,t:1527023257693};\\\", \\\"{x:1320,y:909,t:1527023257709};\\\", \\\"{x:1318,y:910,t:1527023257725};\\\", \\\"{x:1317,y:910,t:1527023257743};\\\", \\\"{x:1314,y:912,t:1527023257759};\\\", \\\"{x:1313,y:912,t:1527023257776};\\\", \\\"{x:1311,y:913,t:1527023257805};\\\", \\\"{x:1311,y:914,t:1527023257820};\\\", \\\"{x:1310,y:914,t:1527023257828};\\\", \\\"{x:1308,y:916,t:1527023257844};\\\", \\\"{x:1307,y:916,t:1527023257858};\\\", \\\"{x:1303,y:917,t:1527023257874};\\\", \\\"{x:1301,y:918,t:1527023257892};\\\", \\\"{x:1298,y:919,t:1527023257907};\\\", \\\"{x:1296,y:919,t:1527023257924};\\\", \\\"{x:1296,y:920,t:1527023257942};\\\", \\\"{x:1295,y:920,t:1527023257958};\\\", \\\"{x:1294,y:920,t:1527023257996};\\\", \\\"{x:1293,y:919,t:1527023258008};\\\", \\\"{x:1291,y:919,t:1527023258025};\\\", \\\"{x:1287,y:917,t:1527023258042};\\\", \\\"{x:1287,y:916,t:1527023258058};\\\", \\\"{x:1285,y:915,t:1527023258075};\\\", \\\"{x:1285,y:914,t:1527023258092};\\\", \\\"{x:1284,y:913,t:1527023258134};\\\", \\\"{x:1284,y:911,t:1527023258174};\\\", \\\"{x:1284,y:910,t:1527023258197};\\\", \\\"{x:1284,y:908,t:1527023258213};\\\", \\\"{x:1284,y:907,t:1527023258224};\\\", \\\"{x:1283,y:907,t:1527023258244};\\\", \\\"{x:1283,y:905,t:1527023258258};\\\", \\\"{x:1283,y:904,t:1527023258276};\\\", \\\"{x:1283,y:903,t:1527023258300};\\\", \\\"{x:1283,y:902,t:1527023258332};\\\", \\\"{x:1283,y:901,t:1527023258356};\\\", \\\"{x:1283,y:900,t:1527023258372};\\\", \\\"{x:1282,y:899,t:1527023258381};\\\", \\\"{x:1282,y:898,t:1527023258404};\\\", \\\"{x:1282,y:897,t:1527023258413};\\\", \\\"{x:1282,y:896,t:1527023258429};\\\", \\\"{x:1282,y:895,t:1527023258445};\\\", \\\"{x:1282,y:894,t:1527023258460};\\\", \\\"{x:1282,y:893,t:1527023258501};\\\", \\\"{x:1282,y:892,t:1527023258582};\\\", \\\"{x:1282,y:891,t:1527023258597};\\\", \\\"{x:1282,y:890,t:1527023258609};\\\", \\\"{x:1282,y:889,t:1527023258629};\\\", \\\"{x:1281,y:888,t:1527023258643};\\\", \\\"{x:1281,y:887,t:1527023258659};\\\", \\\"{x:1281,y:886,t:1527023258675};\\\", \\\"{x:1281,y:884,t:1527023258693};\\\", \\\"{x:1281,y:883,t:1527023258710};\\\", \\\"{x:1281,y:882,t:1527023260029};\\\", \\\"{x:1278,y:883,t:1527023260043};\\\", \\\"{x:1278,y:885,t:1527023260060};\\\", \\\"{x:1277,y:889,t:1527023260076};\\\", \\\"{x:1276,y:894,t:1527023260093};\\\", \\\"{x:1275,y:895,t:1527023260110};\\\", \\\"{x:1275,y:896,t:1527023260126};\\\", \\\"{x:1274,y:896,t:1527023260143};\\\", \\\"{x:1274,y:895,t:1527023261334};\\\", \\\"{x:1274,y:894,t:1527023261349};\\\", \\\"{x:1274,y:893,t:1527023261565};\\\", \\\"{x:1274,y:892,t:1527023261577};\\\", \\\"{x:1274,y:891,t:1527023261593};\\\", \\\"{x:1274,y:890,t:1527023263150};\\\", \\\"{x:1272,y:890,t:1527023263161};\\\", \\\"{x:1271,y:893,t:1527023263178};\\\", \\\"{x:1270,y:898,t:1527023263194};\\\", \\\"{x:1270,y:901,t:1527023263211};\\\", \\\"{x:1268,y:903,t:1527023263228};\\\", \\\"{x:1268,y:904,t:1527023263245};\\\", \\\"{x:1268,y:905,t:1527023263262};\\\", \\\"{x:1268,y:906,t:1527023263428};\\\", \\\"{x:1268,y:908,t:1527023263444};\\\", \\\"{x:1269,y:908,t:1527023263645};\\\", \\\"{x:1270,y:908,t:1527023263685};\\\", \\\"{x:1271,y:908,t:1527023263701};\\\", \\\"{x:1272,y:908,t:1527023263726};\\\", \\\"{x:1273,y:908,t:1527023263733};\\\", \\\"{x:1274,y:907,t:1527023263757};\\\", \\\"{x:1274,y:906,t:1527023263789};\\\", \\\"{x:1276,y:905,t:1527023263797};\\\", \\\"{x:1277,y:904,t:1527023263811};\\\", \\\"{x:1278,y:901,t:1527023263828};\\\", \\\"{x:1280,y:898,t:1527023263845};\\\", \\\"{x:1281,y:896,t:1527023263861};\\\", \\\"{x:1282,y:894,t:1527023263878};\\\", \\\"{x:1282,y:891,t:1527023263895};\\\", \\\"{x:1282,y:889,t:1527023263911};\\\", \\\"{x:1282,y:887,t:1527023263928};\\\", \\\"{x:1282,y:885,t:1527023263945};\\\", \\\"{x:1282,y:884,t:1527023263961};\\\", \\\"{x:1282,y:883,t:1527023263988};\\\", \\\"{x:1282,y:884,t:1527023264077};\\\", \\\"{x:1282,y:889,t:1527023264085};\\\", \\\"{x:1282,y:896,t:1527023264095};\\\", \\\"{x:1284,y:912,t:1527023264112};\\\", \\\"{x:1286,y:926,t:1527023264128};\\\", \\\"{x:1287,y:936,t:1527023264146};\\\", \\\"{x:1289,y:944,t:1527023264161};\\\", \\\"{x:1289,y:946,t:1527023264178};\\\", \\\"{x:1289,y:948,t:1527023264196};\\\", \\\"{x:1289,y:947,t:1527023264341};\\\", \\\"{x:1289,y:943,t:1527023264349};\\\", \\\"{x:1290,y:939,t:1527023264363};\\\", \\\"{x:1291,y:935,t:1527023264378};\\\", \\\"{x:1291,y:926,t:1527023264397};\\\", \\\"{x:1291,y:925,t:1527023264412};\\\", \\\"{x:1291,y:924,t:1527023264429};\\\", \\\"{x:1292,y:923,t:1527023264452};\\\", \\\"{x:1293,y:923,t:1527023264533};\\\", \\\"{x:1293,y:922,t:1527023264545};\\\", \\\"{x:1293,y:921,t:1527023264565};\\\", \\\"{x:1293,y:920,t:1527023264581};\\\", \\\"{x:1292,y:918,t:1527023264597};\\\", \\\"{x:1292,y:917,t:1527023264613};\\\", \\\"{x:1291,y:914,t:1527023264629};\\\", \\\"{x:1290,y:912,t:1527023264645};\\\", \\\"{x:1290,y:911,t:1527023264663};\\\", \\\"{x:1289,y:908,t:1527023264679};\\\", \\\"{x:1289,y:906,t:1527023264696};\\\", \\\"{x:1287,y:903,t:1527023264712};\\\", \\\"{x:1287,y:901,t:1527023264730};\\\", \\\"{x:1286,y:898,t:1527023264745};\\\", \\\"{x:1285,y:895,t:1527023264763};\\\", \\\"{x:1283,y:892,t:1527023264778};\\\", \\\"{x:1282,y:890,t:1527023264795};\\\", \\\"{x:1282,y:886,t:1527023264812};\\\", \\\"{x:1282,y:883,t:1527023264829};\\\", \\\"{x:1281,y:880,t:1527023264845};\\\", \\\"{x:1281,y:878,t:1527023264862};\\\", \\\"{x:1280,y:874,t:1527023264880};\\\", \\\"{x:1280,y:870,t:1527023264895};\\\", \\\"{x:1279,y:866,t:1527023264912};\\\", \\\"{x:1278,y:863,t:1527023264929};\\\", \\\"{x:1277,y:860,t:1527023264945};\\\", \\\"{x:1277,y:856,t:1527023264963};\\\", \\\"{x:1276,y:851,t:1527023264979};\\\", \\\"{x:1274,y:843,t:1527023264996};\\\", \\\"{x:1274,y:840,t:1527023265012};\\\", \\\"{x:1274,y:835,t:1527023265029};\\\", \\\"{x:1273,y:829,t:1527023265046};\\\", \\\"{x:1273,y:828,t:1527023265063};\\\", \\\"{x:1272,y:822,t:1527023265080};\\\", \\\"{x:1272,y:817,t:1527023265095};\\\", \\\"{x:1272,y:812,t:1527023265112};\\\", \\\"{x:1271,y:806,t:1527023265129};\\\", \\\"{x:1270,y:799,t:1527023265145};\\\", \\\"{x:1269,y:796,t:1527023265163};\\\", \\\"{x:1269,y:791,t:1527023265180};\\\", \\\"{x:1268,y:785,t:1527023265196};\\\", \\\"{x:1267,y:782,t:1527023265212};\\\", \\\"{x:1267,y:778,t:1527023265229};\\\", \\\"{x:1267,y:775,t:1527023265245};\\\", \\\"{x:1267,y:773,t:1527023265262};\\\", \\\"{x:1266,y:772,t:1527023265279};\\\", \\\"{x:1266,y:771,t:1527023265296};\\\", \\\"{x:1263,y:771,t:1527023265436};\\\", \\\"{x:1261,y:773,t:1527023265446};\\\", \\\"{x:1256,y:780,t:1527023265462};\\\", \\\"{x:1252,y:788,t:1527023265479};\\\", \\\"{x:1250,y:797,t:1527023265496};\\\", \\\"{x:1250,y:802,t:1527023265512};\\\", \\\"{x:1247,y:810,t:1527023265529};\\\", \\\"{x:1246,y:814,t:1527023265546};\\\", \\\"{x:1245,y:821,t:1527023265562};\\\", \\\"{x:1245,y:824,t:1527023265579};\\\", \\\"{x:1243,y:830,t:1527023265596};\\\", \\\"{x:1242,y:834,t:1527023265612};\\\", \\\"{x:1242,y:836,t:1527023265630};\\\", \\\"{x:1243,y:843,t:1527023265646};\\\", \\\"{x:1245,y:848,t:1527023265663};\\\", \\\"{x:1247,y:853,t:1527023265680};\\\", \\\"{x:1248,y:858,t:1527023265696};\\\", \\\"{x:1249,y:861,t:1527023265712};\\\", \\\"{x:1251,y:865,t:1527023265730};\\\", \\\"{x:1252,y:869,t:1527023265746};\\\", \\\"{x:1254,y:872,t:1527023265762};\\\", \\\"{x:1255,y:877,t:1527023265779};\\\", \\\"{x:1257,y:884,t:1527023265796};\\\", \\\"{x:1260,y:892,t:1527023265812};\\\", \\\"{x:1263,y:897,t:1527023265830};\\\", \\\"{x:1264,y:901,t:1527023265847};\\\", \\\"{x:1265,y:903,t:1527023265863};\\\", \\\"{x:1266,y:905,t:1527023265880};\\\", \\\"{x:1266,y:906,t:1527023265896};\\\", \\\"{x:1267,y:908,t:1527023265912};\\\", \\\"{x:1267,y:910,t:1527023265929};\\\", \\\"{x:1267,y:912,t:1527023265947};\\\", \\\"{x:1267,y:913,t:1527023265963};\\\", \\\"{x:1267,y:915,t:1527023265979};\\\", \\\"{x:1267,y:916,t:1527023265996};\\\", \\\"{x:1267,y:917,t:1527023266062};\\\", \\\"{x:1267,y:918,t:1527023266077};\\\", \\\"{x:1267,y:919,t:1527023266093};\\\", \\\"{x:1267,y:920,t:1527023266109};\\\", \\\"{x:1267,y:922,t:1527023266125};\\\", \\\"{x:1267,y:923,t:1527023266149};\\\", \\\"{x:1267,y:924,t:1527023266165};\\\", \\\"{x:1267,y:925,t:1527023266180};\\\", \\\"{x:1267,y:929,t:1527023266198};\\\", \\\"{x:1266,y:930,t:1527023266213};\\\", \\\"{x:1266,y:931,t:1527023266230};\\\", \\\"{x:1266,y:932,t:1527023266247};\\\", \\\"{x:1267,y:932,t:1527023266461};\\\", \\\"{x:1269,y:931,t:1527023266485};\\\", \\\"{x:1270,y:930,t:1527023266517};\\\", \\\"{x:1271,y:930,t:1527023266573};\\\", \\\"{x:1271,y:929,t:1527023266580};\\\", \\\"{x:1271,y:928,t:1527023266604};\\\", \\\"{x:1271,y:927,t:1527023266613};\\\", \\\"{x:1271,y:926,t:1527023266629};\\\", \\\"{x:1271,y:924,t:1527023266646};\\\", \\\"{x:1272,y:922,t:1527023266663};\\\", \\\"{x:1273,y:922,t:1527023266679};\\\", \\\"{x:1273,y:921,t:1527023266708};\\\", \\\"{x:1273,y:920,t:1527023266716};\\\", \\\"{x:1273,y:919,t:1527023266732};\\\", \\\"{x:1273,y:918,t:1527023266747};\\\", \\\"{x:1273,y:917,t:1527023266763};\\\", \\\"{x:1273,y:914,t:1527023266780};\\\", \\\"{x:1273,y:913,t:1527023266796};\\\", \\\"{x:1273,y:912,t:1527023266813};\\\", \\\"{x:1273,y:910,t:1527023266830};\\\", \\\"{x:1273,y:908,t:1527023266846};\\\", \\\"{x:1273,y:904,t:1527023266862};\\\", \\\"{x:1273,y:901,t:1527023266880};\\\", \\\"{x:1272,y:897,t:1527023266896};\\\", \\\"{x:1270,y:894,t:1527023266913};\\\", \\\"{x:1270,y:892,t:1527023266929};\\\", \\\"{x:1270,y:889,t:1527023266946};\\\", \\\"{x:1269,y:886,t:1527023266963};\\\", \\\"{x:1269,y:880,t:1527023266979};\\\", \\\"{x:1269,y:875,t:1527023266996};\\\", \\\"{x:1268,y:872,t:1527023267012};\\\", \\\"{x:1267,y:868,t:1527023267030};\\\", \\\"{x:1266,y:864,t:1527023267046};\\\", \\\"{x:1266,y:862,t:1527023267063};\\\", \\\"{x:1265,y:860,t:1527023267080};\\\", \\\"{x:1265,y:859,t:1527023267096};\\\", \\\"{x:1265,y:857,t:1527023267113};\\\", \\\"{x:1265,y:856,t:1527023267148};\\\", \\\"{x:1265,y:855,t:1527023267213};\\\", \\\"{x:1265,y:854,t:1527023267253};\\\", \\\"{x:1265,y:853,t:1527023267263};\\\", \\\"{x:1265,y:852,t:1527023267414};\\\", \\\"{x:1265,y:851,t:1527023267445};\\\", \\\"{x:1267,y:851,t:1527023267885};\\\", \\\"{x:1267,y:853,t:1527023267898};\\\", \\\"{x:1270,y:857,t:1527023267914};\\\", \\\"{x:1270,y:859,t:1527023267931};\\\", \\\"{x:1270,y:860,t:1527023267948};\\\", \\\"{x:1271,y:860,t:1527023267964};\\\", \\\"{x:1271,y:861,t:1527023268030};\\\", \\\"{x:1271,y:862,t:1527023268037};\\\", \\\"{x:1272,y:863,t:1527023268048};\\\", \\\"{x:1274,y:865,t:1527023268065};\\\", \\\"{x:1275,y:871,t:1527023268081};\\\", \\\"{x:1276,y:873,t:1527023268098};\\\", \\\"{x:1278,y:877,t:1527023268114};\\\", \\\"{x:1280,y:883,t:1527023268130};\\\", \\\"{x:1280,y:886,t:1527023268148};\\\", \\\"{x:1281,y:890,t:1527023268164};\\\", \\\"{x:1282,y:893,t:1527023268180};\\\", \\\"{x:1282,y:895,t:1527023268197};\\\", \\\"{x:1283,y:896,t:1527023268214};\\\", \\\"{x:1284,y:896,t:1527023268284};\\\", \\\"{x:1285,y:896,t:1527023268297};\\\", \\\"{x:1285,y:892,t:1527023268314};\\\", \\\"{x:1288,y:874,t:1527023268331};\\\", \\\"{x:1289,y:855,t:1527023268347};\\\", \\\"{x:1289,y:837,t:1527023268364};\\\", \\\"{x:1290,y:831,t:1527023268380};\\\", \\\"{x:1290,y:825,t:1527023268398};\\\", \\\"{x:1290,y:820,t:1527023268414};\\\", \\\"{x:1290,y:817,t:1527023268430};\\\", \\\"{x:1290,y:814,t:1527023268447};\\\", \\\"{x:1290,y:810,t:1527023268464};\\\", \\\"{x:1290,y:806,t:1527023268480};\\\", \\\"{x:1290,y:802,t:1527023268497};\\\", \\\"{x:1290,y:799,t:1527023268514};\\\", \\\"{x:1290,y:795,t:1527023268530};\\\", \\\"{x:1290,y:793,t:1527023268548};\\\", \\\"{x:1290,y:791,t:1527023268564};\\\", \\\"{x:1290,y:790,t:1527023268581};\\\", \\\"{x:1290,y:789,t:1527023268604};\\\", \\\"{x:1290,y:787,t:1527023268620};\\\", \\\"{x:1290,y:786,t:1527023268631};\\\", \\\"{x:1290,y:783,t:1527023268647};\\\", \\\"{x:1290,y:781,t:1527023268664};\\\", \\\"{x:1290,y:779,t:1527023268681};\\\", \\\"{x:1290,y:776,t:1527023268698};\\\", \\\"{x:1290,y:773,t:1527023268714};\\\", \\\"{x:1290,y:771,t:1527023268732};\\\", \\\"{x:1290,y:770,t:1527023268748};\\\", \\\"{x:1290,y:767,t:1527023268764};\\\", \\\"{x:1290,y:765,t:1527023268781};\\\", \\\"{x:1290,y:760,t:1527023268798};\\\", \\\"{x:1290,y:757,t:1527023268815};\\\", \\\"{x:1290,y:753,t:1527023268832};\\\", \\\"{x:1290,y:750,t:1527023268848};\\\", \\\"{x:1290,y:747,t:1527023268864};\\\", \\\"{x:1290,y:744,t:1527023268882};\\\", \\\"{x:1290,y:741,t:1527023268897};\\\", \\\"{x:1290,y:737,t:1527023268915};\\\", \\\"{x:1290,y:729,t:1527023268932};\\\", \\\"{x:1290,y:720,t:1527023268947};\\\", \\\"{x:1290,y:712,t:1527023268965};\\\", \\\"{x:1290,y:708,t:1527023268981};\\\", \\\"{x:1290,y:702,t:1527023268998};\\\", \\\"{x:1290,y:697,t:1527023269015};\\\", \\\"{x:1290,y:694,t:1527023269032};\\\", \\\"{x:1290,y:688,t:1527023269048};\\\", \\\"{x:1290,y:682,t:1527023269065};\\\", \\\"{x:1290,y:674,t:1527023269082};\\\", \\\"{x:1290,y:665,t:1527023269098};\\\", \\\"{x:1288,y:661,t:1527023269114};\\\", \\\"{x:1286,y:654,t:1527023269131};\\\", \\\"{x:1285,y:651,t:1527023269148};\\\", \\\"{x:1284,y:644,t:1527023269165};\\\", \\\"{x:1283,y:641,t:1527023269182};\\\", \\\"{x:1283,y:637,t:1527023269198};\\\", \\\"{x:1281,y:633,t:1527023269215};\\\", \\\"{x:1281,y:631,t:1527023269231};\\\", \\\"{x:1281,y:628,t:1527023269247};\\\", \\\"{x:1280,y:625,t:1527023269264};\\\", \\\"{x:1279,y:620,t:1527023269281};\\\", \\\"{x:1279,y:618,t:1527023269298};\\\", \\\"{x:1279,y:615,t:1527023269316};\\\", \\\"{x:1277,y:612,t:1527023269332};\\\", \\\"{x:1277,y:608,t:1527023269349};\\\", \\\"{x:1277,y:606,t:1527023269364};\\\", \\\"{x:1277,y:602,t:1527023269382};\\\", \\\"{x:1275,y:597,t:1527023269399};\\\", \\\"{x:1275,y:590,t:1527023269414};\\\", \\\"{x:1272,y:581,t:1527023269431};\\\", \\\"{x:1272,y:577,t:1527023269449};\\\", \\\"{x:1272,y:570,t:1527023269465};\\\", \\\"{x:1272,y:565,t:1527023269481};\\\", \\\"{x:1272,y:560,t:1527023269499};\\\", \\\"{x:1272,y:558,t:1527023269515};\\\", \\\"{x:1271,y:555,t:1527023269532};\\\", \\\"{x:1271,y:548,t:1527023269548};\\\", \\\"{x:1271,y:542,t:1527023269565};\\\", \\\"{x:1271,y:537,t:1527023269581};\\\", \\\"{x:1271,y:527,t:1527023269599};\\\", \\\"{x:1271,y:520,t:1527023269615};\\\", \\\"{x:1271,y:515,t:1527023269632};\\\", \\\"{x:1271,y:512,t:1527023269649};\\\", \\\"{x:1271,y:510,t:1527023269665};\\\", \\\"{x:1271,y:509,t:1527023269682};\\\", \\\"{x:1271,y:506,t:1527023269698};\\\", \\\"{x:1272,y:504,t:1527023269715};\\\", \\\"{x:1272,y:503,t:1527023269732};\\\", \\\"{x:1273,y:500,t:1527023269749};\\\", \\\"{x:1273,y:497,t:1527023269765};\\\", \\\"{x:1273,y:496,t:1527023269789};\\\", \\\"{x:1274,y:494,t:1527023269813};\\\", \\\"{x:1275,y:493,t:1527023269974};\\\", \\\"{x:1274,y:493,t:1527023270053};\\\", \\\"{x:1272,y:493,t:1527023270066};\\\", \\\"{x:1271,y:493,t:1527023270082};\\\", \\\"{x:1270,y:493,t:1527023270100};\\\", \\\"{x:1269,y:494,t:1527023270116};\\\", \\\"{x:1268,y:496,t:1527023270189};\\\", \\\"{x:1267,y:496,t:1527023270220};\\\", \\\"{x:1266,y:496,t:1527023270236};\\\", \\\"{x:1266,y:497,t:1527023270249};\\\", \\\"{x:1265,y:497,t:1527023270265};\\\", \\\"{x:1264,y:499,t:1527023270281};\\\", \\\"{x:1263,y:500,t:1527023270298};\\\", \\\"{x:1262,y:502,t:1527023270315};\\\", \\\"{x:1262,y:503,t:1527023270331};\\\", \\\"{x:1261,y:506,t:1527023270348};\\\", \\\"{x:1260,y:507,t:1527023270388};\\\", \\\"{x:1260,y:508,t:1527023271005};\\\", \\\"{x:1260,y:509,t:1527023271016};\\\", \\\"{x:1260,y:512,t:1527023271033};\\\", \\\"{x:1259,y:515,t:1527023271049};\\\", \\\"{x:1258,y:516,t:1527023271069};\\\", \\\"{x:1258,y:517,t:1527023271085};\\\", \\\"{x:1257,y:518,t:1527023271117};\\\", \\\"{x:1256,y:519,t:1527023271238};\\\", \\\"{x:1255,y:519,t:1527023271253};\\\", \\\"{x:1250,y:519,t:1527023271266};\\\", \\\"{x:1230,y:523,t:1527023271283};\\\", \\\"{x:1211,y:525,t:1527023271300};\\\", \\\"{x:1191,y:525,t:1527023271316};\\\", \\\"{x:1121,y:525,t:1527023271332};\\\", \\\"{x:1027,y:525,t:1527023271350};\\\", \\\"{x:919,y:525,t:1527023271365};\\\", \\\"{x:824,y:525,t:1527023271382};\\\", \\\"{x:752,y:525,t:1527023271399};\\\", \\\"{x:702,y:525,t:1527023271415};\\\", \\\"{x:668,y:525,t:1527023271432};\\\", \\\"{x:655,y:525,t:1527023271450};\\\", \\\"{x:638,y:525,t:1527023271465};\\\", \\\"{x:624,y:525,t:1527023271482};\\\", \\\"{x:616,y:525,t:1527023271499};\\\", \\\"{x:609,y:525,t:1527023271516};\\\", \\\"{x:599,y:526,t:1527023271532};\\\", \\\"{x:596,y:526,t:1527023271549};\\\", \\\"{x:593,y:526,t:1527023271566};\\\", \\\"{x:590,y:526,t:1527023271583};\\\", \\\"{x:589,y:526,t:1527023271604};\\\", \\\"{x:588,y:526,t:1527023271615};\\\", \\\"{x:584,y:526,t:1527023271632};\\\", \\\"{x:583,y:526,t:1527023271649};\\\", \\\"{x:576,y:526,t:1527023271665};\\\", \\\"{x:567,y:525,t:1527023271682};\\\", \\\"{x:558,y:525,t:1527023271700};\\\", \\\"{x:546,y:525,t:1527023271715};\\\", \\\"{x:519,y:525,t:1527023271732};\\\", \\\"{x:494,y:525,t:1527023271750};\\\", \\\"{x:458,y:525,t:1527023271766};\\\", \\\"{x:432,y:525,t:1527023271782};\\\", \\\"{x:413,y:527,t:1527023271800};\\\", \\\"{x:399,y:529,t:1527023271816};\\\", \\\"{x:394,y:530,t:1527023271833};\\\", \\\"{x:391,y:531,t:1527023271849};\\\", \\\"{x:389,y:531,t:1527023271872};\\\", \\\"{x:389,y:532,t:1527023271890};\\\", \\\"{x:388,y:532,t:1527023271905};\\\", \\\"{x:388,y:533,t:1527023271980};\\\", \\\"{x:386,y:533,t:1527023272084};\\\", \\\"{x:385,y:534,t:1527023272125};\\\", \\\"{x:384,y:535,t:1527023272156};\\\", \\\"{x:384,y:536,t:1527023272172};\\\", \\\"{x:383,y:538,t:1527023272196};\\\", \\\"{x:383,y:540,t:1527023272988};\\\", \\\"{x:383,y:541,t:1527023272996};\\\", \\\"{x:383,y:544,t:1527023273007};\\\", \\\"{x:385,y:548,t:1527023273023};\\\", \\\"{x:400,y:557,t:1527023273041};\\\", \\\"{x:418,y:566,t:1527023273057};\\\", \\\"{x:447,y:578,t:1527023273076};\\\", \\\"{x:474,y:590,t:1527023273092};\\\", \\\"{x:493,y:600,t:1527023273109};\\\", \\\"{x:517,y:612,t:1527023273126};\\\", \\\"{x:562,y:633,t:1527023273143};\\\", \\\"{x:610,y:659,t:1527023273160};\\\", \\\"{x:672,y:691,t:1527023273176};\\\", \\\"{x:718,y:718,t:1527023273193};\\\", \\\"{x:767,y:746,t:1527023273210};\\\", \\\"{x:797,y:768,t:1527023273226};\\\", \\\"{x:832,y:796,t:1527023273243};\\\", \\\"{x:891,y:839,t:1527023273260};\\\", \\\"{x:927,y:860,t:1527023273276};\\\", \\\"{x:987,y:882,t:1527023273293};\\\", \\\"{x:1058,y:898,t:1527023273311};\\\", \\\"{x:1141,y:907,t:1527023273327};\\\", \\\"{x:1219,y:907,t:1527023273343};\\\", \\\"{x:1291,y:907,t:1527023273360};\\\", \\\"{x:1347,y:907,t:1527023273377};\\\", \\\"{x:1388,y:907,t:1527023273393};\\\", \\\"{x:1418,y:907,t:1527023273411};\\\", \\\"{x:1435,y:908,t:1527023273427};\\\", \\\"{x:1443,y:908,t:1527023273443};\\\", \\\"{x:1446,y:908,t:1527023273460};\\\", \\\"{x:1447,y:908,t:1527023273524};\\\", \\\"{x:1448,y:908,t:1527023273685};\\\", \\\"{x:1445,y:909,t:1527023273695};\\\", \\\"{x:1428,y:913,t:1527023273711};\\\", \\\"{x:1407,y:917,t:1527023273727};\\\", \\\"{x:1372,y:917,t:1527023273745};\\\", \\\"{x:1336,y:917,t:1527023273761};\\\", \\\"{x:1305,y:917,t:1527023273778};\\\", \\\"{x:1284,y:917,t:1527023273795};\\\", \\\"{x:1276,y:917,t:1527023273811};\\\", \\\"{x:1275,y:917,t:1527023273844};\\\", \\\"{x:1275,y:916,t:1527023273901};\\\", \\\"{x:1275,y:915,t:1527023273912};\\\", \\\"{x:1275,y:912,t:1527023273928};\\\", \\\"{x:1277,y:906,t:1527023273946};\\\", \\\"{x:1282,y:898,t:1527023273962};\\\", \\\"{x:1283,y:895,t:1527023273979};\\\", \\\"{x:1287,y:887,t:1527023273996};\\\", \\\"{x:1289,y:883,t:1527023274011};\\\", \\\"{x:1295,y:872,t:1527023274028};\\\", \\\"{x:1299,y:864,t:1527023274046};\\\", \\\"{x:1304,y:855,t:1527023274062};\\\", \\\"{x:1307,y:847,t:1527023274079};\\\", \\\"{x:1312,y:841,t:1527023274096};\\\", \\\"{x:1316,y:834,t:1527023274112};\\\", \\\"{x:1322,y:827,t:1527023274129};\\\", \\\"{x:1331,y:821,t:1527023274146};\\\", \\\"{x:1334,y:816,t:1527023274163};\\\", \\\"{x:1336,y:813,t:1527023274179};\\\", \\\"{x:1338,y:811,t:1527023274197};\\\", \\\"{x:1340,y:809,t:1527023274213};\\\", \\\"{x:1341,y:808,t:1527023274229};\\\", \\\"{x:1343,y:808,t:1527023274286};\\\", \\\"{x:1344,y:808,t:1527023274301};\\\", \\\"{x:1346,y:808,t:1527023274325};\\\", \\\"{x:1347,y:808,t:1527023274341};\\\", \\\"{x:1349,y:808,t:1527023274365};\\\", \\\"{x:1350,y:808,t:1527023274380};\\\", \\\"{x:1351,y:809,t:1527023274397};\\\", \\\"{x:1352,y:809,t:1527023274420};\\\", \\\"{x:1352,y:810,t:1527023275933};\\\", \\\"{x:1350,y:810,t:1527023276004};\\\", \\\"{x:1347,y:810,t:1527023276017};\\\", \\\"{x:1340,y:808,t:1527023276033};\\\", \\\"{x:1326,y:804,t:1527023276049};\\\", \\\"{x:1314,y:799,t:1527023276067};\\\", \\\"{x:1305,y:795,t:1527023276082};\\\", \\\"{x:1296,y:789,t:1527023276099};\\\", \\\"{x:1284,y:778,t:1527023276116};\\\", \\\"{x:1270,y:766,t:1527023276134};\\\", \\\"{x:1255,y:750,t:1527023276150};\\\", \\\"{x:1239,y:730,t:1527023276166};\\\", \\\"{x:1209,y:690,t:1527023276183};\\\", \\\"{x:1177,y:638,t:1527023276199};\\\", \\\"{x:1139,y:592,t:1527023276216};\\\", \\\"{x:1098,y:540,t:1527023276233};\\\", \\\"{x:1067,y:511,t:1527023276249};\\\", \\\"{x:1011,y:459,t:1527023276267};\\\", \\\"{x:949,y:411,t:1527023276283};\\\", \\\"{x:827,y:333,t:1527023276300};\\\", \\\"{x:738,y:287,t:1527023276317};\\\", \\\"{x:628,y:244,t:1527023276334};\\\", \\\"{x:520,y:213,t:1527023276350};\\\", \\\"{x:397,y:186,t:1527023276367};\\\", \\\"{x:302,y:172,t:1527023276384};\\\", \\\"{x:258,y:168,t:1527023276401};\\\", \\\"{x:207,y:170,t:1527023276418};\\\", \\\"{x:159,y:185,t:1527023276433};\\\", \\\"{x:116,y:206,t:1527023276451};\\\", \\\"{x:93,y:222,t:1527023276467};\\\", \\\"{x:85,y:234,t:1527023276484};\\\", \\\"{x:85,y:258,t:1527023276500};\\\", \\\"{x:99,y:277,t:1527023276518};\\\", \\\"{x:118,y:290,t:1527023276533};\\\", \\\"{x:164,y:312,t:1527023276551};\\\", \\\"{x:237,y:338,t:1527023276568};\\\", \\\"{x:302,y:361,t:1527023276584};\\\", \\\"{x:358,y:376,t:1527023276601};\\\", \\\"{x:417,y:396,t:1527023276617};\\\", \\\"{x:449,y:402,t:1527023276634};\\\", \\\"{x:459,y:403,t:1527023276651};\\\", \\\"{x:460,y:406,t:1527023276749};\\\", \\\"{x:459,y:409,t:1527023276757};\\\", \\\"{x:458,y:414,t:1527023276768};\\\", \\\"{x:453,y:425,t:1527023276786};\\\", \\\"{x:451,y:434,t:1527023276801};\\\", \\\"{x:450,y:441,t:1527023276818};\\\", \\\"{x:449,y:444,t:1527023276835};\\\", \\\"{x:448,y:446,t:1527023276852};\\\", \\\"{x:446,y:449,t:1527023276868};\\\", \\\"{x:443,y:456,t:1527023276886};\\\", \\\"{x:440,y:460,t:1527023276902};\\\", \\\"{x:438,y:462,t:1527023276911};\\\", \\\"{x:435,y:464,t:1527023276929};\\\", \\\"{x:434,y:467,t:1527023276945};\\\", \\\"{x:433,y:468,t:1527023276962};\\\", \\\"{x:432,y:471,t:1527023276978};\\\", \\\"{x:429,y:474,t:1527023276996};\\\", \\\"{x:426,y:477,t:1527023277012};\\\", \\\"{x:418,y:483,t:1527023277028};\\\", \\\"{x:411,y:488,t:1527023277046};\\\", \\\"{x:408,y:490,t:1527023277061};\\\", \\\"{x:404,y:492,t:1527023277080};\\\", \\\"{x:403,y:493,t:1527023277097};\\\", \\\"{x:400,y:493,t:1527023277116};\\\", \\\"{x:398,y:493,t:1527023277129};\\\", \\\"{x:395,y:493,t:1527023277146};\\\", \\\"{x:392,y:493,t:1527023277163};\\\", \\\"{x:391,y:493,t:1527023277180};\\\", \\\"{x:388,y:493,t:1527023277196};\\\", \\\"{x:387,y:492,t:1527023277213};\\\", \\\"{x:385,y:491,t:1527023277229};\\\", \\\"{x:385,y:490,t:1527023277248};\\\", \\\"{x:385,y:489,t:1527023277264};\\\", \\\"{x:384,y:487,t:1527023277280};\\\", \\\"{x:383,y:486,t:1527023277297};\\\", \\\"{x:381,y:482,t:1527023277314};\\\", \\\"{x:378,y:478,t:1527023277330};\\\", \\\"{x:378,y:477,t:1527023277347};\\\", \\\"{x:377,y:477,t:1527023277588};\\\", \\\"{x:375,y:477,t:1527023277597};\\\", \\\"{x:374,y:484,t:1527023277614};\\\", \\\"{x:374,y:491,t:1527023277631};\\\", \\\"{x:374,y:499,t:1527023277646};\\\", \\\"{x:374,y:505,t:1527023277663};\\\", \\\"{x:375,y:507,t:1527023277681};\\\", \\\"{x:375,y:510,t:1527023277696};\\\", \\\"{x:375,y:511,t:1527023277715};\\\", \\\"{x:375,y:515,t:1527023278036};\\\", \\\"{x:379,y:521,t:1527023278048};\\\", \\\"{x:393,y:533,t:1527023278064};\\\", \\\"{x:411,y:546,t:1527023278080};\\\", \\\"{x:438,y:565,t:1527023278098};\\\", \\\"{x:469,y:584,t:1527023278113};\\\", \\\"{x:503,y:600,t:1527023278131};\\\", \\\"{x:525,y:614,t:1527023278148};\\\", \\\"{x:527,y:615,t:1527023278164};\\\", \\\"{x:533,y:619,t:1527023278181};\\\", \\\"{x:533,y:620,t:1527023278197};\\\", \\\"{x:534,y:621,t:1527023278213};\\\", \\\"{x:535,y:622,t:1527023278231};\\\", \\\"{x:536,y:623,t:1527023278248};\\\", \\\"{x:539,y:628,t:1527023278265};\\\", \\\"{x:543,y:635,t:1527023278281};\\\", \\\"{x:547,y:640,t:1527023278297};\\\", \\\"{x:549,y:643,t:1527023278314};\\\", \\\"{x:550,y:644,t:1527023278331};\\\", \\\"{x:551,y:645,t:1527023278356};\\\", \\\"{x:551,y:646,t:1527023278364};\\\", \\\"{x:551,y:647,t:1527023278381};\\\", \\\"{x:551,y:649,t:1527023278401};\\\", \\\"{x:552,y:653,t:1527023278414};\\\", \\\"{x:552,y:654,t:1527023278430};\\\", \\\"{x:552,y:657,t:1527023278448};\\\", \\\"{x:552,y:658,t:1527023278464};\\\", \\\"{x:552,y:660,t:1527023278481};\\\", \\\"{x:552,y:661,t:1527023278498};\\\", \\\"{x:552,y:662,t:1527023278514};\\\", \\\"{x:550,y:667,t:1527023278531};\\\", \\\"{x:549,y:668,t:1527023278556};\\\", \\\"{x:549,y:669,t:1527023279453};\\\", \\\"{x:550,y:669,t:1527023279485};\\\", \\\"{x:551,y:669,t:1527023279500};\\\", \\\"{x:551,y:668,t:1527023279540};\\\", \\\"{x:553,y:668,t:1527023279548};\\\", \\\"{x:553,y:667,t:1527023279565};\\\", \\\"{x:554,y:666,t:1527023279582};\\\", \\\"{x:556,y:665,t:1527023279604};\\\", \\\"{x:557,y:664,t:1527023279693};\\\", \\\"{x:559,y:663,t:1527023279816};\\\" ] }, { \\\"rt\\\": 16776, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 353718, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"JYZGH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:559,y:662,t:1527023280708};\\\", \\\"{x:559,y:661,t:1527023280764};\\\", \\\"{x:559,y:660,t:1527023280780};\\\", \\\"{x:560,y:659,t:1527023280787};\\\", \\\"{x:561,y:658,t:1527023280819};\\\", \\\"{x:562,y:657,t:1527023280836};\\\", \\\"{x:563,y:657,t:1527023280852};\\\", \\\"{x:564,y:656,t:1527023280866};\\\", \\\"{x:565,y:656,t:1527023280883};\\\", \\\"{x:566,y:654,t:1527023280899};\\\", \\\"{x:567,y:654,t:1527023280915};\\\", \\\"{x:568,y:653,t:1527023280940};\\\", \\\"{x:569,y:653,t:1527023280972};\\\", \\\"{x:569,y:652,t:1527023281141};\\\", \\\"{x:570,y:652,t:1527023281149};\\\", \\\"{x:571,y:651,t:1527023281925};\\\", \\\"{x:572,y:651,t:1527023282381};\\\", \\\"{x:572,y:649,t:1527023287789};\\\", \\\"{x:572,y:643,t:1527023287802};\\\", \\\"{x:572,y:626,t:1527023287820};\\\", \\\"{x:568,y:601,t:1527023287836};\\\", \\\"{x:563,y:586,t:1527023287853};\\\", \\\"{x:560,y:574,t:1527023287869};\\\", \\\"{x:558,y:565,t:1527023287885};\\\", \\\"{x:557,y:557,t:1527023287905};\\\", \\\"{x:557,y:549,t:1527023287922};\\\", \\\"{x:557,y:542,t:1527023287939};\\\", \\\"{x:557,y:534,t:1527023287955};\\\", \\\"{x:559,y:522,t:1527023287972};\\\", \\\"{x:565,y:513,t:1527023287989};\\\", \\\"{x:571,y:503,t:1527023288005};\\\", \\\"{x:575,y:492,t:1527023288022};\\\", \\\"{x:581,y:481,t:1527023288039};\\\", \\\"{x:586,y:473,t:1527023288055};\\\", \\\"{x:590,y:466,t:1527023288071};\\\", \\\"{x:592,y:461,t:1527023288088};\\\", \\\"{x:592,y:459,t:1527023288105};\\\", \\\"{x:592,y:456,t:1527023288121};\\\", \\\"{x:592,y:455,t:1527023288139};\\\", \\\"{x:591,y:454,t:1527023288155};\\\", \\\"{x:590,y:453,t:1527023288171};\\\", \\\"{x:589,y:453,t:1527023288188};\\\", \\\"{x:587,y:453,t:1527023288205};\\\", \\\"{x:584,y:453,t:1527023288222};\\\", \\\"{x:577,y:455,t:1527023288239};\\\", \\\"{x:565,y:459,t:1527023288255};\\\", \\\"{x:551,y:462,t:1527023288272};\\\", \\\"{x:536,y:464,t:1527023288289};\\\", \\\"{x:515,y:469,t:1527023288306};\\\", \\\"{x:498,y:474,t:1527023288324};\\\", \\\"{x:488,y:478,t:1527023288339};\\\", \\\"{x:484,y:479,t:1527023288355};\\\", \\\"{x:482,y:481,t:1527023288372};\\\", \\\"{x:481,y:482,t:1527023288389};\\\", \\\"{x:479,y:485,t:1527023288407};\\\", \\\"{x:476,y:488,t:1527023288422};\\\", \\\"{x:474,y:490,t:1527023288439};\\\", \\\"{x:470,y:493,t:1527023288457};\\\", \\\"{x:465,y:496,t:1527023288471};\\\", \\\"{x:459,y:499,t:1527023288488};\\\", \\\"{x:450,y:502,t:1527023288506};\\\", \\\"{x:443,y:505,t:1527023288523};\\\", \\\"{x:438,y:508,t:1527023288538};\\\", \\\"{x:434,y:510,t:1527023288556};\\\", \\\"{x:432,y:512,t:1527023288572};\\\", \\\"{x:430,y:514,t:1527023288588};\\\", \\\"{x:427,y:516,t:1527023288606};\\\", \\\"{x:424,y:519,t:1527023288623};\\\", \\\"{x:420,y:522,t:1527023288640};\\\", \\\"{x:415,y:525,t:1527023288655};\\\", \\\"{x:412,y:527,t:1527023288672};\\\", \\\"{x:407,y:529,t:1527023288689};\\\", \\\"{x:398,y:533,t:1527023288706};\\\", \\\"{x:390,y:534,t:1527023288722};\\\", \\\"{x:375,y:536,t:1527023288739};\\\", \\\"{x:342,y:536,t:1527023288755};\\\", \\\"{x:333,y:538,t:1527023288772};\\\", \\\"{x:326,y:540,t:1527023288788};\\\", \\\"{x:326,y:539,t:1527023288806};\\\", \\\"{x:319,y:539,t:1527023288822};\\\", \\\"{x:319,y:541,t:1527023288839};\\\", \\\"{x:318,y:543,t:1527023288867};\\\", \\\"{x:317,y:543,t:1527023288996};\\\", \\\"{x:318,y:543,t:1527023289131};\\\", \\\"{x:321,y:542,t:1527023289141};\\\", \\\"{x:324,y:536,t:1527023289156};\\\", \\\"{x:335,y:526,t:1527023289174};\\\", \\\"{x:343,y:519,t:1527023289191};\\\", \\\"{x:350,y:511,t:1527023289206};\\\", \\\"{x:359,y:501,t:1527023289222};\\\", \\\"{x:366,y:494,t:1527023289240};\\\", \\\"{x:376,y:486,t:1527023289257};\\\", \\\"{x:388,y:478,t:1527023289273};\\\", \\\"{x:399,y:470,t:1527023289290};\\\", \\\"{x:414,y:461,t:1527023289306};\\\", \\\"{x:429,y:452,t:1527023289323};\\\", \\\"{x:452,y:443,t:1527023289339};\\\", \\\"{x:463,y:440,t:1527023289356};\\\", \\\"{x:468,y:439,t:1527023289372};\\\", \\\"{x:472,y:438,t:1527023289390};\\\", \\\"{x:482,y:438,t:1527023289407};\\\", \\\"{x:498,y:438,t:1527023289423};\\\", \\\"{x:517,y:438,t:1527023289440};\\\", \\\"{x:540,y:438,t:1527023289457};\\\", \\\"{x:567,y:438,t:1527023289473};\\\", \\\"{x:592,y:441,t:1527023289490};\\\", \\\"{x:621,y:445,t:1527023289507};\\\", \\\"{x:642,y:448,t:1527023289524};\\\", \\\"{x:667,y:454,t:1527023289541};\\\", \\\"{x:686,y:459,t:1527023289557};\\\", \\\"{x:708,y:467,t:1527023289572};\\\", \\\"{x:730,y:473,t:1527023289590};\\\", \\\"{x:766,y:479,t:1527023289606};\\\", \\\"{x:809,y:486,t:1527023289623};\\\", \\\"{x:840,y:493,t:1527023289640};\\\", \\\"{x:864,y:500,t:1527023289657};\\\", \\\"{x:875,y:504,t:1527023289673};\\\", \\\"{x:876,y:504,t:1527023289690};\\\", \\\"{x:876,y:505,t:1527023289796};\\\", \\\"{x:873,y:508,t:1527023289807};\\\", \\\"{x:860,y:512,t:1527023289824};\\\", \\\"{x:842,y:515,t:1527023289840};\\\", \\\"{x:818,y:517,t:1527023289856};\\\", \\\"{x:789,y:517,t:1527023289873};\\\", \\\"{x:762,y:517,t:1527023289889};\\\", \\\"{x:735,y:517,t:1527023289907};\\\", \\\"{x:715,y:517,t:1527023289924};\\\", \\\"{x:693,y:517,t:1527023289940};\\\", \\\"{x:684,y:518,t:1527023289956};\\\", \\\"{x:674,y:520,t:1527023289974};\\\", \\\"{x:663,y:522,t:1527023289990};\\\", \\\"{x:652,y:524,t:1527023290006};\\\", \\\"{x:644,y:525,t:1527023290024};\\\", \\\"{x:626,y:528,t:1527023290040};\\\", \\\"{x:609,y:530,t:1527023290057};\\\", \\\"{x:579,y:535,t:1527023290073};\\\", \\\"{x:537,y:540,t:1527023290089};\\\", \\\"{x:495,y:547,t:1527023290108};\\\", \\\"{x:455,y:552,t:1527023290123};\\\", \\\"{x:436,y:555,t:1527023290140};\\\", \\\"{x:416,y:557,t:1527023290156};\\\", \\\"{x:405,y:561,t:1527023290175};\\\", \\\"{x:399,y:564,t:1527023290189};\\\", \\\"{x:391,y:568,t:1527023290207};\\\", \\\"{x:385,y:569,t:1527023290224};\\\", \\\"{x:378,y:572,t:1527023290240};\\\", \\\"{x:369,y:574,t:1527023290257};\\\", \\\"{x:350,y:578,t:1527023290274};\\\", \\\"{x:327,y:580,t:1527023290290};\\\", \\\"{x:298,y:582,t:1527023290306};\\\", \\\"{x:256,y:584,t:1527023290324};\\\", \\\"{x:232,y:587,t:1527023290340};\\\", \\\"{x:216,y:588,t:1527023290357};\\\", \\\"{x:212,y:588,t:1527023290374};\\\", \\\"{x:210,y:588,t:1527023290391};\\\", \\\"{x:209,y:588,t:1527023290427};\\\", \\\"{x:206,y:588,t:1527023290443};\\\", \\\"{x:203,y:588,t:1527023290457};\\\", \\\"{x:197,y:588,t:1527023290474};\\\", \\\"{x:186,y:588,t:1527023290492};\\\", \\\"{x:173,y:588,t:1527023290507};\\\", \\\"{x:166,y:588,t:1527023290524};\\\", \\\"{x:165,y:587,t:1527023290541};\\\", \\\"{x:163,y:586,t:1527023290563};\\\", \\\"{x:162,y:585,t:1527023290580};\\\", \\\"{x:162,y:584,t:1527023290591};\\\", \\\"{x:162,y:583,t:1527023290607};\\\", \\\"{x:162,y:582,t:1527023290624};\\\", \\\"{x:162,y:580,t:1527023292053};\\\", \\\"{x:168,y:580,t:1527023292059};\\\", \\\"{x:179,y:580,t:1527023292075};\\\", \\\"{x:221,y:580,t:1527023292092};\\\", \\\"{x:250,y:576,t:1527023292109};\\\", \\\"{x:283,y:575,t:1527023292125};\\\", \\\"{x:312,y:575,t:1527023292142};\\\", \\\"{x:327,y:575,t:1527023292158};\\\", \\\"{x:330,y:574,t:1527023292174};\\\", \\\"{x:336,y:573,t:1527023292191};\\\", \\\"{x:337,y:572,t:1527023292208};\\\", \\\"{x:339,y:571,t:1527023292224};\\\", \\\"{x:342,y:570,t:1527023292242};\\\", \\\"{x:348,y:568,t:1527023292259};\\\", \\\"{x:356,y:566,t:1527023292276};\\\", \\\"{x:369,y:563,t:1527023292292};\\\", \\\"{x:374,y:560,t:1527023292309};\\\", \\\"{x:376,y:559,t:1527023292325};\\\", \\\"{x:377,y:559,t:1527023292341};\\\", \\\"{x:375,y:559,t:1527023292476};\\\", \\\"{x:373,y:560,t:1527023292494};\\\", \\\"{x:372,y:560,t:1527023292509};\\\", \\\"{x:371,y:560,t:1527023292525};\\\", \\\"{x:371,y:561,t:1527023292542};\\\", \\\"{x:371,y:565,t:1527023292559};\\\", \\\"{x:371,y:567,t:1527023292575};\\\", \\\"{x:373,y:571,t:1527023292591};\\\", \\\"{x:373,y:572,t:1527023292609};\\\", \\\"{x:375,y:573,t:1527023292627};\\\", \\\"{x:377,y:573,t:1527023292642};\\\", \\\"{x:378,y:573,t:1527023292659};\\\", \\\"{x:382,y:573,t:1527023292676};\\\", \\\"{x:386,y:572,t:1527023292693};\\\", \\\"{x:387,y:569,t:1527023292710};\\\", \\\"{x:388,y:565,t:1527023292727};\\\", \\\"{x:388,y:560,t:1527023292742};\\\", \\\"{x:386,y:557,t:1527023292760};\\\", \\\"{x:381,y:553,t:1527023292777};\\\", \\\"{x:370,y:548,t:1527023292792};\\\", \\\"{x:354,y:543,t:1527023292809};\\\", \\\"{x:339,y:538,t:1527023292826};\\\", \\\"{x:323,y:537,t:1527023292842};\\\", \\\"{x:314,y:536,t:1527023292859};\\\", \\\"{x:307,y:535,t:1527023292875};\\\", \\\"{x:304,y:535,t:1527023292957};\\\", \\\"{x:301,y:534,t:1527023292964};\\\", \\\"{x:300,y:534,t:1527023292976};\\\", \\\"{x:287,y:533,t:1527023292993};\\\", \\\"{x:271,y:533,t:1527023293012};\\\", \\\"{x:251,y:530,t:1527023293026};\\\", \\\"{x:229,y:530,t:1527023293043};\\\", \\\"{x:220,y:530,t:1527023293059};\\\", \\\"{x:212,y:530,t:1527023293076};\\\", \\\"{x:210,y:530,t:1527023293093};\\\", \\\"{x:208,y:530,t:1527023293109};\\\", \\\"{x:208,y:531,t:1527023293131};\\\", \\\"{x:207,y:531,t:1527023293143};\\\", \\\"{x:206,y:532,t:1527023293158};\\\", \\\"{x:205,y:533,t:1527023293176};\\\", \\\"{x:204,y:534,t:1527023293196};\\\", \\\"{x:203,y:534,t:1527023293209};\\\", \\\"{x:202,y:534,t:1527023293226};\\\", \\\"{x:202,y:535,t:1527023293308};\\\", \\\"{x:202,y:536,t:1527023293316};\\\", \\\"{x:201,y:537,t:1527023293332};\\\", \\\"{x:200,y:538,t:1527023293348};\\\", \\\"{x:198,y:539,t:1527023293361};\\\", \\\"{x:195,y:539,t:1527023293376};\\\", \\\"{x:194,y:540,t:1527023293393};\\\", \\\"{x:200,y:543,t:1527023294068};\\\", \\\"{x:212,y:547,t:1527023294077};\\\", \\\"{x:250,y:556,t:1527023294094};\\\", \\\"{x:300,y:564,t:1527023294112};\\\", \\\"{x:364,y:572,t:1527023294127};\\\", \\\"{x:420,y:580,t:1527023294143};\\\", \\\"{x:461,y:588,t:1527023294160};\\\", \\\"{x:484,y:592,t:1527023294177};\\\", \\\"{x:500,y:595,t:1527023294195};\\\", \\\"{x:508,y:598,t:1527023294210};\\\", \\\"{x:521,y:604,t:1527023294226};\\\", \\\"{x:538,y:612,t:1527023294243};\\\", \\\"{x:564,y:621,t:1527023294260};\\\", \\\"{x:593,y:632,t:1527023294277};\\\", \\\"{x:622,y:641,t:1527023294293};\\\", \\\"{x:645,y:648,t:1527023294310};\\\", \\\"{x:659,y:653,t:1527023294327};\\\", \\\"{x:680,y:660,t:1527023294343};\\\", \\\"{x:697,y:664,t:1527023294360};\\\", \\\"{x:713,y:668,t:1527023294377};\\\", \\\"{x:730,y:674,t:1527023294393};\\\", \\\"{x:745,y:680,t:1527023294410};\\\", \\\"{x:758,y:685,t:1527023294427};\\\", \\\"{x:771,y:692,t:1527023294443};\\\", \\\"{x:775,y:695,t:1527023294460};\\\", \\\"{x:771,y:698,t:1527023294604};\\\", \\\"{x:765,y:699,t:1527023294612};\\\", \\\"{x:753,y:700,t:1527023294627};\\\", \\\"{x:717,y:700,t:1527023294644};\\\", \\\"{x:611,y:700,t:1527023294660};\\\", \\\"{x:561,y:700,t:1527023294678};\\\", \\\"{x:524,y:700,t:1527023294694};\\\", \\\"{x:502,y:694,t:1527023294711};\\\", \\\"{x:490,y:691,t:1527023294728};\\\", \\\"{x:485,y:690,t:1527023294744};\\\", \\\"{x:484,y:689,t:1527023294760};\\\", \\\"{x:483,y:688,t:1527023294778};\\\", \\\"{x:482,y:687,t:1527023294794};\\\", \\\"{x:480,y:685,t:1527023294810};\\\", \\\"{x:479,y:684,t:1527023294828};\\\", \\\"{x:478,y:683,t:1527023294843};\\\", \\\"{x:478,y:682,t:1527023294899};\\\", \\\"{x:478,y:681,t:1527023294923};\\\", \\\"{x:478,y:680,t:1527023294947};\\\", \\\"{x:479,y:679,t:1527023294958};\\\", \\\"{x:480,y:679,t:1527023294980};\\\", \\\"{x:481,y:679,t:1527023295003};\\\", \\\"{x:482,y:678,t:1527023295019};\\\", \\\"{x:482,y:677,t:1527023295044};\\\", \\\"{x:484,y:675,t:1527023295058};\\\", \\\"{x:484,y:672,t:1527023295075};\\\", \\\"{x:478,y:661,t:1527023295091};\\\", \\\"{x:434,y:633,t:1527023295109};\\\", \\\"{x:369,y:609,t:1527023295125};\\\", \\\"{x:286,y:588,t:1527023295145};\\\", \\\"{x:218,y:576,t:1527023295162};\\\", \\\"{x:165,y:568,t:1527023295178};\\\", \\\"{x:143,y:566,t:1527023295195};\\\", \\\"{x:133,y:565,t:1527023295211};\\\", \\\"{x:131,y:564,t:1527023295228};\\\", \\\"{x:125,y:559,t:1527023295245};\\\", \\\"{x:115,y:553,t:1527023295261};\\\", \\\"{x:107,y:549,t:1527023295278};\\\", \\\"{x:101,y:545,t:1527023295296};\\\", \\\"{x:100,y:544,t:1527023295311};\\\", \\\"{x:103,y:544,t:1527023295396};\\\", \\\"{x:109,y:544,t:1527023295412};\\\", \\\"{x:113,y:544,t:1527023295429};\\\", \\\"{x:121,y:542,t:1527023295446};\\\", \\\"{x:128,y:541,t:1527023295462};\\\", \\\"{x:133,y:540,t:1527023295479};\\\", \\\"{x:134,y:540,t:1527023295496};\\\", \\\"{x:137,y:539,t:1527023295512};\\\", \\\"{x:138,y:538,t:1527023295529};\\\", \\\"{x:139,y:538,t:1527023295548};\\\", \\\"{x:143,y:537,t:1527023295564};\\\", \\\"{x:145,y:537,t:1527023295580};\\\", \\\"{x:147,y:537,t:1527023295596};\\\", \\\"{x:148,y:535,t:1527023295614};\\\", \\\"{x:149,y:535,t:1527023295631};\\\", \\\"{x:150,y:535,t:1527023295646};\\\", \\\"{x:153,y:535,t:1527023295661};\\\", \\\"{x:154,y:535,t:1527023295678};\\\", \\\"{x:155,y:535,t:1527023295695};\\\", \\\"{x:162,y:536,t:1527023296003};\\\", \\\"{x:176,y:542,t:1527023296012};\\\", \\\"{x:249,y:566,t:1527023296028};\\\", \\\"{x:354,y:590,t:1527023296046};\\\", \\\"{x:440,y:616,t:1527023296063};\\\", \\\"{x:504,y:633,t:1527023296078};\\\", \\\"{x:529,y:644,t:1527023296095};\\\", \\\"{x:544,y:651,t:1527023296113};\\\", \\\"{x:553,y:654,t:1527023296128};\\\", \\\"{x:554,y:655,t:1527023296145};\\\", \\\"{x:555,y:656,t:1527023296179};\\\", \\\"{x:553,y:656,t:1527023296236};\\\", \\\"{x:550,y:656,t:1527023296246};\\\", \\\"{x:547,y:656,t:1527023296262};\\\", \\\"{x:541,y:652,t:1527023296278};\\\", \\\"{x:537,y:649,t:1527023296295};\\\", \\\"{x:536,y:649,t:1527023296312};\\\", \\\"{x:535,y:647,t:1527023296332};\\\", \\\"{x:533,y:647,t:1527023296364};\\\", \\\"{x:531,y:646,t:1527023296380};\\\", \\\"{x:530,y:645,t:1527023296484};\\\", \\\"{x:530,y:646,t:1527023296499};\\\", \\\"{x:530,y:649,t:1527023296514};\\\", \\\"{x:530,y:654,t:1527023296528};\\\", \\\"{x:530,y:659,t:1527023296545};\\\", \\\"{x:530,y:662,t:1527023296562};\\\", \\\"{x:530,y:666,t:1527023296579};\\\", \\\"{x:530,y:667,t:1527023296595};\\\", \\\"{x:530,y:668,t:1527023296619};\\\" ] }, { \\\"rt\\\": 20033, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 375039, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"JYZGH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 3.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\", \\\"H\\\", \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -F -O -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:530,y:669,t:1527023298547};\\\", \\\"{x:530,y:668,t:1527023298732};\\\", \\\"{x:530,y:665,t:1527023298746};\\\", \\\"{x:530,y:652,t:1527023298763};\\\", \\\"{x:530,y:643,t:1527023298780};\\\", \\\"{x:530,y:626,t:1527023298796};\\\", \\\"{x:533,y:607,t:1527023298815};\\\", \\\"{x:537,y:585,t:1527023298831};\\\", \\\"{x:540,y:565,t:1527023298847};\\\", \\\"{x:543,y:546,t:1527023298865};\\\", \\\"{x:548,y:523,t:1527023298881};\\\", \\\"{x:553,y:509,t:1527023298898};\\\", \\\"{x:554,y:508,t:1527023298914};\\\", \\\"{x:554,y:492,t:1527023299092};\\\", \\\"{x:560,y:433,t:1527023299101};\\\", \\\"{x:568,y:376,t:1527023299114};\\\", \\\"{x:591,y:269,t:1527023299131};\\\", \\\"{x:605,y:241,t:1527023299146};\\\", \\\"{x:605,y:240,t:1527023299164};\\\", \\\"{x:605,y:243,t:1527023299837};\\\", \\\"{x:608,y:247,t:1527023299847};\\\", \\\"{x:610,y:252,t:1527023299865};\\\", \\\"{x:613,y:262,t:1527023299881};\\\", \\\"{x:619,y:272,t:1527023299898};\\\", \\\"{x:624,y:282,t:1527023299915};\\\", \\\"{x:644,y:305,t:1527023299932};\\\", \\\"{x:660,y:322,t:1527023299948};\\\", \\\"{x:674,y:338,t:1527023299964};\\\", \\\"{x:695,y:356,t:1527023299981};\\\", \\\"{x:714,y:376,t:1527023299998};\\\", \\\"{x:724,y:389,t:1527023300014};\\\", \\\"{x:735,y:404,t:1527023300031};\\\", \\\"{x:749,y:416,t:1527023300048};\\\", \\\"{x:759,y:423,t:1527023300064};\\\", \\\"{x:770,y:433,t:1527023300081};\\\", \\\"{x:775,y:437,t:1527023300098};\\\", \\\"{x:779,y:440,t:1527023300114};\\\", \\\"{x:782,y:444,t:1527023300131};\\\", \\\"{x:784,y:448,t:1527023300148};\\\", \\\"{x:787,y:451,t:1527023300164};\\\", \\\"{x:791,y:455,t:1527023300182};\\\", \\\"{x:794,y:459,t:1527023300198};\\\", \\\"{x:796,y:462,t:1527023300215};\\\", \\\"{x:800,y:466,t:1527023300231};\\\", \\\"{x:804,y:469,t:1527023300248};\\\", \\\"{x:809,y:472,t:1527023300265};\\\", \\\"{x:814,y:474,t:1527023300282};\\\", \\\"{x:819,y:475,t:1527023300299};\\\", \\\"{x:832,y:476,t:1527023300316};\\\", \\\"{x:842,y:476,t:1527023300332};\\\", \\\"{x:852,y:476,t:1527023300348};\\\", \\\"{x:856,y:476,t:1527023300365};\\\", \\\"{x:857,y:476,t:1527023300382};\\\", \\\"{x:858,y:476,t:1527023300398};\\\", \\\"{x:859,y:476,t:1527023300415};\\\", \\\"{x:860,y:476,t:1527023300443};\\\", \\\"{x:861,y:475,t:1527023300451};\\\", \\\"{x:862,y:475,t:1527023300500};\\\", \\\"{x:864,y:475,t:1527023300515};\\\", \\\"{x:866,y:475,t:1527023300533};\\\", \\\"{x:870,y:475,t:1527023300549};\\\", \\\"{x:877,y:475,t:1527023300566};\\\", \\\"{x:882,y:476,t:1527023300582};\\\", \\\"{x:890,y:479,t:1527023300599};\\\", \\\"{x:911,y:485,t:1527023300616};\\\", \\\"{x:938,y:490,t:1527023300632};\\\", \\\"{x:963,y:495,t:1527023300649};\\\", \\\"{x:1002,y:505,t:1527023300666};\\\", \\\"{x:1052,y:519,t:1527023300682};\\\", \\\"{x:1184,y:549,t:1527023300699};\\\", \\\"{x:1304,y:587,t:1527023300716};\\\", \\\"{x:1454,y:620,t:1527023300733};\\\", \\\"{x:1594,y:648,t:1527023300749};\\\", \\\"{x:1736,y:674,t:1527023300765};\\\", \\\"{x:1880,y:695,t:1527023300782};\\\", \\\"{x:1919,y:709,t:1527023300800};\\\", \\\"{x:1919,y:720,t:1527023300815};\\\", \\\"{x:1919,y:728,t:1527023300833};\\\", \\\"{x:1919,y:732,t:1527023300850};\\\", \\\"{x:1919,y:729,t:1527023300908};\\\", \\\"{x:1919,y:724,t:1527023300916};\\\", \\\"{x:1919,y:714,t:1527023300933};\\\", \\\"{x:1905,y:696,t:1527023300949};\\\", \\\"{x:1882,y:681,t:1527023300966};\\\", \\\"{x:1857,y:668,t:1527023300982};\\\", \\\"{x:1828,y:657,t:1527023300999};\\\", \\\"{x:1799,y:652,t:1527023301015};\\\", \\\"{x:1781,y:645,t:1527023301033};\\\", \\\"{x:1769,y:644,t:1527023301050};\\\", \\\"{x:1765,y:642,t:1527023301066};\\\", \\\"{x:1764,y:641,t:1527023301082};\\\", \\\"{x:1746,y:641,t:1527023301099};\\\", \\\"{x:1718,y:643,t:1527023301116};\\\", \\\"{x:1689,y:644,t:1527023301133};\\\", \\\"{x:1652,y:644,t:1527023301150};\\\", \\\"{x:1610,y:644,t:1527023301167};\\\", \\\"{x:1551,y:647,t:1527023301182};\\\", \\\"{x:1496,y:653,t:1527023301200};\\\", \\\"{x:1459,y:653,t:1527023301217};\\\", \\\"{x:1436,y:653,t:1527023301233};\\\", \\\"{x:1418,y:654,t:1527023301250};\\\", \\\"{x:1408,y:658,t:1527023301266};\\\", \\\"{x:1400,y:659,t:1527023301282};\\\", \\\"{x:1388,y:663,t:1527023301299};\\\", \\\"{x:1378,y:664,t:1527023301316};\\\", \\\"{x:1364,y:667,t:1527023301332};\\\", \\\"{x:1354,y:667,t:1527023301349};\\\", \\\"{x:1344,y:669,t:1527023301366};\\\", \\\"{x:1335,y:671,t:1527023301382};\\\", \\\"{x:1322,y:673,t:1527023301399};\\\", \\\"{x:1308,y:676,t:1527023301416};\\\", \\\"{x:1300,y:678,t:1527023301433};\\\", \\\"{x:1294,y:682,t:1527023301449};\\\", \\\"{x:1293,y:684,t:1527023301467};\\\", \\\"{x:1293,y:688,t:1527023301483};\\\", \\\"{x:1293,y:691,t:1527023301499};\\\", \\\"{x:1293,y:694,t:1527023301517};\\\", \\\"{x:1294,y:696,t:1527023301534};\\\", \\\"{x:1297,y:700,t:1527023301550};\\\", \\\"{x:1300,y:702,t:1527023301566};\\\", \\\"{x:1303,y:702,t:1527023301583};\\\", \\\"{x:1317,y:707,t:1527023301601};\\\", \\\"{x:1330,y:710,t:1527023301618};\\\", \\\"{x:1344,y:712,t:1527023301634};\\\", \\\"{x:1352,y:713,t:1527023301649};\\\", \\\"{x:1360,y:713,t:1527023301666};\\\", \\\"{x:1365,y:713,t:1527023301683};\\\", \\\"{x:1368,y:712,t:1527023301700};\\\", \\\"{x:1371,y:710,t:1527023301716};\\\", \\\"{x:1375,y:706,t:1527023301733};\\\", \\\"{x:1379,y:703,t:1527023301750};\\\", \\\"{x:1384,y:695,t:1527023301767};\\\", \\\"{x:1393,y:675,t:1527023301783};\\\", \\\"{x:1405,y:629,t:1527023301800};\\\", \\\"{x:1421,y:581,t:1527023301816};\\\", \\\"{x:1432,y:530,t:1527023301833};\\\", \\\"{x:1435,y:505,t:1527023301849};\\\", \\\"{x:1435,y:492,t:1527023301866};\\\", \\\"{x:1438,y:476,t:1527023301884};\\\", \\\"{x:1438,y:467,t:1527023301900};\\\", \\\"{x:1438,y:459,t:1527023301917};\\\", \\\"{x:1437,y:453,t:1527023301934};\\\", \\\"{x:1437,y:447,t:1527023301950};\\\", \\\"{x:1437,y:438,t:1527023301966};\\\", \\\"{x:1437,y:426,t:1527023301983};\\\", \\\"{x:1436,y:418,t:1527023302000};\\\", \\\"{x:1434,y:413,t:1527023302016};\\\", \\\"{x:1433,y:409,t:1527023302034};\\\", \\\"{x:1433,y:406,t:1527023302051};\\\", \\\"{x:1433,y:404,t:1527023302066};\\\", \\\"{x:1433,y:403,t:1527023302084};\\\", \\\"{x:1432,y:401,t:1527023302115};\\\", \\\"{x:1430,y:400,t:1527023302148};\\\", \\\"{x:1430,y:399,t:1527023302180};\\\", \\\"{x:1429,y:398,t:1527023302229};\\\", \\\"{x:1428,y:398,t:1527023302236};\\\", \\\"{x:1427,y:398,t:1527023302252};\\\", \\\"{x:1426,y:398,t:1527023302276};\\\", \\\"{x:1425,y:398,t:1527023302371};\\\", \\\"{x:1424,y:398,t:1527023302383};\\\", \\\"{x:1423,y:398,t:1527023302411};\\\", \\\"{x:1422,y:398,t:1527023302495};\\\", \\\"{x:1421,y:398,t:1527023302504};\\\", \\\"{x:1420,y:399,t:1527023302521};\\\", \\\"{x:1419,y:401,t:1527023302537};\\\", \\\"{x:1418,y:402,t:1527023302554};\\\", \\\"{x:1414,y:407,t:1527023302571};\\\", \\\"{x:1412,y:410,t:1527023302587};\\\", \\\"{x:1411,y:411,t:1527023302606};\\\", \\\"{x:1410,y:412,t:1527023302620};\\\", \\\"{x:1410,y:414,t:1527023302637};\\\", \\\"{x:1410,y:416,t:1527023302654};\\\", \\\"{x:1409,y:420,t:1527023302671};\\\", \\\"{x:1408,y:423,t:1527023302687};\\\", \\\"{x:1408,y:426,t:1527023302704};\\\", \\\"{x:1407,y:427,t:1527023302721};\\\", \\\"{x:1407,y:429,t:1527023302736};\\\", \\\"{x:1407,y:430,t:1527023302754};\\\", \\\"{x:1407,y:431,t:1527023302775};\\\", \\\"{x:1407,y:432,t:1527023302787};\\\", \\\"{x:1407,y:433,t:1527023302804};\\\", \\\"{x:1407,y:434,t:1527023302823};\\\", \\\"{x:1408,y:436,t:1527023302855};\\\", \\\"{x:1409,y:438,t:1527023302895};\\\", \\\"{x:1410,y:439,t:1527023302911};\\\", \\\"{x:1411,y:440,t:1527023302921};\\\", \\\"{x:1413,y:442,t:1527023302938};\\\", \\\"{x:1415,y:442,t:1527023302959};\\\", \\\"{x:1416,y:443,t:1527023302972};\\\", \\\"{x:1420,y:445,t:1527023302989};\\\", \\\"{x:1422,y:447,t:1527023303005};\\\", \\\"{x:1425,y:449,t:1527023303021};\\\", \\\"{x:1428,y:450,t:1527023303038};\\\", \\\"{x:1430,y:452,t:1527023303054};\\\", \\\"{x:1435,y:455,t:1527023303071};\\\", \\\"{x:1438,y:456,t:1527023303088};\\\", \\\"{x:1444,y:460,t:1527023303104};\\\", \\\"{x:1448,y:463,t:1527023303121};\\\", \\\"{x:1450,y:465,t:1527023303138};\\\", \\\"{x:1452,y:467,t:1527023303154};\\\", \\\"{x:1453,y:469,t:1527023303172};\\\", \\\"{x:1453,y:470,t:1527023303189};\\\", \\\"{x:1455,y:472,t:1527023303204};\\\", \\\"{x:1456,y:475,t:1527023303221};\\\", \\\"{x:1458,y:476,t:1527023303238};\\\", \\\"{x:1459,y:478,t:1527023303255};\\\", \\\"{x:1460,y:479,t:1527023303271};\\\", \\\"{x:1460,y:480,t:1527023303288};\\\", \\\"{x:1461,y:481,t:1527023303304};\\\", \\\"{x:1462,y:482,t:1527023303321};\\\", \\\"{x:1463,y:484,t:1527023303339};\\\", \\\"{x:1464,y:484,t:1527023303356};\\\", \\\"{x:1465,y:486,t:1527023303372};\\\", \\\"{x:1466,y:486,t:1527023303388};\\\", \\\"{x:1466,y:487,t:1527023303405};\\\", \\\"{x:1466,y:489,t:1527023303421};\\\", \\\"{x:1468,y:490,t:1527023303438};\\\", \\\"{x:1470,y:494,t:1527023303455};\\\", \\\"{x:1472,y:496,t:1527023303471};\\\", \\\"{x:1472,y:497,t:1527023303487};\\\", \\\"{x:1472,y:498,t:1527023303505};\\\", \\\"{x:1472,y:500,t:1527023303521};\\\", \\\"{x:1473,y:501,t:1527023303537};\\\", \\\"{x:1473,y:502,t:1527023303555};\\\", \\\"{x:1473,y:505,t:1527023303571};\\\", \\\"{x:1475,y:509,t:1527023303587};\\\", \\\"{x:1477,y:515,t:1527023303605};\\\", \\\"{x:1477,y:517,t:1527023303621};\\\", \\\"{x:1477,y:520,t:1527023303638};\\\", \\\"{x:1478,y:521,t:1527023303663};\\\", \\\"{x:1479,y:521,t:1527023303679};\\\", \\\"{x:1479,y:523,t:1527023303703};\\\", \\\"{x:1479,y:524,t:1527023303727};\\\", \\\"{x:1479,y:526,t:1527023303744};\\\", \\\"{x:1479,y:527,t:1527023303755};\\\", \\\"{x:1479,y:529,t:1527023303773};\\\", \\\"{x:1479,y:534,t:1527023303788};\\\", \\\"{x:1479,y:537,t:1527023303805};\\\", \\\"{x:1479,y:540,t:1527023303822};\\\", \\\"{x:1479,y:543,t:1527023303838};\\\", \\\"{x:1477,y:558,t:1527023303855};\\\", \\\"{x:1475,y:566,t:1527023303872};\\\", \\\"{x:1474,y:575,t:1527023303888};\\\", \\\"{x:1472,y:588,t:1527023303905};\\\", \\\"{x:1466,y:600,t:1527023303922};\\\", \\\"{x:1460,y:613,t:1527023303938};\\\", \\\"{x:1451,y:633,t:1527023303955};\\\", \\\"{x:1440,y:664,t:1527023303972};\\\", \\\"{x:1424,y:689,t:1527023303988};\\\", \\\"{x:1411,y:712,t:1527023304005};\\\", \\\"{x:1402,y:723,t:1527023304023};\\\", \\\"{x:1394,y:732,t:1527023304038};\\\", \\\"{x:1384,y:742,t:1527023304055};\\\", \\\"{x:1378,y:748,t:1527023304072};\\\", \\\"{x:1376,y:749,t:1527023304088};\\\", \\\"{x:1373,y:752,t:1527023304105};\\\", \\\"{x:1367,y:755,t:1527023304122};\\\", \\\"{x:1361,y:758,t:1527023304139};\\\", \\\"{x:1357,y:760,t:1527023304155};\\\", \\\"{x:1353,y:762,t:1527023304172};\\\", \\\"{x:1349,y:764,t:1527023304189};\\\", \\\"{x:1347,y:765,t:1527023304205};\\\", \\\"{x:1343,y:766,t:1527023304222};\\\", \\\"{x:1341,y:767,t:1527023304239};\\\", \\\"{x:1338,y:767,t:1527023304255};\\\", \\\"{x:1333,y:768,t:1527023304273};\\\", \\\"{x:1327,y:769,t:1527023304290};\\\", \\\"{x:1322,y:770,t:1527023304305};\\\", \\\"{x:1320,y:770,t:1527023304322};\\\", \\\"{x:1319,y:770,t:1527023304339};\\\", \\\"{x:1318,y:771,t:1527023304359};\\\", \\\"{x:1317,y:772,t:1527023304375};\\\", \\\"{x:1316,y:772,t:1527023304390};\\\", \\\"{x:1308,y:775,t:1527023304405};\\\", \\\"{x:1301,y:775,t:1527023304423};\\\", \\\"{x:1291,y:775,t:1527023304439};\\\", \\\"{x:1286,y:778,t:1527023304455};\\\", \\\"{x:1281,y:778,t:1527023304472};\\\", \\\"{x:1279,y:778,t:1527023304488};\\\", \\\"{x:1277,y:778,t:1527023304504};\\\", \\\"{x:1275,y:778,t:1527023304522};\\\", \\\"{x:1274,y:778,t:1527023304538};\\\", \\\"{x:1272,y:778,t:1527023304556};\\\", \\\"{x:1271,y:778,t:1527023304571};\\\", \\\"{x:1270,y:779,t:1527023304598};\\\", \\\"{x:1268,y:778,t:1527023304654};\\\", \\\"{x:1266,y:776,t:1527023304663};\\\", \\\"{x:1266,y:775,t:1527023304672};\\\", \\\"{x:1263,y:766,t:1527023304689};\\\", \\\"{x:1258,y:754,t:1527023304706};\\\", \\\"{x:1256,y:742,t:1527023304722};\\\", \\\"{x:1251,y:736,t:1527023304739};\\\", \\\"{x:1249,y:731,t:1527023304756};\\\", \\\"{x:1249,y:726,t:1527023304772};\\\", \\\"{x:1249,y:720,t:1527023304789};\\\", \\\"{x:1249,y:709,t:1527023304806};\\\", \\\"{x:1249,y:700,t:1527023304822};\\\", \\\"{x:1250,y:692,t:1527023304839};\\\", \\\"{x:1254,y:681,t:1527023304857};\\\", \\\"{x:1256,y:673,t:1527023304872};\\\", \\\"{x:1257,y:664,t:1527023304889};\\\", \\\"{x:1258,y:655,t:1527023304906};\\\", \\\"{x:1258,y:646,t:1527023304922};\\\", \\\"{x:1258,y:636,t:1527023304939};\\\", \\\"{x:1258,y:627,t:1527023304956};\\\", \\\"{x:1258,y:617,t:1527023304972};\\\", \\\"{x:1258,y:611,t:1527023304989};\\\", \\\"{x:1256,y:606,t:1527023305006};\\\", \\\"{x:1254,y:601,t:1527023305022};\\\", \\\"{x:1251,y:594,t:1527023305039};\\\", \\\"{x:1250,y:588,t:1527023305056};\\\", \\\"{x:1249,y:584,t:1527023305073};\\\", \\\"{x:1246,y:580,t:1527023305090};\\\", \\\"{x:1245,y:579,t:1527023305108};\\\", \\\"{x:1245,y:578,t:1527023305159};\\\", \\\"{x:1244,y:578,t:1527023305173};\\\", \\\"{x:1241,y:578,t:1527023305189};\\\", \\\"{x:1238,y:586,t:1527023305205};\\\", \\\"{x:1236,y:608,t:1527023305223};\\\", \\\"{x:1237,y:625,t:1527023305239};\\\", \\\"{x:1241,y:640,t:1527023305256};\\\", \\\"{x:1246,y:649,t:1527023305273};\\\", \\\"{x:1250,y:657,t:1527023305289};\\\", \\\"{x:1256,y:667,t:1527023305306};\\\", \\\"{x:1258,y:671,t:1527023305323};\\\", \\\"{x:1261,y:675,t:1527023305339};\\\", \\\"{x:1264,y:679,t:1527023305358};\\\", \\\"{x:1267,y:683,t:1527023305373};\\\", \\\"{x:1269,y:686,t:1527023305389};\\\", \\\"{x:1272,y:690,t:1527023305406};\\\", \\\"{x:1283,y:703,t:1527023305422};\\\", \\\"{x:1288,y:709,t:1527023305439};\\\", \\\"{x:1291,y:716,t:1527023305456};\\\", \\\"{x:1297,y:718,t:1527023305472};\\\", \\\"{x:1301,y:723,t:1527023305490};\\\", \\\"{x:1303,y:726,t:1527023305506};\\\", \\\"{x:1307,y:729,t:1527023305523};\\\", \\\"{x:1309,y:731,t:1527023305540};\\\", \\\"{x:1320,y:742,t:1527023305556};\\\", \\\"{x:1330,y:751,t:1527023305573};\\\", \\\"{x:1343,y:761,t:1527023305590};\\\", \\\"{x:1359,y:771,t:1527023305606};\\\", \\\"{x:1372,y:780,t:1527023305622};\\\", \\\"{x:1378,y:786,t:1527023305640};\\\", \\\"{x:1381,y:790,t:1527023305655};\\\", \\\"{x:1384,y:793,t:1527023305673};\\\", \\\"{x:1386,y:795,t:1527023305690};\\\", \\\"{x:1388,y:799,t:1527023305706};\\\", \\\"{x:1389,y:800,t:1527023305723};\\\", \\\"{x:1391,y:804,t:1527023305740};\\\", \\\"{x:1392,y:812,t:1527023305756};\\\", \\\"{x:1394,y:816,t:1527023305773};\\\", \\\"{x:1395,y:820,t:1527023305790};\\\", \\\"{x:1396,y:820,t:1527023305806};\\\", \\\"{x:1396,y:823,t:1527023305823};\\\", \\\"{x:1396,y:824,t:1527023305847};\\\", \\\"{x:1397,y:826,t:1527023305862};\\\", \\\"{x:1397,y:828,t:1527023305887};\\\", \\\"{x:1397,y:830,t:1527023305903};\\\", \\\"{x:1398,y:831,t:1527023305910};\\\", \\\"{x:1398,y:832,t:1527023305923};\\\", \\\"{x:1398,y:834,t:1527023305940};\\\", \\\"{x:1399,y:836,t:1527023305957};\\\", \\\"{x:1400,y:838,t:1527023305973};\\\", \\\"{x:1400,y:839,t:1527023305990};\\\", \\\"{x:1400,y:840,t:1527023306007};\\\", \\\"{x:1400,y:842,t:1527023306023};\\\", \\\"{x:1398,y:844,t:1527023306040};\\\", \\\"{x:1391,y:849,t:1527023306059};\\\", \\\"{x:1379,y:854,t:1527023306073};\\\", \\\"{x:1371,y:859,t:1527023306091};\\\", \\\"{x:1365,y:863,t:1527023306107};\\\", \\\"{x:1364,y:864,t:1527023306123};\\\", \\\"{x:1363,y:864,t:1527023306141};\\\", \\\"{x:1362,y:866,t:1527023306159};\\\", \\\"{x:1361,y:866,t:1527023306183};\\\", \\\"{x:1360,y:867,t:1527023306215};\\\", \\\"{x:1355,y:868,t:1527023306231};\\\", \\\"{x:1352,y:868,t:1527023306247};\\\", \\\"{x:1348,y:868,t:1527023306258};\\\", \\\"{x:1339,y:870,t:1527023306273};\\\", \\\"{x:1331,y:870,t:1527023306291};\\\", \\\"{x:1322,y:870,t:1527023306307};\\\", \\\"{x:1316,y:870,t:1527023306324};\\\", \\\"{x:1313,y:870,t:1527023306340};\\\", \\\"{x:1311,y:870,t:1527023306356};\\\", \\\"{x:1304,y:870,t:1527023306374};\\\", \\\"{x:1300,y:869,t:1527023306390};\\\", \\\"{x:1282,y:866,t:1527023306406};\\\", \\\"{x:1272,y:865,t:1527023306424};\\\", \\\"{x:1261,y:864,t:1527023306440};\\\", \\\"{x:1251,y:862,t:1527023306458};\\\", \\\"{x:1242,y:861,t:1527023306473};\\\", \\\"{x:1237,y:860,t:1527023306490};\\\", \\\"{x:1235,y:859,t:1527023306507};\\\", \\\"{x:1233,y:858,t:1527023306523};\\\", \\\"{x:1232,y:857,t:1527023306540};\\\", \\\"{x:1229,y:853,t:1527023306557};\\\", \\\"{x:1226,y:849,t:1527023306573};\\\", \\\"{x:1225,y:846,t:1527023306590};\\\", \\\"{x:1225,y:844,t:1527023306606};\\\", \\\"{x:1225,y:843,t:1527023306624};\\\", \\\"{x:1223,y:840,t:1527023306641};\\\", \\\"{x:1223,y:833,t:1527023306657};\\\", \\\"{x:1223,y:828,t:1527023306674};\\\", \\\"{x:1223,y:823,t:1527023306690};\\\", \\\"{x:1224,y:818,t:1527023306707};\\\", \\\"{x:1227,y:813,t:1527023306724};\\\", \\\"{x:1228,y:809,t:1527023306741};\\\", \\\"{x:1230,y:805,t:1527023306757};\\\", \\\"{x:1230,y:803,t:1527023306774};\\\", \\\"{x:1230,y:801,t:1527023306790};\\\", \\\"{x:1231,y:797,t:1527023306807};\\\", \\\"{x:1231,y:794,t:1527023306824};\\\", \\\"{x:1231,y:793,t:1527023306841};\\\", \\\"{x:1231,y:791,t:1527023306857};\\\", \\\"{x:1231,y:789,t:1527023306874};\\\", \\\"{x:1231,y:786,t:1527023306891};\\\", \\\"{x:1231,y:790,t:1527023307088};\\\", \\\"{x:1231,y:791,t:1527023307095};\\\", \\\"{x:1231,y:792,t:1527023307108};\\\", \\\"{x:1231,y:796,t:1527023307124};\\\", \\\"{x:1231,y:799,t:1527023307142};\\\", \\\"{x:1231,y:801,t:1527023307158};\\\", \\\"{x:1231,y:804,t:1527023307175};\\\", \\\"{x:1229,y:809,t:1527023307191};\\\", \\\"{x:1229,y:811,t:1527023307208};\\\", \\\"{x:1229,y:814,t:1527023307224};\\\", \\\"{x:1229,y:818,t:1527023307240};\\\", \\\"{x:1229,y:820,t:1527023307258};\\\", \\\"{x:1227,y:823,t:1527023307274};\\\", \\\"{x:1227,y:825,t:1527023307291};\\\", \\\"{x:1227,y:827,t:1527023307308};\\\", \\\"{x:1227,y:830,t:1527023307324};\\\", \\\"{x:1226,y:832,t:1527023307341};\\\", \\\"{x:1226,y:833,t:1527023307358};\\\", \\\"{x:1226,y:836,t:1527023307374};\\\", \\\"{x:1225,y:837,t:1527023307391};\\\", \\\"{x:1224,y:840,t:1527023307408};\\\", \\\"{x:1223,y:842,t:1527023307430};\\\", \\\"{x:1223,y:843,t:1527023307455};\\\", \\\"{x:1223,y:845,t:1527023307471};\\\", \\\"{x:1223,y:846,t:1527023307479};\\\", \\\"{x:1222,y:847,t:1527023307492};\\\", \\\"{x:1222,y:848,t:1527023307508};\\\", \\\"{x:1222,y:849,t:1527023307544};\\\", \\\"{x:1222,y:850,t:1527023307558};\\\", \\\"{x:1222,y:851,t:1527023307574};\\\", \\\"{x:1222,y:852,t:1527023307591};\\\", \\\"{x:1221,y:851,t:1527023307760};\\\", \\\"{x:1221,y:841,t:1527023307776};\\\", \\\"{x:1221,y:834,t:1527023307791};\\\", \\\"{x:1221,y:828,t:1527023307808};\\\", \\\"{x:1221,y:823,t:1527023307825};\\\", \\\"{x:1221,y:817,t:1527023307841};\\\", \\\"{x:1222,y:811,t:1527023307859};\\\", \\\"{x:1225,y:804,t:1527023307875};\\\", \\\"{x:1225,y:800,t:1527023307891};\\\", \\\"{x:1226,y:796,t:1527023307909};\\\", \\\"{x:1226,y:789,t:1527023307925};\\\", \\\"{x:1226,y:783,t:1527023307941};\\\", \\\"{x:1226,y:778,t:1527023307958};\\\", \\\"{x:1226,y:772,t:1527023307975};\\\", \\\"{x:1226,y:767,t:1527023307992};\\\", \\\"{x:1226,y:763,t:1527023308009};\\\", \\\"{x:1226,y:758,t:1527023308025};\\\", \\\"{x:1226,y:755,t:1527023308042};\\\", \\\"{x:1226,y:751,t:1527023308059};\\\", \\\"{x:1226,y:749,t:1527023308076};\\\", \\\"{x:1226,y:747,t:1527023308091};\\\", \\\"{x:1226,y:746,t:1527023308108};\\\", \\\"{x:1226,y:745,t:1527023308128};\\\", \\\"{x:1226,y:743,t:1527023308152};\\\", \\\"{x:1226,y:742,t:1527023308159};\\\", \\\"{x:1225,y:741,t:1527023308176};\\\", \\\"{x:1225,y:740,t:1527023308192};\\\", \\\"{x:1225,y:738,t:1527023308209};\\\", \\\"{x:1225,y:737,t:1527023308226};\\\", \\\"{x:1225,y:736,t:1527023308242};\\\", \\\"{x:1224,y:735,t:1527023308279};\\\", \\\"{x:1224,y:734,t:1527023308344};\\\", \\\"{x:1224,y:733,t:1527023308391};\\\", \\\"{x:1224,y:734,t:1527023308520};\\\", \\\"{x:1222,y:734,t:1527023308527};\\\", \\\"{x:1221,y:737,t:1527023308542};\\\", \\\"{x:1218,y:746,t:1527023308559};\\\", \\\"{x:1218,y:752,t:1527023308575};\\\", \\\"{x:1218,y:757,t:1527023308592};\\\", \\\"{x:1218,y:760,t:1527023308609};\\\", \\\"{x:1218,y:761,t:1527023308626};\\\", \\\"{x:1218,y:763,t:1527023308642};\\\", \\\"{x:1218,y:764,t:1527023308661};\\\", \\\"{x:1218,y:765,t:1527023308711};\\\", \\\"{x:1218,y:766,t:1527023308742};\\\", \\\"{x:1219,y:767,t:1527023308766};\\\", \\\"{x:1219,y:769,t:1527023308831};\\\", \\\"{x:1219,y:770,t:1527023308895};\\\", \\\"{x:1219,y:772,t:1527023308920};\\\", \\\"{x:1219,y:773,t:1527023308944};\\\", \\\"{x:1219,y:775,t:1527023308959};\\\", \\\"{x:1219,y:776,t:1527023308976};\\\", \\\"{x:1219,y:778,t:1527023308992};\\\", \\\"{x:1219,y:780,t:1527023309009};\\\", \\\"{x:1219,y:782,t:1527023309028};\\\", \\\"{x:1219,y:785,t:1527023309042};\\\", \\\"{x:1219,y:789,t:1527023309059};\\\", \\\"{x:1219,y:791,t:1527023309076};\\\", \\\"{x:1219,y:795,t:1527023309093};\\\", \\\"{x:1219,y:798,t:1527023309110};\\\", \\\"{x:1219,y:803,t:1527023309127};\\\", \\\"{x:1220,y:807,t:1527023309142};\\\", \\\"{x:1221,y:814,t:1527023309159};\\\", \\\"{x:1221,y:816,t:1527023309176};\\\", \\\"{x:1222,y:820,t:1527023309193};\\\", \\\"{x:1222,y:825,t:1527023309210};\\\", \\\"{x:1223,y:832,t:1527023309226};\\\", \\\"{x:1223,y:836,t:1527023309243};\\\", \\\"{x:1223,y:843,t:1527023309260};\\\", \\\"{x:1223,y:848,t:1527023309276};\\\", \\\"{x:1223,y:852,t:1527023309292};\\\", \\\"{x:1223,y:854,t:1527023309309};\\\", \\\"{x:1223,y:856,t:1527023309326};\\\", \\\"{x:1223,y:857,t:1527023309342};\\\", \\\"{x:1223,y:858,t:1527023309479};\\\", \\\"{x:1229,y:855,t:1527023309493};\\\", \\\"{x:1246,y:846,t:1527023309510};\\\", \\\"{x:1262,y:838,t:1527023309526};\\\", \\\"{x:1278,y:828,t:1527023309544};\\\", \\\"{x:1281,y:825,t:1527023309559};\\\", \\\"{x:1284,y:823,t:1527023309577};\\\", \\\"{x:1288,y:820,t:1527023309593};\\\", \\\"{x:1294,y:816,t:1527023309609};\\\", \\\"{x:1300,y:813,t:1527023309626};\\\", \\\"{x:1306,y:809,t:1527023309644};\\\", \\\"{x:1312,y:805,t:1527023309659};\\\", \\\"{x:1317,y:803,t:1527023309677};\\\", \\\"{x:1321,y:801,t:1527023309693};\\\", \\\"{x:1327,y:799,t:1527023309709};\\\", \\\"{x:1340,y:798,t:1527023309726};\\\", \\\"{x:1363,y:794,t:1527023309743};\\\", \\\"{x:1382,y:792,t:1527023309759};\\\", \\\"{x:1402,y:788,t:1527023309776};\\\", \\\"{x:1430,y:786,t:1527023309793};\\\", \\\"{x:1469,y:785,t:1527023309811};\\\", \\\"{x:1499,y:785,t:1527023309826};\\\", \\\"{x:1529,y:785,t:1527023309844};\\\", \\\"{x:1557,y:785,t:1527023309861};\\\", \\\"{x:1594,y:785,t:1527023309876};\\\", \\\"{x:1620,y:785,t:1527023309893};\\\", \\\"{x:1630,y:785,t:1527023309910};\\\", \\\"{x:1635,y:785,t:1527023309926};\\\", \\\"{x:1645,y:785,t:1527023309942};\\\", \\\"{x:1650,y:785,t:1527023309960};\\\", \\\"{x:1653,y:785,t:1527023309976};\\\", \\\"{x:1656,y:785,t:1527023309992};\\\", \\\"{x:1658,y:785,t:1527023310015};\\\", \\\"{x:1659,y:785,t:1527023310026};\\\", \\\"{x:1660,y:785,t:1527023310143};\\\", \\\"{x:1660,y:788,t:1527023310160};\\\", \\\"{x:1660,y:790,t:1527023310177};\\\", \\\"{x:1660,y:793,t:1527023310193};\\\", \\\"{x:1659,y:795,t:1527023310211};\\\", \\\"{x:1657,y:799,t:1527023310227};\\\", \\\"{x:1655,y:800,t:1527023310243};\\\", \\\"{x:1652,y:802,t:1527023310260};\\\", \\\"{x:1640,y:808,t:1527023310277};\\\", \\\"{x:1626,y:816,t:1527023310294};\\\", \\\"{x:1616,y:822,t:1527023310311};\\\", \\\"{x:1605,y:828,t:1527023310327};\\\", \\\"{x:1599,y:831,t:1527023310343};\\\", \\\"{x:1587,y:835,t:1527023310360};\\\", \\\"{x:1571,y:842,t:1527023310377};\\\", \\\"{x:1544,y:850,t:1527023310393};\\\", \\\"{x:1516,y:856,t:1527023310410};\\\", \\\"{x:1477,y:861,t:1527023310427};\\\", \\\"{x:1434,y:864,t:1527023310442};\\\", \\\"{x:1376,y:868,t:1527023310460};\\\", \\\"{x:1326,y:868,t:1527023310477};\\\", \\\"{x:1294,y:868,t:1527023310493};\\\", \\\"{x:1261,y:865,t:1527023310510};\\\", \\\"{x:1221,y:859,t:1527023310526};\\\", \\\"{x:1207,y:851,t:1527023310543};\\\", \\\"{x:1202,y:848,t:1527023310560};\\\", \\\"{x:1198,y:836,t:1527023310577};\\\", \\\"{x:1196,y:820,t:1527023310593};\\\", \\\"{x:1195,y:800,t:1527023310610};\\\", \\\"{x:1195,y:779,t:1527023310627};\\\", \\\"{x:1198,y:756,t:1527023310644};\\\", \\\"{x:1204,y:734,t:1527023310660};\\\", \\\"{x:1212,y:716,t:1527023310677};\\\", \\\"{x:1217,y:707,t:1527023310693};\\\", \\\"{x:1220,y:703,t:1527023310710};\\\", \\\"{x:1225,y:701,t:1527023310727};\\\", \\\"{x:1229,y:699,t:1527023310744};\\\", \\\"{x:1238,y:698,t:1527023310760};\\\", \\\"{x:1243,y:697,t:1527023310777};\\\", \\\"{x:1247,y:697,t:1527023310794};\\\", \\\"{x:1247,y:698,t:1527023310810};\\\", \\\"{x:1248,y:699,t:1527023310827};\\\", \\\"{x:1248,y:700,t:1527023310844};\\\", \\\"{x:1248,y:702,t:1527023310860};\\\", \\\"{x:1249,y:704,t:1527023310877};\\\", \\\"{x:1249,y:706,t:1527023310895};\\\", \\\"{x:1249,y:711,t:1527023310910};\\\", \\\"{x:1249,y:717,t:1527023310927};\\\", \\\"{x:1249,y:720,t:1527023310944};\\\", \\\"{x:1249,y:721,t:1527023310960};\\\", \\\"{x:1249,y:722,t:1527023311006};\\\", \\\"{x:1249,y:723,t:1527023311014};\\\", \\\"{x:1249,y:724,t:1527023311030};\\\", \\\"{x:1249,y:725,t:1527023311047};\\\", \\\"{x:1248,y:727,t:1527023311060};\\\", \\\"{x:1248,y:729,t:1527023311079};\\\", \\\"{x:1247,y:730,t:1527023311094};\\\", \\\"{x:1246,y:731,t:1527023311110};\\\", \\\"{x:1245,y:733,t:1527023311159};\\\", \\\"{x:1245,y:734,t:1527023311175};\\\", \\\"{x:1245,y:735,t:1527023311183};\\\", \\\"{x:1245,y:736,t:1527023311200};\\\", \\\"{x:1244,y:737,t:1527023311211};\\\", \\\"{x:1244,y:739,t:1527023311228};\\\", \\\"{x:1243,y:742,t:1527023311244};\\\", \\\"{x:1241,y:745,t:1527023311261};\\\", \\\"{x:1239,y:749,t:1527023311277};\\\", \\\"{x:1236,y:755,t:1527023311295};\\\", \\\"{x:1233,y:759,t:1527023311311};\\\", \\\"{x:1233,y:760,t:1527023311328};\\\", \\\"{x:1232,y:761,t:1527023311345};\\\", \\\"{x:1232,y:763,t:1527023311367};\\\", \\\"{x:1231,y:764,t:1527023311377};\\\", \\\"{x:1230,y:768,t:1527023311395};\\\", \\\"{x:1228,y:771,t:1527023311412};\\\", \\\"{x:1226,y:775,t:1527023311428};\\\", \\\"{x:1225,y:775,t:1527023311445};\\\", \\\"{x:1225,y:776,t:1527023311462};\\\", \\\"{x:1224,y:778,t:1527023311478};\\\", \\\"{x:1223,y:779,t:1527023311511};\\\", \\\"{x:1222,y:781,t:1527023311544};\\\", \\\"{x:1221,y:783,t:1527023311567};\\\", \\\"{x:1220,y:785,t:1527023311591};\\\", \\\"{x:1218,y:787,t:1527023311607};\\\", \\\"{x:1217,y:789,t:1527023311623};\\\", \\\"{x:1216,y:790,t:1527023311632};\\\", \\\"{x:1214,y:792,t:1527023311645};\\\", \\\"{x:1214,y:793,t:1527023311662};\\\", \\\"{x:1213,y:795,t:1527023311679};\\\", \\\"{x:1211,y:798,t:1527023311695};\\\", \\\"{x:1210,y:802,t:1527023311711};\\\", \\\"{x:1208,y:805,t:1527023311729};\\\", \\\"{x:1205,y:811,t:1527023311745};\\\", \\\"{x:1205,y:813,t:1527023311761};\\\", \\\"{x:1204,y:816,t:1527023311779};\\\", \\\"{x:1203,y:816,t:1527023311799};\\\", \\\"{x:1203,y:818,t:1527023311815};\\\", \\\"{x:1203,y:816,t:1527023312007};\\\", \\\"{x:1203,y:815,t:1527023312015};\\\", \\\"{x:1203,y:813,t:1527023312039};\\\", \\\"{x:1204,y:811,t:1527023312047};\\\", \\\"{x:1205,y:811,t:1527023312063};\\\", \\\"{x:1205,y:810,t:1527023312079};\\\", \\\"{x:1206,y:809,t:1527023312095};\\\", \\\"{x:1207,y:809,t:1527023312223};\\\", \\\"{x:1208,y:809,t:1527023312240};\\\", \\\"{x:1209,y:809,t:1527023312247};\\\", \\\"{x:1209,y:810,t:1527023312262};\\\", \\\"{x:1212,y:815,t:1527023312278};\\\", \\\"{x:1214,y:817,t:1527023312295};\\\", \\\"{x:1217,y:821,t:1527023312311};\\\", \\\"{x:1218,y:823,t:1527023312328};\\\", \\\"{x:1219,y:826,t:1527023312345};\\\", \\\"{x:1222,y:831,t:1527023312361};\\\", \\\"{x:1222,y:833,t:1527023312382};\\\", \\\"{x:1222,y:835,t:1527023312395};\\\", \\\"{x:1223,y:835,t:1527023312412};\\\", \\\"{x:1224,y:837,t:1527023312429};\\\", \\\"{x:1224,y:838,t:1527023312445};\\\", \\\"{x:1225,y:841,t:1527023312462};\\\", \\\"{x:1225,y:843,t:1527023312486};\\\", \\\"{x:1226,y:843,t:1527023312494};\\\", \\\"{x:1227,y:844,t:1527023312513};\\\", \\\"{x:1228,y:846,t:1527023312528};\\\", \\\"{x:1228,y:847,t:1527023312559};\\\", \\\"{x:1228,y:849,t:1527023312567};\\\", \\\"{x:1228,y:850,t:1527023312583};\\\", \\\"{x:1231,y:849,t:1527023312823};\\\", \\\"{x:1232,y:849,t:1527023312847};\\\", \\\"{x:1232,y:848,t:1527023312871};\\\", \\\"{x:1233,y:847,t:1527023312903};\\\", \\\"{x:1234,y:846,t:1527023312920};\\\", \\\"{x:1235,y:844,t:1527023312983};\\\", \\\"{x:1235,y:843,t:1527023313007};\\\", \\\"{x:1236,y:842,t:1527023313024};\\\", \\\"{x:1236,y:841,t:1527023313031};\\\", \\\"{x:1236,y:840,t:1527023313056};\\\", \\\"{x:1236,y:838,t:1527023313095};\\\", \\\"{x:1236,y:837,t:1527023313239};\\\", \\\"{x:1236,y:835,t:1527023313288};\\\", \\\"{x:1236,y:834,t:1527023313303};\\\", \\\"{x:1236,y:833,t:1527023313319};\\\", \\\"{x:1236,y:832,t:1527023313329};\\\", \\\"{x:1235,y:829,t:1527023313347};\\\", \\\"{x:1235,y:828,t:1527023313363};\\\", \\\"{x:1234,y:827,t:1527023313448};\\\", \\\"{x:1234,y:826,t:1527023313463};\\\", \\\"{x:1232,y:824,t:1527023313479};\\\", \\\"{x:1231,y:823,t:1527023313496};\\\", \\\"{x:1230,y:822,t:1527023313519};\\\", \\\"{x:1229,y:821,t:1527023313672};\\\", \\\"{x:1228,y:820,t:1527023313687};\\\", \\\"{x:1227,y:820,t:1527023313696};\\\", \\\"{x:1225,y:818,t:1527023313713};\\\", \\\"{x:1224,y:818,t:1527023313730};\\\", \\\"{x:1221,y:816,t:1527023313747};\\\", \\\"{x:1216,y:812,t:1527023313764};\\\", \\\"{x:1212,y:811,t:1527023313779};\\\", \\\"{x:1208,y:807,t:1527023313796};\\\", \\\"{x:1203,y:804,t:1527023313814};\\\", \\\"{x:1200,y:803,t:1527023313829};\\\", \\\"{x:1198,y:801,t:1527023313847};\\\", \\\"{x:1196,y:799,t:1527023313863};\\\", \\\"{x:1195,y:798,t:1527023313879};\\\", \\\"{x:1191,y:793,t:1527023313896};\\\", \\\"{x:1185,y:788,t:1527023313913};\\\", \\\"{x:1174,y:780,t:1527023313929};\\\", \\\"{x:1156,y:766,t:1527023313946};\\\", \\\"{x:1135,y:751,t:1527023313963};\\\", \\\"{x:1103,y:731,t:1527023313979};\\\", \\\"{x:1069,y:713,t:1527023313996};\\\", \\\"{x:1041,y:700,t:1527023314013};\\\", \\\"{x:991,y:677,t:1527023314029};\\\", \\\"{x:919,y:642,t:1527023314046};\\\", \\\"{x:860,y:620,t:1527023314062};\\\", \\\"{x:809,y:604,t:1527023314079};\\\", \\\"{x:756,y:588,t:1527023314096};\\\", \\\"{x:716,y:577,t:1527023314113};\\\", \\\"{x:680,y:566,t:1527023314130};\\\", \\\"{x:656,y:558,t:1527023314146};\\\", \\\"{x:630,y:553,t:1527023314164};\\\", \\\"{x:608,y:549,t:1527023314180};\\\", \\\"{x:593,y:549,t:1527023314196};\\\", \\\"{x:586,y:549,t:1527023314213};\\\", \\\"{x:574,y:549,t:1527023314230};\\\", \\\"{x:570,y:549,t:1527023314246};\\\", \\\"{x:562,y:549,t:1527023314263};\\\", \\\"{x:556,y:549,t:1527023314280};\\\", \\\"{x:552,y:548,t:1527023314297};\\\", \\\"{x:548,y:547,t:1527023314313};\\\", \\\"{x:546,y:543,t:1527023314330};\\\", \\\"{x:546,y:532,t:1527023314347};\\\", \\\"{x:549,y:518,t:1527023314364};\\\", \\\"{x:560,y:505,t:1527023314380};\\\", \\\"{x:574,y:496,t:1527023314398};\\\", \\\"{x:579,y:491,t:1527023314413};\\\", \\\"{x:604,y:481,t:1527023314431};\\\", \\\"{x:617,y:476,t:1527023314446};\\\", \\\"{x:629,y:471,t:1527023314464};\\\", \\\"{x:642,y:469,t:1527023314481};\\\", \\\"{x:649,y:468,t:1527023314497};\\\", \\\"{x:651,y:467,t:1527023314513};\\\", \\\"{x:651,y:469,t:1527023314567};\\\", \\\"{x:649,y:475,t:1527023314581};\\\", \\\"{x:643,y:486,t:1527023314598};\\\", \\\"{x:639,y:494,t:1527023314613};\\\", \\\"{x:635,y:499,t:1527023314630};\\\", \\\"{x:634,y:500,t:1527023314647};\\\", \\\"{x:633,y:501,t:1527023314799};\\\", \\\"{x:629,y:500,t:1527023314813};\\\", \\\"{x:627,y:498,t:1527023314830};\\\", \\\"{x:620,y:495,t:1527023314848};\\\", \\\"{x:618,y:494,t:1527023314864};\\\", \\\"{x:614,y:493,t:1527023314880};\\\", \\\"{x:612,y:491,t:1527023314898};\\\", \\\"{x:610,y:490,t:1527023314915};\\\", \\\"{x:608,y:489,t:1527023314931};\\\", \\\"{x:606,y:485,t:1527023314947};\\\", \\\"{x:603,y:482,t:1527023314965};\\\", \\\"{x:601,y:479,t:1527023314981};\\\", \\\"{x:599,y:476,t:1527023314997};\\\", \\\"{x:599,y:474,t:1527023315015};\\\", \\\"{x:599,y:473,t:1527023315031};\\\", \\\"{x:599,y:471,t:1527023315063};\\\", \\\"{x:599,y:473,t:1527023315391};\\\", \\\"{x:599,y:477,t:1527023315398};\\\", \\\"{x:596,y:485,t:1527023315415};\\\", \\\"{x:596,y:487,t:1527023315431};\\\", \\\"{x:596,y:489,t:1527023315447};\\\", \\\"{x:595,y:489,t:1527023315568};\\\", \\\"{x:595,y:490,t:1527023315599};\\\", \\\"{x:595,y:491,t:1527023315639};\\\", \\\"{x:595,y:492,t:1527023315654};\\\", \\\"{x:595,y:493,t:1527023315670};\\\", \\\"{x:595,y:495,t:1527023315681};\\\", \\\"{x:597,y:499,t:1527023315698};\\\", \\\"{x:600,y:503,t:1527023315715};\\\", \\\"{x:602,y:507,t:1527023315731};\\\", \\\"{x:603,y:509,t:1527023315748};\\\", \\\"{x:604,y:509,t:1527023315782};\\\", \\\"{x:605,y:514,t:1527023316054};\\\", \\\"{x:605,y:517,t:1527023316065};\\\", \\\"{x:608,y:525,t:1527023316082};\\\", \\\"{x:611,y:535,t:1527023316099};\\\", \\\"{x:613,y:539,t:1527023316115};\\\", \\\"{x:613,y:540,t:1527023316131};\\\", \\\"{x:614,y:539,t:1527023316567};\\\", \\\"{x:615,y:534,t:1527023316581};\\\", \\\"{x:617,y:521,t:1527023316600};\\\", \\\"{x:618,y:513,t:1527023316616};\\\", \\\"{x:620,y:509,t:1527023316632};\\\", \\\"{x:620,y:503,t:1527023316648};\\\", \\\"{x:620,y:497,t:1527023316665};\\\", \\\"{x:619,y:491,t:1527023316682};\\\", \\\"{x:618,y:487,t:1527023316698};\\\", \\\"{x:617,y:482,t:1527023316715};\\\", \\\"{x:616,y:479,t:1527023316733};\\\", \\\"{x:616,y:476,t:1527023316748};\\\", \\\"{x:616,y:473,t:1527023316765};\\\", \\\"{x:616,y:472,t:1527023316782};\\\", \\\"{x:617,y:468,t:1527023316798};\\\", \\\"{x:619,y:466,t:1527023316815};\\\", \\\"{x:620,y:466,t:1527023317149};\\\", \\\"{x:618,y:479,t:1527023317165};\\\", \\\"{x:615,y:506,t:1527023317183};\\\", \\\"{x:614,y:524,t:1527023317200};\\\", \\\"{x:614,y:539,t:1527023317215};\\\", \\\"{x:614,y:548,t:1527023317232};\\\", \\\"{x:614,y:559,t:1527023317249};\\\", \\\"{x:615,y:570,t:1527023317267};\\\", \\\"{x:616,y:580,t:1527023317283};\\\", \\\"{x:616,y:591,t:1527023317299};\\\", \\\"{x:616,y:601,t:1527023317316};\\\", \\\"{x:616,y:618,t:1527023317333};\\\", \\\"{x:612,y:639,t:1527023317349};\\\", \\\"{x:595,y:670,t:1527023317366};\\\", \\\"{x:586,y:685,t:1527023317382};\\\", \\\"{x:579,y:699,t:1527023317400};\\\", \\\"{x:569,y:711,t:1527023317416};\\\", \\\"{x:563,y:718,t:1527023317432};\\\", \\\"{x:559,y:721,t:1527023317449};\\\", \\\"{x:554,y:722,t:1527023317466};\\\", \\\"{x:546,y:722,t:1527023317482};\\\", \\\"{x:538,y:722,t:1527023317499};\\\", \\\"{x:526,y:720,t:1527023317516};\\\", \\\"{x:505,y:712,t:1527023317533};\\\", \\\"{x:488,y:700,t:1527023317549};\\\", \\\"{x:478,y:685,t:1527023317566};\\\", \\\"{x:476,y:676,t:1527023317583};\\\", \\\"{x:476,y:666,t:1527023317599};\\\", \\\"{x:481,y:656,t:1527023317616};\\\", \\\"{x:483,y:652,t:1527023317632};\\\", \\\"{x:484,y:651,t:1527023317649};\\\", \\\"{x:484,y:650,t:1527023317687};\\\", \\\"{x:484,y:652,t:1527023317856};\\\", \\\"{x:484,y:656,t:1527023317866};\\\", \\\"{x:484,y:663,t:1527023317883};\\\", \\\"{x:484,y:669,t:1527023317899};\\\", \\\"{x:484,y:671,t:1527023317916};\\\", \\\"{x:485,y:672,t:1527023317934};\\\" ] }, { \\\"rt\\\": 25803, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 402125, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"JYZGH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 3.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\", \\\"O\\\", \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:485,y:671,t:1527023319462};\\\", \\\"{x:485,y:670,t:1527023319491};\\\", \\\"{x:485,y:668,t:1527023319518};\\\", \\\"{x:485,y:667,t:1527023319550};\\\", \\\"{x:484,y:667,t:1527023319567};\\\", \\\"{x:484,y:666,t:1527023319590};\\\", \\\"{x:483,y:665,t:1527023319606};\\\", \\\"{x:483,y:664,t:1527023320742};\\\", \\\"{x:482,y:664,t:1527023320864};\\\", \\\"{x:482,y:662,t:1527023321151};\\\", \\\"{x:482,y:661,t:1527023321215};\\\", \\\"{x:482,y:659,t:1527023321304};\\\", \\\"{x:482,y:658,t:1527023321368};\\\", \\\"{x:484,y:658,t:1527023321535};\\\", \\\"{x:492,y:658,t:1527023321546};\\\", \\\"{x:518,y:661,t:1527023321562};\\\", \\\"{x:548,y:666,t:1527023321579};\\\", \\\"{x:587,y:672,t:1527023321597};\\\", \\\"{x:628,y:676,t:1527023321612};\\\", \\\"{x:660,y:684,t:1527023321630};\\\", \\\"{x:702,y:690,t:1527023321652};\\\", \\\"{x:748,y:699,t:1527023321670};\\\", \\\"{x:803,y:705,t:1527023321686};\\\", \\\"{x:843,y:714,t:1527023321702};\\\", \\\"{x:875,y:718,t:1527023321720};\\\", \\\"{x:917,y:726,t:1527023321737};\\\", \\\"{x:952,y:734,t:1527023321752};\\\", \\\"{x:1004,y:745,t:1527023321770};\\\", \\\"{x:1045,y:749,t:1527023321787};\\\", \\\"{x:1075,y:754,t:1527023321804};\\\", \\\"{x:1105,y:759,t:1527023321819};\\\", \\\"{x:1134,y:763,t:1527023321836};\\\", \\\"{x:1152,y:766,t:1527023321854};\\\", \\\"{x:1178,y:770,t:1527023321870};\\\", \\\"{x:1227,y:783,t:1527023321886};\\\", \\\"{x:1291,y:800,t:1527023321904};\\\", \\\"{x:1382,y:821,t:1527023321920};\\\", \\\"{x:1466,y:836,t:1527023321936};\\\", \\\"{x:1541,y:847,t:1527023321954};\\\", \\\"{x:1592,y:856,t:1527023321969};\\\", \\\"{x:1626,y:862,t:1527023321986};\\\", \\\"{x:1643,y:864,t:1527023322003};\\\", \\\"{x:1653,y:867,t:1527023322019};\\\", \\\"{x:1660,y:868,t:1527023322036};\\\", \\\"{x:1664,y:868,t:1527023322053};\\\", \\\"{x:1668,y:868,t:1527023322071};\\\", \\\"{x:1669,y:869,t:1527023322087};\\\", \\\"{x:1668,y:871,t:1527023322256};\\\", \\\"{x:1663,y:875,t:1527023322271};\\\", \\\"{x:1658,y:879,t:1527023322288};\\\", \\\"{x:1656,y:882,t:1527023322304};\\\", \\\"{x:1652,y:885,t:1527023322321};\\\", \\\"{x:1651,y:887,t:1527023322339};\\\", \\\"{x:1651,y:888,t:1527023322432};\\\", \\\"{x:1650,y:889,t:1527023322488};\\\", \\\"{x:1649,y:890,t:1527023322551};\\\", \\\"{x:1649,y:891,t:1527023322567};\\\", \\\"{x:1649,y:892,t:1527023322592};\\\", \\\"{x:1648,y:893,t:1527023322615};\\\", \\\"{x:1647,y:894,t:1527023322647};\\\", \\\"{x:1648,y:894,t:1527023322799};\\\", \\\"{x:1652,y:889,t:1527023322807};\\\", \\\"{x:1655,y:884,t:1527023322822};\\\", \\\"{x:1665,y:873,t:1527023322839};\\\", \\\"{x:1665,y:869,t:1527023322855};\\\", \\\"{x:1669,y:863,t:1527023322872};\\\", \\\"{x:1669,y:860,t:1527023322889};\\\", \\\"{x:1670,y:857,t:1527023322905};\\\", \\\"{x:1671,y:852,t:1527023322922};\\\", \\\"{x:1671,y:849,t:1527023322939};\\\", \\\"{x:1672,y:845,t:1527023322956};\\\", \\\"{x:1673,y:840,t:1527023322972};\\\", \\\"{x:1675,y:835,t:1527023322989};\\\", \\\"{x:1676,y:831,t:1527023323005};\\\", \\\"{x:1676,y:827,t:1527023323023};\\\", \\\"{x:1677,y:820,t:1527023323039};\\\", \\\"{x:1677,y:812,t:1527023323056};\\\", \\\"{x:1677,y:806,t:1527023323072};\\\", \\\"{x:1677,y:804,t:1527023323089};\\\", \\\"{x:1677,y:801,t:1527023323106};\\\", \\\"{x:1677,y:798,t:1527023323122};\\\", \\\"{x:1677,y:797,t:1527023323143};\\\", \\\"{x:1677,y:796,t:1527023323156};\\\", \\\"{x:1677,y:795,t:1527023323172};\\\", \\\"{x:1676,y:794,t:1527023323263};\\\", \\\"{x:1675,y:795,t:1527023323273};\\\", \\\"{x:1671,y:797,t:1527023323290};\\\", \\\"{x:1663,y:809,t:1527023323306};\\\", \\\"{x:1655,y:824,t:1527023323323};\\\", \\\"{x:1645,y:837,t:1527023323339};\\\", \\\"{x:1640,y:847,t:1527023323356};\\\", \\\"{x:1635,y:855,t:1527023323373};\\\", \\\"{x:1631,y:863,t:1527023323390};\\\", \\\"{x:1627,y:869,t:1527023323406};\\\", \\\"{x:1623,y:877,t:1527023323423};\\\", \\\"{x:1621,y:882,t:1527023323439};\\\", \\\"{x:1620,y:885,t:1527023323456};\\\", \\\"{x:1619,y:888,t:1527023323473};\\\", \\\"{x:1618,y:892,t:1527023323490};\\\", \\\"{x:1618,y:894,t:1527023323506};\\\", \\\"{x:1618,y:897,t:1527023323523};\\\", \\\"{x:1618,y:898,t:1527023323541};\\\", \\\"{x:1616,y:901,t:1527023323556};\\\", \\\"{x:1616,y:904,t:1527023323573};\\\", \\\"{x:1615,y:907,t:1527023323590};\\\", \\\"{x:1615,y:911,t:1527023323606};\\\", \\\"{x:1612,y:915,t:1527023323623};\\\", \\\"{x:1612,y:916,t:1527023323647};\\\", \\\"{x:1611,y:917,t:1527023323663};\\\", \\\"{x:1611,y:918,t:1527023323673};\\\", \\\"{x:1610,y:918,t:1527023323711};\\\", \\\"{x:1609,y:918,t:1527023323723};\\\", \\\"{x:1608,y:918,t:1527023323743};\\\", \\\"{x:1605,y:918,t:1527023323756};\\\", \\\"{x:1600,y:916,t:1527023323772};\\\", \\\"{x:1598,y:909,t:1527023323790};\\\", \\\"{x:1598,y:895,t:1527023323806};\\\", \\\"{x:1598,y:884,t:1527023323824};\\\", \\\"{x:1602,y:869,t:1527023323839};\\\", \\\"{x:1608,y:852,t:1527023323856};\\\", \\\"{x:1610,y:838,t:1527023323873};\\\", \\\"{x:1611,y:826,t:1527023323889};\\\", \\\"{x:1613,y:817,t:1527023323906};\\\", \\\"{x:1613,y:809,t:1527023323923};\\\", \\\"{x:1612,y:806,t:1527023323941};\\\", \\\"{x:1612,y:803,t:1527023323957};\\\", \\\"{x:1611,y:799,t:1527023323973};\\\", \\\"{x:1608,y:794,t:1527023323990};\\\", \\\"{x:1604,y:784,t:1527023324006};\\\", \\\"{x:1601,y:774,t:1527023324024};\\\", \\\"{x:1600,y:766,t:1527023324040};\\\", \\\"{x:1597,y:757,t:1527023324056};\\\", \\\"{x:1595,y:751,t:1527023324074};\\\", \\\"{x:1593,y:746,t:1527023324091};\\\", \\\"{x:1590,y:741,t:1527023324106};\\\", \\\"{x:1588,y:737,t:1527023324124};\\\", \\\"{x:1587,y:731,t:1527023324140};\\\", \\\"{x:1584,y:723,t:1527023324157};\\\", \\\"{x:1584,y:717,t:1527023324174};\\\", \\\"{x:1583,y:707,t:1527023324191};\\\", \\\"{x:1582,y:701,t:1527023324208};\\\", \\\"{x:1582,y:695,t:1527023324223};\\\", \\\"{x:1582,y:689,t:1527023324240};\\\", \\\"{x:1582,y:684,t:1527023324257};\\\", \\\"{x:1582,y:679,t:1527023324274};\\\", \\\"{x:1582,y:673,t:1527023324291};\\\", \\\"{x:1582,y:666,t:1527023324308};\\\", \\\"{x:1584,y:663,t:1527023324323};\\\", \\\"{x:1584,y:659,t:1527023324342};\\\", \\\"{x:1585,y:656,t:1527023324358};\\\", \\\"{x:1586,y:652,t:1527023324374};\\\", \\\"{x:1587,y:644,t:1527023324391};\\\", \\\"{x:1587,y:637,t:1527023324408};\\\", \\\"{x:1587,y:633,t:1527023324425};\\\", \\\"{x:1587,y:629,t:1527023324442};\\\", \\\"{x:1587,y:626,t:1527023324458};\\\", \\\"{x:1587,y:623,t:1527023324475};\\\", \\\"{x:1587,y:620,t:1527023324491};\\\", \\\"{x:1587,y:616,t:1527023324508};\\\", \\\"{x:1587,y:613,t:1527023324526};\\\", \\\"{x:1587,y:610,t:1527023324541};\\\", \\\"{x:1587,y:607,t:1527023324558};\\\", \\\"{x:1585,y:600,t:1527023324575};\\\", \\\"{x:1583,y:594,t:1527023324591};\\\", \\\"{x:1581,y:590,t:1527023324608};\\\", \\\"{x:1580,y:587,t:1527023324625};\\\", \\\"{x:1579,y:581,t:1527023324643};\\\", \\\"{x:1577,y:576,t:1527023324658};\\\", \\\"{x:1576,y:571,t:1527023324675};\\\", \\\"{x:1573,y:566,t:1527023324692};\\\", \\\"{x:1572,y:562,t:1527023324708};\\\", \\\"{x:1572,y:559,t:1527023324725};\\\", \\\"{x:1571,y:554,t:1527023324742};\\\", \\\"{x:1569,y:549,t:1527023324758};\\\", \\\"{x:1569,y:544,t:1527023324775};\\\", \\\"{x:1568,y:542,t:1527023324792};\\\", \\\"{x:1567,y:538,t:1527023324808};\\\", \\\"{x:1567,y:536,t:1527023324825};\\\", \\\"{x:1567,y:532,t:1527023324842};\\\", \\\"{x:1567,y:529,t:1527023324859};\\\", \\\"{x:1567,y:527,t:1527023324875};\\\", \\\"{x:1567,y:524,t:1527023324892};\\\", \\\"{x:1567,y:522,t:1527023324909};\\\", \\\"{x:1567,y:518,t:1527023324925};\\\", \\\"{x:1567,y:515,t:1527023324942};\\\", \\\"{x:1567,y:512,t:1527023324959};\\\", \\\"{x:1567,y:511,t:1527023324975};\\\", \\\"{x:1567,y:510,t:1527023324992};\\\", \\\"{x:1567,y:509,t:1527023325009};\\\", \\\"{x:1567,y:508,t:1527023325039};\\\", \\\"{x:1567,y:507,t:1527023325119};\\\", \\\"{x:1567,y:506,t:1527023325208};\\\", \\\"{x:1560,y:505,t:1527023325215};\\\", \\\"{x:1548,y:504,t:1527023325226};\\\", \\\"{x:1509,y:500,t:1527023325242};\\\", \\\"{x:1412,y:486,t:1527023325259};\\\", \\\"{x:1260,y:466,t:1527023325276};\\\", \\\"{x:1106,y:451,t:1527023325294};\\\", \\\"{x:946,y:432,t:1527023325309};\\\", \\\"{x:807,y:432,t:1527023325326};\\\", \\\"{x:634,y:426,t:1527023325342};\\\", \\\"{x:559,y:426,t:1527023325359};\\\", \\\"{x:531,y:427,t:1527023325375};\\\", \\\"{x:506,y:432,t:1527023325393};\\\", \\\"{x:489,y:436,t:1527023325410};\\\", \\\"{x:476,y:440,t:1527023325426};\\\", \\\"{x:461,y:448,t:1527023325442};\\\", \\\"{x:442,y:455,t:1527023325461};\\\", \\\"{x:417,y:463,t:1527023325477};\\\", \\\"{x:392,y:475,t:1527023325492};\\\", \\\"{x:361,y:487,t:1527023325506};\\\", \\\"{x:332,y:499,t:1527023325522};\\\", \\\"{x:308,y:510,t:1527023325540};\\\", \\\"{x:290,y:519,t:1527023325555};\\\", \\\"{x:275,y:532,t:1527023325573};\\\", \\\"{x:271,y:542,t:1527023325591};\\\", \\\"{x:270,y:550,t:1527023325606};\\\", \\\"{x:271,y:565,t:1527023325622};\\\", \\\"{x:280,y:575,t:1527023325640};\\\", \\\"{x:295,y:588,t:1527023325655};\\\", \\\"{x:319,y:598,t:1527023325672};\\\", \\\"{x:342,y:605,t:1527023325688};\\\", \\\"{x:395,y:619,t:1527023325706};\\\", \\\"{x:454,y:628,t:1527023325723};\\\", \\\"{x:488,y:634,t:1527023325740};\\\", \\\"{x:518,y:639,t:1527023325756};\\\", \\\"{x:545,y:641,t:1527023325772};\\\", \\\"{x:565,y:644,t:1527023325789};\\\", \\\"{x:585,y:645,t:1527023325805};\\\", \\\"{x:616,y:645,t:1527023325822};\\\", \\\"{x:645,y:645,t:1527023325839};\\\", \\\"{x:674,y:645,t:1527023325855};\\\", \\\"{x:708,y:646,t:1527023325872};\\\", \\\"{x:729,y:646,t:1527023325889};\\\", \\\"{x:747,y:648,t:1527023325906};\\\", \\\"{x:765,y:647,t:1527023325922};\\\", \\\"{x:772,y:644,t:1527023325940};\\\", \\\"{x:778,y:641,t:1527023325956};\\\", \\\"{x:780,y:639,t:1527023325973};\\\", \\\"{x:780,y:638,t:1527023325999};\\\", \\\"{x:780,y:637,t:1527023326014};\\\", \\\"{x:780,y:636,t:1527023326023};\\\", \\\"{x:772,y:634,t:1527023326040};\\\", \\\"{x:752,y:634,t:1527023326057};\\\", \\\"{x:723,y:634,t:1527023326073};\\\", \\\"{x:686,y:634,t:1527023326090};\\\", \\\"{x:638,y:634,t:1527023326106};\\\", \\\"{x:592,y:630,t:1527023326123};\\\", \\\"{x:561,y:622,t:1527023326141};\\\", \\\"{x:553,y:617,t:1527023326156};\\\", \\\"{x:551,y:616,t:1527023326172};\\\", \\\"{x:551,y:614,t:1527023326190};\\\", \\\"{x:551,y:607,t:1527023326206};\\\", \\\"{x:553,y:603,t:1527023326223};\\\", \\\"{x:557,y:597,t:1527023326240};\\\", \\\"{x:561,y:592,t:1527023326257};\\\", \\\"{x:566,y:586,t:1527023326272};\\\", \\\"{x:570,y:583,t:1527023326289};\\\", \\\"{x:575,y:578,t:1527023326306};\\\", \\\"{x:579,y:575,t:1527023326323};\\\", \\\"{x:585,y:569,t:1527023326341};\\\", \\\"{x:590,y:566,t:1527023326358};\\\", \\\"{x:598,y:562,t:1527023326374};\\\", \\\"{x:607,y:561,t:1527023326390};\\\", \\\"{x:621,y:559,t:1527023326407};\\\", \\\"{x:631,y:559,t:1527023326423};\\\", \\\"{x:635,y:559,t:1527023326440};\\\", \\\"{x:639,y:558,t:1527023327247};\\\", \\\"{x:640,y:557,t:1527023327256};\\\", \\\"{x:645,y:555,t:1527023327274};\\\", \\\"{x:648,y:554,t:1527023327291};\\\", \\\"{x:653,y:552,t:1527023327306};\\\", \\\"{x:655,y:551,t:1527023327324};\\\", \\\"{x:658,y:550,t:1527023327359};\\\", \\\"{x:658,y:549,t:1527023327374};\\\", \\\"{x:661,y:549,t:1527023327390};\\\", \\\"{x:662,y:548,t:1527023327407};\\\", \\\"{x:663,y:547,t:1527023327423};\\\", \\\"{x:664,y:546,t:1527023327441};\\\", \\\"{x:666,y:546,t:1527023327457};\\\", \\\"{x:666,y:544,t:1527023327473};\\\", \\\"{x:667,y:544,t:1527023327491};\\\", \\\"{x:668,y:543,t:1527023327507};\\\", \\\"{x:668,y:542,t:1527023327524};\\\", \\\"{x:667,y:543,t:1527023327759};\\\", \\\"{x:665,y:543,t:1527023327774};\\\", \\\"{x:662,y:543,t:1527023327791};\\\", \\\"{x:660,y:544,t:1527023327808};\\\", \\\"{x:657,y:544,t:1527023327824};\\\", \\\"{x:654,y:545,t:1527023327840};\\\", \\\"{x:652,y:545,t:1527023327857};\\\", \\\"{x:651,y:545,t:1527023327935};\\\", \\\"{x:650,y:545,t:1527023327942};\\\", \\\"{x:649,y:545,t:1527023328007};\\\", \\\"{x:648,y:546,t:1527023328031};\\\", \\\"{x:647,y:547,t:1527023328046};\\\", \\\"{x:646,y:547,t:1527023328063};\\\", \\\"{x:645,y:547,t:1527023328086};\\\", \\\"{x:644,y:547,t:1527023328167};\\\", \\\"{x:644,y:548,t:1527023328239};\\\", \\\"{x:643,y:548,t:1527023329720};\\\", \\\"{x:642,y:548,t:1527023329741};\\\", \\\"{x:641,y:548,t:1527023329758};\\\", \\\"{x:641,y:550,t:1527023329776};\\\", \\\"{x:640,y:551,t:1527023329798};\\\", \\\"{x:640,y:552,t:1527023329862};\\\", \\\"{x:640,y:553,t:1527023329943};\\\", \\\"{x:639,y:554,t:1527023329966};\\\", \\\"{x:639,y:555,t:1527023329999};\\\", \\\"{x:639,y:556,t:1527023330055};\\\", \\\"{x:638,y:557,t:1527023330071};\\\", \\\"{x:638,y:558,t:1527023330087};\\\", \\\"{x:638,y:559,t:1527023330095};\\\", \\\"{x:638,y:560,t:1527023330120};\\\", \\\"{x:638,y:561,t:1527023330134};\\\", \\\"{x:638,y:562,t:1527023330150};\\\", \\\"{x:638,y:563,t:1527023330166};\\\", \\\"{x:637,y:564,t:1527023330177};\\\", \\\"{x:637,y:565,t:1527023330192};\\\", \\\"{x:636,y:566,t:1527023330222};\\\", \\\"{x:636,y:567,t:1527023330230};\\\", \\\"{x:636,y:568,t:1527023330242};\\\", \\\"{x:635,y:569,t:1527023330259};\\\", \\\"{x:635,y:570,t:1527023330277};\\\", \\\"{x:635,y:571,t:1527023330293};\\\", \\\"{x:635,y:572,t:1527023330310};\\\", \\\"{x:634,y:574,t:1527023330326};\\\", \\\"{x:634,y:575,t:1527023330358};\\\", \\\"{x:634,y:576,t:1527023330366};\\\", \\\"{x:634,y:577,t:1527023330377};\\\", \\\"{x:632,y:578,t:1527023330393};\\\", \\\"{x:632,y:580,t:1527023330409};\\\", \\\"{x:632,y:581,t:1527023330438};\\\", \\\"{x:632,y:582,t:1527023330446};\\\", \\\"{x:632,y:583,t:1527023330462};\\\", \\\"{x:631,y:584,t:1527023330477};\\\", \\\"{x:631,y:585,t:1527023330495};\\\", \\\"{x:631,y:586,t:1527023330510};\\\", \\\"{x:630,y:587,t:1527023330535};\\\", \\\"{x:630,y:588,t:1527023330615};\\\", \\\"{x:629,y:589,t:1527023330655};\\\", \\\"{x:628,y:589,t:1527023330711};\\\", \\\"{x:627,y:590,t:1527023330742};\\\", \\\"{x:626,y:590,t:1527023330775};\\\", \\\"{x:625,y:590,t:1527023330783};\\\", \\\"{x:624,y:590,t:1527023330794};\\\", \\\"{x:622,y:591,t:1527023330810};\\\", \\\"{x:618,y:592,t:1527023330828};\\\", \\\"{x:617,y:593,t:1527023330844};\\\", \\\"{x:614,y:593,t:1527023330860};\\\", \\\"{x:609,y:593,t:1527023330877};\\\", \\\"{x:602,y:593,t:1527023330894};\\\", \\\"{x:595,y:593,t:1527023330912};\\\", \\\"{x:591,y:593,t:1527023330926};\\\", \\\"{x:589,y:593,t:1527023330944};\\\", \\\"{x:588,y:593,t:1527023330961};\\\", \\\"{x:585,y:593,t:1527023330976};\\\", \\\"{x:583,y:593,t:1527023330993};\\\", \\\"{x:580,y:593,t:1527023331011};\\\", \\\"{x:576,y:593,t:1527023331026};\\\", \\\"{x:572,y:592,t:1527023331044};\\\", \\\"{x:566,y:589,t:1527023331060};\\\", \\\"{x:559,y:586,t:1527023331076};\\\", \\\"{x:549,y:579,t:1527023331093};\\\", \\\"{x:543,y:575,t:1527023331110};\\\", \\\"{x:537,y:569,t:1527023331127};\\\", \\\"{x:530,y:565,t:1527023331145};\\\", \\\"{x:521,y:560,t:1527023331160};\\\", \\\"{x:507,y:553,t:1527023331177};\\\", \\\"{x:498,y:547,t:1527023331194};\\\", \\\"{x:490,y:544,t:1527023331210};\\\", \\\"{x:485,y:540,t:1527023331227};\\\", \\\"{x:480,y:537,t:1527023331244};\\\", \\\"{x:474,y:533,t:1527023331260};\\\", \\\"{x:465,y:526,t:1527023331277};\\\", \\\"{x:451,y:519,t:1527023331295};\\\", \\\"{x:440,y:512,t:1527023331310};\\\", \\\"{x:431,y:507,t:1527023331327};\\\", \\\"{x:427,y:505,t:1527023331344};\\\", \\\"{x:420,y:502,t:1527023331361};\\\", \\\"{x:415,y:499,t:1527023331378};\\\", \\\"{x:412,y:498,t:1527023331393};\\\", \\\"{x:409,y:498,t:1527023331411};\\\", \\\"{x:407,y:498,t:1527023331428};\\\", \\\"{x:405,y:498,t:1527023331443};\\\", \\\"{x:404,y:499,t:1527023331460};\\\", \\\"{x:400,y:502,t:1527023331478};\\\", \\\"{x:398,y:503,t:1527023331494};\\\", \\\"{x:397,y:504,t:1527023331511};\\\", \\\"{x:396,y:505,t:1527023331534};\\\", \\\"{x:395,y:505,t:1527023331546};\\\", \\\"{x:395,y:506,t:1527023331561};\\\", \\\"{x:395,y:507,t:1527023331578};\\\", \\\"{x:395,y:509,t:1527023331595};\\\", \\\"{x:395,y:512,t:1527023331612};\\\", \\\"{x:395,y:514,t:1527023331628};\\\", \\\"{x:395,y:515,t:1527023331645};\\\", \\\"{x:395,y:521,t:1527023331663};\\\", \\\"{x:395,y:523,t:1527023331680};\\\", \\\"{x:395,y:527,t:1527023331694};\\\", \\\"{x:395,y:529,t:1527023331710};\\\", \\\"{x:395,y:531,t:1527023331728};\\\", \\\"{x:395,y:532,t:1527023331745};\\\", \\\"{x:397,y:532,t:1527023331774};\\\", \\\"{x:398,y:532,t:1527023331782};\\\", \\\"{x:401,y:532,t:1527023331793};\\\", \\\"{x:418,y:529,t:1527023331811};\\\", \\\"{x:439,y:523,t:1527023331828};\\\", \\\"{x:470,y:519,t:1527023331844};\\\", \\\"{x:509,y:514,t:1527023331861};\\\", \\\"{x:560,y:508,t:1527023331877};\\\", \\\"{x:584,y:504,t:1527023331894};\\\", \\\"{x:596,y:500,t:1527023331911};\\\", \\\"{x:598,y:498,t:1527023331928};\\\", \\\"{x:598,y:497,t:1527023331945};\\\", \\\"{x:598,y:492,t:1527023331960};\\\", \\\"{x:598,y:487,t:1527023331978};\\\", \\\"{x:598,y:484,t:1527023331995};\\\", \\\"{x:598,y:483,t:1527023332011};\\\", \\\"{x:598,y:481,t:1527023332028};\\\", \\\"{x:598,y:480,t:1527023332046};\\\", \\\"{x:598,y:478,t:1527023332061};\\\", \\\"{x:598,y:475,t:1527023332078};\\\", \\\"{x:598,y:474,t:1527023332095};\\\", \\\"{x:598,y:472,t:1527023332111};\\\", \\\"{x:599,y:470,t:1527023332128};\\\", \\\"{x:599,y:469,t:1527023332145};\\\", \\\"{x:601,y:469,t:1527023332160};\\\", \\\"{x:602,y:467,t:1527023332178};\\\", \\\"{x:604,y:467,t:1527023332196};\\\", \\\"{x:607,y:465,t:1527023332212};\\\", \\\"{x:608,y:465,t:1527023332228};\\\", \\\"{x:608,y:464,t:1527023332244};\\\", \\\"{x:610,y:465,t:1527023333342};\\\", \\\"{x:610,y:467,t:1527023333350};\\\", \\\"{x:611,y:473,t:1527023333361};\\\", \\\"{x:615,y:480,t:1527023333379};\\\", \\\"{x:620,y:492,t:1527023333396};\\\", \\\"{x:623,y:499,t:1527023333412};\\\", \\\"{x:625,y:504,t:1527023333429};\\\", \\\"{x:625,y:506,t:1527023333446};\\\", \\\"{x:625,y:507,t:1527023333462};\\\", \\\"{x:625,y:509,t:1527023333479};\\\", \\\"{x:625,y:513,t:1527023333495};\\\", \\\"{x:625,y:516,t:1527023333513};\\\", \\\"{x:625,y:522,t:1527023333529};\\\", \\\"{x:625,y:528,t:1527023333546};\\\", \\\"{x:625,y:533,t:1527023333562};\\\", \\\"{x:625,y:536,t:1527023333578};\\\", \\\"{x:625,y:539,t:1527023333596};\\\", \\\"{x:625,y:541,t:1527023333612};\\\", \\\"{x:625,y:544,t:1527023333628};\\\", \\\"{x:625,y:547,t:1527023333645};\\\", \\\"{x:625,y:549,t:1527023333661};\\\", \\\"{x:625,y:552,t:1527023333679};\\\", \\\"{x:625,y:554,t:1527023333696};\\\", \\\"{x:625,y:558,t:1527023333713};\\\", \\\"{x:624,y:563,t:1527023333729};\\\", \\\"{x:623,y:566,t:1527023333746};\\\", \\\"{x:621,y:570,t:1527023333764};\\\", \\\"{x:620,y:571,t:1527023333779};\\\", \\\"{x:618,y:573,t:1527023333796};\\\", \\\"{x:617,y:574,t:1527023333814};\\\", \\\"{x:629,y:574,t:1527023333862};\\\", \\\"{x:711,y:576,t:1527023333879};\\\", \\\"{x:804,y:583,t:1527023333897};\\\", \\\"{x:860,y:590,t:1527023333913};\\\", \\\"{x:900,y:591,t:1527023333930};\\\", \\\"{x:923,y:591,t:1527023333946};\\\", \\\"{x:924,y:591,t:1527023333963};\\\", \\\"{x:925,y:591,t:1527023333980};\\\", \\\"{x:926,y:588,t:1527023333995};\\\", \\\"{x:926,y:587,t:1527023334013};\\\", \\\"{x:924,y:580,t:1527023334030};\\\", \\\"{x:920,y:572,t:1527023334046};\\\", \\\"{x:915,y:566,t:1527023334063};\\\", \\\"{x:909,y:558,t:1527023334081};\\\", \\\"{x:901,y:553,t:1527023334096};\\\", \\\"{x:890,y:548,t:1527023334113};\\\", \\\"{x:879,y:543,t:1527023334130};\\\", \\\"{x:869,y:538,t:1527023334146};\\\", \\\"{x:858,y:533,t:1527023334163};\\\", \\\"{x:850,y:530,t:1527023334181};\\\", \\\"{x:844,y:525,t:1527023334196};\\\", \\\"{x:840,y:520,t:1527023334214};\\\", \\\"{x:837,y:514,t:1527023334230};\\\", \\\"{x:835,y:510,t:1527023334246};\\\", \\\"{x:834,y:506,t:1527023334263};\\\", \\\"{x:832,y:498,t:1527023334280};\\\", \\\"{x:830,y:489,t:1527023334296};\\\", \\\"{x:830,y:482,t:1527023334314};\\\", \\\"{x:829,y:476,t:1527023334331};\\\", \\\"{x:827,y:469,t:1527023334346};\\\", \\\"{x:827,y:466,t:1527023334363};\\\", \\\"{x:827,y:464,t:1527023334379};\\\", \\\"{x:826,y:463,t:1527023334397};\\\", \\\"{x:825,y:462,t:1527023334413};\\\", \\\"{x:825,y:461,t:1527023334430};\\\", \\\"{x:825,y:460,t:1527023334446};\\\", \\\"{x:825,y:462,t:1527023334999};\\\", \\\"{x:825,y:463,t:1527023335014};\\\", \\\"{x:825,y:466,t:1527023335030};\\\", \\\"{x:825,y:470,t:1527023335047};\\\", \\\"{x:826,y:474,t:1527023335064};\\\", \\\"{x:826,y:480,t:1527023335080};\\\", \\\"{x:827,y:483,t:1527023335097};\\\", \\\"{x:827,y:487,t:1527023335115};\\\", \\\"{x:828,y:489,t:1527023335130};\\\", \\\"{x:828,y:493,t:1527023335148};\\\", \\\"{x:828,y:494,t:1527023335164};\\\", \\\"{x:828,y:497,t:1527023335180};\\\", \\\"{x:828,y:498,t:1527023335197};\\\", \\\"{x:828,y:500,t:1527023335214};\\\", \\\"{x:828,y:502,t:1527023335229};\\\", \\\"{x:828,y:504,t:1527023335247};\\\", \\\"{x:828,y:507,t:1527023335264};\\\", \\\"{x:828,y:508,t:1527023335280};\\\", \\\"{x:828,y:509,t:1527023335297};\\\", \\\"{x:828,y:510,t:1527023335313};\\\", \\\"{x:828,y:511,t:1527023335330};\\\", \\\"{x:827,y:512,t:1527023335615};\\\", \\\"{x:807,y:514,t:1527023335632};\\\", \\\"{x:776,y:514,t:1527023335647};\\\", \\\"{x:738,y:514,t:1527023335664};\\\", \\\"{x:700,y:512,t:1527023335681};\\\", \\\"{x:676,y:509,t:1527023335698};\\\", \\\"{x:663,y:507,t:1527023335714};\\\", \\\"{x:661,y:507,t:1527023335731};\\\", \\\"{x:660,y:506,t:1527023335814};\\\", \\\"{x:660,y:505,t:1527023335838};\\\", \\\"{x:660,y:504,t:1527023335848};\\\", \\\"{x:659,y:503,t:1527023335864};\\\", \\\"{x:658,y:503,t:1527023335991};\\\", \\\"{x:656,y:503,t:1527023336014};\\\", \\\"{x:654,y:503,t:1527023336031};\\\", \\\"{x:653,y:503,t:1527023336062};\\\", \\\"{x:651,y:503,t:1527023336078};\\\", \\\"{x:650,y:503,t:1527023336102};\\\", \\\"{x:648,y:503,t:1527023336114};\\\", \\\"{x:647,y:503,t:1527023336134};\\\", \\\"{x:647,y:504,t:1527023337295};\\\", \\\"{x:650,y:505,t:1527023337302};\\\", \\\"{x:652,y:506,t:1527023337316};\\\", \\\"{x:656,y:506,t:1527023337332};\\\", \\\"{x:659,y:508,t:1527023337349};\\\", \\\"{x:660,y:508,t:1527023337366};\\\", \\\"{x:662,y:508,t:1527023337382};\\\", \\\"{x:663,y:509,t:1527023337414};\\\", \\\"{x:664,y:509,t:1527023337439};\\\", \\\"{x:665,y:510,t:1527023337463};\\\", \\\"{x:667,y:510,t:1527023337478};\\\", \\\"{x:668,y:510,t:1527023337519};\\\", \\\"{x:668,y:511,t:1527023337534};\\\", \\\"{x:669,y:511,t:1527023337549};\\\", \\\"{x:670,y:511,t:1527023337566};\\\", \\\"{x:673,y:512,t:1527023337582};\\\", \\\"{x:674,y:512,t:1527023337600};\\\", \\\"{x:676,y:513,t:1527023337617};\\\", \\\"{x:680,y:513,t:1527023337632};\\\", \\\"{x:680,y:514,t:1527023337649};\\\", \\\"{x:682,y:515,t:1527023337667};\\\", \\\"{x:683,y:515,t:1527023337686};\\\", \\\"{x:684,y:515,t:1527023337699};\\\", \\\"{x:688,y:515,t:1527023337716};\\\", \\\"{x:690,y:515,t:1527023337733};\\\", \\\"{x:693,y:516,t:1527023337748};\\\", \\\"{x:698,y:517,t:1527023337766};\\\", \\\"{x:703,y:518,t:1527023337782};\\\", \\\"{x:705,y:518,t:1527023337799};\\\", \\\"{x:707,y:518,t:1527023337816};\\\", \\\"{x:710,y:518,t:1527023337832};\\\", \\\"{x:711,y:519,t:1527023337849};\\\", \\\"{x:718,y:520,t:1527023337865};\\\", \\\"{x:723,y:521,t:1527023337883};\\\", \\\"{x:732,y:524,t:1527023337899};\\\", \\\"{x:742,y:526,t:1527023337916};\\\", \\\"{x:754,y:528,t:1527023337933};\\\", \\\"{x:771,y:531,t:1527023337949};\\\", \\\"{x:798,y:534,t:1527023337965};\\\", \\\"{x:813,y:537,t:1527023337983};\\\", \\\"{x:821,y:538,t:1527023337999};\\\", \\\"{x:823,y:538,t:1527023338016};\\\", \\\"{x:827,y:538,t:1527023338033};\\\", \\\"{x:828,y:539,t:1527023338049};\\\", \\\"{x:832,y:540,t:1527023338066};\\\", \\\"{x:840,y:541,t:1527023338083};\\\", \\\"{x:847,y:542,t:1527023338099};\\\", \\\"{x:851,y:542,t:1527023338116};\\\", \\\"{x:857,y:542,t:1527023338133};\\\", \\\"{x:862,y:542,t:1527023338149};\\\", \\\"{x:870,y:542,t:1527023338167};\\\", \\\"{x:873,y:542,t:1527023338183};\\\", \\\"{x:876,y:542,t:1527023338199};\\\", \\\"{x:877,y:542,t:1527023338221};\\\", \\\"{x:879,y:542,t:1527023338233};\\\", \\\"{x:880,y:541,t:1527023338250};\\\", \\\"{x:880,y:540,t:1527023338278};\\\", \\\"{x:881,y:538,t:1527023338286};\\\", \\\"{x:881,y:537,t:1527023338302};\\\", \\\"{x:881,y:535,t:1527023338315};\\\", \\\"{x:878,y:533,t:1527023338334};\\\", \\\"{x:866,y:528,t:1527023338351};\\\", \\\"{x:858,y:525,t:1527023338366};\\\", \\\"{x:848,y:524,t:1527023338383};\\\", \\\"{x:838,y:522,t:1527023338400};\\\", \\\"{x:833,y:522,t:1527023338416};\\\", \\\"{x:829,y:521,t:1527023338434};\\\", \\\"{x:828,y:521,t:1527023338450};\\\", \\\"{x:825,y:520,t:1527023338466};\\\", \\\"{x:823,y:520,t:1527023338483};\\\", \\\"{x:818,y:518,t:1527023338500};\\\", \\\"{x:813,y:517,t:1527023338516};\\\", \\\"{x:801,y:516,t:1527023338533};\\\", \\\"{x:779,y:512,t:1527023338549};\\\", \\\"{x:762,y:509,t:1527023338566};\\\", \\\"{x:746,y:507,t:1527023338583};\\\", \\\"{x:734,y:503,t:1527023338600};\\\", \\\"{x:722,y:500,t:1527023338617};\\\", \\\"{x:713,y:497,t:1527023338633};\\\", \\\"{x:704,y:494,t:1527023338650};\\\", \\\"{x:691,y:491,t:1527023338666};\\\", \\\"{x:679,y:488,t:1527023338684};\\\", \\\"{x:667,y:487,t:1527023338700};\\\", \\\"{x:656,y:484,t:1527023338716};\\\", \\\"{x:649,y:483,t:1527023338734};\\\", \\\"{x:641,y:482,t:1527023338750};\\\", \\\"{x:638,y:482,t:1527023338766};\\\", \\\"{x:637,y:482,t:1527023338783};\\\", \\\"{x:635,y:482,t:1527023338800};\\\", \\\"{x:634,y:482,t:1527023338816};\\\", \\\"{x:632,y:482,t:1527023338833};\\\", \\\"{x:631,y:482,t:1527023338850};\\\", \\\"{x:627,y:482,t:1527023338867};\\\", \\\"{x:620,y:484,t:1527023338884};\\\", \\\"{x:614,y:485,t:1527023338900};\\\", \\\"{x:612,y:486,t:1527023338918};\\\", \\\"{x:608,y:489,t:1527023338933};\\\", \\\"{x:599,y:494,t:1527023338950};\\\", \\\"{x:592,y:496,t:1527023338966};\\\", \\\"{x:587,y:497,t:1527023338983};\\\", \\\"{x:573,y:498,t:1527023339000};\\\", \\\"{x:551,y:500,t:1527023339017};\\\", \\\"{x:528,y:500,t:1527023339033};\\\", \\\"{x:501,y:502,t:1527023339050};\\\", \\\"{x:465,y:502,t:1527023339067};\\\", \\\"{x:438,y:504,t:1527023339084};\\\", \\\"{x:412,y:507,t:1527023339100};\\\", \\\"{x:394,y:509,t:1527023339117};\\\", \\\"{x:389,y:512,t:1527023339132};\\\", \\\"{x:387,y:513,t:1527023339150};\\\", \\\"{x:385,y:514,t:1527023339174};\\\", \\\"{x:385,y:515,t:1527023339214};\\\", \\\"{x:384,y:516,t:1527023339222};\\\", \\\"{x:384,y:518,t:1527023339239};\\\", \\\"{x:384,y:519,t:1527023339254};\\\", \\\"{x:384,y:520,t:1527023339267};\\\", \\\"{x:384,y:521,t:1527023339284};\\\", \\\"{x:384,y:523,t:1527023339300};\\\", \\\"{x:385,y:524,t:1527023339317};\\\", \\\"{x:387,y:525,t:1527023339334};\\\", \\\"{x:389,y:525,t:1527023339350};\\\", \\\"{x:391,y:525,t:1527023339367};\\\", \\\"{x:394,y:525,t:1527023339384};\\\", \\\"{x:397,y:525,t:1527023339400};\\\", \\\"{x:399,y:525,t:1527023339417};\\\", \\\"{x:402,y:525,t:1527023339434};\\\", \\\"{x:403,y:525,t:1527023339450};\\\", \\\"{x:409,y:525,t:1527023339467};\\\", \\\"{x:416,y:525,t:1527023339484};\\\", \\\"{x:423,y:525,t:1527023339500};\\\", \\\"{x:432,y:526,t:1527023339517};\\\", \\\"{x:441,y:526,t:1527023339534};\\\", \\\"{x:445,y:526,t:1527023339550};\\\", \\\"{x:449,y:526,t:1527023339567};\\\", \\\"{x:454,y:526,t:1527023339584};\\\", \\\"{x:460,y:526,t:1527023339600};\\\", \\\"{x:473,y:526,t:1527023339617};\\\", \\\"{x:484,y:526,t:1527023339635};\\\", \\\"{x:496,y:526,t:1527023339650};\\\", \\\"{x:501,y:526,t:1527023339667};\\\", \\\"{x:504,y:526,t:1527023339684};\\\", \\\"{x:505,y:526,t:1527023339700};\\\", \\\"{x:506,y:526,t:1527023339718};\\\", \\\"{x:507,y:526,t:1527023339734};\\\", \\\"{x:508,y:526,t:1527023339967};\\\", \\\"{x:509,y:525,t:1527023342055};\\\", \\\"{x:510,y:525,t:1527023342095};\\\", \\\"{x:511,y:525,t:1527023342159};\\\", \\\"{x:512,y:525,t:1527023342207};\\\", \\\"{x:513,y:525,t:1527023342247};\\\", \\\"{x:514,y:525,t:1527023342279};\\\", \\\"{x:515,y:525,t:1527023342287};\\\", \\\"{x:519,y:525,t:1527023342303};\\\", \\\"{x:523,y:525,t:1527023342319};\\\", \\\"{x:529,y:525,t:1527023342337};\\\", \\\"{x:541,y:527,t:1527023342353};\\\", \\\"{x:556,y:529,t:1527023342371};\\\", \\\"{x:578,y:532,t:1527023342386};\\\", \\\"{x:601,y:532,t:1527023342402};\\\", \\\"{x:623,y:532,t:1527023342419};\\\", \\\"{x:638,y:532,t:1527023342436};\\\", \\\"{x:651,y:530,t:1527023342453};\\\", \\\"{x:665,y:528,t:1527023342470};\\\", \\\"{x:670,y:526,t:1527023342486};\\\", \\\"{x:674,y:525,t:1527023342503};\\\", \\\"{x:677,y:525,t:1527023342520};\\\", \\\"{x:681,y:525,t:1527023342536};\\\", \\\"{x:683,y:525,t:1527023342553};\\\", \\\"{x:684,y:525,t:1527023342670};\\\", \\\"{x:684,y:526,t:1527023342694};\\\", \\\"{x:679,y:529,t:1527023342720};\\\", \\\"{x:675,y:529,t:1527023342736};\\\", \\\"{x:667,y:530,t:1527023342753};\\\", \\\"{x:661,y:530,t:1527023342770};\\\", \\\"{x:655,y:531,t:1527023342787};\\\", \\\"{x:652,y:532,t:1527023342803};\\\", \\\"{x:650,y:532,t:1527023342820};\\\", \\\"{x:649,y:532,t:1527023342837};\\\", \\\"{x:647,y:533,t:1527023342854};\\\", \\\"{x:645,y:533,t:1527023342870};\\\", \\\"{x:642,y:534,t:1527023342887};\\\", \\\"{x:641,y:534,t:1527023342904};\\\", \\\"{x:639,y:534,t:1527023342920};\\\", \\\"{x:637,y:534,t:1527023342936};\\\", \\\"{x:633,y:534,t:1527023342953};\\\", \\\"{x:631,y:534,t:1527023342970};\\\", \\\"{x:629,y:534,t:1527023342986};\\\", \\\"{x:627,y:534,t:1527023343003};\\\", \\\"{x:625,y:534,t:1527023343020};\\\", \\\"{x:623,y:534,t:1527023343036};\\\", \\\"{x:622,y:534,t:1527023343053};\\\", \\\"{x:620,y:534,t:1527023343070};\\\", \\\"{x:619,y:534,t:1527023343094};\\\", \\\"{x:618,y:534,t:1527023343103};\\\", \\\"{x:617,y:534,t:1527023343121};\\\", \\\"{x:616,y:534,t:1527023343142};\\\", \\\"{x:615,y:534,t:1527023343166};\\\", \\\"{x:614,y:534,t:1527023343239};\\\", \\\"{x:613,y:536,t:1527023343725};\\\", \\\"{x:613,y:539,t:1527023343737};\\\", \\\"{x:612,y:543,t:1527023343754};\\\", \\\"{x:612,y:548,t:1527023343770};\\\", \\\"{x:615,y:552,t:1527023343787};\\\", \\\"{x:619,y:557,t:1527023343805};\\\", \\\"{x:620,y:559,t:1527023343820};\\\", \\\"{x:623,y:562,t:1527023343837};\\\", \\\"{x:625,y:564,t:1527023343854};\\\", \\\"{x:625,y:565,t:1527023343870};\\\", \\\"{x:626,y:569,t:1527023343887};\\\", \\\"{x:629,y:576,t:1527023343904};\\\", \\\"{x:629,y:582,t:1527023343921};\\\", \\\"{x:628,y:589,t:1527023343937};\\\", \\\"{x:625,y:594,t:1527023343954};\\\", \\\"{x:622,y:597,t:1527023343971};\\\", \\\"{x:620,y:599,t:1527023343988};\\\", \\\"{x:618,y:600,t:1527023344004};\\\", \\\"{x:613,y:603,t:1527023344021};\\\", \\\"{x:606,y:607,t:1527023344037};\\\", \\\"{x:592,y:614,t:1527023344054};\\\", \\\"{x:580,y:619,t:1527023344072};\\\", \\\"{x:573,y:622,t:1527023344088};\\\", \\\"{x:568,y:625,t:1527023344105};\\\", \\\"{x:565,y:627,t:1527023344121};\\\", \\\"{x:561,y:629,t:1527023344138};\\\", \\\"{x:552,y:634,t:1527023344154};\\\", \\\"{x:536,y:640,t:1527023344171};\\\", \\\"{x:516,y:649,t:1527023344188};\\\", \\\"{x:495,y:658,t:1527023344204};\\\", \\\"{x:474,y:667,t:1527023344221};\\\", \\\"{x:459,y:674,t:1527023344238};\\\", \\\"{x:454,y:679,t:1527023344254};\\\", \\\"{x:453,y:680,t:1527023344272};\\\", \\\"{x:452,y:681,t:1527023344288};\\\", \\\"{x:452,y:682,t:1527023344388};\\\", \\\"{x:452,y:682,t:1527023344462};\\\", \\\"{x:453,y:681,t:1527023344728};\\\", \\\"{x:454,y:681,t:1527023344738};\\\", \\\"{x:456,y:680,t:1527023344755};\\\", \\\"{x:459,y:678,t:1527023344771};\\\", \\\"{x:462,y:675,t:1527023344788};\\\", \\\"{x:463,y:674,t:1527023344806};\\\", \\\"{x:463,y:673,t:1527023344821};\\\", \\\"{x:463,y:671,t:1527023345710};\\\", \\\"{x:464,y:668,t:1527023345722};\\\", \\\"{x:464,y:664,t:1527023345739};\\\", \\\"{x:466,y:662,t:1527023345755};\\\", \\\"{x:466,y:659,t:1527023345772};\\\", \\\"{x:466,y:657,t:1527023345790};\\\", \\\"{x:467,y:652,t:1527023345805};\\\", \\\"{x:468,y:649,t:1527023345822};\\\", \\\"{x:468,y:648,t:1527023345846};\\\", \\\"{x:469,y:648,t:1527023345862};\\\", \\\"{x:469,y:646,t:1527023345894};\\\", \\\"{x:469,y:645,t:1527023345926};\\\", \\\"{x:470,y:642,t:1527023345942};\\\", \\\"{x:471,y:641,t:1527023345958};\\\", \\\"{x:472,y:639,t:1527023345990};\\\", \\\"{x:473,y:638,t:1527023346006};\\\", \\\"{x:473,y:637,t:1527023346023};\\\", \\\"{x:473,y:636,t:1527023346039};\\\", \\\"{x:473,y:635,t:1527023346056};\\\", \\\"{x:473,y:633,t:1527023346072};\\\", \\\"{x:474,y:630,t:1527023346089};\\\", \\\"{x:476,y:626,t:1527023346105};\\\", \\\"{x:476,y:623,t:1527023346123};\\\", \\\"{x:477,y:618,t:1527023346139};\\\", \\\"{x:478,y:615,t:1527023346157};\\\", \\\"{x:480,y:611,t:1527023346173};\\\", \\\"{x:481,y:606,t:1527023346190};\\\", \\\"{x:481,y:601,t:1527023346206};\\\", \\\"{x:484,y:598,t:1527023346227};\\\", \\\"{x:484,y:593,t:1527023346239};\\\", \\\"{x:485,y:589,t:1527023346256};\\\", \\\"{x:487,y:584,t:1527023346272};\\\", \\\"{x:487,y:582,t:1527023346289};\\\", \\\"{x:488,y:580,t:1527023346306};\\\", \\\"{x:490,y:577,t:1527023346322};\\\", \\\"{x:490,y:574,t:1527023346339};\\\", \\\"{x:492,y:571,t:1527023346357};\\\", \\\"{x:492,y:568,t:1527023346373};\\\", \\\"{x:492,y:564,t:1527023346389};\\\", \\\"{x:494,y:557,t:1527023346405};\\\" ] }, { \\\"rt\\\": 7214, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 410668, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"JYZGH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"C\\\", \\\"Z\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:495,y:539,t:1527023346521};\\\", \\\"{x:495,y:536,t:1527023346539};\\\", \\\"{x:495,y:534,t:1527023346556};\\\", \\\"{x:494,y:530,t:1527023346573};\\\", \\\"{x:492,y:527,t:1527023346588};\\\", \\\"{x:491,y:526,t:1527023346606};\\\", \\\"{x:491,y:525,t:1527023346626};\\\", \\\"{x:491,y:524,t:1527023346639};\\\", \\\"{x:490,y:523,t:1527023346656};\\\", \\\"{x:490,y:522,t:1527023346710};\\\", \\\"{x:489,y:521,t:1527023346723};\\\", \\\"{x:483,y:521,t:1527023347054};\\\", \\\"{x:473,y:521,t:1527023347062};\\\", \\\"{x:461,y:521,t:1527023347074};\\\", \\\"{x:433,y:520,t:1527023347090};\\\", \\\"{x:397,y:515,t:1527023347107};\\\", \\\"{x:372,y:512,t:1527023347125};\\\", \\\"{x:353,y:509,t:1527023347140};\\\", \\\"{x:340,y:507,t:1527023347157};\\\", \\\"{x:337,y:506,t:1527023347173};\\\", \\\"{x:333,y:503,t:1527023347190};\\\", \\\"{x:329,y:501,t:1527023347207};\\\", \\\"{x:321,y:497,t:1527023347224};\\\", \\\"{x:314,y:494,t:1527023347240};\\\", \\\"{x:311,y:490,t:1527023347256};\\\", \\\"{x:309,y:489,t:1527023347273};\\\", \\\"{x:308,y:488,t:1527023347293};\\\", \\\"{x:307,y:488,t:1527023347310};\\\", \\\"{x:306,y:488,t:1527023347323};\\\", \\\"{x:305,y:487,t:1527023347340};\\\", \\\"{x:303,y:486,t:1527023347357};\\\", \\\"{x:303,y:485,t:1527023347374};\\\", \\\"{x:301,y:484,t:1527023347390};\\\", \\\"{x:300,y:483,t:1527023347454};\\\", \\\"{x:299,y:482,t:1527023347551};\\\", \\\"{x:298,y:482,t:1527023347567};\\\", \\\"{x:298,y:481,t:1527023347615};\\\", \\\"{x:297,y:481,t:1527023347951};\\\", \\\"{x:296,y:481,t:1527023348207};\\\", \\\"{x:297,y:480,t:1527023348254};\\\", \\\"{x:298,y:480,t:1527023348262};\\\", \\\"{x:301,y:480,t:1527023348274};\\\", \\\"{x:306,y:480,t:1527023348292};\\\", \\\"{x:313,y:480,t:1527023348308};\\\", \\\"{x:321,y:481,t:1527023348324};\\\", \\\"{x:328,y:481,t:1527023348342};\\\", \\\"{x:335,y:483,t:1527023348357};\\\", \\\"{x:341,y:484,t:1527023348375};\\\", \\\"{x:345,y:485,t:1527023348392};\\\", \\\"{x:348,y:485,t:1527023348408};\\\", \\\"{x:350,y:486,t:1527023348425};\\\", \\\"{x:351,y:486,t:1527023348441};\\\", \\\"{x:352,y:486,t:1527023348462};\\\", \\\"{x:352,y:487,t:1527023348526};\\\", \\\"{x:351,y:488,t:1527023348542};\\\", \\\"{x:349,y:490,t:1527023348558};\\\", \\\"{x:341,y:491,t:1527023348575};\\\", \\\"{x:332,y:492,t:1527023348592};\\\", \\\"{x:317,y:494,t:1527023348608};\\\", \\\"{x:298,y:494,t:1527023348625};\\\", \\\"{x:287,y:494,t:1527023348642};\\\", \\\"{x:273,y:494,t:1527023348659};\\\", \\\"{x:267,y:493,t:1527023348677};\\\", \\\"{x:260,y:493,t:1527023348691};\\\", \\\"{x:258,y:492,t:1527023348709};\\\", \\\"{x:255,y:491,t:1527023348724};\\\", \\\"{x:248,y:491,t:1527023348742};\\\", \\\"{x:244,y:491,t:1527023348758};\\\", \\\"{x:237,y:491,t:1527023348774};\\\", \\\"{x:231,y:491,t:1527023348791};\\\", \\\"{x:221,y:491,t:1527023348809};\\\", \\\"{x:201,y:493,t:1527023348824};\\\", \\\"{x:186,y:493,t:1527023348841};\\\", \\\"{x:174,y:493,t:1527023348858};\\\", \\\"{x:168,y:495,t:1527023348874};\\\", \\\"{x:165,y:495,t:1527023348892};\\\", \\\"{x:162,y:491,t:1527023348909};\\\", \\\"{x:162,y:492,t:1527023350214};\\\", \\\"{x:163,y:496,t:1527023350226};\\\", \\\"{x:165,y:500,t:1527023350243};\\\", \\\"{x:165,y:504,t:1527023350260};\\\", \\\"{x:165,y:507,t:1527023350276};\\\", \\\"{x:166,y:513,t:1527023350292};\\\", \\\"{x:167,y:517,t:1527023350309};\\\", \\\"{x:167,y:519,t:1527023350325};\\\", \\\"{x:167,y:524,t:1527023350343};\\\", \\\"{x:167,y:527,t:1527023350360};\\\", \\\"{x:168,y:532,t:1527023350377};\\\", \\\"{x:169,y:535,t:1527023350392};\\\", \\\"{x:169,y:536,t:1527023350410};\\\", \\\"{x:169,y:537,t:1527023350686};\\\", \\\"{x:169,y:538,t:1527023350830};\\\", \\\"{x:167,y:538,t:1527023350843};\\\", \\\"{x:163,y:537,t:1527023350860};\\\", \\\"{x:161,y:534,t:1527023350878};\\\", \\\"{x:158,y:532,t:1527023350893};\\\", \\\"{x:158,y:531,t:1527023350910};\\\", \\\"{x:158,y:529,t:1527023350934};\\\", \\\"{x:158,y:528,t:1527023350950};\\\", \\\"{x:157,y:527,t:1527023350966};\\\", \\\"{x:157,y:529,t:1527023351205};\\\", \\\"{x:157,y:532,t:1527023351214};\\\", \\\"{x:158,y:534,t:1527023351226};\\\", \\\"{x:158,y:536,t:1527023351244};\\\", \\\"{x:159,y:539,t:1527023351259};\\\", \\\"{x:159,y:541,t:1527023351276};\\\", \\\"{x:159,y:542,t:1527023351293};\\\", \\\"{x:160,y:543,t:1527023351311};\\\", \\\"{x:161,y:544,t:1527023351358};\\\", \\\"{x:161,y:545,t:1527023351374};\\\", \\\"{x:161,y:546,t:1527023351408};\\\", \\\"{x:161,y:547,t:1527023351426};\\\", \\\"{x:161,y:548,t:1527023351461};\\\", \\\"{x:165,y:550,t:1527023351990};\\\", \\\"{x:174,y:553,t:1527023351998};\\\", \\\"{x:181,y:555,t:1527023352010};\\\", \\\"{x:200,y:563,t:1527023352028};\\\", \\\"{x:228,y:571,t:1527023352044};\\\", \\\"{x:266,y:579,t:1527023352061};\\\", \\\"{x:307,y:596,t:1527023352078};\\\", \\\"{x:331,y:604,t:1527023352095};\\\", \\\"{x:358,y:615,t:1527023352111};\\\", \\\"{x:375,y:624,t:1527023352128};\\\", \\\"{x:411,y:632,t:1527023352145};\\\", \\\"{x:447,y:647,t:1527023352160};\\\", \\\"{x:462,y:653,t:1527023352178};\\\", \\\"{x:475,y:656,t:1527023352195};\\\", \\\"{x:487,y:661,t:1527023352210};\\\", \\\"{x:490,y:663,t:1527023352229};\\\", \\\"{x:492,y:664,t:1527023352244};\\\", \\\"{x:493,y:664,t:1527023352334};\\\", \\\"{x:494,y:664,t:1527023352358};\\\", \\\"{x:495,y:664,t:1527023352823};\\\", \\\"{x:496,y:664,t:1527023352830};\\\", \\\"{x:497,y:666,t:1527023352844};\\\", \\\"{x:497,y:667,t:1527023352861};\\\", \\\"{x:500,y:672,t:1527023352878};\\\", \\\"{x:501,y:672,t:1527023352894};\\\", \\\"{x:503,y:673,t:1527023352911};\\\" ] }, { \\\"rt\\\": 5649, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 417655, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"JYZGH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"X\\\", \\\"D\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:503,y:672,t:1527023355454};\\\", \\\"{x:503,y:671,t:1527023355518};\\\", \\\"{x:503,y:670,t:1527023356134};\\\", \\\"{x:501,y:669,t:1527023356431};\\\", \\\"{x:501,y:667,t:1527023356448};\\\", \\\"{x:497,y:662,t:1527023356467};\\\", \\\"{x:494,y:658,t:1527023356481};\\\", \\\"{x:490,y:653,t:1527023356497};\\\", \\\"{x:483,y:644,t:1527023356515};\\\", \\\"{x:477,y:638,t:1527023356531};\\\", \\\"{x:475,y:634,t:1527023356547};\\\", \\\"{x:472,y:631,t:1527023356564};\\\", \\\"{x:471,y:630,t:1527023356581};\\\", \\\"{x:470,y:628,t:1527023356597};\\\", \\\"{x:469,y:627,t:1527023356621};\\\", \\\"{x:468,y:626,t:1527023356630};\\\", \\\"{x:467,y:624,t:1527023356648};\\\", \\\"{x:466,y:621,t:1527023356665};\\\", \\\"{x:465,y:618,t:1527023356680};\\\", \\\"{x:463,y:614,t:1527023356699};\\\", \\\"{x:461,y:611,t:1527023356715};\\\", \\\"{x:460,y:608,t:1527023356730};\\\", \\\"{x:459,y:606,t:1527023356748};\\\", \\\"{x:456,y:601,t:1527023356765};\\\", \\\"{x:455,y:598,t:1527023356781};\\\", \\\"{x:450,y:591,t:1527023356798};\\\", \\\"{x:447,y:586,t:1527023356815};\\\", \\\"{x:445,y:582,t:1527023356832};\\\", \\\"{x:443,y:579,t:1527023356847};\\\", \\\"{x:440,y:574,t:1527023356865};\\\", \\\"{x:438,y:569,t:1527023356882};\\\", \\\"{x:434,y:563,t:1527023356898};\\\", \\\"{x:432,y:559,t:1527023356915};\\\", \\\"{x:426,y:554,t:1527023356931};\\\", \\\"{x:424,y:552,t:1527023356948};\\\", \\\"{x:422,y:550,t:1527023356964};\\\", \\\"{x:421,y:547,t:1527023356983};\\\", \\\"{x:420,y:547,t:1527023356998};\\\", \\\"{x:418,y:546,t:1527023357023};\\\", \\\"{x:417,y:546,t:1527023357095};\\\", \\\"{x:416,y:546,t:1527023357118};\\\", \\\"{x:415,y:546,t:1527023357175};\\\", \\\"{x:413,y:546,t:1527023357182};\\\", \\\"{x:412,y:546,t:1527023357199};\\\", \\\"{x:409,y:548,t:1527023357215};\\\", \\\"{x:409,y:550,t:1527023357232};\\\", \\\"{x:407,y:552,t:1527023357249};\\\", \\\"{x:406,y:554,t:1527023357264};\\\", \\\"{x:405,y:556,t:1527023357281};\\\", \\\"{x:403,y:558,t:1527023357298};\\\", \\\"{x:402,y:560,t:1527023357315};\\\", \\\"{x:401,y:562,t:1527023357332};\\\", \\\"{x:399,y:563,t:1527023357348};\\\", \\\"{x:398,y:565,t:1527023357364};\\\", \\\"{x:394,y:568,t:1527023357382};\\\", \\\"{x:393,y:571,t:1527023357399};\\\", \\\"{x:392,y:572,t:1527023357415};\\\", \\\"{x:391,y:575,t:1527023357433};\\\", \\\"{x:390,y:577,t:1527023357448};\\\", \\\"{x:388,y:580,t:1527023357465};\\\", \\\"{x:387,y:584,t:1527023357481};\\\", \\\"{x:386,y:585,t:1527023357498};\\\", \\\"{x:386,y:588,t:1527023357515};\\\", \\\"{x:385,y:589,t:1527023357532};\\\", \\\"{x:385,y:591,t:1527023357548};\\\", \\\"{x:384,y:592,t:1527023357565};\\\", \\\"{x:384,y:594,t:1527023357581};\\\", \\\"{x:384,y:595,t:1527023357598};\\\", \\\"{x:386,y:596,t:1527023357997};\\\", \\\"{x:399,y:595,t:1527023358005};\\\", \\\"{x:418,y:592,t:1527023358016};\\\", \\\"{x:457,y:587,t:1527023358032};\\\", \\\"{x:480,y:584,t:1527023358049};\\\", \\\"{x:496,y:580,t:1527023358065};\\\", \\\"{x:504,y:576,t:1527023358084};\\\", \\\"{x:510,y:573,t:1527023358098};\\\", \\\"{x:515,y:572,t:1527023358116};\\\", \\\"{x:516,y:571,t:1527023358133};\\\", \\\"{x:520,y:570,t:1527023358149};\\\", \\\"{x:524,y:569,t:1527023358165};\\\", \\\"{x:527,y:568,t:1527023358183};\\\", \\\"{x:530,y:568,t:1527023358199};\\\", \\\"{x:534,y:565,t:1527023358216};\\\", \\\"{x:539,y:561,t:1527023358233};\\\", \\\"{x:546,y:556,t:1527023358248};\\\", \\\"{x:553,y:552,t:1527023358265};\\\", \\\"{x:558,y:549,t:1527023358283};\\\", \\\"{x:565,y:545,t:1527023358299};\\\", \\\"{x:574,y:541,t:1527023358316};\\\", \\\"{x:590,y:535,t:1527023358333};\\\", \\\"{x:605,y:533,t:1527023358349};\\\", \\\"{x:621,y:528,t:1527023358365};\\\", \\\"{x:636,y:524,t:1527023358383};\\\", \\\"{x:643,y:521,t:1527023358400};\\\", \\\"{x:649,y:519,t:1527023358415};\\\", \\\"{x:651,y:519,t:1527023358433};\\\", \\\"{x:652,y:519,t:1527023358449};\\\", \\\"{x:649,y:520,t:1527023358598};\\\", \\\"{x:646,y:521,t:1527023358606};\\\", \\\"{x:642,y:522,t:1527023358618};\\\", \\\"{x:637,y:524,t:1527023358632};\\\", \\\"{x:633,y:524,t:1527023358650};\\\", \\\"{x:632,y:524,t:1527023358666};\\\", \\\"{x:629,y:525,t:1527023358909};\\\", \\\"{x:628,y:525,t:1527023358925};\\\", \\\"{x:626,y:525,t:1527023358933};\\\", \\\"{x:622,y:525,t:1527023358949};\\\", \\\"{x:620,y:525,t:1527023358967};\\\", \\\"{x:617,y:525,t:1527023359245};\\\", \\\"{x:611,y:522,t:1527023359253};\\\", \\\"{x:601,y:518,t:1527023359266};\\\", \\\"{x:577,y:508,t:1527023359284};\\\", \\\"{x:535,y:496,t:1527023359300};\\\", \\\"{x:503,y:485,t:1527023359317};\\\", \\\"{x:476,y:475,t:1527023359334};\\\", \\\"{x:455,y:470,t:1527023359350};\\\", \\\"{x:450,y:468,t:1527023359367};\\\", \\\"{x:446,y:468,t:1527023359383};\\\", \\\"{x:442,y:467,t:1527023359400};\\\", \\\"{x:439,y:466,t:1527023359416};\\\", \\\"{x:436,y:464,t:1527023359435};\\\", \\\"{x:435,y:464,t:1527023359450};\\\", \\\"{x:434,y:464,t:1527023359466};\\\", \\\"{x:433,y:464,t:1527023359483};\\\", \\\"{x:432,y:464,t:1527023359509};\\\", \\\"{x:431,y:464,t:1527023359526};\\\", \\\"{x:429,y:464,t:1527023359533};\\\", \\\"{x:426,y:464,t:1527023359549};\\\", \\\"{x:423,y:467,t:1527023359567};\\\", \\\"{x:418,y:469,t:1527023359583};\\\", \\\"{x:413,y:472,t:1527023359601};\\\", \\\"{x:410,y:474,t:1527023359616};\\\", \\\"{x:405,y:475,t:1527023359634};\\\", \\\"{x:401,y:476,t:1527023359651};\\\", \\\"{x:399,y:476,t:1527023359667};\\\", \\\"{x:397,y:476,t:1527023359683};\\\", \\\"{x:396,y:477,t:1527023359700};\\\", \\\"{x:395,y:478,t:1527023359717};\\\", \\\"{x:392,y:479,t:1527023359734};\\\", \\\"{x:390,y:481,t:1527023359749};\\\", \\\"{x:387,y:482,t:1527023359767};\\\", \\\"{x:381,y:485,t:1527023359785};\\\", \\\"{x:379,y:485,t:1527023359800};\\\", \\\"{x:378,y:486,t:1527023359817};\\\", \\\"{x:377,y:487,t:1527023359900};\\\", \\\"{x:377,y:487,t:1527023359986};\\\", \\\"{x:375,y:488,t:1527023360034};\\\", \\\"{x:374,y:489,t:1527023360050};\\\", \\\"{x:374,y:492,t:1527023360067};\\\", \\\"{x:375,y:497,t:1527023360083};\\\", \\\"{x:388,y:507,t:1527023360101};\\\", \\\"{x:400,y:518,t:1527023360117};\\\", \\\"{x:417,y:542,t:1527023360135};\\\", \\\"{x:429,y:561,t:1527023360152};\\\", \\\"{x:442,y:581,t:1527023360167};\\\", \\\"{x:455,y:600,t:1527023360185};\\\", \\\"{x:466,y:619,t:1527023360201};\\\", \\\"{x:476,y:636,t:1527023360217};\\\", \\\"{x:482,y:647,t:1527023360234};\\\", \\\"{x:491,y:665,t:1527023360251};\\\", \\\"{x:499,y:675,t:1527023360268};\\\", \\\"{x:504,y:682,t:1527023360283};\\\", \\\"{x:505,y:684,t:1527023360300};\\\" ] }, { \\\"rt\\\": 13046, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 431977, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"JYZGH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"J\\\", \\\"A\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:505,y:683,t:1527023362037};\\\", \\\"{x:507,y:681,t:1527023362537};\\\", \\\"{x:509,y:681,t:1527023362553};\\\", \\\"{x:510,y:679,t:1527023362561};\\\", \\\"{x:512,y:678,t:1527023362574};\\\", \\\"{x:518,y:674,t:1527023362590};\\\", \\\"{x:524,y:669,t:1527023362607};\\\", \\\"{x:529,y:666,t:1527023362624};\\\", \\\"{x:534,y:661,t:1527023362641};\\\", \\\"{x:540,y:655,t:1527023362657};\\\", \\\"{x:542,y:653,t:1527023362673};\\\", \\\"{x:555,y:645,t:1527023362690};\\\", \\\"{x:565,y:640,t:1527023362707};\\\", \\\"{x:578,y:634,t:1527023362724};\\\", \\\"{x:585,y:626,t:1527023362740};\\\", \\\"{x:601,y:620,t:1527023362757};\\\", \\\"{x:615,y:614,t:1527023362773};\\\", \\\"{x:625,y:609,t:1527023362789};\\\", \\\"{x:640,y:606,t:1527023362806};\\\", \\\"{x:652,y:601,t:1527023362824};\\\", \\\"{x:663,y:597,t:1527023362840};\\\", \\\"{x:681,y:592,t:1527023362857};\\\", \\\"{x:707,y:588,t:1527023362873};\\\", \\\"{x:724,y:586,t:1527023362890};\\\", \\\"{x:744,y:584,t:1527023362907};\\\", \\\"{x:767,y:584,t:1527023362924};\\\", \\\"{x:791,y:581,t:1527023362940};\\\", \\\"{x:818,y:581,t:1527023362957};\\\", \\\"{x:849,y:581,t:1527023362973};\\\", \\\"{x:874,y:581,t:1527023362990};\\\", \\\"{x:899,y:581,t:1527023363007};\\\", \\\"{x:919,y:581,t:1527023363024};\\\", \\\"{x:932,y:581,t:1527023363040};\\\", \\\"{x:942,y:581,t:1527023363056};\\\", \\\"{x:948,y:581,t:1527023363074};\\\", \\\"{x:949,y:581,t:1527023363106};\\\", \\\"{x:947,y:581,t:1527023363418};\\\", \\\"{x:946,y:581,t:1527023363434};\\\", \\\"{x:945,y:581,t:1527023363442};\\\", \\\"{x:944,y:581,t:1527023363482};\\\", \\\"{x:944,y:582,t:1527023363514};\\\", \\\"{x:943,y:582,t:1527023363618};\\\", \\\"{x:942,y:582,t:1527023363633};\\\", \\\"{x:941,y:582,t:1527023363642};\\\", \\\"{x:940,y:582,t:1527023363666};\\\", \\\"{x:939,y:583,t:1527023363674};\\\", \\\"{x:937,y:583,t:1527023363706};\\\", \\\"{x:937,y:584,t:1527023363738};\\\", \\\"{x:936,y:585,t:1527023363762};\\\", \\\"{x:935,y:585,t:1527023363778};\\\", \\\"{x:934,y:585,t:1527023363801};\\\", \\\"{x:933,y:585,t:1527023363850};\\\", \\\"{x:932,y:585,t:1527023364626};\\\", \\\"{x:930,y:585,t:1527023364850};\\\", \\\"{x:929,y:585,t:1527023364859};\\\", \\\"{x:927,y:584,t:1527023364875};\\\", \\\"{x:924,y:582,t:1527023364892};\\\", \\\"{x:922,y:580,t:1527023364909};\\\", \\\"{x:920,y:578,t:1527023364925};\\\", \\\"{x:917,y:576,t:1527023364941};\\\", \\\"{x:915,y:576,t:1527023365041};\\\", \\\"{x:914,y:576,t:1527023365178};\\\", \\\"{x:913,y:576,t:1527023365355};\\\", \\\"{x:911,y:576,t:1527023365370};\\\", \\\"{x:910,y:576,t:1527023365482};\\\", \\\"{x:908,y:577,t:1527023365530};\\\", \\\"{x:907,y:577,t:1527023365722};\\\", \\\"{x:906,y:577,t:1527023365746};\\\", \\\"{x:904,y:577,t:1527023365759};\\\", \\\"{x:903,y:577,t:1527023365776};\\\", \\\"{x:902,y:577,t:1527023365793};\\\", \\\"{x:901,y:577,t:1527023365810};\\\", \\\"{x:899,y:577,t:1527023365834};\\\", \\\"{x:898,y:576,t:1527023367138};\\\", \\\"{x:896,y:576,t:1527023367242};\\\", \\\"{x:895,y:576,t:1527023367298};\\\", \\\"{x:893,y:576,t:1527023367378};\\\", \\\"{x:890,y:576,t:1527023367393};\\\", \\\"{x:888,y:576,t:1527023367410};\\\", \\\"{x:885,y:576,t:1527023367427};\\\", \\\"{x:883,y:576,t:1527023367444};\\\", \\\"{x:882,y:576,t:1527023367466};\\\", \\\"{x:880,y:576,t:1527023367481};\\\", \\\"{x:879,y:576,t:1527023367674};\\\", \\\"{x:877,y:576,t:1527023367689};\\\", \\\"{x:876,y:576,t:1527023367706};\\\", \\\"{x:874,y:576,t:1527023367722};\\\", \\\"{x:873,y:576,t:1527023367730};\\\", \\\"{x:872,y:576,t:1527023367746};\\\", \\\"{x:871,y:576,t:1527023367762};\\\", \\\"{x:870,y:576,t:1527023367778};\\\", \\\"{x:869,y:576,t:1527023367810};\\\", \\\"{x:867,y:576,t:1527023367858};\\\", \\\"{x:866,y:576,t:1527023367914};\\\", \\\"{x:865,y:576,t:1527023367962};\\\", \\\"{x:864,y:577,t:1527023368514};\\\", \\\"{x:862,y:578,t:1527023368553};\\\", \\\"{x:861,y:578,t:1527023368562};\\\", \\\"{x:857,y:580,t:1527023368579};\\\", \\\"{x:853,y:581,t:1527023368595};\\\", \\\"{x:852,y:581,t:1527023368640};\\\", \\\"{x:851,y:581,t:1527023368649};\\\", \\\"{x:849,y:581,t:1527023368713};\\\", \\\"{x:848,y:581,t:1527023368737};\\\", \\\"{x:847,y:581,t:1527023368745};\\\", \\\"{x:846,y:581,t:1527023368762};\\\", \\\"{x:844,y:583,t:1527023368778};\\\", \\\"{x:842,y:583,t:1527023368795};\\\", \\\"{x:840,y:583,t:1527023368812};\\\", \\\"{x:837,y:583,t:1527023368829};\\\", \\\"{x:830,y:583,t:1527023368845};\\\", \\\"{x:823,y:583,t:1527023368862};\\\", \\\"{x:817,y:583,t:1527023368878};\\\", \\\"{x:809,y:583,t:1527023368896};\\\", \\\"{x:795,y:583,t:1527023368912};\\\", \\\"{x:779,y:580,t:1527023368928};\\\", \\\"{x:766,y:577,t:1527023368946};\\\", \\\"{x:761,y:577,t:1527023368961};\\\", \\\"{x:755,y:577,t:1527023368978};\\\", \\\"{x:744,y:573,t:1527023368995};\\\", \\\"{x:731,y:568,t:1527023369012};\\\", \\\"{x:715,y:562,t:1527023369029};\\\", \\\"{x:707,y:558,t:1527023369045};\\\", \\\"{x:698,y:551,t:1527023369062};\\\", \\\"{x:676,y:538,t:1527023369078};\\\", \\\"{x:650,y:523,t:1527023369095};\\\", \\\"{x:618,y:510,t:1527023369112};\\\", \\\"{x:575,y:497,t:1527023369129};\\\", \\\"{x:533,y:489,t:1527023369144};\\\", \\\"{x:514,y:486,t:1527023369162};\\\", \\\"{x:505,y:484,t:1527023369179};\\\", \\\"{x:500,y:483,t:1527023369194};\\\", \\\"{x:497,y:482,t:1527023369212};\\\", \\\"{x:494,y:481,t:1527023369229};\\\", \\\"{x:491,y:481,t:1527023369245};\\\", \\\"{x:485,y:481,t:1527023369262};\\\", \\\"{x:472,y:478,t:1527023369279};\\\", \\\"{x:465,y:476,t:1527023369295};\\\", \\\"{x:459,y:476,t:1527023369312};\\\", \\\"{x:449,y:475,t:1527023369329};\\\", \\\"{x:448,y:475,t:1527023369344};\\\", \\\"{x:446,y:475,t:1527023369362};\\\", \\\"{x:444,y:475,t:1527023369379};\\\", \\\"{x:442,y:475,t:1527023369395};\\\", \\\"{x:439,y:475,t:1527023369412};\\\", \\\"{x:438,y:475,t:1527023369429};\\\", \\\"{x:435,y:474,t:1527023369445};\\\", \\\"{x:432,y:473,t:1527023369462};\\\", \\\"{x:428,y:472,t:1527023369479};\\\", \\\"{x:425,y:472,t:1527023369495};\\\", \\\"{x:424,y:472,t:1527023369512};\\\", \\\"{x:422,y:472,t:1527023369529};\\\", \\\"{x:421,y:472,t:1527023369545};\\\", \\\"{x:419,y:470,t:1527023369563};\\\", \\\"{x:416,y:468,t:1527023369579};\\\", \\\"{x:411,y:466,t:1527023369595};\\\", \\\"{x:408,y:463,t:1527023369613};\\\", \\\"{x:404,y:461,t:1527023369629};\\\", \\\"{x:400,y:459,t:1527023369646};\\\", \\\"{x:399,y:458,t:1527023369662};\\\", \\\"{x:395,y:456,t:1527023369679};\\\", \\\"{x:392,y:455,t:1527023369696};\\\", \\\"{x:389,y:455,t:1527023369712};\\\", \\\"{x:388,y:455,t:1527023369729};\\\", \\\"{x:387,y:455,t:1527023369898};\\\", \\\"{x:386,y:455,t:1527023370329};\\\", \\\"{x:403,y:459,t:1527023370346};\\\", \\\"{x:431,y:464,t:1527023370363};\\\", \\\"{x:455,y:472,t:1527023370380};\\\", \\\"{x:480,y:478,t:1527023370396};\\\", \\\"{x:503,y:484,t:1527023370414};\\\", \\\"{x:512,y:489,t:1527023370430};\\\", \\\"{x:515,y:490,t:1527023370446};\\\", \\\"{x:516,y:492,t:1527023370463};\\\", \\\"{x:517,y:492,t:1527023370529};\\\", \\\"{x:525,y:495,t:1527023370562};\\\", \\\"{x:531,y:496,t:1527023370568};\\\", \\\"{x:537,y:496,t:1527023370580};\\\", \\\"{x:561,y:501,t:1527023370595};\\\", \\\"{x:593,y:502,t:1527023370613};\\\", \\\"{x:622,y:507,t:1527023370631};\\\", \\\"{x:649,y:509,t:1527023370646};\\\", \\\"{x:670,y:509,t:1527023370663};\\\", \\\"{x:675,y:510,t:1527023370681};\\\", \\\"{x:676,y:510,t:1527023370777};\\\", \\\"{x:675,y:510,t:1527023370809};\\\", \\\"{x:671,y:509,t:1527023370818};\\\", \\\"{x:668,y:507,t:1527023370830};\\\", \\\"{x:661,y:503,t:1527023370847};\\\", \\\"{x:658,y:502,t:1527023370863};\\\", \\\"{x:654,y:500,t:1527023370880};\\\", \\\"{x:649,y:499,t:1527023370897};\\\", \\\"{x:645,y:497,t:1527023370913};\\\", \\\"{x:642,y:496,t:1527023370937};\\\", \\\"{x:640,y:493,t:1527023370946};\\\", \\\"{x:635,y:492,t:1527023370963};\\\", \\\"{x:632,y:490,t:1527023370979};\\\", \\\"{x:628,y:489,t:1527023370997};\\\", \\\"{x:627,y:488,t:1527023371013};\\\", \\\"{x:625,y:488,t:1527023371138};\\\", \\\"{x:623,y:489,t:1527023371264};\\\", \\\"{x:620,y:491,t:1527023371280};\\\", \\\"{x:618,y:496,t:1527023371297};\\\", \\\"{x:618,y:500,t:1527023371313};\\\", \\\"{x:618,y:503,t:1527023371330};\\\", \\\"{x:618,y:508,t:1527023371347};\\\", \\\"{x:618,y:516,t:1527023371364};\\\", \\\"{x:618,y:522,t:1527023371380};\\\", \\\"{x:618,y:527,t:1527023371397};\\\", \\\"{x:618,y:528,t:1527023371441};\\\", \\\"{x:618,y:529,t:1527023371970};\\\", \\\"{x:618,y:530,t:1527023371982};\\\", \\\"{x:618,y:534,t:1527023371997};\\\", \\\"{x:617,y:538,t:1527023372015};\\\", \\\"{x:617,y:543,t:1527023372032};\\\", \\\"{x:616,y:546,t:1527023372046};\\\", \\\"{x:616,y:551,t:1527023372064};\\\", \\\"{x:614,y:559,t:1527023372080};\\\", \\\"{x:614,y:566,t:1527023372098};\\\", \\\"{x:614,y:573,t:1527023372114};\\\", \\\"{x:613,y:578,t:1527023372131};\\\", \\\"{x:613,y:581,t:1527023372149};\\\", \\\"{x:613,y:586,t:1527023372164};\\\", \\\"{x:613,y:589,t:1527023372181};\\\", \\\"{x:613,y:593,t:1527023372197};\\\", \\\"{x:613,y:597,t:1527023372214};\\\", \\\"{x:613,y:602,t:1527023372231};\\\", \\\"{x:613,y:608,t:1527023372247};\\\", \\\"{x:613,y:611,t:1527023372264};\\\", \\\"{x:608,y:619,t:1527023372281};\\\", \\\"{x:606,y:623,t:1527023372298};\\\", \\\"{x:605,y:625,t:1527023372314};\\\", \\\"{x:605,y:627,t:1527023372331};\\\", \\\"{x:605,y:628,t:1527023372348};\\\", \\\"{x:603,y:629,t:1527023372365};\\\", \\\"{x:603,y:630,t:1527023372394};\\\", \\\"{x:603,y:631,t:1527023372402};\\\", \\\"{x:602,y:632,t:1527023372418};\\\", \\\"{x:602,y:633,t:1527023372434};\\\", \\\"{x:602,y:634,t:1527023372458};\\\", \\\"{x:601,y:636,t:1527023372635};\\\", \\\"{x:600,y:636,t:1527023372770};\\\", \\\"{x:599,y:637,t:1527023373658};\\\", \\\"{x:598,y:638,t:1527023373665};\\\", \\\"{x:598,y:639,t:1527023373681};\\\", \\\"{x:596,y:641,t:1527023373698};\\\", \\\"{x:595,y:641,t:1527023373715};\\\", \\\"{x:594,y:642,t:1527023373731};\\\", \\\"{x:592,y:643,t:1527023373754};\\\", \\\"{x:592,y:644,t:1527023373769};\\\", \\\"{x:590,y:644,t:1527023373781};\\\", \\\"{x:589,y:645,t:1527023373801};\\\", \\\"{x:588,y:645,t:1527023373814};\\\", \\\"{x:587,y:647,t:1527023373831};\\\", \\\"{x:582,y:649,t:1527023373847};\\\", \\\"{x:579,y:651,t:1527023373864};\\\", \\\"{x:576,y:654,t:1527023373881};\\\", \\\"{x:575,y:655,t:1527023373897};\\\", \\\"{x:574,y:656,t:1527023373914};\\\", \\\"{x:573,y:657,t:1527023373931};\\\", \\\"{x:572,y:657,t:1527023373947};\\\", \\\"{x:570,y:659,t:1527023373964};\\\", \\\"{x:567,y:661,t:1527023373982};\\\", \\\"{x:565,y:662,t:1527023374017};\\\", \\\"{x:563,y:663,t:1527023374032};\\\", \\\"{x:561,y:664,t:1527023374047};\\\", \\\"{x:556,y:666,t:1527023374064};\\\", \\\"{x:551,y:668,t:1527023374083};\\\", \\\"{x:549,y:670,t:1527023374097};\\\", \\\"{x:548,y:671,t:1527023374114};\\\", \\\"{x:546,y:671,t:1527023374136};\\\", \\\"{x:546,y:672,t:1527023374161};\\\", \\\"{x:546,y:673,t:1527023374168};\\\", \\\"{x:545,y:674,t:1527023374185};\\\", \\\"{x:544,y:675,t:1527023374199};\\\", \\\"{x:543,y:675,t:1527023374216};\\\", \\\"{x:543,y:677,t:1527023374232};\\\", \\\"{x:541,y:680,t:1527023374249};\\\", \\\"{x:540,y:681,t:1527023374266};\\\", \\\"{x:539,y:684,t:1527023374283};\\\", \\\"{x:537,y:686,t:1527023374299};\\\", \\\"{x:536,y:687,t:1527023374322};\\\", \\\"{x:535,y:688,t:1527023374506};\\\", \\\"{x:535,y:689,t:1527023374554};\\\", \\\"{x:533,y:690,t:1527023374594};\\\", \\\"{x:533,y:691,t:1527023374610};\\\", \\\"{x:531,y:691,t:1527023374634};\\\", \\\"{x:530,y:691,t:1527023375674};\\\", \\\"{x:528,y:691,t:1527023375714};\\\", \\\"{x:527,y:690,t:1527023375761};\\\", \\\"{x:527,y:689,t:1527023375866};\\\", \\\"{x:527,y:688,t:1527023375953};\\\", \\\"{x:527,y:687,t:1527023375986};\\\", \\\"{x:526,y:686,t:1527023376025};\\\", \\\"{x:525,y:684,t:1527023376114};\\\", \\\"{x:524,y:683,t:1527023376177};\\\" ] }, { \\\"rt\\\": 64461, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 497791, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"JYZGH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\", \\\"F\\\", \\\"O\\\", \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -L \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:522,y:677,t:1527023376402};\\\", \\\"{x:522,y:676,t:1527023376473};\\\", \\\"{x:522,y:675,t:1527023376513};\\\", \\\"{x:521,y:675,t:1527023376521};\\\", \\\"{x:521,y:674,t:1527023376536};\\\", \\\"{x:521,y:673,t:1527023376553};\\\", \\\"{x:520,y:673,t:1527023376568};\\\", \\\"{x:519,y:671,t:1527023376585};\\\", \\\"{x:517,y:668,t:1527023376601};\\\", \\\"{x:516,y:666,t:1527023376618};\\\", \\\"{x:515,y:665,t:1527023376634};\\\", \\\"{x:515,y:663,t:1527023376652};\\\", \\\"{x:515,y:660,t:1527023376669};\\\", \\\"{x:515,y:659,t:1527023376685};\\\", \\\"{x:514,y:657,t:1527023376702};\\\", \\\"{x:514,y:656,t:1527023376718};\\\", \\\"{x:514,y:655,t:1527023376842};\\\", \\\"{x:513,y:655,t:1527023377410};\\\", \\\"{x:515,y:652,t:1527023378466};\\\", \\\"{x:519,y:651,t:1527023378474};\\\", \\\"{x:524,y:649,t:1527023378487};\\\", \\\"{x:557,y:643,t:1527023378505};\\\", \\\"{x:618,y:638,t:1527023378521};\\\", \\\"{x:726,y:629,t:1527023378538};\\\", \\\"{x:785,y:626,t:1527023378554};\\\", \\\"{x:834,y:618,t:1527023378571};\\\", \\\"{x:859,y:616,t:1527023378588};\\\", \\\"{x:886,y:613,t:1527023378605};\\\", \\\"{x:896,y:611,t:1527023378621};\\\", \\\"{x:909,y:607,t:1527023378638};\\\", \\\"{x:919,y:606,t:1527023378654};\\\", \\\"{x:932,y:605,t:1527023378671};\\\", \\\"{x:950,y:602,t:1527023378688};\\\", \\\"{x:969,y:602,t:1527023378705};\\\", \\\"{x:1010,y:605,t:1527023378722};\\\", \\\"{x:1042,y:611,t:1527023378738};\\\", \\\"{x:1069,y:614,t:1527023378755};\\\", \\\"{x:1087,y:621,t:1527023378772};\\\", \\\"{x:1100,y:627,t:1527023378788};\\\", \\\"{x:1111,y:635,t:1527023378805};\\\", \\\"{x:1127,y:646,t:1527023378822};\\\", \\\"{x:1139,y:656,t:1527023378838};\\\", \\\"{x:1154,y:668,t:1527023378855};\\\", \\\"{x:1173,y:678,t:1527023378872};\\\", \\\"{x:1186,y:684,t:1527023378888};\\\", \\\"{x:1197,y:690,t:1527023378905};\\\", \\\"{x:1205,y:695,t:1527023378922};\\\", \\\"{x:1208,y:697,t:1527023378939};\\\", \\\"{x:1214,y:702,t:1527023378955};\\\", \\\"{x:1219,y:705,t:1527023378972};\\\", \\\"{x:1223,y:708,t:1527023378989};\\\", \\\"{x:1224,y:709,t:1527023379005};\\\", \\\"{x:1225,y:710,t:1527023379023};\\\", \\\"{x:1226,y:712,t:1527023379040};\\\", \\\"{x:1228,y:714,t:1527023379055};\\\", \\\"{x:1230,y:717,t:1527023379072};\\\", \\\"{x:1231,y:718,t:1527023379088};\\\", \\\"{x:1230,y:717,t:1527023379250};\\\", \\\"{x:1230,y:716,t:1527023379258};\\\", \\\"{x:1229,y:716,t:1527023379272};\\\", \\\"{x:1227,y:714,t:1527023379290};\\\", \\\"{x:1223,y:708,t:1527023379305};\\\", \\\"{x:1221,y:703,t:1527023379322};\\\", \\\"{x:1220,y:702,t:1527023379339};\\\", \\\"{x:1219,y:699,t:1527023379356};\\\", \\\"{x:1217,y:697,t:1527023379372};\\\", \\\"{x:1217,y:696,t:1527023379389};\\\", \\\"{x:1217,y:695,t:1527023379406};\\\", \\\"{x:1216,y:692,t:1527023379423};\\\", \\\"{x:1216,y:691,t:1527023379439};\\\", \\\"{x:1215,y:689,t:1527023379456};\\\", \\\"{x:1215,y:688,t:1527023379473};\\\", \\\"{x:1214,y:686,t:1527023379489};\\\", \\\"{x:1214,y:685,t:1527023379506};\\\", \\\"{x:1214,y:684,t:1527023379523};\\\", \\\"{x:1212,y:685,t:1527023379690};\\\", \\\"{x:1211,y:688,t:1527023379706};\\\", \\\"{x:1209,y:692,t:1527023379723};\\\", \\\"{x:1208,y:695,t:1527023379740};\\\", \\\"{x:1207,y:697,t:1527023379756};\\\", \\\"{x:1207,y:698,t:1527023379773};\\\", \\\"{x:1206,y:699,t:1527023379790};\\\", \\\"{x:1205,y:701,t:1527023379806};\\\", \\\"{x:1204,y:701,t:1527023379826};\\\", \\\"{x:1202,y:703,t:1527023379842};\\\", \\\"{x:1201,y:703,t:1527023379857};\\\", \\\"{x:1201,y:705,t:1527023379873};\\\", \\\"{x:1197,y:708,t:1527023379890};\\\", \\\"{x:1195,y:709,t:1527023379907};\\\", \\\"{x:1192,y:712,t:1527023379923};\\\", \\\"{x:1191,y:712,t:1527023379940};\\\", \\\"{x:1191,y:713,t:1527023379985};\\\", \\\"{x:1190,y:713,t:1527023379993};\\\", \\\"{x:1190,y:714,t:1527023380007};\\\", \\\"{x:1189,y:715,t:1527023380023};\\\", \\\"{x:1188,y:716,t:1527023380040};\\\", \\\"{x:1187,y:718,t:1527023380057};\\\", \\\"{x:1186,y:719,t:1527023380073};\\\", \\\"{x:1185,y:719,t:1527023380090};\\\", \\\"{x:1184,y:719,t:1527023380155};\\\", \\\"{x:1183,y:719,t:1527023380170};\\\", \\\"{x:1182,y:719,t:1527023380186};\\\", \\\"{x:1181,y:719,t:1527023380202};\\\", \\\"{x:1180,y:719,t:1527023380210};\\\", \\\"{x:1180,y:718,t:1527023380224};\\\", \\\"{x:1179,y:716,t:1527023380242};\\\", \\\"{x:1178,y:715,t:1527023380260};\\\", \\\"{x:1177,y:713,t:1527023380273};\\\", \\\"{x:1175,y:712,t:1527023380292};\\\", \\\"{x:1175,y:711,t:1527023380307};\\\", \\\"{x:1174,y:711,t:1527023380324};\\\", \\\"{x:1174,y:710,t:1527023380340};\\\", \\\"{x:1173,y:710,t:1527023380570};\\\", \\\"{x:1172,y:710,t:1527023385106};\\\", \\\"{x:1171,y:708,t:1527023385138};\\\", \\\"{x:1170,y:702,t:1527023385147};\\\", \\\"{x:1169,y:699,t:1527023385164};\\\", \\\"{x:1169,y:695,t:1527023385181};\\\", \\\"{x:1168,y:693,t:1527023385197};\\\", \\\"{x:1168,y:691,t:1527023385214};\\\", \\\"{x:1168,y:688,t:1527023385230};\\\", \\\"{x:1167,y:686,t:1527023385258};\\\", \\\"{x:1167,y:685,t:1527023385274};\\\", \\\"{x:1166,y:684,t:1527023385282};\\\", \\\"{x:1165,y:682,t:1527023385306};\\\", \\\"{x:1165,y:681,t:1527023385314};\\\", \\\"{x:1164,y:678,t:1527023385331};\\\", \\\"{x:1164,y:677,t:1527023385347};\\\", \\\"{x:1162,y:674,t:1527023385365};\\\", \\\"{x:1161,y:672,t:1527023385381};\\\", \\\"{x:1160,y:669,t:1527023385397};\\\", \\\"{x:1159,y:667,t:1527023385414};\\\", \\\"{x:1158,y:665,t:1527023385431};\\\", \\\"{x:1158,y:662,t:1527023385447};\\\", \\\"{x:1157,y:661,t:1527023385464};\\\", \\\"{x:1155,y:656,t:1527023385481};\\\", \\\"{x:1155,y:655,t:1527023385498};\\\", \\\"{x:1153,y:650,t:1527023385514};\\\", \\\"{x:1153,y:647,t:1527023385532};\\\", \\\"{x:1152,y:640,t:1527023385548};\\\", \\\"{x:1151,y:631,t:1527023385564};\\\", \\\"{x:1150,y:620,t:1527023385581};\\\", \\\"{x:1149,y:606,t:1527023385598};\\\", \\\"{x:1147,y:591,t:1527023385615};\\\", \\\"{x:1144,y:574,t:1527023385631};\\\", \\\"{x:1144,y:562,t:1527023385649};\\\", \\\"{x:1144,y:549,t:1527023385664};\\\", \\\"{x:1144,y:535,t:1527023385680};\\\", \\\"{x:1144,y:530,t:1527023385697};\\\", \\\"{x:1141,y:522,t:1527023385714};\\\", \\\"{x:1138,y:515,t:1527023385731};\\\", \\\"{x:1131,y:504,t:1527023385748};\\\", \\\"{x:1128,y:496,t:1527023385763};\\\", \\\"{x:1125,y:491,t:1527023385780};\\\", \\\"{x:1122,y:482,t:1527023385798};\\\", \\\"{x:1117,y:472,t:1527023385815};\\\", \\\"{x:1116,y:469,t:1527023385830};\\\", \\\"{x:1115,y:463,t:1527023385848};\\\", \\\"{x:1112,y:451,t:1527023385865};\\\", \\\"{x:1111,y:444,t:1527023385881};\\\", \\\"{x:1111,y:441,t:1527023385898};\\\", \\\"{x:1111,y:437,t:1527023385916};\\\", \\\"{x:1111,y:436,t:1527023385930};\\\", \\\"{x:1111,y:434,t:1527023385948};\\\", \\\"{x:1110,y:434,t:1527023386184};\\\", \\\"{x:1110,y:435,t:1527023386249};\\\", \\\"{x:1110,y:436,t:1527023386265};\\\", \\\"{x:1109,y:436,t:1527023386305};\\\", \\\"{x:1108,y:437,t:1527023386329};\\\", \\\"{x:1108,y:438,t:1527023386337};\\\", \\\"{x:1107,y:438,t:1527023386353};\\\", \\\"{x:1107,y:439,t:1527023386365};\\\", \\\"{x:1106,y:439,t:1527023386386};\\\", \\\"{x:1105,y:439,t:1527023386399};\\\", \\\"{x:1105,y:440,t:1527023386425};\\\", \\\"{x:1104,y:441,t:1527023387066};\\\", \\\"{x:1105,y:441,t:1527023388194};\\\", \\\"{x:1106,y:441,t:1527023388202};\\\", \\\"{x:1107,y:441,t:1527023388218};\\\", \\\"{x:1108,y:441,t:1527023388235};\\\", \\\"{x:1109,y:441,t:1527023388251};\\\", \\\"{x:1110,y:441,t:1527023388298};\\\", \\\"{x:1111,y:441,t:1527023388306};\\\", \\\"{x:1112,y:441,t:1527023388345};\\\", \\\"{x:1113,y:441,t:1527023388353};\\\", \\\"{x:1114,y:441,t:1527023388370};\\\", \\\"{x:1116,y:441,t:1527023388393};\\\", \\\"{x:1117,y:441,t:1527023388418};\\\", \\\"{x:1119,y:441,t:1527023388442};\\\", \\\"{x:1120,y:441,t:1527023388466};\\\", \\\"{x:1122,y:441,t:1527023388482};\\\", \\\"{x:1124,y:441,t:1527023388489};\\\", \\\"{x:1125,y:441,t:1527023388502};\\\", \\\"{x:1127,y:441,t:1527023388518};\\\", \\\"{x:1129,y:441,t:1527023388535};\\\", \\\"{x:1132,y:441,t:1527023388552};\\\", \\\"{x:1133,y:441,t:1527023388569};\\\", \\\"{x:1136,y:441,t:1527023388586};\\\", \\\"{x:1138,y:441,t:1527023388610};\\\", \\\"{x:1139,y:441,t:1527023388626};\\\", \\\"{x:1141,y:441,t:1527023388635};\\\", \\\"{x:1144,y:441,t:1527023388652};\\\", \\\"{x:1148,y:441,t:1527023388668};\\\", \\\"{x:1152,y:441,t:1527023388686};\\\", \\\"{x:1157,y:441,t:1527023388702};\\\", \\\"{x:1161,y:441,t:1527023388720};\\\", \\\"{x:1167,y:441,t:1527023388735};\\\", \\\"{x:1175,y:441,t:1527023388752};\\\", \\\"{x:1189,y:441,t:1527023388769};\\\", \\\"{x:1198,y:441,t:1527023388785};\\\", \\\"{x:1211,y:441,t:1527023388802};\\\", \\\"{x:1222,y:441,t:1527023388819};\\\", \\\"{x:1236,y:441,t:1527023388835};\\\", \\\"{x:1249,y:441,t:1527023388852};\\\", \\\"{x:1267,y:441,t:1527023388869};\\\", \\\"{x:1281,y:441,t:1527023388885};\\\", \\\"{x:1293,y:438,t:1527023388902};\\\", \\\"{x:1298,y:438,t:1527023388918};\\\", \\\"{x:1304,y:438,t:1527023388935};\\\", \\\"{x:1308,y:438,t:1527023388952};\\\", \\\"{x:1313,y:438,t:1527023388969};\\\", \\\"{x:1322,y:438,t:1527023388986};\\\", \\\"{x:1335,y:438,t:1527023389002};\\\", \\\"{x:1352,y:438,t:1527023389019};\\\", \\\"{x:1372,y:438,t:1527023389036};\\\", \\\"{x:1394,y:435,t:1527023389052};\\\", \\\"{x:1412,y:435,t:1527023389068};\\\", \\\"{x:1418,y:435,t:1527023389086};\\\", \\\"{x:1420,y:435,t:1527023389102};\\\", \\\"{x:1422,y:435,t:1527023389145};\\\", \\\"{x:1423,y:435,t:1527023389153};\\\", \\\"{x:1426,y:435,t:1527023389169};\\\", \\\"{x:1434,y:435,t:1527023389186};\\\", \\\"{x:1443,y:435,t:1527023389203};\\\", \\\"{x:1453,y:435,t:1527023389219};\\\", \\\"{x:1464,y:438,t:1527023389236};\\\", \\\"{x:1474,y:440,t:1527023389253};\\\", \\\"{x:1482,y:442,t:1527023389269};\\\", \\\"{x:1490,y:442,t:1527023389286};\\\", \\\"{x:1507,y:442,t:1527023389303};\\\", \\\"{x:1514,y:442,t:1527023389319};\\\", \\\"{x:1520,y:442,t:1527023389336};\\\", \\\"{x:1533,y:443,t:1527023389353};\\\", \\\"{x:1542,y:443,t:1527023389369};\\\", \\\"{x:1551,y:446,t:1527023389386};\\\", \\\"{x:1557,y:447,t:1527023389403};\\\", \\\"{x:1558,y:448,t:1527023389419};\\\", \\\"{x:1560,y:448,t:1527023389435};\\\", \\\"{x:1561,y:448,t:1527023389578};\\\", \\\"{x:1562,y:447,t:1527023389594};\\\", \\\"{x:1563,y:447,t:1527023389603};\\\", \\\"{x:1567,y:447,t:1527023389621};\\\", \\\"{x:1571,y:446,t:1527023389636};\\\", \\\"{x:1575,y:446,t:1527023389653};\\\", \\\"{x:1576,y:446,t:1527023389671};\\\", \\\"{x:1577,y:446,t:1527023389686};\\\", \\\"{x:1578,y:446,t:1527023389713};\\\", \\\"{x:1579,y:447,t:1527023394353};\\\", \\\"{x:1580,y:449,t:1527023394361};\\\", \\\"{x:1580,y:450,t:1527023394379};\\\", \\\"{x:1581,y:450,t:1527023394393};\\\", \\\"{x:1581,y:452,t:1527023394409};\\\", \\\"{x:1582,y:453,t:1527023394427};\\\", \\\"{x:1583,y:453,t:1527023394443};\\\", \\\"{x:1584,y:453,t:1527023394649};\\\", \\\"{x:1585,y:453,t:1527023394681};\\\", \\\"{x:1585,y:452,t:1527023394778};\\\", \\\"{x:1585,y:451,t:1527023394866};\\\", \\\"{x:1585,y:450,t:1527023396241};\\\", \\\"{x:1584,y:450,t:1527023406674};\\\", \\\"{x:1583,y:450,t:1527023406794};\\\", \\\"{x:1583,y:451,t:1527023406811};\\\", \\\"{x:1582,y:451,t:1527023406945};\\\", \\\"{x:1581,y:452,t:1527023407034};\\\", \\\"{x:1580,y:452,t:1527023407074};\\\", \\\"{x:1580,y:453,t:1527023407170};\\\", \\\"{x:1580,y:460,t:1527023413625};\\\", \\\"{x:1582,y:471,t:1527023413637};\\\", \\\"{x:1587,y:489,t:1527023413654};\\\", \\\"{x:1592,y:506,t:1527023413670};\\\", \\\"{x:1595,y:524,t:1527023413688};\\\", \\\"{x:1599,y:540,t:1527023413704};\\\", \\\"{x:1600,y:555,t:1527023413721};\\\", \\\"{x:1603,y:568,t:1527023413736};\\\", \\\"{x:1604,y:574,t:1527023413753};\\\", \\\"{x:1605,y:587,t:1527023413770};\\\", \\\"{x:1605,y:605,t:1527023413787};\\\", \\\"{x:1606,y:627,t:1527023413803};\\\", \\\"{x:1607,y:644,t:1527023413819};\\\", \\\"{x:1609,y:656,t:1527023413837};\\\", \\\"{x:1609,y:670,t:1527023413853};\\\", \\\"{x:1608,y:680,t:1527023413869};\\\", \\\"{x:1608,y:687,t:1527023413887};\\\", \\\"{x:1607,y:693,t:1527023413904};\\\", \\\"{x:1604,y:702,t:1527023413920};\\\", \\\"{x:1603,y:707,t:1527023413936};\\\", \\\"{x:1600,y:714,t:1527023413954};\\\", \\\"{x:1598,y:716,t:1527023413970};\\\", \\\"{x:1598,y:718,t:1527023413987};\\\", \\\"{x:1596,y:721,t:1527023414004};\\\", \\\"{x:1595,y:723,t:1527023414041};\\\", \\\"{x:1594,y:725,t:1527023414089};\\\", \\\"{x:1593,y:725,t:1527023414122};\\\", \\\"{x:1591,y:725,t:1527023414145};\\\", \\\"{x:1591,y:726,t:1527023414161};\\\", \\\"{x:1590,y:726,t:1527023414172};\\\", \\\"{x:1587,y:727,t:1527023414189};\\\", \\\"{x:1586,y:728,t:1527023414204};\\\", \\\"{x:1584,y:730,t:1527023414221};\\\", \\\"{x:1582,y:731,t:1527023414238};\\\", \\\"{x:1580,y:735,t:1527023414255};\\\", \\\"{x:1577,y:738,t:1527023414272};\\\", \\\"{x:1575,y:739,t:1527023414289};\\\", \\\"{x:1574,y:741,t:1527023414305};\\\", \\\"{x:1572,y:743,t:1527023414321};\\\", \\\"{x:1572,y:744,t:1527023414338};\\\", \\\"{x:1569,y:748,t:1527023414354};\\\", \\\"{x:1563,y:752,t:1527023414371};\\\", \\\"{x:1557,y:756,t:1527023414389};\\\", \\\"{x:1550,y:762,t:1527023414406};\\\", \\\"{x:1534,y:771,t:1527023414421};\\\", \\\"{x:1516,y:782,t:1527023414439};\\\", \\\"{x:1503,y:789,t:1527023414455};\\\", \\\"{x:1489,y:798,t:1527023414471};\\\", \\\"{x:1482,y:802,t:1527023414488};\\\", \\\"{x:1478,y:805,t:1527023414505};\\\", \\\"{x:1475,y:806,t:1527023414521};\\\", \\\"{x:1468,y:809,t:1527023414538};\\\", \\\"{x:1462,y:810,t:1527023414555};\\\", \\\"{x:1456,y:810,t:1527023414572};\\\", \\\"{x:1452,y:810,t:1527023414588};\\\", \\\"{x:1449,y:810,t:1527023414606};\\\", \\\"{x:1446,y:810,t:1527023414621};\\\", \\\"{x:1444,y:809,t:1527023414638};\\\", \\\"{x:1441,y:808,t:1527023414656};\\\", \\\"{x:1437,y:805,t:1527023414673};\\\", \\\"{x:1435,y:802,t:1527023414688};\\\", \\\"{x:1432,y:796,t:1527023414705};\\\", \\\"{x:1431,y:794,t:1527023414723};\\\", \\\"{x:1431,y:793,t:1527023414739};\\\", \\\"{x:1431,y:792,t:1527023414755};\\\", \\\"{x:1431,y:791,t:1527023414777};\\\", \\\"{x:1431,y:790,t:1527023414788};\\\", \\\"{x:1431,y:788,t:1527023414804};\\\", \\\"{x:1431,y:787,t:1527023414832};\\\", \\\"{x:1431,y:785,t:1527023415010};\\\", \\\"{x:1429,y:784,t:1527023415023};\\\", \\\"{x:1427,y:782,t:1527023415040};\\\", \\\"{x:1423,y:779,t:1527023415055};\\\", \\\"{x:1419,y:776,t:1527023415072};\\\", \\\"{x:1418,y:775,t:1527023415090};\\\", \\\"{x:1417,y:775,t:1527023415649};\\\", \\\"{x:1416,y:775,t:1527023415657};\\\", \\\"{x:1414,y:775,t:1527023415689};\\\", \\\"{x:1412,y:775,t:1527023415706};\\\", \\\"{x:1409,y:776,t:1527023415722};\\\", \\\"{x:1407,y:776,t:1527023415740};\\\", \\\"{x:1406,y:777,t:1527023415755};\\\", \\\"{x:1405,y:778,t:1527023415773};\\\", \\\"{x:1404,y:778,t:1527023415800};\\\", \\\"{x:1403,y:778,t:1527023415808};\\\", \\\"{x:1402,y:778,t:1527023415822};\\\", \\\"{x:1401,y:778,t:1527023415840};\\\", \\\"{x:1394,y:778,t:1527023415856};\\\", \\\"{x:1385,y:773,t:1527023415873};\\\", \\\"{x:1374,y:771,t:1527023415889};\\\", \\\"{x:1361,y:767,t:1527023415907};\\\", \\\"{x:1351,y:764,t:1527023415922};\\\", \\\"{x:1344,y:762,t:1527023415939};\\\", \\\"{x:1339,y:761,t:1527023415957};\\\", \\\"{x:1335,y:759,t:1527023415972};\\\", \\\"{x:1331,y:758,t:1527023415989};\\\", \\\"{x:1324,y:756,t:1527023416007};\\\", \\\"{x:1313,y:754,t:1527023416023};\\\", \\\"{x:1292,y:749,t:1527023416039};\\\", \\\"{x:1260,y:743,t:1527023416056};\\\", \\\"{x:1232,y:737,t:1527023416073};\\\", \\\"{x:1188,y:730,t:1527023416090};\\\", \\\"{x:1115,y:717,t:1527023416107};\\\", \\\"{x:1031,y:706,t:1527023416124};\\\", \\\"{x:932,y:692,t:1527023416140};\\\", \\\"{x:848,y:678,t:1527023416156};\\\", \\\"{x:775,y:667,t:1527023416173};\\\", \\\"{x:724,y:659,t:1527023416190};\\\", \\\"{x:679,y:644,t:1527023416207};\\\", \\\"{x:651,y:632,t:1527023416224};\\\", \\\"{x:631,y:619,t:1527023416239};\\\", \\\"{x:588,y:593,t:1527023416256};\\\", \\\"{x:541,y:564,t:1527023416274};\\\", \\\"{x:510,y:547,t:1527023416291};\\\", \\\"{x:485,y:533,t:1527023416307};\\\", \\\"{x:477,y:530,t:1527023416316};\\\", \\\"{x:473,y:527,t:1527023416333};\\\", \\\"{x:472,y:527,t:1527023416351};\\\", \\\"{x:470,y:525,t:1527023416432};\\\", \\\"{x:466,y:518,t:1527023416440};\\\", \\\"{x:459,y:512,t:1527023416451};\\\", \\\"{x:426,y:488,t:1527023416467};\\\", \\\"{x:400,y:468,t:1527023416484};\\\", \\\"{x:370,y:452,t:1527023416501};\\\", \\\"{x:356,y:445,t:1527023416516};\\\", \\\"{x:348,y:442,t:1527023416533};\\\", \\\"{x:341,y:440,t:1527023416550};\\\", \\\"{x:338,y:440,t:1527023416566};\\\", \\\"{x:337,y:440,t:1527023416583};\\\", \\\"{x:328,y:437,t:1527023416601};\\\", \\\"{x:318,y:435,t:1527023416616};\\\", \\\"{x:304,y:433,t:1527023416633};\\\", \\\"{x:292,y:432,t:1527023416650};\\\", \\\"{x:284,y:432,t:1527023416667};\\\", \\\"{x:277,y:432,t:1527023416684};\\\", \\\"{x:272,y:432,t:1527023416700};\\\", \\\"{x:254,y:438,t:1527023416718};\\\", \\\"{x:236,y:447,t:1527023416733};\\\", \\\"{x:231,y:450,t:1527023416750};\\\", \\\"{x:211,y:465,t:1527023416768};\\\", \\\"{x:191,y:476,t:1527023416785};\\\", \\\"{x:177,y:484,t:1527023416801};\\\", \\\"{x:174,y:487,t:1527023416817};\\\", \\\"{x:173,y:489,t:1527023416834};\\\", \\\"{x:171,y:491,t:1527023416850};\\\", \\\"{x:171,y:492,t:1527023416868};\\\", \\\"{x:171,y:495,t:1527023416883};\\\", \\\"{x:171,y:497,t:1527023416904};\\\", \\\"{x:173,y:499,t:1527023416917};\\\", \\\"{x:177,y:500,t:1527023416933};\\\", \\\"{x:180,y:500,t:1527023416951};\\\", \\\"{x:182,y:500,t:1527023416967};\\\", \\\"{x:187,y:497,t:1527023416984};\\\", \\\"{x:193,y:492,t:1527023417000};\\\", \\\"{x:197,y:489,t:1527023417017};\\\", \\\"{x:199,y:486,t:1527023417034};\\\", \\\"{x:200,y:484,t:1527023417050};\\\", \\\"{x:200,y:483,t:1527023417068};\\\", \\\"{x:200,y:481,t:1527023417085};\\\", \\\"{x:200,y:479,t:1527023417100};\\\", \\\"{x:198,y:478,t:1527023417118};\\\", \\\"{x:196,y:478,t:1527023417134};\\\", \\\"{x:193,y:477,t:1527023417150};\\\", \\\"{x:188,y:476,t:1527023417168};\\\", \\\"{x:187,y:470,t:1527023417184};\\\", \\\"{x:184,y:466,t:1527023417201};\\\", \\\"{x:181,y:462,t:1527023417218};\\\", \\\"{x:172,y:450,t:1527023417235};\\\", \\\"{x:167,y:443,t:1527023417251};\\\", \\\"{x:164,y:439,t:1527023417267};\\\", \\\"{x:164,y:436,t:1527023417285};\\\", \\\"{x:163,y:436,t:1527023417301};\\\", \\\"{x:162,y:435,t:1527023417317};\\\", \\\"{x:162,y:436,t:1527023417681};\\\", \\\"{x:162,y:437,t:1527023417705};\\\", \\\"{x:162,y:438,t:1527023417728};\\\", \\\"{x:162,y:441,t:1527023417736};\\\", \\\"{x:162,y:443,t:1527023417768};\\\", \\\"{x:162,y:445,t:1527023417785};\\\", \\\"{x:162,y:446,t:1527023417857};\\\", \\\"{x:160,y:451,t:1527023418019};\\\", \\\"{x:157,y:455,t:1527023418034};\\\", \\\"{x:156,y:457,t:1527023418051};\\\", \\\"{x:156,y:460,t:1527023418068};\\\", \\\"{x:153,y:466,t:1527023418085};\\\", \\\"{x:152,y:471,t:1527023418102};\\\", \\\"{x:151,y:474,t:1527023418119};\\\", \\\"{x:155,y:476,t:1527023418426};\\\", \\\"{x:184,y:481,t:1527023418435};\\\", \\\"{x:301,y:499,t:1527023418452};\\\", \\\"{x:445,y:516,t:1527023418469};\\\", \\\"{x:583,y:535,t:1527023418486};\\\", \\\"{x:716,y:552,t:1527023418502};\\\", \\\"{x:803,y:558,t:1527023418519};\\\", \\\"{x:834,y:560,t:1527023418535};\\\", \\\"{x:846,y:560,t:1527023418552};\\\", \\\"{x:847,y:560,t:1527023418569};\\\", \\\"{x:850,y:559,t:1527023418745};\\\", \\\"{x:851,y:555,t:1527023418752};\\\", \\\"{x:858,y:544,t:1527023418770};\\\", \\\"{x:865,y:537,t:1527023418787};\\\", \\\"{x:870,y:529,t:1527023418803};\\\", \\\"{x:872,y:527,t:1527023418819};\\\", \\\"{x:873,y:525,t:1527023418835};\\\", \\\"{x:873,y:524,t:1527023418944};\\\", \\\"{x:871,y:524,t:1527023418960};\\\", \\\"{x:867,y:524,t:1527023418969};\\\", \\\"{x:861,y:524,t:1527023418985};\\\", \\\"{x:849,y:526,t:1527023419003};\\\", \\\"{x:838,y:528,t:1527023419019};\\\", \\\"{x:831,y:529,t:1527023419036};\\\", \\\"{x:828,y:530,t:1527023419053};\\\", \\\"{x:827,y:530,t:1527023419105};\\\", \\\"{x:826,y:530,t:1527023419119};\\\", \\\"{x:824,y:528,t:1527023419136};\\\", \\\"{x:824,y:527,t:1527023419153};\\\", \\\"{x:823,y:527,t:1527023419176};\\\", \\\"{x:823,y:526,t:1527023420561};\\\", \\\"{x:823,y:525,t:1527023420776};\\\", \\\"{x:823,y:524,t:1527023420824};\\\", \\\"{x:823,y:523,t:1527023420953};\\\", \\\"{x:823,y:522,t:1527023420977};\\\", \\\"{x:823,y:521,t:1527023420992};\\\", \\\"{x:822,y:519,t:1527023421073};\\\", \\\"{x:822,y:518,t:1527023422789};\\\", \\\"{x:822,y:516,t:1527023422804};\\\", \\\"{x:821,y:515,t:1527023422901};\\\", \\\"{x:821,y:513,t:1527023423028};\\\", \\\"{x:820,y:512,t:1527023423293};\\\", \\\"{x:818,y:512,t:1527023423941};\\\", \\\"{x:817,y:512,t:1527023423948};\\\", \\\"{x:816,y:512,t:1527023423965};\\\", \\\"{x:815,y:512,t:1527023423977};\\\", \\\"{x:814,y:514,t:1527023423994};\\\", \\\"{x:811,y:516,t:1527023424012};\\\", \\\"{x:811,y:518,t:1527023424037};\\\", \\\"{x:810,y:518,t:1527023424044};\\\", \\\"{x:810,y:520,t:1527023424061};\\\", \\\"{x:810,y:521,t:1527023424078};\\\", \\\"{x:810,y:522,t:1527023424094};\\\", \\\"{x:810,y:525,t:1527023424111};\\\", \\\"{x:818,y:527,t:1527023424128};\\\", \\\"{x:838,y:527,t:1527023424145};\\\", \\\"{x:858,y:527,t:1527023424161};\\\", \\\"{x:874,y:526,t:1527023424178};\\\", \\\"{x:877,y:525,t:1527023424194};\\\", \\\"{x:878,y:524,t:1527023424210};\\\", \\\"{x:878,y:522,t:1527023424227};\\\", \\\"{x:877,y:519,t:1527023424244};\\\", \\\"{x:875,y:519,t:1527023424259};\\\", \\\"{x:871,y:518,t:1527023424277};\\\", \\\"{x:866,y:517,t:1527023424294};\\\", \\\"{x:860,y:517,t:1527023424310};\\\", \\\"{x:855,y:517,t:1527023424327};\\\", \\\"{x:851,y:517,t:1527023424344};\\\", \\\"{x:848,y:517,t:1527023424361};\\\", \\\"{x:844,y:517,t:1527023424378};\\\", \\\"{x:838,y:518,t:1527023424394};\\\", \\\"{x:836,y:518,t:1527023424410};\\\", \\\"{x:836,y:519,t:1527023424427};\\\", \\\"{x:835,y:519,t:1527023424444};\\\", \\\"{x:835,y:520,t:1527023424460};\\\", \\\"{x:834,y:520,t:1527023424477};\\\", \\\"{x:833,y:520,t:1527023424494};\\\", \\\"{x:833,y:521,t:1527023424509};\\\", \\\"{x:832,y:521,t:1527023424527};\\\", \\\"{x:831,y:522,t:1527023424564};\\\", \\\"{x:831,y:520,t:1527023424756};\\\", \\\"{x:831,y:517,t:1527023424764};\\\", \\\"{x:831,y:512,t:1527023424778};\\\", \\\"{x:831,y:502,t:1527023424795};\\\", \\\"{x:831,y:494,t:1527023424811};\\\", \\\"{x:832,y:486,t:1527023424827};\\\", \\\"{x:832,y:483,t:1527023424845};\\\", \\\"{x:832,y:481,t:1527023424861};\\\", \\\"{x:832,y:480,t:1527023424878};\\\", \\\"{x:832,y:479,t:1527023424895};\\\", \\\"{x:832,y:476,t:1527023424911};\\\", \\\"{x:832,y:470,t:1527023424929};\\\", \\\"{x:832,y:465,t:1527023424944};\\\", \\\"{x:833,y:460,t:1527023424962};\\\", \\\"{x:835,y:456,t:1527023424978};\\\", \\\"{x:835,y:454,t:1527023424995};\\\", \\\"{x:835,y:452,t:1527023425010};\\\", \\\"{x:835,y:450,t:1527023425027};\\\", \\\"{x:835,y:449,t:1527023425044};\\\", \\\"{x:835,y:448,t:1527023425060};\\\", \\\"{x:834,y:448,t:1527023425078};\\\", \\\"{x:834,y:447,t:1527023425140};\\\", \\\"{x:834,y:446,t:1527023425285};\\\", \\\"{x:832,y:450,t:1527023427067};\\\", \\\"{x:832,y:454,t:1527023427080};\\\", \\\"{x:832,y:466,t:1527023427097};\\\", \\\"{x:833,y:475,t:1527023427114};\\\", \\\"{x:834,y:483,t:1527023427130};\\\", \\\"{x:836,y:488,t:1527023427146};\\\", \\\"{x:836,y:494,t:1527023427163};\\\", \\\"{x:840,y:506,t:1527023427181};\\\", \\\"{x:842,y:512,t:1527023427197};\\\", \\\"{x:846,y:520,t:1527023427213};\\\", \\\"{x:849,y:532,t:1527023427230};\\\", \\\"{x:854,y:543,t:1527023427246};\\\", \\\"{x:858,y:551,t:1527023427263};\\\", \\\"{x:863,y:561,t:1527023427280};\\\", \\\"{x:870,y:573,t:1527023427298};\\\", \\\"{x:871,y:578,t:1527023427313};\\\", \\\"{x:873,y:581,t:1527023427330};\\\", \\\"{x:873,y:582,t:1527023427347};\\\", \\\"{x:873,y:583,t:1527023427363};\\\", \\\"{x:873,y:584,t:1527023427445};\\\", \\\"{x:870,y:582,t:1527023427452};\\\", \\\"{x:868,y:580,t:1527023427463};\\\", \\\"{x:864,y:576,t:1527023427480};\\\", \\\"{x:860,y:572,t:1527023427497};\\\", \\\"{x:859,y:571,t:1527023427513};\\\", \\\"{x:858,y:571,t:1527023427530};\\\", \\\"{x:858,y:570,t:1527023427548};\\\", \\\"{x:857,y:569,t:1527023427563};\\\", \\\"{x:856,y:568,t:1527023427580};\\\", \\\"{x:855,y:568,t:1527023427605};\\\", \\\"{x:855,y:567,t:1527023427613};\\\", \\\"{x:853,y:567,t:1527023427630};\\\", \\\"{x:851,y:567,t:1527023427647};\\\", \\\"{x:849,y:567,t:1527023427663};\\\", \\\"{x:848,y:567,t:1527023427680};\\\", \\\"{x:846,y:567,t:1527023427697};\\\", \\\"{x:845,y:567,t:1527023427713};\\\", \\\"{x:843,y:567,t:1527023427730};\\\", \\\"{x:842,y:567,t:1527023427756};\\\", \\\"{x:842,y:566,t:1527023427764};\\\", \\\"{x:840,y:566,t:1527023427844};\\\", \\\"{x:839,y:566,t:1527023427925};\\\", \\\"{x:839,y:565,t:1527023429013};\\\", \\\"{x:839,y:564,t:1527023429028};\\\", \\\"{x:839,y:563,t:1527023429045};\\\", \\\"{x:840,y:561,t:1527023429101};\\\", \\\"{x:841,y:560,t:1527023429173};\\\", \\\"{x:841,y:559,t:1527023429333};\\\", \\\"{x:842,y:558,t:1527023429653};\\\", \\\"{x:843,y:557,t:1527023429668};\\\", \\\"{x:843,y:556,t:1527023429772};\\\", \\\"{x:843,y:554,t:1527023430093};\\\", \\\"{x:843,y:553,t:1527023430125};\\\", \\\"{x:843,y:552,t:1527023430165};\\\", \\\"{x:843,y:551,t:1527023430197};\\\", \\\"{x:843,y:550,t:1527023430221};\\\", \\\"{x:843,y:549,t:1527023430292};\\\", \\\"{x:843,y:548,t:1527023430331};\\\", \\\"{x:843,y:547,t:1527023430372};\\\", \\\"{x:843,y:546,t:1527023433885};\\\", \\\"{x:831,y:546,t:1527023433902};\\\", \\\"{x:824,y:546,t:1527023433919};\\\", \\\"{x:823,y:545,t:1527023433936};\\\", \\\"{x:824,y:545,t:1527023434037};\\\", \\\"{x:823,y:545,t:1527023434197};\\\", \\\"{x:821,y:545,t:1527023434204};\\\", \\\"{x:816,y:545,t:1527023434219};\\\", \\\"{x:781,y:545,t:1527023434235};\\\", \\\"{x:609,y:545,t:1527023434252};\\\", \\\"{x:454,y:520,t:1527023434270};\\\", \\\"{x:338,y:521,t:1527023434285};\\\", \\\"{x:309,y:519,t:1527023434302};\\\", \\\"{x:294,y:511,t:1527023434318};\\\", \\\"{x:295,y:509,t:1527023434477};\\\", \\\"{x:298,y:505,t:1527023434485};\\\", \\\"{x:312,y:496,t:1527023434503};\\\", \\\"{x:336,y:488,t:1527023434520};\\\", \\\"{x:363,y:479,t:1527023434535};\\\", \\\"{x:412,y:470,t:1527023434553};\\\", \\\"{x:486,y:452,t:1527023434569};\\\", \\\"{x:522,y:447,t:1527023434586};\\\", \\\"{x:631,y:428,t:1527023434602};\\\", \\\"{x:718,y:409,t:1527023434620};\\\", \\\"{x:762,y:402,t:1527023434636};\\\", \\\"{x:765,y:402,t:1527023434652};\\\", \\\"{x:766,y:402,t:1527023434669};\\\", \\\"{x:766,y:401,t:1527023434692};\\\", \\\"{x:766,y:400,t:1527023434708};\\\", \\\"{x:762,y:397,t:1527023434720};\\\", \\\"{x:748,y:395,t:1527023434736};\\\", \\\"{x:746,y:395,t:1527023434752};\\\", \\\"{x:745,y:394,t:1527023439869};\\\", \\\"{x:743,y:389,t:1527023439876};\\\", \\\"{x:743,y:387,t:1527023439893};\\\", \\\"{x:742,y:386,t:1527023439905};\\\", \\\"{x:745,y:385,t:1527023439932};\\\", \\\"{x:752,y:382,t:1527023439940};\\\", \\\"{x:757,y:382,t:1527023439955};\\\", \\\"{x:761,y:385,t:1527023439972};\\\", \\\"{x:761,y:391,t:1527023439989};\\\", \\\"{x:761,y:406,t:1527023440005};\\\", \\\"{x:757,y:422,t:1527023440022};\\\", \\\"{x:751,y:437,t:1527023440040};\\\", \\\"{x:748,y:446,t:1527023440055};\\\", \\\"{x:747,y:450,t:1527023440072};\\\", \\\"{x:744,y:455,t:1527023440089};\\\", \\\"{x:740,y:462,t:1527023440105};\\\", \\\"{x:729,y:472,t:1527023440123};\\\", \\\"{x:716,y:484,t:1527023440139};\\\", \\\"{x:702,y:494,t:1527023440154};\\\", \\\"{x:675,y:522,t:1527023440174};\\\", \\\"{x:660,y:545,t:1527023440191};\\\", \\\"{x:633,y:585,t:1527023440208};\\\", \\\"{x:598,y:630,t:1527023440223};\\\", \\\"{x:564,y:688,t:1527023440241};\\\", \\\"{x:528,y:741,t:1527023440258};\\\", \\\"{x:498,y:780,t:1527023440273};\\\", \\\"{x:482,y:807,t:1527023440291};\\\", \\\"{x:471,y:825,t:1527023440308};\\\", \\\"{x:470,y:827,t:1527023440323};\\\", \\\"{x:469,y:826,t:1527023440388};\\\", \\\"{x:469,y:823,t:1527023440396};\\\", \\\"{x:469,y:818,t:1527023440408};\\\", \\\"{x:469,y:805,t:1527023440424};\\\", \\\"{x:469,y:794,t:1527023440441};\\\", \\\"{x:469,y:776,t:1527023440458};\\\", \\\"{x:477,y:763,t:1527023440475};\\\", \\\"{x:497,y:735,t:1527023440492};\\\", \\\"{x:511,y:718,t:1527023440508};\\\", \\\"{x:522,y:706,t:1527023440525};\\\", \\\"{x:526,y:698,t:1527023440543};\\\", \\\"{x:527,y:695,t:1527023440559};\\\", \\\"{x:528,y:694,t:1527023440574};\\\", \\\"{x:528,y:692,t:1527023441412};\\\", \\\"{x:528,y:688,t:1527023441424};\\\", \\\"{x:528,y:682,t:1527023441441};\\\", \\\"{x:528,y:675,t:1527023441457};\\\", \\\"{x:528,y:665,t:1527023441474};\\\", \\\"{x:525,y:653,t:1527023441491};\\\", \\\"{x:524,y:648,t:1527023441508};\\\", \\\"{x:524,y:647,t:1527023442196};\\\" ] }, { \\\"rt\\\": 17545, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 516870, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"JYZGH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B -O -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:536,y:639,t:1527023442396};\\\", \\\"{x:535,y:639,t:1527023442812};\\\", \\\"{x:533,y:639,t:1527023442826};\\\", \\\"{x:527,y:640,t:1527023442843};\\\", \\\"{x:518,y:640,t:1527023442859};\\\", \\\"{x:509,y:639,t:1527023442875};\\\", \\\"{x:499,y:638,t:1527023442893};\\\", \\\"{x:489,y:637,t:1527023442910};\\\", \\\"{x:480,y:635,t:1527023442926};\\\", \\\"{x:474,y:635,t:1527023442943};\\\", \\\"{x:460,y:635,t:1527023442959};\\\", \\\"{x:443,y:635,t:1527023442976};\\\", \\\"{x:424,y:635,t:1527023442993};\\\", \\\"{x:408,y:630,t:1527023443010};\\\", \\\"{x:385,y:619,t:1527023443026};\\\", \\\"{x:353,y:606,t:1527023443044};\\\", \\\"{x:304,y:582,t:1527023443060};\\\", \\\"{x:260,y:575,t:1527023443076};\\\", \\\"{x:231,y:569,t:1527023443092};\\\", \\\"{x:214,y:564,t:1527023443109};\\\", \\\"{x:209,y:560,t:1527023443126};\\\", \\\"{x:203,y:557,t:1527023443142};\\\", \\\"{x:200,y:551,t:1527023443159};\\\", \\\"{x:200,y:544,t:1527023443176};\\\", \\\"{x:200,y:542,t:1527023443192};\\\", \\\"{x:200,y:540,t:1527023443982};\\\", \\\"{x:200,y:539,t:1527023444004};\\\", \\\"{x:200,y:537,t:1527023444058};\\\", \\\"{x:201,y:537,t:1527023444060};\\\", \\\"{x:201,y:536,t:1527023444083};\\\", \\\"{x:202,y:536,t:1527023444093};\\\", \\\"{x:204,y:534,t:1527023444111};\\\", \\\"{x:207,y:532,t:1527023444126};\\\", \\\"{x:213,y:528,t:1527023444144};\\\", \\\"{x:220,y:526,t:1527023444160};\\\", \\\"{x:234,y:518,t:1527023444177};\\\", \\\"{x:255,y:511,t:1527023444193};\\\", \\\"{x:284,y:501,t:1527023444212};\\\", \\\"{x:320,y:492,t:1527023444227};\\\", \\\"{x:367,y:478,t:1527023444244};\\\", \\\"{x:397,y:468,t:1527023444262};\\\", \\\"{x:431,y:458,t:1527023444277};\\\", \\\"{x:463,y:448,t:1527023444294};\\\", \\\"{x:496,y:438,t:1527023444310};\\\", \\\"{x:533,y:430,t:1527023444327};\\\", \\\"{x:582,y:413,t:1527023444344};\\\", \\\"{x:611,y:407,t:1527023444361};\\\", \\\"{x:637,y:400,t:1527023444377};\\\", \\\"{x:657,y:396,t:1527023444394};\\\", \\\"{x:672,y:394,t:1527023444411};\\\", \\\"{x:689,y:390,t:1527023444426};\\\", \\\"{x:707,y:387,t:1527023444444};\\\", \\\"{x:721,y:386,t:1527023444461};\\\", \\\"{x:734,y:386,t:1527023444478};\\\", \\\"{x:756,y:386,t:1527023444494};\\\", \\\"{x:781,y:386,t:1527023444510};\\\", \\\"{x:807,y:386,t:1527023444527};\\\", \\\"{x:850,y:389,t:1527023444544};\\\", \\\"{x:916,y:402,t:1527023444560};\\\", \\\"{x:995,y:421,t:1527023444578};\\\", \\\"{x:1083,y:440,t:1527023444594};\\\", \\\"{x:1180,y:454,t:1527023444611};\\\", \\\"{x:1291,y:478,t:1527023444627};\\\", \\\"{x:1342,y:485,t:1527023444644};\\\", \\\"{x:1372,y:492,t:1527023444661};\\\", \\\"{x:1400,y:498,t:1527023444678};\\\", \\\"{x:1424,y:503,t:1527023444693};\\\", \\\"{x:1436,y:505,t:1527023444711};\\\", \\\"{x:1448,y:506,t:1527023444728};\\\", \\\"{x:1457,y:508,t:1527023444744};\\\", \\\"{x:1465,y:509,t:1527023444760};\\\", \\\"{x:1476,y:512,t:1527023444778};\\\", \\\"{x:1493,y:518,t:1527023444794};\\\", \\\"{x:1515,y:523,t:1527023444811};\\\", \\\"{x:1549,y:531,t:1527023444828};\\\", \\\"{x:1576,y:534,t:1527023444845};\\\", \\\"{x:1601,y:540,t:1527023444862};\\\", \\\"{x:1619,y:542,t:1527023444878};\\\", \\\"{x:1635,y:545,t:1527023444895};\\\", \\\"{x:1647,y:546,t:1527023444911};\\\", \\\"{x:1655,y:547,t:1527023444928};\\\", \\\"{x:1656,y:547,t:1527023445005};\\\", \\\"{x:1656,y:546,t:1527023445021};\\\", \\\"{x:1656,y:544,t:1527023445028};\\\", \\\"{x:1656,y:542,t:1527023445045};\\\", \\\"{x:1654,y:539,t:1527023445062};\\\", \\\"{x:1646,y:531,t:1527023445079};\\\", \\\"{x:1638,y:529,t:1527023445095};\\\", \\\"{x:1626,y:524,t:1527023445111};\\\", \\\"{x:1614,y:519,t:1527023445127};\\\", \\\"{x:1599,y:515,t:1527023445145};\\\", \\\"{x:1583,y:511,t:1527023445161};\\\", \\\"{x:1572,y:511,t:1527023445177};\\\", \\\"{x:1563,y:510,t:1527023445195};\\\", \\\"{x:1554,y:509,t:1527023445211};\\\", \\\"{x:1535,y:506,t:1527023445227};\\\", \\\"{x:1515,y:504,t:1527023445245};\\\", \\\"{x:1497,y:504,t:1527023445261};\\\", \\\"{x:1480,y:504,t:1527023445278};\\\", \\\"{x:1461,y:504,t:1527023445295};\\\", \\\"{x:1445,y:507,t:1527023445311};\\\", \\\"{x:1430,y:513,t:1527023445327};\\\", \\\"{x:1420,y:520,t:1527023445345};\\\", \\\"{x:1411,y:531,t:1527023445362};\\\", \\\"{x:1398,y:550,t:1527023445378};\\\", \\\"{x:1386,y:569,t:1527023445395};\\\", \\\"{x:1378,y:578,t:1527023445412};\\\", \\\"{x:1374,y:585,t:1527023445428};\\\", \\\"{x:1375,y:592,t:1527023445446};\\\", \\\"{x:1377,y:592,t:1527023445462};\\\", \\\"{x:1377,y:593,t:1527023445478};\\\", \\\"{x:1378,y:593,t:1527023445496};\\\", \\\"{x:1379,y:593,t:1527023445517};\\\", \\\"{x:1381,y:596,t:1527023445528};\\\", \\\"{x:1383,y:602,t:1527023445545};\\\", \\\"{x:1387,y:606,t:1527023445562};\\\", \\\"{x:1390,y:612,t:1527023445578};\\\", \\\"{x:1395,y:619,t:1527023445595};\\\", \\\"{x:1404,y:637,t:1527023445612};\\\", \\\"{x:1411,y:648,t:1527023445628};\\\", \\\"{x:1420,y:658,t:1527023445645};\\\", \\\"{x:1434,y:670,t:1527023445662};\\\", \\\"{x:1444,y:679,t:1527023445678};\\\", \\\"{x:1461,y:691,t:1527023445695};\\\", \\\"{x:1479,y:703,t:1527023445712};\\\", \\\"{x:1496,y:714,t:1527023445729};\\\", \\\"{x:1512,y:726,t:1527023445745};\\\", \\\"{x:1523,y:732,t:1527023445762};\\\", \\\"{x:1534,y:740,t:1527023445779};\\\", \\\"{x:1545,y:746,t:1527023445795};\\\", \\\"{x:1548,y:748,t:1527023445812};\\\", \\\"{x:1549,y:749,t:1527023445828};\\\", \\\"{x:1550,y:750,t:1527023445940};\\\", \\\"{x:1551,y:750,t:1527023445956};\\\", \\\"{x:1552,y:749,t:1527023445964};\\\", \\\"{x:1552,y:744,t:1527023445980};\\\", \\\"{x:1549,y:730,t:1527023445995};\\\", \\\"{x:1548,y:714,t:1527023446013};\\\", \\\"{x:1548,y:712,t:1527023447045};\\\", \\\"{x:1547,y:712,t:1527023447053};\\\", \\\"{x:1547,y:711,t:1527023447069};\\\", \\\"{x:1547,y:710,t:1527023447079};\\\", \\\"{x:1546,y:708,t:1527023447096};\\\", \\\"{x:1546,y:706,t:1527023447112};\\\", \\\"{x:1545,y:704,t:1527023447130};\\\", \\\"{x:1543,y:702,t:1527023447145};\\\", \\\"{x:1541,y:699,t:1527023447162};\\\", \\\"{x:1539,y:694,t:1527023447179};\\\", \\\"{x:1537,y:689,t:1527023447196};\\\", \\\"{x:1533,y:684,t:1527023447213};\\\", \\\"{x:1529,y:679,t:1527023447230};\\\", \\\"{x:1524,y:674,t:1527023447246};\\\", \\\"{x:1518,y:668,t:1527023447263};\\\", \\\"{x:1513,y:664,t:1527023447280};\\\", \\\"{x:1508,y:662,t:1527023447296};\\\", \\\"{x:1503,y:658,t:1527023447313};\\\", \\\"{x:1494,y:651,t:1527023447330};\\\", \\\"{x:1483,y:644,t:1527023447346};\\\", \\\"{x:1477,y:641,t:1527023447363};\\\", \\\"{x:1468,y:636,t:1527023447380};\\\", \\\"{x:1462,y:632,t:1527023447396};\\\", \\\"{x:1452,y:625,t:1527023447413};\\\", \\\"{x:1443,y:621,t:1527023447430};\\\", \\\"{x:1436,y:618,t:1527023447446};\\\", \\\"{x:1431,y:615,t:1527023447463};\\\", \\\"{x:1429,y:612,t:1527023447480};\\\", \\\"{x:1425,y:610,t:1527023447496};\\\", \\\"{x:1424,y:609,t:1527023447513};\\\", \\\"{x:1422,y:608,t:1527023447530};\\\", \\\"{x:1421,y:607,t:1527023447547};\\\", \\\"{x:1420,y:605,t:1527023447563};\\\", \\\"{x:1418,y:605,t:1527023451389};\\\", \\\"{x:1416,y:605,t:1527023451399};\\\", \\\"{x:1402,y:615,t:1527023451417};\\\", \\\"{x:1395,y:624,t:1527023451433};\\\", \\\"{x:1391,y:633,t:1527023451450};\\\", \\\"{x:1384,y:644,t:1527023451466};\\\", \\\"{x:1376,y:654,t:1527023451483};\\\", \\\"{x:1365,y:667,t:1527023451499};\\\", \\\"{x:1360,y:673,t:1527023451516};\\\", \\\"{x:1355,y:679,t:1527023451533};\\\", \\\"{x:1352,y:686,t:1527023451550};\\\", \\\"{x:1349,y:690,t:1527023451565};\\\", \\\"{x:1347,y:693,t:1527023451584};\\\", \\\"{x:1347,y:699,t:1527023451600};\\\", \\\"{x:1347,y:707,t:1527023451617};\\\", \\\"{x:1347,y:711,t:1527023451633};\\\", \\\"{x:1347,y:716,t:1527023451651};\\\", \\\"{x:1347,y:719,t:1527023451666};\\\", \\\"{x:1347,y:720,t:1527023451683};\\\", \\\"{x:1346,y:720,t:1527023451796};\\\", \\\"{x:1343,y:720,t:1527023451804};\\\", \\\"{x:1343,y:719,t:1527023451820};\\\", \\\"{x:1343,y:718,t:1527023451833};\\\", \\\"{x:1347,y:714,t:1527023451850};\\\", \\\"{x:1353,y:712,t:1527023451866};\\\", \\\"{x:1360,y:709,t:1527023451883};\\\", \\\"{x:1375,y:703,t:1527023451899};\\\", \\\"{x:1388,y:702,t:1527023451917};\\\", \\\"{x:1414,y:702,t:1527023451933};\\\", \\\"{x:1441,y:702,t:1527023451950};\\\", \\\"{x:1463,y:703,t:1527023451967};\\\", \\\"{x:1484,y:703,t:1527023451983};\\\", \\\"{x:1500,y:703,t:1527023452000};\\\", \\\"{x:1514,y:703,t:1527023452017};\\\", \\\"{x:1521,y:703,t:1527023452033};\\\", \\\"{x:1525,y:703,t:1527023452050};\\\", \\\"{x:1529,y:703,t:1527023452067};\\\", \\\"{x:1533,y:703,t:1527023452083};\\\", \\\"{x:1536,y:703,t:1527023452100};\\\", \\\"{x:1537,y:703,t:1527023452118};\\\", \\\"{x:1538,y:703,t:1527023452437};\\\", \\\"{x:1537,y:703,t:1527023452493};\\\", \\\"{x:1535,y:704,t:1527023452516};\\\", \\\"{x:1534,y:704,t:1527023452535};\\\", \\\"{x:1532,y:705,t:1527023452550};\\\", \\\"{x:1531,y:705,t:1527023452567};\\\", \\\"{x:1529,y:706,t:1527023452584};\\\", \\\"{x:1527,y:707,t:1527023452601};\\\", \\\"{x:1523,y:707,t:1527023452618};\\\", \\\"{x:1520,y:707,t:1527023452635};\\\", \\\"{x:1513,y:707,t:1527023452651};\\\", \\\"{x:1504,y:709,t:1527023452669};\\\", \\\"{x:1488,y:710,t:1527023452684};\\\", \\\"{x:1481,y:712,t:1527023452701};\\\", \\\"{x:1474,y:712,t:1527023452717};\\\", \\\"{x:1473,y:712,t:1527023452734};\\\", \\\"{x:1472,y:713,t:1527023452755};\\\", \\\"{x:1471,y:713,t:1527023452771};\\\", \\\"{x:1470,y:713,t:1527023452795};\\\", \\\"{x:1468,y:713,t:1527023452828};\\\", \\\"{x:1468,y:712,t:1527023452988};\\\", \\\"{x:1469,y:711,t:1527023453012};\\\", \\\"{x:1470,y:710,t:1527023453020};\\\", \\\"{x:1471,y:709,t:1527023453035};\\\", \\\"{x:1472,y:709,t:1527023453052};\\\", \\\"{x:1473,y:709,t:1527023453067};\\\", \\\"{x:1474,y:708,t:1527023453085};\\\", \\\"{x:1475,y:708,t:1527023453102};\\\", \\\"{x:1477,y:708,t:1527023453118};\\\", \\\"{x:1478,y:708,t:1527023453135};\\\", \\\"{x:1481,y:707,t:1527023453151};\\\", \\\"{x:1483,y:707,t:1527023453167};\\\", \\\"{x:1485,y:707,t:1527023453184};\\\", \\\"{x:1486,y:707,t:1527023453201};\\\", \\\"{x:1487,y:706,t:1527023453219};\\\", \\\"{x:1488,y:706,t:1527023453236};\\\", \\\"{x:1489,y:706,t:1527023453341};\\\", \\\"{x:1490,y:706,t:1527023453364};\\\", \\\"{x:1491,y:706,t:1527023453389};\\\", \\\"{x:1492,y:706,t:1527023453444};\\\", \\\"{x:1493,y:706,t:1527023453476};\\\", \\\"{x:1495,y:706,t:1527023453501};\\\", \\\"{x:1496,y:706,t:1527023453518};\\\", \\\"{x:1497,y:706,t:1527023454260};\\\", \\\"{x:1499,y:706,t:1527023454581};\\\", \\\"{x:1499,y:705,t:1527023454588};\\\", \\\"{x:1500,y:704,t:1527023454604};\\\", \\\"{x:1501,y:702,t:1527023454644};\\\", \\\"{x:1499,y:702,t:1527023455132};\\\", \\\"{x:1496,y:702,t:1527023455140};\\\", \\\"{x:1491,y:705,t:1527023455152};\\\", \\\"{x:1473,y:709,t:1527023455169};\\\", \\\"{x:1450,y:713,t:1527023455186};\\\", \\\"{x:1424,y:713,t:1527023455202};\\\", \\\"{x:1335,y:700,t:1527023455219};\\\", \\\"{x:1265,y:691,t:1527023455236};\\\", \\\"{x:1190,y:681,t:1527023455252};\\\", \\\"{x:1128,y:671,t:1527023455269};\\\", \\\"{x:1067,y:664,t:1527023455286};\\\", \\\"{x:1020,y:658,t:1527023455302};\\\", \\\"{x:979,y:650,t:1527023455319};\\\", \\\"{x:949,y:645,t:1527023455336};\\\", \\\"{x:925,y:642,t:1527023455352};\\\", \\\"{x:903,y:639,t:1527023455369};\\\", \\\"{x:883,y:634,t:1527023455386};\\\", \\\"{x:855,y:631,t:1527023455404};\\\", \\\"{x:843,y:631,t:1527023455419};\\\", \\\"{x:818,y:628,t:1527023455435};\\\", \\\"{x:816,y:628,t:1527023455453};\\\", \\\"{x:814,y:628,t:1527023455469};\\\", \\\"{x:812,y:628,t:1527023455540};\\\", \\\"{x:811,y:628,t:1527023455564};\\\", \\\"{x:811,y:627,t:1527023455580};\\\", \\\"{x:810,y:627,t:1527023455588};\\\", \\\"{x:808,y:627,t:1527023455604};\\\", \\\"{x:805,y:625,t:1527023455620};\\\", \\\"{x:804,y:624,t:1527023455636};\\\", \\\"{x:800,y:622,t:1527023455653};\\\", \\\"{x:792,y:616,t:1527023455669};\\\", \\\"{x:773,y:606,t:1527023455686};\\\", \\\"{x:736,y:581,t:1527023455704};\\\", \\\"{x:689,y:550,t:1527023455721};\\\", \\\"{x:623,y:521,t:1527023455737};\\\", \\\"{x:549,y:493,t:1527023455754};\\\", \\\"{x:491,y:468,t:1527023455770};\\\", \\\"{x:406,y:435,t:1527023455786};\\\", \\\"{x:296,y:404,t:1527023455803};\\\", \\\"{x:250,y:397,t:1527023455820};\\\", \\\"{x:220,y:391,t:1527023455836};\\\", \\\"{x:202,y:389,t:1527023455853};\\\", \\\"{x:189,y:387,t:1527023455870};\\\", \\\"{x:180,y:386,t:1527023455886};\\\", \\\"{x:173,y:386,t:1527023455903};\\\", \\\"{x:164,y:386,t:1527023455920};\\\", \\\"{x:155,y:388,t:1527023455937};\\\", \\\"{x:138,y:392,t:1527023455953};\\\", \\\"{x:132,y:397,t:1527023455970};\\\", \\\"{x:122,y:408,t:1527023455987};\\\", \\\"{x:119,y:422,t:1527023456004};\\\", \\\"{x:119,y:436,t:1527023456020};\\\", \\\"{x:122,y:446,t:1527023456037};\\\", \\\"{x:126,y:451,t:1527023456053};\\\", \\\"{x:128,y:452,t:1527023456070};\\\", \\\"{x:129,y:452,t:1527023456088};\\\", \\\"{x:129,y:453,t:1527023456103};\\\", \\\"{x:130,y:453,t:1527023456221};\\\", \\\"{x:131,y:453,t:1527023456244};\\\", \\\"{x:132,y:453,t:1527023456253};\\\", \\\"{x:137,y:453,t:1527023456270};\\\", \\\"{x:145,y:453,t:1527023456287};\\\", \\\"{x:153,y:454,t:1527023456304};\\\", \\\"{x:168,y:456,t:1527023456320};\\\", \\\"{x:182,y:457,t:1527023456337};\\\", \\\"{x:190,y:457,t:1527023456353};\\\", \\\"{x:193,y:457,t:1527023456370};\\\", \\\"{x:194,y:457,t:1527023456387};\\\", \\\"{x:195,y:457,t:1527023456411};\\\", \\\"{x:195,y:456,t:1527023456427};\\\", \\\"{x:195,y:454,t:1527023456437};\\\", \\\"{x:191,y:453,t:1527023456453};\\\", \\\"{x:190,y:452,t:1527023456476};\\\", \\\"{x:188,y:452,t:1527023456488};\\\", \\\"{x:186,y:452,t:1527023456508};\\\", \\\"{x:186,y:451,t:1527023456520};\\\", \\\"{x:184,y:450,t:1527023456537};\\\", \\\"{x:183,y:450,t:1527023456554};\\\", \\\"{x:182,y:450,t:1527023456570};\\\", \\\"{x:177,y:450,t:1527023456586};\\\", \\\"{x:176,y:450,t:1527023456604};\\\", \\\"{x:174,y:450,t:1527023456620};\\\", \\\"{x:172,y:451,t:1527023456638};\\\", \\\"{x:171,y:451,t:1527023456654};\\\", \\\"{x:169,y:451,t:1527023456670};\\\", \\\"{x:167,y:451,t:1527023456688};\\\", \\\"{x:166,y:451,t:1527023456704};\\\", \\\"{x:165,y:451,t:1527023456720};\\\", \\\"{x:166,y:452,t:1527023456964};\\\", \\\"{x:177,y:454,t:1527023456971};\\\", \\\"{x:256,y:465,t:1527023456988};\\\", \\\"{x:388,y:475,t:1527023457004};\\\", \\\"{x:542,y:488,t:1527023457021};\\\", \\\"{x:701,y:499,t:1527023457037};\\\", \\\"{x:829,y:505,t:1527023457054};\\\", \\\"{x:913,y:509,t:1527023457071};\\\", \\\"{x:964,y:517,t:1527023457087};\\\", \\\"{x:987,y:521,t:1527023457104};\\\", \\\"{x:996,y:521,t:1527023457121};\\\", \\\"{x:999,y:521,t:1527023457137};\\\", \\\"{x:1001,y:521,t:1527023457154};\\\", \\\"{x:1003,y:520,t:1527023457171};\\\", \\\"{x:1005,y:520,t:1527023457228};\\\", \\\"{x:1005,y:519,t:1527023457238};\\\", \\\"{x:1005,y:514,t:1527023457254};\\\", \\\"{x:1001,y:510,t:1527023457271};\\\", \\\"{x:994,y:508,t:1527023457288};\\\", \\\"{x:979,y:506,t:1527023457305};\\\", \\\"{x:961,y:506,t:1527023457321};\\\", \\\"{x:939,y:506,t:1527023457338};\\\", \\\"{x:917,y:509,t:1527023457355};\\\", \\\"{x:894,y:514,t:1527023457373};\\\", \\\"{x:884,y:518,t:1527023457388};\\\", \\\"{x:879,y:521,t:1527023457404};\\\", \\\"{x:877,y:522,t:1527023457421};\\\", \\\"{x:876,y:523,t:1527023457438};\\\", \\\"{x:875,y:523,t:1527023457454};\\\", \\\"{x:874,y:523,t:1527023457483};\\\", \\\"{x:873,y:523,t:1527023457491};\\\", \\\"{x:872,y:523,t:1527023457504};\\\", \\\"{x:871,y:523,t:1527023457521};\\\", \\\"{x:870,y:523,t:1527023457538};\\\", \\\"{x:866,y:523,t:1527023457554};\\\", \\\"{x:859,y:522,t:1527023457572};\\\", \\\"{x:849,y:519,t:1527023457587};\\\", \\\"{x:840,y:519,t:1527023457604};\\\", \\\"{x:833,y:519,t:1527023457622};\\\", \\\"{x:828,y:519,t:1527023457638};\\\", \\\"{x:826,y:519,t:1527023457654};\\\", \\\"{x:825,y:519,t:1527023457672};\\\", \\\"{x:826,y:519,t:1527023459180};\\\", \\\"{x:828,y:519,t:1527023459204};\\\", \\\"{x:831,y:519,t:1527023459212};\\\", \\\"{x:833,y:522,t:1527023459223};\\\", \\\"{x:840,y:530,t:1527023459239};\\\", \\\"{x:847,y:542,t:1527023459257};\\\", \\\"{x:853,y:556,t:1527023459273};\\\", \\\"{x:858,y:573,t:1527023459290};\\\", \\\"{x:858,y:592,t:1527023459307};\\\", \\\"{x:858,y:618,t:1527023459323};\\\", \\\"{x:856,y:635,t:1527023459339};\\\", \\\"{x:851,y:650,t:1527023459357};\\\", \\\"{x:846,y:661,t:1527023459374};\\\", \\\"{x:832,y:680,t:1527023459389};\\\", \\\"{x:820,y:693,t:1527023459406};\\\", \\\"{x:806,y:701,t:1527023459424};\\\", \\\"{x:793,y:706,t:1527023459440};\\\", \\\"{x:779,y:709,t:1527023459457};\\\", \\\"{x:751,y:712,t:1527023459474};\\\", \\\"{x:717,y:711,t:1527023459490};\\\", \\\"{x:637,y:700,t:1527023459506};\\\", \\\"{x:566,y:691,t:1527023459524};\\\", \\\"{x:534,y:686,t:1527023459542};\\\", \\\"{x:520,y:685,t:1527023459558};\\\", \\\"{x:517,y:684,t:1527023459573};\\\", \\\"{x:516,y:683,t:1527023459589};\\\", \\\"{x:515,y:683,t:1527023459643};\\\", \\\"{x:514,y:683,t:1527023459796};\\\", \\\"{x:513,y:682,t:1527023460660};\\\", \\\"{x:513,y:681,t:1527023460683};\\\", \\\"{x:514,y:680,t:1527023460716};\\\", \\\"{x:514,y:679,t:1527023460747};\\\", \\\"{x:516,y:677,t:1527023460771};\\\", \\\"{x:516,y:676,t:1527023460923};\\\", \\\"{x:517,y:676,t:1527023460974};\\\", \\\"{x:517,y:675,t:1527023461003};\\\", \\\"{x:518,y:674,t:1527023461043};\\\" ] }, { \\\"rt\\\": 7746, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 525834, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"JYZGH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:519,y:673,t:1527023461427};\\\", \\\"{x:519,y:672,t:1527023461459};\\\", \\\"{x:519,y:671,t:1527023461474};\\\", \\\"{x:519,y:669,t:1527023461490};\\\", \\\"{x:520,y:667,t:1527023461508};\\\", \\\"{x:521,y:663,t:1527023461525};\\\", \\\"{x:522,y:660,t:1527023461541};\\\", \\\"{x:522,y:635,t:1527023461603};\\\", \\\"{x:522,y:627,t:1527023461609};\\\", \\\"{x:521,y:611,t:1527023461624};\\\", \\\"{x:519,y:596,t:1527023461641};\\\", \\\"{x:517,y:585,t:1527023461659};\\\", \\\"{x:515,y:570,t:1527023461674};\\\", \\\"{x:511,y:556,t:1527023461691};\\\", \\\"{x:511,y:547,t:1527023461708};\\\", \\\"{x:511,y:539,t:1527023461725};\\\", \\\"{x:510,y:528,t:1527023461741};\\\", \\\"{x:507,y:516,t:1527023461758};\\\", \\\"{x:507,y:509,t:1527023461774};\\\", \\\"{x:506,y:501,t:1527023461792};\\\", \\\"{x:506,y:495,t:1527023461809};\\\", \\\"{x:508,y:488,t:1527023461825};\\\", \\\"{x:509,y:478,t:1527023461841};\\\", \\\"{x:511,y:472,t:1527023461859};\\\", \\\"{x:515,y:461,t:1527023461876};\\\", \\\"{x:517,y:452,t:1527023461891};\\\", \\\"{x:520,y:444,t:1527023461908};\\\", \\\"{x:521,y:437,t:1527023461925};\\\", \\\"{x:522,y:432,t:1527023461942};\\\", \\\"{x:522,y:429,t:1527023461959};\\\", \\\"{x:522,y:427,t:1527023461975};\\\", \\\"{x:523,y:425,t:1527023461991};\\\", \\\"{x:523,y:423,t:1527023462009};\\\", \\\"{x:523,y:422,t:1527023462026};\\\", \\\"{x:523,y:421,t:1527023462044};\\\", \\\"{x:523,y:420,t:1527023462059};\\\", \\\"{x:523,y:419,t:1527023462075};\\\", \\\"{x:522,y:418,t:1527023462091};\\\", \\\"{x:522,y:417,t:1527023462109};\\\", \\\"{x:521,y:417,t:1527023462125};\\\", \\\"{x:520,y:417,t:1527023462180};\\\", \\\"{x:519,y:417,t:1527023462220};\\\", \\\"{x:518,y:417,t:1527023462236};\\\", \\\"{x:517,y:417,t:1527023462252};\\\", \\\"{x:516,y:417,t:1527023462300};\\\", \\\"{x:515,y:417,t:1527023462323};\\\", \\\"{x:514,y:417,t:1527023462355};\\\", \\\"{x:513,y:417,t:1527023462364};\\\", \\\"{x:512,y:417,t:1527023462379};\\\", \\\"{x:511,y:417,t:1527023462395};\\\", \\\"{x:510,y:417,t:1527023462411};\\\", \\\"{x:509,y:417,t:1527023462426};\\\", \\\"{x:507,y:418,t:1527023462442};\\\", \\\"{x:505,y:418,t:1527023462459};\\\", \\\"{x:504,y:420,t:1527023462476};\\\", \\\"{x:502,y:420,t:1527023462492};\\\", \\\"{x:500,y:421,t:1527023462509};\\\", \\\"{x:498,y:422,t:1527023462525};\\\", \\\"{x:497,y:422,t:1527023462543};\\\", \\\"{x:496,y:422,t:1527023465516};\\\", \\\"{x:482,y:425,t:1527023465528};\\\", \\\"{x:459,y:435,t:1527023465546};\\\", \\\"{x:441,y:449,t:1527023465561};\\\", \\\"{x:425,y:459,t:1527023465577};\\\", \\\"{x:404,y:467,t:1527023465594};\\\", \\\"{x:383,y:476,t:1527023465611};\\\", \\\"{x:378,y:478,t:1527023465627};\\\", \\\"{x:377,y:479,t:1527023465644};\\\", \\\"{x:375,y:479,t:1527023465662};\\\", \\\"{x:373,y:482,t:1527023465677};\\\", \\\"{x:371,y:484,t:1527023465695};\\\", \\\"{x:369,y:488,t:1527023465711};\\\", \\\"{x:368,y:493,t:1527023465727};\\\", \\\"{x:368,y:495,t:1527023465744};\\\", \\\"{x:368,y:496,t:1527023465761};\\\", \\\"{x:368,y:499,t:1527023465779};\\\", \\\"{x:371,y:503,t:1527023465795};\\\", \\\"{x:380,y:507,t:1527023465811};\\\", \\\"{x:392,y:509,t:1527023465829};\\\", \\\"{x:411,y:513,t:1527023465845};\\\", \\\"{x:444,y:518,t:1527023465862};\\\", \\\"{x:492,y:526,t:1527023465877};\\\", \\\"{x:562,y:536,t:1527023465895};\\\", \\\"{x:637,y:547,t:1527023465912};\\\", \\\"{x:698,y:554,t:1527023465928};\\\", \\\"{x:767,y:562,t:1527023465945};\\\", \\\"{x:813,y:568,t:1527023465961};\\\", \\\"{x:840,y:569,t:1527023465979};\\\", \\\"{x:862,y:569,t:1527023465995};\\\", \\\"{x:866,y:569,t:1527023466011};\\\", \\\"{x:867,y:569,t:1527023466028};\\\", \\\"{x:867,y:568,t:1527023466045};\\\", \\\"{x:867,y:567,t:1527023466092};\\\", \\\"{x:867,y:566,t:1527023466099};\\\", \\\"{x:867,y:565,t:1527023466111};\\\", \\\"{x:869,y:563,t:1527023466130};\\\", \\\"{x:874,y:560,t:1527023466144};\\\", \\\"{x:877,y:559,t:1527023466161};\\\", \\\"{x:877,y:558,t:1527023466178};\\\", \\\"{x:876,y:558,t:1527023466194};\\\", \\\"{x:872,y:558,t:1527023466211};\\\", \\\"{x:868,y:558,t:1527023466228};\\\", \\\"{x:864,y:559,t:1527023466244};\\\", \\\"{x:857,y:562,t:1527023466261};\\\", \\\"{x:854,y:564,t:1527023466278};\\\", \\\"{x:852,y:566,t:1527023466295};\\\", \\\"{x:850,y:566,t:1527023466312};\\\", \\\"{x:849,y:567,t:1527023466340};\\\", \\\"{x:848,y:567,t:1527023466347};\\\", \\\"{x:847,y:567,t:1527023466361};\\\", \\\"{x:846,y:568,t:1527023466379};\\\", \\\"{x:844,y:568,t:1527023466396};\\\", \\\"{x:843,y:569,t:1527023466876};\\\", \\\"{x:842,y:573,t:1527023466883};\\\", \\\"{x:841,y:578,t:1527023466897};\\\", \\\"{x:838,y:586,t:1527023466913};\\\", \\\"{x:835,y:594,t:1527023466929};\\\", \\\"{x:830,y:603,t:1527023466946};\\\", \\\"{x:828,y:612,t:1527023466962};\\\", \\\"{x:823,y:622,t:1527023466979};\\\", \\\"{x:813,y:640,t:1527023466995};\\\", \\\"{x:800,y:656,t:1527023467012};\\\", \\\"{x:786,y:670,t:1527023467029};\\\", \\\"{x:770,y:683,t:1527023467046};\\\", \\\"{x:754,y:698,t:1527023467063};\\\", \\\"{x:733,y:712,t:1527023467078};\\\", \\\"{x:714,y:726,t:1527023467096};\\\", \\\"{x:701,y:738,t:1527023467113};\\\", \\\"{x:688,y:746,t:1527023467129};\\\", \\\"{x:681,y:752,t:1527023467146};\\\", \\\"{x:674,y:755,t:1527023467162};\\\", \\\"{x:670,y:757,t:1527023467179};\\\", \\\"{x:669,y:758,t:1527023467196};\\\", \\\"{x:666,y:758,t:1527023467213};\\\", \\\"{x:666,y:759,t:1527023467230};\\\", \\\"{x:664,y:759,t:1527023467246};\\\", \\\"{x:659,y:759,t:1527023467263};\\\", \\\"{x:653,y:759,t:1527023467280};\\\", \\\"{x:648,y:759,t:1527023467296};\\\", \\\"{x:640,y:759,t:1527023467313};\\\", \\\"{x:639,y:759,t:1527023467328};\\\", \\\"{x:637,y:759,t:1527023467346};\\\", \\\"{x:636,y:759,t:1527023467437};\\\", \\\"{x:635,y:759,t:1527023467468};\\\", \\\"{x:635,y:757,t:1527023467508};\\\", \\\"{x:635,y:756,t:1527023467556};\\\", \\\"{x:634,y:755,t:1527023467717};\\\", \\\"{x:633,y:755,t:1527023467739};\\\", \\\"{x:631,y:755,t:1527023467756};\\\", \\\"{x:630,y:755,t:1527023467772};\\\", \\\"{x:627,y:755,t:1527023467780};\\\", \\\"{x:624,y:757,t:1527023467796};\\\", \\\"{x:621,y:758,t:1527023467813};\\\", \\\"{x:618,y:759,t:1527023467830};\\\", \\\"{x:616,y:760,t:1527023467846};\\\", \\\"{x:615,y:761,t:1527023467863};\\\", \\\"{x:613,y:763,t:1527023467880};\\\", \\\"{x:611,y:764,t:1527023467897};\\\", \\\"{x:610,y:764,t:1527023467913};\\\", \\\"{x:608,y:764,t:1527023467930};\\\", \\\"{x:606,y:764,t:1527023467947};\\\", \\\"{x:601,y:764,t:1527023467963};\\\", \\\"{x:594,y:764,t:1527023467979};\\\", \\\"{x:590,y:764,t:1527023467997};\\\", \\\"{x:589,y:764,t:1527023468013};\\\", \\\"{x:587,y:764,t:1527023468030};\\\", \\\"{x:586,y:764,t:1527023468047};\\\", \\\"{x:582,y:764,t:1527023468063};\\\", \\\"{x:571,y:764,t:1527023468080};\\\", \\\"{x:552,y:762,t:1527023468097};\\\", \\\"{x:541,y:760,t:1527023468113};\\\", \\\"{x:538,y:757,t:1527023468130};\\\", \\\"{x:533,y:749,t:1527023468147};\\\", \\\"{x:534,y:745,t:1527023468164};\\\", \\\"{x:532,y:741,t:1527023468180};\\\", \\\"{x:532,y:732,t:1527023468197};\\\", \\\"{x:532,y:730,t:1527023468236};\\\", \\\"{x:533,y:730,t:1527023468324};\\\", \\\"{x:531,y:730,t:1527023468339};\\\", \\\"{x:530,y:729,t:1527023468372};\\\", \\\"{x:529,y:726,t:1527023468380};\\\", \\\"{x:526,y:722,t:1527023468397};\\\", \\\"{x:524,y:719,t:1527023468414};\\\", \\\"{x:523,y:718,t:1527023468430};\\\", \\\"{x:520,y:715,t:1527023468447};\\\", \\\"{x:520,y:714,t:1527023468464};\\\", \\\"{x:520,y:712,t:1527023468480};\\\", \\\"{x:519,y:709,t:1527023468497};\\\", \\\"{x:517,y:703,t:1527023468514};\\\", \\\"{x:516,y:701,t:1527023468531};\\\", \\\"{x:516,y:700,t:1527023468554};\\\", \\\"{x:516,y:699,t:1527023468643};\\\", \\\"{x:516,y:698,t:1527023468650};\\\", \\\"{x:516,y:697,t:1527023468664};\\\", \\\"{x:515,y:694,t:1527023468681};\\\", \\\"{x:515,y:692,t:1527023469556};\\\", \\\"{x:515,y:691,t:1527023469565};\\\", \\\"{x:515,y:686,t:1527023469581};\\\", \\\"{x:515,y:679,t:1527023469597};\\\", \\\"{x:515,y:672,t:1527023469614};\\\", \\\"{x:515,y:667,t:1527023469631};\\\", \\\"{x:515,y:663,t:1527023469647};\\\", \\\"{x:515,y:658,t:1527023469665};\\\", \\\"{x:515,y:656,t:1527023469681};\\\", \\\"{x:515,y:653,t:1527023469697};\\\", \\\"{x:515,y:650,t:1527023469715};\\\", \\\"{x:510,y:640,t:1527023469766};\\\", \\\"{x:508,y:637,t:1527023469780};\\\", \\\"{x:506,y:632,t:1527023469797};\\\", \\\"{x:504,y:629,t:1527023469814};\\\", \\\"{x:503,y:626,t:1527023469830};\\\", \\\"{x:503,y:624,t:1527023469848};\\\", \\\"{x:501,y:623,t:1527023469864};\\\", \\\"{x:500,y:619,t:1527023469880};\\\", \\\"{x:498,y:617,t:1527023469897};\\\", \\\"{x:497,y:616,t:1527023469915};\\\", \\\"{x:490,y:605,t:1527023469968};\\\", \\\"{x:487,y:602,t:1527023469981};\\\", \\\"{x:486,y:597,t:1527023469998};\\\", \\\"{x:484,y:594,t:1527023470014};\\\", \\\"{x:483,y:593,t:1527023470030};\\\" ] }, { \\\"rt\\\": 19148, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 546231, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"JYZGH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 5.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"M\\\", \\\"H\\\", \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:480,y:583,t:1527023470153};\\\", \\\"{x:480,y:581,t:1527023470165};\\\", \\\"{x:480,y:579,t:1527023470182};\\\", \\\"{x:480,y:577,t:1527023470199};\\\", \\\"{x:480,y:575,t:1527023470214};\\\", \\\"{x:480,y:574,t:1527023470231};\\\", \\\"{x:480,y:573,t:1527023470248};\\\", \\\"{x:481,y:572,t:1527023470275};\\\", \\\"{x:481,y:571,t:1527023470323};\\\", \\\"{x:481,y:570,t:1527023470339};\\\", \\\"{x:481,y:569,t:1527023470380};\\\", \\\"{x:483,y:567,t:1527023470419};\\\", \\\"{x:483,y:566,t:1527023470449};\\\", \\\"{x:483,y:565,t:1527023470466};\\\", \\\"{x:484,y:563,t:1527023470483};\\\", \\\"{x:484,y:562,t:1527023470498};\\\", \\\"{x:486,y:559,t:1527023470515};\\\", \\\"{x:488,y:557,t:1527023470531};\\\", \\\"{x:490,y:554,t:1527023470549};\\\", \\\"{x:493,y:551,t:1527023470565};\\\", \\\"{x:494,y:550,t:1527023470582};\\\", \\\"{x:496,y:545,t:1527023470599};\\\", \\\"{x:497,y:541,t:1527023470616};\\\", \\\"{x:498,y:537,t:1527023470632};\\\", \\\"{x:500,y:531,t:1527023470649};\\\", \\\"{x:501,y:526,t:1527023470665};\\\", \\\"{x:502,y:519,t:1527023470682};\\\", \\\"{x:502,y:515,t:1527023470699};\\\", \\\"{x:502,y:507,t:1527023470715};\\\", \\\"{x:502,y:502,t:1527023470732};\\\", \\\"{x:504,y:495,t:1527023470748};\\\", \\\"{x:505,y:490,t:1527023470765};\\\", \\\"{x:527,y:440,t:1527023470904};\\\", \\\"{x:533,y:433,t:1527023470916};\\\", \\\"{x:537,y:429,t:1527023470933};\\\", \\\"{x:542,y:426,t:1527023470948};\\\", \\\"{x:546,y:423,t:1527023470965};\\\", \\\"{x:552,y:422,t:1527023470982};\\\", \\\"{x:556,y:421,t:1527023470998};\\\", \\\"{x:562,y:419,t:1527023471016};\\\", \\\"{x:568,y:419,t:1527023471033};\\\", \\\"{x:573,y:419,t:1527023471049};\\\", \\\"{x:580,y:419,t:1527023471066};\\\", \\\"{x:586,y:419,t:1527023471083};\\\", \\\"{x:591,y:419,t:1527023471098};\\\", \\\"{x:595,y:419,t:1527023471115};\\\", \\\"{x:597,y:419,t:1527023471133};\\\", \\\"{x:599,y:419,t:1527023471149};\\\", \\\"{x:600,y:420,t:1527023471165};\\\", \\\"{x:603,y:422,t:1527023471183};\\\", \\\"{x:605,y:422,t:1527023471199};\\\", \\\"{x:608,y:423,t:1527023471215};\\\", \\\"{x:611,y:424,t:1527023471233};\\\", \\\"{x:613,y:425,t:1527023471250};\\\", \\\"{x:615,y:426,t:1527023471266};\\\", \\\"{x:617,y:426,t:1527023471283};\\\", \\\"{x:619,y:427,t:1527023471299};\\\", \\\"{x:621,y:429,t:1527023471316};\\\", \\\"{x:623,y:429,t:1527023471333};\\\", \\\"{x:624,y:430,t:1527023471350};\\\", \\\"{x:627,y:431,t:1527023471366};\\\", \\\"{x:629,y:432,t:1527023471383};\\\", \\\"{x:630,y:432,t:1527023471400};\\\", \\\"{x:631,y:433,t:1527023471416};\\\", \\\"{x:631,y:434,t:1527023471434};\\\", \\\"{x:632,y:434,t:1527023471452};\\\", \\\"{x:632,y:435,t:1527023471466};\\\", \\\"{x:634,y:435,t:1527023471484};\\\", \\\"{x:634,y:436,t:1527023471507};\\\", \\\"{x:635,y:436,t:1527023471531};\\\", \\\"{x:635,y:438,t:1527023471563};\\\", \\\"{x:636,y:438,t:1527023471599};\\\", \\\"{x:637,y:439,t:1527023471615};\\\", \\\"{x:637,y:440,t:1527023471635};\\\", \\\"{x:637,y:441,t:1527023471980};\\\", \\\"{x:638,y:441,t:1527023471996};\\\", \\\"{x:638,y:442,t:1527023472100};\\\", \\\"{x:640,y:444,t:1527023472364};\\\", \\\"{x:641,y:444,t:1527023472580};\\\", \\\"{x:642,y:444,t:1527023472587};\\\", \\\"{x:643,y:444,t:1527023472789};\\\", \\\"{x:644,y:444,t:1527023473884};\\\", \\\"{x:645,y:444,t:1527023473932};\\\", \\\"{x:646,y:444,t:1527023474020};\\\", \\\"{x:647,y:444,t:1527023476324};\\\", \\\"{x:646,y:444,t:1527023479732};\\\", \\\"{x:645,y:444,t:1527023479756};\\\", \\\"{x:644,y:444,t:1527023479916};\\\", \\\"{x:643,y:444,t:1527023480003};\\\", \\\"{x:642,y:444,t:1527023480075};\\\", \\\"{x:642,y:442,t:1527023480291};\\\", \\\"{x:641,y:442,t:1527023480356};\\\", \\\"{x:641,y:441,t:1527023480387};\\\", \\\"{x:640,y:441,t:1527023480444};\\\", \\\"{x:639,y:440,t:1527023480628};\\\", \\\"{x:640,y:440,t:1527023481100};\\\", \\\"{x:641,y:440,t:1527023481124};\\\", \\\"{x:641,y:441,t:1527023481140};\\\", \\\"{x:643,y:441,t:1527023481158};\\\", \\\"{x:643,y:442,t:1527023481173};\\\", \\\"{x:641,y:447,t:1527023481190};\\\", \\\"{x:636,y:451,t:1527023481207};\\\", \\\"{x:628,y:459,t:1527023481224};\\\", \\\"{x:615,y:467,t:1527023481240};\\\", \\\"{x:606,y:472,t:1527023481257};\\\", \\\"{x:602,y:474,t:1527023481273};\\\", \\\"{x:599,y:476,t:1527023481290};\\\", \\\"{x:598,y:478,t:1527023481307};\\\", \\\"{x:598,y:482,t:1527023481324};\\\", \\\"{x:598,y:484,t:1527023481340};\\\", \\\"{x:598,y:486,t:1527023481357};\\\", \\\"{x:598,y:489,t:1527023481374};\\\", \\\"{x:598,y:490,t:1527023481391};\\\", \\\"{x:599,y:492,t:1527023481407};\\\", \\\"{x:600,y:493,t:1527023481425};\\\", \\\"{x:603,y:495,t:1527023481441};\\\", \\\"{x:605,y:496,t:1527023481457};\\\", \\\"{x:608,y:499,t:1527023481475};\\\", \\\"{x:616,y:503,t:1527023481491};\\\", \\\"{x:626,y:511,t:1527023481508};\\\", \\\"{x:629,y:514,t:1527023481524};\\\", \\\"{x:633,y:517,t:1527023481540};\\\", \\\"{x:634,y:517,t:1527023481557};\\\", \\\"{x:634,y:518,t:1527023481574};\\\", \\\"{x:634,y:519,t:1527023481611};\\\", \\\"{x:634,y:521,t:1527023481643};\\\", \\\"{x:634,y:523,t:1527023481659};\\\", \\\"{x:633,y:524,t:1527023481684};\\\", \\\"{x:632,y:525,t:1527023481691};\\\", \\\"{x:632,y:528,t:1527023481708};\\\", \\\"{x:631,y:529,t:1527023481725};\\\", \\\"{x:629,y:531,t:1527023481741};\\\", \\\"{x:628,y:532,t:1527023481758};\\\", \\\"{x:627,y:534,t:1527023481775};\\\", \\\"{x:626,y:535,t:1527023481792};\\\", \\\"{x:624,y:536,t:1527023481808};\\\", \\\"{x:622,y:536,t:1527023481825};\\\", \\\"{x:622,y:537,t:1527023481841};\\\", \\\"{x:621,y:537,t:1527023481858};\\\", \\\"{x:621,y:538,t:1527023481875};\\\", \\\"{x:620,y:539,t:1527023482164};\\\", \\\"{x:619,y:540,t:1527023482175};\\\", \\\"{x:617,y:544,t:1527023482194};\\\", \\\"{x:615,y:549,t:1527023482209};\\\", \\\"{x:613,y:557,t:1527023482225};\\\", \\\"{x:612,y:560,t:1527023482240};\\\", \\\"{x:611,y:565,t:1527023482258};\\\", \\\"{x:611,y:567,t:1527023482275};\\\", \\\"{x:611,y:568,t:1527023482298};\\\", \\\"{x:611,y:569,t:1527023482331};\\\", \\\"{x:608,y:570,t:1527023482781};\\\", \\\"{x:603,y:570,t:1527023482794};\\\", \\\"{x:567,y:567,t:1527023482810};\\\", \\\"{x:523,y:557,t:1527023482826};\\\", \\\"{x:477,y:548,t:1527023482845};\\\", \\\"{x:432,y:539,t:1527023482861};\\\", \\\"{x:393,y:532,t:1527023482877};\\\", \\\"{x:376,y:526,t:1527023482893};\\\", \\\"{x:368,y:521,t:1527023482910};\\\", \\\"{x:363,y:516,t:1527023482927};\\\", \\\"{x:358,y:512,t:1527023482944};\\\", \\\"{x:356,y:510,t:1527023482960};\\\", \\\"{x:354,y:506,t:1527023482977};\\\", \\\"{x:354,y:504,t:1527023482993};\\\", \\\"{x:352,y:501,t:1527023483011};\\\", \\\"{x:351,y:499,t:1527023483026};\\\", \\\"{x:351,y:498,t:1527023483044};\\\", \\\"{x:353,y:493,t:1527023483060};\\\", \\\"{x:355,y:491,t:1527023483077};\\\", \\\"{x:359,y:489,t:1527023483093};\\\", \\\"{x:360,y:488,t:1527023483111};\\\", \\\"{x:361,y:488,t:1527023483127};\\\", \\\"{x:363,y:486,t:1527023483181};\\\", \\\"{x:365,y:485,t:1527023483196};\\\", \\\"{x:366,y:483,t:1527023483211};\\\", \\\"{x:369,y:480,t:1527023483227};\\\", \\\"{x:370,y:479,t:1527023483244};\\\", \\\"{x:371,y:477,t:1527023483260};\\\", \\\"{x:372,y:476,t:1527023483277};\\\", \\\"{x:373,y:476,t:1527023483295};\\\", \\\"{x:375,y:476,t:1527023483332};\\\", \\\"{x:378,y:476,t:1527023483356};\\\", \\\"{x:379,y:476,t:1527023483381};\\\", \\\"{x:380,y:476,t:1527023483394};\\\", \\\"{x:381,y:477,t:1527023483412};\\\", \\\"{x:383,y:477,t:1527023483485};\\\", \\\"{x:383,y:478,t:1527023483653};\\\", \\\"{x:381,y:479,t:1527023483660};\\\", \\\"{x:366,y:486,t:1527023483678};\\\", \\\"{x:349,y:491,t:1527023483694};\\\", \\\"{x:326,y:497,t:1527023483710};\\\", \\\"{x:301,y:500,t:1527023483728};\\\", \\\"{x:284,y:501,t:1527023483744};\\\", \\\"{x:271,y:502,t:1527023483762};\\\", \\\"{x:265,y:504,t:1527023483778};\\\", \\\"{x:262,y:504,t:1527023483794};\\\", \\\"{x:261,y:505,t:1527023483811};\\\", \\\"{x:254,y:504,t:1527023483828};\\\", \\\"{x:252,y:503,t:1527023483844};\\\", \\\"{x:250,y:501,t:1527023483862};\\\", \\\"{x:250,y:500,t:1527023483933};\\\", \\\"{x:250,y:496,t:1527023483965};\\\", \\\"{x:250,y:494,t:1527023483980};\\\", \\\"{x:250,y:493,t:1527023483995};\\\", \\\"{x:250,y:491,t:1527023484011};\\\", \\\"{x:250,y:489,t:1527023484028};\\\", \\\"{x:250,y:488,t:1527023484045};\\\", \\\"{x:251,y:483,t:1527023484173};\\\", \\\"{x:254,y:478,t:1527023484181};\\\", \\\"{x:254,y:475,t:1527023484195};\\\", \\\"{x:254,y:476,t:1527023484211};\\\", \\\"{x:254,y:478,t:1527023484228};\\\", \\\"{x:252,y:480,t:1527023484244};\\\", \\\"{x:251,y:481,t:1527023484261};\\\", \\\"{x:251,y:483,t:1527023484373};\\\", \\\"{x:254,y:486,t:1527023484558};\\\", \\\"{x:254,y:488,t:1527023484565};\\\", \\\"{x:254,y:491,t:1527023484578};\\\", \\\"{x:273,y:486,t:1527023485064};\\\", \\\"{x:357,y:473,t:1527023485079};\\\", \\\"{x:464,y:463,t:1527023485096};\\\", \\\"{x:586,y:446,t:1527023485111};\\\", \\\"{x:702,y:434,t:1527023485129};\\\", \\\"{x:824,y:432,t:1527023485145};\\\", \\\"{x:919,y:430,t:1527023485162};\\\", \\\"{x:992,y:427,t:1527023485179};\\\", \\\"{x:1026,y:425,t:1527023485194};\\\", \\\"{x:1046,y:424,t:1527023485212};\\\", \\\"{x:1059,y:424,t:1527023485228};\\\", \\\"{x:1062,y:424,t:1527023485245};\\\", \\\"{x:1059,y:424,t:1527023485333};\\\", \\\"{x:1039,y:426,t:1527023485345};\\\", \\\"{x:973,y:434,t:1527023485362};\\\", \\\"{x:907,y:439,t:1527023485380};\\\", \\\"{x:842,y:443,t:1527023485395};\\\", \\\"{x:790,y:444,t:1527023485413};\\\", \\\"{x:780,y:444,t:1527023485429};\\\", \\\"{x:779,y:445,t:1527023485516};\\\", \\\"{x:779,y:446,t:1527023485540};\\\", \\\"{x:779,y:447,t:1527023485556};\\\", \\\"{x:779,y:448,t:1527023485581};\\\", \\\"{x:782,y:448,t:1527023485629};\\\", \\\"{x:787,y:448,t:1527023485646};\\\", \\\"{x:793,y:448,t:1527023485663};\\\", \\\"{x:802,y:448,t:1527023485679};\\\", \\\"{x:809,y:448,t:1527023485696};\\\", \\\"{x:811,y:448,t:1527023485713};\\\", \\\"{x:812,y:448,t:1527023485729};\\\", \\\"{x:813,y:448,t:1527023485746};\\\", \\\"{x:814,y:448,t:1527023485773};\\\", \\\"{x:815,y:447,t:1527023486022};\\\", \\\"{x:816,y:447,t:1527023486270};\\\", \\\"{x:817,y:450,t:1527023486285};\\\", \\\"{x:818,y:455,t:1527023486297};\\\", \\\"{x:821,y:464,t:1527023486314};\\\", \\\"{x:825,y:471,t:1527023486332};\\\", \\\"{x:826,y:476,t:1527023486347};\\\", \\\"{x:829,y:484,t:1527023486363};\\\", \\\"{x:835,y:496,t:1527023486380};\\\", \\\"{x:840,y:505,t:1527023486396};\\\", \\\"{x:847,y:518,t:1527023486413};\\\", \\\"{x:850,y:523,t:1527023486430};\\\", \\\"{x:852,y:527,t:1527023486447};\\\", \\\"{x:852,y:523,t:1527023486517};\\\", \\\"{x:852,y:518,t:1527023486530};\\\", \\\"{x:852,y:503,t:1527023486547};\\\", \\\"{x:851,y:490,t:1527023486564};\\\", \\\"{x:849,y:480,t:1527023486580};\\\", \\\"{x:842,y:466,t:1527023486596};\\\", \\\"{x:837,y:459,t:1527023486613};\\\", \\\"{x:836,y:453,t:1527023486630};\\\", \\\"{x:834,y:450,t:1527023486645};\\\", \\\"{x:832,y:447,t:1527023486663};\\\", \\\"{x:829,y:444,t:1527023486680};\\\", \\\"{x:827,y:441,t:1527023486696};\\\", \\\"{x:826,y:440,t:1527023486713};\\\", \\\"{x:825,y:439,t:1527023486791};\\\", \\\"{x:825,y:443,t:1527023487029};\\\", \\\"{x:825,y:463,t:1527023487047};\\\", \\\"{x:825,y:487,t:1527023487064};\\\", \\\"{x:829,y:509,t:1527023487079};\\\", \\\"{x:833,y:530,t:1527023487098};\\\", \\\"{x:835,y:545,t:1527023487114};\\\", \\\"{x:836,y:553,t:1527023487130};\\\", \\\"{x:838,y:559,t:1527023487147};\\\", \\\"{x:838,y:562,t:1527023487164};\\\", \\\"{x:838,y:564,t:1527023487188};\\\", \\\"{x:838,y:565,t:1527023487204};\\\", \\\"{x:838,y:567,t:1527023487214};\\\", \\\"{x:838,y:568,t:1527023487230};\\\", \\\"{x:838,y:571,t:1527023487247};\\\", \\\"{x:837,y:571,t:1527023487445};\\\", \\\"{x:836,y:571,t:1527023487485};\\\", \\\"{x:836,y:569,t:1527023487709};\\\", \\\"{x:835,y:566,t:1527023487716};\\\", \\\"{x:835,y:560,t:1527023487731};\\\", \\\"{x:835,y:550,t:1527023487748};\\\", \\\"{x:835,y:532,t:1527023487764};\\\", \\\"{x:837,y:522,t:1527023487781};\\\", \\\"{x:842,y:509,t:1527023487798};\\\", \\\"{x:847,y:496,t:1527023487814};\\\", \\\"{x:851,y:486,t:1527023487831};\\\", \\\"{x:852,y:479,t:1527023487848};\\\", \\\"{x:855,y:475,t:1527023487864};\\\", \\\"{x:855,y:471,t:1527023487881};\\\", \\\"{x:855,y:470,t:1527023487898};\\\", \\\"{x:855,y:469,t:1527023487914};\\\", \\\"{x:855,y:468,t:1527023487931};\\\", \\\"{x:855,y:467,t:1527023487973};\\\", \\\"{x:855,y:466,t:1527023487981};\\\", \\\"{x:855,y:465,t:1527023487997};\\\", \\\"{x:853,y:462,t:1527023488015};\\\", \\\"{x:850,y:461,t:1527023488031};\\\", \\\"{x:848,y:459,t:1527023488048};\\\", \\\"{x:846,y:458,t:1527023488065};\\\", \\\"{x:845,y:458,t:1527023488081};\\\", \\\"{x:844,y:458,t:1527023488098};\\\", \\\"{x:843,y:457,t:1527023488114};\\\", \\\"{x:841,y:455,t:1527023488132};\\\", \\\"{x:840,y:454,t:1527023488149};\\\", \\\"{x:839,y:454,t:1527023488181};\\\", \\\"{x:835,y:454,t:1527023488484};\\\", \\\"{x:823,y:459,t:1527023488498};\\\", \\\"{x:802,y:474,t:1527023488515};\\\", \\\"{x:777,y:493,t:1527023488530};\\\", \\\"{x:758,y:512,t:1527023488548};\\\", \\\"{x:740,y:536,t:1527023488565};\\\", \\\"{x:724,y:557,t:1527023488582};\\\", \\\"{x:707,y:576,t:1527023488599};\\\", \\\"{x:689,y:598,t:1527023488616};\\\", \\\"{x:670,y:620,t:1527023488632};\\\", \\\"{x:654,y:641,t:1527023488648};\\\", \\\"{x:639,y:660,t:1527023488665};\\\", \\\"{x:628,y:675,t:1527023488681};\\\", \\\"{x:616,y:690,t:1527023488698};\\\", \\\"{x:609,y:700,t:1527023488715};\\\", \\\"{x:604,y:705,t:1527023488731};\\\", \\\"{x:599,y:712,t:1527023488748};\\\", \\\"{x:586,y:718,t:1527023488765};\\\", \\\"{x:577,y:719,t:1527023488781};\\\", \\\"{x:563,y:721,t:1527023488798};\\\", \\\"{x:544,y:720,t:1527023488815};\\\", \\\"{x:524,y:717,t:1527023488831};\\\", \\\"{x:512,y:711,t:1527023488848};\\\", \\\"{x:503,y:706,t:1527023488865};\\\", \\\"{x:498,y:705,t:1527023488881};\\\", \\\"{x:493,y:702,t:1527023488898};\\\", \\\"{x:488,y:698,t:1527023488916};\\\", \\\"{x:485,y:696,t:1527023488931};\\\", \\\"{x:481,y:692,t:1527023488948};\\\", \\\"{x:481,y:691,t:1527023488965};\\\", \\\"{x:480,y:690,t:1527023488982};\\\", \\\"{x:479,y:689,t:1527023488999};\\\", \\\"{x:478,y:688,t:1527023489020};\\\", \\\"{x:478,y:687,t:1527023489036};\\\" ] }, { \\\"rt\\\": 7738, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 555205, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"JYZGH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:478,y:685,t:1527023491027};\\\", \\\"{x:478,y:684,t:1527023491068};\\\", \\\"{x:478,y:683,t:1527023491108};\\\", \\\"{x:482,y:680,t:1527023496230};\\\", \\\"{x:530,y:665,t:1527023496248};\\\", \\\"{x:570,y:658,t:1527023496263};\\\", \\\"{x:592,y:654,t:1527023496279};\\\", \\\"{x:608,y:653,t:1527023496304};\\\", \\\"{x:613,y:653,t:1527023496322};\\\", \\\"{x:614,y:653,t:1527023496338};\\\", \\\"{x:617,y:653,t:1527023496354};\\\", \\\"{x:619,y:653,t:1527023496371};\\\", \\\"{x:628,y:655,t:1527023496388};\\\", \\\"{x:637,y:665,t:1527023496404};\\\", \\\"{x:659,y:672,t:1527023496421};\\\", \\\"{x:704,y:679,t:1527023496438};\\\", \\\"{x:775,y:686,t:1527023496454};\\\", \\\"{x:831,y:686,t:1527023496471};\\\", \\\"{x:871,y:686,t:1527023496488};\\\", \\\"{x:883,y:688,t:1527023496506};\\\", \\\"{x:894,y:684,t:1527023496522};\\\", \\\"{x:898,y:682,t:1527023496538};\\\", \\\"{x:898,y:680,t:1527023496555};\\\", \\\"{x:899,y:674,t:1527023496571};\\\", \\\"{x:903,y:659,t:1527023496588};\\\", \\\"{x:906,y:646,t:1527023496604};\\\", \\\"{x:907,y:637,t:1527023496622};\\\", \\\"{x:907,y:624,t:1527023496639};\\\", \\\"{x:902,y:611,t:1527023496656};\\\", \\\"{x:892,y:597,t:1527023496671};\\\", \\\"{x:881,y:585,t:1527023496688};\\\", \\\"{x:875,y:579,t:1527023496705};\\\", \\\"{x:862,y:570,t:1527023496722};\\\", \\\"{x:856,y:561,t:1527023496738};\\\", \\\"{x:852,y:552,t:1527023496756};\\\", \\\"{x:849,y:546,t:1527023496773};\\\", \\\"{x:846,y:539,t:1527023496788};\\\", \\\"{x:843,y:536,t:1527023496805};\\\", \\\"{x:842,y:536,t:1527023496884};\\\", \\\"{x:841,y:536,t:1527023496892};\\\", \\\"{x:840,y:536,t:1527023496906};\\\", \\\"{x:838,y:539,t:1527023496922};\\\", \\\"{x:837,y:543,t:1527023496938};\\\", \\\"{x:836,y:546,t:1527023496955};\\\", \\\"{x:835,y:550,t:1527023496972};\\\", \\\"{x:835,y:554,t:1527023496989};\\\", \\\"{x:834,y:555,t:1527023497005};\\\", \\\"{x:834,y:558,t:1527023497022};\\\", \\\"{x:834,y:559,t:1527023497085};\\\", \\\"{x:834,y:561,t:1527023497500};\\\", \\\"{x:830,y:565,t:1527023497508};\\\", \\\"{x:826,y:567,t:1527023497522};\\\", \\\"{x:811,y:576,t:1527023497539};\\\", \\\"{x:792,y:587,t:1527023497556};\\\", \\\"{x:754,y:606,t:1527023497572};\\\", \\\"{x:722,y:619,t:1527023497590};\\\", \\\"{x:699,y:629,t:1527023497605};\\\", \\\"{x:680,y:639,t:1527023497623};\\\", \\\"{x:663,y:648,t:1527023497639};\\\", \\\"{x:651,y:655,t:1527023497655};\\\", \\\"{x:637,y:660,t:1527023497673};\\\", \\\"{x:621,y:667,t:1527023497689};\\\", \\\"{x:611,y:668,t:1527023497705};\\\", \\\"{x:603,y:671,t:1527023497722};\\\", \\\"{x:593,y:675,t:1527023497739};\\\", \\\"{x:587,y:677,t:1527023497755};\\\", \\\"{x:578,y:681,t:1527023497773};\\\", \\\"{x:577,y:681,t:1527023497789};\\\", \\\"{x:575,y:682,t:1527023497805};\\\", \\\"{x:574,y:684,t:1527023497861};\\\", \\\"{x:573,y:686,t:1527023497872};\\\", \\\"{x:571,y:686,t:1527023497889};\\\", \\\"{x:565,y:687,t:1527023497906};\\\", \\\"{x:563,y:687,t:1527023497924};\\\", \\\"{x:562,y:687,t:1527023497940};\\\", \\\"{x:561,y:687,t:1527023497980};\\\", \\\"{x:560,y:687,t:1527023497997};\\\", \\\"{x:558,y:687,t:1527023498007};\\\", \\\"{x:557,y:687,t:1527023498022};\\\", \\\"{x:555,y:687,t:1527023498039};\\\", \\\"{x:554,y:687,t:1527023498061};\\\", \\\"{x:554,y:686,t:1527023498957};\\\" ] }, { \\\"rt\\\": 12056, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 568610, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"JYZGH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 4, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"J\\\", \\\"X\\\", \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:556,y:683,t:1527023499984};\\\", \\\"{x:557,y:683,t:1527023499999};\\\", \\\"{x:558,y:682,t:1527023500026};\\\", \\\"{x:559,y:681,t:1527023500040};\\\", \\\"{x:561,y:680,t:1527023500060};\\\", \\\"{x:561,y:679,t:1527023500076};\\\", \\\"{x:562,y:678,t:1527023500108};\\\", \\\"{x:562,y:675,t:1527023500124};\\\", \\\"{x:562,y:671,t:1527023500140};\\\", \\\"{x:562,y:667,t:1527023500157};\\\", \\\"{x:562,y:664,t:1527023500174};\\\", \\\"{x:562,y:662,t:1527023500190};\\\", \\\"{x:562,y:661,t:1527023500207};\\\", \\\"{x:562,y:660,t:1527023500225};\\\", \\\"{x:561,y:660,t:1527023500365};\\\", \\\"{x:561,y:663,t:1527023500380};\\\", \\\"{x:560,y:665,t:1527023500392};\\\", \\\"{x:560,y:669,t:1527023500409};\\\", \\\"{x:559,y:672,t:1527023500424};\\\", \\\"{x:557,y:674,t:1527023500442};\\\", \\\"{x:557,y:675,t:1527023500458};\\\", \\\"{x:557,y:676,t:1527023500474};\\\", \\\"{x:557,y:677,t:1527023500491};\\\", \\\"{x:557,y:678,t:1527023502878};\\\", \\\"{x:559,y:675,t:1527023503605};\\\", \\\"{x:565,y:670,t:1527023503614};\\\", \\\"{x:575,y:666,t:1527023503626};\\\", \\\"{x:595,y:659,t:1527023503644};\\\", \\\"{x:615,y:653,t:1527023503661};\\\", \\\"{x:624,y:649,t:1527023503677};\\\", \\\"{x:636,y:647,t:1527023503694};\\\", \\\"{x:651,y:644,t:1527023503710};\\\", \\\"{x:665,y:643,t:1527023503727};\\\", \\\"{x:674,y:641,t:1527023503744};\\\", \\\"{x:683,y:640,t:1527023503760};\\\", \\\"{x:691,y:639,t:1527023503777};\\\", \\\"{x:700,y:637,t:1527023503793};\\\", \\\"{x:708,y:636,t:1527023503811};\\\", \\\"{x:711,y:636,t:1527023503827};\\\", \\\"{x:711,y:635,t:1527023503843};\\\", \\\"{x:711,y:634,t:1527023503893};\\\", \\\"{x:709,y:629,t:1527023503911};\\\", \\\"{x:703,y:623,t:1527023503927};\\\", \\\"{x:698,y:616,t:1527023503944};\\\", \\\"{x:697,y:615,t:1527023503960};\\\", \\\"{x:694,y:612,t:1527023503977};\\\", \\\"{x:692,y:608,t:1527023503995};\\\", \\\"{x:691,y:606,t:1527023504010};\\\", \\\"{x:690,y:606,t:1527023504027};\\\", \\\"{x:690,y:604,t:1527023504045};\\\", \\\"{x:690,y:603,t:1527023505141};\\\", \\\"{x:688,y:599,t:1527023505149};\\\", \\\"{x:688,y:597,t:1527023505162};\\\", \\\"{x:688,y:596,t:1527023505179};\\\", \\\"{x:687,y:593,t:1527023505195};\\\", \\\"{x:685,y:589,t:1527023505212};\\\", \\\"{x:683,y:585,t:1527023505229};\\\", \\\"{x:681,y:581,t:1527023505245};\\\", \\\"{x:678,y:575,t:1527023505263};\\\", \\\"{x:676,y:571,t:1527023505278};\\\", \\\"{x:672,y:565,t:1527023505296};\\\", \\\"{x:671,y:560,t:1527023505311};\\\", \\\"{x:669,y:556,t:1527023505329};\\\", \\\"{x:668,y:554,t:1527023505345};\\\", \\\"{x:666,y:550,t:1527023505361};\\\", \\\"{x:664,y:547,t:1527023505379};\\\", \\\"{x:663,y:545,t:1527023505395};\\\", \\\"{x:662,y:540,t:1527023505412};\\\", \\\"{x:661,y:533,t:1527023505429};\\\", \\\"{x:661,y:529,t:1527023505446};\\\", \\\"{x:661,y:526,t:1527023505462};\\\", \\\"{x:661,y:522,t:1527023505479};\\\", \\\"{x:661,y:519,t:1527023505495};\\\", \\\"{x:661,y:516,t:1527023505512};\\\", \\\"{x:661,y:514,t:1527023505529};\\\", \\\"{x:661,y:513,t:1527023505545};\\\", \\\"{x:659,y:513,t:1527023505596};\\\", \\\"{x:658,y:513,t:1527023505612};\\\", \\\"{x:656,y:513,t:1527023505629};\\\", \\\"{x:655,y:514,t:1527023505646};\\\", \\\"{x:651,y:516,t:1527023505663};\\\", \\\"{x:650,y:517,t:1527023505679};\\\", \\\"{x:648,y:517,t:1527023505696};\\\", \\\"{x:647,y:518,t:1527023505733};\\\", \\\"{x:646,y:518,t:1527023505757};\\\", \\\"{x:646,y:519,t:1527023505764};\\\", \\\"{x:645,y:519,t:1527023505779};\\\", \\\"{x:644,y:520,t:1527023505796};\\\", \\\"{x:642,y:520,t:1527023505813};\\\", \\\"{x:641,y:521,t:1527023505836};\\\", \\\"{x:640,y:521,t:1527023505860};\\\", \\\"{x:638,y:522,t:1527023505884};\\\", \\\"{x:640,y:523,t:1527023506436};\\\", \\\"{x:649,y:523,t:1527023506446};\\\", \\\"{x:661,y:523,t:1527023506462};\\\", \\\"{x:684,y:524,t:1527023506479};\\\", \\\"{x:709,y:524,t:1527023506495};\\\", \\\"{x:732,y:524,t:1527023506514};\\\", \\\"{x:748,y:524,t:1527023506529};\\\", \\\"{x:757,y:524,t:1527023506546};\\\", \\\"{x:760,y:524,t:1527023506563};\\\", \\\"{x:771,y:523,t:1527023506580};\\\", \\\"{x:787,y:518,t:1527023506596};\\\", \\\"{x:795,y:516,t:1527023506613};\\\", \\\"{x:801,y:514,t:1527023506630};\\\", \\\"{x:804,y:513,t:1527023506647};\\\", \\\"{x:806,y:512,t:1527023506662};\\\", \\\"{x:808,y:510,t:1527023506680};\\\", \\\"{x:808,y:509,t:1527023506698};\\\", \\\"{x:808,y:508,t:1527023506713};\\\", \\\"{x:808,y:504,t:1527023506730};\\\", \\\"{x:808,y:501,t:1527023506748};\\\", \\\"{x:808,y:500,t:1527023506763};\\\", \\\"{x:808,y:497,t:1527023506780};\\\", \\\"{x:808,y:494,t:1527023506797};\\\", \\\"{x:810,y:491,t:1527023506813};\\\", \\\"{x:812,y:489,t:1527023506830};\\\", \\\"{x:814,y:488,t:1527023506846};\\\", \\\"{x:814,y:487,t:1527023506863};\\\", \\\"{x:816,y:486,t:1527023506879};\\\", \\\"{x:817,y:485,t:1527023506897};\\\", \\\"{x:818,y:484,t:1527023506913};\\\", \\\"{x:820,y:483,t:1527023506929};\\\", \\\"{x:821,y:483,t:1527023506964};\\\", \\\"{x:822,y:483,t:1527023506980};\\\", \\\"{x:823,y:483,t:1527023507029};\\\", \\\"{x:819,y:483,t:1527023507333};\\\", \\\"{x:816,y:483,t:1527023507347};\\\", \\\"{x:803,y:482,t:1527023507362};\\\", \\\"{x:782,y:478,t:1527023507380};\\\", \\\"{x:724,y:465,t:1527023507397};\\\", \\\"{x:684,y:457,t:1527023507415};\\\", \\\"{x:648,y:450,t:1527023507431};\\\", \\\"{x:616,y:445,t:1527023507447};\\\", \\\"{x:587,y:441,t:1527023507464};\\\", \\\"{x:559,y:437,t:1527023507480};\\\", \\\"{x:530,y:432,t:1527023507497};\\\", \\\"{x:512,y:431,t:1527023507514};\\\", \\\"{x:490,y:428,t:1527023507531};\\\", \\\"{x:468,y:427,t:1527023507547};\\\", \\\"{x:446,y:426,t:1527023507563};\\\", \\\"{x:429,y:424,t:1527023507581};\\\", \\\"{x:419,y:424,t:1527023507597};\\\", \\\"{x:417,y:424,t:1527023507614};\\\", \\\"{x:416,y:424,t:1527023507630};\\\", \\\"{x:414,y:424,t:1527023507652};\\\", \\\"{x:412,y:424,t:1527023507663};\\\", \\\"{x:408,y:426,t:1527023507681};\\\", \\\"{x:405,y:428,t:1527023507697};\\\", \\\"{x:405,y:430,t:1527023507714};\\\", \\\"{x:405,y:434,t:1527023507732};\\\", \\\"{x:405,y:439,t:1527023507748};\\\", \\\"{x:404,y:441,t:1527023507764};\\\", \\\"{x:403,y:442,t:1527023507780};\\\", \\\"{x:401,y:445,t:1527023507798};\\\", \\\"{x:399,y:447,t:1527023507813};\\\", \\\"{x:392,y:448,t:1527023507831};\\\", \\\"{x:387,y:451,t:1527023507848};\\\", \\\"{x:381,y:452,t:1527023507864};\\\", \\\"{x:376,y:452,t:1527023507880};\\\", \\\"{x:373,y:452,t:1527023507899};\\\", \\\"{x:373,y:453,t:1527023508325};\\\", \\\"{x:373,y:455,t:1527023508340};\\\", \\\"{x:375,y:455,t:1527023508356};\\\", \\\"{x:376,y:455,t:1527023508366};\\\", \\\"{x:380,y:457,t:1527023508380};\\\", \\\"{x:384,y:459,t:1527023508397};\\\", \\\"{x:388,y:462,t:1527023508415};\\\", \\\"{x:394,y:465,t:1527023508431};\\\", \\\"{x:398,y:466,t:1527023508448};\\\", \\\"{x:399,y:467,t:1527023508465};\\\", \\\"{x:401,y:467,t:1527023508480};\\\", \\\"{x:402,y:468,t:1527023508524};\\\", \\\"{x:403,y:468,t:1527023508548};\\\", \\\"{x:404,y:467,t:1527023508564};\\\", \\\"{x:404,y:464,t:1527023508581};\\\", \\\"{x:404,y:462,t:1527023508598};\\\", \\\"{x:404,y:459,t:1527023508615};\\\", \\\"{x:404,y:458,t:1527023508660};\\\", \\\"{x:404,y:456,t:1527023508692};\\\", \\\"{x:403,y:456,t:1527023508725};\\\", \\\"{x:402,y:456,t:1527023508732};\\\", \\\"{x:401,y:456,t:1527023508757};\\\", \\\"{x:399,y:455,t:1527023508765};\\\", \\\"{x:398,y:455,t:1527023508782};\\\", \\\"{x:395,y:455,t:1527023508798};\\\", \\\"{x:394,y:454,t:1527023508815};\\\", \\\"{x:392,y:454,t:1527023508832};\\\", \\\"{x:390,y:454,t:1527023508848};\\\", \\\"{x:389,y:454,t:1527023508868};\\\", \\\"{x:387,y:454,t:1527023508917};\\\", \\\"{x:390,y:455,t:1527023509276};\\\", \\\"{x:394,y:457,t:1527023509284};\\\", \\\"{x:400,y:460,t:1527023509299};\\\", \\\"{x:414,y:466,t:1527023509315};\\\", \\\"{x:440,y:477,t:1527023509333};\\\", \\\"{x:461,y:486,t:1527023509349};\\\", \\\"{x:486,y:500,t:1527023509364};\\\", \\\"{x:503,y:508,t:1527023509382};\\\", \\\"{x:522,y:519,t:1527023509399};\\\", \\\"{x:545,y:533,t:1527023509414};\\\", \\\"{x:568,y:545,t:1527023509433};\\\", \\\"{x:587,y:552,t:1527023509449};\\\", \\\"{x:610,y:561,t:1527023509465};\\\", \\\"{x:628,y:567,t:1527023509482};\\\", \\\"{x:652,y:573,t:1527023509499};\\\", \\\"{x:676,y:579,t:1527023509516};\\\", \\\"{x:699,y:581,t:1527023509532};\\\", \\\"{x:719,y:584,t:1527023509549};\\\", \\\"{x:733,y:585,t:1527023509564};\\\", \\\"{x:744,y:585,t:1527023509582};\\\", \\\"{x:749,y:585,t:1527023509599};\\\", \\\"{x:752,y:585,t:1527023509616};\\\", \\\"{x:756,y:585,t:1527023509632};\\\", \\\"{x:758,y:584,t:1527023509649};\\\", \\\"{x:761,y:583,t:1527023509666};\\\", \\\"{x:766,y:580,t:1527023509682};\\\", \\\"{x:771,y:578,t:1527023509700};\\\", \\\"{x:772,y:577,t:1527023509716};\\\", \\\"{x:773,y:577,t:1527023509732};\\\", \\\"{x:780,y:577,t:1527023509749};\\\", \\\"{x:793,y:578,t:1527023509765};\\\", \\\"{x:816,y:580,t:1527023509783};\\\", \\\"{x:829,y:583,t:1527023509799};\\\", \\\"{x:839,y:584,t:1527023509815};\\\", \\\"{x:841,y:585,t:1527023509832};\\\", \\\"{x:842,y:585,t:1527023509849};\\\", \\\"{x:844,y:585,t:1527023509866};\\\", \\\"{x:844,y:584,t:1527023510101};\\\", \\\"{x:844,y:583,t:1527023510116};\\\", \\\"{x:844,y:580,t:1527023510132};\\\", \\\"{x:843,y:580,t:1527023510149};\\\", \\\"{x:842,y:578,t:1527023510167};\\\", \\\"{x:841,y:576,t:1527023510183};\\\", \\\"{x:840,y:576,t:1527023510199};\\\", \\\"{x:839,y:574,t:1527023510216};\\\", \\\"{x:837,y:574,t:1527023510236};\\\", \\\"{x:837,y:573,t:1527023510249};\\\", \\\"{x:836,y:573,t:1527023510268};\\\", \\\"{x:836,y:572,t:1527023510284};\\\", \\\"{x:835,y:571,t:1527023510300};\\\", \\\"{x:835,y:570,t:1527023510372};\\\", \\\"{x:834,y:569,t:1527023510388};\\\", \\\"{x:834,y:568,t:1527023510493};\\\", \\\"{x:832,y:568,t:1527023510892};\\\", \\\"{x:827,y:569,t:1527023510900};\\\", \\\"{x:808,y:576,t:1527023510917};\\\", \\\"{x:786,y:582,t:1527023510933};\\\", \\\"{x:762,y:590,t:1527023510950};\\\", \\\"{x:748,y:597,t:1527023510966};\\\", \\\"{x:723,y:604,t:1527023510982};\\\", \\\"{x:692,y:608,t:1527023511000};\\\", \\\"{x:654,y:616,t:1527023511017};\\\", \\\"{x:619,y:623,t:1527023511033};\\\", \\\"{x:587,y:633,t:1527023511050};\\\", \\\"{x:564,y:638,t:1527023511067};\\\", \\\"{x:553,y:641,t:1527023511083};\\\", \\\"{x:547,y:642,t:1527023511100};\\\", \\\"{x:546,y:643,t:1527023511116};\\\", \\\"{x:542,y:644,t:1527023511133};\\\", \\\"{x:535,y:648,t:1527023511150};\\\", \\\"{x:529,y:651,t:1527023511167};\\\", \\\"{x:524,y:655,t:1527023511183};\\\", \\\"{x:519,y:657,t:1527023511200};\\\", \\\"{x:516,y:660,t:1527023511217};\\\", \\\"{x:514,y:663,t:1527023511233};\\\", \\\"{x:512,y:667,t:1527023511251};\\\", \\\"{x:510,y:670,t:1527023511267};\\\", \\\"{x:508,y:674,t:1527023511284};\\\", \\\"{x:507,y:677,t:1527023511300};\\\", \\\"{x:507,y:680,t:1527023511317};\\\", \\\"{x:506,y:682,t:1527023511334};\\\", \\\"{x:505,y:683,t:1527023511356};\\\" ] }, { \\\"rt\\\": 6017, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 575919, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"JYZGH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"O\\\", \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:504,y:682,t:1527023513701};\\\", \\\"{x:502,y:676,t:1527023513708};\\\", \\\"{x:500,y:671,t:1527023513719};\\\", \\\"{x:494,y:657,t:1527023513736};\\\", \\\"{x:484,y:636,t:1527023513753};\\\", \\\"{x:462,y:600,t:1527023513770};\\\", \\\"{x:448,y:573,t:1527023513786};\\\", \\\"{x:433,y:552,t:1527023513802};\\\", \\\"{x:421,y:532,t:1527023513819};\\\", \\\"{x:408,y:509,t:1527023513836};\\\", \\\"{x:400,y:493,t:1527023513852};\\\", \\\"{x:394,y:475,t:1527023513868};\\\", \\\"{x:391,y:462,t:1527023513886};\\\", \\\"{x:390,y:450,t:1527023513902};\\\", \\\"{x:389,y:441,t:1527023513919};\\\", \\\"{x:389,y:439,t:1527023513936};\\\", \\\"{x:389,y:437,t:1527023513951};\\\", \\\"{x:390,y:436,t:1527023514020};\\\", \\\"{x:398,y:436,t:1527023514035};\\\", \\\"{x:404,y:436,t:1527023514052};\\\", \\\"{x:409,y:437,t:1527023514069};\\\", \\\"{x:417,y:439,t:1527023514086};\\\", \\\"{x:426,y:442,t:1527023514102};\\\", \\\"{x:428,y:442,t:1527023514119};\\\", \\\"{x:432,y:444,t:1527023514135};\\\", \\\"{x:434,y:445,t:1527023514152};\\\", \\\"{x:437,y:446,t:1527023514168};\\\", \\\"{x:443,y:447,t:1527023514186};\\\", \\\"{x:452,y:450,t:1527023514202};\\\", \\\"{x:468,y:454,t:1527023514219};\\\", \\\"{x:498,y:458,t:1527023514235};\\\", \\\"{x:515,y:459,t:1527023514253};\\\", \\\"{x:530,y:460,t:1527023514269};\\\", \\\"{x:541,y:463,t:1527023514286};\\\", \\\"{x:548,y:463,t:1527023514303};\\\", \\\"{x:557,y:464,t:1527023514319};\\\", \\\"{x:564,y:465,t:1527023514337};\\\", \\\"{x:574,y:466,t:1527023514353};\\\", \\\"{x:588,y:468,t:1527023514369};\\\", \\\"{x:597,y:469,t:1527023514386};\\\", \\\"{x:611,y:471,t:1527023514403};\\\", \\\"{x:627,y:471,t:1527023514419};\\\", \\\"{x:662,y:476,t:1527023514437};\\\", \\\"{x:683,y:480,t:1527023514453};\\\", \\\"{x:706,y:484,t:1527023514468};\\\", \\\"{x:724,y:487,t:1527023514487};\\\", \\\"{x:735,y:490,t:1527023514503};\\\", \\\"{x:745,y:495,t:1527023514519};\\\", \\\"{x:750,y:495,t:1527023514536};\\\", \\\"{x:752,y:496,t:1527023514553};\\\", \\\"{x:753,y:496,t:1527023514568};\\\", \\\"{x:754,y:496,t:1527023514604};\\\", \\\"{x:755,y:496,t:1527023514628};\\\", \\\"{x:756,y:496,t:1527023514636};\\\", \\\"{x:757,y:496,t:1527023514797};\\\", \\\"{x:756,y:496,t:1527023515004};\\\", \\\"{x:755,y:496,t:1527023515020};\\\", \\\"{x:751,y:495,t:1527023515036};\\\", \\\"{x:751,y:493,t:1527023515060};\\\", \\\"{x:751,y:491,t:1527023515070};\\\", \\\"{x:751,y:485,t:1527023515086};\\\", \\\"{x:752,y:482,t:1527023515104};\\\", \\\"{x:754,y:477,t:1527023515120};\\\", \\\"{x:755,y:476,t:1527023515136};\\\", \\\"{x:755,y:475,t:1527023515189};\\\", \\\"{x:755,y:474,t:1527023515203};\\\", \\\"{x:755,y:472,t:1527023515220};\\\", \\\"{x:746,y:466,t:1527023515237};\\\", \\\"{x:737,y:460,t:1527023515254};\\\", \\\"{x:729,y:456,t:1527023515270};\\\", \\\"{x:725,y:454,t:1527023515287};\\\", \\\"{x:724,y:454,t:1527023515303};\\\", \\\"{x:723,y:454,t:1527023515320};\\\", \\\"{x:723,y:455,t:1527023515380};\\\", \\\"{x:726,y:460,t:1527023515389};\\\", \\\"{x:736,y:466,t:1527023515404};\\\", \\\"{x:750,y:471,t:1527023515420};\\\", \\\"{x:755,y:472,t:1527023515437};\\\", \\\"{x:760,y:474,t:1527023515453};\\\", \\\"{x:761,y:474,t:1527023515470};\\\", \\\"{x:762,y:474,t:1527023515499};\\\", \\\"{x:764,y:474,t:1527023515508};\\\", \\\"{x:765,y:474,t:1527023515520};\\\", \\\"{x:769,y:474,t:1527023515537};\\\", \\\"{x:780,y:473,t:1527023515554};\\\", \\\"{x:786,y:472,t:1527023515571};\\\", \\\"{x:792,y:472,t:1527023515587};\\\", \\\"{x:802,y:470,t:1527023515604};\\\", \\\"{x:815,y:468,t:1527023515621};\\\", \\\"{x:823,y:465,t:1527023515637};\\\", \\\"{x:826,y:464,t:1527023515655};\\\", \\\"{x:827,y:464,t:1527023515692};\\\", \\\"{x:828,y:464,t:1527023515803};\\\", \\\"{x:828,y:463,t:1527023515843};\\\", \\\"{x:829,y:463,t:1527023515854};\\\", \\\"{x:829,y:461,t:1527023515870};\\\", \\\"{x:830,y:461,t:1527023515887};\\\", \\\"{x:831,y:461,t:1527023515904};\\\", \\\"{x:832,y:460,t:1527023515940};\\\", \\\"{x:833,y:458,t:1527023515964};\\\", \\\"{x:834,y:457,t:1527023515980};\\\", \\\"{x:836,y:454,t:1527023515996};\\\", \\\"{x:837,y:453,t:1527023516003};\\\", \\\"{x:837,y:452,t:1527023516028};\\\", \\\"{x:838,y:452,t:1527023516037};\\\", \\\"{x:837,y:453,t:1527023516468};\\\", \\\"{x:837,y:455,t:1527023516475};\\\", \\\"{x:837,y:458,t:1527023516488};\\\", \\\"{x:836,y:465,t:1527023516504};\\\", \\\"{x:836,y:472,t:1527023516522};\\\", \\\"{x:834,y:475,t:1527023516539};\\\", \\\"{x:834,y:479,t:1527023516554};\\\", \\\"{x:834,y:481,t:1527023516571};\\\", \\\"{x:834,y:489,t:1527023516588};\\\", \\\"{x:834,y:493,t:1527023516604};\\\", \\\"{x:833,y:501,t:1527023516622};\\\", \\\"{x:832,y:505,t:1527023516638};\\\", \\\"{x:832,y:510,t:1527023516654};\\\", \\\"{x:829,y:515,t:1527023516671};\\\", \\\"{x:829,y:518,t:1527023516688};\\\", \\\"{x:829,y:520,t:1527023516703};\\\", \\\"{x:829,y:522,t:1527023516723};\\\", \\\"{x:829,y:523,t:1527023516755};\\\", \\\"{x:828,y:525,t:1527023516772};\\\", \\\"{x:828,y:526,t:1527023516795};\\\", \\\"{x:828,y:527,t:1527023516811};\\\", \\\"{x:828,y:528,t:1527023517092};\\\", \\\"{x:826,y:529,t:1527023517105};\\\", \\\"{x:822,y:532,t:1527023517121};\\\", \\\"{x:818,y:535,t:1527023517137};\\\", \\\"{x:816,y:537,t:1527023517155};\\\", \\\"{x:810,y:541,t:1527023517172};\\\", \\\"{x:801,y:548,t:1527023517188};\\\", \\\"{x:792,y:551,t:1527023517205};\\\", \\\"{x:780,y:554,t:1527023517222};\\\", \\\"{x:766,y:560,t:1527023517237};\\\", \\\"{x:753,y:564,t:1527023517255};\\\", \\\"{x:737,y:568,t:1527023517272};\\\", \\\"{x:722,y:570,t:1527023517289};\\\", \\\"{x:713,y:571,t:1527023517305};\\\", \\\"{x:709,y:572,t:1527023517322};\\\", \\\"{x:706,y:572,t:1527023517338};\\\", \\\"{x:703,y:573,t:1527023517355};\\\", \\\"{x:693,y:573,t:1527023517371};\\\", \\\"{x:681,y:573,t:1527023517388};\\\", \\\"{x:665,y:573,t:1527023517406};\\\", \\\"{x:643,y:573,t:1527023517423};\\\", \\\"{x:627,y:573,t:1527023517438};\\\", \\\"{x:614,y:573,t:1527023517455};\\\", \\\"{x:611,y:573,t:1527023517472};\\\", \\\"{x:610,y:573,t:1527023517488};\\\", \\\"{x:607,y:573,t:1527023517505};\\\", \\\"{x:604,y:573,t:1527023517522};\\\", \\\"{x:602,y:572,t:1527023517538};\\\", \\\"{x:598,y:570,t:1527023517555};\\\", \\\"{x:591,y:568,t:1527023517571};\\\", \\\"{x:588,y:567,t:1527023517588};\\\", \\\"{x:585,y:567,t:1527023517606};\\\", \\\"{x:583,y:567,t:1527023517622};\\\", \\\"{x:583,y:566,t:1527023517638};\\\", \\\"{x:585,y:565,t:1527023517725};\\\", \\\"{x:587,y:565,t:1527023517739};\\\", \\\"{x:593,y:564,t:1527023517756};\\\", \\\"{x:601,y:564,t:1527023517773};\\\", \\\"{x:602,y:564,t:1527023517789};\\\", \\\"{x:603,y:564,t:1527023517804};\\\", \\\"{x:604,y:564,t:1527023517821};\\\", \\\"{x:605,y:564,t:1527023517844};\\\", \\\"{x:606,y:564,t:1527023517867};\\\", \\\"{x:607,y:564,t:1527023517892};\\\", \\\"{x:607,y:565,t:1527023518171};\\\", \\\"{x:598,y:577,t:1527023518189};\\\", \\\"{x:586,y:588,t:1527023518206};\\\", \\\"{x:574,y:603,t:1527023518222};\\\", \\\"{x:566,y:613,t:1527023518239};\\\", \\\"{x:565,y:617,t:1527023518255};\\\", \\\"{x:563,y:620,t:1527023518272};\\\", \\\"{x:563,y:622,t:1527023518289};\\\", \\\"{x:562,y:623,t:1527023518306};\\\", \\\"{x:561,y:624,t:1527023518322};\\\", \\\"{x:560,y:625,t:1527023518340};\\\", \\\"{x:559,y:626,t:1527023518356};\\\", \\\"{x:558,y:628,t:1527023518372};\\\", \\\"{x:557,y:630,t:1527023518389};\\\", \\\"{x:556,y:631,t:1527023518406};\\\", \\\"{x:555,y:632,t:1527023518423};\\\", \\\"{x:553,y:633,t:1527023518440};\\\", \\\"{x:552,y:634,t:1527023518469};\\\", \\\"{x:552,y:635,t:1527023518493};\\\", \\\"{x:551,y:636,t:1527023518506};\\\", \\\"{x:550,y:638,t:1527023518522};\\\", \\\"{x:549,y:640,t:1527023518539};\\\", \\\"{x:547,y:645,t:1527023518556};\\\", \\\"{x:546,y:647,t:1527023518573};\\\", \\\"{x:543,y:651,t:1527023518589};\\\", \\\"{x:543,y:655,t:1527023518606};\\\", \\\"{x:539,y:660,t:1527023518624};\\\", \\\"{x:535,y:665,t:1527023518640};\\\", \\\"{x:535,y:668,t:1527023518658};\\\", \\\"{x:534,y:670,t:1527023518673};\\\", \\\"{x:532,y:672,t:1527023518689};\\\", \\\"{x:532,y:673,t:1527023518706};\\\", \\\"{x:532,y:674,t:1527023518723};\\\", \\\"{x:531,y:675,t:1527023518738};\\\", \\\"{x:531,y:677,t:1527023518756};\\\", \\\"{x:529,y:678,t:1527023518773};\\\", \\\"{x:534,y:672,t:1527023519485};\\\", \\\"{x:537,y:666,t:1527023519492};\\\", \\\"{x:543,y:661,t:1527023519507};\\\", \\\"{x:546,y:657,t:1527023519524};\\\", \\\"{x:549,y:655,t:1527023519540};\\\", \\\"{x:549,y:654,t:1527023519557};\\\", \\\"{x:550,y:653,t:1527023519580};\\\", \\\"{x:551,y:652,t:1527023519644};\\\" ] }, { \\\"rt\\\": 7180, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 584475, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"JYZGH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 4, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\", \\\"M\\\", \\\"L\\\", \\\"D\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:551,y:648,t:1527023523085};\\\", \\\"{x:538,y:634,t:1527023523094};\\\", \\\"{x:509,y:596,t:1527023523110};\\\", \\\"{x:478,y:567,t:1527023523129};\\\", \\\"{x:445,y:535,t:1527023523143};\\\", \\\"{x:425,y:515,t:1527023523160};\\\", \\\"{x:402,y:496,t:1527023523194};\\\", \\\"{x:392,y:486,t:1527023523209};\\\", \\\"{x:385,y:479,t:1527023523227};\\\", \\\"{x:379,y:476,t:1527023523243};\\\", \\\"{x:373,y:472,t:1527023523260};\\\", \\\"{x:367,y:468,t:1527023523276};\\\", \\\"{x:359,y:465,t:1527023523293};\\\", \\\"{x:351,y:461,t:1527023523310};\\\", \\\"{x:343,y:459,t:1527023523326};\\\", \\\"{x:336,y:456,t:1527023523343};\\\", \\\"{x:331,y:456,t:1527023523360};\\\", \\\"{x:324,y:455,t:1527023523376};\\\", \\\"{x:317,y:454,t:1527023523393};\\\", \\\"{x:309,y:452,t:1527023523410};\\\", \\\"{x:303,y:451,t:1527023523427};\\\", \\\"{x:296,y:451,t:1527023523443};\\\", \\\"{x:285,y:451,t:1527023523460};\\\", \\\"{x:276,y:450,t:1527023523476};\\\", \\\"{x:267,y:449,t:1527023523495};\\\", \\\"{x:257,y:447,t:1527023523511};\\\", \\\"{x:243,y:445,t:1527023523526};\\\", \\\"{x:227,y:444,t:1527023523543};\\\", \\\"{x:208,y:441,t:1527023523560};\\\", \\\"{x:184,y:435,t:1527023523576};\\\", \\\"{x:168,y:434,t:1527023523593};\\\", \\\"{x:155,y:430,t:1527023523611};\\\", \\\"{x:138,y:428,t:1527023523627};\\\", \\\"{x:129,y:426,t:1527023523643};\\\", \\\"{x:125,y:426,t:1527023523660};\\\", \\\"{x:123,y:426,t:1527023523677};\\\", \\\"{x:121,y:427,t:1527023523693};\\\", \\\"{x:119,y:428,t:1527023523710};\\\", \\\"{x:115,y:431,t:1527023523728};\\\", \\\"{x:112,y:438,t:1527023523743};\\\", \\\"{x:112,y:446,t:1527023523761};\\\", \\\"{x:112,y:453,t:1527023523778};\\\", \\\"{x:117,y:460,t:1527023523793};\\\", \\\"{x:122,y:467,t:1527023523811};\\\", \\\"{x:127,y:468,t:1527023523826};\\\", \\\"{x:131,y:471,t:1527023523843};\\\", \\\"{x:138,y:473,t:1527023523860};\\\", \\\"{x:143,y:473,t:1527023523877};\\\", \\\"{x:146,y:473,t:1527023523893};\\\", \\\"{x:147,y:473,t:1527023523911};\\\", \\\"{x:149,y:473,t:1527023524000};\\\", \\\"{x:149,y:472,t:1527023524010};\\\", \\\"{x:149,y:470,t:1527023524026};\\\", \\\"{x:149,y:468,t:1527023524043};\\\", \\\"{x:149,y:467,t:1527023524060};\\\", \\\"{x:149,y:466,t:1527023524076};\\\", \\\"{x:150,y:465,t:1527023524107};\\\", \\\"{x:150,y:464,t:1527023524116};\\\", \\\"{x:152,y:464,t:1527023524132};\\\", \\\"{x:154,y:463,t:1527023524156};\\\", \\\"{x:156,y:463,t:1527023524436};\\\", \\\"{x:163,y:464,t:1527023524443};\\\", \\\"{x:197,y:483,t:1527023524461};\\\", \\\"{x:224,y:497,t:1527023524477};\\\", \\\"{x:274,y:518,t:1527023524494};\\\", \\\"{x:319,y:533,t:1527023524512};\\\", \\\"{x:346,y:540,t:1527023524527};\\\", \\\"{x:371,y:545,t:1527023524544};\\\", \\\"{x:387,y:547,t:1527023524561};\\\", \\\"{x:395,y:547,t:1527023524577};\\\", \\\"{x:396,y:547,t:1527023524594};\\\", \\\"{x:397,y:547,t:1527023524612};\\\", \\\"{x:399,y:546,t:1527023524652};\\\", \\\"{x:399,y:545,t:1527023524661};\\\", \\\"{x:399,y:543,t:1527023524677};\\\", \\\"{x:399,y:538,t:1527023524695};\\\", \\\"{x:399,y:536,t:1527023524712};\\\", \\\"{x:399,y:532,t:1527023524727};\\\", \\\"{x:398,y:529,t:1527023524745};\\\", \\\"{x:398,y:525,t:1527023524762};\\\", \\\"{x:397,y:521,t:1527023524778};\\\", \\\"{x:396,y:519,t:1527023524795};\\\", \\\"{x:395,y:516,t:1527023524812};\\\", \\\"{x:394,y:513,t:1527023524828};\\\", \\\"{x:394,y:511,t:1527023524844};\\\", \\\"{x:393,y:509,t:1527023524861};\\\", \\\"{x:392,y:507,t:1527023524878};\\\", \\\"{x:391,y:507,t:1527023524894};\\\", \\\"{x:390,y:506,t:1527023524911};\\\", \\\"{x:389,y:504,t:1527023524932};\\\", \\\"{x:388,y:503,t:1527023524947};\\\", \\\"{x:387,y:503,t:1527023524962};\\\", \\\"{x:387,y:502,t:1527023525228};\\\", \\\"{x:386,y:505,t:1527023525244};\\\", \\\"{x:386,y:512,t:1527023525261};\\\", \\\"{x:386,y:522,t:1527023525279};\\\", \\\"{x:387,y:532,t:1527023525295};\\\", \\\"{x:391,y:545,t:1527023525312};\\\", \\\"{x:395,y:554,t:1527023525329};\\\", \\\"{x:399,y:565,t:1527023525345};\\\", \\\"{x:401,y:573,t:1527023525361};\\\", \\\"{x:403,y:582,t:1527023525378};\\\", \\\"{x:405,y:588,t:1527023525395};\\\", \\\"{x:406,y:591,t:1527023525411};\\\", \\\"{x:406,y:592,t:1527023525428};\\\", \\\"{x:405,y:593,t:1527023525582};\\\", \\\"{x:403,y:593,t:1527023525596};\\\", \\\"{x:401,y:592,t:1527023525612};\\\", \\\"{x:399,y:590,t:1527023525628};\\\", \\\"{x:396,y:587,t:1527023525645};\\\", \\\"{x:394,y:585,t:1527023525662};\\\", \\\"{x:393,y:582,t:1527023525678};\\\", \\\"{x:393,y:581,t:1527023525695};\\\", \\\"{x:393,y:580,t:1527023525712};\\\", \\\"{x:392,y:579,t:1527023525729};\\\", \\\"{x:392,y:577,t:1527023525746};\\\", \\\"{x:390,y:577,t:1527023526036};\\\", \\\"{x:389,y:581,t:1527023526045};\\\", \\\"{x:387,y:588,t:1527023526062};\\\", \\\"{x:386,y:598,t:1527023526079};\\\", \\\"{x:385,y:603,t:1527023526097};\\\", \\\"{x:385,y:605,t:1527023526112};\\\", \\\"{x:385,y:606,t:1527023526129};\\\", \\\"{x:385,y:607,t:1527023526145};\\\", \\\"{x:385,y:608,t:1527023526164};\\\", \\\"{x:385,y:609,t:1527023526179};\\\", \\\"{x:385,y:611,t:1527023526196};\\\", \\\"{x:385,y:613,t:1527023526212};\\\", \\\"{x:385,y:616,t:1527023526229};\\\", \\\"{x:385,y:618,t:1527023526246};\\\", \\\"{x:385,y:619,t:1527023526268};\\\", \\\"{x:385,y:621,t:1527023526564};\\\", \\\"{x:392,y:629,t:1527023526580};\\\", \\\"{x:402,y:639,t:1527023526596};\\\", \\\"{x:412,y:648,t:1527023526612};\\\", \\\"{x:422,y:657,t:1527023526629};\\\", \\\"{x:432,y:665,t:1527023526645};\\\", \\\"{x:443,y:675,t:1527023526662};\\\", \\\"{x:454,y:683,t:1527023526680};\\\", \\\"{x:464,y:692,t:1527023526696};\\\", \\\"{x:475,y:698,t:1527023526712};\\\", \\\"{x:482,y:704,t:1527023526729};\\\", \\\"{x:485,y:707,t:1527023526746};\\\", \\\"{x:489,y:709,t:1527023526763};\\\", \\\"{x:492,y:711,t:1527023526780};\\\", \\\"{x:493,y:712,t:1527023526796};\\\", \\\"{x:494,y:712,t:1527023526820};\\\", \\\"{x:493,y:710,t:1527023527045};\\\", \\\"{x:493,y:709,t:1527023527061};\\\", \\\"{x:492,y:708,t:1527023527076};\\\", \\\"{x:492,y:707,t:1527023527133};\\\", \\\"{x:491,y:707,t:1527023527165};\\\", \\\"{x:489,y:705,t:1527023527301};\\\", \\\"{x:489,y:704,t:1527023527314};\\\", \\\"{x:488,y:703,t:1527023527330};\\\", \\\"{x:488,y:702,t:1527023527347};\\\", \\\"{x:488,y:701,t:1527023528276};\\\" ] }, { \\\"rt\\\": 33010, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 618777, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"JYZGH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"I look at the bottom where 12 pm says started \\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 14518, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States of America\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 634301, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"JYZGH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 14426, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Humanities\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 649744, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"JYZGH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 48255, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 699347, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"JYZGH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"JYZGH\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 124, dom: 1014, initialDom: 1130",
  "javascriptErrors": []
}