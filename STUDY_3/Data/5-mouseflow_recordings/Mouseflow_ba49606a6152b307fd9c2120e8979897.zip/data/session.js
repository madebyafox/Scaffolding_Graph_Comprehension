var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "ba49606a6152b307fd9c2120e8979897",
  "created": "2018-05-15T14:07:11.4030472-07:00",
  "lastActivity": "2018-05-15T14:07:47.8510472-07:00",
  "pageViews": [
    {
      "id": "051512105c8d7629db36d600e9d9e95cd2e1169a",
      "startTime": "2018-05-15T14:07:11.4030472-07:00",
      "endTime": "2018-05-15T14:07:47.8510472-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 36448,
      "engagementTime": 29246,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 36448,
  "engagementTime": 29246,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=B4LD9",
    "CONDITION=111"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "88aae7823298cdc73d39aa2ca9aaeec1",
  "gdpr": false
}