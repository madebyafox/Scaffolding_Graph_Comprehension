var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "3937c3432cbd8df8697428b3e780c228",
  "created": "2018-05-25T09:11:10.5687006-07:00",
  "lastActivity": "2018-05-25T09:11:37.6837006-07:00",
  "pageViews": [
    {
      "id": "05251038874065225f866eddc149199d94b7caf8",
      "startTime": "2018-05-25T09:11:10.5687006-07:00",
      "endTime": "2018-05-25T09:11:37.6837006-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 27115,
      "engagementTime": 19266,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 27115,
  "engagementTime": 19266,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.35",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=RV9F6",
    "CONDITION=115",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "92ffdfacb44d662fe17bc30c5d1e7210",
  "gdpr": false
}