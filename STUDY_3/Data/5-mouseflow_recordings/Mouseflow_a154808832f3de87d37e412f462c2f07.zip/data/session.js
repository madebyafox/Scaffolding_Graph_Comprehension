var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a154808832f3de87d37e412f462c2f07",
  "created": "2018-05-21T12:11:01.2882683-07:00",
  "lastActivity": "2018-05-21T12:12:13.5230382-07:00",
  "pageViews": [
    {
      "id": "05210103fb9031b7180a998ce96732cb63346aa6",
      "startTime": "2018-05-21T12:11:01.4929563-07:00",
      "endTime": "2018-05-21T12:12:13.5230382-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 72408,
      "engagementTime": 69558,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 72408,
  "engagementTime": 69558,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.34",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=GQ35Z",
    "CONDITION=111",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d57725a9e0f6b4e08bcb3316bed9bb5d",
  "gdpr": false
}